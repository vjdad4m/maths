import ThirteenLower384b
import ShorePairs

namespace Graffiti384b.DiversityEleven
open Finset SimpleGraph ShorePairs
open private Repair.nbr_add Repair.full_nbr Repair.omit_set from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A graph on six labels has a suitable retained pair if vertices of zero
external support have distinct internal triangle counts at least two. -/
def SixSelector : Prop :=
  ∀ (H : SimpleGraph (Fin 6)) (dec : DecidableRel H.Adj) (Z : Finset (Fin 6)),
    letI := dec
    (∀ x∈Z, 3≤H.degree x ∧ 2≤trianglesAt H x) →
    Set.InjOn (trianglesAt H) (Z : Set (Fin 6)) →
    ∃ p q : Fin 6, p≠q ∧ ∀ i, i≠p → i≠q →
      ((i∈Z → H.Adj i p ∧ H.Adj i q) ∧
       (i∉Z → 2≤H.degree i → H.Adj i p ∨ H.Adj i q))

private theorem on_range (U : Finset V) (a : Fin 6 ≃ U) (i : Fin 6)
    (closed : ∀ w,G.Adj (a i).val w → w∈U) :
    let H := G.comap (fun i => (a i).val)
    letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
    trianglesAt H i=trianglesAt G (a i).val := by
  classical
  let H := G.comap (fun i => (a i).val)
  letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
  let em : Fin 6 ↪ V := a.toEmbedding.trans (Function.Embedding.subtype _)
  change (pairs H (H.neighborFinset i)).card = (pairs G (G.neighborFinset (a i).val)).card
  have eq : (pairs H (H.neighborFinset i)).image (fun s=>s.map em)=
      pairs G (G.neighborFinset (a i).val) := by
    ext p
    constructor
    · intro pm
      obtain ⟨q,qs,rfl⟩ := mem_image.mp pm
      obtain ⟨x,xm,y,ym,xy,rfl⟩ := (pair_mem H).mp qs
      have x1 : (a x).val∈G.neighborFinset (a i).val := (G.mem_neighborFinset ..).mpr
        ((H.mem_neighborFinset ..).mp xm)
      have y1 : (a y).val∈G.neighborFinset (a i).val := (G.mem_neighborFinset ..).mpr
        ((H.mem_neighborFinset ..).mp ym)
      exact (pair_mem G).mpr ⟨(a x).val,x1,(a y).val,y1,xy,by simp [em]⟩
    · intro pm
      obtain ⟨x,xm,y,ym,xy,rfl⟩ := (pair_mem G).mp pm
      have xu : x∈U := closed x ((G.mem_neighborFinset ..).mp xm)
      have yu : y∈U := closed y ((G.mem_neighborFinset ..).mp ym)
      let xi : Fin 6 := a.symm ⟨x,xu⟩
      let yi : Fin 6 := a.symm ⟨y,yu⟩
      have xx : (a xi).val=x := by simp [xi]
      have yy : (a yi).val=y := by simp [yi]
      have jx : xi∈H.neighborFinset i := (H.mem_neighborFinset ..).mpr
        (by change G.Adj (a i).val (a xi).val; rw [xx]; exact (G.mem_neighborFinset ..).mp xm)
      have jy : yi∈H.neighborFinset i := (H.mem_neighborFinset ..).mpr
        (by change G.Adj (a i).val (a yi).val; rw [yy]; exact (G.mem_neighborFinset ..).mp ym)
      have e : H.Adj xi yi := by change G.Adj (a xi).val (a yi).val; rwa [xx,yy]
      exact mem_image.mpr ⟨{xi,yi},(pair_mem H).mpr ⟨xi,jx,yi,jy,e,rfl⟩,by
        simp [em,xi,yi]⟩
  rw [←eq,card_image_of_injective _ (Finset.map_injective em)]

omit [Fintype V] [DecidableEq V] in
private theorem count_in_range (U : Finset V) (a : Fin 6 ≃ U) (i : Fin 6) :
    let H := G.comap (fun i => (a i).val)
    letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
    H.degree i=nbr G (a i).val U := by
  classical
  let H := G.comap (fun i => (a i).val)
  letI : DecidableRel H.Adj := fun x y => inferInstanceAs (Decidable (G.Adj (a x).val (a y).val))
  let em : Fin 6 ↪ V := a.toEmbedding.trans (Function.Embedding.subtype _)
  have eq : (H.neighborFinset i).map em = U.filter (G.Adj (a i).val) := by
    ext x
    constructor
    · intro xm
      obtain ⟨j,jm,rfl⟩ := mem_map.mp xm
      exact mem_filter.mpr ⟨(a j).property,(H.mem_neighborFinset ..).mp jm⟩
    · intro xm
      obtain ⟨xu,ix⟩ := mem_filter.mp xm
      let j : Fin 6 := a.symm ⟨x,xu⟩
      have eq : (a j).val=x := by simp [j]
      refine mem_map.mpr ⟨j,(H.mem_neighborFinset ..).mpr ?_,eq⟩
      change G.Adj (a i).val (a j).val
      rwa [eq]
  change H.degree i=(U.filter (G.Adj (a i).val)).card
  rw [←eq,card_map,card_neighborFinset_eq_degree]

/-- Two baseline low omissions touching at most three highs close the
diversity-eleven bound, assuming the six-label graph selector. -/
theorem exact_of_two_low_footprint_three (select : SixSelector)
    (t : (types G).card=11) (nine : (high G).card=9)
    (scores : Set.InjOn (trianglesAt G) (high G : Set V))
    (min : ∀ x∈high G,2≤trianglesAt G x) {O P : Finset V}
    (two : 2≤O.card) (low : Disjoint O (high G))
    (deg : ∀ e∈O,2≤G.degree e)
    (ind : ∀ x∈O,∀ y∈O,¬G.Adj x y)
    (touch : ∀ z∈high G,(∃ x∈O,G.Adj x z)→z∈P)
    (three : P.card≤3) : gamma G≤bound G := by
  classical
  have un : 6≤((high G)\P).card := by
    have h := card_le_card (show high G∩P ⊆ P from inter_subset_right)
    have c := card_sdiff_add_card_eq_card (show high G∩P ⊆ high G from inter_subset_left)
    have eq : high G \ (high G∩P)=high G \ P := by ext x; simp
    rw [eq] at c
    omega
  obtain ⟨U,us,sz⟩ := exists_subset_card_eq un
  let a : Fin 6 ≃ U := (Fintype.equivFinOfCardEq
    (show Fintype.card U=6 by rwa [Fintype.card_coe])).symm
  let H := G.comap (fun i => (a i).val)
  let dec : DecidableRel H.Adj := fun i j => inferInstanceAs (Decidable (G.Adj (a i).val (a j).val))
  letI := dec
  let R := (O∪U)ᶜ
  let Z := univ.filter (fun i : Fin 6 => nbr G (a i).val R=0)
  have uh : U ⊆ high G := us.trans sdiff_subset
  have dj : Disjoint O U := low.mono_right uh
  have free (x : V) (xo : x∈O) (u : V) (uu : u∈U) : ¬G.Adj x u :=
    fun e=>(mem_sdiff.mp (us uu)).2 (touch u (uh uu) ⟨x,xo,e⟩)
  have dz (i : Fin 6) : H.degree i=nbr G (a i).val U := count_in_range G U a i
  have split (i : Fin 6) : G.degree (a i).val=H.degree i+nbr G (a i).val R := by
    have z : nbr G (a i).val O=0 := by
      rw [nbr,filter_eq_empty_iff.mpr (fun x xo e=>free x xo (a i).val (a i).property e.symm),
        card_empty]
    have f := Repair.full_nbr G (a i).val (O∪U)
    rw [Repair.nbr_add G (a i).val dj,z,zero_add,←dz i] at f
    exact f.symm
  have zz (i : Fin 6) : i∈Z ↔ nbr G (a i).val R=0 := by simp [Z]
  have score (i : Fin 6) (iz : i∈Z) : trianglesAt H i=trianglesAt G (a i).val := by
    apply on_range G U a i
    intro w aw
    by_contra wu
    have wo : w∉O := fun wo => free w wo (a i).val (a i).property aw.symm
    have wr : w∈R := mem_compl.mpr (fun wm => (mem_union.mp wm).elim wo wu)
    have n : 0<nbr G (a i).val R := card_pos.mpr ⟨w,mem_filter.mpr ⟨wr,aw⟩⟩
    rw [(zz i).mp iz] at n
    omega
  have jmin : ∀ i∈Z,3≤H.degree i ∧ 2≤trianglesAt H i := by
    intro i iz
    have dh := (mem_filter.mp (uh (a i).property)).2
    rw [split i,(zz i).mp iz] at dh
    exact ⟨by omega,(score i iz).symm ▸ min _ (uh (a i).property)⟩
  have ji : Set.InjOn (trianglesAt H) (Z : Set (Fin 6)) := by
    intro i iz j jz eq
    apply a.injective
    apply Subtype.ext
    apply scores (uh (a i).property) (uh (a j).property)
    exact (score i iz).symm.trans (eq.trans (score j jz))
  obtain ⟨p,q,pq,good⟩ := select H dec Z jmin ji
  let M : Finset V := {(a p).val,(a q).val}
  have mu : M ⊆ U := insert_subset (a p).property (singleton_subset_iff.mpr (a q).property)
  have dM : (a p).val≠(a q).val := fun eq=>pq (a.injective (Subtype.ext eq))
  have mc : M.card=2 := card_pair dM
  let T := O∪(U\M)
  have tc : 6≤T.card := by
    change 6≤(O∪(U\M)).card
    rw [card_union_of_disjoint (dj.mono_right sdiff_subset),card_sdiff mu,sz,mc]
    omega
  have rM : Disjoint R M := by
    refine Finset.disjoint_left.mpr (fun x xr xm => ?_)
    exact (mem_compl.mp xr) (mem_union_right _ (mu xm))
  have tail : Tᶜ=R∪M := by
    ext x
    simp only [T,R,mem_compl,mem_union,mem_sdiff]
    constructor
    · intro h
      by_cases hm : x∈M
      · exact Or.inr hm
      · exact Or.inl (fun hx=>h (hx.elim Or.inl (fun hu=>Or.inr ⟨hu,hm⟩)))
    · intro h
      rcases h with hr|hm
      · exact fun ht=>hr (ht.elim Or.inl (fun h=>Or.inr h.1))
      · intro ht
        rcases ht with ho|⟨_,hn⟩
        · exact Finset.disjoint_left.mp dj ho (mu hm)
        · exact hn hm
  have enough : ∀ x∈T,2≤nbr G x Tᶜ := by
    intro x xm
    rcases mem_union.mp xm with xo|xu
    · have f : R.filter (G.Adj x)=G.neighborFinset x := by
        ext w
        simp only [mem_filter,mem_neighborFinset]
        exact ⟨And.right,fun h=>⟨mem_compl.mpr (fun wo =>
          (mem_union.mp wo).elim (fun wo=>ind x xo w wo h) (fun wu=>free x xo w wu h)),h⟩⟩
      rw [tail,Repair.nbr_add G x rM,nbr,f,card_neighborFinset_eq_degree]
      have d := deg x xo
      omega
    · obtain ⟨uu,um⟩ := mem_sdiff.mp xu
      let i : Fin 6 := a.symm ⟨x,uu⟩
      have ix : (a i).val=x := by simp [i]
      have ip : i≠p := fun eq=>um (by rw [←ix,eq]; exact mem_insert_self ..)
      have iq : i≠q := fun eq=>um (by rw [←ix,eq]; exact mem_insert_of_mem (mem_singleton_self _))
      rw [tail,Repair.nbr_add G x rM]
      by_cases iz : i∈Z
      · obtain ⟨ap,aq⟩ := (good i ip iq).1 iz
        have p1 : G.Adj x (a p).val := by rw [←ix]; exact ap
        have q1 : G.Adj x (a q).val := by rw [←ix]; exact aq
        have n : nbr G x M=2 := by
          unfold nbr
          rw [filter_eq_self.mpr (fun y ym => by
            rcases (show y=(a p).val ∨ y=(a q).val by simpa [M] using ym) with rfl|rfl
            · exact p1
            · exact q1),mc]
        omega
      · have ext : 0<nbr G x R := by
          by_contra! h
          have e : nbr G (a i).val R=0 := by rw [ix]; omega
          exact iz ((zz i).mpr e)
        by_cases r : 2≤nbr G x R
        · omega
        · have d : 3≤G.degree (a i).val := (mem_filter.mp (uh (a i).property)).2
          rw [split i,ix] at d
          have hd : 2≤H.degree i := by omega
          have one : 0<nbr G x M := by
            rcases (good i ip iq).2 iz hd with p1|q1
            · exact card_pos.mpr ⟨(a p).val,mem_filter.mpr
                ⟨mem_insert_self ..,by rw [←ix]; exact p1⟩⟩
            · exact card_pos.mpr ⟨(a q).val,mem_filter.mpr
                ⟨mem_insert_of_mem (mem_singleton_self _),by rw [←ix]; exact q1⟩⟩
          omega
  have om := Repair.omit_set G T enough
  unfold bound
  rw [t]
  omega

#print axioms exact_of_two_low_footprint_three
end Graffiti384b.DiversityEleven
