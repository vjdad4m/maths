import Mathlib.Data.Finset.Card
import Mathlib.Tactic.FinCases
import Init.Data.BitVec.Lemmas

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 40000

def vertices : List Nat := [0,1,2,3,4,5]

def pairs6 : List (Nat×Nat) :=
  [(0,1),(0,2),(1,2),(0,3),(1,3),(2,3),(0,4),(1,4),(2,4),(3,4),
    (0,5),(1,5),(2,5),(3,5),(4,5)]

def edge (g i j : Nat) : Bool :=
  let a := min i j
  let b := max i j
  i != j && g.testBit (b*(b-1)/2+a)

def deg (g i : Nat) : Nat := (vertices.filter (edge g i)).length

def tri (g i : Nat) : Nat :=
  (pairs6.filter (fun (u,v)=>edge g i u && edge g i v && edge g u v)).length

def ordered (g : Nat) : Bool :=
  deg g 0 ≤ deg g 1 && deg g 1 ≤ deg g 2 && deg g 2 ≤ deg g 3 &&
    deg g 3 ≤ deg g 4 && deg g 4 ≤ deg g 5

def valid (g z : Nat) : Bool :=
  vertices.all (fun i=> !z.testBit i || (deg g i ≥ 3 && tri g i ≥ 2)) &&
  pairs6.all (fun (i,j)=> !(z.testBit i && z.testBit j) || tri g i != tri g j)

def canKeep (g z p q : Nat) : Bool :=
  vertices.all (fun i=> i == p || i == q ||
    if z.testBit i then edge g i p && edge g i q
    else if deg g i ≥ 2 then edge g i p || edge g i q
    else true)

def solution (g z : Nat) : Bool := pairs6.any (fun (p,q)=>canKeep g z p q)

def check (g : Nat) : Bool :=
  !ordered g || (List.range 64).all (fun z=> !valid g z || solution g z)

def chunk (b : Nat) : Bool :=
  (List.range 256).all (fun offset=>check (256*b+offset))

set_option maxRecDepth 100000 in
theorem test_chunk : chunk 127=true := by decide

#print axioms test_chunk
end Graffiti384b.SixUntouched
