import SixUntouchedKernel384b
import Init.Data.Nat.Bitwise.Lemmas

namespace Graffiti384b.SixUntouched
set_option maxHeartbeats 0
set_option maxRecDepth 100000

def full : Nat := 18446744073709551615

def zeroMask : Nat → Nat
  | 0 => 6148914691236517205
  | 1 => 3689348814741910323
  | 2 => 1085102592571150095
  | 3 => 71777214294589695
  | 4 => 281470681808895
  | 5 => 4294967295
  | _ => 0

private theorem full_table : ∀ z : Fin 64,full.testBit z.val=true := by
  intro z
  fin_cases z <;> decide
private theorem zero_table : ∀ (i : Fin 6) (z : Fin 64),
    (zeroMask i.val).testBit z.val = !z.val.testBit i.val := by
  intro i z
  fin_cases i <;> fin_cases z <;> decide

private theorem full_bit {z : Nat} (zlt : z<64) : full.testBit z=true := full_table ⟨z,zlt⟩
private theorem zero_bit {i z : Nat} (ilt : i<6) (zlt : z<64) :
    (zeroMask i).testBit z = !z.testBit i := zero_table ⟨i,ilt⟩ ⟨z,zlt⟩

def andMasks {α : Type} (xs : List α) (f : α→Nat) : Nat :=
  xs.foldr (fun x a=>f x &&& a) full

def orMasks {α : Type} (xs : List α) (f : α→Nat) : Nat :=
  xs.foldr (fun x a=>f x ||| a) 0

private theorem and_mask_bit {α : Type} (xs : List α) (f : α→Nat) {z : Nat} (zlt : z<64) :
    (andMasks xs f).testBit z=xs.all (fun x=>(f x).testBit z) := by
  induction xs with
  | nil => exact full_bit zlt
  | cons x xs ih =>
    change (f x &&& andMasks xs f).testBit z = _
    rw [Nat.testBit_and,ih]
    rfl

private theorem or_mask_bit {α : Type} (xs : List α) (f : α→Nat) (z : Nat) :
    (orMasks xs f).testBit z=xs.any (fun x=>(f x).testBit z) := by
  induction xs with
  | nil => simp [orMasks]
  | cons x xs ih =>
    change (f x ||| orMasks xs f).testBit z = _
    rw [Nat.testBit_or,ih]
    rfl

theorem vertex_lt {i : Nat} (h : i∈vertices) : i<6 := by simp [vertices] at h; omega

theorem pair_lt {p : Nat×Nat} (h : p∈pairs6) : p.1<6 ∧ p.2<6 ∧ p.1<p.2 := by
  rcases p with ⟨a,b⟩
  simp only [pairs6,List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at h
  omega

def localValid (g i : Nat) : Nat :=
  if deg g i ≥ 3 && tri g i ≥ 2 then full else zeroMask i

def pairedValid (g : Nat) (p : Nat×Nat) : Nat :=
  if tri g p.1 == tri g p.2 then zeroMask p.1 ||| zeroMask p.2 else full

def masksValid (g : Nat) : Nat :=
  andMasks vertices (localValid g) &&& andMasks pairs6 (pairedValid g)

def localKeep (g p q i : Nat) : Nat :=
  if i == p || i == q || (edge g i p && edge g i q) then full
  else if deg g i ≥ 2 && !(edge g i p || edge g i q) then 0
  else zeroMask i

def masksKeep (g : Nat) : Nat :=
  orMasks pairs6 (fun (p,q)=>andMasks vertices (localKeep g p q))

private theorem local_valid_bit {g i z : Nat} (ilt : i<6) (zlt : z<64) :
    (localValid g i).testBit z = (!z.testBit i || (deg g i ≥ 3 && tri g i ≥ 2)) := by
  unfold localValid
  split <;> rename_i h <;> simp [h,full_bit zlt,zero_bit ilt zlt]

private theorem paired_valid_bit {g z : Nat} {p : Nat×Nat}
    (hlt : p.1<6 ∧ p.2<6) (zlt : z<64) :
    (pairedValid g p).testBit z =
      (!(z.testBit p.1 && z.testBit p.2) || tri g p.1 != tri g p.2) := by
  unfold pairedValid
  by_cases q : tri g p.1=tri g p.2 <;>
    cases ea : z.testBit p.1 <;> cases eb : z.testBit p.2 <;>
    simp [q,full_bit zlt,zero_bit hlt.1 zlt,zero_bit hlt.2 zlt,ea,eb]

private theorem all_congr {α : Type} (l : List α) {p q : α→Bool}
    (h : ∀ x∈l,p x=q x) : l.all p=l.all q := by
  induction l with
  | nil => rfl
  | cons x xs ih =>
    simp only [List.all_cons]
    rw [h x (List.mem_cons_self ..),ih (fun y ym => h y (List.mem_cons_of_mem _ ym))]

private theorem any_congr {α : Type} (l : List α) {p q : α→Bool}
    (h : ∀ x∈l,p x=q x) : l.any p=l.any q := by
  induction l with
  | nil => rfl
  | cons x xs ih =>
    simp only [List.any_cons]
    rw [h x (List.mem_cons_self ..),ih (fun y ym => h y (List.mem_cons_of_mem _ ym))]

theorem valid_bit {g z : Nat} (zlt : z<64) : (masksValid g).testBit z=valid g z := by
  unfold masksValid valid
  rw [Nat.testBit_and,and_mask_bit _ _ zlt,and_mask_bit _ _ zlt]
  congr 1
  · apply all_congr
    intro i hm
    exact local_valid_bit (vertex_lt hm) zlt
  · apply all_congr
    intro q hq
    have h := pair_lt hq
    exact paired_valid_bit ⟨h.1,h.2.1⟩ zlt

private theorem local_keep_bit {g p q i z : Nat} (ilt : i<6) (zlt : z<64) :
    (localKeep g p q i).testBit z =
       (i == p || i == q ||
         if z.testBit i then edge g i p && edge g i q
         else if deg g i ≥ 2 then edge g i p || edge g i q else true) := by
  unfold localKeep
  by_cases ep : i=p <;> by_cases eq : i=q <;> by_cases d : 2≤deg g i <;>
    cases e1 : edge g i p <;> cases e2 : edge g i q <;> cases ez : z.testBit i <;>
    simp [ep,eq,d,e1,e2,ez,full_bit zlt,zero_bit ilt zlt]

theorem keep_bit {g z : Nat} (zlt : z<64) : (masksKeep g).testBit z=solution g z := by
  unfold masksKeep solution
  rw [or_mask_bit]
  apply any_congr
  intro p hp
  rcases p with ⟨a,b⟩
  rw [and_mask_bit _ _ zlt]
  unfold canKeep
  apply all_congr
  intro i hi
  exact local_keep_bit (vertex_lt hi) zlt

def packed (g : Nat) : Bool := !ordered g || ((masksValid g &&& masksKeep g) == masksValid g)

def band (b : Nat) : Bool := (List.range 256).all (fun i=>packed (256*b+i))

theorem packed_sound {g z : Nat} (hc : packed g=true) (order : ordered g=true)
    (lim : z<64) (v : valid g z=true) : solution g z=true := by
  unfold packed at hc
  simp only [order,Bool.not_true,Bool.false_or,beq_iff_eq] at hc
  have e := congrArg (fun m : Nat => m.testBit z) hc
  change (masksValid g &&& masksKeep g).testBit z=(masksValid g).testBit z at e
  simpa [Nat.testBit_and,valid_bit lim,keep_bit lim,v] using e


#print axioms packed_sound
end Graffiti384b.SixUntouched
