import SixUntouchedTruth384b
import Q8Original384b
import Mathlib.Data.Fin.Tuple.Sort

namespace Graffiti384b.SixUntouched
open Finset SimpleGraph
open private Q8Original.triangle_comap from Q8Original384b
set_option maxHeartbeats 3000000

private theorem degree_comap (G : SimpleGraph Label) [DecidableRel G.Adj]
    (p : Label ≃ Label) (i : Label) :
    (G.comap p).degree i = G.degree (p i) := by
  have h : ((G.comap p).neighborFinset i).map p.toEmbedding = G.neighborFinset (p i) := by
    ext x
    obtain ⟨j,rfl⟩ := p.surjective x
    have m := Finset.mem_map' p.toEmbedding (a:=j) (s:=(G.comap p).neighborFinset i)
    change p j ∈ _ ↔ j ∈ _ at m
    rw [m,SimpleGraph.mem_neighborFinset,SimpleGraph.mem_neighborFinset]
    rfl
  rw [←G.card_neighborFinset_eq_degree,←h,Finset.card_map,SimpleGraph.card_neighborFinset_eq_degree]

/-- A degree-ordered selector is sufficient on all labelled six-vertex graphs. -/
theorem unsort_keep
    (select : ∀ (H : SimpleGraph Label) (dec : DecidableRel H.Adj) (Z : Finset Label),
      letI := dec
      Monotone (fun i : Label => H.degree i) →
      (∀ i∈Z, 3≤H.degree i ∧ 2≤trianglesAt H i) →
      Set.InjOn (trianglesAt H) (Z : Set Label) →
      ∃ p q : Label, p≠q ∧ Keeps H Z p q)
    (G : SimpleGraph Label) [DecidableRel G.Adj] (Z : Finset Label)
    (large : ∀ i∈Z, 3≤G.degree i ∧ 2≤trianglesAt G i)
    (distinct : Set.InjOn (trianglesAt G) (Z : Set Label)) :
    ∃ p q : Label, p≠q ∧ Keeps G Z p q := by
  let e : Label ≃ Label := Tuple.sort (fun i : Label => G.degree i)
  let H := G.comap (e : Label→Label)
  let dec : DecidableRel H.Adj := inferInstanceAs (DecidableRel (G.comap (e : Label→Label)).Adj)
  let Y := Z.map e.symm.toEmbedding
  have mem (i : Label) : i∈Y ↔ e i∈Z := by simp [Y]
  have deg (i : Label) : H.degree i = G.degree (e i) := degree_comap G e i
  have tri (i : Label) : trianglesAt H i = trianglesAt G (e i) := Q8Original.triangle_comap G e i
  have order : Monotone (fun i : Label => H.degree i) := by
    intro i j hij
    change H.degree i ≤ H.degree j
    rw [deg,deg]
    exact Tuple.monotone_sort (fun i : Label => G.degree i) hij
  have upper (i : Label) (iy : i∈Y) : 3≤H.degree i ∧ 2≤trianglesAt H i := by
    rw [deg,tri]
    exact large _ ((mem i).mp iy)
  have distinctY : Set.InjOn (trianglesAt H) (Y : Set Label) := by
    intro i hi j hj eq
    rw [tri,tri] at eq
    exact e.injective (distinct ((mem i).mp hi) ((mem j).mp hj) eq)
  obtain ⟨p,q,pq,keep⟩ := select H dec Y order upper distinctY
  refine ⟨e p,e q,e.injective.ne pq,?_⟩
  intro i ip iq
  obtain ⟨j,rfl⟩ := e.surjective i
  have k := keep j (fun eq => ip (congrArg e eq)) (fun eq => iq (congrArg e eq))
  constructor
  · intro iz
    exact k.1 ((mem j).mpr iz)
  · intro iz d
    exact k.2 (fun jy => iz ((mem j).mp jy)) (by rwa [deg])

end Graffiti384b.SixUntouched
#print axioms Graffiti384b.SixUntouched.unsort_keep
