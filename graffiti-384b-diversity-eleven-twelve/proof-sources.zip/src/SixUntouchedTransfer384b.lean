import SixUntouchedKernel384b
import EffectiveSearchScore384b

namespace Graffiti384b.SixUntouched
open SimpleGraph Finset
set_option maxHeartbeats 3000000
set_option maxRecDepth 16000

abbrev Label := Fin 6

private def graphBits (G : SimpleGraph Label) [DecidableRel G.Adj] : List Bool :=
  [decide (G.Adj 0 1),decide (G.Adj 0 2),decide (G.Adj 1 2),
   decide (G.Adj 0 3),decide (G.Adj 1 3),decide (G.Adj 2 3),
   decide (G.Adj 0 4),decide (G.Adj 1 4),decide (G.Adj 2 4),decide (G.Adj 3 4),
   decide (G.Adj 0 5),decide (G.Adj 1 5),decide (G.Adj 2 5),decide (G.Adj 3 5),decide (G.Adj 4 5)]

def encodeGraph (G : SimpleGraph Label) [DecidableRel G.Adj] : Fin 32768 :=
  let b := BitVec.ofBoolListLE (graphBits G)
  ⟨b.toNat, by simpa only [graphBits,List.length_cons,List.length_nil] using b.isLt⟩

theorem edge_encodeGraph (G : SimpleGraph Label) [DecidableRel G.Adj] (i j : Label) :
    edge (encodeGraph G).val i.val j.val = true ↔ G.Adj i j := by
  have data (n : Nat) : (encodeGraph G).val.testBit n = (graphBits G).getD n false := by
    change (BitVec.ofBoolListLE (graphBits G)).getLsbD n = _
    rw [BitVec.getLsb_ofBoolListLE]
  dsimp only [edge]
  rw [data]
  fin_cases i <;> fin_cases j <;>
    simp [graphBits]
  all_goals exact G.adj_comm _ _

private def zeroBits (Z : Finset Label) : List Bool :=
  [decide (0∈Z),decide (1∈Z),decide (2∈Z),decide (3∈Z),decide (4∈Z),decide (5∈Z)]

def encodeZero (Z : Finset Label) : Fin 64 :=
  let b := BitVec.ofBoolListLE (zeroBits Z)
  ⟨b.toNat, by simpa only [zeroBits,List.length_cons,List.length_nil] using b.isLt⟩

@[simp] theorem bit_encodeZero (Z : Finset Label) (i : Label) :
    (encodeZero Z).val.testBit i.val = true ↔ i∈Z := by
  change (BitVec.ofBoolListLE (zeroBits Z)).getLsbD i.val=true ↔ _
  rw [BitVec.getLsb_ofBoolListLE]
  fin_cases i <;> simp [zeroBits]

private def verticesFin : List Label := [0,1,2,3,4,5]
private theorem vertices_map : verticesFin.map Fin.val = vertices := by decide
private theorem vertices_nodup : verticesFin.Nodup := by decide
private theorem vertices_mem : ∀ j : Label, j∈verticesFin := by decide

theorem deg_encodeGraph (G : SimpleGraph Label) [DecidableRel G.Adj] (i : Label) :
    deg (encodeGraph G).val i.val = G.degree i := by
  let b := (encodeGraph G).val
  let L := verticesFin.filter (fun j => edge b i.val j.val)
  have l : (vertices.filter (edge b i.val)).length = L.length := by
    rw [←vertices_map,List.filter_map,List.length_map]
    rfl
  have eq : L.toFinset = G.neighborFinset i := by
    ext j
    simp only [L,List.mem_toFinset,List.mem_filter,vertices_mem,true_and,G.mem_neighborFinset]
    exact edge_encodeGraph G i j
  change (vertices.filter (edge b i.val)).length = G.degree i
  rw [l,←List.toFinset_card_of_nodup (vertices_nodup.filter _),eq,G.card_neighborFinset_eq_degree]

private def pairsFin : List (Label×Label) :=
  [(0,1),(0,2),(1,2),(0,3),(1,3),(2,3),(0,4),(1,4),(2,4),(3,4),
    (0,5),(1,5),(2,5),(3,5),(4,5)]

private theorem pairs_map : pairsFin.map (fun x => (x.1.val,x.2.val)) = pairs6 := by decide
private theorem pairs_perm : pairsFin.Perm (EffectiveSearch.orderedPairs 6) := by decide
private theorem ordered_nodup : (EffectiveSearch.orderedPairs 6).Nodup := by decide
private theorem ordered_iff :
    ∀ i j : Label, (i,j)∈EffectiveSearch.orderedPairs 6 ↔ i<j := by decide

theorem tri_encodeGraph (G : SimpleGraph Label) [DecidableRel G.Adj] (i : Label) :
    tri (encodeGraph G).val i.val = trianglesAt G i := by
  let E : EffectiveSearch.Rel 6 := fun v w => edge (encodeGraph G).val v.val w.val
  have hi := EffectiveSearch.score_eq_triangles G (Equiv.refl Label) E ordered_nodup ordered_iff
    (edge_encodeGraph G) i
  have h :
      tri (encodeGraph G).val i.val = EffectiveSearch.score E i := by
    unfold tri EffectiveSearch.score
    rw [←pairs_map,List.filter_map,List.length_map]
    exact (pairs_perm.filter _).length_eq
  exact h.trans hi

theorem ordered_encodeGraph (G : SimpleGraph Label) [DecidableRel G.Adj]
    (ord : ∀ i j : Label, i≤j → G.degree i≤G.degree j) :
    ordered (encodeGraph G).val = true := by
  unfold ordered
  simp only [Bool.and_eq_true,decide_eq_true_eq]
  have bridge (i j : Label) (ij : i≤j) :
      deg (encodeGraph G).val i.val ≤ deg (encodeGraph G).val j.val := by
    rw [deg_encodeGraph,deg_encodeGraph]
    exact ord i j ij
  exact ⟨⟨⟨⟨bridge 0 1 (by decide),bridge 1 2 (by decide)⟩,bridge 2 3 (by decide)⟩,
    bridge 3 4 (by decide)⟩,bridge 4 5 (by decide)⟩

end Graffiti384b.SixUntouched
#print axioms Graffiti384b.SixUntouched.edge_encodeGraph
#print axioms Graffiti384b.SixUntouched.deg_encodeGraph
#print axioms Graffiti384b.SixUntouched.tri_encodeGraph
