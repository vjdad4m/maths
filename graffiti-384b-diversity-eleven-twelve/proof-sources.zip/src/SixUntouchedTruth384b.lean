import SixUntouchedTransfer384b

namespace Graffiti384b.SixUntouched
open Finset SimpleGraph
open private vertices_mem vertices_map pairsFin pairs_map from SixUntouchedTransfer384b
set_option maxHeartbeats 3000000

private theorem fin_pair_strict : ∀ i j : Label, (i,j)∈pairsFin → i<j := by decide

/-- The numeric validity guard exactly uses minimum scores/degrees on zero-contact
vertices and pairwise distinct triangle scores on those vertices. -/
theorem valid_encodeGraph_encodeZero (G : SimpleGraph Label) [DecidableRel G.Adj]
    (Z : Finset Label) (large : ∀ i∈Z, 3≤G.degree i ∧ 2≤trianglesAt G i)
    (distinct : Set.InjOn (trianglesAt G) (Z : Set Label)) :
    valid (encodeGraph G).val (encodeZero Z).val = true := by
  unfold valid
  rw [Bool.and_eq_true]
  constructor
  · apply List.all_eq_true.mpr
    rw [←vertices_map]
    intro j jmem
    obtain ⟨i,_,rfl⟩ := List.mem_map.mp jmem
    by_cases inZ : i∈Z
    · have bit := (bit_encodeZero Z i).mpr inZ
      simp [bit,deg_encodeGraph,tri_encodeGraph,(large i inZ).1,(large i inZ).2]
    · have bit := Bool.eq_false_iff.mpr (fun h => inZ ((bit_encodeZero Z i).mp h))
      simp [bit]
  · apply List.all_eq_true.mpr
    rw [←pairs_map]
    intro ij ijmem
    obtain ⟨⟨i,j⟩,finmem,rfl⟩ := List.mem_map.mp ijmem
    have ne : i≠j := ne_of_lt (fin_pair_strict i j finmem)
    by_cases hi : i∈Z
    · have bi := (bit_encodeZero Z i).mpr hi
      by_cases hj : j∈Z
      · have bj := (bit_encodeZero Z j).mpr hj
        have hd : trianglesAt G i≠trianglesAt G j := fun s => ne (distinct hi hj s)
        simp [bi,bj,tri_encodeGraph,hd]
      · have bj := Bool.eq_false_iff.mpr (fun h => hj ((bit_encodeZero Z j).mp h))
        simp [bi,bj]
    · have bi := Bool.eq_false_iff.mpr (fun h => hi ((bit_encodeZero Z i).mp h))
      simp [bi]

/-- The two retained graph vertices represented by a successful numeric answer. -/
def Keeps (G : SimpleGraph Label) [DecidableRel G.Adj] (Z : Finset Label) (p q : Label) : Prop :=
  ∀ i, i≠p → i≠q →
    (i∈Z → G.Adj i p ∧ G.Adj i q) ∧
    (i∉Z → 2≤G.degree i → G.Adj i p ∨ G.Adj i q)

theorem keep_of_solution (G : SimpleGraph Label) [DecidableRel G.Adj] (Z : Finset Label)
    (ok : solution (encodeGraph G).val (encodeZero Z).val = true) :
    ∃ p q : Label, p≠q ∧ Keeps G Z p q := by
  unfold solution at ok
  obtain ⟨pq,pqmem,good⟩ := List.any_eq_true.mp ok
  rw [←pairs_map] at pqmem
  obtain ⟨⟨p,q⟩,finmem,rfl⟩ := List.mem_map.mp pqmem
  refine ⟨p,q,ne_of_lt (fin_pair_strict p q finmem),?_⟩
  unfold Keeps
  intro i ip iq
  have v : i.val∈vertices := by rw [←vertices_map]; exact List.mem_map.mpr ⟨i,vertices_mem i,rfl⟩
  change canKeep _ _ p.val q.val = true at good
  unfold canKeep at good
  have h := (List.all_eq_true.mp good) i.val v
  have ip' : i.val≠p.val := fun h => ip (Fin.ext h)
  have iq' : i.val≠q.val := fun h => iq (Fin.ext h)
  have ipB : (i.val == p.val) = false := Bool.eq_false_iff.mpr (fun e => ip' (beq_iff_eq.mp e))
  have iqB : (i.val == q.val) = false := Bool.eq_false_iff.mpr (fun e => iq' (beq_iff_eq.mp e))
  simp only [ipB,iqB,Bool.false_or] at h
  constructor
  · intro iz
    have bit := (bit_encodeZero Z i).mpr iz
    simp only [bit,if_pos rfl,if_true,Bool.and_eq_true] at h
    exact ⟨(edge_encodeGraph G i p).mp h.1,(edge_encodeGraph G i q).mp h.2⟩
  · intro iz dg
    have bit := Bool.eq_false_iff.mpr (fun h => iz ((bit_encodeZero Z i).mp h))
    simp only [bit,Bool.false_eq_true,if_false,deg_encodeGraph,if_pos dg,Bool.or_eq_true] at h
    exact h.imp (edge_encodeGraph G i p).mp (edge_encodeGraph G i q).mp

end Graffiti384b.SixUntouched
#print axioms Graffiti384b.SixUntouched.valid_encodeGraph_encodeZero
#print axioms Graffiti384b.SixUntouched.keep_of_solution
