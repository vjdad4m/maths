import SixUntouchedSort384b
import SixUntouchedPacked384b
import TwelveSingleLow384b
import TwelveIndependentLower384b
import DiversityElevenTwelveResidual384b

namespace Graffiti384b.DiversityEleven
open Finset SimpleGraph
open Graffiti384b.SixUntouched

/-- The symbolic graph argument leaves exactly a Boolean certificate on
degree-sorted labelled graphs of order six. -/
theorem selector_of_packed (cert : ∀ g : Fin 32768, packed g.val=true) : SixSelector := by
  intro H dec Z
  letI := dec
  intro large distinct
  apply unsort_keep _ H Z large distinct
  intro G de W ord cap inj
  letI := de
  apply keep_of_solution G W
  exact packed_sound (cert (encodeGraph G)) (ordered_encodeGraph G ord)
    (encodeZero W).isLt (valid_encodeGraph_encodeZero G W cap inj)

theorem exact_twelve_lower (select : SixSelector)
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (sup : Supported G) (t : (types G).card=11)
    (nine : (high G).card=9) (q : (nonleaves G).card=12) : gamma G≤bound G := by
  by_contra! bad
  obtain ⟨scores,min⟩ : Set.InjOn (trianglesAt G) (high G : Set V) ∧
      (∀ x∈high G,2≤trianglesAt G x) := by
    rcases split_profile G sup t bad with ⟨qq,_⟩|⟨_,sc,mn,_⟩
    · omega
    · exact ⟨sc,mn⟩
  by_cases has : ∃x∈nonleaves G \ high G,∃y∈nonleaves G \ high G,G.Adj x y
  · obtain ⟨x,xl,y,yl,xy⟩ := has
    exact (not_le_of_gt bad) (exact_twelve_single_low_edge G select t nine q scores min xy xl yl
      (fun a al b bl ab=>low_edge_unique G sup t nine bad xl yl al bl xy ab))
  · exact (not_le_of_gt bad) (exact_twelve_independent G sup t nine q scores min
      (fun x xl y yl xy=>has ⟨x,xl,y,yl,xy⟩))

theorem residual_eleven_at_most_eleven (select : SixSelector)
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (t : (types G).card=11) (bad : bound G<gamma G) :
    ∃ (J : SimpleGraph V) (dec : DecidableRel J.Adj),
      letI := dec
      J ≤ G ∧ Supported J ∧ (∀ v,trianglesAt J v=trianglesAt G v) ∧
        types J=types G ∧ bound J<gamma J ∧ (high J).card=9 ∧
        10≤(nonleaves J).card ∧ (nonleaves J).card≤11 := by
  obtain ⟨J,dec,sub,sup,sc,tp,jbad,nine,mn,mx⟩ := residual_eleven_at_most_twelve G t bad
  letI := dec
  have tj : (types J).card=11 := by simpa [tp] using t
  have top : (nonleaves J).card≤11 := by
    by_contra! large
    exact not_le_of_gt jbad (exact_twelve_lower select J sup tj nine (by omega))
  exact ⟨J,dec,sub,sup,sc,tp,jbad,nine,mn,top⟩

#print axioms selector_of_packed
#print axioms exact_twelve_lower
#print axioms residual_eleven_at_most_eleven
end Graffiti384b.DiversityEleven
