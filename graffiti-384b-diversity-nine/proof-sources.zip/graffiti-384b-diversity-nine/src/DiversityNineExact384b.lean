import DiversityNineResidualTwo384b
import Q11Exact384b
import Q12Exact384b

namespace Graffiti384b.DiversityNine
open SimpleGraph

theorem exact_of_nine_types {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (diverse : (types G).card=9) : gamma G≤bound G :=
  exact_from_two_orders G diverse
    (fun ord=>EffectiveSearch.Q11.exact_of_nine_types G ord diverse)
    (fun ord=>EffectiveSearch.Q12.exact_of_nine_types G ord diverse)

#print axioms exact_of_nine_types
end Graffiti384b.DiversityNine
