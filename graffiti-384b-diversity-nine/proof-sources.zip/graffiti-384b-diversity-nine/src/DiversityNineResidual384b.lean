import Q8Exact384b
import Q9Exact384b

namespace Graffiti384b.DiversityNine
open SimpleGraph
open private OddQuota.core_data from OddQuota384b

/-- The only remaining cases at diversity nine involve ten to twelve
nonleaves. This theorem makes the finite prerequisites explicit. -/
theorem exact_from_three_orders
    {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (t : (types G).card=9)
    (q10 : (nonleaves G).card=10 → gamma G≤bound G)
    (q11 : (nonleaves G).card=11 → gamma G≤bound G)
    (q12 : (nonleaves G).card=12 → gamma G≤bound G) : gamma G≤bound G := by
  have q8 : 8≤(nonleaves G).card := by
    by_contra bad
    obtain ⟨eq,_,_⟩ := OddQuota.core_data G (by omega)
    omega
  by_cases big : 13≤(nonleaves G).card
  · have h := nonleaf_bound G
    unfold bound
    omega
  rcases (show (nonleaves G).card=8 ∨ (nonleaves G).card=9 ∨
      (nonleaves G).card=10 ∨ (nonleaves G).card=11 ∨ (nonleaves G).card=12 by omega)
    with eight|nine|ten|eleven|twelve
  · exact Q8.exact_of_eight_nonleaves G eight (by omega)
  · exact Q9.exact_of_nine_nonleaves G nine (by omega)
  · exact q10 ten
  · exact q11 eleven
  · exact q12 twelve

#print axioms exact_from_three_orders
end Graffiti384b.DiversityNine
