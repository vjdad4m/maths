import DiversityNineResidual384b
import Q10Exact384b
namespace Graffiti384b.DiversityNine
open SimpleGraph
theorem exact_from_two_orders
    {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) [DecidableRel G.Adj] (t : (types G).card=9)
    (q11 : (nonleaves G).card=11 → gamma G≤bound G)
    (q12 : (nonleaves G).card=12 → gamma G≤bound G) : gamma G≤bound G :=
  exact_from_three_orders G t (fun ten=>Q10.exact_of_ten_nonleaves G ten (by omega) (by omega)) q11 q12

#print axioms exact_from_two_orders
end Graffiti384b.DiversityNine
