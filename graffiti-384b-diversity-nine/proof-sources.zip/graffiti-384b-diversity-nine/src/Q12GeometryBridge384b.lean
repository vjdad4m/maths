import EffectiveSearchGraph384b
import Q12AnchorNormalize384b

namespace Graffiti384b.EffectiveSearch.Q12
open Finset SimpleGraph
set_option linter.unusedSectionVars false
set_option maxHeartbeats 4500000

abbrev V := Label 12

def forms (s : Fin 69) : Shape :=
  let t := Graffiti384bQ12.anchorTable s
  ⟨decide (t.1=1),t.2.1,t.2.2.1,t.2.2.2⟩

private def pairsSeven : Fin 45→V×V :=
  ![(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,9),(2,10),(2,11),(3,4),(3,5),(3,6),(3,7),(3,8),(3,9),(3,10),(3,11),(4,5),(4,6),(4,7),(4,8),(4,9),(4,10),(4,11),(5,6),(5,7),(5,8),(5,9),(5,10),(5,11),(6,7),(6,8),(6,9),(6,10),(6,11),(7,8),(7,9),(7,10),(7,11),(8,9),(8,10),(8,11),(9,10),(9,11),(10,11)]

private theorem slot_total : ∀ (i j : Fin 12), (2 : Nat) ≤ Fin.val i → i < j →
    ∃ k : Fin 45,k.val=slot 12 i.val j.val ∧ pairsSeven k=(i,j) := by decide

private theorem data_eq : ∀ s : Fin 69,
    let S := forms s
    let T := Graffiti384bQ12.anchorTable s
    (S.edge01=true↔T.1=1) ∧ (if S.edge01 then 1 else 0)=T.1 ∧
      S.d0=T.2.1 ∧ S.d1=T.2.2.1 ∧ S.common=T.2.2.2 := by decide

variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The actual graph supplies the free bits; all anchor rows remain fixed. -/
theorem entries_of_shape (s : Fin 69) (p : V≃V)
    (edge01 : G.Adj (p 0) (p 1)↔(Graffiti384bQ12.anchorTable s).1=1)
    (contact : ∀ j : V,2≤j.val→
      let t := Graffiti384bQ12.anchorTable s
      let a := t.2.1-t.1
      let b := t.2.2.1-t.1
      let c := t.2.2.2
      let r := j.val-2
      (G.Adj (p 0) (p j)↔r<a) ∧
      (G.Adj (p 1) (p j)↔r<c ∨ (a≤r ∧ r<a+b-c))) :
    ∃ bits : Nat→Bool, ∀ i j,adj 12 (forms s) bits i j=true↔G.Adj (p i) (p j) := by
  let bits (k : Nat) := if h:k<45 then
    let t := pairsSeven ⟨k,h⟩
    decide (G.Adj (p t.1) (p t.2))
    else false
  refine ⟨bits,?_⟩
  have ordered (i j : V) (lt : i<j) : adj 12 (forms s) bits i j=true↔G.Adj (p i) (p j) := by
    have ni : i.val < j.val := lt
    dsimp [adj]
    simp only [min_eq_left ni.le,max_eq_right ni.le,if_neg (ne_of_lt ni)]
    have eq := data_eq s
    by_cases z : i.val=0
    · have zi : i=0 := Fin.ext z
      rw [if_pos z]
      by_cases w : j.val=1
      · have wj : j=1 := Fin.ext w
        simpa only [if_pos w,zi,wj] using eq.1.trans edge01.symm
      have up : 2≤j.val := by omega
      rw [if_neg w,zi]
      simpa only [anchorZero,eq.2.1,eq.2.2.1,decide_eq_true_eq] using (contact j up).1.symm
    rw [if_neg z]
    by_cases o : i.val=1
    · have oi : i=1 := Fin.ext o
      have up : 2≤j.val := by omega
      rw [if_pos o,oi]
      simpa only [anchorOne,eq.2.1,eq.2.2.1,eq.2.2.2.1,eq.2.2.2.2,decide_eq_true_eq]
        using (contact j up).2.symm
    rw [if_neg o]
    obtain ⟨k,kVal,matchPair⟩ := slot_total i j (by omega) lt
    rw [←kVal]
    simp only [bits,dif_pos k.isLt,matchPair,decide_eq_true_eq]
  intro i j
  rcases lt_trichotomy i j with lo|same|hi
  · exact ordered i j lo
  · subst j
    simp [adj,G.loopless]
  · have swap : adj 12 (forms s) bits i j = adj 12 (forms s) bits j i := by simp [adj,min_comm,max_comm]
    rw [swap,SimpleGraph.adj_comm]
    exact ordered j i hi



theorem quota_from_covers
    (covers : ∀ (s : Fin 69) (bits : Nat→Bool),
      Ranked (adj 12 (forms s) bits) (root (by decide)) →
        ∃ D : Finset V, D.card≤7 ∧ Effective (adj 12 (forms s) bits) (adj 12 (forms s) bits) D)
    (diverse : 8≤(Q9Original.PositiveScores G).card) :
    ∃ D : Finset V,D.card≤7 ∧ Q9Original.Effective G D := by
  rw [←trianglePalette_eq_positiveScores] at diverse
  apply quota_from_normalized G (h:=by decide) (by decide) (by decide) _ diverse
  intro x y xy xd yd cd
  obtain ⟨s,p,roots,edge,contacts⟩ := Graffiti384bQ12.normalize_two_anchors G x y xy xd yd cd
  obtain ⟨bits,fit⟩ := entries_of_shape G s p edge contacts
  exact ⟨p,adj 12 (forms s) bits,roots,fit,covers s bits⟩

#print axioms quota_from_covers
end Graffiti384b.EffectiveSearch.Q12
