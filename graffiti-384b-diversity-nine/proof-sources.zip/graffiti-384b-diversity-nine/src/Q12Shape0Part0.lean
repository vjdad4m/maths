import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape0T1 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))))))))
private theorem q12Shape0T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 0 7 q12Shape0T1=true := by decide

private def q12Shape0T3 : Tree 12 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11}))))))))
private theorem q12Shape0T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 4 11 q12Shape0T3=true := by decide

private def q12Shape0T5 : Tree 12 := (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {5,6,7,8,9,10,11}))))))
private theorem q12Shape0T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 12 515 q12Shape0T5=true := by decide

private def q12Shape0T7 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11}))))))
private theorem q12Shape0T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 524 1027 q12Shape0T7=true := by decide

private def q12Shape0T9 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape0T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1548 2051 q12Shape0T9=true := by decide

private def q12Shape0T10 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {5,6,7,8,9,10,11}))))
private theorem q12Shape0T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3596 3 q12Shape0T10=true := by decide

private def q12Shape0T8 : Tree 12 := .split 11 q12Shape0T9 q12Shape0T10
private theorem q12Shape0T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1548 3 q12Shape0T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1548 (3 ||| 2^11) q12Shape0T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (1548 ||| 2^11) 3 q12Shape0T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T9OK,q12Shape0T10OK⟩

private def q12Shape0T6 : Tree 12 := .split 10 q12Shape0T7 q12Shape0T8
private theorem q12Shape0T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 524 3 q12Shape0T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 524 (3 ||| 2^10) q12Shape0T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (524 ||| 2^10) 3 q12Shape0T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T7OK,q12Shape0T8OK⟩

private def q12Shape0T4 : Tree 12 := .split 9 q12Shape0T5 q12Shape0T6
private theorem q12Shape0T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 12 3 q12Shape0T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 12 (3 ||| 2^9) q12Shape0T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (12 ||| 2^9) 3 q12Shape0T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T5OK,q12Shape0T6OK⟩

private def q12Shape0T2 : Tree 12 := .split 3 q12Shape0T3 q12Shape0T4
private theorem q12Shape0T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 4 3 q12Shape0T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 4 (3 ||| 2^3) q12Shape0T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (4 ||| 2^3) 3 q12Shape0T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T3OK,q12Shape0T4OK⟩

private def q12Shape0T0 : Tree 12 := .split 2 q12Shape0T1 q12Shape0T2
private theorem q12Shape0T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 0 3 q12Shape0T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 0 (3 ||| 2^2) q12Shape0T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (0 ||| 2^2) 3 q12Shape0T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T1OK,q12Shape0T2OK⟩

def q12Shape0P0 : Tree 12 := q12Shape0T0
theorem q12Shape0P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 0 3 q12Shape0P0=true := q12Shape0T0OK

end Graffiti384b.EffectiveSearch.Q12
