import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape0T69 : Tree 12 := (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10,11}))))))
private theorem q12Shape0T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 524 q12Shape0T69=true := by decide

private def q12Shape0T70 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))) (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape0T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 515 12 q12Shape0T70=true := by decide

private def q12Shape0T68 : Tree 12 := .split 9 q12Shape0T69 q12Shape0T70
private theorem q12Shape0T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 12 q12Shape0T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 (12 ||| 2^9) q12Shape0T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (3 ||| 2^9) 12 q12Shape0T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T69OK,q12Shape0T70OK⟩

private def q12Shape0T73 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11}))))))
private theorem q12Shape0T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 11 1540 q12Shape0T73=true := by decide

private def q12Shape0T75 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10,11})))))
private theorem q12Shape0T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1035 2564 q12Shape0T75=true := by decide

private def q12Shape0T76 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {3,4,7,8,9,10,11}))))
private theorem q12Shape0T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3083 516 q12Shape0T76=true := by decide

private def q12Shape0T74 : Tree 12 := .split 11 q12Shape0T75 q12Shape0T76
private theorem q12Shape0T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1035 516 q12Shape0T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1035 (516 ||| 2^11) q12Shape0T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (1035 ||| 2^11) 516 q12Shape0T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T75OK,q12Shape0T76OK⟩

private def q12Shape0T72 : Tree 12 := .split 10 q12Shape0T73 q12Shape0T74
private theorem q12Shape0T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 11 516 q12Shape0T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 11 (516 ||| 2^10) q12Shape0T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (11 ||| 2^10) 516 q12Shape0T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T73OK,q12Shape0T74OK⟩

private def q12Shape0T78 : Tree 12 := (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 17 (.split 18 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11}))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11})))))
private theorem q12Shape0T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 523 1028 q12Shape0T78=true := by decide

private def q12Shape0T79 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11})))
private theorem q12Shape0T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1547 4 q12Shape0T79=true := by decide

private def q12Shape0T77 : Tree 12 := .split 10 q12Shape0T78 q12Shape0T79
private theorem q12Shape0T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 523 4 q12Shape0T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 523 (4 ||| 2^10) q12Shape0T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (523 ||| 2^10) 4 q12Shape0T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T78OK,q12Shape0T79OK⟩

private def q12Shape0T71 : Tree 12 := .split 9 q12Shape0T72 q12Shape0T77
private theorem q12Shape0T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 11 4 q12Shape0T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 11 (4 ||| 2^9) q12Shape0T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (11 ||| 2^9) 4 q12Shape0T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T72OK,q12Shape0T77OK⟩

private def q12Shape0T67 : Tree 12 := .split 3 q12Shape0T68 q12Shape0T71
private theorem q12Shape0T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 4 q12Shape0T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 (4 ||| 2^3) q12Shape0T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (3 ||| 2^3) 4 q12Shape0T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T68OK,q12Shape0T71OK⟩

private def q12Shape0T83 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10,11}))))))
private theorem q12Shape0T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 7 1544 q12Shape0T83=true := by decide

private def q12Shape0T85 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape0T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1031 2568 q12Shape0T85=true := by decide

private def q12Shape0T86 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {3,4,7,8,9,10,11}))))
private theorem q12Shape0T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3079 520 q12Shape0T86=true := by decide

private def q12Shape0T84 : Tree 12 := .split 11 q12Shape0T85 q12Shape0T86
private theorem q12Shape0T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1031 520 q12Shape0T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1031 (520 ||| 2^11) q12Shape0T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (1031 ||| 2^11) 520 q12Shape0T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T85OK,q12Shape0T86OK⟩

private def q12Shape0T82 : Tree 12 := .split 10 q12Shape0T83 q12Shape0T84
private theorem q12Shape0T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 7 520 q12Shape0T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 7 (520 ||| 2^10) q12Shape0T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (7 ||| 2^10) 520 q12Shape0T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T83OK,q12Shape0T84OK⟩

private def q12Shape0T89 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape0T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 519 3080 q12Shape0T89=true := by decide

private def q12Shape0T90 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape0T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 2567 1032 q12Shape0T90=true := by decide

private def q12Shape0T88 : Tree 12 := .split 11 q12Shape0T89 q12Shape0T90
private theorem q12Shape0T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 519 1032 q12Shape0T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 519 (1032 ||| 2^11) q12Shape0T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (519 ||| 2^11) 1032 q12Shape0T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T89OK,q12Shape0T90OK⟩

private def q12Shape0T91 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10,11})))) (.split 18 (.tip (.cover {0,5,7,8,9,10,11})) (.tip (.cover {0,4,7,8,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11})))
private theorem q12Shape0T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 1543 8 q12Shape0T91=true := by decide

private def q12Shape0T87 : Tree 12 := .split 10 q12Shape0T88 q12Shape0T91
private theorem q12Shape0T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 519 8 q12Shape0T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 519 (8 ||| 2^10) q12Shape0T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (519 ||| 2^10) 8 q12Shape0T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T88OK,q12Shape0T91OK⟩

private def q12Shape0T81 : Tree 12 := .split 9 q12Shape0T82 q12Shape0T87
private theorem q12Shape0T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 7 8 q12Shape0T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 7 (8 ||| 2^9) q12Shape0T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (7 ||| 2^9) 8 q12Shape0T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T82OK,q12Shape0T87OK⟩

private def q12Shape0T92 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape0T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 15 0 q12Shape0T92=true := by decide

private def q12Shape0T80 : Tree 12 := .split 3 q12Shape0T81 q12Shape0T92
private theorem q12Shape0T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 7 0 q12Shape0T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 7 (0 ||| 2^3) q12Shape0T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (7 ||| 2^3) 0 q12Shape0T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T81OK,q12Shape0T92OK⟩

private def q12Shape0T66 : Tree 12 := .split 2 q12Shape0T67 q12Shape0T80
private theorem q12Shape0T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 0 q12Shape0T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 (0 ||| 2^2) q12Shape0T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) (3 ||| 2^2) 0 q12Shape0T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape0T67OK,q12Shape0T80OK⟩

def q12Shape0P3 : Tree 12 := q12Shape0T66
theorem q12Shape0P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,0⟩) 3 0 q12Shape0P3=true := q12Shape0T66OK

end Graffiti384b.EffectiveSearch.Q12
