import Q12Shape1Part0
import Q12Shape1Part1
import Q12Shape1Part2
import Q12Shape1Part3
import Q12Shape1Part4
import Q12Shape1Part5
import Q12Shape1Part6

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape1M79 : Tree 12 := .split 11 q12Shape1P1 q12Shape1P2
private theorem q12Shape1M79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 512 q12Shape1M79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 (512 ||| 2^11) q12Shape1P1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (1024 ||| 2^11) 512 q12Shape1P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1P1OK,q12Shape1P2OK⟩
private def q12Shape1M80 : Tree 12 := .split 10 q12Shape1P0 q12Shape1M79
private theorem q12Shape1M80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 512 q12Shape1M80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 (512 ||| 2^10) q12Shape1P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (0 ||| 2^10) 512 q12Shape1M79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1P0OK,q12Shape1M79OK⟩
private def q12Shape1M133 : Tree 12 := .split 11 q12Shape1P3 q12Shape1P4
private theorem q12Shape1M133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 1024 q12Shape1M133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 (1024 ||| 2^11) q12Shape1P3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (512 ||| 2^11) 1024 q12Shape1P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1P3OK,q12Shape1P4OK⟩
private def q12Shape1M180 : Tree 12 := .split 11 q12Shape1P5 q12Shape1P6
private theorem q12Shape1M180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1536 0 q12Shape1M180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1536 (0 ||| 2^11) q12Shape1P5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (1536 ||| 2^11) 0 q12Shape1P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1P5OK,q12Shape1P6OK⟩
private def q12Shape1M181 : Tree 12 := .split 10 q12Shape1M133 q12Shape1M180
private theorem q12Shape1M181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 0 q12Shape1M181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 (0 ||| 2^10) q12Shape1M133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (512 ||| 2^10) 0 q12Shape1M180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1M133OK,q12Shape1M180OK⟩
private def q12Shape1M182 : Tree 12 := .split 9 q12Shape1M80 q12Shape1M181
private theorem q12Shape1M182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 0 q12Shape1M182=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 (0 ||| 2^9) q12Shape1M80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (0 ||| 2^9) 0 q12Shape1M181)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1M80OK,q12Shape1M181OK⟩

theorem q12Shape1_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 1) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 1) b) (adj 12 (forms 1) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) adj_mono b H q12Shape1M182 q12Shape1M182OK

#print axioms q12Shape1_cover

end Graffiti384b.EffectiveSearch.Q12
