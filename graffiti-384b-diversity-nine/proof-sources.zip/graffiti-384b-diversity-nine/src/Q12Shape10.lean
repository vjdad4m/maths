import Q12Shape10Part0
import Q12Shape10Part1

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape10M62 : Tree 12 := .split 24 q12Shape10P0 q12Shape10P1
private theorem q12Shape10M62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 0 q12Shape10M62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (0 ||| 2^24) q12Shape10P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^24) 0 q12Shape10P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10P0OK,q12Shape10P1OK⟩

theorem q12Shape10_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 10) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 10) b) (adj 12 (forms 10) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) adj_mono b H q12Shape10M62 q12Shape10M62OK

#print axioms q12Shape10_cover

end Graffiti384b.EffectiveSearch.Q12
