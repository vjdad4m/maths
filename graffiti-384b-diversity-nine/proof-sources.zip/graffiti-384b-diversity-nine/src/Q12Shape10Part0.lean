import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape10T10 : Tree 12 := (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape10T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 6055350239232 q12Shape10T10=true := by decide

private def q12Shape10T11 : Tree 12 := (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,6,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape10T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 4294967296 6051055271936 q12Shape10T11=true := by decide

private def q12Shape10T9 : Tree 12 := .split 32 q12Shape10T10 q12Shape10T11
private theorem q12Shape10T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 6051055271936 q12Shape10T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (6051055271936 ||| 2^32) q12Shape10T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^32) 6051055271936 q12Shape10T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T10OK,q12Shape10T11OK⟩

private def q12Shape10T12 : Tree 12 := (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,6,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape10T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 2147483648 6048907788288 q12Shape10T12=true := by decide

private def q12Shape10T8 : Tree 12 := .split 31 q12Shape10T9 q12Shape10T12
private theorem q12Shape10T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 6048907788288 q12Shape10T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (6048907788288 ||| 2^31) q12Shape10T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^31) 6048907788288 q12Shape10T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T9OK,q12Shape10T12OK⟩

private def q12Shape10T13 : Tree 12 := (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,9,11})))
private theorem q12Shape10T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 268435456 6048639352832 q12Shape10T13=true := by decide

private def q12Shape10T7 : Tree 12 := .split 28 q12Shape10T8 q12Shape10T13
private theorem q12Shape10T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 6048639352832 q12Shape10T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (6048639352832 ||| 2^28) q12Shape10T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^28) 6048639352832 q12Shape10T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T8OK,q12Shape10T13OK⟩

private def q12Shape10T14 : Tree 12 := (.split 28 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,5,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape10T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 134217728 6048505135104 q12Shape10T14=true := by decide

private def q12Shape10T6 : Tree 12 := .split 27 q12Shape10T7 q12Shape10T14
private theorem q12Shape10T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 6048505135104 q12Shape10T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (6048505135104 ||| 2^27) q12Shape10T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^27) 6048505135104 q12Shape10T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T7OK,q12Shape10T14OK⟩

private def q12Shape10T16 : Tree 12 := (.split 28 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,5,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11})))
private theorem q12Shape10T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 67108864 6048572243968 q12Shape10T16=true := by decide

private def q12Shape10T17 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape10T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 201326592 6048438026240 q12Shape10T17=true := by decide

private def q12Shape10T15 : Tree 12 := .split 27 q12Shape10T16 q12Shape10T17
private theorem q12Shape10T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 67108864 6048438026240 q12Shape10T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 67108864 (6048438026240 ||| 2^27) q12Shape10T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (67108864 ||| 2^27) 6048438026240 q12Shape10T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T16OK,q12Shape10T17OK⟩

private def q12Shape10T5 : Tree 12 := .split 26 q12Shape10T6 q12Shape10T15
private theorem q12Shape10T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 6048438026240 q12Shape10T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (6048438026240 ||| 2^26) q12Shape10T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^26) 6048438026240 q12Shape10T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T6OK,q12Shape10T15OK⟩

private def q12Shape10T19 : Tree 12 := (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11})))
private theorem q12Shape10T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 4398046511104 1650458624000 q12Shape10T19=true := by decide

private def q12Shape10T20 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape10T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 4398113619968 1650391515136 q12Shape10T20=true := by decide

private def q12Shape10T18 : Tree 12 := .split 26 q12Shape10T19 q12Shape10T20
private theorem q12Shape10T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 4398046511104 1650391515136 q12Shape10T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 4398046511104 (1650391515136 ||| 2^26) q12Shape10T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (4398046511104 ||| 2^26) 1650391515136 q12Shape10T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T19OK,q12Shape10T20OK⟩

private def q12Shape10T4 : Tree 12 := .split 42 q12Shape10T5 q12Shape10T18
private theorem q12Shape10T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 1650391515136 q12Shape10T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (1650391515136 ||| 2^42) q12Shape10T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^42) 1650391515136 q12Shape10T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T5OK,q12Shape10T18OK⟩

private def q12Shape10T23 : Tree 12 := (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape10T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099511627776 4948993507328 q12Shape10T23=true := by decide

private def q12Shape10T24 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,11}))
private theorem q12Shape10T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099578736640 4948926398464 q12Shape10T24=true := by decide

private def q12Shape10T22 : Tree 12 := .split 26 q12Shape10T23 q12Shape10T24
private theorem q12Shape10T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099511627776 4948926398464 q12Shape10T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099511627776 (4948926398464 ||| 2^26) q12Shape10T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (1099511627776 ||| 2^26) 4948926398464 q12Shape10T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T23OK,q12Shape10T24OK⟩

private def q12Shape10T25 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape10T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 5497558138880 550879887360 q12Shape10T25=true := by decide

private def q12Shape10T21 : Tree 12 := .split 42 q12Shape10T22 q12Shape10T25
private theorem q12Shape10T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099511627776 550879887360 q12Shape10T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099511627776 (550879887360 ||| 2^42) q12Shape10T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (1099511627776 ||| 2^42) 550879887360 q12Shape10T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T22OK,q12Shape10T25OK⟩

private def q12Shape10T3 : Tree 12 := .split 40 q12Shape10T4 q12Shape10T21
private theorem q12Shape10T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 550879887360 q12Shape10T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (550879887360 ||| 2^40) q12Shape10T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^40) 550879887360 q12Shape10T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T4OK,q12Shape10T21OK⟩

private def q12Shape10T30 : Tree 12 := (.split 28 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape10T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 5498883538944 q12Shape10T30=true := by decide

private def q12Shape10T31 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape10T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549890031616 5498749321216 q12Shape10T31=true := by decide

private def q12Shape10T29 : Tree 12 := .split 27 q12Shape10T30 q12Shape10T31
private theorem q12Shape10T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 5498749321216 q12Shape10T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 (5498749321216 ||| 2^27) q12Shape10T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (549755813888 ||| 2^27) 5498749321216 q12Shape10T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T30OK,q12Shape10T31OK⟩

private def q12Shape10T32 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape10T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549822922752 5498682212352 q12Shape10T32=true := by decide

private def q12Shape10T28 : Tree 12 := .split 26 q12Shape10T29 q12Shape10T32
private theorem q12Shape10T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 5498682212352 q12Shape10T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 (5498682212352 ||| 2^26) q12Shape10T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (549755813888 ||| 2^26) 5498682212352 q12Shape10T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T29OK,q12Shape10T32OK⟩

private def q12Shape10T33 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape10T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 4947802324992 1100635701248 q12Shape10T33=true := by decide

private def q12Shape10T27 : Tree 12 := .split 42 q12Shape10T28 q12Shape10T33
private theorem q12Shape10T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 1100635701248 q12Shape10T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 (1100635701248 ||| 2^42) q12Shape10T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (549755813888 ||| 2^42) 1100635701248 q12Shape10T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T28OK,q12Shape10T33OK⟩

private def q12Shape10T34 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,11}))
private theorem q12Shape10T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1649267441664 1124073472 q12Shape10T34=true := by decide

private def q12Shape10T26 : Tree 12 := .split 40 q12Shape10T27 q12Shape10T34
private theorem q12Shape10T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 1124073472 q12Shape10T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549755813888 (1124073472 ||| 2^40) q12Shape10T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (549755813888 ||| 2^40) 1124073472 q12Shape10T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T27OK,q12Shape10T34OK⟩

private def q12Shape10T2 : Tree 12 := .split 39 q12Shape10T3 q12Shape10T26
private theorem q12Shape10T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 1124073472 q12Shape10T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (1124073472 ||| 2^39) q12Shape10T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^39) 1124073472 q12Shape10T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T3OK,q12Shape10T26OK⟩

private def q12Shape10T37 : Tree 12 := (.split 42 (.split 26 (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11})))
private theorem q12Shape10T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1073741824 1649317773312 q12Shape10T37=true := by decide

private def q12Shape10T38 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape10T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1100585369600 549806145536 q12Shape10T38=true := by decide

private def q12Shape10T36 : Tree 12 := .split 40 q12Shape10T37 q12Shape10T38
private theorem q12Shape10T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1073741824 549806145536 q12Shape10T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1073741824 (549806145536 ||| 2^40) q12Shape10T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (1073741824 ||| 2^40) 549806145536 q12Shape10T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T37OK,q12Shape10T38OK⟩

private def q12Shape10T39 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape10T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 550829555712 50331648 q12Shape10T39=true := by decide

private def q12Shape10T35 : Tree 12 := .split 39 q12Shape10T36 q12Shape10T39
private theorem q12Shape10T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1073741824 50331648 q12Shape10T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1073741824 (50331648 ||| 2^39) q12Shape10T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (1073741824 ||| 2^39) 50331648 q12Shape10T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T36OK,q12Shape10T39OK⟩

private def q12Shape10T1 : Tree 12 := .split 30 q12Shape10T2 q12Shape10T35
private theorem q12Shape10T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 50331648 q12Shape10T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (50331648 ||| 2^30) q12Shape10T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^30) 50331648 q12Shape10T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T2OK,q12Shape10T35OK⟩

private def q12Shape10T43 : Tree 12 := (.split 42 (.split 26 (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11})))
private theorem q12Shape10T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 33554432 1650357960704 q12Shape10T43=true := by decide

private def q12Shape10T44 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape10T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099545182208 550846332928 q12Shape10T44=true := by decide

private def q12Shape10T42 : Tree 12 := .split 40 q12Shape10T43 q12Shape10T44
private theorem q12Shape10T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 33554432 550846332928 q12Shape10T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 33554432 (550846332928 ||| 2^40) q12Shape10T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (33554432 ||| 2^40) 550846332928 q12Shape10T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T43OK,q12Shape10T44OK⟩

private def q12Shape10T45 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape10T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549789368320 1090519040 q12Shape10T45=true := by decide

private def q12Shape10T41 : Tree 12 := .split 39 q12Shape10T42 q12Shape10T45
private theorem q12Shape10T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 33554432 1090519040 q12Shape10T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 33554432 (1090519040 ||| 2^39) q12Shape10T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (33554432 ||| 2^39) 1090519040 q12Shape10T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T42OK,q12Shape10T45OK⟩

private def q12Shape10T46 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape10T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1107296256 16777216 q12Shape10T46=true := by decide

private def q12Shape10T40 : Tree 12 := .split 30 q12Shape10T41 q12Shape10T46
private theorem q12Shape10T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 33554432 16777216 q12Shape10T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 33554432 (16777216 ||| 2^30) q12Shape10T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (33554432 ||| 2^30) 16777216 q12Shape10T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T41OK,q12Shape10T46OK⟩

private def q12Shape10T0 : Tree 12 := .split 25 q12Shape10T1 q12Shape10T40
private theorem q12Shape10T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 16777216 q12Shape10T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 (16777216 ||| 2^25) q12Shape10T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (0 ||| 2^25) 16777216 q12Shape10T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T1OK,q12Shape10T40OK⟩

def q12Shape10P0 : Tree 12 := q12Shape10T0
theorem q12Shape10P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 0 16777216 q12Shape10P0=true := q12Shape10T0OK

end Graffiti384b.EffectiveSearch.Q12
