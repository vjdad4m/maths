import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape10T54 : Tree 12 := (.split 28 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,5,11})) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11})))
private theorem q12Shape10T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 6048622575616 q12Shape10T54=true := by decide

private def q12Shape10T55 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape10T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 150994944 6048488357888 q12Shape10T55=true := by decide

private def q12Shape10T53 : Tree 12 := .split 27 q12Shape10T54 q12Shape10T55
private theorem q12Shape10T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 6048488357888 q12Shape10T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 (6048488357888 ||| 2^27) q12Shape10T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (16777216 ||| 2^27) 6048488357888 q12Shape10T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T54OK,q12Shape10T55OK⟩

private def q12Shape10T56 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape10T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 83886080 6048421249024 q12Shape10T56=true := by decide

private def q12Shape10T52 : Tree 12 := .split 26 q12Shape10T53 q12Shape10T56
private theorem q12Shape10T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 6048421249024 q12Shape10T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 (6048421249024 ||| 2^26) q12Shape10T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (16777216 ||| 2^26) 6048421249024 q12Shape10T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T53OK,q12Shape10T56OK⟩

private def q12Shape10T57 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape10T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 4398063288320 1650374737920 q12Shape10T57=true := by decide

private def q12Shape10T51 : Tree 12 := .split 42 q12Shape10T52 q12Shape10T57
private theorem q12Shape10T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 1650374737920 q12Shape10T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 (1650374737920 ||| 2^42) q12Shape10T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (16777216 ||| 2^42) 1650374737920 q12Shape10T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T52OK,q12Shape10T57OK⟩

private def q12Shape10T58 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape10T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1099528404992 550863110144 q12Shape10T58=true := by decide

private def q12Shape10T50 : Tree 12 := .split 40 q12Shape10T51 q12Shape10T58
private theorem q12Shape10T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 550863110144 q12Shape10T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 (550863110144 ||| 2^40) q12Shape10T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (16777216 ||| 2^40) 550863110144 q12Shape10T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T51OK,q12Shape10T58OK⟩

private def q12Shape10T59 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape10T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 549772591104 1107296256 q12Shape10T59=true := by decide

private def q12Shape10T49 : Tree 12 := .split 39 q12Shape10T50 q12Shape10T59
private theorem q12Shape10T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 1107296256 q12Shape10T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 (1107296256 ||| 2^39) q12Shape10T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (16777216 ||| 2^39) 1107296256 q12Shape10T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T50OK,q12Shape10T59OK⟩

private def q12Shape10T60 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape10T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 1090519040 33554432 q12Shape10T60=true := by decide

private def q12Shape10T48 : Tree 12 := .split 30 q12Shape10T49 q12Shape10T60
private theorem q12Shape10T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 33554432 q12Shape10T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 (33554432 ||| 2^30) q12Shape10T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (16777216 ||| 2^30) 33554432 q12Shape10T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T49OK,q12Shape10T60OK⟩

private def q12Shape10T61 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape10T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 50331648 0 q12Shape10T61=true := by decide

private def q12Shape10T47 : Tree 12 := .split 25 q12Shape10T48 q12Shape10T61
private theorem q12Shape10T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 0 q12Shape10T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 (0 ||| 2^25) q12Shape10T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) (16777216 ||| 2^25) 0 q12Shape10T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape10T48OK,q12Shape10T61OK⟩

def q12Shape10P1 : Tree 12 := q12Shape10T47
theorem q12Shape10P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,3⟩) 16777216 0 q12Shape10P1=true := q12Shape10T47OK

end Graffiti384b.EffectiveSearch.Q12
