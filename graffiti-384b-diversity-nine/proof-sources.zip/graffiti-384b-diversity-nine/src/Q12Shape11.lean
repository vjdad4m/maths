import Q12Shape11Part0

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q12Shape11_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 11) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 11) b) (adj 12 (forms 11) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) adj_mono b H q12Shape11P0 q12Shape11P0OK

#print axioms q12Shape11_cover

end Graffiti384b.EffectiveSearch.Q12
