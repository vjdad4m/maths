import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape11T10 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape11T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 660351221880 q12Shape11T10=true := by decide

private def q12Shape11T13 : Tree 12 := (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,4,5,8,9,10,11})))
private theorem q12Shape11T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 64 660351227960 q12Shape11T13=true := by decide

private def q12Shape11T14 : Tree 12 := (.split 13 (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,7,9,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.split 19 (.split 20 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11})))
private theorem q12Shape11T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4160 660351223864 q12Shape11T14=true := by decide

private def q12Shape11T12 : Tree 12 := .split 12 q12Shape11T13 q12Shape11T14
private theorem q12Shape11T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 64 660351223864 q12Shape11T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 64 (660351223864 ||| 2^12) q12Shape11T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (64 ||| 2^12) 660351223864 q12Shape11T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T13OK,q12Shape11T14OK⟩

private def q12Shape11T15 : Tree 12 := (.split 12 (.split 13 (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,6,9,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.split 20 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape11T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2112 660351221816 q12Shape11T15=true := by decide

private def q12Shape11T11 : Tree 12 := .split 11 q12Shape11T12 q12Shape11T15
private theorem q12Shape11T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 64 660351221816 q12Shape11T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 64 (660351221816 ||| 2^11) q12Shape11T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (64 ||| 2^11) 660351221816 q12Shape11T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T12OK,q12Shape11T15OK⟩

private def q12Shape11T9 : Tree 12 := .split 6 q12Shape11T10 q12Shape11T11
private theorem q12Shape11T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 660351221816 q12Shape11T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (660351221816 ||| 2^6) q12Shape11T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^6) 660351221816 q12Shape11T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T10OK,q12Shape11T11OK⟩

private def q12Shape11T19 : Tree 12 := (.split 13 (.split 14 (.tip (.cover {0,1,4,5,8,10,11})) (.tip (.cover {0,4,5,8,9,10,11}))) (.tip (.cover {0,1,3,4,5,10,11})))
private theorem q12Shape11T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 32 660351227992 q12Shape11T19=true := by decide

private def q12Shape11T22 : Tree 12 := (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,7,8,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 19 (.split 20 (.split 21 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))))
private theorem q12Shape11T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4128 660351248472 q12Shape11T22=true := by decide

private def q12Shape11T23 : Tree 12 := (.tip (.cover {0,1,3,6,8,10,11}))
private theorem q12Shape11T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 20512 660351232088 q12Shape11T23=true := by decide

private def q12Shape11T21 : Tree 12 := .split 14 q12Shape11T22 q12Shape11T23
private theorem q12Shape11T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4128 660351232088 q12Shape11T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4128 (660351232088 ||| 2^14) q12Shape11T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (4128 ||| 2^14) 660351232088 q12Shape11T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T22OK,q12Shape11T23OK⟩

private def q12Shape11T24 : Tree 12 := (.tip (.cover {0,1,3,6,9,10,11}))
private theorem q12Shape11T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 12320 660351223896 q12Shape11T24=true := by decide

private def q12Shape11T20 : Tree 12 := .split 13 q12Shape11T21 q12Shape11T24
private theorem q12Shape11T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4128 660351223896 q12Shape11T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4128 (660351223896 ||| 2^13) q12Shape11T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (4128 ||| 2^13) 660351223896 q12Shape11T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T21OK,q12Shape11T24OK⟩

private def q12Shape11T18 : Tree 12 := .split 12 q12Shape11T19 q12Shape11T20
private theorem q12Shape11T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 32 660351223896 q12Shape11T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 32 (660351223896 ||| 2^12) q12Shape11T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (32 ||| 2^12) 660351223896 q12Shape11T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T19OK,q12Shape11T20OK⟩

private def q12Shape11T27 : Tree 12 := (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,8,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 20 (.split 21 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape11T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2080 660351234136 q12Shape11T27=true := by decide

private def q12Shape11T28 : Tree 12 := (.tip (.cover {0,1,3,7,9,10,11}))
private theorem q12Shape11T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 10272 660351225944 q12Shape11T28=true := by decide

private def q12Shape11T26 : Tree 12 := .split 13 q12Shape11T27 q12Shape11T28
private theorem q12Shape11T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2080 660351225944 q12Shape11T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2080 (660351225944 ||| 2^13) q12Shape11T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (2080 ||| 2^13) 660351225944 q12Shape11T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T27OK,q12Shape11T28OK⟩

private def q12Shape11T29 : Tree 12 := (.tip (.cover {0,1,3,8,9,10,11}))
private theorem q12Shape11T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 6176 660351221848 q12Shape11T29=true := by decide

private def q12Shape11T25 : Tree 12 := .split 12 q12Shape11T26 q12Shape11T29
private theorem q12Shape11T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2080 660351221848 q12Shape11T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2080 (660351221848 ||| 2^12) q12Shape11T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (2080 ||| 2^12) 660351221848 q12Shape11T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T26OK,q12Shape11T29OK⟩

private def q12Shape11T17 : Tree 12 := .split 11 q12Shape11T18 q12Shape11T25
private theorem q12Shape11T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 32 660351221848 q12Shape11T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 32 (660351221848 ||| 2^11) q12Shape11T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (32 ||| 2^11) 660351221848 q12Shape11T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T18OK,q12Shape11T25OK⟩

private def q12Shape11T30 : Tree 12 := (.tip (.cover {0,1,2,6,7,10,11}))
private theorem q12Shape11T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 96 660351221784 q12Shape11T30=true := by decide

private def q12Shape11T16 : Tree 12 := .split 6 q12Shape11T17 q12Shape11T30
private theorem q12Shape11T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 32 660351221784 q12Shape11T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 32 (660351221784 ||| 2^6) q12Shape11T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (32 ||| 2^6) 660351221784 q12Shape11T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T17OK,q12Shape11T30OK⟩

private def q12Shape11T8 : Tree 12 := .split 5 q12Shape11T9 q12Shape11T16
private theorem q12Shape11T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 660351221784 q12Shape11T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (660351221784 ||| 2^5) q12Shape11T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^5) 660351221784 q12Shape11T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T9OK,q12Shape11T16OK⟩

private def q12Shape11T36 : Tree 12 := (.split 14 (.tip (.cover {0,1,4,5,7,10,11})) (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,7,9,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.split 19 (.split 20 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))))
private theorem q12Shape11T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 660351236200 q12Shape11T36=true := by decide

private def q12Shape11T38 : Tree 12 := (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,7,8,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 19 (.split 20 (.split 21 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))))
private theorem q12Shape11T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8208 660351244392 q12Shape11T38=true := by decide

private def q12Shape11T39 : Tree 12 := (.tip (.cover {0,1,3,6,7,10,11}))
private theorem q12Shape11T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 24592 660351228008 q12Shape11T39=true := by decide

private def q12Shape11T37 : Tree 12 := .split 14 q12Shape11T38 q12Shape11T39
private theorem q12Shape11T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8208 660351228008 q12Shape11T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8208 (660351228008 ||| 2^14) q12Shape11T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (8208 ||| 2^14) 660351228008 q12Shape11T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T38OK,q12Shape11T39OK⟩

private def q12Shape11T35 : Tree 12 := .split 13 q12Shape11T36 q12Shape11T37
private theorem q12Shape11T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 660351228008 q12Shape11T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 (660351228008 ||| 2^13) q12Shape11T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (16 ||| 2^13) 660351228008 q12Shape11T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T36OK,q12Shape11T37OK⟩

private def q12Shape11T40 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape11T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4112 660351223912 q12Shape11T40=true := by decide

private def q12Shape11T34 : Tree 12 := .split 12 q12Shape11T35 q12Shape11T40
private theorem q12Shape11T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 660351223912 q12Shape11T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 (660351223912 ||| 2^12) q12Shape11T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (16 ||| 2^12) 660351223912 q12Shape11T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T35OK,q12Shape11T40OK⟩

private def q12Shape11T41 : Tree 12 := (.split 12 (.split 13 (.split 14 (.tip (.cover {1,4,5,6,7,10,11})) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape11T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2064 660351221864 q12Shape11T41=true := by decide

private def q12Shape11T33 : Tree 12 := .split 11 q12Shape11T34 q12Shape11T41
private theorem q12Shape11T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 660351221864 q12Shape11T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 (660351221864 ||| 2^11) q12Shape11T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (16 ||| 2^11) 660351221864 q12Shape11T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T34OK,q12Shape11T41OK⟩

private def q12Shape11T42 : Tree 12 := (.tip (.cover {0,1,2,6,8,10,11}))
private theorem q12Shape11T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 80 660351221800 q12Shape11T42=true := by decide

private def q12Shape11T32 : Tree 12 := .split 6 q12Shape11T33 q12Shape11T42
private theorem q12Shape11T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 660351221800 q12Shape11T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 (660351221800 ||| 2^6) q12Shape11T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (16 ||| 2^6) 660351221800 q12Shape11T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T33OK,q12Shape11T42OK⟩

private def q12Shape11T43 : Tree 12 := (.tip (.cover {0,1,2,6,9,10,11}))
private theorem q12Shape11T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 48 660351221768 q12Shape11T43=true := by decide

private def q12Shape11T31 : Tree 12 := .split 5 q12Shape11T32 q12Shape11T43
private theorem q12Shape11T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 660351221768 q12Shape11T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 16 (660351221768 ||| 2^5) q12Shape11T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (16 ||| 2^5) 660351221768 q12Shape11T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T32OK,q12Shape11T43OK⟩

private def q12Shape11T7 : Tree 12 := .split 4 q12Shape11T8 q12Shape11T31
private theorem q12Shape11T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 660351221768 q12Shape11T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (660351221768 ||| 2^4) q12Shape11T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^4) 660351221768 q12Shape11T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T8OK,q12Shape11T31OK⟩

private def q12Shape11T50 : Tree 12 := (.split 14 (.tip (.cover {0,1,4,5,6,10,11})) (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,6,9,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.split 20 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,9,10,11}))))
private theorem q12Shape11T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 660351236208 q12Shape11T50=true := by decide

private def q12Shape11T51 : Tree 12 := (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,8,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 20 (.split 21 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,3,6,7,10,11})))
private theorem q12Shape11T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8200 660351228016 q12Shape11T51=true := by decide

private def q12Shape11T49 : Tree 12 := .split 13 q12Shape11T50 q12Shape11T51
private theorem q12Shape11T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 660351228016 q12Shape11T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 (660351228016 ||| 2^13) q12Shape11T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (8 ||| 2^13) 660351228016 q12Shape11T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T50OK,q12Shape11T51OK⟩

private def q12Shape11T52 : Tree 12 := (.split 13 (.split 14 (.tip (.cover {1,4,5,6,7,10,11})) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11})))
private theorem q12Shape11T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4104 660351223920 q12Shape11T52=true := by decide

private def q12Shape11T48 : Tree 12 := .split 12 q12Shape11T49 q12Shape11T52
private theorem q12Shape11T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 660351223920 q12Shape11T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 (660351223920 ||| 2^12) q12Shape11T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (8 ||| 2^12) 660351223920 q12Shape11T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T49OK,q12Shape11T52OK⟩

private def q12Shape11T53 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape11T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2056 660351221872 q12Shape11T53=true := by decide

private def q12Shape11T47 : Tree 12 := .split 11 q12Shape11T48 q12Shape11T53
private theorem q12Shape11T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 660351221872 q12Shape11T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 (660351221872 ||| 2^11) q12Shape11T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (8 ||| 2^11) 660351221872 q12Shape11T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T48OK,q12Shape11T53OK⟩

private def q12Shape11T54 : Tree 12 := (.tip (.cover {0,1,2,7,8,10,11}))
private theorem q12Shape11T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 72 660351221808 q12Shape11T54=true := by decide

private def q12Shape11T46 : Tree 12 := .split 6 q12Shape11T47 q12Shape11T54
private theorem q12Shape11T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 660351221808 q12Shape11T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 (660351221808 ||| 2^6) q12Shape11T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (8 ||| 2^6) 660351221808 q12Shape11T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T47OK,q12Shape11T54OK⟩

private def q12Shape11T55 : Tree 12 := (.tip (.cover {0,1,2,7,9,10,11}))
private theorem q12Shape11T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 40 660351221776 q12Shape11T55=true := by decide

private def q12Shape11T45 : Tree 12 := .split 5 q12Shape11T46 q12Shape11T55
private theorem q12Shape11T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 660351221776 q12Shape11T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 (660351221776 ||| 2^5) q12Shape11T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (8 ||| 2^5) 660351221776 q12Shape11T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T46OK,q12Shape11T55OK⟩

private def q12Shape11T56 : Tree 12 := (.tip (.cover {0,1,2,8,9,10,11}))
private theorem q12Shape11T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 24 660351221760 q12Shape11T56=true := by decide

private def q12Shape11T44 : Tree 12 := .split 4 q12Shape11T45 q12Shape11T56
private theorem q12Shape11T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 660351221760 q12Shape11T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 8 (660351221760 ||| 2^4) q12Shape11T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (8 ||| 2^4) 660351221760 q12Shape11T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T45OK,q12Shape11T56OK⟩

private def q12Shape11T6 : Tree 12 := .split 3 q12Shape11T7 q12Shape11T44
private theorem q12Shape11T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 660351221760 q12Shape11T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (660351221760 ||| 2^3) q12Shape11T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^3) 660351221760 q12Shape11T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T7OK,q12Shape11T44OK⟩

private def q12Shape11T57 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape11T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 68719476736 591631745024 q12Shape11T57=true := by decide

private def q12Shape11T5 : Tree 12 := .split 36 q12Shape11T6 q12Shape11T57
private theorem q12Shape11T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 591631745024 q12Shape11T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (591631745024 ||| 2^36) q12Shape11T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^36) 591631745024 q12Shape11T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T6OK,q12Shape11T57OK⟩

private def q12Shape11T58 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape11T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 34359738368 557272006656 q12Shape11T58=true := by decide

private def q12Shape11T4 : Tree 12 := .split 35 q12Shape11T5 q12Shape11T58
private theorem q12Shape11T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 557272006656 q12Shape11T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (557272006656 ||| 2^35) q12Shape11T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^35) 557272006656 q12Shape11T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T5OK,q12Shape11T58OK⟩

private def q12Shape11T59 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape11T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 4294967296 552977039360 q12Shape11T59=true := by decide

private def q12Shape11T3 : Tree 12 := .split 32 q12Shape11T4 q12Shape11T59
private theorem q12Shape11T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 552977039360 q12Shape11T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (552977039360 ||| 2^32) q12Shape11T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^32) 552977039360 q12Shape11T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T4OK,q12Shape11T59OK⟩

private def q12Shape11T60 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape11T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 2147483648 550829555712 q12Shape11T60=true := by decide

private def q12Shape11T2 : Tree 12 := .split 31 q12Shape11T3 q12Shape11T60
private theorem q12Shape11T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 550829555712 q12Shape11T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (550829555712 ||| 2^31) q12Shape11T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^31) 550829555712 q12Shape11T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T3OK,q12Shape11T60OK⟩

private def q12Shape11T61 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape11T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 549755813888 1073741824 q12Shape11T61=true := by decide

private def q12Shape11T1 : Tree 12 := .split 39 q12Shape11T2 q12Shape11T61
private theorem q12Shape11T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 1073741824 q12Shape11T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (1073741824 ||| 2^39) q12Shape11T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^39) 1073741824 q12Shape11T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T2OK,q12Shape11T61OK⟩

private def q12Shape11T62 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape11T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 1073741824 0 q12Shape11T62=true := by decide

private def q12Shape11T0 : Tree 12 := .split 30 q12Shape11T1 q12Shape11T62
private theorem q12Shape11T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 0 q12Shape11T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 (0 ||| 2^30) q12Shape11T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) (0 ||| 2^30) 0 q12Shape11T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape11T1OK,q12Shape11T62OK⟩

def q12Shape11P0 : Tree 12 := q12Shape11T0
theorem q12Shape11P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,4⟩) 0 0 q12Shape11P0=true := q12Shape11T0OK

end Graffiti384b.EffectiveSearch.Q12
