import Q12Shape12Part0
import Q12Shape12Part1
import Q12Shape12Part2
import Q12Shape12Part3
import Q12Shape12Part4
import Q12Shape12Part5
import Q12Shape12Part6
import Q12Shape12Part7
import Q12Shape12Part8
import Q12Shape12Part9
import Q12Shape12Part10
import Q12Shape12Part11

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12M54 : Tree 12 := .split 24 q12Shape12P0 q12Shape12P1
private theorem q12Shape12M54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 1966080 q12Shape12M54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 (1966080 ||| 2^24) q12Shape12P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (0 ||| 2^24) 1966080 q12Shape12P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12P0OK,q12Shape12P1OK⟩
private def q12Shape12M92 : Tree 12 := .split 20 q12Shape12M54 q12Shape12P2
private theorem q12Shape12M92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 917504 q12Shape12M92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 (917504 ||| 2^20) q12Shape12M54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (0 ||| 2^20) 917504 q12Shape12P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12M54OK,q12Shape12P2OK⟩
private def q12Shape12M161 : Tree 12 := .split 20 q12Shape12P3 q12Shape12P4
private theorem q12Shape12M161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 393216 q12Shape12M161=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 (393216 ||| 2^20) q12Shape12P3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (524288 ||| 2^20) 393216 q12Shape12P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12P3OK,q12Shape12P4OK⟩
private def q12Shape12M162 : Tree 12 := .split 19 q12Shape12M92 q12Shape12M161
private theorem q12Shape12M162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 393216 q12Shape12M162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 (393216 ||| 2^19) q12Shape12M92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (0 ||| 2^19) 393216 q12Shape12M161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12M92OK,q12Shape12M161OK⟩
private def q12Shape12M231 : Tree 12 := .split 20 q12Shape12P5 q12Shape12P6
private theorem q12Shape12M231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 655360 q12Shape12M231=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 (655360 ||| 2^20) q12Shape12P5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (262144 ||| 2^20) 655360 q12Shape12P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12P5OK,q12Shape12P6OK⟩
private def q12Shape12M265 : Tree 12 := .split 19 q12Shape12M231 q12Shape12P7
private theorem q12Shape12M265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 131072 q12Shape12M265=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 (131072 ||| 2^19) q12Shape12M231 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (262144 ||| 2^19) 131072 q12Shape12P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12M231OK,q12Shape12P7OK⟩
private def q12Shape12M266 : Tree 12 := .split 18 q12Shape12M162 q12Shape12M265
private theorem q12Shape12M266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 131072 q12Shape12M266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 (131072 ||| 2^18) q12Shape12M162 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (0 ||| 2^18) 131072 q12Shape12M265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12M162OK,q12Shape12M265OK⟩
private def q12Shape12M329 : Tree 12 := .split 20 q12Shape12P8 q12Shape12P9
private theorem q12Shape12M329OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 786432 q12Shape12M329=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (786432 ||| 2^20) q12Shape12P8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^20) 786432 q12Shape12P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12P8OK,q12Shape12P9OK⟩
private def q12Shape12M359 : Tree 12 := .split 19 q12Shape12M329 q12Shape12P10
private theorem q12Shape12M359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 262144 q12Shape12M359=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (262144 ||| 2^19) q12Shape12M329 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^19) 262144 q12Shape12P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12M329OK,q12Shape12P10OK⟩
private def q12Shape12M387 : Tree 12 := .split 18 q12Shape12M359 q12Shape12P11
private theorem q12Shape12M387OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 0 q12Shape12M387=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (0 ||| 2^18) q12Shape12M359 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^18) 0 q12Shape12P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12M359OK,q12Shape12P11OK⟩
private def q12Shape12M388 : Tree 12 := .split 17 q12Shape12M266 q12Shape12M387
private theorem q12Shape12M388OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 0 q12Shape12M388=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 (0 ||| 2^17) q12Shape12M266 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (0 ||| 2^17) 0 q12Shape12M387)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12M266OK,q12Shape12M387OK⟩

theorem q12Shape12_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 12) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 12) b) (adj 12 (forms 12) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) adj_mono b H q12Shape12M388 q12Shape12M388OK

#print axioms q12Shape12_cover

end Graffiti384b.EffectiveSearch.Q12
