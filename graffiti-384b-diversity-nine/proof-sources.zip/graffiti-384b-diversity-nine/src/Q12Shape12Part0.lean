import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T2 : Tree 12 := (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,2,3,6,9,10,11}))))
private theorem q12Shape12T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 119406592 q12Shape12T2=true := by decide

private def q12Shape12T4 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape12T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67108864 1126039552 q12Shape12T4=true := by decide

private def q12Shape12T7 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1140850688 36559519744 q12Shape12T7=true := by decide

private def q12Shape12T8 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 35500589056 2199781376 q12Shape12T8=true := by decide

private def q12Shape12T6 : Tree 12 := .split 35 q12Shape12T7 q12Shape12T8
private theorem q12Shape12T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1140850688 2199781376 q12Shape12T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1140850688 (2199781376 ||| 2^35) q12Shape12T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1140850688 ||| 2^35) 2199781376 q12Shape12T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T7OK,q12Shape12T8OK⟩

private def q12Shape12T9 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3288334336 52297728 q12Shape12T9=true := by decide

private def q12Shape12T5 : Tree 12 := .split 31 q12Shape12T6 q12Shape12T9
private theorem q12Shape12T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1140850688 52297728 q12Shape12T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1140850688 (52297728 ||| 2^31) q12Shape12T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1140850688 ||| 2^31) 52297728 q12Shape12T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T6OK,q12Shape12T9OK⟩

private def q12Shape12T3 : Tree 12 := .split 30 q12Shape12T4 q12Shape12T5
private theorem q12Shape12T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67108864 52297728 q12Shape12T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67108864 (52297728 ||| 2^30) q12Shape12T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67108864 ||| 2^30) 52297728 q12Shape12T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T4OK,q12Shape12T5OK⟩

private def q12Shape12T1 : Tree 12 := .split 26 q12Shape12T2 q12Shape12T3
private theorem q12Shape12T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 52297728 q12Shape12T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 (52297728 ||| 2^26) q12Shape12T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (0 ||| 2^26) 52297728 q12Shape12T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T2OK,q12Shape12T3OK⟩

private def q12Shape12T13 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape12T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33554432 3307077632 q12Shape12T13=true := by decide

private def q12Shape12T15 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2181038080 35519332352 q12Shape12T15=true := by decide

private def q12Shape12T16 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 36540776448 1159593984 q12Shape12T16=true := by decide

private def q12Shape12T14 : Tree 12 := .split 35 q12Shape12T15 q12Shape12T16
private theorem q12Shape12T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2181038080 1159593984 q12Shape12T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2181038080 (1159593984 ||| 2^35) q12Shape12T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (2181038080 ||| 2^35) 1159593984 q12Shape12T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T15OK,q12Shape12T16OK⟩

private def q12Shape12T12 : Tree 12 := .split 31 q12Shape12T13 q12Shape12T14
private theorem q12Shape12T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33554432 1159593984 q12Shape12T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33554432 (1159593984 ||| 2^31) q12Shape12T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33554432 ||| 2^31) 1159593984 q12Shape12T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T13OK,q12Shape12T14OK⟩

private def q12Shape12T18 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape12T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107296256 2233335808 q12Shape12T18=true := by decide

private def q12Shape12T19 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3254779904 85852160 q12Shape12T19=true := by decide

private def q12Shape12T17 : Tree 12 := .split 31 q12Shape12T18 q12Shape12T19
private theorem q12Shape12T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107296256 85852160 q12Shape12T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107296256 (85852160 ||| 2^31) q12Shape12T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1107296256 ||| 2^31) 85852160 q12Shape12T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T18OK,q12Shape12T19OK⟩

private def q12Shape12T11 : Tree 12 := .split 30 q12Shape12T12 q12Shape12T17
private theorem q12Shape12T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33554432 85852160 q12Shape12T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33554432 (85852160 ||| 2^30) q12Shape12T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33554432 ||| 2^30) 85852160 q12Shape12T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T12OK,q12Shape12T17OK⟩

private def q12Shape12T22 : Tree 12 := (.tip (.cover {0,2,3,5,9,10,11}))
private theorem q12Shape12T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 100663296 3239968768 q12Shape12T22=true := by decide

private def q12Shape12T23 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2248146944 1092485120 q12Shape12T23=true := by decide

private def q12Shape12T21 : Tree 12 := .split 31 q12Shape12T22 q12Shape12T23
private theorem q12Shape12T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 100663296 1092485120 q12Shape12T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 100663296 (1092485120 ||| 2^31) q12Shape12T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (100663296 ||| 2^31) 1092485120 q12Shape12T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T22OK,q12Shape12T23OK⟩

private def q12Shape12T25 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1174405120 2166226944 q12Shape12T25=true := by decide

private def q12Shape12T26 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,6,9,10,11})))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3321888768 18743296 q12Shape12T26=true := by decide

private def q12Shape12T24 : Tree 12 := .split 31 q12Shape12T25 q12Shape12T26
private theorem q12Shape12T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1174405120 18743296 q12Shape12T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1174405120 (18743296 ||| 2^31) q12Shape12T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1174405120 ||| 2^31) 18743296 q12Shape12T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T25OK,q12Shape12T26OK⟩

private def q12Shape12T20 : Tree 12 := .split 30 q12Shape12T21 q12Shape12T24
private theorem q12Shape12T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 100663296 18743296 q12Shape12T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 100663296 (18743296 ||| 2^30) q12Shape12T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (100663296 ||| 2^30) 18743296 q12Shape12T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T21OK,q12Shape12T24OK⟩

private def q12Shape12T10 : Tree 12 := .split 26 q12Shape12T11 q12Shape12T20
private theorem q12Shape12T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33554432 18743296 q12Shape12T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33554432 (18743296 ||| 2^26) q12Shape12T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33554432 ||| 2^26) 18743296 q12Shape12T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T11OK,q12Shape12T20OK⟩

private def q12Shape12T0 : Tree 12 := .split 25 q12Shape12T1 q12Shape12T10
private theorem q12Shape12T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 18743296 q12Shape12T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 (18743296 ||| 2^25) q12Shape12T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (0 ||| 2^25) 18743296 q12Shape12T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T1OK,q12Shape12T10OK⟩

def q12Shape12P0 : Tree 12 := q12Shape12T0
theorem q12Shape12P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 0 18743296 q12Shape12P0=true := q12Shape12T0OK

end Graffiti384b.EffectiveSearch.Q12
