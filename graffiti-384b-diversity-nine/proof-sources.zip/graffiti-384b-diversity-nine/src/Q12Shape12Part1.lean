import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T31 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 3323854848 q12Shape12T31=true := by decide

private def q12Shape12T32 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2164260864 1176371200 q12Shape12T32=true := by decide

private def q12Shape12T30 : Tree 12 := .split 31 q12Shape12T31 q12Shape12T32
private theorem q12Shape12T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 1176371200 q12Shape12T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 (1176371200 ||| 2^31) q12Shape12T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16777216 ||| 2^31) 1176371200 q12Shape12T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T31OK,q12Shape12T32OK⟩

private def q12Shape12T34 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1090519040 2250113024 q12Shape12T34=true := by decide

private def q12Shape12T35 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3238002688 102629376 q12Shape12T35=true := by decide

private def q12Shape12T33 : Tree 12 := .split 31 q12Shape12T34 q12Shape12T35
private theorem q12Shape12T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1090519040 102629376 q12Shape12T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1090519040 (102629376 ||| 2^31) q12Shape12T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1090519040 ||| 2^31) 102629376 q12Shape12T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T34OK,q12Shape12T35OK⟩

private def q12Shape12T29 : Tree 12 := .split 30 q12Shape12T30 q12Shape12T33
private theorem q12Shape12T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 102629376 q12Shape12T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 (102629376 ||| 2^30) q12Shape12T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16777216 ||| 2^30) 102629376 q12Shape12T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T30OK,q12Shape12T33OK⟩

private def q12Shape12T38 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 83886080 3256745984 q12Shape12T38=true := by decide

private def q12Shape12T39 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape12T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2231369728 1109262336 q12Shape12T39=true := by decide

private def q12Shape12T37 : Tree 12 := .split 31 q12Shape12T38 q12Shape12T39
private theorem q12Shape12T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 83886080 1109262336 q12Shape12T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 83886080 (1109262336 ||| 2^31) q12Shape12T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (83886080 ||| 2^31) 1109262336 q12Shape12T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T38OK,q12Shape12T39OK⟩

private def q12Shape12T42 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1157627904 36542742528 q12Shape12T42=true := by decide

private def q12Shape12T43 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,7,9,10,11})))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 35517366272 2183004160 q12Shape12T43=true := by decide

private def q12Shape12T41 : Tree 12 := .split 35 q12Shape12T42 q12Shape12T43
private theorem q12Shape12T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1157627904 2183004160 q12Shape12T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1157627904 (2183004160 ||| 2^35) q12Shape12T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1157627904 ||| 2^35) 2183004160 q12Shape12T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T42OK,q12Shape12T43OK⟩

private def q12Shape12T44 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3305111552 35520512 q12Shape12T44=true := by decide

private def q12Shape12T40 : Tree 12 := .split 31 q12Shape12T41 q12Shape12T44
private theorem q12Shape12T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1157627904 35520512 q12Shape12T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1157627904 (35520512 ||| 2^31) q12Shape12T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1157627904 ||| 2^31) 35520512 q12Shape12T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T41OK,q12Shape12T44OK⟩

private def q12Shape12T36 : Tree 12 := .split 30 q12Shape12T37 q12Shape12T40
private theorem q12Shape12T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 83886080 35520512 q12Shape12T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 83886080 (35520512 ||| 2^30) q12Shape12T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (83886080 ||| 2^30) 35520512 q12Shape12T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T37OK,q12Shape12T40OK⟩

private def q12Shape12T28 : Tree 12 := .split 26 q12Shape12T29 q12Shape12T36
private theorem q12Shape12T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 35520512 q12Shape12T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 (35520512 ||| 2^26) q12Shape12T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16777216 ||| 2^26) 35520512 q12Shape12T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T29OK,q12Shape12T36OK⟩

private def q12Shape12T48 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50331648 3290300416 q12Shape12T48=true := by decide

private def q12Shape12T50 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2197815296 35502555136 q12Shape12T50=true := by decide

private def q12Shape12T51 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,8,9,10,11})))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 36557553664 1142816768 q12Shape12T51=true := by decide

private def q12Shape12T49 : Tree 12 := .split 35 q12Shape12T50 q12Shape12T51
private theorem q12Shape12T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2197815296 1142816768 q12Shape12T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2197815296 (1142816768 ||| 2^35) q12Shape12T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (2197815296 ||| 2^35) 1142816768 q12Shape12T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T50OK,q12Shape12T51OK⟩

private def q12Shape12T47 : Tree 12 := .split 31 q12Shape12T48 q12Shape12T49
private theorem q12Shape12T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50331648 1142816768 q12Shape12T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50331648 (1142816768 ||| 2^31) q12Shape12T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50331648 ||| 2^31) 1142816768 q12Shape12T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T48OK,q12Shape12T49OK⟩

private def q12Shape12T52 : Tree 12 := (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape12T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1124073472 69074944 q12Shape12T52=true := by decide

private def q12Shape12T46 : Tree 12 := .split 30 q12Shape12T47 q12Shape12T52
private theorem q12Shape12T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50331648 69074944 q12Shape12T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50331648 (69074944 ||| 2^30) q12Shape12T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50331648 ||| 2^30) 69074944 q12Shape12T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T47OK,q12Shape12T52OK⟩

private def q12Shape12T53 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 117440512 1966080 q12Shape12T53=true := by decide

private def q12Shape12T45 : Tree 12 := .split 26 q12Shape12T46 q12Shape12T53
private theorem q12Shape12T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50331648 1966080 q12Shape12T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50331648 (1966080 ||| 2^26) q12Shape12T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50331648 ||| 2^26) 1966080 q12Shape12T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T46OK,q12Shape12T53OK⟩

private def q12Shape12T27 : Tree 12 := .split 25 q12Shape12T28 q12Shape12T45
private theorem q12Shape12T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 1966080 q12Shape12T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 (1966080 ||| 2^25) q12Shape12T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16777216 ||| 2^25) 1966080 q12Shape12T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T28OK,q12Shape12T45OK⟩

def q12Shape12P1 : Tree 12 := q12Shape12T27
theorem q12Shape12P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16777216 1966080 q12Shape12P1=true := q12Shape12T27OK

end Graffiti384b.EffectiveSearch.Q12
