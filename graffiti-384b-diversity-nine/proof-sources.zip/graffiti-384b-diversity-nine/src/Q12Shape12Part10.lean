import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T336 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))))
private theorem q12Shape12T336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 3339976704 q12Shape12T336=true := by decide

private def q12Shape12T337 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148139008 1192493056 q12Shape12T337=true := by decide

private def q12Shape12T335 : Tree 12 := .split 31 q12Shape12T336 q12Shape12T337
private theorem q12Shape12T335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 1192493056 q12Shape12T335=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 (1192493056 ||| 2^31) q12Shape12T336 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (655360 ||| 2^31) 1192493056 q12Shape12T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T336OK,q12Shape12T337OK⟩

private def q12Shape12T339 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8,11}))))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074397184 2266234880 q12Shape12T339=true := by decide

private def q12Shape12T340 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3221880832 118751232 q12Shape12T340=true := by decide

private def q12Shape12T338 : Tree 12 := .split 31 q12Shape12T339 q12Shape12T340
private theorem q12Shape12T338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074397184 118751232 q12Shape12T338=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074397184 (118751232 ||| 2^31) q12Shape12T339 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1074397184 ||| 2^31) 118751232 q12Shape12T340)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T339OK,q12Shape12T340OK⟩

private def q12Shape12T334 : Tree 12 := .split 30 q12Shape12T335 q12Shape12T338
private theorem q12Shape12T334OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 118751232 q12Shape12T334=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 (118751232 ||| 2^30) q12Shape12T335 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (655360 ||| 2^30) 118751232 q12Shape12T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T335OK,q12Shape12T338OK⟩

private def q12Shape12T344 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T344OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67764224 37632606208 q12Shape12T344=true := by decide

private def q12Shape12T345 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,6,8,9,10,11})))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34427502592 3272867840 q12Shape12T345=true := by decide

private def q12Shape12T343 : Tree 12 := .split 35 q12Shape12T344 q12Shape12T345
private theorem q12Shape12T343OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67764224 3272867840 q12Shape12T343=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67764224 (3272867840 ||| 2^35) q12Shape12T344 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67764224 ||| 2^35) 3272867840 q12Shape12T345)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T344OK,q12Shape12T345OK⟩

private def q12Shape12T346 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T346OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2215247872 1125384192 q12Shape12T346=true := by decide

private def q12Shape12T342 : Tree 12 := .split 31 q12Shape12T343 q12Shape12T346
private theorem q12Shape12T342OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67764224 1125384192 q12Shape12T342=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67764224 (1125384192 ||| 2^31) q12Shape12T343 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67764224 ||| 2^31) 1125384192 q12Shape12T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T343OK,q12Shape12T346OK⟩

private def q12Shape12T347 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T347OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1141506048 51642368 q12Shape12T347=true := by decide

private def q12Shape12T341 : Tree 12 := .split 30 q12Shape12T342 q12Shape12T347
private theorem q12Shape12T341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67764224 51642368 q12Shape12T341=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67764224 (51642368 ||| 2^30) q12Shape12T342 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67764224 ||| 2^30) 51642368 q12Shape12T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T342OK,q12Shape12T347OK⟩

private def q12Shape12T333 : Tree 12 := .split 26 q12Shape12T334 q12Shape12T341
private theorem q12Shape12T333OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 51642368 q12Shape12T333=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 (51642368 ||| 2^26) q12Shape12T334 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (655360 ||| 2^26) 51642368 q12Shape12T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T334OK,q12Shape12T341OK⟩

private def q12Shape12T348 : Tree 12 := (.split 26 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape12T348OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34209792 18087936 q12Shape12T348=true := by decide

private def q12Shape12T332 : Tree 12 := .split 25 q12Shape12T333 q12Shape12T348
private theorem q12Shape12T332OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 18087936 q12Shape12T332=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 (18087936 ||| 2^25) q12Shape12T333 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (655360 ||| 2^25) 18087936 q12Shape12T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T333OK,q12Shape12T348OK⟩

private def q12Shape12T353 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape12T353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 3323199488 q12Shape12T353=true := by decide

private def q12Shape12T354 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2164916224 1175715840 q12Shape12T354=true := by decide

private def q12Shape12T352 : Tree 12 := .split 31 q12Shape12T353 q12Shape12T354
private theorem q12Shape12T352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 1175715840 q12Shape12T352=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 (1175715840 ||| 2^31) q12Shape12T353 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17432576 ||| 2^31) 1175715840 q12Shape12T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T353OK,q12Shape12T354OK⟩

private def q12Shape12T355 : Tree 12 := (.split 31 (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,6,8,9,10,11})))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape12T355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1091174400 101974016 q12Shape12T355=true := by decide

private def q12Shape12T351 : Tree 12 := .split 30 q12Shape12T352 q12Shape12T355
private theorem q12Shape12T351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 101974016 q12Shape12T351=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 (101974016 ||| 2^30) q12Shape12T352 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17432576 ||| 2^30) 101974016 q12Shape12T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T352OK,q12Shape12T355OK⟩

private def q12Shape12T356 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T356OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84541440 34865152 q12Shape12T356=true := by decide

private def q12Shape12T350 : Tree 12 := .split 26 q12Shape12T351 q12Shape12T356
private theorem q12Shape12T350OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 34865152 q12Shape12T350=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 (34865152 ||| 2^26) q12Shape12T351 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17432576 ||| 2^26) 34865152 q12Shape12T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T351OK,q12Shape12T356OK⟩

private def q12Shape12T357 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape12T357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50987008 1310720 q12Shape12T357=true := by decide

private def q12Shape12T349 : Tree 12 := .split 25 q12Shape12T350 q12Shape12T357
private theorem q12Shape12T349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 1310720 q12Shape12T349=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17432576 (1310720 ||| 2^25) q12Shape12T350 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17432576 ||| 2^25) 1310720 q12Shape12T357)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T350OK,q12Shape12T357OK⟩

private def q12Shape12T331 : Tree 12 := .split 24 q12Shape12T332 q12Shape12T349
private theorem q12Shape12T331OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 1310720 q12Shape12T331=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 (1310720 ||| 2^24) q12Shape12T332 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (655360 ||| 2^24) 1310720 q12Shape12T349)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T332OK,q12Shape12T349OK⟩

private def q12Shape12T358 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T358OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1703936 262144 q12Shape12T358=true := by decide

private def q12Shape12T330 : Tree 12 := .split 20 q12Shape12T331 q12Shape12T358
private theorem q12Shape12T330OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 262144 q12Shape12T330=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 (262144 ||| 2^20) q12Shape12T331 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (655360 ||| 2^20) 262144 q12Shape12T358)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T331OK,q12Shape12T358OK⟩

def q12Shape12P10 : Tree 12 := q12Shape12T330
theorem q12Shape12P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 655360 262144 q12Shape12P10=true := q12Shape12T330OK

end Graffiti384b.EffectiveSearch.Q12
