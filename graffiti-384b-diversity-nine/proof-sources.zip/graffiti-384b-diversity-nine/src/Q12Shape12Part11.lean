import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T367 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T367OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 3340238848 q12Shape12T367=true := by decide

private def q12Shape12T368 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T368OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2147876864 1192755200 q12Shape12T368=true := by decide

private def q12Shape12T366 : Tree 12 := .split 31 q12Shape12T367 q12Shape12T368
private theorem q12Shape12T366OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 1192755200 q12Shape12T366=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 (1192755200 ||| 2^31) q12Shape12T367 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (393216 ||| 2^31) 1192755200 q12Shape12T368)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T367OK,q12Shape12T368OK⟩

private def q12Shape12T370 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8,11}))))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T370OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074135040 2266497024 q12Shape12T370=true := by decide

private def q12Shape12T371 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3221618688 119013376 q12Shape12T371=true := by decide

private def q12Shape12T369 : Tree 12 := .split 31 q12Shape12T370 q12Shape12T371
private theorem q12Shape12T369OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074135040 119013376 q12Shape12T369=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074135040 (119013376 ||| 2^31) q12Shape12T370 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1074135040 ||| 2^31) 119013376 q12Shape12T371)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T370OK,q12Shape12T371OK⟩

private def q12Shape12T365 : Tree 12 := .split 30 q12Shape12T366 q12Shape12T369
private theorem q12Shape12T365OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 119013376 q12Shape12T365=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 (119013376 ||| 2^30) q12Shape12T366 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (393216 ||| 2^30) 119013376 q12Shape12T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T366OK,q12Shape12T369OK⟩

private def q12Shape12T374 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T374OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67502080 3273129984 q12Shape12T374=true := by decide

private def q12Shape12T375 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,7,8,9,10,11})))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T375OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2214985728 1125646336 q12Shape12T375=true := by decide

private def q12Shape12T373 : Tree 12 := .split 31 q12Shape12T374 q12Shape12T375
private theorem q12Shape12T373OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67502080 1125646336 q12Shape12T373=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67502080 (1125646336 ||| 2^31) q12Shape12T374 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67502080 ||| 2^31) 1125646336 q12Shape12T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T374OK,q12Shape12T375OK⟩

private def q12Shape12T376 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T376OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1141243904 51904512 q12Shape12T376=true := by decide

private def q12Shape12T372 : Tree 12 := .split 30 q12Shape12T373 q12Shape12T376
private theorem q12Shape12T372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67502080 51904512 q12Shape12T372=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67502080 (51904512 ||| 2^30) q12Shape12T373 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67502080 ||| 2^30) 51904512 q12Shape12T376)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T373OK,q12Shape12T376OK⟩

private def q12Shape12T364 : Tree 12 := .split 26 q12Shape12T365 q12Shape12T372
private theorem q12Shape12T364OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 51904512 q12Shape12T364=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 (51904512 ||| 2^26) q12Shape12T365 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (393216 ||| 2^26) 51904512 q12Shape12T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T365OK,q12Shape12T372OK⟩

private def q12Shape12T380 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T380OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33947648 3306684416 q12Shape12T380=true := by decide

private def q12Shape12T381 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T381OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2181431296 1159200768 q12Shape12T381=true := by decide

private def q12Shape12T379 : Tree 12 := .split 31 q12Shape12T380 q12Shape12T381
private theorem q12Shape12T379OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33947648 1159200768 q12Shape12T379=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33947648 (1159200768 ||| 2^31) q12Shape12T380 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33947648 ||| 2^31) 1159200768 q12Shape12T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T380OK,q12Shape12T381OK⟩

private def q12Shape12T382 : Tree 12 := (.split 31 (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,7,8,9,10,11})))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape12T382OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107689472 85458944 q12Shape12T382=true := by decide

private def q12Shape12T378 : Tree 12 := .split 30 q12Shape12T379 q12Shape12T382
private theorem q12Shape12T378OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33947648 85458944 q12Shape12T378=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33947648 (85458944 ||| 2^30) q12Shape12T379 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33947648 ||| 2^30) 85458944 q12Shape12T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T379OK,q12Shape12T382OK⟩

private def q12Shape12T383 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T383OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101056512 18350080 q12Shape12T383=true := by decide

private def q12Shape12T377 : Tree 12 := .split 26 q12Shape12T378 q12Shape12T383
private theorem q12Shape12T377OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33947648 18350080 q12Shape12T377=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33947648 (18350080 ||| 2^26) q12Shape12T378 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33947648 ||| 2^26) 18350080 q12Shape12T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T378OK,q12Shape12T383OK⟩

private def q12Shape12T363 : Tree 12 := .split 25 q12Shape12T364 q12Shape12T377
private theorem q12Shape12T363OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 18350080 q12Shape12T363=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 (18350080 ||| 2^25) q12Shape12T364 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (393216 ||| 2^25) 18350080 q12Shape12T377)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T364OK,q12Shape12T377OK⟩

private def q12Shape12T384 : Tree 12 := (.split 25 (.split 26 (.split 30 (.split 31 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape12T384OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17170432 1572864 q12Shape12T384=true := by decide

private def q12Shape12T362 : Tree 12 := .split 24 q12Shape12T363 q12Shape12T384
private theorem q12Shape12T362OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 1572864 q12Shape12T362=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 (1572864 ||| 2^24) q12Shape12T363 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (393216 ||| 2^24) 1572864 q12Shape12T384)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T363OK,q12Shape12T384OK⟩

private def q12Shape12T385 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape12T385OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1441792 524288 q12Shape12T385=true := by decide

private def q12Shape12T361 : Tree 12 := .split 20 q12Shape12T362 q12Shape12T385
private theorem q12Shape12T361OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 524288 q12Shape12T361=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 (524288 ||| 2^20) q12Shape12T362 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (393216 ||| 2^20) 524288 q12Shape12T385)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T362OK,q12Shape12T385OK⟩

private def q12Shape12T386 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape12T386OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 917504 0 q12Shape12T386=true := by decide

private def q12Shape12T360 : Tree 12 := .split 19 q12Shape12T361 q12Shape12T386
private theorem q12Shape12T360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 0 q12Shape12T360=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 (0 ||| 2^19) q12Shape12T361 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (393216 ||| 2^19) 0 q12Shape12T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T361OK,q12Shape12T386OK⟩

def q12Shape12P11 : Tree 12 := q12Shape12T360
theorem q12Shape12P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 393216 0 q12Shape12P11=true := q12Shape12T360OK

end Graffiti384b.EffectiveSearch.Q12
