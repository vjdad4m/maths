import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T59 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape12T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 1192099840 q12Shape12T59=true := by decide

private def q12Shape12T62 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074790400 36625580032 q12Shape12T62=true := by decide

private def q12Shape12T63 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 35434528768 2265841664 q12Shape12T63=true := by decide

private def q12Shape12T61 : Tree 12 := .split 35 q12Shape12T62 q12Shape12T63
private theorem q12Shape12T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074790400 2265841664 q12Shape12T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074790400 (2265841664 ||| 2^35) q12Shape12T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1074790400 ||| 2^35) 2265841664 q12Shape12T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T62OK,q12Shape12T63OK⟩

private def q12Shape12T64 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape12T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3222274048 118358016 q12Shape12T64=true := by decide

private def q12Shape12T60 : Tree 12 := .split 31 q12Shape12T61 q12Shape12T64
private theorem q12Shape12T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074790400 118358016 q12Shape12T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074790400 (118358016 ||| 2^31) q12Shape12T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1074790400 ||| 2^31) 118358016 q12Shape12T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T61OK,q12Shape12T64OK⟩

private def q12Shape12T58 : Tree 12 := .split 30 q12Shape12T59 q12Shape12T60
private theorem q12Shape12T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 118358016 q12Shape12T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 (118358016 ||| 2^30) q12Shape12T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1048576 ||| 2^30) 118358016 q12Shape12T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T59OK,q12Shape12T60OK⟩

private def q12Shape12T65 : Tree 12 := (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape12T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 68157440 51249152 q12Shape12T65=true := by decide

private def q12Shape12T57 : Tree 12 := .split 26 q12Shape12T58 q12Shape12T65
private theorem q12Shape12T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 51249152 q12Shape12T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 (51249152 ||| 2^26) q12Shape12T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1048576 ||| 2^26) 51249152 q12Shape12T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T58OK,q12Shape12T65OK⟩

private def q12Shape12T70 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 37665767424 q12Shape12T70=true := by decide

private def q12Shape12T71 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34394341376 3306029056 q12Shape12T71=true := by decide

private def q12Shape12T69 : Tree 12 := .split 35 q12Shape12T70 q12Shape12T71
private theorem q12Shape12T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 3306029056 q12Shape12T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 (3306029056 ||| 2^35) q12Shape12T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34603008 ||| 2^35) 3306029056 q12Shape12T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T70OK,q12Shape12T71OK⟩

private def q12Shape12T72 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape12T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2182086656 1158545408 q12Shape12T72=true := by decide

private def q12Shape12T68 : Tree 12 := .split 31 q12Shape12T69 q12Shape12T72
private theorem q12Shape12T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 1158545408 q12Shape12T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 (1158545408 ||| 2^31) q12Shape12T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34603008 ||| 2^31) 1158545408 q12Shape12T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T69OK,q12Shape12T72OK⟩

private def q12Shape12T73 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape12T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1108344832 84803584 q12Shape12T73=true := by decide

private def q12Shape12T67 : Tree 12 := .split 30 q12Shape12T68 q12Shape12T73
private theorem q12Shape12T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 84803584 q12Shape12T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 (84803584 ||| 2^30) q12Shape12T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34603008 ||| 2^30) 84803584 q12Shape12T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T68OK,q12Shape12T73OK⟩

private def q12Shape12T76 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape12T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101711872 3238920192 q12Shape12T76=true := by decide

private def q12Shape12T77 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape12T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2249195520 1091436544 q12Shape12T77=true := by decide

private def q12Shape12T75 : Tree 12 := .split 31 q12Shape12T76 q12Shape12T77
private theorem q12Shape12T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101711872 1091436544 q12Shape12T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101711872 (1091436544 ||| 2^31) q12Shape12T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (101711872 ||| 2^31) 1091436544 q12Shape12T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T76OK,q12Shape12T77OK⟩

private def q12Shape12T78 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape12T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1175453696 17694720 q12Shape12T78=true := by decide

private def q12Shape12T74 : Tree 12 := .split 30 q12Shape12T75 q12Shape12T78
private theorem q12Shape12T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101711872 17694720 q12Shape12T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101711872 (17694720 ||| 2^30) q12Shape12T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (101711872 ||| 2^30) 17694720 q12Shape12T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T75OK,q12Shape12T78OK⟩

private def q12Shape12T66 : Tree 12 := .split 26 q12Shape12T67 q12Shape12T74
private theorem q12Shape12T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 17694720 q12Shape12T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34603008 (17694720 ||| 2^26) q12Shape12T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34603008 ||| 2^26) 17694720 q12Shape12T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T67OK,q12Shape12T74OK⟩

private def q12Shape12T56 : Tree 12 := .split 25 q12Shape12T57 q12Shape12T66
private theorem q12Shape12T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 17694720 q12Shape12T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 (17694720 ||| 2^25) q12Shape12T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1048576 ||| 2^25) 17694720 q12Shape12T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T57OK,q12Shape12T66OK⟩

private def q12Shape12T83 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape12T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 3322806272 q12Shape12T83=true := by decide

private def q12Shape12T84 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape12T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2165309440 1175322624 q12Shape12T84=true := by decide

private def q12Shape12T82 : Tree 12 := .split 31 q12Shape12T83 q12Shape12T84
private theorem q12Shape12T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 1175322624 q12Shape12T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 (1175322624 ||| 2^31) q12Shape12T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17825792 ||| 2^31) 1175322624 q12Shape12T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T83OK,q12Shape12T84OK⟩

private def q12Shape12T85 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1091567616 101580800 q12Shape12T85=true := by decide

private def q12Shape12T81 : Tree 12 := .split 30 q12Shape12T82 q12Shape12T85
private theorem q12Shape12T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 101580800 q12Shape12T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 (101580800 ||| 2^30) q12Shape12T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17825792 ||| 2^30) 101580800 q12Shape12T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T82OK,q12Shape12T85OK⟩

private def q12Shape12T88 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape12T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84934656 3255697408 q12Shape12T88=true := by decide

private def q12Shape12T89 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape12T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2232418304 1108213760 q12Shape12T89=true := by decide

private def q12Shape12T87 : Tree 12 := .split 31 q12Shape12T88 q12Shape12T89
private theorem q12Shape12T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84934656 1108213760 q12Shape12T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84934656 (1108213760 ||| 2^31) q12Shape12T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (84934656 ||| 2^31) 1108213760 q12Shape12T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T88OK,q12Shape12T89OK⟩

private def q12Shape12T90 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1158676480 34471936 q12Shape12T90=true := by decide

private def q12Shape12T86 : Tree 12 := .split 30 q12Shape12T87 q12Shape12T90
private theorem q12Shape12T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84934656 34471936 q12Shape12T86=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84934656 (34471936 ||| 2^30) q12Shape12T87 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (84934656 ||| 2^30) 34471936 q12Shape12T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T87OK,q12Shape12T90OK⟩

private def q12Shape12T80 : Tree 12 := .split 26 q12Shape12T81 q12Shape12T86
private theorem q12Shape12T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 34471936 q12Shape12T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 (34471936 ||| 2^26) q12Shape12T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17825792 ||| 2^26) 34471936 q12Shape12T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T81OK,q12Shape12T86OK⟩

private def q12Shape12T91 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 51380224 917504 q12Shape12T91=true := by decide

private def q12Shape12T79 : Tree 12 := .split 25 q12Shape12T80 q12Shape12T91
private theorem q12Shape12T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 917504 q12Shape12T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17825792 (917504 ||| 2^25) q12Shape12T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17825792 ||| 2^25) 917504 q12Shape12T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T80OK,q12Shape12T91OK⟩

private def q12Shape12T55 : Tree 12 := .split 24 q12Shape12T56 q12Shape12T79
private theorem q12Shape12T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 917504 q12Shape12T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 (917504 ||| 2^24) q12Shape12T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1048576 ||| 2^24) 917504 q12Shape12T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T56OK,q12Shape12T79OK⟩

def q12Shape12P2 : Tree 12 := q12Shape12T55
theorem q12Shape12P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1048576 917504 q12Shape12P2=true := q12Shape12T55OK

end Graffiti384b.EffectiveSearch.Q12
