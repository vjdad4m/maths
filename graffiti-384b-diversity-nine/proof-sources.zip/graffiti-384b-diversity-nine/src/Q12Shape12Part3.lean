import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T98 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape12T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 3340107776 q12Shape12T98=true := by decide

private def q12Shape12T100 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148007936 35552362496 q12Shape12T100=true := by decide

private def q12Shape12T101 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 36507746304 1192624128 q12Shape12T101=true := by decide

private def q12Shape12T99 : Tree 12 := .split 35 q12Shape12T100 q12Shape12T101
private theorem q12Shape12T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148007936 1192624128 q12Shape12T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148007936 (1192624128 ||| 2^35) q12Shape12T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (2148007936 ||| 2^35) 1192624128 q12Shape12T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T100OK,q12Shape12T101OK⟩

private def q12Shape12T97 : Tree 12 := .split 31 q12Shape12T98 q12Shape12T99
private theorem q12Shape12T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 1192624128 q12Shape12T97=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 (1192624128 ||| 2^31) q12Shape12T98 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (524288 ||| 2^31) 1192624128 q12Shape12T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T98OK,q12Shape12T99OK⟩

private def q12Shape12T103 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape12T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074266112 2266365952 q12Shape12T103=true := by decide

private def q12Shape12T104 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape12T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3221749760 118882304 q12Shape12T104=true := by decide

private def q12Shape12T102 : Tree 12 := .split 31 q12Shape12T103 q12Shape12T104
private theorem q12Shape12T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074266112 118882304 q12Shape12T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074266112 (118882304 ||| 2^31) q12Shape12T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1074266112 ||| 2^31) 118882304 q12Shape12T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T103OK,q12Shape12T104OK⟩

private def q12Shape12T96 : Tree 12 := .split 30 q12Shape12T97 q12Shape12T102
private theorem q12Shape12T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 118882304 q12Shape12T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 (118882304 ||| 2^30) q12Shape12T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (524288 ||| 2^30) 118882304 q12Shape12T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T97OK,q12Shape12T102OK⟩

private def q12Shape12T108 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67633152 37632737280 q12Shape12T108=true := by decide

private def q12Shape12T109 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34427371520 3272998912 q12Shape12T109=true := by decide

private def q12Shape12T107 : Tree 12 := .split 35 q12Shape12T108 q12Shape12T109
private theorem q12Shape12T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67633152 3272998912 q12Shape12T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67633152 (3272998912 ||| 2^35) q12Shape12T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67633152 ||| 2^35) 3272998912 q12Shape12T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T108OK,q12Shape12T109OK⟩

private def q12Shape12T110 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape12T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2215116800 1125515264 q12Shape12T110=true := by decide

private def q12Shape12T106 : Tree 12 := .split 31 q12Shape12T107 q12Shape12T110
private theorem q12Shape12T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67633152 1125515264 q12Shape12T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67633152 (1125515264 ||| 2^31) q12Shape12T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67633152 ||| 2^31) 1125515264 q12Shape12T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T107OK,q12Shape12T110OK⟩

private def q12Shape12T111 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape12T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1141374976 51773440 q12Shape12T111=true := by decide

private def q12Shape12T105 : Tree 12 := .split 30 q12Shape12T106 q12Shape12T111
private theorem q12Shape12T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67633152 51773440 q12Shape12T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67633152 (51773440 ||| 2^30) q12Shape12T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67633152 ||| 2^30) 51773440 q12Shape12T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T106OK,q12Shape12T111OK⟩

private def q12Shape12T95 : Tree 12 := .split 26 q12Shape12T96 q12Shape12T105
private theorem q12Shape12T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 51773440 q12Shape12T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 (51773440 ||| 2^26) q12Shape12T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (524288 ||| 2^26) 51773440 q12Shape12T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T96OK,q12Shape12T105OK⟩

private def q12Shape12T113 : Tree 12 := (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape12T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34078720 85327872 q12Shape12T113=true := by decide

private def q12Shape12T116 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape12T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101187584 3239444480 q12Shape12T116=true := by decide

private def q12Shape12T117 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape12T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2248671232 1091960832 q12Shape12T117=true := by decide

private def q12Shape12T115 : Tree 12 := .split 31 q12Shape12T116 q12Shape12T117
private theorem q12Shape12T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101187584 1091960832 q12Shape12T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101187584 (1091960832 ||| 2^31) q12Shape12T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (101187584 ||| 2^31) 1091960832 q12Shape12T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T116OK,q12Shape12T117OK⟩

private def q12Shape12T118 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape12T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1174929408 18219008 q12Shape12T118=true := by decide

private def q12Shape12T114 : Tree 12 := .split 30 q12Shape12T115 q12Shape12T118
private theorem q12Shape12T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101187584 18219008 q12Shape12T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101187584 (18219008 ||| 2^30) q12Shape12T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (101187584 ||| 2^30) 18219008 q12Shape12T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T115OK,q12Shape12T118OK⟩

private def q12Shape12T112 : Tree 12 := .split 26 q12Shape12T113 q12Shape12T114
private theorem q12Shape12T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34078720 18219008 q12Shape12T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34078720 (18219008 ||| 2^26) q12Shape12T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34078720 ||| 2^26) 18219008 q12Shape12T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T113OK,q12Shape12T114OK⟩

private def q12Shape12T94 : Tree 12 := .split 25 q12Shape12T95 q12Shape12T112
private theorem q12Shape12T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 18219008 q12Shape12T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 (18219008 ||| 2^25) q12Shape12T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (524288 ||| 2^25) 18219008 q12Shape12T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T95OK,q12Shape12T112OK⟩

private def q12Shape12T123 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape12T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 3323330560 q12Shape12T123=true := by decide

private def q12Shape12T124 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2164785152 1175846912 q12Shape12T124=true := by decide

private def q12Shape12T122 : Tree 12 := .split 31 q12Shape12T123 q12Shape12T124
private theorem q12Shape12T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 1175846912 q12Shape12T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 (1175846912 ||| 2^31) q12Shape12T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17301504 ||| 2^31) 1175846912 q12Shape12T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T123OK,q12Shape12T124OK⟩

private def q12Shape12T126 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape12T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1091043328 2249588736 q12Shape12T126=true := by decide

private def q12Shape12T127 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3238526976 102105088 q12Shape12T127=true := by decide

private def q12Shape12T125 : Tree 12 := .split 31 q12Shape12T126 q12Shape12T127
private theorem q12Shape12T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1091043328 102105088 q12Shape12T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1091043328 (102105088 ||| 2^31) q12Shape12T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1091043328 ||| 2^31) 102105088 q12Shape12T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T126OK,q12Shape12T127OK⟩

private def q12Shape12T121 : Tree 12 := .split 30 q12Shape12T122 q12Shape12T125
private theorem q12Shape12T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 102105088 q12Shape12T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 (102105088 ||| 2^30) q12Shape12T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17301504 ||| 2^30) 102105088 q12Shape12T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T122OK,q12Shape12T125OK⟩

private def q12Shape12T128 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84410368 34996224 q12Shape12T128=true := by decide

private def q12Shape12T120 : Tree 12 := .split 26 q12Shape12T121 q12Shape12T128
private theorem q12Shape12T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 34996224 q12Shape12T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 (34996224 ||| 2^26) q12Shape12T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17301504 ||| 2^26) 34996224 q12Shape12T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T121OK,q12Shape12T128OK⟩

private def q12Shape12T132 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape12T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50855936 3289776128 q12Shape12T132=true := by decide

private def q12Shape12T133 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2198339584 1142292480 q12Shape12T133=true := by decide

private def q12Shape12T131 : Tree 12 := .split 31 q12Shape12T132 q12Shape12T133
private theorem q12Shape12T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50855936 1142292480 q12Shape12T131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50855936 (1142292480 ||| 2^31) q12Shape12T132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50855936 ||| 2^31) 1142292480 q12Shape12T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T132OK,q12Shape12T133OK⟩

private def q12Shape12T134 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape12T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1124597760 68550656 q12Shape12T134=true := by decide

private def q12Shape12T130 : Tree 12 := .split 30 q12Shape12T131 q12Shape12T134
private theorem q12Shape12T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50855936 68550656 q12Shape12T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50855936 (68550656 ||| 2^30) q12Shape12T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50855936 ||| 2^30) 68550656 q12Shape12T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T131OK,q12Shape12T134OK⟩

private def q12Shape12T135 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 117964800 1441792 q12Shape12T135=true := by decide

private def q12Shape12T129 : Tree 12 := .split 26 q12Shape12T130 q12Shape12T135
private theorem q12Shape12T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50855936 1441792 q12Shape12T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50855936 (1441792 ||| 2^26) q12Shape12T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50855936 ||| 2^26) 1441792 q12Shape12T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T130OK,q12Shape12T135OK⟩

private def q12Shape12T119 : Tree 12 := .split 25 q12Shape12T120 q12Shape12T129
private theorem q12Shape12T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 1441792 q12Shape12T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17301504 (1441792 ||| 2^25) q12Shape12T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17301504 ||| 2^25) 1441792 q12Shape12T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T120OK,q12Shape12T129OK⟩

private def q12Shape12T93 : Tree 12 := .split 24 q12Shape12T94 q12Shape12T119
private theorem q12Shape12T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 1441792 q12Shape12T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 (1441792 ||| 2^24) q12Shape12T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (524288 ||| 2^24) 1441792 q12Shape12T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T94OK,q12Shape12T119OK⟩

def q12Shape12P3 : Tree 12 := q12Shape12T93
theorem q12Shape12P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 524288 1441792 q12Shape12P3=true := q12Shape12T93OK

end Graffiti384b.EffectiveSearch.Q12
