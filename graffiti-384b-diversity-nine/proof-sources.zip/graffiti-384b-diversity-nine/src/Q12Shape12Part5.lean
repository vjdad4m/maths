import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T168 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 3340369920 q12Shape12T168=true := by decide

private def q12Shape12T169 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2147745792 1192886272 q12Shape12T169=true := by decide

private def q12Shape12T167 : Tree 12 := .split 31 q12Shape12T168 q12Shape12T169
private theorem q12Shape12T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 1192886272 q12Shape12T167=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 (1192886272 ||| 2^31) q12Shape12T168 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (262144 ||| 2^31) 1192886272 q12Shape12T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T168OK,q12Shape12T169OK⟩

private def q12Shape12T171 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074003968 2266628096 q12Shape12T171=true := by decide

private def q12Shape12T172 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3221487616 119144448 q12Shape12T172=true := by decide

private def q12Shape12T170 : Tree 12 := .split 31 q12Shape12T171 q12Shape12T172
private theorem q12Shape12T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074003968 119144448 q12Shape12T170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074003968 (119144448 ||| 2^31) q12Shape12T171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1074003968 ||| 2^31) 119144448 q12Shape12T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T171OK,q12Shape12T172OK⟩

private def q12Shape12T166 : Tree 12 := .split 30 q12Shape12T167 q12Shape12T170
private theorem q12Shape12T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 119144448 q12Shape12T166=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 (119144448 ||| 2^30) q12Shape12T167 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (262144 ||| 2^30) 119144448 q12Shape12T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T167OK,q12Shape12T170OK⟩

private def q12Shape12T175 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67371008 3273261056 q12Shape12T175=true := by decide

private def q12Shape12T176 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2214854656 1125777408 q12Shape12T176=true := by decide

private def q12Shape12T174 : Tree 12 := .split 31 q12Shape12T175 q12Shape12T176
private theorem q12Shape12T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67371008 1125777408 q12Shape12T174=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67371008 (1125777408 ||| 2^31) q12Shape12T175 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67371008 ||| 2^31) 1125777408 q12Shape12T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T175OK,q12Shape12T176OK⟩

private def q12Shape12T177 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1141112832 52035584 q12Shape12T177=true := by decide

private def q12Shape12T173 : Tree 12 := .split 30 q12Shape12T174 q12Shape12T177
private theorem q12Shape12T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67371008 52035584 q12Shape12T173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67371008 (52035584 ||| 2^30) q12Shape12T174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67371008 ||| 2^30) 52035584 q12Shape12T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T174OK,q12Shape12T177OK⟩

private def q12Shape12T165 : Tree 12 := .split 26 q12Shape12T166 q12Shape12T173
private theorem q12Shape12T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 52035584 q12Shape12T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 (52035584 ||| 2^26) q12Shape12T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (262144 ||| 2^26) 52035584 q12Shape12T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T166OK,q12Shape12T173OK⟩

private def q12Shape12T181 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33816576 3306815488 q12Shape12T181=true := by decide

private def q12Shape12T182 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2181300224 1159331840 q12Shape12T182=true := by decide

private def q12Shape12T180 : Tree 12 := .split 31 q12Shape12T181 q12Shape12T182
private theorem q12Shape12T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33816576 1159331840 q12Shape12T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33816576 (1159331840 ||| 2^31) q12Shape12T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33816576 ||| 2^31) 1159331840 q12Shape12T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T181OK,q12Shape12T182OK⟩

private def q12Shape12T184 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107558400 2233073664 q12Shape12T184=true := by decide

private def q12Shape12T185 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3255042048 85590016 q12Shape12T185=true := by decide

private def q12Shape12T183 : Tree 12 := .split 31 q12Shape12T184 q12Shape12T185
private theorem q12Shape12T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107558400 85590016 q12Shape12T183=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107558400 (85590016 ||| 2^31) q12Shape12T184 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1107558400 ||| 2^31) 85590016 q12Shape12T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T184OK,q12Shape12T185OK⟩

private def q12Shape12T179 : Tree 12 := .split 30 q12Shape12T180 q12Shape12T183
private theorem q12Shape12T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33816576 85590016 q12Shape12T179=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33816576 (85590016 ||| 2^30) q12Shape12T180 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33816576 ||| 2^30) 85590016 q12Shape12T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T180OK,q12Shape12T183OK⟩

private def q12Shape12T186 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 100925440 18481152 q12Shape12T186=true := by decide

private def q12Shape12T178 : Tree 12 := .split 26 q12Shape12T179 q12Shape12T186
private theorem q12Shape12T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33816576 18481152 q12Shape12T178=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33816576 (18481152 ||| 2^26) q12Shape12T179 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33816576 ||| 2^26) 18481152 q12Shape12T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T179OK,q12Shape12T186OK⟩

private def q12Shape12T164 : Tree 12 := .split 25 q12Shape12T165 q12Shape12T178
private theorem q12Shape12T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 18481152 q12Shape12T164=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 (18481152 ||| 2^25) q12Shape12T165 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (262144 ||| 2^25) 18481152 q12Shape12T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T165OK,q12Shape12T178OK⟩

private def q12Shape12T189 : Tree 12 := (.split 30 (.split 31 (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape12T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17039360 102367232 q12Shape12T189=true := by decide

private def q12Shape12T192 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84148224 3256483840 q12Shape12T192=true := by decide

private def q12Shape12T193 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape12T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2231631872 1109000192 q12Shape12T193=true := by decide

private def q12Shape12T191 : Tree 12 := .split 31 q12Shape12T192 q12Shape12T193
private theorem q12Shape12T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84148224 1109000192 q12Shape12T191=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84148224 (1109000192 ||| 2^31) q12Shape12T192 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (84148224 ||| 2^31) 1109000192 q12Shape12T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T192OK,q12Shape12T193OK⟩

private def q12Shape12T194 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1157890048 35258368 q12Shape12T194=true := by decide

private def q12Shape12T190 : Tree 12 := .split 30 q12Shape12T191 q12Shape12T194
private theorem q12Shape12T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84148224 35258368 q12Shape12T190=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84148224 (35258368 ||| 2^30) q12Shape12T191 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (84148224 ||| 2^30) 35258368 q12Shape12T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T191OK,q12Shape12T194OK⟩

private def q12Shape12T188 : Tree 12 := .split 26 q12Shape12T189 q12Shape12T190
private theorem q12Shape12T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17039360 35258368 q12Shape12T188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17039360 (35258368 ||| 2^26) q12Shape12T189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17039360 ||| 2^26) 35258368 q12Shape12T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T189OK,q12Shape12T190OK⟩

private def q12Shape12T198 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50593792 3290038272 q12Shape12T198=true := by decide

private def q12Shape12T199 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2198077440 1142554624 q12Shape12T199=true := by decide

private def q12Shape12T197 : Tree 12 := .split 31 q12Shape12T198 q12Shape12T199
private theorem q12Shape12T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50593792 1142554624 q12Shape12T197=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50593792 (1142554624 ||| 2^31) q12Shape12T198 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50593792 ||| 2^31) 1142554624 q12Shape12T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T198OK,q12Shape12T199OK⟩

private def q12Shape12T200 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape12T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1124335616 68812800 q12Shape12T200=true := by decide

private def q12Shape12T196 : Tree 12 := .split 30 q12Shape12T197 q12Shape12T200
private theorem q12Shape12T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50593792 68812800 q12Shape12T196=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50593792 (68812800 ||| 2^30) q12Shape12T197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50593792 ||| 2^30) 68812800 q12Shape12T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T197OK,q12Shape12T200OK⟩

private def q12Shape12T201 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 117702656 1703936 q12Shape12T201=true := by decide

private def q12Shape12T195 : Tree 12 := .split 26 q12Shape12T196 q12Shape12T201
private theorem q12Shape12T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50593792 1703936 q12Shape12T195=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50593792 (1703936 ||| 2^26) q12Shape12T196 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (50593792 ||| 2^26) 1703936 q12Shape12T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T196OK,q12Shape12T201OK⟩

private def q12Shape12T187 : Tree 12 := .split 25 q12Shape12T188 q12Shape12T195
private theorem q12Shape12T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17039360 1703936 q12Shape12T187=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17039360 (1703936 ||| 2^25) q12Shape12T188 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17039360 ||| 2^25) 1703936 q12Shape12T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T188OK,q12Shape12T195OK⟩

private def q12Shape12T163 : Tree 12 := .split 24 q12Shape12T164 q12Shape12T187
private theorem q12Shape12T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 1703936 q12Shape12T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 (1703936 ||| 2^24) q12Shape12T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (262144 ||| 2^24) 1703936 q12Shape12T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T164OK,q12Shape12T187OK⟩

def q12Shape12P5 : Tree 12 := q12Shape12T163
theorem q12Shape12P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 262144 1703936 q12Shape12P5=true := q12Shape12T163OK

end Graffiti384b.EffectiveSearch.Q12
