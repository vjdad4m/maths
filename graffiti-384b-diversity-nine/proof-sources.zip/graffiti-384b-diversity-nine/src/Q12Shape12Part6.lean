import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T207 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 3339321344 q12Shape12T207=true := by decide

private def q12Shape12T208 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape12T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148794368 1191837696 q12Shape12T208=true := by decide

private def q12Shape12T206 : Tree 12 := .split 31 q12Shape12T207 q12Shape12T208
private theorem q12Shape12T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 1191837696 q12Shape12T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 (1191837696 ||| 2^31) q12Shape12T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1310720 ||| 2^31) 1191837696 q12Shape12T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T207OK,q12Shape12T208OK⟩

private def q12Shape12T211 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1075052544 36625317888 q12Shape12T211=true := by decide

private def q12Shape12T212 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,7,9,10,11})))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 35434790912 2265579520 q12Shape12T212=true := by decide

private def q12Shape12T210 : Tree 12 := .split 35 q12Shape12T211 q12Shape12T212
private theorem q12Shape12T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1075052544 2265579520 q12Shape12T210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1075052544 (2265579520 ||| 2^35) q12Shape12T211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1075052544 ||| 2^35) 2265579520 q12Shape12T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T211OK,q12Shape12T212OK⟩

private def q12Shape12T213 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3222536192 118095872 q12Shape12T213=true := by decide

private def q12Shape12T209 : Tree 12 := .split 31 q12Shape12T210 q12Shape12T213
private theorem q12Shape12T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1075052544 118095872 q12Shape12T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1075052544 (118095872 ||| 2^31) q12Shape12T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1075052544 ||| 2^31) 118095872 q12Shape12T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T210OK,q12Shape12T213OK⟩

private def q12Shape12T205 : Tree 12 := .split 30 q12Shape12T206 q12Shape12T209
private theorem q12Shape12T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 118095872 q12Shape12T205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 (118095872 ||| 2^30) q12Shape12T206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1310720 ||| 2^30) 118095872 q12Shape12T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T206OK,q12Shape12T209OK⟩

private def q12Shape12T216 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 68419584 3272212480 q12Shape12T216=true := by decide

private def q12Shape12T217 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape12T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2215903232 1124728832 q12Shape12T217=true := by decide

private def q12Shape12T215 : Tree 12 := .split 31 q12Shape12T216 q12Shape12T217
private theorem q12Shape12T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 68419584 1124728832 q12Shape12T215=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 68419584 (1124728832 ||| 2^31) q12Shape12T216 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (68419584 ||| 2^31) 1124728832 q12Shape12T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T216OK,q12Shape12T217OK⟩

private def q12Shape12T218 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1142161408 50987008 q12Shape12T218=true := by decide

private def q12Shape12T214 : Tree 12 := .split 30 q12Shape12T215 q12Shape12T218
private theorem q12Shape12T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 68419584 50987008 q12Shape12T214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 68419584 (50987008 ||| 2^30) q12Shape12T215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (68419584 ||| 2^30) 50987008 q12Shape12T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T215OK,q12Shape12T218OK⟩

private def q12Shape12T204 : Tree 12 := .split 26 q12Shape12T205 q12Shape12T214
private theorem q12Shape12T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 50987008 q12Shape12T204=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 (50987008 ||| 2^26) q12Shape12T205 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1310720 ||| 2^26) 50987008 q12Shape12T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T205OK,q12Shape12T214OK⟩

private def q12Shape12T219 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34865152 17432576 q12Shape12T219=true := by decide

private def q12Shape12T203 : Tree 12 := .split 25 q12Shape12T204 q12Shape12T219
private theorem q12Shape12T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 17432576 q12Shape12T203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 (17432576 ||| 2^25) q12Shape12T204 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1310720 ||| 2^25) 17432576 q12Shape12T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T204OK,q12Shape12T219OK⟩

private def q12Shape12T224 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape12T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 3322544128 q12Shape12T224=true := by decide

private def q12Shape12T225 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape12T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2165571584 1175060480 q12Shape12T225=true := by decide

private def q12Shape12T223 : Tree 12 := .split 31 q12Shape12T224 q12Shape12T225
private theorem q12Shape12T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 1175060480 q12Shape12T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 (1175060480 ||| 2^31) q12Shape12T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (18087936 ||| 2^31) 1175060480 q12Shape12T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T224OK,q12Shape12T225OK⟩

private def q12Shape12T226 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1091829760 101318656 q12Shape12T226=true := by decide

private def q12Shape12T222 : Tree 12 := .split 30 q12Shape12T223 q12Shape12T226
private theorem q12Shape12T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 101318656 q12Shape12T222=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 (101318656 ||| 2^30) q12Shape12T223 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (18087936 ||| 2^30) 101318656 q12Shape12T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T223OK,q12Shape12T226OK⟩

private def q12Shape12T228 : Tree 12 := (.split 31 (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,7,9,10,11})))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape12T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 85196800 1107951616 q12Shape12T228=true := by decide

private def q12Shape12T229 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1158938624 34209792 q12Shape12T229=true := by decide

private def q12Shape12T227 : Tree 12 := .split 30 q12Shape12T228 q12Shape12T229
private theorem q12Shape12T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 85196800 34209792 q12Shape12T227=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 85196800 (34209792 ||| 2^30) q12Shape12T228 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (85196800 ||| 2^30) 34209792 q12Shape12T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T228OK,q12Shape12T229OK⟩

private def q12Shape12T221 : Tree 12 := .split 26 q12Shape12T222 q12Shape12T227
private theorem q12Shape12T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 34209792 q12Shape12T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 (34209792 ||| 2^26) q12Shape12T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (18087936 ||| 2^26) 34209792 q12Shape12T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T222OK,q12Shape12T227OK⟩

private def q12Shape12T230 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 51642368 655360 q12Shape12T230=true := by decide

private def q12Shape12T220 : Tree 12 := .split 25 q12Shape12T221 q12Shape12T230
private theorem q12Shape12T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 655360 q12Shape12T220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 18087936 (655360 ||| 2^25) q12Shape12T221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (18087936 ||| 2^25) 655360 q12Shape12T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T221OK,q12Shape12T230OK⟩

private def q12Shape12T202 : Tree 12 := .split 24 q12Shape12T203 q12Shape12T220
private theorem q12Shape12T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 655360 q12Shape12T202=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 (655360 ||| 2^24) q12Shape12T203 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1310720 ||| 2^24) 655360 q12Shape12T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T203OK,q12Shape12T220OK⟩

def q12Shape12P6 : Tree 12 := q12Shape12T202
theorem q12Shape12P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1310720 655360 q12Shape12P6=true := q12Shape12T202OK

end Graffiti384b.EffectiveSearch.Q12
