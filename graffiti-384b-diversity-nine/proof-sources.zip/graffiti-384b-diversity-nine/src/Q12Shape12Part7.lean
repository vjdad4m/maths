import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T238 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))))
private theorem q12Shape12T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 3339845632 q12Shape12T238=true := by decide

private def q12Shape12T240 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148270080 35552100352 q12Shape12T240=true := by decide

private def q12Shape12T241 : Tree 12 := (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,8,9,10,11})))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape12T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 36508008448 1192361984 q12Shape12T241=true := by decide

private def q12Shape12T239 : Tree 12 := .split 35 q12Shape12T240 q12Shape12T241
private theorem q12Shape12T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148270080 1192361984 q12Shape12T239=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2148270080 (1192361984 ||| 2^35) q12Shape12T240 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (2148270080 ||| 2^35) 1192361984 q12Shape12T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T240OK,q12Shape12T241OK⟩

private def q12Shape12T237 : Tree 12 := .split 31 q12Shape12T238 q12Shape12T239
private theorem q12Shape12T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 1192361984 q12Shape12T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 (1192361984 ||| 2^31) q12Shape12T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (786432 ||| 2^31) 1192361984 q12Shape12T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T238OK,q12Shape12T239OK⟩

private def q12Shape12T242 : Tree 12 := (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape12T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1074528256 118620160 q12Shape12T242=true := by decide

private def q12Shape12T236 : Tree 12 := .split 30 q12Shape12T237 q12Shape12T242
private theorem q12Shape12T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 118620160 q12Shape12T236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 (118620160 ||| 2^30) q12Shape12T237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (786432 ||| 2^30) 118620160 q12Shape12T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T237OK,q12Shape12T242OK⟩

private def q12Shape12T243 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67895296 51511296 q12Shape12T243=true := by decide

private def q12Shape12T235 : Tree 12 := .split 26 q12Shape12T236 q12Shape12T243
private theorem q12Shape12T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 51511296 q12Shape12T235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 (51511296 ||| 2^26) q12Shape12T236 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (786432 ||| 2^26) 51511296 q12Shape12T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T236OK,q12Shape12T243OK⟩

private def q12Shape12T247 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34340864 3306291200 q12Shape12T247=true := by decide

private def q12Shape12T248 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2181824512 1158807552 q12Shape12T248=true := by decide

private def q12Shape12T246 : Tree 12 := .split 31 q12Shape12T247 q12Shape12T248
private theorem q12Shape12T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34340864 1158807552 q12Shape12T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34340864 (1158807552 ||| 2^31) q12Shape12T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34340864 ||| 2^31) 1158807552 q12Shape12T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T247OK,q12Shape12T248OK⟩

private def q12Shape12T249 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape12T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1108082688 85065728 q12Shape12T249=true := by decide

private def q12Shape12T245 : Tree 12 := .split 30 q12Shape12T246 q12Shape12T249
private theorem q12Shape12T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34340864 85065728 q12Shape12T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34340864 (85065728 ||| 2^30) q12Shape12T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34340864 ||| 2^30) 85065728 q12Shape12T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T246OK,q12Shape12T249OK⟩

private def q12Shape12T250 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 101449728 17956864 q12Shape12T250=true := by decide

private def q12Shape12T244 : Tree 12 := .split 26 q12Shape12T245 q12Shape12T250
private theorem q12Shape12T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34340864 17956864 q12Shape12T244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 34340864 (17956864 ||| 2^26) q12Shape12T245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (34340864 ||| 2^26) 17956864 q12Shape12T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T245OK,q12Shape12T250OK⟩

private def q12Shape12T234 : Tree 12 := .split 25 q12Shape12T235 q12Shape12T244
private theorem q12Shape12T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 17956864 q12Shape12T234=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 (17956864 ||| 2^25) q12Shape12T235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (786432 ||| 2^25) 17956864 q12Shape12T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T235OK,q12Shape12T244OK⟩

private def q12Shape12T255 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11}))))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape12T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 3323068416 q12Shape12T255=true := by decide

private def q12Shape12T256 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2165047296 1175584768 q12Shape12T256=true := by decide

private def q12Shape12T254 : Tree 12 := .split 31 q12Shape12T255 q12Shape12T256
private theorem q12Shape12T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 1175584768 q12Shape12T254=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 (1175584768 ||| 2^31) q12Shape12T255 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17563648 ||| 2^31) 1175584768 q12Shape12T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T255OK,q12Shape12T256OK⟩

private def q12Shape12T257 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape12T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1091305472 101842944 q12Shape12T257=true := by decide

private def q12Shape12T253 : Tree 12 := .split 30 q12Shape12T254 q12Shape12T257
private theorem q12Shape12T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 101842944 q12Shape12T253=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 (101842944 ||| 2^30) q12Shape12T254 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17563648 ||| 2^30) 101842944 q12Shape12T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T254OK,q12Shape12T257OK⟩

private def q12Shape12T258 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84672512 34734080 q12Shape12T258=true := by decide

private def q12Shape12T252 : Tree 12 := .split 26 q12Shape12T253 q12Shape12T258
private theorem q12Shape12T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 34734080 q12Shape12T252=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 (34734080 ||| 2^26) q12Shape12T253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17563648 ||| 2^26) 34734080 q12Shape12T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T253OK,q12Shape12T258OK⟩

private def q12Shape12T261 : Tree 12 := (.split 31 (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,8,9,10,11})))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape12T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 51118080 1142030336 q12Shape12T261=true := by decide

private def q12Shape12T262 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape12T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1124859904 68288512 q12Shape12T262=true := by decide

private def q12Shape12T260 : Tree 12 := .split 30 q12Shape12T261 q12Shape12T262
private theorem q12Shape12T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 51118080 68288512 q12Shape12T260=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 51118080 (68288512 ||| 2^30) q12Shape12T261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (51118080 ||| 2^30) 68288512 q12Shape12T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T261OK,q12Shape12T262OK⟩

private def q12Shape12T263 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 118226944 1179648 q12Shape12T263=true := by decide

private def q12Shape12T259 : Tree 12 := .split 26 q12Shape12T260 q12Shape12T263
private theorem q12Shape12T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 51118080 1179648 q12Shape12T259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 51118080 (1179648 ||| 2^26) q12Shape12T260 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (51118080 ||| 2^26) 1179648 q12Shape12T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T260OK,q12Shape12T263OK⟩

private def q12Shape12T251 : Tree 12 := .split 25 q12Shape12T252 q12Shape12T259
private theorem q12Shape12T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 1179648 q12Shape12T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 17563648 (1179648 ||| 2^25) q12Shape12T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (17563648 ||| 2^25) 1179648 q12Shape12T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T252OK,q12Shape12T259OK⟩

private def q12Shape12T233 : Tree 12 := .split 24 q12Shape12T234 q12Shape12T251
private theorem q12Shape12T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 1179648 q12Shape12T233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 (1179648 ||| 2^24) q12Shape12T234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (786432 ||| 2^24) 1179648 q12Shape12T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T234OK,q12Shape12T251OK⟩

private def q12Shape12T264 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape12T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1835008 131072 q12Shape12T264=true := by decide

private def q12Shape12T232 : Tree 12 := .split 20 q12Shape12T233 q12Shape12T264
private theorem q12Shape12T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 131072 q12Shape12T232=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 (131072 ||| 2^20) q12Shape12T233 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (786432 ||| 2^20) 131072 q12Shape12T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T233OK,q12Shape12T264OK⟩

def q12Shape12P7 : Tree 12 := q12Shape12T232
theorem q12Shape12P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 786432 131072 q12Shape12P7=true := q12Shape12T232OK

end Graffiti384b.EffectiveSearch.Q12
