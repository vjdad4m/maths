import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape12T272 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))))
private theorem q12Shape12T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 3340500992 q12Shape12T272=true := by decide

private def q12Shape12T273 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2147614720 1193017344 q12Shape12T273=true := by decide

private def q12Shape12T271 : Tree 12 := .split 31 q12Shape12T272 q12Shape12T273
private theorem q12Shape12T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 1193017344 q12Shape12T271=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (1193017344 ||| 2^31) q12Shape12T272 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^31) 1193017344 q12Shape12T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T272OK,q12Shape12T273OK⟩

private def q12Shape12T275 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8,11}))))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1073872896 2266759168 q12Shape12T275=true := by decide

private def q12Shape12T276 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3221356544 119275520 q12Shape12T276=true := by decide

private def q12Shape12T274 : Tree 12 := .split 31 q12Shape12T275 q12Shape12T276
private theorem q12Shape12T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1073872896 119275520 q12Shape12T274=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1073872896 (119275520 ||| 2^31) q12Shape12T275 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1073872896 ||| 2^31) 119275520 q12Shape12T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T275OK,q12Shape12T276OK⟩

private def q12Shape12T270 : Tree 12 := .split 30 q12Shape12T271 q12Shape12T274
private theorem q12Shape12T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 119275520 q12Shape12T270=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (119275520 ||| 2^30) q12Shape12T271 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^30) 119275520 q12Shape12T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T271OK,q12Shape12T274OK⟩

private def q12Shape12T279 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))))
private theorem q12Shape12T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67239936 3273392128 q12Shape12T279=true := by decide

private def q12Shape12T280 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2214723584 1125908480 q12Shape12T280=true := by decide

private def q12Shape12T278 : Tree 12 := .split 31 q12Shape12T279 q12Shape12T280
private theorem q12Shape12T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67239936 1125908480 q12Shape12T278=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67239936 (1125908480 ||| 2^31) q12Shape12T279 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67239936 ||| 2^31) 1125908480 q12Shape12T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T279OK,q12Shape12T280OK⟩

private def q12Shape12T281 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1140981760 52166656 q12Shape12T281=true := by decide

private def q12Shape12T277 : Tree 12 := .split 30 q12Shape12T278 q12Shape12T281
private theorem q12Shape12T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67239936 52166656 q12Shape12T277=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 67239936 (52166656 ||| 2^30) q12Shape12T278 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (67239936 ||| 2^30) 52166656 q12Shape12T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T278OK,q12Shape12T281OK⟩

private def q12Shape12T269 : Tree 12 := .split 26 q12Shape12T270 q12Shape12T277
private theorem q12Shape12T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 52166656 q12Shape12T269=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (52166656 ||| 2^26) q12Shape12T270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^26) 52166656 q12Shape12T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T270OK,q12Shape12T277OK⟩

private def q12Shape12T285 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))))
private theorem q12Shape12T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33685504 3306946560 q12Shape12T285=true := by decide

private def q12Shape12T286 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2181169152 1159462912 q12Shape12T286=true := by decide

private def q12Shape12T284 : Tree 12 := .split 31 q12Shape12T285 q12Shape12T286
private theorem q12Shape12T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33685504 1159462912 q12Shape12T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33685504 (1159462912 ||| 2^31) q12Shape12T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33685504 ||| 2^31) 1159462912 q12Shape12T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T285OK,q12Shape12T286OK⟩

private def q12Shape12T288 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8,11}))))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107427328 2233204736 q12Shape12T288=true := by decide

private def q12Shape12T289 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3254910976 85721088 q12Shape12T289=true := by decide

private def q12Shape12T287 : Tree 12 := .split 31 q12Shape12T288 q12Shape12T289
private theorem q12Shape12T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107427328 85721088 q12Shape12T287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1107427328 (85721088 ||| 2^31) q12Shape12T288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1107427328 ||| 2^31) 85721088 q12Shape12T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T288OK,q12Shape12T289OK⟩

private def q12Shape12T283 : Tree 12 := .split 30 q12Shape12T284 q12Shape12T287
private theorem q12Shape12T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33685504 85721088 q12Shape12T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33685504 (85721088 ||| 2^30) q12Shape12T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33685504 ||| 2^30) 85721088 q12Shape12T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T284OK,q12Shape12T287OK⟩

private def q12Shape12T290 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape12T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 100794368 18612224 q12Shape12T290=true := by decide

private def q12Shape12T282 : Tree 12 := .split 26 q12Shape12T283 q12Shape12T290
private theorem q12Shape12T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33685504 18612224 q12Shape12T282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 33685504 (18612224 ||| 2^26) q12Shape12T283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (33685504 ||| 2^26) 18612224 q12Shape12T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T283OK,q12Shape12T290OK⟩

private def q12Shape12T268 : Tree 12 := .split 25 q12Shape12T269 q12Shape12T282
private theorem q12Shape12T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 18612224 q12Shape12T268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (18612224 ||| 2^25) q12Shape12T269 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^25) 18612224 q12Shape12T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T269OK,q12Shape12T282OK⟩

private def q12Shape12T295 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape12T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 3323723776 q12Shape12T295=true := by decide

private def q12Shape12T296 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape12T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 2164391936 1176240128 q12Shape12T296=true := by decide

private def q12Shape12T294 : Tree 12 := .split 31 q12Shape12T295 q12Shape12T296
private theorem q12Shape12T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 1176240128 q12Shape12T294=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 (1176240128 ||| 2^31) q12Shape12T295 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16908288 ||| 2^31) 1176240128 q12Shape12T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T295OK,q12Shape12T296OK⟩

private def q12Shape12T298 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8,11}))))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape12T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1090650112 2249981952 q12Shape12T298=true := by decide

private def q12Shape12T299 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape12T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 3238133760 102498304 q12Shape12T299=true := by decide

private def q12Shape12T297 : Tree 12 := .split 31 q12Shape12T298 q12Shape12T299
private theorem q12Shape12T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1090650112 102498304 q12Shape12T297=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 1090650112 (102498304 ||| 2^31) q12Shape12T298 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (1090650112 ||| 2^31) 102498304 q12Shape12T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T298OK,q12Shape12T299OK⟩

private def q12Shape12T293 : Tree 12 := .split 30 q12Shape12T294 q12Shape12T297
private theorem q12Shape12T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 102498304 q12Shape12T293=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 (102498304 ||| 2^30) q12Shape12T294 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16908288 ||| 2^30) 102498304 q12Shape12T297)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T294OK,q12Shape12T297OK⟩

private def q12Shape12T300 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape12T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 84017152 35389440 q12Shape12T300=true := by decide

private def q12Shape12T292 : Tree 12 := .split 26 q12Shape12T293 q12Shape12T300
private theorem q12Shape12T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 35389440 q12Shape12T292=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 (35389440 ||| 2^26) q12Shape12T293 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16908288 ||| 2^26) 35389440 q12Shape12T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T293OK,q12Shape12T300OK⟩

private def q12Shape12T301 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape12T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 50462720 1835008 q12Shape12T301=true := by decide

private def q12Shape12T291 : Tree 12 := .split 25 q12Shape12T292 q12Shape12T301
private theorem q12Shape12T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 1835008 q12Shape12T291=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 16908288 (1835008 ||| 2^25) q12Shape12T292 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (16908288 ||| 2^25) 1835008 q12Shape12T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T292OK,q12Shape12T301OK⟩

private def q12Shape12T267 : Tree 12 := .split 24 q12Shape12T268 q12Shape12T291
private theorem q12Shape12T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 1835008 q12Shape12T267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 (1835008 ||| 2^24) q12Shape12T268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) (131072 ||| 2^24) 1835008 q12Shape12T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape12T268OK,q12Shape12T291OK⟩

def q12Shape12P8 : Tree 12 := q12Shape12T267
theorem q12Shape12P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,2⟩) 131072 1835008 q12Shape12P8=true := q12Shape12T267OK

end Graffiti384b.EffectiveSearch.Q12
