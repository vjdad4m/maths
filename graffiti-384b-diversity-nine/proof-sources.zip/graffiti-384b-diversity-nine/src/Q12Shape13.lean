import Q12Shape13Part0
import Q12Shape13Part1
import Q12Shape13Part2
import Q12Shape13Part3
import Q12Shape13Part4
import Q12Shape13Part5

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape13M42 : Tree 12 := .split 31 q12Shape13P0 q12Shape13P1
private theorem q12Shape13M42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 1191182336 q12Shape13M42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 (1191182336 ||| 2^31) q12Shape13P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (0 ||| 2^31) 1191182336 q12Shape13P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13P0OK,q12Shape13P1OK⟩
private def q12Shape13M66 : Tree 12 := .split 30 q12Shape13M42 q12Shape13P2
private theorem q12Shape13M66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 117440512 q12Shape13M66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 (117440512 ||| 2^30) q12Shape13M42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (0 ||| 2^30) 117440512 q12Shape13P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13M42OK,q12Shape13P2OK⟩
private def q12Shape13M92 : Tree 12 := .split 26 q12Shape13M66 q12Shape13P3
private theorem q12Shape13M92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 50331648 q12Shape13M92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 (50331648 ||| 2^26) q12Shape13M66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (0 ||| 2^26) 50331648 q12Shape13P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13M66OK,q12Shape13P3OK⟩
private def q12Shape13M120 : Tree 12 := .split 25 q12Shape13M92 q12Shape13P4
private theorem q12Shape13M120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 16777216 q12Shape13M120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 (16777216 ||| 2^25) q12Shape13M92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (0 ||| 2^25) 16777216 q12Shape13P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13M92OK,q12Shape13P4OK⟩
private def q12Shape13M150 : Tree 12 := .split 24 q12Shape13M120 q12Shape13P5
private theorem q12Shape13M150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 0 q12Shape13M150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 (0 ||| 2^24) q12Shape13M120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (0 ||| 2^24) 0 q12Shape13P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13M120OK,q12Shape13P5OK⟩

theorem q12Shape13_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 13) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 13) b) (adj 12 (forms 13) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) adj_mono b H q12Shape13M150 q12Shape13M150OK

#print axioms q12Shape13_cover

end Graffiti384b.EffectiveSearch.Q12
