import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape13T1 : Tree 12 := (.tip (.cover {0,2,3,4,9,10,11}))
private theorem q12Shape13T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 37698404352 q12Shape13T1=true := by decide

private def q12Shape13T5 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11})))))
private theorem q12Shape13T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738368 4401385177091 q12Shape13T5=true := by decide

private def q12Shape13T7 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738370 4401385177601 q12Shape13T7=true := by decide

private def q12Shape13T8 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738882 4401385177089 q12Shape13T8=true := by decide

private def q12Shape13T6 : Tree 12 := .split 9 q12Shape13T7 q12Shape13T8
private theorem q12Shape13T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738370 4401385177089 q12Shape13T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738370 (4401385177089 ||| 2^9) q12Shape13T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738370 ||| 2^9) 4401385177089 q12Shape13T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T7OK,q12Shape13T8OK⟩

private def q12Shape13T4 : Tree 12 := .split 1 q12Shape13T5 q12Shape13T6
private theorem q12Shape13T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738368 4401385177089 q12Shape13T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738368 (4401385177089 ||| 2^1) q12Shape13T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738368 ||| 2^1) 4401385177089 q12Shape13T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T5OK,q12Shape13T6OK⟩

private def q12Shape13T11 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738369 4401385177602 q12Shape13T11=true := by decide

private def q12Shape13T12 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738881 4401385177090 q12Shape13T12=true := by decide

private def q12Shape13T10 : Tree 12 := .split 9 q12Shape13T11 q12Shape13T12
private theorem q12Shape13T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738369 4401385177090 q12Shape13T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738369 (4401385177090 ||| 2^9) q12Shape13T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738369 ||| 2^9) 4401385177090 q12Shape13T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T11OK,q12Shape13T12OK⟩

private def q12Shape13T14 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738371 4401385177600 q12Shape13T14=true := by decide

private def q12Shape13T17 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))
private theorem q12Shape13T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738883 4401385177280 q12Shape13T17=true := by decide

private def q12Shape13T18 : Tree 12 := (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,1,3,5,6,7,11}))))
private theorem q12Shape13T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359739011 4401385177152 q12Shape13T18=true := by decide

private def q12Shape13T16 : Tree 12 := .split 7 q12Shape13T17 q12Shape13T18
private theorem q12Shape13T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738883 4401385177152 q12Shape13T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738883 (4401385177152 ||| 2^7) q12Shape13T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738883 ||| 2^7) 4401385177152 q12Shape13T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T17OK,q12Shape13T18OK⟩

private def q12Shape13T19 : Tree 12 := (.split 7 (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11})))
private theorem q12Shape13T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738947 4401385177088 q12Shape13T19=true := by decide

private def q12Shape13T15 : Tree 12 := .split 6 q12Shape13T16 q12Shape13T19
private theorem q12Shape13T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738883 4401385177088 q12Shape13T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738883 (4401385177088 ||| 2^6) q12Shape13T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738883 ||| 2^6) 4401385177088 q12Shape13T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T16OK,q12Shape13T19OK⟩

private def q12Shape13T13 : Tree 12 := .split 9 q12Shape13T14 q12Shape13T15
private theorem q12Shape13T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738371 4401385177088 q12Shape13T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738371 (4401385177088 ||| 2^9) q12Shape13T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738371 ||| 2^9) 4401385177088 q12Shape13T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T14OK,q12Shape13T15OK⟩

private def q12Shape13T9 : Tree 12 := .split 1 q12Shape13T10 q12Shape13T13
private theorem q12Shape13T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738369 4401385177088 q12Shape13T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738369 (4401385177088 ||| 2^1) q12Shape13T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738369 ||| 2^1) 4401385177088 q12Shape13T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T10OK,q12Shape13T13OK⟩

private def q12Shape13T3 : Tree 12 := .split 0 q12Shape13T4 q12Shape13T9
private theorem q12Shape13T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738368 4401385177088 q12Shape13T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738368 (4401385177088 ||| 2^0) q12Shape13T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738368 ||| 2^0) 4401385177088 q12Shape13T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T4OK,q12Shape13T9OK⟩

private def q12Shape13T20 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape13T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 4432406249472 3338665984 q12Shape13T20=true := by decide

private def q12Shape13T2 : Tree 12 := .split 42 q12Shape13T3 q12Shape13T20
private theorem q12Shape13T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738368 3338665984 q12Shape13T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34359738368 (3338665984 ||| 2^42) q12Shape13T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (34359738368 ||| 2^42) 3338665984 q12Shape13T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T3OK,q12Shape13T20OK⟩

private def q12Shape13T0 : Tree 12 := .split 35 q12Shape13T1 q12Shape13T2
private theorem q12Shape13T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 3338665984 q12Shape13T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 (3338665984 ||| 2^35) q12Shape13T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (0 ||| 2^35) 3338665984 q12Shape13T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T1OK,q12Shape13T2OK⟩

def q12Shape13P0 : Tree 12 := q12Shape13T0
theorem q12Shape13P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 0 3338665984 q12Shape13P0=true := q12Shape13T0OK

end Graffiti384b.EffectiveSearch.Q12
