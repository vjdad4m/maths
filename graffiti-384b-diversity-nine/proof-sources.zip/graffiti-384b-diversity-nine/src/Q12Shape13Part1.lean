import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape13T25 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11})))))
private theorem q12Shape13T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 4433597431811 q12Shape13T25=true := by decide

private def q12Shape13T27 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483650 4433597432321 q12Shape13T27=true := by decide

private def q12Shape13T28 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484162 4433597431809 q12Shape13T28=true := by decide

private def q12Shape13T26 : Tree 12 := .split 9 q12Shape13T27 q12Shape13T28
private theorem q12Shape13T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483650 4433597431809 q12Shape13T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483650 (4433597431809 ||| 2^9) q12Shape13T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483650 ||| 2^9) 4433597431809 q12Shape13T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T27OK,q12Shape13T28OK⟩

private def q12Shape13T24 : Tree 12 := .split 1 q12Shape13T25 q12Shape13T26
private theorem q12Shape13T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 4433597431809 q12Shape13T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 (4433597431809 ||| 2^1) q12Shape13T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483648 ||| 2^1) 4433597431809 q12Shape13T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T25OK,q12Shape13T26OK⟩

private def q12Shape13T31 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483649 4433597432322 q12Shape13T31=true := by decide

private def q12Shape13T32 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484161 4433597431810 q12Shape13T32=true := by decide

private def q12Shape13T30 : Tree 12 := .split 9 q12Shape13T31 q12Shape13T32
private theorem q12Shape13T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483649 4433597431810 q12Shape13T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483649 (4433597431810 ||| 2^9) q12Shape13T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483649 ||| 2^9) 4433597431810 q12Shape13T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T31OK,q12Shape13T32OK⟩

private def q12Shape13T34 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483651 4433597432320 q12Shape13T34=true := by decide

private def q12Shape13T37 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))
private theorem q12Shape13T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484163 4433597432000 q12Shape13T37=true := by decide

private def q12Shape13T38 : Tree 12 := (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,1,3,5,6,7,11}))))
private theorem q12Shape13T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484291 4433597431872 q12Shape13T38=true := by decide

private def q12Shape13T36 : Tree 12 := .split 7 q12Shape13T37 q12Shape13T38
private theorem q12Shape13T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484163 4433597431872 q12Shape13T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484163 (4433597431872 ||| 2^7) q12Shape13T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147484163 ||| 2^7) 4433597431872 q12Shape13T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T37OK,q12Shape13T38OK⟩

private def q12Shape13T39 : Tree 12 := (.split 7 (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11})))
private theorem q12Shape13T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484227 4433597431808 q12Shape13T39=true := by decide

private def q12Shape13T35 : Tree 12 := .split 6 q12Shape13T36 q12Shape13T39
private theorem q12Shape13T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484163 4433597431808 q12Shape13T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147484163 (4433597431808 ||| 2^6) q12Shape13T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147484163 ||| 2^6) 4433597431808 q12Shape13T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T36OK,q12Shape13T39OK⟩

private def q12Shape13T33 : Tree 12 := .split 9 q12Shape13T34 q12Shape13T35
private theorem q12Shape13T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483651 4433597431808 q12Shape13T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483651 (4433597431808 ||| 2^9) q12Shape13T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483651 ||| 2^9) 4433597431808 q12Shape13T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T34OK,q12Shape13T35OK⟩

private def q12Shape13T29 : Tree 12 := .split 1 q12Shape13T30 q12Shape13T33
private theorem q12Shape13T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483649 4433597431808 q12Shape13T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483649 (4433597431808 ||| 2^1) q12Shape13T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483649 ||| 2^1) 4433597431808 q12Shape13T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T30OK,q12Shape13T33OK⟩

private def q12Shape13T23 : Tree 12 := .split 0 q12Shape13T24 q12Shape13T29
private theorem q12Shape13T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 4433597431808 q12Shape13T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 (4433597431808 ||| 2^0) q12Shape13T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483648 ||| 2^0) 4433597431808 q12Shape13T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T24OK,q12Shape13T29OK⟩

private def q12Shape13T40 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape13T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 4400193994752 35550920704 q12Shape13T40=true := by decide

private def q12Shape13T22 : Tree 12 := .split 42 q12Shape13T23 q12Shape13T40
private theorem q12Shape13T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 35550920704 q12Shape13T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 (35550920704 ||| 2^42) q12Shape13T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483648 ||| 2^42) 35550920704 q12Shape13T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T23OK,q12Shape13T40OK⟩

private def q12Shape13T41 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape13T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 36507222016 1191182336 q12Shape13T41=true := by decide

private def q12Shape13T21 : Tree 12 := .split 35 q12Shape13T22 q12Shape13T41
private theorem q12Shape13T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 1191182336 q12Shape13T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 (1191182336 ||| 2^35) q12Shape13T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (2147483648 ||| 2^35) 1191182336 q12Shape13T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T22OK,q12Shape13T41OK⟩

def q12Shape13P1 : Tree 12 := q12Shape13T21
theorem q12Shape13P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2147483648 1191182336 q12Shape13P1=true := q12Shape13T21OK

end Graffiti384b.EffectiveSearch.Q12
