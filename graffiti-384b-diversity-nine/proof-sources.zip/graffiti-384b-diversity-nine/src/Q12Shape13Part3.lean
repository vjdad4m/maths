import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape13T73 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11})))))
private theorem q12Shape13T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 4435677806595 q12Shape13T73=true := by decide

private def q12Shape13T75 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108866 4435677807105 q12Shape13T75=true := by decide

private def q12Shape13T76 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109378 4435677806593 q12Shape13T76=true := by decide

private def q12Shape13T74 : Tree 12 := .split 9 q12Shape13T75 q12Shape13T76
private theorem q12Shape13T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108866 4435677806593 q12Shape13T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108866 (4435677806593 ||| 2^9) q12Shape13T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108866 ||| 2^9) 4435677806593 q12Shape13T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T75OK,q12Shape13T76OK⟩

private def q12Shape13T72 : Tree 12 := .split 1 q12Shape13T73 q12Shape13T74
private theorem q12Shape13T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 4435677806593 q12Shape13T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 (4435677806593 ||| 2^1) q12Shape13T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108864 ||| 2^1) 4435677806593 q12Shape13T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T73OK,q12Shape13T74OK⟩

private def q12Shape13T79 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108865 4435677807106 q12Shape13T79=true := by decide

private def q12Shape13T80 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109377 4435677806594 q12Shape13T80=true := by decide

private def q12Shape13T78 : Tree 12 := .split 9 q12Shape13T79 q12Shape13T80
private theorem q12Shape13T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108865 4435677806594 q12Shape13T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108865 (4435677806594 ||| 2^9) q12Shape13T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108865 ||| 2^9) 4435677806594 q12Shape13T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T79OK,q12Shape13T80OK⟩

private def q12Shape13T82 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11}))))
private theorem q12Shape13T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108867 4435677807104 q12Shape13T82=true := by decide

private def q12Shape13T85 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7,11}))))
private theorem q12Shape13T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109379 4435677806784 q12Shape13T85=true := by decide

private def q12Shape13T86 : Tree 12 := (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,1,3,5,6,7,11}))))
private theorem q12Shape13T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109507 4435677806656 q12Shape13T86=true := by decide

private def q12Shape13T84 : Tree 12 := .split 7 q12Shape13T85 q12Shape13T86
private theorem q12Shape13T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109379 4435677806656 q12Shape13T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109379 (4435677806656 ||| 2^7) q12Shape13T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67109379 ||| 2^7) 4435677806656 q12Shape13T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T85OK,q12Shape13T86OK⟩

private def q12Shape13T87 : Tree 12 := (.split 7 (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,1,3,5,6,7,11})))) (.tip (.cover {0,1,2,5,6,7,11})))
private theorem q12Shape13T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109443 4435677806592 q12Shape13T87=true := by decide

private def q12Shape13T83 : Tree 12 := .split 6 q12Shape13T84 q12Shape13T87
private theorem q12Shape13T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109379 4435677806592 q12Shape13T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67109379 (4435677806592 ||| 2^6) q12Shape13T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67109379 ||| 2^6) 4435677806592 q12Shape13T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T84OK,q12Shape13T87OK⟩

private def q12Shape13T81 : Tree 12 := .split 9 q12Shape13T82 q12Shape13T83
private theorem q12Shape13T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108867 4435677806592 q12Shape13T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108867 (4435677806592 ||| 2^9) q12Shape13T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108867 ||| 2^9) 4435677806592 q12Shape13T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T82OK,q12Shape13T83OK⟩

private def q12Shape13T77 : Tree 12 := .split 1 q12Shape13T78 q12Shape13T81
private theorem q12Shape13T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108865 4435677806592 q12Shape13T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108865 (4435677806592 ||| 2^1) q12Shape13T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108865 ||| 2^1) 4435677806592 q12Shape13T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T78OK,q12Shape13T81OK⟩

private def q12Shape13T71 : Tree 12 := .split 0 q12Shape13T72 q12Shape13T77
private theorem q12Shape13T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 4435677806592 q12Shape13T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 (4435677806592 ||| 2^0) q12Shape13T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108864 ||| 2^0) 4435677806592 q12Shape13T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T72OK,q12Shape13T77OK⟩

private def q12Shape13T88 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape13T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 4398113619968 37631295488 q12Shape13T88=true := by decide

private def q12Shape13T70 : Tree 12 := .split 42 q12Shape13T71 q12Shape13T88
private theorem q12Shape13T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 37631295488 q12Shape13T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 (37631295488 ||| 2^42) q12Shape13T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108864 ||| 2^42) 37631295488 q12Shape13T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T71OK,q12Shape13T88OK⟩

private def q12Shape13T89 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape13T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34426847232 3271557120 q12Shape13T89=true := by decide

private def q12Shape13T69 : Tree 12 := .split 35 q12Shape13T70 q12Shape13T89
private theorem q12Shape13T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 3271557120 q12Shape13T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 (3271557120 ||| 2^35) q12Shape13T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108864 ||| 2^35) 3271557120 q12Shape13T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T70OK,q12Shape13T89OK⟩

private def q12Shape13T90 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape13T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2214592512 1124073472 q12Shape13T90=true := by decide

private def q12Shape13T68 : Tree 12 := .split 31 q12Shape13T69 q12Shape13T90
private theorem q12Shape13T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 1124073472 q12Shape13T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 (1124073472 ||| 2^31) q12Shape13T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108864 ||| 2^31) 1124073472 q12Shape13T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T69OK,q12Shape13T90OK⟩

private def q12Shape13T91 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape13T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 1140850688 50331648 q12Shape13T91=true := by decide

private def q12Shape13T67 : Tree 12 := .split 30 q12Shape13T68 q12Shape13T91
private theorem q12Shape13T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 50331648 q12Shape13T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 (50331648 ||| 2^30) q12Shape13T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (67108864 ||| 2^30) 50331648 q12Shape13T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T68OK,q12Shape13T91OK⟩

def q12Shape13P3 : Tree 12 := q12Shape13T67
theorem q12Shape13P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 67108864 50331648 q12Shape13P3=true := q12Shape13T67OK

end Graffiti384b.EffectiveSearch.Q12
