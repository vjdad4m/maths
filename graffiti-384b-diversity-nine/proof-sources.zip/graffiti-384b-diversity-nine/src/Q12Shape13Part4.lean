import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape13T100 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,8,11})))))
private theorem q12Shape13T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 4435711361027 q12Shape13T100=true := by decide

private def q12Shape13T102 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,8,11}))))
private theorem q12Shape13T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554434 4435711361537 q12Shape13T102=true := by decide

private def q12Shape13T103 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.tip (.cover {0,1,2,5,6,8,11}))))
private theorem q12Shape13T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554946 4435711361025 q12Shape13T103=true := by decide

private def q12Shape13T101 : Tree 12 := .split 9 q12Shape13T102 q12Shape13T103
private theorem q12Shape13T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554434 4435711361025 q12Shape13T101=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554434 (4435711361025 ||| 2^9) q12Shape13T102 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554434 ||| 2^9) 4435711361025 q12Shape13T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T102OK,q12Shape13T103OK⟩

private def q12Shape13T99 : Tree 12 := .split 1 q12Shape13T100 q12Shape13T101
private theorem q12Shape13T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 4435711361025 q12Shape13T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 (4435711361025 ||| 2^1) q12Shape13T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554432 ||| 2^1) 4435711361025 q12Shape13T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T100OK,q12Shape13T101OK⟩

private def q12Shape13T106 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,8,11}))))
private theorem q12Shape13T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554433 4435711361538 q12Shape13T106=true := by decide

private def q12Shape13T107 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.tip (.cover {0,1,2,5,6,8,11}))))
private theorem q12Shape13T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554945 4435711361026 q12Shape13T107=true := by decide

private def q12Shape13T105 : Tree 12 := .split 9 q12Shape13T106 q12Shape13T107
private theorem q12Shape13T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554433 4435711361026 q12Shape13T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554433 (4435711361026 ||| 2^9) q12Shape13T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554433 ||| 2^9) 4435711361026 q12Shape13T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T106OK,q12Shape13T107OK⟩

private def q12Shape13T109 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.tip (.cover {0,1,2,5,6,8,11}))))
private theorem q12Shape13T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554435 4435711361536 q12Shape13T109=true := by decide

private def q12Shape13T112 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11}))))
private theorem q12Shape13T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554947 4435711361216 q12Shape13T112=true := by decide

private def q12Shape13T113 : Tree 12 := (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,1,3,5,6,8,11}))))
private theorem q12Shape13T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33555075 4435711361088 q12Shape13T113=true := by decide

private def q12Shape13T111 : Tree 12 := .split 7 q12Shape13T112 q12Shape13T113
private theorem q12Shape13T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554947 4435711361088 q12Shape13T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554947 (4435711361088 ||| 2^7) q12Shape13T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554947 ||| 2^7) 4435711361088 q12Shape13T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T112OK,q12Shape13T113OK⟩

private def q12Shape13T114 : Tree 12 := (.split 7 (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,1,3,5,6,8,11})))) (.tip (.cover {0,1,2,5,6,8,11})))
private theorem q12Shape13T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33555011 4435711361024 q12Shape13T114=true := by decide

private def q12Shape13T110 : Tree 12 := .split 6 q12Shape13T111 q12Shape13T114
private theorem q12Shape13T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554947 4435711361024 q12Shape13T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554947 (4435711361024 ||| 2^6) q12Shape13T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554947 ||| 2^6) 4435711361024 q12Shape13T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T111OK,q12Shape13T114OK⟩

private def q12Shape13T108 : Tree 12 := .split 9 q12Shape13T109 q12Shape13T110
private theorem q12Shape13T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554435 4435711361024 q12Shape13T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554435 (4435711361024 ||| 2^9) q12Shape13T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554435 ||| 2^9) 4435711361024 q12Shape13T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T109OK,q12Shape13T110OK⟩

private def q12Shape13T104 : Tree 12 := .split 1 q12Shape13T105 q12Shape13T108
private theorem q12Shape13T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554433 4435711361024 q12Shape13T104=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554433 (4435711361024 ||| 2^1) q12Shape13T105 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554433 ||| 2^1) 4435711361024 q12Shape13T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T105OK,q12Shape13T108OK⟩

private def q12Shape13T98 : Tree 12 := .split 0 q12Shape13T99 q12Shape13T104
private theorem q12Shape13T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 4435711361024 q12Shape13T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 (4435711361024 ||| 2^0) q12Shape13T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554432 ||| 2^0) 4435711361024 q12Shape13T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T99OK,q12Shape13T104OK⟩

private def q12Shape13T115 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape13T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 4398080065536 37664849920 q12Shape13T115=true := by decide

private def q12Shape13T97 : Tree 12 := .split 42 q12Shape13T98 q12Shape13T115
private theorem q12Shape13T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 37664849920 q12Shape13T97=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 (37664849920 ||| 2^42) q12Shape13T98 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554432 ||| 2^42) 37664849920 q12Shape13T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T98OK,q12Shape13T115OK⟩

private def q12Shape13T116 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape13T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34393292800 3305111552 q12Shape13T116=true := by decide

private def q12Shape13T96 : Tree 12 := .split 35 q12Shape13T97 q12Shape13T116
private theorem q12Shape13T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 3305111552 q12Shape13T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 (3305111552 ||| 2^35) q12Shape13T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554432 ||| 2^35) 3305111552 q12Shape13T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T97OK,q12Shape13T116OK⟩

private def q12Shape13T117 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape13T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2181038080 1157627904 q12Shape13T117=true := by decide

private def q12Shape13T95 : Tree 12 := .split 31 q12Shape13T96 q12Shape13T117
private theorem q12Shape13T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 1157627904 q12Shape13T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 (1157627904 ||| 2^31) q12Shape13T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554432 ||| 2^31) 1157627904 q12Shape13T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T96OK,q12Shape13T117OK⟩

private def q12Shape13T118 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape13T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 1107296256 83886080 q12Shape13T118=true := by decide

private def q12Shape13T94 : Tree 12 := .split 30 q12Shape13T95 q12Shape13T118
private theorem q12Shape13T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 83886080 q12Shape13T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 (83886080 ||| 2^30) q12Shape13T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554432 ||| 2^30) 83886080 q12Shape13T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T95OK,q12Shape13T118OK⟩

private def q12Shape13T119 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape13T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 100663296 16777216 q12Shape13T119=true := by decide

private def q12Shape13T93 : Tree 12 := .split 26 q12Shape13T94 q12Shape13T119
private theorem q12Shape13T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 16777216 q12Shape13T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 (16777216 ||| 2^26) q12Shape13T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (33554432 ||| 2^26) 16777216 q12Shape13T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T94OK,q12Shape13T119OK⟩

def q12Shape13P4 : Tree 12 := q12Shape13T93
theorem q12Shape13P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 33554432 16777216 q12Shape13P4=true := q12Shape13T93OK

end Graffiti384b.EffectiveSearch.Q12
