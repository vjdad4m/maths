import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape13T129 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,8,11})))))
private theorem q12Shape13T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 4435728138243 q12Shape13T129=true := by decide

private def q12Shape13T131 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,8,11}))))
private theorem q12Shape13T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777218 4435728138753 q12Shape13T131=true := by decide

private def q12Shape13T132 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.tip (.cover {0,1,2,5,7,8,11}))))
private theorem q12Shape13T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777730 4435728138241 q12Shape13T132=true := by decide

private def q12Shape13T130 : Tree 12 := .split 9 q12Shape13T131 q12Shape13T132
private theorem q12Shape13T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777218 4435728138241 q12Shape13T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777218 (4435728138241 ||| 2^9) q12Shape13T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777218 ||| 2^9) 4435728138241 q12Shape13T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T131OK,q12Shape13T132OK⟩

private def q12Shape13T128 : Tree 12 := .split 1 q12Shape13T129 q12Shape13T130
private theorem q12Shape13T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 4435728138241 q12Shape13T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (4435728138241 ||| 2^1) q12Shape13T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^1) 4435728138241 q12Shape13T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T129OK,q12Shape13T130OK⟩

private def q12Shape13T135 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,8,11}))))
private theorem q12Shape13T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777217 4435728138754 q12Shape13T135=true := by decide

private def q12Shape13T136 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.tip (.cover {0,1,2,5,7,8,11}))))
private theorem q12Shape13T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777729 4435728138242 q12Shape13T136=true := by decide

private def q12Shape13T134 : Tree 12 := .split 9 q12Shape13T135 q12Shape13T136
private theorem q12Shape13T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777217 4435728138242 q12Shape13T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777217 (4435728138242 ||| 2^9) q12Shape13T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777217 ||| 2^9) 4435728138242 q12Shape13T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T135OK,q12Shape13T136OK⟩

private def q12Shape13T138 : Tree 12 := (.split 6 (.split 7 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))))) (.split 7 (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.tip (.cover {0,1,2,5,7,8,11}))))
private theorem q12Shape13T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777219 4435728138752 q12Shape13T138=true := by decide

private def q12Shape13T141 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape13T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777731 4435728138432 q12Shape13T141=true := by decide

private def q12Shape13T142 : Tree 12 := (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape13T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777859 4435728138304 q12Shape13T142=true := by decide

private def q12Shape13T140 : Tree 12 := .split 7 q12Shape13T141 q12Shape13T142
private theorem q12Shape13T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777731 4435728138304 q12Shape13T140=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777731 (4435728138304 ||| 2^7) q12Shape13T141 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777731 ||| 2^7) 4435728138304 q12Shape13T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T141OK,q12Shape13T142OK⟩

private def q12Shape13T143 : Tree 12 := (.split 7 (.split 14 (.split 15 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10,11})))) (.split 15 (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))) (.tip (.cover {0,1,2,5,7,8,11})))
private theorem q12Shape13T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777795 4435728138240 q12Shape13T143=true := by decide

private def q12Shape13T139 : Tree 12 := .split 6 q12Shape13T140 q12Shape13T143
private theorem q12Shape13T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777731 4435728138240 q12Shape13T139=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777731 (4435728138240 ||| 2^6) q12Shape13T140 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777731 ||| 2^6) 4435728138240 q12Shape13T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T140OK,q12Shape13T143OK⟩

private def q12Shape13T137 : Tree 12 := .split 9 q12Shape13T138 q12Shape13T139
private theorem q12Shape13T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777219 4435728138240 q12Shape13T137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777219 (4435728138240 ||| 2^9) q12Shape13T138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777219 ||| 2^9) 4435728138240 q12Shape13T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T138OK,q12Shape13T139OK⟩

private def q12Shape13T133 : Tree 12 := .split 1 q12Shape13T134 q12Shape13T137
private theorem q12Shape13T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777217 4435728138240 q12Shape13T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777217 (4435728138240 ||| 2^1) q12Shape13T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777217 ||| 2^1) 4435728138240 q12Shape13T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T134OK,q12Shape13T137OK⟩

private def q12Shape13T127 : Tree 12 := .split 0 q12Shape13T128 q12Shape13T133
private theorem q12Shape13T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 4435728138240 q12Shape13T127=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (4435728138240 ||| 2^0) q12Shape13T128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^0) 4435728138240 q12Shape13T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T128OK,q12Shape13T133OK⟩

private def q12Shape13T144 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape13T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 4398063288320 37681627136 q12Shape13T144=true := by decide

private def q12Shape13T126 : Tree 12 := .split 42 q12Shape13T127 q12Shape13T144
private theorem q12Shape13T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 37681627136 q12Shape13T126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (37681627136 ||| 2^42) q12Shape13T127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^42) 37681627136 q12Shape13T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T127OK,q12Shape13T144OK⟩

private def q12Shape13T145 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape13T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 34376515584 3321888768 q12Shape13T145=true := by decide

private def q12Shape13T125 : Tree 12 := .split 35 q12Shape13T126 q12Shape13T145
private theorem q12Shape13T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 3321888768 q12Shape13T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (3321888768 ||| 2^35) q12Shape13T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^35) 3321888768 q12Shape13T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T126OK,q12Shape13T145OK⟩

private def q12Shape13T146 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape13T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 2164260864 1174405120 q12Shape13T146=true := by decide

private def q12Shape13T124 : Tree 12 := .split 31 q12Shape13T125 q12Shape13T146
private theorem q12Shape13T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 1174405120 q12Shape13T124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (1174405120 ||| 2^31) q12Shape13T125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^31) 1174405120 q12Shape13T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T125OK,q12Shape13T146OK⟩

private def q12Shape13T147 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape13T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 1090519040 100663296 q12Shape13T147=true := by decide

private def q12Shape13T123 : Tree 12 := .split 30 q12Shape13T124 q12Shape13T147
private theorem q12Shape13T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 100663296 q12Shape13T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (100663296 ||| 2^30) q12Shape13T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^30) 100663296 q12Shape13T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T124OK,q12Shape13T147OK⟩

private def q12Shape13T148 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape13T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 83886080 33554432 q12Shape13T148=true := by decide

private def q12Shape13T122 : Tree 12 := .split 26 q12Shape13T123 q12Shape13T148
private theorem q12Shape13T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 33554432 q12Shape13T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (33554432 ||| 2^26) q12Shape13T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^26) 33554432 q12Shape13T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T123OK,q12Shape13T148OK⟩

private def q12Shape13T149 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape13T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 50331648 0 q12Shape13T149=true := by decide

private def q12Shape13T121 : Tree 12 := .split 25 q12Shape13T122 q12Shape13T149
private theorem q12Shape13T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 0 q12Shape13T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 (0 ||| 2^25) q12Shape13T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) (16777216 ||| 2^25) 0 q12Shape13T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape13T122OK,q12Shape13T149OK⟩

def q12Shape13P5 : Tree 12 := q12Shape13T121
theorem q12Shape13P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,3⟩) 16777216 0 q12Shape13P5=true := q12Shape13T121OK

end Graffiti384b.EffectiveSearch.Q12
