import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape14T1 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))))
private theorem q12Shape14T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 0 37580963847 q12Shape14T1=true := by decide

private def q12Shape14T3 : Tree 12 := (.split 10 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10,11})))))))
private theorem q12Shape14T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 4 37580964355 q12Shape14T3=true := by decide

private def q12Shape14T5 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))
private theorem q12Shape14T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 516 37580964867 q12Shape14T5=true := by decide

private def q12Shape14T7 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1540 37581094915 q12Shape14T7=true := by decide

private def q12Shape14T9 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))))
private theorem q12Shape14T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132612 37580963907 q12Shape14T9=true := by decide

private def q12Shape14T10 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {5,6,7,8,9,10,11}))))
private theorem q12Shape14T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132676 37580963843 q12Shape14T10=true := by decide

private def q12Shape14T8 : Tree 12 := .split 6 q12Shape14T9 q12Shape14T10
private theorem q12Shape14T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132612 37580963843 q12Shape14T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132612 (37580963843 ||| 2^6) q12Shape14T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (132612 ||| 2^6) 37580963843 q12Shape14T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T9OK,q12Shape14T10OK⟩

private def q12Shape14T6 : Tree 12 := .split 17 q12Shape14T7 q12Shape14T8
private theorem q12Shape14T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1540 37580963843 q12Shape14T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1540 (37580963843 ||| 2^17) q12Shape14T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1540 ||| 2^17) 37580963843 q12Shape14T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T7OK,q12Shape14T8OK⟩

private def q12Shape14T4 : Tree 12 := .split 10 q12Shape14T5 q12Shape14T6
private theorem q12Shape14T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 516 37580963843 q12Shape14T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 516 (37580963843 ||| 2^10) q12Shape14T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (516 ||| 2^10) 37580963843 q12Shape14T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T5OK,q12Shape14T6OK⟩

private def q12Shape14T2 : Tree 12 := .split 9 q12Shape14T3 q12Shape14T4
private theorem q12Shape14T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 4 37580963843 q12Shape14T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 4 (37580963843 ||| 2^9) q12Shape14T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (4 ||| 2^9) 37580963843 q12Shape14T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T3OK,q12Shape14T4OK⟩

private def q12Shape14T0 : Tree 12 := .split 2 q12Shape14T1 q12Shape14T2
private theorem q12Shape14T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 0 37580963843 q12Shape14T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 0 (37580963843 ||| 2^2) q12Shape14T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (0 ||| 2^2) 37580963843 q12Shape14T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T1OK,q12Shape14T2OK⟩

def q12Shape14P0 : Tree 12 := q12Shape14T0
theorem q12Shape14P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 0 37580963843 q12Shape14P0=true := q12Shape14T0OK

end Graffiti384b.EffectiveSearch.Q12
