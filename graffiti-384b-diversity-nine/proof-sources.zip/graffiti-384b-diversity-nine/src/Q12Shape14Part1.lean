import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape14T13 : Tree 12 := (.split 10 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))))
private theorem q12Shape14T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2 37580964357 q12Shape14T13=true := by decide

private def q12Shape14T15 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11}))))))
private theorem q12Shape14T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 514 37580964869 q12Shape14T15=true := by decide

private def q12Shape14T17 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1538 37581094917 q12Shape14T17=true := by decide

private def q12Shape14T18 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11})))) (.split 14 (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11}))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {1,4,6,7,8,10,11})))))
private theorem q12Shape14T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132610 37580963845 q12Shape14T18=true := by decide

private def q12Shape14T16 : Tree 12 := .split 17 q12Shape14T17 q12Shape14T18
private theorem q12Shape14T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1538 37580963845 q12Shape14T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1538 (37580963845 ||| 2^17) q12Shape14T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1538 ||| 2^17) 37580963845 q12Shape14T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T17OK,q12Shape14T18OK⟩

private def q12Shape14T14 : Tree 12 := .split 10 q12Shape14T15 q12Shape14T16
private theorem q12Shape14T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 514 37580963845 q12Shape14T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 514 (37580963845 ||| 2^10) q12Shape14T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (514 ||| 2^10) 37580963845 q12Shape14T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T15OK,q12Shape14T16OK⟩

private def q12Shape14T12 : Tree 12 := .split 9 q12Shape14T13 q12Shape14T14
private theorem q12Shape14T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2 37580963845 q12Shape14T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2 (37580963845 ||| 2^9) q12Shape14T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (2 ||| 2^9) 37580963845 q12Shape14T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T13OK,q12Shape14T14OK⟩

private def q12Shape14T21 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))
private theorem q12Shape14T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 6 37580965377 q12Shape14T21=true := by decide

private def q12Shape14T23 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1030 37581095425 q12Shape14T23=true := by decide

private def q12Shape14T25 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))))
private theorem q12Shape14T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132102 37580964417 q12Shape14T25=true := by decide

private def q12Shape14T26 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {5,6,7,8,9,10,11}))))
private theorem q12Shape14T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132166 37580964353 q12Shape14T26=true := by decide

private def q12Shape14T24 : Tree 12 := .split 6 q12Shape14T25 q12Shape14T26
private theorem q12Shape14T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132102 37580964353 q12Shape14T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132102 (37580964353 ||| 2^6) q12Shape14T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (132102 ||| 2^6) 37580964353 q12Shape14T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T25OK,q12Shape14T26OK⟩

private def q12Shape14T22 : Tree 12 := .split 17 q12Shape14T23 q12Shape14T24
private theorem q12Shape14T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1030 37580964353 q12Shape14T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1030 (37580964353 ||| 2^17) q12Shape14T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1030 ||| 2^17) 37580964353 q12Shape14T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T23OK,q12Shape14T24OK⟩

private def q12Shape14T20 : Tree 12 := .split 10 q12Shape14T21 q12Shape14T22
private theorem q12Shape14T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 6 37580964353 q12Shape14T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 6 (37580964353 ||| 2^10) q12Shape14T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (6 ||| 2^10) 37580964353 q12Shape14T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T21OK,q12Shape14T22OK⟩

private def q12Shape14T29 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 518 37581095937 q12Shape14T29=true := by decide

private def q12Shape14T30 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11})))) (.split 14 (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11}))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {1,4,6,7,8,10,11})))))
private theorem q12Shape14T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 131590 37580964865 q12Shape14T30=true := by decide

private def q12Shape14T28 : Tree 12 := .split 17 q12Shape14T29 q12Shape14T30
private theorem q12Shape14T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 518 37580964865 q12Shape14T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 518 (37580964865 ||| 2^17) q12Shape14T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (518 ||| 2^17) 37580964865 q12Shape14T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T29OK,q12Shape14T30OK⟩

private def q12Shape14T32 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10,11}))))) (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10,11})))) (.tip (.cover {2,3,6,7,8,10,11}))))
private theorem q12Shape14T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1542 37581094913 q12Shape14T32=true := by decide

private def q12Shape14T34 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11}))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {1,4,6,7,8,10,11}))))
private theorem q12Shape14T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132614 37580963905 q12Shape14T34=true := by decide

private def q12Shape14T35 : Tree 12 := (.split 14 (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {1,4,6,7,8,10,11}))) (.tip (.cover {2,3,6,7,8,10,11})))
private theorem q12Shape14T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132678 37580963841 q12Shape14T35=true := by decide

private def q12Shape14T33 : Tree 12 := .split 6 q12Shape14T34 q12Shape14T35
private theorem q12Shape14T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132614 37580963841 q12Shape14T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132614 (37580963841 ||| 2^6) q12Shape14T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (132614 ||| 2^6) 37580963841 q12Shape14T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T34OK,q12Shape14T35OK⟩

private def q12Shape14T31 : Tree 12 := .split 17 q12Shape14T32 q12Shape14T33
private theorem q12Shape14T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1542 37580963841 q12Shape14T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1542 (37580963841 ||| 2^17) q12Shape14T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1542 ||| 2^17) 37580963841 q12Shape14T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T32OK,q12Shape14T33OK⟩

private def q12Shape14T27 : Tree 12 := .split 10 q12Shape14T28 q12Shape14T31
private theorem q12Shape14T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 518 37580963841 q12Shape14T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 518 (37580963841 ||| 2^10) q12Shape14T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (518 ||| 2^10) 37580963841 q12Shape14T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T28OK,q12Shape14T31OK⟩

private def q12Shape14T19 : Tree 12 := .split 9 q12Shape14T20 q12Shape14T27
private theorem q12Shape14T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 6 37580963841 q12Shape14T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 6 (37580963841 ||| 2^9) q12Shape14T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (6 ||| 2^9) 37580963841 q12Shape14T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T20OK,q12Shape14T27OK⟩

private def q12Shape14T11 : Tree 12 := .split 2 q12Shape14T12 q12Shape14T19
private theorem q12Shape14T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2 37580963841 q12Shape14T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2 (37580963841 ||| 2^2) q12Shape14T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (2 ||| 2^2) 37580963841 q12Shape14T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T12OK,q12Shape14T19OK⟩

def q12Shape14P1 : Tree 12 := q12Shape14T11
theorem q12Shape14P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2 37580963841 q12Shape14P1=true := q12Shape14T11OK

end Graffiti384b.EffectiveSearch.Q12
