import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape14T39 : Tree 12 := (.split 10 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))))
private theorem q12Shape14T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1 37580964358 q12Shape14T39=true := by decide

private def q12Shape14T41 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))
private theorem q12Shape14T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 513 37580964870 q12Shape14T41=true := by decide

private def q12Shape14T43 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,6,7,8,10,11}))))
private theorem q12Shape14T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1537 37581094918 q12Shape14T43=true := by decide

private def q12Shape14T44 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,6,7,8,10,11}))) (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10,11})))) (.tip (.cover {1,3,6,7,8,10,11}))))
private theorem q12Shape14T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132609 37580963846 q12Shape14T44=true := by decide

private def q12Shape14T42 : Tree 12 := .split 17 q12Shape14T43 q12Shape14T44
private theorem q12Shape14T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1537 37580963846 q12Shape14T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1537 (37580963846 ||| 2^17) q12Shape14T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1537 ||| 2^17) 37580963846 q12Shape14T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T43OK,q12Shape14T44OK⟩

private def q12Shape14T40 : Tree 12 := .split 10 q12Shape14T41 q12Shape14T42
private theorem q12Shape14T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 513 37580963846 q12Shape14T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 513 (37580963846 ||| 2^10) q12Shape14T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (513 ||| 2^10) 37580963846 q12Shape14T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T41OK,q12Shape14T42OK⟩

private def q12Shape14T38 : Tree 12 := .split 9 q12Shape14T39 q12Shape14T40
private theorem q12Shape14T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1 37580963846 q12Shape14T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1 (37580963846 ||| 2^9) q12Shape14T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1 ||| 2^9) 37580963846 q12Shape14T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T39OK,q12Shape14T40OK⟩

private def q12Shape14T47 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))
private theorem q12Shape14T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 5 37580965378 q12Shape14T47=true := by decide

private def q12Shape14T49 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1029 37581095426 q12Shape14T49=true := by decide

private def q12Shape14T51 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))))
private theorem q12Shape14T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132101 37580964418 q12Shape14T51=true := by decide

private def q12Shape14T52 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {5,6,7,8,9,10,11}))))
private theorem q12Shape14T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132165 37580964354 q12Shape14T52=true := by decide

private def q12Shape14T50 : Tree 12 := .split 6 q12Shape14T51 q12Shape14T52
private theorem q12Shape14T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132101 37580964354 q12Shape14T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132101 (37580964354 ||| 2^6) q12Shape14T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (132101 ||| 2^6) 37580964354 q12Shape14T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T51OK,q12Shape14T52OK⟩

private def q12Shape14T48 : Tree 12 := .split 17 q12Shape14T49 q12Shape14T50
private theorem q12Shape14T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1029 37580964354 q12Shape14T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1029 (37580964354 ||| 2^17) q12Shape14T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1029 ||| 2^17) 37580964354 q12Shape14T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T49OK,q12Shape14T50OK⟩

private def q12Shape14T46 : Tree 12 := .split 10 q12Shape14T47 q12Shape14T48
private theorem q12Shape14T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 5 37580964354 q12Shape14T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 5 (37580964354 ||| 2^10) q12Shape14T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (5 ||| 2^10) 37580964354 q12Shape14T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T47OK,q12Shape14T48OK⟩

private def q12Shape14T55 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 517 37581095938 q12Shape14T55=true := by decide

private def q12Shape14T57 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {3,5,6,7,8,10,11})))))
private theorem q12Shape14T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 131589 37580964930 q12Shape14T57=true := by decide

private def q12Shape14T58 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.tip (.cover {2,4,6,7,8,10,11}))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {3,5,6,7,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))))
private theorem q12Shape14T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 131653 37580964866 q12Shape14T58=true := by decide

private def q12Shape14T56 : Tree 12 := .split 6 q12Shape14T57 q12Shape14T58
private theorem q12Shape14T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 131589 37580964866 q12Shape14T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 131589 (37580964866 ||| 2^6) q12Shape14T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (131589 ||| 2^6) 37580964866 q12Shape14T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T57OK,q12Shape14T58OK⟩

private def q12Shape14T54 : Tree 12 := .split 17 q12Shape14T55 q12Shape14T56
private theorem q12Shape14T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 517 37580964866 q12Shape14T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 517 (37580964866 ||| 2^17) q12Shape14T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (517 ||| 2^17) 37580964866 q12Shape14T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T55OK,q12Shape14T56OK⟩

private def q12Shape14T60 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,6,7,8,10,11}))) (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10,11})))) (.tip (.cover {1,3,6,7,8,10,11}))))
private theorem q12Shape14T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1541 37581094914 q12Shape14T60=true := by decide

private def q12Shape14T61 : Tree 12 := (.split 6 (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))) (.tip (.cover {1,3,6,7,8,10,11}))) (.split 14 (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))) (.tip (.cover {1,3,6,7,8,10,11}))))
private theorem q12Shape14T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132613 37580963842 q12Shape14T61=true := by decide

private def q12Shape14T59 : Tree 12 := .split 17 q12Shape14T60 q12Shape14T61
private theorem q12Shape14T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1541 37580963842 q12Shape14T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1541 (37580963842 ||| 2^17) q12Shape14T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1541 ||| 2^17) 37580963842 q12Shape14T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T60OK,q12Shape14T61OK⟩

private def q12Shape14T53 : Tree 12 := .split 10 q12Shape14T54 q12Shape14T59
private theorem q12Shape14T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 517 37580963842 q12Shape14T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 517 (37580963842 ||| 2^10) q12Shape14T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (517 ||| 2^10) 37580963842 q12Shape14T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T54OK,q12Shape14T59OK⟩

private def q12Shape14T45 : Tree 12 := .split 9 q12Shape14T46 q12Shape14T53
private theorem q12Shape14T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 5 37580963842 q12Shape14T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 5 (37580963842 ||| 2^9) q12Shape14T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (5 ||| 2^9) 37580963842 q12Shape14T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T46OK,q12Shape14T53OK⟩

private def q12Shape14T37 : Tree 12 := .split 2 q12Shape14T38 q12Shape14T45
private theorem q12Shape14T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1 37580963842 q12Shape14T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1 (37580963842 ||| 2^2) q12Shape14T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1 ||| 2^2) 37580963842 q12Shape14T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T38OK,q12Shape14T45OK⟩

def q12Shape14P2 : Tree 12 := q12Shape14T37
theorem q12Shape14P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1 37580963842 q12Shape14P2=true := q12Shape14T37OK

end Graffiti384b.EffectiveSearch.Q12
