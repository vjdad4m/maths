import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape14T65 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))
private theorem q12Shape14T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 37580965380 q12Shape14T65=true := by decide

private def q12Shape14T67 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1027 37581095428 q12Shape14T67=true := by decide

private def q12Shape14T69 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {3,4,6,7,8,10,11}))))
private theorem q12Shape14T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132099 37580964420 q12Shape14T69=true := by decide

private def q12Shape14T70 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10,11})))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10,11}))) (.tip (.cover {3,4,6,7,8,10,11}))))
private theorem q12Shape14T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132163 37580964356 q12Shape14T70=true := by decide

private def q12Shape14T68 : Tree 12 := .split 6 q12Shape14T69 q12Shape14T70
private theorem q12Shape14T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132099 37580964356 q12Shape14T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132099 (37580964356 ||| 2^6) q12Shape14T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (132099 ||| 2^6) 37580964356 q12Shape14T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T69OK,q12Shape14T70OK⟩

private def q12Shape14T66 : Tree 12 := .split 17 q12Shape14T67 q12Shape14T68
private theorem q12Shape14T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1027 37580964356 q12Shape14T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1027 (37580964356 ||| 2^17) q12Shape14T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1027 ||| 2^17) 37580964356 q12Shape14T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T67OK,q12Shape14T68OK⟩

private def q12Shape14T64 : Tree 12 := .split 10 q12Shape14T65 q12Shape14T66
private theorem q12Shape14T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 37580964356 q12Shape14T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 (37580964356 ||| 2^10) q12Shape14T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (3 ||| 2^10) 37580964356 q12Shape14T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T65OK,q12Shape14T66OK⟩

private def q12Shape14T73 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape14T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 515 37581095940 q12Shape14T73=true := by decide

private def q12Shape14T74 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11})))) (.split 14 (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11}))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {1,4,6,7,8,10,11})))))
private theorem q12Shape14T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 131587 37580964868 q12Shape14T74=true := by decide

private def q12Shape14T72 : Tree 12 := .split 17 q12Shape14T73 q12Shape14T74
private theorem q12Shape14T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 515 37580964868 q12Shape14T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 515 (37580964868 ||| 2^17) q12Shape14T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (515 ||| 2^17) 37580964868 q12Shape14T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T73OK,q12Shape14T74OK⟩

private def q12Shape14T76 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,6,7,8,10,11}))) (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10,11})))) (.tip (.cover {1,3,6,7,8,10,11}))))
private theorem q12Shape14T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1539 37581094916 q12Shape14T76=true := by decide

private def q12Shape14T77 : Tree 12 := (.split 6 (.split 14 (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11}))) (.tip (.cover {1,3,6,7,8,10,11}))) (.split 14 (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10,11}))) (.tip (.cover {1,4,6,7,8,10,11}))) (.tip (.cover {1,3,6,7,8,10,11}))))
private theorem q12Shape14T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132611 37580963844 q12Shape14T77=true := by decide

private def q12Shape14T75 : Tree 12 := .split 17 q12Shape14T76 q12Shape14T77
private theorem q12Shape14T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1539 37580963844 q12Shape14T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1539 (37580963844 ||| 2^17) q12Shape14T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1539 ||| 2^17) 37580963844 q12Shape14T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T76OK,q12Shape14T77OK⟩

private def q12Shape14T71 : Tree 12 := .split 10 q12Shape14T72 q12Shape14T75
private theorem q12Shape14T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 515 37580963844 q12Shape14T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 515 (37580963844 ||| 2^10) q12Shape14T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (515 ||| 2^10) 37580963844 q12Shape14T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T72OK,q12Shape14T75OK⟩

private def q12Shape14T63 : Tree 12 := .split 9 q12Shape14T64 q12Shape14T71
private theorem q12Shape14T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 37580963844 q12Shape14T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 (37580963844 ||| 2^9) q12Shape14T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (3 ||| 2^9) 37580963844 q12Shape14T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T64OK,q12Shape14T71OK⟩

private def q12Shape14T80 : Tree 12 := (.split 17 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10,11}))) (.split 6 (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10,11}))))) (.tip (.cover {1,2,6,7,8,10,11}))))
private theorem q12Shape14T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 7 37580965376 q12Shape14T80=true := by decide

private def q12Shape14T82 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10,11}))))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape14T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1031 37581095424 q12Shape14T82=true := by decide

private def q12Shape14T83 : Tree 12 := (.split 6 (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {3,4,6,7,8,10,11})))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape14T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132103 37580964352 q12Shape14T83=true := by decide

private def q12Shape14T81 : Tree 12 := .split 17 q12Shape14T82 q12Shape14T83
private theorem q12Shape14T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1031 37580964352 q12Shape14T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1031 (37580964352 ||| 2^17) q12Shape14T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1031 ||| 2^17) 37580964352 q12Shape14T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T82OK,q12Shape14T83OK⟩

private def q12Shape14T79 : Tree 12 := .split 10 q12Shape14T80 q12Shape14T81
private theorem q12Shape14T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 7 37580964352 q12Shape14T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 7 (37580964352 ||| 2^10) q12Shape14T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (7 ||| 2^10) 37580964352 q12Shape14T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T80OK,q12Shape14T81OK⟩

private def q12Shape14T86 : Tree 12 := (.split 6 (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10,11}))))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape14T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 519 37581095936 q12Shape14T86=true := by decide

private def q12Shape14T87 : Tree 12 := (.split 6 (.split 14 (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10,11}))) (.split 21 (.split 27 (.tip (.small 1)) (.tip (.cover {3,5,6,7,8,10,11}))) (.tip (.cover {1,4,6,7,8,10,11})))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape14T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 131591 37580964864 q12Shape14T87=true := by decide

private def q12Shape14T85 : Tree 12 := .split 17 q12Shape14T86 q12Shape14T87
private theorem q12Shape14T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 519 37580964864 q12Shape14T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 519 (37580964864 ||| 2^17) q12Shape14T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (519 ||| 2^17) 37580964864 q12Shape14T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T86OK,q12Shape14T87OK⟩

private def q12Shape14T89 : Tree 12 := (.split 6 (.split 14 (.split 21 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10,11})))) (.tip (.cover {1,3,6,7,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape14T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1543 37581094912 q12Shape14T89=true := by decide

private def q12Shape14T90 : Tree 12 := (.split 6 (.split 14 (.split 21 (.tip (.cover {1,5,6,7,8,10,11})) (.tip (.cover {1,4,6,7,8,10,11}))) (.tip (.cover {1,3,6,7,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape14T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 132615 37580963840 q12Shape14T90=true := by decide

private def q12Shape14T88 : Tree 12 := .split 17 q12Shape14T89 q12Shape14T90
private theorem q12Shape14T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1543 37580963840 q12Shape14T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1543 (37580963840 ||| 2^17) q12Shape14T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (1543 ||| 2^17) 37580963840 q12Shape14T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T89OK,q12Shape14T90OK⟩

private def q12Shape14T84 : Tree 12 := .split 10 q12Shape14T85 q12Shape14T88
private theorem q12Shape14T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 519 37580963840 q12Shape14T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 519 (37580963840 ||| 2^10) q12Shape14T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (519 ||| 2^10) 37580963840 q12Shape14T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T85OK,q12Shape14T88OK⟩

private def q12Shape14T78 : Tree 12 := .split 9 q12Shape14T79 q12Shape14T84
private theorem q12Shape14T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 7 37580963840 q12Shape14T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 7 (37580963840 ||| 2^9) q12Shape14T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (7 ||| 2^9) 37580963840 q12Shape14T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T79OK,q12Shape14T84OK⟩

private def q12Shape14T62 : Tree 12 := .split 2 q12Shape14T63 q12Shape14T78
private theorem q12Shape14T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 37580963840 q12Shape14T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 (37580963840 ||| 2^2) q12Shape14T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) (3 ||| 2^2) 37580963840 q12Shape14T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape14T63OK,q12Shape14T78OK⟩

def q12Shape14P3 : Tree 12 := q12Shape14T62
theorem q12Shape14P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 3 37580963840 q12Shape14P3=true := q12Shape14T62OK

private def q12Shape14T93 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape14T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 34359738368 3221225472 q12Shape14T93=true := by decide

def q12Shape14P4 : Tree 12 := q12Shape14T93
theorem q12Shape14P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 34359738368 3221225472 q12Shape14P4=true := q12Shape14T93OK

private def q12Shape14T95 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape14T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2147483648 1073741824 q12Shape14T95=true := by decide

def q12Shape14P5 : Tree 12 := q12Shape14T95
theorem q12Shape14P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 2147483648 1073741824 q12Shape14P5=true := q12Shape14T95OK

private def q12Shape14T97 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape14T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1073741824 0 q12Shape14T97=true := by decide

def q12Shape14P6 : Tree 12 := q12Shape14T97
theorem q12Shape14P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,5,4⟩) 1073741824 0 q12Shape14P6=true := q12Shape14T97OK

end Graffiti384b.EffectiveSearch.Q12
