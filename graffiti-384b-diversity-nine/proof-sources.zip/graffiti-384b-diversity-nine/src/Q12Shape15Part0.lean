import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape15T6 : Tree 12 := (.tip (.cover {0,2,3,4,9,10,11}))
private theorem q12Shape15T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 37698404352 q12Shape15T6=true := by decide

private def q12Shape15T9 : Tree 12 := (.split 44 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10})))
private theorem q12Shape15T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34359738368 13197478199296 q12Shape15T9=true := by decide

private def q12Shape15T10 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,10}))
private theorem q12Shape15T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 8830452760576 4401385177088 q12Shape15T10=true := by decide

private def q12Shape15T8 : Tree 12 := .split 43 q12Shape15T9 q12Shape15T10
private theorem q12Shape15T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34359738368 4401385177088 q12Shape15T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34359738368 (4401385177088 ||| 2^43) q12Shape15T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (34359738368 ||| 2^43) 4401385177088 q12Shape15T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T9OK,q12Shape15T10OK⟩

private def q12Shape15T11 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape15T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 4432406249472 3338665984 q12Shape15T11=true := by decide

private def q12Shape15T7 : Tree 12 := .split 42 q12Shape15T8 q12Shape15T11
private theorem q12Shape15T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34359738368 3338665984 q12Shape15T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34359738368 (3338665984 ||| 2^42) q12Shape15T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (34359738368 ||| 2^42) 3338665984 q12Shape15T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T8OK,q12Shape15T11OK⟩

private def q12Shape15T5 : Tree 12 := .split 35 q12Shape15T6 q12Shape15T7
private theorem q12Shape15T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 3338665984 q12Shape15T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 (3338665984 ||| 2^35) q12Shape15T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (0 ||| 2^35) 3338665984 q12Shape15T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T6OK,q12Shape15T7OK⟩

private def q12Shape15T15 : Tree 12 := (.split 44 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10})))
private theorem q12Shape15T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2147483648 13229690454016 q12Shape15T15=true := by decide

private def q12Shape15T16 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,10}))
private theorem q12Shape15T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 8798240505856 4433597431808 q12Shape15T16=true := by decide

private def q12Shape15T14 : Tree 12 := .split 43 q12Shape15T15 q12Shape15T16
private theorem q12Shape15T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2147483648 4433597431808 q12Shape15T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2147483648 (4433597431808 ||| 2^43) q12Shape15T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (2147483648 ||| 2^43) 4433597431808 q12Shape15T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T15OK,q12Shape15T16OK⟩

private def q12Shape15T17 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape15T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 4400193994752 35550920704 q12Shape15T17=true := by decide

private def q12Shape15T13 : Tree 12 := .split 42 q12Shape15T14 q12Shape15T17
private theorem q12Shape15T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2147483648 35550920704 q12Shape15T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2147483648 (35550920704 ||| 2^42) q12Shape15T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (2147483648 ||| 2^42) 35550920704 q12Shape15T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T14OK,q12Shape15T17OK⟩

private def q12Shape15T18 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape15T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 36507222016 1191182336 q12Shape15T18=true := by decide

private def q12Shape15T12 : Tree 12 := .split 35 q12Shape15T13 q12Shape15T18
private theorem q12Shape15T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2147483648 1191182336 q12Shape15T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2147483648 (1191182336 ||| 2^35) q12Shape15T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (2147483648 ||| 2^35) 1191182336 q12Shape15T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T13OK,q12Shape15T18OK⟩

private def q12Shape15T4 : Tree 12 := .split 31 q12Shape15T5 q12Shape15T12
private theorem q12Shape15T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 1191182336 q12Shape15T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 (1191182336 ||| 2^31) q12Shape15T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (0 ||| 2^31) 1191182336 q12Shape15T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T5OK,q12Shape15T12OK⟩

private def q12Shape15T23 : Tree 12 := (.split 44 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,9,10})))
private theorem q12Shape15T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 13230764195840 q12Shape15T23=true := by decide

private def q12Shape15T24 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,10}))
private theorem q12Shape15T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 8797166764032 4434671173632 q12Shape15T24=true := by decide

private def q12Shape15T22 : Tree 12 := .split 43 q12Shape15T23 q12Shape15T24
private theorem q12Shape15T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 4434671173632 q12Shape15T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 (4434671173632 ||| 2^43) q12Shape15T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (1073741824 ||| 2^43) 4434671173632 q12Shape15T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T23OK,q12Shape15T24OK⟩

private def q12Shape15T25 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape15T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 4399120252928 36624662528 q12Shape15T25=true := by decide

private def q12Shape15T21 : Tree 12 := .split 42 q12Shape15T22 q12Shape15T25
private theorem q12Shape15T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 36624662528 q12Shape15T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 (36624662528 ||| 2^42) q12Shape15T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (1073741824 ||| 2^42) 36624662528 q12Shape15T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T22OK,q12Shape15T25OK⟩

private def q12Shape15T26 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape15T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 35433480192 2264924160 q12Shape15T26=true := by decide

private def q12Shape15T20 : Tree 12 := .split 35 q12Shape15T21 q12Shape15T26
private theorem q12Shape15T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 2264924160 q12Shape15T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 (2264924160 ||| 2^35) q12Shape15T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (1073741824 ||| 2^35) 2264924160 q12Shape15T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T21OK,q12Shape15T26OK⟩

private def q12Shape15T27 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape15T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 3221225472 117440512 q12Shape15T27=true := by decide

private def q12Shape15T19 : Tree 12 := .split 31 q12Shape15T20 q12Shape15T27
private theorem q12Shape15T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 117440512 q12Shape15T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1073741824 (117440512 ||| 2^31) q12Shape15T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (1073741824 ||| 2^31) 117440512 q12Shape15T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T20OK,q12Shape15T27OK⟩

private def q12Shape15T3 : Tree 12 := .split 30 q12Shape15T4 q12Shape15T19
private theorem q12Shape15T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 117440512 q12Shape15T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 (117440512 ||| 2^30) q12Shape15T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (0 ||| 2^30) 117440512 q12Shape15T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T4OK,q12Shape15T19OK⟩

private def q12Shape15T33 : Tree 12 := (.split 44 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10})))
private theorem q12Shape15T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 13231770828800 q12Shape15T33=true := by decide

private def q12Shape15T34 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,10}))
private theorem q12Shape15T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 8796160131072 4435677806592 q12Shape15T34=true := by decide

private def q12Shape15T32 : Tree 12 := .split 43 q12Shape15T33 q12Shape15T34
private theorem q12Shape15T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 4435677806592 q12Shape15T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 (4435677806592 ||| 2^43) q12Shape15T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (67108864 ||| 2^43) 4435677806592 q12Shape15T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T33OK,q12Shape15T34OK⟩

private def q12Shape15T35 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape15T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 4398113619968 37631295488 q12Shape15T35=true := by decide

private def q12Shape15T31 : Tree 12 := .split 42 q12Shape15T32 q12Shape15T35
private theorem q12Shape15T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 37631295488 q12Shape15T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 (37631295488 ||| 2^42) q12Shape15T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (67108864 ||| 2^42) 37631295488 q12Shape15T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T32OK,q12Shape15T35OK⟩

private def q12Shape15T36 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape15T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34426847232 3271557120 q12Shape15T36=true := by decide

private def q12Shape15T30 : Tree 12 := .split 35 q12Shape15T31 q12Shape15T36
private theorem q12Shape15T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 3271557120 q12Shape15T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 (3271557120 ||| 2^35) q12Shape15T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (67108864 ||| 2^35) 3271557120 q12Shape15T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T31OK,q12Shape15T36OK⟩

private def q12Shape15T37 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape15T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2214592512 1124073472 q12Shape15T37=true := by decide

private def q12Shape15T29 : Tree 12 := .split 31 q12Shape15T30 q12Shape15T37
private theorem q12Shape15T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 1124073472 q12Shape15T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 (1124073472 ||| 2^31) q12Shape15T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (67108864 ||| 2^31) 1124073472 q12Shape15T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T30OK,q12Shape15T37OK⟩

private def q12Shape15T38 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape15T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1140850688 50331648 q12Shape15T38=true := by decide

private def q12Shape15T28 : Tree 12 := .split 30 q12Shape15T29 q12Shape15T38
private theorem q12Shape15T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 50331648 q12Shape15T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 67108864 (50331648 ||| 2^30) q12Shape15T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (67108864 ||| 2^30) 50331648 q12Shape15T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T29OK,q12Shape15T38OK⟩

private def q12Shape15T2 : Tree 12 := .split 26 q12Shape15T3 q12Shape15T28
private theorem q12Shape15T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 50331648 q12Shape15T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 (50331648 ||| 2^26) q12Shape15T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (0 ||| 2^26) 50331648 q12Shape15T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T3OK,q12Shape15T28OK⟩

private def q12Shape15T45 : Tree 12 := (.split 44 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,9,10})))
private theorem q12Shape15T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 13231804383232 q12Shape15T45=true := by decide

private def q12Shape15T46 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,10}))
private theorem q12Shape15T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 8796126576640 4435711361024 q12Shape15T46=true := by decide

private def q12Shape15T44 : Tree 12 := .split 43 q12Shape15T45 q12Shape15T46
private theorem q12Shape15T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 4435711361024 q12Shape15T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 (4435711361024 ||| 2^43) q12Shape15T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (33554432 ||| 2^43) 4435711361024 q12Shape15T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T45OK,q12Shape15T46OK⟩

private def q12Shape15T47 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape15T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 4398080065536 37664849920 q12Shape15T47=true := by decide

private def q12Shape15T43 : Tree 12 := .split 42 q12Shape15T44 q12Shape15T47
private theorem q12Shape15T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 37664849920 q12Shape15T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 (37664849920 ||| 2^42) q12Shape15T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (33554432 ||| 2^42) 37664849920 q12Shape15T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T44OK,q12Shape15T47OK⟩

private def q12Shape15T48 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape15T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34393292800 3305111552 q12Shape15T48=true := by decide

private def q12Shape15T42 : Tree 12 := .split 35 q12Shape15T43 q12Shape15T48
private theorem q12Shape15T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 3305111552 q12Shape15T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 (3305111552 ||| 2^35) q12Shape15T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (33554432 ||| 2^35) 3305111552 q12Shape15T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T43OK,q12Shape15T48OK⟩

private def q12Shape15T49 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape15T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2181038080 1157627904 q12Shape15T49=true := by decide

private def q12Shape15T41 : Tree 12 := .split 31 q12Shape15T42 q12Shape15T49
private theorem q12Shape15T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 1157627904 q12Shape15T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 (1157627904 ||| 2^31) q12Shape15T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (33554432 ||| 2^31) 1157627904 q12Shape15T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T42OK,q12Shape15T49OK⟩

private def q12Shape15T50 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape15T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1107296256 83886080 q12Shape15T50=true := by decide

private def q12Shape15T40 : Tree 12 := .split 30 q12Shape15T41 q12Shape15T50
private theorem q12Shape15T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 83886080 q12Shape15T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 (83886080 ||| 2^30) q12Shape15T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (33554432 ||| 2^30) 83886080 q12Shape15T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T41OK,q12Shape15T50OK⟩

private def q12Shape15T51 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape15T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 100663296 16777216 q12Shape15T51=true := by decide

private def q12Shape15T39 : Tree 12 := .split 26 q12Shape15T40 q12Shape15T51
private theorem q12Shape15T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 16777216 q12Shape15T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 33554432 (16777216 ||| 2^26) q12Shape15T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (33554432 ||| 2^26) 16777216 q12Shape15T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T40OK,q12Shape15T51OK⟩

private def q12Shape15T1 : Tree 12 := .split 25 q12Shape15T2 q12Shape15T39
private theorem q12Shape15T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 16777216 q12Shape15T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 (16777216 ||| 2^25) q12Shape15T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (0 ||| 2^25) 16777216 q12Shape15T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T2OK,q12Shape15T39OK⟩

private def q12Shape15T62 : Tree 12 := (.split 29 (.split 32 (.split 33 (.split 34 (.split 36 (.split 37 (.split 38 (.tip (.cover {0,1,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10})))
private theorem q12Shape15T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 30824409858048 q12Shape15T62=true := by decide

private def q12Shape15T63 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape15T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 285212672 30824141422592 q12Shape15T63=true := by decide

private def q12Shape15T61 : Tree 12 := .split 28 q12Shape15T62 q12Shape15T63
private theorem q12Shape15T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 30824141422592 q12Shape15T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (30824141422592 ||| 2^28) q12Shape15T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^28) 30824141422592 q12Shape15T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T62OK,q12Shape15T63OK⟩

private def q12Shape15T64 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape15T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 150994944 30824007204864 q12Shape15T64=true := by decide

private def q12Shape15T60 : Tree 12 := .split 27 q12Shape15T61 q12Shape15T64
private theorem q12Shape15T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 30824007204864 q12Shape15T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (30824007204864 ||| 2^27) q12Shape15T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^27) 30824007204864 q12Shape15T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T61OK,q12Shape15T64OK⟩

private def q12Shape15T65 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,10}))
private theorem q12Shape15T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 17592202821632 13231821160448 q12Shape15T65=true := by decide

private def q12Shape15T59 : Tree 12 := .split 44 q12Shape15T60 q12Shape15T65
private theorem q12Shape15T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 13231821160448 q12Shape15T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (13231821160448 ||| 2^44) q12Shape15T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^44) 13231821160448 q12Shape15T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T60OK,q12Shape15T65OK⟩

private def q12Shape15T66 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,10}))
private theorem q12Shape15T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 8796109799424 4435728138240 q12Shape15T66=true := by decide

private def q12Shape15T58 : Tree 12 := .split 43 q12Shape15T59 q12Shape15T66
private theorem q12Shape15T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 4435728138240 q12Shape15T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (4435728138240 ||| 2^43) q12Shape15T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^43) 4435728138240 q12Shape15T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T59OK,q12Shape15T66OK⟩

private def q12Shape15T67 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape15T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 4398063288320 37681627136 q12Shape15T67=true := by decide

private def q12Shape15T57 : Tree 12 := .split 42 q12Shape15T58 q12Shape15T67
private theorem q12Shape15T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 37681627136 q12Shape15T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (37681627136 ||| 2^42) q12Shape15T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^42) 37681627136 q12Shape15T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T58OK,q12Shape15T67OK⟩

private def q12Shape15T68 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape15T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 34376515584 3321888768 q12Shape15T68=true := by decide

private def q12Shape15T56 : Tree 12 := .split 35 q12Shape15T57 q12Shape15T68
private theorem q12Shape15T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 3321888768 q12Shape15T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (3321888768 ||| 2^35) q12Shape15T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^35) 3321888768 q12Shape15T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T57OK,q12Shape15T68OK⟩

private def q12Shape15T69 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape15T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 2164260864 1174405120 q12Shape15T69=true := by decide

private def q12Shape15T55 : Tree 12 := .split 31 q12Shape15T56 q12Shape15T69
private theorem q12Shape15T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 1174405120 q12Shape15T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (1174405120 ||| 2^31) q12Shape15T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^31) 1174405120 q12Shape15T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T56OK,q12Shape15T69OK⟩

private def q12Shape15T70 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape15T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 1090519040 100663296 q12Shape15T70=true := by decide

private def q12Shape15T54 : Tree 12 := .split 30 q12Shape15T55 q12Shape15T70
private theorem q12Shape15T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 100663296 q12Shape15T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (100663296 ||| 2^30) q12Shape15T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^30) 100663296 q12Shape15T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T55OK,q12Shape15T70OK⟩

private def q12Shape15T71 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape15T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 83886080 33554432 q12Shape15T71=true := by decide

private def q12Shape15T53 : Tree 12 := .split 26 q12Shape15T54 q12Shape15T71
private theorem q12Shape15T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 33554432 q12Shape15T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (33554432 ||| 2^26) q12Shape15T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^26) 33554432 q12Shape15T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T54OK,q12Shape15T71OK⟩

private def q12Shape15T72 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape15T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 50331648 0 q12Shape15T72=true := by decide

private def q12Shape15T52 : Tree 12 := .split 25 q12Shape15T53 q12Shape15T72
private theorem q12Shape15T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 0 q12Shape15T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 16777216 (0 ||| 2^25) q12Shape15T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (16777216 ||| 2^25) 0 q12Shape15T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T53OK,q12Shape15T72OK⟩

private def q12Shape15T0 : Tree 12 := .split 24 q12Shape15T1 q12Shape15T52
private theorem q12Shape15T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 0 q12Shape15T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 (0 ||| 2^24) q12Shape15T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) (0 ||| 2^24) 0 q12Shape15T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape15T1OK,q12Shape15T52OK⟩

def q12Shape15P0 : Tree 12 := q12Shape15T0
theorem q12Shape15P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,7,6,3⟩) 0 0 q12Shape15P0=true := q12Shape15T0OK

end Graffiti384b.EffectiveSearch.Q12
