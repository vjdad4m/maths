import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape17T0 : Tree 12 := (.split 30 (.split 31 (.split 35 (.split 42 (.split 43 (.split 44 (.split 32 (.split 33 (.split 34 (.split 36 (.split 37 (.split 38 (.tip (.cover {0,1,2,3,4,5,8})) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape17T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 (forms 17)) 0 0 q12Shape17T0=true := by decide


theorem q12Shape17_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 17) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 17) b) (adj 12 (forms 17) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 (forms 17)) adj_mono b H q12Shape17T0 q12Shape17T0OK

#print axioms q12Shape17_cover
end Graffiti384b.EffectiveSearch.Q12
