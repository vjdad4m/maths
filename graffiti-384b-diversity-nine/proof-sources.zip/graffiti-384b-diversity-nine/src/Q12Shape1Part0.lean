import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape1T2 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 134656 q12Shape1T2=true := by decide

private def q12Shape1T4 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131072 265728 q12Shape1T4=true := by decide

private def q12Shape1T6 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 393216 16780800 q12Shape1T6=true := by decide

private def q12Shape1T9 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17170432 103079218688 q12Shape1T9=true := by decide

private def q12Shape1T10 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736647168 34359741952 q12Shape1T10=true := by decide

private def q12Shape1T8 : Tree 12 := .split 36 q12Shape1T9 q12Shape1T10
private theorem q12Shape1T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17170432 34359741952 q12Shape1T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17170432 (34359741952 ||| 2^36) q12Shape1T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (17170432 ||| 2^36) 34359741952 q12Shape1T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T9OK,q12Shape1T10OK⟩

private def q12Shape1T11 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376908800 3584 q12Shape1T11=true := by decide

private def q12Shape1T7 : Tree 12 := .split 35 q12Shape1T8 q12Shape1T11
private theorem q12Shape1T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17170432 3584 q12Shape1T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17170432 (3584 ||| 2^35) q12Shape1T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (17170432 ||| 2^35) 3584 q12Shape1T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T8OK,q12Shape1T11OK⟩

private def q12Shape1T5 : Tree 12 := .split 24 q12Shape1T6 q12Shape1T7
private theorem q12Shape1T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 393216 3584 q12Shape1T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 393216 (3584 ||| 2^24) q12Shape1T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (393216 ||| 2^24) 3584 q12Shape1T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T6OK,q12Shape1T7OK⟩

private def q12Shape1T3 : Tree 12 := .split 18 q12Shape1T4 q12Shape1T5
private theorem q12Shape1T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131072 3584 q12Shape1T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131072 (3584 ||| 2^18) q12Shape1T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (131072 ||| 2^18) 3584 q12Shape1T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T4OK,q12Shape1T5OK⟩

private def q12Shape1T1 : Tree 12 := .split 17 q12Shape1T2 q12Shape1T3
private theorem q12Shape1T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 3584 q12Shape1T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 (3584 ||| 2^17) q12Shape1T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (0 ||| 2^17) 3584 q12Shape1T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T2OK,q12Shape1T3OK⟩

private def q12Shape1T13 : Tree 12 := (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))))
private theorem q12Shape1T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2048 132608 q12Shape1T13=true := by decide

private def q12Shape1T16 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133120 17040896 q12Shape1T16=true := by decide

private def q12Shape1T19 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910336 103079478784 q12Shape1T19=true := by decide

private def q12Shape1T20 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736387072 34360002048 q12Shape1T20=true := by decide

private def q12Shape1T18 : Tree 12 := .split 36 q12Shape1T19 q12Shape1T20
private theorem q12Shape1T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910336 34360002048 q12Shape1T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910336 (34360002048 ||| 2^36) q12Shape1T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16910336 ||| 2^36) 34360002048 q12Shape1T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T19OK,q12Shape1T20OK⟩

private def q12Shape1T21 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376648704 263680 q12Shape1T21=true := by decide

private def q12Shape1T17 : Tree 12 := .split 35 q12Shape1T18 q12Shape1T21
private theorem q12Shape1T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910336 263680 q12Shape1T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910336 (263680 ||| 2^35) q12Shape1T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16910336 ||| 2^35) 263680 q12Shape1T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T18OK,q12Shape1T21OK⟩

private def q12Shape1T15 : Tree 12 := .split 24 q12Shape1T16 q12Shape1T17
private theorem q12Shape1T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133120 263680 q12Shape1T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133120 (263680 ||| 2^24) q12Shape1T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (133120 ||| 2^24) 263680 q12Shape1T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T16OK,q12Shape1T17OK⟩

private def q12Shape1T25 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395264 103095993856 q12Shape1T25=true := by decide

private def q12Shape1T26 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68719872000 34376517120 q12Shape1T26=true := by decide

private def q12Shape1T24 : Tree 12 := .split 36 q12Shape1T25 q12Shape1T26
private theorem q12Shape1T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395264 34376517120 q12Shape1T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395264 (34376517120 ||| 2^36) q12Shape1T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (395264 ||| 2^36) 34376517120 q12Shape1T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T25OK,q12Shape1T26OK⟩

private def q12Shape1T27 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34360133632 16778752 q12Shape1T27=true := by decide

private def q12Shape1T23 : Tree 12 := .split 35 q12Shape1T24 q12Shape1T27
private theorem q12Shape1T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395264 16778752 q12Shape1T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395264 (16778752 ||| 2^35) q12Shape1T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (395264 ||| 2^35) 16778752 q12Shape1T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T24OK,q12Shape1T27OK⟩

private def q12Shape1T28 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape1T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17172480 1536 q12Shape1T28=true := by decide

private def q12Shape1T22 : Tree 12 := .split 24 q12Shape1T23 q12Shape1T28
private theorem q12Shape1T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395264 1536 q12Shape1T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395264 (1536 ||| 2^24) q12Shape1T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (395264 ||| 2^24) 1536 q12Shape1T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T23OK,q12Shape1T28OK⟩

private def q12Shape1T14 : Tree 12 := .split 18 q12Shape1T15 q12Shape1T22
private theorem q12Shape1T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133120 1536 q12Shape1T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133120 (1536 ||| 2^18) q12Shape1T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (133120 ||| 2^18) 1536 q12Shape1T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T15OK,q12Shape1T22OK⟩

private def q12Shape1T12 : Tree 12 := .split 17 q12Shape1T13 q12Shape1T14
private theorem q12Shape1T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2048 1536 q12Shape1T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2048 (1536 ||| 2^17) q12Shape1T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (2048 ||| 2^17) 1536 q12Shape1T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T13OK,q12Shape1T14OK⟩

private def q12Shape1T0 : Tree 12 := .split 11 q12Shape1T1 q12Shape1T12
private theorem q12Shape1T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 1536 q12Shape1T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 (1536 ||| 2^11) q12Shape1T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (0 ||| 2^11) 1536 q12Shape1T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T1OK,q12Shape1T12OK⟩

def q12Shape1P0 : Tree 12 := q12Shape1T0
theorem q12Shape1P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 0 1536 q12Shape1P0=true := q12Shape1T0OK

end Graffiti384b.EffectiveSearch.Q12
