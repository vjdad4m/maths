import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape1T31 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 395776 q12Shape1T31=true := by decide

private def q12Shape1T33 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 263168 16910848 q12Shape1T33=true := by decide

private def q12Shape1T36 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17040384 103079348736 q12Shape1T36=true := by decide

private def q12Shape1T37 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736517120 34359872000 q12Shape1T37=true := by decide

private def q12Shape1T35 : Tree 12 := .split 36 q12Shape1T36 q12Shape1T37
private theorem q12Shape1T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17040384 34359872000 q12Shape1T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17040384 (34359872000 ||| 2^36) q12Shape1T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (17040384 ||| 2^36) 34359872000 q12Shape1T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T36OK,q12Shape1T37OK⟩

private def q12Shape1T38 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376778752 133632 q12Shape1T38=true := by decide

private def q12Shape1T34 : Tree 12 := .split 35 q12Shape1T35 q12Shape1T38
private theorem q12Shape1T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17040384 133632 q12Shape1T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17040384 (133632 ||| 2^35) q12Shape1T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (17040384 ||| 2^35) 133632 q12Shape1T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T35OK,q12Shape1T38OK⟩

private def q12Shape1T32 : Tree 12 := .split 24 q12Shape1T33 q12Shape1T34
private theorem q12Shape1T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 263168 133632 q12Shape1T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 263168 (133632 ||| 2^24) q12Shape1T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (263168 ||| 2^24) 133632 q12Shape1T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T33OK,q12Shape1T34OK⟩

private def q12Shape1T30 : Tree 12 := .split 18 q12Shape1T31 q12Shape1T32
private theorem q12Shape1T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 133632 q12Shape1T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 (133632 ||| 2^18) q12Shape1T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (1024 ||| 2^18) 133632 q12Shape1T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T31OK,q12Shape1T32OK⟩

private def q12Shape1T40 : Tree 12 := (.split 24 (.tip (.small 0)) (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape1T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 132096 264704 q12Shape1T40=true := by decide

private def q12Shape1T44 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 394240 103095994880 q12Shape1T44=true := by decide

private def q12Shape1T45 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68719870976 34376518144 q12Shape1T45=true := by decide

private def q12Shape1T43 : Tree 12 := .split 36 q12Shape1T44 q12Shape1T45
private theorem q12Shape1T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 394240 34376518144 q12Shape1T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 394240 (34376518144 ||| 2^36) q12Shape1T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (394240 ||| 2^36) 34376518144 q12Shape1T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T44OK,q12Shape1T45OK⟩

private def q12Shape1T46 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34360132608 16779776 q12Shape1T46=true := by decide

private def q12Shape1T42 : Tree 12 := .split 35 q12Shape1T43 q12Shape1T46
private theorem q12Shape1T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 394240 16779776 q12Shape1T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 394240 (16779776 ||| 2^35) q12Shape1T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (394240 ||| 2^35) 16779776 q12Shape1T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T43OK,q12Shape1T46OK⟩

private def q12Shape1T47 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape1T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17171456 2560 q12Shape1T47=true := by decide

private def q12Shape1T41 : Tree 12 := .split 24 q12Shape1T42 q12Shape1T47
private theorem q12Shape1T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 394240 2560 q12Shape1T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 394240 (2560 ||| 2^24) q12Shape1T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (394240 ||| 2^24) 2560 q12Shape1T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T42OK,q12Shape1T47OK⟩

private def q12Shape1T39 : Tree 12 := .split 18 q12Shape1T40 q12Shape1T41
private theorem q12Shape1T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 132096 2560 q12Shape1T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 132096 (2560 ||| 2^18) q12Shape1T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (132096 ||| 2^18) 2560 q12Shape1T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T40OK,q12Shape1T41OK⟩

private def q12Shape1T29 : Tree 12 := .split 17 q12Shape1T30 q12Shape1T39
private theorem q12Shape1T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 2560 q12Shape1T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 (2560 ||| 2^17) q12Shape1T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (1024 ||| 2^17) 2560 q12Shape1T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T30OK,q12Shape1T39OK⟩

def q12Shape1P1 : Tree 12 := q12Shape1T29
theorem q12Shape1P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 1024 2560 q12Shape1P1=true := q12Shape1T29OK

end Graffiti384b.EffectiveSearch.Q12
