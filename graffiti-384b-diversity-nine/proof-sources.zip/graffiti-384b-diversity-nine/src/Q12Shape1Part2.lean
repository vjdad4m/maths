import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape1T51 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 17170944 q12Shape1T51=true := by decide

private def q12Shape1T54 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16780288 103079608832 q12Shape1T54=true := by decide

private def q12Shape1T55 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736257024 34360132096 q12Shape1T55=true := by decide

private def q12Shape1T53 : Tree 12 := .split 36 q12Shape1T54 q12Shape1T55
private theorem q12Shape1T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16780288 34360132096 q12Shape1T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16780288 (34360132096 ||| 2^36) q12Shape1T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16780288 ||| 2^36) 34360132096 q12Shape1T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T54OK,q12Shape1T55OK⟩

private def q12Shape1T56 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376518656 393728 q12Shape1T56=true := by decide

private def q12Shape1T52 : Tree 12 := .split 35 q12Shape1T53 q12Shape1T56
private theorem q12Shape1T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16780288 393728 q12Shape1T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16780288 (393728 ||| 2^35) q12Shape1T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16780288 ||| 2^35) 393728 q12Shape1T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T53OK,q12Shape1T56OK⟩

private def q12Shape1T50 : Tree 12 := .split 24 q12Shape1T51 q12Shape1T52
private theorem q12Shape1T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 393728 q12Shape1T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 (393728 ||| 2^24) q12Shape1T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (3072 ||| 2^24) 393728 q12Shape1T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T51OK,q12Shape1T52OK⟩

private def q12Shape1T60 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 265216 103096123904 q12Shape1T60=true := by decide

private def q12Shape1T61 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68719741952 34376647168 q12Shape1T61=true := by decide

private def q12Shape1T59 : Tree 12 := .split 36 q12Shape1T60 q12Shape1T61
private theorem q12Shape1T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 265216 34376647168 q12Shape1T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 265216 (34376647168 ||| 2^36) q12Shape1T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (265216 ||| 2^36) 34376647168 q12Shape1T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T60OK,q12Shape1T61OK⟩

private def q12Shape1T62 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34360003584 16908800 q12Shape1T62=true := by decide

private def q12Shape1T58 : Tree 12 := .split 35 q12Shape1T59 q12Shape1T62
private theorem q12Shape1T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 265216 16908800 q12Shape1T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 265216 (16908800 ||| 2^35) q12Shape1T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (265216 ||| 2^35) 16908800 q12Shape1T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T59OK,q12Shape1T62OK⟩

private def q12Shape1T63 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape1T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17042432 131584 q12Shape1T63=true := by decide

private def q12Shape1T57 : Tree 12 := .split 24 q12Shape1T58 q12Shape1T63
private theorem q12Shape1T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 265216 131584 q12Shape1T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 265216 (131584 ||| 2^24) q12Shape1T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (265216 ||| 2^24) 131584 q12Shape1T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T58OK,q12Shape1T63OK⟩

private def q12Shape1T49 : Tree 12 := .split 18 q12Shape1T50 q12Shape1T57
private theorem q12Shape1T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 131584 q12Shape1T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 (131584 ||| 2^18) q12Shape1T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (3072 ||| 2^18) 131584 q12Shape1T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T50OK,q12Shape1T57OK⟩

private def q12Shape1T68 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 103096254976 q12Shape1T68=true := by decide

private def q12Shape1T69 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68719610880 34376778240 q12Shape1T69=true := by decide

private def q12Shape1T67 : Tree 12 := .split 36 q12Shape1T68 q12Shape1T69
private theorem q12Shape1T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 34376778240 q12Shape1T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 (34376778240 ||| 2^36) q12Shape1T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (134144 ||| 2^36) 34376778240 q12Shape1T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T68OK,q12Shape1T69OK⟩

private def q12Shape1T70 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34359872512 17039872 q12Shape1T70=true := by decide

private def q12Shape1T66 : Tree 12 := .split 35 q12Shape1T67 q12Shape1T70
private theorem q12Shape1T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 17039872 q12Shape1T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 (17039872 ||| 2^35) q12Shape1T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (134144 ||| 2^35) 17039872 q12Shape1T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T67OK,q12Shape1T70OK⟩

private def q12Shape1T71 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape1T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16911360 262656 q12Shape1T71=true := by decide

private def q12Shape1T65 : Tree 12 := .split 24 q12Shape1T66 q12Shape1T71
private theorem q12Shape1T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 262656 q12Shape1T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 (262656 ||| 2^24) q12Shape1T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (134144 ||| 2^24) 262656 q12Shape1T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T66OK,q12Shape1T71OK⟩

private def q12Shape1T75 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {2,3,4,7,9,10,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 396288 103095992832 q12Shape1T75=true := by decide

private def q12Shape1T76 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {2,3,4,7,8,10,11}))) (.tip (.cover {2,3,4,8,9,10,11})))
private theorem q12Shape1T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68719873024 34376516096 q12Shape1T76=true := by decide

private def q12Shape1T74 : Tree 12 := .split 36 q12Shape1T75 q12Shape1T76
private theorem q12Shape1T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 396288 34376516096 q12Shape1T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 396288 (34376516096 ||| 2^36) q12Shape1T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (396288 ||| 2^36) 34376516096 q12Shape1T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T75OK,q12Shape1T76OK⟩

private def q12Shape1T77 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {2,3,4,7,9,10,11}))) (.tip (.cover {2,3,4,7,9,10,11}))) (.tip (.cover {2,3,4,8,9,10,11}))) (.tip (.cover {2,3,4,8,9,10,11})))
private theorem q12Shape1T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34360134656 16777728 q12Shape1T77=true := by decide

private def q12Shape1T73 : Tree 12 := .split 35 q12Shape1T74 q12Shape1T77
private theorem q12Shape1T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 396288 16777728 q12Shape1T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 396288 (16777728 ||| 2^35) q12Shape1T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (396288 ||| 2^35) 16777728 q12Shape1T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T74OK,q12Shape1T77OK⟩

private def q12Shape1T78 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape1T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17173504 512 q12Shape1T78=true := by decide

private def q12Shape1T72 : Tree 12 := .split 24 q12Shape1T73 q12Shape1T78
private theorem q12Shape1T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 396288 512 q12Shape1T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 396288 (512 ||| 2^24) q12Shape1T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (396288 ||| 2^24) 512 q12Shape1T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T73OK,q12Shape1T78OK⟩

private def q12Shape1T64 : Tree 12 := .split 18 q12Shape1T65 q12Shape1T72
private theorem q12Shape1T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 512 q12Shape1T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 134144 (512 ||| 2^18) q12Shape1T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (134144 ||| 2^18) 512 q12Shape1T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T65OK,q12Shape1T72OK⟩

private def q12Shape1T48 : Tree 12 := .split 17 q12Shape1T49 q12Shape1T64
private theorem q12Shape1T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 512 q12Shape1T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 (512 ||| 2^17) q12Shape1T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (3072 ||| 2^17) 512 q12Shape1T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T49OK,q12Shape1T64OK⟩

def q12Shape1P2 : Tree 12 := q12Shape1T48
theorem q12Shape1P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 3072 512 q12Shape1P2=true := q12Shape1T48OK

end Graffiti384b.EffectiveSearch.Q12
