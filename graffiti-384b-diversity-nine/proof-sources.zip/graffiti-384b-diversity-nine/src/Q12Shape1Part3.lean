import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape1T83 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 396288 q12Shape1T83=true := by decide

private def q12Shape1T85 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 262656 16911360 q12Shape1T85=true := by decide

private def q12Shape1T88 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape1T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17039872 103079349248 q12Shape1T88=true := by decide

private def q12Shape1T89 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape1T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736516608 34359872512 q12Shape1T89=true := by decide

private def q12Shape1T87 : Tree 12 := .split 36 q12Shape1T88 q12Shape1T89
private theorem q12Shape1T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17039872 34359872512 q12Shape1T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17039872 (34359872512 ||| 2^36) q12Shape1T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (17039872 ||| 2^36) 34359872512 q12Shape1T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T88OK,q12Shape1T89OK⟩

private def q12Shape1T90 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape1T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376778240 134144 q12Shape1T90=true := by decide

private def q12Shape1T86 : Tree 12 := .split 35 q12Shape1T87 q12Shape1T90
private theorem q12Shape1T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17039872 134144 q12Shape1T86=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17039872 (134144 ||| 2^35) q12Shape1T87 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (17039872 ||| 2^35) 134144 q12Shape1T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T87OK,q12Shape1T90OK⟩

private def q12Shape1T84 : Tree 12 := .split 24 q12Shape1T85 q12Shape1T86
private theorem q12Shape1T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 262656 134144 q12Shape1T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 262656 (134144 ||| 2^24) q12Shape1T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (262656 ||| 2^24) 134144 q12Shape1T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T85OK,q12Shape1T86OK⟩

private def q12Shape1T82 : Tree 12 := .split 18 q12Shape1T83 q12Shape1T84
private theorem q12Shape1T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 134144 q12Shape1T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 (134144 ||| 2^18) q12Shape1T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (512 ||| 2^18) 134144 q12Shape1T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T83OK,q12Shape1T84OK⟩

private def q12Shape1T93 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131584 17042432 q12Shape1T93=true := by decide

private def q12Shape1T96 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape1T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16908800 103079480320 q12Shape1T96=true := by decide

private def q12Shape1T97 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape1T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736385536 34360003584 q12Shape1T97=true := by decide

private def q12Shape1T95 : Tree 12 := .split 36 q12Shape1T96 q12Shape1T97
private theorem q12Shape1T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16908800 34360003584 q12Shape1T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16908800 (34360003584 ||| 2^36) q12Shape1T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16908800 ||| 2^36) 34360003584 q12Shape1T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T96OK,q12Shape1T97OK⟩

private def q12Shape1T98 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape1T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376647168 265216 q12Shape1T98=true := by decide

private def q12Shape1T94 : Tree 12 := .split 35 q12Shape1T95 q12Shape1T98
private theorem q12Shape1T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16908800 265216 q12Shape1T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16908800 (265216 ||| 2^35) q12Shape1T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16908800 ||| 2^35) 265216 q12Shape1T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T95OK,q12Shape1T98OK⟩

private def q12Shape1T92 : Tree 12 := .split 24 q12Shape1T93 q12Shape1T94
private theorem q12Shape1T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131584 265216 q12Shape1T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131584 (265216 ||| 2^24) q12Shape1T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (131584 ||| 2^24) 265216 q12Shape1T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T93OK,q12Shape1T94OK⟩

private def q12Shape1T100 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape1T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 393728 16780288 q12Shape1T100=true := by decide

private def q12Shape1T101 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape1T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17170944 3072 q12Shape1T101=true := by decide

private def q12Shape1T99 : Tree 12 := .split 24 q12Shape1T100 q12Shape1T101
private theorem q12Shape1T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 393728 3072 q12Shape1T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 393728 (3072 ||| 2^24) q12Shape1T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (393728 ||| 2^24) 3072 q12Shape1T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T100OK,q12Shape1T101OK⟩

private def q12Shape1T91 : Tree 12 := .split 18 q12Shape1T92 q12Shape1T99
private theorem q12Shape1T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131584 3072 q12Shape1T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 131584 (3072 ||| 2^18) q12Shape1T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (131584 ||| 2^18) 3072 q12Shape1T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T92OK,q12Shape1T99OK⟩

private def q12Shape1T81 : Tree 12 := .split 17 q12Shape1T82 q12Shape1T91
private theorem q12Shape1T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 3072 q12Shape1T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 (3072 ||| 2^17) q12Shape1T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (512 ||| 2^17) 3072 q12Shape1T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T82OK,q12Shape1T91OK⟩

def q12Shape1P3 : Tree 12 := q12Shape1T81
theorem q12Shape1P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 512 3072 q12Shape1P3=true := q12Shape1T81OK

end Graffiti384b.EffectiveSearch.Q12
