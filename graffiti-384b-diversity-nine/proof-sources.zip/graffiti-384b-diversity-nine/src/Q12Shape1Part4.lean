import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape1T105 : Tree 12 := (.tip (.small 0))
private theorem q12Shape1T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 17171456 q12Shape1T105=true := by decide

private def q12Shape1T108 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape1T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16779776 103079609344 q12Shape1T108=true := by decide

private def q12Shape1T109 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape1T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736256512 34360132608 q12Shape1T109=true := by decide

private def q12Shape1T107 : Tree 12 := .split 36 q12Shape1T108 q12Shape1T109
private theorem q12Shape1T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16779776 34360132608 q12Shape1T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16779776 (34360132608 ||| 2^36) q12Shape1T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16779776 ||| 2^36) 34360132608 q12Shape1T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T108OK,q12Shape1T109OK⟩

private def q12Shape1T110 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape1T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376518144 394240 q12Shape1T110=true := by decide

private def q12Shape1T106 : Tree 12 := .split 35 q12Shape1T107 q12Shape1T110
private theorem q12Shape1T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16779776 394240 q12Shape1T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16779776 (394240 ||| 2^35) q12Shape1T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16779776 ||| 2^35) 394240 q12Shape1T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T107OK,q12Shape1T110OK⟩

private def q12Shape1T104 : Tree 12 := .split 24 q12Shape1T105 q12Shape1T106
private theorem q12Shape1T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 394240 q12Shape1T104=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 (394240 ||| 2^24) q12Shape1T105 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (2560 ||| 2^24) 394240 q12Shape1T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T105OK,q12Shape1T106OK⟩

private def q12Shape1T114 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape1T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 264704 103096124416 q12Shape1T114=true := by decide

private def q12Shape1T115 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape1T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68719741440 34376647680 q12Shape1T115=true := by decide

private def q12Shape1T113 : Tree 12 := .split 36 q12Shape1T114 q12Shape1T115
private theorem q12Shape1T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 264704 34376647680 q12Shape1T113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 264704 (34376647680 ||| 2^36) q12Shape1T114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (264704 ||| 2^36) 34376647680 q12Shape1T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T114OK,q12Shape1T115OK⟩

private def q12Shape1T116 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape1T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34360003072 16909312 q12Shape1T116=true := by decide

private def q12Shape1T112 : Tree 12 := .split 35 q12Shape1T113 q12Shape1T116
private theorem q12Shape1T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 264704 16909312 q12Shape1T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 264704 (16909312 ||| 2^35) q12Shape1T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (264704 ||| 2^35) 16909312 q12Shape1T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T113OK,q12Shape1T116OK⟩

private def q12Shape1T117 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape1T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17041920 132096 q12Shape1T117=true := by decide

private def q12Shape1T111 : Tree 12 := .split 24 q12Shape1T112 q12Shape1T117
private theorem q12Shape1T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 264704 132096 q12Shape1T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 264704 (132096 ||| 2^24) q12Shape1T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (264704 ||| 2^24) 132096 q12Shape1T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T112OK,q12Shape1T117OK⟩

private def q12Shape1T103 : Tree 12 := .split 18 q12Shape1T104 q12Shape1T111
private theorem q12Shape1T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 132096 q12Shape1T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 (132096 ||| 2^18) q12Shape1T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (2560 ||| 2^18) 132096 q12Shape1T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T104OK,q12Shape1T111OK⟩

private def q12Shape1T122 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 103096255488 q12Shape1T122=true := by decide

private def q12Shape1T123 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape1T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68719610368 34376778752 q12Shape1T123=true := by decide

private def q12Shape1T121 : Tree 12 := .split 36 q12Shape1T122 q12Shape1T123
private theorem q12Shape1T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 34376778752 q12Shape1T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 (34376778752 ||| 2^36) q12Shape1T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (133632 ||| 2^36) 34376778752 q12Shape1T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T122OK,q12Shape1T123OK⟩

private def q12Shape1T124 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape1T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34359872000 17040384 q12Shape1T124=true := by decide

private def q12Shape1T120 : Tree 12 := .split 35 q12Shape1T121 q12Shape1T124
private theorem q12Shape1T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 17040384 q12Shape1T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 (17040384 ||| 2^35) q12Shape1T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (133632 ||| 2^35) 17040384 q12Shape1T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T121OK,q12Shape1T124OK⟩

private def q12Shape1T127 : Tree 12 := (.split 37 (.split 39 (.tip (.small 1)) (.split 40 (.tip (.small 1)) (.tip (.cover {2,3,5,7,9,10,11})))) (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape1T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910848 103079478272 q12Shape1T127=true := by decide

private def q12Shape1T128 : Tree 12 := (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {2,3,5,8,9,10,11})))
private theorem q12Shape1T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 68736387584 34360001536 q12Shape1T128=true := by decide

private def q12Shape1T126 : Tree 12 := .split 36 q12Shape1T127 q12Shape1T128
private theorem q12Shape1T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910848 34360001536 q12Shape1T126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910848 (34360001536 ||| 2^36) q12Shape1T127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16910848 ||| 2^36) 34360001536 q12Shape1T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T127OK,q12Shape1T128OK⟩

private def q12Shape1T129 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {2,3,5,8,9,10,11}))) (.tip (.cover {2,3,5,8,9,10,11})))
private theorem q12Shape1T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 34376649216 263168 q12Shape1T129=true := by decide

private def q12Shape1T125 : Tree 12 := .split 35 q12Shape1T126 q12Shape1T129
private theorem q12Shape1T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910848 263168 q12Shape1T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 16910848 (263168 ||| 2^35) q12Shape1T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (16910848 ||| 2^35) 263168 q12Shape1T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T126OK,q12Shape1T129OK⟩

private def q12Shape1T119 : Tree 12 := .split 24 q12Shape1T120 q12Shape1T125
private theorem q12Shape1T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 263168 q12Shape1T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 (263168 ||| 2^24) q12Shape1T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (133632 ||| 2^24) 263168 q12Shape1T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T120OK,q12Shape1T125OK⟩

private def q12Shape1T131 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape1T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395776 16778240 q12Shape1T131=true := by decide

private def q12Shape1T132 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape1T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 17172992 1024 q12Shape1T132=true := by decide

private def q12Shape1T130 : Tree 12 := .split 24 q12Shape1T131 q12Shape1T132
private theorem q12Shape1T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395776 1024 q12Shape1T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 395776 (1024 ||| 2^24) q12Shape1T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (395776 ||| 2^24) 1024 q12Shape1T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T131OK,q12Shape1T132OK⟩

private def q12Shape1T118 : Tree 12 := .split 18 q12Shape1T119 q12Shape1T130
private theorem q12Shape1T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 1024 q12Shape1T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 133632 (1024 ||| 2^18) q12Shape1T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (133632 ||| 2^18) 1024 q12Shape1T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T119OK,q12Shape1T130OK⟩

private def q12Shape1T102 : Tree 12 := .split 17 q12Shape1T103 q12Shape1T118
private theorem q12Shape1T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 1024 q12Shape1T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 (1024 ||| 2^17) q12Shape1T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) (2560 ||| 2^17) 1024 q12Shape1T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape1T103OK,q12Shape1T118OK⟩

def q12Shape1P4 : Tree 12 := q12Shape1T102
theorem q12Shape1P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,1⟩) 2560 1024 q12Shape1P4=true := q12Shape1T102OK

end Graffiti384b.EffectiveSearch.Q12
