import Q12Shape20Part0
import Q12Shape20Part1
import Q12Shape20Part2
import Q12Shape20Part3
import Q12Shape20Part4
import Q12Shape20Part5
import Q12Shape20Part6
import Q12Shape20Part7

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape20M30 : Tree 12 := .split 2 q12Shape20P0 q12Shape20P1
private theorem q12Shape20M30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 0 3 q12Shape20M30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 0 (3 ||| 2^2) q12Shape20P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (0 ||| 2^2) 3 q12Shape20P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20P0OK,q12Shape20P1OK⟩
private def q12Shape20M61 : Tree 12 := .split 2 q12Shape20P2 q12Shape20P3
private theorem q12Shape20M61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 1 q12Shape20M61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 (1 ||| 2^2) q12Shape20P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (2 ||| 2^2) 1 q12Shape20P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20P2OK,q12Shape20P3OK⟩
private def q12Shape20M62 : Tree 12 := .split 1 q12Shape20M30 q12Shape20M61
private theorem q12Shape20M62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 0 1 q12Shape20M62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 0 (1 ||| 2^1) q12Shape20M30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (0 ||| 2^1) 1 q12Shape20M61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20M30OK,q12Shape20M61OK⟩
private def q12Shape20M93 : Tree 12 := .split 2 q12Shape20P4 q12Shape20P5
private theorem q12Shape20M93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1 2 q12Shape20M93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1 (2 ||| 2^2) q12Shape20P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1 ||| 2^2) 2 q12Shape20P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20P4OK,q12Shape20P5OK⟩
private def q12Shape20M124 : Tree 12 := .split 2 q12Shape20P6 q12Shape20P7
private theorem q12Shape20M124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 3 0 q12Shape20M124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 3 (0 ||| 2^2) q12Shape20P6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (3 ||| 2^2) 0 q12Shape20P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20P6OK,q12Shape20P7OK⟩
private def q12Shape20M125 : Tree 12 := .split 1 q12Shape20M93 q12Shape20M124
private theorem q12Shape20M125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1 0 q12Shape20M125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1 (0 ||| 2^1) q12Shape20M93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1 ||| 2^1) 0 q12Shape20M124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20M93OK,q12Shape20M124OK⟩
private def q12Shape20M126 : Tree 12 := .split 0 q12Shape20M62 q12Shape20M125
private theorem q12Shape20M126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 0 0 q12Shape20M126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 0 (0 ||| 2^0) q12Shape20M62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (0 ||| 2^0) 0 q12Shape20M125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20M62OK,q12Shape20M125OK⟩

theorem q12Shape20_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 20) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 20) b) (adj 12 (forms 20) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) adj_mono b H q12Shape20M126 q12Shape20M126OK

#print axioms q12Shape20_cover

end Graffiti384b.EffectiveSearch.Q12
