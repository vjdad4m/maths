import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape20T18 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 132611 q12Shape20T18=true := by decide

private def q12Shape20T19 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131076 1539 q12Shape20T19=true := by decide

private def q12Shape20T17 : Tree 12 := .split 17 q12Shape20T18 q12Shape20T19
private theorem q12Shape20T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 1539 q12Shape20T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 (1539 ||| 2^17) q12Shape20T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (4 ||| 2^17) 1539 q12Shape20T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T18OK,q12Shape20T19OK⟩

private def q12Shape20T21 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1028 131587 q12Shape20T21=true := by decide

private def q12Shape20T22 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132100 515 q12Shape20T22=true := by decide

private def q12Shape20T20 : Tree 12 := .split 17 q12Shape20T21 q12Shape20T22
private theorem q12Shape20T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1028 515 q12Shape20T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1028 (515 ||| 2^17) q12Shape20T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1028 ||| 2^17) 515 q12Shape20T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T21OK,q12Shape20T22OK⟩

private def q12Shape20T16 : Tree 12 := .split 10 q12Shape20T17 q12Shape20T20
private theorem q12Shape20T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 515 q12Shape20T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 (515 ||| 2^10) q12Shape20T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (4 ||| 2^10) 515 q12Shape20T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T17OK,q12Shape20T20OK⟩

private def q12Shape20T25 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 516 132099 q12Shape20T25=true := by decide

private def q12Shape20T26 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131588 1027 q12Shape20T26=true := by decide

private def q12Shape20T24 : Tree 12 := .split 17 q12Shape20T25 q12Shape20T26
private theorem q12Shape20T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 516 1027 q12Shape20T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 516 (1027 ||| 2^17) q12Shape20T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (516 ||| 2^17) 1027 q12Shape20T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T25OK,q12Shape20T26OK⟩

private def q12Shape20T28 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1540 131075 q12Shape20T28=true := by decide

private def q12Shape20T29 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132612 3 q12Shape20T29=true := by decide

private def q12Shape20T27 : Tree 12 := .split 17 q12Shape20T28 q12Shape20T29
private theorem q12Shape20T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1540 3 q12Shape20T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1540 (3 ||| 2^17) q12Shape20T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1540 ||| 2^17) 3 q12Shape20T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T28OK,q12Shape20T29OK⟩

private def q12Shape20T23 : Tree 12 := .split 10 q12Shape20T24 q12Shape20T27
private theorem q12Shape20T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 516 3 q12Shape20T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 516 (3 ||| 2^10) q12Shape20T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (516 ||| 2^10) 3 q12Shape20T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T24OK,q12Shape20T27OK⟩

private def q12Shape20T15 : Tree 12 := .split 9 q12Shape20T16 q12Shape20T23
private theorem q12Shape20T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 3 q12Shape20T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 (3 ||| 2^9) q12Shape20T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (4 ||| 2^9) 3 q12Shape20T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T16OK,q12Shape20T23OK⟩

def q12Shape20P1 : Tree 12 := q12Shape20T15
theorem q12Shape20P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 4 3 q12Shape20P1=true := q12Shape20T15OK

end Graffiti384b.EffectiveSearch.Q12
