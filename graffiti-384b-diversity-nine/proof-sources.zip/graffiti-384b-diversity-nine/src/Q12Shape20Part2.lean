import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape20T34 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 132613 q12Shape20T34=true := by decide

private def q12Shape20T35 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131074 1541 q12Shape20T35=true := by decide

private def q12Shape20T33 : Tree 12 := .split 17 q12Shape20T34 q12Shape20T35
private theorem q12Shape20T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 1541 q12Shape20T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 (1541 ||| 2^17) q12Shape20T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (2 ||| 2^17) 1541 q12Shape20T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T34OK,q12Shape20T35OK⟩

private def q12Shape20T37 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1026 131589 q12Shape20T37=true := by decide

private def q12Shape20T38 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132098 517 q12Shape20T38=true := by decide

private def q12Shape20T36 : Tree 12 := .split 17 q12Shape20T37 q12Shape20T38
private theorem q12Shape20T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1026 517 q12Shape20T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1026 (517 ||| 2^17) q12Shape20T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1026 ||| 2^17) 517 q12Shape20T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T37OK,q12Shape20T38OK⟩

private def q12Shape20T32 : Tree 12 := .split 10 q12Shape20T33 q12Shape20T36
private theorem q12Shape20T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 517 q12Shape20T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 (517 ||| 2^10) q12Shape20T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (2 ||| 2^10) 517 q12Shape20T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T33OK,q12Shape20T36OK⟩

private def q12Shape20T41 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 514 132101 q12Shape20T41=true := by decide

private def q12Shape20T42 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131586 1029 q12Shape20T42=true := by decide

private def q12Shape20T40 : Tree 12 := .split 17 q12Shape20T41 q12Shape20T42
private theorem q12Shape20T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 514 1029 q12Shape20T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 514 (1029 ||| 2^17) q12Shape20T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (514 ||| 2^17) 1029 q12Shape20T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T41OK,q12Shape20T42OK⟩

private def q12Shape20T44 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1538 131077 q12Shape20T44=true := by decide

private def q12Shape20T45 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132610 5 q12Shape20T45=true := by decide

private def q12Shape20T43 : Tree 12 := .split 17 q12Shape20T44 q12Shape20T45
private theorem q12Shape20T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1538 5 q12Shape20T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1538 (5 ||| 2^17) q12Shape20T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1538 ||| 2^17) 5 q12Shape20T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T44OK,q12Shape20T45OK⟩

private def q12Shape20T39 : Tree 12 := .split 10 q12Shape20T40 q12Shape20T43
private theorem q12Shape20T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 514 5 q12Shape20T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 514 (5 ||| 2^10) q12Shape20T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (514 ||| 2^10) 5 q12Shape20T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T40OK,q12Shape20T43OK⟩

private def q12Shape20T31 : Tree 12 := .split 9 q12Shape20T32 q12Shape20T39
private theorem q12Shape20T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 5 q12Shape20T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 (5 ||| 2^9) q12Shape20T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (2 ||| 2^9) 5 q12Shape20T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T32OK,q12Shape20T39OK⟩

def q12Shape20P2 : Tree 12 := q12Shape20T31
theorem q12Shape20P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 2 5 q12Shape20P2=true := q12Shape20T31OK

end Graffiti384b.EffectiveSearch.Q12
