import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape20T49 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 132609 q12Shape20T49=true := by decide

private def q12Shape20T50 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131078 1537 q12Shape20T50=true := by decide

private def q12Shape20T48 : Tree 12 := .split 17 q12Shape20T49 q12Shape20T50
private theorem q12Shape20T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 1537 q12Shape20T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 (1537 ||| 2^17) q12Shape20T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (6 ||| 2^17) 1537 q12Shape20T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T49OK,q12Shape20T50OK⟩

private def q12Shape20T52 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1030 131585 q12Shape20T52=true := by decide

private def q12Shape20T53 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132102 513 q12Shape20T53=true := by decide

private def q12Shape20T51 : Tree 12 := .split 17 q12Shape20T52 q12Shape20T53
private theorem q12Shape20T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1030 513 q12Shape20T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1030 (513 ||| 2^17) q12Shape20T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1030 ||| 2^17) 513 q12Shape20T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T52OK,q12Shape20T53OK⟩

private def q12Shape20T47 : Tree 12 := .split 10 q12Shape20T48 q12Shape20T51
private theorem q12Shape20T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 513 q12Shape20T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 (513 ||| 2^10) q12Shape20T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (6 ||| 2^10) 513 q12Shape20T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T48OK,q12Shape20T51OK⟩

private def q12Shape20T56 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 518 132097 q12Shape20T56=true := by decide

private def q12Shape20T57 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131590 1025 q12Shape20T57=true := by decide

private def q12Shape20T55 : Tree 12 := .split 17 q12Shape20T56 q12Shape20T57
private theorem q12Shape20T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 518 1025 q12Shape20T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 518 (1025 ||| 2^17) q12Shape20T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (518 ||| 2^17) 1025 q12Shape20T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T56OK,q12Shape20T57OK⟩

private def q12Shape20T59 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1542 131073 q12Shape20T59=true := by decide

private def q12Shape20T60 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132614 1 q12Shape20T60=true := by decide

private def q12Shape20T58 : Tree 12 := .split 17 q12Shape20T59 q12Shape20T60
private theorem q12Shape20T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1542 1 q12Shape20T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1542 (1 ||| 2^17) q12Shape20T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1542 ||| 2^17) 1 q12Shape20T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T59OK,q12Shape20T60OK⟩

private def q12Shape20T54 : Tree 12 := .split 10 q12Shape20T55 q12Shape20T58
private theorem q12Shape20T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 518 1 q12Shape20T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 518 (1 ||| 2^10) q12Shape20T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (518 ||| 2^10) 1 q12Shape20T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T55OK,q12Shape20T58OK⟩

private def q12Shape20T46 : Tree 12 := .split 9 q12Shape20T47 q12Shape20T54
private theorem q12Shape20T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 1 q12Shape20T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 (1 ||| 2^9) q12Shape20T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (6 ||| 2^9) 1 q12Shape20T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T47OK,q12Shape20T54OK⟩

def q12Shape20P3 : Tree 12 := q12Shape20T46
theorem q12Shape20P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 6 1 q12Shape20P3=true := q12Shape20T46OK

end Graffiti384b.EffectiveSearch.Q12
