import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape20T81 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 132610 q12Shape20T81=true := by decide

private def q12Shape20T82 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131077 1538 q12Shape20T82=true := by decide

private def q12Shape20T80 : Tree 12 := .split 17 q12Shape20T81 q12Shape20T82
private theorem q12Shape20T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 1538 q12Shape20T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 (1538 ||| 2^17) q12Shape20T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (5 ||| 2^17) 1538 q12Shape20T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T81OK,q12Shape20T82OK⟩

private def q12Shape20T84 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1029 131586 q12Shape20T84=true := by decide

private def q12Shape20T85 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132101 514 q12Shape20T85=true := by decide

private def q12Shape20T83 : Tree 12 := .split 17 q12Shape20T84 q12Shape20T85
private theorem q12Shape20T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1029 514 q12Shape20T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1029 (514 ||| 2^17) q12Shape20T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1029 ||| 2^17) 514 q12Shape20T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T84OK,q12Shape20T85OK⟩

private def q12Shape20T79 : Tree 12 := .split 10 q12Shape20T80 q12Shape20T83
private theorem q12Shape20T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 514 q12Shape20T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 (514 ||| 2^10) q12Shape20T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (5 ||| 2^10) 514 q12Shape20T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T80OK,q12Shape20T83OK⟩

private def q12Shape20T88 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 517 132098 q12Shape20T88=true := by decide

private def q12Shape20T89 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 131589 1026 q12Shape20T89=true := by decide

private def q12Shape20T87 : Tree 12 := .split 17 q12Shape20T88 q12Shape20T89
private theorem q12Shape20T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 517 1026 q12Shape20T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 517 (1026 ||| 2^17) q12Shape20T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (517 ||| 2^17) 1026 q12Shape20T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T88OK,q12Shape20T89OK⟩

private def q12Shape20T91 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1541 131074 q12Shape20T91=true := by decide

private def q12Shape20T92 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape20T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 132613 2 q12Shape20T92=true := by decide

private def q12Shape20T90 : Tree 12 := .split 17 q12Shape20T91 q12Shape20T92
private theorem q12Shape20T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1541 2 q12Shape20T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 1541 (2 ||| 2^17) q12Shape20T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (1541 ||| 2^17) 2 q12Shape20T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T91OK,q12Shape20T92OK⟩

private def q12Shape20T86 : Tree 12 := .split 10 q12Shape20T87 q12Shape20T90
private theorem q12Shape20T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 517 2 q12Shape20T86=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 517 (2 ||| 2^10) q12Shape20T87 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (517 ||| 2^10) 2 q12Shape20T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T87OK,q12Shape20T90OK⟩

private def q12Shape20T78 : Tree 12 := .split 9 q12Shape20T79 q12Shape20T86
private theorem q12Shape20T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 2 q12Shape20T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 (2 ||| 2^9) q12Shape20T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) (5 ||| 2^9) 2 q12Shape20T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape20T79OK,q12Shape20T86OK⟩

def q12Shape20P5 : Tree 12 := q12Shape20T78
theorem q12Shape20P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,8,6,4⟩) 5 2 q12Shape20P5=true := q12Shape20T78OK

end Graffiti384b.EffectiveSearch.Q12
