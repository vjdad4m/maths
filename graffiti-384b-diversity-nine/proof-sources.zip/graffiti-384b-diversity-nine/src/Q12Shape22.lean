import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape22T0 : Tree 12 := (.tip (.small 0))
private theorem q12Shape22T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 (forms 22)) 0 0 q12Shape22T0=true := by decide


theorem q12Shape22_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 22) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 22) b) (adj 12 (forms 22) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 (forms 22)) adj_mono b H q12Shape22T0 q12Shape22T0OK

#print axioms q12Shape22_cover
end Graffiti384b.EffectiveSearch.Q12
