import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape23T0 : Tree 12 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,6,9,10,11})))))))
private theorem q12Shape23T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 (forms 23)) 0 0 q12Shape23T0=true := by decide


theorem q12Shape23_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 23) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 23) b) (adj 12 (forms 23) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 (forms 23)) adj_mono b H q12Shape23T0 q12Shape23T0OK

#print axioms q12Shape23_cover
end Graffiti384b.EffectiveSearch.Q12
