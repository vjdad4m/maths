import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape24T2 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))))
private theorem q12Shape24T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 0 1073872896 q12Shape24T2=true := by decide

private def q12Shape24T3 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))))))
private theorem q12Shape24T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073741824 131072 q12Shape24T3=true := by decide

private def q12Shape24T1 : Tree 12 := .split 30 q12Shape24T2 q12Shape24T3
private theorem q12Shape24T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 0 131072 q12Shape24T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 0 (131072 ||| 2^30) q12Shape24T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (0 ||| 2^30) 131072 q12Shape24T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T2OK,q12Shape24T3OK⟩

private def q12Shape24T6 : Tree 12 := (.tip (.small 1))
private theorem q12Shape24T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131072 1073741825 q12Shape24T6=true := by decide

private def q12Shape24T8 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,4,8,9,10,11})))))
private theorem q12Shape24T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131073 1073741826 q12Shape24T8=true := by decide

private def q12Shape24T9 : Tree 12 := (.split 2 (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,5,8,9,10,11})))) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))
private theorem q12Shape24T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131075 1073741824 q12Shape24T9=true := by decide

private def q12Shape24T7 : Tree 12 := .split 1 q12Shape24T8 q12Shape24T9
private theorem q12Shape24T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131073 1073741824 q12Shape24T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131073 (1073741824 ||| 2^1) q12Shape24T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (131073 ||| 2^1) 1073741824 q12Shape24T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T8OK,q12Shape24T9OK⟩

private def q12Shape24T5 : Tree 12 := .split 0 q12Shape24T6 q12Shape24T7
private theorem q12Shape24T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131072 1073741824 q12Shape24T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131072 (1073741824 ||| 2^0) q12Shape24T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (131072 ||| 2^0) 1073741824 q12Shape24T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T6OK,q12Shape24T7OK⟩

private def q12Shape24T11 : Tree 12 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))))
private theorem q12Shape24T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872896 1 q12Shape24T11=true := by decide

private def q12Shape24T13 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.split 4 (.tip (.small 1)) (.split 9 (.tip (.small 0)) (.tip (.cover {2,4,6,8,9,10,11})))) (.split 4 (.split 9 (.tip (.small 0)) (.tip (.cover {2,4,7,8,9,10,11}))) (.tip (.cover {1,2,4,8,9,10,11})))))
private theorem q12Shape24T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872897 2 q12Shape24T13=true := by decide

private def q12Shape24T15 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {2,5,6,8,9,10,11}))))) (.split 4 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10,11})))) (.tip (.cover {1,2,5,8,9,10,11}))))
private theorem q12Shape24T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872899 4 q12Shape24T15=true := by decide

private def q12Shape24T16 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape24T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872903 0 q12Shape24T16=true := by decide

private def q12Shape24T14 : Tree 12 := .split 2 q12Shape24T15 q12Shape24T16
private theorem q12Shape24T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872899 0 q12Shape24T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872899 (0 ||| 2^2) q12Shape24T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (1073872899 ||| 2^2) 0 q12Shape24T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T15OK,q12Shape24T16OK⟩

private def q12Shape24T12 : Tree 12 := .split 1 q12Shape24T13 q12Shape24T14
private theorem q12Shape24T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872897 0 q12Shape24T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872897 (0 ||| 2^1) q12Shape24T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (1073872897 ||| 2^1) 0 q12Shape24T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T13OK,q12Shape24T14OK⟩

private def q12Shape24T10 : Tree 12 := .split 0 q12Shape24T11 q12Shape24T12
private theorem q12Shape24T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872896 0 q12Shape24T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 1073872896 (0 ||| 2^0) q12Shape24T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (1073872896 ||| 2^0) 0 q12Shape24T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T11OK,q12Shape24T12OK⟩

private def q12Shape24T4 : Tree 12 := .split 30 q12Shape24T5 q12Shape24T10
private theorem q12Shape24T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131072 0 q12Shape24T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 131072 (0 ||| 2^30) q12Shape24T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (131072 ||| 2^30) 0 q12Shape24T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T5OK,q12Shape24T10OK⟩

private def q12Shape24T0 : Tree 12 := .split 17 q12Shape24T1 q12Shape24T4
private theorem q12Shape24T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 0 0 q12Shape24T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 0 (0 ||| 2^17) q12Shape24T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) (0 ||| 2^17) 0 q12Shape24T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape24T1OK,q12Shape24T4OK⟩

def q12Shape24P0 : Tree 12 := q12Shape24T0
theorem q12Shape24P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,2⟩) 0 0 q12Shape24P0=true := q12Shape24T0OK

end Graffiti384b.EffectiveSearch.Q12
