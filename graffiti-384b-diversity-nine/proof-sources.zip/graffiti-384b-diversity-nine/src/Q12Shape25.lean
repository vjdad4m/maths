import Q12Shape25Part0
import Q12Shape25Part1
import Q12Shape25Part2
import Q12Shape25Part3
import Q12Shape25Part4
import Q12Shape25Part5
import Q12Shape25Part6
import Q12Shape25Part7
import Q12Shape25Part8
import Q12Shape25Part9
import Q12Shape25Part10
import Q12Shape25Part11
import Q12Shape25Part12
import Q12Shape25Part13
import Q12Shape25Part14
import Q12Shape25Part15
import Q12Shape25Part16
import Q12Shape25Part17
import Q12Shape25Part18
import Q12Shape25Part19
import Q12Shape25Part20
import Q12Shape25Part21
import Q12Shape25Part22
import Q12Shape25Part23
import Q12Shape25Part24
import Q12Shape25Part25
import Q12Shape25Part26
import Q12Shape25Part27
import Q12Shape25Part28
import Q12Shape25Part29
import Q12Shape25Part30
import Q12Shape25Part31
import Q12Shape25Part32
import Q12Shape25Part33
import Q12Shape25Part34
import Q12Shape25Part35
import Q12Shape25Part36

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25M80 : Tree 12 := .split 37 q12Shape25P0 q12Shape25P1
private theorem q12Shape25M80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 137422176256 q12Shape25M80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (137422176256 ||| 2^37) q12Shape25P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^37) 137422176256 q12Shape25P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P0OK,q12Shape25P1OK⟩
private def q12Shape25M167 : Tree 12 := .split 37 q12Shape25P2 q12Shape25P3
private theorem q12Shape25M167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 68702699520 q12Shape25M167=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 (68702699520 ||| 2^37) q12Shape25P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (68719476736 ||| 2^37) 68702699520 q12Shape25P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P2OK,q12Shape25P3OK⟩
private def q12Shape25M168 : Tree 12 := .split 36 q12Shape25M80 q12Shape25M167
private theorem q12Shape25M168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 68702699520 q12Shape25M168=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (68702699520 ||| 2^36) q12Shape25M80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^36) 68702699520 q12Shape25M167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M80OK,q12Shape25M167OK⟩
private def q12Shape25M235 : Tree 12 := .split 38 q12Shape25P4 q12Shape25P5
private theorem q12Shape25M235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34359738368 240501391360 q12Shape25M235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34359738368 (240501391360 ||| 2^38) q12Shape25P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34359738368 ||| 2^38) 240501391360 q12Shape25P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P4OK,q12Shape25P5OK⟩
private def q12Shape25M283 : Tree 12 := .split 37 q12Shape25M235 q12Shape25P6
private theorem q12Shape25M283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34359738368 103062437888 q12Shape25M283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34359738368 (103062437888 ||| 2^37) q12Shape25M235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34359738368 ||| 2^37) 103062437888 q12Shape25P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M235OK,q12Shape25P6OK⟩
private def q12Shape25M340 : Tree 12 := .split 39 q12Shape25P7 q12Shape25P8
private theorem q12Shape25M340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103079215104 446659821568 q12Shape25M340=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103079215104 (446659821568 ||| 2^39) q12Shape25P7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (103079215104 ||| 2^39) 446659821568 q12Shape25P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P7OK,q12Shape25P8OK⟩
private def q12Shape25M346 : Tree 12 := .split 38 q12Shape25M340 q12Shape25P9
private theorem q12Shape25M346OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103079215104 171781914624 q12Shape25M346=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103079215104 (171781914624 ||| 2^38) q12Shape25M340 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (103079215104 ||| 2^38) 171781914624 q12Shape25P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M340OK,q12Shape25P9OK⟩
private def q12Shape25M358 : Tree 12 := .split 37 q12Shape25M346 q12Shape25P10
private theorem q12Shape25M358OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103079215104 34342961152 q12Shape25M358=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103079215104 (34342961152 ||| 2^37) q12Shape25M346 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (103079215104 ||| 2^37) 34342961152 q12Shape25P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M346OK,q12Shape25P10OK⟩
private def q12Shape25M359 : Tree 12 := .split 36 q12Shape25M283 q12Shape25M358
private theorem q12Shape25M359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34359738368 34342961152 q12Shape25M359=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34359738368 (34342961152 ||| 2^36) q12Shape25M283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34359738368 ||| 2^36) 34342961152 q12Shape25M358)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M283OK,q12Shape25M358OK⟩
private def q12Shape25M360 : Tree 12 := .split 35 q12Shape25M168 q12Shape25M359
private theorem q12Shape25M360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 34342961152 q12Shape25M360=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (34342961152 ||| 2^35) q12Shape25M168 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^35) 34342961152 q12Shape25M359)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M168OK,q12Shape25M359OK⟩
private def q12Shape25M370 : Tree 12 := .split 34 q12Shape25M360 q12Shape25P11
private theorem q12Shape25M370OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 17163091968 q12Shape25M370=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (17163091968 ||| 2^34) q12Shape25M360 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^34) 17163091968 q12Shape25P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M360OK,q12Shape25P11OK⟩
private def q12Shape25M382 : Tree 12 := .split 33 q12Shape25M370 q12Shape25P12
private theorem q12Shape25M382OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 8573157376 q12Shape25M382=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (8573157376 ||| 2^33) q12Shape25M370 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^33) 8573157376 q12Shape25P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M370OK,q12Shape25P12OK⟩
private def q12Shape25M404 : Tree 12 := .split 32 q12Shape25M382 q12Shape25P13
private theorem q12Shape25M404OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 4278190080 q12Shape25M404=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (4278190080 ||| 2^32) q12Shape25M382 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^32) 4278190080 q12Shape25P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M382OK,q12Shape25P13OK⟩
private def q12Shape25M451 : Tree 12 := .split 32 q12Shape25P14 q12Shape25P15
private theorem q12Shape25M451OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2147483648 2130706432 q12Shape25M451=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2147483648 (2130706432 ||| 2^32) q12Shape25P14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (2147483648 ||| 2^32) 2130706432 q12Shape25P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P14OK,q12Shape25P15OK⟩
private def q12Shape25M452 : Tree 12 := .split 31 q12Shape25M404 q12Shape25M451
private theorem q12Shape25M452OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 2130706432 q12Shape25M452=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (2130706432 ||| 2^31) q12Shape25M404 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^31) 2130706432 q12Shape25M451)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M404OK,q12Shape25M451OK⟩
private def q12Shape25M489 : Tree 12 := .split 34 q12Shape25P16 q12Shape25P17
private theorem q12Shape25M489OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 16089350144 q12Shape25M489=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 (16089350144 ||| 2^34) q12Shape25P16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1073741824 ||| 2^34) 16089350144 q12Shape25P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P16OK,q12Shape25P17OK⟩
private def q12Shape25M505 : Tree 12 := .split 33 q12Shape25M489 q12Shape25P18
private theorem q12Shape25M505OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 7499415552 q12Shape25M505=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 (7499415552 ||| 2^33) q12Shape25M489 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1073741824 ||| 2^33) 7499415552 q12Shape25P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M489OK,q12Shape25P18OK⟩
private def q12Shape25M529 : Tree 12 := .split 32 q12Shape25M505 q12Shape25P19
private theorem q12Shape25M529OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 3204448256 q12Shape25M529=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 (3204448256 ||| 2^32) q12Shape25M505 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1073741824 ||| 2^32) 3204448256 q12Shape25P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M505OK,q12Shape25P19OK⟩
private def q12Shape25M580 : Tree 12 := .split 32 q12Shape25P20 q12Shape25P21
private theorem q12Shape25M580OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 1056964608 q12Shape25M580=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 (1056964608 ||| 2^32) q12Shape25P20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3221225472 ||| 2^32) 1056964608 q12Shape25P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P20OK,q12Shape25P21OK⟩
private def q12Shape25M581 : Tree 12 := .split 31 q12Shape25M529 q12Shape25M580
private theorem q12Shape25M581OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 1056964608 q12Shape25M581=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1073741824 (1056964608 ||| 2^31) q12Shape25M529 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1073741824 ||| 2^31) 1056964608 q12Shape25M580)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M529OK,q12Shape25M580OK⟩
private def q12Shape25M582 : Tree 12 := .split 30 q12Shape25M452 q12Shape25M581
private theorem q12Shape25M582OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 1056964608 q12Shape25M582=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (1056964608 ||| 2^30) q12Shape25M452 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^30) 1056964608 q12Shape25M581)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M452OK,q12Shape25M581OK⟩
private def q12Shape25M602 : Tree 12 := .split 29 q12Shape25M582 q12Shape25P22
private theorem q12Shape25M602OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 520093696 q12Shape25M602=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (520093696 ||| 2^29) q12Shape25M582 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^29) 520093696 q12Shape25P22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M582OK,q12Shape25P22OK⟩
private def q12Shape25M624 : Tree 12 := .split 28 q12Shape25M602 q12Shape25P23
private theorem q12Shape25M624OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 251658240 q12Shape25M624=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (251658240 ||| 2^28) q12Shape25M602 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^28) 251658240 q12Shape25P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M602OK,q12Shape25P23OK⟩
private def q12Shape25M672 : Tree 12 := .split 27 q12Shape25M624 q12Shape25P24
private theorem q12Shape25M672OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 117440512 q12Shape25M672=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (117440512 ||| 2^27) q12Shape25M624 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^27) 117440512 q12Shape25P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M624OK,q12Shape25P24OK⟩
private def q12Shape25M789 : Tree 12 := .split 27 q12Shape25P25 q12Shape25P26
private theorem q12Shape25M789OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 50331648 q12Shape25M789=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (50331648 ||| 2^27) q12Shape25P25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^27) 50331648 q12Shape25P26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P25OK,q12Shape25P26OK⟩
private def q12Shape25M790 : Tree 12 := .split 26 q12Shape25M672 q12Shape25M789
private theorem q12Shape25M790OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 50331648 q12Shape25M790=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (50331648 ||| 2^26) q12Shape25M672 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^26) 50331648 q12Shape25M789)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M672OK,q12Shape25M789OK⟩
private def q12Shape25M847 : Tree 12 := .split 29 q12Shape25P27 q12Shape25P28
private theorem q12Shape25M847OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 486539264 q12Shape25M847=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (486539264 ||| 2^29) q12Shape25P27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^29) 486539264 q12Shape25P28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P27OK,q12Shape25P28OK⟩
private def q12Shape25M883 : Tree 12 := .split 28 q12Shape25M847 q12Shape25P29
private theorem q12Shape25M883OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 218103808 q12Shape25M883=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (218103808 ||| 2^28) q12Shape25M847 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^28) 218103808 q12Shape25P29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M847OK,q12Shape25P29OK⟩
private def q12Shape25M946 : Tree 12 := .split 28 q12Shape25P30 q12Shape25P31
private theorem q12Shape25M946OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 83886080 q12Shape25M946=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (83886080 ||| 2^28) q12Shape25P30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^28) 83886080 q12Shape25P31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P30OK,q12Shape25P31OK⟩
private def q12Shape25M947 : Tree 12 := .split 27 q12Shape25M883 q12Shape25M946
private theorem q12Shape25M947OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 83886080 q12Shape25M947=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (83886080 ||| 2^27) q12Shape25M883 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^27) 83886080 q12Shape25M946)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M883OK,q12Shape25M946OK⟩
private def q12Shape25M1014 : Tree 12 := .split 28 q12Shape25P32 q12Shape25P33
private theorem q12Shape25M1014OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 150994944 q12Shape25M1014=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (150994944 ||| 2^28) q12Shape25P32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^28) 150994944 q12Shape25P33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P32OK,q12Shape25P33OK⟩
private def q12Shape25M1077 : Tree 12 := .split 28 q12Shape25P34 q12Shape25P35
private theorem q12Shape25M1077OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 16777216 q12Shape25M1077=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (16777216 ||| 2^28) q12Shape25P34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^28) 16777216 q12Shape25P35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P34OK,q12Shape25P35OK⟩
private def q12Shape25M1078 : Tree 12 := .split 27 q12Shape25M1014 q12Shape25M1077
private theorem q12Shape25M1078OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 16777216 q12Shape25M1078=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (16777216 ||| 2^27) q12Shape25M1014 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^27) 16777216 q12Shape25M1077)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1014OK,q12Shape25M1077OK⟩
private def q12Shape25M1079 : Tree 12 := .split 26 q12Shape25M947 q12Shape25M1078
private theorem q12Shape25M1079OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 16777216 q12Shape25M1079=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (16777216 ||| 2^26) q12Shape25M947 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^26) 16777216 q12Shape25M1078)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M947OK,q12Shape25M1078OK⟩
private def q12Shape25M1080 : Tree 12 := .split 25 q12Shape25M790 q12Shape25M1079
private theorem q12Shape25M1080OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 16777216 q12Shape25M1080=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (16777216 ||| 2^25) q12Shape25M790 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^25) 16777216 q12Shape25M1079)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M790OK,q12Shape25M1079OK⟩
private def q12Shape25M1115 : Tree 12 := .split 31 q12Shape25P36 q12Shape25P37
private theorem q12Shape25M1115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 2113929216 q12Shape25M1115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 (2113929216 ||| 2^31) q12Shape25P36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16777216 ||| 2^31) 2113929216 q12Shape25P37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P36OK,q12Shape25P37OK⟩
private def q12Shape25M1146 : Tree 12 := .split 31 q12Shape25P38 q12Shape25P39
private theorem q12Shape25M1146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1090519040 1040187392 q12Shape25M1146=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1090519040 (1040187392 ||| 2^31) q12Shape25P38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1090519040 ||| 2^31) 1040187392 q12Shape25P39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P38OK,q12Shape25P39OK⟩
private def q12Shape25M1147 : Tree 12 := .split 30 q12Shape25M1115 q12Shape25M1146
private theorem q12Shape25M1147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 1040187392 q12Shape25M1147=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 (1040187392 ||| 2^30) q12Shape25M1115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16777216 ||| 2^30) 1040187392 q12Shape25M1146)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1115OK,q12Shape25M1146OK⟩
private def q12Shape25M1149 : Tree 12 := .split 29 q12Shape25M1147 q12Shape25P40
private theorem q12Shape25M1149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 503316480 q12Shape25M1149=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 (503316480 ||| 2^29) q12Shape25M1147 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16777216 ||| 2^29) 503316480 q12Shape25P40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1147OK,q12Shape25P40OK⟩
private def q12Shape25M1153 : Tree 12 := .split 28 q12Shape25M1149 q12Shape25P41
private theorem q12Shape25M1153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 234881024 q12Shape25M1153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 (234881024 ||| 2^28) q12Shape25M1149 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16777216 ||| 2^28) 234881024 q12Shape25P41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1149OK,q12Shape25P41OK⟩
private def q12Shape25M1181 : Tree 12 := .split 27 q12Shape25M1153 q12Shape25P42
private theorem q12Shape25M1181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 100663296 q12Shape25M1181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 (100663296 ||| 2^27) q12Shape25M1153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16777216 ||| 2^27) 100663296 q12Shape25P42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1153OK,q12Shape25P42OK⟩
private def q12Shape25M1235 : Tree 12 := .split 26 q12Shape25M1181 q12Shape25P43
private theorem q12Shape25M1235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 33554432 q12Shape25M1235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 (33554432 ||| 2^26) q12Shape25M1181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16777216 ||| 2^26) 33554432 q12Shape25P43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1181OK,q12Shape25P43OK⟩
private def q12Shape25M1370 : Tree 12 := .split 26 q12Shape25P44 q12Shape25P45
private theorem q12Shape25M1370OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 0 q12Shape25M1370=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (0 ||| 2^26) q12Shape25P44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^26) 0 q12Shape25P45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25P44OK,q12Shape25P45OK⟩
private def q12Shape25M1371 : Tree 12 := .split 25 q12Shape25M1235 q12Shape25M1370
private theorem q12Shape25M1371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 0 q12Shape25M1371=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16777216 (0 ||| 2^25) q12Shape25M1235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16777216 ||| 2^25) 0 q12Shape25M1370)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1235OK,q12Shape25M1370OK⟩
private def q12Shape25M1372 : Tree 12 := .split 24 q12Shape25M1080 q12Shape25M1371
private theorem q12Shape25M1372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 0 q12Shape25M1372=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 0 (0 ||| 2^24) q12Shape25M1080 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (0 ||| 2^24) 0 q12Shape25M1371)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25M1080OK,q12Shape25M1371OK⟩

theorem q12Shape25_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 25) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 25) b) (adj 12 (forms 25) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) adj_mono b H q12Shape25M1372 q12Shape25M1372OK

#print axioms q12Shape25_cover

end Graffiti384b.EffectiveSearch.Q12
