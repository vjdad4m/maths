import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T29 : Tree 12 := (.tip (.cover {2,3,4,5,6,10,11}))
private theorem q12Shape25T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137438953472 962055897088 q12Shape25T29=true := by decide

private def q12Shape25T32 : Tree 12 := (.tip (.cover {2,3,4,5,6,9,10}))
private theorem q12Shape25T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 687194767360 3710834966528 q12Shape25T32=true := by decide

private def q12Shape25T35 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,10}))
private theorem q12Shape25T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2886218022912 14705951244288 q12Shape25T35=true := by decide

private def q12Shape25T40 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,9,10})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.tip (.cover {0,1,3,4,8,9,10})) (.tip (.cover {0,2,4,6,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10})))))
private theorem q12Shape25T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 23502044267532 q12Shape25T40=true := by decide

private def q12Shape25T41 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.tip (.cover {0,1,3,4,8,9,10})) (.tip (.cover {0,2,3,6,8,9,10})))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311046144 23502044266508 q12Shape25T41=true := by decide

private def q12Shape25T39 : Tree 12 := .split 10 q12Shape25T40 q12Shape25T41
private theorem q12Shape25T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 23502044266508 q12Shape25T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 (23502044266508 ||| 2^10) q12Shape25T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11682311045120 ||| 2^10) 23502044266508 q12Shape25T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T40OK,q12Shape25T41OK⟩

private def q12Shape25T43 : Tree 12 := (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.tip (.cover {0,3,4,6,8,9,10})) (.tip (.cover {0,1,2,5,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10})))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape25T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045128 23502044267524 q12Shape25T43=true := by decide

private def q12Shape25T44 : Tree 12 := (.split 11 (.split 17 (.split 18 (.split 4 (.tip (.cover {0,3,4,6,8,9,10})) (.tip (.cover {0,1,2,5,8,9,10}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,8,9}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311046152 23502044266500 q12Shape25T44=true := by decide

private def q12Shape25T42 : Tree 12 := .split 10 q12Shape25T43 q12Shape25T44
private theorem q12Shape25T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045128 23502044266500 q12Shape25T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045128 (23502044266500 ||| 2^10) q12Shape25T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11682311045128 ||| 2^10) 23502044266500 q12Shape25T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T43OK,q12Shape25T44OK⟩

private def q12Shape25T38 : Tree 12 := .split 3 q12Shape25T39 q12Shape25T42
private theorem q12Shape25T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 23502044266500 q12Shape25T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 (23502044266500 ||| 2^3) q12Shape25T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11682311045120 ||| 2^3) 23502044266500 q12Shape25T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T39OK,q12Shape25T42OK⟩

private def q12Shape25T47 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.tip (.cover {1,3,4,5,8,9,10})) (.tip (.cover {0,1,2,6,8,9,10})))) (.tip (.cover {0,1,4,7,8,9,10}))) (.split 17 (.split 18 (.split 4 (.tip (.cover {1,3,4,5,8,9,10})) (.tip (.cover {0,1,2,6,8,9,10}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,8,9}))))
private theorem q12Shape25T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045124 23502044267528 q12Shape25T47=true := by decide

private def q12Shape25T48 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311046148 23502044266504 q12Shape25T48=true := by decide

private def q12Shape25T46 : Tree 12 := .split 10 q12Shape25T47 q12Shape25T48
private theorem q12Shape25T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045124 23502044266504 q12Shape25T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045124 (23502044266504 ||| 2^10) q12Shape25T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11682311045124 ||| 2^10) 23502044266504 q12Shape25T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T47OK,q12Shape25T48OK⟩

private def q12Shape25T49 : Tree 12 := (.tip (.cover {0,1,2,7,8,9,10}))
private theorem q12Shape25T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045132 23502044266496 q12Shape25T49=true := by decide

private def q12Shape25T45 : Tree 12 := .split 3 q12Shape25T46 q12Shape25T49
private theorem q12Shape25T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045124 23502044266496 q12Shape25T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045124 (23502044266496 ||| 2^3) q12Shape25T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11682311045124 ||| 2^3) 23502044266496 q12Shape25T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T46OK,q12Shape25T49OK⟩

private def q12Shape25T37 : Tree 12 := .split 2 q12Shape25T38 q12Shape25T45
private theorem q12Shape25T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 23502044266496 q12Shape25T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 (23502044266496 ||| 2^2) q12Shape25T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11682311045120 ||| 2^2) 23502044266496 q12Shape25T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T38OK,q12Shape25T45OK⟩

private def q12Shape25T50 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,11}))
private theorem q12Shape25T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 29274497089536 5909858222080 q12Shape25T50=true := by decide

private def q12Shape25T36 : Tree 12 := .split 44 q12Shape25T37 q12Shape25T50
private theorem q12Shape25T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 5909858222080 q12Shape25T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11682311045120 (5909858222080 ||| 2^44) q12Shape25T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11682311045120 ||| 2^44) 5909858222080 q12Shape25T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T37OK,q12Shape25T50OK⟩

private def q12Shape25T34 : Tree 12 := .split 43 q12Shape25T35 q12Shape25T36
private theorem q12Shape25T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2886218022912 5909858222080 q12Shape25T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2886218022912 (5909858222080 ||| 2^43) q12Shape25T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (2886218022912 ||| 2^43) 5909858222080 q12Shape25T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T35OK,q12Shape25T36OK⟩

private def q12Shape25T51 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape25T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7284264534016 1511811710976 q12Shape25T51=true := by decide

private def q12Shape25T33 : Tree 12 := .split 42 q12Shape25T34 q12Shape25T51
private theorem q12Shape25T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2886218022912 1511811710976 q12Shape25T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2886218022912 (1511811710976 ||| 2^42) q12Shape25T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (2886218022912 ||| 2^42) 1511811710976 q12Shape25T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T34OK,q12Shape25T51OK⟩

private def q12Shape25T31 : Tree 12 := .split 41 q12Shape25T32 q12Shape25T33
private theorem q12Shape25T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 687194767360 1511811710976 q12Shape25T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 687194767360 (1511811710976 ||| 2^41) q12Shape25T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (687194767360 ||| 2^41) 1511811710976 q12Shape25T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T32OK,q12Shape25T33OK⟩

private def q12Shape25T52 : Tree 12 := (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape25T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1786706395136 412300083200 q12Shape25T52=true := by decide

private def q12Shape25T30 : Tree 12 := .split 40 q12Shape25T31 q12Shape25T52
private theorem q12Shape25T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 687194767360 412300083200 q12Shape25T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 687194767360 (412300083200 ||| 2^40) q12Shape25T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (687194767360 ||| 2^40) 412300083200 q12Shape25T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T31OK,q12Shape25T52OK⟩

private def q12Shape25T28 : Tree 12 := .split 39 q12Shape25T29 q12Shape25T30
private theorem q12Shape25T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137438953472 412300083200 q12Shape25T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137438953472 (412300083200 ||| 2^39) q12Shape25T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (137438953472 ||| 2^39) 412300083200 q12Shape25T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T29OK,q12Shape25T30OK⟩

private def q12Shape25T54 : Tree 12 := (.tip (.cover {2,3,4,5,6,10,11}))
private theorem q12Shape25T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 412316860416 687177990144 q12Shape25T54=true := by decide

private def q12Shape25T60 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,8}))
private theorem q12Shape25T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 34222282637312 q12Shape25T60=true := by decide

private def q12Shape25T64 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,9,10})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.tip (.cover {0,1,3,4,7,9,10})) (.tip (.cover {0,2,4,6,7,9,10}))) (.tip (.cover {0,4,6,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10})))))
private theorem q12Shape25T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718720 16630096593932 q12Shape25T64=true := by decide

private def q12Shape25T65 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.tip (.cover {0,1,3,4,7,9,10})) (.tip (.cover {0,2,3,6,7,9,10}))) (.tip (.cover {0,3,6,7,8,9,10})))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258719744 16630096592908 q12Shape25T65=true := by decide

private def q12Shape25T63 : Tree 12 := .split 10 q12Shape25T64 q12Shape25T65
private theorem q12Shape25T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718720 16630096592908 q12Shape25T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718720 (16630096592908 ||| 2^10) q12Shape25T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18554258718720 ||| 2^10) 16630096592908 q12Shape25T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T64OK,q12Shape25T65OK⟩

private def q12Shape25T67 : Tree 12 := (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10})))) (.tip (.cover {0,1,4,7,8,9,10})))) (.tip (.cover {2,3,4,5,7,8,10})))
private theorem q12Shape25T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718728 16630096593924 q12Shape25T67=true := by decide

private def q12Shape25T68 : Tree 12 := (.split 11 (.split 17 (.split 18 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10})))) (.tip (.cover {2,3,4,5,7,8,10}))) (.tip (.cover {2,3,4,6,7,8,10}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258719752 16630096592900 q12Shape25T68=true := by decide

private def q12Shape25T66 : Tree 12 := .split 10 q12Shape25T67 q12Shape25T68
private theorem q12Shape25T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718728 16630096592900 q12Shape25T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718728 (16630096592900 ||| 2^10) q12Shape25T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18554258718728 ||| 2^10) 16630096592900 q12Shape25T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T67OK,q12Shape25T68OK⟩

private def q12Shape25T62 : Tree 12 := .split 3 q12Shape25T63 q12Shape25T66
private theorem q12Shape25T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718720 16630096592900 q12Shape25T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718720 (16630096592900 ||| 2^3) q12Shape25T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18554258718720 ||| 2^3) 16630096592900 q12Shape25T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T63OK,q12Shape25T66OK⟩

private def q12Shape25T72 : Tree 12 := (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.tip (.cover {1,3,4,5,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10}))))) (.tip (.cover {0,1,4,7,8,9,10})))
private theorem q12Shape25T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718724 16630096595976 q12Shape25T72=true := by decide

private def q12Shape25T73 : Tree 12 := (.split 17 (.split 18 (.split 4 (.split 5 (.tip (.cover {1,3,4,5,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10})))) (.tip (.cover {2,3,4,5,7,8,10}))) (.tip (.cover {2,3,4,6,7,8,10})))
private theorem q12Shape25T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258720772 16630096593928 q12Shape25T73=true := by decide

private def q12Shape25T71 : Tree 12 := .split 11 q12Shape25T72 q12Shape25T73
private theorem q12Shape25T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718724 16630096593928 q12Shape25T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718724 (16630096593928 ||| 2^11) q12Shape25T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18554258718724 ||| 2^11) 16630096593928 q12Shape25T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T72OK,q12Shape25T73OK⟩

private def q12Shape25T74 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape25T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258719748 16630096592904 q12Shape25T74=true := by decide

private def q12Shape25T70 : Tree 12 := .split 10 q12Shape25T71 q12Shape25T74
private theorem q12Shape25T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718724 16630096592904 q12Shape25T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718724 (16630096592904 ||| 2^10) q12Shape25T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18554258718724 ||| 2^10) 16630096592904 q12Shape25T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T71OK,q12Shape25T74OK⟩

private def q12Shape25T75 : Tree 12 := (.tip (.cover {0,1,2,7,8,9,10}))
private theorem q12Shape25T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718732 16630096592896 q12Shape25T75=true := by decide

private def q12Shape25T69 : Tree 12 := .split 3 q12Shape25T70 q12Shape25T75
private theorem q12Shape25T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718724 16630096592896 q12Shape25T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718724 (16630096592896 ||| 2^3) q12Shape25T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18554258718724 ||| 2^3) 16630096592896 q12Shape25T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T70OK,q12Shape25T75OK⟩

private def q12Shape25T61 : Tree 12 := .split 2 q12Shape25T62 q12Shape25T69
private theorem q12Shape25T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718720 16630096592896 q12Shape25T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18554258718720 (16630096592896 ||| 2^2) q12Shape25T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18554258718720 ||| 2^2) 16630096592896 q12Shape25T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T62OK,q12Shape25T69OK⟩

private def q12Shape25T59 : Tree 12 := .split 44 q12Shape25T60 q12Shape25T61
private theorem q12Shape25T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 16630096592896 q12Shape25T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 (16630096592896 ||| 2^44) q12Shape25T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (962072674304 ||| 2^44) 16630096592896 q12Shape25T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T60OK,q12Shape25T61OK⟩

private def q12Shape25T76 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape25T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9758165696512 7834003570688 q12Shape25T76=true := by decide

private def q12Shape25T58 : Tree 12 := .split 43 q12Shape25T59 q12Shape25T76
private theorem q12Shape25T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 7834003570688 q12Shape25T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 (7834003570688 ||| 2^43) q12Shape25T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (962072674304 ||| 2^43) 7834003570688 q12Shape25T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T59OK,q12Shape25T76OK⟩

private def q12Shape25T77 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape25T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5360119185408 3435957059584 q12Shape25T77=true := by decide

private def q12Shape25T57 : Tree 12 := .split 42 q12Shape25T58 q12Shape25T77
private theorem q12Shape25T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 3435957059584 q12Shape25T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 (3435957059584 ||| 2^42) q12Shape25T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (962072674304 ||| 2^42) 3435957059584 q12Shape25T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T58OK,q12Shape25T77OK⟩

private def q12Shape25T78 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape25T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3161095929856 1236933804032 q12Shape25T78=true := by decide

private def q12Shape25T56 : Tree 12 := .split 41 q12Shape25T57 q12Shape25T78
private theorem q12Shape25T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 1236933804032 q12Shape25T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 (1236933804032 ||| 2^41) q12Shape25T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (962072674304 ||| 2^41) 1236933804032 q12Shape25T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T57OK,q12Shape25T78OK⟩

private def q12Shape25T79 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape25T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2061584302080 137422176256 q12Shape25T79=true := by decide

private def q12Shape25T55 : Tree 12 := .split 40 q12Shape25T56 q12Shape25T79
private theorem q12Shape25T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 137422176256 q12Shape25T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 962072674304 (137422176256 ||| 2^40) q12Shape25T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (962072674304 ||| 2^40) 137422176256 q12Shape25T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T56OK,q12Shape25T79OK⟩

private def q12Shape25T53 : Tree 12 := .split 39 q12Shape25T54 q12Shape25T55
private theorem q12Shape25T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 412316860416 137422176256 q12Shape25T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 412316860416 (137422176256 ||| 2^39) q12Shape25T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (412316860416 ||| 2^39) 137422176256 q12Shape25T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T54OK,q12Shape25T55OK⟩

private def q12Shape25T27 : Tree 12 := .split 38 q12Shape25T28 q12Shape25T53
private theorem q12Shape25T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137438953472 137422176256 q12Shape25T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137438953472 (137422176256 ||| 2^38) q12Shape25T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (137438953472 ||| 2^38) 137422176256 q12Shape25T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T28OK,q12Shape25T53OK⟩

def q12Shape25P1 : Tree 12 := q12Shape25T27
theorem q12Shape25P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137438953472 137422176256 q12Shape25P1=true := q12Shape25T27OK

end Graffiti384b.EffectiveSearch.Q12
