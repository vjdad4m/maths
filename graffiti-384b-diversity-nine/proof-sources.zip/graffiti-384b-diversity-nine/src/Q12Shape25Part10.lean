import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T375 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))))
private theorem q12Shape25T375OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 266271195136 q12Shape25T375=true := by decide

private def q12Shape25T376 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T376OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 146028888064 128832241664 q12Shape25T376=true := by decide

private def q12Shape25T374 : Tree 12 := .split 37 q12Shape25T375 q12Shape25T376
private theorem q12Shape25T374OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 128832241664 q12Shape25T374=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 (128832241664 ||| 2^37) q12Shape25T375 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (8589934592 ||| 2^37) 128832241664 q12Shape25T376)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T375OK,q12Shape25T376OK⟩

private def q12Shape25T377 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T377OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 77309411328 60112764928 q12Shape25T377=true := by decide

private def q12Shape25T373 : Tree 12 := .split 36 q12Shape25T374 q12Shape25T377
private theorem q12Shape25T373OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 60112764928 q12Shape25T373=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 (60112764928 ||| 2^36) q12Shape25T374 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (8589934592 ||| 2^36) 60112764928 q12Shape25T377)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T374OK,q12Shape25T377OK⟩

private def q12Shape25T379 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T379OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 42949672960 94472503296 q12Shape25T379=true := by decide

private def q12Shape25T380 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape25T380OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 111669149696 25753026560 q12Shape25T380=true := by decide

private def q12Shape25T378 : Tree 12 := .split 36 q12Shape25T379 q12Shape25T380
private theorem q12Shape25T378OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 42949672960 25753026560 q12Shape25T378=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 42949672960 (25753026560 ||| 2^36) q12Shape25T379 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (42949672960 ||| 2^36) 25753026560 q12Shape25T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T379OK,q12Shape25T380OK⟩

private def q12Shape25T372 : Tree 12 := .split 35 q12Shape25T373 q12Shape25T378
private theorem q12Shape25T372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 25753026560 q12Shape25T372=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 (25753026560 ||| 2^35) q12Shape25T373 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (8589934592 ||| 2^35) 25753026560 q12Shape25T378)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T373OK,q12Shape25T378OK⟩

private def q12Shape25T381 : Tree 12 := (.split 35 (.tip (.cover {2,3,4,5,9,10,11})) (.split 36 (.tip (.cover {2,3,4,5,8,10,11})) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T381OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 25769803776 8573157376 q12Shape25T381=true := by decide

private def q12Shape25T371 : Tree 12 := .split 34 q12Shape25T372 q12Shape25T381
private theorem q12Shape25T371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 8573157376 q12Shape25T371=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 (8573157376 ||| 2^34) q12Shape25T372 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (8589934592 ||| 2^34) 8573157376 q12Shape25T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T372OK,q12Shape25T381OK⟩

def q12Shape25P12 : Tree 12 := q12Shape25T371
theorem q12Shape25P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8589934592 8573157376 q12Shape25P12=true := q12Shape25T371OK

private def q12Shape25T388 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))))
private theorem q12Shape25T388OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 270566162432 q12Shape25T388=true := by decide

private def q12Shape25T389 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T389OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 141733920768 133127208960 q12Shape25T389=true := by decide

private def q12Shape25T387 : Tree 12 := .split 37 q12Shape25T388 q12Shape25T389
private theorem q12Shape25T387OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 133127208960 q12Shape25T387=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 (133127208960 ||| 2^37) q12Shape25T388 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (4294967296 ||| 2^37) 133127208960 q12Shape25T389)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T388OK,q12Shape25T389OK⟩

private def q12Shape25T390 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T390OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 73014444032 64407732224 q12Shape25T390=true := by decide

private def q12Shape25T386 : Tree 12 := .split 36 q12Shape25T387 q12Shape25T390
private theorem q12Shape25T386OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 64407732224 q12Shape25T386=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 (64407732224 ||| 2^36) q12Shape25T387 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (4294967296 ||| 2^36) 64407732224 q12Shape25T390)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T387OK,q12Shape25T390OK⟩

private def q12Shape25T393 : Tree 12 := (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,7,8,9,10}))))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T393OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 38654705664 236206424064 q12Shape25T393=true := by decide

private def q12Shape25T394 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape25T394OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 176093659136 98767470592 q12Shape25T394=true := by decide

private def q12Shape25T392 : Tree 12 := .split 37 q12Shape25T393 q12Shape25T394
private theorem q12Shape25T392OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 38654705664 98767470592 q12Shape25T392=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 38654705664 (98767470592 ||| 2^37) q12Shape25T393 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (38654705664 ||| 2^37) 98767470592 q12Shape25T394)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T393OK,q12Shape25T394OK⟩

private def q12Shape25T395 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape25T395OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 107374182400 30047993856 q12Shape25T395=true := by decide

private def q12Shape25T391 : Tree 12 := .split 36 q12Shape25T392 q12Shape25T395
private theorem q12Shape25T391OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 38654705664 30047993856 q12Shape25T391=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 38654705664 (30047993856 ||| 2^36) q12Shape25T392 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (38654705664 ||| 2^36) 30047993856 q12Shape25T395)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T392OK,q12Shape25T395OK⟩

private def q12Shape25T385 : Tree 12 := .split 35 q12Shape25T386 q12Shape25T391
private theorem q12Shape25T385OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 30047993856 q12Shape25T385=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 (30047993856 ||| 2^35) q12Shape25T386 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (4294967296 ||| 2^35) 30047993856 q12Shape25T391)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T386OK,q12Shape25T391OK⟩

private def q12Shape25T396 : Tree 12 := (.split 35 (.tip (.cover {2,3,4,5,9,10,11})) (.split 36 (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T396OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 21474836480 12868124672 q12Shape25T396=true := by decide

private def q12Shape25T384 : Tree 12 := .split 34 q12Shape25T385 q12Shape25T396
private theorem q12Shape25T384OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 12868124672 q12Shape25T384=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 (12868124672 ||| 2^34) q12Shape25T385 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (4294967296 ||| 2^34) 12868124672 q12Shape25T396)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T385OK,q12Shape25T396OK⟩

private def q12Shape25T398 : Tree 12 := (.split 35 (.tip (.cover {2,3,4,5,9,10,11})) (.split 36 (.split 37 (.split 38 (.tip (.cover {2,3,4,5,8,9,10})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T398OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 12884901888 21458059264 q12Shape25T398=true := by decide

private def q12Shape25T400 : Tree 12 := (.tip (.cover {2,3,4,5,9,10,11}))
private theorem q12Shape25T400OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 30064771072 38637928448 q12Shape25T400=true := by decide

private def q12Shape25T402 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T402OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 64424509440 72997666816 q12Shape25T402=true := by decide

private def q12Shape25T403 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape25T403OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 133143986176 4278190080 q12Shape25T403=true := by decide

private def q12Shape25T401 : Tree 12 := .split 36 q12Shape25T402 q12Shape25T403
private theorem q12Shape25T401OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 64424509440 4278190080 q12Shape25T401=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 64424509440 (4278190080 ||| 2^36) q12Shape25T402 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (64424509440 ||| 2^36) 4278190080 q12Shape25T403)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T402OK,q12Shape25T403OK⟩

private def q12Shape25T399 : Tree 12 := .split 35 q12Shape25T400 q12Shape25T401
private theorem q12Shape25T399OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 30064771072 4278190080 q12Shape25T399=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 30064771072 (4278190080 ||| 2^35) q12Shape25T400 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (30064771072 ||| 2^35) 4278190080 q12Shape25T401)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T400OK,q12Shape25T401OK⟩

private def q12Shape25T397 : Tree 12 := .split 34 q12Shape25T398 q12Shape25T399
private theorem q12Shape25T397OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 12884901888 4278190080 q12Shape25T397=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 12884901888 (4278190080 ||| 2^34) q12Shape25T398 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (12884901888 ||| 2^34) 4278190080 q12Shape25T399)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T398OK,q12Shape25T399OK⟩

private def q12Shape25T383 : Tree 12 := .split 33 q12Shape25T384 q12Shape25T397
private theorem q12Shape25T383OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 4278190080 q12Shape25T383=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 (4278190080 ||| 2^33) q12Shape25T384 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (4294967296 ||| 2^33) 4278190080 q12Shape25T397)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T384OK,q12Shape25T397OK⟩

def q12Shape25P13 : Tree 12 := q12Shape25T383
theorem q12Shape25P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4294967296 4278190080 q12Shape25P13=true := q12Shape25T383OK

end Graffiti384b.EffectiveSearch.Q12
