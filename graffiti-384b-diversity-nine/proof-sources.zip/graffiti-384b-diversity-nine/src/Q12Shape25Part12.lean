import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T436 : Tree 12 := (.split 35 (.split 36 (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.split 38 (.tip (.cover {2,3,4,5,8,9,10})) (.tip (.cover {0,1,5,8,9,10,11})))) (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11})))) (.split 36 (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape25T436OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6442450944 27900510208 q12Shape25T436=true := by decide

private def q12Shape25T438 : Tree 12 := (.split 36 (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))) (.tip (.cover {0,1,5,8,9,10,11})))) (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T438OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 23622320128 45080379392 q12Shape25T438=true := by decide

private def q12Shape25T439 : Tree 12 := (.split 36 (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T439OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 57982058496 10720641024 q12Shape25T439=true := by decide

private def q12Shape25T437 : Tree 12 := .split 35 q12Shape25T438 q12Shape25T439
private theorem q12Shape25T437OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 23622320128 10720641024 q12Shape25T437=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 23622320128 (10720641024 ||| 2^35) q12Shape25T438 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (23622320128 ||| 2^35) 10720641024 q12Shape25T439)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T438OK,q12Shape25T439OK⟩

private def q12Shape25T435 : Tree 12 := .split 34 q12Shape25T436 q12Shape25T437
private theorem q12Shape25T435OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6442450944 10720641024 q12Shape25T435=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6442450944 (10720641024 ||| 2^34) q12Shape25T436 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6442450944 ||| 2^34) 10720641024 q12Shape25T437)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T436OK,q12Shape25T437OK⟩

private def q12Shape25T443 : Tree 12 := (.split 37 (.split 38 (.tip (.cover {2,3,4,5,8,9,10})) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))))) (.split 38 (.tip (.cover {2,3,4,5,8,9,10})) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T443OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15032385536 122389790720 q12Shape25T443=true := by decide

private def q12Shape25T444 : Tree 12 := (.split 37 (.split 38 (.tip (.cover {2,3,4,5,8,9,10})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T444OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83751862272 53670313984 q12Shape25T444=true := by decide

private def q12Shape25T442 : Tree 12 := .split 36 q12Shape25T443 q12Shape25T444
private theorem q12Shape25T442OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15032385536 53670313984 q12Shape25T442=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15032385536 (53670313984 ||| 2^36) q12Shape25T443 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (15032385536 ||| 2^36) 53670313984 q12Shape25T444)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T443OK,q12Shape25T444OK⟩

private def q12Shape25T445 : Tree 12 := (.split 36 (.split 37 (.split 38 (.tip (.cover {2,3,4,5,8,9,10})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T445OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 49392123904 19310575616 q12Shape25T445=true := by decide

private def q12Shape25T441 : Tree 12 := .split 35 q12Shape25T442 q12Shape25T445
private theorem q12Shape25T441OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15032385536 19310575616 q12Shape25T441=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15032385536 (19310575616 ||| 2^35) q12Shape25T442 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (15032385536 ||| 2^35) 19310575616 q12Shape25T445)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T442OK,q12Shape25T445OK⟩

private def q12Shape25T448 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T448OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 32212254720 105209921536 q12Shape25T448=true := by decide

private def q12Shape25T449 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T449OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100931731456 36490444800 q12Shape25T449=true := by decide

private def q12Shape25T447 : Tree 12 := .split 36 q12Shape25T448 q12Shape25T449
private theorem q12Shape25T447OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 32212254720 36490444800 q12Shape25T447=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 32212254720 (36490444800 ||| 2^36) q12Shape25T448 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (32212254720 ||| 2^36) 36490444800 q12Shape25T449)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T448OK,q12Shape25T449OK⟩

private def q12Shape25T450 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T450OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 66571993088 2130706432 q12Shape25T450=true := by decide

private def q12Shape25T446 : Tree 12 := .split 35 q12Shape25T447 q12Shape25T450
private theorem q12Shape25T446OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 32212254720 2130706432 q12Shape25T446=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 32212254720 (2130706432 ||| 2^35) q12Shape25T447 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (32212254720 ||| 2^35) 2130706432 q12Shape25T450)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T447OK,q12Shape25T450OK⟩

private def q12Shape25T440 : Tree 12 := .split 34 q12Shape25T441 q12Shape25T446
private theorem q12Shape25T440OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15032385536 2130706432 q12Shape25T440=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15032385536 (2130706432 ||| 2^34) q12Shape25T441 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (15032385536 ||| 2^34) 2130706432 q12Shape25T446)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T441OK,q12Shape25T446OK⟩

private def q12Shape25T434 : Tree 12 := .split 33 q12Shape25T435 q12Shape25T440
private theorem q12Shape25T434OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6442450944 2130706432 q12Shape25T434=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6442450944 (2130706432 ||| 2^33) q12Shape25T435 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6442450944 ||| 2^33) 2130706432 q12Shape25T440)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T435OK,q12Shape25T440OK⟩

def q12Shape25P15 : Tree 12 := q12Shape25T434
theorem q12Shape25P15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6442450944 2130706432 q12Shape25P15=true := q12Shape25T434OK

end Graffiti384b.EffectiveSearch.Q12
