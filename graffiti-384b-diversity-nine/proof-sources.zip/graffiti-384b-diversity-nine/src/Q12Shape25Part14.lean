import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T485 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,9,10})))))
private theorem q12Shape25T485OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 256607518720 q12Shape25T485=true := by decide

private def q12Shape25T486 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,7,9,11})) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T486OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 155692564480 119168565248 q12Shape25T486=true := by decide

private def q12Shape25T484 : Tree 12 := .split 37 q12Shape25T485 q12Shape25T486
private theorem q12Shape25T484OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 119168565248 q12Shape25T484=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 (119168565248 ||| 2^37) q12Shape25T485 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18253611008 ||| 2^37) 119168565248 q12Shape25T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T485OK,q12Shape25T486OK⟩

private def q12Shape25T487 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T487OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 86973087744 50449088512 q12Shape25T487=true := by decide

private def q12Shape25T483 : Tree 12 := .split 36 q12Shape25T484 q12Shape25T487
private theorem q12Shape25T483OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 50449088512 q12Shape25T483=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 (50449088512 ||| 2^36) q12Shape25T484 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18253611008 ||| 2^36) 50449088512 q12Shape25T487)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T484OK,q12Shape25T487OK⟩

private def q12Shape25T488 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T488OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 52613349376 16089350144 q12Shape25T488=true := by decide

private def q12Shape25T482 : Tree 12 := .split 35 q12Shape25T483 q12Shape25T488
private theorem q12Shape25T482OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 16089350144 q12Shape25T482=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 (16089350144 ||| 2^35) q12Shape25T483 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18253611008 ||| 2^35) 16089350144 q12Shape25T488)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T483OK,q12Shape25T488OK⟩

def q12Shape25P17 : Tree 12 := q12Shape25T482
theorem q12Shape25P17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18253611008 16089350144 q12Shape25P17=true := q12Shape25T482OK

private def q12Shape25T494 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,8,9,11})))))
private theorem q12Shape25T494OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 265197453312 q12Shape25T494=true := by decide

private def q12Shape25T495 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T495OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 147102629888 127758499840 q12Shape25T495=true := by decide

private def q12Shape25T493 : Tree 12 := .split 37 q12Shape25T494 q12Shape25T495
private theorem q12Shape25T493OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 127758499840 q12Shape25T493=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 (127758499840 ||| 2^37) q12Shape25T494 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (9663676416 ||| 2^37) 127758499840 q12Shape25T495)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T494OK,q12Shape25T495OK⟩

private def q12Shape25T496 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T496OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 78383153152 59039023104 q12Shape25T496=true := by decide

private def q12Shape25T492 : Tree 12 := .split 36 q12Shape25T493 q12Shape25T496
private theorem q12Shape25T492OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 59039023104 q12Shape25T492=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 (59039023104 ||| 2^36) q12Shape25T493 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (9663676416 ||| 2^36) 59039023104 q12Shape25T496)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T493OK,q12Shape25T496OK⟩

private def q12Shape25T497 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T497OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 44023414784 24679284736 q12Shape25T497=true := by decide

private def q12Shape25T491 : Tree 12 := .split 35 q12Shape25T492 q12Shape25T497
private theorem q12Shape25T491OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 24679284736 q12Shape25T491=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 (24679284736 ||| 2^35) q12Shape25T492 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (9663676416 ||| 2^35) 24679284736 q12Shape25T497)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T492OK,q12Shape25T497OK⟩

private def q12Shape25T501 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,9})))))
private theorem q12Shape25T501OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 26843545600 248017584128 q12Shape25T501=true := by decide

private def q12Shape25T502 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,5,6,7,8,9})))
private theorem q12Shape25T502OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 164282499072 110578630656 q12Shape25T502=true := by decide

private def q12Shape25T500 : Tree 12 := .split 37 q12Shape25T501 q12Shape25T502
private theorem q12Shape25T500OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 26843545600 110578630656 q12Shape25T500=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 26843545600 (110578630656 ||| 2^37) q12Shape25T501 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (26843545600 ||| 2^37) 110578630656 q12Shape25T502)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T501OK,q12Shape25T502OK⟩

private def q12Shape25T503 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T503OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 95563022336 41859153920 q12Shape25T503=true := by decide

private def q12Shape25T499 : Tree 12 := .split 36 q12Shape25T500 q12Shape25T503
private theorem q12Shape25T499OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 26843545600 41859153920 q12Shape25T499=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 26843545600 (41859153920 ||| 2^36) q12Shape25T500 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (26843545600 ||| 2^36) 41859153920 q12Shape25T503)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T500OK,q12Shape25T503OK⟩

private def q12Shape25T504 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T504OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 61203283968 7499415552 q12Shape25T504=true := by decide

private def q12Shape25T498 : Tree 12 := .split 35 q12Shape25T499 q12Shape25T504
private theorem q12Shape25T498OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 26843545600 7499415552 q12Shape25T498=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 26843545600 (7499415552 ||| 2^35) q12Shape25T499 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (26843545600 ||| 2^35) 7499415552 q12Shape25T504)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T499OK,q12Shape25T504OK⟩

private def q12Shape25T490 : Tree 12 := .split 34 q12Shape25T491 q12Shape25T498
private theorem q12Shape25T490OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 7499415552 q12Shape25T490=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 (7499415552 ||| 2^34) q12Shape25T491 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (9663676416 ||| 2^34) 7499415552 q12Shape25T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T491OK,q12Shape25T498OK⟩

def q12Shape25P18 : Tree 12 := q12Shape25T490
theorem q12Shape25P18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9663676416 7499415552 q12Shape25P18=true := q12Shape25T490OK

end Graffiti384b.EffectiveSearch.Q12
