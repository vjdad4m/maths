import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T510 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T510OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 132053467136 q12Shape25T510=true := by decide

private def q12Shape25T511 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T511OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 74088185856 63333990400 q12Shape25T511=true := by decide

private def q12Shape25T509 : Tree 12 := .split 36 q12Shape25T510 q12Shape25T511
private theorem q12Shape25T509OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 63333990400 q12Shape25T509=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 (63333990400 ||| 2^36) q12Shape25T510 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (5368709120 ||| 2^36) 63333990400 q12Shape25T511)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T510OK,q12Shape25T511OK⟩

private def q12Shape25T512 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,7,9,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T512OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 39728447488 28974252032 q12Shape25T512=true := by decide

private def q12Shape25T508 : Tree 12 := .split 35 q12Shape25T509 q12Shape25T512
private theorem q12Shape25T508OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 28974252032 q12Shape25T508=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 (28974252032 ||| 2^35) q12Shape25T509 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (5368709120 ||| 2^35) 28974252032 q12Shape25T512)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T509OK,q12Shape25T512OK⟩

private def q12Shape25T515 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T515OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 22548578304 114873597952 q12Shape25T515=true := by decide

private def q12Shape25T516 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,8,10})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T516OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 91268055040 46154121216 q12Shape25T516=true := by decide

private def q12Shape25T514 : Tree 12 := .split 36 q12Shape25T515 q12Shape25T516
private theorem q12Shape25T514OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 22548578304 46154121216 q12Shape25T514=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 22548578304 (46154121216 ||| 2^36) q12Shape25T515 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (22548578304 ||| 2^36) 46154121216 q12Shape25T516)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T515OK,q12Shape25T516OK⟩

private def q12Shape25T517 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,7,9,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T517OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 56908316672 11794382848 q12Shape25T517=true := by decide

private def q12Shape25T513 : Tree 12 := .split 35 q12Shape25T514 q12Shape25T517
private theorem q12Shape25T513OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 22548578304 11794382848 q12Shape25T513=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 22548578304 (11794382848 ||| 2^35) q12Shape25T514 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (22548578304 ||| 2^35) 11794382848 q12Shape25T517)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T514OK,q12Shape25T517OK⟩

private def q12Shape25T507 : Tree 12 := .split 34 q12Shape25T508 q12Shape25T513
private theorem q12Shape25T507OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 11794382848 q12Shape25T507=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 (11794382848 ||| 2^34) q12Shape25T508 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (5368709120 ||| 2^34) 11794382848 q12Shape25T513)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T508OK,q12Shape25T513OK⟩

private def q12Shape25T521 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T521OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 13958643712 123463532544 q12Shape25T521=true := by decide

private def q12Shape25T522 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T522OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 82678120448 54744055808 q12Shape25T522=true := by decide

private def q12Shape25T520 : Tree 12 := .split 36 q12Shape25T521 q12Shape25T522
private theorem q12Shape25T520OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 13958643712 54744055808 q12Shape25T520=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 13958643712 (54744055808 ||| 2^36) q12Shape25T521 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (13958643712 ||| 2^36) 54744055808 q12Shape25T522)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T521OK,q12Shape25T522OK⟩

private def q12Shape25T523 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.tip (.cover {2,3,4,5,7,9,10})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T523OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 48318382080 20384317440 q12Shape25T523=true := by decide

private def q12Shape25T519 : Tree 12 := .split 35 q12Shape25T520 q12Shape25T523
private theorem q12Shape25T519OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 13958643712 20384317440 q12Shape25T519=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 13958643712 (20384317440 ||| 2^35) q12Shape25T520 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (13958643712 ||| 2^35) 20384317440 q12Shape25T523)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T520OK,q12Shape25T523OK⟩

private def q12Shape25T526 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T526OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 31138512896 106283663360 q12Shape25T526=true := by decide

private def q12Shape25T527 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T527OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 99857989632 37564186624 q12Shape25T527=true := by decide

private def q12Shape25T525 : Tree 12 := .split 36 q12Shape25T526 q12Shape25T527
private theorem q12Shape25T525OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 31138512896 37564186624 q12Shape25T525=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 31138512896 (37564186624 ||| 2^36) q12Shape25T526 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (31138512896 ||| 2^36) 37564186624 q12Shape25T527)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T526OK,q12Shape25T527OK⟩

private def q12Shape25T528 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T528OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 65498251264 3204448256 q12Shape25T528=true := by decide

private def q12Shape25T524 : Tree 12 := .split 35 q12Shape25T525 q12Shape25T528
private theorem q12Shape25T524OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 31138512896 3204448256 q12Shape25T524=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 31138512896 (3204448256 ||| 2^35) q12Shape25T525 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (31138512896 ||| 2^35) 3204448256 q12Shape25T528)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T525OK,q12Shape25T528OK⟩

private def q12Shape25T518 : Tree 12 := .split 34 q12Shape25T519 q12Shape25T524
private theorem q12Shape25T518OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 13958643712 3204448256 q12Shape25T518=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 13958643712 (3204448256 ||| 2^34) q12Shape25T519 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (13958643712 ||| 2^34) 3204448256 q12Shape25T524)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T519OK,q12Shape25T524OK⟩

private def q12Shape25T506 : Tree 12 := .split 33 q12Shape25T507 q12Shape25T518
private theorem q12Shape25T506OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 3204448256 q12Shape25T506=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 (3204448256 ||| 2^33) q12Shape25T507 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (5368709120 ||| 2^33) 3204448256 q12Shape25T518)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T507OK,q12Shape25T518OK⟩

def q12Shape25P19 : Tree 12 := q12Shape25T506
theorem q12Shape25P19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5368709120 3204448256 q12Shape25P19=true := q12Shape25T506OK

end Graffiti384b.EffectiveSearch.Q12
