import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T534 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T534OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 134200950784 q12Shape25T534=true := by decide

private def q12Shape25T535 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T535OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 71940702208 65481474048 q12Shape25T535=true := by decide

private def q12Shape25T533 : Tree 12 := .split 36 q12Shape25T534 q12Shape25T535
private theorem q12Shape25T533OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 65481474048 q12Shape25T533=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 (65481474048 ||| 2^36) q12Shape25T534 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3221225472 ||| 2^36) 65481474048 q12Shape25T535)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T534OK,q12Shape25T535OK⟩

private def q12Shape25T537 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T537OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 37580963840 99841212416 q12Shape25T537=true := by decide

private def q12Shape25T538 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape25T538OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 106300440576 31121735680 q12Shape25T538=true := by decide

private def q12Shape25T536 : Tree 12 := .split 36 q12Shape25T537 q12Shape25T538
private theorem q12Shape25T536OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 37580963840 31121735680 q12Shape25T536=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 37580963840 (31121735680 ||| 2^36) q12Shape25T537 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (37580963840 ||| 2^36) 31121735680 q12Shape25T538)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T537OK,q12Shape25T538OK⟩

private def q12Shape25T532 : Tree 12 := .split 35 q12Shape25T533 q12Shape25T536
private theorem q12Shape25T532OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 31121735680 q12Shape25T532=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 (31121735680 ||| 2^35) q12Shape25T533 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3221225472 ||| 2^35) 31121735680 q12Shape25T536)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T533OK,q12Shape25T536OK⟩

private def q12Shape25T541 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T541OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20401094656 117021081600 q12Shape25T541=true := by decide

private def q12Shape25T542 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T542OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 89120571392 48301604864 q12Shape25T542=true := by decide

private def q12Shape25T540 : Tree 12 := .split 36 q12Shape25T541 q12Shape25T542
private theorem q12Shape25T540OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20401094656 48301604864 q12Shape25T540=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20401094656 (48301604864 ||| 2^36) q12Shape25T541 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20401094656 ||| 2^36) 48301604864 q12Shape25T542)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T541OK,q12Shape25T542OK⟩

private def q12Shape25T544 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,9,10})))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T544OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 54760833024 82661343232 q12Shape25T544=true := by decide

private def q12Shape25T545 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape25T545OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 123480309760 13941866496 q12Shape25T545=true := by decide

private def q12Shape25T543 : Tree 12 := .split 36 q12Shape25T544 q12Shape25T545
private theorem q12Shape25T543OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 54760833024 13941866496 q12Shape25T543=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 54760833024 (13941866496 ||| 2^36) q12Shape25T544 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (54760833024 ||| 2^36) 13941866496 q12Shape25T545)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T544OK,q12Shape25T545OK⟩

private def q12Shape25T539 : Tree 12 := .split 35 q12Shape25T540 q12Shape25T543
private theorem q12Shape25T539OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20401094656 13941866496 q12Shape25T539=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20401094656 (13941866496 ||| 2^35) q12Shape25T540 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20401094656 ||| 2^35) 13941866496 q12Shape25T543)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T540OK,q12Shape25T543OK⟩

private def q12Shape25T531 : Tree 12 := .split 34 q12Shape25T532 q12Shape25T539
private theorem q12Shape25T531OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 13941866496 q12Shape25T531=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 (13941866496 ||| 2^34) q12Shape25T532 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3221225472 ||| 2^34) 13941866496 q12Shape25T539)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T532OK,q12Shape25T539OK⟩

private def q12Shape25T549 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T549OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11811160064 125611016192 q12Shape25T549=true := by decide

private def q12Shape25T550 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T550OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 80530636800 56891539456 q12Shape25T550=true := by decide

private def q12Shape25T548 : Tree 12 := .split 36 q12Shape25T549 q12Shape25T550
private theorem q12Shape25T548OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11811160064 56891539456 q12Shape25T548=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11811160064 (56891539456 ||| 2^36) q12Shape25T549 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11811160064 ||| 2^36) 56891539456 q12Shape25T550)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T549OK,q12Shape25T550OK⟩

private def q12Shape25T551 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T551OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 46170898432 22531801088 q12Shape25T551=true := by decide

private def q12Shape25T547 : Tree 12 := .split 35 q12Shape25T548 q12Shape25T551
private theorem q12Shape25T547OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11811160064 22531801088 q12Shape25T547=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11811160064 (22531801088 ||| 2^35) q12Shape25T548 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11811160064 ||| 2^35) 22531801088 q12Shape25T551)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T548OK,q12Shape25T551OK⟩

private def q12Shape25T554 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T554OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 28991029248 108431147008 q12Shape25T554=true := by decide

private def q12Shape25T555 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T555OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 97710505984 39711670272 q12Shape25T555=true := by decide

private def q12Shape25T553 : Tree 12 := .split 36 q12Shape25T554 q12Shape25T555
private theorem q12Shape25T553OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 28991029248 39711670272 q12Shape25T553=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 28991029248 (39711670272 ||| 2^36) q12Shape25T554 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (28991029248 ||| 2^36) 39711670272 q12Shape25T555)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T554OK,q12Shape25T555OK⟩

private def q12Shape25T556 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T556OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 63350767616 5351931904 q12Shape25T556=true := by decide

private def q12Shape25T552 : Tree 12 := .split 35 q12Shape25T553 q12Shape25T556
private theorem q12Shape25T552OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 28991029248 5351931904 q12Shape25T552=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 28991029248 (5351931904 ||| 2^35) q12Shape25T553 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (28991029248 ||| 2^35) 5351931904 q12Shape25T556)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T553OK,q12Shape25T556OK⟩

private def q12Shape25T546 : Tree 12 := .split 34 q12Shape25T547 q12Shape25T552
private theorem q12Shape25T546OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11811160064 5351931904 q12Shape25T546=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11811160064 (5351931904 ||| 2^34) q12Shape25T547 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11811160064 ||| 2^34) 5351931904 q12Shape25T552)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T547OK,q12Shape25T552OK⟩

private def q12Shape25T530 : Tree 12 := .split 33 q12Shape25T531 q12Shape25T546
private theorem q12Shape25T530OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 5351931904 q12Shape25T530=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 (5351931904 ||| 2^33) q12Shape25T531 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3221225472 ||| 2^33) 5351931904 q12Shape25T546)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T531OK,q12Shape25T546OK⟩

def q12Shape25P20 : Tree 12 := q12Shape25T530
theorem q12Shape25P20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3221225472 5351931904 q12Shape25P20=true := q12Shape25T530OK

end Graffiti384b.EffectiveSearch.Q12
