import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T561 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T561OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 129905983488 q12Shape25T561=true := by decide

private def q12Shape25T562 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T562OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 76235669504 61186506752 q12Shape25T562=true := by decide

private def q12Shape25T560 : Tree 12 := .split 36 q12Shape25T561 q12Shape25T562
private theorem q12Shape25T560OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 61186506752 q12Shape25T560=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 (61186506752 ||| 2^36) q12Shape25T561 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (7516192768 ||| 2^36) 61186506752 q12Shape25T562)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T561OK,q12Shape25T562OK⟩

private def q12Shape25T563 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T563OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 41875931136 26826768384 q12Shape25T563=true := by decide

private def q12Shape25T559 : Tree 12 := .split 35 q12Shape25T560 q12Shape25T563
private theorem q12Shape25T559OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 26826768384 q12Shape25T559=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 (26826768384 ||| 2^35) q12Shape25T560 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (7516192768 ||| 2^35) 26826768384 q12Shape25T563)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T560OK,q12Shape25T563OK⟩

private def q12Shape25T566 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T566OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24696061952 112726114304 q12Shape25T566=true := by decide

private def q12Shape25T567 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T567OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 93415538688 44006637568 q12Shape25T567=true := by decide

private def q12Shape25T565 : Tree 12 := .split 36 q12Shape25T566 q12Shape25T567
private theorem q12Shape25T565OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24696061952 44006637568 q12Shape25T565=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24696061952 (44006637568 ||| 2^36) q12Shape25T566 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (24696061952 ||| 2^36) 44006637568 q12Shape25T567)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T566OK,q12Shape25T567OK⟩

private def q12Shape25T568 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T568OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 59055800320 9646899200 q12Shape25T568=true := by decide

private def q12Shape25T564 : Tree 12 := .split 35 q12Shape25T565 q12Shape25T568
private theorem q12Shape25T564OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24696061952 9646899200 q12Shape25T564=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24696061952 (9646899200 ||| 2^35) q12Shape25T565 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (24696061952 ||| 2^35) 9646899200 q12Shape25T568)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T565OK,q12Shape25T568OK⟩

private def q12Shape25T558 : Tree 12 := .split 34 q12Shape25T559 q12Shape25T564
private theorem q12Shape25T558OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 9646899200 q12Shape25T558=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 (9646899200 ||| 2^34) q12Shape25T559 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (7516192768 ||| 2^34) 9646899200 q12Shape25T564)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T559OK,q12Shape25T564OK⟩

private def q12Shape25T572 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape25T572OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16106127360 121316048896 q12Shape25T572=true := by decide

private def q12Shape25T573 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T573OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 84825604096 52596572160 q12Shape25T573=true := by decide

private def q12Shape25T571 : Tree 12 := .split 36 q12Shape25T572 q12Shape25T573
private theorem q12Shape25T571OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16106127360 52596572160 q12Shape25T571=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16106127360 (52596572160 ||| 2^36) q12Shape25T572 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16106127360 ||| 2^36) 52596572160 q12Shape25T573)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T572OK,q12Shape25T573OK⟩

private def q12Shape25T574 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T574OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50465865728 18236833792 q12Shape25T574=true := by decide

private def q12Shape25T570 : Tree 12 := .split 35 q12Shape25T571 q12Shape25T574
private theorem q12Shape25T570OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16106127360 18236833792 q12Shape25T570=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16106127360 (18236833792 ||| 2^35) q12Shape25T571 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16106127360 ||| 2^35) 18236833792 q12Shape25T574)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T571OK,q12Shape25T574OK⟩

private def q12Shape25T577 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T577OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33285996544 104136179712 q12Shape25T577=true := by decide

private def q12Shape25T578 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T578OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 102005473280 35416702976 q12Shape25T578=true := by decide

private def q12Shape25T576 : Tree 12 := .split 36 q12Shape25T577 q12Shape25T578
private theorem q12Shape25T576OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33285996544 35416702976 q12Shape25T576=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33285996544 (35416702976 ||| 2^36) q12Shape25T577 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33285996544 ||| 2^36) 35416702976 q12Shape25T578)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T577OK,q12Shape25T578OK⟩

private def q12Shape25T579 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T579OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67645734912 1056964608 q12Shape25T579=true := by decide

private def q12Shape25T575 : Tree 12 := .split 35 q12Shape25T576 q12Shape25T579
private theorem q12Shape25T575OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33285996544 1056964608 q12Shape25T575=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33285996544 (1056964608 ||| 2^35) q12Shape25T576 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33285996544 ||| 2^35) 1056964608 q12Shape25T579)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T576OK,q12Shape25T579OK⟩

private def q12Shape25T569 : Tree 12 := .split 34 q12Shape25T570 q12Shape25T575
private theorem q12Shape25T569OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16106127360 1056964608 q12Shape25T569=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16106127360 (1056964608 ||| 2^34) q12Shape25T570 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16106127360 ||| 2^34) 1056964608 q12Shape25T575)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T570OK,q12Shape25T575OK⟩

private def q12Shape25T557 : Tree 12 := .split 33 q12Shape25T558 q12Shape25T569
private theorem q12Shape25T557OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 1056964608 q12Shape25T557=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 (1056964608 ||| 2^33) q12Shape25T558 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (7516192768 ||| 2^33) 1056964608 q12Shape25T569)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T558OK,q12Shape25T569OK⟩

def q12Shape25P21 : Tree 12 := q12Shape25T557
theorem q12Shape25P21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7516192768 1056964608 q12Shape25P21=true := q12Shape25T557OK

end Graffiti384b.EffectiveSearch.Q12
