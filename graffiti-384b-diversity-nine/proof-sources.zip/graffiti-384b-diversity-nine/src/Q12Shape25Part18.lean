import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T591 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,9,10})))))
private theorem q12Shape25T591OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 274324258816 q12Shape25T591=true := by decide

private def q12Shape25T592 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T592OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137975824384 136885305344 q12Shape25T592=true := by decide

private def q12Shape25T590 : Tree 12 := .split 37 q12Shape25T591 q12Shape25T592
private theorem q12Shape25T590OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 136885305344 q12Shape25T590=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (136885305344 ||| 2^37) q12Shape25T591 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^37) 136885305344 q12Shape25T592)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T591OK,q12Shape25T592OK⟩

private def q12Shape25T593 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T593OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69256347648 68165828608 q12Shape25T593=true := by decide

private def q12Shape25T589 : Tree 12 := .split 36 q12Shape25T590 q12Shape25T593
private theorem q12Shape25T589OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 68165828608 q12Shape25T589=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (68165828608 ||| 2^36) q12Shape25T590 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^36) 68165828608 q12Shape25T593)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T590OK,q12Shape25T593OK⟩

private def q12Shape25T595 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,6,7,8,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T595OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34896609280 102525566976 q12Shape25T595=true := by decide

private def q12Shape25T596 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T596OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103616086016 33806090240 q12Shape25T596=true := by decide

private def q12Shape25T594 : Tree 12 := .split 36 q12Shape25T595 q12Shape25T596
private theorem q12Shape25T594OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34896609280 33806090240 q12Shape25T594=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34896609280 (33806090240 ||| 2^36) q12Shape25T595 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34896609280 ||| 2^36) 33806090240 q12Shape25T596)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T595OK,q12Shape25T596OK⟩

private def q12Shape25T588 : Tree 12 := .split 35 q12Shape25T589 q12Shape25T594
private theorem q12Shape25T588OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 33806090240 q12Shape25T588=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (33806090240 ||| 2^35) q12Shape25T589 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^35) 33806090240 q12Shape25T594)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T589OK,q12Shape25T594OK⟩

private def q12Shape25T597 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T597OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17716740096 16626221056 q12Shape25T597=true := by decide

private def q12Shape25T587 : Tree 12 := .split 34 q12Shape25T588 q12Shape25T597
private theorem q12Shape25T587OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 16626221056 q12Shape25T587=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (16626221056 ||| 2^34) q12Shape25T588 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^34) 16626221056 q12Shape25T597)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T588OK,q12Shape25T597OK⟩

private def q12Shape25T598 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T598OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9126805504 8036286464 q12Shape25T598=true := by decide

private def q12Shape25T586 : Tree 12 := .split 33 q12Shape25T587 q12Shape25T598
private theorem q12Shape25T586OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 8036286464 q12Shape25T586=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (8036286464 ||| 2^33) q12Shape25T587 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^33) 8036286464 q12Shape25T598)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T587OK,q12Shape25T598OK⟩

private def q12Shape25T599 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T599OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4831838208 3741319168 q12Shape25T599=true := by decide

private def q12Shape25T585 : Tree 12 := .split 32 q12Shape25T586 q12Shape25T599
private theorem q12Shape25T585OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 3741319168 q12Shape25T585=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (3741319168 ||| 2^32) q12Shape25T586 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^32) 3741319168 q12Shape25T599)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T586OK,q12Shape25T599OK⟩

private def q12Shape25T600 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T600OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2684354560 1593835520 q12Shape25T600=true := by decide

private def q12Shape25T584 : Tree 12 := .split 31 q12Shape25T585 q12Shape25T600
private theorem q12Shape25T584OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 1593835520 q12Shape25T584=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (1593835520 ||| 2^31) q12Shape25T585 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^31) 1593835520 q12Shape25T600)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T585OK,q12Shape25T600OK⟩

private def q12Shape25T601 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T601OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1610612736 520093696 q12Shape25T601=true := by decide

private def q12Shape25T583 : Tree 12 := .split 30 q12Shape25T584 q12Shape25T601
private theorem q12Shape25T583OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 520093696 q12Shape25T583=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 (520093696 ||| 2^30) q12Shape25T584 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (536870912 ||| 2^30) 520093696 q12Shape25T601)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T584OK,q12Shape25T601OK⟩

def q12Shape25P22 : Tree 12 := q12Shape25T583
theorem q12Shape25P22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 536870912 520093696 q12Shape25P22=true := q12Shape25T583OK

private def q12Shape25T612 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))))
private theorem q12Shape25T612OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 274592694272 q12Shape25T612=true := by decide

private def q12Shape25T613 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T613OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137707388928 137153740800 q12Shape25T613=true := by decide

private def q12Shape25T611 : Tree 12 := .split 37 q12Shape25T612 q12Shape25T613
private theorem q12Shape25T611OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 137153740800 q12Shape25T611=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (137153740800 ||| 2^37) q12Shape25T612 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^37) 137153740800 q12Shape25T613)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T612OK,q12Shape25T613OK⟩

private def q12Shape25T614 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T614OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68987912192 68434264064 q12Shape25T614=true := by decide

private def q12Shape25T610 : Tree 12 := .split 36 q12Shape25T611 q12Shape25T614
private theorem q12Shape25T610OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 68434264064 q12Shape25T610=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (68434264064 ||| 2^36) q12Shape25T611 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^36) 68434264064 q12Shape25T614)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T611OK,q12Shape25T614OK⟩

private def q12Shape25T616 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,6,7,8,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T616OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34628173824 102794002432 q12Shape25T616=true := by decide

private def q12Shape25T617 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T617OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103347650560 34074525696 q12Shape25T617=true := by decide

private def q12Shape25T615 : Tree 12 := .split 36 q12Shape25T616 q12Shape25T617
private theorem q12Shape25T615OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34628173824 34074525696 q12Shape25T615=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34628173824 (34074525696 ||| 2^36) q12Shape25T616 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34628173824 ||| 2^36) 34074525696 q12Shape25T617)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T616OK,q12Shape25T617OK⟩

private def q12Shape25T609 : Tree 12 := .split 35 q12Shape25T610 q12Shape25T615
private theorem q12Shape25T609OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 34074525696 q12Shape25T609=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (34074525696 ||| 2^35) q12Shape25T610 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^35) 34074525696 q12Shape25T615)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T610OK,q12Shape25T615OK⟩

private def q12Shape25T618 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T618OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17448304640 16894656512 q12Shape25T618=true := by decide

private def q12Shape25T608 : Tree 12 := .split 34 q12Shape25T609 q12Shape25T618
private theorem q12Shape25T608OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 16894656512 q12Shape25T608=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (16894656512 ||| 2^34) q12Shape25T609 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^34) 16894656512 q12Shape25T618)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T609OK,q12Shape25T618OK⟩

private def q12Shape25T619 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T619OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8858370048 8304721920 q12Shape25T619=true := by decide

private def q12Shape25T607 : Tree 12 := .split 33 q12Shape25T608 q12Shape25T619
private theorem q12Shape25T607OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 8304721920 q12Shape25T607=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (8304721920 ||| 2^33) q12Shape25T608 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^33) 8304721920 q12Shape25T619)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T608OK,q12Shape25T619OK⟩

private def q12Shape25T620 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T620OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4563402752 4009754624 q12Shape25T620=true := by decide

private def q12Shape25T606 : Tree 12 := .split 32 q12Shape25T607 q12Shape25T620
private theorem q12Shape25T606OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 4009754624 q12Shape25T606=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (4009754624 ||| 2^32) q12Shape25T607 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^32) 4009754624 q12Shape25T620)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T607OK,q12Shape25T620OK⟩

private def q12Shape25T621 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T621OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2415919104 1862270976 q12Shape25T621=true := by decide

private def q12Shape25T605 : Tree 12 := .split 31 q12Shape25T606 q12Shape25T621
private theorem q12Shape25T605OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 1862270976 q12Shape25T605=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (1862270976 ||| 2^31) q12Shape25T606 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^31) 1862270976 q12Shape25T621)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T606OK,q12Shape25T621OK⟩

private def q12Shape25T622 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T622OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1342177280 788529152 q12Shape25T622=true := by decide

private def q12Shape25T604 : Tree 12 := .split 30 q12Shape25T605 q12Shape25T622
private theorem q12Shape25T604OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 788529152 q12Shape25T604=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (788529152 ||| 2^30) q12Shape25T605 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^30) 788529152 q12Shape25T622)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T605OK,q12Shape25T622OK⟩

private def q12Shape25T623 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,6,9,10,11})) (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T623OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 805306368 251658240 q12Shape25T623=true := by decide

private def q12Shape25T603 : Tree 12 := .split 29 q12Shape25T604 q12Shape25T623
private theorem q12Shape25T603OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 251658240 q12Shape25T603=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 (251658240 ||| 2^29) q12Shape25T604 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (268435456 ||| 2^29) 251658240 q12Shape25T623)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T604OK,q12Shape25T623OK⟩

def q12Shape25P23 : Tree 12 := q12Shape25T603
theorem q12Shape25P23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 268435456 251658240 q12Shape25P23=true := q12Shape25T603OK

end Graffiti384b.EffectiveSearch.Q12
