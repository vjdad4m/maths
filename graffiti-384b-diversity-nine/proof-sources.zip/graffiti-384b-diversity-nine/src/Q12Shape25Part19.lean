import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T635 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))))
private theorem q12Shape25T635OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 274726912000 q12Shape25T635=true := by decide

private def q12Shape25T636 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T636OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137573171200 137287958528 q12Shape25T636=true := by decide

private def q12Shape25T634 : Tree 12 := .split 37 q12Shape25T635 q12Shape25T636
private theorem q12Shape25T634OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 137287958528 q12Shape25T634=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (137287958528 ||| 2^37) q12Shape25T635 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^37) 137287958528 q12Shape25T636)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T635OK,q12Shape25T636OK⟩

private def q12Shape25T637 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T637OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68853694464 68568481792 q12Shape25T637=true := by decide

private def q12Shape25T633 : Tree 12 := .split 36 q12Shape25T634 q12Shape25T637
private theorem q12Shape25T633OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 68568481792 q12Shape25T633=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (68568481792 ||| 2^36) q12Shape25T634 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^36) 68568481792 q12Shape25T637)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T634OK,q12Shape25T637OK⟩

private def q12Shape25T640 : Tree 12 := (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,6,7,8,9,10}))))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T640OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34493956096 240367173632 q12Shape25T640=true := by decide

private def q12Shape25T641 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T641OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171932909568 102928220160 q12Shape25T641=true := by decide

private def q12Shape25T639 : Tree 12 := .split 37 q12Shape25T640 q12Shape25T641
private theorem q12Shape25T639OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34493956096 102928220160 q12Shape25T639=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34493956096 (102928220160 ||| 2^37) q12Shape25T640 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34493956096 ||| 2^37) 102928220160 q12Shape25T641)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T640OK,q12Shape25T641OK⟩

private def q12Shape25T642 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T642OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103213432832 34208743424 q12Shape25T642=true := by decide

private def q12Shape25T638 : Tree 12 := .split 36 q12Shape25T639 q12Shape25T642
private theorem q12Shape25T638OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34493956096 34208743424 q12Shape25T638=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34493956096 (34208743424 ||| 2^36) q12Shape25T639 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34493956096 ||| 2^36) 34208743424 q12Shape25T642)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T639OK,q12Shape25T642OK⟩

private def q12Shape25T632 : Tree 12 := .split 35 q12Shape25T633 q12Shape25T638
private theorem q12Shape25T632OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 34208743424 q12Shape25T632=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (34208743424 ||| 2^35) q12Shape25T633 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^35) 34208743424 q12Shape25T638)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T633OK,q12Shape25T638OK⟩

private def q12Shape25T643 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T643OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17314086912 17028874240 q12Shape25T643=true := by decide

private def q12Shape25T631 : Tree 12 := .split 34 q12Shape25T632 q12Shape25T643
private theorem q12Shape25T631OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 17028874240 q12Shape25T631=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (17028874240 ||| 2^34) q12Shape25T632 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^34) 17028874240 q12Shape25T643)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T632OK,q12Shape25T643OK⟩

private def q12Shape25T644 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T644OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8724152320 8438939648 q12Shape25T644=true := by decide

private def q12Shape25T630 : Tree 12 := .split 33 q12Shape25T631 q12Shape25T644
private theorem q12Shape25T630OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 8438939648 q12Shape25T630=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (8438939648 ||| 2^33) q12Shape25T631 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^33) 8438939648 q12Shape25T644)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T631OK,q12Shape25T644OK⟩

private def q12Shape25T645 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T645OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4429185024 4143972352 q12Shape25T645=true := by decide

private def q12Shape25T629 : Tree 12 := .split 32 q12Shape25T630 q12Shape25T645
private theorem q12Shape25T629OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 4143972352 q12Shape25T629=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (4143972352 ||| 2^32) q12Shape25T630 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^32) 4143972352 q12Shape25T645)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T630OK,q12Shape25T645OK⟩

private def q12Shape25T646 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T646OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2281701376 1996488704 q12Shape25T646=true := by decide

private def q12Shape25T628 : Tree 12 := .split 31 q12Shape25T629 q12Shape25T646
private theorem q12Shape25T628OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 1996488704 q12Shape25T628=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (1996488704 ||| 2^31) q12Shape25T629 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^31) 1996488704 q12Shape25T646)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T629OK,q12Shape25T646OK⟩

private def q12Shape25T647 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T647OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1207959552 922746880 q12Shape25T647=true := by decide

private def q12Shape25T627 : Tree 12 := .split 30 q12Shape25T628 q12Shape25T647
private theorem q12Shape25T627OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 922746880 q12Shape25T627=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (922746880 ||| 2^30) q12Shape25T628 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^30) 922746880 q12Shape25T647)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T628OK,q12Shape25T647OK⟩

private def q12Shape25T649 : Tree 12 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,6,9,10,11})) (.split 36 (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T649OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 671088640 1459617792 q12Shape25T649=true := by decide

private def q12Shape25T650 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T650OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1744830464 385875968 q12Shape25T650=true := by decide

private def q12Shape25T648 : Tree 12 := .split 30 q12Shape25T649 q12Shape25T650
private theorem q12Shape25T648OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 671088640 385875968 q12Shape25T648=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 671088640 (385875968 ||| 2^30) q12Shape25T649 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (671088640 ||| 2^30) 385875968 q12Shape25T650)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T649OK,q12Shape25T650OK⟩

private def q12Shape25T626 : Tree 12 := .split 29 q12Shape25T627 q12Shape25T648
private theorem q12Shape25T626OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 385875968 q12Shape25T626=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (385875968 ||| 2^29) q12Shape25T627 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^29) 385875968 q12Shape25T648)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T627OK,q12Shape25T648OK⟩

private def q12Shape25T654 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,6,9,10,11})) (.split 36 (.split 37 (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T654OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 402653184 3875536896 q12Shape25T654=true := by decide

private def q12Shape25T655 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T655OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2550136832 1728053248 q12Shape25T655=true := by decide

private def q12Shape25T653 : Tree 12 := .split 31 q12Shape25T654 q12Shape25T655
private theorem q12Shape25T653OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 402653184 1728053248 q12Shape25T653=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 402653184 (1728053248 ||| 2^31) q12Shape25T654 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (402653184 ||| 2^31) 1728053248 q12Shape25T655)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T654OK,q12Shape25T655OK⟩

private def q12Shape25T656 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T656OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1476395008 654311424 q12Shape25T656=true := by decide

private def q12Shape25T652 : Tree 12 := .split 30 q12Shape25T653 q12Shape25T656
private theorem q12Shape25T652OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 402653184 654311424 q12Shape25T652=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 402653184 (654311424 ||| 2^30) q12Shape25T653 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (402653184 ||| 2^30) 654311424 q12Shape25T656)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T653OK,q12Shape25T656OK⟩

private def q12Shape25T663 : Tree 12 := (.tip (.cover {2,3,4,6,9,10,11}))
private theorem q12Shape25T663OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 67763175424 q12Shape25T663=true := by decide

private def q12Shape25T665 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T665OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35299262464 102122913792 q12Shape25T665=true := by decide

private def q12Shape25T666 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T666OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 104018739200 33403437056 q12Shape25T666=true := by decide

private def q12Shape25T664 : Tree 12 := .split 36 q12Shape25T665 q12Shape25T666
private theorem q12Shape25T664OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35299262464 33403437056 q12Shape25T664=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35299262464 (33403437056 ||| 2^36) q12Shape25T665 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (35299262464 ||| 2^36) 33403437056 q12Shape25T666)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T665OK,q12Shape25T666OK⟩

private def q12Shape25T662 : Tree 12 := .split 35 q12Shape25T663 q12Shape25T664
private theorem q12Shape25T662OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 33403437056 q12Shape25T662=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 (33403437056 ||| 2^35) q12Shape25T663 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (939524096 ||| 2^35) 33403437056 q12Shape25T664)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T663OK,q12Shape25T664OK⟩

private def q12Shape25T667 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T667OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18119393280 16223567872 q12Shape25T667=true := by decide

private def q12Shape25T661 : Tree 12 := .split 34 q12Shape25T662 q12Shape25T667
private theorem q12Shape25T661OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 16223567872 q12Shape25T661=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 (16223567872 ||| 2^34) q12Shape25T662 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (939524096 ||| 2^34) 16223567872 q12Shape25T667)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T662OK,q12Shape25T667OK⟩

private def q12Shape25T668 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T668OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9529458688 7633633280 q12Shape25T668=true := by decide

private def q12Shape25T660 : Tree 12 := .split 33 q12Shape25T661 q12Shape25T668
private theorem q12Shape25T660OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 7633633280 q12Shape25T660=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 (7633633280 ||| 2^33) q12Shape25T661 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (939524096 ||| 2^33) 7633633280 q12Shape25T668)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T661OK,q12Shape25T668OK⟩

private def q12Shape25T669 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T669OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5234491392 3338665984 q12Shape25T669=true := by decide

private def q12Shape25T659 : Tree 12 := .split 32 q12Shape25T660 q12Shape25T669
private theorem q12Shape25T659OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 3338665984 q12Shape25T659=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 (3338665984 ||| 2^32) q12Shape25T660 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (939524096 ||| 2^32) 3338665984 q12Shape25T669)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T660OK,q12Shape25T669OK⟩

private def q12Shape25T670 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T670OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3087007744 1191182336 q12Shape25T670=true := by decide

private def q12Shape25T658 : Tree 12 := .split 31 q12Shape25T659 q12Shape25T670
private theorem q12Shape25T658OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 1191182336 q12Shape25T658=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 (1191182336 ||| 2^31) q12Shape25T659 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (939524096 ||| 2^31) 1191182336 q12Shape25T670)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T659OK,q12Shape25T670OK⟩

private def q12Shape25T671 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T671OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2013265920 117440512 q12Shape25T671=true := by decide

private def q12Shape25T657 : Tree 12 := .split 30 q12Shape25T658 q12Shape25T671
private theorem q12Shape25T657OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 117440512 q12Shape25T657=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 939524096 (117440512 ||| 2^30) q12Shape25T658 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (939524096 ||| 2^30) 117440512 q12Shape25T671)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T658OK,q12Shape25T671OK⟩

private def q12Shape25T651 : Tree 12 := .split 29 q12Shape25T652 q12Shape25T657
private theorem q12Shape25T651OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 402653184 117440512 q12Shape25T651=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 402653184 (117440512 ||| 2^29) q12Shape25T652 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (402653184 ||| 2^29) 117440512 q12Shape25T657)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T652OK,q12Shape25T657OK⟩

private def q12Shape25T625 : Tree 12 := .split 28 q12Shape25T626 q12Shape25T651
private theorem q12Shape25T625OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 117440512 q12Shape25T625=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 (117440512 ||| 2^28) q12Shape25T626 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (134217728 ||| 2^28) 117440512 q12Shape25T651)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T626OK,q12Shape25T651OK⟩

def q12Shape25P24 : Tree 12 := q12Shape25T625
theorem q12Shape25P24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 134217728 117440512 q12Shape25P24=true := q12Shape25T625OK

end Graffiti384b.EffectiveSearch.Q12
