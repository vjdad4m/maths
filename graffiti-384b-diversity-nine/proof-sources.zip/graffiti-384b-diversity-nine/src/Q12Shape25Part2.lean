import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T84 : Tree 12 := (.tip (.cover {2,3,4,5,6,9,11}))
private theorem q12Shape25T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 2130287001600 q12Shape25T84=true := by decide

private def q12Shape25T86 : Tree 12 := (.tip (.cover {2,3,4,5,6,9,10}))
private theorem q12Shape25T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1168231104512 3229798629376 q12Shape25T86=true := by decide

private def q12Shape25T90 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,8}))
private theorem q12Shape25T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3367254360064 31817100951552 q12Shape25T90=true := by decide

private def q12Shape25T94 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,9,10})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.tip (.cover {0,1,3,4,8,9,10})) (.tip (.cover {0,2,4,6,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10})))))
private theorem q12Shape25T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404480 14224914908172 q12Shape25T94=true := by decide

private def q12Shape25T95 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.tip (.cover {0,1,3,4,8,9,10})) (.tip (.cover {0,2,3,6,8,9,10})))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440405504 14224914907148 q12Shape25T95=true := by decide

private def q12Shape25T93 : Tree 12 := .split 10 q12Shape25T94 q12Shape25T95
private theorem q12Shape25T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404480 14224914907148 q12Shape25T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404480 (14224914907148 ||| 2^10) q12Shape25T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20959440404480 ||| 2^10) 14224914907148 q12Shape25T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T94OK,q12Shape25T95OK⟩

private def q12Shape25T97 : Tree 12 := (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.tip (.cover {0,3,4,6,8,9,10})) (.tip (.cover {0,1,2,5,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10})))) (.tip (.cover {2,3,4,5,7,8,10})))
private theorem q12Shape25T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404488 14224914908164 q12Shape25T97=true := by decide

private def q12Shape25T98 : Tree 12 := (.split 11 (.split 17 (.split 18 (.split 4 (.tip (.cover {0,3,4,6,8,9,10})) (.tip (.cover {0,1,2,5,8,9,10}))) (.tip (.cover {2,3,4,5,7,8,10}))) (.tip (.cover {2,3,4,6,7,8,10}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440405512 14224914907140 q12Shape25T98=true := by decide

private def q12Shape25T96 : Tree 12 := .split 10 q12Shape25T97 q12Shape25T98
private theorem q12Shape25T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404488 14224914907140 q12Shape25T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404488 (14224914907140 ||| 2^10) q12Shape25T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20959440404488 ||| 2^10) 14224914907140 q12Shape25T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T97OK,q12Shape25T98OK⟩

private def q12Shape25T92 : Tree 12 := .split 3 q12Shape25T93 q12Shape25T96
private theorem q12Shape25T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404480 14224914907140 q12Shape25T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404480 (14224914907140 ||| 2^3) q12Shape25T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20959440404480 ||| 2^3) 14224914907140 q12Shape25T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T93OK,q12Shape25T96OK⟩

private def q12Shape25T101 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.tip (.cover {1,3,4,5,8,9,10})) (.tip (.cover {0,1,2,6,8,9,10})))) (.tip (.cover {0,1,4,7,8,9,10}))) (.split 17 (.split 18 (.split 4 (.tip (.cover {1,3,4,5,8,9,10})) (.tip (.cover {0,1,2,6,8,9,10}))) (.tip (.cover {2,3,4,5,7,8,10}))) (.tip (.cover {2,3,4,6,7,8,10}))))
private theorem q12Shape25T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404484 14224914908168 q12Shape25T101=true := by decide

private def q12Shape25T102 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape25T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440405508 14224914907144 q12Shape25T102=true := by decide

private def q12Shape25T100 : Tree 12 := .split 10 q12Shape25T101 q12Shape25T102
private theorem q12Shape25T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404484 14224914907144 q12Shape25T100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404484 (14224914907144 ||| 2^10) q12Shape25T101 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20959440404484 ||| 2^10) 14224914907144 q12Shape25T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T101OK,q12Shape25T102OK⟩

private def q12Shape25T103 : Tree 12 := (.tip (.cover {0,1,2,7,8,9,10}))
private theorem q12Shape25T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404492 14224914907136 q12Shape25T103=true := by decide

private def q12Shape25T99 : Tree 12 := .split 3 q12Shape25T100 q12Shape25T103
private theorem q12Shape25T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404484 14224914907136 q12Shape25T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404484 (14224914907136 ||| 2^3) q12Shape25T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20959440404484 ||| 2^3) 14224914907136 q12Shape25T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T100OK,q12Shape25T103OK⟩

private def q12Shape25T91 : Tree 12 := .split 2 q12Shape25T92 q12Shape25T99
private theorem q12Shape25T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404480 14224914907136 q12Shape25T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20959440404480 (14224914907136 ||| 2^2) q12Shape25T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (20959440404480 ||| 2^2) 14224914907136 q12Shape25T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T92OK,q12Shape25T99OK⟩

private def q12Shape25T89 : Tree 12 := .split 44 q12Shape25T90 q12Shape25T91
private theorem q12Shape25T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3367254360064 14224914907136 q12Shape25T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3367254360064 (14224914907136 ||| 2^44) q12Shape25T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3367254360064 ||| 2^44) 14224914907136 q12Shape25T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T90OK,q12Shape25T91OK⟩

private def q12Shape25T104 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape25T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 12163347382272 5428821884928 q12Shape25T104=true := by decide

private def q12Shape25T88 : Tree 12 := .split 43 q12Shape25T89 q12Shape25T104
private theorem q12Shape25T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3367254360064 5428821884928 q12Shape25T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3367254360064 (5428821884928 ||| 2^43) q12Shape25T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3367254360064 ||| 2^43) 5428821884928 q12Shape25T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T89OK,q12Shape25T104OK⟩

private def q12Shape25T105 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape25T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7765300871168 1030775373824 q12Shape25T105=true := by decide

private def q12Shape25T87 : Tree 12 := .split 42 q12Shape25T88 q12Shape25T105
private theorem q12Shape25T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3367254360064 1030775373824 q12Shape25T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3367254360064 (1030775373824 ||| 2^42) q12Shape25T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3367254360064 ||| 2^42) 1030775373824 q12Shape25T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T88OK,q12Shape25T105OK⟩

private def q12Shape25T85 : Tree 12 := .split 41 q12Shape25T86 q12Shape25T87
private theorem q12Shape25T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1168231104512 1030775373824 q12Shape25T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1168231104512 (1030775373824 ||| 2^41) q12Shape25T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1168231104512 ||| 2^41) 1030775373824 q12Shape25T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T86OK,q12Shape25T87OK⟩

private def q12Shape25T83 : Tree 12 := .split 40 q12Shape25T84 q12Shape25T85
private theorem q12Shape25T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 1030775373824 q12Shape25T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 (1030775373824 ||| 2^40) q12Shape25T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (68719476736 ||| 2^40) 1030775373824 q12Shape25T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T84OK,q12Shape25T85OK⟩

private def q12Shape25T106 : Tree 12 := (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))))
private theorem q12Shape25T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 618475290624 481019559936 q12Shape25T106=true := by decide

private def q12Shape25T82 : Tree 12 := .split 39 q12Shape25T83 q12Shape25T106
private theorem q12Shape25T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 481019559936 q12Shape25T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 (481019559936 ||| 2^39) q12Shape25T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (68719476736 ||| 2^39) 481019559936 q12Shape25T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T83OK,q12Shape25T106OK⟩

private def q12Shape25T109 : Tree 12 := (.tip (.cover {2,3,4,5,6,9,11}))
private theorem q12Shape25T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 343597383680 1855409094656 q12Shape25T109=true := by decide

private def q12Shape25T113 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape25T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1443109011456 16149060255744 q12Shape25T113=true := by decide

private def q12Shape25T118 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,9,10})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.tip (.cover {0,1,3,4,7,9,10})) (.tip (.cover {0,2,4,6,7,9,10}))) (.tip (.cover {0,4,6,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10})))))
private theorem q12Shape25T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 24945153278988 q12Shape25T118=true := by decide

private def q12Shape25T119 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.tip (.cover {0,1,3,4,7,9,10})) (.tip (.cover {0,2,3,6,7,9,10}))) (.tip (.cover {0,3,6,7,8,9,10})))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202034688 24945153277964 q12Shape25T119=true := by decide

private def q12Shape25T117 : Tree 12 := .split 10 q12Shape25T118 q12Shape25T119
private theorem q12Shape25T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 24945153277964 q12Shape25T117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 (24945153277964 ||| 2^10) q12Shape25T118 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033664 ||| 2^10) 24945153277964 q12Shape25T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T118OK,q12Shape25T119OK⟩

private def q12Shape25T121 : Tree 12 := (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10})))) (.tip (.cover {0,1,4,7,8,9,10})))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape25T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033672 24945153278980 q12Shape25T121=true := by decide

private def q12Shape25T122 : Tree 12 := (.split 11 (.split 17 (.split 18 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,5,7,9,10})))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,8,9}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202034696 24945153277956 q12Shape25T122=true := by decide

private def q12Shape25T120 : Tree 12 := .split 10 q12Shape25T121 q12Shape25T122
private theorem q12Shape25T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033672 24945153277956 q12Shape25T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033672 (24945153277956 ||| 2^10) q12Shape25T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033672 ||| 2^10) 24945153277956 q12Shape25T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T121OK,q12Shape25T122OK⟩

private def q12Shape25T116 : Tree 12 := .split 3 q12Shape25T117 q12Shape25T120
private theorem q12Shape25T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 24945153277956 q12Shape25T116=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 (24945153277956 ||| 2^3) q12Shape25T117 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033664 ||| 2^3) 24945153277956 q12Shape25T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T117OK,q12Shape25T120OK⟩

private def q12Shape25T126 : Tree 12 := (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.tip (.cover {1,3,4,5,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10}))))) (.tip (.cover {0,1,4,7,8,9,10})))
private theorem q12Shape25T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033668 24945153281032 q12Shape25T126=true := by decide

private def q12Shape25T127 : Tree 12 := (.split 17 (.split 18 (.split 4 (.split 5 (.tip (.cover {1,3,4,5,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,10})) (.tip (.cover {0,1,2,6,7,9,10})))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,8,9})))
private theorem q12Shape25T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202035716 24945153278984 q12Shape25T127=true := by decide

private def q12Shape25T125 : Tree 12 := .split 11 q12Shape25T126 q12Shape25T127
private theorem q12Shape25T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033668 24945153278984 q12Shape25T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033668 (24945153278984 ||| 2^11) q12Shape25T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033668 ||| 2^11) 24945153278984 q12Shape25T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T126OK,q12Shape25T127OK⟩

private def q12Shape25T128 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202034692 24945153277960 q12Shape25T128=true := by decide

private def q12Shape25T124 : Tree 12 := .split 10 q12Shape25T125 q12Shape25T128
private theorem q12Shape25T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033668 24945153277960 q12Shape25T124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033668 (24945153277960 ||| 2^10) q12Shape25T125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033668 ||| 2^10) 24945153277960 q12Shape25T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T125OK,q12Shape25T128OK⟩

private def q12Shape25T129 : Tree 12 := (.tip (.cover {0,1,2,7,8,9,10}))
private theorem q12Shape25T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033676 24945153277952 q12Shape25T129=true := by decide

private def q12Shape25T123 : Tree 12 := .split 3 q12Shape25T124 q12Shape25T129
private theorem q12Shape25T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033668 24945153277952 q12Shape25T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033668 (24945153277952 ||| 2^3) q12Shape25T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033668 ||| 2^3) 24945153277952 q12Shape25T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T124OK,q12Shape25T129OK⟩

private def q12Shape25T115 : Tree 12 := .split 2 q12Shape25T116 q12Shape25T123
private theorem q12Shape25T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 24945153277952 q12Shape25T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 (24945153277952 ||| 2^2) q12Shape25T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033664 ||| 2^2) 24945153277952 q12Shape25T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T116OK,q12Shape25T123OK⟩

private def q12Shape25T130 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,11}))
private theorem q12Shape25T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 27831388078080 7352967233536 q12Shape25T130=true := by decide

private def q12Shape25T114 : Tree 12 := .split 44 q12Shape25T115 q12Shape25T130
private theorem q12Shape25T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 7352967233536 q12Shape25T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10239202033664 (7352967233536 ||| 2^44) q12Shape25T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10239202033664 ||| 2^44) 7352967233536 q12Shape25T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T115OK,q12Shape25T130OK⟩

private def q12Shape25T112 : Tree 12 := .split 43 q12Shape25T113 q12Shape25T114
private theorem q12Shape25T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1443109011456 7352967233536 q12Shape25T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1443109011456 (7352967233536 ||| 2^43) q12Shape25T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1443109011456 ||| 2^43) 7352967233536 q12Shape25T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T113OK,q12Shape25T114OK⟩

private def q12Shape25T131 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape25T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5841155522560 2954920722432 q12Shape25T131=true := by decide

private def q12Shape25T111 : Tree 12 := .split 42 q12Shape25T112 q12Shape25T131
private theorem q12Shape25T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1443109011456 2954920722432 q12Shape25T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1443109011456 (2954920722432 ||| 2^42) q12Shape25T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1443109011456 ||| 2^42) 2954920722432 q12Shape25T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T112OK,q12Shape25T131OK⟩

private def q12Shape25T132 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape25T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3642132267008 755897466880 q12Shape25T132=true := by decide

private def q12Shape25T110 : Tree 12 := .split 41 q12Shape25T111 q12Shape25T132
private theorem q12Shape25T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1443109011456 755897466880 q12Shape25T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1443109011456 (755897466880 ||| 2^41) q12Shape25T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1443109011456 ||| 2^41) 755897466880 q12Shape25T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T111OK,q12Shape25T132OK⟩

private def q12Shape25T108 : Tree 12 := .split 40 q12Shape25T109 q12Shape25T110
private theorem q12Shape25T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 343597383680 755897466880 q12Shape25T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 343597383680 (755897466880 ||| 2^40) q12Shape25T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (343597383680 ||| 2^40) 755897466880 q12Shape25T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T109OK,q12Shape25T110OK⟩

private def q12Shape25T133 : Tree 12 := (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape25T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 893353197568 206141652992 q12Shape25T133=true := by decide

private def q12Shape25T107 : Tree 12 := .split 39 q12Shape25T108 q12Shape25T133
private theorem q12Shape25T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 343597383680 206141652992 q12Shape25T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 343597383680 (206141652992 ||| 2^39) q12Shape25T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (343597383680 ||| 2^39) 206141652992 q12Shape25T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T108OK,q12Shape25T133OK⟩

private def q12Shape25T81 : Tree 12 := .split 38 q12Shape25T82 q12Shape25T107
private theorem q12Shape25T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 206141652992 q12Shape25T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 (206141652992 ||| 2^38) q12Shape25T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (68719476736 ||| 2^38) 206141652992 q12Shape25T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T82OK,q12Shape25T107OK⟩

def q12Shape25P2 : Tree 12 := q12Shape25T81
theorem q12Shape25P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68719476736 206141652992 q12Shape25P2=true := q12Shape25T81OK

end Graffiti384b.EffectiveSearch.Q12
