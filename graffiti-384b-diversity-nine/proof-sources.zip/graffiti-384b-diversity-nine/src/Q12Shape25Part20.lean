import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T684 : Tree 12 := (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,9,11}))))))
private theorem q12Shape25T684OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 549671927808 q12Shape25T684=true := by decide

private def q12Shape25T685 : Tree 12 := (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,10})))))
private theorem q12Shape25T685OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 274945015808 274794020864 q12Shape25T685=true := by decide

private def q12Shape25T683 : Tree 12 := .split 38 q12Shape25T684 q12Shape25T685
private theorem q12Shape25T683OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 274794020864 q12Shape25T683=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (274794020864 ||| 2^38) q12Shape25T684 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^38) 274794020864 q12Shape25T685)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T684OK,q12Shape25T685OK⟩

private def q12Shape25T686 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,5,6,7,9,11})))) (.tip (.cover {0,1,6,7,8,9,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T686OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137506062336 137355067392 q12Shape25T686=true := by decide

private def q12Shape25T682 : Tree 12 := .split 37 q12Shape25T683 q12Shape25T686
private theorem q12Shape25T682OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 137355067392 q12Shape25T682=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (137355067392 ||| 2^37) q12Shape25T683 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^37) 137355067392 q12Shape25T686)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T683OK,q12Shape25T686OK⟩

private def q12Shape25T688 : Tree 12 := (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T688OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68786585600 206074544128 q12Shape25T688=true := by decide

private def q12Shape25T689 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T689OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206225539072 68635590656 q12Shape25T689=true := by decide

private def q12Shape25T687 : Tree 12 := .split 37 q12Shape25T688 q12Shape25T689
private theorem q12Shape25T687OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68786585600 68635590656 q12Shape25T687=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68786585600 (68635590656 ||| 2^37) q12Shape25T688 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (68786585600 ||| 2^37) 68635590656 q12Shape25T689)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T688OK,q12Shape25T689OK⟩

private def q12Shape25T681 : Tree 12 := .split 36 q12Shape25T682 q12Shape25T687
private theorem q12Shape25T681OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 68635590656 q12Shape25T681=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (68635590656 ||| 2^36) q12Shape25T682 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^36) 68635590656 q12Shape25T687)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T682OK,q12Shape25T687OK⟩

private def q12Shape25T695 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,5,6,7,10,11})))))
private theorem q12Shape25T695OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 2164579631104 q12Shape25T695=true := by decide

private def q12Shape25T696 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,9,11}))))
private theorem q12Shape25T696OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1133938475008 1065068003328 q12Shape25T696=true := by decide

private def q12Shape25T694 : Tree 12 := .split 40 q12Shape25T695 q12Shape25T696
private theorem q12Shape25T694OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 1065068003328 q12Shape25T694=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 (1065068003328 ||| 2^40) q12Shape25T695 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34426847232 ||| 2^40) 1065068003328 q12Shape25T696)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T695OK,q12Shape25T696OK⟩

private def q12Shape25T697 : Tree 12 := (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,10,11})))) (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,6,7,8,9,11})))))
private theorem q12Shape25T697OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 584182661120 515312189440 q12Shape25T697=true := by decide

private def q12Shape25T693 : Tree 12 := .split 39 q12Shape25T694 q12Shape25T697
private theorem q12Shape25T693OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 515312189440 q12Shape25T693=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 (515312189440 ||| 2^39) q12Shape25T694 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34426847232 ||| 2^39) 515312189440 q12Shape25T697)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T694OK,q12Shape25T697OK⟩

private def q12Shape25T698 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T698OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309304754176 240434282496 q12Shape25T698=true := by decide

private def q12Shape25T692 : Tree 12 := .split 38 q12Shape25T693 q12Shape25T698
private theorem q12Shape25T692OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 240434282496 q12Shape25T692=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 (240434282496 ||| 2^38) q12Shape25T693 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34426847232 ||| 2^38) 240434282496 q12Shape25T698)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T693OK,q12Shape25T698OK⟩

private def q12Shape25T699 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T699OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171865800704 102995329024 q12Shape25T699=true := by decide

private def q12Shape25T691 : Tree 12 := .split 37 q12Shape25T692 q12Shape25T699
private theorem q12Shape25T691OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 102995329024 q12Shape25T691=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 (102995329024 ||| 2^37) q12Shape25T692 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34426847232 ||| 2^37) 102995329024 q12Shape25T699)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T692OK,q12Shape25T699OK⟩

private def q12Shape25T700 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T700OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103146323968 34275852288 q12Shape25T700=true := by decide

private def q12Shape25T690 : Tree 12 := .split 36 q12Shape25T691 q12Shape25T700
private theorem q12Shape25T690OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 34275852288 q12Shape25T690=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34426847232 (34275852288 ||| 2^36) q12Shape25T691 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34426847232 ||| 2^36) 34275852288 q12Shape25T700)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T691OK,q12Shape25T700OK⟩

private def q12Shape25T680 : Tree 12 := .split 35 q12Shape25T681 q12Shape25T690
private theorem q12Shape25T680OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 34275852288 q12Shape25T680=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (34275852288 ||| 2^35) q12Shape25T681 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^35) 34275852288 q12Shape25T690)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T681OK,q12Shape25T690OK⟩

private def q12Shape25T701 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T701OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17246978048 17095983104 q12Shape25T701=true := by decide

private def q12Shape25T679 : Tree 12 := .split 34 q12Shape25T680 q12Shape25T701
private theorem q12Shape25T679OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 17095983104 q12Shape25T679=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (17095983104 ||| 2^34) q12Shape25T680 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^34) 17095983104 q12Shape25T701)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T680OK,q12Shape25T701OK⟩

private def q12Shape25T702 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T702OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8657043456 8506048512 q12Shape25T702=true := by decide

private def q12Shape25T678 : Tree 12 := .split 33 q12Shape25T679 q12Shape25T702
private theorem q12Shape25T678OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 8506048512 q12Shape25T678=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (8506048512 ||| 2^33) q12Shape25T679 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^33) 8506048512 q12Shape25T702)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T679OK,q12Shape25T702OK⟩

private def q12Shape25T703 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T703OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4362076160 4211081216 q12Shape25T703=true := by decide

private def q12Shape25T677 : Tree 12 := .split 32 q12Shape25T678 q12Shape25T703
private theorem q12Shape25T677OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 4211081216 q12Shape25T677=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (4211081216 ||| 2^32) q12Shape25T678 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^32) 4211081216 q12Shape25T703)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T678OK,q12Shape25T703OK⟩

private def q12Shape25T704 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T704OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2214592512 2063597568 q12Shape25T704=true := by decide

private def q12Shape25T676 : Tree 12 := .split 31 q12Shape25T677 q12Shape25T704
private theorem q12Shape25T676OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 2063597568 q12Shape25T676=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (2063597568 ||| 2^31) q12Shape25T677 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^31) 2063597568 q12Shape25T704)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T677OK,q12Shape25T704OK⟩

private def q12Shape25T705 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T705OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1140850688 989855744 q12Shape25T705=true := by decide

private def q12Shape25T675 : Tree 12 := .split 30 q12Shape25T676 q12Shape25T705
private theorem q12Shape25T675OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 989855744 q12Shape25T675=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (989855744 ||| 2^30) q12Shape25T676 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^30) 989855744 q12Shape25T705)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T676OK,q12Shape25T705OK⟩

private def q12Shape25T708 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 35 (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T708OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 603979776 3674210304 q12Shape25T708=true := by decide

private def q12Shape25T709 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T709OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2751463424 1526726656 q12Shape25T709=true := by decide

private def q12Shape25T707 : Tree 12 := .split 31 q12Shape25T708 q12Shape25T709
private theorem q12Shape25T707OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 603979776 1526726656 q12Shape25T707=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 603979776 (1526726656 ||| 2^31) q12Shape25T708 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (603979776 ||| 2^31) 1526726656 q12Shape25T709)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T708OK,q12Shape25T709OK⟩

private def q12Shape25T710 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T710OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1677721600 452984832 q12Shape25T710=true := by decide

private def q12Shape25T706 : Tree 12 := .split 30 q12Shape25T707 q12Shape25T710
private theorem q12Shape25T706OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 603979776 452984832 q12Shape25T706=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 603979776 (452984832 ||| 2^30) q12Shape25T707 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (603979776 ||| 2^30) 452984832 q12Shape25T710)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T707OK,q12Shape25T710OK⟩

private def q12Shape25T674 : Tree 12 := .split 29 q12Shape25T675 q12Shape25T706
private theorem q12Shape25T674OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 452984832 q12Shape25T674=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (452984832 ||| 2^29) q12Shape25T675 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^29) 452984832 q12Shape25T706)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T675OK,q12Shape25T706OK⟩

private def q12Shape25T715 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.split 37 (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))) (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T715OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 8237613056 q12Shape25T715=true := by decide

private def q12Shape25T716 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T716OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4630511616 3942645760 q12Shape25T716=true := by decide

private def q12Shape25T714 : Tree 12 := .split 32 q12Shape25T715 q12Shape25T716
private theorem q12Shape25T714OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 3942645760 q12Shape25T714=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 (3942645760 ||| 2^32) q12Shape25T715 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (335544320 ||| 2^32) 3942645760 q12Shape25T716)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T715OK,q12Shape25T716OK⟩

private def q12Shape25T717 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T717OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2483027968 1795162112 q12Shape25T717=true := by decide

private def q12Shape25T713 : Tree 12 := .split 31 q12Shape25T714 q12Shape25T717
private theorem q12Shape25T713OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 1795162112 q12Shape25T713=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 (1795162112 ||| 2^31) q12Shape25T714 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (335544320 ||| 2^31) 1795162112 q12Shape25T717)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T714OK,q12Shape25T717OK⟩

private def q12Shape25T718 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T718OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1409286144 721420288 q12Shape25T718=true := by decide

private def q12Shape25T712 : Tree 12 := .split 30 q12Shape25T713 q12Shape25T718
private theorem q12Shape25T712OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 721420288 q12Shape25T712=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 (721420288 ||| 2^30) q12Shape25T713 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (335544320 ||| 2^30) 721420288 q12Shape25T718)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T713OK,q12Shape25T718OK⟩

private def q12Shape25T725 : Tree 12 := (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T725OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 67830284288 q12Shape25T725=true := by decide

private def q12Shape25T726 : Tree 12 := (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T726OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35232153600 33470545920 q12Shape25T726=true := by decide

private def q12Shape25T724 : Tree 12 := .split 35 q12Shape25T725 q12Shape25T726
private theorem q12Shape25T724OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 33470545920 q12Shape25T724=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 (33470545920 ||| 2^35) q12Shape25T725 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (872415232 ||| 2^35) 33470545920 q12Shape25T726)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T725OK,q12Shape25T726OK⟩

private def q12Shape25T727 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T727OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18052284416 16290676736 q12Shape25T727=true := by decide

private def q12Shape25T723 : Tree 12 := .split 34 q12Shape25T724 q12Shape25T727
private theorem q12Shape25T723OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 16290676736 q12Shape25T723=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 (16290676736 ||| 2^34) q12Shape25T724 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (872415232 ||| 2^34) 16290676736 q12Shape25T727)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T724OK,q12Shape25T727OK⟩

private def q12Shape25T728 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T728OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9462349824 7700742144 q12Shape25T728=true := by decide

private def q12Shape25T722 : Tree 12 := .split 33 q12Shape25T723 q12Shape25T728
private theorem q12Shape25T722OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 7700742144 q12Shape25T722=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 (7700742144 ||| 2^33) q12Shape25T723 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (872415232 ||| 2^33) 7700742144 q12Shape25T728)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T723OK,q12Shape25T728OK⟩

private def q12Shape25T729 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T729OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5167382528 3405774848 q12Shape25T729=true := by decide

private def q12Shape25T721 : Tree 12 := .split 32 q12Shape25T722 q12Shape25T729
private theorem q12Shape25T721OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 3405774848 q12Shape25T721=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 (3405774848 ||| 2^32) q12Shape25T722 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (872415232 ||| 2^32) 3405774848 q12Shape25T729)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T722OK,q12Shape25T729OK⟩

private def q12Shape25T730 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T730OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3019898880 1258291200 q12Shape25T730=true := by decide

private def q12Shape25T720 : Tree 12 := .split 31 q12Shape25T721 q12Shape25T730
private theorem q12Shape25T720OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 1258291200 q12Shape25T720=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 (1258291200 ||| 2^31) q12Shape25T721 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (872415232 ||| 2^31) 1258291200 q12Shape25T730)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T721OK,q12Shape25T730OK⟩

private def q12Shape25T731 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T731OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1946157056 184549376 q12Shape25T731=true := by decide

private def q12Shape25T719 : Tree 12 := .split 30 q12Shape25T720 q12Shape25T731
private theorem q12Shape25T719OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 184549376 q12Shape25T719=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 872415232 (184549376 ||| 2^30) q12Shape25T720 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (872415232 ||| 2^30) 184549376 q12Shape25T731)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T720OK,q12Shape25T731OK⟩

private def q12Shape25T711 : Tree 12 := .split 29 q12Shape25T712 q12Shape25T719
private theorem q12Shape25T711OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 184549376 q12Shape25T711=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 335544320 (184549376 ||| 2^29) q12Shape25T712 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (335544320 ||| 2^29) 184549376 q12Shape25T719)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T712OK,q12Shape25T719OK⟩

private def q12Shape25T673 : Tree 12 := .split 28 q12Shape25T674 q12Shape25T711
private theorem q12Shape25T673OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 184549376 q12Shape25T673=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 (184549376 ||| 2^28) q12Shape25T674 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (67108864 ||| 2^28) 184549376 q12Shape25T711)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T674OK,q12Shape25T711OK⟩

def q12Shape25P25 : Tree 12 := q12Shape25T673
theorem q12Shape25P25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 67108864 184549376 q12Shape25P25=true := q12Shape25T673OK

end Graffiti384b.EffectiveSearch.Q12
