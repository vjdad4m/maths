import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T739 : Tree 12 := (.split 35 (.split 36 (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,6,8,9,10,11})))) (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.split 36 (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape25T739OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 34141634560 q12Shape25T739=true := by decide

private def q12Shape25T740 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T740OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17381195776 16961765376 q12Shape25T740=true := by decide

private def q12Shape25T738 : Tree 12 := .split 34 q12Shape25T739 q12Shape25T740
private theorem q12Shape25T738OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 16961765376 q12Shape25T738=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 (16961765376 ||| 2^34) q12Shape25T739 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (201326592 ||| 2^34) 16961765376 q12Shape25T740)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T739OK,q12Shape25T740OK⟩

private def q12Shape25T741 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T741OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8791261184 8371830784 q12Shape25T741=true := by decide

private def q12Shape25T737 : Tree 12 := .split 33 q12Shape25T738 q12Shape25T741
private theorem q12Shape25T737OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 8371830784 q12Shape25T737=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 (8371830784 ||| 2^33) q12Shape25T738 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (201326592 ||| 2^33) 8371830784 q12Shape25T741)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T738OK,q12Shape25T741OK⟩

private def q12Shape25T742 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T742OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4496293888 4076863488 q12Shape25T742=true := by decide

private def q12Shape25T736 : Tree 12 := .split 32 q12Shape25T737 q12Shape25T742
private theorem q12Shape25T736OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 4076863488 q12Shape25T736=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 (4076863488 ||| 2^32) q12Shape25T737 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (201326592 ||| 2^32) 4076863488 q12Shape25T742)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T737OK,q12Shape25T742OK⟩

private def q12Shape25T743 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T743OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2348810240 1929379840 q12Shape25T743=true := by decide

private def q12Shape25T735 : Tree 12 := .split 31 q12Shape25T736 q12Shape25T743
private theorem q12Shape25T735OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 1929379840 q12Shape25T735=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 (1929379840 ||| 2^31) q12Shape25T736 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (201326592 ||| 2^31) 1929379840 q12Shape25T743)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T736OK,q12Shape25T743OK⟩

private def q12Shape25T744 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T744OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1275068416 855638016 q12Shape25T744=true := by decide

private def q12Shape25T734 : Tree 12 := .split 30 q12Shape25T735 q12Shape25T744
private theorem q12Shape25T734OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 855638016 q12Shape25T734=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 (855638016 ||| 2^30) q12Shape25T735 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (201326592 ||| 2^30) 855638016 q12Shape25T744)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T735OK,q12Shape25T744OK⟩

private def q12Shape25T751 : Tree 12 := (.split 36 (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))) (.tip (.cover {0,1,6,8,9,10,11})))) (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T751OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 67964502016 q12Shape25T751=true := by decide

private def q12Shape25T752 : Tree 12 := (.split 36 (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T752OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35097935872 33604763648 q12Shape25T752=true := by decide

private def q12Shape25T750 : Tree 12 := .split 35 q12Shape25T751 q12Shape25T752
private theorem q12Shape25T750OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 33604763648 q12Shape25T750=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 (33604763648 ||| 2^35) q12Shape25T751 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (738197504 ||| 2^35) 33604763648 q12Shape25T752)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T751OK,q12Shape25T752OK⟩

private def q12Shape25T753 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T753OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17918066688 16424894464 q12Shape25T753=true := by decide

private def q12Shape25T749 : Tree 12 := .split 34 q12Shape25T750 q12Shape25T753
private theorem q12Shape25T749OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 16424894464 q12Shape25T749=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 (16424894464 ||| 2^34) q12Shape25T750 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (738197504 ||| 2^34) 16424894464 q12Shape25T753)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T750OK,q12Shape25T753OK⟩

private def q12Shape25T754 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T754OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9328132096 7834959872 q12Shape25T754=true := by decide

private def q12Shape25T748 : Tree 12 := .split 33 q12Shape25T749 q12Shape25T754
private theorem q12Shape25T748OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 7834959872 q12Shape25T748=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 (7834959872 ||| 2^33) q12Shape25T749 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (738197504 ||| 2^33) 7834959872 q12Shape25T754)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T749OK,q12Shape25T754OK⟩

private def q12Shape25T755 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T755OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5033164800 3539992576 q12Shape25T755=true := by decide

private def q12Shape25T747 : Tree 12 := .split 32 q12Shape25T748 q12Shape25T755
private theorem q12Shape25T747OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 3539992576 q12Shape25T747=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 (3539992576 ||| 2^32) q12Shape25T748 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (738197504 ||| 2^32) 3539992576 q12Shape25T755)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T748OK,q12Shape25T755OK⟩

private def q12Shape25T756 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T756OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2885681152 1392508928 q12Shape25T756=true := by decide

private def q12Shape25T746 : Tree 12 := .split 31 q12Shape25T747 q12Shape25T756
private theorem q12Shape25T746OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 1392508928 q12Shape25T746=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 (1392508928 ||| 2^31) q12Shape25T747 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (738197504 ||| 2^31) 1392508928 q12Shape25T756)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T747OK,q12Shape25T756OK⟩

private def q12Shape25T757 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T757OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1811939328 318767104 q12Shape25T757=true := by decide

private def q12Shape25T745 : Tree 12 := .split 30 q12Shape25T746 q12Shape25T757
private theorem q12Shape25T745OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 318767104 q12Shape25T745=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 738197504 (318767104 ||| 2^30) q12Shape25T746 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (738197504 ||| 2^30) 318767104 q12Shape25T757)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T746OK,q12Shape25T757OK⟩

private def q12Shape25T733 : Tree 12 := .split 29 q12Shape25T734 q12Shape25T745
private theorem q12Shape25T733OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 318767104 q12Shape25T733=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 (318767104 ||| 2^29) q12Shape25T734 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (201326592 ||| 2^29) 318767104 q12Shape25T745)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T734OK,q12Shape25T745OK⟩

private def q12Shape25T766 : Tree 12 := (.split 37 (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))))) (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T766OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 136952414208 q12Shape25T766=true := by decide

private def q12Shape25T767 : Tree 12 := (.split 37 (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T767OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69189238784 68232937472 q12Shape25T767=true := by decide

private def q12Shape25T765 : Tree 12 := .split 36 q12Shape25T766 q12Shape25T767
private theorem q12Shape25T765OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 68232937472 q12Shape25T765=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (68232937472 ||| 2^36) q12Shape25T766 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^36) 68232937472 q12Shape25T767)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T766OK,q12Shape25T767OK⟩

private def q12Shape25T768 : Tree 12 := (.split 36 (.split 37 (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T768OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34829500416 33873199104 q12Shape25T768=true := by decide

private def q12Shape25T764 : Tree 12 := .split 35 q12Shape25T765 q12Shape25T768
private theorem q12Shape25T764OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 33873199104 q12Shape25T764=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (33873199104 ||| 2^35) q12Shape25T765 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^35) 33873199104 q12Shape25T768)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T765OK,q12Shape25T768OK⟩

private def q12Shape25T769 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T769OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17649631232 16693329920 q12Shape25T769=true := by decide

private def q12Shape25T763 : Tree 12 := .split 34 q12Shape25T764 q12Shape25T769
private theorem q12Shape25T763OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 16693329920 q12Shape25T763=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (16693329920 ||| 2^34) q12Shape25T764 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^34) 16693329920 q12Shape25T769)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T764OK,q12Shape25T769OK⟩

private def q12Shape25T770 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T770OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9059696640 8103395328 q12Shape25T770=true := by decide

private def q12Shape25T762 : Tree 12 := .split 33 q12Shape25T763 q12Shape25T770
private theorem q12Shape25T762OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 8103395328 q12Shape25T762=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (8103395328 ||| 2^33) q12Shape25T763 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^33) 8103395328 q12Shape25T770)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T763OK,q12Shape25T770OK⟩

private def q12Shape25T771 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T771OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4764729344 3808428032 q12Shape25T771=true := by decide

private def q12Shape25T761 : Tree 12 := .split 32 q12Shape25T762 q12Shape25T771
private theorem q12Shape25T761OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 3808428032 q12Shape25T761=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (3808428032 ||| 2^32) q12Shape25T762 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^32) 3808428032 q12Shape25T771)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T762OK,q12Shape25T771OK⟩

private def q12Shape25T772 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T772OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2617245696 1660944384 q12Shape25T772=true := by decide

private def q12Shape25T760 : Tree 12 := .split 31 q12Shape25T761 q12Shape25T772
private theorem q12Shape25T760OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 1660944384 q12Shape25T760=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (1660944384 ||| 2^31) q12Shape25T761 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^31) 1660944384 q12Shape25T772)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T761OK,q12Shape25T772OK⟩

private def q12Shape25T773 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T773OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1543503872 587202560 q12Shape25T773=true := by decide

private def q12Shape25T759 : Tree 12 := .split 30 q12Shape25T760 q12Shape25T773
private theorem q12Shape25T759OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 587202560 q12Shape25T759=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (587202560 ||| 2^30) q12Shape25T760 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^30) 587202560 q12Shape25T773)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T760OK,q12Shape25T773OK⟩

private def q12Shape25T781 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T781OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 136415543296 q12Shape25T781=true := by decide

private def q12Shape25T782 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T782OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69726109696 67696066560 q12Shape25T782=true := by decide

private def q12Shape25T780 : Tree 12 := .split 36 q12Shape25T781 q12Shape25T782
private theorem q12Shape25T780OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 67696066560 q12Shape25T780=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 (67696066560 ||| 2^36) q12Shape25T781 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1006632960 ||| 2^36) 67696066560 q12Shape25T782)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T781OK,q12Shape25T782OK⟩

private def q12Shape25T783 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T783OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35366371328 33336328192 q12Shape25T783=true := by decide

private def q12Shape25T779 : Tree 12 := .split 35 q12Shape25T780 q12Shape25T783
private theorem q12Shape25T779OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 33336328192 q12Shape25T779=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 (33336328192 ||| 2^35) q12Shape25T780 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1006632960 ||| 2^35) 33336328192 q12Shape25T783)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T780OK,q12Shape25T783OK⟩

private def q12Shape25T784 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T784OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18186502144 16156459008 q12Shape25T784=true := by decide

private def q12Shape25T778 : Tree 12 := .split 34 q12Shape25T779 q12Shape25T784
private theorem q12Shape25T778OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 16156459008 q12Shape25T778=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 (16156459008 ||| 2^34) q12Shape25T779 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1006632960 ||| 2^34) 16156459008 q12Shape25T784)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T779OK,q12Shape25T784OK⟩

private def q12Shape25T785 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T785OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9596567552 7566524416 q12Shape25T785=true := by decide

private def q12Shape25T777 : Tree 12 := .split 33 q12Shape25T778 q12Shape25T785
private theorem q12Shape25T777OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 7566524416 q12Shape25T777=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 (7566524416 ||| 2^33) q12Shape25T778 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1006632960 ||| 2^33) 7566524416 q12Shape25T785)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T778OK,q12Shape25T785OK⟩

private def q12Shape25T786 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T786OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5301600256 3271557120 q12Shape25T786=true := by decide

private def q12Shape25T776 : Tree 12 := .split 32 q12Shape25T777 q12Shape25T786
private theorem q12Shape25T776OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 3271557120 q12Shape25T776=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 (3271557120 ||| 2^32) q12Shape25T777 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1006632960 ||| 2^32) 3271557120 q12Shape25T786)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T777OK,q12Shape25T786OK⟩

private def q12Shape25T787 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T787OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3154116608 1124073472 q12Shape25T787=true := by decide

private def q12Shape25T775 : Tree 12 := .split 31 q12Shape25T776 q12Shape25T787
private theorem q12Shape25T775OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 1124073472 q12Shape25T775=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 (1124073472 ||| 2^31) q12Shape25T776 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1006632960 ||| 2^31) 1124073472 q12Shape25T787)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T776OK,q12Shape25T787OK⟩

private def q12Shape25T788 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T788OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2080374784 50331648 q12Shape25T788=true := by decide

private def q12Shape25T774 : Tree 12 := .split 30 q12Shape25T775 q12Shape25T788
private theorem q12Shape25T774OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 50331648 q12Shape25T774=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1006632960 (50331648 ||| 2^30) q12Shape25T775 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1006632960 ||| 2^30) 50331648 q12Shape25T788)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T775OK,q12Shape25T788OK⟩

private def q12Shape25T758 : Tree 12 := .split 29 q12Shape25T759 q12Shape25T774
private theorem q12Shape25T758OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 50331648 q12Shape25T758=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 469762048 (50331648 ||| 2^29) q12Shape25T759 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (469762048 ||| 2^29) 50331648 q12Shape25T774)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T759OK,q12Shape25T774OK⟩

private def q12Shape25T732 : Tree 12 := .split 28 q12Shape25T733 q12Shape25T758
private theorem q12Shape25T732OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 50331648 q12Shape25T732=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 (50331648 ||| 2^28) q12Shape25T733 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (201326592 ||| 2^28) 50331648 q12Shape25T758)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T733OK,q12Shape25T758OK⟩

def q12Shape25P26 : Tree 12 := q12Shape25T732
theorem q12Shape25P26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 201326592 50331648 q12Shape25P26=true := q12Shape25T732OK

end Graffiti384b.EffectiveSearch.Q12
