import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T799 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,9,10,11})))))
private theorem q12Shape25T799OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 274827575296 q12Shape25T799=true := by decide

private def q12Shape25T801 : Tree 12 := (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))))
private theorem q12Shape25T801OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137472507904 412266528768 q12Shape25T801=true := by decide

private def q12Shape25T802 : Tree 12 := (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))))
private theorem q12Shape25T802OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 412350414848 137388621824 q12Shape25T802=true := by decide

private def q12Shape25T800 : Tree 12 := .split 38 q12Shape25T801 q12Shape25T802
private theorem q12Shape25T800OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137472507904 137388621824 q12Shape25T800=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137472507904 (137388621824 ||| 2^38) q12Shape25T801 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (137472507904 ||| 2^38) 137388621824 q12Shape25T802)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T801OK,q12Shape25T802OK⟩

private def q12Shape25T798 : Tree 12 := .split 37 q12Shape25T799 q12Shape25T800
private theorem q12Shape25T798OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 137388621824 q12Shape25T798=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (137388621824 ||| 2^37) q12Shape25T799 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^37) 137388621824 q12Shape25T800)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T799OK,q12Shape25T800OK⟩

private def q12Shape25T805 : Tree 12 := (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T805OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68753031168 480986005504 q12Shape25T805=true := by decide

private def q12Shape25T806 : Tree 12 := (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T806OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 343630938112 206108098560 q12Shape25T806=true := by decide

private def q12Shape25T804 : Tree 12 := .split 38 q12Shape25T805 q12Shape25T806
private theorem q12Shape25T804OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68753031168 206108098560 q12Shape25T804=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68753031168 (206108098560 ||| 2^38) q12Shape25T805 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (68753031168 ||| 2^38) 206108098560 q12Shape25T806)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T805OK,q12Shape25T806OK⟩

private def q12Shape25T808 : Tree 12 := (.split 39 (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,9,11})))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T808OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206191984640 343547052032 q12Shape25T808=true := by decide

private def q12Shape25T809 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T809OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 481069891584 68669145088 q12Shape25T809=true := by decide

private def q12Shape25T807 : Tree 12 := .split 38 q12Shape25T808 q12Shape25T809
private theorem q12Shape25T807OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206191984640 68669145088 q12Shape25T807=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206191984640 (68669145088 ||| 2^38) q12Shape25T808 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (206191984640 ||| 2^38) 68669145088 q12Shape25T809)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T808OK,q12Shape25T809OK⟩

private def q12Shape25T803 : Tree 12 := .split 37 q12Shape25T804 q12Shape25T807
private theorem q12Shape25T803OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68753031168 68669145088 q12Shape25T803=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68753031168 (68669145088 ||| 2^37) q12Shape25T804 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (68753031168 ||| 2^37) 68669145088 q12Shape25T807)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T804OK,q12Shape25T807OK⟩

private def q12Shape25T797 : Tree 12 := .split 36 q12Shape25T798 q12Shape25T803
private theorem q12Shape25T797OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 68669145088 q12Shape25T797=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (68669145088 ||| 2^36) q12Shape25T798 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^36) 68669145088 q12Shape25T803)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T798OK,q12Shape25T803OK⟩

private def q12Shape25T813 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T813OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34393292800 515345743872 q12Shape25T813=true := by decide

private def q12Shape25T814 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11})))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T814OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309271199744 240467836928 q12Shape25T814=true := by decide

private def q12Shape25T812 : Tree 12 := .split 38 q12Shape25T813 q12Shape25T814
private theorem q12Shape25T812OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34393292800 240467836928 q12Shape25T812=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34393292800 (240467836928 ||| 2^38) q12Shape25T813 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34393292800 ||| 2^38) 240467836928 q12Shape25T814)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T813OK,q12Shape25T814OK⟩

private def q12Shape25T816 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T816OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171832246272 377906790400 q12Shape25T816=true := by decide

private def q12Shape25T817 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T817OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 446710153216 103028883456 q12Shape25T817=true := by decide

private def q12Shape25T815 : Tree 12 := .split 38 q12Shape25T816 q12Shape25T817
private theorem q12Shape25T815OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171832246272 103028883456 q12Shape25T815=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171832246272 (103028883456 ||| 2^38) q12Shape25T816 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (171832246272 ||| 2^38) 103028883456 q12Shape25T817)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T816OK,q12Shape25T817OK⟩

private def q12Shape25T811 : Tree 12 := .split 37 q12Shape25T812 q12Shape25T815
private theorem q12Shape25T811OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34393292800 103028883456 q12Shape25T811=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34393292800 (103028883456 ||| 2^37) q12Shape25T812 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34393292800 ||| 2^37) 103028883456 q12Shape25T815)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T812OK,q12Shape25T815OK⟩

private def q12Shape25T820 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T820OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103112769536 446626267136 q12Shape25T820=true := by decide

private def q12Shape25T821 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T821OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 377990676480 171748360192 q12Shape25T821=true := by decide

private def q12Shape25T819 : Tree 12 := .split 38 q12Shape25T820 q12Shape25T821
private theorem q12Shape25T819OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103112769536 171748360192 q12Shape25T819=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103112769536 (171748360192 ||| 2^38) q12Shape25T820 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (103112769536 ||| 2^38) 171748360192 q12Shape25T821)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T820OK,q12Shape25T821OK⟩

private def q12Shape25T823 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T823OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240551723008 309187313664 q12Shape25T823=true := by decide

private def q12Shape25T824 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape25T824OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 515429629952 34309406720 q12Shape25T824=true := by decide

private def q12Shape25T822 : Tree 12 := .split 38 q12Shape25T823 q12Shape25T824
private theorem q12Shape25T822OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240551723008 34309406720 q12Shape25T822=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240551723008 (34309406720 ||| 2^38) q12Shape25T823 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (240551723008 ||| 2^38) 34309406720 q12Shape25T824)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T823OK,q12Shape25T824OK⟩

private def q12Shape25T818 : Tree 12 := .split 37 q12Shape25T819 q12Shape25T822
private theorem q12Shape25T818OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103112769536 34309406720 q12Shape25T818=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103112769536 (34309406720 ||| 2^37) q12Shape25T819 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (103112769536 ||| 2^37) 34309406720 q12Shape25T822)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T819OK,q12Shape25T822OK⟩

private def q12Shape25T810 : Tree 12 := .split 36 q12Shape25T811 q12Shape25T818
private theorem q12Shape25T810OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34393292800 34309406720 q12Shape25T810=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34393292800 (34309406720 ||| 2^36) q12Shape25T811 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34393292800 ||| 2^36) 34309406720 q12Shape25T818)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T811OK,q12Shape25T818OK⟩

private def q12Shape25T796 : Tree 12 := .split 35 q12Shape25T797 q12Shape25T810
private theorem q12Shape25T796OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 34309406720 q12Shape25T796=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (34309406720 ||| 2^35) q12Shape25T797 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^35) 34309406720 q12Shape25T810)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T797OK,q12Shape25T810OK⟩

private def q12Shape25T825 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T825OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17213423616 17129537536 q12Shape25T825=true := by decide

private def q12Shape25T795 : Tree 12 := .split 34 q12Shape25T796 q12Shape25T825
private theorem q12Shape25T795OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 17129537536 q12Shape25T795=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (17129537536 ||| 2^34) q12Shape25T796 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^34) 17129537536 q12Shape25T825)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T796OK,q12Shape25T825OK⟩

private def q12Shape25T826 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T826OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8623489024 8539602944 q12Shape25T826=true := by decide

private def q12Shape25T794 : Tree 12 := .split 33 q12Shape25T795 q12Shape25T826
private theorem q12Shape25T794OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 8539602944 q12Shape25T794=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (8539602944 ||| 2^33) q12Shape25T795 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^33) 8539602944 q12Shape25T826)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T795OK,q12Shape25T826OK⟩

private def q12Shape25T827 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T827OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4328521728 4244635648 q12Shape25T827=true := by decide

private def q12Shape25T793 : Tree 12 := .split 32 q12Shape25T794 q12Shape25T827
private theorem q12Shape25T793OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 4244635648 q12Shape25T793=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (4244635648 ||| 2^32) q12Shape25T794 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^32) 4244635648 q12Shape25T827)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T794OK,q12Shape25T827OK⟩

private def q12Shape25T828 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T828OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2181038080 2097152000 q12Shape25T828=true := by decide

private def q12Shape25T792 : Tree 12 := .split 31 q12Shape25T793 q12Shape25T828
private theorem q12Shape25T792OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 2097152000 q12Shape25T792=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (2097152000 ||| 2^31) q12Shape25T793 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^31) 2097152000 q12Shape25T828)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T793OK,q12Shape25T828OK⟩

private def q12Shape25T829 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T829OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1107296256 1023410176 q12Shape25T829=true := by decide

private def q12Shape25T791 : Tree 12 := .split 30 q12Shape25T792 q12Shape25T829
private theorem q12Shape25T791OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 1023410176 q12Shape25T791=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 (1023410176 ||| 2^30) q12Shape25T792 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (33554432 ||| 2^30) 1023410176 q12Shape25T829)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T792OK,q12Shape25T829OK⟩

def q12Shape25P27 : Tree 12 := q12Shape25T791
theorem q12Shape25P27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33554432 1023410176 q12Shape25P27=true := q12Shape25T791OK

end Graffiti384b.EffectiveSearch.Q12
