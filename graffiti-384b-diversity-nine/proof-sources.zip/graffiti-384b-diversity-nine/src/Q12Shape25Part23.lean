import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T838 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,9,10})))))
private theorem q12Shape25T838OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 274290704384 q12Shape25T838=true := by decide

private def q12Shape25T839 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,6,7,9,11})) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T839OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 138009378816 136851750912 q12Shape25T839=true := by decide

private def q12Shape25T837 : Tree 12 := .split 37 q12Shape25T838 q12Shape25T839
private theorem q12Shape25T837OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 136851750912 q12Shape25T837=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (136851750912 ||| 2^37) q12Shape25T838 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^37) 136851750912 q12Shape25T839)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T838OK,q12Shape25T839OK⟩

private def q12Shape25T840 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T840OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69289902080 68132274176 q12Shape25T840=true := by decide

private def q12Shape25T836 : Tree 12 := .split 36 q12Shape25T837 q12Shape25T840
private theorem q12Shape25T836OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 68132274176 q12Shape25T836=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (68132274176 ||| 2^36) q12Shape25T837 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^36) 68132274176 q12Shape25T840)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T837OK,q12Shape25T840OK⟩

private def q12Shape25T841 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T841OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34930163712 33772535808 q12Shape25T841=true := by decide

private def q12Shape25T835 : Tree 12 := .split 35 q12Shape25T836 q12Shape25T841
private theorem q12Shape25T835OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 33772535808 q12Shape25T835=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (33772535808 ||| 2^35) q12Shape25T836 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^35) 33772535808 q12Shape25T841)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T836OK,q12Shape25T841OK⟩

private def q12Shape25T842 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T842OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17750294528 16592666624 q12Shape25T842=true := by decide

private def q12Shape25T834 : Tree 12 := .split 34 q12Shape25T835 q12Shape25T842
private theorem q12Shape25T834OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 16592666624 q12Shape25T834=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (16592666624 ||| 2^34) q12Shape25T835 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^34) 16592666624 q12Shape25T842)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T835OK,q12Shape25T842OK⟩

private def q12Shape25T843 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T843OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9160359936 8002732032 q12Shape25T843=true := by decide

private def q12Shape25T833 : Tree 12 := .split 33 q12Shape25T834 q12Shape25T843
private theorem q12Shape25T833OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 8002732032 q12Shape25T833=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (8002732032 ||| 2^33) q12Shape25T834 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^33) 8002732032 q12Shape25T843)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T834OK,q12Shape25T843OK⟩

private def q12Shape25T844 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T844OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4865392640 3707764736 q12Shape25T844=true := by decide

private def q12Shape25T832 : Tree 12 := .split 32 q12Shape25T833 q12Shape25T844
private theorem q12Shape25T832OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 3707764736 q12Shape25T832=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (3707764736 ||| 2^32) q12Shape25T833 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^32) 3707764736 q12Shape25T844)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T833OK,q12Shape25T844OK⟩

private def q12Shape25T845 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T845OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2717908992 1560281088 q12Shape25T845=true := by decide

private def q12Shape25T831 : Tree 12 := .split 31 q12Shape25T832 q12Shape25T845
private theorem q12Shape25T831OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 1560281088 q12Shape25T831=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (1560281088 ||| 2^31) q12Shape25T832 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^31) 1560281088 q12Shape25T845)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T832OK,q12Shape25T845OK⟩

private def q12Shape25T846 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T846OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1644167168 486539264 q12Shape25T846=true := by decide

private def q12Shape25T830 : Tree 12 := .split 30 q12Shape25T831 q12Shape25T846
private theorem q12Shape25T830OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 486539264 q12Shape25T830=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 (486539264 ||| 2^30) q12Shape25T831 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (570425344 ||| 2^30) 486539264 q12Shape25T846)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T831OK,q12Shape25T846OK⟩

def q12Shape25P28 : Tree 12 := q12Shape25T830
theorem q12Shape25P28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 570425344 486539264 q12Shape25P28=true := q12Shape25T830OK

private def q12Shape25T857 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,8,9,11})))))
private theorem q12Shape25T857OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 274559139840 q12Shape25T857=true := by decide

private def q12Shape25T858 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T858OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 137740943360 137120186368 q12Shape25T858=true := by decide

private def q12Shape25T856 : Tree 12 := .split 37 q12Shape25T857 q12Shape25T858
private theorem q12Shape25T856OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 137120186368 q12Shape25T856=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (137120186368 ||| 2^37) q12Shape25T857 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^37) 137120186368 q12Shape25T858)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T857OK,q12Shape25T858OK⟩

private def q12Shape25T859 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T859OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69021466624 68400709632 q12Shape25T859=true := by decide

private def q12Shape25T855 : Tree 12 := .split 36 q12Shape25T856 q12Shape25T859
private theorem q12Shape25T855OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 68400709632 q12Shape25T855=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (68400709632 ||| 2^36) q12Shape25T856 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^36) 68400709632 q12Shape25T859)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T856OK,q12Shape25T859OK⟩

private def q12Shape25T860 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T860OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34661728256 34040971264 q12Shape25T860=true := by decide

private def q12Shape25T854 : Tree 12 := .split 35 q12Shape25T855 q12Shape25T860
private theorem q12Shape25T854OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 34040971264 q12Shape25T854=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (34040971264 ||| 2^35) q12Shape25T855 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^35) 34040971264 q12Shape25T860)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T855OK,q12Shape25T860OK⟩

private def q12Shape25T861 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T861OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17481859072 16861102080 q12Shape25T861=true := by decide

private def q12Shape25T853 : Tree 12 := .split 34 q12Shape25T854 q12Shape25T861
private theorem q12Shape25T853OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 16861102080 q12Shape25T853=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (16861102080 ||| 2^34) q12Shape25T854 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^34) 16861102080 q12Shape25T861)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T854OK,q12Shape25T861OK⟩

private def q12Shape25T862 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T862OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8891924480 8271167488 q12Shape25T862=true := by decide

private def q12Shape25T852 : Tree 12 := .split 33 q12Shape25T853 q12Shape25T862
private theorem q12Shape25T852OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 8271167488 q12Shape25T852=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (8271167488 ||| 2^33) q12Shape25T853 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^33) 8271167488 q12Shape25T862)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T853OK,q12Shape25T862OK⟩

private def q12Shape25T863 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T863OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4596957184 3976200192 q12Shape25T863=true := by decide

private def q12Shape25T851 : Tree 12 := .split 32 q12Shape25T852 q12Shape25T863
private theorem q12Shape25T851OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 3976200192 q12Shape25T851=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (3976200192 ||| 2^32) q12Shape25T852 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^32) 3976200192 q12Shape25T863)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T852OK,q12Shape25T863OK⟩

private def q12Shape25T864 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T864OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2449473536 1828716544 q12Shape25T864=true := by decide

private def q12Shape25T850 : Tree 12 := .split 31 q12Shape25T851 q12Shape25T864
private theorem q12Shape25T850OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 1828716544 q12Shape25T850=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (1828716544 ||| 2^31) q12Shape25T851 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^31) 1828716544 q12Shape25T864)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T851OK,q12Shape25T864OK⟩

private def q12Shape25T865 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T865OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1375731712 754974720 q12Shape25T865=true := by decide

private def q12Shape25T849 : Tree 12 := .split 30 q12Shape25T850 q12Shape25T865
private theorem q12Shape25T849OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 754974720 q12Shape25T849=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (754974720 ||| 2^30) q12Shape25T850 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^30) 754974720 q12Shape25T865)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T850OK,q12Shape25T865OK⟩

private def q12Shape25T874 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,9})))))
private theorem q12Shape25T874OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 274022268928 q12Shape25T874=true := by decide

private def q12Shape25T875 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,5,6,7,8,9})))
private theorem q12Shape25T875OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 138277814272 136583315456 q12Shape25T875=true := by decide

private def q12Shape25T873 : Tree 12 := .split 37 q12Shape25T874 q12Shape25T875
private theorem q12Shape25T873OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 136583315456 q12Shape25T873=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (136583315456 ||| 2^37) q12Shape25T874 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^37) 136583315456 q12Shape25T875)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T874OK,q12Shape25T875OK⟩

private def q12Shape25T876 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T876OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69558337536 67863838720 q12Shape25T876=true := by decide

private def q12Shape25T872 : Tree 12 := .split 36 q12Shape25T873 q12Shape25T876
private theorem q12Shape25T872OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 67863838720 q12Shape25T872=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (67863838720 ||| 2^36) q12Shape25T873 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^36) 67863838720 q12Shape25T876)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T873OK,q12Shape25T876OK⟩

private def q12Shape25T877 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T877OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35198599168 33504100352 q12Shape25T877=true := by decide

private def q12Shape25T871 : Tree 12 := .split 35 q12Shape25T872 q12Shape25T877
private theorem q12Shape25T871OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 33504100352 q12Shape25T871=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (33504100352 ||| 2^35) q12Shape25T872 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^35) 33504100352 q12Shape25T877)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T872OK,q12Shape25T877OK⟩

private def q12Shape25T878 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T878OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18018729984 16324231168 q12Shape25T878=true := by decide

private def q12Shape25T870 : Tree 12 := .split 34 q12Shape25T871 q12Shape25T878
private theorem q12Shape25T870OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 16324231168 q12Shape25T870=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (16324231168 ||| 2^34) q12Shape25T871 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^34) 16324231168 q12Shape25T878)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T871OK,q12Shape25T878OK⟩

private def q12Shape25T879 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T879OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9428795392 7734296576 q12Shape25T879=true := by decide

private def q12Shape25T869 : Tree 12 := .split 33 q12Shape25T870 q12Shape25T879
private theorem q12Shape25T869OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 7734296576 q12Shape25T869=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (7734296576 ||| 2^33) q12Shape25T870 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^33) 7734296576 q12Shape25T879)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T870OK,q12Shape25T879OK⟩

private def q12Shape25T880 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T880OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5133828096 3439329280 q12Shape25T880=true := by decide

private def q12Shape25T868 : Tree 12 := .split 32 q12Shape25T869 q12Shape25T880
private theorem q12Shape25T868OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 3439329280 q12Shape25T868=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (3439329280 ||| 2^32) q12Shape25T869 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^32) 3439329280 q12Shape25T880)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T869OK,q12Shape25T880OK⟩

private def q12Shape25T881 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T881OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2986344448 1291845632 q12Shape25T881=true := by decide

private def q12Shape25T867 : Tree 12 := .split 31 q12Shape25T868 q12Shape25T881
private theorem q12Shape25T867OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 1291845632 q12Shape25T867=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (1291845632 ||| 2^31) q12Shape25T868 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^31) 1291845632 q12Shape25T881)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T868OK,q12Shape25T881OK⟩

private def q12Shape25T882 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T882OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1912602624 218103808 q12Shape25T882=true := by decide

private def q12Shape25T866 : Tree 12 := .split 30 q12Shape25T867 q12Shape25T882
private theorem q12Shape25T866OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 218103808 q12Shape25T866=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 838860800 (218103808 ||| 2^30) q12Shape25T867 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (838860800 ||| 2^30) 218103808 q12Shape25T882)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T867OK,q12Shape25T882OK⟩

private def q12Shape25T848 : Tree 12 := .split 29 q12Shape25T849 q12Shape25T866
private theorem q12Shape25T848OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 218103808 q12Shape25T848=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 (218103808 ||| 2^29) q12Shape25T849 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (301989888 ||| 2^29) 218103808 q12Shape25T866)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T849OK,q12Shape25T866OK⟩

def q12Shape25P29 : Tree 12 := q12Shape25T848
theorem q12Shape25P29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 301989888 218103808 q12Shape25P29=true := q12Shape25T848OK

end Graffiti384b.EffectiveSearch.Q12
