import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T892 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T892OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 137254404096 q12Shape25T892=true := by decide

private def q12Shape25T893 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T893OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68887248896 68534927360 q12Shape25T893=true := by decide

private def q12Shape25T891 : Tree 12 := .split 36 q12Shape25T892 q12Shape25T893
private theorem q12Shape25T891OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 68534927360 q12Shape25T891=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (68534927360 ||| 2^36) q12Shape25T892 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^36) 68534927360 q12Shape25T893)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T892OK,q12Shape25T893OK⟩

private def q12Shape25T894 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,6,7,9,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T894OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34527510528 34175188992 q12Shape25T894=true := by decide

private def q12Shape25T890 : Tree 12 := .split 35 q12Shape25T891 q12Shape25T894
private theorem q12Shape25T890OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 34175188992 q12Shape25T890=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (34175188992 ||| 2^35) q12Shape25T891 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^35) 34175188992 q12Shape25T894)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T891OK,q12Shape25T894OK⟩

private def q12Shape25T895 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T895OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17347641344 16995319808 q12Shape25T895=true := by decide

private def q12Shape25T889 : Tree 12 := .split 34 q12Shape25T890 q12Shape25T895
private theorem q12Shape25T889OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 16995319808 q12Shape25T889=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (16995319808 ||| 2^34) q12Shape25T890 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^34) 16995319808 q12Shape25T895)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T890OK,q12Shape25T895OK⟩

private def q12Shape25T896 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T896OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8757706752 8405385216 q12Shape25T896=true := by decide

private def q12Shape25T888 : Tree 12 := .split 33 q12Shape25T889 q12Shape25T896
private theorem q12Shape25T888OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 8405385216 q12Shape25T888=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (8405385216 ||| 2^33) q12Shape25T889 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^33) 8405385216 q12Shape25T896)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T889OK,q12Shape25T896OK⟩

private def q12Shape25T897 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T897OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4462739456 4110417920 q12Shape25T897=true := by decide

private def q12Shape25T887 : Tree 12 := .split 32 q12Shape25T888 q12Shape25T897
private theorem q12Shape25T887OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 4110417920 q12Shape25T887=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (4110417920 ||| 2^32) q12Shape25T888 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^32) 4110417920 q12Shape25T897)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T888OK,q12Shape25T897OK⟩

private def q12Shape25T898 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T898OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2315255808 1962934272 q12Shape25T898=true := by decide

private def q12Shape25T886 : Tree 12 := .split 31 q12Shape25T887 q12Shape25T898
private theorem q12Shape25T886OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 1962934272 q12Shape25T886=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (1962934272 ||| 2^31) q12Shape25T887 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^31) 1962934272 q12Shape25T898)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T887OK,q12Shape25T898OK⟩

private def q12Shape25T899 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T899OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1241513984 889192448 q12Shape25T899=true := by decide

private def q12Shape25T885 : Tree 12 := .split 30 q12Shape25T886 q12Shape25T899
private theorem q12Shape25T885OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 889192448 q12Shape25T885=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (889192448 ||| 2^30) q12Shape25T886 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^30) 889192448 q12Shape25T899)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T886OK,q12Shape25T899OK⟩

private def q12Shape25T907 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T907OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 136717533184 q12Shape25T907=true := by decide

private def q12Shape25T908 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,7,8,10})))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T908OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69424119808 67998056448 q12Shape25T908=true := by decide

private def q12Shape25T906 : Tree 12 := .split 36 q12Shape25T907 q12Shape25T908
private theorem q12Shape25T906OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 67998056448 q12Shape25T906=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 (67998056448 ||| 2^36) q12Shape25T907 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (704643072 ||| 2^36) 67998056448 q12Shape25T908)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T907OK,q12Shape25T908OK⟩

private def q12Shape25T909 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,6,7,9,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T909OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35064381440 33638318080 q12Shape25T909=true := by decide

private def q12Shape25T905 : Tree 12 := .split 35 q12Shape25T906 q12Shape25T909
private theorem q12Shape25T905OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 33638318080 q12Shape25T905=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 (33638318080 ||| 2^35) q12Shape25T906 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (704643072 ||| 2^35) 33638318080 q12Shape25T909)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T906OK,q12Shape25T909OK⟩

private def q12Shape25T910 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T910OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17884512256 16458448896 q12Shape25T910=true := by decide

private def q12Shape25T904 : Tree 12 := .split 34 q12Shape25T905 q12Shape25T910
private theorem q12Shape25T904OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 16458448896 q12Shape25T904=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 (16458448896 ||| 2^34) q12Shape25T905 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (704643072 ||| 2^34) 16458448896 q12Shape25T910)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T905OK,q12Shape25T910OK⟩

private def q12Shape25T911 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T911OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9294577664 7868514304 q12Shape25T911=true := by decide

private def q12Shape25T903 : Tree 12 := .split 33 q12Shape25T904 q12Shape25T911
private theorem q12Shape25T903OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 7868514304 q12Shape25T903=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 (7868514304 ||| 2^33) q12Shape25T904 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (704643072 ||| 2^33) 7868514304 q12Shape25T911)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T904OK,q12Shape25T911OK⟩

private def q12Shape25T912 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T912OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4999610368 3573547008 q12Shape25T912=true := by decide

private def q12Shape25T902 : Tree 12 := .split 32 q12Shape25T903 q12Shape25T912
private theorem q12Shape25T902OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 3573547008 q12Shape25T902=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 (3573547008 ||| 2^32) q12Shape25T903 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (704643072 ||| 2^32) 3573547008 q12Shape25T912)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T903OK,q12Shape25T912OK⟩

private def q12Shape25T913 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T913OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2852126720 1426063360 q12Shape25T913=true := by decide

private def q12Shape25T901 : Tree 12 := .split 31 q12Shape25T902 q12Shape25T913
private theorem q12Shape25T901OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 1426063360 q12Shape25T901=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 (1426063360 ||| 2^31) q12Shape25T902 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (704643072 ||| 2^31) 1426063360 q12Shape25T913)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T902OK,q12Shape25T913OK⟩

private def q12Shape25T914 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T914OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1778384896 352321536 q12Shape25T914=true := by decide

private def q12Shape25T900 : Tree 12 := .split 30 q12Shape25T901 q12Shape25T914
private theorem q12Shape25T900OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 352321536 q12Shape25T900=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 704643072 (352321536 ||| 2^30) q12Shape25T901 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (704643072 ||| 2^30) 352321536 q12Shape25T914)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T901OK,q12Shape25T914OK⟩

private def q12Shape25T884 : Tree 12 := .split 29 q12Shape25T885 q12Shape25T900
private theorem q12Shape25T884OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 352321536 q12Shape25T884=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 (352321536 ||| 2^29) q12Shape25T885 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (167772160 ||| 2^29) 352321536 q12Shape25T900)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T885OK,q12Shape25T900OK⟩

def q12Shape25P30 : Tree 12 := q12Shape25T884
theorem q12Shape25P30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 167772160 352321536 q12Shape25P30=true := q12Shape25T884OK

end Graffiti384b.EffectiveSearch.Q12
