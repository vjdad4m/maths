import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T956 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T956OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 137321512960 q12Shape25T956=true := by decide

private def q12Shape25T957 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T957OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68820140032 68602036224 q12Shape25T957=true := by decide

private def q12Shape25T955 : Tree 12 := .split 36 q12Shape25T956 q12Shape25T957
private theorem q12Shape25T955OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 68602036224 q12Shape25T955=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (68602036224 ||| 2^36) q12Shape25T956 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^36) 68602036224 q12Shape25T957)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T956OK,q12Shape25T957OK⟩

private def q12Shape25T959 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T959OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34460401664 102961774592 q12Shape25T959=true := by decide

private def q12Shape25T960 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T960OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103179878400 34242297856 q12Shape25T960=true := by decide

private def q12Shape25T958 : Tree 12 := .split 36 q12Shape25T959 q12Shape25T960
private theorem q12Shape25T958OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34460401664 34242297856 q12Shape25T958=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34460401664 (34242297856 ||| 2^36) q12Shape25T959 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34460401664 ||| 2^36) 34242297856 q12Shape25T960)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T959OK,q12Shape25T960OK⟩

private def q12Shape25T954 : Tree 12 := .split 35 q12Shape25T955 q12Shape25T958
private theorem q12Shape25T954OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 34242297856 q12Shape25T954=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (34242297856 ||| 2^35) q12Shape25T955 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^35) 34242297856 q12Shape25T958)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T955OK,q12Shape25T958OK⟩

private def q12Shape25T961 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T961OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17280532480 17062428672 q12Shape25T961=true := by decide

private def q12Shape25T953 : Tree 12 := .split 34 q12Shape25T954 q12Shape25T961
private theorem q12Shape25T953OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 17062428672 q12Shape25T953=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (17062428672 ||| 2^34) q12Shape25T954 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^34) 17062428672 q12Shape25T961)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T954OK,q12Shape25T961OK⟩

private def q12Shape25T962 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T962OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8690597888 8472494080 q12Shape25T962=true := by decide

private def q12Shape25T952 : Tree 12 := .split 33 q12Shape25T953 q12Shape25T962
private theorem q12Shape25T952OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 8472494080 q12Shape25T952=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (8472494080 ||| 2^33) q12Shape25T953 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^33) 8472494080 q12Shape25T962)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T953OK,q12Shape25T962OK⟩

private def q12Shape25T963 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T963OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4395630592 4177526784 q12Shape25T963=true := by decide

private def q12Shape25T951 : Tree 12 := .split 32 q12Shape25T952 q12Shape25T963
private theorem q12Shape25T951OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 4177526784 q12Shape25T951=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (4177526784 ||| 2^32) q12Shape25T952 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^32) 4177526784 q12Shape25T963)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T952OK,q12Shape25T963OK⟩

private def q12Shape25T964 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T964OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2248146944 2030043136 q12Shape25T964=true := by decide

private def q12Shape25T950 : Tree 12 := .split 31 q12Shape25T951 q12Shape25T964
private theorem q12Shape25T950OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 2030043136 q12Shape25T950=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (2030043136 ||| 2^31) q12Shape25T951 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^31) 2030043136 q12Shape25T964)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T951OK,q12Shape25T964OK⟩

private def q12Shape25T965 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T965OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1174405120 956301312 q12Shape25T965=true := by decide

private def q12Shape25T949 : Tree 12 := .split 30 q12Shape25T950 q12Shape25T965
private theorem q12Shape25T949OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 956301312 q12Shape25T949=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (956301312 ||| 2^30) q12Shape25T950 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^30) 956301312 q12Shape25T965)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T950OK,q12Shape25T965OK⟩

private def q12Shape25T973 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T973OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 136784642048 q12Shape25T973=true := by decide

private def q12Shape25T974 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T974OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69357010944 68065165312 q12Shape25T974=true := by decide

private def q12Shape25T972 : Tree 12 := .split 36 q12Shape25T973 q12Shape25T974
private theorem q12Shape25T972OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 68065165312 q12Shape25T972=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 (68065165312 ||| 2^36) q12Shape25T973 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (637534208 ||| 2^36) 68065165312 q12Shape25T974)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T973OK,q12Shape25T974OK⟩

private def q12Shape25T976 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,9,10})))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T976OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34997272576 102424903680 q12Shape25T976=true := by decide

private def q12Shape25T977 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape25T977OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 103716749312 33705426944 q12Shape25T977=true := by decide

private def q12Shape25T975 : Tree 12 := .split 36 q12Shape25T976 q12Shape25T977
private theorem q12Shape25T975OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34997272576 33705426944 q12Shape25T975=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34997272576 (33705426944 ||| 2^36) q12Shape25T976 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (34997272576 ||| 2^36) 33705426944 q12Shape25T977)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T976OK,q12Shape25T977OK⟩

private def q12Shape25T971 : Tree 12 := .split 35 q12Shape25T972 q12Shape25T975
private theorem q12Shape25T971OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 33705426944 q12Shape25T971=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 (33705426944 ||| 2^35) q12Shape25T972 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (637534208 ||| 2^35) 33705426944 q12Shape25T975)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T972OK,q12Shape25T975OK⟩

private def q12Shape25T978 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T978OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17817403392 16525557760 q12Shape25T978=true := by decide

private def q12Shape25T970 : Tree 12 := .split 34 q12Shape25T971 q12Shape25T978
private theorem q12Shape25T970OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 16525557760 q12Shape25T970=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 (16525557760 ||| 2^34) q12Shape25T971 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (637534208 ||| 2^34) 16525557760 q12Shape25T978)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T971OK,q12Shape25T978OK⟩

private def q12Shape25T979 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T979OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9227468800 7935623168 q12Shape25T979=true := by decide

private def q12Shape25T969 : Tree 12 := .split 33 q12Shape25T970 q12Shape25T979
private theorem q12Shape25T969OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 7935623168 q12Shape25T969=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 (7935623168 ||| 2^33) q12Shape25T970 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (637534208 ||| 2^33) 7935623168 q12Shape25T979)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T970OK,q12Shape25T979OK⟩

private def q12Shape25T980 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T980OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4932501504 3640655872 q12Shape25T980=true := by decide

private def q12Shape25T968 : Tree 12 := .split 32 q12Shape25T969 q12Shape25T980
private theorem q12Shape25T968OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 3640655872 q12Shape25T968=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 (3640655872 ||| 2^32) q12Shape25T969 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (637534208 ||| 2^32) 3640655872 q12Shape25T980)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T969OK,q12Shape25T980OK⟩

private def q12Shape25T981 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T981OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2785017856 1493172224 q12Shape25T981=true := by decide

private def q12Shape25T967 : Tree 12 := .split 31 q12Shape25T968 q12Shape25T981
private theorem q12Shape25T967OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 1493172224 q12Shape25T967=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 (1493172224 ||| 2^31) q12Shape25T968 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (637534208 ||| 2^31) 1493172224 q12Shape25T981)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T968OK,q12Shape25T981OK⟩

private def q12Shape25T982 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T982OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1711276032 419430400 q12Shape25T982=true := by decide

private def q12Shape25T966 : Tree 12 := .split 30 q12Shape25T967 q12Shape25T982
private theorem q12Shape25T966OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 419430400 q12Shape25T966=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 637534208 (419430400 ||| 2^30) q12Shape25T967 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (637534208 ||| 2^30) 419430400 q12Shape25T982)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T967OK,q12Shape25T982OK⟩

private def q12Shape25T948 : Tree 12 := .split 29 q12Shape25T949 q12Shape25T966
private theorem q12Shape25T948OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 419430400 q12Shape25T948=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 (419430400 ||| 2^29) q12Shape25T949 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (100663296 ||| 2^29) 419430400 q12Shape25T966)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T949OK,q12Shape25T966OK⟩

def q12Shape25P32 : Tree 12 := q12Shape25T948
theorem q12Shape25P32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 100663296 419430400 q12Shape25P32=true := q12Shape25T948OK

end Graffiti384b.EffectiveSearch.Q12
