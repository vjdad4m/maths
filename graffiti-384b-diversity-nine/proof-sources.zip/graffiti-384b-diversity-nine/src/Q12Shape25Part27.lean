import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T991 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,9,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T991OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 137053077504 q12Shape25T991=true := by decide

private def q12Shape25T992 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T992OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69088575488 68333600768 q12Shape25T992=true := by decide

private def q12Shape25T990 : Tree 12 := .split 36 q12Shape25T991 q12Shape25T992
private theorem q12Shape25T990OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 68333600768 q12Shape25T990=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (68333600768 ||| 2^36) q12Shape25T991 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^36) 68333600768 q12Shape25T992)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T991OK,q12Shape25T992OK⟩

private def q12Shape25T993 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T993OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34728837120 33973862400 q12Shape25T993=true := by decide

private def q12Shape25T989 : Tree 12 := .split 35 q12Shape25T990 q12Shape25T993
private theorem q12Shape25T989OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 33973862400 q12Shape25T989=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (33973862400 ||| 2^35) q12Shape25T990 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^35) 33973862400 q12Shape25T993)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T990OK,q12Shape25T993OK⟩

private def q12Shape25T994 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T994OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17548967936 16793993216 q12Shape25T994=true := by decide

private def q12Shape25T988 : Tree 12 := .split 34 q12Shape25T989 q12Shape25T994
private theorem q12Shape25T988OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 16793993216 q12Shape25T988=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (16793993216 ||| 2^34) q12Shape25T989 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^34) 16793993216 q12Shape25T994)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T989OK,q12Shape25T994OK⟩

private def q12Shape25T995 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T995OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8959033344 8204058624 q12Shape25T995=true := by decide

private def q12Shape25T987 : Tree 12 := .split 33 q12Shape25T988 q12Shape25T995
private theorem q12Shape25T987OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 8204058624 q12Shape25T987=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (8204058624 ||| 2^33) q12Shape25T988 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^33) 8204058624 q12Shape25T995)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T988OK,q12Shape25T995OK⟩

private def q12Shape25T996 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T996OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4664066048 3909091328 q12Shape25T996=true := by decide

private def q12Shape25T986 : Tree 12 := .split 32 q12Shape25T987 q12Shape25T996
private theorem q12Shape25T986OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 3909091328 q12Shape25T986=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (3909091328 ||| 2^32) q12Shape25T987 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^32) 3909091328 q12Shape25T996)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T987OK,q12Shape25T996OK⟩

private def q12Shape25T997 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T997OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2516582400 1761607680 q12Shape25T997=true := by decide

private def q12Shape25T985 : Tree 12 := .split 31 q12Shape25T986 q12Shape25T997
private theorem q12Shape25T985OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 1761607680 q12Shape25T985=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (1761607680 ||| 2^31) q12Shape25T986 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^31) 1761607680 q12Shape25T997)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T986OK,q12Shape25T997OK⟩

private def q12Shape25T998 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T998OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1442840576 687865856 q12Shape25T998=true := by decide

private def q12Shape25T984 : Tree 12 := .split 30 q12Shape25T985 q12Shape25T998
private theorem q12Shape25T984OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 687865856 q12Shape25T984=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (687865856 ||| 2^30) q12Shape25T985 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^30) 687865856 q12Shape25T998)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T985OK,q12Shape25T998OK⟩

private def q12Shape25T1006 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T1006OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 136516206592 q12Shape25T1006=true := by decide

private def q12Shape25T1007 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T1007OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69625446400 67796729856 q12Shape25T1007=true := by decide

private def q12Shape25T1005 : Tree 12 := .split 36 q12Shape25T1006 q12Shape25T1007
private theorem q12Shape25T1005OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 67796729856 q12Shape25T1005=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 (67796729856 ||| 2^36) q12Shape25T1006 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (905969664 ||| 2^36) 67796729856 q12Shape25T1007)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1006OK,q12Shape25T1007OK⟩

private def q12Shape25T1008 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T1008OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35265708032 33436991488 q12Shape25T1008=true := by decide

private def q12Shape25T1004 : Tree 12 := .split 35 q12Shape25T1005 q12Shape25T1008
private theorem q12Shape25T1004OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 33436991488 q12Shape25T1004=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 (33436991488 ||| 2^35) q12Shape25T1005 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (905969664 ||| 2^35) 33436991488 q12Shape25T1008)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1005OK,q12Shape25T1008OK⟩

private def q12Shape25T1009 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1009OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18085838848 16257122304 q12Shape25T1009=true := by decide

private def q12Shape25T1003 : Tree 12 := .split 34 q12Shape25T1004 q12Shape25T1009
private theorem q12Shape25T1003OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 16257122304 q12Shape25T1003=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 (16257122304 ||| 2^34) q12Shape25T1004 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (905969664 ||| 2^34) 16257122304 q12Shape25T1009)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1004OK,q12Shape25T1009OK⟩

private def q12Shape25T1010 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1010OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9495904256 7667187712 q12Shape25T1010=true := by decide

private def q12Shape25T1002 : Tree 12 := .split 33 q12Shape25T1003 q12Shape25T1010
private theorem q12Shape25T1002OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 7667187712 q12Shape25T1002=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 (7667187712 ||| 2^33) q12Shape25T1003 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (905969664 ||| 2^33) 7667187712 q12Shape25T1010)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1003OK,q12Shape25T1010OK⟩

private def q12Shape25T1011 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1011OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5200936960 3372220416 q12Shape25T1011=true := by decide

private def q12Shape25T1001 : Tree 12 := .split 32 q12Shape25T1002 q12Shape25T1011
private theorem q12Shape25T1001OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 3372220416 q12Shape25T1001=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 (3372220416 ||| 2^32) q12Shape25T1002 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (905969664 ||| 2^32) 3372220416 q12Shape25T1011)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1002OK,q12Shape25T1011OK⟩

private def q12Shape25T1012 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1012OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3053453312 1224736768 q12Shape25T1012=true := by decide

private def q12Shape25T1000 : Tree 12 := .split 31 q12Shape25T1001 q12Shape25T1012
private theorem q12Shape25T1000OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 1224736768 q12Shape25T1000=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 (1224736768 ||| 2^31) q12Shape25T1001 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (905969664 ||| 2^31) 1224736768 q12Shape25T1012)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1001OK,q12Shape25T1012OK⟩

private def q12Shape25T1013 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1013OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1979711488 150994944 q12Shape25T1013=true := by decide

private def q12Shape25T999 : Tree 12 := .split 30 q12Shape25T1000 q12Shape25T1013
private theorem q12Shape25T999OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 150994944 q12Shape25T999=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 905969664 (150994944 ||| 2^30) q12Shape25T1000 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (905969664 ||| 2^30) 150994944 q12Shape25T1013)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1000OK,q12Shape25T1013OK⟩

private def q12Shape25T983 : Tree 12 := .split 29 q12Shape25T984 q12Shape25T999
private theorem q12Shape25T983OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 150994944 q12Shape25T983=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 (150994944 ||| 2^29) q12Shape25T984 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (369098752 ||| 2^29) 150994944 q12Shape25T999)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T984OK,q12Shape25T999OK⟩

def q12Shape25P33 : Tree 12 := q12Shape25T983
theorem q12Shape25P33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 369098752 150994944 q12Shape25P33=true := q12Shape25T983OK

end Graffiti384b.EffectiveSearch.Q12
