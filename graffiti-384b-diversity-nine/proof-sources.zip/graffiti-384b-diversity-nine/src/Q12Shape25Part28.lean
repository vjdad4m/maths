import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T1023 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T1023OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 137187295232 q12Shape25T1023=true := by decide

private def q12Shape25T1024 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T1024OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 68954357760 68467818496 q12Shape25T1024=true := by decide

private def q12Shape25T1022 : Tree 12 := .split 36 q12Shape25T1023 q12Shape25T1024
private theorem q12Shape25T1022OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 68467818496 q12Shape25T1022=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (68467818496 ||| 2^36) q12Shape25T1023 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^36) 68467818496 q12Shape25T1024)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1023OK,q12Shape25T1024OK⟩

private def q12Shape25T1025 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T1025OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34594619392 34108080128 q12Shape25T1025=true := by decide

private def q12Shape25T1021 : Tree 12 := .split 35 q12Shape25T1022 q12Shape25T1025
private theorem q12Shape25T1021OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 34108080128 q12Shape25T1021=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (34108080128 ||| 2^35) q12Shape25T1022 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^35) 34108080128 q12Shape25T1025)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1022OK,q12Shape25T1025OK⟩

private def q12Shape25T1026 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1026OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17414750208 16928210944 q12Shape25T1026=true := by decide

private def q12Shape25T1020 : Tree 12 := .split 34 q12Shape25T1021 q12Shape25T1026
private theorem q12Shape25T1020OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 16928210944 q12Shape25T1020=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (16928210944 ||| 2^34) q12Shape25T1021 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^34) 16928210944 q12Shape25T1026)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1021OK,q12Shape25T1026OK⟩

private def q12Shape25T1027 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1027OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8824815616 8338276352 q12Shape25T1027=true := by decide

private def q12Shape25T1019 : Tree 12 := .split 33 q12Shape25T1020 q12Shape25T1027
private theorem q12Shape25T1019OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 8338276352 q12Shape25T1019=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (8338276352 ||| 2^33) q12Shape25T1020 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^33) 8338276352 q12Shape25T1027)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1020OK,q12Shape25T1027OK⟩

private def q12Shape25T1028 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1028OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4529848320 4043309056 q12Shape25T1028=true := by decide

private def q12Shape25T1018 : Tree 12 := .split 32 q12Shape25T1019 q12Shape25T1028
private theorem q12Shape25T1018OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 4043309056 q12Shape25T1018=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (4043309056 ||| 2^32) q12Shape25T1019 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^32) 4043309056 q12Shape25T1028)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1019OK,q12Shape25T1028OK⟩

private def q12Shape25T1029 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1029OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2382364672 1895825408 q12Shape25T1029=true := by decide

private def q12Shape25T1017 : Tree 12 := .split 31 q12Shape25T1018 q12Shape25T1029
private theorem q12Shape25T1017OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 1895825408 q12Shape25T1017=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (1895825408 ||| 2^31) q12Shape25T1018 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^31) 1895825408 q12Shape25T1029)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1018OK,q12Shape25T1029OK⟩

private def q12Shape25T1030 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1030OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1308622848 822083584 q12Shape25T1030=true := by decide

private def q12Shape25T1016 : Tree 12 := .split 30 q12Shape25T1017 q12Shape25T1030
private theorem q12Shape25T1016OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 822083584 q12Shape25T1016=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (822083584 ||| 2^30) q12Shape25T1017 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^30) 822083584 q12Shape25T1030)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1017OK,q12Shape25T1030OK⟩

private def q12Shape25T1038 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T1038OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 136650424320 q12Shape25T1038=true := by decide

private def q12Shape25T1039 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape25T1039OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69491228672 67930947584 q12Shape25T1039=true := by decide

private def q12Shape25T1037 : Tree 12 := .split 36 q12Shape25T1038 q12Shape25T1039
private theorem q12Shape25T1037OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 67930947584 q12Shape25T1037=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 (67930947584 ||| 2^36) q12Shape25T1038 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (771751936 ||| 2^36) 67930947584 q12Shape25T1039)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1038OK,q12Shape25T1039OK⟩

private def q12Shape25T1040 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T1040OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35131490304 33571209216 q12Shape25T1040=true := by decide

private def q12Shape25T1036 : Tree 12 := .split 35 q12Shape25T1037 q12Shape25T1040
private theorem q12Shape25T1036OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 33571209216 q12Shape25T1036=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 (33571209216 ||| 2^35) q12Shape25T1037 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (771751936 ||| 2^35) 33571209216 q12Shape25T1040)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1037OK,q12Shape25T1040OK⟩

private def q12Shape25T1041 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1041OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17951621120 16391340032 q12Shape25T1041=true := by decide

private def q12Shape25T1035 : Tree 12 := .split 34 q12Shape25T1036 q12Shape25T1041
private theorem q12Shape25T1035OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 16391340032 q12Shape25T1035=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 (16391340032 ||| 2^34) q12Shape25T1036 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (771751936 ||| 2^34) 16391340032 q12Shape25T1041)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1036OK,q12Shape25T1041OK⟩

private def q12Shape25T1042 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1042OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9361686528 7801405440 q12Shape25T1042=true := by decide

private def q12Shape25T1034 : Tree 12 := .split 33 q12Shape25T1035 q12Shape25T1042
private theorem q12Shape25T1034OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 7801405440 q12Shape25T1034=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 (7801405440 ||| 2^33) q12Shape25T1035 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (771751936 ||| 2^33) 7801405440 q12Shape25T1042)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1035OK,q12Shape25T1042OK⟩

private def q12Shape25T1043 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1043OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5066719232 3506438144 q12Shape25T1043=true := by decide

private def q12Shape25T1033 : Tree 12 := .split 32 q12Shape25T1034 q12Shape25T1043
private theorem q12Shape25T1033OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 3506438144 q12Shape25T1033=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 (3506438144 ||| 2^32) q12Shape25T1034 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (771751936 ||| 2^32) 3506438144 q12Shape25T1043)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1034OK,q12Shape25T1043OK⟩

private def q12Shape25T1044 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1044OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2919235584 1358954496 q12Shape25T1044=true := by decide

private def q12Shape25T1032 : Tree 12 := .split 31 q12Shape25T1033 q12Shape25T1044
private theorem q12Shape25T1032OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 1358954496 q12Shape25T1032=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 (1358954496 ||| 2^31) q12Shape25T1033 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (771751936 ||| 2^31) 1358954496 q12Shape25T1044)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1033OK,q12Shape25T1044OK⟩

private def q12Shape25T1045 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1045OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1845493760 285212672 q12Shape25T1045=true := by decide

private def q12Shape25T1031 : Tree 12 := .split 30 q12Shape25T1032 q12Shape25T1045
private theorem q12Shape25T1031OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 285212672 q12Shape25T1031=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 771751936 (285212672 ||| 2^30) q12Shape25T1032 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (771751936 ||| 2^30) 285212672 q12Shape25T1045)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1032OK,q12Shape25T1045OK⟩

private def q12Shape25T1015 : Tree 12 := .split 29 q12Shape25T1016 q12Shape25T1031
private theorem q12Shape25T1015OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 285212672 q12Shape25T1015=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 (285212672 ||| 2^29) q12Shape25T1016 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (234881024 ||| 2^29) 285212672 q12Shape25T1031)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1016OK,q12Shape25T1031OK⟩

def q12Shape25P34 : Tree 12 := q12Shape25T1015
theorem q12Shape25P34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 234881024 285212672 q12Shape25P34=true := q12Shape25T1015OK

end Graffiti384b.EffectiveSearch.Q12
