import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T1054 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape25T1054OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 136918859776 q12Shape25T1054=true := by decide

private def q12Shape25T1055 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T1055OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69222793216 68199383040 q12Shape25T1055=true := by decide

private def q12Shape25T1053 : Tree 12 := .split 36 q12Shape25T1054 q12Shape25T1055
private theorem q12Shape25T1053OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 68199383040 q12Shape25T1053=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (68199383040 ||| 2^36) q12Shape25T1054 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^36) 68199383040 q12Shape25T1055)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1054OK,q12Shape25T1055OK⟩

private def q12Shape25T1056 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T1056OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 34863054848 33839644672 q12Shape25T1056=true := by decide

private def q12Shape25T1052 : Tree 12 := .split 35 q12Shape25T1053 q12Shape25T1056
private theorem q12Shape25T1052OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 33839644672 q12Shape25T1052=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (33839644672 ||| 2^35) q12Shape25T1053 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^35) 33839644672 q12Shape25T1056)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1053OK,q12Shape25T1056OK⟩

private def q12Shape25T1057 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1057OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17683185664 16659775488 q12Shape25T1057=true := by decide

private def q12Shape25T1051 : Tree 12 := .split 34 q12Shape25T1052 q12Shape25T1057
private theorem q12Shape25T1051OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 16659775488 q12Shape25T1051=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (16659775488 ||| 2^34) q12Shape25T1052 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^34) 16659775488 q12Shape25T1057)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1052OK,q12Shape25T1057OK⟩

private def q12Shape25T1058 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1058OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9093251072 8069840896 q12Shape25T1058=true := by decide

private def q12Shape25T1050 : Tree 12 := .split 33 q12Shape25T1051 q12Shape25T1058
private theorem q12Shape25T1050OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 8069840896 q12Shape25T1050=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (8069840896 ||| 2^33) q12Shape25T1051 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^33) 8069840896 q12Shape25T1058)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1051OK,q12Shape25T1058OK⟩

private def q12Shape25T1059 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1059OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4798283776 3774873600 q12Shape25T1059=true := by decide

private def q12Shape25T1049 : Tree 12 := .split 32 q12Shape25T1050 q12Shape25T1059
private theorem q12Shape25T1049OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 3774873600 q12Shape25T1049=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (3774873600 ||| 2^32) q12Shape25T1050 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^32) 3774873600 q12Shape25T1059)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1050OK,q12Shape25T1059OK⟩

private def q12Shape25T1060 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1060OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2650800128 1627389952 q12Shape25T1060=true := by decide

private def q12Shape25T1048 : Tree 12 := .split 31 q12Shape25T1049 q12Shape25T1060
private theorem q12Shape25T1048OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 1627389952 q12Shape25T1048=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (1627389952 ||| 2^31) q12Shape25T1049 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^31) 1627389952 q12Shape25T1060)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1049OK,q12Shape25T1060OK⟩

private def q12Shape25T1061 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1061OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1577058304 553648128 q12Shape25T1061=true := by decide

private def q12Shape25T1047 : Tree 12 := .split 30 q12Shape25T1048 q12Shape25T1061
private theorem q12Shape25T1047OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 553648128 q12Shape25T1047=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (553648128 ||| 2^30) q12Shape25T1048 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^30) 553648128 q12Shape25T1061)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1048OK,q12Shape25T1061OK⟩

private def q12Shape25T1069 : Tree 12 := (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T1069OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 136381988864 q12Shape25T1069=true := by decide

private def q12Shape25T1070 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T1070OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 69759664128 67662512128 q12Shape25T1070=true := by decide

private def q12Shape25T1068 : Tree 12 := .split 36 q12Shape25T1069 q12Shape25T1070
private theorem q12Shape25T1068OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 67662512128 q12Shape25T1068=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 (67662512128 ||| 2^36) q12Shape25T1069 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1040187392 ||| 2^36) 67662512128 q12Shape25T1070)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1069OK,q12Shape25T1070OK⟩

private def q12Shape25T1071 : Tree 12 := (.split 36 (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T1071OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 35399925760 33302773760 q12Shape25T1071=true := by decide

private def q12Shape25T1067 : Tree 12 := .split 35 q12Shape25T1068 q12Shape25T1071
private theorem q12Shape25T1067OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 33302773760 q12Shape25T1067=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 (33302773760 ||| 2^35) q12Shape25T1068 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1040187392 ||| 2^35) 33302773760 q12Shape25T1071)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1068OK,q12Shape25T1071OK⟩

private def q12Shape25T1072 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1072OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18220056576 16122904576 q12Shape25T1072=true := by decide

private def q12Shape25T1066 : Tree 12 := .split 34 q12Shape25T1067 q12Shape25T1072
private theorem q12Shape25T1066OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 16122904576 q12Shape25T1066=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 (16122904576 ||| 2^34) q12Shape25T1067 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1040187392 ||| 2^34) 16122904576 q12Shape25T1072)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1067OK,q12Shape25T1072OK⟩

private def q12Shape25T1073 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1073OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9630121984 7532969984 q12Shape25T1073=true := by decide

private def q12Shape25T1065 : Tree 12 := .split 33 q12Shape25T1066 q12Shape25T1073
private theorem q12Shape25T1065OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 7532969984 q12Shape25T1065=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 (7532969984 ||| 2^33) q12Shape25T1066 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1040187392 ||| 2^33) 7532969984 q12Shape25T1073)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1066OK,q12Shape25T1073OK⟩

private def q12Shape25T1074 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1074OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5335154688 3238002688 q12Shape25T1074=true := by decide

private def q12Shape25T1064 : Tree 12 := .split 32 q12Shape25T1065 q12Shape25T1074
private theorem q12Shape25T1064OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 3238002688 q12Shape25T1064=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 (3238002688 ||| 2^32) q12Shape25T1065 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1040187392 ||| 2^32) 3238002688 q12Shape25T1074)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1065OK,q12Shape25T1074OK⟩

private def q12Shape25T1075 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1075OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3187671040 1090519040 q12Shape25T1075=true := by decide

private def q12Shape25T1063 : Tree 12 := .split 31 q12Shape25T1064 q12Shape25T1075
private theorem q12Shape25T1063OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 1090519040 q12Shape25T1063=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 (1090519040 ||| 2^31) q12Shape25T1064 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1040187392 ||| 2^31) 1090519040 q12Shape25T1075)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1064OK,q12Shape25T1075OK⟩

private def q12Shape25T1076 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1076OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2113929216 16777216 q12Shape25T1076=true := by decide

private def q12Shape25T1062 : Tree 12 := .split 30 q12Shape25T1063 q12Shape25T1076
private theorem q12Shape25T1062OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 16777216 q12Shape25T1062=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1040187392 (16777216 ||| 2^30) q12Shape25T1063 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1040187392 ||| 2^30) 16777216 q12Shape25T1076)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1063OK,q12Shape25T1076OK⟩

private def q12Shape25T1046 : Tree 12 := .split 29 q12Shape25T1047 q12Shape25T1062
private theorem q12Shape25T1046OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 16777216 q12Shape25T1046=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 (16777216 ||| 2^29) q12Shape25T1047 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (503316480 ||| 2^29) 16777216 q12Shape25T1062)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1047OK,q12Shape25T1062OK⟩

def q12Shape25P35 : Tree 12 := q12Shape25T1046
theorem q12Shape25P35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 503316480 16777216 q12Shape25P35=true := q12Shape25T1046OK

end Graffiti384b.EffectiveSearch.Q12
