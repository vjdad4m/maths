import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T138 : Tree 12 := (.tip (.cover {2,3,4,5,6,9,10}))
private theorem q12Shape25T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 4191871303680 q12Shape25T138=true := by decide

private def q12Shape25T140 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape25T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2405181685760 6390894559232 q12Shape25T140=true := by decide

private def q12Shape25T146 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,9,11})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.tip (.cover {0,1,3,4,7,9,11})) (.tip (.cover {0,2,4,6,7,9,11}))) (.tip (.cover {0,4,6,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,11})))))
private theorem q12Shape25T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 28381127115788 q12Shape25T146=true := by decide

private def q12Shape25T147 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.tip (.cover {0,1,3,4,7,9,11})) (.tip (.cover {0,2,3,6,7,9,11}))) (.tip (.cover {0,3,6,7,8,9,11})))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,11})))
private theorem q12Shape25T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228197888 28381127114764 q12Shape25T147=true := by decide

private def q12Shape25T145 : Tree 12 := .split 10 q12Shape25T146 q12Shape25T147
private theorem q12Shape25T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 28381127114764 q12Shape25T145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 (28381127114764 ||| 2^10) q12Shape25T146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196864 ||| 2^10) 28381127114764 q12Shape25T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T146OK,q12Shape25T147OK⟩

private def q12Shape25T149 : Tree 12 := (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,7,9,11})) (.tip (.cover {0,1,2,5,7,9,11}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,5,7,9,11})))) (.tip (.cover {0,1,4,7,8,9,11})))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape25T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196872 28381127115780 q12Shape25T149=true := by decide

private def q12Shape25T150 : Tree 12 := (.split 11 (.split 17 (.split 18 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,7,9,11})) (.tip (.cover {0,1,2,5,7,9,11}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,5,7,9,11})))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,8,9}))) (.tip (.cover {0,1,3,7,8,9,11})))
private theorem q12Shape25T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228197896 28381127114756 q12Shape25T150=true := by decide

private def q12Shape25T148 : Tree 12 := .split 10 q12Shape25T149 q12Shape25T150
private theorem q12Shape25T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196872 28381127114756 q12Shape25T148=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196872 (28381127114756 ||| 2^10) q12Shape25T149 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196872 ||| 2^10) 28381127114756 q12Shape25T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T149OK,q12Shape25T150OK⟩

private def q12Shape25T144 : Tree 12 := .split 3 q12Shape25T145 q12Shape25T148
private theorem q12Shape25T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 28381127114756 q12Shape25T144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 (28381127114756 ||| 2^3) q12Shape25T145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196864 ||| 2^3) 28381127114756 q12Shape25T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T145OK,q12Shape25T148OK⟩

private def q12Shape25T154 : Tree 12 := (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.tip (.cover {1,3,4,5,7,9,11})) (.tip (.cover {0,1,2,6,7,9,11}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,6,7,9,11}))))) (.tip (.cover {0,1,4,7,8,9,11})))
private theorem q12Shape25T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196868 28381127117832 q12Shape25T154=true := by decide

private def q12Shape25T155 : Tree 12 := (.split 17 (.split 18 (.split 4 (.split 5 (.tip (.cover {1,3,4,5,7,9,11})) (.tip (.cover {0,1,2,6,7,9,11}))) (.split 5 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,6,7,9,11})))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,8,9})))
private theorem q12Shape25T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228198916 28381127115784 q12Shape25T155=true := by decide

private def q12Shape25T153 : Tree 12 := .split 11 q12Shape25T154 q12Shape25T155
private theorem q12Shape25T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196868 28381127115784 q12Shape25T153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196868 (28381127115784 ||| 2^11) q12Shape25T154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196868 ||| 2^11) 28381127115784 q12Shape25T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T154OK,q12Shape25T155OK⟩

private def q12Shape25T156 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228197892 28381127114760 q12Shape25T156=true := by decide

private def q12Shape25T152 : Tree 12 := .split 10 q12Shape25T153 q12Shape25T156
private theorem q12Shape25T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196868 28381127114760 q12Shape25T152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196868 (28381127114760 ||| 2^10) q12Shape25T153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196868 ||| 2^10) 28381127114760 q12Shape25T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T153OK,q12Shape25T156OK⟩

private def q12Shape25T157 : Tree 12 := (.tip (.cover {0,1,2,7,8,9,11}))
private theorem q12Shape25T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196876 28381127114752 q12Shape25T157=true := by decide

private def q12Shape25T151 : Tree 12 := .split 3 q12Shape25T152 q12Shape25T157
private theorem q12Shape25T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196868 28381127114752 q12Shape25T151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196868 (28381127114752 ||| 2^3) q12Shape25T152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196868 ||| 2^3) 28381127114752 q12Shape25T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T152OK,q12Shape25T157OK⟩

private def q12Shape25T143 : Tree 12 := .split 2 q12Shape25T144 q12Shape25T151
private theorem q12Shape25T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 28381127114752 q12Shape25T143=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 (28381127114752 ||| 2^2) q12Shape25T144 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196864 ||| 2^2) 28381127114752 q12Shape25T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T144OK,q12Shape25T151OK⟩

private def q12Shape25T158 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,10}))
private theorem q12Shape25T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24395414241280 10788941070336 q12Shape25T158=true := by decide

private def q12Shape25T142 : Tree 12 := .split 44 q12Shape25T143 q12Shape25T158
private theorem q12Shape25T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 10788941070336 q12Shape25T142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 (10788941070336 ||| 2^44) q12Shape25T143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196864 ||| 2^44) 10788941070336 q12Shape25T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T143OK,q12Shape25T158OK⟩

private def q12Shape25T159 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,9}))
private theorem q12Shape25T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15599321219072 1992848048128 q12Shape25T159=true := by decide

private def q12Shape25T141 : Tree 12 := .split 43 q12Shape25T142 q12Shape25T159
private theorem q12Shape25T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 1992848048128 q12Shape25T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6803228196864 (1992848048128 ||| 2^43) q12Shape25T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6803228196864 ||| 2^43) 1992848048128 q12Shape25T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T142OK,q12Shape25T159OK⟩

private def q12Shape25T139 : Tree 12 := .split 42 q12Shape25T140 q12Shape25T141
private theorem q12Shape25T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2405181685760 1992848048128 q12Shape25T139=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2405181685760 (1992848048128 ||| 2^42) q12Shape25T140 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (2405181685760 ||| 2^42) 1992848048128 q12Shape25T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T140OK,q12Shape25T141OK⟩

private def q12Shape25T137 : Tree 12 := .split 41 q12Shape25T138 q12Shape25T139
private theorem q12Shape25T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 1992848048128 q12Shape25T137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 (1992848048128 ||| 2^41) q12Shape25T138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (206158430208 ||| 2^41) 1992848048128 q12Shape25T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T138OK,q12Shape25T139OK⟩

private def q12Shape25T160 : Tree 12 := (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape25T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1305670057984 893336420352 q12Shape25T160=true := by decide

private def q12Shape25T136 : Tree 12 := .split 40 q12Shape25T137 q12Shape25T160
private theorem q12Shape25T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 893336420352 q12Shape25T136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 (893336420352 ||| 2^40) q12Shape25T137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (206158430208 ||| 2^40) 893336420352 q12Shape25T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T137OK,q12Shape25T160OK⟩

private def q12Shape25T161 : Tree 12 := (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 755914244096 343580606464 q12Shape25T161=true := by decide

private def q12Shape25T135 : Tree 12 := .split 39 q12Shape25T136 q12Shape25T161
private theorem q12Shape25T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 343580606464 q12Shape25T135=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 (343580606464 ||| 2^39) q12Shape25T136 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (206158430208 ||| 2^39) 343580606464 q12Shape25T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T136OK,q12Shape25T161OK⟩

private def q12Shape25T164 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 481036337152 1717970141184 q12Shape25T164=true := by decide

private def q12Shape25T165 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,7,8,9})))
private theorem q12Shape25T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1580547964928 618458513408 q12Shape25T165=true := by decide

private def q12Shape25T163 : Tree 12 := .split 40 q12Shape25T164 q12Shape25T165
private theorem q12Shape25T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 481036337152 618458513408 q12Shape25T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 481036337152 (618458513408 ||| 2^40) q12Shape25T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (481036337152 ||| 2^40) 618458513408 q12Shape25T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T164OK,q12Shape25T165OK⟩

private def q12Shape25T166 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1030792151040 68702699520 q12Shape25T166=true := by decide

private def q12Shape25T162 : Tree 12 := .split 39 q12Shape25T163 q12Shape25T166
private theorem q12Shape25T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 481036337152 68702699520 q12Shape25T162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 481036337152 (68702699520 ||| 2^39) q12Shape25T163 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (481036337152 ||| 2^39) 68702699520 q12Shape25T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T163OK,q12Shape25T166OK⟩

private def q12Shape25T134 : Tree 12 := .split 38 q12Shape25T135 q12Shape25T162
private theorem q12Shape25T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 68702699520 q12Shape25T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 (68702699520 ||| 2^38) q12Shape25T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (206158430208 ||| 2^38) 68702699520 q12Shape25T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T135OK,q12Shape25T162OK⟩

def q12Shape25P3 : Tree 12 := q12Shape25T134
theorem q12Shape25P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 206158430208 68702699520 q12Shape25P3=true := q12Shape25T134OK

end Graffiti384b.EffectiveSearch.Q12
