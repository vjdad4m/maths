import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T1134 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 31104958464 q12Shape25T1134=true := by decide

private def q12Shape25T1135 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 20417871872 13925089280 q12Shape25T1135=true := by decide

private def q12Shape25T1133 : Tree 12 := .split 34 q12Shape25T1134 q12Shape25T1135
private theorem q12Shape25T1133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 13925089280 q12Shape25T1133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 (13925089280 ||| 2^34) q12Shape25T1134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3238002688 ||| 2^34) 13925089280 q12Shape25T1135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1134OK,q12Shape25T1135OK⟩

private def q12Shape25T1137 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11827937280 22515023872 q12Shape25T1137=true := by decide

private def q12Shape25T1138 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 29007806464 5335154688 q12Shape25T1138=true := by decide

private def q12Shape25T1136 : Tree 12 := .split 34 q12Shape25T1137 q12Shape25T1138
private theorem q12Shape25T1136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11827937280 5335154688 q12Shape25T1136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 11827937280 (5335154688 ||| 2^34) q12Shape25T1137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (11827937280 ||| 2^34) 5335154688 q12Shape25T1138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1137OK,q12Shape25T1138OK⟩

private def q12Shape25T1132 : Tree 12 := .split 33 q12Shape25T1133 q12Shape25T1136
private theorem q12Shape25T1132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 5335154688 q12Shape25T1132=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 (5335154688 ||| 2^33) q12Shape25T1133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3238002688 ||| 2^33) 5335154688 q12Shape25T1136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1133OK,q12Shape25T1136OK⟩

private def q12Shape25T1141 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7532969984 26809991168 q12Shape25T1141=true := by decide

private def q12Shape25T1142 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24712839168 9630121984 q12Shape25T1142=true := by decide

private def q12Shape25T1140 : Tree 12 := .split 34 q12Shape25T1141 q12Shape25T1142
private theorem q12Shape25T1140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7532969984 9630121984 q12Shape25T1140=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7532969984 (9630121984 ||| 2^34) q12Shape25T1141 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (7532969984 ||| 2^34) 9630121984 q12Shape25T1142)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1141OK,q12Shape25T1142OK⟩

private def q12Shape25T1144 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16122904576 18220056576 q12Shape25T1144=true := by decide

private def q12Shape25T1145 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape25T1145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 33302773760 1040187392 q12Shape25T1145=true := by decide

private def q12Shape25T1143 : Tree 12 := .split 34 q12Shape25T1144 q12Shape25T1145
private theorem q12Shape25T1143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16122904576 1040187392 q12Shape25T1143=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 16122904576 (1040187392 ||| 2^34) q12Shape25T1144 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (16122904576 ||| 2^34) 1040187392 q12Shape25T1145)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1144OK,q12Shape25T1145OK⟩

private def q12Shape25T1139 : Tree 12 := .split 33 q12Shape25T1140 q12Shape25T1143
private theorem q12Shape25T1139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7532969984 1040187392 q12Shape25T1139=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 7532969984 (1040187392 ||| 2^33) q12Shape25T1140 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (7532969984 ||| 2^33) 1040187392 q12Shape25T1143)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1140OK,q12Shape25T1143OK⟩

private def q12Shape25T1131 : Tree 12 := .split 32 q12Shape25T1132 q12Shape25T1139
private theorem q12Shape25T1131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 1040187392 q12Shape25T1131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 (1040187392 ||| 2^32) q12Shape25T1132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (3238002688 ||| 2^32) 1040187392 q12Shape25T1139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1132OK,q12Shape25T1139OK⟩

def q12Shape25P39 : Tree 12 := q12Shape25T1131
theorem q12Shape25P39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3238002688 1040187392 q12Shape25P39=true := q12Shape25T1131OK

private def q12Shape25T1148 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,6,9,10,11})) (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 553648128 503316480 q12Shape25T1148=true := by decide

def q12Shape25P40 : Tree 12 := q12Shape25T1148
theorem q12Shape25P40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 553648128 503316480 q12Shape25P40=true := q12Shape25T1148OK

private def q12Shape25T1151 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,6,9,10,11})) (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 285212672 771751936 q12Shape25T1151=true := by decide

private def q12Shape25T1152 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,6,9,10,11})) (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 822083584 234881024 q12Shape25T1152=true := by decide

private def q12Shape25T1150 : Tree 12 := .split 29 q12Shape25T1151 q12Shape25T1152
private theorem q12Shape25T1150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 285212672 234881024 q12Shape25T1150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 285212672 (234881024 ||| 2^29) q12Shape25T1151 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (285212672 ||| 2^29) 234881024 q12Shape25T1152)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1151OK,q12Shape25T1152OK⟩

def q12Shape25P41 : Tree 12 := q12Shape25T1150
theorem q12Shape25P41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 285212672 234881024 q12Shape25P41=true := q12Shape25T1150OK

end Graffiti384b.EffectiveSearch.Q12
