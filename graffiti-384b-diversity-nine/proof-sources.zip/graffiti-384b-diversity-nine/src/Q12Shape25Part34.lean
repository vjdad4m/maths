import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T1186 : Tree 12 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 2046820352 q12Shape25T1186=true := by decide

private def q12Shape25T1187 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1157627904 973078528 q12Shape25T1187=true := by decide

private def q12Shape25T1185 : Tree 12 := .split 30 q12Shape25T1186 q12Shape25T1187
private theorem q12Shape25T1185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 973078528 q12Shape25T1185=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 (973078528 ||| 2^30) q12Shape25T1186 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (83886080 ||| 2^30) 973078528 q12Shape25T1187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1186OK,q12Shape25T1187OK⟩

private def q12Shape25T1189 : Tree 12 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 620756992 1509949440 q12Shape25T1189=true := by decide

private def q12Shape25T1190 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1694498816 436207616 q12Shape25T1190=true := by decide

private def q12Shape25T1188 : Tree 12 := .split 30 q12Shape25T1189 q12Shape25T1190
private theorem q12Shape25T1188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 620756992 436207616 q12Shape25T1188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 620756992 (436207616 ||| 2^30) q12Shape25T1189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (620756992 ||| 2^30) 436207616 q12Shape25T1190)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1189OK,q12Shape25T1190OK⟩

private def q12Shape25T1184 : Tree 12 := .split 29 q12Shape25T1185 q12Shape25T1188
private theorem q12Shape25T1184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 436207616 q12Shape25T1184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 (436207616 ||| 2^29) q12Shape25T1185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (83886080 ||| 2^29) 436207616 q12Shape25T1188)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1185OK,q12Shape25T1188OK⟩

private def q12Shape25T1194 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 35 (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.split 37 (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 352321536 3925868544 q12Shape25T1194=true := by decide

private def q12Shape25T1195 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2499805184 1778384896 q12Shape25T1195=true := by decide

private def q12Shape25T1193 : Tree 12 := .split 31 q12Shape25T1194 q12Shape25T1195
private theorem q12Shape25T1193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 352321536 1778384896 q12Shape25T1193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 352321536 (1778384896 ||| 2^31) q12Shape25T1194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (352321536 ||| 2^31) 1778384896 q12Shape25T1195)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1194OK,q12Shape25T1195OK⟩

private def q12Shape25T1196 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1426063360 704643072 q12Shape25T1196=true := by decide

private def q12Shape25T1192 : Tree 12 := .split 30 q12Shape25T1193 q12Shape25T1196
private theorem q12Shape25T1192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 352321536 704643072 q12Shape25T1192=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 352321536 (704643072 ||| 2^30) q12Shape25T1193 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (352321536 ||| 2^30) 704643072 q12Shape25T1196)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1193OK,q12Shape25T1196OK⟩

private def q12Shape25T1201 : Tree 12 := (.split 34 (.split 35 (.split 36 (.tip (.cover {2,3,4,6,8,10,11})) (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 16273899520 q12Shape25T1201=true := by decide

private def q12Shape25T1202 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9479127040 7683964928 q12Shape25T1202=true := by decide

private def q12Shape25T1200 : Tree 12 := .split 33 q12Shape25T1201 q12Shape25T1202
private theorem q12Shape25T1200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 7683964928 q12Shape25T1200=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 (7683964928 ||| 2^33) q12Shape25T1201 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (889192448 ||| 2^33) 7683964928 q12Shape25T1202)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1201OK,q12Shape25T1202OK⟩

private def q12Shape25T1203 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5184159744 3388997632 q12Shape25T1203=true := by decide

private def q12Shape25T1199 : Tree 12 := .split 32 q12Shape25T1200 q12Shape25T1203
private theorem q12Shape25T1199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 3388997632 q12Shape25T1199=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 (3388997632 ||| 2^32) q12Shape25T1200 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (889192448 ||| 2^32) 3388997632 q12Shape25T1203)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1200OK,q12Shape25T1203OK⟩

private def q12Shape25T1204 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3036676096 1241513984 q12Shape25T1204=true := by decide

private def q12Shape25T1198 : Tree 12 := .split 31 q12Shape25T1199 q12Shape25T1204
private theorem q12Shape25T1198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 1241513984 q12Shape25T1198=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 (1241513984 ||| 2^31) q12Shape25T1199 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (889192448 ||| 2^31) 1241513984 q12Shape25T1204)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1199OK,q12Shape25T1204OK⟩

private def q12Shape25T1205 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1962934272 167772160 q12Shape25T1205=true := by decide

private def q12Shape25T1197 : Tree 12 := .split 30 q12Shape25T1198 q12Shape25T1205
private theorem q12Shape25T1197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 167772160 q12Shape25T1197=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 889192448 (167772160 ||| 2^30) q12Shape25T1198 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (889192448 ||| 2^30) 167772160 q12Shape25T1205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1198OK,q12Shape25T1205OK⟩

private def q12Shape25T1191 : Tree 12 := .split 29 q12Shape25T1192 q12Shape25T1197
private theorem q12Shape25T1191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 352321536 167772160 q12Shape25T1191=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 352321536 (167772160 ||| 2^29) q12Shape25T1192 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (352321536 ||| 2^29) 167772160 q12Shape25T1197)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1192OK,q12Shape25T1197OK⟩

private def q12Shape25T1183 : Tree 12 := .split 28 q12Shape25T1184 q12Shape25T1191
private theorem q12Shape25T1183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 167772160 q12Shape25T1183=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 (167772160 ||| 2^28) q12Shape25T1184 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (83886080 ||| 2^28) 167772160 q12Shape25T1191)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1184OK,q12Shape25T1191OK⟩

private def q12Shape25T1210 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 4060086272 q12Shape25T1210=true := by decide

private def q12Shape25T1211 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2365587456 1912602624 q12Shape25T1211=true := by decide

private def q12Shape25T1209 : Tree 12 := .split 31 q12Shape25T1210 q12Shape25T1211
private theorem q12Shape25T1209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 1912602624 q12Shape25T1209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 (1912602624 ||| 2^31) q12Shape25T1210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (218103808 ||| 2^31) 1912602624 q12Shape25T1211)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1210OK,q12Shape25T1211OK⟩

private def q12Shape25T1212 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1291845632 838860800 q12Shape25T1212=true := by decide

private def q12Shape25T1208 : Tree 12 := .split 30 q12Shape25T1209 q12Shape25T1212
private theorem q12Shape25T1208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 838860800 q12Shape25T1208=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 (838860800 ||| 2^30) q12Shape25T1209 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (218103808 ||| 2^30) 838860800 q12Shape25T1212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1209OK,q12Shape25T1212OK⟩

private def q12Shape25T1216 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.tip (.cover {2,3,4,6,8,9,11})) (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 754974720 7818182656 q12Shape25T1216=true := by decide

private def q12Shape25T1217 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5049942016 3523215360 q12Shape25T1217=true := by decide

private def q12Shape25T1215 : Tree 12 := .split 32 q12Shape25T1216 q12Shape25T1217
private theorem q12Shape25T1215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 754974720 3523215360 q12Shape25T1215=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 754974720 (3523215360 ||| 2^32) q12Shape25T1216 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (754974720 ||| 2^32) 3523215360 q12Shape25T1217)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1216OK,q12Shape25T1217OK⟩

private def q12Shape25T1218 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2902458368 1375731712 q12Shape25T1218=true := by decide

private def q12Shape25T1214 : Tree 12 := .split 31 q12Shape25T1215 q12Shape25T1218
private theorem q12Shape25T1214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 754974720 1375731712 q12Shape25T1214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 754974720 (1375731712 ||| 2^31) q12Shape25T1215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (754974720 ||| 2^31) 1375731712 q12Shape25T1218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1215OK,q12Shape25T1218OK⟩

private def q12Shape25T1219 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1828716544 301989888 q12Shape25T1219=true := by decide

private def q12Shape25T1213 : Tree 12 := .split 30 q12Shape25T1214 q12Shape25T1219
private theorem q12Shape25T1213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 754974720 301989888 q12Shape25T1213=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 754974720 (301989888 ||| 2^30) q12Shape25T1214 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (754974720 ||| 2^30) 301989888 q12Shape25T1219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1214OK,q12Shape25T1219OK⟩

private def q12Shape25T1207 : Tree 12 := .split 29 q12Shape25T1208 q12Shape25T1213
private theorem q12Shape25T1207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 301989888 q12Shape25T1207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 (301989888 ||| 2^29) q12Shape25T1208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (218103808 ||| 2^29) 301989888 q12Shape25T1213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1208OK,q12Shape25T1213OK⟩

private def q12Shape25T1224 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.tip (.cover {2,3,4,6,8,9,10})) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 8086618112 q12Shape25T1224=true := by decide

private def q12Shape25T1225 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4781506560 3791650816 q12Shape25T1225=true := by decide

private def q12Shape25T1223 : Tree 12 := .split 32 q12Shape25T1224 q12Shape25T1225
private theorem q12Shape25T1223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 3791650816 q12Shape25T1223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 (3791650816 ||| 2^32) q12Shape25T1224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (486539264 ||| 2^32) 3791650816 q12Shape25T1225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1224OK,q12Shape25T1225OK⟩

private def q12Shape25T1226 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2634022912 1644167168 q12Shape25T1226=true := by decide

private def q12Shape25T1222 : Tree 12 := .split 31 q12Shape25T1223 q12Shape25T1226
private theorem q12Shape25T1222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 1644167168 q12Shape25T1222=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 (1644167168 ||| 2^31) q12Shape25T1223 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (486539264 ||| 2^31) 1644167168 q12Shape25T1226)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1223OK,q12Shape25T1226OK⟩

private def q12Shape25T1227 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1560281088 570425344 q12Shape25T1227=true := by decide

private def q12Shape25T1221 : Tree 12 := .split 30 q12Shape25T1222 q12Shape25T1227
private theorem q12Shape25T1221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 570425344 q12Shape25T1221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 (570425344 ||| 2^30) q12Shape25T1222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (486539264 ||| 2^30) 570425344 q12Shape25T1227)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1222OK,q12Shape25T1227OK⟩

private def q12Shape25T1231 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1023410176 7549747200 q12Shape25T1231=true := by decide

private def q12Shape25T1232 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5318377472 3254779904 q12Shape25T1232=true := by decide

private def q12Shape25T1230 : Tree 12 := .split 32 q12Shape25T1231 q12Shape25T1232
private theorem q12Shape25T1230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1023410176 3254779904 q12Shape25T1230=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1023410176 (3254779904 ||| 2^32) q12Shape25T1231 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1023410176 ||| 2^32) 3254779904 q12Shape25T1232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1231OK,q12Shape25T1232OK⟩

private def q12Shape25T1233 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3170893824 1107296256 q12Shape25T1233=true := by decide

private def q12Shape25T1229 : Tree 12 := .split 31 q12Shape25T1230 q12Shape25T1233
private theorem q12Shape25T1229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1023410176 1107296256 q12Shape25T1229=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1023410176 (1107296256 ||| 2^31) q12Shape25T1230 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1023410176 ||| 2^31) 1107296256 q12Shape25T1233)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1230OK,q12Shape25T1233OK⟩

private def q12Shape25T1234 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2097152000 33554432 q12Shape25T1234=true := by decide

private def q12Shape25T1228 : Tree 12 := .split 30 q12Shape25T1229 q12Shape25T1234
private theorem q12Shape25T1228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1023410176 33554432 q12Shape25T1228=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1023410176 (33554432 ||| 2^30) q12Shape25T1229 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1023410176 ||| 2^30) 33554432 q12Shape25T1234)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1229OK,q12Shape25T1234OK⟩

private def q12Shape25T1220 : Tree 12 := .split 29 q12Shape25T1221 q12Shape25T1228
private theorem q12Shape25T1220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 33554432 q12Shape25T1220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 486539264 (33554432 ||| 2^29) q12Shape25T1221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (486539264 ||| 2^29) 33554432 q12Shape25T1228)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1221OK,q12Shape25T1228OK⟩

private def q12Shape25T1206 : Tree 12 := .split 28 q12Shape25T1207 q12Shape25T1220
private theorem q12Shape25T1206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 33554432 q12Shape25T1206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 218103808 (33554432 ||| 2^28) q12Shape25T1207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (218103808 ||| 2^28) 33554432 q12Shape25T1220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1207OK,q12Shape25T1220OK⟩

private def q12Shape25T1182 : Tree 12 := .split 27 q12Shape25T1183 q12Shape25T1206
private theorem q12Shape25T1182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 33554432 q12Shape25T1182=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 (33554432 ||| 2^27) q12Shape25T1183 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (83886080 ||| 2^27) 33554432 q12Shape25T1206)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1183OK,q12Shape25T1206OK⟩

def q12Shape25P43 : Tree 12 := q12Shape25T1182
theorem q12Shape25P43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 83886080 33554432 q12Shape25P43=true := q12Shape25T1182OK

end Graffiti384b.EffectiveSearch.Q12
