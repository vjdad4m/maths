import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T1243 : Tree 12 := (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 17112760320 q12Shape25T1243=true := by decide

private def q12Shape25T1244 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8640266240 8522825728 q12Shape25T1244=true := by decide

private def q12Shape25T1242 : Tree 12 := .split 33 q12Shape25T1243 q12Shape25T1244
private theorem q12Shape25T1242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 8522825728 q12Shape25T1242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (8522825728 ||| 2^33) q12Shape25T1243 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^33) 8522825728 q12Shape25T1244)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1243OK,q12Shape25T1244OK⟩

private def q12Shape25T1245 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4345298944 4227858432 q12Shape25T1245=true := by decide

private def q12Shape25T1241 : Tree 12 := .split 32 q12Shape25T1242 q12Shape25T1245
private theorem q12Shape25T1241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 4227858432 q12Shape25T1241=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (4227858432 ||| 2^32) q12Shape25T1242 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^32) 4227858432 q12Shape25T1245)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1242OK,q12Shape25T1245OK⟩

private def q12Shape25T1246 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2197815296 2080374784 q12Shape25T1246=true := by decide

private def q12Shape25T1240 : Tree 12 := .split 31 q12Shape25T1241 q12Shape25T1246
private theorem q12Shape25T1240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 2080374784 q12Shape25T1240=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (2080374784 ||| 2^31) q12Shape25T1241 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^31) 2080374784 q12Shape25T1246)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1241OK,q12Shape25T1246OK⟩

private def q12Shape25T1247 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1124073472 1006632960 q12Shape25T1247=true := by decide

private def q12Shape25T1239 : Tree 12 := .split 30 q12Shape25T1240 q12Shape25T1247
private theorem q12Shape25T1239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 1006632960 q12Shape25T1239=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (1006632960 ||| 2^30) q12Shape25T1240 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^30) 1006632960 q12Shape25T1247)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1240OK,q12Shape25T1247OK⟩

private def q12Shape25T1252 : Tree 12 := (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 16575889408 q12Shape25T1252=true := by decide

private def q12Shape25T1253 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9177137152 7985954816 q12Shape25T1253=true := by decide

private def q12Shape25T1251 : Tree 12 := .split 33 q12Shape25T1252 q12Shape25T1253
private theorem q12Shape25T1251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 7985954816 q12Shape25T1251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 (7985954816 ||| 2^33) q12Shape25T1252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (587202560 ||| 2^33) 7985954816 q12Shape25T1253)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1252OK,q12Shape25T1253OK⟩

private def q12Shape25T1254 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4882169856 3690987520 q12Shape25T1254=true := by decide

private def q12Shape25T1250 : Tree 12 := .split 32 q12Shape25T1251 q12Shape25T1254
private theorem q12Shape25T1250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 3690987520 q12Shape25T1250=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 (3690987520 ||| 2^32) q12Shape25T1251 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (587202560 ||| 2^32) 3690987520 q12Shape25T1254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1251OK,q12Shape25T1254OK⟩

private def q12Shape25T1255 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2734686208 1543503872 q12Shape25T1255=true := by decide

private def q12Shape25T1249 : Tree 12 := .split 31 q12Shape25T1250 q12Shape25T1255
private theorem q12Shape25T1249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 1543503872 q12Shape25T1249=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 (1543503872 ||| 2^31) q12Shape25T1250 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (587202560 ||| 2^31) 1543503872 q12Shape25T1255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1250OK,q12Shape25T1255OK⟩

private def q12Shape25T1256 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1660944384 469762048 q12Shape25T1256=true := by decide

private def q12Shape25T1248 : Tree 12 := .split 30 q12Shape25T1249 q12Shape25T1256
private theorem q12Shape25T1248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 469762048 q12Shape25T1248=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 587202560 (469762048 ||| 2^30) q12Shape25T1249 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (587202560 ||| 2^30) 469762048 q12Shape25T1256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1249OK,q12Shape25T1256OK⟩

private def q12Shape25T1238 : Tree 12 := .split 29 q12Shape25T1239 q12Shape25T1248
private theorem q12Shape25T1238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 469762048 q12Shape25T1238=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (469762048 ||| 2^29) q12Shape25T1239 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^29) 469762048 q12Shape25T1248)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1239OK,q12Shape25T1248OK⟩

private def q12Shape25T1262 : Tree 12 := (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,8,9,11})))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 16844324864 q12Shape25T1262=true := by decide

private def q12Shape25T1263 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 8908701696 8254390272 q12Shape25T1263=true := by decide

private def q12Shape25T1261 : Tree 12 := .split 33 q12Shape25T1262 q12Shape25T1263
private theorem q12Shape25T1261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 8254390272 q12Shape25T1261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 (8254390272 ||| 2^33) q12Shape25T1262 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (318767104 ||| 2^33) 8254390272 q12Shape25T1263)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1262OK,q12Shape25T1263OK⟩

private def q12Shape25T1264 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4613734400 3959422976 q12Shape25T1264=true := by decide

private def q12Shape25T1260 : Tree 12 := .split 32 q12Shape25T1261 q12Shape25T1264
private theorem q12Shape25T1260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 3959422976 q12Shape25T1260=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 (3959422976 ||| 2^32) q12Shape25T1261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (318767104 ||| 2^32) 3959422976 q12Shape25T1264)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1261OK,q12Shape25T1264OK⟩

private def q12Shape25T1265 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2466250752 1811939328 q12Shape25T1265=true := by decide

private def q12Shape25T1259 : Tree 12 := .split 31 q12Shape25T1260 q12Shape25T1265
private theorem q12Shape25T1259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 1811939328 q12Shape25T1259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 (1811939328 ||| 2^31) q12Shape25T1260 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (318767104 ||| 2^31) 1811939328 q12Shape25T1265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1260OK,q12Shape25T1265OK⟩

private def q12Shape25T1266 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1392508928 738197504 q12Shape25T1266=true := by decide

private def q12Shape25T1258 : Tree 12 := .split 30 q12Shape25T1259 q12Shape25T1266
private theorem q12Shape25T1258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 738197504 q12Shape25T1258=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 (738197504 ||| 2^30) q12Shape25T1259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (318767104 ||| 2^30) 738197504 q12Shape25T1266)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1259OK,q12Shape25T1266OK⟩

private def q12Shape25T1271 : Tree 12 := (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,8,9,11})))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 16307453952 q12Shape25T1271=true := by decide

private def q12Shape25T1272 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9445572608 7717519360 q12Shape25T1272=true := by decide

private def q12Shape25T1270 : Tree 12 := .split 33 q12Shape25T1271 q12Shape25T1272
private theorem q12Shape25T1270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 7717519360 q12Shape25T1270=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 (7717519360 ||| 2^33) q12Shape25T1271 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (855638016 ||| 2^33) 7717519360 q12Shape25T1272)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1271OK,q12Shape25T1272OK⟩

private def q12Shape25T1273 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5150605312 3422552064 q12Shape25T1273=true := by decide

private def q12Shape25T1269 : Tree 12 := .split 32 q12Shape25T1270 q12Shape25T1273
private theorem q12Shape25T1269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 3422552064 q12Shape25T1269=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 (3422552064 ||| 2^32) q12Shape25T1270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (855638016 ||| 2^32) 3422552064 q12Shape25T1273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1270OK,q12Shape25T1273OK⟩

private def q12Shape25T1274 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3003121664 1275068416 q12Shape25T1274=true := by decide

private def q12Shape25T1268 : Tree 12 := .split 31 q12Shape25T1269 q12Shape25T1274
private theorem q12Shape25T1268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 1275068416 q12Shape25T1268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 (1275068416 ||| 2^31) q12Shape25T1269 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (855638016 ||| 2^31) 1275068416 q12Shape25T1274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1269OK,q12Shape25T1274OK⟩

private def q12Shape25T1275 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1929379840 201326592 q12Shape25T1275=true := by decide

private def q12Shape25T1267 : Tree 12 := .split 30 q12Shape25T1268 q12Shape25T1275
private theorem q12Shape25T1267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 201326592 q12Shape25T1267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 855638016 (201326592 ||| 2^30) q12Shape25T1268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (855638016 ||| 2^30) 201326592 q12Shape25T1275)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1268OK,q12Shape25T1275OK⟩

private def q12Shape25T1257 : Tree 12 := .split 29 q12Shape25T1258 q12Shape25T1267
private theorem q12Shape25T1257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 201326592 q12Shape25T1257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 318767104 (201326592 ||| 2^29) q12Shape25T1258 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (318767104 ||| 2^29) 201326592 q12Shape25T1267)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1258OK,q12Shape25T1267OK⟩

private def q12Shape25T1237 : Tree 12 := .split 28 q12Shape25T1238 q12Shape25T1257
private theorem q12Shape25T1237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 201326592 q12Shape25T1237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (201326592 ||| 2^28) q12Shape25T1238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^28) 201326592 q12Shape25T1257)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1238OK,q12Shape25T1257OK⟩

private def q12Shape25T1281 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 8388608000 q12Shape25T1281=true := by decide

private def q12Shape25T1282 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4479516672 4093640704 q12Shape25T1282=true := by decide

private def q12Shape25T1280 : Tree 12 := .split 32 q12Shape25T1281 q12Shape25T1282
private theorem q12Shape25T1280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 4093640704 q12Shape25T1280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 (4093640704 ||| 2^32) q12Shape25T1281 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (184549376 ||| 2^32) 4093640704 q12Shape25T1282)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1281OK,q12Shape25T1282OK⟩

private def q12Shape25T1283 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2332033024 1946157056 q12Shape25T1283=true := by decide

private def q12Shape25T1279 : Tree 12 := .split 31 q12Shape25T1280 q12Shape25T1283
private theorem q12Shape25T1279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 1946157056 q12Shape25T1279=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 (1946157056 ||| 2^31) q12Shape25T1280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (184549376 ||| 2^31) 1946157056 q12Shape25T1283)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1280OK,q12Shape25T1283OK⟩

private def q12Shape25T1284 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1258291200 872415232 q12Shape25T1284=true := by decide

private def q12Shape25T1278 : Tree 12 := .split 30 q12Shape25T1279 q12Shape25T1284
private theorem q12Shape25T1278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 872415232 q12Shape25T1278=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 (872415232 ||| 2^30) q12Shape25T1279 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (184549376 ||| 2^30) 872415232 q12Shape25T1284)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1279OK,q12Shape25T1284OK⟩

private def q12Shape25T1288 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721420288 7851737088 q12Shape25T1288=true := by decide

private def q12Shape25T1289 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5016387584 3556769792 q12Shape25T1289=true := by decide

private def q12Shape25T1287 : Tree 12 := .split 32 q12Shape25T1288 q12Shape25T1289
private theorem q12Shape25T1287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721420288 3556769792 q12Shape25T1287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721420288 (3556769792 ||| 2^32) q12Shape25T1288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (721420288 ||| 2^32) 3556769792 q12Shape25T1289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1288OK,q12Shape25T1289OK⟩

private def q12Shape25T1290 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2868903936 1409286144 q12Shape25T1290=true := by decide

private def q12Shape25T1286 : Tree 12 := .split 31 q12Shape25T1287 q12Shape25T1290
private theorem q12Shape25T1286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721420288 1409286144 q12Shape25T1286=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721420288 (1409286144 ||| 2^31) q12Shape25T1287 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (721420288 ||| 2^31) 1409286144 q12Shape25T1290)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1287OK,q12Shape25T1290OK⟩

private def q12Shape25T1291 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1795162112 335544320 q12Shape25T1291=true := by decide

private def q12Shape25T1285 : Tree 12 := .split 30 q12Shape25T1286 q12Shape25T1291
private theorem q12Shape25T1285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721420288 335544320 q12Shape25T1285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721420288 (335544320 ||| 2^30) q12Shape25T1286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (721420288 ||| 2^30) 335544320 q12Shape25T1291)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1286OK,q12Shape25T1291OK⟩

private def q12Shape25T1277 : Tree 12 := .split 29 q12Shape25T1278 q12Shape25T1285
private theorem q12Shape25T1277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 335544320 q12Shape25T1277=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 (335544320 ||| 2^29) q12Shape25T1278 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (184549376 ||| 2^29) 335544320 q12Shape25T1285)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1278OK,q12Shape25T1285OK⟩

private def q12Shape25T1296 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 8120172544 q12Shape25T1296=true := by decide

private def q12Shape25T1297 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4747952128 3825205248 q12Shape25T1297=true := by decide

private def q12Shape25T1295 : Tree 12 := .split 32 q12Shape25T1296 q12Shape25T1297
private theorem q12Shape25T1295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 3825205248 q12Shape25T1295=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 (3825205248 ||| 2^32) q12Shape25T1296 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (452984832 ||| 2^32) 3825205248 q12Shape25T1297)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1296OK,q12Shape25T1297OK⟩

private def q12Shape25T1298 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2600468480 1677721600 q12Shape25T1298=true := by decide

private def q12Shape25T1294 : Tree 12 := .split 31 q12Shape25T1295 q12Shape25T1298
private theorem q12Shape25T1294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 1677721600 q12Shape25T1294=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 (1677721600 ||| 2^31) q12Shape25T1295 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (452984832 ||| 2^31) 1677721600 q12Shape25T1298)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1295OK,q12Shape25T1298OK⟩

private def q12Shape25T1299 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1526726656 603979776 q12Shape25T1299=true := by decide

private def q12Shape25T1293 : Tree 12 := .split 30 q12Shape25T1294 q12Shape25T1299
private theorem q12Shape25T1293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 603979776 q12Shape25T1293=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 (603979776 ||| 2^30) q12Shape25T1294 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (452984832 ||| 2^30) 603979776 q12Shape25T1299)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1294OK,q12Shape25T1299OK⟩

private def q12Shape25T1303 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 989855744 7583301632 q12Shape25T1303=true := by decide

private def q12Shape25T1304 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5284823040 3288334336 q12Shape25T1304=true := by decide

private def q12Shape25T1302 : Tree 12 := .split 32 q12Shape25T1303 q12Shape25T1304
private theorem q12Shape25T1302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 989855744 3288334336 q12Shape25T1302=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 989855744 (3288334336 ||| 2^32) q12Shape25T1303 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (989855744 ||| 2^32) 3288334336 q12Shape25T1304)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1303OK,q12Shape25T1304OK⟩

private def q12Shape25T1305 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1305OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3137339392 1140850688 q12Shape25T1305=true := by decide

private def q12Shape25T1301 : Tree 12 := .split 31 q12Shape25T1302 q12Shape25T1305
private theorem q12Shape25T1301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 989855744 1140850688 q12Shape25T1301=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 989855744 (1140850688 ||| 2^31) q12Shape25T1302 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (989855744 ||| 2^31) 1140850688 q12Shape25T1305)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1302OK,q12Shape25T1305OK⟩

private def q12Shape25T1306 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1306OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2063597568 67108864 q12Shape25T1306=true := by decide

private def q12Shape25T1300 : Tree 12 := .split 30 q12Shape25T1301 q12Shape25T1306
private theorem q12Shape25T1300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 989855744 67108864 q12Shape25T1300=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 989855744 (67108864 ||| 2^30) q12Shape25T1301 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (989855744 ||| 2^30) 67108864 q12Shape25T1306)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1301OK,q12Shape25T1306OK⟩

private def q12Shape25T1292 : Tree 12 := .split 29 q12Shape25T1293 q12Shape25T1300
private theorem q12Shape25T1292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 67108864 q12Shape25T1292=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 452984832 (67108864 ||| 2^29) q12Shape25T1293 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (452984832 ||| 2^29) 67108864 q12Shape25T1300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1293OK,q12Shape25T1300OK⟩

private def q12Shape25T1276 : Tree 12 := .split 28 q12Shape25T1277 q12Shape25T1292
private theorem q12Shape25T1276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 67108864 q12Shape25T1276=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 184549376 (67108864 ||| 2^28) q12Shape25T1277 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (184549376 ||| 2^28) 67108864 q12Shape25T1292)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1277OK,q12Shape25T1292OK⟩

private def q12Shape25T1236 : Tree 12 := .split 27 q12Shape25T1237 q12Shape25T1276
private theorem q12Shape25T1236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 67108864 q12Shape25T1236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 (67108864 ||| 2^27) q12Shape25T1237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (50331648 ||| 2^27) 67108864 q12Shape25T1276)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1237OK,q12Shape25T1276OK⟩

def q12Shape25P44 : Tree 12 := q12Shape25T1236
theorem q12Shape25P44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 50331648 67108864 q12Shape25P44=true := q12Shape25T1236OK

end Graffiti384b.EffectiveSearch.Q12
