import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T1313 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1313OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 8455716864 q12Shape25T1313=true := by decide

private def q12Shape25T1314 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1314OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4412407808 4160749568 q12Shape25T1314=true := by decide

private def q12Shape25T1312 : Tree 12 := .split 32 q12Shape25T1313 q12Shape25T1314
private theorem q12Shape25T1312OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 4160749568 q12Shape25T1312=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 (4160749568 ||| 2^32) q12Shape25T1313 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (117440512 ||| 2^32) 4160749568 q12Shape25T1314)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1313OK,q12Shape25T1314OK⟩

private def q12Shape25T1315 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1315OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2264924160 2013265920 q12Shape25T1315=true := by decide

private def q12Shape25T1311 : Tree 12 := .split 31 q12Shape25T1312 q12Shape25T1315
private theorem q12Shape25T1311OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 2013265920 q12Shape25T1311=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 (2013265920 ||| 2^31) q12Shape25T1312 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (117440512 ||| 2^31) 2013265920 q12Shape25T1315)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1312OK,q12Shape25T1315OK⟩

private def q12Shape25T1316 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1316OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1191182336 939524096 q12Shape25T1316=true := by decide

private def q12Shape25T1310 : Tree 12 := .split 30 q12Shape25T1311 q12Shape25T1316
private theorem q12Shape25T1310OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 939524096 q12Shape25T1310=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 (939524096 ||| 2^30) q12Shape25T1311 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (117440512 ||| 2^30) 939524096 q12Shape25T1316)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1311OK,q12Shape25T1316OK⟩

private def q12Shape25T1320 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1320OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 654311424 7918845952 q12Shape25T1320=true := by decide

private def q12Shape25T1321 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1321OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4949278720 3623878656 q12Shape25T1321=true := by decide

private def q12Shape25T1319 : Tree 12 := .split 32 q12Shape25T1320 q12Shape25T1321
private theorem q12Shape25T1319OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 654311424 3623878656 q12Shape25T1319=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 654311424 (3623878656 ||| 2^32) q12Shape25T1320 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (654311424 ||| 2^32) 3623878656 q12Shape25T1321)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1320OK,q12Shape25T1321OK⟩

private def q12Shape25T1322 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1322OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2801795072 1476395008 q12Shape25T1322=true := by decide

private def q12Shape25T1318 : Tree 12 := .split 31 q12Shape25T1319 q12Shape25T1322
private theorem q12Shape25T1318OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 654311424 1476395008 q12Shape25T1318=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 654311424 (1476395008 ||| 2^31) q12Shape25T1319 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (654311424 ||| 2^31) 1476395008 q12Shape25T1322)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1319OK,q12Shape25T1322OK⟩

private def q12Shape25T1323 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1323OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1728053248 402653184 q12Shape25T1323=true := by decide

private def q12Shape25T1317 : Tree 12 := .split 30 q12Shape25T1318 q12Shape25T1323
private theorem q12Shape25T1317OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 654311424 402653184 q12Shape25T1317=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 654311424 (402653184 ||| 2^30) q12Shape25T1318 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (654311424 ||| 2^30) 402653184 q12Shape25T1323)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1318OK,q12Shape25T1323OK⟩

private def q12Shape25T1309 : Tree 12 := .split 29 q12Shape25T1310 q12Shape25T1317
private theorem q12Shape25T1309OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 402653184 q12Shape25T1309=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 (402653184 ||| 2^29) q12Shape25T1310 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (117440512 ||| 2^29) 402653184 q12Shape25T1317)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1310OK,q12Shape25T1317OK⟩

private def q12Shape25T1328 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1328OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 8187281408 q12Shape25T1328=true := by decide

private def q12Shape25T1329 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1329OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4680843264 3892314112 q12Shape25T1329=true := by decide

private def q12Shape25T1327 : Tree 12 := .split 32 q12Shape25T1328 q12Shape25T1329
private theorem q12Shape25T1327OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 3892314112 q12Shape25T1327=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 (3892314112 ||| 2^32) q12Shape25T1328 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (385875968 ||| 2^32) 3892314112 q12Shape25T1329)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1328OK,q12Shape25T1329OK⟩

private def q12Shape25T1330 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1330OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2533359616 1744830464 q12Shape25T1330=true := by decide

private def q12Shape25T1326 : Tree 12 := .split 31 q12Shape25T1327 q12Shape25T1330
private theorem q12Shape25T1326OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 1744830464 q12Shape25T1326=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 (1744830464 ||| 2^31) q12Shape25T1327 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (385875968 ||| 2^31) 1744830464 q12Shape25T1330)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1327OK,q12Shape25T1330OK⟩

private def q12Shape25T1331 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1331OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1459617792 671088640 q12Shape25T1331=true := by decide

private def q12Shape25T1325 : Tree 12 := .split 30 q12Shape25T1326 q12Shape25T1331
private theorem q12Shape25T1325OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 671088640 q12Shape25T1325=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 (671088640 ||| 2^30) q12Shape25T1326 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (385875968 ||| 2^30) 671088640 q12Shape25T1331)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1326OK,q12Shape25T1331OK⟩

private def q12Shape25T1335 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 922746880 7650410496 q12Shape25T1335=true := by decide

private def q12Shape25T1336 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5217714176 3355443200 q12Shape25T1336=true := by decide

private def q12Shape25T1334 : Tree 12 := .split 32 q12Shape25T1335 q12Shape25T1336
private theorem q12Shape25T1334OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 922746880 3355443200 q12Shape25T1334=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 922746880 (3355443200 ||| 2^32) q12Shape25T1335 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (922746880 ||| 2^32) 3355443200 q12Shape25T1336)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1335OK,q12Shape25T1336OK⟩

private def q12Shape25T1337 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3070230528 1207959552 q12Shape25T1337=true := by decide

private def q12Shape25T1333 : Tree 12 := .split 31 q12Shape25T1334 q12Shape25T1337
private theorem q12Shape25T1333OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 922746880 1207959552 q12Shape25T1333=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 922746880 (1207959552 ||| 2^31) q12Shape25T1334 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (922746880 ||| 2^31) 1207959552 q12Shape25T1337)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1334OK,q12Shape25T1337OK⟩

private def q12Shape25T1338 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1996488704 134217728 q12Shape25T1338=true := by decide

private def q12Shape25T1332 : Tree 12 := .split 30 q12Shape25T1333 q12Shape25T1338
private theorem q12Shape25T1332OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 922746880 134217728 q12Shape25T1332=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 922746880 (134217728 ||| 2^30) q12Shape25T1333 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (922746880 ||| 2^30) 134217728 q12Shape25T1338)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1333OK,q12Shape25T1338OK⟩

private def q12Shape25T1324 : Tree 12 := .split 29 q12Shape25T1325 q12Shape25T1332
private theorem q12Shape25T1324OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 134217728 q12Shape25T1324=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 385875968 (134217728 ||| 2^29) q12Shape25T1325 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (385875968 ||| 2^29) 134217728 q12Shape25T1332)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1325OK,q12Shape25T1332OK⟩

private def q12Shape25T1308 : Tree 12 := .split 28 q12Shape25T1309 q12Shape25T1324
private theorem q12Shape25T1308OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 134217728 q12Shape25T1308=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 (134217728 ||| 2^28) q12Shape25T1309 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (117440512 ||| 2^28) 134217728 q12Shape25T1324)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1309OK,q12Shape25T1324OK⟩

private def q12Shape25T1344 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1344OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 8321499136 q12Shape25T1344=true := by decide

private def q12Shape25T1345 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4546625536 4026531840 q12Shape25T1345=true := by decide

private def q12Shape25T1343 : Tree 12 := .split 32 q12Shape25T1344 q12Shape25T1345
private theorem q12Shape25T1343OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 4026531840 q12Shape25T1343=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 (4026531840 ||| 2^32) q12Shape25T1344 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (251658240 ||| 2^32) 4026531840 q12Shape25T1345)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1344OK,q12Shape25T1345OK⟩

private def q12Shape25T1346 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1346OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2399141888 1879048192 q12Shape25T1346=true := by decide

private def q12Shape25T1342 : Tree 12 := .split 31 q12Shape25T1343 q12Shape25T1346
private theorem q12Shape25T1342OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 1879048192 q12Shape25T1342=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 (1879048192 ||| 2^31) q12Shape25T1343 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (251658240 ||| 2^31) 1879048192 q12Shape25T1346)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1343OK,q12Shape25T1346OK⟩

private def q12Shape25T1347 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1347OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1325400064 805306368 q12Shape25T1347=true := by decide

private def q12Shape25T1341 : Tree 12 := .split 30 q12Shape25T1342 q12Shape25T1347
private theorem q12Shape25T1341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 805306368 q12Shape25T1341=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 (805306368 ||| 2^30) q12Shape25T1342 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (251658240 ||| 2^30) 805306368 q12Shape25T1347)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1342OK,q12Shape25T1347OK⟩

private def q12Shape25T1351 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 788529152 7784628224 q12Shape25T1351=true := by decide

private def q12Shape25T1352 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5083496448 3489660928 q12Shape25T1352=true := by decide

private def q12Shape25T1350 : Tree 12 := .split 32 q12Shape25T1351 q12Shape25T1352
private theorem q12Shape25T1350OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 788529152 3489660928 q12Shape25T1350=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 788529152 (3489660928 ||| 2^32) q12Shape25T1351 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (788529152 ||| 2^32) 3489660928 q12Shape25T1352)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1351OK,q12Shape25T1352OK⟩

private def q12Shape25T1353 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2936012800 1342177280 q12Shape25T1353=true := by decide

private def q12Shape25T1349 : Tree 12 := .split 31 q12Shape25T1350 q12Shape25T1353
private theorem q12Shape25T1349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 788529152 1342177280 q12Shape25T1349=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 788529152 (1342177280 ||| 2^31) q12Shape25T1350 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (788529152 ||| 2^31) 1342177280 q12Shape25T1353)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1350OK,q12Shape25T1353OK⟩

private def q12Shape25T1354 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1862270976 268435456 q12Shape25T1354=true := by decide

private def q12Shape25T1348 : Tree 12 := .split 30 q12Shape25T1349 q12Shape25T1354
private theorem q12Shape25T1348OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 788529152 268435456 q12Shape25T1348=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 788529152 (268435456 ||| 2^30) q12Shape25T1349 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (788529152 ||| 2^30) 268435456 q12Shape25T1354)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1349OK,q12Shape25T1354OK⟩

private def q12Shape25T1340 : Tree 12 := .split 29 q12Shape25T1341 q12Shape25T1348
private theorem q12Shape25T1340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 268435456 q12Shape25T1340=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 (268435456 ||| 2^29) q12Shape25T1341 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (251658240 ||| 2^29) 268435456 q12Shape25T1348)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1341OK,q12Shape25T1348OK⟩

private def q12Shape25T1359 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 8053063680 q12Shape25T1359=true := by decide

private def q12Shape25T1360 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 4815060992 3758096384 q12Shape25T1360=true := by decide

private def q12Shape25T1358 : Tree 12 := .split 32 q12Shape25T1359 q12Shape25T1360
private theorem q12Shape25T1358OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 3758096384 q12Shape25T1358=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 (3758096384 ||| 2^32) q12Shape25T1359 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (520093696 ||| 2^32) 3758096384 q12Shape25T1360)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1359OK,q12Shape25T1360OK⟩

private def q12Shape25T1361 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1361OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2667577344 1610612736 q12Shape25T1361=true := by decide

private def q12Shape25T1357 : Tree 12 := .split 31 q12Shape25T1358 q12Shape25T1361
private theorem q12Shape25T1357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 1610612736 q12Shape25T1357=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 (1610612736 ||| 2^31) q12Shape25T1358 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (520093696 ||| 2^31) 1610612736 q12Shape25T1361)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1358OK,q12Shape25T1361OK⟩

private def q12Shape25T1362 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1362OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1593835520 536870912 q12Shape25T1362=true := by decide

private def q12Shape25T1356 : Tree 12 := .split 30 q12Shape25T1357 q12Shape25T1362
private theorem q12Shape25T1356OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 536870912 q12Shape25T1356=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 (536870912 ||| 2^30) q12Shape25T1357 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (520093696 ||| 2^30) 536870912 q12Shape25T1362)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1357OK,q12Shape25T1362OK⟩

private def q12Shape25T1366 : Tree 12 := (.split 33 (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape25T1366OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1056964608 7516192768 q12Shape25T1366=true := by decide

private def q12Shape25T1367 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1367OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5351931904 3221225472 q12Shape25T1367=true := by decide

private def q12Shape25T1365 : Tree 12 := .split 32 q12Shape25T1366 q12Shape25T1367
private theorem q12Shape25T1365OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1056964608 3221225472 q12Shape25T1365=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1056964608 (3221225472 ||| 2^32) q12Shape25T1366 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1056964608 ||| 2^32) 3221225472 q12Shape25T1367)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1366OK,q12Shape25T1367OK⟩

private def q12Shape25T1368 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1368OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3204448256 1073741824 q12Shape25T1368=true := by decide

private def q12Shape25T1364 : Tree 12 := .split 31 q12Shape25T1365 q12Shape25T1368
private theorem q12Shape25T1364OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1056964608 1073741824 q12Shape25T1364=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1056964608 (1073741824 ||| 2^31) q12Shape25T1365 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1056964608 ||| 2^31) 1073741824 q12Shape25T1368)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1365OK,q12Shape25T1368OK⟩

private def q12Shape25T1369 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape25T1369OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2130706432 0 q12Shape25T1369=true := by decide

private def q12Shape25T1363 : Tree 12 := .split 30 q12Shape25T1364 q12Shape25T1369
private theorem q12Shape25T1363OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1056964608 0 q12Shape25T1363=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1056964608 (0 ||| 2^30) q12Shape25T1364 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1056964608 ||| 2^30) 0 q12Shape25T1369)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1364OK,q12Shape25T1369OK⟩

private def q12Shape25T1355 : Tree 12 := .split 29 q12Shape25T1356 q12Shape25T1363
private theorem q12Shape25T1355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 0 q12Shape25T1355=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 520093696 (0 ||| 2^29) q12Shape25T1356 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (520093696 ||| 2^29) 0 q12Shape25T1363)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1356OK,q12Shape25T1363OK⟩

private def q12Shape25T1339 : Tree 12 := .split 28 q12Shape25T1340 q12Shape25T1355
private theorem q12Shape25T1339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 0 q12Shape25T1339=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 251658240 (0 ||| 2^28) q12Shape25T1340 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (251658240 ||| 2^28) 0 q12Shape25T1355)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1340OK,q12Shape25T1355OK⟩

private def q12Shape25T1307 : Tree 12 := .split 27 q12Shape25T1308 q12Shape25T1339
private theorem q12Shape25T1307OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 0 q12Shape25T1307=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 (0 ||| 2^27) q12Shape25T1308 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (117440512 ||| 2^27) 0 q12Shape25T1339)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T1308OK,q12Shape25T1339OK⟩

def q12Shape25P45 : Tree 12 := q12Shape25T1307
theorem q12Shape25P45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 117440512 0 q12Shape25P45=true := q12Shape25T1307OK

end Graffiti384b.EffectiveSearch.Q12
