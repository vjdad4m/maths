import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T199 : Tree 12 := (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11}))))
private theorem q12Shape25T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 4088792088576 q12Shape25T199=true := by decide

private def q12Shape25T201 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape25T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2508260900864 6287815344128 q12Shape25T201=true := by decide

private def q12Shape25T207 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,9,10})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {0,1,3,4,7,8,10})) (.tip (.cover {0,2,4,6,7,8,10}))) (.tip (.cover {0,4,6,7,8,9,10}))) (.tip (.cover {0,4,6,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10})))))
private theorem q12Shape25T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 28278047900684 q12Shape25T207=true := by decide

private def q12Shape25T208 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.split 6 (.tip (.cover {0,1,3,4,7,8,10})) (.tip (.cover {0,2,3,6,7,8,10}))) (.tip (.cover {0,3,6,7,8,9,10}))) (.tip (.cover {0,3,6,7,8,9,10})))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,10})))
private theorem q12Shape25T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307412992 28278047899660 q12Shape25T208=true := by decide

private def q12Shape25T206 : Tree 12 := .split 10 q12Shape25T207 q12Shape25T208
private theorem q12Shape25T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 28278047899660 q12Shape25T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 (28278047899660 ||| 2^10) q12Shape25T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411968 ||| 2^10) 28278047899660 q12Shape25T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T207OK,q12Shape25T208OK⟩

private def q12Shape25T212 : Tree 12 := (.tip (.small 0))
private theorem q12Shape25T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411976 28278048033796 q12Shape25T212=true := by decide

private def q12Shape25T213 : Tree 12 := (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {0,3,4,6,7,8,10})) (.tip (.cover {0,1,2,5,7,8,10}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,5,7,8,10})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,5,7,8,10}))) (.tip (.cover {0,1,2,5,9,10,11})))) (.tip (.cover {0,1,4,7,8,9,10})))
private theorem q12Shape25T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307543048 28278047902724 q12Shape25T213=true := by decide

private def q12Shape25T211 : Tree 12 := .split 17 q12Shape25T212 q12Shape25T213
private theorem q12Shape25T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411976 28278047902724 q12Shape25T211=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411976 (28278047902724 ||| 2^17) q12Shape25T212 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411976 ||| 2^17) 28278047902724 q12Shape25T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T212OK,q12Shape25T213OK⟩

private def q12Shape25T214 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape25T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307414024 28278047900676 q12Shape25T214=true := by decide

private def q12Shape25T210 : Tree 12 := .split 11 q12Shape25T211 q12Shape25T214
private theorem q12Shape25T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411976 28278047900676 q12Shape25T210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411976 (28278047900676 ||| 2^11) q12Shape25T211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411976 ||| 2^11) 28278047900676 q12Shape25T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T211OK,q12Shape25T214OK⟩

private def q12Shape25T217 : Tree 12 := (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {0,3,4,6,7,8,10})) (.tip (.cover {0,1,2,5,7,8,10}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,5,7,8,10})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,5,7,8,10}))) (.tip (.cover {0,1,2,5,9,10,11})))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape25T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307413000 28278048032772 q12Shape25T217=true := by decide

private def q12Shape25T218 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307544072 28278047901700 q12Shape25T218=true := by decide

private def q12Shape25T216 : Tree 12 := .split 17 q12Shape25T217 q12Shape25T218
private theorem q12Shape25T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307413000 28278047901700 q12Shape25T216=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307413000 (28278047901700 ||| 2^17) q12Shape25T217 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307413000 ||| 2^17) 28278047901700 q12Shape25T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T217OK,q12Shape25T218OK⟩

private def q12Shape25T219 : Tree 12 := (.tip (.cover {0,1,3,7,8,9,10}))
private theorem q12Shape25T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307415048 28278047899652 q12Shape25T219=true := by decide

private def q12Shape25T215 : Tree 12 := .split 11 q12Shape25T216 q12Shape25T219
private theorem q12Shape25T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307413000 28278047899652 q12Shape25T215=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307413000 (28278047899652 ||| 2^11) q12Shape25T216 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307413000 ||| 2^11) 28278047899652 q12Shape25T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T216OK,q12Shape25T219OK⟩

private def q12Shape25T209 : Tree 12 := .split 10 q12Shape25T210 q12Shape25T215
private theorem q12Shape25T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411976 28278047899652 q12Shape25T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411976 (28278047899652 ||| 2^10) q12Shape25T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411976 ||| 2^10) 28278047899652 q12Shape25T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T210OK,q12Shape25T215OK⟩

private def q12Shape25T205 : Tree 12 := .split 3 q12Shape25T206 q12Shape25T209
private theorem q12Shape25T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 28278047899652 q12Shape25T205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 (28278047899652 ||| 2^3) q12Shape25T206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411968 ||| 2^3) 28278047899652 q12Shape25T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T206OK,q12Shape25T209OK⟩

private def q12Shape25T224 : Tree 12 := (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,7,8,10})) (.tip (.cover {0,1,2,6,7,8,10}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,6,7,8,10})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,6,7,8,10}))) (.tip (.cover {0,1,2,6,9,10,11})))))
private theorem q12Shape25T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 28278048033800 q12Shape25T224=true := by decide

private def q12Shape25T225 : Tree 12 := (.tip (.cover {0,1,4,7,8,9,10}))
private theorem q12Shape25T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307543044 28278047902728 q12Shape25T225=true := by decide

private def q12Shape25T223 : Tree 12 := .split 17 q12Shape25T224 q12Shape25T225
private theorem q12Shape25T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 28278047902728 q12Shape25T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 (28278047902728 ||| 2^17) q12Shape25T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411972 ||| 2^17) 28278047902728 q12Shape25T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T224OK,q12Shape25T225OK⟩

private def q12Shape25T227 : Tree 12 := (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,7,8,10})) (.tip (.cover {0,1,2,6,7,8,10}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,6,7,8,10})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,10})) (.tip (.cover {0,1,2,6,7,8,10}))) (.tip (.cover {0,1,2,6,9,10,11})))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape25T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307414020 28278048031752 q12Shape25T227=true := by decide

private def q12Shape25T228 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307545092 28278047900680 q12Shape25T228=true := by decide

private def q12Shape25T226 : Tree 12 := .split 17 q12Shape25T227 q12Shape25T228
private theorem q12Shape25T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307414020 28278047900680 q12Shape25T226=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307414020 (28278047900680 ||| 2^17) q12Shape25T227 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307414020 ||| 2^17) 28278047900680 q12Shape25T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T227OK,q12Shape25T228OK⟩

private def q12Shape25T222 : Tree 12 := .split 11 q12Shape25T223 q12Shape25T226
private theorem q12Shape25T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 28278047900680 q12Shape25T222=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 (28278047900680 ||| 2^11) q12Shape25T223 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411972 ||| 2^11) 28278047900680 q12Shape25T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T223OK,q12Shape25T226OK⟩

private def q12Shape25T229 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307412996 28278047899656 q12Shape25T229=true := by decide

private def q12Shape25T221 : Tree 12 := .split 10 q12Shape25T222 q12Shape25T229
private theorem q12Shape25T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 28278047899656 q12Shape25T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 (28278047899656 ||| 2^10) q12Shape25T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411972 ||| 2^10) 28278047899656 q12Shape25T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T222OK,q12Shape25T229OK⟩

private def q12Shape25T230 : Tree 12 := (.tip (.cover {0,1,2,7,8,9,10}))
private theorem q12Shape25T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411980 28278047899648 q12Shape25T230=true := by decide

private def q12Shape25T220 : Tree 12 := .split 3 q12Shape25T221 q12Shape25T230
private theorem q12Shape25T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 28278047899648 q12Shape25T220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411972 (28278047899648 ||| 2^3) q12Shape25T221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411972 ||| 2^3) 28278047899648 q12Shape25T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T221OK,q12Shape25T230OK⟩

private def q12Shape25T204 : Tree 12 := .split 2 q12Shape25T205 q12Shape25T220
private theorem q12Shape25T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 28278047899648 q12Shape25T204=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 (28278047899648 ||| 2^2) q12Shape25T205 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411968 ||| 2^2) 28278047899648 q12Shape25T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T205OK,q12Shape25T220OK⟩

private def q12Shape25T231 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape25T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 24498493456384 10685861855232 q12Shape25T231=true := by decide

private def q12Shape25T203 : Tree 12 := .split 44 q12Shape25T204 q12Shape25T231
private theorem q12Shape25T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 10685861855232 q12Shape25T203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 (10685861855232 ||| 2^44) q12Shape25T204 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411968 ||| 2^44) 10685861855232 q12Shape25T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T204OK,q12Shape25T231OK⟩

private def q12Shape25T232 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape25T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 15702400434176 1889768833024 q12Shape25T232=true := by decide

private def q12Shape25T202 : Tree 12 := .split 43 q12Shape25T203 q12Shape25T232
private theorem q12Shape25T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 1889768833024 q12Shape25T202=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 6906307411968 (1889768833024 ||| 2^43) q12Shape25T203 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (6906307411968 ||| 2^43) 1889768833024 q12Shape25T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T203OK,q12Shape25T232OK⟩

private def q12Shape25T200 : Tree 12 := .split 42 q12Shape25T201 q12Shape25T202
private theorem q12Shape25T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2508260900864 1889768833024 q12Shape25T200=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2508260900864 (1889768833024 ||| 2^42) q12Shape25T201 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (2508260900864 ||| 2^42) 1889768833024 q12Shape25T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T201OK,q12Shape25T202OK⟩

private def q12Shape25T198 : Tree 12 := .split 41 q12Shape25T199 q12Shape25T200
private theorem q12Shape25T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 1889768833024 q12Shape25T198=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 (1889768833024 ||| 2^41) q12Shape25T199 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (309237645312 ||| 2^41) 1889768833024 q12Shape25T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T199OK,q12Shape25T200OK⟩

private def q12Shape25T233 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1408749273088 790257205248 q12Shape25T233=true := by decide

private def q12Shape25T197 : Tree 12 := .split 40 q12Shape25T198 q12Shape25T233
private theorem q12Shape25T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 790257205248 q12Shape25T197=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 (790257205248 ||| 2^40) q12Shape25T198 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (309237645312 ||| 2^40) 790257205248 q12Shape25T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T198OK,q12Shape25T233OK⟩

private def q12Shape25T234 : Tree 12 := (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.split 42 (.tip (.cover {2,3,4,5,6,8,11})) (.tip (.cover {0,1,5,6,7,8,9})))))
private theorem q12Shape25T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 858993459200 240501391360 q12Shape25T234=true := by decide

private def q12Shape25T196 : Tree 12 := .split 39 q12Shape25T197 q12Shape25T234
private theorem q12Shape25T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 240501391360 q12Shape25T196=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 (240501391360 ||| 2^39) q12Shape25T197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (309237645312 ||| 2^39) 240501391360 q12Shape25T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T197OK,q12Shape25T234OK⟩

def q12Shape25P5 : Tree 12 := q12Shape25T196
theorem q12Shape25P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 309237645312 240501391360 q12Shape25P5=true := q12Shape25T196OK

end Graffiti384b.EffectiveSearch.Q12
