import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T239 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape25T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 2027207786496 q12Shape25T239=true := by decide

private def q12Shape25T243 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape25T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1271310319616 16320858947584 q12Shape25T243=true := by decide

private def q12Shape25T248 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,9,11})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {0,1,3,4,7,8,11})) (.tip (.cover {0,2,4,6,7,8,11}))) (.tip (.cover {0,4,6,7,8,9,11}))) (.tip (.cover {0,4,6,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,11})))))
private theorem q12Shape25T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 25116951970828 q12Shape25T248=true := by decide

private def q12Shape25T249 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.split 6 (.tip (.cover {0,1,3,4,7,8,11})) (.tip (.cover {0,2,3,6,7,8,11}))) (.tip (.cover {0,3,6,7,8,9,11}))) (.tip (.cover {0,3,6,7,8,9,11})))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,11})))
private theorem q12Shape25T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403342848 25116951969804 q12Shape25T249=true := by decide

private def q12Shape25T247 : Tree 12 := .split 10 q12Shape25T248 q12Shape25T249
private theorem q12Shape25T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 25116951969804 q12Shape25T247=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 (25116951969804 ||| 2^10) q12Shape25T248 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341824 ||| 2^10) 25116951969804 q12Shape25T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T248OK,q12Shape25T249OK⟩

private def q12Shape25T253 : Tree 12 := (.tip (.small 0))
private theorem q12Shape25T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341832 25116952103940 q12Shape25T253=true := by decide

private def q12Shape25T254 : Tree 12 := (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {0,3,4,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.tip (.cover {0,1,2,5,9,10,11})))) (.tip (.cover {0,1,4,7,8,9,11})))
private theorem q12Shape25T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403472904 25116951972868 q12Shape25T254=true := by decide

private def q12Shape25T252 : Tree 12 := .split 17 q12Shape25T253 q12Shape25T254
private theorem q12Shape25T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341832 25116951972868 q12Shape25T252=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341832 (25116951972868 ||| 2^17) q12Shape25T253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341832 ||| 2^17) 25116951972868 q12Shape25T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T253OK,q12Shape25T254OK⟩

private def q12Shape25T255 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape25T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403343880 25116951970820 q12Shape25T255=true := by decide

private def q12Shape25T251 : Tree 12 := .split 11 q12Shape25T252 q12Shape25T255
private theorem q12Shape25T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341832 25116951970820 q12Shape25T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341832 (25116951970820 ||| 2^11) q12Shape25T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341832 ||| 2^11) 25116951970820 q12Shape25T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T252OK,q12Shape25T255OK⟩

private def q12Shape25T258 : Tree 12 := (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {0,3,4,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.tip (.cover {0,1,2,5,9,10,11})))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape25T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403342856 25116952102916 q12Shape25T258=true := by decide

private def q12Shape25T259 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403473928 25116951971844 q12Shape25T259=true := by decide

private def q12Shape25T257 : Tree 12 := .split 17 q12Shape25T258 q12Shape25T259
private theorem q12Shape25T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403342856 25116951971844 q12Shape25T257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403342856 (25116951971844 ||| 2^17) q12Shape25T258 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403342856 ||| 2^17) 25116951971844 q12Shape25T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T258OK,q12Shape25T259OK⟩

private def q12Shape25T260 : Tree 12 := (.tip (.cover {0,1,3,7,8,9,11}))
private theorem q12Shape25T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403344904 25116951969796 q12Shape25T260=true := by decide

private def q12Shape25T256 : Tree 12 := .split 11 q12Shape25T257 q12Shape25T260
private theorem q12Shape25T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403342856 25116951969796 q12Shape25T256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403342856 (25116951969796 ||| 2^11) q12Shape25T257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403342856 ||| 2^11) 25116951969796 q12Shape25T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T257OK,q12Shape25T260OK⟩

private def q12Shape25T250 : Tree 12 := .split 10 q12Shape25T251 q12Shape25T256
private theorem q12Shape25T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341832 25116951969796 q12Shape25T250=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341832 (25116951969796 ||| 2^10) q12Shape25T251 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341832 ||| 2^10) 25116951969796 q12Shape25T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T251OK,q12Shape25T256OK⟩

private def q12Shape25T246 : Tree 12 := .split 3 q12Shape25T247 q12Shape25T250
private theorem q12Shape25T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 25116951969796 q12Shape25T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 (25116951969796 ||| 2^3) q12Shape25T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341824 ||| 2^3) 25116951969796 q12Shape25T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T247OK,q12Shape25T250OK⟩

private def q12Shape25T265 : Tree 12 := (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.tip (.cover {0,1,2,6,9,10,11})))))
private theorem q12Shape25T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 25116952103944 q12Shape25T265=true := by decide

private def q12Shape25T266 : Tree 12 := (.tip (.cover {0,1,4,7,8,9,11}))
private theorem q12Shape25T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403472900 25116951972872 q12Shape25T266=true := by decide

private def q12Shape25T264 : Tree 12 := .split 17 q12Shape25T265 q12Shape25T266
private theorem q12Shape25T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 25116951972872 q12Shape25T264=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 (25116951972872 ||| 2^17) q12Shape25T265 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341828 ||| 2^17) 25116951972872 q12Shape25T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T265OK,q12Shape25T266OK⟩

private def q12Shape25T268 : Tree 12 := (.split 18 (.split 4 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11})))) (.split 5 (.split 6 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.tip (.cover {0,1,2,6,9,10,11})))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape25T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403343876 25116952101896 q12Shape25T268=true := by decide

private def q12Shape25T269 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403474948 25116951970824 q12Shape25T269=true := by decide

private def q12Shape25T267 : Tree 12 := .split 17 q12Shape25T268 q12Shape25T269
private theorem q12Shape25T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403343876 25116951970824 q12Shape25T267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403343876 (25116951970824 ||| 2^17) q12Shape25T268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403343876 ||| 2^17) 25116951970824 q12Shape25T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T268OK,q12Shape25T269OK⟩

private def q12Shape25T263 : Tree 12 := .split 11 q12Shape25T264 q12Shape25T267
private theorem q12Shape25T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 25116951970824 q12Shape25T263=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 (25116951970824 ||| 2^11) q12Shape25T264 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341828 ||| 2^11) 25116951970824 q12Shape25T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T264OK,q12Shape25T267OK⟩

private def q12Shape25T270 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape25T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403342852 25116951969800 q12Shape25T270=true := by decide

private def q12Shape25T262 : Tree 12 := .split 10 q12Shape25T263 q12Shape25T270
private theorem q12Shape25T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 25116951969800 q12Shape25T262=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 (25116951969800 ||| 2^10) q12Shape25T263 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341828 ||| 2^10) 25116951969800 q12Shape25T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T263OK,q12Shape25T270OK⟩

private def q12Shape25T271 : Tree 12 := (.tip (.cover {0,1,2,7,8,9,11}))
private theorem q12Shape25T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341836 25116951969792 q12Shape25T271=true := by decide

private def q12Shape25T261 : Tree 12 := .split 3 q12Shape25T262 q12Shape25T271
private theorem q12Shape25T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 25116951969792 q12Shape25T261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341828 (25116951969792 ||| 2^3) q12Shape25T262 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341828 ||| 2^3) 25116951969792 q12Shape25T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T262OK,q12Shape25T271OK⟩

private def q12Shape25T245 : Tree 12 := .split 2 q12Shape25T246 q12Shape25T261
private theorem q12Shape25T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 25116951969792 q12Shape25T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 (25116951969792 ||| 2^2) q12Shape25T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341824 ||| 2^2) 25116951969792 q12Shape25T261)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T246OK,q12Shape25T261OK⟩

private def q12Shape25T272 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,10}))
private theorem q12Shape25T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 27659589386240 7524765925376 q12Shape25T272=true := by decide

private def q12Shape25T244 : Tree 12 := .split 44 q12Shape25T245 q12Shape25T272
private theorem q12Shape25T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 7524765925376 q12Shape25T244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 10067403341824 (7524765925376 ||| 2^44) q12Shape25T245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (10067403341824 ||| 2^44) 7524765925376 q12Shape25T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T245OK,q12Shape25T272OK⟩

private def q12Shape25T242 : Tree 12 := .split 43 q12Shape25T243 q12Shape25T244
private theorem q12Shape25T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1271310319616 7524765925376 q12Shape25T242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1271310319616 (7524765925376 ||| 2^43) q12Shape25T243 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1271310319616 ||| 2^43) 7524765925376 q12Shape25T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T243OK,q12Shape25T244OK⟩

private def q12Shape25T273 : Tree 12 := (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5669356830720 3126719414272 q12Shape25T273=true := by decide

private def q12Shape25T241 : Tree 12 := .split 42 q12Shape25T242 q12Shape25T273
private theorem q12Shape25T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1271310319616 3126719414272 q12Shape25T241=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1271310319616 (3126719414272 ||| 2^42) q12Shape25T242 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1271310319616 ||| 2^42) 3126719414272 q12Shape25T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T242OK,q12Shape25T273OK⟩

private def q12Shape25T274 : Tree 12 := (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,9,11})))
private theorem q12Shape25T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 3470333575168 927696158720 q12Shape25T274=true := by decide

private def q12Shape25T240 : Tree 12 := .split 41 q12Shape25T241 q12Shape25T274
private theorem q12Shape25T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1271310319616 927696158720 q12Shape25T240=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1271310319616 (927696158720 ||| 2^41) q12Shape25T241 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (1271310319616 ||| 2^41) 927696158720 q12Shape25T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T241OK,q12Shape25T274OK⟩

private def q12Shape25T238 : Tree 12 := .split 40 q12Shape25T239 q12Shape25T240
private theorem q12Shape25T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 927696158720 q12Shape25T238=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 (927696158720 ||| 2^40) q12Shape25T239 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (171798691840 ||| 2^40) 927696158720 q12Shape25T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T239OK,q12Shape25T240OK⟩

private def q12Shape25T276 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape25T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721554505728 1477451972608 q12Shape25T276=true := by decide

private def q12Shape25T277 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,8,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape25T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1821066133504 377940344832 q12Shape25T277=true := by decide

private def q12Shape25T275 : Tree 12 := .split 40 q12Shape25T276 q12Shape25T277
private theorem q12Shape25T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721554505728 377940344832 q12Shape25T275=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 721554505728 (377940344832 ||| 2^40) q12Shape25T276 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (721554505728 ||| 2^40) 377940344832 q12Shape25T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T276OK,q12Shape25T277OK⟩

private def q12Shape25T237 : Tree 12 := .split 39 q12Shape25T238 q12Shape25T275
private theorem q12Shape25T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 377940344832 q12Shape25T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 (377940344832 ||| 2^39) q12Shape25T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (171798691840 ||| 2^39) 377940344832 q12Shape25T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T238OK,q12Shape25T275OK⟩

private def q12Shape25T280 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 446676598784 1752329879552 q12Shape25T280=true := by decide

private def q12Shape25T281 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,7,8,9})))
private theorem q12Shape25T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1546188226560 652818251776 q12Shape25T281=true := by decide

private def q12Shape25T279 : Tree 12 := .split 40 q12Shape25T280 q12Shape25T281
private theorem q12Shape25T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 446676598784 652818251776 q12Shape25T279=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 446676598784 (652818251776 ||| 2^40) q12Shape25T280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (446676598784 ||| 2^40) 652818251776 q12Shape25T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T280OK,q12Shape25T281OK⟩

private def q12Shape25T282 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape25T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 996432412672 103062437888 q12Shape25T282=true := by decide

private def q12Shape25T278 : Tree 12 := .split 39 q12Shape25T279 q12Shape25T282
private theorem q12Shape25T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 446676598784 103062437888 q12Shape25T278=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 446676598784 (103062437888 ||| 2^39) q12Shape25T279 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (446676598784 ||| 2^39) 103062437888 q12Shape25T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T279OK,q12Shape25T282OK⟩

private def q12Shape25T236 : Tree 12 := .split 38 q12Shape25T237 q12Shape25T278
private theorem q12Shape25T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 103062437888 q12Shape25T236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 (103062437888 ||| 2^38) q12Shape25T237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (171798691840 ||| 2^38) 103062437888 q12Shape25T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T237OK,q12Shape25T278OK⟩

def q12Shape25P6 : Tree 12 := q12Shape25T236
theorem q12Shape25P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 171798691840 103062437888 q12Shape25P6=true := q12Shape25T236OK

end Graffiti384b.EffectiveSearch.Q12
