import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T292 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,8}))
private theorem q12Shape25T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 34531520282624 q12Shape25T292=true := by decide

private def q12Shape25T296 : Tree 12 := (.split 11 (.tip (.cover {0,1,4,7,8,10,11})) (.split 17 (.tip (.small 0)) (.split 18 (.split 4 (.split 5 (.split 6 (.split 7 (.tip (.cover {0,1,3,4,7,8,11})) (.tip (.cover {0,2,4,6,7,8,11}))) (.tip (.cover {0,4,6,7,9,10,11}))) (.tip (.cover {0,4,6,7,8,10,11}))) (.tip (.cover {0,4,6,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11})))))
private theorem q12Shape25T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073408 16939334239244 q12Shape25T296=true := by decide

private def q12Shape25T297 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 1)) (.split 4 (.split 5 (.split 6 (.split 7 (.tip (.cover {0,1,3,4,7,8,11})) (.tip (.cover {0,2,3,6,7,8,11}))) (.tip (.cover {0,3,6,7,9,10,11}))) (.tip (.cover {0,3,6,7,8,10,11}))) (.tip (.cover {0,3,6,7,8,10,11})))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape25T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074432 16939334238220 q12Shape25T297=true := by decide

private def q12Shape25T295 : Tree 12 := .split 10 q12Shape25T296 q12Shape25T297
private theorem q12Shape25T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073408 16939334238220 q12Shape25T295=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073408 (16939334238220 ||| 2^10) q12Shape25T296 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073408 ||| 2^10) 16939334238220 q12Shape25T297)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T296OK,q12Shape25T297OK⟩

private def q12Shape25T301 : Tree 12 := (.tip (.small 0))
private theorem q12Shape25T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073416 16939334372356 q12Shape25T301=true := by decide

private def q12Shape25T304 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {0,3,4,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.split 7 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,5,7,8,11})))) (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.tip (.cover {0,1,2,5,7,10,11}))))
private theorem q12Shape25T304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021204488 16939334503444 q12Shape25T304=true := by decide

private def q12Shape25T305 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {0,1,2,5,9,10,11})))
private theorem q12Shape25T305OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021204504 16939334503428 q12Shape25T305=true := by decide

private def q12Shape25T303 : Tree 12 := .split 4 q12Shape25T304 q12Shape25T305
private theorem q12Shape25T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021204488 16939334503428 q12Shape25T303=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021204488 (16939334503428 ||| 2^4) q12Shape25T304 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021204488 ||| 2^4) 16939334503428 q12Shape25T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T304OK,q12Shape25T305OK⟩

private def q12Shape25T306 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape25T306OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021466632 16939334241284 q12Shape25T306=true := by decide

private def q12Shape25T302 : Tree 12 := .split 18 q12Shape25T303 q12Shape25T306
private theorem q12Shape25T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021204488 16939334241284 q12Shape25T302=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021204488 (16939334241284 ||| 2^18) q12Shape25T303 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021204488 ||| 2^18) 16939334241284 q12Shape25T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T303OK,q12Shape25T306OK⟩

private def q12Shape25T300 : Tree 12 := .split 17 q12Shape25T301 q12Shape25T302
private theorem q12Shape25T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073416 16939334241284 q12Shape25T300=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073416 (16939334241284 ||| 2^17) q12Shape25T301 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073416 ||| 2^17) 16939334241284 q12Shape25T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T301OK,q12Shape25T302OK⟩

private def q12Shape25T307 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,10}))
private theorem q12Shape25T307OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075464 16939334239236 q12Shape25T307=true := by decide

private def q12Shape25T299 : Tree 12 := .split 11 q12Shape25T300 q12Shape25T307
private theorem q12Shape25T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073416 16939334239236 q12Shape25T299=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073416 (16939334239236 ||| 2^11) q12Shape25T300 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073416 ||| 2^11) 16939334239236 q12Shape25T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T300OK,q12Shape25T307OK⟩

private def q12Shape25T312 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {0,3,4,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.split 7 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,5,7,8,11})))) (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.tip (.cover {0,1,2,5,7,10,11}))))
private theorem q12Shape25T312OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 16939334633492 q12Shape25T312=true := by decide

private def q12Shape25T313 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,5,7,8,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {0,1,2,5,9,10,11})))
private theorem q12Shape25T313OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074456 16939334633476 q12Shape25T313=true := by decide

private def q12Shape25T311 : Tree 12 := .split 4 q12Shape25T312 q12Shape25T313
private theorem q12Shape25T311OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 16939334633476 q12Shape25T311=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 (16939334633476 ||| 2^4) q12Shape25T312 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021074440 ||| 2^4) 16939334633476 q12Shape25T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T312OK,q12Shape25T313OK⟩

private def q12Shape25T314 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,10}))
private theorem q12Shape25T314OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021336584 16939334371332 q12Shape25T314=true := by decide

private def q12Shape25T310 : Tree 12 := .split 18 q12Shape25T311 q12Shape25T314
private theorem q12Shape25T310OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 16939334371332 q12Shape25T310=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 (16939334371332 ||| 2^18) q12Shape25T311 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021074440 ||| 2^18) 16939334371332 q12Shape25T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T311OK,q12Shape25T314OK⟩

private def q12Shape25T315 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape25T315OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021205512 16939334240260 q12Shape25T315=true := by decide

private def q12Shape25T309 : Tree 12 := .split 17 q12Shape25T310 q12Shape25T315
private theorem q12Shape25T309OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 16939334240260 q12Shape25T309=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 (16939334240260 ||| 2^17) q12Shape25T310 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021074440 ||| 2^17) 16939334240260 q12Shape25T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T310OK,q12Shape25T315OK⟩

private def q12Shape25T316 : Tree 12 := (.tip (.cover {0,1,3,7,8,10,11}))
private theorem q12Shape25T316OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021076488 16939334238212 q12Shape25T316=true := by decide

private def q12Shape25T308 : Tree 12 := .split 11 q12Shape25T309 q12Shape25T316
private theorem q12Shape25T308OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 16939334238212 q12Shape25T308=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074440 (16939334238212 ||| 2^11) q12Shape25T309 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021074440 ||| 2^11) 16939334238212 q12Shape25T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T309OK,q12Shape25T316OK⟩

private def q12Shape25T298 : Tree 12 := .split 10 q12Shape25T299 q12Shape25T308
private theorem q12Shape25T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073416 16939334238212 q12Shape25T298=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073416 (16939334238212 ||| 2^10) q12Shape25T299 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073416 ||| 2^10) 16939334238212 q12Shape25T308)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T299OK,q12Shape25T308OK⟩

private def q12Shape25T294 : Tree 12 := .split 3 q12Shape25T295 q12Shape25T298
private theorem q12Shape25T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073408 16939334238212 q12Shape25T294=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073408 (16939334238212 ||| 2^3) q12Shape25T295 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073408 ||| 2^3) 16939334238212 q12Shape25T298)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T295OK,q12Shape25T298OK⟩

private def q12Shape25T322 : Tree 12 := (.tip (.small 1))
private theorem q12Shape25T322OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 16939334634504 q12Shape25T322=true := by decide

private def q12Shape25T324 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {1,3,4,5,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.split 7 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,6,7,8,11})))) (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.tip (.cover {0,1,2,6,7,10,11}))))
private theorem q12Shape25T324OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021335556 16939334372376 q12Shape25T324=true := by decide

private def q12Shape25T325 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape25T325OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021335572 16939334372360 q12Shape25T325=true := by decide

private def q12Shape25T323 : Tree 12 := .split 4 q12Shape25T324 q12Shape25T325
private theorem q12Shape25T323OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021335556 16939334372360 q12Shape25T323=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021335556 (16939334372360 ||| 2^4) q12Shape25T324 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021335556 ||| 2^4) 16939334372360 q12Shape25T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T324OK,q12Shape25T325OK⟩

private def q12Shape25T321 : Tree 12 := .split 18 q12Shape25T322 q12Shape25T323
private theorem q12Shape25T321OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 16939334372360 q12Shape25T321=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 (16939334372360 ||| 2^18) q12Shape25T322 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073412 ||| 2^18) 16939334372360 q12Shape25T323)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T322OK,q12Shape25T323OK⟩

private def q12Shape25T326 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape25T326OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021204484 16939334241288 q12Shape25T326=true := by decide

private def q12Shape25T320 : Tree 12 := .split 17 q12Shape25T321 q12Shape25T326
private theorem q12Shape25T320OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 16939334241288 q12Shape25T320=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 (16939334241288 ||| 2^17) q12Shape25T321 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073412 ||| 2^17) 16939334241288 q12Shape25T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T321OK,q12Shape25T326OK⟩

private def q12Shape25T330 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {1,3,4,5,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.split 7 (.tip (.cover {3,4,5,6,7,9,11})) (.tip (.cover {0,1,2,6,7,8,11})))) (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.tip (.cover {0,1,2,6,7,10,11}))))
private theorem q12Shape25T330OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075460 16939334632472 q12Shape25T330=true := by decide

private def q12Shape25T331 : Tree 12 := (.split 5 (.split 6 (.split 7 (.tip (.cover {3,4,5,6,7,8,11})) (.tip (.cover {0,1,2,6,7,8,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape25T331OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075476 16939334632456 q12Shape25T331=true := by decide

private def q12Shape25T329 : Tree 12 := .split 4 q12Shape25T330 q12Shape25T331
private theorem q12Shape25T329OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075460 16939334632456 q12Shape25T329=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075460 (16939334632456 ||| 2^4) q12Shape25T330 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021075460 ||| 2^4) 16939334632456 q12Shape25T331)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T330OK,q12Shape25T331OK⟩

private def q12Shape25T332 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,10}))
private theorem q12Shape25T332OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021337604 16939334370312 q12Shape25T332=true := by decide

private def q12Shape25T328 : Tree 12 := .split 18 q12Shape25T329 q12Shape25T332
private theorem q12Shape25T328OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075460 16939334370312 q12Shape25T328=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075460 (16939334370312 ||| 2^18) q12Shape25T329 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021075460 ||| 2^18) 16939334370312 q12Shape25T332)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T329OK,q12Shape25T332OK⟩

private def q12Shape25T333 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape25T333OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021206532 16939334239240 q12Shape25T333=true := by decide

private def q12Shape25T327 : Tree 12 := .split 17 q12Shape25T328 q12Shape25T333
private theorem q12Shape25T327OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075460 16939334239240 q12Shape25T327=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021075460 (16939334239240 ||| 2^17) q12Shape25T328 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021075460 ||| 2^17) 16939334239240 q12Shape25T333)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T328OK,q12Shape25T333OK⟩

private def q12Shape25T319 : Tree 12 := .split 11 q12Shape25T320 q12Shape25T327
private theorem q12Shape25T319OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 16939334239240 q12Shape25T319=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 (16939334239240 ||| 2^11) q12Shape25T320 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073412 ||| 2^11) 16939334239240 q12Shape25T327)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T320OK,q12Shape25T327OK⟩

private def q12Shape25T334 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape25T334OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021074436 16939334238216 q12Shape25T334=true := by decide

private def q12Shape25T318 : Tree 12 := .split 10 q12Shape25T319 q12Shape25T334
private theorem q12Shape25T318OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 16939334238216 q12Shape25T318=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 (16939334238216 ||| 2^10) q12Shape25T319 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073412 ||| 2^10) 16939334238216 q12Shape25T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T319OK,q12Shape25T334OK⟩

private def q12Shape25T335 : Tree 12 := (.tip (.cover {0,1,2,7,8,10,11}))
private theorem q12Shape25T335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073420 16939334238208 q12Shape25T335=true := by decide

private def q12Shape25T317 : Tree 12 := .split 3 q12Shape25T318 q12Shape25T335
private theorem q12Shape25T317OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 16939334238208 q12Shape25T317=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073412 (16939334238208 ||| 2^3) q12Shape25T318 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073412 ||| 2^3) 16939334238208 q12Shape25T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T318OK,q12Shape25T335OK⟩

private def q12Shape25T293 : Tree 12 := .split 2 q12Shape25T294 q12Shape25T317
private theorem q12Shape25T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073408 16939334238208 q12Shape25T293=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 18245021073408 (16939334238208 ||| 2^2) q12Shape25T294 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (18245021073408 ||| 2^2) 16939334238208 q12Shape25T317)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T294OK,q12Shape25T317OK⟩

private def q12Shape25T291 : Tree 12 := .split 44 q12Shape25T292 q12Shape25T293
private theorem q12Shape25T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 16939334238208 q12Shape25T291=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 (16939334238208 ||| 2^44) q12Shape25T292 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (652835028992 ||| 2^44) 16939334238208 q12Shape25T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T292OK,q12Shape25T293OK⟩

private def q12Shape25T336 : Tree 12 := (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,9,10})))
private theorem q12Shape25T336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 9448928051200 8143241216000 q12Shape25T336=true := by decide

private def q12Shape25T290 : Tree 12 := .split 43 q12Shape25T291 q12Shape25T336
private theorem q12Shape25T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 8143241216000 q12Shape25T290=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 (8143241216000 ||| 2^43) q12Shape25T291 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (652835028992 ||| 2^43) 8143241216000 q12Shape25T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T291OK,q12Shape25T336OK⟩

private def q12Shape25T337 : Tree 12 := (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,9,11}))) (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,9,10}))))
private theorem q12Shape25T337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 5050881540096 3745194704896 q12Shape25T337=true := by decide

private def q12Shape25T289 : Tree 12 := .split 42 q12Shape25T290 q12Shape25T337
private theorem q12Shape25T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 3745194704896 q12Shape25T289=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 (3745194704896 ||| 2^42) q12Shape25T290 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (652835028992 ||| 2^42) 3745194704896 q12Shape25T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T290OK,q12Shape25T337OK⟩

private def q12Shape25T338 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape25T338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 2851858284544 1546171449344 q12Shape25T338=true := by decide

private def q12Shape25T288 : Tree 12 := .split 41 q12Shape25T289 q12Shape25T338
private theorem q12Shape25T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 1546171449344 q12Shape25T288=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 (1546171449344 ||| 2^41) q12Shape25T289 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (652835028992 ||| 2^41) 1546171449344 q12Shape25T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T289OK,q12Shape25T338OK⟩

private def q12Shape25T339 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape25T339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1752346656768 446659821568 q12Shape25T339=true := by decide

private def q12Shape25T287 : Tree 12 := .split 40 q12Shape25T288 q12Shape25T339
private theorem q12Shape25T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 446659821568 q12Shape25T287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 (446659821568 ||| 2^40) q12Shape25T288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (652835028992 ||| 2^40) 446659821568 q12Shape25T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T288OK,q12Shape25T339OK⟩

def q12Shape25P8 : Tree 12 := q12Shape25T287
theorem q12Shape25P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 652835028992 446659821568 q12Shape25P8=true := q12Shape25T287OK

end Graffiti384b.EffectiveSearch.Q12
