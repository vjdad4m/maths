import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape25T343 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,8,10}))))
private theorem q12Shape25T343OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 377957122048 1821049356288 q12Shape25T343=true := by decide

private def q12Shape25T344 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape25T344OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1477468749824 721537728512 q12Shape25T344=true := by decide

private def q12Shape25T342 : Tree 12 := .split 40 q12Shape25T343 q12Shape25T344
private theorem q12Shape25T342OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 377957122048 721537728512 q12Shape25T342=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 377957122048 (721537728512 ||| 2^40) q12Shape25T343 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (377957122048 ||| 2^40) 721537728512 q12Shape25T344)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T343OK,q12Shape25T344OK⟩

private def q12Shape25T345 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape25T345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 927712935936 171781914624 q12Shape25T345=true := by decide

private def q12Shape25T341 : Tree 12 := .split 39 q12Shape25T342 q12Shape25T345
private theorem q12Shape25T341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 377957122048 171781914624 q12Shape25T341=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 377957122048 (171781914624 ||| 2^39) q12Shape25T342 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (377957122048 ||| 2^39) 171781914624 q12Shape25T345)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T342OK,q12Shape25T345OK⟩

def q12Shape25P9 : Tree 12 := q12Shape25T341
theorem q12Shape25P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 377957122048 171781914624 q12Shape25P9=true := q12Shape25T341OK

private def q12Shape25T350 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape25T350OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 1958488309760 q12Shape25T350=true := by decide

private def q12Shape25T351 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape25T351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1340029796352 858976681984 q12Shape25T351=true := by decide

private def q12Shape25T349 : Tree 12 := .split 40 q12Shape25T350 q12Shape25T351
private theorem q12Shape25T349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 858976681984 q12Shape25T349=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 (858976681984 ||| 2^40) q12Shape25T350 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (240518168576 ||| 2^40) 858976681984 q12Shape25T351)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T350OK,q12Shape25T351OK⟩

private def q12Shape25T352 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 790273982464 309220868096 q12Shape25T352=true := by decide

private def q12Shape25T348 : Tree 12 := .split 39 q12Shape25T349 q12Shape25T352
private theorem q12Shape25T348OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 309220868096 q12Shape25T348=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 (309220868096 ||| 2^39) q12Shape25T349 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (240518168576 ||| 2^39) 309220868096 q12Shape25T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T349OK,q12Shape25T352OK⟩

private def q12Shape25T355 : Tree 12 := (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape25T355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 515396075520 1683610402816 q12Shape25T355=true := by decide

private def q12Shape25T356 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,8,9})))
private theorem q12Shape25T356OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1614907703296 584098775040 q12Shape25T356=true := by decide

private def q12Shape25T354 : Tree 12 := .split 40 q12Shape25T355 q12Shape25T356
private theorem q12Shape25T354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 515396075520 584098775040 q12Shape25T354=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 515396075520 (584098775040 ||| 2^40) q12Shape25T355 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (515396075520 ||| 2^40) 584098775040 q12Shape25T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T355OK,q12Shape25T356OK⟩

private def q12Shape25T357 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {2,3,4,5,6,7,8})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape25T357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 1065151889408 34342961152 q12Shape25T357=true := by decide

private def q12Shape25T353 : Tree 12 := .split 39 q12Shape25T354 q12Shape25T357
private theorem q12Shape25T353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 515396075520 34342961152 q12Shape25T353=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 515396075520 (34342961152 ||| 2^39) q12Shape25T354 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (515396075520 ||| 2^39) 34342961152 q12Shape25T357)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T354OK,q12Shape25T357OK⟩

private def q12Shape25T347 : Tree 12 := .split 38 q12Shape25T348 q12Shape25T353
private theorem q12Shape25T347OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 34342961152 q12Shape25T347=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 (34342961152 ||| 2^38) q12Shape25T348 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (240518168576 ||| 2^38) 34342961152 q12Shape25T353)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T348OK,q12Shape25T353OK⟩

def q12Shape25P10 : Tree 12 := q12Shape25T347
theorem q12Shape25P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 240518168576 34342961152 q12Shape25P10=true := q12Shape25T347OK

private def q12Shape25T364 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,5,6,7,9,10})))))
private theorem q12Shape25T364OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 257681260544 q12Shape25T364=true := by decide

private def q12Shape25T365 : Tree 12 := (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T365OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 154618822656 120242307072 q12Shape25T365=true := by decide

private def q12Shape25T363 : Tree 12 := .split 37 q12Shape25T364 q12Shape25T365
private theorem q12Shape25T363OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 120242307072 q12Shape25T363=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 (120242307072 ||| 2^37) q12Shape25T364 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (17179869184 ||| 2^37) 120242307072 q12Shape25T365)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T364OK,q12Shape25T365OK⟩

private def q12Shape25T366 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.split 41 (.tip (.cover {2,3,4,5,6,9,10})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T366OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 85899345920 51522830336 q12Shape25T366=true := by decide

private def q12Shape25T362 : Tree 12 := .split 36 q12Shape25T363 q12Shape25T366
private theorem q12Shape25T362OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 51522830336 q12Shape25T362=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 (51522830336 ||| 2^36) q12Shape25T363 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (17179869184 ||| 2^36) 51522830336 q12Shape25T366)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T363OK,q12Shape25T366OK⟩

private def q12Shape25T368 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape25T368OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 51539607552 85882568704 q12Shape25T368=true := by decide

private def q12Shape25T369 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape25T369OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 120259084288 17163091968 q12Shape25T369=true := by decide

private def q12Shape25T367 : Tree 12 := .split 36 q12Shape25T368 q12Shape25T369
private theorem q12Shape25T367OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 51539607552 17163091968 q12Shape25T367=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 51539607552 (17163091968 ||| 2^36) q12Shape25T368 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (51539607552 ||| 2^36) 17163091968 q12Shape25T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T368OK,q12Shape25T369OK⟩

private def q12Shape25T361 : Tree 12 := .split 35 q12Shape25T362 q12Shape25T367
private theorem q12Shape25T361OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 17163091968 q12Shape25T361=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 (17163091968 ||| 2^35) q12Shape25T362 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) (17179869184 ||| 2^35) 17163091968 q12Shape25T367)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape25T362OK,q12Shape25T367OK⟩

def q12Shape25P11 : Tree 12 := q12Shape25T361
theorem q12Shape25P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,3⟩) 17179869184 17163091968 q12Shape25P11=true := q12Shape25T361OK

end Graffiti384b.EffectiveSearch.Q12
