import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape26T4 : Tree 12 := (.split 34 (.split 35 (.tip (.cover {2,3,4,5,9,10,11})) (.split 36 (.tip (.cover {2,3,4,5,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.split 35 (.tip (.cover {2,3,4,5,9,10,11})) (.split 36 (.tip (.cover {2,3,4,5,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))))
private theorem q12Shape26T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 16106127360 q12Shape26T4=true := by decide

private def q12Shape26T5 : Tree 12 := (.split 34 (.split 35 (.tip (.cover {2,3,4,5,9,10,11})) (.split 36 (.tip (.cover {2,3,4,5,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape26T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 8589934592 7516192768 q12Shape26T5=true := by decide

private def q12Shape26T3 : Tree 12 := .split 33 q12Shape26T4 q12Shape26T5
private theorem q12Shape26T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 7516192768 q12Shape26T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 (7516192768 ||| 2^33) q12Shape26T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) (0 ||| 2^33) 7516192768 q12Shape26T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape26T4OK,q12Shape26T5OK⟩

private def q12Shape26T6 : Tree 12 := (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,5,9,10,11})) (.split 36 (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape26T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 4294967296 3221225472 q12Shape26T6=true := by decide

private def q12Shape26T2 : Tree 12 := .split 32 q12Shape26T3 q12Shape26T6
private theorem q12Shape26T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 3221225472 q12Shape26T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 (3221225472 ||| 2^32) q12Shape26T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) (0 ||| 2^32) 3221225472 q12Shape26T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape26T3OK,q12Shape26T6OK⟩

private def q12Shape26T7 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 35 (.split 36 (.tip (.cover {2,3,4,5,8,10,11})) (.split 37 (.tip (.cover {2,3,4,5,8,9,11})) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape26T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 2147483648 1073741824 q12Shape26T7=true := by decide

private def q12Shape26T1 : Tree 12 := .split 31 q12Shape26T2 q12Shape26T7
private theorem q12Shape26T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 1073741824 q12Shape26T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 (1073741824 ||| 2^31) q12Shape26T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) (0 ||| 2^31) 1073741824 q12Shape26T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape26T2OK,q12Shape26T7OK⟩

private def q12Shape26T11 : Tree 12 := (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {2,3,4,5,6,10,11})) (.split 40 (.tip (.cover {2,3,4,5,6,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape26T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 1073741824 15032385536 q12Shape26T11=true := by decide

private def q12Shape26T12 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape26T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 9663676416 6442450944 q12Shape26T12=true := by decide

private def q12Shape26T10 : Tree 12 := .split 33 q12Shape26T11 q12Shape26T12
private theorem q12Shape26T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 1073741824 6442450944 q12Shape26T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 1073741824 (6442450944 ||| 2^33) q12Shape26T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) (1073741824 ||| 2^33) 6442450944 q12Shape26T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape26T11OK,q12Shape26T12OK⟩

private def q12Shape26T13 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape26T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 5368709120 2147483648 q12Shape26T13=true := by decide

private def q12Shape26T9 : Tree 12 := .split 32 q12Shape26T10 q12Shape26T13
private theorem q12Shape26T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 1073741824 2147483648 q12Shape26T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 1073741824 (2147483648 ||| 2^32) q12Shape26T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) (1073741824 ||| 2^32) 2147483648 q12Shape26T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape26T10OK,q12Shape26T13OK⟩

private def q12Shape26T14 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape26T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 3221225472 0 q12Shape26T14=true := by decide

private def q12Shape26T8 : Tree 12 := .split 31 q12Shape26T9 q12Shape26T14
private theorem q12Shape26T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 1073741824 0 q12Shape26T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 1073741824 (0 ||| 2^31) q12Shape26T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) (1073741824 ||| 2^31) 0 q12Shape26T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape26T9OK,q12Shape26T14OK⟩

private def q12Shape26T0 : Tree 12 := .split 30 q12Shape26T1 q12Shape26T8
private theorem q12Shape26T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 0 q12Shape26T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 (0 ||| 2^30) q12Shape26T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) (0 ||| 2^30) 0 q12Shape26T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape26T1OK,q12Shape26T8OK⟩

def q12Shape26P0 : Tree 12 := q12Shape26T0
theorem q12Shape26P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,5,5,4⟩) 0 0 q12Shape26P0=true := q12Shape26T0OK

end Graffiti384b.EffectiveSearch.Q12
