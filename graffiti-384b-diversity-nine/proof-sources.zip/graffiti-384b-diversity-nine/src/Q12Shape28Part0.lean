import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape28T3 : Tree 12 := (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10,11}))))))
private theorem q12Shape28T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 134656 q12Shape28T3=true := by decide

private def q12Shape28T5 : Tree 12 := (.split 24 (.tip (.small 0)) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))))
private theorem q12Shape28T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 131072 265728 q12Shape28T5=true := by decide

private def q12Shape28T6 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))))
private theorem q12Shape28T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 393216 3584 q12Shape28T6=true := by decide

private def q12Shape28T4 : Tree 12 := .split 18 q12Shape28T5 q12Shape28T6
private theorem q12Shape28T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 131072 3584 q12Shape28T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 131072 (3584 ||| 2^18) q12Shape28T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (131072 ||| 2^18) 3584 q12Shape28T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T5OK,q12Shape28T6OK⟩

private def q12Shape28T2 : Tree 12 := .split 17 q12Shape28T3 q12Shape28T4
private theorem q12Shape28T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 3584 q12Shape28T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 (3584 ||| 2^17) q12Shape28T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (0 ||| 2^17) 3584 q12Shape28T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T3OK,q12Shape28T4OK⟩

private def q12Shape28T9 : Tree 12 := (.split 24 (.tip (.small 0)) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,10,11})))))
private theorem q12Shape28T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2048 394752 q12Shape28T9=true := by decide

private def q12Shape28T10 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10,11}))))
private theorem q12Shape28T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 264192 132608 q12Shape28T10=true := by decide

private def q12Shape28T8 : Tree 12 := .split 18 q12Shape28T9 q12Shape28T10
private theorem q12Shape28T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2048 132608 q12Shape28T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2048 (132608 ||| 2^18) q12Shape28T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (2048 ||| 2^18) 132608 q12Shape28T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T9OK,q12Shape28T10OK⟩

private def q12Shape28T12 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))))
private theorem q12Shape28T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 133120 263680 q12Shape28T12=true := by decide

private def q12Shape28T13 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10,11}))))
private theorem q12Shape28T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 395264 1536 q12Shape28T13=true := by decide

private def q12Shape28T11 : Tree 12 := .split 18 q12Shape28T12 q12Shape28T13
private theorem q12Shape28T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 133120 1536 q12Shape28T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 133120 (1536 ||| 2^18) q12Shape28T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (133120 ||| 2^18) 1536 q12Shape28T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T12OK,q12Shape28T13OK⟩

private def q12Shape28T7 : Tree 12 := .split 17 q12Shape28T8 q12Shape28T11
private theorem q12Shape28T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2048 1536 q12Shape28T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2048 (1536 ||| 2^17) q12Shape28T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (2048 ||| 2^17) 1536 q12Shape28T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T8OK,q12Shape28T11OK⟩

private def q12Shape28T1 : Tree 12 := .split 11 q12Shape28T2 q12Shape28T7
private theorem q12Shape28T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 1536 q12Shape28T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 (1536 ||| 2^11) q12Shape28T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (0 ||| 2^11) 1536 q12Shape28T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T2OK,q12Shape28T7OK⟩

private def q12Shape28T17 : Tree 12 := (.split 24 (.tip (.small 0)) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10,11})))))
private theorem q12Shape28T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1024 395776 q12Shape28T17=true := by decide

private def q12Shape28T18 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))))
private theorem q12Shape28T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 263168 133632 q12Shape28T18=true := by decide

private def q12Shape28T16 : Tree 12 := .split 18 q12Shape28T17 q12Shape28T18
private theorem q12Shape28T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1024 133632 q12Shape28T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1024 (133632 ||| 2^18) q12Shape28T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (1024 ||| 2^18) 133632 q12Shape28T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T17OK,q12Shape28T18OK⟩

private def q12Shape28T20 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape28T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 132096 264704 q12Shape28T20=true := by decide

private def q12Shape28T21 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape28T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 394240 2560 q12Shape28T21=true := by decide

private def q12Shape28T19 : Tree 12 := .split 18 q12Shape28T20 q12Shape28T21
private theorem q12Shape28T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 132096 2560 q12Shape28T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 132096 (2560 ||| 2^18) q12Shape28T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (132096 ||| 2^18) 2560 q12Shape28T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T20OK,q12Shape28T21OK⟩

private def q12Shape28T15 : Tree 12 := .split 17 q12Shape28T16 q12Shape28T19
private theorem q12Shape28T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1024 2560 q12Shape28T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1024 (2560 ||| 2^17) q12Shape28T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (1024 ||| 2^17) 2560 q12Shape28T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T16OK,q12Shape28T19OK⟩

private def q12Shape28T24 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))))
private theorem q12Shape28T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3072 393728 q12Shape28T24=true := by decide

private def q12Shape28T25 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10,11}))))
private theorem q12Shape28T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 265216 131584 q12Shape28T25=true := by decide

private def q12Shape28T23 : Tree 12 := .split 18 q12Shape28T24 q12Shape28T25
private theorem q12Shape28T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3072 131584 q12Shape28T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3072 (131584 ||| 2^18) q12Shape28T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (3072 ||| 2^18) 131584 q12Shape28T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T24OK,q12Shape28T25OK⟩

private def q12Shape28T27 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape28T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 134144 262656 q12Shape28T27=true := by decide

private def q12Shape28T28 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {2,3,4,8,9,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape28T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 396288 512 q12Shape28T28=true := by decide

private def q12Shape28T26 : Tree 12 := .split 18 q12Shape28T27 q12Shape28T28
private theorem q12Shape28T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 134144 512 q12Shape28T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 134144 (512 ||| 2^18) q12Shape28T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (134144 ||| 2^18) 512 q12Shape28T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T27OK,q12Shape28T28OK⟩

private def q12Shape28T22 : Tree 12 := .split 17 q12Shape28T23 q12Shape28T26
private theorem q12Shape28T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3072 512 q12Shape28T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3072 (512 ||| 2^17) q12Shape28T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (3072 ||| 2^17) 512 q12Shape28T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T23OK,q12Shape28T26OK⟩

private def q12Shape28T14 : Tree 12 := .split 11 q12Shape28T15 q12Shape28T22
private theorem q12Shape28T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1024 512 q12Shape28T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1024 (512 ||| 2^11) q12Shape28T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (1024 ||| 2^11) 512 q12Shape28T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T15OK,q12Shape28T22OK⟩

private def q12Shape28T0 : Tree 12 := .split 10 q12Shape28T1 q12Shape28T14
private theorem q12Shape28T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 512 q12Shape28T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 (512 ||| 2^10) q12Shape28T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (0 ||| 2^10) 512 q12Shape28T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T1OK,q12Shape28T14OK⟩

def q12Shape28P0 : Tree 12 := q12Shape28T0
theorem q12Shape28P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 0 512 q12Shape28P0=true := q12Shape28T0OK

end Graffiti384b.EffectiveSearch.Q12
