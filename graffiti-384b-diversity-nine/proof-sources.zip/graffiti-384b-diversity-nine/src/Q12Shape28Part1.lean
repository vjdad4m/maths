import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape28T33 : Tree 12 := (.split 24 (.tip (.small 0)) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))))
private theorem q12Shape28T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 396288 q12Shape28T33=true := by decide

private def q12Shape28T34 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))))
private theorem q12Shape28T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 262656 134144 q12Shape28T34=true := by decide

private def q12Shape28T32 : Tree 12 := .split 18 q12Shape28T33 q12Shape28T34
private theorem q12Shape28T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 134144 q12Shape28T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 (134144 ||| 2^18) q12Shape28T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (512 ||| 2^18) 134144 q12Shape28T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T33OK,q12Shape28T34OK⟩

private def q12Shape28T36 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))))
private theorem q12Shape28T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 131584 265216 q12Shape28T36=true := by decide

private def q12Shape28T37 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10,11}))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10,11}))))
private theorem q12Shape28T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 393728 3072 q12Shape28T37=true := by decide

private def q12Shape28T35 : Tree 12 := .split 18 q12Shape28T36 q12Shape28T37
private theorem q12Shape28T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 131584 3072 q12Shape28T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 131584 (3072 ||| 2^18) q12Shape28T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (131584 ||| 2^18) 3072 q12Shape28T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T36OK,q12Shape28T37OK⟩

private def q12Shape28T31 : Tree 12 := .split 17 q12Shape28T32 q12Shape28T35
private theorem q12Shape28T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 3072 q12Shape28T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 (3072 ||| 2^17) q12Shape28T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (512 ||| 2^17) 3072 q12Shape28T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T32OK,q12Shape28T35OK⟩

private def q12Shape28T40 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))))
private theorem q12Shape28T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2560 394240 q12Shape28T40=true := by decide

private def q12Shape28T41 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10,11}))))
private theorem q12Shape28T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 264704 132096 q12Shape28T41=true := by decide

private def q12Shape28T39 : Tree 12 := .split 18 q12Shape28T40 q12Shape28T41
private theorem q12Shape28T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2560 132096 q12Shape28T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2560 (132096 ||| 2^18) q12Shape28T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (2560 ||| 2^18) 132096 q12Shape28T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T40OK,q12Shape28T41OK⟩

private def q12Shape28T43 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {2,3,5,8,9,10,11})))))
private theorem q12Shape28T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 133632 263168 q12Shape28T43=true := by decide

private def q12Shape28T44 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10,11}))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10,11}))))
private theorem q12Shape28T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 395776 1024 q12Shape28T44=true := by decide

private def q12Shape28T42 : Tree 12 := .split 18 q12Shape28T43 q12Shape28T44
private theorem q12Shape28T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 133632 1024 q12Shape28T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 133632 (1024 ||| 2^18) q12Shape28T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (133632 ||| 2^18) 1024 q12Shape28T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T43OK,q12Shape28T44OK⟩

private def q12Shape28T38 : Tree 12 := .split 17 q12Shape28T39 q12Shape28T42
private theorem q12Shape28T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2560 1024 q12Shape28T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 2560 (1024 ||| 2^17) q12Shape28T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (2560 ||| 2^17) 1024 q12Shape28T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T39OK,q12Shape28T42OK⟩

private def q12Shape28T30 : Tree 12 := .split 11 q12Shape28T31 q12Shape28T38
private theorem q12Shape28T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 1024 q12Shape28T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 (1024 ||| 2^11) q12Shape28T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (512 ||| 2^11) 1024 q12Shape28T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T31OK,q12Shape28T38OK⟩

private def q12Shape28T48 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))))
private theorem q12Shape28T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1536 395264 q12Shape28T48=true := by decide

private def q12Shape28T49 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {2,3,6,8,9,10,11})))))
private theorem q12Shape28T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 263680 133120 q12Shape28T49=true := by decide

private def q12Shape28T47 : Tree 12 := .split 18 q12Shape28T48 q12Shape28T49
private theorem q12Shape28T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1536 133120 q12Shape28T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1536 (133120 ||| 2^18) q12Shape28T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (1536 ||| 2^18) 133120 q12Shape28T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T48OK,q12Shape28T49OK⟩

private def q12Shape28T51 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.split 36 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10,11})))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape28T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 132608 264192 q12Shape28T51=true := by decide

private def q12Shape28T52 : Tree 12 := (.split 24 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10,11}))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10,11}))))
private theorem q12Shape28T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 394752 2048 q12Shape28T52=true := by decide

private def q12Shape28T50 : Tree 12 := .split 18 q12Shape28T51 q12Shape28T52
private theorem q12Shape28T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 132608 2048 q12Shape28T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 132608 (2048 ||| 2^18) q12Shape28T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (132608 ||| 2^18) 2048 q12Shape28T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T51OK,q12Shape28T52OK⟩

private def q12Shape28T46 : Tree 12 := .split 17 q12Shape28T47 q12Shape28T50
private theorem q12Shape28T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1536 2048 q12Shape28T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1536 (2048 ||| 2^17) q12Shape28T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (1536 ||| 2^17) 2048 q12Shape28T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T47OK,q12Shape28T50OK⟩

private def q12Shape28T54 : Tree 12 := (.split 18 (.split 24 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11}))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11})))) (.split 24 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11}))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11})))))
private theorem q12Shape28T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3584 131072 q12Shape28T54=true := by decide

private def q12Shape28T55 : Tree 12 := (.split 18 (.split 24 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11}))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11})))) (.split 24 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11}))) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10,11})))))
private theorem q12Shape28T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 134656 0 q12Shape28T55=true := by decide

private def q12Shape28T53 : Tree 12 := .split 17 q12Shape28T54 q12Shape28T55
private theorem q12Shape28T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3584 0 q12Shape28T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 3584 (0 ||| 2^17) q12Shape28T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (3584 ||| 2^17) 0 q12Shape28T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T54OK,q12Shape28T55OK⟩

private def q12Shape28T45 : Tree 12 := .split 11 q12Shape28T46 q12Shape28T53
private theorem q12Shape28T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1536 0 q12Shape28T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 1536 (0 ||| 2^11) q12Shape28T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (1536 ||| 2^11) 0 q12Shape28T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T46OK,q12Shape28T53OK⟩

private def q12Shape28T29 : Tree 12 := .split 10 q12Shape28T30 q12Shape28T45
private theorem q12Shape28T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 0 q12Shape28T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 (0 ||| 2^10) q12Shape28T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) (512 ||| 2^10) 0 q12Shape28T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape28T30OK,q12Shape28T45OK⟩

def q12Shape28P1 : Tree 12 := q12Shape28T29
theorem q12Shape28P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,1⟩) 512 0 q12Shape28P1=true := q12Shape28T29OK

end Graffiti384b.EffectiveSearch.Q12
