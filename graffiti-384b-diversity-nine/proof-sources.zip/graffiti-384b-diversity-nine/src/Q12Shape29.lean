import Q12Shape29Part0
import Q12Shape29Part1
import Q12Shape29Part2
import Q12Shape29Part3

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape29M68 : Tree 12 := .split 24 q12Shape29P0 q12Shape29P1
private theorem q12Shape29M68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 393216 q12Shape29M68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 (393216 ||| 2^24) q12Shape29P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (0 ||| 2^24) 393216 q12Shape29P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29P0OK,q12Shape29P1OK⟩
private def q12Shape29M88 : Tree 12 := .split 18 q12Shape29M68 q12Shape29P2
private theorem q12Shape29M88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 131072 q12Shape29M88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 (131072 ||| 2^18) q12Shape29M68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (0 ||| 2^18) 131072 q12Shape29P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29M68OK,q12Shape29P2OK⟩
private def q12Shape29M112 : Tree 12 := .split 17 q12Shape29M88 q12Shape29P3
private theorem q12Shape29M112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 0 q12Shape29M112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 (0 ||| 2^17) q12Shape29M88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (0 ||| 2^17) 0 q12Shape29P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29M88OK,q12Shape29P3OK⟩

theorem q12Shape29_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 29) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 29) b) (adj 12 (forms 29) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) adj_mono b H q12Shape29M112 q12Shape29M112OK

#print axioms q12Shape29_cover

end Graffiti384b.EffectiveSearch.Q12
