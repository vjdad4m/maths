import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape29T2 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 34376908801 q12Shape29T2=true := by decide

private def q12Shape29T4 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738368 17170449 q12Shape29T4=true := by decide

private def q12Shape29T6 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738384 17170465 q12Shape29T6=true := by decide

private def q12Shape29T7 : Tree 12 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,4,9,10,11})))) (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))))))
private theorem q12Shape29T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738416 17170433 q12Shape29T7=true := by decide

private def q12Shape29T5 : Tree 12 := .split 5 q12Shape29T6 q12Shape29T7
private theorem q12Shape29T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738384 17170433 q12Shape29T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738384 (17170433 ||| 2^5) q12Shape29T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738384 ||| 2^5) 17170433 q12Shape29T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T6OK,q12Shape29T7OK⟩

private def q12Shape29T3 : Tree 12 := .split 4 q12Shape29T4 q12Shape29T5
private theorem q12Shape29T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738368 17170433 q12Shape29T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738368 (17170433 ||| 2^4) q12Shape29T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738368 ||| 2^4) 17170433 q12Shape29T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T4OK,q12Shape29T5OK⟩

private def q12Shape29T1 : Tree 12 := .split 35 q12Shape29T2 q12Shape29T3
private theorem q12Shape29T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 17170433 q12Shape29T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 (17170433 ||| 2^35) q12Shape29T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (0 ||| 2^35) 17170433 q12Shape29T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T2OK,q12Shape29T3OK⟩

private def q12Shape29T10 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 1 34376908816 q12Shape29T10=true := by decide

private def q12Shape29T12 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 17 34376908832 q12Shape29T12=true := by decide

private def q12Shape29T14 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 49 34376912896 q12Shape29T14=true := by decide

private def q12Shape29T16 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 4145 34376916992 q12Shape29T16=true := by decide

private def q12Shape29T18 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,2,3,5,9,10,11})))) (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {0,2,3,6,9,10,11}))) (.tip (.cover {0,1,2,4,9,10,11}))))
private theorem q12Shape29T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 12337 34376908802 q12Shape29T18=true := by decide

private def q12Shape29T19 : Tree 12 := (.split 2 (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape29T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 12339 34376908800 q12Shape29T19=true := by decide

private def q12Shape29T17 : Tree 12 := .split 1 q12Shape29T18 q12Shape29T19
private theorem q12Shape29T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 12337 34376908800 q12Shape29T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 12337 (34376908800 ||| 2^1) q12Shape29T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (12337 ||| 2^1) 34376908800 q12Shape29T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T18OK,q12Shape29T19OK⟩

private def q12Shape29T15 : Tree 12 := .split 13 q12Shape29T16 q12Shape29T17
private theorem q12Shape29T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 4145 34376908800 q12Shape29T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 4145 (34376908800 ||| 2^13) q12Shape29T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (4145 ||| 2^13) 34376908800 q12Shape29T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T16OK,q12Shape29T17OK⟩

private def q12Shape29T13 : Tree 12 := .split 12 q12Shape29T14 q12Shape29T15
private theorem q12Shape29T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 49 34376908800 q12Shape29T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 49 (34376908800 ||| 2^12) q12Shape29T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (49 ||| 2^12) 34376908800 q12Shape29T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T14OK,q12Shape29T15OK⟩

private def q12Shape29T11 : Tree 12 := .split 5 q12Shape29T12 q12Shape29T13
private theorem q12Shape29T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 17 34376908800 q12Shape29T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 17 (34376908800 ||| 2^5) q12Shape29T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (17 ||| 2^5) 34376908800 q12Shape29T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T12OK,q12Shape29T13OK⟩

private def q12Shape29T9 : Tree 12 := .split 4 q12Shape29T10 q12Shape29T11
private theorem q12Shape29T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 1 34376908800 q12Shape29T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 1 (34376908800 ||| 2^4) q12Shape29T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (1 ||| 2^4) 34376908800 q12Shape29T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T10OK,q12Shape29T11OK⟩

private def q12Shape29T22 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738369 17170480 q12Shape29T22=true := by decide

private def q12Shape29T24 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738401 17174544 q12Shape29T24=true := by decide

private def q12Shape29T26 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742497 17178640 q12Shape29T26=true := by decide

private def q12Shape29T28 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10,11}))))) (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10,11})))) (.tip (.cover {0,2,4,7,9,10,11}))))
private theorem q12Shape29T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750689 17170450 q12Shape29T28=true := by decide

private def q12Shape29T29 : Tree 12 := (.split 2 (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))
private theorem q12Shape29T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750691 17170448 q12Shape29T29=true := by decide

private def q12Shape29T27 : Tree 12 := .split 1 q12Shape29T28 q12Shape29T29
private theorem q12Shape29T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750689 17170448 q12Shape29T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750689 (17170448 ||| 2^1) q12Shape29T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359750689 ||| 2^1) 17170448 q12Shape29T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T28OK,q12Shape29T29OK⟩

private def q12Shape29T25 : Tree 12 := .split 13 q12Shape29T26 q12Shape29T27
private theorem q12Shape29T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742497 17170448 q12Shape29T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742497 (17170448 ||| 2^13) q12Shape29T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359742497 ||| 2^13) 17170448 q12Shape29T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T26OK,q12Shape29T27OK⟩

private def q12Shape29T23 : Tree 12 := .split 12 q12Shape29T24 q12Shape29T25
private theorem q12Shape29T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738401 17170448 q12Shape29T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738401 (17170448 ||| 2^12) q12Shape29T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738401 ||| 2^12) 17170448 q12Shape29T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T24OK,q12Shape29T25OK⟩

private def q12Shape29T21 : Tree 12 := .split 5 q12Shape29T22 q12Shape29T23
private theorem q12Shape29T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738369 17170448 q12Shape29T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738369 (17170448 ||| 2^5) q12Shape29T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738369 ||| 2^5) 17170448 q12Shape29T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T22OK,q12Shape29T23OK⟩

private def q12Shape29T32 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738385 17174560 q12Shape29T32=true := by decide

private def q12Shape29T34 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742481 17178656 q12Shape29T34=true := by decide

private def q12Shape29T36 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10,11}))))) (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10,11})))) (.tip (.cover {0,2,4,8,9,10,11}))))
private theorem q12Shape29T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750673 17170466 q12Shape29T36=true := by decide

private def q12Shape29T37 : Tree 12 := (.split 2 (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape29T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750675 17170464 q12Shape29T37=true := by decide

private def q12Shape29T35 : Tree 12 := .split 1 q12Shape29T36 q12Shape29T37
private theorem q12Shape29T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750673 17170464 q12Shape29T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750673 (17170464 ||| 2^1) q12Shape29T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359750673 ||| 2^1) 17170464 q12Shape29T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T36OK,q12Shape29T37OK⟩

private def q12Shape29T33 : Tree 12 := .split 13 q12Shape29T34 q12Shape29T35
private theorem q12Shape29T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742481 17170464 q12Shape29T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742481 (17170464 ||| 2^13) q12Shape29T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359742481 ||| 2^13) 17170464 q12Shape29T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T34OK,q12Shape29T35OK⟩

private def q12Shape29T31 : Tree 12 := .split 12 q12Shape29T32 q12Shape29T33
private theorem q12Shape29T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738385 17170464 q12Shape29T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738385 (17170464 ||| 2^12) q12Shape29T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738385 ||| 2^12) 17170464 q12Shape29T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T32OK,q12Shape29T33OK⟩

private def q12Shape29T40 : Tree 12 := (.tip (.small 1))
private theorem q12Shape29T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738417 17182720 q12Shape29T40=true := by decide

private def q12Shape29T42 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,2,3,7,9,10,11}))))) (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,6,7,9,10,11})))) (.tip (.cover {0,1,2,4,9,10,11}))))
private theorem q12Shape29T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359746609 17174530 q12Shape29T42=true := by decide

private def q12Shape29T43 : Tree 12 := (.split 2 (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape29T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359746611 17174528 q12Shape29T43=true := by decide

private def q12Shape29T41 : Tree 12 := .split 1 q12Shape29T42 q12Shape29T43
private theorem q12Shape29T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359746609 17174528 q12Shape29T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359746609 (17174528 ||| 2^1) q12Shape29T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359746609 ||| 2^1) 17174528 q12Shape29T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T42OK,q12Shape29T43OK⟩

private def q12Shape29T39 : Tree 12 := .split 13 q12Shape29T40 q12Shape29T41
private theorem q12Shape29T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738417 17174528 q12Shape29T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738417 (17174528 ||| 2^13) q12Shape29T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738417 ||| 2^13) 17174528 q12Shape29T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T40OK,q12Shape29T41OK⟩

private def q12Shape29T46 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,2,3,7,9,10,11}))))) (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,6,8,9,10,11})))) (.tip (.cover {0,1,2,4,9,10,11}))))
private theorem q12Shape29T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742513 17178626 q12Shape29T46=true := by decide

private def q12Shape29T47 : Tree 12 := (.split 2 (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape29T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742515 17178624 q12Shape29T47=true := by decide

private def q12Shape29T45 : Tree 12 := .split 1 q12Shape29T46 q12Shape29T47
private theorem q12Shape29T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742513 17178624 q12Shape29T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742513 (17178624 ||| 2^1) q12Shape29T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359742513 ||| 2^1) 17178624 q12Shape29T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T46OK,q12Shape29T47OK⟩

private def q12Shape29T49 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,2,3,5,9,10,11})))) (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {0,2,3,6,9,10,11}))) (.tip (.cover {0,1,2,4,9,10,11}))))
private theorem q12Shape29T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750705 17170434 q12Shape29T49=true := by decide

private def q12Shape29T50 : Tree 12 := (.split 2 (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape29T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750707 17170432 q12Shape29T50=true := by decide

private def q12Shape29T48 : Tree 12 := .split 1 q12Shape29T49 q12Shape29T50
private theorem q12Shape29T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750705 17170432 q12Shape29T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359750705 (17170432 ||| 2^1) q12Shape29T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359750705 ||| 2^1) 17170432 q12Shape29T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T49OK,q12Shape29T50OK⟩

private def q12Shape29T44 : Tree 12 := .split 13 q12Shape29T45 q12Shape29T48
private theorem q12Shape29T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742513 17170432 q12Shape29T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359742513 (17170432 ||| 2^13) q12Shape29T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359742513 ||| 2^13) 17170432 q12Shape29T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T45OK,q12Shape29T48OK⟩

private def q12Shape29T38 : Tree 12 := .split 12 q12Shape29T39 q12Shape29T44
private theorem q12Shape29T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738417 17170432 q12Shape29T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738417 (17170432 ||| 2^12) q12Shape29T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738417 ||| 2^12) 17170432 q12Shape29T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T39OK,q12Shape29T44OK⟩

private def q12Shape29T30 : Tree 12 := .split 5 q12Shape29T31 q12Shape29T38
private theorem q12Shape29T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738385 17170432 q12Shape29T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738385 (17170432 ||| 2^5) q12Shape29T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738385 ||| 2^5) 17170432 q12Shape29T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T31OK,q12Shape29T38OK⟩

private def q12Shape29T20 : Tree 12 := .split 4 q12Shape29T21 q12Shape29T30
private theorem q12Shape29T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738369 17170432 q12Shape29T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 34359738369 (17170432 ||| 2^4) q12Shape29T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (34359738369 ||| 2^4) 17170432 q12Shape29T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T21OK,q12Shape29T30OK⟩

private def q12Shape29T8 : Tree 12 := .split 35 q12Shape29T9 q12Shape29T20
private theorem q12Shape29T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 1 17170432 q12Shape29T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 1 (17170432 ||| 2^35) q12Shape29T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (1 ||| 2^35) 17170432 q12Shape29T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T9OK,q12Shape29T20OK⟩

private def q12Shape29T0 : Tree 12 := .split 0 q12Shape29T1 q12Shape29T8
private theorem q12Shape29T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 17170432 q12Shape29T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 (17170432 ||| 2^0) q12Shape29T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) (0 ||| 2^0) 17170432 q12Shape29T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape29T1OK,q12Shape29T8OK⟩

def q12Shape29P0 : Tree 12 := q12Shape29T0
theorem q12Shape29P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,2⟩) 0 17170432 q12Shape29P0=true := q12Shape29T0OK

end Graffiti384b.EffectiveSearch.Q12
