import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape2T3 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10,11}))))))
private theorem q12Shape2T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 652852199424 q12Shape2T3=true := by decide

private def q12Shape2T4 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10,11}))))))
private theorem q12Shape2T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755813888 103096385536 q12Shape2T4=true := by decide

private def q12Shape2T2 : Tree 12 := .split 39 q12Shape2T3 q12Shape2T4
private theorem q12Shape2T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 103096385536 q12Shape2T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 (103096385536 ||| 2^39) q12Shape2T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (0 ||| 2^39) 103096385536 q12Shape2T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T3OK,q12Shape2T4OK⟩

private def q12Shape2T6 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10,11}))))))
private theorem q12Shape2T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719476736 584132722688 q12Shape2T6=true := by decide

private def q12Shape2T7 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,9,10,11})))))
private theorem q12Shape2T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 618475290624 34376908800 q12Shape2T7=true := by decide

private def q12Shape2T5 : Tree 12 := .split 39 q12Shape2T6 q12Shape2T7
private theorem q12Shape2T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719476736 34376908800 q12Shape2T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719476736 (34376908800 ||| 2^39) q12Shape2T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (68719476736 ||| 2^39) 34376908800 q12Shape2T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T6OK,q12Shape2T7OK⟩

private def q12Shape2T1 : Tree 12 := .split 36 q12Shape2T2 q12Shape2T5
private theorem q12Shape2T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 34376908800 q12Shape2T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 (34376908800 ||| 2^36) q12Shape2T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (0 ||| 2^36) 34376908800 q12Shape2T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T2OK,q12Shape2T5OK⟩

private def q12Shape2T10 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10,11}))))))
private theorem q12Shape2T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359738368 618492461056 q12Shape2T10=true := by decide

private def q12Shape2T11 : Tree 12 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,8,10,11})))))
private theorem q12Shape2T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 584115552256 68736647168 q12Shape2T11=true := by decide

private def q12Shape2T9 : Tree 12 := .split 39 q12Shape2T10 q12Shape2T11
private theorem q12Shape2T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359738368 68736647168 q12Shape2T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359738368 (68736647168 ||| 2^39) q12Shape2T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34359738368 ||| 2^39) 68736647168 q12Shape2T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T10OK,q12Shape2T11OK⟩

private def q12Shape2T12 : Tree 12 := (.split 39 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,7,10,11}))))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,7,10,11}))))))
private theorem q12Shape2T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 103079215104 17170432 q12Shape2T12=true := by decide

private def q12Shape2T8 : Tree 12 := .split 36 q12Shape2T9 q12Shape2T12
private theorem q12Shape2T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359738368 17170432 q12Shape2T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359738368 (17170432 ||| 2^36) q12Shape2T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34359738368 ||| 2^36) 17170432 q12Shape2T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T9OK,q12Shape2T12OK⟩

private def q12Shape2T0 : Tree 12 := .split 35 q12Shape2T1 q12Shape2T8
private theorem q12Shape2T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 17170432 q12Shape2T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 (17170432 ||| 2^35) q12Shape2T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (0 ||| 2^35) 17170432 q12Shape2T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T1OK,q12Shape2T8OK⟩

def q12Shape2P0 : Tree 12 := q12Shape2T0
theorem q12Shape2P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 0 17170432 q12Shape2P0=true := q12Shape2T0OK

end Graffiti384b.EffectiveSearch.Q12
