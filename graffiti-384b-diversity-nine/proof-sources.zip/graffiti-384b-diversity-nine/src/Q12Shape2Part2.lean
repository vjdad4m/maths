import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape2T48 : Tree 12 := (.tip (.small 1))
private theorem q12Shape2T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 652851937281 q12Shape2T48=true := by decide

private def q12Shape2T50 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11}))))))
private theorem q12Shape2T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262145 652851937282 q12Shape2T50=true := by decide

private def q12Shape2T51 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,9,10,11}))))) (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.tip (.cover {0,2,7,8,9,10,11}))))
private theorem q12Shape2T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262147 652851937280 q12Shape2T51=true := by decide

private def q12Shape2T49 : Tree 12 := .split 1 q12Shape2T50 q12Shape2T51
private theorem q12Shape2T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262145 652851937280 q12Shape2T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262145 (652851937280 ||| 2^1) q12Shape2T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (262145 ||| 2^1) 652851937280 q12Shape2T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T50OK,q12Shape2T51OK⟩

private def q12Shape2T47 : Tree 12 := .split 0 q12Shape2T48 q12Shape2T49
private theorem q12Shape2T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 652851937280 q12Shape2T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 (652851937280 ||| 2^0) q12Shape2T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (262144 ||| 2^0) 652851937280 q12Shape2T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T48OK,q12Shape2T49OK⟩

private def q12Shape2T53 : Tree 12 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10,11})))))
private theorem q12Shape2T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756076032 103096123393 q12Shape2T53=true := by decide

private def q12Shape2T55 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,1,2,4,8,10,11})))))
private theorem q12Shape2T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756076033 103096123394 q12Shape2T55=true := by decide

private def q12Shape2T56 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,1,2,5,8,10,11})))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,1,2,4,8,10,11}))) (.tip (.cover {0,1,2,7,8,10,11}))))
private theorem q12Shape2T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756076035 103096123392 q12Shape2T56=true := by decide

private def q12Shape2T54 : Tree 12 := .split 1 q12Shape2T55 q12Shape2T56
private theorem q12Shape2T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756076033 103096123392 q12Shape2T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756076033 (103096123392 ||| 2^1) q12Shape2T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (549756076033 ||| 2^1) 103096123392 q12Shape2T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T55OK,q12Shape2T56OK⟩

private def q12Shape2T52 : Tree 12 := .split 0 q12Shape2T53 q12Shape2T54
private theorem q12Shape2T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756076032 103096123392 q12Shape2T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756076032 (103096123392 ||| 2^0) q12Shape2T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (549756076032 ||| 2^0) 103096123392 q12Shape2T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T53OK,q12Shape2T54OK⟩

private def q12Shape2T46 : Tree 12 := .split 39 q12Shape2T47 q12Shape2T52
private theorem q12Shape2T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 103096123392 q12Shape2T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 (103096123392 ||| 2^39) q12Shape2T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (262144 ||| 2^39) 103096123392 q12Shape2T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T47OK,q12Shape2T52OK⟩

private def q12Shape2T59 : Tree 12 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10,11})))))
private theorem q12Shape2T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738880 584132460545 q12Shape2T59=true := by decide

private def q12Shape2T61 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))))
private theorem q12Shape2T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738881 584132460546 q12Shape2T61=true := by decide

private def q12Shape2T62 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,1,2,7,8,10,11}))))
private theorem q12Shape2T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738883 584132460544 q12Shape2T62=true := by decide

private def q12Shape2T60 : Tree 12 := .split 1 q12Shape2T61 q12Shape2T62
private theorem q12Shape2T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738881 584132460544 q12Shape2T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738881 (584132460544 ||| 2^1) q12Shape2T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (68719738881 ||| 2^1) 584132460544 q12Shape2T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T61OK,q12Shape2T62OK⟩

private def q12Shape2T58 : Tree 12 := .split 0 q12Shape2T59 q12Shape2T60
private theorem q12Shape2T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738880 584132460544 q12Shape2T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738880 (584132460544 ||| 2^0) q12Shape2T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (68719738880 ||| 2^0) 584132460544 q12Shape2T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T59OK,q12Shape2T60OK⟩

private def q12Shape2T63 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape2T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 618475552768 34376646656 q12Shape2T63=true := by decide

private def q12Shape2T57 : Tree 12 := .split 39 q12Shape2T58 q12Shape2T63
private theorem q12Shape2T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738880 34376646656 q12Shape2T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719738880 (34376646656 ||| 2^39) q12Shape2T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (68719738880 ||| 2^39) 34376646656 q12Shape2T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T58OK,q12Shape2T63OK⟩

private def q12Shape2T45 : Tree 12 := .split 36 q12Shape2T46 q12Shape2T57
private theorem q12Shape2T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 34376646656 q12Shape2T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 (34376646656 ||| 2^36) q12Shape2T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (262144 ||| 2^36) 34376646656 q12Shape2T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T46OK,q12Shape2T57OK⟩

private def q12Shape2T67 : Tree 12 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10,11})))))
private theorem q12Shape2T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000512 618492198913 q12Shape2T67=true := by decide

private def q12Shape2T69 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))))
private theorem q12Shape2T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000513 618492198914 q12Shape2T69=true := by decide

private def q12Shape2T70 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,1,2,7,9,10,11}))))
private theorem q12Shape2T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000515 618492198912 q12Shape2T70=true := by decide

private def q12Shape2T68 : Tree 12 := .split 1 q12Shape2T69 q12Shape2T70
private theorem q12Shape2T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000513 618492198912 q12Shape2T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000513 (618492198912 ||| 2^1) q12Shape2T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34360000513 ||| 2^1) 618492198912 q12Shape2T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T69OK,q12Shape2T70OK⟩

private def q12Shape2T66 : Tree 12 := .split 0 q12Shape2T67 q12Shape2T68
private theorem q12Shape2T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000512 618492198912 q12Shape2T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000512 (618492198912 ||| 2^0) q12Shape2T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34360000512 ||| 2^0) 618492198912 q12Shape2T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T67OK,q12Shape2T68OK⟩

private def q12Shape2T71 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape2T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 584115814400 68736385024 q12Shape2T71=true := by decide

private def q12Shape2T65 : Tree 12 := .split 39 q12Shape2T66 q12Shape2T71
private theorem q12Shape2T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000512 68736385024 q12Shape2T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000512 (68736385024 ||| 2^39) q12Shape2T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34360000512 ||| 2^39) 68736385024 q12Shape2T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T66OK,q12Shape2T71OK⟩

private def q12Shape2T72 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape2T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 103079477248 16908288 q12Shape2T72=true := by decide

private def q12Shape2T64 : Tree 12 := .split 36 q12Shape2T65 q12Shape2T72
private theorem q12Shape2T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000512 16908288 q12Shape2T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360000512 (16908288 ||| 2^36) q12Shape2T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34360000512 ||| 2^36) 16908288 q12Shape2T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T65OK,q12Shape2T72OK⟩

private def q12Shape2T44 : Tree 12 := .split 35 q12Shape2T45 q12Shape2T64
private theorem q12Shape2T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 16908288 q12Shape2T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 (16908288 ||| 2^35) q12Shape2T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (262144 ||| 2^35) 16908288 q12Shape2T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T45OK,q12Shape2T64OK⟩

private def q12Shape2T77 : Tree 12 := (.tip (.small 1))
private theorem q12Shape2T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 652835160065 q12Shape2T77=true := by decide

private def q12Shape2T80 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,6,9,10,11})))))
private theorem q12Shape2T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039361 652835160070 q12Shape2T80=true := by decide

private def q12Shape2T81 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))))
private theorem q12Shape2T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039365 652835160066 q12Shape2T81=true := by decide

private def q12Shape2T79 : Tree 12 := .split 2 q12Shape2T80 q12Shape2T81
private theorem q12Shape2T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039361 652835160066 q12Shape2T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039361 (652835160066 ||| 2^2) q12Shape2T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17039361 ||| 2^2) 652835160066 q12Shape2T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T80OK,q12Shape2T81OK⟩

private def q12Shape2T83 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,9,10,11})))) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,9,10,11})))))
private theorem q12Shape2T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039363 652835160068 q12Shape2T83=true := by decide

private def q12Shape2T84 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape2T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039367 652835160064 q12Shape2T84=true := by decide

private def q12Shape2T82 : Tree 12 := .split 2 q12Shape2T83 q12Shape2T84
private theorem q12Shape2T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039363 652835160064 q12Shape2T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039363 (652835160064 ||| 2^2) q12Shape2T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17039363 ||| 2^2) 652835160064 q12Shape2T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T83OK,q12Shape2T84OK⟩

private def q12Shape2T78 : Tree 12 := .split 1 q12Shape2T79 q12Shape2T82
private theorem q12Shape2T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039361 652835160064 q12Shape2T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039361 (652835160064 ||| 2^1) q12Shape2T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17039361 ||| 2^1) 652835160064 q12Shape2T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T79OK,q12Shape2T82OK⟩

private def q12Shape2T76 : Tree 12 := .split 0 q12Shape2T77 q12Shape2T78
private theorem q12Shape2T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 652835160064 q12Shape2T76=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 (652835160064 ||| 2^0) q12Shape2T77 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17039360 ||| 2^0) 652835160064 q12Shape2T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T77OK,q12Shape2T78OK⟩

private def q12Shape2T85 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape2T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549772853248 103079346176 q12Shape2T85=true := by decide

private def q12Shape2T75 : Tree 12 := .split 39 q12Shape2T76 q12Shape2T85
private theorem q12Shape2T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 103079346176 q12Shape2T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 (103079346176 ||| 2^39) q12Shape2T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17039360 ||| 2^39) 103079346176 q12Shape2T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T76OK,q12Shape2T85OK⟩

private def q12Shape2T86 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape2T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68736516096 34359869440 q12Shape2T86=true := by decide

private def q12Shape2T74 : Tree 12 := .split 36 q12Shape2T75 q12Shape2T86
private theorem q12Shape2T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 34359869440 q12Shape2T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 (34359869440 ||| 2^36) q12Shape2T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17039360 ||| 2^36) 34359869440 q12Shape2T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T75OK,q12Shape2T86OK⟩

private def q12Shape2T87 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape2T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34376777728 131072 q12Shape2T87=true := by decide

private def q12Shape2T73 : Tree 12 := .split 35 q12Shape2T74 q12Shape2T87
private theorem q12Shape2T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 131072 q12Shape2T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17039360 (131072 ||| 2^35) q12Shape2T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17039360 ||| 2^35) 131072 q12Shape2T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T74OK,q12Shape2T87OK⟩

private def q12Shape2T43 : Tree 12 := .split 24 q12Shape2T44 q12Shape2T73
private theorem q12Shape2T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 131072 q12Shape2T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 (131072 ||| 2^24) q12Shape2T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (262144 ||| 2^24) 131072 q12Shape2T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T44OK,q12Shape2T73OK⟩

def q12Shape2P2 : Tree 12 := q12Shape2T43
theorem q12Shape2P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 262144 131072 q12Shape2P2=true := q12Shape2T43OK

end Graffiti384b.EffectiveSearch.Q12
