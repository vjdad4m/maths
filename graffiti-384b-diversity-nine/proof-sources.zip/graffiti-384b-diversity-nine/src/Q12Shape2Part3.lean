import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape2T94 : Tree 12 := (.tip (.small 1))
private theorem q12Shape2T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 652852068353 q12Shape2T94=true := by decide

private def q12Shape2T96 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11}))))))
private theorem q12Shape2T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131073 652852068354 q12Shape2T96=true := by decide

private def q12Shape2T97 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11}))))) (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,6,9,10,11})))) (.tip (.cover {0,2,7,8,9,10,11}))))
private theorem q12Shape2T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131075 652852068352 q12Shape2T97=true := by decide

private def q12Shape2T95 : Tree 12 := .split 1 q12Shape2T96 q12Shape2T97
private theorem q12Shape2T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131073 652852068352 q12Shape2T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131073 (652852068352 ||| 2^1) q12Shape2T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (131073 ||| 2^1) 652852068352 q12Shape2T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T96OK,q12Shape2T97OK⟩

private def q12Shape2T93 : Tree 12 := .split 0 q12Shape2T94 q12Shape2T95
private theorem q12Shape2T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 652852068352 q12Shape2T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 (652852068352 ||| 2^0) q12Shape2T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (131072 ||| 2^0) 652852068352 q12Shape2T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T94OK,q12Shape2T95OK⟩

private def q12Shape2T99 : Tree 12 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10,11})))))
private theorem q12Shape2T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755944960 103096254465 q12Shape2T99=true := by decide

private def q12Shape2T101 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,1,2,4,8,10,11})))))
private theorem q12Shape2T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755944961 103096254466 q12Shape2T101=true := by decide

private def q12Shape2T102 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,1,2,4,8,10,11})))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,6,7,9,10,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,7,8,10,11}))))
private theorem q12Shape2T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755944963 103096254464 q12Shape2T102=true := by decide

private def q12Shape2T100 : Tree 12 := .split 1 q12Shape2T101 q12Shape2T102
private theorem q12Shape2T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755944961 103096254464 q12Shape2T100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755944961 (103096254464 ||| 2^1) q12Shape2T101 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (549755944961 ||| 2^1) 103096254464 q12Shape2T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T101OK,q12Shape2T102OK⟩

private def q12Shape2T98 : Tree 12 := .split 0 q12Shape2T99 q12Shape2T100
private theorem q12Shape2T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755944960 103096254464 q12Shape2T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549755944960 (103096254464 ||| 2^0) q12Shape2T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (549755944960 ||| 2^0) 103096254464 q12Shape2T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T99OK,q12Shape2T100OK⟩

private def q12Shape2T92 : Tree 12 := .split 39 q12Shape2T93 q12Shape2T98
private theorem q12Shape2T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 103096254464 q12Shape2T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 (103096254464 ||| 2^39) q12Shape2T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (131072 ||| 2^39) 103096254464 q12Shape2T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T93OK,q12Shape2T98OK⟩

private def q12Shape2T105 : Tree 12 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10,11})))))
private theorem q12Shape2T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607808 584132591617 q12Shape2T105=true := by decide

private def q12Shape2T107 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))))
private theorem q12Shape2T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607809 584132591618 q12Shape2T107=true := by decide

private def q12Shape2T108 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,1,2,7,8,10,11}))))
private theorem q12Shape2T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607811 584132591616 q12Shape2T108=true := by decide

private def q12Shape2T106 : Tree 12 := .split 1 q12Shape2T107 q12Shape2T108
private theorem q12Shape2T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607809 584132591616 q12Shape2T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607809 (584132591616 ||| 2^1) q12Shape2T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (68719607809 ||| 2^1) 584132591616 q12Shape2T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T107OK,q12Shape2T108OK⟩

private def q12Shape2T104 : Tree 12 := .split 0 q12Shape2T105 q12Shape2T106
private theorem q12Shape2T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607808 584132591616 q12Shape2T104=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607808 (584132591616 ||| 2^0) q12Shape2T105 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (68719607808 ||| 2^0) 584132591616 q12Shape2T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T105OK,q12Shape2T106OK⟩

private def q12Shape2T109 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape2T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 618475421696 34376777728 q12Shape2T109=true := by decide

private def q12Shape2T103 : Tree 12 := .split 39 q12Shape2T104 q12Shape2T109
private theorem q12Shape2T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607808 34376777728 q12Shape2T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719607808 (34376777728 ||| 2^39) q12Shape2T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (68719607808 ||| 2^39) 34376777728 q12Shape2T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T104OK,q12Shape2T109OK⟩

private def q12Shape2T91 : Tree 12 := .split 36 q12Shape2T92 q12Shape2T103
private theorem q12Shape2T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 34376777728 q12Shape2T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 (34376777728 ||| 2^36) q12Shape2T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (131072 ||| 2^36) 34376777728 q12Shape2T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T92OK,q12Shape2T103OK⟩

private def q12Shape2T113 : Tree 12 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10,11})))))
private theorem q12Shape2T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869440 618492329985 q12Shape2T113=true := by decide

private def q12Shape2T115 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))))
private theorem q12Shape2T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869441 618492329986 q12Shape2T115=true := by decide

private def q12Shape2T116 : Tree 12 := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,6,7,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,1,2,7,9,10,11}))))
private theorem q12Shape2T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869443 618492329984 q12Shape2T116=true := by decide

private def q12Shape2T114 : Tree 12 := .split 1 q12Shape2T115 q12Shape2T116
private theorem q12Shape2T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869441 618492329984 q12Shape2T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869441 (618492329984 ||| 2^1) q12Shape2T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34359869441 ||| 2^1) 618492329984 q12Shape2T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T115OK,q12Shape2T116OK⟩

private def q12Shape2T112 : Tree 12 := .split 0 q12Shape2T113 q12Shape2T114
private theorem q12Shape2T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869440 618492329984 q12Shape2T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869440 (618492329984 ||| 2^0) q12Shape2T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34359869440 ||| 2^0) 618492329984 q12Shape2T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T113OK,q12Shape2T114OK⟩

private def q12Shape2T117 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape2T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 584115683328 68736516096 q12Shape2T117=true := by decide

private def q12Shape2T111 : Tree 12 := .split 39 q12Shape2T112 q12Shape2T117
private theorem q12Shape2T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869440 68736516096 q12Shape2T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869440 (68736516096 ||| 2^39) q12Shape2T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34359869440 ||| 2^39) 68736516096 q12Shape2T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T112OK,q12Shape2T117OK⟩

private def q12Shape2T118 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape2T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 103079346176 17039360 q12Shape2T118=true := by decide

private def q12Shape2T110 : Tree 12 := .split 36 q12Shape2T111 q12Shape2T118
private theorem q12Shape2T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869440 17039360 q12Shape2T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34359869440 (17039360 ||| 2^36) q12Shape2T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (34359869440 ||| 2^36) 17039360 q12Shape2T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T111OK,q12Shape2T118OK⟩

private def q12Shape2T90 : Tree 12 := .split 35 q12Shape2T91 q12Shape2T110
private theorem q12Shape2T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 17039360 q12Shape2T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 (17039360 ||| 2^35) q12Shape2T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (131072 ||| 2^35) 17039360 q12Shape2T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T91OK,q12Shape2T110OK⟩

private def q12Shape2T123 : Tree 12 := (.tip (.small 1))
private theorem q12Shape2T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 652835291137 q12Shape2T123=true := by decide

private def q12Shape2T126 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))))
private theorem q12Shape2T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908289 652835291142 q12Shape2T126=true := by decide

private def q12Shape2T127 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,9,10,11})))) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))))
private theorem q12Shape2T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908293 652835291138 q12Shape2T127=true := by decide

private def q12Shape2T125 : Tree 12 := .split 2 q12Shape2T126 q12Shape2T127
private theorem q12Shape2T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908289 652835291138 q12Shape2T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908289 (652835291138 ||| 2^2) q12Shape2T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (16908289 ||| 2^2) 652835291138 q12Shape2T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T126OK,q12Shape2T127OK⟩

private def q12Shape2T129 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,9,10,11})))) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,5,8,9,10,11}))))
private theorem q12Shape2T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908291 652835291140 q12Shape2T129=true := by decide

private def q12Shape2T130 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,9,10,11})))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape2T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908295 652835291136 q12Shape2T130=true := by decide

private def q12Shape2T128 : Tree 12 := .split 2 q12Shape2T129 q12Shape2T130
private theorem q12Shape2T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908291 652835291136 q12Shape2T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908291 (652835291136 ||| 2^2) q12Shape2T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (16908291 ||| 2^2) 652835291136 q12Shape2T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T129OK,q12Shape2T130OK⟩

private def q12Shape2T124 : Tree 12 := .split 1 q12Shape2T125 q12Shape2T128
private theorem q12Shape2T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908289 652835291136 q12Shape2T124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908289 (652835291136 ||| 2^1) q12Shape2T125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (16908289 ||| 2^1) 652835291136 q12Shape2T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T125OK,q12Shape2T128OK⟩

private def q12Shape2T122 : Tree 12 := .split 0 q12Shape2T123 q12Shape2T124
private theorem q12Shape2T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 652835291136 q12Shape2T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 (652835291136 ||| 2^0) q12Shape2T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (16908288 ||| 2^0) 652835291136 q12Shape2T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T123OK,q12Shape2T124OK⟩

private def q12Shape2T131 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape2T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549772722176 103079477248 q12Shape2T131=true := by decide

private def q12Shape2T121 : Tree 12 := .split 39 q12Shape2T122 q12Shape2T131
private theorem q12Shape2T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 103079477248 q12Shape2T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 (103079477248 ||| 2^39) q12Shape2T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (16908288 ||| 2^39) 103079477248 q12Shape2T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T122OK,q12Shape2T131OK⟩

private def q12Shape2T132 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape2T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68736385024 34360000512 q12Shape2T132=true := by decide

private def q12Shape2T120 : Tree 12 := .split 36 q12Shape2T121 q12Shape2T132
private theorem q12Shape2T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 34360000512 q12Shape2T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 (34360000512 ||| 2^36) q12Shape2T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (16908288 ||| 2^36) 34360000512 q12Shape2T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T121OK,q12Shape2T132OK⟩

private def q12Shape2T133 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape2T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34376646656 262144 q12Shape2T133=true := by decide

private def q12Shape2T119 : Tree 12 := .split 35 q12Shape2T120 q12Shape2T133
private theorem q12Shape2T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 262144 q12Shape2T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 16908288 (262144 ||| 2^35) q12Shape2T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (16908288 ||| 2^35) 262144 q12Shape2T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T120OK,q12Shape2T133OK⟩

private def q12Shape2T89 : Tree 12 := .split 24 q12Shape2T90 q12Shape2T119
private theorem q12Shape2T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 262144 q12Shape2T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 (262144 ||| 2^24) q12Shape2T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (131072 ||| 2^24) 262144 q12Shape2T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T90OK,q12Shape2T119OK⟩

def q12Shape2P3 : Tree 12 := q12Shape2T89
theorem q12Shape2P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 131072 262144 q12Shape2P3=true := q12Shape2T89OK

end Graffiti384b.EffectiveSearch.Q12
