import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape2T139 : Tree 12 := (.tip (.small 1))
private theorem q12Shape2T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 652851806209 q12Shape2T139=true := by decide

private def q12Shape2T142 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))))
private theorem q12Shape2T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393217 652851806214 q12Shape2T142=true := by decide

private def q12Shape2T143 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,4,8,9,10,11}))))
private theorem q12Shape2T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393221 652851806210 q12Shape2T143=true := by decide

private def q12Shape2T141 : Tree 12 := .split 2 q12Shape2T142 q12Shape2T143
private theorem q12Shape2T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393217 652851806210 q12Shape2T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393217 (652851806210 ||| 2^2) q12Shape2T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393217 ||| 2^2) 652851806210 q12Shape2T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T142OK,q12Shape2T143OK⟩

private def q12Shape2T145 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))))
private theorem q12Shape2T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393219 652851806212 q12Shape2T145=true := by decide

private def q12Shape2T146 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape2T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393223 652851806208 q12Shape2T146=true := by decide

private def q12Shape2T144 : Tree 12 := .split 2 q12Shape2T145 q12Shape2T146
private theorem q12Shape2T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393219 652851806208 q12Shape2T144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393219 (652851806208 ||| 2^2) q12Shape2T145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393219 ||| 2^2) 652851806208 q12Shape2T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T145OK,q12Shape2T146OK⟩

private def q12Shape2T140 : Tree 12 := .split 1 q12Shape2T141 q12Shape2T144
private theorem q12Shape2T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393217 652851806208 q12Shape2T140=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393217 (652851806208 ||| 2^1) q12Shape2T141 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393217 ||| 2^1) 652851806208 q12Shape2T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T141OK,q12Shape2T144OK⟩

private def q12Shape2T138 : Tree 12 := .split 0 q12Shape2T139 q12Shape2T140
private theorem q12Shape2T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 652851806208 q12Shape2T138=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 (652851806208 ||| 2^0) q12Shape2T139 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393216 ||| 2^0) 652851806208 q12Shape2T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T139OK,q12Shape2T140OK⟩

private def q12Shape2T147 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape2T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549756207104 103095992320 q12Shape2T147=true := by decide

private def q12Shape2T137 : Tree 12 := .split 39 q12Shape2T138 q12Shape2T147
private theorem q12Shape2T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 103095992320 q12Shape2T137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 (103095992320 ||| 2^39) q12Shape2T138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393216 ||| 2^39) 103095992320 q12Shape2T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T138OK,q12Shape2T147OK⟩

private def q12Shape2T148 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape2T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68719869952 34376515584 q12Shape2T148=true := by decide

private def q12Shape2T136 : Tree 12 := .split 36 q12Shape2T137 q12Shape2T148
private theorem q12Shape2T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 34376515584 q12Shape2T136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 (34376515584 ||| 2^36) q12Shape2T137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393216 ||| 2^36) 34376515584 q12Shape2T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T137OK,q12Shape2T148OK⟩

private def q12Shape2T149 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape2T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34360131584 16777216 q12Shape2T149=true := by decide

private def q12Shape2T135 : Tree 12 := .split 35 q12Shape2T136 q12Shape2T149
private theorem q12Shape2T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 16777216 q12Shape2T135=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 (16777216 ||| 2^35) q12Shape2T136 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393216 ||| 2^35) 16777216 q12Shape2T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T136OK,q12Shape2T149OK⟩

private def q12Shape2T154 : Tree 12 := (.tip (.small 1))
private theorem q12Shape2T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 652835028993 q12Shape2T154=true := by decide

private def q12Shape2T157 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))))
private theorem q12Shape2T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170433 652835028998 q12Shape2T157=true := by decide

private def q12Shape2T158 : Tree 12 := (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,4,8,9,10,11}))))
private theorem q12Shape2T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170437 652835028994 q12Shape2T158=true := by decide

private def q12Shape2T156 : Tree 12 := .split 2 q12Shape2T157 q12Shape2T158
private theorem q12Shape2T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170433 652835028994 q12Shape2T156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170433 (652835028994 ||| 2^2) q12Shape2T157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17170433 ||| 2^2) 652835028994 q12Shape2T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T157OK,q12Shape2T158OK⟩

private def q12Shape2T159 : Tree 12 := (.split 2 (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10,11})))) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,5,8,9,10,11})))) (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))))
private theorem q12Shape2T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170435 652835028992 q12Shape2T159=true := by decide

private def q12Shape2T155 : Tree 12 := .split 1 q12Shape2T156 q12Shape2T159
private theorem q12Shape2T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170433 652835028992 q12Shape2T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170433 (652835028992 ||| 2^1) q12Shape2T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17170433 ||| 2^1) 652835028992 q12Shape2T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T156OK,q12Shape2T159OK⟩

private def q12Shape2T153 : Tree 12 := .split 0 q12Shape2T154 q12Shape2T155
private theorem q12Shape2T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 652835028992 q12Shape2T153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 (652835028992 ||| 2^0) q12Shape2T154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17170432 ||| 2^0) 652835028992 q12Shape2T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T154OK,q12Shape2T155OK⟩

private def q12Shape2T160 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape2T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 549772984320 103079215104 q12Shape2T160=true := by decide

private def q12Shape2T152 : Tree 12 := .split 39 q12Shape2T153 q12Shape2T160
private theorem q12Shape2T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 103079215104 q12Shape2T152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 (103079215104 ||| 2^39) q12Shape2T153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17170432 ||| 2^39) 103079215104 q12Shape2T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T153OK,q12Shape2T160OK⟩

private def q12Shape2T161 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape2T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 68736647168 34359738368 q12Shape2T161=true := by decide

private def q12Shape2T151 : Tree 12 := .split 36 q12Shape2T152 q12Shape2T161
private theorem q12Shape2T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 34359738368 q12Shape2T151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 (34359738368 ||| 2^36) q12Shape2T152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17170432 ||| 2^36) 34359738368 q12Shape2T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T152OK,q12Shape2T161OK⟩

private def q12Shape2T162 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape2T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 34376908800 0 q12Shape2T162=true := by decide

private def q12Shape2T150 : Tree 12 := .split 35 q12Shape2T151 q12Shape2T162
private theorem q12Shape2T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 0 q12Shape2T150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 17170432 (0 ||| 2^35) q12Shape2T151 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (17170432 ||| 2^35) 0 q12Shape2T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T151OK,q12Shape2T162OK⟩

private def q12Shape2T134 : Tree 12 := .split 24 q12Shape2T135 q12Shape2T150
private theorem q12Shape2T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 0 q12Shape2T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 (0 ||| 2^24) q12Shape2T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) (393216 ||| 2^24) 0 q12Shape2T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape2T135OK,q12Shape2T150OK⟩

def q12Shape2P4 : Tree 12 := q12Shape2T134
theorem q12Shape2P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,2⟩) 393216 0 q12Shape2P4=true := q12Shape2T134OK

end Graffiti384b.EffectiveSearch.Q12
