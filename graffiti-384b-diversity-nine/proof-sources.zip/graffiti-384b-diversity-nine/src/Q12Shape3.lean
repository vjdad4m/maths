import Q12Shape3Part0
import Q12Shape3Part1
import Q12Shape3Part2
import Q12Shape3Part3
import Q12Shape3Part4
import Q12Shape3Part5

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape3M53 : Tree 12 := .split 1 q12Shape3P1 q12Shape3P2
private theorem q12Shape3M53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 1 34376515584 q12Shape3M53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 1 (34376515584 ||| 2^1) q12Shape3P1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (1 ||| 2^1) 34376515584 q12Shape3P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3P1OK,q12Shape3P2OK⟩
private def q12Shape3M54 : Tree 12 := .split 0 q12Shape3P0 q12Shape3M53
private theorem q12Shape3M54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 34376515584 q12Shape3M54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 (34376515584 ||| 2^0) q12Shape3P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (0 ||| 2^0) 34376515584 q12Shape3M53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3P0OK,q12Shape3M53OK⟩
private def q12Shape3M100 : Tree 12 := .split 35 q12Shape3M54 q12Shape3P3
private theorem q12Shape3M100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 16777216 q12Shape3M100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 (16777216 ||| 2^35) q12Shape3M54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (0 ||| 2^35) 16777216 q12Shape3P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3M54OK,q12Shape3P3OK⟩
private def q12Shape3M166 : Tree 12 := .split 1 q12Shape3P5 q12Shape3P6
private theorem q12Shape3M166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 16777217 34359738368 q12Shape3M166=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 16777217 (34359738368 ||| 2^1) q12Shape3P5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (16777217 ||| 2^1) 34359738368 q12Shape3P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3P5OK,q12Shape3P6OK⟩
private def q12Shape3M167 : Tree 12 := .split 0 q12Shape3P4 q12Shape3M166
private theorem q12Shape3M167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 16777216 34359738368 q12Shape3M167=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 16777216 (34359738368 ||| 2^0) q12Shape3P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (16777216 ||| 2^0) 34359738368 q12Shape3M166)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3P4OK,q12Shape3M166OK⟩
private def q12Shape3M169 : Tree 12 := .split 35 q12Shape3M167 q12Shape3P7
private theorem q12Shape3M169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 16777216 0 q12Shape3M169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 16777216 (0 ||| 2^35) q12Shape3M167 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (16777216 ||| 2^35) 0 q12Shape3P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3M167OK,q12Shape3P7OK⟩
private def q12Shape3M170 : Tree 12 := .split 24 q12Shape3M100 q12Shape3M169
private theorem q12Shape3M170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 0 q12Shape3M170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 (0 ||| 2^24) q12Shape3M100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (0 ||| 2^24) 0 q12Shape3M169)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3M100OK,q12Shape3M169OK⟩

theorem q12Shape3_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 3) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 3) b) (adj 12 (forms 3) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) adj_mono b H q12Shape3M170 q12Shape3M170OK

#print axioms q12Shape3_cover

end Graffiti384b.EffectiveSearch.Q12
