import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape30T2 : Tree 12 := (.tip (.cover {0,2,3,4,7,10,11}))
private theorem q12Shape30T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 0 558328971264 q12Shape30T2=true := by decide

private def q12Shape30T5 : Tree 12 := (.tip (.cover {0,2,3,4,7,9,11}))
private theorem q12Shape30T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549755813888 1116674719744 q12Shape30T5=true := by decide

private def q12Shape30T6 : Tree 12 := (.split 34 (.split 36 (.split 37 (.split 38 (.split 41 (.tip (.cover {0,2,3,4,7,9,10})) (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 43 (.tip (.cover {0,2,3,4,7,8,10})) (.tip (.cover {0,1,5,6,7,8,9}))))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape30T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1649267441664 17163091968 q12Shape30T6=true := by decide

private def q12Shape30T4 : Tree 12 := .split 40 q12Shape30T5 q12Shape30T6
private theorem q12Shape30T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549755813888 17163091968 q12Shape30T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549755813888 (17163091968 ||| 2^40) q12Shape30T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549755813888 ||| 2^40) 17163091968 q12Shape30T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T5OK,q12Shape30T6OK⟩

private def q12Shape30T14 : Tree 12 := (.tip (.cover {0,2,3,4,7,9,10}))
private theorem q12Shape30T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 3839683985408 q12Shape30T14=true := by decide

private def q12Shape30T18 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,8}))
private theorem q12Shape30T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 575525617664 34608829693952 q12Shape30T18=true := by decide

private def q12Shape30T21 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 17 (.split 5 (.split 2 (.tip (.cover {0,1,3,4,6,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,3,6,7,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))))
private theorem q12Shape30T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18167711662080 17016643653648 q12Shape30T21=true := by decide

private def q12Shape30T22 : Tree 12 := (.split 19 (.split 10 (.split 5 (.split 2 (.tip (.cover {0,1,3,4,6,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,4,6,7,9,10}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18167711666176 17016643649552 q12Shape30T22=true := by decide

private def q12Shape30T20 : Tree 12 := .split 12 q12Shape30T21 q12Shape30T22
private theorem q12Shape30T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18167711662080 17016643649552 q12Shape30T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18167711662080 (17016643649552 ||| 2^12) q12Shape30T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18167711662080 ||| 2^12) 17016643649552 q12Shape30T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T21OK,q12Shape30T22OK⟩

private def q12Shape30T23 : Tree 12 := (.split 12 (.split 19 (.split 2 (.split 5 (.tip (.cover {0,3,4,6,7,9,10})) (.tip (.cover {0,1,2,5,6,9,10}))) (.tip (.cover {0,1,2,6,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,10}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18167711662096 17016643649536 q12Shape30T23=true := by decide

private def q12Shape30T19 : Tree 12 := .split 4 q12Shape30T20 q12Shape30T23
private theorem q12Shape30T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18167711662080 17016643649536 q12Shape30T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18167711662080 (17016643649536 ||| 2^4) q12Shape30T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18167711662080 ||| 2^4) 17016643649536 q12Shape30T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T20OK,q12Shape30T23OK⟩

private def q12Shape30T17 : Tree 12 := .split 44 q12Shape30T18 q12Shape30T19
private theorem q12Shape30T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 575525617664 17016643649536 q12Shape30T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 575525617664 (17016643649536 ||| 2^44) q12Shape30T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (575525617664 ||| 2^44) 17016643649536 q12Shape30T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T18OK,q12Shape30T19OK⟩

private def q12Shape30T24 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape30T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9371618639872 8220550627328 q12Shape30T24=true := by decide

private def q12Shape30T16 : Tree 12 := .split 43 q12Shape30T17 q12Shape30T24
private theorem q12Shape30T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 575525617664 8220550627328 q12Shape30T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 575525617664 (8220550627328 ||| 2^43) q12Shape30T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (575525617664 ||| 2^43) 8220550627328 q12Shape30T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T17OK,q12Shape30T24OK⟩

private def q12Shape30T25 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape30T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4973572128768 3822504116224 q12Shape30T25=true := by decide

private def q12Shape30T15 : Tree 12 := .split 42 q12Shape30T16 q12Shape30T25
private theorem q12Shape30T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 575525617664 3822504116224 q12Shape30T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 575525617664 (3822504116224 ||| 2^42) q12Shape30T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (575525617664 ||| 2^42) 3822504116224 q12Shape30T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T16OK,q12Shape30T25OK⟩

private def q12Shape30T13 : Tree 12 := .split 34 q12Shape30T14 q12Shape30T15
private theorem q12Shape30T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 3822504116224 q12Shape30T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 (3822504116224 ||| 2^34) q12Shape30T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (558345748480 ||| 2^34) 3822504116224 q12Shape30T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T14OK,q12Shape30T15OK⟩

private def q12Shape30T26 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2757369004032 1623480860672 q12Shape30T26=true := by decide

private def q12Shape30T12 : Tree 12 := .split 41 q12Shape30T13 q12Shape30T26
private theorem q12Shape30T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 1623480860672 q12Shape30T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 (1623480860672 ||| 2^41) q12Shape30T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (558345748480 ||| 2^41) 1623480860672 q12Shape30T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T13OK,q12Shape30T26OK⟩

private def q12Shape30T27 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1657857376256 523969232896 q12Shape30T27=true := by decide

private def q12Shape30T11 : Tree 12 := .split 40 q12Shape30T12 q12Shape30T27
private theorem q12Shape30T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 523969232896 q12Shape30T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 (523969232896 ||| 2^40) q12Shape30T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (558345748480 ||| 2^40) 523969232896 q12Shape30T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T12OK,q12Shape30T27OK⟩

private def q12Shape30T28 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 833223655424 249091325952 q12Shape30T28=true := by decide

private def q12Shape30T10 : Tree 12 := .split 38 q12Shape30T11 q12Shape30T28
private theorem q12Shape30T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 249091325952 q12Shape30T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 (249091325952 ||| 2^38) q12Shape30T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (558345748480 ||| 2^38) 249091325952 q12Shape30T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T11OK,q12Shape30T28OK⟩

private def q12Shape30T29 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 695784701952 111652372480 q12Shape30T29=true := by decide

private def q12Shape30T9 : Tree 12 := .split 37 q12Shape30T10 q12Shape30T29
private theorem q12Shape30T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 111652372480 q12Shape30T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 (111652372480 ||| 2^37) q12Shape30T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (558345748480 ||| 2^37) 111652372480 q12Shape30T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T10OK,q12Shape30T29OK⟩

private def q12Shape30T30 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape30T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 627065225216 42932895744 q12Shape30T30=true := by decide

private def q12Shape30T8 : Tree 12 := .split 36 q12Shape30T9 q12Shape30T30
private theorem q12Shape30T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 42932895744 q12Shape30T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 (42932895744 ||| 2^36) q12Shape30T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (558345748480 ||| 2^36) 42932895744 q12Shape30T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T9OK,q12Shape30T30OK⟩

private def q12Shape30T31 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 592705486848 8573157376 q12Shape30T31=true := by decide

private def q12Shape30T7 : Tree 12 := .split 35 q12Shape30T8 q12Shape30T31
private theorem q12Shape30T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 8573157376 q12Shape30T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 558345748480 (8573157376 ||| 2^35) q12Shape30T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (558345748480 ||| 2^35) 8573157376 q12Shape30T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T8OK,q12Shape30T31OK⟩

private def q12Shape30T3 : Tree 12 := .split 33 q12Shape30T4 q12Shape30T7
private theorem q12Shape30T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549755813888 8573157376 q12Shape30T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549755813888 (8573157376 ||| 2^33) q12Shape30T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549755813888 ||| 2^33) 8573157376 q12Shape30T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T4OK,q12Shape30T7OK⟩

private def q12Shape30T1 : Tree 12 := .split 39 q12Shape30T2 q12Shape30T3
private theorem q12Shape30T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 0 8573157376 q12Shape30T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 0 (8573157376 ||| 2^39) q12Shape30T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (0 ||| 2^39) 8573157376 q12Shape30T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T2OK,q12Shape30T3OK⟩

private def q12Shape30T38 : Tree 12 := (.tip (.cover {0,2,3,4,7,9,11}))
private theorem q12Shape30T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 1627775827968 q12Shape30T38=true := by decide

private def q12Shape30T42 : Tree 12 := (.tip (.cover {0,2,3,4,7,9,10}))
private theorem q12Shape30T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1103806595072 3294223138816 q12Shape30T42=true := by decide

private def q12Shape30T45 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape30T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1120986464256 16471182802944 q12Shape30T45=true := by decide

private def q12Shape30T49 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 17 (.split 5 (.split 2 (.tip (.cover {0,1,3,4,6,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,3,6,7,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))))
private theorem q12Shape30T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486464 25267275829264 q12Shape30T49=true := by decide

private def q12Shape30T50 : Tree 12 := (.split 19 (.split 10 (.split 5 (.split 2 (.tip (.cover {0,1,3,4,6,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,4,6,7,9,10}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079490560 25267275825168 q12Shape30T50=true := by decide

private def q12Shape30T48 : Tree 12 := .split 12 q12Shape30T49 q12Shape30T50
private theorem q12Shape30T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486464 25267275825168 q12Shape30T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486464 (25267275825168 ||| 2^12) q12Shape30T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9917079486464 ||| 2^12) 25267275825168 q12Shape30T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T49OK,q12Shape30T50OK⟩

private def q12Shape30T51 : Tree 12 := (.split 12 (.split 19 (.split 2 (.split 5 (.tip (.cover {0,3,4,6,7,9,10})) (.tip (.cover {0,1,2,5,6,9,10}))) (.tip (.cover {0,1,2,6,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486480 25267275825152 q12Shape30T51=true := by decide

private def q12Shape30T47 : Tree 12 := .split 4 q12Shape30T48 q12Shape30T51
private theorem q12Shape30T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486464 25267275825152 q12Shape30T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486464 (25267275825152 ||| 2^4) q12Shape30T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9917079486464 ||| 2^4) 25267275825152 q12Shape30T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T48OK,q12Shape30T51OK⟩

private def q12Shape30T52 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,11}))
private theorem q12Shape30T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 27509265530880 7675089780736 q12Shape30T52=true := by decide

private def q12Shape30T46 : Tree 12 := .split 44 q12Shape30T47 q12Shape30T52
private theorem q12Shape30T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486464 7675089780736 q12Shape30T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9917079486464 (7675089780736 ||| 2^44) q12Shape30T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9917079486464 ||| 2^44) 7675089780736 q12Shape30T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T47OK,q12Shape30T52OK⟩

private def q12Shape30T44 : Tree 12 := .split 43 q12Shape30T45 q12Shape30T46
private theorem q12Shape30T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1120986464256 7675089780736 q12Shape30T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1120986464256 (7675089780736 ||| 2^43) q12Shape30T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1120986464256 ||| 2^43) 7675089780736 q12Shape30T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T45OK,q12Shape30T46OK⟩

private def q12Shape30T53 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape30T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5519032975360 3277043269632 q12Shape30T53=true := by decide

private def q12Shape30T43 : Tree 12 := .split 42 q12Shape30T44 q12Shape30T53
private theorem q12Shape30T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1120986464256 3277043269632 q12Shape30T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1120986464256 (3277043269632 ||| 2^42) q12Shape30T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1120986464256 ||| 2^42) 3277043269632 q12Shape30T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T44OK,q12Shape30T53OK⟩

private def q12Shape30T41 : Tree 12 := .split 34 q12Shape30T42 q12Shape30T43
private theorem q12Shape30T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1103806595072 3277043269632 q12Shape30T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1103806595072 (3277043269632 ||| 2^34) q12Shape30T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1103806595072 ||| 2^34) 3277043269632 q12Shape30T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T42OK,q12Shape30T43OK⟩

private def q12Shape30T54 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3302829850624 1078020014080 q12Shape30T54=true := by decide

private def q12Shape30T40 : Tree 12 := .split 41 q12Shape30T41 q12Shape30T54
private theorem q12Shape30T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1103806595072 1078020014080 q12Shape30T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1103806595072 (1078020014080 ||| 2^41) q12Shape30T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1103806595072 ||| 2^41) 1078020014080 q12Shape30T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T41OK,q12Shape30T54OK⟩

private def q12Shape30T55 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1653562408960 528264200192 q12Shape30T55=true := by decide

private def q12Shape30T39 : Tree 12 := .split 39 q12Shape30T40 q12Shape30T55
private theorem q12Shape30T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1103806595072 528264200192 q12Shape30T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1103806595072 (528264200192 ||| 2^39) q12Shape30T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1103806595072 ||| 2^39) 528264200192 q12Shape30T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T40OK,q12Shape30T55OK⟩

private def q12Shape30T37 : Tree 12 := .split 40 q12Shape30T38 q12Shape30T39
private theorem q12Shape30T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 528264200192 q12Shape30T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 (528264200192 ||| 2^40) q12Shape30T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4294967296 ||| 2^40) 528264200192 q12Shape30T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T38OK,q12Shape30T39OK⟩

private def q12Shape30T58 : Tree 12 := (.tip (.cover {2,3,4,5,7,9,10}))
private theorem q12Shape30T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 12884901888 2735877390336 q12Shape30T58=true := by decide

private def q12Shape30T62 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape30T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2211908157440 6584168087552 q12Shape30T62=true := by decide

private def q12Shape30T67 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 17 (.split 5 (.split 2 (.tip (.cover {0,1,3,4,6,9,11})) (.tip (.cover {1,3,4,5,6,9,11}))) (.tip (.cover {0,2,3,6,7,9,11}))) (.tip (.cover {0,1,4,6,8,9,11}))))
private theorem q12Shape30T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 28574400647184 q12Shape30T67=true := by decide

private def q12Shape30T68 : Tree 12 := (.split 19 (.split 10 (.split 5 (.split 2 (.tip (.cover {0,1,3,4,6,9,11})) (.tip (.cover {1,3,4,5,6,9,11}))) (.tip (.cover {0,2,4,6,7,9,11}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954672640 28574400643088 q12Shape30T68=true := by decide

private def q12Shape30T66 : Tree 12 := .split 12 q12Shape30T67 q12Shape30T68
private theorem q12Shape30T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 28574400643088 q12Shape30T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 (28574400643088 ||| 2^12) q12Shape30T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6609954668544 ||| 2^12) 28574400643088 q12Shape30T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T67OK,q12Shape30T68OK⟩

private def q12Shape30T69 : Tree 12 := (.split 12 (.split 19 (.split 2 (.split 5 (.tip (.cover {0,3,4,6,7,9,11})) (.tip (.cover {0,1,2,5,6,9,11}))) (.tip (.cover {0,1,2,6,8,9,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668560 28574400643072 q12Shape30T69=true := by decide

private def q12Shape30T65 : Tree 12 := .split 4 q12Shape30T66 q12Shape30T69
private theorem q12Shape30T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 28574400643072 q12Shape30T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 (28574400643072 ||| 2^4) q12Shape30T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6609954668544 ||| 2^4) 28574400643072 q12Shape30T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T66OK,q12Shape30T69OK⟩

private def q12Shape30T70 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,10}))
private theorem q12Shape30T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 24202140712960 10982214598656 q12Shape30T70=true := by decide

private def q12Shape30T64 : Tree 12 := .split 44 q12Shape30T65 q12Shape30T70
private theorem q12Shape30T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 10982214598656 q12Shape30T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 (10982214598656 ||| 2^44) q12Shape30T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6609954668544 ||| 2^44) 10982214598656 q12Shape30T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T65OK,q12Shape30T70OK⟩

private def q12Shape30T71 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,9}))
private theorem q12Shape30T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 15406047690752 2186121576448 q12Shape30T71=true := by decide

private def q12Shape30T63 : Tree 12 := .split 43 q12Shape30T64 q12Shape30T71
private theorem q12Shape30T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 2186121576448 q12Shape30T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6609954668544 (2186121576448 ||| 2^43) q12Shape30T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6609954668544 ||| 2^43) 2186121576448 q12Shape30T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T64OK,q12Shape30T71OK⟩

private def q12Shape30T61 : Tree 12 := .split 42 q12Shape30T62 q12Shape30T63
private theorem q12Shape30T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2211908157440 2186121576448 q12Shape30T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2211908157440 (2186121576448 ||| 2^42) q12Shape30T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (2211908157440 ||| 2^42) 2186121576448 q12Shape30T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T62OK,q12Shape30T63OK⟩

private def q12Shape30T72 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3311419785216 1086609948672 q12Shape30T72=true := by decide

private def q12Shape30T60 : Tree 12 := .split 40 q12Shape30T61 q12Shape30T72
private theorem q12Shape30T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2211908157440 1086609948672 q12Shape30T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2211908157440 (1086609948672 ||| 2^40) q12Shape30T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (2211908157440 ||| 2^40) 1086609948672 q12Shape30T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T61OK,q12Shape30T72OK⟩

private def q12Shape30T73 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2761663971328 536854134784 q12Shape30T73=true := by decide

private def q12Shape30T59 : Tree 12 := .split 39 q12Shape30T60 q12Shape30T73
private theorem q12Shape30T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2211908157440 536854134784 q12Shape30T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2211908157440 (536854134784 ||| 2^39) q12Shape30T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (2211908157440 ||| 2^39) 536854134784 q12Shape30T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T60OK,q12Shape30T73OK⟩

private def q12Shape30T57 : Tree 12 := .split 41 q12Shape30T58 q12Shape30T59
private theorem q12Shape30T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 12884901888 536854134784 q12Shape30T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 12884901888 (536854134784 ||| 2^41) q12Shape30T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (12884901888 ||| 2^41) 536854134784 q12Shape30T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T58OK,q12Shape30T59OK⟩

private def q12Shape30T75 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9})))) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape30T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 30064771072 1069430079488 q12Shape30T75=true := by decide

private def q12Shape30T76 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape30T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 579820584960 519674265600 q12Shape30T76=true := by decide

private def q12Shape30T74 : Tree 12 := .split 39 q12Shape30T75 q12Shape30T76
private theorem q12Shape30T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 30064771072 519674265600 q12Shape30T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 30064771072 (519674265600 ||| 2^39) q12Shape30T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (30064771072 ||| 2^39) 519674265600 q12Shape30T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T75OK,q12Shape30T76OK⟩

private def q12Shape30T56 : Tree 12 := .split 34 q12Shape30T57 q12Shape30T74
private theorem q12Shape30T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 12884901888 519674265600 q12Shape30T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 12884901888 (519674265600 ||| 2^34) q12Shape30T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (12884901888 ||| 2^34) 519674265600 q12Shape30T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T57OK,q12Shape30T74OK⟩

private def q12Shape30T36 : Tree 12 := .split 33 q12Shape30T37 q12Shape30T56
private theorem q12Shape30T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 519674265600 q12Shape30T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 (519674265600 ||| 2^33) q12Shape30T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4294967296 ||| 2^33) 519674265600 q12Shape30T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T37OK,q12Shape30T56OK⟩

private def q12Shape30T77 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 279172874240 244796358656 q12Shape30T77=true := by decide

private def q12Shape30T35 : Tree 12 := .split 38 q12Shape30T36 q12Shape30T77
private theorem q12Shape30T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 244796358656 q12Shape30T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 (244796358656 ||| 2^38) q12Shape30T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4294967296 ||| 2^38) 244796358656 q12Shape30T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T36OK,q12Shape30T77OK⟩

private def q12Shape30T78 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 141733920768 107357405184 q12Shape30T78=true := by decide

private def q12Shape30T34 : Tree 12 := .split 37 q12Shape30T35 q12Shape30T78
private theorem q12Shape30T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 107357405184 q12Shape30T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 (107357405184 ||| 2^37) q12Shape30T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4294967296 ||| 2^37) 107357405184 q12Shape30T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T35OK,q12Shape30T78OK⟩

private def q12Shape30T79 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 73014444032 38637928448 q12Shape30T79=true := by decide

private def q12Shape30T33 : Tree 12 := .split 36 q12Shape30T34 q12Shape30T79
private theorem q12Shape30T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 38637928448 q12Shape30T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 (38637928448 ||| 2^36) q12Shape30T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4294967296 ||| 2^36) 38637928448 q12Shape30T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T34OK,q12Shape30T79OK⟩

private def q12Shape30T80 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 38654705664 4278190080 q12Shape30T80=true := by decide

private def q12Shape30T32 : Tree 12 := .split 35 q12Shape30T33 q12Shape30T80
private theorem q12Shape30T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 4278190080 q12Shape30T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4294967296 (4278190080 ||| 2^35) q12Shape30T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4294967296 ||| 2^35) 4278190080 q12Shape30T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T33OK,q12Shape30T80OK⟩

private def q12Shape30T0 : Tree 12 := .split 32 q12Shape30T1 q12Shape30T32
private theorem q12Shape30T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 0 4278190080 q12Shape30T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 0 (4278190080 ||| 2^32) q12Shape30T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (0 ||| 2^32) 4278190080 q12Shape30T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T1OK,q12Shape30T32OK⟩

def q12Shape30P0 : Tree 12 := q12Shape30T0
theorem q12Shape30P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 0 4278190080 q12Shape30P0=true := q12Shape30T0OK

end Graffiti384b.EffectiveSearch.Q12
