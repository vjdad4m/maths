import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape30T125 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape30T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 18135482630144 q12Shape30T125=true := by decide

private def q12Shape30T130 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape30T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 8789633794048 q12Shape30T130=true := by decide

private def q12Shape30T134 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 17 (.split 5 (.split 6 (.split 7 (.split 2 (.tip (.cover {0,1,3,4,6,8,11})) (.tip (.cover {1,3,4,5,6,8,11}))) (.tip (.cover {0,2,3,6,7,8,11}))) (.tip (.cover {0,2,3,4,7,8,10}))) (.tip (.cover {0,2,3,4,7,9,10}))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape30T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309248 17035971006480 q12Shape30T134=true := by decide

private def q12Shape30T135 : Tree 12 := (.split 19 (.split 10 (.split 5 (.split 6 (.split 7 (.split 2 (.tip (.cover {0,1,3,4,6,8,11})) (.tip (.cover {1,3,4,5,6,8,11}))) (.tip (.cover {0,2,4,6,7,8,11}))) (.tip (.cover {0,2,3,4,7,8,10}))) (.tip (.cover {0,2,3,4,7,9,10}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384313344 17035971002384 q12Shape30T135=true := by decide

private def q12Shape30T133 : Tree 12 := .split 12 q12Shape30T134 q12Shape30T135
private theorem q12Shape30T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309248 17035971002384 q12Shape30T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309248 (17035971002384 ||| 2^12) q12Shape30T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18148384309248 ||| 2^12) 17035971002384 q12Shape30T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T134OK,q12Shape30T135OK⟩

private def q12Shape30T136 : Tree 12 := (.split 12 (.split 19 (.split 2 (.split 7 (.tip (.cover {0,3,4,6,7,8,11})) (.tip (.cover {0,1,2,5,6,8,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {2,3,4,5,6,8,10}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309264 17035971002368 q12Shape30T136=true := by decide

private def q12Shape30T132 : Tree 12 := .split 4 q12Shape30T133 q12Shape30T136
private theorem q12Shape30T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309248 17035971002368 q12Shape30T132=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309248 (17035971002368 ||| 2^4) q12Shape30T133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18148384309248 ||| 2^4) 17035971002368 q12Shape30T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T133OK,q12Shape30T136OK⟩

private def q12Shape30T137 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,10}))
private theorem q12Shape30T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 26944477331456 8239877980160 q12Shape30T137=true := by decide

private def q12Shape30T131 : Tree 12 := .split 43 q12Shape30T132 q12Shape30T137
private theorem q12Shape30T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309248 8239877980160 q12Shape30T131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18148384309248 (8239877980160 ||| 2^43) q12Shape30T132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18148384309248 ||| 2^43) 8239877980160 q12Shape30T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T132OK,q12Shape30T137OK⟩

private def q12Shape30T129 : Tree 12 := .split 39 q12Shape30T130 q12Shape30T131
private theorem q12Shape30T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 8239877980160 q12Shape30T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 (8239877980160 ||| 2^39) q12Shape30T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (17598628495360 ||| 2^39) 8239877980160 q12Shape30T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T130OK,q12Shape30T131OK⟩

private def q12Shape30T138 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape30T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 21996675006464 3841831469056 q12Shape30T138=true := by decide

private def q12Shape30T128 : Tree 12 := .split 42 q12Shape30T129 q12Shape30T138
private theorem q12Shape30T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 3841831469056 q12Shape30T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 (3841831469056 ||| 2^42) q12Shape30T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (17598628495360 ||| 2^42) 3841831469056 q12Shape30T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T129OK,q12Shape30T138OK⟩

private def q12Shape30T139 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,10}))
private theorem q12Shape30T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 19797651750912 1642808213504 q12Shape30T139=true := by decide

private def q12Shape30T127 : Tree 12 := .split 41 q12Shape30T128 q12Shape30T139
private theorem q12Shape30T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 1642808213504 q12Shape30T127=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 (1642808213504 ||| 2^41) q12Shape30T128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (17598628495360 ||| 2^41) 1642808213504 q12Shape30T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T128OK,q12Shape30T139OK⟩

private def q12Shape30T140 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape30T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18698140123136 543296585728 q12Shape30T140=true := by decide

private def q12Shape30T126 : Tree 12 := .split 40 q12Shape30T127 q12Shape30T140
private theorem q12Shape30T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 543296585728 q12Shape30T126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17598628495360 (543296585728 ||| 2^40) q12Shape30T127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (17598628495360 ||| 2^40) 543296585728 q12Shape30T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T127OK,q12Shape30T140OK⟩

private def q12Shape30T124 : Tree 12 := .split 44 q12Shape30T125 q12Shape30T126
private theorem q12Shape30T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 543296585728 q12Shape30T124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 (543296585728 ||| 2^44) q12Shape30T125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6442450944 ||| 2^44) 543296585728 q12Shape30T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T125OK,q12Shape30T126OK⟩

private def q12Shape30T142 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10})))) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape30T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 23622320128 1075872530432 q12Shape30T142=true := by decide

private def q12Shape30T143 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape30T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 573378134016 526116716544 q12Shape30T143=true := by decide

private def q12Shape30T141 : Tree 12 := .split 39 q12Shape30T142 q12Shape30T143
private theorem q12Shape30T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 23622320128 526116716544 q12Shape30T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 23622320128 (526116716544 ||| 2^39) q12Shape30T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (23622320128 ||| 2^39) 526116716544 q12Shape30T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T142OK,q12Shape30T143OK⟩

private def q12Shape30T123 : Tree 12 := .split 34 q12Shape30T124 q12Shape30T141
private theorem q12Shape30T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 526116716544 q12Shape30T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 (526116716544 ||| 2^34) q12Shape30T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6442450944 ||| 2^34) 526116716544 q12Shape30T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T124OK,q12Shape30T141OK⟩

private def q12Shape30T146 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,11})))) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape30T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 15032385536 1084462465024 q12Shape30T146=true := by decide

private def q12Shape30T147 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape30T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 564788199424 534706651136 q12Shape30T147=true := by decide

private def q12Shape30T145 : Tree 12 := .split 39 q12Shape30T146 q12Shape30T147
private theorem q12Shape30T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 15032385536 534706651136 q12Shape30T145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 15032385536 (534706651136 ||| 2^39) q12Shape30T146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (15032385536 ||| 2^39) 534706651136 q12Shape30T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T146OK,q12Shape30T147OK⟩

private def q12Shape30T149 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9})))) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape30T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 32212254720 1067282595840 q12Shape30T149=true := by decide

private def q12Shape30T150 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape30T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 581968068608 517526781952 q12Shape30T150=true := by decide

private def q12Shape30T148 : Tree 12 := .split 39 q12Shape30T149 q12Shape30T150
private theorem q12Shape30T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 32212254720 517526781952 q12Shape30T148=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 32212254720 (517526781952 ||| 2^39) q12Shape30T149 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (32212254720 ||| 2^39) 517526781952 q12Shape30T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T149OK,q12Shape30T150OK⟩

private def q12Shape30T144 : Tree 12 := .split 34 q12Shape30T145 q12Shape30T148
private theorem q12Shape30T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 15032385536 517526781952 q12Shape30T144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 15032385536 (517526781952 ||| 2^34) q12Shape30T145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (15032385536 ||| 2^34) 517526781952 q12Shape30T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T145OK,q12Shape30T148OK⟩

private def q12Shape30T122 : Tree 12 := .split 33 q12Shape30T123 q12Shape30T144
private theorem q12Shape30T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 517526781952 q12Shape30T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 (517526781952 ||| 2^33) q12Shape30T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6442450944 ||| 2^33) 517526781952 q12Shape30T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T123OK,q12Shape30T144OK⟩

def q12Shape30P2 : Tree 12 := q12Shape30T122
theorem q12Shape30P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6442450944 517526781952 q12Shape30P2=true := q12Shape30T122OK

private def q12Shape30T152 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 277025390592 242648875008 q12Shape30T152=true := by decide

def q12Shape30P3 : Tree 12 := q12Shape30T152
theorem q12Shape30P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 277025390592 242648875008 q12Shape30P3=true := q12Shape30T152OK

private def q12Shape30T154 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 139586437120 105209921536 q12Shape30T154=true := by decide

def q12Shape30P4 : Tree 12 := q12Shape30T154
theorem q12Shape30P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 139586437120 105209921536 q12Shape30P4=true := q12Shape30T154OK

private def q12Shape30T156 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 70866960384 36490444800 q12Shape30T156=true := by decide

def q12Shape30P5 : Tree 12 := q12Shape30T156
theorem q12Shape30P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 70866960384 36490444800 q12Shape30P5=true := q12Shape30T156OK

private def q12Shape30T158 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 36507222016 2130706432 q12Shape30T158=true := by decide

def q12Shape30P6 : Tree 12 := q12Shape30T158
theorem q12Shape30P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 36507222016 2130706432 q12Shape30P6=true := q12Shape30T158OK

private def q12Shape30T164 : Tree 12 := (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {0,2,3,4,7,10,11})) (.split 40 (.tip (.cover {0,2,3,4,7,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape30T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 16626221056 q12Shape30T164=true := by decide

private def q12Shape30T165 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9126805504 8036286464 q12Shape30T165=true := by decide

private def q12Shape30T163 : Tree 12 := .split 33 q12Shape30T164 q12Shape30T165
private theorem q12Shape30T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 8036286464 q12Shape30T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 (8036286464 ||| 2^33) q12Shape30T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (536870912 ||| 2^33) 8036286464 q12Shape30T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T164OK,q12Shape30T165OK⟩

private def q12Shape30T166 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4831838208 3741319168 q12Shape30T166=true := by decide

private def q12Shape30T162 : Tree 12 := .split 32 q12Shape30T163 q12Shape30T166
private theorem q12Shape30T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 3741319168 q12Shape30T162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 (3741319168 ||| 2^32) q12Shape30T163 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (536870912 ||| 2^32) 3741319168 q12Shape30T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T163OK,q12Shape30T166OK⟩

private def q12Shape30T167 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2684354560 1593835520 q12Shape30T167=true := by decide

private def q12Shape30T161 : Tree 12 := .split 31 q12Shape30T162 q12Shape30T167
private theorem q12Shape30T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 1593835520 q12Shape30T161=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 (1593835520 ||| 2^31) q12Shape30T162 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (536870912 ||| 2^31) 1593835520 q12Shape30T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T162OK,q12Shape30T167OK⟩

def q12Shape30P7 : Tree 12 := q12Shape30T161
theorem q12Shape30P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 536870912 1593835520 q12Shape30P7=true := q12Shape30T161OK

end Graffiti384b.EffectiveSearch.Q12
