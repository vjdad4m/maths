import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape30T178 : Tree 12 := (.tip (.cover {0,2,3,4,7,10,11}))
private theorem q12Shape30T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 1098689544192 q12Shape30T178=true := by decide

private def q12Shape30T182 : Tree 12 := (.tip (.cover {0,2,3,4,7,9,10}))
private theorem q12Shape30T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550024249344 3848005484544 q12Shape30T182=true := by decide

private def q12Shape30T186 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,8}))
private theorem q12Shape30T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550561120256 34633794191360 q12Shape30T186=true := by decide

private def q12Shape30T189 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 18 (.split 5 (.split 3 (.tip (.cover {0,1,3,4,5,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,3,5,7,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))))
private theorem q12Shape30T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18142747164672 17041608151056 q12Shape30T189=true := by decide

private def q12Shape30T190 : Tree 12 := (.split 19 (.split 11 (.split 5 (.split 3 (.tip (.cover {0,1,3,4,5,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,4,5,7,9,10}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18142747168768 17041608146960 q12Shape30T190=true := by decide

private def q12Shape30T188 : Tree 12 := .split 12 q12Shape30T189 q12Shape30T190
private theorem q12Shape30T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18142747164672 17041608146960 q12Shape30T188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18142747164672 (17041608146960 ||| 2^12) q12Shape30T189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18142747164672 ||| 2^12) 17041608146960 q12Shape30T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T189OK,q12Shape30T190OK⟩

private def q12Shape30T191 : Tree 12 := (.split 12 (.split 19 (.split 3 (.split 5 (.tip (.cover {0,3,4,5,7,9,10})) (.tip (.cover {0,1,2,5,6,9,10}))) (.tip (.cover {0,1,2,5,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,10}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18142747164688 17041608146944 q12Shape30T191=true := by decide

private def q12Shape30T187 : Tree 12 := .split 4 q12Shape30T188 q12Shape30T191
private theorem q12Shape30T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18142747164672 17041608146944 q12Shape30T187=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18142747164672 (17041608146944 ||| 2^4) q12Shape30T188 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18142747164672 ||| 2^4) 17041608146944 q12Shape30T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T188OK,q12Shape30T191OK⟩

private def q12Shape30T185 : Tree 12 := .split 44 q12Shape30T186 q12Shape30T187
private theorem q12Shape30T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550561120256 17041608146944 q12Shape30T185=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550561120256 (17041608146944 ||| 2^44) q12Shape30T186 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (550561120256 ||| 2^44) 17041608146944 q12Shape30T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T186OK,q12Shape30T187OK⟩

private def q12Shape30T192 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape30T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9346654142464 8245515124736 q12Shape30T192=true := by decide

private def q12Shape30T184 : Tree 12 := .split 43 q12Shape30T185 q12Shape30T192
private theorem q12Shape30T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550561120256 8245515124736 q12Shape30T184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550561120256 (8245515124736 ||| 2^43) q12Shape30T185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (550561120256 ||| 2^43) 8245515124736 q12Shape30T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T185OK,q12Shape30T192OK⟩

private def q12Shape30T193 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape30T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4948607631360 3847468613632 q12Shape30T193=true := by decide

private def q12Shape30T183 : Tree 12 := .split 42 q12Shape30T184 q12Shape30T193
private theorem q12Shape30T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550561120256 3847468613632 q12Shape30T183=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550561120256 (3847468613632 ||| 2^42) q12Shape30T184 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (550561120256 ||| 2^42) 3847468613632 q12Shape30T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T184OK,q12Shape30T193OK⟩

private def q12Shape30T181 : Tree 12 := .split 29 q12Shape30T182 q12Shape30T183
private theorem q12Shape30T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550024249344 3847468613632 q12Shape30T181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550024249344 (3847468613632 ||| 2^29) q12Shape30T182 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (550024249344 ||| 2^29) 3847468613632 q12Shape30T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T182OK,q12Shape30T183OK⟩

private def q12Shape30T194 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape30T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2749047504896 1648445358080 q12Shape30T194=true := by decide

private def q12Shape30T180 : Tree 12 := .split 41 q12Shape30T181 q12Shape30T194
private theorem q12Shape30T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550024249344 1648445358080 q12Shape30T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550024249344 (1648445358080 ||| 2^41) q12Shape30T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (550024249344 ||| 2^41) 1648445358080 q12Shape30T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T181OK,q12Shape30T194OK⟩

private def q12Shape30T195 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape30T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1649535877120 548933730304 q12Shape30T195=true := by decide

private def q12Shape30T179 : Tree 12 := .split 40 q12Shape30T180 q12Shape30T195
private theorem q12Shape30T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550024249344 548933730304 q12Shape30T179=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550024249344 (548933730304 ||| 2^40) q12Shape30T180 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (550024249344 ||| 2^40) 548933730304 q12Shape30T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T180OK,q12Shape30T195OK⟩

private def q12Shape30T177 : Tree 12 := .split 39 q12Shape30T178 q12Shape30T179
private theorem q12Shape30T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 548933730304 q12Shape30T177=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (548933730304 ||| 2^39) q12Shape30T178 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^39) 548933730304 q12Shape30T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T178OK,q12Shape30T179OK⟩

private def q12Shape30T196 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 275146342400 274055823360 q12Shape30T196=true := by decide

private def q12Shape30T176 : Tree 12 := .split 38 q12Shape30T177 q12Shape30T196
private theorem q12Shape30T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 274055823360 q12Shape30T176=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (274055823360 ||| 2^38) q12Shape30T177 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^38) 274055823360 q12Shape30T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T177OK,q12Shape30T196OK⟩

private def q12Shape30T197 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 137707388928 136616869888 q12Shape30T197=true := by decide

private def q12Shape30T175 : Tree 12 := .split 37 q12Shape30T176 q12Shape30T197
private theorem q12Shape30T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 136616869888 q12Shape30T175=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (136616869888 ||| 2^37) q12Shape30T176 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^37) 136616869888 q12Shape30T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T176OK,q12Shape30T197OK⟩

private def q12Shape30T198 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 68987912192 67897393152 q12Shape30T198=true := by decide

private def q12Shape30T174 : Tree 12 := .split 36 q12Shape30T175 q12Shape30T198
private theorem q12Shape30T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 67897393152 q12Shape30T174=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (67897393152 ||| 2^36) q12Shape30T175 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^36) 67897393152 q12Shape30T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T175OK,q12Shape30T198OK⟩

private def q12Shape30T199 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 34628173824 33537654784 q12Shape30T199=true := by decide

private def q12Shape30T173 : Tree 12 := .split 35 q12Shape30T174 q12Shape30T199
private theorem q12Shape30T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 33537654784 q12Shape30T173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (33537654784 ||| 2^35) q12Shape30T174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^35) 33537654784 q12Shape30T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T174OK,q12Shape30T199OK⟩

private def q12Shape30T200 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17448304640 16357785600 q12Shape30T200=true := by decide

private def q12Shape30T172 : Tree 12 := .split 34 q12Shape30T173 q12Shape30T200
private theorem q12Shape30T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 16357785600 q12Shape30T172=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (16357785600 ||| 2^34) q12Shape30T173 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^34) 16357785600 q12Shape30T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T173OK,q12Shape30T200OK⟩

private def q12Shape30T201 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8858370048 7767851008 q12Shape30T201=true := by decide

private def q12Shape30T171 : Tree 12 := .split 33 q12Shape30T172 q12Shape30T201
private theorem q12Shape30T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 7767851008 q12Shape30T171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (7767851008 ||| 2^33) q12Shape30T172 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^33) 7767851008 q12Shape30T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T172OK,q12Shape30T201OK⟩

private def q12Shape30T202 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4563402752 3472883712 q12Shape30T202=true := by decide

private def q12Shape30T170 : Tree 12 := .split 32 q12Shape30T171 q12Shape30T202
private theorem q12Shape30T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 3472883712 q12Shape30T170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (3472883712 ||| 2^32) q12Shape30T171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^32) 3472883712 q12Shape30T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T171OK,q12Shape30T202OK⟩

private def q12Shape30T203 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2415919104 1325400064 q12Shape30T203=true := by decide

private def q12Shape30T169 : Tree 12 := .split 31 q12Shape30T170 q12Shape30T203
private theorem q12Shape30T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 1325400064 q12Shape30T169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 (1325400064 ||| 2^31) q12Shape30T170 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (268435456 ||| 2^31) 1325400064 q12Shape30T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T170OK,q12Shape30T203OK⟩

def q12Shape30P8 : Tree 12 := q12Shape30T169
theorem q12Shape30P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 268435456 1325400064 q12Shape30P8=true := q12Shape30T169OK

private def q12Shape30T215 : Tree 12 := (.tip (.cover {0,2,3,4,7,9,11}))
private theorem q12Shape30T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 1648579575808 q12Shape30T215=true := by decide

private def q12Shape30T219 : Tree 12 := (.tip (.cover {0,2,3,4,7,9,10}))
private theorem q12Shape30T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099645845504 3298383888384 q12Shape30T219=true := by decide

private def q12Shape30T222 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape30T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1100182716416 16491986550784 q12Shape30T222=true := by decide

private def q12Shape30T226 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 18 (.split 5 (.split 3 (.tip (.cover {0,1,3,4,5,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,3,5,7,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))))
private theorem q12Shape30T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738624 25288079577104 q12Shape30T226=true := by decide

private def q12Shape30T227 : Tree 12 := (.split 19 (.split 11 (.split 5 (.split 3 (.tip (.cover {0,1,3,4,5,9,10})) (.tip (.cover {1,3,4,5,6,9,10}))) (.tip (.cover {0,2,4,5,7,9,10}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275742720 25288079573008 q12Shape30T227=true := by decide

private def q12Shape30T225 : Tree 12 := .split 12 q12Shape30T226 q12Shape30T227
private theorem q12Shape30T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738624 25288079573008 q12Shape30T225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738624 (25288079573008 ||| 2^12) q12Shape30T226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9896275738624 ||| 2^12) 25288079573008 q12Shape30T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T226OK,q12Shape30T227OK⟩

private def q12Shape30T228 : Tree 12 := (.split 12 (.split 19 (.split 3 (.split 5 (.tip (.cover {0,3,4,5,7,9,10})) (.tip (.cover {0,1,2,5,6,9,10}))) (.tip (.cover {0,1,2,5,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738640 25288079572992 q12Shape30T228=true := by decide

private def q12Shape30T224 : Tree 12 := .split 4 q12Shape30T225 q12Shape30T228
private theorem q12Shape30T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738624 25288079572992 q12Shape30T224=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738624 (25288079572992 ||| 2^4) q12Shape30T225 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9896275738624 ||| 2^4) 25288079572992 q12Shape30T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T225OK,q12Shape30T228OK⟩

private def q12Shape30T229 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,11}))
private theorem q12Shape30T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 27488461783040 7695893528576 q12Shape30T229=true := by decide

private def q12Shape30T223 : Tree 12 := .split 44 q12Shape30T224 q12Shape30T229
private theorem q12Shape30T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738624 7695893528576 q12Shape30T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9896275738624 (7695893528576 ||| 2^44) q12Shape30T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9896275738624 ||| 2^44) 7695893528576 q12Shape30T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T224OK,q12Shape30T229OK⟩

private def q12Shape30T221 : Tree 12 := .split 43 q12Shape30T222 q12Shape30T223
private theorem q12Shape30T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1100182716416 7695893528576 q12Shape30T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1100182716416 (7695893528576 ||| 2^43) q12Shape30T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1100182716416 ||| 2^43) 7695893528576 q12Shape30T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T222OK,q12Shape30T223OK⟩

private def q12Shape30T230 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,11}))
private theorem q12Shape30T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5498229227520 3297847017472 q12Shape30T230=true := by decide

private def q12Shape30T220 : Tree 12 := .split 42 q12Shape30T221 q12Shape30T230
private theorem q12Shape30T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1100182716416 3297847017472 q12Shape30T220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1100182716416 (3297847017472 ||| 2^42) q12Shape30T221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1100182716416 ||| 2^42) 3297847017472 q12Shape30T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T221OK,q12Shape30T230OK⟩

private def q12Shape30T218 : Tree 12 := .split 29 q12Shape30T219 q12Shape30T220
private theorem q12Shape30T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099645845504 3297847017472 q12Shape30T218=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099645845504 (3297847017472 ||| 2^29) q12Shape30T219 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1099645845504 ||| 2^29) 3297847017472 q12Shape30T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T219OK,q12Shape30T220OK⟩

private def q12Shape30T231 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape30T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3298669101056 1098823761920 q12Shape30T231=true := by decide

private def q12Shape30T217 : Tree 12 := .split 41 q12Shape30T218 q12Shape30T231
private theorem q12Shape30T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099645845504 1098823761920 q12Shape30T217=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099645845504 (1098823761920 ||| 2^41) q12Shape30T218 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1099645845504 ||| 2^41) 1098823761920 q12Shape30T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T218OK,q12Shape30T231OK⟩

private def q12Shape30T232 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape30T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1649401659392 549067948032 q12Shape30T232=true := by decide

private def q12Shape30T216 : Tree 12 := .split 39 q12Shape30T217 q12Shape30T232
private theorem q12Shape30T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099645845504 549067948032 q12Shape30T216=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099645845504 (549067948032 ||| 2^39) q12Shape30T217 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1099645845504 ||| 2^39) 549067948032 q12Shape30T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T217OK,q12Shape30T232OK⟩

private def q12Shape30T214 : Tree 12 := .split 40 q12Shape30T215 q12Shape30T216
private theorem q12Shape30T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 549067948032 q12Shape30T214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (549067948032 ||| 2^40) q12Shape30T215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^40) 549067948032 q12Shape30T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T215OK,q12Shape30T216OK⟩

private def q12Shape30T235 : Tree 12 := (.tip (.cover {2,3,4,6,7,9,10}))
private theorem q12Shape30T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 402653184 2748359639040 q12Shape30T235=true := by decide

private def q12Shape30T239 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape30T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2199425908736 6596650336256 q12Shape30T239=true := by decide

private def q12Shape30T244 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 18 (.split 5 (.split 3 (.tip (.cover {0,1,3,4,5,9,11})) (.tip (.cover {1,3,4,5,6,9,11}))) (.tip (.cover {0,2,3,5,7,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))))
private theorem q12Shape30T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 28586882895888 q12Shape30T244=true := by decide

private def q12Shape30T245 : Tree 12 := (.split 19 (.split 11 (.split 5 (.split 3 (.tip (.cover {0,1,3,4,5,9,11})) (.tip (.cover {1,3,4,5,6,9,11}))) (.tip (.cover {0,2,4,5,7,9,11}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472423936 28586882891792 q12Shape30T245=true := by decide

private def q12Shape30T243 : Tree 12 := .split 12 q12Shape30T244 q12Shape30T245
private theorem q12Shape30T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 28586882891792 q12Shape30T243=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 (28586882891792 ||| 2^12) q12Shape30T244 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597472419840 ||| 2^12) 28586882891792 q12Shape30T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T244OK,q12Shape30T245OK⟩

private def q12Shape30T246 : Tree 12 := (.split 12 (.split 19 (.split 3 (.split 5 (.tip (.cover {0,3,4,5,7,9,11})) (.tip (.cover {0,1,2,5,6,9,11}))) (.tip (.cover {0,1,2,5,8,9,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419856 28586882891776 q12Shape30T246=true := by decide

private def q12Shape30T242 : Tree 12 := .split 4 q12Shape30T243 q12Shape30T246
private theorem q12Shape30T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 28586882891776 q12Shape30T242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 (28586882891776 ||| 2^4) q12Shape30T243 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597472419840 ||| 2^4) 28586882891776 q12Shape30T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T243OK,q12Shape30T246OK⟩

private def q12Shape30T247 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,10}))
private theorem q12Shape30T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 24189658464256 10994696847360 q12Shape30T247=true := by decide

private def q12Shape30T241 : Tree 12 := .split 44 q12Shape30T242 q12Shape30T247
private theorem q12Shape30T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 10994696847360 q12Shape30T241=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 (10994696847360 ||| 2^44) q12Shape30T242 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597472419840 ||| 2^44) 10994696847360 q12Shape30T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T242OK,q12Shape30T247OK⟩

private def q12Shape30T248 : Tree 12 := (.tip (.cover {0,1,5,6,7,8,9}))
private theorem q12Shape30T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 15393565442048 2198603825152 q12Shape30T248=true := by decide

private def q12Shape30T240 : Tree 12 := .split 43 q12Shape30T241 q12Shape30T248
private theorem q12Shape30T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 2198603825152 q12Shape30T240=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597472419840 (2198603825152 ||| 2^43) q12Shape30T241 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597472419840 ||| 2^43) 2198603825152 q12Shape30T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T241OK,q12Shape30T248OK⟩

private def q12Shape30T238 : Tree 12 := .split 42 q12Shape30T239 q12Shape30T240
private theorem q12Shape30T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2199425908736 2198603825152 q12Shape30T238=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2199425908736 (2198603825152 ||| 2^42) q12Shape30T239 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (2199425908736 ||| 2^42) 2198603825152 q12Shape30T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T239OK,q12Shape30T240OK⟩

private def q12Shape30T249 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape30T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3298937536512 1099092197376 q12Shape30T249=true := by decide

private def q12Shape30T237 : Tree 12 := .split 40 q12Shape30T238 q12Shape30T249
private theorem q12Shape30T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2199425908736 1099092197376 q12Shape30T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2199425908736 (1099092197376 ||| 2^40) q12Shape30T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (2199425908736 ||| 2^40) 1099092197376 q12Shape30T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T238OK,q12Shape30T249OK⟩

private def q12Shape30T250 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape30T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2749181722624 549336383488 q12Shape30T250=true := by decide

private def q12Shape30T236 : Tree 12 := .split 39 q12Shape30T237 q12Shape30T250
private theorem q12Shape30T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2199425908736 549336383488 q12Shape30T236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2199425908736 (549336383488 ||| 2^39) q12Shape30T237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (2199425908736 ||| 2^39) 549336383488 q12Shape30T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T237OK,q12Shape30T250OK⟩

private def q12Shape30T234 : Tree 12 := .split 41 q12Shape30T235 q12Shape30T236
private theorem q12Shape30T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 402653184 549336383488 q12Shape30T234=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 402653184 (549336383488 ||| 2^41) q12Shape30T235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (402653184 ||| 2^41) 549336383488 q12Shape30T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T235OK,q12Shape30T236OK⟩

private def q12Shape30T252 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9})))) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape30T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 939524096 1098555326464 q12Shape30T252=true := by decide

private def q12Shape30T253 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape30T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550695337984 548799512576 q12Shape30T253=true := by decide

private def q12Shape30T251 : Tree 12 := .split 39 q12Shape30T252 q12Shape30T253
private theorem q12Shape30T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 939524096 548799512576 q12Shape30T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 939524096 (548799512576 ||| 2^39) q12Shape30T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (939524096 ||| 2^39) 548799512576 q12Shape30T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T252OK,q12Shape30T253OK⟩

private def q12Shape30T233 : Tree 12 := .split 29 q12Shape30T234 q12Shape30T251
private theorem q12Shape30T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 402653184 548799512576 q12Shape30T233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 402653184 (548799512576 ||| 2^29) q12Shape30T234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (402653184 ||| 2^29) 548799512576 q12Shape30T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T234OK,q12Shape30T251OK⟩

private def q12Shape30T213 : Tree 12 := .split 28 q12Shape30T214 q12Shape30T233
private theorem q12Shape30T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 548799512576 q12Shape30T213=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (548799512576 ||| 2^28) q12Shape30T214 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^28) 548799512576 q12Shape30T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T214OK,q12Shape30T233OK⟩

private def q12Shape30T254 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 275012124672 273921605632 q12Shape30T254=true := by decide

private def q12Shape30T212 : Tree 12 := .split 38 q12Shape30T213 q12Shape30T254
private theorem q12Shape30T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 273921605632 q12Shape30T212=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (273921605632 ||| 2^38) q12Shape30T213 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^38) 273921605632 q12Shape30T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T213OK,q12Shape30T254OK⟩

private def q12Shape30T255 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 137573171200 136482652160 q12Shape30T255=true := by decide

private def q12Shape30T211 : Tree 12 := .split 37 q12Shape30T212 q12Shape30T255
private theorem q12Shape30T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 136482652160 q12Shape30T211=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (136482652160 ||| 2^37) q12Shape30T212 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^37) 136482652160 q12Shape30T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T212OK,q12Shape30T255OK⟩

private def q12Shape30T256 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 68853694464 67763175424 q12Shape30T256=true := by decide

private def q12Shape30T210 : Tree 12 := .split 36 q12Shape30T211 q12Shape30T256
private theorem q12Shape30T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 67763175424 q12Shape30T210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (67763175424 ||| 2^36) q12Shape30T211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^36) 67763175424 q12Shape30T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T211OK,q12Shape30T256OK⟩

private def q12Shape30T257 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 34493956096 33403437056 q12Shape30T257=true := by decide

private def q12Shape30T209 : Tree 12 := .split 35 q12Shape30T210 q12Shape30T257
private theorem q12Shape30T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 33403437056 q12Shape30T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (33403437056 ||| 2^35) q12Shape30T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^35) 33403437056 q12Shape30T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T210OK,q12Shape30T257OK⟩

private def q12Shape30T258 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17314086912 16223567872 q12Shape30T258=true := by decide

private def q12Shape30T208 : Tree 12 := .split 34 q12Shape30T209 q12Shape30T258
private theorem q12Shape30T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 16223567872 q12Shape30T208=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (16223567872 ||| 2^34) q12Shape30T209 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^34) 16223567872 q12Shape30T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T209OK,q12Shape30T258OK⟩

private def q12Shape30T259 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8724152320 7633633280 q12Shape30T259=true := by decide

private def q12Shape30T207 : Tree 12 := .split 33 q12Shape30T208 q12Shape30T259
private theorem q12Shape30T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 7633633280 q12Shape30T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (7633633280 ||| 2^33) q12Shape30T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^33) 7633633280 q12Shape30T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T208OK,q12Shape30T259OK⟩

private def q12Shape30T260 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4429185024 3338665984 q12Shape30T260=true := by decide

private def q12Shape30T206 : Tree 12 := .split 32 q12Shape30T207 q12Shape30T260
private theorem q12Shape30T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 3338665984 q12Shape30T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (3338665984 ||| 2^32) q12Shape30T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^32) 3338665984 q12Shape30T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T207OK,q12Shape30T260OK⟩

private def q12Shape30T261 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2281701376 1191182336 q12Shape30T261=true := by decide

private def q12Shape30T205 : Tree 12 := .split 31 q12Shape30T206 q12Shape30T261
private theorem q12Shape30T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 1191182336 q12Shape30T205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 (1191182336 ||| 2^31) q12Shape30T206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (134217728 ||| 2^31) 1191182336 q12Shape30T261)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T206OK,q12Shape30T261OK⟩

def q12Shape30P9 : Tree 12 := q12Shape30T205
theorem q12Shape30P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 134217728 1191182336 q12Shape30P9=true := q12Shape30T205OK

end Graffiti384b.EffectiveSearch.Q12
