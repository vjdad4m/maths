import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape30T265 : Tree 12 := (.tip (.cover {0,2,3,4,7,8,11}))
private theorem q12Shape30T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 67108864 4947181568000 q12Shape30T265=true := by decide

private def q12Shape30T270 : Tree 12 := (.tip (.cover {0,2,3,4,7,8,10}))
private theorem q12Shape30T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 10995032391680 q12Shape30T270=true := by decide

private def q12Shape30T272 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape30T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398650490880 13193518776320 q12Shape30T272=true := by decide

private def q12Shape30T276 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 18 (.split 5 (.split 6 (.split 3 (.tip (.cover {0,1,3,4,5,8,10})) (.tip (.cover {1,3,4,5,6,8,10}))) (.tip (.cover {0,2,3,5,7,8,10}))) (.tip (.cover {0,2,3,4,7,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))))
private theorem q12Shape30T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746432 28586681569296 q12Shape30T276=true := by decide

private def q12Shape30T277 : Tree 12 := (.split 19 (.split 11 (.split 5 (.split 6 (.split 3 (.tip (.cover {0,1,3,4,5,8,10})) (.tip (.cover {1,3,4,5,6,8,10}))) (.tip (.cover {0,2,4,5,7,8,10}))) (.tip (.cover {0,2,3,4,7,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673750528 28586681565200 q12Shape30T277=true := by decide

private def q12Shape30T275 : Tree 12 := .split 12 q12Shape30T276 q12Shape30T277
private theorem q12Shape30T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746432 28586681565200 q12Shape30T275=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746432 (28586681565200 ||| 2^12) q12Shape30T276 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597673746432 ||| 2^12) 28586681565200 q12Shape30T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T276OK,q12Shape30T277OK⟩

private def q12Shape30T278 : Tree 12 := (.split 12 (.split 19 (.split 3 (.split 6 (.tip (.cover {0,3,4,5,7,8,10})) (.tip (.cover {0,1,2,5,6,8,10}))) (.tip (.cover {0,1,2,5,8,9,10}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746448 28586681565184 q12Shape30T278=true := by decide

private def q12Shape30T274 : Tree 12 := .split 4 q12Shape30T275 q12Shape30T278
private theorem q12Shape30T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746432 28586681565184 q12Shape30T274=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746432 (28586681565184 ||| 2^4) q12Shape30T275 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597673746432 ||| 2^4) 28586681565184 q12Shape30T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T275OK,q12Shape30T278OK⟩

private def q12Shape30T279 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape30T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 24189859790848 10994495520768 q12Shape30T279=true := by decide

private def q12Shape30T273 : Tree 12 := .split 44 q12Shape30T274 q12Shape30T279
private theorem q12Shape30T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746432 10994495520768 q12Shape30T273=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597673746432 (10994495520768 ||| 2^44) q12Shape30T274 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597673746432 ||| 2^44) 10994495520768 q12Shape30T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T274OK,q12Shape30T279OK⟩

private def q12Shape30T271 : Tree 12 := .split 41 q12Shape30T272 q12Shape30T273
private theorem q12Shape30T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398650490880 10994495520768 q12Shape30T271=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398650490880 (10994495520768 ||| 2^41) q12Shape30T272 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4398650490880 ||| 2^41) 10994495520768 q12Shape30T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T272OK,q12Shape30T273OK⟩

private def q12Shape30T269 : Tree 12 := .split 29 q12Shape30T270 q12Shape30T271
private theorem q12Shape30T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 10994495520768 q12Shape30T269=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 (10994495520768 ||| 2^29) q12Shape30T270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4398113619968 ||| 2^29) 10994495520768 q12Shape30T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T270OK,q12Shape30T271OK⟩

private def q12Shape30T280 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape30T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 13194206642176 2198402498560 q12Shape30T280=true := by decide

private def q12Shape30T268 : Tree 12 := .split 43 q12Shape30T269 q12Shape30T280
private theorem q12Shape30T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 2198402498560 q12Shape30T268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 (2198402498560 ||| 2^43) q12Shape30T269 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4398113619968 ||| 2^43) 2198402498560 q12Shape30T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T269OK,q12Shape30T280OK⟩

private def q12Shape30T281 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,11}))
private theorem q12Shape30T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5497625247744 1098890870784 q12Shape30T281=true := by decide

private def q12Shape30T267 : Tree 12 := .split 40 q12Shape30T268 q12Shape30T281
private theorem q12Shape30T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 1098890870784 q12Shape30T267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 (1098890870784 ||| 2^40) q12Shape30T268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4398113619968 ||| 2^40) 1098890870784 q12Shape30T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T268OK,q12Shape30T281OK⟩

private def q12Shape30T282 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape30T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4947869433856 549135056896 q12Shape30T282=true := by decide

private def q12Shape30T266 : Tree 12 := .split 39 q12Shape30T267 q12Shape30T282
private theorem q12Shape30T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 549135056896 q12Shape30T266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398113619968 (549135056896 ||| 2^39) q12Shape30T267 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4398113619968 ||| 2^39) 549135056896 q12Shape30T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T267OK,q12Shape30T282OK⟩

private def q12Shape30T264 : Tree 12 := .split 42 q12Shape30T265 q12Shape30T266
private theorem q12Shape30T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 67108864 549135056896 q12Shape30T264=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 67108864 (549135056896 ||| 2^42) q12Shape30T265 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (67108864 ||| 2^42) 549135056896 q12Shape30T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T265OK,q12Shape30T266OK⟩

private def q12Shape30T285 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape30T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 335544320 9345496514560 q12Shape30T285=true := by decide

private def q12Shape30T290 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape30T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 8795740700672 q12Shape30T290=true := by decide

private def q12Shape30T294 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 18 (.split 5 (.split 6 (.split 3 (.tip (.cover {0,1,3,4,5,8,11})) (.tip (.cover {1,3,4,5,6,8,11}))) (.tip (.cover {0,2,3,5,7,8,11}))) (.tip (.cover {0,2,3,4,7,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))))
private theorem q12Shape30T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194304 25288415121424 q12Shape30T294=true := by decide

private def q12Shape30T295 : Tree 12 := (.split 19 (.split 11 (.split 5 (.split 6 (.split 3 (.tip (.cover {0,1,3,4,5,8,11})) (.tip (.cover {1,3,4,5,6,8,11}))) (.tip (.cover {0,2,4,5,7,8,11}))) (.tip (.cover {0,2,3,4,7,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940198400 25288415117328 q12Shape30T295=true := by decide

private def q12Shape30T293 : Tree 12 := .split 12 q12Shape30T294 q12Shape30T295
private theorem q12Shape30T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194304 25288415117328 q12Shape30T293=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194304 (25288415117328 ||| 2^12) q12Shape30T294 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895940194304 ||| 2^12) 25288415117328 q12Shape30T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T294OK,q12Shape30T295OK⟩

private def q12Shape30T296 : Tree 12 := (.split 12 (.split 19 (.split 3 (.split 6 (.tip (.cover {0,3,4,5,7,8,11})) (.tip (.cover {0,1,2,5,6,8,11}))) (.tip (.cover {0,1,2,5,8,9,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194320 25288415117312 q12Shape30T296=true := by decide

private def q12Shape30T292 : Tree 12 := .split 4 q12Shape30T293 q12Shape30T296
private theorem q12Shape30T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194304 25288415117312 q12Shape30T292=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194304 (25288415117312 ||| 2^4) q12Shape30T293 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895940194304 ||| 2^4) 25288415117312 q12Shape30T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T293OK,q12Shape30T296OK⟩

private def q12Shape30T297 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,10}))
private theorem q12Shape30T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 27488126238720 7696229072896 q12Shape30T297=true := by decide

private def q12Shape30T291 : Tree 12 := .split 44 q12Shape30T292 q12Shape30T297
private theorem q12Shape30T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194304 7696229072896 q12Shape30T291=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895940194304 (7696229072896 ||| 2^44) q12Shape30T292 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895940194304 ||| 2^44) 7696229072896 q12Shape30T297)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T292OK,q12Shape30T297OK⟩

private def q12Shape30T289 : Tree 12 := .split 40 q12Shape30T290 q12Shape30T291
private theorem q12Shape30T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 7696229072896 q12Shape30T289=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 (7696229072896 ||| 2^40) q12Shape30T290 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (8796428566528 ||| 2^40) 7696229072896 q12Shape30T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T290OK,q12Shape30T291OK⟩

private def q12Shape30T298 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape30T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 13194475077632 3298182561792 q12Shape30T298=true := by decide

private def q12Shape30T288 : Tree 12 := .split 42 q12Shape30T289 q12Shape30T298
private theorem q12Shape30T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 3298182561792 q12Shape30T288=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 (3298182561792 ||| 2^42) q12Shape30T289 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (8796428566528 ||| 2^42) 3298182561792 q12Shape30T298)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T289OK,q12Shape30T298OK⟩

private def q12Shape30T299 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,10}))
private theorem q12Shape30T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 10995451822080 1099159306240 q12Shape30T299=true := by decide

private def q12Shape30T287 : Tree 12 := .split 41 q12Shape30T288 q12Shape30T299
private theorem q12Shape30T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 1099159306240 q12Shape30T287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 (1099159306240 ||| 2^41) q12Shape30T288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (8796428566528 ||| 2^41) 1099159306240 q12Shape30T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T288OK,q12Shape30T299OK⟩

private def q12Shape30T300 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape30T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9346184380416 549403492352 q12Shape30T300=true := by decide

private def q12Shape30T286 : Tree 12 := .split 39 q12Shape30T287 q12Shape30T300
private theorem q12Shape30T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 549403492352 q12Shape30T286=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8796428566528 (549403492352 ||| 2^39) q12Shape30T287 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (8796428566528 ||| 2^39) 549403492352 q12Shape30T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T287OK,q12Shape30T300OK⟩

private def q12Shape30T284 : Tree 12 := .split 43 q12Shape30T285 q12Shape30T286
private theorem q12Shape30T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 335544320 549403492352 q12Shape30T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 335544320 (549403492352 ||| 2^43) q12Shape30T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (335544320 ||| 2^43) 549403492352 q12Shape30T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T285OK,q12Shape30T286OK⟩

private def q12Shape30T302 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9})))) (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,8,9}))))
private theorem q12Shape30T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 872415232 1098622435328 q12Shape30T302=true := by decide

private def q12Shape30T303 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape30T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550628229120 548866621440 q12Shape30T303=true := by decide

private def q12Shape30T301 : Tree 12 := .split 39 q12Shape30T302 q12Shape30T303
private theorem q12Shape30T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 872415232 548866621440 q12Shape30T301=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 872415232 (548866621440 ||| 2^39) q12Shape30T302 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (872415232 ||| 2^39) 548866621440 q12Shape30T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T302OK,q12Shape30T303OK⟩

private def q12Shape30T283 : Tree 12 := .split 29 q12Shape30T284 q12Shape30T301
private theorem q12Shape30T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 335544320 548866621440 q12Shape30T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 335544320 (548866621440 ||| 2^29) q12Shape30T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (335544320 ||| 2^29) 548866621440 q12Shape30T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T284OK,q12Shape30T301OK⟩

private def q12Shape30T263 : Tree 12 := .split 28 q12Shape30T264 q12Shape30T283
private theorem q12Shape30T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 67108864 548866621440 q12Shape30T263=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 67108864 (548866621440 ||| 2^28) q12Shape30T264 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (67108864 ||| 2^28) 548866621440 q12Shape30T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T264OK,q12Shape30T283OK⟩

def q12Shape30P10 : Tree 12 := q12Shape30T263
theorem q12Shape30P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 67108864 548866621440 q12Shape30P10=true := q12Shape30T263OK

end Graffiti384b.EffectiveSearch.Q12
