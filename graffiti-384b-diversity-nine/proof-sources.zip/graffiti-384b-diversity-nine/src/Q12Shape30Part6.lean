import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape30T358 : Tree 12 := (.tip (.cover {0,2,3,4,7,10,11}))
private theorem q12Shape30T358OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 557255229440 q12Shape30T358=true := by decide

private def q12Shape30T360 : Tree 12 := (.split 36 (.split 40 (.split 33 (.tip (.cover {0,2,3,4,7,9,11})) (.split 37 (.split 38 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape30T360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550829555712 41859153920 q12Shape30T360=true := by decide

private def q12Shape30T361 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T361OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 585189294080 7499415552 q12Shape30T361=true := by decide

private def q12Shape30T359 : Tree 12 := .split 35 q12Shape30T360 q12Shape30T361
private theorem q12Shape30T359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550829555712 7499415552 q12Shape30T359=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 550829555712 (7499415552 ||| 2^35) q12Shape30T360 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (550829555712 ||| 2^35) 7499415552 q12Shape30T361)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T360OK,q12Shape30T361OK⟩

private def q12Shape30T357 : Tree 12 := .split 39 q12Shape30T358 q12Shape30T359
private theorem q12Shape30T357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 7499415552 q12Shape30T357=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 (7499415552 ||| 2^39) q12Shape30T358 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1073741824 ||| 2^39) 7499415552 q12Shape30T359)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T358OK,q12Shape30T359OK⟩

private def q12Shape30T365 : Tree 12 := (.split 38 (.split 39 (.split 42 (.split 40 (.tip (.cover {2,3,4,5,6,7,11})) (.split 33 (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11})))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape30T365OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5368709120 243722616832 q12Shape30T365=true := by decide

private def q12Shape30T366 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T366OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 142807662592 106283663360 q12Shape30T366=true := by decide

private def q12Shape30T364 : Tree 12 := .split 37 q12Shape30T365 q12Shape30T366
private theorem q12Shape30T364OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5368709120 106283663360 q12Shape30T364=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5368709120 (106283663360 ||| 2^37) q12Shape30T365 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (5368709120 ||| 2^37) 106283663360 q12Shape30T366)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T365OK,q12Shape30T366OK⟩

private def q12Shape30T367 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T367OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 74088185856 37564186624 q12Shape30T367=true := by decide

private def q12Shape30T363 : Tree 12 := .split 36 q12Shape30T364 q12Shape30T367
private theorem q12Shape30T363OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5368709120 37564186624 q12Shape30T363=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5368709120 (37564186624 ||| 2^36) q12Shape30T364 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (5368709120 ||| 2^36) 37564186624 q12Shape30T367)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T364OK,q12Shape30T367OK⟩

private def q12Shape30T368 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T368OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 39728447488 3204448256 q12Shape30T368=true := by decide

private def q12Shape30T362 : Tree 12 := .split 35 q12Shape30T363 q12Shape30T368
private theorem q12Shape30T362OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5368709120 3204448256 q12Shape30T362=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5368709120 (3204448256 ||| 2^35) q12Shape30T363 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (5368709120 ||| 2^35) 3204448256 q12Shape30T368)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T363OK,q12Shape30T368OK⟩

private def q12Shape30T356 : Tree 12 := .split 32 q12Shape30T357 q12Shape30T362
private theorem q12Shape30T356OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 3204448256 q12Shape30T356=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 (3204448256 ||| 2^32) q12Shape30T357 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1073741824 ||| 2^32) 3204448256 q12Shape30T362)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T357OK,q12Shape30T362OK⟩

private def q12Shape30T371 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape30T371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3221225472 104136179712 q12Shape30T371=true := by decide

private def q12Shape30T372 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 71940702208 35416702976 q12Shape30T372=true := by decide

private def q12Shape30T370 : Tree 12 := .split 36 q12Shape30T371 q12Shape30T372
private theorem q12Shape30T370OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3221225472 35416702976 q12Shape30T370=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3221225472 (35416702976 ||| 2^36) q12Shape30T371 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (3221225472 ||| 2^36) 35416702976 q12Shape30T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T371OK,q12Shape30T372OK⟩

private def q12Shape30T373 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T373OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 37580963840 1056964608 q12Shape30T373=true := by decide

private def q12Shape30T369 : Tree 12 := .split 35 q12Shape30T370 q12Shape30T373
private theorem q12Shape30T369OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3221225472 1056964608 q12Shape30T369=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3221225472 (1056964608 ||| 2^35) q12Shape30T370 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (3221225472 ||| 2^35) 1056964608 q12Shape30T373)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T370OK,q12Shape30T373OK⟩

private def q12Shape30T355 : Tree 12 := .split 31 q12Shape30T356 q12Shape30T369
private theorem q12Shape30T355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 1056964608 q12Shape30T355=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 (1056964608 ||| 2^31) q12Shape30T356 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1073741824 ||| 2^31) 1056964608 q12Shape30T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T356OK,q12Shape30T369OK⟩

private def q12Shape30T374 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T374OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1610612736 520093696 q12Shape30T374=true := by decide

private def q12Shape30T354 : Tree 12 := .split 29 q12Shape30T355 q12Shape30T374
private theorem q12Shape30T354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 520093696 q12Shape30T354=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 (520093696 ||| 2^29) q12Shape30T355 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1073741824 ||| 2^29) 520093696 q12Shape30T374)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T355OK,q12Shape30T374OK⟩

private def q12Shape30T375 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T375OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1342177280 251658240 q12Shape30T375=true := by decide

private def q12Shape30T353 : Tree 12 := .split 28 q12Shape30T354 q12Shape30T375
private theorem q12Shape30T353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 251658240 q12Shape30T353=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 (251658240 ||| 2^28) q12Shape30T354 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1073741824 ||| 2^28) 251658240 q12Shape30T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T354OK,q12Shape30T375OK⟩

private def q12Shape30T376 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T376OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1207959552 117440512 q12Shape30T376=true := by decide

private def q12Shape30T352 : Tree 12 := .split 27 q12Shape30T353 q12Shape30T376
private theorem q12Shape30T352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 117440512 q12Shape30T352=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 (117440512 ||| 2^27) q12Shape30T353 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1073741824 ||| 2^27) 117440512 q12Shape30T376)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T353OK,q12Shape30T376OK⟩

private def q12Shape30T377 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T377OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1140850688 50331648 q12Shape30T377=true := by decide

private def q12Shape30T351 : Tree 12 := .split 26 q12Shape30T352 q12Shape30T377
private theorem q12Shape30T351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 50331648 q12Shape30T351=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 (50331648 ||| 2^26) q12Shape30T352 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1073741824 ||| 2^26) 50331648 q12Shape30T377)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T352OK,q12Shape30T377OK⟩

def q12Shape30P20 : Tree 12 := q12Shape30T351
theorem q12Shape30P20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1073741824 50331648 q12Shape30P20=true := q12Shape30T351OK

private def q12Shape30T387 : Tree 12 := (.tip (.cover {0,2,3,4,7,10,11}))
private theorem q12Shape30T387OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 583259914240 q12Shape30T387=true := by decide

private def q12Shape30T389 : Tree 12 := (.split 36 (.split 40 (.split 28 (.tip (.cover {0,2,3,4,7,9,11})) (.split 37 (.split 38 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape30T389OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549789368320 67863838720 q12Shape30T389=true := by decide

private def q12Shape30T390 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape30T390OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 584149106688 33504100352 q12Shape30T390=true := by decide

private def q12Shape30T388 : Tree 12 := .split 35 q12Shape30T389 q12Shape30T390
private theorem q12Shape30T388OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549789368320 33504100352 q12Shape30T388=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549789368320 (33504100352 ||| 2^35) q12Shape30T389 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549789368320 ||| 2^35) 33504100352 q12Shape30T390)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T389OK,q12Shape30T390OK⟩

private def q12Shape30T386 : Tree 12 := .split 39 q12Shape30T387 q12Shape30T388
private theorem q12Shape30T386OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 33504100352 q12Shape30T386=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (33504100352 ||| 2^39) q12Shape30T387 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^39) 33504100352 q12Shape30T388)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T387OK,q12Shape30T388OK⟩

private def q12Shape30T394 : Tree 12 := (.split 38 (.split 39 (.split 42 (.split 40 (.tip (.cover {2,3,4,5,6,7,11})) (.split 28 (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11})))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape30T394OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 167772160 273888051200 q12Shape30T394=true := by decide

private def q12Shape30T395 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T395OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 137606725632 136449097728 q12Shape30T395=true := by decide

private def q12Shape30T393 : Tree 12 := .split 37 q12Shape30T394 q12Shape30T395
private theorem q12Shape30T393OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 167772160 136449097728 q12Shape30T393=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 167772160 (136449097728 ||| 2^37) q12Shape30T394 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (167772160 ||| 2^37) 136449097728 q12Shape30T395)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T394OK,q12Shape30T395OK⟩

private def q12Shape30T396 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T396OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 68887248896 67729620992 q12Shape30T396=true := by decide

private def q12Shape30T392 : Tree 12 := .split 36 q12Shape30T393 q12Shape30T396
private theorem q12Shape30T392OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 167772160 67729620992 q12Shape30T392=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 167772160 (67729620992 ||| 2^36) q12Shape30T393 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (167772160 ||| 2^36) 67729620992 q12Shape30T396)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T393OK,q12Shape30T396OK⟩

private def q12Shape30T397 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T397OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 34527510528 33369882624 q12Shape30T397=true := by decide

private def q12Shape30T391 : Tree 12 := .split 35 q12Shape30T392 q12Shape30T397
private theorem q12Shape30T391OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 167772160 33369882624 q12Shape30T391=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 167772160 (33369882624 ||| 2^35) q12Shape30T392 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (167772160 ||| 2^35) 33369882624 q12Shape30T397)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T392OK,q12Shape30T397OK⟩

private def q12Shape30T385 : Tree 12 := .split 27 q12Shape30T386 q12Shape30T391
private theorem q12Shape30T385OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 33369882624 q12Shape30T385=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (33369882624 ||| 2^27) q12Shape30T386 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^27) 33369882624 q12Shape30T391)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T386OK,q12Shape30T391OK⟩

private def q12Shape30T400 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,6,8,10,11})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape30T400OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 100663296 136381988864 q12Shape30T400=true := by decide

private def q12Shape30T401 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T401OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 68820140032 67662512128 q12Shape30T401=true := by decide

private def q12Shape30T399 : Tree 12 := .split 36 q12Shape30T400 q12Shape30T401
private theorem q12Shape30T399OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 100663296 67662512128 q12Shape30T399=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 100663296 (67662512128 ||| 2^36) q12Shape30T400 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (100663296 ||| 2^36) 67662512128 q12Shape30T401)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T400OK,q12Shape30T401OK⟩

private def q12Shape30T402 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T402OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 34460401664 33302773760 q12Shape30T402=true := by decide

private def q12Shape30T398 : Tree 12 := .split 35 q12Shape30T399 q12Shape30T402
private theorem q12Shape30T398OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 100663296 33302773760 q12Shape30T398=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 100663296 (33302773760 ||| 2^35) q12Shape30T399 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (100663296 ||| 2^35) 33302773760 q12Shape30T402)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T399OK,q12Shape30T402OK⟩

private def q12Shape30T384 : Tree 12 := .split 26 q12Shape30T385 q12Shape30T398
private theorem q12Shape30T384OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 33302773760 q12Shape30T384=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (33302773760 ||| 2^26) q12Shape30T385 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^26) 33302773760 q12Shape30T398)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T385OK,q12Shape30T398OK⟩

private def q12Shape30T403 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T403OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17213423616 16122904576 q12Shape30T403=true := by decide

private def q12Shape30T383 : Tree 12 := .split 34 q12Shape30T384 q12Shape30T403
private theorem q12Shape30T383OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 16122904576 q12Shape30T383=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (16122904576 ||| 2^34) q12Shape30T384 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^34) 16122904576 q12Shape30T403)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T384OK,q12Shape30T403OK⟩

private def q12Shape30T404 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T404OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8623489024 7532969984 q12Shape30T404=true := by decide

private def q12Shape30T382 : Tree 12 := .split 33 q12Shape30T383 q12Shape30T404
private theorem q12Shape30T382OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 7532969984 q12Shape30T382=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (7532969984 ||| 2^33) q12Shape30T383 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^33) 7532969984 q12Shape30T404)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T383OK,q12Shape30T404OK⟩

private def q12Shape30T405 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T405OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4328521728 3238002688 q12Shape30T405=true := by decide

private def q12Shape30T381 : Tree 12 := .split 32 q12Shape30T382 q12Shape30T405
private theorem q12Shape30T381OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 3238002688 q12Shape30T381=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (3238002688 ||| 2^32) q12Shape30T382 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^32) 3238002688 q12Shape30T405)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T382OK,q12Shape30T405OK⟩

private def q12Shape30T406 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T406OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2181038080 1090519040 q12Shape30T406=true := by decide

private def q12Shape30T380 : Tree 12 := .split 31 q12Shape30T381 q12Shape30T406
private theorem q12Shape30T380OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 1090519040 q12Shape30T380=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (1090519040 ||| 2^31) q12Shape30T381 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^31) 1090519040 q12Shape30T406)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T381OK,q12Shape30T406OK⟩

private def q12Shape30T407 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T407OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1107296256 16777216 q12Shape30T407=true := by decide

private def q12Shape30T379 : Tree 12 := .split 30 q12Shape30T380 q12Shape30T407
private theorem q12Shape30T379OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 16777216 q12Shape30T379=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 (16777216 ||| 2^30) q12Shape30T380 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (33554432 ||| 2^30) 16777216 q12Shape30T407)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T380OK,q12Shape30T407OK⟩

def q12Shape30P21 : Tree 12 := q12Shape30T379
theorem q12Shape30P21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 33554432 16777216 q12Shape30P21=true := q12Shape30T379OK

end Graffiti384b.EffectiveSearch.Q12
