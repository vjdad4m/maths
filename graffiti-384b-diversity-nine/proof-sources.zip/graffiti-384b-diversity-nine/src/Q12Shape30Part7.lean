import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape30T415 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape30T415OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 6597036212224 q12Shape30T415=true := by decide

private def q12Shape30T418 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape30T418OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398063288320 13194105978880 q12Shape30T418=true := by decide

private def q12Shape30T428 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 5 (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,2,3,5,7,10,11})))) (.split 14 (.tip (.cover {0,1,2,4,5,10,11})) (.tip (.cover {0,2,3,5,7,10,11})))))
private theorem q12Shape30T428OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587269168156 q12Shape30T428=true := by decide

private def q12Shape30T429 : Tree 12 := (.split 19 (.split 13 (.split 14 (.tip (.cover {0,2,4,5,7,10,11})) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T429OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086547968 28587269164060 q12Shape30T429=true := by decide

private def q12Shape30T427 : Tree 12 := .split 12 q12Shape30T428 q12Shape30T429
private theorem q12Shape30T427OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587269164060 q12Shape30T427=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587269164060 ||| 2^12) q12Shape30T428 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^12) 28587269164060 q12Shape30T429)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T428OK,q12Shape30T429OK⟩

private def q12Shape30T430 : Tree 12 := (.split 12 (.split 19 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T430OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543888 28587269164044 q12Shape30T430=true := by decide

private def q12Shape30T426 : Tree 12 := .split 4 q12Shape30T427 q12Shape30T430
private theorem q12Shape30T426OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587269164044 q12Shape30T426=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587269164044 ||| 2^4) q12Shape30T427 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^4) 28587269164044 q12Shape30T430)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T427OK,q12Shape30T430OK⟩

private def q12Shape30T431 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape30T431OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086806016 28587268901900 q12Shape30T431=true := by decide

private def q12Shape30T425 : Tree 12 := .split 18 q12Shape30T426 q12Shape30T431
private theorem q12Shape30T425OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587268901900 q12Shape30T425=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587268901900 ||| 2^18) q12Shape30T426 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^18) 28587268901900 q12Shape30T431)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T426OK,q12Shape30T431OK⟩

private def q12Shape30T432 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape30T432OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086674944 28587268770828 q12Shape30T432=true := by decide

private def q12Shape30T424 : Tree 12 := .split 17 q12Shape30T425 q12Shape30T432
private theorem q12Shape30T424OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587268770828 q12Shape30T424=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587268770828 ||| 2^17) q12Shape30T425 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^17) 28587268770828 q12Shape30T432)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T425OK,q12Shape30T432OK⟩

private def q12Shape30T433 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape30T433OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086545920 28587268768780 q12Shape30T433=true := by decide

private def q12Shape30T423 : Tree 12 := .split 11 q12Shape30T424 q12Shape30T433
private theorem q12Shape30T423OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587268768780 q12Shape30T423=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587268768780 ||| 2^11) q12Shape30T424 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^11) 28587268768780 q12Shape30T433)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T424OK,q12Shape30T433OK⟩

private def q12Shape30T434 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape30T434OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086544896 28587268767756 q12Shape30T434=true := by decide

private def q12Shape30T422 : Tree 12 := .split 10 q12Shape30T423 q12Shape30T434
private theorem q12Shape30T422OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587268767756 q12Shape30T422=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587268767756 ||| 2^10) q12Shape30T423 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^10) 28587268767756 q12Shape30T434)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T423OK,q12Shape30T434OK⟩

private def q12Shape30T435 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape30T435OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543880 28587268767748 q12Shape30T435=true := by decide

private def q12Shape30T421 : Tree 12 := .split 3 q12Shape30T422 q12Shape30T435
private theorem q12Shape30T421OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587268767748 q12Shape30T421=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587268767748 ||| 2^3) q12Shape30T422 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^3) 28587268767748 q12Shape30T435)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T422OK,q12Shape30T435OK⟩

private def q12Shape30T436 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape30T436OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543876 28587268767744 q12Shape30T436=true := by decide

private def q12Shape30T420 : Tree 12 := .split 2 q12Shape30T421 q12Shape30T436
private theorem q12Shape30T420OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 28587268767744 q12Shape30T420=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (28587268767744 ||| 2^2) q12Shape30T421 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^2) 28587268767744 q12Shape30T436)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T421OK,q12Shape30T436OK⟩

private def q12Shape30T437 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,10}))
private theorem q12Shape30T437OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 24189272588288 10995082723328 q12Shape30T437=true := by decide

private def q12Shape30T419 : Tree 12 := .split 44 q12Shape30T420 q12Shape30T437
private theorem q12Shape30T419OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 10995082723328 q12Shape30T419=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 6597086543872 (10995082723328 ||| 2^44) q12Shape30T420 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (6597086543872 ||| 2^44) 10995082723328 q12Shape30T437)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T420OK,q12Shape30T437OK⟩

private def q12Shape30T417 : Tree 12 := .split 41 q12Shape30T418 q12Shape30T419
private theorem q12Shape30T417OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398063288320 10995082723328 q12Shape30T417=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398063288320 (10995082723328 ||| 2^41) q12Shape30T418 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4398063288320 ||| 2^41) 10995082723328 q12Shape30T419)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T418OK,q12Shape30T419OK⟩

private def q12Shape30T438 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape30T438OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 13194156310528 2198989701120 q12Shape30T438=true := by decide

private def q12Shape30T416 : Tree 12 := .split 43 q12Shape30T417 q12Shape30T438
private theorem q12Shape30T416OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398063288320 2198989701120 q12Shape30T416=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4398063288320 (2198989701120 ||| 2^43) q12Shape30T417 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (4398063288320 ||| 2^43) 2198989701120 q12Shape30T438)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T417OK,q12Shape30T438OK⟩

private def q12Shape30T414 : Tree 12 := .split 42 q12Shape30T415 q12Shape30T416
private theorem q12Shape30T414OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 2198989701120 q12Shape30T414=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 (2198989701120 ||| 2^42) q12Shape30T415 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (16777216 ||| 2^42) 2198989701120 q12Shape30T416)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T415OK,q12Shape30T416OK⟩

private def q12Shape30T442 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape30T442OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099528404992 16492640862208 q12Shape30T442=true := by decide

private def q12Shape30T452 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 5 (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,2,3,5,7,10,11})))) (.split 14 (.tip (.cover {0,1,2,4,5,10,11})) (.tip (.cover {0,2,3,5,7,10,11})))))
private theorem q12Shape30T452OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288734284828 q12Shape30T452=true := by decide

private def q12Shape30T453 : Tree 12 := (.split 19 (.split 13 (.split 14 (.tip (.cover {0,2,4,5,7,10,11})) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T453OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621431296 25288734280732 q12Shape30T453=true := by decide

private def q12Shape30T451 : Tree 12 := .split 12 q12Shape30T452 q12Shape30T453
private theorem q12Shape30T451OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288734280732 q12Shape30T451=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288734280732 ||| 2^12) q12Shape30T452 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^12) 25288734280732 q12Shape30T453)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T452OK,q12Shape30T453OK⟩

private def q12Shape30T454 : Tree 12 := (.split 12 (.split 19 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape30T454OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427216 25288734280716 q12Shape30T454=true := by decide

private def q12Shape30T450 : Tree 12 := .split 4 q12Shape30T451 q12Shape30T454
private theorem q12Shape30T450OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288734280716 q12Shape30T450=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288734280716 ||| 2^4) q12Shape30T451 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^4) 25288734280716 q12Shape30T454)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T451OK,q12Shape30T454OK⟩

private def q12Shape30T455 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape30T455OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621689344 25288734018572 q12Shape30T455=true := by decide

private def q12Shape30T449 : Tree 12 := .split 18 q12Shape30T450 q12Shape30T455
private theorem q12Shape30T449OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288734018572 q12Shape30T449=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288734018572 ||| 2^18) q12Shape30T450 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^18) 25288734018572 q12Shape30T455)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T450OK,q12Shape30T455OK⟩

private def q12Shape30T456 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape30T456OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621558272 25288733887500 q12Shape30T456=true := by decide

private def q12Shape30T448 : Tree 12 := .split 17 q12Shape30T449 q12Shape30T456
private theorem q12Shape30T448OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288733887500 q12Shape30T448=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288733887500 ||| 2^17) q12Shape30T449 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^17) 25288733887500 q12Shape30T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T449OK,q12Shape30T456OK⟩

private def q12Shape30T457 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape30T457OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621429248 25288733885452 q12Shape30T457=true := by decide

private def q12Shape30T447 : Tree 12 := .split 11 q12Shape30T448 q12Shape30T457
private theorem q12Shape30T447OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288733885452 q12Shape30T447=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288733885452 ||| 2^11) q12Shape30T448 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^11) 25288733885452 q12Shape30T457)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T448OK,q12Shape30T457OK⟩

private def q12Shape30T458 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape30T458OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621428224 25288733884428 q12Shape30T458=true := by decide

private def q12Shape30T446 : Tree 12 := .split 10 q12Shape30T447 q12Shape30T458
private theorem q12Shape30T446OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288733884428 q12Shape30T446=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288733884428 ||| 2^10) q12Shape30T447 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^10) 25288733884428 q12Shape30T458)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T447OK,q12Shape30T458OK⟩

private def q12Shape30T459 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape30T459OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427208 25288733884420 q12Shape30T459=true := by decide

private def q12Shape30T445 : Tree 12 := .split 3 q12Shape30T446 q12Shape30T459
private theorem q12Shape30T445OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288733884420 q12Shape30T445=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288733884420 ||| 2^3) q12Shape30T446 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^3) 25288733884420 q12Shape30T459)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T446OK,q12Shape30T459OK⟩

private def q12Shape30T460 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,9}))
private theorem q12Shape30T460OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427204 25288733884416 q12Shape30T460=true := by decide

private def q12Shape30T444 : Tree 12 := .split 2 q12Shape30T445 q12Shape30T460
private theorem q12Shape30T444OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 25288733884416 q12Shape30T444=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (25288733884416 ||| 2^2) q12Shape30T445 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^2) 25288733884416 q12Shape30T460)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T445OK,q12Shape30T460OK⟩

private def q12Shape30T461 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,10}))
private theorem q12Shape30T461OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 27487807471616 7696547840000 q12Shape30T461=true := by decide

private def q12Shape30T443 : Tree 12 := .split 44 q12Shape30T444 q12Shape30T461
private theorem q12Shape30T443OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 7696547840000 q12Shape30T443=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9895621427200 (7696547840000 ||| 2^44) q12Shape30T444 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (9895621427200 ||| 2^44) 7696547840000 q12Shape30T461)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T444OK,q12Shape30T461OK⟩

private def q12Shape30T441 : Tree 12 := .split 43 q12Shape30T442 q12Shape30T443
private theorem q12Shape30T441OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099528404992 7696547840000 q12Shape30T441=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099528404992 (7696547840000 ||| 2^43) q12Shape30T442 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1099528404992 ||| 2^43) 7696547840000 q12Shape30T443)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T442OK,q12Shape30T443OK⟩

private def q12Shape30T462 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape30T462OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 5497574916096 3298501328896 q12Shape30T462=true := by decide

private def q12Shape30T440 : Tree 12 := .split 42 q12Shape30T441 q12Shape30T462
private theorem q12Shape30T440OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099528404992 3298501328896 q12Shape30T440=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099528404992 (3298501328896 ||| 2^42) q12Shape30T441 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1099528404992 ||| 2^42) 3298501328896 q12Shape30T462)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T441OK,q12Shape30T462OK⟩

private def q12Shape30T463 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T463OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 3298551660544 1099478073344 q12Shape30T463=true := by decide

private def q12Shape30T439 : Tree 12 := .split 41 q12Shape30T440 q12Shape30T463
private theorem q12Shape30T439OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099528404992 1099478073344 q12Shape30T439=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1099528404992 (1099478073344 ||| 2^41) q12Shape30T440 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (1099528404992 ||| 2^41) 1099478073344 q12Shape30T463)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T440OK,q12Shape30T463OK⟩

private def q12Shape30T413 : Tree 12 := .split 40 q12Shape30T414 q12Shape30T439
private theorem q12Shape30T413OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 1099478073344 q12Shape30T413=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 (1099478073344 ||| 2^40) q12Shape30T414 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (16777216 ||| 2^40) 1099478073344 q12Shape30T439)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T414OK,q12Shape30T439OK⟩

private def q12Shape30T469 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,8}))
private theorem q12Shape30T469OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 34634582720512 q12Shape30T469=true := by decide

private def q12Shape30T478 : Tree 12 := (.split 19 (.tip (.small 1)) (.split 5 (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,2,3,5,7,9,11})))) (.split 15 (.tip (.cover {0,1,2,4,5,9,11})) (.tip (.cover {0,2,3,5,7,9,11})))))
private theorem q12Shape30T478OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042397076508 q12Shape30T478=true := by decide

private def q12Shape30T479 : Tree 12 := (.split 19 (.split 13 (.split 15 (.tip (.cover {0,2,4,5,7,9,11})) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T479OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958639616 17042397072412 q12Shape30T479=true := by decide

private def q12Shape30T477 : Tree 12 := .split 12 q12Shape30T478 q12Shape30T479
private theorem q12Shape30T477OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042397072412 q12Shape30T477=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042397072412 ||| 2^12) q12Shape30T478 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^12) 17042397072412 q12Shape30T479)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T478OK,q12Shape30T479OK⟩

private def q12Shape30T480 : Tree 12 := (.split 12 (.split 19 (.split 5 (.split 7 (.tip (.cover {0,3,4,5,7,9,11})) (.tip (.cover {0,1,2,5,8,9,11}))) (.tip (.cover {0,1,2,5,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,10}))) (.tip (.cover {2,3,4,5,6,8,10})))
private theorem q12Shape30T480OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635536 17042397072396 q12Shape30T480=true := by decide

private def q12Shape30T476 : Tree 12 := .split 4 q12Shape30T477 q12Shape30T480
private theorem q12Shape30T476OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042397072396 q12Shape30T476=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042397072396 ||| 2^4) q12Shape30T477 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^4) 17042397072396 q12Shape30T480)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T477OK,q12Shape30T480OK⟩

private def q12Shape30T481 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,10}))
private theorem q12Shape30T481OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958897664 17042396810252 q12Shape30T481=true := by decide

private def q12Shape30T475 : Tree 12 := .split 18 q12Shape30T476 q12Shape30T481
private theorem q12Shape30T475OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042396810252 q12Shape30T475=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042396810252 ||| 2^18) q12Shape30T476 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^18) 17042396810252 q12Shape30T481)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T476OK,q12Shape30T481OK⟩

private def q12Shape30T482 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape30T482OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958766592 17042396679180 q12Shape30T482=true := by decide

private def q12Shape30T474 : Tree 12 := .split 17 q12Shape30T475 q12Shape30T482
private theorem q12Shape30T474OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042396679180 q12Shape30T474=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042396679180 ||| 2^17) q12Shape30T475 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^17) 17042396679180 q12Shape30T482)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T475OK,q12Shape30T482OK⟩

private def q12Shape30T483 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,10}))
private theorem q12Shape30T483OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958637568 17042396677132 q12Shape30T483=true := by decide

private def q12Shape30T473 : Tree 12 := .split 11 q12Shape30T474 q12Shape30T483
private theorem q12Shape30T473OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042396677132 q12Shape30T473=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042396677132 ||| 2^11) q12Shape30T474 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^11) 17042396677132 q12Shape30T483)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T474OK,q12Shape30T483OK⟩

private def q12Shape30T484 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape30T484OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958636544 17042396676108 q12Shape30T484=true := by decide

private def q12Shape30T472 : Tree 12 := .split 10 q12Shape30T473 q12Shape30T484
private theorem q12Shape30T472OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042396676108 q12Shape30T472=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042396676108 ||| 2^10) q12Shape30T473 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^10) 17042396676108 q12Shape30T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T473OK,q12Shape30T484OK⟩

private def q12Shape30T485 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,10}))
private theorem q12Shape30T485OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635528 17042396676100 q12Shape30T485=true := by decide

private def q12Shape30T471 : Tree 12 := .split 3 q12Shape30T472 q12Shape30T485
private theorem q12Shape30T471OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042396676100 q12Shape30T471=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042396676100 ||| 2^3) q12Shape30T472 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^3) 17042396676100 q12Shape30T485)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T472OK,q12Shape30T485OK⟩

private def q12Shape30T486 : Tree 12 := (.tip (.cover {2,3,4,6,7,8,10}))
private theorem q12Shape30T486OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635524 17042396676096 q12Shape30T486=true := by decide

private def q12Shape30T470 : Tree 12 := .split 2 q12Shape30T471 q12Shape30T486
private theorem q12Shape30T470OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 17042396676096 q12Shape30T470=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 18141958635520 (17042396676096 ||| 2^2) q12Shape30T471 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (18141958635520 ||| 2^2) 17042396676096 q12Shape30T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T471OK,q12Shape30T486OK⟩

private def q12Shape30T468 : Tree 12 := .split 44 q12Shape30T469 q12Shape30T470
private theorem q12Shape30T468OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 17042396676096 q12Shape30T468=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 (17042396676096 ||| 2^44) q12Shape30T469 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549772591104 ||| 2^44) 17042396676096 q12Shape30T470)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T469OK,q12Shape30T470OK⟩

private def q12Shape30T487 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape30T487OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 9345865613312 8246303653888 q12Shape30T487=true := by decide

private def q12Shape30T467 : Tree 12 := .split 43 q12Shape30T468 q12Shape30T487
private theorem q12Shape30T467OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 8246303653888 q12Shape30T467=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 (8246303653888 ||| 2^43) q12Shape30T468 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549772591104 ||| 2^43) 8246303653888 q12Shape30T487)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T468OK,q12Shape30T487OK⟩

private def q12Shape30T488 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape30T488OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4947819102208 3848257142784 q12Shape30T488=true := by decide

private def q12Shape30T466 : Tree 12 := .split 42 q12Shape30T467 q12Shape30T488
private theorem q12Shape30T466OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 3848257142784 q12Shape30T466=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 (3848257142784 ||| 2^42) q12Shape30T467 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549772591104 ||| 2^42) 3848257142784 q12Shape30T488)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T467OK,q12Shape30T488OK⟩

private def q12Shape30T489 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T489OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2748795846656 1649233887232 q12Shape30T489=true := by decide

private def q12Shape30T465 : Tree 12 := .split 41 q12Shape30T466 q12Shape30T489
private theorem q12Shape30T465OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 1649233887232 q12Shape30T465=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 (1649233887232 ||| 2^41) q12Shape30T466 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549772591104 ||| 2^41) 1649233887232 q12Shape30T489)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T466OK,q12Shape30T489OK⟩

private def q12Shape30T490 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T490OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1649284218880 549722259456 q12Shape30T490=true := by decide

private def q12Shape30T464 : Tree 12 := .split 40 q12Shape30T465 q12Shape30T490
private theorem q12Shape30T464OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 549722259456 q12Shape30T464=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 549772591104 (549722259456 ||| 2^40) q12Shape30T465 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (549772591104 ||| 2^40) 549722259456 q12Shape30T490)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T465OK,q12Shape30T490OK⟩

private def q12Shape30T412 : Tree 12 := .split 39 q12Shape30T413 q12Shape30T464
private theorem q12Shape30T412OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 549722259456 q12Shape30T412=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 (549722259456 ||| 2^39) q12Shape30T413 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (16777216 ||| 2^39) 549722259456 q12Shape30T464)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T413OK,q12Shape30T464OK⟩

private def q12Shape30T491 : Tree 12 := (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.split 40 (.tip (.cover {2,3,4,5,7,9,11})) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape30T491OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17196646400 532542390272 q12Shape30T491=true := by decide

private def q12Shape30T411 : Tree 12 := .split 34 q12Shape30T412 q12Shape30T491
private theorem q12Shape30T411OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 532542390272 q12Shape30T411=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 (532542390272 ||| 2^34) q12Shape30T412 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (16777216 ||| 2^34) 532542390272 q12Shape30T491)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T412OK,q12Shape30T491OK⟩

private def q12Shape30T492 : Tree 12 := (.split 39 (.tip (.cover {2,3,4,5,7,10,11})) (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape30T492OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8606711808 523952455680 q12Shape30T492=true := by decide

private def q12Shape30T410 : Tree 12 := .split 33 q12Shape30T411 q12Shape30T492
private theorem q12Shape30T410OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 523952455680 q12Shape30T410=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 (523952455680 ||| 2^33) q12Shape30T411 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (16777216 ||| 2^33) 523952455680 q12Shape30T492)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T411OK,q12Shape30T492OK⟩

private def q12Shape30T493 : Tree 12 := (.split 39 (.split 42 (.split 40 (.tip (.cover {2,3,4,5,6,7,11})) (.split 33 (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11})))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape30T493OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4311744512 519657488384 q12Shape30T493=true := by decide

private def q12Shape30T409 : Tree 12 := .split 32 q12Shape30T410 q12Shape30T493
private theorem q12Shape30T409OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 519657488384 q12Shape30T409=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 (519657488384 ||| 2^32) q12Shape30T410 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (16777216 ||| 2^32) 519657488384 q12Shape30T493)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T410OK,q12Shape30T493OK⟩

def q12Shape30P22 : Tree 12 := q12Shape30T409
theorem q12Shape30P22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 16777216 519657488384 q12Shape30P22=true := q12Shape30T409OK

end Graffiti384b.EffectiveSearch.Q12
