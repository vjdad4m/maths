import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape30T494 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape30T494OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2164260864 517510004736 q12Shape30T494=true := by decide

def q12Shape30P23 : Tree 12 := q12Shape30T494
theorem q12Shape30P23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2164260864 517510004736 q12Shape30P23=true := q12Shape30T494OK

private def q12Shape30T496 : Tree 12 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.split 40 (.tip (.cover {2,3,4,6,7,9,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape30T496OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 553648128 516973133824 q12Shape30T496=true := by decide

def q12Shape30P24 : Tree 12 := q12Shape30T496
theorem q12Shape30P24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 553648128 516973133824 q12Shape30P24=true := q12Shape30T496OK

private def q12Shape30T499 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 39 (.tip (.cover {2,3,4,6,7,10,11})) (.split 40 (.split 41 (.split 44 (.tip (.cover {2,3,4,5,6,7,9})) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape30T499OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 285212672 518852182016 q12Shape30T499=true := by decide

private def q12Shape30T500 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T500OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2432696320 516704698368 q12Shape30T500=true := by decide

private def q12Shape30T498 : Tree 12 := .split 31 q12Shape30T499 q12Shape30T500
private theorem q12Shape30T498OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 285212672 516704698368 q12Shape30T498=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 285212672 (516704698368 ||| 2^31) q12Shape30T499 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (285212672 ||| 2^31) 516704698368 q12Shape30T500)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T499OK,q12Shape30T500OK⟩

def q12Shape30P25 : Tree 12 := q12Shape30T498
theorem q12Shape30P25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 285212672 516704698368 q12Shape30P25=true := q12Shape30T498OK

private def q12Shape30T505 : Tree 12 := (.split 34 (.split 39 (.split 42 (.split 40 (.tip (.cover {2,3,4,5,6,7,11})) (.split 28 (.split 41 (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape30T505OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 531602866176 q12Shape30T505=true := by decide

private def q12Shape30T506 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T506OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8740929536 523012931584 q12Shape30T506=true := by decide

private def q12Shape30T504 : Tree 12 := .split 33 q12Shape30T505 q12Shape30T506
private theorem q12Shape30T504OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 523012931584 q12Shape30T504=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 (523012931584 ||| 2^33) q12Shape30T505 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (150994944 ||| 2^33) 523012931584 q12Shape30T506)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T505OK,q12Shape30T506OK⟩

private def q12Shape30T507 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T507OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4445962240 518717964288 q12Shape30T507=true := by decide

private def q12Shape30T503 : Tree 12 := .split 32 q12Shape30T504 q12Shape30T507
private theorem q12Shape30T503OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 518717964288 q12Shape30T503=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 (518717964288 ||| 2^32) q12Shape30T504 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (150994944 ||| 2^32) 518717964288 q12Shape30T507)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T504OK,q12Shape30T507OK⟩

private def q12Shape30T508 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T508OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2298478592 516570480640 q12Shape30T508=true := by decide

private def q12Shape30T502 : Tree 12 := .split 31 q12Shape30T503 q12Shape30T508
private theorem q12Shape30T502OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 516570480640 q12Shape30T502=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 (516570480640 ||| 2^31) q12Shape30T503 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (150994944 ||| 2^31) 516570480640 q12Shape30T508)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T503OK,q12Shape30T508OK⟩

def q12Shape30P26 : Tree 12 := q12Shape30T502
theorem q12Shape30P26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 150994944 516570480640 q12Shape30P26=true := q12Shape30T502OK

private def q12Shape30T510 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T510OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 274894684160 241692573696 q12Shape30T510=true := by decide

def q12Shape30P27 : Tree 12 := q12Shape30T510
theorem q12Shape30P27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 274894684160 241692573696 q12Shape30P27=true := q12Shape30T510OK

private def q12Shape30T512 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T512OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 137455730688 104253620224 q12Shape30T512=true := by decide

def q12Shape30P28 : Tree 12 := q12Shape30T512
theorem q12Shape30P28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 137455730688 104253620224 q12Shape30P28=true := q12Shape30T512OK

private def q12Shape30T514 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T514OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 68736253952 35534143488 q12Shape30T514=true := by decide

def q12Shape30P29 : Tree 12 := q12Shape30T514
theorem q12Shape30P29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 68736253952 35534143488 q12Shape30P29=true := q12Shape30T514OK

private def q12Shape30T516 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T516OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 34376515584 1174405120 q12Shape30T516=true := by decide

def q12Shape30P30 : Tree 12 := q12Shape30T516
theorem q12Shape30P30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 34376515584 1174405120 q12Shape30P30=true := q12Shape30T516OK

private def q12Shape30T524 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape30T524OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 136398766080 q12Shape30T524=true := by decide

private def q12Shape30T525 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T525OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 68803362816 67679289344 q12Shape30T525=true := by decide

private def q12Shape30T523 : Tree 12 := .split 36 q12Shape30T524 q12Shape30T525
private theorem q12Shape30T523OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 67679289344 q12Shape30T523=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 (67679289344 ||| 2^36) q12Shape30T524 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (83886080 ||| 2^36) 67679289344 q12Shape30T525)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T524OK,q12Shape30T525OK⟩

private def q12Shape30T526 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape30T526OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 34443624448 33319550976 q12Shape30T526=true := by decide

private def q12Shape30T522 : Tree 12 := .split 35 q12Shape30T523 q12Shape30T526
private theorem q12Shape30T522OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 33319550976 q12Shape30T522=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 (33319550976 ||| 2^35) q12Shape30T523 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (83886080 ||| 2^35) 33319550976 q12Shape30T526)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T523OK,q12Shape30T526OK⟩

private def q12Shape30T527 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T527OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 17263755264 16139681792 q12Shape30T527=true := by decide

private def q12Shape30T521 : Tree 12 := .split 34 q12Shape30T522 q12Shape30T527
private theorem q12Shape30T521OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 16139681792 q12Shape30T521=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 (16139681792 ||| 2^34) q12Shape30T522 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (83886080 ||| 2^34) 16139681792 q12Shape30T527)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T522OK,q12Shape30T527OK⟩

private def q12Shape30T528 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T528OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 8673820672 7549747200 q12Shape30T528=true := by decide

private def q12Shape30T520 : Tree 12 := .split 33 q12Shape30T521 q12Shape30T528
private theorem q12Shape30T520OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 7549747200 q12Shape30T520=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 (7549747200 ||| 2^33) q12Shape30T521 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (83886080 ||| 2^33) 7549747200 q12Shape30T528)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T521OK,q12Shape30T528OK⟩

private def q12Shape30T529 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T529OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 4378853376 3254779904 q12Shape30T529=true := by decide

private def q12Shape30T519 : Tree 12 := .split 32 q12Shape30T520 q12Shape30T529
private theorem q12Shape30T519OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 3254779904 q12Shape30T519=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 (3254779904 ||| 2^32) q12Shape30T520 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (83886080 ||| 2^32) 3254779904 q12Shape30T529)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T520OK,q12Shape30T529OK⟩

private def q12Shape30T530 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape30T530OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 2231369728 1107296256 q12Shape30T530=true := by decide

private def q12Shape30T518 : Tree 12 := .split 31 q12Shape30T519 q12Shape30T530
private theorem q12Shape30T518OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 1107296256 q12Shape30T518=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 (1107296256 ||| 2^31) q12Shape30T519 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) (83886080 ||| 2^31) 1107296256 q12Shape30T530)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape30T519OK,q12Shape30T530OK⟩

def q12Shape30P31 : Tree 12 := q12Shape30T518
theorem q12Shape30P31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 83886080 1107296256 q12Shape30P31=true := q12Shape30T518OK

private def q12Shape30T532 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape30T532OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1090519040 33554432 q12Shape30T532=true := by decide

def q12Shape30P32 : Tree 12 := q12Shape30T532
theorem q12Shape30P32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 1090519040 33554432 q12Shape30P32=true := q12Shape30T532OK

private def q12Shape30T534 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape30T534OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 50331648 0 q12Shape30T534=true := by decide

def q12Shape30P33 : Tree 12 := q12Shape30T534
theorem q12Shape30P33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,5,3⟩) 50331648 0 q12Shape30P33=true := q12Shape30T534OK

end Graffiti384b.EffectiveSearch.Q12
