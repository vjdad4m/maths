import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape32T13 : Tree 12 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))))))
private theorem q12Shape32T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2 13 q12Shape32T13=true := by decide

private def q12Shape32T15 : Tree 12 := (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))))))
private theorem q12Shape32T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 10 517 q12Shape32T15=true := by decide

private def q12Shape32T17 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))))
private theorem q12Shape32T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 522 1029 q12Shape32T17=true := by decide

private def q12Shape32T19 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1546 2053 q12Shape32T19=true := by decide

private def q12Shape32T20 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3594 5 q12Shape32T20=true := by decide

private def q12Shape32T18 : Tree 12 := .split 11 q12Shape32T19 q12Shape32T20
private theorem q12Shape32T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1546 5 q12Shape32T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1546 (5 ||| 2^11) q12Shape32T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (1546 ||| 2^11) 5 q12Shape32T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T19OK,q12Shape32T20OK⟩

private def q12Shape32T16 : Tree 12 := .split 10 q12Shape32T17 q12Shape32T18
private theorem q12Shape32T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 522 5 q12Shape32T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 522 (5 ||| 2^10) q12Shape32T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (522 ||| 2^10) 5 q12Shape32T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T17OK,q12Shape32T18OK⟩

private def q12Shape32T14 : Tree 12 := .split 9 q12Shape32T15 q12Shape32T16
private theorem q12Shape32T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 10 5 q12Shape32T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 10 (5 ||| 2^9) q12Shape32T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (10 ||| 2^9) 5 q12Shape32T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T15OK,q12Shape32T16OK⟩

private def q12Shape32T12 : Tree 12 := .split 3 q12Shape32T13 q12Shape32T14
private theorem q12Shape32T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2 5 q12Shape32T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2 (5 ||| 2^3) q12Shape32T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (2 ||| 2^3) 5 q12Shape32T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T13OK,q12Shape32T14OK⟩

private def q12Shape32T23 : Tree 12 := (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11})))))))
private theorem q12Shape32T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 6 521 q12Shape32T23=true := by decide

private def q12Shape32T25 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))))
private theorem q12Shape32T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 518 1033 q12Shape32T25=true := by decide

private def q12Shape32T27 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1542 2057 q12Shape32T27=true := by decide

private def q12Shape32T28 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3590 9 q12Shape32T28=true := by decide

private def q12Shape32T26 : Tree 12 := .split 11 q12Shape32T27 q12Shape32T28
private theorem q12Shape32T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1542 9 q12Shape32T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1542 (9 ||| 2^11) q12Shape32T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (1542 ||| 2^11) 9 q12Shape32T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T27OK,q12Shape32T28OK⟩

private def q12Shape32T24 : Tree 12 := .split 10 q12Shape32T25 q12Shape32T26
private theorem q12Shape32T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 518 9 q12Shape32T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 518 (9 ||| 2^10) q12Shape32T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (518 ||| 2^10) 9 q12Shape32T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T25OK,q12Shape32T26OK⟩

private def q12Shape32T22 : Tree 12 := .split 9 q12Shape32T23 q12Shape32T24
private theorem q12Shape32T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 6 9 q12Shape32T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 6 (9 ||| 2^9) q12Shape32T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (6 ||| 2^9) 9 q12Shape32T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T23OK,q12Shape32T24OK⟩

private def q12Shape32T31 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11}))))))
private theorem q12Shape32T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 14 1537 q12Shape32T31=true := by decide

private def q12Shape32T33 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape32T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1038 2561 q12Shape32T33=true := by decide

private def q12Shape32T34 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {5,6,7,8,9,10,11}))))
private theorem q12Shape32T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3086 513 q12Shape32T34=true := by decide

private def q12Shape32T32 : Tree 12 := .split 11 q12Shape32T33 q12Shape32T34
private theorem q12Shape32T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1038 513 q12Shape32T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1038 (513 ||| 2^11) q12Shape32T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (1038 ||| 2^11) 513 q12Shape32T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T33OK,q12Shape32T34OK⟩

private def q12Shape32T30 : Tree 12 := .split 10 q12Shape32T31 q12Shape32T32
private theorem q12Shape32T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 14 513 q12Shape32T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 14 (513 ||| 2^10) q12Shape32T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (14 ||| 2^10) 513 q12Shape32T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T31OK,q12Shape32T32OK⟩

private def q12Shape32T37 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 526 3073 q12Shape32T37=true := by decide

private def q12Shape32T38 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2574 1025 q12Shape32T38=true := by decide

private def q12Shape32T36 : Tree 12 := .split 11 q12Shape32T37 q12Shape32T38
private theorem q12Shape32T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 526 1025 q12Shape32T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 526 (1025 ||| 2^11) q12Shape32T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (526 ||| 2^11) 1025 q12Shape32T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T37OK,q12Shape32T38OK⟩

private def q12Shape32T39 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11})))) (.tip (.cover {2,3,7,8,9,10,11})))
private theorem q12Shape32T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1550 1 q12Shape32T39=true := by decide

private def q12Shape32T35 : Tree 12 := .split 10 q12Shape32T36 q12Shape32T39
private theorem q12Shape32T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 526 1 q12Shape32T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 526 (1 ||| 2^10) q12Shape32T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (526 ||| 2^10) 1 q12Shape32T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T36OK,q12Shape32T39OK⟩

private def q12Shape32T29 : Tree 12 := .split 9 q12Shape32T30 q12Shape32T35
private theorem q12Shape32T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 14 1 q12Shape32T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 14 (1 ||| 2^9) q12Shape32T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (14 ||| 2^9) 1 q12Shape32T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T30OK,q12Shape32T35OK⟩

private def q12Shape32T21 : Tree 12 := .split 3 q12Shape32T22 q12Shape32T29
private theorem q12Shape32T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 6 1 q12Shape32T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 6 (1 ||| 2^3) q12Shape32T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (6 ||| 2^3) 1 q12Shape32T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T22OK,q12Shape32T29OK⟩

private def q12Shape32T11 : Tree 12 := .split 2 q12Shape32T12 q12Shape32T21
private theorem q12Shape32T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2 1 q12Shape32T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2 (1 ||| 2^2) q12Shape32T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (2 ||| 2^2) 1 q12Shape32T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T12OK,q12Shape32T21OK⟩

def q12Shape32P1 : Tree 12 := q12Shape32T11
theorem q12Shape32P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2 1 q12Shape32P1=true := q12Shape32T11OK

end Graffiti384b.EffectiveSearch.Q12
