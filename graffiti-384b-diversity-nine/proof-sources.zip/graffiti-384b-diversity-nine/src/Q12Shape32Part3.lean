import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape32T69 : Tree 12 := (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10,11}))))))
private theorem q12Shape32T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 524 q12Shape32T69=true := by decide

private def q12Shape32T70 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))) (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape32T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 515 12 q12Shape32T70=true := by decide

private def q12Shape32T68 : Tree 12 := .split 9 q12Shape32T69 q12Shape32T70
private theorem q12Shape32T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 12 q12Shape32T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 (12 ||| 2^9) q12Shape32T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (3 ||| 2^9) 12 q12Shape32T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T69OK,q12Shape32T70OK⟩

private def q12Shape32T73 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11}))))))
private theorem q12Shape32T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 11 1540 q12Shape32T73=true := by decide

private def q12Shape32T75 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10,11})))))
private theorem q12Shape32T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1035 2564 q12Shape32T75=true := by decide

private def q12Shape32T76 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {3,4,7,8,9,10,11}))))
private theorem q12Shape32T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3083 516 q12Shape32T76=true := by decide

private def q12Shape32T74 : Tree 12 := .split 11 q12Shape32T75 q12Shape32T76
private theorem q12Shape32T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1035 516 q12Shape32T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1035 (516 ||| 2^11) q12Shape32T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (1035 ||| 2^11) 516 q12Shape32T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T75OK,q12Shape32T76OK⟩

private def q12Shape32T72 : Tree 12 := .split 10 q12Shape32T73 q12Shape32T74
private theorem q12Shape32T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 11 516 q12Shape32T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 11 (516 ||| 2^10) q12Shape32T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (11 ||| 2^10) 516 q12Shape32T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T73OK,q12Shape32T74OK⟩

private def q12Shape32T78 : Tree 12 := (.split 11 (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 17 (.split 18 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11}))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11})))))
private theorem q12Shape32T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 523 1028 q12Shape32T78=true := by decide

private def q12Shape32T79 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11})))
private theorem q12Shape32T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1547 4 q12Shape32T79=true := by decide

private def q12Shape32T77 : Tree 12 := .split 10 q12Shape32T78 q12Shape32T79
private theorem q12Shape32T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 523 4 q12Shape32T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 523 (4 ||| 2^10) q12Shape32T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (523 ||| 2^10) 4 q12Shape32T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T78OK,q12Shape32T79OK⟩

private def q12Shape32T71 : Tree 12 := .split 9 q12Shape32T72 q12Shape32T77
private theorem q12Shape32T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 11 4 q12Shape32T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 11 (4 ||| 2^9) q12Shape32T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (11 ||| 2^9) 4 q12Shape32T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T72OK,q12Shape32T77OK⟩

private def q12Shape32T67 : Tree 12 := .split 3 q12Shape32T68 q12Shape32T71
private theorem q12Shape32T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 4 q12Shape32T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 (4 ||| 2^3) q12Shape32T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (3 ||| 2^3) 4 q12Shape32T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T68OK,q12Shape32T71OK⟩

private def q12Shape32T83 : Tree 12 := (.split 11 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10,11}))))))
private theorem q12Shape32T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 7 1544 q12Shape32T83=true := by decide

private def q12Shape32T85 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape32T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1031 2568 q12Shape32T85=true := by decide

private def q12Shape32T86 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {3,4,7,8,9,10,11}))))
private theorem q12Shape32T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3079 520 q12Shape32T86=true := by decide

private def q12Shape32T84 : Tree 12 := .split 11 q12Shape32T85 q12Shape32T86
private theorem q12Shape32T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1031 520 q12Shape32T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1031 (520 ||| 2^11) q12Shape32T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (1031 ||| 2^11) 520 q12Shape32T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T85OK,q12Shape32T86OK⟩

private def q12Shape32T82 : Tree 12 := .split 10 q12Shape32T83 q12Shape32T84
private theorem q12Shape32T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 7 520 q12Shape32T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 7 (520 ||| 2^10) q12Shape32T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (7 ||| 2^10) 520 q12Shape32T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T83OK,q12Shape32T84OK⟩

private def q12Shape32T89 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 519 3080 q12Shape32T89=true := by decide

private def q12Shape32T90 : Tree 12 := (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10,11})))) (.split 18 (.split 24 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape32T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 2567 1032 q12Shape32T90=true := by decide

private def q12Shape32T88 : Tree 12 := .split 11 q12Shape32T89 q12Shape32T90
private theorem q12Shape32T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 519 1032 q12Shape32T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 519 (1032 ||| 2^11) q12Shape32T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (519 ||| 2^11) 1032 q12Shape32T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T89OK,q12Shape32T90OK⟩

private def q12Shape32T91 : Tree 12 := (.split 11 (.split 17 (.split 18 (.tip (.small 0)) (.split 24 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10,11})))) (.split 18 (.tip (.cover {0,5,7,8,9,10,11})) (.tip (.cover {0,4,7,8,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11})))
private theorem q12Shape32T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 1543 8 q12Shape32T91=true := by decide

private def q12Shape32T87 : Tree 12 := .split 10 q12Shape32T88 q12Shape32T91
private theorem q12Shape32T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 519 8 q12Shape32T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 519 (8 ||| 2^10) q12Shape32T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (519 ||| 2^10) 8 q12Shape32T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T88OK,q12Shape32T91OK⟩

private def q12Shape32T81 : Tree 12 := .split 9 q12Shape32T82 q12Shape32T87
private theorem q12Shape32T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 7 8 q12Shape32T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 7 (8 ||| 2^9) q12Shape32T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (7 ||| 2^9) 8 q12Shape32T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T82OK,q12Shape32T87OK⟩

private def q12Shape32T92 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape32T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 15 0 q12Shape32T92=true := by decide

private def q12Shape32T80 : Tree 12 := .split 3 q12Shape32T81 q12Shape32T92
private theorem q12Shape32T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 7 0 q12Shape32T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 7 (0 ||| 2^3) q12Shape32T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (7 ||| 2^3) 0 q12Shape32T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T81OK,q12Shape32T92OK⟩

private def q12Shape32T66 : Tree 12 := .split 2 q12Shape32T67 q12Shape32T80
private theorem q12Shape32T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 0 q12Shape32T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 (0 ||| 2^2) q12Shape32T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) (3 ||| 2^2) 0 q12Shape32T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape32T67OK,q12Shape32T80OK⟩

def q12Shape32P3 : Tree 12 := q12Shape32T66
theorem q12Shape32P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,0⟩) 3 0 q12Shape32P3=true := q12Shape32T66OK

end Graffiti384b.EffectiveSearch.Q12
