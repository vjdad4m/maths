import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T2 : Tree 12 := (.tip (.small 0))
private theorem q12Shape33T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 0 396800 q12Shape33T2=true := by decide

private def q12Shape33T4 : Tree 12 := (.tip (.small 0))
private theorem q12Shape33T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262144 16911872 q12Shape33T4=true := by decide

private def q12Shape33T8 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,7,8,11}))))
private theorem q12Shape33T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039360 240518303232 q12Shape33T8=true := by decide

private def q12Shape33T9 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,3,6,7,8,11})))
private theorem q12Shape33T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455992832 103079349760 q12Shape33T9=true := by decide

private def q12Shape33T7 : Tree 12 := .split 37 q12Shape33T8 q12Shape33T9
private theorem q12Shape33T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039360 103079349760 q12Shape33T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039360 (103079349760 ||| 2^37) q12Shape33T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17039360 ||| 2^37) 103079349760 q12Shape33T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T8OK,q12Shape33T9OK⟩

private def q12Shape33T10 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,7,8,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,3,6,7,8,11})))
private theorem q12Shape33T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736516096 34359873024 q12Shape33T10=true := by decide

private def q12Shape33T6 : Tree 12 := .split 36 q12Shape33T7 q12Shape33T10
private theorem q12Shape33T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039360 34359873024 q12Shape33T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039360 (34359873024 ||| 2^36) q12Shape33T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17039360 ||| 2^36) 34359873024 q12Shape33T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T7OK,q12Shape33T10OK⟩

private def q12Shape33T11 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,7,10,11})))
private theorem q12Shape33T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376777728 134656 q12Shape33T11=true := by decide

private def q12Shape33T5 : Tree 12 := .split 35 q12Shape33T6 q12Shape33T11
private theorem q12Shape33T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039360 134656 q12Shape33T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039360 (134656 ||| 2^35) q12Shape33T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17039360 ||| 2^35) 134656 q12Shape33T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T6OK,q12Shape33T11OK⟩

private def q12Shape33T3 : Tree 12 := .split 24 q12Shape33T4 q12Shape33T5
private theorem q12Shape33T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262144 134656 q12Shape33T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262144 (134656 ||| 2^24) q12Shape33T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (262144 ||| 2^24) 134656 q12Shape33T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T4OK,q12Shape33T5OK⟩

private def q12Shape33T1 : Tree 12 := .split 18 q12Shape33T2 q12Shape33T3
private theorem q12Shape33T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 0 134656 q12Shape33T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 0 (134656 ||| 2^18) q12Shape33T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (0 ||| 2^18) 134656 q12Shape33T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T2OK,q12Shape33T3OK⟩

private def q12Shape33T14 : Tree 12 := (.tip (.small 0))
private theorem q12Shape33T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131072 17042944 q12Shape33T14=true := by decide

private def q12Shape33T18 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape33T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908288 240518434304 q12Shape33T18=true := by decide

private def q12Shape33T19 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455861760 103079480832 q12Shape33T19=true := by decide

private def q12Shape33T17 : Tree 12 := .split 37 q12Shape33T18 q12Shape33T19
private theorem q12Shape33T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908288 103079480832 q12Shape33T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908288 (103079480832 ||| 2^37) q12Shape33T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16908288 ||| 2^37) 103079480832 q12Shape33T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T18OK,q12Shape33T19OK⟩

private def q12Shape33T20 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736385024 34360004096 q12Shape33T20=true := by decide

private def q12Shape33T16 : Tree 12 := .split 36 q12Shape33T17 q12Shape33T20
private theorem q12Shape33T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908288 34360004096 q12Shape33T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908288 (34360004096 ||| 2^36) q12Shape33T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16908288 ||| 2^36) 34360004096 q12Shape33T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T17OK,q12Shape33T20OK⟩

private def q12Shape33T21 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape33T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376646656 265728 q12Shape33T21=true := by decide

private def q12Shape33T15 : Tree 12 := .split 35 q12Shape33T16 q12Shape33T21
private theorem q12Shape33T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908288 265728 q12Shape33T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908288 (265728 ||| 2^35) q12Shape33T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16908288 ||| 2^35) 265728 q12Shape33T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T16OK,q12Shape33T21OK⟩

private def q12Shape33T13 : Tree 12 := .split 24 q12Shape33T14 q12Shape33T15
private theorem q12Shape33T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131072 265728 q12Shape33T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131072 (265728 ||| 2^24) q12Shape33T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (131072 ||| 2^24) 265728 q12Shape33T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T14OK,q12Shape33T15OK⟩

private def q12Shape33T26 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 240534949376 q12Shape33T26=true := by decide

private def q12Shape33T27 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439346688 103095995904 q12Shape33T27=true := by decide

private def q12Shape33T25 : Tree 12 := .split 37 q12Shape33T26 q12Shape33T27
private theorem q12Shape33T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 103095995904 q12Shape33T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 (103095995904 ||| 2^37) q12Shape33T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (393216 ||| 2^37) 103095995904 q12Shape33T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T26OK,q12Shape33T27OK⟩

private def q12Shape33T28 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719869952 34376519168 q12Shape33T28=true := by decide

private def q12Shape33T24 : Tree 12 := .split 36 q12Shape33T25 q12Shape33T28
private theorem q12Shape33T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 34376519168 q12Shape33T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 (34376519168 ||| 2^36) q12Shape33T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (393216 ||| 2^36) 34376519168 q12Shape33T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T25OK,q12Shape33T28OK⟩

private def q12Shape33T29 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360131584 16780800 q12Shape33T29=true := by decide

private def q12Shape33T23 : Tree 12 := .split 35 q12Shape33T24 q12Shape33T29
private theorem q12Shape33T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 16780800 q12Shape33T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 (16780800 ||| 2^35) q12Shape33T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (393216 ||| 2^35) 16780800 q12Shape33T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T24OK,q12Shape33T29OK⟩

private def q12Shape33T33 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170432 240518172160 q12Shape33T33=true := by decide

private def q12Shape33T34 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137456123904 103079218688 q12Shape33T34=true := by decide

private def q12Shape33T32 : Tree 12 := .split 37 q12Shape33T33 q12Shape33T34
private theorem q12Shape33T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170432 103079218688 q12Shape33T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170432 (103079218688 ||| 2^37) q12Shape33T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17170432 ||| 2^37) 103079218688 q12Shape33T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T33OK,q12Shape33T34OK⟩

private def q12Shape33T35 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736647168 34359741952 q12Shape33T35=true := by decide

private def q12Shape33T31 : Tree 12 := .split 36 q12Shape33T32 q12Shape33T35
private theorem q12Shape33T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170432 34359741952 q12Shape33T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170432 (34359741952 ||| 2^36) q12Shape33T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17170432 ||| 2^36) 34359741952 q12Shape33T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T32OK,q12Shape33T35OK⟩

private def q12Shape33T36 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376908800 3584 q12Shape33T36=true := by decide

private def q12Shape33T30 : Tree 12 := .split 35 q12Shape33T31 q12Shape33T36
private theorem q12Shape33T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170432 3584 q12Shape33T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170432 (3584 ||| 2^35) q12Shape33T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17170432 ||| 2^35) 3584 q12Shape33T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T31OK,q12Shape33T36OK⟩

private def q12Shape33T22 : Tree 12 := .split 24 q12Shape33T23 q12Shape33T30
private theorem q12Shape33T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 3584 q12Shape33T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393216 (3584 ||| 2^24) q12Shape33T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (393216 ||| 2^24) 3584 q12Shape33T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T23OK,q12Shape33T30OK⟩

private def q12Shape33T12 : Tree 12 := .split 18 q12Shape33T13 q12Shape33T22
private theorem q12Shape33T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131072 3584 q12Shape33T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131072 (3584 ||| 2^18) q12Shape33T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (131072 ||| 2^18) 3584 q12Shape33T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T13OK,q12Shape33T22OK⟩

private def q12Shape33T0 : Tree 12 := .split 17 q12Shape33T1 q12Shape33T12
private theorem q12Shape33T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 0 3584 q12Shape33T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 0 (3584 ||| 2^17) q12Shape33T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (0 ||| 2^17) 3584 q12Shape33T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T1OK,q12Shape33T12OK⟩

def q12Shape33P0 : Tree 12 := q12Shape33T0
theorem q12Shape33P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 0 3584 q12Shape33P0=true := q12Shape33T0OK

end Graffiti384b.EffectiveSearch.Q12
