import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T39 : Tree 12 := (.tip (.small 0))
private theorem q12Shape33T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 2048 17171968 q12Shape33T39=true := by decide

private def q12Shape33T43 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,8,11}))))
private theorem q12Shape33T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16779264 240518563328 q12Shape33T43=true := by decide

private def q12Shape33T44 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,7,8,11})))
private theorem q12Shape33T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455732736 103079609856 q12Shape33T44=true := by decide

private def q12Shape33T42 : Tree 12 := .split 37 q12Shape33T43 q12Shape33T44
private theorem q12Shape33T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16779264 103079609856 q12Shape33T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16779264 (103079609856 ||| 2^37) q12Shape33T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16779264 ||| 2^37) 103079609856 q12Shape33T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T43OK,q12Shape33T44OK⟩

private def q12Shape33T45 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,7,8,11})))
private theorem q12Shape33T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736256000 34360133120 q12Shape33T45=true := by decide

private def q12Shape33T41 : Tree 12 := .split 36 q12Shape33T42 q12Shape33T45
private theorem q12Shape33T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16779264 34360133120 q12Shape33T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16779264 (34360133120 ||| 2^36) q12Shape33T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16779264 ||| 2^36) 34360133120 q12Shape33T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T42OK,q12Shape33T45OK⟩

private def q12Shape33T46 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape33T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376517632 394752 q12Shape33T46=true := by decide

private def q12Shape33T40 : Tree 12 := .split 35 q12Shape33T41 q12Shape33T46
private theorem q12Shape33T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16779264 394752 q12Shape33T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16779264 (394752 ||| 2^35) q12Shape33T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16779264 ||| 2^35) 394752 q12Shape33T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T41OK,q12Shape33T46OK⟩

private def q12Shape33T38 : Tree 12 := .split 24 q12Shape33T39 q12Shape33T40
private theorem q12Shape33T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 2048 394752 q12Shape33T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 2048 (394752 ||| 2^24) q12Shape33T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (2048 ||| 2^24) 394752 q12Shape33T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T39OK,q12Shape33T40OK⟩

private def q12Shape33T51 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,8,11}))))
private theorem q12Shape33T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 240535078400 q12Shape33T51=true := by decide

private def q12Shape33T52 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape33T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439217664 103096124928 q12Shape33T52=true := by decide

private def q12Shape33T50 : Tree 12 := .split 37 q12Shape33T51 q12Shape33T52
private theorem q12Shape33T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 103096124928 q12Shape33T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 (103096124928 ||| 2^37) q12Shape33T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (264192 ||| 2^37) 103096124928 q12Shape33T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T51OK,q12Shape33T52OK⟩

private def q12Shape33T53 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape33T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719740928 34376648192 q12Shape33T53=true := by decide

private def q12Shape33T49 : Tree 12 := .split 36 q12Shape33T50 q12Shape33T53
private theorem q12Shape33T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 34376648192 q12Shape33T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 (34376648192 ||| 2^36) q12Shape33T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (264192 ||| 2^36) 34376648192 q12Shape33T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T50OK,q12Shape33T53OK⟩

private def q12Shape33T54 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape33T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360002560 16909824 q12Shape33T54=true := by decide

private def q12Shape33T48 : Tree 12 := .split 35 q12Shape33T49 q12Shape33T54
private theorem q12Shape33T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 16909824 q12Shape33T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 (16909824 ||| 2^35) q12Shape33T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (264192 ||| 2^35) 16909824 q12Shape33T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T49OK,q12Shape33T54OK⟩

private def q12Shape33T55 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape33T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17041408 132608 q12Shape33T55=true := by decide

private def q12Shape33T47 : Tree 12 := .split 24 q12Shape33T48 q12Shape33T55
private theorem q12Shape33T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 132608 q12Shape33T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 264192 (132608 ||| 2^24) q12Shape33T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (264192 ||| 2^24) 132608 q12Shape33T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T48OK,q12Shape33T55OK⟩

private def q12Shape33T37 : Tree 12 := .split 18 q12Shape33T38 q12Shape33T47
private theorem q12Shape33T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 2048 132608 q12Shape33T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 2048 (132608 ||| 2^18) q12Shape33T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (2048 ||| 2^18) 132608 q12Shape33T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T38OK,q12Shape33T47OK⟩

def q12Shape33P1 : Tree 12 := q12Shape33T37
theorem q12Shape33P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 2048 132608 q12Shape33P1=true := q12Shape33T37OK

end Graffiti384b.EffectiveSearch.Q12
