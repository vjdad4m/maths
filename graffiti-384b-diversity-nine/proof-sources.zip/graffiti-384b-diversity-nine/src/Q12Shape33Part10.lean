import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T250 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 240535208960 q12Shape33T250=true := by decide

private def q12Shape33T251 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439087104 103096255488 q12Shape33T251=true := by decide

private def q12Shape33T249 : Tree 12 := .split 37 q12Shape33T250 q12Shape33T251
private theorem q12Shape33T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 103096255488 q12Shape33T249=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 (103096255488 ||| 2^37) q12Shape33T250 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133632 ||| 2^37) 103096255488 q12Shape33T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T250OK,q12Shape33T251OK⟩

private def q12Shape33T252 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719610368 34376778752 q12Shape33T252=true := by decide

private def q12Shape33T248 : Tree 12 := .split 36 q12Shape33T249 q12Shape33T252
private theorem q12Shape33T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 34376778752 q12Shape33T248=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 (34376778752 ||| 2^36) q12Shape33T249 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133632 ||| 2^36) 34376778752 q12Shape33T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T249OK,q12Shape33T252OK⟩

private def q12Shape33T253 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359872000 17040384 q12Shape33T253=true := by decide

private def q12Shape33T247 : Tree 12 := .split 35 q12Shape33T248 q12Shape33T253
private theorem q12Shape33T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 17040384 q12Shape33T247=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 (17040384 ||| 2^35) q12Shape33T248 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133632 ||| 2^35) 17040384 q12Shape33T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T248OK,q12Shape33T253OK⟩

private def q12Shape33T257 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,9,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {2,3,5,7,9,10,11}))))
private theorem q12Shape33T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910848 240518431744 q12Shape33T257=true := by decide

private def q12Shape33T258 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,9,11}))) (.tip (.cover {2,3,5,7,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455864320 103079478272 q12Shape33T258=true := by decide

private def q12Shape33T256 : Tree 12 := .split 37 q12Shape33T257 q12Shape33T258
private theorem q12Shape33T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910848 103079478272 q12Shape33T256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910848 (103079478272 ||| 2^37) q12Shape33T257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16910848 ||| 2^37) 103079478272 q12Shape33T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T257OK,q12Shape33T258OK⟩

private def q12Shape33T259 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {2,3,5,8,9,10,11})))
private theorem q12Shape33T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736387584 34360001536 q12Shape33T259=true := by decide

private def q12Shape33T255 : Tree 12 := .split 36 q12Shape33T256 q12Shape33T259
private theorem q12Shape33T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910848 34360001536 q12Shape33T255=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910848 (34360001536 ||| 2^36) q12Shape33T256 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16910848 ||| 2^36) 34360001536 q12Shape33T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T256OK,q12Shape33T259OK⟩

private def q12Shape33T260 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {2,3,5,8,9,10,11}))) (.tip (.cover {2,3,5,8,9,10,11})))
private theorem q12Shape33T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376649216 263168 q12Shape33T260=true := by decide

private def q12Shape33T254 : Tree 12 := .split 35 q12Shape33T255 q12Shape33T260
private theorem q12Shape33T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910848 263168 q12Shape33T254=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910848 (263168 ||| 2^35) q12Shape33T255 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16910848 ||| 2^35) 263168 q12Shape33T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T255OK,q12Shape33T260OK⟩

private def q12Shape33T246 : Tree 12 := .split 24 q12Shape33T247 q12Shape33T254
private theorem q12Shape33T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 263168 q12Shape33T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 (263168 ||| 2^24) q12Shape33T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133632 ||| 2^24) 263168 q12Shape33T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T247OK,q12Shape33T254OK⟩

private def q12Shape33T262 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape33T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395776 16778240 q12Shape33T262=true := by decide

private def q12Shape33T263 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape33T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17172992 1024 q12Shape33T263=true := by decide

private def q12Shape33T261 : Tree 12 := .split 24 q12Shape33T262 q12Shape33T263
private theorem q12Shape33T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395776 1024 q12Shape33T261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395776 (1024 ||| 2^24) q12Shape33T262 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (395776 ||| 2^24) 1024 q12Shape33T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T262OK,q12Shape33T263OK⟩

private def q12Shape33T245 : Tree 12 := .split 18 q12Shape33T246 q12Shape33T261
private theorem q12Shape33T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 1024 q12Shape33T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 (1024 ||| 2^18) q12Shape33T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133632 ||| 2^18) 1024 q12Shape33T261)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T246OK,q12Shape33T261OK⟩

def q12Shape33P10 : Tree 12 := q12Shape33T245
theorem q12Shape33P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133632 1024 q12Shape33P10=true := q12Shape33T245OK

end Graffiti384b.EffectiveSearch.Q12
