import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T271 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,7,8,11}))))
private theorem q12Shape33T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 240535341056 q12Shape33T271=true := by decide

private def q12Shape33T272 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,3,6,7,8,11})))
private theorem q12Shape33T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137438955008 103096387584 q12Shape33T272=true := by decide

private def q12Shape33T270 : Tree 12 := .split 37 q12Shape33T271 q12Shape33T272
private theorem q12Shape33T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 103096387584 q12Shape33T270=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 (103096387584 ||| 2^37) q12Shape33T271 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (1536 ||| 2^37) 103096387584 q12Shape33T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T271OK,q12Shape33T272OK⟩

private def q12Shape33T273 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,7,8,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,3,6,7,8,11})))
private theorem q12Shape33T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719478272 34376910848 q12Shape33T273=true := by decide

private def q12Shape33T269 : Tree 12 := .split 36 q12Shape33T270 q12Shape33T273
private theorem q12Shape33T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 34376910848 q12Shape33T269=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 (34376910848 ||| 2^36) q12Shape33T270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (1536 ||| 2^36) 34376910848 q12Shape33T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T270OK,q12Shape33T273OK⟩

private def q12Shape33T274 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,7,10,11})))
private theorem q12Shape33T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359739904 17172480 q12Shape33T274=true := by decide

private def q12Shape33T268 : Tree 12 := .split 35 q12Shape33T269 q12Shape33T274
private theorem q12Shape33T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 17172480 q12Shape33T268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 (17172480 ||| 2^35) q12Shape33T269 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (1536 ||| 2^35) 17172480 q12Shape33T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T269OK,q12Shape33T274OK⟩

private def q12Shape33T278 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape33T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778752 240518563840 q12Shape33T278=true := by decide

private def q12Shape33T279 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455732224 103079610368 q12Shape33T279=true := by decide

private def q12Shape33T277 : Tree 12 := .split 37 q12Shape33T278 q12Shape33T279
private theorem q12Shape33T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778752 103079610368 q12Shape33T277=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778752 (103079610368 ||| 2^37) q12Shape33T278 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16778752 ||| 2^37) 103079610368 q12Shape33T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T278OK,q12Shape33T279OK⟩

private def q12Shape33T280 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736255488 34360133632 q12Shape33T280=true := by decide

private def q12Shape33T276 : Tree 12 := .split 36 q12Shape33T277 q12Shape33T280
private theorem q12Shape33T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778752 34360133632 q12Shape33T276=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778752 (34360133632 ||| 2^36) q12Shape33T277 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16778752 ||| 2^36) 34360133632 q12Shape33T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T277OK,q12Shape33T280OK⟩

private def q12Shape33T281 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape33T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376517120 395264 q12Shape33T281=true := by decide

private def q12Shape33T275 : Tree 12 := .split 35 q12Shape33T276 q12Shape33T281
private theorem q12Shape33T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778752 395264 q12Shape33T275=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778752 (395264 ||| 2^35) q12Shape33T276 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16778752 ||| 2^35) 395264 q12Shape33T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T276OK,q12Shape33T281OK⟩

private def q12Shape33T267 : Tree 12 := .split 24 q12Shape33T268 q12Shape33T275
private theorem q12Shape33T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 395264 q12Shape33T267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 (395264 ||| 2^24) q12Shape33T268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (1536 ||| 2^24) 395264 q12Shape33T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T268OK,q12Shape33T275OK⟩

private def q12Shape33T286 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 240535078912 q12Shape33T286=true := by decide

private def q12Shape33T287 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439217152 103096125440 q12Shape33T287=true := by decide

private def q12Shape33T285 : Tree 12 := .split 37 q12Shape33T286 q12Shape33T287
private theorem q12Shape33T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 103096125440 q12Shape33T285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 (103096125440 ||| 2^37) q12Shape33T286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263680 ||| 2^37) 103096125440 q12Shape33T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T286OK,q12Shape33T287OK⟩

private def q12Shape33T288 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719740416 34376648704 q12Shape33T288=true := by decide

private def q12Shape33T284 : Tree 12 := .split 36 q12Shape33T285 q12Shape33T288
private theorem q12Shape33T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 34376648704 q12Shape33T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 (34376648704 ||| 2^36) q12Shape33T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263680 ||| 2^36) 34376648704 q12Shape33T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T285OK,q12Shape33T288OK⟩

private def q12Shape33T289 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360002048 16910336 q12Shape33T289=true := by decide

private def q12Shape33T283 : Tree 12 := .split 35 q12Shape33T284 q12Shape33T289
private theorem q12Shape33T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 16910336 q12Shape33T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 (16910336 ||| 2^35) q12Shape33T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263680 ||| 2^35) 16910336 q12Shape33T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T284OK,q12Shape33T289OK⟩

private def q12Shape33T293 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,9,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {2,3,6,7,9,10,11}))))
private theorem q12Shape33T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040896 240518301696 q12Shape33T293=true := by decide

private def q12Shape33T294 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,9,11}))) (.tip (.cover {2,3,6,7,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455994368 103079348224 q12Shape33T294=true := by decide

private def q12Shape33T292 : Tree 12 := .split 37 q12Shape33T293 q12Shape33T294
private theorem q12Shape33T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040896 103079348224 q12Shape33T292=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040896 (103079348224 ||| 2^37) q12Shape33T293 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17040896 ||| 2^37) 103079348224 q12Shape33T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T293OK,q12Shape33T294OK⟩

private def q12Shape33T295 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {2,3,6,8,9,10,11})))
private theorem q12Shape33T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736517632 34359871488 q12Shape33T295=true := by decide

private def q12Shape33T291 : Tree 12 := .split 36 q12Shape33T292 q12Shape33T295
private theorem q12Shape33T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040896 34359871488 q12Shape33T291=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040896 (34359871488 ||| 2^36) q12Shape33T292 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17040896 ||| 2^36) 34359871488 q12Shape33T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T292OK,q12Shape33T295OK⟩

private def q12Shape33T296 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {2,3,6,7,9,10,11}))) (.tip (.cover {2,3,6,7,9,10,11}))) (.tip (.cover {2,3,6,8,9,10,11}))) (.tip (.cover {2,3,6,8,9,10,11})))
private theorem q12Shape33T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376779264 133120 q12Shape33T296=true := by decide

private def q12Shape33T290 : Tree 12 := .split 35 q12Shape33T291 q12Shape33T296
private theorem q12Shape33T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040896 133120 q12Shape33T290=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040896 (133120 ||| 2^35) q12Shape33T291 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17040896 ||| 2^35) 133120 q12Shape33T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T291OK,q12Shape33T296OK⟩

private def q12Shape33T282 : Tree 12 := .split 24 q12Shape33T283 q12Shape33T290
private theorem q12Shape33T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 133120 q12Shape33T282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263680 (133120 ||| 2^24) q12Shape33T283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263680 ||| 2^24) 133120 q12Shape33T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T283OK,q12Shape33T290OK⟩

private def q12Shape33T266 : Tree 12 := .split 18 q12Shape33T267 q12Shape33T282
private theorem q12Shape33T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 133120 q12Shape33T266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 (133120 ||| 2^18) q12Shape33T267 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (1536 ||| 2^18) 133120 q12Shape33T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T267OK,q12Shape33T282OK⟩

def q12Shape33P11 : Tree 12 := q12Shape33T266
theorem q12Shape33P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1536 133120 q12Shape33P11=true := q12Shape33T266OK

end Graffiti384b.EffectiveSearch.Q12
