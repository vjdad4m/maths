import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T302 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,7,8,11}))))
private theorem q12Shape33T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 240535209984 q12Shape33T302=true := by decide

private def q12Shape33T303 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,3,6,7,8,11})))
private theorem q12Shape33T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439086080 103096256512 q12Shape33T303=true := by decide

private def q12Shape33T301 : Tree 12 := .split 37 q12Shape33T302 q12Shape33T303
private theorem q12Shape33T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 103096256512 q12Shape33T301=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 (103096256512 ||| 2^37) q12Shape33T302 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132608 ||| 2^37) 103096256512 q12Shape33T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T302OK,q12Shape33T303OK⟩

private def q12Shape33T304 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,7,8,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,3,6,7,8,11})))
private theorem q12Shape33T304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719609344 34376779776 q12Shape33T304=true := by decide

private def q12Shape33T300 : Tree 12 := .split 36 q12Shape33T301 q12Shape33T304
private theorem q12Shape33T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 34376779776 q12Shape33T300=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 (34376779776 ||| 2^36) q12Shape33T301 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132608 ||| 2^36) 34376779776 q12Shape33T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T301OK,q12Shape33T304OK⟩

private def q12Shape33T305 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,7,9,11}))) (.tip (.cover {0,1,3,6,7,10,11})))
private theorem q12Shape33T305OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359870976 17041408 q12Shape33T305=true := by decide

private def q12Shape33T299 : Tree 12 := .split 35 q12Shape33T300 q12Shape33T305
private theorem q12Shape33T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 17041408 q12Shape33T299=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 (17041408 ||| 2^35) q12Shape33T300 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132608 ||| 2^35) 17041408 q12Shape33T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T300OK,q12Shape33T305OK⟩

private def q12Shape33T306 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape33T306OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16909824 264192 q12Shape33T306=true := by decide

private def q12Shape33T298 : Tree 12 := .split 24 q12Shape33T299 q12Shape33T306
private theorem q12Shape33T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 264192 q12Shape33T298=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 (264192 ||| 2^24) q12Shape33T299 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132608 ||| 2^24) 264192 q12Shape33T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T299OK,q12Shape33T306OK⟩

private def q12Shape33T308 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape33T308OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394752 16779264 q12Shape33T308=true := by decide

private def q12Shape33T309 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape33T309OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17171968 2048 q12Shape33T309=true := by decide

private def q12Shape33T307 : Tree 12 := .split 24 q12Shape33T308 q12Shape33T309
private theorem q12Shape33T307OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394752 2048 q12Shape33T307=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394752 (2048 ||| 2^24) q12Shape33T308 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (394752 ||| 2^24) 2048 q12Shape33T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T308OK,q12Shape33T309OK⟩

private def q12Shape33T297 : Tree 12 := .split 18 q12Shape33T298 q12Shape33T307
private theorem q12Shape33T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 2048 q12Shape33T297=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 (2048 ||| 2^18) q12Shape33T298 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132608 ||| 2^18) 2048 q12Shape33T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T298OK,q12Shape33T307OK⟩

def q12Shape33P12 : Tree 12 := q12Shape33T297
theorem q12Shape33P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132608 2048 q12Shape33P12=true := q12Shape33T297OK

private def q12Shape33T314 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T314OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 17170432 q12Shape33T314=true := by decide

private def q12Shape33T315 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T315OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780800 393216 q12Shape33T315=true := by decide

private def q12Shape33T313 : Tree 12 := .split 24 q12Shape33T314 q12Shape33T315
private theorem q12Shape33T313OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 393216 q12Shape33T313=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 (393216 ||| 2^24) q12Shape33T314 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3584 ||| 2^24) 393216 q12Shape33T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T314OK,q12Shape33T315OK⟩

private def q12Shape33T317 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T317OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265728 16908288 q12Shape33T317=true := by decide

private def q12Shape33T318 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T318OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17042944 131072 q12Shape33T318=true := by decide

private def q12Shape33T316 : Tree 12 := .split 24 q12Shape33T317 q12Shape33T318
private theorem q12Shape33T316OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265728 131072 q12Shape33T316=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265728 (131072 ||| 2^24) q12Shape33T317 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (265728 ||| 2^24) 131072 q12Shape33T318)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T317OK,q12Shape33T318OK⟩

private def q12Shape33T312 : Tree 12 := .split 18 q12Shape33T313 q12Shape33T316
private theorem q12Shape33T312OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 131072 q12Shape33T312=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 (131072 ||| 2^18) q12Shape33T313 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3584 ||| 2^18) 131072 q12Shape33T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T313OK,q12Shape33T316OK⟩

private def q12Shape33T321 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T321OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134656 17039360 q12Shape33T321=true := by decide

private def q12Shape33T322 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T322OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16911872 262144 q12Shape33T322=true := by decide

private def q12Shape33T320 : Tree 12 := .split 24 q12Shape33T321 q12Shape33T322
private theorem q12Shape33T320OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134656 262144 q12Shape33T320=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134656 (262144 ||| 2^24) q12Shape33T321 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (134656 ||| 2^24) 262144 q12Shape33T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T321OK,q12Shape33T322OK⟩

private def q12Shape33T324 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T324OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396800 16777216 q12Shape33T324=true := by decide

private def q12Shape33T325 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape33T325OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17174016 0 q12Shape33T325=true := by decide

private def q12Shape33T323 : Tree 12 := .split 24 q12Shape33T324 q12Shape33T325
private theorem q12Shape33T323OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396800 0 q12Shape33T323=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396800 (0 ||| 2^24) q12Shape33T324 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (396800 ||| 2^24) 0 q12Shape33T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T324OK,q12Shape33T325OK⟩

private def q12Shape33T319 : Tree 12 := .split 18 q12Shape33T320 q12Shape33T323
private theorem q12Shape33T319OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134656 0 q12Shape33T319=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134656 (0 ||| 2^18) q12Shape33T320 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (134656 ||| 2^18) 0 q12Shape33T323)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T320OK,q12Shape33T323OK⟩

private def q12Shape33T311 : Tree 12 := .split 17 q12Shape33T312 q12Shape33T319
private theorem q12Shape33T311OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 0 q12Shape33T311=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 (0 ||| 2^17) q12Shape33T312 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3584 ||| 2^17) 0 q12Shape33T319)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T312OK,q12Shape33T319OK⟩

def q12Shape33P13 : Tree 12 := q12Shape33T311
theorem q12Shape33P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3584 0 q12Shape33P13=true := q12Shape33T311OK

end Graffiti384b.EffectiveSearch.Q12
