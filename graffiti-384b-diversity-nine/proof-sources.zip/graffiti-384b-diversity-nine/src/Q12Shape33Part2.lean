import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T61 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 240535209472 q12Shape33T61=true := by decide

private def q12Shape33T62 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439086592 103096256000 q12Shape33T62=true := by decide

private def q12Shape33T60 : Tree 12 := .split 37 q12Shape33T61 q12Shape33T62
private theorem q12Shape33T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 103096256000 q12Shape33T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 (103096256000 ||| 2^37) q12Shape33T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133120 ||| 2^37) 103096256000 q12Shape33T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T61OK,q12Shape33T62OK⟩

private def q12Shape33T63 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719609856 34376779264 q12Shape33T63=true := by decide

private def q12Shape33T59 : Tree 12 := .split 36 q12Shape33T60 q12Shape33T63
private theorem q12Shape33T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 34376779264 q12Shape33T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 (34376779264 ||| 2^36) q12Shape33T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133120 ||| 2^36) 34376779264 q12Shape33T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T60OK,q12Shape33T63OK⟩

private def q12Shape33T64 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359871488 17040896 q12Shape33T64=true := by decide

private def q12Shape33T58 : Tree 12 := .split 35 q12Shape33T59 q12Shape33T64
private theorem q12Shape33T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 17040896 q12Shape33T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 (17040896 ||| 2^35) q12Shape33T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133120 ||| 2^35) 17040896 q12Shape33T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T59OK,q12Shape33T64OK⟩

private def q12Shape33T68 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910336 240518432256 q12Shape33T68=true := by decide

private def q12Shape33T69 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455863808 103079478784 q12Shape33T69=true := by decide

private def q12Shape33T67 : Tree 12 := .split 37 q12Shape33T68 q12Shape33T69
private theorem q12Shape33T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910336 103079478784 q12Shape33T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910336 (103079478784 ||| 2^37) q12Shape33T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16910336 ||| 2^37) 103079478784 q12Shape33T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T68OK,q12Shape33T69OK⟩

private def q12Shape33T70 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736387072 34360002048 q12Shape33T70=true := by decide

private def q12Shape33T66 : Tree 12 := .split 36 q12Shape33T67 q12Shape33T70
private theorem q12Shape33T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910336 34360002048 q12Shape33T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910336 (34360002048 ||| 2^36) q12Shape33T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16910336 ||| 2^36) 34360002048 q12Shape33T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T67OK,q12Shape33T70OK⟩

private def q12Shape33T71 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376648704 263680 q12Shape33T71=true := by decide

private def q12Shape33T65 : Tree 12 := .split 35 q12Shape33T66 q12Shape33T71
private theorem q12Shape33T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910336 263680 q12Shape33T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16910336 (263680 ||| 2^35) q12Shape33T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16910336 ||| 2^35) 263680 q12Shape33T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T66OK,q12Shape33T71OK⟩

private def q12Shape33T57 : Tree 12 := .split 24 q12Shape33T58 q12Shape33T65
private theorem q12Shape33T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 263680 q12Shape33T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 (263680 ||| 2^24) q12Shape33T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133120 ||| 2^24) 263680 q12Shape33T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T58OK,q12Shape33T65OK⟩

private def q12Shape33T76 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 240534947328 q12Shape33T76=true := by decide

private def q12Shape33T77 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439348736 103095993856 q12Shape33T77=true := by decide

private def q12Shape33T75 : Tree 12 := .split 37 q12Shape33T76 q12Shape33T77
private theorem q12Shape33T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 103095993856 q12Shape33T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 (103095993856 ||| 2^37) q12Shape33T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (395264 ||| 2^37) 103095993856 q12Shape33T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T76OK,q12Shape33T77OK⟩

private def q12Shape33T78 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719872000 34376517120 q12Shape33T78=true := by decide

private def q12Shape33T74 : Tree 12 := .split 36 q12Shape33T75 q12Shape33T78
private theorem q12Shape33T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 34376517120 q12Shape33T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 (34376517120 ||| 2^36) q12Shape33T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (395264 ||| 2^36) 34376517120 q12Shape33T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T75OK,q12Shape33T78OK⟩

private def q12Shape33T79 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360133632 16778752 q12Shape33T79=true := by decide

private def q12Shape33T73 : Tree 12 := .split 35 q12Shape33T74 q12Shape33T79
private theorem q12Shape33T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 16778752 q12Shape33T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 (16778752 ||| 2^35) q12Shape33T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (395264 ||| 2^35) 16778752 q12Shape33T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T74OK,q12Shape33T79OK⟩

private def q12Shape33T80 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape33T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17172480 1536 q12Shape33T80=true := by decide

private def q12Shape33T72 : Tree 12 := .split 24 q12Shape33T73 q12Shape33T80
private theorem q12Shape33T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 1536 q12Shape33T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 395264 (1536 ||| 2^24) q12Shape33T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (395264 ||| 2^24) 1536 q12Shape33T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T73OK,q12Shape33T80OK⟩

private def q12Shape33T56 : Tree 12 := .split 18 q12Shape33T57 q12Shape33T72
private theorem q12Shape33T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 1536 q12Shape33T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 (1536 ||| 2^18) q12Shape33T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (133120 ||| 2^18) 1536 q12Shape33T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T57OK,q12Shape33T72OK⟩

def q12Shape33P2 : Tree 12 := q12Shape33T56
theorem q12Shape33P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 133120 1536 q12Shape33P2=true := q12Shape33T56OK

end Graffiti384b.EffectiveSearch.Q12
