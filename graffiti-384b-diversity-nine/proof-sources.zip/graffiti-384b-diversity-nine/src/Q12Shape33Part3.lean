import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T85 : Tree 12 := (.tip (.small 0))
private theorem q12Shape33T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1024 17172992 q12Shape33T85=true := by decide

private def q12Shape33T89 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,11}))))
private theorem q12Shape33T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778240 240518564352 q12Shape33T89=true := by decide

private def q12Shape33T90 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape33T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455731712 103079610880 q12Shape33T90=true := by decide

private def q12Shape33T88 : Tree 12 := .split 37 q12Shape33T89 q12Shape33T90
private theorem q12Shape33T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778240 103079610880 q12Shape33T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778240 (103079610880 ||| 2^37) q12Shape33T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16778240 ||| 2^37) 103079610880 q12Shape33T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T89OK,q12Shape33T90OK⟩

private def q12Shape33T91 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape33T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736254976 34360134144 q12Shape33T91=true := by decide

private def q12Shape33T87 : Tree 12 := .split 36 q12Shape33T88 q12Shape33T91
private theorem q12Shape33T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778240 34360134144 q12Shape33T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778240 (34360134144 ||| 2^36) q12Shape33T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16778240 ||| 2^36) 34360134144 q12Shape33T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T88OK,q12Shape33T91OK⟩

private def q12Shape33T92 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape33T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376516608 395776 q12Shape33T92=true := by decide

private def q12Shape33T86 : Tree 12 := .split 35 q12Shape33T87 q12Shape33T92
private theorem q12Shape33T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778240 395776 q12Shape33T86=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16778240 (395776 ||| 2^35) q12Shape33T87 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16778240 ||| 2^35) 395776 q12Shape33T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T87OK,q12Shape33T92OK⟩

private def q12Shape33T84 : Tree 12 := .split 24 q12Shape33T85 q12Shape33T86
private theorem q12Shape33T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1024 395776 q12Shape33T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1024 (395776 ||| 2^24) q12Shape33T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (1024 ||| 2^24) 395776 q12Shape33T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T85OK,q12Shape33T86OK⟩

private def q12Shape33T97 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 240535079424 q12Shape33T97=true := by decide

private def q12Shape33T98 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439216640 103096125952 q12Shape33T98=true := by decide

private def q12Shape33T96 : Tree 12 := .split 37 q12Shape33T97 q12Shape33T98
private theorem q12Shape33T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 103096125952 q12Shape33T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 (103096125952 ||| 2^37) q12Shape33T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263168 ||| 2^37) 103096125952 q12Shape33T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T97OK,q12Shape33T98OK⟩

private def q12Shape33T99 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719739904 34376649216 q12Shape33T99=true := by decide

private def q12Shape33T95 : Tree 12 := .split 36 q12Shape33T96 q12Shape33T99
private theorem q12Shape33T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 34376649216 q12Shape33T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 (34376649216 ||| 2^36) q12Shape33T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263168 ||| 2^36) 34376649216 q12Shape33T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T96OK,q12Shape33T99OK⟩

private def q12Shape33T100 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360001536 16910848 q12Shape33T100=true := by decide

private def q12Shape33T94 : Tree 12 := .split 35 q12Shape33T95 q12Shape33T100
private theorem q12Shape33T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 16910848 q12Shape33T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 (16910848 ||| 2^35) q12Shape33T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263168 ||| 2^35) 16910848 q12Shape33T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T95OK,q12Shape33T100OK⟩

private def q12Shape33T104 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040384 240518302208 q12Shape33T104=true := by decide

private def q12Shape33T105 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455993856 103079348736 q12Shape33T105=true := by decide

private def q12Shape33T103 : Tree 12 := .split 37 q12Shape33T104 q12Shape33T105
private theorem q12Shape33T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040384 103079348736 q12Shape33T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040384 (103079348736 ||| 2^37) q12Shape33T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17040384 ||| 2^37) 103079348736 q12Shape33T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T104OK,q12Shape33T105OK⟩

private def q12Shape33T106 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736517120 34359872000 q12Shape33T106=true := by decide

private def q12Shape33T102 : Tree 12 := .split 36 q12Shape33T103 q12Shape33T106
private theorem q12Shape33T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040384 34359872000 q12Shape33T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040384 (34359872000 ||| 2^36) q12Shape33T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17040384 ||| 2^36) 34359872000 q12Shape33T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T103OK,q12Shape33T106OK⟩

private def q12Shape33T107 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376778752 133632 q12Shape33T107=true := by decide

private def q12Shape33T101 : Tree 12 := .split 35 q12Shape33T102 q12Shape33T107
private theorem q12Shape33T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040384 133632 q12Shape33T101=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17040384 (133632 ||| 2^35) q12Shape33T102 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17040384 ||| 2^35) 133632 q12Shape33T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T102OK,q12Shape33T107OK⟩

private def q12Shape33T93 : Tree 12 := .split 24 q12Shape33T94 q12Shape33T101
private theorem q12Shape33T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 133632 q12Shape33T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 263168 (133632 ||| 2^24) q12Shape33T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (263168 ||| 2^24) 133632 q12Shape33T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T94OK,q12Shape33T101OK⟩

private def q12Shape33T83 : Tree 12 := .split 18 q12Shape33T84 q12Shape33T93
private theorem q12Shape33T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1024 133632 q12Shape33T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1024 (133632 ||| 2^18) q12Shape33T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (1024 ||| 2^18) 133632 q12Shape33T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T84OK,q12Shape33T93OK⟩

def q12Shape33P3 : Tree 12 := q12Shape33T83
theorem q12Shape33P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 1024 133632 q12Shape33P3=true := q12Shape33T83OK

end Graffiti384b.EffectiveSearch.Q12
