import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T113 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,8,11}))))
private theorem q12Shape33T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 240535210496 q12Shape33T113=true := by decide

private def q12Shape33T114 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape33T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439085568 103096257024 q12Shape33T114=true := by decide

private def q12Shape33T112 : Tree 12 := .split 37 q12Shape33T113 q12Shape33T114
private theorem q12Shape33T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 103096257024 q12Shape33T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 (103096257024 ||| 2^37) q12Shape33T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132096 ||| 2^37) 103096257024 q12Shape33T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T113OK,q12Shape33T114OK⟩

private def q12Shape33T115 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape33T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719608832 34376780288 q12Shape33T115=true := by decide

private def q12Shape33T111 : Tree 12 := .split 36 q12Shape33T112 q12Shape33T115
private theorem q12Shape33T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 34376780288 q12Shape33T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 (34376780288 ||| 2^36) q12Shape33T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132096 ||| 2^36) 34376780288 q12Shape33T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T112OK,q12Shape33T115OK⟩

private def q12Shape33T116 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape33T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359870464 17041920 q12Shape33T116=true := by decide

private def q12Shape33T110 : Tree 12 := .split 35 q12Shape33T111 q12Shape33T116
private theorem q12Shape33T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 17041920 q12Shape33T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 (17041920 ||| 2^35) q12Shape33T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132096 ||| 2^35) 17041920 q12Shape33T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T111OK,q12Shape33T116OK⟩

private def q12Shape33T117 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape33T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16909312 264704 q12Shape33T117=true := by decide

private def q12Shape33T109 : Tree 12 := .split 24 q12Shape33T110 q12Shape33T117
private theorem q12Shape33T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 264704 q12Shape33T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 (264704 ||| 2^24) q12Shape33T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132096 ||| 2^24) 264704 q12Shape33T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T110OK,q12Shape33T117OK⟩

private def q12Shape33T122 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 240534948352 q12Shape33T122=true := by decide

private def q12Shape33T123 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439347712 103095994880 q12Shape33T123=true := by decide

private def q12Shape33T121 : Tree 12 := .split 37 q12Shape33T122 q12Shape33T123
private theorem q12Shape33T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 103095994880 q12Shape33T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 (103095994880 ||| 2^37) q12Shape33T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (394240 ||| 2^37) 103095994880 q12Shape33T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T122OK,q12Shape33T123OK⟩

private def q12Shape33T124 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719870976 34376518144 q12Shape33T124=true := by decide

private def q12Shape33T120 : Tree 12 := .split 36 q12Shape33T121 q12Shape33T124
private theorem q12Shape33T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 34376518144 q12Shape33T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 (34376518144 ||| 2^36) q12Shape33T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (394240 ||| 2^36) 34376518144 q12Shape33T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T121OK,q12Shape33T124OK⟩

private def q12Shape33T125 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360132608 16779776 q12Shape33T125=true := by decide

private def q12Shape33T119 : Tree 12 := .split 35 q12Shape33T120 q12Shape33T125
private theorem q12Shape33T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 16779776 q12Shape33T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 (16779776 ||| 2^35) q12Shape33T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (394240 ||| 2^35) 16779776 q12Shape33T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T120OK,q12Shape33T125OK⟩

private def q12Shape33T126 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape33T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17171456 2560 q12Shape33T126=true := by decide

private def q12Shape33T118 : Tree 12 := .split 24 q12Shape33T119 q12Shape33T126
private theorem q12Shape33T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 2560 q12Shape33T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 394240 (2560 ||| 2^24) q12Shape33T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (394240 ||| 2^24) 2560 q12Shape33T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T119OK,q12Shape33T126OK⟩

private def q12Shape33T108 : Tree 12 := .split 18 q12Shape33T109 q12Shape33T118
private theorem q12Shape33T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 2560 q12Shape33T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 (2560 ||| 2^18) q12Shape33T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (132096 ||| 2^18) 2560 q12Shape33T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T109OK,q12Shape33T118OK⟩

def q12Shape33P4 : Tree 12 := q12Shape33T108
theorem q12Shape33P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 132096 2560 q12Shape33P4=true := q12Shape33T108OK

end Graffiti384b.EffectiveSearch.Q12
