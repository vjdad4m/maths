import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T133 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 240535339520 q12Shape33T133=true := by decide

private def q12Shape33T134 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137438956544 103096386048 q12Shape33T134=true := by decide

private def q12Shape33T132 : Tree 12 := .split 37 q12Shape33T133 q12Shape33T134
private theorem q12Shape33T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 103096386048 q12Shape33T132=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 (103096386048 ||| 2^37) q12Shape33T133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3072 ||| 2^37) 103096386048 q12Shape33T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T133OK,q12Shape33T134OK⟩

private def q12Shape33T135 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719479808 34376909312 q12Shape33T135=true := by decide

private def q12Shape33T131 : Tree 12 := .split 36 q12Shape33T132 q12Shape33T135
private theorem q12Shape33T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 34376909312 q12Shape33T131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 (34376909312 ||| 2^36) q12Shape33T132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3072 ||| 2^36) 34376909312 q12Shape33T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T132OK,q12Shape33T135OK⟩

private def q12Shape33T136 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359741440 17170944 q12Shape33T136=true := by decide

private def q12Shape33T130 : Tree 12 := .split 35 q12Shape33T131 q12Shape33T136
private theorem q12Shape33T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 17170944 q12Shape33T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 (17170944 ||| 2^35) q12Shape33T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3072 ||| 2^35) 17170944 q12Shape33T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T131OK,q12Shape33T136OK⟩

private def q12Shape33T140 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780288 240518562304 q12Shape33T140=true := by decide

private def q12Shape33T141 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455733760 103079608832 q12Shape33T141=true := by decide

private def q12Shape33T139 : Tree 12 := .split 37 q12Shape33T140 q12Shape33T141
private theorem q12Shape33T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780288 103079608832 q12Shape33T139=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780288 (103079608832 ||| 2^37) q12Shape33T140 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16780288 ||| 2^37) 103079608832 q12Shape33T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T140OK,q12Shape33T141OK⟩

private def q12Shape33T142 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736257024 34360132096 q12Shape33T142=true := by decide

private def q12Shape33T138 : Tree 12 := .split 36 q12Shape33T139 q12Shape33T142
private theorem q12Shape33T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780288 34360132096 q12Shape33T138=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780288 (34360132096 ||| 2^36) q12Shape33T139 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16780288 ||| 2^36) 34360132096 q12Shape33T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T139OK,q12Shape33T142OK⟩

private def q12Shape33T143 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376518656 393728 q12Shape33T143=true := by decide

private def q12Shape33T137 : Tree 12 := .split 35 q12Shape33T138 q12Shape33T143
private theorem q12Shape33T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780288 393728 q12Shape33T137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16780288 (393728 ||| 2^35) q12Shape33T138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16780288 ||| 2^35) 393728 q12Shape33T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T138OK,q12Shape33T143OK⟩

private def q12Shape33T129 : Tree 12 := .split 24 q12Shape33T130 q12Shape33T137
private theorem q12Shape33T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 393728 q12Shape33T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 (393728 ||| 2^24) q12Shape33T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3072 ||| 2^24) 393728 q12Shape33T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T130OK,q12Shape33T137OK⟩

private def q12Shape33T148 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 240535077376 q12Shape33T148=true := by decide

private def q12Shape33T149 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439218688 103096123904 q12Shape33T149=true := by decide

private def q12Shape33T147 : Tree 12 := .split 37 q12Shape33T148 q12Shape33T149
private theorem q12Shape33T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 103096123904 q12Shape33T147=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 (103096123904 ||| 2^37) q12Shape33T148 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (265216 ||| 2^37) 103096123904 q12Shape33T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T148OK,q12Shape33T149OK⟩

private def q12Shape33T150 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719741952 34376647168 q12Shape33T150=true := by decide

private def q12Shape33T146 : Tree 12 := .split 36 q12Shape33T147 q12Shape33T150
private theorem q12Shape33T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 34376647168 q12Shape33T146=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 (34376647168 ||| 2^36) q12Shape33T147 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (265216 ||| 2^36) 34376647168 q12Shape33T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T147OK,q12Shape33T150OK⟩

private def q12Shape33T151 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360003584 16908800 q12Shape33T151=true := by decide

private def q12Shape33T145 : Tree 12 := .split 35 q12Shape33T146 q12Shape33T151
private theorem q12Shape33T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 16908800 q12Shape33T145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 (16908800 ||| 2^35) q12Shape33T146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (265216 ||| 2^35) 16908800 q12Shape33T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T146OK,q12Shape33T151OK⟩

private def q12Shape33T152 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape33T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17042432 131584 q12Shape33T152=true := by decide

private def q12Shape33T144 : Tree 12 := .split 24 q12Shape33T145 q12Shape33T152
private theorem q12Shape33T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 131584 q12Shape33T144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 265216 (131584 ||| 2^24) q12Shape33T145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (265216 ||| 2^24) 131584 q12Shape33T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T145OK,q12Shape33T152OK⟩

private def q12Shape33T128 : Tree 12 := .split 18 q12Shape33T129 q12Shape33T144
private theorem q12Shape33T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 131584 q12Shape33T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 (131584 ||| 2^18) q12Shape33T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (3072 ||| 2^18) 131584 q12Shape33T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T129OK,q12Shape33T144OK⟩

def q12Shape33P5 : Tree 12 := q12Shape33T128
theorem q12Shape33P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 3072 131584 q12Shape33P5=true := q12Shape33T128OK

end Graffiti384b.EffectiveSearch.Q12
