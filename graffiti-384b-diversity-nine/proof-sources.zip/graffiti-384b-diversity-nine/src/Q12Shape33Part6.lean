import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T158 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))))
private theorem q12Shape33T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 240535208448 q12Shape33T158=true := by decide

private def q12Shape33T159 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439087616 103096254976 q12Shape33T159=true := by decide

private def q12Shape33T157 : Tree 12 := .split 37 q12Shape33T158 q12Shape33T159
private theorem q12Shape33T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 103096254976 q12Shape33T157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 (103096254976 ||| 2^37) q12Shape33T158 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (134144 ||| 2^37) 103096254976 q12Shape33T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T158OK,q12Shape33T159OK⟩

private def q12Shape33T160 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,9,10,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719610880 34376778240 q12Shape33T160=true := by decide

private def q12Shape33T156 : Tree 12 := .split 36 q12Shape33T157 q12Shape33T160
private theorem q12Shape33T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 34376778240 q12Shape33T156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 (34376778240 ||| 2^36) q12Shape33T157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (134144 ||| 2^36) 34376778240 q12Shape33T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T157OK,q12Shape33T160OK⟩

private def q12Shape33T161 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11})))
private theorem q12Shape33T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359872512 17039872 q12Shape33T161=true := by decide

private def q12Shape33T155 : Tree 12 := .split 35 q12Shape33T156 q12Shape33T161
private theorem q12Shape33T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 17039872 q12Shape33T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 (17039872 ||| 2^35) q12Shape33T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (134144 ||| 2^35) 17039872 q12Shape33T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T156OK,q12Shape33T161OK⟩

private def q12Shape33T162 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape33T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16911360 262656 q12Shape33T162=true := by decide

private def q12Shape33T154 : Tree 12 := .split 24 q12Shape33T155 q12Shape33T162
private theorem q12Shape33T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 262656 q12Shape33T154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 (262656 ||| 2^24) q12Shape33T155 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (134144 ||| 2^24) 262656 q12Shape33T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T155OK,q12Shape33T162OK⟩

private def q12Shape33T167 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,9,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,10,11}))) (.tip (.cover {2,3,4,7,9,10,11}))))
private theorem q12Shape33T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 240534946304 q12Shape33T167=true := by decide

private def q12Shape33T168 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,9,11}))) (.tip (.cover {2,3,4,7,8,9,11}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape33T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439349760 103095992832 q12Shape33T168=true := by decide

private def q12Shape33T166 : Tree 12 := .split 37 q12Shape33T167 q12Shape33T168
private theorem q12Shape33T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 103095992832 q12Shape33T166=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 (103095992832 ||| 2^37) q12Shape33T167 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (396288 ||| 2^37) 103095992832 q12Shape33T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T167OK,q12Shape33T168OK⟩

private def q12Shape33T169 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,10,11}))) (.tip (.cover {0,1,3,4,7,8,11}))) (.tip (.cover {2,3,4,7,8,10,11}))) (.tip (.cover {2,3,4,8,9,10,11})))
private theorem q12Shape33T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719873024 34376516096 q12Shape33T169=true := by decide

private def q12Shape33T165 : Tree 12 := .split 36 q12Shape33T166 q12Shape33T169
private theorem q12Shape33T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 34376516096 q12Shape33T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 (34376516096 ||| 2^36) q12Shape33T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (396288 ||| 2^36) 34376516096 q12Shape33T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T166OK,q12Shape33T169OK⟩

private def q12Shape33T170 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {2,3,4,7,9,10,11}))) (.tip (.cover {2,3,4,7,9,10,11}))) (.tip (.cover {2,3,4,8,9,10,11}))) (.tip (.cover {2,3,4,8,9,10,11})))
private theorem q12Shape33T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360134656 16777728 q12Shape33T170=true := by decide

private def q12Shape33T164 : Tree 12 := .split 35 q12Shape33T165 q12Shape33T170
private theorem q12Shape33T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 16777728 q12Shape33T164=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 (16777728 ||| 2^35) q12Shape33T165 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (396288 ||| 2^35) 16777728 q12Shape33T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T165OK,q12Shape33T170OK⟩

private def q12Shape33T171 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape33T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17173504 512 q12Shape33T171=true := by decide

private def q12Shape33T163 : Tree 12 := .split 24 q12Shape33T164 q12Shape33T171
private theorem q12Shape33T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 512 q12Shape33T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 396288 (512 ||| 2^24) q12Shape33T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (396288 ||| 2^24) 512 q12Shape33T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T164OK,q12Shape33T171OK⟩

private def q12Shape33T153 : Tree 12 := .split 18 q12Shape33T154 q12Shape33T163
private theorem q12Shape33T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 512 q12Shape33T153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 (512 ||| 2^18) q12Shape33T154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (134144 ||| 2^18) 512 q12Shape33T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T154OK,q12Shape33T163OK⟩

def q12Shape33P6 : Tree 12 := q12Shape33T153
theorem q12Shape33P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 134144 512 q12Shape33P6=true := q12Shape33T153OK

end Graffiti384b.EffectiveSearch.Q12
