import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T177 : Tree 12 := (.tip (.small 0))
private theorem q12Shape33T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 512 17173504 q12Shape33T177=true := by decide

private def q12Shape33T181 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape33T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16777728 240518564864 q12Shape33T181=true := by decide

private def q12Shape33T182 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455731200 103079611392 q12Shape33T182=true := by decide

private def q12Shape33T180 : Tree 12 := .split 37 q12Shape33T181 q12Shape33T182
private theorem q12Shape33T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16777728 103079611392 q12Shape33T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16777728 (103079611392 ||| 2^37) q12Shape33T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16777728 ||| 2^37) 103079611392 q12Shape33T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T181OK,q12Shape33T182OK⟩

private def q12Shape33T183 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736254464 34360134656 q12Shape33T183=true := by decide

private def q12Shape33T179 : Tree 12 := .split 36 q12Shape33T180 q12Shape33T183
private theorem q12Shape33T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16777728 34360134656 q12Shape33T179=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16777728 (34360134656 ||| 2^36) q12Shape33T180 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16777728 ||| 2^36) 34360134656 q12Shape33T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T180OK,q12Shape33T183OK⟩

private def q12Shape33T184 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape33T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376516096 396288 q12Shape33T184=true := by decide

private def q12Shape33T178 : Tree 12 := .split 35 q12Shape33T179 q12Shape33T184
private theorem q12Shape33T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16777728 396288 q12Shape33T178=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16777728 (396288 ||| 2^35) q12Shape33T179 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16777728 ||| 2^35) 396288 q12Shape33T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T179OK,q12Shape33T184OK⟩

private def q12Shape33T176 : Tree 12 := .split 24 q12Shape33T177 q12Shape33T178
private theorem q12Shape33T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 512 396288 q12Shape33T176=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 512 (396288 ||| 2^24) q12Shape33T177 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (512 ||| 2^24) 396288 q12Shape33T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T177OK,q12Shape33T178OK⟩

private def q12Shape33T189 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,11}))))
private theorem q12Shape33T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 240535079936 q12Shape33T189=true := by decide

private def q12Shape33T190 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape33T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439216128 103096126464 q12Shape33T190=true := by decide

private def q12Shape33T188 : Tree 12 := .split 37 q12Shape33T189 q12Shape33T190
private theorem q12Shape33T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 103096126464 q12Shape33T188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 (103096126464 ||| 2^37) q12Shape33T189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (262656 ||| 2^37) 103096126464 q12Shape33T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T189OK,q12Shape33T190OK⟩

private def q12Shape33T191 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape33T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719739392 34376649728 q12Shape33T191=true := by decide

private def q12Shape33T187 : Tree 12 := .split 36 q12Shape33T188 q12Shape33T191
private theorem q12Shape33T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 34376649728 q12Shape33T187=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 (34376649728 ||| 2^36) q12Shape33T188 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (262656 ||| 2^36) 34376649728 q12Shape33T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T188OK,q12Shape33T191OK⟩

private def q12Shape33T192 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape33T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34360001024 16911360 q12Shape33T192=true := by decide

private def q12Shape33T186 : Tree 12 := .split 35 q12Shape33T187 q12Shape33T192
private theorem q12Shape33T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 16911360 q12Shape33T186=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 (16911360 ||| 2^35) q12Shape33T187 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (262656 ||| 2^35) 16911360 q12Shape33T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T187OK,q12Shape33T192OK⟩

private def q12Shape33T196 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape33T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039872 240518302720 q12Shape33T196=true := by decide

private def q12Shape33T197 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455993344 103079349248 q12Shape33T197=true := by decide

private def q12Shape33T195 : Tree 12 := .split 37 q12Shape33T196 q12Shape33T197
private theorem q12Shape33T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039872 103079349248 q12Shape33T195=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039872 (103079349248 ||| 2^37) q12Shape33T196 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17039872 ||| 2^37) 103079349248 q12Shape33T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T196OK,q12Shape33T197OK⟩

private def q12Shape33T198 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736516608 34359872512 q12Shape33T198=true := by decide

private def q12Shape33T194 : Tree 12 := .split 36 q12Shape33T195 q12Shape33T198
private theorem q12Shape33T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039872 34359872512 q12Shape33T194=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039872 (34359872512 ||| 2^36) q12Shape33T195 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17039872 ||| 2^36) 34359872512 q12Shape33T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T195OK,q12Shape33T198OK⟩

private def q12Shape33T199 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape33T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376778240 134144 q12Shape33T199=true := by decide

private def q12Shape33T193 : Tree 12 := .split 35 q12Shape33T194 q12Shape33T199
private theorem q12Shape33T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039872 134144 q12Shape33T193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17039872 (134144 ||| 2^35) q12Shape33T194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (17039872 ||| 2^35) 134144 q12Shape33T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T194OK,q12Shape33T199OK⟩

private def q12Shape33T185 : Tree 12 := .split 24 q12Shape33T186 q12Shape33T193
private theorem q12Shape33T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 134144 q12Shape33T185=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 262656 (134144 ||| 2^24) q12Shape33T186 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (262656 ||| 2^24) 134144 q12Shape33T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T186OK,q12Shape33T193OK⟩

private def q12Shape33T175 : Tree 12 := .split 18 q12Shape33T176 q12Shape33T185
private theorem q12Shape33T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 512 134144 q12Shape33T175=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 512 (134144 ||| 2^18) q12Shape33T176 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (512 ||| 2^18) 134144 q12Shape33T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T176OK,q12Shape33T185OK⟩

def q12Shape33P7 : Tree 12 := q12Shape33T175
theorem q12Shape33P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 512 134144 q12Shape33P7=true := q12Shape33T175OK

end Graffiti384b.EffectiveSearch.Q12
