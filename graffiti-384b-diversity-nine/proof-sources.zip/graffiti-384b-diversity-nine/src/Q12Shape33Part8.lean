import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape33T205 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,8,11}))))
private theorem q12Shape33T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 240535211008 q12Shape33T205=true := by decide

private def q12Shape33T206 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,7,8,11})))
private theorem q12Shape33T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137439085056 103096257536 q12Shape33T206=true := by decide

private def q12Shape33T204 : Tree 12 := .split 37 q12Shape33T205 q12Shape33T206
private theorem q12Shape33T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 103096257536 q12Shape33T204=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 (103096257536 ||| 2^37) q12Shape33T205 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (131584 ||| 2^37) 103096257536 q12Shape33T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T205OK,q12Shape33T206OK⟩

private def q12Shape33T207 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,7,8,11})))
private theorem q12Shape33T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68719608320 34376780800 q12Shape33T207=true := by decide

private def q12Shape33T203 : Tree 12 := .split 36 q12Shape33T204 q12Shape33T207
private theorem q12Shape33T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 34376780800 q12Shape33T203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 (34376780800 ||| 2^36) q12Shape33T204 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (131584 ||| 2^36) 34376780800 q12Shape33T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T204OK,q12Shape33T207OK⟩

private def q12Shape33T208 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape33T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34359869952 17042432 q12Shape33T208=true := by decide

private def q12Shape33T202 : Tree 12 := .split 35 q12Shape33T203 q12Shape33T208
private theorem q12Shape33T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 17042432 q12Shape33T202=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 (17042432 ||| 2^35) q12Shape33T203 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (131584 ||| 2^35) 17042432 q12Shape33T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T203OK,q12Shape33T208OK⟩

private def q12Shape33T212 : Tree 12 := (.split 39 (.split 40 (.tip (.small 1)) (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11})))) (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))))
private theorem q12Shape33T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908800 240518433792 q12Shape33T212=true := by decide

private def q12Shape33T213 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 137455862272 103079480320 q12Shape33T213=true := by decide

private def q12Shape33T211 : Tree 12 := .split 37 q12Shape33T212 q12Shape33T213
private theorem q12Shape33T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908800 103079480320 q12Shape33T211=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908800 (103079480320 ||| 2^37) q12Shape33T212 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16908800 ||| 2^37) 103079480320 q12Shape33T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T212OK,q12Shape33T213OK⟩

private def q12Shape33T214 : Tree 12 := (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {0,1,3,5,9,10,11}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape33T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 68736385536 34360003584 q12Shape33T214=true := by decide

private def q12Shape33T210 : Tree 12 := .split 36 q12Shape33T211 q12Shape33T214
private theorem q12Shape33T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908800 34360003584 q12Shape33T210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908800 (34360003584 ||| 2^36) q12Shape33T211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16908800 ||| 2^36) 34360003584 q12Shape33T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T211OK,q12Shape33T214OK⟩

private def q12Shape33T215 : Tree 12 := (.split 36 (.split 37 (.split 39 (.split 40 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11})))
private theorem q12Shape33T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 34376647168 265216 q12Shape33T215=true := by decide

private def q12Shape33T209 : Tree 12 := .split 35 q12Shape33T210 q12Shape33T215
private theorem q12Shape33T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908800 265216 q12Shape33T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 16908800 (265216 ||| 2^35) q12Shape33T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (16908800 ||| 2^35) 265216 q12Shape33T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T210OK,q12Shape33T215OK⟩

private def q12Shape33T201 : Tree 12 := .split 24 q12Shape33T202 q12Shape33T209
private theorem q12Shape33T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 265216 q12Shape33T201=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 (265216 ||| 2^24) q12Shape33T202 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (131584 ||| 2^24) 265216 q12Shape33T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T202OK,q12Shape33T209OK⟩

private def q12Shape33T217 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape33T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393728 16780288 q12Shape33T217=true := by decide

private def q12Shape33T218 : Tree 12 := (.split 35 (.split 36 (.split 37 (.split 39 (.split 40 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape33T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 17170944 3072 q12Shape33T218=true := by decide

private def q12Shape33T216 : Tree 12 := .split 24 q12Shape33T217 q12Shape33T218
private theorem q12Shape33T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393728 3072 q12Shape33T216=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 393728 (3072 ||| 2^24) q12Shape33T217 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (393728 ||| 2^24) 3072 q12Shape33T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T217OK,q12Shape33T218OK⟩

private def q12Shape33T200 : Tree 12 := .split 18 q12Shape33T201 q12Shape33T216
private theorem q12Shape33T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 3072 q12Shape33T200=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 (3072 ||| 2^18) q12Shape33T201 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) (131584 ||| 2^18) 3072 q12Shape33T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape33T201OK,q12Shape33T216OK⟩

def q12Shape33P8 : Tree 12 := q12Shape33T200
theorem q12Shape33P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,1⟩) 131584 3072 q12Shape33P8=true := q12Shape33T200OK

end Graffiti384b.EffectiveSearch.Q12
