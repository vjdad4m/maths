import Q12Shape34Part0
import Q12Shape34Part1
import Q12Shape34Part2
import Q12Shape34Part3
import Q12Shape34Part4
import Q12Shape34Part5
import Q12Shape34Part6
import Q12Shape34Part7
import Q12Shape34Part8
import Q12Shape34Part9
import Q12Shape34Part10
import Q12Shape34Part11
import Q12Shape34Part12
import Q12Shape34Part13
import Q12Shape34Part14
import Q12Shape34Part15
import Q12Shape34Part16
import Q12Shape34Part17

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34M96 : Tree 12 := .split 25 q12Shape34P0 q12Shape34P1
private theorem q12Shape34M96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 652855869440 q12Shape34M96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (652855869440 ||| 2^25) q12Shape34P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^25) 652855869440 q12Shape34P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34P0OK,q12Shape34P1OK⟩
private def q12Shape34M164 : Tree 12 := .split 21 q12Shape34M96 q12Shape34P2
private theorem q12Shape34M164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 652853772288 q12Shape34M164=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (652853772288 ||| 2^21) q12Shape34M96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^21) 652853772288 q12Shape34P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M96OK,q12Shape34P2OK⟩
private def q12Shape34M242 : Tree 12 := .split 20 q12Shape34M164 q12Shape34P3
private theorem q12Shape34M242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 652852723712 q12Shape34M242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (652852723712 ||| 2^20) q12Shape34M164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^20) 652852723712 q12Shape34P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M164OK,q12Shape34P3OK⟩
private def q12Shape34M335 : Tree 12 := .split 20 q12Shape34P4 q12Shape34P5
private theorem q12Shape34M335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 652852199424 q12Shape34M335=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (652852199424 ||| 2^20) q12Shape34P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^20) 652852199424 q12Shape34P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34P4OK,q12Shape34P5OK⟩
private def q12Shape34M336 : Tree 12 := .split 19 q12Shape34M242 q12Shape34M335
private theorem q12Shape34M336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 652852199424 q12Shape34M336=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (652852199424 ||| 2^19) q12Shape34M242 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^19) 652852199424 q12Shape34M335)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M242OK,q12Shape34M335OK⟩
private def q12Shape34M384 : Tree 12 := .split 39 q12Shape34M336 q12Shape34P6
private theorem q12Shape34M384OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 103096385536 q12Shape34M384=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (103096385536 ||| 2^39) q12Shape34M336 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^39) 103096385536 q12Shape34P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M336OK,q12Shape34P6OK⟩
private def q12Shape34M428 : Tree 12 := .split 36 q12Shape34M384 q12Shape34P7
private theorem q12Shape34M428OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 34376908800 q12Shape34M428=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (34376908800 ||| 2^36) q12Shape34M384 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^36) 34376908800 q12Shape34P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M384OK,q12Shape34P7OK⟩
private def q12Shape34M472 : Tree 12 := .split 35 q12Shape34M428 q12Shape34P8
private theorem q12Shape34M472OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 17170432 q12Shape34M472=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (17170432 ||| 2^35) q12Shape34M428 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^35) 17170432 q12Shape34P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M428OK,q12Shape34P8OK⟩
private def q12Shape34M573 : Tree 12 := .split 39 q12Shape34P9 q12Shape34P10
private theorem q12Shape34M573OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 103079608320 q12Shape34M573=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (103079608320 ||| 2^39) q12Shape34P9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^39) 103079608320 q12Shape34P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34P9OK,q12Shape34P10OK⟩
private def q12Shape34M603 : Tree 12 := .split 36 q12Shape34M573 q12Shape34P11
private theorem q12Shape34M603OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 34360131584 q12Shape34M603=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (34360131584 ||| 2^36) q12Shape34M573 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^36) 34360131584 q12Shape34P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M573OK,q12Shape34P11OK⟩
private def q12Shape34M631 : Tree 12 := .split 35 q12Shape34M603 q12Shape34P12
private theorem q12Shape34M631OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 393216 q12Shape34M631=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (393216 ||| 2^35) q12Shape34M603 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^35) 393216 q12Shape34P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M603OK,q12Shape34P12OK⟩
private def q12Shape34M632 : Tree 12 := .split 24 q12Shape34M472 q12Shape34M631
private theorem q12Shape34M632OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 393216 q12Shape34M632=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (393216 ||| 2^24) q12Shape34M472 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^24) 393216 q12Shape34M631)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M472OK,q12Shape34M631OK⟩
private def q12Shape34M721 : Tree 12 := .split 19 q12Shape34P13 q12Shape34P14
private theorem q12Shape34M721OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652851937280 q12Shape34M721=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652851937280 ||| 2^19) q12Shape34P13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^19) 652851937280 q12Shape34P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34P13OK,q12Shape34P14OK⟩
private def q12Shape34M749 : Tree 12 := .split 39 q12Shape34M721 q12Shape34P15
private theorem q12Shape34M749OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 103096123392 q12Shape34M749=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (103096123392 ||| 2^39) q12Shape34M721 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^39) 103096123392 q12Shape34P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M721OK,q12Shape34P15OK⟩
private def q12Shape34M779 : Tree 12 := .split 36 q12Shape34M749 q12Shape34P16
private theorem q12Shape34M779OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 34376646656 q12Shape34M779=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (34376646656 ||| 2^36) q12Shape34M749 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^36) 34376646656 q12Shape34P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M749OK,q12Shape34P16OK⟩
private def q12Shape34M807 : Tree 12 := .split 35 q12Shape34M779 q12Shape34P17
private theorem q12Shape34M807OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 16908288 q12Shape34M807=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (16908288 ||| 2^35) q12Shape34M779 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^35) 16908288 q12Shape34P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M779OK,q12Shape34P17OK⟩
private def q12Shape34M809 : Tree 12 := .split 24 q12Shape34M807 q12Shape34P18
private theorem q12Shape34M809OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 131072 q12Shape34M809=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (131072 ||| 2^24) q12Shape34M807 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^24) 131072 q12Shape34P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M807OK,q12Shape34P18OK⟩
private def q12Shape34M810 : Tree 12 := .split 18 q12Shape34M632 q12Shape34M809
private theorem q12Shape34M810OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 131072 q12Shape34M810=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (131072 ||| 2^18) q12Shape34M632 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^18) 131072 q12Shape34M809)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M632OK,q12Shape34M809OK⟩
private def q12Shape34M883 : Tree 12 := .split 20 q12Shape34P19 q12Shape34P20
private theorem q12Shape34M883OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652852592640 q12Shape34M883=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652852592640 ||| 2^20) q12Shape34P19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^20) 652852592640 q12Shape34P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34P19OK,q12Shape34P20OK⟩
private def q12Shape34M903 : Tree 12 := .split 19 q12Shape34M883 q12Shape34P21
private theorem q12Shape34M903OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652852068352 q12Shape34M903=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652852068352 ||| 2^19) q12Shape34M883 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^19) 652852068352 q12Shape34P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M883OK,q12Shape34P21OK⟩
private def q12Shape34M933 : Tree 12 := .split 39 q12Shape34M903 q12Shape34P22
private theorem q12Shape34M933OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 103096254464 q12Shape34M933=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (103096254464 ||| 2^39) q12Shape34M903 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^39) 103096254464 q12Shape34P22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M903OK,q12Shape34P22OK⟩
private def q12Shape34M967 : Tree 12 := .split 36 q12Shape34M933 q12Shape34P23
private theorem q12Shape34M967OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 34376777728 q12Shape34M967=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (34376777728 ||| 2^36) q12Shape34M933 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^36) 34376777728 q12Shape34P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M933OK,q12Shape34P23OK⟩
private def q12Shape34M999 : Tree 12 := .split 35 q12Shape34M967 q12Shape34P24
private theorem q12Shape34M999OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 17039360 q12Shape34M999=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (17039360 ||| 2^35) q12Shape34M967 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^35) 17039360 q12Shape34P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M967OK,q12Shape34P24OK⟩
private def q12Shape34M1001 : Tree 12 := .split 24 q12Shape34M999 q12Shape34P25
private theorem q12Shape34M1001OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 262144 q12Shape34M1001=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (262144 ||| 2^24) q12Shape34M999 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^24) 262144 q12Shape34P25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M999OK,q12Shape34P25OK⟩
private def q12Shape34M1003 : Tree 12 := .split 18 q12Shape34M1001 q12Shape34P26
private theorem q12Shape34M1003OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 0 q12Shape34M1003=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (0 ||| 2^18) q12Shape34M1001 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^18) 0 q12Shape34P26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M1001OK,q12Shape34P26OK⟩
private def q12Shape34M1004 : Tree 12 := .split 17 q12Shape34M810 q12Shape34M1003
private theorem q12Shape34M1004OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 0 q12Shape34M1004=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 0 (0 ||| 2^17) q12Shape34M810 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (0 ||| 2^17) 0 q12Shape34M1003)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34M810OK,q12Shape34M1003OK⟩

theorem q12Shape34_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 34) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 34) b) (adj 12 (forms 34) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) adj_mono b H q12Shape34M1004 q12Shape34M1004OK

#print axioms q12Shape34_cover

end Graffiti384b.EffectiveSearch.Q12
