import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T66 : Tree 12 := (.tip (.cover {0,1,2,3,5,10,11}))
private theorem q12Shape34T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 660573388800 q12Shape34T66=true := by decide

private def q12Shape34T69 : Tree 12 := (.split 40 (.split 41 (.split 28 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,8,10,11})))) (.split 33 (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,11})))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape34T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4328521728 656291004416 q12Shape34T69=true := by decide

private def q12Shape34T70 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4336910336 656282615808 q12Shape34T70=true := by decide

private def q12Shape34T68 : Tree 12 := .split 23 q12Shape34T69 q12Shape34T70
private theorem q12Shape34T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4328521728 656282615808 q12Shape34T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4328521728 (656282615808 ||| 2^23) q12Shape34T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (4328521728 ||| 2^23) 656282615808 q12Shape34T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T69OK,q12Shape34T70OK⟩

private def q12Shape34T71 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4332716032 656278421504 q12Shape34T71=true := by decide

private def q12Shape34T67 : Tree 12 := .split 22 q12Shape34T68 q12Shape34T71
private theorem q12Shape34T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4328521728 656278421504 q12Shape34T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4328521728 (656278421504 ||| 2^22) q12Shape34T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (4328521728 ||| 2^22) 656278421504 q12Shape34T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T68OK,q12Shape34T71OK⟩

private def q12Shape34T65 : Tree 12 := .split 32 q12Shape34T66 q12Shape34T67
private theorem q12Shape34T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 656278421504 q12Shape34T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 (656278421504 ||| 2^32) q12Shape34T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33554432 ||| 2^32) 656278421504 q12Shape34T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T66OK,q12Shape34T67OK⟩

private def q12Shape34T76 : Tree 12 := (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 37 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,6,7,9,11}))))
private theorem q12Shape34T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 658706923520 q12Shape34T76=true := by decide

private def q12Shape34T77 : Tree 12 := (.split 33 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,5,8,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape34T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2449473536 658438488064 q12Shape34T77=true := by decide

private def q12Shape34T75 : Tree 12 := .split 28 q12Shape34T76 q12Shape34T77
private theorem q12Shape34T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 658438488064 q12Shape34T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 (658438488064 ||| 2^28) q12Shape34T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2181038080 ||| 2^28) 658438488064 q12Shape34T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T76OK,q12Shape34T77OK⟩

private def q12Shape34T78 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2189426688 658430099456 q12Shape34T78=true := by decide

private def q12Shape34T74 : Tree 12 := .split 23 q12Shape34T75 q12Shape34T78
private theorem q12Shape34T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 658430099456 q12Shape34T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 (658430099456 ||| 2^23) q12Shape34T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2181038080 ||| 2^23) 658430099456 q12Shape34T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T75OK,q12Shape34T78OK⟩

private def q12Shape34T79 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2185232384 658425905152 q12Shape34T79=true := by decide

private def q12Shape34T73 : Tree 12 := .split 22 q12Shape34T74 q12Shape34T79
private theorem q12Shape34T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 658425905152 q12Shape34T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 (658425905152 ||| 2^22) q12Shape34T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2181038080 ||| 2^22) 658425905152 q12Shape34T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T74OK,q12Shape34T79OK⟩

private def q12Shape34T80 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 6476005376 654130937856 q12Shape34T80=true := by decide

private def q12Shape34T72 : Tree 12 := .split 32 q12Shape34T73 q12Shape34T80
private theorem q12Shape34T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 654130937856 q12Shape34T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181038080 (654130937856 ||| 2^32) q12Shape34T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2181038080 ||| 2^32) 654130937856 q12Shape34T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T73OK,q12Shape34T80OK⟩

private def q12Shape34T64 : Tree 12 := .split 31 q12Shape34T65 q12Shape34T72
private theorem q12Shape34T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 654130937856 q12Shape34T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 (654130937856 ||| 2^31) q12Shape34T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33554432 ||| 2^31) 654130937856 q12Shape34T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T65OK,q12Shape34T72OK⟩

private def q12Shape34T82 : Tree 12 := (.split 23 (.split 28 (.split 29 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.tip (.cover {0,2,3,7,8,9,10})) (.split 40 (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape34T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1107296256 653061390336 q12Shape34T82=true := by decide

private def q12Shape34T83 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape34T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1111490560 653057196032 q12Shape34T83=true := by decide

private def q12Shape34T81 : Tree 12 := .split 22 q12Shape34T82 q12Shape34T83
private theorem q12Shape34T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1107296256 653057196032 q12Shape34T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1107296256 (653057196032 ||| 2^22) q12Shape34T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1107296256 ||| 2^22) 653057196032 q12Shape34T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T82OK,q12Shape34T83OK⟩

private def q12Shape34T63 : Tree 12 := .split 30 q12Shape34T64 q12Shape34T81
private theorem q12Shape34T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 653057196032 q12Shape34T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 (653057196032 ||| 2^30) q12Shape34T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33554432 ||| 2^30) 653057196032 q12Shape34T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T64OK,q12Shape34T81OK⟩

private def q12Shape34T86 : Tree 12 := (.split 23 (.split 33 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.split 29 (.tip (.cover {0,2,3,7,8,9,10})) (.split 40 (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11})))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 167772160 655074656256 q12Shape34T86=true := by decide

private def q12Shape34T87 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 171966464 655070461952 q12Shape34T87=true := by decide

private def q12Shape34T85 : Tree 12 := .split 22 q12Shape34T86 q12Shape34T87
private theorem q12Shape34T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 167772160 655070461952 q12Shape34T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 167772160 (655070461952 ||| 2^22) q12Shape34T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (167772160 ||| 2^22) 655070461952 q12Shape34T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T86OK,q12Shape34T87OK⟩

private def q12Shape34T88 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2315255808 652922978304 q12Shape34T88=true := by decide

private def q12Shape34T84 : Tree 12 := .split 31 q12Shape34T85 q12Shape34T88
private theorem q12Shape34T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 167772160 652922978304 q12Shape34T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 167772160 (652922978304 ||| 2^31) q12Shape34T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (167772160 ||| 2^31) 652922978304 q12Shape34T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T85OK,q12Shape34T88OK⟩

private def q12Shape34T62 : Tree 12 := .split 27 q12Shape34T63 q12Shape34T84
private theorem q12Shape34T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 652922978304 q12Shape34T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 (652922978304 ||| 2^27) q12Shape34T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33554432 ||| 2^27) 652922978304 q12Shape34T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T63OK,q12Shape34T84OK⟩

private def q12Shape34T92 : Tree 12 := (.split 23 (.split 33 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.split 29 (.tip (.cover {0,2,3,7,8,9,10})) (.split 42 (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,4,5,9,10,11})))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape34T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100663296 657289248768 q12Shape34T92=true := by decide

private def q12Shape34T93 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 104857600 657285054464 q12Shape34T93=true := by decide

private def q12Shape34T91 : Tree 12 := .split 22 q12Shape34T92 q12Shape34T93
private theorem q12Shape34T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100663296 657285054464 q12Shape34T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100663296 (657285054464 ||| 2^22) q12Shape34T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (100663296 ||| 2^22) 657285054464 q12Shape34T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T92OK,q12Shape34T93OK⟩

private def q12Shape34T94 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4395630592 652990087168 q12Shape34T94=true := by decide

private def q12Shape34T90 : Tree 12 := .split 32 q12Shape34T91 q12Shape34T94
private theorem q12Shape34T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100663296 652990087168 q12Shape34T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100663296 (652990087168 ||| 2^32) q12Shape34T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (100663296 ||| 2^32) 652990087168 q12Shape34T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T91OK,q12Shape34T94OK⟩

private def q12Shape34T95 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 234881024 652855869440 q12Shape34T95=true := by decide

private def q12Shape34T89 : Tree 12 := .split 27 q12Shape34T90 q12Shape34T95
private theorem q12Shape34T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100663296 652855869440 q12Shape34T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100663296 (652855869440 ||| 2^27) q12Shape34T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (100663296 ||| 2^27) 652855869440 q12Shape34T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T90OK,q12Shape34T95OK⟩

private def q12Shape34T61 : Tree 12 := .split 26 q12Shape34T62 q12Shape34T89
private theorem q12Shape34T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 652855869440 q12Shape34T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 (652855869440 ||| 2^26) q12Shape34T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33554432 ||| 2^26) 652855869440 q12Shape34T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T62OK,q12Shape34T89OK⟩

def q12Shape34P1 : Tree 12 := q12Shape34T61
theorem q12Shape34P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33554432 652855869440 q12Shape34P1=true := q12Shape34T61OK

end Graffiti384b.EffectiveSearch.Q12
