import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T617 : Tree 12 := (.split 28 (.split 42 (.split 37 (.tip (.cover {0,1,2,3,6,8,11})) (.split 40 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,9,10,11})))) (.tip (.cover {0,1,4,5,7,10,11}))) (.split 33 (.split 34 (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))))
private theorem q12Shape34T617OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 626243010560 q12Shape34T617=true := by decide

private def q12Shape34T618 : Tree 12 := (.split 28 (.split 29 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,6,8,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape34T618OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 36523999232 624095526912 q12Shape34T618=true := by decide

private def q12Shape34T616 : Tree 12 := .split 31 q12Shape34T617 q12Shape34T618
private theorem q12Shape34T616OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 624095526912 q12Shape34T616=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (624095526912 ||| 2^31) q12Shape34T617 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^31) 624095526912 q12Shape34T618)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T617OK,q12Shape34T618OK⟩

private def q12Shape34T619 : Tree 12 := (.split 31 (.split 28 (.split 29 (.split 37 (.tip (.cover {0,2,3,6,8,9,11})) (.split 44 (.tip (.cover {0,2,3,6,7,8,9})) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape34T619OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35450257408 623021785088 q12Shape34T619=true := by decide

private def q12Shape34T615 : Tree 12 := .split 30 q12Shape34T616 q12Shape34T619
private theorem q12Shape34T615OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 623021785088 q12Shape34T615=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (623021785088 ||| 2^30) q12Shape34T616 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^30) 623021785088 q12Shape34T619)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T616OK,q12Shape34T619OK⟩

private def q12Shape34T620 : Tree 12 := (.split 31 (.split 33 (.split 34 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,5,8,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape34T620OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34443624448 622954676224 q12Shape34T620=true := by decide

private def q12Shape34T614 : Tree 12 := .split 26 q12Shape34T615 q12Shape34T620
private theorem q12Shape34T614OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 622954676224 q12Shape34T614=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (622954676224 ||| 2^26) q12Shape34T615 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^26) 622954676224 q12Shape34T620)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T615OK,q12Shape34T620OK⟩

private def q12Shape34T621 : Tree 12 := (.split 26 (.split 30 (.split 33 (.split 34 (.split 37 (.tip (.cover {0,2,3,5,8,9,11})) (.split 31 (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11})))
private theorem q12Shape34T621OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34410070016 622921121792 q12Shape34T621=true := by decide

private def q12Shape34T613 : Tree 12 := .split 25 q12Shape34T614 q12Shape34T621
private theorem q12Shape34T613OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 622921121792 q12Shape34T613=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (622921121792 ||| 2^25) q12Shape34T614 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^25) 622921121792 q12Shape34T621)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T614OK,q12Shape34T621OK⟩

private def q12Shape34T622 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape34T622OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34384904192 622912733184 q12Shape34T622=true := by decide

private def q12Shape34T612 : Tree 12 := .split 23 q12Shape34T613 q12Shape34T622
private theorem q12Shape34T612OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 622912733184 q12Shape34T612=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (622912733184 ||| 2^23) q12Shape34T613 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^23) 622912733184 q12Shape34T622)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T613OK,q12Shape34T622OK⟩

private def q12Shape34T623 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape34T623OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34380709888 622908538880 q12Shape34T623=true := by decide

private def q12Shape34T611 : Tree 12 := .split 22 q12Shape34T612 q12Shape34T623
private theorem q12Shape34T611OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 622908538880 q12Shape34T611=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (622908538880 ||| 2^22) q12Shape34T612 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^22) 622908538880 q12Shape34T623)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T612OK,q12Shape34T623OK⟩

private def q12Shape34T624 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T624OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 38671482880 618613571584 q12Shape34T624=true := by decide

private def q12Shape34T610 : Tree 12 := .split 32 q12Shape34T611 q12Shape34T624
private theorem q12Shape34T610OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 618613571584 q12Shape34T610=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (618613571584 ||| 2^32) q12Shape34T611 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^32) 618613571584 q12Shape34T624)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T611OK,q12Shape34T624OK⟩

private def q12Shape34T625 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T625OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34510733312 618479353856 q12Shape34T625=true := by decide

private def q12Shape34T609 : Tree 12 := .split 27 q12Shape34T610 q12Shape34T625
private theorem q12Shape34T609OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 618479353856 q12Shape34T609=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (618479353856 ||| 2^27) q12Shape34T610 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^27) 618479353856 q12Shape34T625)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T610OK,q12Shape34T625OK⟩

private def q12Shape34T626 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T626OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34378612736 618477256704 q12Shape34T626=true := by decide

private def q12Shape34T608 : Tree 12 := .split 21 q12Shape34T609 q12Shape34T626
private theorem q12Shape34T608OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 618477256704 q12Shape34T608=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (618477256704 ||| 2^21) q12Shape34T609 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^21) 618477256704 q12Shape34T626)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T609OK,q12Shape34T626OK⟩

private def q12Shape34T627 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape34T627OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34377564160 618476208128 q12Shape34T627=true := by decide

private def q12Shape34T607 : Tree 12 := .split 20 q12Shape34T608 q12Shape34T627
private theorem q12Shape34T607OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 618476208128 q12Shape34T607=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (618476208128 ||| 2^20) q12Shape34T608 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^20) 618476208128 q12Shape34T627)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T608OK,q12Shape34T627OK⟩

private def q12Shape34T628 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape34T628OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34377039872 618475683840 q12Shape34T628=true := by decide

private def q12Shape34T606 : Tree 12 := .split 19 q12Shape34T607 q12Shape34T628
private theorem q12Shape34T606OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 618475683840 q12Shape34T606=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (618475683840 ||| 2^19) q12Shape34T607 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^19) 618475683840 q12Shape34T628)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T607OK,q12Shape34T628OK⟩

private def q12Shape34T629 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T629OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 584132329472 68719869952 q12Shape34T629=true := by decide

private def q12Shape34T605 : Tree 12 := .split 39 q12Shape34T606 q12Shape34T629
private theorem q12Shape34T605OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 68719869952 q12Shape34T605=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (68719869952 ||| 2^39) q12Shape34T606 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^39) 68719869952 q12Shape34T629)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T606OK,q12Shape34T629OK⟩

private def q12Shape34T630 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T630OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 103095992320 393216 q12Shape34T630=true := by decide

private def q12Shape34T604 : Tree 12 := .split 36 q12Shape34T605 q12Shape34T630
private theorem q12Shape34T604OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 393216 q12Shape34T604=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 (393216 ||| 2^36) q12Shape34T605 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34376515584 ||| 2^36) 393216 q12Shape34T630)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T605OK,q12Shape34T630OK⟩

def q12Shape34P12 : Tree 12 := q12Shape34T604
theorem q12Shape34P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34376515584 393216 q12Shape34P12=true := q12Shape34T604OK

end Graffiti384b.EffectiveSearch.Q12
