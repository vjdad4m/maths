import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T640 : Tree 12 := (.tip (.cover {0,1,2,3,6,10,11}))
private theorem q12Shape34T640OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 653103071232 q12Shape34T640=true := by decide

private def q12Shape34T644 : Tree 12 := (.split 34 (.split 37 (.split 38 (.split 40 (.split 32 (.split 28 (.tip (.cover {0,1,2,3,4,9,11})) (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,7,8,10,11})))) (.tip (.cover {1,2,3,4,5,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {1,2,3,4,5,10,11})))
private theorem q12Shape34T644OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134479872 664780013568 q12Shape34T644=true := by decide

private def q12Shape34T645 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T645OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8724414464 656190078976 q12Shape34T645=true := by decide

private def q12Shape34T643 : Tree 12 := .split 33 q12Shape34T644 q12Shape34T645
private theorem q12Shape34T643OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134479872 656190078976 q12Shape34T643=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134479872 (656190078976 ||| 2^33) q12Shape34T644 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134479872 ||| 2^33) 656190078976 q12Shape34T645)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T644OK,q12Shape34T645OK⟩

private def q12Shape34T646 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T646OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2281963520 654042595328 q12Shape34T646=true := by decide

private def q12Shape34T642 : Tree 12 := .split 31 q12Shape34T643 q12Shape34T646
private theorem q12Shape34T642OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134479872 654042595328 q12Shape34T642=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134479872 (654042595328 ||| 2^31) q12Shape34T643 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134479872 ||| 2^31) 654042595328 q12Shape34T646)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T643OK,q12Shape34T646OK⟩

private def q12Shape34T647 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T647OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1208221696 652968853504 q12Shape34T647=true := by decide

private def q12Shape34T641 : Tree 12 := .split 30 q12Shape34T642 q12Shape34T647
private theorem q12Shape34T641OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134479872 652968853504 q12Shape34T641=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134479872 (652968853504 ||| 2^30) q12Shape34T642 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134479872 ||| 2^30) 652968853504 q12Shape34T647)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T642OK,q12Shape34T647OK⟩

private def q12Shape34T639 : Tree 12 := .split 27 q12Shape34T640 q12Shape34T641
private theorem q12Shape34T639OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652968853504 q12Shape34T639=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652968853504 ||| 2^27) q12Shape34T640 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^27) 652968853504 q12Shape34T641)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T640OK,q12Shape34T641OK⟩

private def q12Shape34T652 : Tree 12 := (.split 34 (.split 37 (.split 38 (.split 42 (.split 31 (.split 28 (.tip (.cover {0,1,2,3,4,8,11})) (.split 40 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,7,9,10,11})))) (.tip (.cover {1,2,3,4,5,8,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {1,2,3,4,5,10,11})))
private theorem q12Shape34T652OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 666994606080 q12Shape34T652=true := by decide

private def q12Shape34T653 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T653OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8657305600 658404671488 q12Shape34T653=true := by decide

private def q12Shape34T651 : Tree 12 := .split 33 q12Shape34T652 q12Shape34T653
private theorem q12Shape34T651OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 658404671488 q12Shape34T651=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 (658404671488 ||| 2^33) q12Shape34T652 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67371008 ||| 2^33) 658404671488 q12Shape34T653)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T652OK,q12Shape34T653OK⟩

private def q12Shape34T654 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T654OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4362338304 654109704192 q12Shape34T654=true := by decide

private def q12Shape34T650 : Tree 12 := .split 32 q12Shape34T651 q12Shape34T654
private theorem q12Shape34T650OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 654109704192 q12Shape34T650=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 (654109704192 ||| 2^32) q12Shape34T651 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67371008 ||| 2^32) 654109704192 q12Shape34T654)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T651OK,q12Shape34T654OK⟩

private def q12Shape34T655 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T655OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1141112832 653035962368 q12Shape34T655=true := by decide

private def q12Shape34T649 : Tree 12 := .split 30 q12Shape34T650 q12Shape34T655
private theorem q12Shape34T649OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 653035962368 q12Shape34T649=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 (653035962368 ||| 2^30) q12Shape34T650 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67371008 ||| 2^30) 653035962368 q12Shape34T655)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T650OK,q12Shape34T655OK⟩

private def q12Shape34T656 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T656OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 201588736 652901744640 q12Shape34T656=true := by decide

private def q12Shape34T648 : Tree 12 := .split 27 q12Shape34T649 q12Shape34T656
private theorem q12Shape34T648OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 652901744640 q12Shape34T648=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67371008 (652901744640 ||| 2^27) q12Shape34T649 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67371008 ||| 2^27) 652901744640 q12Shape34T656)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T649OK,q12Shape34T656OK⟩

private def q12Shape34T638 : Tree 12 := .split 26 q12Shape34T639 q12Shape34T648
private theorem q12Shape34T638OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652901744640 q12Shape34T638=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652901744640 ||| 2^26) q12Shape34T639 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^26) 652901744640 q12Shape34T648)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T639OK,q12Shape34T648OK⟩

private def q12Shape34T662 : Tree 12 := (.split 34 (.split 40 (.split 41 (.split 42 (.split 30 (.split 28 (.tip (.cover {0,1,2,3,4,7,11})) (.split 37 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {1,2,3,4,5,7,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {1,2,3,4,5,10,11})))
private theorem q12Shape34T662OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 668101902336 q12Shape34T662=true := by decide

private def q12Shape34T663 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T663OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8623751168 659511967744 q12Shape34T663=true := by decide

private def q12Shape34T661 : Tree 12 := .split 33 q12Shape34T662 q12Shape34T663
private theorem q12Shape34T661OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 659511967744 q12Shape34T661=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 (659511967744 ||| 2^33) q12Shape34T662 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33816576 ||| 2^33) 659511967744 q12Shape34T663)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T662OK,q12Shape34T663OK⟩

private def q12Shape34T664 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T664OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4328783872 655217000448 q12Shape34T664=true := by decide

private def q12Shape34T660 : Tree 12 := .split 32 q12Shape34T661 q12Shape34T664
private theorem q12Shape34T660OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 655217000448 q12Shape34T660=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 (655217000448 ||| 2^32) q12Shape34T661 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33816576 ||| 2^32) 655217000448 q12Shape34T664)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T661OK,q12Shape34T664OK⟩

private def q12Shape34T665 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T665OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181300224 653069516800 q12Shape34T665=true := by decide

private def q12Shape34T659 : Tree 12 := .split 31 q12Shape34T660 q12Shape34T665
private theorem q12Shape34T659OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 653069516800 q12Shape34T659=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 (653069516800 ||| 2^31) q12Shape34T660 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33816576 ||| 2^31) 653069516800 q12Shape34T665)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T660OK,q12Shape34T665OK⟩

private def q12Shape34T666 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T666OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 168034304 652935299072 q12Shape34T666=true := by decide

private def q12Shape34T658 : Tree 12 := .split 27 q12Shape34T659 q12Shape34T666
private theorem q12Shape34T658OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 652935299072 q12Shape34T658=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 (652935299072 ||| 2^27) q12Shape34T659 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33816576 ||| 2^27) 652935299072 q12Shape34T666)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T659OK,q12Shape34T666OK⟩

private def q12Shape34T667 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T667OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100925440 652868190208 q12Shape34T667=true := by decide

private def q12Shape34T657 : Tree 12 := .split 26 q12Shape34T658 q12Shape34T667
private theorem q12Shape34T657OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 652868190208 q12Shape34T657=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33816576 (652868190208 ||| 2^26) q12Shape34T658 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33816576 ||| 2^26) 652868190208 q12Shape34T667)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T658OK,q12Shape34T667OK⟩

private def q12Shape34T637 : Tree 12 := .split 25 q12Shape34T638 q12Shape34T657
private theorem q12Shape34T637OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652868190208 q12Shape34T637=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652868190208 ||| 2^25) q12Shape34T638 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^25) 652868190208 q12Shape34T657)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T638OK,q12Shape34T657OK⟩

private def q12Shape34T668 : Tree 12 := (.tip (.cover {1,2,3,5,6,10,11}))
private theorem q12Shape34T668OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8650752 652859801600 q12Shape34T668=true := by decide

private def q12Shape34T636 : Tree 12 := .split 23 q12Shape34T637 q12Shape34T668
private theorem q12Shape34T636OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652859801600 q12Shape34T636=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652859801600 ||| 2^23) q12Shape34T637 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^23) 652859801600 q12Shape34T668)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T637OK,q12Shape34T668OK⟩

private def q12Shape34T669 : Tree 12 := (.tip (.cover {1,2,3,5,6,10,11}))
private theorem q12Shape34T669OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4456448 652855607296 q12Shape34T669=true := by decide

private def q12Shape34T635 : Tree 12 := .split 22 q12Shape34T636 q12Shape34T669
private theorem q12Shape34T635OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652855607296 q12Shape34T635=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652855607296 ||| 2^22) q12Shape34T636 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^22) 652855607296 q12Shape34T669)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T636OK,q12Shape34T669OK⟩

private def q12Shape34T675 : Tree 12 := (.split 32 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,2,3,6,10,11})))
private theorem q12Shape34T675OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 653893697536 q12Shape34T675=true := by decide

private def q12Shape34T678 : Tree 12 := (.split 32 (.split 22 (.split 23 (.split 33 (.split 34 (.split 37 (.split 40 (.tip (.cover {1,2,3,5,6,9,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape34T678OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 136577024 656980705280 q12Shape34T678=true := by decide

private def q12Shape34T679 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T679OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2284060672 654833221632 q12Shape34T679=true := by decide

private def q12Shape34T677 : Tree 12 := .split 31 q12Shape34T678 q12Shape34T679
private theorem q12Shape34T677OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 136577024 654833221632 q12Shape34T677=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 136577024 (654833221632 ||| 2^31) q12Shape34T678 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (136577024 ||| 2^31) 654833221632 q12Shape34T679)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T678OK,q12Shape34T679OK⟩

private def q12Shape34T680 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T680OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1210318848 653759479808 q12Shape34T680=true := by decide

private def q12Shape34T676 : Tree 12 := .split 30 q12Shape34T677 q12Shape34T680
private theorem q12Shape34T676OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 136577024 653759479808 q12Shape34T676=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 136577024 (653759479808 ||| 2^30) q12Shape34T677 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (136577024 ||| 2^30) 653759479808 q12Shape34T680)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T677OK,q12Shape34T680OK⟩

private def q12Shape34T674 : Tree 12 := .split 27 q12Shape34T675 q12Shape34T676
private theorem q12Shape34T674OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 653759479808 q12Shape34T674=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 (653759479808 ||| 2^27) q12Shape34T675 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2359296 ||| 2^27) 653759479808 q12Shape34T676)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T675OK,q12Shape34T676OK⟩

private def q12Shape34T681 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T681OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 539230208 653222608896 q12Shape34T681=true := by decide

private def q12Shape34T673 : Tree 12 := .split 29 q12Shape34T674 q12Shape34T681
private theorem q12Shape34T673OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 653222608896 q12Shape34T673=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 (653222608896 ||| 2^29) q12Shape34T674 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2359296 ||| 2^29) 653222608896 q12Shape34T681)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T674OK,q12Shape34T681OK⟩

private def q12Shape34T682 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T682OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 270794752 652954173440 q12Shape34T682=true := by decide

private def q12Shape34T672 : Tree 12 := .split 28 q12Shape34T673 q12Shape34T682
private theorem q12Shape34T672OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 652954173440 q12Shape34T672=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 (652954173440 ||| 2^28) q12Shape34T673 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2359296 ||| 2^28) 652954173440 q12Shape34T682)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T673OK,q12Shape34T682OK⟩

private def q12Shape34T683 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T683OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69468160 652887064576 q12Shape34T683=true := by decide

private def q12Shape34T671 : Tree 12 := .split 26 q12Shape34T672 q12Shape34T683
private theorem q12Shape34T671OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 652887064576 q12Shape34T671=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 (652887064576 ||| 2^26) q12Shape34T672 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2359296 ||| 2^26) 652887064576 q12Shape34T683)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T672OK,q12Shape34T683OK⟩

private def q12Shape34T684 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T684OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35913728 652853510144 q12Shape34T684=true := by decide

private def q12Shape34T670 : Tree 12 := .split 25 q12Shape34T671 q12Shape34T684
private theorem q12Shape34T670OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 652853510144 q12Shape34T670=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2359296 (652853510144 ||| 2^25) q12Shape34T671 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2359296 ||| 2^25) 652853510144 q12Shape34T684)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T671OK,q12Shape34T684OK⟩

private def q12Shape34T634 : Tree 12 := .split 21 q12Shape34T635 q12Shape34T670
private theorem q12Shape34T634OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652853510144 q12Shape34T634=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652853510144 ||| 2^21) q12Shape34T635 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^21) 652853510144 q12Shape34T670)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T635OK,q12Shape34T670OK⟩

private def q12Shape34T691 : Tree 12 := (.split 31 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,2,3,6,10,11})))
private theorem q12Shape34T691OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 653894746112 q12Shape34T691=true := by decide

private def q12Shape34T694 : Tree 12 := (.split 32 (.split 22 (.split 23 (.split 33 (.split 34 (.split 37 (.split 42 (.tip (.cover {1,2,3,5,6,8,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T694OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68419584 657048862720 q12Shape34T694=true := by decide

private def q12Shape34T695 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape34T695OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2215903232 654901379072 q12Shape34T695=true := by decide

private def q12Shape34T693 : Tree 12 := .split 31 q12Shape34T694 q12Shape34T695
private theorem q12Shape34T693OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68419584 654901379072 q12Shape34T693=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68419584 (654901379072 ||| 2^31) q12Shape34T694 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68419584 ||| 2^31) 654901379072 q12Shape34T695)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T694OK,q12Shape34T695OK⟩

private def q12Shape34T696 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T696OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1142161408 653827637248 q12Shape34T696=true := by decide

private def q12Shape34T692 : Tree 12 := .split 30 q12Shape34T693 q12Shape34T696
private theorem q12Shape34T692OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68419584 653827637248 q12Shape34T692=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68419584 (653827637248 ||| 2^30) q12Shape34T693 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68419584 ||| 2^30) 653827637248 q12Shape34T696)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T693OK,q12Shape34T696OK⟩

private def q12Shape34T690 : Tree 12 := .split 26 q12Shape34T691 q12Shape34T692
private theorem q12Shape34T690OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 653827637248 q12Shape34T690=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 (653827637248 ||| 2^26) q12Shape34T691 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1310720 ||| 2^26) 653827637248 q12Shape34T692)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T691OK,q12Shape34T692OK⟩

private def q12Shape34T697 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T697OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 538181632 653290766336 q12Shape34T697=true := by decide

private def q12Shape34T689 : Tree 12 := .split 29 q12Shape34T690 q12Shape34T697
private theorem q12Shape34T689OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 653290766336 q12Shape34T689=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 (653290766336 ||| 2^29) q12Shape34T690 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1310720 ||| 2^29) 653290766336 q12Shape34T697)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T690OK,q12Shape34T697OK⟩

private def q12Shape34T698 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T698OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 269746176 653022330880 q12Shape34T698=true := by decide

private def q12Shape34T688 : Tree 12 := .split 28 q12Shape34T689 q12Shape34T698
private theorem q12Shape34T688OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 653022330880 q12Shape34T688=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 (653022330880 ||| 2^28) q12Shape34T689 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1310720 ||| 2^28) 653022330880 q12Shape34T698)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T689OK,q12Shape34T698OK⟩

private def q12Shape34T699 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T699OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 135528448 652888113152 q12Shape34T699=true := by decide

private def q12Shape34T687 : Tree 12 := .split 27 q12Shape34T688 q12Shape34T699
private theorem q12Shape34T687OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 652888113152 q12Shape34T687=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 (652888113152 ||| 2^27) q12Shape34T688 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1310720 ||| 2^27) 652888113152 q12Shape34T699)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T688OK,q12Shape34T699OK⟩

private def q12Shape34T700 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T700OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34865152 652854558720 q12Shape34T700=true := by decide

private def q12Shape34T686 : Tree 12 := .split 25 q12Shape34T687 q12Shape34T700
private theorem q12Shape34T686OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 652854558720 q12Shape34T686=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 (652854558720 ||| 2^25) q12Shape34T687 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1310720 ||| 2^25) 652854558720 q12Shape34T700)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T687OK,q12Shape34T700OK⟩

private def q12Shape34T701 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T701OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 3407872 652852461568 q12Shape34T701=true := by decide

private def q12Shape34T685 : Tree 12 := .split 21 q12Shape34T686 q12Shape34T701
private theorem q12Shape34T685OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 652852461568 q12Shape34T685=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1310720 (652852461568 ||| 2^21) q12Shape34T686 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1310720 ||| 2^21) 652852461568 q12Shape34T701)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T686OK,q12Shape34T701OK⟩

private def q12Shape34T633 : Tree 12 := .split 20 q12Shape34T634 q12Shape34T685
private theorem q12Shape34T633OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652852461568 q12Shape34T633=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 (652852461568 ||| 2^20) q12Shape34T634 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (262144 ||| 2^20) 652852461568 q12Shape34T685)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T634OK,q12Shape34T685OK⟩

def q12Shape34P13 : Tree 12 := q12Shape34T633
theorem q12Shape34P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 262144 652852461568 q12Shape34P13=true := q12Shape34T633OK

end Graffiti384b.EffectiveSearch.Q12
