import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T709 : Tree 12 := (.split 30 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,2,3,6,10,11})))
private theorem q12Shape34T709OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 653895270400 q12Shape34T709=true := by decide

private def q12Shape34T712 : Tree 12 := (.split 32 (.split 22 (.split 23 (.split 33 (.split 34 (.split 40 (.split 42 (.tip (.cover {1,2,3,5,6,7,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T712OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34340864 657082941440 q12Shape34T712=true := by decide

private def q12Shape34T713 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T713OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181824512 654935457792 q12Shape34T713=true := by decide

private def q12Shape34T711 : Tree 12 := .split 31 q12Shape34T712 q12Shape34T713
private theorem q12Shape34T711OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34340864 654935457792 q12Shape34T711=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34340864 (654935457792 ||| 2^31) q12Shape34T712 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34340864 ||| 2^31) 654935457792 q12Shape34T713)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T712OK,q12Shape34T713OK⟩

private def q12Shape34T714 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape34T714OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1108082688 653861715968 q12Shape34T714=true := by decide

private def q12Shape34T710 : Tree 12 := .split 30 q12Shape34T711 q12Shape34T714
private theorem q12Shape34T710OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34340864 653861715968 q12Shape34T710=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34340864 (653861715968 ||| 2^30) q12Shape34T711 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34340864 ||| 2^30) 653861715968 q12Shape34T714)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T711OK,q12Shape34T714OK⟩

private def q12Shape34T708 : Tree 12 := .split 25 q12Shape34T709 q12Shape34T710
private theorem q12Shape34T708OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 653861715968 q12Shape34T708=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 (653861715968 ||| 2^25) q12Shape34T709 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (786432 ||| 2^25) 653861715968 q12Shape34T710)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T709OK,q12Shape34T710OK⟩

private def q12Shape34T715 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T715OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 537657344 653324845056 q12Shape34T715=true := by decide

private def q12Shape34T707 : Tree 12 := .split 29 q12Shape34T708 q12Shape34T715
private theorem q12Shape34T707OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 653324845056 q12Shape34T707=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 (653324845056 ||| 2^29) q12Shape34T708 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (786432 ||| 2^29) 653324845056 q12Shape34T715)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T708OK,q12Shape34T715OK⟩

private def q12Shape34T716 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T716OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 269221888 653056409600 q12Shape34T716=true := by decide

private def q12Shape34T706 : Tree 12 := .split 28 q12Shape34T707 q12Shape34T716
private theorem q12Shape34T706OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 653056409600 q12Shape34T706=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 (653056409600 ||| 2^28) q12Shape34T707 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (786432 ||| 2^28) 653056409600 q12Shape34T716)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T707OK,q12Shape34T716OK⟩

private def q12Shape34T717 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T717OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 135004160 652922191872 q12Shape34T717=true := by decide

private def q12Shape34T705 : Tree 12 := .split 27 q12Shape34T706 q12Shape34T717
private theorem q12Shape34T705OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 652922191872 q12Shape34T705=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 (652922191872 ||| 2^27) q12Shape34T706 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (786432 ||| 2^27) 652922191872 q12Shape34T717)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T706OK,q12Shape34T717OK⟩

private def q12Shape34T718 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T718OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67895296 652855083008 q12Shape34T718=true := by decide

private def q12Shape34T704 : Tree 12 := .split 26 q12Shape34T705 q12Shape34T718
private theorem q12Shape34T704OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 652855083008 q12Shape34T704=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 (652855083008 ||| 2^26) q12Shape34T705 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (786432 ||| 2^26) 652855083008 q12Shape34T718)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T705OK,q12Shape34T718OK⟩

private def q12Shape34T719 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T719OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2883584 652852985856 q12Shape34T719=true := by decide

private def q12Shape34T703 : Tree 12 := .split 21 q12Shape34T704 q12Shape34T719
private theorem q12Shape34T703OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 652852985856 q12Shape34T703=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 (652852985856 ||| 2^21) q12Shape34T704 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (786432 ||| 2^21) 652852985856 q12Shape34T719)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T704OK,q12Shape34T719OK⟩

private def q12Shape34T720 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T720OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1835008 652851937280 q12Shape34T720=true := by decide

private def q12Shape34T702 : Tree 12 := .split 20 q12Shape34T703 q12Shape34T720
private theorem q12Shape34T702OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 652851937280 q12Shape34T702=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 (652851937280 ||| 2^20) q12Shape34T703 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (786432 ||| 2^20) 652851937280 q12Shape34T720)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T703OK,q12Shape34T720OK⟩

def q12Shape34P14 : Tree 12 := q12Shape34T702
theorem q12Shape34P14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 786432 652851937280 q12Shape34P14=true := q12Shape34T702OK

private def q12Shape34T735 : Tree 12 := (.split 22 (.split 40 (.tip (.cover {0,1,2,3,6,9,11})) (.split 42 (.tip (.cover {0,1,2,3,6,8,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.split 33 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape34T735OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 523973033984 q12Shape34T735=true := by decide

private def q12Shape34T736 : Tree 12 := (.split 22 (.split 40 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape34T736OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 554051043328 519678066688 q12Shape34T736=true := by decide

private def q12Shape34T734 : Tree 12 := .split 32 q12Shape34T735 q12Shape34T736
private theorem q12Shape34T734OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 519678066688 q12Shape34T734=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (519678066688 ||| 2^32) q12Shape34T735 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^32) 519678066688 q12Shape34T736)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T735OK,q12Shape34T736OK⟩

private def q12Shape34T737 : Tree 12 := (.split 32 (.split 22 (.split 42 (.tip (.cover {0,1,2,3,6,8,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T737OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 551903559680 517530583040 q12Shape34T737=true := by decide

private def q12Shape34T733 : Tree 12 := .split 31 q12Shape34T734 q12Shape34T737
private theorem q12Shape34T733OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 517530583040 q12Shape34T733=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (517530583040 ||| 2^31) q12Shape34T734 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^31) 517530583040 q12Shape34T737)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T734OK,q12Shape34T737OK⟩

private def q12Shape34T738 : Tree 12 := (.split 32 (.split 33 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape34T738OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549758173184 517528485888 q12Shape34T738=true := by decide

private def q12Shape34T732 : Tree 12 := .split 21 q12Shape34T733 q12Shape34T738
private theorem q12Shape34T732OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 517528485888 q12Shape34T732=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (517528485888 ||| 2^21) q12Shape34T733 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^21) 517528485888 q12Shape34T738)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T733OK,q12Shape34T738OK⟩

private def q12Shape34T739 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T739OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 824633982976 242650578944 q12Shape34T739=true := by decide

private def q12Shape34T731 : Tree 12 := .split 38 q12Shape34T732 q12Shape34T739
private theorem q12Shape34T731OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 242650578944 q12Shape34T731=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (242650578944 ||| 2^38) q12Shape34T732 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^38) 242650578944 q12Shape34T739)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T732OK,q12Shape34T739OK⟩

private def q12Shape34T740 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T740OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 687195029504 105211625472 q12Shape34T740=true := by decide

private def q12Shape34T730 : Tree 12 := .split 37 q12Shape34T731 q12Shape34T740
private theorem q12Shape34T730OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 105211625472 q12Shape34T730=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (105211625472 ||| 2^37) q12Shape34T731 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^37) 105211625472 q12Shape34T740)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T731OK,q12Shape34T740OK⟩

private def q12Shape34T741 : Tree 12 := (.split 21 (.split 31 (.split 33 (.split 34 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape34T741OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549757124608 105210576896 q12Shape34T741=true := by decide

private def q12Shape34T729 : Tree 12 := .split 20 q12Shape34T730 q12Shape34T741
private theorem q12Shape34T729OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 105210576896 q12Shape34T729=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (105210576896 ||| 2^20) q12Shape34T730 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^20) 105210576896 q12Shape34T741)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T730OK,q12Shape34T741OK⟩

private def q12Shape34T742 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T742OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550292946944 104673705984 q12Shape34T742=true := by decide

private def q12Shape34T728 : Tree 12 := .split 29 q12Shape34T729 q12Shape34T742
private theorem q12Shape34T728OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 104673705984 q12Shape34T728=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (104673705984 ||| 2^29) q12Shape34T729 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^29) 104673705984 q12Shape34T742)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T729OK,q12Shape34T742OK⟩

private def q12Shape34T743 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T743OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550024511488 104405270528 q12Shape34T743=true := by decide

private def q12Shape34T727 : Tree 12 := .split 28 q12Shape34T728 q12Shape34T743
private theorem q12Shape34T727OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 104405270528 q12Shape34T727=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (104405270528 ||| 2^28) q12Shape34T728 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^28) 104405270528 q12Shape34T743)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T728OK,q12Shape34T743OK⟩

private def q12Shape34T744 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T744OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550829817856 103331528704 q12Shape34T744=true := by decide

private def q12Shape34T726 : Tree 12 := .split 30 q12Shape34T727 q12Shape34T744
private theorem q12Shape34T726OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 103331528704 q12Shape34T726=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (103331528704 ||| 2^30) q12Shape34T727 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^30) 103331528704 q12Shape34T744)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T727OK,q12Shape34T744OK⟩

private def q12Shape34T745 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T745OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549890293760 103197310976 q12Shape34T745=true := by decide

private def q12Shape34T725 : Tree 12 := .split 27 q12Shape34T726 q12Shape34T745
private theorem q12Shape34T725OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 103197310976 q12Shape34T725=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (103197310976 ||| 2^27) q12Shape34T726 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^27) 103197310976 q12Shape34T745)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T726OK,q12Shape34T745OK⟩

private def q12Shape34T746 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T746OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549823184896 103130202112 q12Shape34T746=true := by decide

private def q12Shape34T724 : Tree 12 := .split 26 q12Shape34T725 q12Shape34T746
private theorem q12Shape34T724OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 103130202112 q12Shape34T724=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (103130202112 ||| 2^26) q12Shape34T725 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^26) 103130202112 q12Shape34T746)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T725OK,q12Shape34T746OK⟩

private def q12Shape34T747 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T747OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789630464 103096647680 q12Shape34T747=true := by decide

private def q12Shape34T723 : Tree 12 := .split 25 q12Shape34T724 q12Shape34T747
private theorem q12Shape34T723OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 103096647680 q12Shape34T723=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (103096647680 ||| 2^25) q12Shape34T724 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^25) 103096647680 q12Shape34T747)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T724OK,q12Shape34T747OK⟩

private def q12Shape34T748 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T748OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756600320 103096123392 q12Shape34T748=true := by decide

private def q12Shape34T722 : Tree 12 := .split 19 q12Shape34T723 q12Shape34T748
private theorem q12Shape34T722OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 103096123392 q12Shape34T722=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 (103096123392 ||| 2^19) q12Shape34T723 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756076032 ||| 2^19) 103096123392 q12Shape34T748)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T723OK,q12Shape34T748OK⟩

def q12Shape34P15 : Tree 12 := q12Shape34T722
theorem q12Shape34P15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756076032 103096123392 q12Shape34P15=true := q12Shape34T722OK

private def q12Shape34T764 : Tree 12 := (.split 22 (.split 37 (.tip (.cover {0,1,2,3,6,9,11})) (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,8,10,11})))) (.split 33 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape34T764OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 3891227394048 q12Shape34T764=true := by decide

private def q12Shape34T765 : Tree 12 := (.split 22 (.split 37 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape34T765OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 73014706176 3886932426752 q12Shape34T765=true := by decide

private def q12Shape34T763 : Tree 12 := .split 32 q12Shape34T764 q12Shape34T765
private theorem q12Shape34T763OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 3886932426752 q12Shape34T763=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (3886932426752 ||| 2^32) q12Shape34T764 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^32) 3886932426752 q12Shape34T765)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T764OK,q12Shape34T765OK⟩

private def q12Shape34T766 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T766OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2267742994432 1687909171200 q12Shape34T766=true := by decide

private def q12Shape34T762 : Tree 12 := .split 41 q12Shape34T763 q12Shape34T766
private theorem q12Shape34T762OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 1687909171200 q12Shape34T762=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (1687909171200 ||| 2^41) q12Shape34T763 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^41) 1687909171200 q12Shape34T766)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T763OK,q12Shape34T766OK⟩

private def q12Shape34T767 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T767OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1168231366656 588397543424 q12Shape34T767=true := by decide

private def q12Shape34T761 : Tree 12 := .split 40 q12Shape34T762 q12Shape34T767
private theorem q12Shape34T761OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 588397543424 q12Shape34T761=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (588397543424 ||| 2^40) q12Shape34T762 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^40) 588397543424 q12Shape34T767)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T762OK,q12Shape34T767OK⟩

private def q12Shape34T768 : Tree 12 := (.split 32 (.split 22 (.split 23 (.split 37 (.tip (.cover {0,2,3,6,8,9,11})) (.split 44 (.tip (.cover {0,2,3,6,7,8,9})) (.tip (.cover {0,1,4,5,7,8,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T768OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69793480704 587323801600 q12Shape34T768=true := by decide

private def q12Shape34T760 : Tree 12 := .split 30 q12Shape34T761 q12Shape34T768
private theorem q12Shape34T760OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 587323801600 q12Shape34T760=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (587323801600 ||| 2^30) q12Shape34T761 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^30) 587323801600 q12Shape34T768)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T761OK,q12Shape34T768OK⟩

private def q12Shape34T769 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 37 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape34T769OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68721836032 587321704448 q12Shape34T769=true := by decide

private def q12Shape34T759 : Tree 12 := .split 21 q12Shape34T760 q12Shape34T769
private theorem q12Shape34T759OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 587321704448 q12Shape34T759=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (587321704448 ||| 2^21) q12Shape34T760 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^21) 587321704448 q12Shape34T769)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T760OK,q12Shape34T769OK⟩

private def q12Shape34T770 : Tree 12 := (.split 21 (.split 30 (.split 33 (.split 34 (.split 37 (.tip (.cover {0,2,3,4,8,9,11})) (.split 32 (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,5,6,8,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape34T770OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720263168 587321180160 q12Shape34T770=true := by decide

private def q12Shape34T758 : Tree 12 := .split 19 q12Shape34T759 q12Shape34T770
private theorem q12Shape34T758OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 587321180160 q12Shape34T758=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (587321180160 ||| 2^19) q12Shape34T759 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^19) 587321180160 q12Shape34T770)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T759OK,q12Shape34T770OK⟩

private def q12Shape34T771 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T771OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69256609792 586784309248 q12Shape34T771=true := by decide

private def q12Shape34T757 : Tree 12 := .split 29 q12Shape34T758 q12Shape34T771
private theorem q12Shape34T757OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 586784309248 q12Shape34T757=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (586784309248 ||| 2^29) q12Shape34T758 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^29) 586784309248 q12Shape34T771)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T758OK,q12Shape34T771OK⟩

private def q12Shape34T772 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T772OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68988174336 586515873792 q12Shape34T772=true := by decide

private def q12Shape34T756 : Tree 12 := .split 28 q12Shape34T757 q12Shape34T772
private theorem q12Shape34T756OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 586515873792 q12Shape34T756=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (586515873792 ||| 2^28) q12Shape34T757 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^28) 586515873792 q12Shape34T772)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T757OK,q12Shape34T772OK⟩

private def q12Shape34T773 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T773OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 70867222528 584368390144 q12Shape34T773=true := by decide

private def q12Shape34T755 : Tree 12 := .split 31 q12Shape34T756 q12Shape34T773
private theorem q12Shape34T755OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 584368390144 q12Shape34T755=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (584368390144 ||| 2^31) q12Shape34T756 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^31) 584368390144 q12Shape34T773)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T756OK,q12Shape34T773OK⟩

private def q12Shape34T774 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T774OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68853956608 584234172416 q12Shape34T774=true := by decide

private def q12Shape34T754 : Tree 12 := .split 27 q12Shape34T755 q12Shape34T774
private theorem q12Shape34T754OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 584234172416 q12Shape34T754=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (584234172416 ||| 2^27) q12Shape34T755 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^27) 584234172416 q12Shape34T774)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T755OK,q12Shape34T774OK⟩

private def q12Shape34T775 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T775OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786847744 584167063552 q12Shape34T775=true := by decide

private def q12Shape34T753 : Tree 12 := .split 26 q12Shape34T754 q12Shape34T775
private theorem q12Shape34T753OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 584167063552 q12Shape34T753=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (584167063552 ||| 2^26) q12Shape34T754 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^26) 584167063552 q12Shape34T775)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T754OK,q12Shape34T775OK⟩

private def q12Shape34T776 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T776OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68753293312 584133509120 q12Shape34T776=true := by decide

private def q12Shape34T752 : Tree 12 := .split 25 q12Shape34T753 q12Shape34T776
private theorem q12Shape34T752OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 584133509120 q12Shape34T752=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (584133509120 ||| 2^25) q12Shape34T753 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^25) 584133509120 q12Shape34T776)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T753OK,q12Shape34T776OK⟩

private def q12Shape34T777 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T777OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720787456 584132460544 q12Shape34T777=true := by decide

private def q12Shape34T751 : Tree 12 := .split 20 q12Shape34T752 q12Shape34T777
private theorem q12Shape34T751OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 584132460544 q12Shape34T751=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (584132460544 ||| 2^20) q12Shape34T752 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^20) 584132460544 q12Shape34T777)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T752OK,q12Shape34T777OK⟩

private def q12Shape34T778 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T778OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 618475552768 34376646656 q12Shape34T778=true := by decide

private def q12Shape34T750 : Tree 12 := .split 39 q12Shape34T751 q12Shape34T778
private theorem q12Shape34T750OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 34376646656 q12Shape34T750=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 (34376646656 ||| 2^39) q12Shape34T751 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719738880 ||| 2^39) 34376646656 q12Shape34T778)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T751OK,q12Shape34T778OK⟩

def q12Shape34P16 : Tree 12 := q12Shape34T750
theorem q12Shape34P16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719738880 34376646656 q12Shape34P16=true := q12Shape34T750OK

end Graffiti384b.EffectiveSearch.Q12
