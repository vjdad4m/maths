import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T821 : Tree 12 := (.split 32 (.tip (.cover {0,1,2,3,4,10,11})) (.split 37 (.split 38 (.split 40 (.split 33 (.tip (.cover {0,1,2,3,4,9,11})) (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,7,8,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape34T821OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 657129734144 q12Shape34T821=true := by decide

private def q12Shape34T822 : Tree 12 := (.split 32 (.split 37 (.split 38 (.split 42 (.split 33 (.tip (.cover {0,1,2,3,4,8,11})) (.split 40 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,7,9,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape34T822OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2147614720 654982250496 q12Shape34T822=true := by decide

private def q12Shape34T820 : Tree 12 := .split 31 q12Shape34T821 q12Shape34T822
private theorem q12Shape34T820OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 654982250496 q12Shape34T820=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (654982250496 ||| 2^31) q12Shape34T821 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^31) 654982250496 q12Shape34T822)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T821OK,q12Shape34T822OK⟩

private def q12Shape34T823 : Tree 12 := (.split 31 (.split 32 (.split 40 (.split 41 (.split 42 (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.split 37 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape34T823OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1073872896 653908508672 q12Shape34T823=true := by decide

private def q12Shape34T819 : Tree 12 := .split 30 q12Shape34T820 q12Shape34T823
private theorem q12Shape34T819OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 653908508672 q12Shape34T819=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (653908508672 ||| 2^30) q12Shape34T820 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^30) 653908508672 q12Shape34T823)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T820OK,q12Shape34T823OK⟩

private def q12Shape34T824 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T824OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 537001984 653371637760 q12Shape34T824=true := by decide

private def q12Shape34T818 : Tree 12 := .split 29 q12Shape34T819 q12Shape34T824
private theorem q12Shape34T818OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 653371637760 q12Shape34T818=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (653371637760 ||| 2^29) q12Shape34T819 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^29) 653371637760 q12Shape34T824)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T819OK,q12Shape34T824OK⟩

private def q12Shape34T825 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T825OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 268566528 653103202304 q12Shape34T825=true := by decide

private def q12Shape34T817 : Tree 12 := .split 28 q12Shape34T818 q12Shape34T825
private theorem q12Shape34T817OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 653103202304 q12Shape34T817=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (653103202304 ||| 2^28) q12Shape34T818 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^28) 653103202304 q12Shape34T825)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T818OK,q12Shape34T825OK⟩

private def q12Shape34T828 : Tree 12 := (.split 32 (.tip (.cover {0,1,2,3,5,10,11})) (.split 28 (.split 29 (.split 33 (.split 34 (.split 37 (.split 40 (.tip (.cover {1,2,3,4,6,9,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {1,2,3,4,6,10,11}))) (.tip (.cover {1,2,3,4,6,10,11}))))
private theorem q12Shape34T828OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134348800 656190210048 q12Shape34T828=true := by decide

private def q12Shape34T829 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T829OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2281832448 654042726400 q12Shape34T829=true := by decide

private def q12Shape34T827 : Tree 12 := .split 31 q12Shape34T828 q12Shape34T829
private theorem q12Shape34T827OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134348800 654042726400 q12Shape34T827=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134348800 (654042726400 ||| 2^31) q12Shape34T828 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134348800 ||| 2^31) 654042726400 q12Shape34T829)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T828OK,q12Shape34T829OK⟩

private def q12Shape34T830 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T830OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1208090624 652968984576 q12Shape34T830=true := by decide

private def q12Shape34T826 : Tree 12 := .split 30 q12Shape34T827 q12Shape34T830
private theorem q12Shape34T826OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134348800 652968984576 q12Shape34T826=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134348800 (652968984576 ||| 2^30) q12Shape34T827 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134348800 ||| 2^30) 652968984576 q12Shape34T830)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T827OK,q12Shape34T830OK⟩

private def q12Shape34T816 : Tree 12 := .split 27 q12Shape34T817 q12Shape34T826
private theorem q12Shape34T816OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652968984576 q12Shape34T816=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652968984576 ||| 2^27) q12Shape34T817 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^27) 652968984576 q12Shape34T826)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T817OK,q12Shape34T826OK⟩

private def q12Shape34T834 : Tree 12 := (.split 31 (.tip (.cover {0,1,2,3,5,10,11})) (.split 28 (.split 29 (.split 33 (.split 34 (.split 37 (.split 42 (.tip (.cover {1,2,3,4,6,8,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {1,2,3,4,6,10,11}))) (.tip (.cover {1,2,3,4,6,10,11}))))
private theorem q12Shape34T834OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67239936 658404802560 q12Shape34T834=true := by decide

private def q12Shape34T835 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T835OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4362207232 654109835264 q12Shape34T835=true := by decide

private def q12Shape34T833 : Tree 12 := .split 32 q12Shape34T834 q12Shape34T835
private theorem q12Shape34T833OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67239936 654109835264 q12Shape34T833=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67239936 (654109835264 ||| 2^32) q12Shape34T834 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67239936 ||| 2^32) 654109835264 q12Shape34T835)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T834OK,q12Shape34T835OK⟩

private def q12Shape34T836 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T836OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1140981760 653036093440 q12Shape34T836=true := by decide

private def q12Shape34T832 : Tree 12 := .split 30 q12Shape34T833 q12Shape34T836
private theorem q12Shape34T832OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67239936 653036093440 q12Shape34T832=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67239936 (653036093440 ||| 2^30) q12Shape34T833 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67239936 ||| 2^30) 653036093440 q12Shape34T836)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T833OK,q12Shape34T836OK⟩

private def q12Shape34T837 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T837OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 201457664 652901875712 q12Shape34T837=true := by decide

private def q12Shape34T831 : Tree 12 := .split 27 q12Shape34T832 q12Shape34T837
private theorem q12Shape34T831OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67239936 652901875712 q12Shape34T831=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67239936 (652901875712 ||| 2^27) q12Shape34T832 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67239936 ||| 2^27) 652901875712 q12Shape34T837)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T832OK,q12Shape34T837OK⟩

private def q12Shape34T815 : Tree 12 := .split 26 q12Shape34T816 q12Shape34T831
private theorem q12Shape34T815OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652901875712 q12Shape34T815=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652901875712 ||| 2^26) q12Shape34T816 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^26) 652901875712 q12Shape34T831)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T816OK,q12Shape34T831OK⟩

private def q12Shape34T842 : Tree 12 := (.split 30 (.tip (.cover {0,1,2,3,5,10,11})) (.split 28 (.split 29 (.split 33 (.split 34 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,6,7,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {1,2,3,4,6,10,11}))) (.tip (.cover {1,2,3,4,6,10,11}))))
private theorem q12Shape34T842OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 659512098816 q12Shape34T842=true := by decide

private def q12Shape34T843 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T843OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4328652800 655217131520 q12Shape34T843=true := by decide

private def q12Shape34T841 : Tree 12 := .split 32 q12Shape34T842 q12Shape34T843
private theorem q12Shape34T841OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 655217131520 q12Shape34T841=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 (655217131520 ||| 2^32) q12Shape34T842 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33685504 ||| 2^32) 655217131520 q12Shape34T843)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T842OK,q12Shape34T843OK⟩

private def q12Shape34T844 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T844OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181169152 653069647872 q12Shape34T844=true := by decide

private def q12Shape34T840 : Tree 12 := .split 31 q12Shape34T841 q12Shape34T844
private theorem q12Shape34T840OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 653069647872 q12Shape34T840=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 (653069647872 ||| 2^31) q12Shape34T841 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33685504 ||| 2^31) 653069647872 q12Shape34T844)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T841OK,q12Shape34T844OK⟩

private def q12Shape34T845 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T845OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 167903232 652935430144 q12Shape34T845=true := by decide

private def q12Shape34T839 : Tree 12 := .split 27 q12Shape34T840 q12Shape34T845
private theorem q12Shape34T839OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 652935430144 q12Shape34T839=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 (652935430144 ||| 2^27) q12Shape34T840 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33685504 ||| 2^27) 652935430144 q12Shape34T845)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T840OK,q12Shape34T845OK⟩

private def q12Shape34T846 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T846OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 100794368 652868321280 q12Shape34T846=true := by decide

private def q12Shape34T838 : Tree 12 := .split 26 q12Shape34T839 q12Shape34T846
private theorem q12Shape34T838OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 652868321280 q12Shape34T838=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 33685504 (652868321280 ||| 2^26) q12Shape34T839 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (33685504 ||| 2^26) 652868321280 q12Shape34T846)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T839OK,q12Shape34T846OK⟩

private def q12Shape34T814 : Tree 12 := .split 25 q12Shape34T815 q12Shape34T838
private theorem q12Shape34T814OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652868321280 q12Shape34T814=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652868321280 ||| 2^25) q12Shape34T815 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^25) 652868321280 q12Shape34T838)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T815OK,q12Shape34T838OK⟩

private def q12Shape34T847 : Tree 12 := (.tip (.cover {1,2,3,5,6,10,11}))
private theorem q12Shape34T847OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8519680 652859932672 q12Shape34T847=true := by decide

private def q12Shape34T813 : Tree 12 := .split 23 q12Shape34T814 q12Shape34T847
private theorem q12Shape34T813OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652859932672 q12Shape34T813=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652859932672 ||| 2^23) q12Shape34T814 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^23) 652859932672 q12Shape34T847)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T814OK,q12Shape34T847OK⟩

private def q12Shape34T848 : Tree 12 := (.tip (.cover {1,2,3,5,6,10,11}))
private theorem q12Shape34T848OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4325376 652855738368 q12Shape34T848=true := by decide

private def q12Shape34T812 : Tree 12 := .split 22 q12Shape34T813 q12Shape34T848
private theorem q12Shape34T812OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652855738368 q12Shape34T812=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652855738368 ||| 2^22) q12Shape34T813 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^22) 652855738368 q12Shape34T848)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T813OK,q12Shape34T848OK⟩

private def q12Shape34T852 : Tree 12 := (.split 33 (.split 34 (.split 37 (.split 38 (.split 40 (.split 22 (.tip (.cover {1,2,3,5,6,9,11})) (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {1,2,3,5,6,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape34T852OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2228224 656108421120 q12Shape34T852=true := by decide

private def q12Shape34T855 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T855OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35782656 656276193280 q12Shape34T855=true := by decide

private def q12Shape34T856 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T856OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 170000384 656141975552 q12Shape34T856=true := by decide

private def q12Shape34T854 : Tree 12 := .split 27 q12Shape34T855 q12Shape34T856
private theorem q12Shape34T854OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35782656 656141975552 q12Shape34T854=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35782656 (656141975552 ||| 2^27) q12Shape34T855 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35782656 ||| 2^27) 656141975552 q12Shape34T856)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T855OK,q12Shape34T856OK⟩

private def q12Shape34T857 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T857OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 102891520 656074866688 q12Shape34T857=true := by decide

private def q12Shape34T853 : Tree 12 := .split 26 q12Shape34T854 q12Shape34T857
private theorem q12Shape34T853OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35782656 656074866688 q12Shape34T853=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35782656 (656074866688 ||| 2^26) q12Shape34T854 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35782656 ||| 2^26) 656074866688 q12Shape34T857)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T854OK,q12Shape34T857OK⟩

private def q12Shape34T851 : Tree 12 := .split 25 q12Shape34T852 q12Shape34T853
private theorem q12Shape34T851OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2228224 656074866688 q12Shape34T851=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2228224 (656074866688 ||| 2^25) q12Shape34T852 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2228224 ||| 2^25) 656074866688 q12Shape34T853)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T852OK,q12Shape34T853OK⟩

private def q12Shape34T858 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T858OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149711872 653927383040 q12Shape34T858=true := by decide

private def q12Shape34T850 : Tree 12 := .split 31 q12Shape34T851 q12Shape34T858
private theorem q12Shape34T850OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2228224 653927383040 q12Shape34T850=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2228224 (653927383040 ||| 2^31) q12Shape34T851 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2228224 ||| 2^31) 653927383040 q12Shape34T858)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T851OK,q12Shape34T858OK⟩

private def q12Shape34T859 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T859OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075970048 652853641216 q12Shape34T859=true := by decide

private def q12Shape34T849 : Tree 12 := .split 30 q12Shape34T850 q12Shape34T859
private theorem q12Shape34T849OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2228224 652853641216 q12Shape34T849=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2228224 (652853641216 ||| 2^30) q12Shape34T850 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2228224 ||| 2^30) 652853641216 q12Shape34T859)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T850OK,q12Shape34T859OK⟩

private def q12Shape34T811 : Tree 12 := .split 21 q12Shape34T812 q12Shape34T849
private theorem q12Shape34T811OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652853641216 q12Shape34T811=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 (652853641216 ||| 2^21) q12Shape34T812 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (131072 ||| 2^21) 652853641216 q12Shape34T849)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T812OK,q12Shape34T849OK⟩

def q12Shape34P19 : Tree 12 := q12Shape34T811
theorem q12Shape34P19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 131072 652853641216 q12Shape34P19=true := q12Shape34T811OK

end Graffiti384b.EffectiveSearch.Q12
