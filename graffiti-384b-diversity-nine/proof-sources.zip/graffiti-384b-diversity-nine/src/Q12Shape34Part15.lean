import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T869 : Tree 12 := (.split 27 (.split 31 (.tip (.cover {0,1,2,3,4,10,11})) (.split 22 (.split 42 (.tip (.cover {1,2,3,5,6,8,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {1,2,3,5,6,10,11})))) (.split 31 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape34T869OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 1096410726400 q12Shape34T869=true := by decide

private def q12Shape34T870 : Tree 12 := (.split 27 (.tip (.cover {0,1,2,3,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T870OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68288512 1096343617536 q12Shape34T870=true := by decide

private def q12Shape34T868 : Tree 12 := .split 26 q12Shape34T869 q12Shape34T870
private theorem q12Shape34T868OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 1096343617536 q12Shape34T868=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (1096343617536 ||| 2^26) q12Shape34T869 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^26) 1096343617536 q12Shape34T870)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T869OK,q12Shape34T870OK⟩

private def q12Shape34T871 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T871OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 274879086592 821465710592 q12Shape34T871=true := by decide

private def q12Shape34T867 : Tree 12 := .split 38 q12Shape34T868 q12Shape34T871
private theorem q12Shape34T867OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 821465710592 q12Shape34T867=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (821465710592 ||| 2^38) q12Shape34T868 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^38) 821465710592 q12Shape34T871)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T868OK,q12Shape34T871OK⟩

private def q12Shape34T872 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T872OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 137440133120 684026757120 q12Shape34T872=true := by decide

private def q12Shape34T866 : Tree 12 := .split 37 q12Shape34T867 q12Shape34T872
private theorem q12Shape34T866OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 684026757120 q12Shape34T866=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (684026757120 ||| 2^37) q12Shape34T867 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^37) 684026757120 q12Shape34T872)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T867OK,q12Shape34T872OK⟩

private def q12Shape34T873 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T873OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17181048832 666846887936 q12Shape34T873=true := by decide

private def q12Shape34T865 : Tree 12 := .split 34 q12Shape34T866 q12Shape34T873
private theorem q12Shape34T865OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 666846887936 q12Shape34T865=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (666846887936 ||| 2^34) q12Shape34T866 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^34) 666846887936 q12Shape34T873)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T866OK,q12Shape34T873OK⟩

private def q12Shape34T874 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T874OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8591114240 658256953344 q12Shape34T874=true := by decide

private def q12Shape34T864 : Tree 12 := .split 33 q12Shape34T865 q12Shape34T874
private theorem q12Shape34T864OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 658256953344 q12Shape34T864=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (658256953344 ||| 2^33) q12Shape34T865 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^33) 658256953344 q12Shape34T874)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T865OK,q12Shape34T874OK⟩

private def q12Shape34T877 : Tree 12 := (.split 31 (.split 33 (.split 34 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape34T877OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34734080 658424725504 q12Shape34T877=true := by decide

private def q12Shape34T878 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T878OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 168951808 658290507776 q12Shape34T878=true := by decide

private def q12Shape34T876 : Tree 12 := .split 27 q12Shape34T877 q12Shape34T878
private theorem q12Shape34T876OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34734080 658290507776 q12Shape34T876=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34734080 (658290507776 ||| 2^27) q12Shape34T877 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34734080 ||| 2^27) 658290507776 q12Shape34T878)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T877OK,q12Shape34T878OK⟩

private def q12Shape34T879 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T879OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 101842944 658223398912 q12Shape34T879=true := by decide

private def q12Shape34T875 : Tree 12 := .split 26 q12Shape34T876 q12Shape34T879
private theorem q12Shape34T875OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34734080 658223398912 q12Shape34T875=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34734080 (658223398912 ||| 2^26) q12Shape34T876 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34734080 ||| 2^26) 658223398912 q12Shape34T879)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T876OK,q12Shape34T879OK⟩

private def q12Shape34T863 : Tree 12 := .split 25 q12Shape34T864 q12Shape34T875
private theorem q12Shape34T863OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 658223398912 q12Shape34T863=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (658223398912 ||| 2^25) q12Shape34T864 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^25) 658223398912 q12Shape34T875)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T864OK,q12Shape34T875OK⟩

private def q12Shape34T880 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T880OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4296146944 653928431616 q12Shape34T880=true := by decide

private def q12Shape34T862 : Tree 12 := .split 32 q12Shape34T863 q12Shape34T880
private theorem q12Shape34T862OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 653928431616 q12Shape34T862=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (653928431616 ||| 2^32) q12Shape34T863 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^32) 653928431616 q12Shape34T880)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T863OK,q12Shape34T880OK⟩

private def q12Shape34T881 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T881OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1074921472 652854689792 q12Shape34T881=true := by decide

private def q12Shape34T861 : Tree 12 := .split 30 q12Shape34T862 q12Shape34T881
private theorem q12Shape34T861OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 652854689792 q12Shape34T861=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (652854689792 ||| 2^30) q12Shape34T862 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^30) 652854689792 q12Shape34T881)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T862OK,q12Shape34T881OK⟩

private def q12Shape34T882 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T882OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 3276800 652852592640 q12Shape34T882=true := by decide

private def q12Shape34T860 : Tree 12 := .split 21 q12Shape34T861 q12Shape34T882
private theorem q12Shape34T860OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 652852592640 q12Shape34T860=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 (652852592640 ||| 2^21) q12Shape34T861 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1179648 ||| 2^21) 652852592640 q12Shape34T882)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T861OK,q12Shape34T882OK⟩

def q12Shape34P20 : Tree 12 := q12Shape34T860
theorem q12Shape34P20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1179648 652852592640 q12Shape34P20=true := q12Shape34T860OK

private def q12Shape34T893 : Tree 12 := (.split 30 (.tip (.cover {0,1,2,3,4,10,11})) (.split 22 (.split 23 (.split 28 (.split 29 (.split 40 (.split 42 (.tip (.cover {1,2,3,5,6,7,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))) (.tip (.cover {1,2,3,5,6,10,11}))))
private theorem q12Shape34T893OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 685302349824 q12Shape34T893=true := by decide

private def q12Shape34T894 : Tree 12 := (.split 30 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T894OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134873088 685168132096 q12Shape34T894=true := by decide

private def q12Shape34T892 : Tree 12 := .split 27 q12Shape34T893 q12Shape34T894
private theorem q12Shape34T892OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 685168132096 q12Shape34T892=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (685168132096 ||| 2^27) q12Shape34T893 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^27) 685168132096 q12Shape34T894)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T893OK,q12Shape34T894OK⟩

private def q12Shape34T895 : Tree 12 := (.split 27 (.split 30 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape34T895OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67764224 685101023232 q12Shape34T895=true := by decide

private def q12Shape34T891 : Tree 12 := .split 26 q12Shape34T892 q12Shape34T895
private theorem q12Shape34T891OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 685101023232 q12Shape34T891=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (685101023232 ||| 2^26) q12Shape34T892 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^26) 685101023232 q12Shape34T895)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T892OK,q12Shape34T895OK⟩

private def q12Shape34T896 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T896OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17180524544 667921154048 q12Shape34T896=true := by decide

private def q12Shape34T890 : Tree 12 := .split 34 q12Shape34T891 q12Shape34T896
private theorem q12Shape34T890OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 667921154048 q12Shape34T890=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (667921154048 ||| 2^34) q12Shape34T891 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^34) 667921154048 q12Shape34T896)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T891OK,q12Shape34T896OK⟩

private def q12Shape34T897 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T897OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8590589952 659331219456 q12Shape34T897=true := by decide

private def q12Shape34T889 : Tree 12 := .split 33 q12Shape34T890 q12Shape34T897
private theorem q12Shape34T889OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 659331219456 q12Shape34T889=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (659331219456 ||| 2^33) q12Shape34T890 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^33) 659331219456 q12Shape34T897)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T890OK,q12Shape34T897OK⟩

private def q12Shape34T898 : Tree 12 := (.split 30 (.tip (.cover {0,1,2,3,5,10,11})) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape34T898OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34209792 659297665024 q12Shape34T898=true := by decide

private def q12Shape34T888 : Tree 12 := .split 25 q12Shape34T889 q12Shape34T898
private theorem q12Shape34T888OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 659297665024 q12Shape34T888=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (659297665024 ||| 2^25) q12Shape34T889 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^25) 659297665024 q12Shape34T898)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T889OK,q12Shape34T898OK⟩

private def q12Shape34T899 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T899OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4295622656 655002697728 q12Shape34T899=true := by decide

private def q12Shape34T887 : Tree 12 := .split 32 q12Shape34T888 q12Shape34T899
private theorem q12Shape34T887OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 655002697728 q12Shape34T887=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (655002697728 ||| 2^32) q12Shape34T888 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^32) 655002697728 q12Shape34T899)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T888OK,q12Shape34T899OK⟩

private def q12Shape34T900 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T900OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148139008 652855214080 q12Shape34T900=true := by decide

private def q12Shape34T886 : Tree 12 := .split 31 q12Shape34T887 q12Shape34T900
private theorem q12Shape34T886OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 652855214080 q12Shape34T886=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (652855214080 ||| 2^31) q12Shape34T887 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^31) 652855214080 q12Shape34T900)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T887OK,q12Shape34T900OK⟩

private def q12Shape34T901 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T901OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2752512 652853116928 q12Shape34T901=true := by decide

private def q12Shape34T885 : Tree 12 := .split 21 q12Shape34T886 q12Shape34T901
private theorem q12Shape34T885OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 652853116928 q12Shape34T885=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (652853116928 ||| 2^21) q12Shape34T886 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^21) 652853116928 q12Shape34T901)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T886OK,q12Shape34T901OK⟩

private def q12Shape34T902 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T902OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1703936 652852068352 q12Shape34T902=true := by decide

private def q12Shape34T884 : Tree 12 := .split 20 q12Shape34T885 q12Shape34T902
private theorem q12Shape34T884OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 652852068352 q12Shape34T884=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 (652852068352 ||| 2^20) q12Shape34T885 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (655360 ||| 2^20) 652852068352 q12Shape34T902)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T885OK,q12Shape34T902OK⟩

def q12Shape34P21 : Tree 12 := q12Shape34T884
theorem q12Shape34P21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 655360 652852068352 q12Shape34P21=true := q12Shape34T884OK

private def q12Shape34T917 : Tree 12 := (.split 22 (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.split 42 (.tip (.cover {0,1,2,3,5,8,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 28 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,6,7,8,10,11}))))
private theorem q12Shape34T917OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 548937662464 q12Shape34T917=true := by decide

private def q12Shape34T918 : Tree 12 := (.split 22 (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape34T918OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549890162688 548803444736 q12Shape34T918=true := by decide

private def q12Shape34T916 : Tree 12 := .split 27 q12Shape34T917 q12Shape34T918
private theorem q12Shape34T916OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 548803444736 q12Shape34T916=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (548803444736 ||| 2^27) q12Shape34T917 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^27) 548803444736 q12Shape34T918)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T917OK,q12Shape34T918OK⟩

private def q12Shape34T919 : Tree 12 := (.split 27 (.split 22 (.split 42 (.tip (.cover {0,1,2,3,5,8,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T919OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549823053824 548736335872 q12Shape34T919=true := by decide

private def q12Shape34T915 : Tree 12 := .split 26 q12Shape34T916 q12Shape34T919
private theorem q12Shape34T915OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 548736335872 q12Shape34T915=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (548736335872 ||| 2^26) q12Shape34T916 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^26) 548736335872 q12Shape34T919)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T916OK,q12Shape34T919OK⟩

private def q12Shape34T920 : Tree 12 := (.split 27 (.split 28 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape34T920OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549758042112 548734238720 q12Shape34T920=true := by decide

private def q12Shape34T914 : Tree 12 := .split 21 q12Shape34T915 q12Shape34T920
private theorem q12Shape34T914OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 548734238720 q12Shape34T914=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (548734238720 ||| 2^21) q12Shape34T915 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^21) 548734238720 q12Shape34T920)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T915OK,q12Shape34T920OK⟩

private def q12Shape34T921 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T921OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 824633851904 273856331776 q12Shape34T921=true := by decide

private def q12Shape34T913 : Tree 12 := .split 38 q12Shape34T914 q12Shape34T921
private theorem q12Shape34T913OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 273856331776 q12Shape34T913=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (273856331776 ||| 2^38) q12Shape34T914 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^38) 273856331776 q12Shape34T921)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T914OK,q12Shape34T921OK⟩

private def q12Shape34T922 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T922OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 687194898432 136417378304 q12Shape34T922=true := by decide

private def q12Shape34T912 : Tree 12 := .split 37 q12Shape34T913 q12Shape34T922
private theorem q12Shape34T912OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 136417378304 q12Shape34T912=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (136417378304 ||| 2^37) q12Shape34T913 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^37) 136417378304 q12Shape34T922)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T913OK,q12Shape34T922OK⟩

private def q12Shape34T923 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T923OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 566935814144 119237509120 q12Shape34T923=true := by decide

private def q12Shape34T911 : Tree 12 := .split 34 q12Shape34T912 q12Shape34T923
private theorem q12Shape34T911OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 119237509120 q12Shape34T911=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (119237509120 ||| 2^34) q12Shape34T912 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^34) 119237509120 q12Shape34T923)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T912OK,q12Shape34T923OK⟩

private def q12Shape34T924 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T924OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 558345879552 110647574528 q12Shape34T924=true := by decide

private def q12Shape34T910 : Tree 12 := .split 33 q12Shape34T911 q12Shape34T924
private theorem q12Shape34T910OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 110647574528 q12Shape34T910=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (110647574528 ||| 2^33) q12Shape34T911 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^33) 110647574528 q12Shape34T924)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T911OK,q12Shape34T924OK⟩

private def q12Shape34T926 : Tree 12 := (.split 26 (.split 28 (.split 29 (.split 33 (.split 34 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape34T926OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756993536 110648623104 q12Shape34T926=true := by decide

private def q12Shape34T927 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T927OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549759090688 110646525952 q12Shape34T927=true := by decide

private def q12Shape34T925 : Tree 12 := .split 21 q12Shape34T926 q12Shape34T927
private theorem q12Shape34T925OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756993536 110646525952 q12Shape34T925=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756993536 (110646525952 ||| 2^21) q12Shape34T926 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756993536 ||| 2^21) 110646525952 q12Shape34T927)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T926OK,q12Shape34T927OK⟩

private def q12Shape34T909 : Tree 12 := .split 20 q12Shape34T910 q12Shape34T925
private theorem q12Shape34T909OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 110646525952 q12Shape34T909=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (110646525952 ||| 2^20) q12Shape34T910 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^20) 110646525952 q12Shape34T925)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T910OK,q12Shape34T925OK⟩

private def q12Shape34T928 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T928OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 554050912256 106351558656 q12Shape34T928=true := by decide

private def q12Shape34T908 : Tree 12 := .split 32 q12Shape34T909 q12Shape34T928
private theorem q12Shape34T908OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 106351558656 q12Shape34T908=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (106351558656 ||| 2^32) q12Shape34T909 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^32) 106351558656 q12Shape34T928)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T909OK,q12Shape34T928OK⟩

private def q12Shape34T929 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T929OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 551903428608 104204075008 q12Shape34T929=true := by decide

private def q12Shape34T907 : Tree 12 := .split 31 q12Shape34T908 q12Shape34T929
private theorem q12Shape34T907OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 104204075008 q12Shape34T907=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (104204075008 ||| 2^31) q12Shape34T908 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^31) 104204075008 q12Shape34T929)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T908OK,q12Shape34T929OK⟩

private def q12Shape34T930 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T930OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550829686784 103130333184 q12Shape34T930=true := by decide

private def q12Shape34T906 : Tree 12 := .split 30 q12Shape34T907 q12Shape34T930
private theorem q12Shape34T906OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 103130333184 q12Shape34T906=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (103130333184 ||| 2^30) q12Shape34T907 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^30) 103130333184 q12Shape34T930)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T907OK,q12Shape34T930OK⟩

private def q12Shape34T931 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T931OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789499392 103096778752 q12Shape34T931=true := by decide

private def q12Shape34T905 : Tree 12 := .split 25 q12Shape34T906 q12Shape34T931
private theorem q12Shape34T905OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 103096778752 q12Shape34T905=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (103096778752 ||| 2^25) q12Shape34T906 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^25) 103096778752 q12Shape34T931)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T906OK,q12Shape34T931OK⟩

private def q12Shape34T932 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T932OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756469248 103096254464 q12Shape34T932=true := by decide

private def q12Shape34T904 : Tree 12 := .split 19 q12Shape34T905 q12Shape34T932
private theorem q12Shape34T904OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 103096254464 q12Shape34T904=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 (103096254464 ||| 2^19) q12Shape34T905 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755944960 ||| 2^19) 103096254464 q12Shape34T932)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T905OK,q12Shape34T932OK⟩

def q12Shape34P22 : Tree 12 := q12Shape34T904
theorem q12Shape34P22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755944960 103096254464 q12Shape34P22=true := q12Shape34T904OK

end Graffiti384b.EffectiveSearch.Q12
