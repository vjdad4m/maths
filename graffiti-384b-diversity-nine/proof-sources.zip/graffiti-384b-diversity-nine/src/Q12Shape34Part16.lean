import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T948 : Tree 12 := (.split 22 (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.split 42 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,1,4,6,8,10,11})))) (.split 28 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,6,7,8,10,11}))))
private theorem q12Shape34T948OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 3916192022528 q12Shape34T948=true := by decide

private def q12Shape34T949 : Tree 12 := (.split 22 (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape34T949OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68853825536 3916057804800 q12Shape34T949=true := by decide

private def q12Shape34T947 : Tree 12 := .split 27 q12Shape34T948 q12Shape34T949
private theorem q12Shape34T947OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 3916057804800 q12Shape34T947=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (3916057804800 ||| 2^27) q12Shape34T948 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^27) 3916057804800 q12Shape34T949)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T948OK,q12Shape34T949OK⟩

private def q12Shape34T950 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T950OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2267742863360 1717034549248 q12Shape34T950=true := by decide

private def q12Shape34T946 : Tree 12 := .split 41 q12Shape34T947 q12Shape34T950
private theorem q12Shape34T946OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 1717034549248 q12Shape34T946=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (1717034549248 ||| 2^41) q12Shape34T947 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^41) 1717034549248 q12Shape34T950)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T947OK,q12Shape34T950OK⟩

private def q12Shape34T951 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T951OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1168231235584 617522921472 q12Shape34T951=true := by decide

private def q12Shape34T945 : Tree 12 := .split 40 q12Shape34T946 q12Shape34T951
private theorem q12Shape34T945OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 617522921472 q12Shape34T945=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (617522921472 ||| 2^40) q12Shape34T946 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^40) 617522921472 q12Shape34T951)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T946OK,q12Shape34T951OK⟩

private def q12Shape34T952 : Tree 12 := (.split 27 (.split 22 (.split 23 (.split 37 (.tip (.cover {0,2,3,5,8,9,11})) (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,6,7,8,11})))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T952OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68753162240 617489367040 q12Shape34T952=true := by decide

private def q12Shape34T944 : Tree 12 := .split 25 q12Shape34T945 q12Shape34T952
private theorem q12Shape34T944OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 617489367040 q12Shape34T944=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (617489367040 ||| 2^25) q12Shape34T945 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^25) 617489367040 q12Shape34T952)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T945OK,q12Shape34T952OK⟩

private def q12Shape34T953 : Tree 12 := (.split 27 (.split 28 (.split 29 (.split 37 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape34T953OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68721704960 617487269888 q12Shape34T953=true := by decide

private def q12Shape34T943 : Tree 12 := .split 21 q12Shape34T944 q12Shape34T953
private theorem q12Shape34T943OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 617487269888 q12Shape34T943=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (617487269888 ||| 2^21) q12Shape34T944 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^21) 617487269888 q12Shape34T953)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T944OK,q12Shape34T953OK⟩

private def q12Shape34T954 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T954OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 85899476992 600307400704 q12Shape34T954=true := by decide

private def q12Shape34T942 : Tree 12 := .split 34 q12Shape34T943 q12Shape34T954
private theorem q12Shape34T942OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 600307400704 q12Shape34T942=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (600307400704 ||| 2^34) q12Shape34T943 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^34) 600307400704 q12Shape34T954)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T943OK,q12Shape34T954OK⟩

private def q12Shape34T955 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T955OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 77309542400 591717466112 q12Shape34T955=true := by decide

private def q12Shape34T941 : Tree 12 := .split 33 q12Shape34T942 q12Shape34T955
private theorem q12Shape34T941OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 591717466112 q12Shape34T941=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (591717466112 ||| 2^33) q12Shape34T942 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^33) 591717466112 q12Shape34T955)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T942OK,q12Shape34T955OK⟩

private def q12Shape34T958 : Tree 12 := (.split 28 (.split 29 (.split 33 (.split 34 (.split 37 (.tip (.cover {0,2,3,4,8,9,11})) (.split 27 (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,5,6,8,10,11})))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11})))
private theorem q12Shape34T958OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720132096 591752593408 q12Shape34T958=true := by decide

private def q12Shape34T959 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape34T959OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68753686528 591719038976 q12Shape34T959=true := by decide

private def q12Shape34T957 : Tree 12 := .split 25 q12Shape34T958 q12Shape34T959
private theorem q12Shape34T957OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720132096 591719038976 q12Shape34T957=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720132096 (591719038976 ||| 2^25) q12Shape34T958 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720132096 ||| 2^25) 591719038976 q12Shape34T959)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T958OK,q12Shape34T959OK⟩

private def q12Shape34T960 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T960OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68722229248 591716941824 q12Shape34T960=true := by decide

private def q12Shape34T956 : Tree 12 := .split 21 q12Shape34T957 q12Shape34T960
private theorem q12Shape34T956OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720132096 591716941824 q12Shape34T956=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720132096 (591716941824 ||| 2^21) q12Shape34T957 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720132096 ||| 2^21) 591716941824 q12Shape34T960)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T957OK,q12Shape34T960OK⟩

private def q12Shape34T940 : Tree 12 := .split 19 q12Shape34T941 q12Shape34T956
private theorem q12Shape34T940OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 591716941824 q12Shape34T940=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (591716941824 ||| 2^19) q12Shape34T941 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^19) 591716941824 q12Shape34T956)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T941OK,q12Shape34T956OK⟩

private def q12Shape34T961 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T961OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 73014575104 587421974528 q12Shape34T961=true := by decide

private def q12Shape34T939 : Tree 12 := .split 32 q12Shape34T940 q12Shape34T961
private theorem q12Shape34T939OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 587421974528 q12Shape34T939=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (587421974528 ||| 2^32) q12Shape34T940 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^32) 587421974528 q12Shape34T961)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T940OK,q12Shape34T961OK⟩

private def q12Shape34T962 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T962OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 70867091456 585274490880 q12Shape34T962=true := by decide

private def q12Shape34T938 : Tree 12 := .split 31 q12Shape34T939 q12Shape34T962
private theorem q12Shape34T938OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 585274490880 q12Shape34T938=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (585274490880 ||| 2^31) q12Shape34T939 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^31) 585274490880 q12Shape34T962)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T939OK,q12Shape34T962OK⟩

private def q12Shape34T963 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T963OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69793349632 584200749056 q12Shape34T963=true := by decide

private def q12Shape34T937 : Tree 12 := .split 30 q12Shape34T938 q12Shape34T963
private theorem q12Shape34T937OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 584200749056 q12Shape34T937=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (584200749056 ||| 2^30) q12Shape34T938 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^30) 584200749056 q12Shape34T963)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T938OK,q12Shape34T963OK⟩

private def q12Shape34T964 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T964OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786716672 584133640192 q12Shape34T964=true := by decide

private def q12Shape34T936 : Tree 12 := .split 26 q12Shape34T937 q12Shape34T964
private theorem q12Shape34T936OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 584133640192 q12Shape34T936=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (584133640192 ||| 2^26) q12Shape34T937 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^26) 584133640192 q12Shape34T964)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T937OK,q12Shape34T964OK⟩

private def q12Shape34T965 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T965OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720656384 584132591616 q12Shape34T965=true := by decide

private def q12Shape34T935 : Tree 12 := .split 20 q12Shape34T936 q12Shape34T965
private theorem q12Shape34T935OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 584132591616 q12Shape34T935=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (584132591616 ||| 2^20) q12Shape34T936 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^20) 584132591616 q12Shape34T965)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T936OK,q12Shape34T965OK⟩

private def q12Shape34T966 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T966OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 618475421696 34376777728 q12Shape34T966=true := by decide

private def q12Shape34T934 : Tree 12 := .split 39 q12Shape34T935 q12Shape34T966
private theorem q12Shape34T934OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 34376777728 q12Shape34T934=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 (34376777728 ||| 2^39) q12Shape34T935 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719607808 ||| 2^39) 34376777728 q12Shape34T966)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T935OK,q12Shape34T966OK⟩

def q12Shape34P23 : Tree 12 := q12Shape34T934
theorem q12Shape34P23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719607808 34376777728 q12Shape34P23=true := q12Shape34T934OK

private def q12Shape34T981 : Tree 12 := (.split 22 (.split 42 (.split 37 (.tip (.cover {0,1,2,3,5,8,11})) (.split 40 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.split 28 (.split 29 (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))))
private theorem q12Shape34T981OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 652016877568 q12Shape34T981=true := by decide

private def q12Shape34T982 : Tree 12 := (.split 22 (.split 23 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,5,8,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape34T982OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34426978304 651949768704 q12Shape34T982=true := by decide

private def q12Shape34T980 : Tree 12 := .split 26 q12Shape34T981 q12Shape34T982
private theorem q12Shape34T980OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 651949768704 q12Shape34T980=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (651949768704 ||| 2^26) q12Shape34T981 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^26) 651949768704 q12Shape34T982)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T981OK,q12Shape34T982OK⟩

private def q12Shape34T983 : Tree 12 := (.split 26 (.split 22 (.split 23 (.split 37 (.tip (.cover {0,2,3,5,8,9,11})) (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,6,7,9,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape34T983OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34393423872 651916214272 q12Shape34T983=true := by decide

private def q12Shape34T979 : Tree 12 := .split 25 q12Shape34T980 q12Shape34T983
private theorem q12Shape34T979OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 651916214272 q12Shape34T979=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (651916214272 ||| 2^25) q12Shape34T980 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^25) 651916214272 q12Shape34T983)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T980OK,q12Shape34T983OK⟩

private def q12Shape34T984 : Tree 12 := (.split 26 (.split 28 (.split 29 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape34T984OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34360918016 651915165696 q12Shape34T984=true := by decide

private def q12Shape34T978 : Tree 12 := .split 20 q12Shape34T979 q12Shape34T984
private theorem q12Shape34T978OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 651915165696 q12Shape34T978=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (651915165696 ||| 2^20) q12Shape34T979 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^20) 651915165696 q12Shape34T984)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T979OK,q12Shape34T984OK⟩

private def q12Shape34T985 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T985OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 51539738624 634735296512 q12Shape34T985=true := by decide

private def q12Shape34T977 : Tree 12 := .split 34 q12Shape34T978 q12Shape34T985
private theorem q12Shape34T977OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 634735296512 q12Shape34T977=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (634735296512 ||| 2^34) q12Shape34T978 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^34) 634735296512 q12Shape34T985)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T978OK,q12Shape34T985OK⟩

private def q12Shape34T986 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T986OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 42949804032 626145361920 q12Shape34T986=true := by decide

private def q12Shape34T976 : Tree 12 := .split 33 q12Shape34T977 q12Shape34T986
private theorem q12Shape34T976OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 626145361920 q12Shape34T976=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (626145361920 ||| 2^33) q12Shape34T977 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^33) 626145361920 q12Shape34T986)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T977OK,q12Shape34T986OK⟩

private def q12Shape34T989 : Tree 12 := (.split 28 (.split 29 (.split 33 (.split 34 (.split 37 (.tip (.cover {0,2,3,4,8,9,11})) (.split 26 (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape34T989OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34360393728 626179440640 q12Shape34T989=true := by decide

private def q12Shape34T990 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape34T990OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34393948160 626145886208 q12Shape34T990=true := by decide

private def q12Shape34T988 : Tree 12 := .split 25 q12Shape34T989 q12Shape34T990
private theorem q12Shape34T988OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34360393728 626145886208 q12Shape34T988=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34360393728 (626145886208 ||| 2^25) q12Shape34T989 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34360393728 ||| 2^25) 626145886208 q12Shape34T990)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T989OK,q12Shape34T990OK⟩

private def q12Shape34T991 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T991OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34361442304 626144837632 q12Shape34T991=true := by decide

private def q12Shape34T987 : Tree 12 := .split 20 q12Shape34T988 q12Shape34T991
private theorem q12Shape34T987OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34360393728 626144837632 q12Shape34T987=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34360393728 (626144837632 ||| 2^20) q12Shape34T988 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34360393728 ||| 2^20) 626144837632 q12Shape34T991)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T988OK,q12Shape34T991OK⟩

private def q12Shape34T975 : Tree 12 := .split 19 q12Shape34T976 q12Shape34T987
private theorem q12Shape34T975OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 626144837632 q12Shape34T975=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (626144837632 ||| 2^19) q12Shape34T976 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^19) 626144837632 q12Shape34T987)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T976OK,q12Shape34T987OK⟩

private def q12Shape34T992 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T992OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 38654836736 621849870336 q12Shape34T992=true := by decide

private def q12Shape34T974 : Tree 12 := .split 32 q12Shape34T975 q12Shape34T992
private theorem q12Shape34T974OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 621849870336 q12Shape34T974=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (621849870336 ||| 2^32) q12Shape34T975 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^32) 621849870336 q12Shape34T992)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T975OK,q12Shape34T992OK⟩

private def q12Shape34T993 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T993OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 36507353088 619702386688 q12Shape34T993=true := by decide

private def q12Shape34T973 : Tree 12 := .split 31 q12Shape34T974 q12Shape34T993
private theorem q12Shape34T973OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 619702386688 q12Shape34T973=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (619702386688 ||| 2^31) q12Shape34T974 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^31) 619702386688 q12Shape34T993)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T974OK,q12Shape34T993OK⟩

private def q12Shape34T994 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape34T994OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35433611264 618628644864 q12Shape34T994=true := by decide

private def q12Shape34T972 : Tree 12 := .split 30 q12Shape34T973 q12Shape34T994
private theorem q12Shape34T972OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 618628644864 q12Shape34T972=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (618628644864 ||| 2^30) q12Shape34T973 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^30) 618628644864 q12Shape34T994)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T973OK,q12Shape34T994OK⟩

private def q12Shape34T995 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T995OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34494087168 618494427136 q12Shape34T995=true := by decide

private def q12Shape34T971 : Tree 12 := .split 27 q12Shape34T972 q12Shape34T995
private theorem q12Shape34T971OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 618494427136 q12Shape34T971=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (618494427136 ||| 2^27) q12Shape34T972 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^27) 618494427136 q12Shape34T995)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T972OK,q12Shape34T995OK⟩

private def q12Shape34T996 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T996OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34361966592 618492329984 q12Shape34T996=true := by decide

private def q12Shape34T970 : Tree 12 := .split 21 q12Shape34T971 q12Shape34T996
private theorem q12Shape34T970OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 618492329984 q12Shape34T970=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (618492329984 ||| 2^21) q12Shape34T971 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^21) 618492329984 q12Shape34T996)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T971OK,q12Shape34T996OK⟩

private def q12Shape34T997 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T997OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 584115683328 68736516096 q12Shape34T997=true := by decide

private def q12Shape34T969 : Tree 12 := .split 39 q12Shape34T970 q12Shape34T997
private theorem q12Shape34T969OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 68736516096 q12Shape34T969=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (68736516096 ||| 2^39) q12Shape34T970 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^39) 68736516096 q12Shape34T997)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T970OK,q12Shape34T997OK⟩

private def q12Shape34T998 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T998OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 103079346176 17039360 q12Shape34T998=true := by decide

private def q12Shape34T968 : Tree 12 := .split 36 q12Shape34T969 q12Shape34T998
private theorem q12Shape34T968OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 17039360 q12Shape34T968=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 (17039360 ||| 2^36) q12Shape34T969 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34359869440 ||| 2^36) 17039360 q12Shape34T998)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T969OK,q12Shape34T998OK⟩

def q12Shape34P24 : Tree 12 := q12Shape34T968
theorem q12Shape34P24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34359869440 17039360 q12Shape34P24=true := q12Shape34T968OK

private def q12Shape34T1000 : Tree 12 := (.split 35 (.split 36 (.split 39 (.split 25 (.split 26 (.split 27 (.tip (.cover {1,2,3,4,6,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape34T1000OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16908288 262144 q12Shape34T1000=true := by decide

def q12Shape34P25 : Tree 12 := q12Shape34T1000
theorem q12Shape34P25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16908288 262144 q12Shape34P25=true := q12Shape34T1000OK

end Graffiti384b.EffectiveSearch.Q12
