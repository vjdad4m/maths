import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T102 : Tree 12 := (.tip (.cover {0,1,2,3,9,10,11}))
private theorem q12Shape34T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 656309878784 q12Shape34T102=true := by decide

private def q12Shape34T108 : Tree 12 := (.split 22 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 40 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.split 33 (.split 42 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,5,6,7,11}))))
private theorem q12Shape34T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 1071579529216 q12Shape34T108=true := by decide

private def q12Shape34T109 : Tree 12 := (.split 22 (.split 40 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 6444548096 1067284561920 q12Shape34T109=true := by decide

private def q12Shape34T107 : Tree 12 := .split 32 q12Shape34T108 q12Shape34T109
private theorem q12Shape34T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 1067284561920 q12Shape34T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 (1067284561920 ||| 2^32) q12Shape34T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2149580800 ||| 2^32) 1067284561920 q12Shape34T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T108OK,q12Shape34T109OK⟩

private def q12Shape34T110 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 277027487744 792406654976 q12Shape34T110=true := by decide

private def q12Shape34T106 : Tree 12 := .split 38 q12Shape34T107 q12Shape34T110
private theorem q12Shape34T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 792406654976 q12Shape34T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 (792406654976 ||| 2^38) q12Shape34T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2149580800 ||| 2^38) 792406654976 q12Shape34T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T107OK,q12Shape34T110OK⟩

private def q12Shape34T111 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 139588534272 654967701504 q12Shape34T111=true := by decide

private def q12Shape34T105 : Tree 12 := .split 37 q12Shape34T106 q12Shape34T111
private theorem q12Shape34T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 654967701504 q12Shape34T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 (654967701504 ||| 2^37) q12Shape34T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2149580800 ||| 2^37) 654967701504 q12Shape34T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T106OK,q12Shape34T111OK⟩

private def q12Shape34T112 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2686451712 654430830592 q12Shape34T112=true := by decide

private def q12Shape34T104 : Tree 12 := .split 29 q12Shape34T105 q12Shape34T112
private theorem q12Shape34T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 654430830592 q12Shape34T104=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 (654430830592 ||| 2^29) q12Shape34T105 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2149580800 ||| 2^29) 654430830592 q12Shape34T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T105OK,q12Shape34T112OK⟩

private def q12Shape34T113 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2418016256 654162395136 q12Shape34T113=true := by decide

private def q12Shape34T103 : Tree 12 := .split 28 q12Shape34T104 q12Shape34T113
private theorem q12Shape34T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 654162395136 q12Shape34T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2149580800 (654162395136 ||| 2^28) q12Shape34T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2149580800 ||| 2^28) 654162395136 q12Shape34T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T104OK,q12Shape34T113OK⟩

private def q12Shape34T101 : Tree 12 := .split 31 q12Shape34T102 q12Shape34T103
private theorem q12Shape34T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 654162395136 q12Shape34T101=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 (654162395136 ||| 2^31) q12Shape34T102 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2097152 ||| 2^31) 654162395136 q12Shape34T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T102OK,q12Shape34T103OK⟩

private def q12Shape34T120 : Tree 12 := (.split 22 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 37 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,4,5,8,10,11})))) (.split 33 (.split 42 (.tip (.cover {0,1,2,3,4,7,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))))
private theorem q12Shape34T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 3958871293952 q12Shape34T120=true := by decide

private def q12Shape34T121 : Tree 12 := (.split 22 (.split 37 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 5370806272 3954576326656 q12Shape34T121=true := by decide

private def q12Shape34T119 : Tree 12 := .split 32 q12Shape34T120 q12Shape34T121
private theorem q12Shape34T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 3954576326656 q12Shape34T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 (3954576326656 ||| 2^32) q12Shape34T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1075838976 ||| 2^32) 3954576326656 q12Shape34T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T120OK,q12Shape34T121OK⟩

private def q12Shape34T122 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2200099094528 1755553071104 q12Shape34T122=true := by decide

private def q12Shape34T118 : Tree 12 := .split 41 q12Shape34T119 q12Shape34T122
private theorem q12Shape34T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 1755553071104 q12Shape34T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 (1755553071104 ||| 2^41) q12Shape34T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1075838976 ||| 2^41) 1755553071104 q12Shape34T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T119OK,q12Shape34T122OK⟩

private def q12Shape34T123 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1100587466752 656041443328 q12Shape34T123=true := by decide

private def q12Shape34T117 : Tree 12 := .split 40 q12Shape34T118 q12Shape34T123
private theorem q12Shape34T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 656041443328 q12Shape34T117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 (656041443328 ||| 2^40) q12Shape34T118 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1075838976 ||| 2^40) 656041443328 q12Shape34T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T118OK,q12Shape34T123OK⟩

private def q12Shape34T124 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1612709888 655504572416 q12Shape34T124=true := by decide

private def q12Shape34T116 : Tree 12 := .split 29 q12Shape34T117 q12Shape34T124
private theorem q12Shape34T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 655504572416 q12Shape34T116=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 (655504572416 ||| 2^29) q12Shape34T117 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1075838976 ||| 2^29) 655504572416 q12Shape34T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T117OK,q12Shape34T124OK⟩

private def q12Shape34T125 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1344274432 655236136960 q12Shape34T125=true := by decide

private def q12Shape34T115 : Tree 12 := .split 28 q12Shape34T116 q12Shape34T125
private theorem q12Shape34T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 655236136960 q12Shape34T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 (655236136960 ||| 2^28) q12Shape34T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1075838976 ||| 2^28) 655236136960 q12Shape34T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T116OK,q12Shape34T125OK⟩

private def q12Shape34T126 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 3223322624 653088653312 q12Shape34T126=true := by decide

private def q12Shape34T114 : Tree 12 := .split 31 q12Shape34T115 q12Shape34T126
private theorem q12Shape34T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 653088653312 q12Shape34T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1075838976 (653088653312 ||| 2^31) q12Shape34T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1075838976 ||| 2^31) 653088653312 q12Shape34T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T115OK,q12Shape34T126OK⟩

private def q12Shape34T100 : Tree 12 := .split 30 q12Shape34T101 q12Shape34T114
private theorem q12Shape34T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 653088653312 q12Shape34T100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 (653088653312 ||| 2^30) q12Shape34T101 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2097152 ||| 2^30) 653088653312 q12Shape34T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T101OK,q12Shape34T114OK⟩

private def q12Shape34T127 : Tree 12 := (.split 30 (.split 31 (.tip (.cover {0,1,2,3,9,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape34T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 136314880 652954435584 q12Shape34T127=true := by decide

private def q12Shape34T99 : Tree 12 := .split 27 q12Shape34T100 q12Shape34T127
private theorem q12Shape34T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 652954435584 q12Shape34T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 (652954435584 ||| 2^27) q12Shape34T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2097152 ||| 2^27) 652954435584 q12Shape34T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T100OK,q12Shape34T127OK⟩

private def q12Shape34T136 : Tree 12 := (.split 22 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 28 (.split 42 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,5,6,7,11}))))
private theorem q12Shape34T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 1098624401408 q12Shape34T136=true := by decide

private def q12Shape34T137 : Tree 12 := (.split 22 (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 203423744 1098490183680 q12Shape34T137=true := by decide

private def q12Shape34T135 : Tree 12 := .split 27 q12Shape34T136 q12Shape34T137
private theorem q12Shape34T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 1098490183680 q12Shape34T135=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (1098490183680 ||| 2^27) q12Shape34T136 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^27) 1098490183680 q12Shape34T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T136OK,q12Shape34T137OK⟩

private def q12Shape34T138 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 274947112960 823612276736 q12Shape34T138=true := by decide

private def q12Shape34T134 : Tree 12 := .split 38 q12Shape34T135 q12Shape34T138
private theorem q12Shape34T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 823612276736 q12Shape34T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (823612276736 ||| 2^38) q12Shape34T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^38) 823612276736 q12Shape34T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T135OK,q12Shape34T138OK⟩

private def q12Shape34T139 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 137508159488 686173323264 q12Shape34T139=true := by decide

private def q12Shape34T133 : Tree 12 := .split 37 q12Shape34T134 q12Shape34T139
private theorem q12Shape34T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 686173323264 q12Shape34T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (686173323264 ||| 2^37) q12Shape34T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^37) 686173323264 q12Shape34T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T134OK,q12Shape34T139OK⟩

private def q12Shape34T140 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17249075200 668993454080 q12Shape34T140=true := by decide

private def q12Shape34T132 : Tree 12 := .split 34 q12Shape34T133 q12Shape34T140
private theorem q12Shape34T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 668993454080 q12Shape34T132=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (668993454080 ||| 2^34) q12Shape34T133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^34) 668993454080 q12Shape34T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T133OK,q12Shape34T140OK⟩

private def q12Shape34T141 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8659140608 660403519488 q12Shape34T141=true := by decide

private def q12Shape34T131 : Tree 12 := .split 33 q12Shape34T132 q12Shape34T141
private theorem q12Shape34T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 660403519488 q12Shape34T131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (660403519488 ||| 2^33) q12Shape34T132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^33) 660403519488 q12Shape34T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T132OK,q12Shape34T141OK⟩

private def q12Shape34T142 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape34T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4364173312 656108552192 q12Shape34T142=true := by decide

private def q12Shape34T130 : Tree 12 := .split 32 q12Shape34T131 q12Shape34T142
private theorem q12Shape34T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 656108552192 q12Shape34T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (656108552192 ||| 2^32) q12Shape34T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^32) 656108552192 q12Shape34T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T131OK,q12Shape34T142OK⟩

private def q12Shape34T143 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2216689664 653961068544 q12Shape34T143=true := by decide

private def q12Shape34T129 : Tree 12 := .split 31 q12Shape34T130 q12Shape34T143
private theorem q12Shape34T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 653961068544 q12Shape34T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (653961068544 ||| 2^31) q12Shape34T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^31) 653961068544 q12Shape34T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T130OK,q12Shape34T143OK⟩

private def q12Shape34T144 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1142947840 652887326720 q12Shape34T144=true := by decide

private def q12Shape34T128 : Tree 12 := .split 30 q12Shape34T129 q12Shape34T144
private theorem q12Shape34T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 652887326720 q12Shape34T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69206016 (652887326720 ||| 2^30) q12Shape34T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (69206016 ||| 2^30) 652887326720 q12Shape34T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T129OK,q12Shape34T144OK⟩

private def q12Shape34T98 : Tree 12 := .split 26 q12Shape34T99 q12Shape34T128
private theorem q12Shape34T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 652887326720 q12Shape34T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 (652887326720 ||| 2^26) q12Shape34T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2097152 ||| 2^26) 652887326720 q12Shape34T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T99OK,q12Shape34T128OK⟩

private def q12Shape34T154 : Tree 12 := (.split 22 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,6,8,10,11})))) (.split 28 (.split 42 (.tip (.cover {0,1,2,3,4,7,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))))
private theorem q12Shape34T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 3984875978752 q12Shape34T154=true := by decide

private def q12Shape34T155 : Tree 12 := (.split 22 (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 169869312 3984741761024 q12Shape34T155=true := by decide

private def q12Shape34T153 : Tree 12 := .split 27 q12Shape34T154 q12Shape34T155
private theorem q12Shape34T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 3984741761024 q12Shape34T153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (3984741761024 ||| 2^27) q12Shape34T154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^27) 3984741761024 q12Shape34T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T154OK,q12Shape34T155OK⟩

private def q12Shape34T156 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2199058907136 1785718505472 q12Shape34T156=true := by decide

private def q12Shape34T152 : Tree 12 := .split 41 q12Shape34T153 q12Shape34T156
private theorem q12Shape34T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 1785718505472 q12Shape34T152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (1785718505472 ||| 2^41) q12Shape34T153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^41) 1785718505472 q12Shape34T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T153OK,q12Shape34T156OK⟩

private def q12Shape34T157 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1099547279360 686206877696 q12Shape34T157=true := by decide

private def q12Shape34T151 : Tree 12 := .split 40 q12Shape34T152 q12Shape34T157
private theorem q12Shape34T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 686206877696 q12Shape34T151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (686206877696 ||| 2^40) q12Shape34T152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^40) 686206877696 q12Shape34T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T152OK,q12Shape34T157OK⟩

private def q12Shape34T158 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17215520768 669027008512 q12Shape34T158=true := by decide

private def q12Shape34T150 : Tree 12 := .split 34 q12Shape34T151 q12Shape34T158
private theorem q12Shape34T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 669027008512 q12Shape34T150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (669027008512 ||| 2^34) q12Shape34T151 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^34) 669027008512 q12Shape34T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T151OK,q12Shape34T158OK⟩

private def q12Shape34T159 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8625586176 660437073920 q12Shape34T159=true := by decide

private def q12Shape34T149 : Tree 12 := .split 33 q12Shape34T150 q12Shape34T159
private theorem q12Shape34T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 660437073920 q12Shape34T149=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (660437073920 ||| 2^33) q12Shape34T150 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^33) 660437073920 q12Shape34T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T150OK,q12Shape34T159OK⟩

private def q12Shape34T160 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape34T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4330618880 656142106624 q12Shape34T160=true := by decide

private def q12Shape34T148 : Tree 12 := .split 32 q12Shape34T149 q12Shape34T160
private theorem q12Shape34T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 656142106624 q12Shape34T148=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (656142106624 ||| 2^32) q12Shape34T149 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^32) 656142106624 q12Shape34T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T149OK,q12Shape34T160OK⟩

private def q12Shape34T161 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2183135232 653994622976 q12Shape34T161=true := by decide

private def q12Shape34T147 : Tree 12 := .split 31 q12Shape34T148 q12Shape34T161
private theorem q12Shape34T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 653994622976 q12Shape34T147=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (653994622976 ||| 2^31) q12Shape34T148 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^31) 653994622976 q12Shape34T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T148OK,q12Shape34T161OK⟩

private def q12Shape34T162 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1109393408 652920881152 q12Shape34T162=true := by decide

private def q12Shape34T146 : Tree 12 := .split 30 q12Shape34T147 q12Shape34T162
private theorem q12Shape34T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 652920881152 q12Shape34T146=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (652920881152 ||| 2^30) q12Shape34T147 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^30) 652920881152 q12Shape34T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T147OK,q12Shape34T162OK⟩

private def q12Shape34T163 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 102760448 652853772288 q12Shape34T163=true := by decide

private def q12Shape34T145 : Tree 12 := .split 26 q12Shape34T146 q12Shape34T163
private theorem q12Shape34T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 652853772288 q12Shape34T145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 35651584 (652853772288 ||| 2^26) q12Shape34T146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (35651584 ||| 2^26) 652853772288 q12Shape34T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T146OK,q12Shape34T163OK⟩

private def q12Shape34T97 : Tree 12 := .split 25 q12Shape34T98 q12Shape34T145
private theorem q12Shape34T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 652853772288 q12Shape34T97=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 (652853772288 ||| 2^25) q12Shape34T98 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2097152 ||| 2^25) 652853772288 q12Shape34T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T98OK,q12Shape34T145OK⟩

def q12Shape34P2 : Tree 12 := q12Shape34T97
theorem q12Shape34P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2097152 652853772288 q12Shape34P2=true := q12Shape34T97OK

end Graffiti384b.EffectiveSearch.Q12
