import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T250 : Tree 12 := (.tip (.cover {0,1,2,3,4,10,11}))
private theorem q12Shape34T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 660606418944 q12Shape34T250=true := by decide

private def q12Shape34T253 : Tree 12 := (.split 40 (.split 41 (.split 22 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,8,10,11})))) (.split 33 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,11})))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape34T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4295491584 657116758016 q12Shape34T253=true := by decide

private def q12Shape34T254 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4832362496 656579887104 q12Shape34T254=true := by decide

private def q12Shape34T252 : Tree 12 := .split 29 q12Shape34T253 q12Shape34T254
private theorem q12Shape34T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4295491584 656579887104 q12Shape34T252=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4295491584 (656579887104 ||| 2^29) q12Shape34T253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (4295491584 ||| 2^29) 656579887104 q12Shape34T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T253OK,q12Shape34T254OK⟩

private def q12Shape34T255 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4563927040 656311451648 q12Shape34T255=true := by decide

private def q12Shape34T251 : Tree 12 := .split 28 q12Shape34T252 q12Shape34T255
private theorem q12Shape34T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4295491584 656311451648 q12Shape34T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4295491584 (656311451648 ||| 2^28) q12Shape34T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (4295491584 ||| 2^28) 656311451648 q12Shape34T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T252OK,q12Shape34T255OK⟩

private def q12Shape34T249 : Tree 12 := .split 32 q12Shape34T250 q12Shape34T251
private theorem q12Shape34T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 656311451648 q12Shape34T249=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (656311451648 ||| 2^32) q12Shape34T250 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^32) 656311451648 q12Shape34T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T250OK,q12Shape34T251OK⟩

private def q12Shape34T260 : Tree 12 := (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 37 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape34T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 659268435968 q12Shape34T260=true := by decide

private def q12Shape34T261 : Tree 12 := (.split 33 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape34T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2152202240 659264241664 q12Shape34T261=true := by decide

private def q12Shape34T259 : Tree 12 := .split 22 q12Shape34T260 q12Shape34T261
private theorem q12Shape34T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 659264241664 q12Shape34T259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 (659264241664 ||| 2^22) q12Shape34T260 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2148007936 ||| 2^22) 659264241664 q12Shape34T261)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T260OK,q12Shape34T261OK⟩

private def q12Shape34T262 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2684878848 658727370752 q12Shape34T262=true := by decide

private def q12Shape34T258 : Tree 12 := .split 29 q12Shape34T259 q12Shape34T262
private theorem q12Shape34T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 658727370752 q12Shape34T258=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 (658727370752 ||| 2^29) q12Shape34T259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2148007936 ||| 2^29) 658727370752 q12Shape34T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T259OK,q12Shape34T262OK⟩

private def q12Shape34T263 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2416443392 658458935296 q12Shape34T263=true := by decide

private def q12Shape34T257 : Tree 12 := .split 28 q12Shape34T258 q12Shape34T263
private theorem q12Shape34T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 658458935296 q12Shape34T257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 (658458935296 ||| 2^28) q12Shape34T258 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2148007936 ||| 2^28) 658458935296 q12Shape34T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T258OK,q12Shape34T263OK⟩

private def q12Shape34T264 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 6442975232 654163968000 q12Shape34T264=true := by decide

private def q12Shape34T256 : Tree 12 := .split 32 q12Shape34T257 q12Shape34T264
private theorem q12Shape34T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 654163968000 q12Shape34T256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2148007936 (654163968000 ||| 2^32) q12Shape34T257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2148007936 ||| 2^32) 654163968000 q12Shape34T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T257OK,q12Shape34T264OK⟩

private def q12Shape34T248 : Tree 12 := .split 31 q12Shape34T249 q12Shape34T256
private theorem q12Shape34T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 654163968000 q12Shape34T248=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (654163968000 ||| 2^31) q12Shape34T249 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^31) 654163968000 q12Shape34T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T249OK,q12Shape34T256OK⟩

private def q12Shape34T266 : Tree 12 := (.split 23 (.split 28 (.split 29 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.tip (.cover {0,2,3,7,8,9,10})) (.split 40 (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,2,3,6,10,11})))
private theorem q12Shape34T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1074266112 653094420480 q12Shape34T266=true := by decide

private def q12Shape34T267 : Tree 12 := (.tip (.cover {0,1,2,3,6,10,11}))
private theorem q12Shape34T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1078460416 653090226176 q12Shape34T267=true := by decide

private def q12Shape34T265 : Tree 12 := .split 22 q12Shape34T266 q12Shape34T267
private theorem q12Shape34T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1074266112 653090226176 q12Shape34T265=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1074266112 (653090226176 ||| 2^22) q12Shape34T266 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1074266112 ||| 2^22) 653090226176 q12Shape34T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T266OK,q12Shape34T267OK⟩

private def q12Shape34T247 : Tree 12 := .split 30 q12Shape34T248 q12Shape34T265
private theorem q12Shape34T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 653090226176 q12Shape34T247=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (653090226176 ||| 2^30) q12Shape34T248 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^30) 653090226176 q12Shape34T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T248OK,q12Shape34T265OK⟩

private def q12Shape34T273 : Tree 12 := (.split 40 (.split 41 (.split 22 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 42 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,1,4,6,8,10,11})))) (.split 28 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,11})))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape34T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 686242004992 q12Shape34T273=true := by decide

private def q12Shape34T274 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17314611200 669062135808 q12Shape34T274=true := by decide

private def q12Shape34T272 : Tree 12 := .split 34 q12Shape34T273 q12Shape34T274
private theorem q12Shape34T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 669062135808 q12Shape34T272=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 (669062135808 ||| 2^34) q12Shape34T273 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134742016 ||| 2^34) 669062135808 q12Shape34T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T273OK,q12Shape34T274OK⟩

private def q12Shape34T275 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8724676608 660472201216 q12Shape34T275=true := by decide

private def q12Shape34T271 : Tree 12 := .split 33 q12Shape34T272 q12Shape34T275
private theorem q12Shape34T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 660472201216 q12Shape34T271=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 (660472201216 ||| 2^33) q12Shape34T272 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134742016 ||| 2^33) 660472201216 q12Shape34T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T272OK,q12Shape34T275OK⟩

private def q12Shape34T276 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4429709312 656177233920 q12Shape34T276=true := by decide

private def q12Shape34T270 : Tree 12 := .split 32 q12Shape34T271 q12Shape34T276
private theorem q12Shape34T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 656177233920 q12Shape34T270=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 (656177233920 ||| 2^32) q12Shape34T271 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134742016 ||| 2^32) 656177233920 q12Shape34T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T271OK,q12Shape34T276OK⟩

private def q12Shape34T277 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2282225664 654029750272 q12Shape34T277=true := by decide

private def q12Shape34T269 : Tree 12 := .split 31 q12Shape34T270 q12Shape34T277
private theorem q12Shape34T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 654029750272 q12Shape34T269=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 (654029750272 ||| 2^31) q12Shape34T270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134742016 ||| 2^31) 654029750272 q12Shape34T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T270OK,q12Shape34T277OK⟩

private def q12Shape34T278 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1208483840 652956008448 q12Shape34T278=true := by decide

private def q12Shape34T268 : Tree 12 := .split 30 q12Shape34T269 q12Shape34T278
private theorem q12Shape34T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 652956008448 q12Shape34T268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 134742016 (652956008448 ||| 2^30) q12Shape34T269 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (134742016 ||| 2^30) 652956008448 q12Shape34T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T269OK,q12Shape34T278OK⟩

private def q12Shape34T246 : Tree 12 := .split 27 q12Shape34T247 q12Shape34T268
private theorem q12Shape34T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 652956008448 q12Shape34T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (652956008448 ||| 2^27) q12Shape34T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^27) 652956008448 q12Shape34T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T247OK,q12Shape34T268OK⟩

private def q12Shape34T286 : Tree 12 := (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 37 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape34T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 686313308160 q12Shape34T286=true := by decide

private def q12Shape34T287 : Tree 12 := (.split 28 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,4,8,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape34T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 71827456 686309113856 q12Shape34T287=true := by decide

private def q12Shape34T285 : Tree 12 := .split 22 q12Shape34T286 q12Shape34T287
private theorem q12Shape34T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 686309113856 q12Shape34T285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 (686309113856 ||| 2^22) q12Shape34T286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67633152 ||| 2^22) 686309113856 q12Shape34T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T286OK,q12Shape34T287OK⟩

private def q12Shape34T288 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17247502336 669129244672 q12Shape34T288=true := by decide

private def q12Shape34T284 : Tree 12 := .split 34 q12Shape34T285 q12Shape34T288
private theorem q12Shape34T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 669129244672 q12Shape34T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 (669129244672 ||| 2^34) q12Shape34T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67633152 ||| 2^34) 669129244672 q12Shape34T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T285OK,q12Shape34T288OK⟩

private def q12Shape34T289 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8657567744 660539310080 q12Shape34T289=true := by decide

private def q12Shape34T283 : Tree 12 := .split 33 q12Shape34T284 q12Shape34T289
private theorem q12Shape34T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 660539310080 q12Shape34T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 (660539310080 ||| 2^33) q12Shape34T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67633152 ||| 2^33) 660539310080 q12Shape34T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T284OK,q12Shape34T289OK⟩

private def q12Shape34T290 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4362600448 656244342784 q12Shape34T290=true := by decide

private def q12Shape34T282 : Tree 12 := .split 32 q12Shape34T283 q12Shape34T290
private theorem q12Shape34T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 656244342784 q12Shape34T282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 (656244342784 ||| 2^32) q12Shape34T283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67633152 ||| 2^32) 656244342784 q12Shape34T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T283OK,q12Shape34T290OK⟩

private def q12Shape34T291 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape34T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2215116800 654096859136 q12Shape34T291=true := by decide

private def q12Shape34T281 : Tree 12 := .split 31 q12Shape34T282 q12Shape34T291
private theorem q12Shape34T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 654096859136 q12Shape34T281=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 (654096859136 ||| 2^31) q12Shape34T282 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67633152 ||| 2^31) 654096859136 q12Shape34T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T282OK,q12Shape34T291OK⟩

private def q12Shape34T292 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape34T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1141374976 653023117312 q12Shape34T292=true := by decide

private def q12Shape34T280 : Tree 12 := .split 30 q12Shape34T281 q12Shape34T292
private theorem q12Shape34T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 653023117312 q12Shape34T280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 (653023117312 ||| 2^30) q12Shape34T281 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67633152 ||| 2^30) 653023117312 q12Shape34T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T281OK,q12Shape34T292OK⟩

private def q12Shape34T293 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 201850880 652888899584 q12Shape34T293=true := by decide

private def q12Shape34T279 : Tree 12 := .split 27 q12Shape34T280 q12Shape34T293
private theorem q12Shape34T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 652888899584 q12Shape34T279=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 67633152 (652888899584 ||| 2^27) q12Shape34T280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (67633152 ||| 2^27) 652888899584 q12Shape34T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T280OK,q12Shape34T293OK⟩

private def q12Shape34T245 : Tree 12 := .split 26 q12Shape34T246 q12Shape34T279
private theorem q12Shape34T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 652888899584 q12Shape34T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (652888899584 ||| 2^26) q12Shape34T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^26) 652888899584 q12Shape34T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T246OK,q12Shape34T279OK⟩

private def q12Shape34T298 : Tree 12 := (.split 23 (.split 33 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.split 29 (.tip (.cover {0,2,3,7,8,9,10})) (.split 40 (.split 42 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,2,3,5,10,11})))
private theorem q12Shape34T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 660375732224 q12Shape34T298=true := by decide

private def q12Shape34T299 : Tree 12 := (.tip (.cover {0,1,2,3,5,10,11}))
private theorem q12Shape34T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 38273024 660371537920 q12Shape34T299=true := by decide

private def q12Shape34T297 : Tree 12 := .split 22 q12Shape34T298 q12Shape34T299
private theorem q12Shape34T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 660371537920 q12Shape34T297=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 (660371537920 ||| 2^22) q12Shape34T298 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34078720 ||| 2^22) 660371537920 q12Shape34T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T298OK,q12Shape34T299OK⟩

private def q12Shape34T300 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape34T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4329046016 656076570624 q12Shape34T300=true := by decide

private def q12Shape34T296 : Tree 12 := .split 32 q12Shape34T297 q12Shape34T300
private theorem q12Shape34T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 656076570624 q12Shape34T296=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 (656076570624 ||| 2^32) q12Shape34T297 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34078720 ||| 2^32) 656076570624 q12Shape34T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T297OK,q12Shape34T300OK⟩

private def q12Shape34T301 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape34T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2181562368 653929086976 q12Shape34T301=true := by decide

private def q12Shape34T295 : Tree 12 := .split 31 q12Shape34T296 q12Shape34T301
private theorem q12Shape34T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 653929086976 q12Shape34T295=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 (653929086976 ||| 2^31) q12Shape34T296 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34078720 ||| 2^31) 653929086976 q12Shape34T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T296OK,q12Shape34T301OK⟩

private def q12Shape34T302 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape34T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1107820544 652855345152 q12Shape34T302=true := by decide

private def q12Shape34T294 : Tree 12 := .split 30 q12Shape34T295 q12Shape34T302
private theorem q12Shape34T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 652855345152 q12Shape34T294=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 34078720 (652855345152 ||| 2^30) q12Shape34T295 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (34078720 ||| 2^30) 652855345152 q12Shape34T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T295OK,q12Shape34T302OK⟩

private def q12Shape34T244 : Tree 12 := .split 25 q12Shape34T245 q12Shape34T294
private theorem q12Shape34T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 652855345152 q12Shape34T244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (652855345152 ||| 2^25) q12Shape34T245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^25) 652855345152 q12Shape34T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T245OK,q12Shape34T294OK⟩

private def q12Shape34T309 : Tree 12 := (.tip (.cover {0,2,3,7,8,9,11}))
private theorem q12Shape34T309OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 664467275776 q12Shape34T309=true := by decide

private def q12Shape34T310 : Tree 12 := (.split 34 (.split 23 (.tip (.cover {0,2,3,7,8,9,10})) (.split 40 (.split 41 (.split 25 (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,5,6,8,10}))) (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,5,6,8,10})))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11})))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape34T310OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 6815744 664463081472 q12Shape34T310=true := by decide

private def q12Shape34T308 : Tree 12 := .split 22 q12Shape34T309 q12Shape34T310
private theorem q12Shape34T308OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 664463081472 q12Shape34T308=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 (664463081472 ||| 2^22) q12Shape34T309 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2621440 ||| 2^22) 664463081472 q12Shape34T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T309OK,q12Shape34T310OK⟩

private def q12Shape34T311 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T311OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8592556032 655873146880 q12Shape34T311=true := by decide

private def q12Shape34T307 : Tree 12 := .split 33 q12Shape34T308 q12Shape34T311
private theorem q12Shape34T307OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 655873146880 q12Shape34T307=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 (655873146880 ||| 2^33) q12Shape34T308 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2621440 ||| 2^33) 655873146880 q12Shape34T311)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T308OK,q12Shape34T311OK⟩

private def q12Shape34T312 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T312OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 539492352 655336275968 q12Shape34T312=true := by decide

private def q12Shape34T306 : Tree 12 := .split 29 q12Shape34T307 q12Shape34T312
private theorem q12Shape34T306OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 655336275968 q12Shape34T306=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 (655336275968 ||| 2^29) q12Shape34T307 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2621440 ||| 2^29) 655336275968 q12Shape34T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T307OK,q12Shape34T312OK⟩

private def q12Shape34T313 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T313OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 271056896 655067840512 q12Shape34T313=true := by decide

private def q12Shape34T305 : Tree 12 := .split 28 q12Shape34T306 q12Shape34T313
private theorem q12Shape34T305OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 655067840512 q12Shape34T305=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 (655067840512 ||| 2^28) q12Shape34T306 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2621440 ||| 2^28) 655067840512 q12Shape34T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T306OK,q12Shape34T313OK⟩

private def q12Shape34T314 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T314OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2150105088 652920356864 q12Shape34T314=true := by decide

private def q12Shape34T304 : Tree 12 := .split 31 q12Shape34T305 q12Shape34T314
private theorem q12Shape34T304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 652920356864 q12Shape34T304=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 (652920356864 ||| 2^31) q12Shape34T305 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2621440 ||| 2^31) 652920356864 q12Shape34T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T305OK,q12Shape34T314OK⟩

private def q12Shape34T315 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T315OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69730304 652853248000 q12Shape34T315=true := by decide

private def q12Shape34T303 : Tree 12 := .split 26 q12Shape34T304 q12Shape34T315
private theorem q12Shape34T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 652853248000 q12Shape34T303=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2621440 (652853248000 ||| 2^26) q12Shape34T304 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (2621440 ||| 2^26) 652853248000 q12Shape34T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T304OK,q12Shape34T315OK⟩

private def q12Shape34T243 : Tree 12 := .split 21 q12Shape34T244 q12Shape34T303
private theorem q12Shape34T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 652853248000 q12Shape34T243=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 (652853248000 ||| 2^21) q12Shape34T244 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (524288 ||| 2^21) 652853248000 q12Shape34T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T244OK,q12Shape34T303OK⟩

def q12Shape34P4 : Tree 12 := q12Shape34T243
theorem q12Shape34P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 524288 652853248000 q12Shape34P4=true := q12Shape34T243OK

end Graffiti384b.EffectiveSearch.Q12
