import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T323 : Tree 12 := (.tip (.cover {0,2,3,7,8,9,11}))
private theorem q12Shape34T323OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 666682916864 q12Shape34T323=true := by decide

private def q12Shape34T326 : Tree 12 := (.tip (.cover {0,2,3,7,8,9,10}))
private theorem q12Shape34T326OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 5767168 683866980352 q12Shape34T326=true := by decide

private def q12Shape34T327 : Tree 12 := (.split 25 (.split 42 (.split 43 (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 26 (.split 30 (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))))
private theorem q12Shape34T327OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 14155776 683858591744 q12Shape34T327=true := by decide

private def q12Shape34T325 : Tree 12 := .split 23 q12Shape34T326 q12Shape34T327
private theorem q12Shape34T325OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 5767168 683858591744 q12Shape34T325=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 5767168 (683858591744 ||| 2^23) q12Shape34T326 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (5767168 ||| 2^23) 683858591744 q12Shape34T327)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T326OK,q12Shape34T327OK⟩

private def q12Shape34T328 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T328OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17185636352 666678722560 q12Shape34T328=true := by decide

private def q12Shape34T324 : Tree 12 := .split 34 q12Shape34T325 q12Shape34T328
private theorem q12Shape34T324OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 5767168 666678722560 q12Shape34T324=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 5767168 (666678722560 ||| 2^34) q12Shape34T325 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (5767168 ||| 2^34) 666678722560 q12Shape34T328)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T325OK,q12Shape34T328OK⟩

private def q12Shape34T322 : Tree 12 := .split 22 q12Shape34T323 q12Shape34T324
private theorem q12Shape34T322OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 666678722560 q12Shape34T322=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 (666678722560 ||| 2^22) q12Shape34T323 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1572864 ||| 2^22) 666678722560 q12Shape34T324)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T323OK,q12Shape34T324OK⟩

private def q12Shape34T329 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T329OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8591507456 658088787968 q12Shape34T329=true := by decide

private def q12Shape34T321 : Tree 12 := .split 33 q12Shape34T322 q12Shape34T329
private theorem q12Shape34T321OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 658088787968 q12Shape34T321=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 (658088787968 ||| 2^33) q12Shape34T322 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1572864 ||| 2^33) 658088787968 q12Shape34T329)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T322OK,q12Shape34T329OK⟩

private def q12Shape34T330 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T330OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 538443776 657551917056 q12Shape34T330=true := by decide

private def q12Shape34T320 : Tree 12 := .split 29 q12Shape34T321 q12Shape34T330
private theorem q12Shape34T320OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 657551917056 q12Shape34T320=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 (657551917056 ||| 2^29) q12Shape34T321 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1572864 ||| 2^29) 657551917056 q12Shape34T330)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T321OK,q12Shape34T330OK⟩

private def q12Shape34T331 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T331OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 270008320 657283481600 q12Shape34T331=true := by decide

private def q12Shape34T319 : Tree 12 := .split 28 q12Shape34T320 q12Shape34T331
private theorem q12Shape34T319OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 657283481600 q12Shape34T319=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 (657283481600 ||| 2^28) q12Shape34T320 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1572864 ||| 2^28) 657283481600 q12Shape34T331)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T320OK,q12Shape34T331OK⟩

private def q12Shape34T332 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T332OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4296540160 652988514304 q12Shape34T332=true := by decide

private def q12Shape34T318 : Tree 12 := .split 32 q12Shape34T319 q12Shape34T332
private theorem q12Shape34T318OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 652988514304 q12Shape34T318=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 (652988514304 ||| 2^32) q12Shape34T319 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1572864 ||| 2^32) 652988514304 q12Shape34T332)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T319OK,q12Shape34T332OK⟩

private def q12Shape34T333 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T333OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 135790592 652854296576 q12Shape34T333=true := by decide

private def q12Shape34T317 : Tree 12 := .split 27 q12Shape34T318 q12Shape34T333
private theorem q12Shape34T317OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 652854296576 q12Shape34T317=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 (652854296576 ||| 2^27) q12Shape34T318 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1572864 ||| 2^27) 652854296576 q12Shape34T333)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T318OK,q12Shape34T333OK⟩

private def q12Shape34T334 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape34T334OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 3670016 652852199424 q12Shape34T334=true := by decide

private def q12Shape34T316 : Tree 12 := .split 21 q12Shape34T317 q12Shape34T334
private theorem q12Shape34T316OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 652852199424 q12Shape34T316=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 (652852199424 ||| 2^21) q12Shape34T317 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (1572864 ||| 2^21) 652852199424 q12Shape34T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T317OK,q12Shape34T334OK⟩

def q12Shape34P5 : Tree 12 := q12Shape34T316
theorem q12Shape34P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1572864 652852199424 q12Shape34P5=true := q12Shape34T316OK

private def q12Shape34T344 : Tree 12 := (.split 31 (.tip (.cover {0,1,2,3,9,10,11})) (.tip (.cover {0,1,2,3,8,10,11})))
private theorem q12Shape34T344OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 104408678400 q12Shape34T344=true := by decide

private def q12Shape34T346 : Tree 12 := (.split 23 (.split 28 (.split 29 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.tip (.cover {0,2,3,7,8,9,10})) (.split 37 (.split 40 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,8,10,11}))))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T346OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550829555712 103339130880 q12Shape34T346=true := by decide

private def q12Shape34T347 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T347OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550833750016 103334936576 q12Shape34T347=true := by decide

private def q12Shape34T345 : Tree 12 := .split 22 q12Shape34T346 q12Shape34T347
private theorem q12Shape34T345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550829555712 103334936576 q12Shape34T345=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550829555712 (103334936576 ||| 2^22) q12Shape34T346 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (550829555712 ||| 2^22) 103334936576 q12Shape34T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T346OK,q12Shape34T347OK⟩

private def q12Shape34T343 : Tree 12 := .split 30 q12Shape34T344 q12Shape34T345
private theorem q12Shape34T343OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103334936576 q12Shape34T343=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 (103334936576 ||| 2^30) q12Shape34T344 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755813888 ||| 2^30) 103334936576 q12Shape34T345)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T344OK,q12Shape34T345OK⟩

private def q12Shape34T348 : Tree 12 := (.split 30 (.split 31 (.tip (.cover {0,1,2,3,9,10,11})) (.split 32 (.split 22 (.split 23 (.split 28 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape34T348OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549890031616 103200718848 q12Shape34T348=true := by decide

private def q12Shape34T342 : Tree 12 := .split 27 q12Shape34T343 q12Shape34T348
private theorem q12Shape34T342OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103200718848 q12Shape34T342=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 (103200718848 ||| 2^27) q12Shape34T343 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755813888 ||| 2^27) 103200718848 q12Shape34T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T343OK,q12Shape34T348OK⟩

private def q12Shape34T350 : Tree 12 := (.split 31 (.split 27 (.split 32 (.tip (.cover {0,1,2,3,8,10,11})) (.split 22 (.split 23 (.split 28 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))) (.tip (.cover {0,1,2,3,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape34T350OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549822922752 104207351808 q12Shape34T350=true := by decide

private def q12Shape34T351 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550896664576 103133609984 q12Shape34T351=true := by decide

private def q12Shape34T349 : Tree 12 := .split 30 q12Shape34T350 q12Shape34T351
private theorem q12Shape34T349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549822922752 103133609984 q12Shape34T349=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549822922752 (103133609984 ||| 2^30) q12Shape34T350 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549822922752 ||| 2^30) 103133609984 q12Shape34T351)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T350OK,q12Shape34T351OK⟩

private def q12Shape34T341 : Tree 12 := .split 26 q12Shape34T342 q12Shape34T349
private theorem q12Shape34T341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103133609984 q12Shape34T341=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 (103133609984 ||| 2^26) q12Shape34T342 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755813888 ||| 2^26) 103133609984 q12Shape34T349)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T342OK,q12Shape34T349OK⟩

private def q12Shape34T356 : Tree 12 := (.split 23 (.split 33 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.split 29 (.tip (.cover {0,2,3,7,8,9,10})) (.split 37 (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,6,8,10,11})))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T356OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 110620442624 q12Shape34T356=true := by decide

private def q12Shape34T357 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549793562624 110616248320 q12Shape34T357=true := by decide

private def q12Shape34T355 : Tree 12 := .split 22 q12Shape34T356 q12Shape34T357
private theorem q12Shape34T355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 110616248320 q12Shape34T355=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 (110616248320 ||| 2^22) q12Shape34T356 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549789368320 ||| 2^22) 110616248320 q12Shape34T357)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T356OK,q12Shape34T357OK⟩

private def q12Shape34T358 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T358OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 554084335616 106321281024 q12Shape34T358=true := by decide

private def q12Shape34T354 : Tree 12 := .split 32 q12Shape34T355 q12Shape34T358
private theorem q12Shape34T354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 106321281024 q12Shape34T354=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 (106321281024 ||| 2^32) q12Shape34T355 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549789368320 ||| 2^32) 106321281024 q12Shape34T358)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T355OK,q12Shape34T358OK⟩

private def q12Shape34T359 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 551936851968 104173797376 q12Shape34T359=true := by decide

private def q12Shape34T353 : Tree 12 := .split 31 q12Shape34T354 q12Shape34T359
private theorem q12Shape34T353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 104173797376 q12Shape34T353=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 (104173797376 ||| 2^31) q12Shape34T354 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549789368320 ||| 2^31) 104173797376 q12Shape34T359)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T354OK,q12Shape34T359OK⟩

private def q12Shape34T360 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550863110144 103100055552 q12Shape34T360=true := by decide

private def q12Shape34T352 : Tree 12 := .split 30 q12Shape34T353 q12Shape34T360
private theorem q12Shape34T352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 103100055552 q12Shape34T352=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789368320 (103100055552 ||| 2^30) q12Shape34T353 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549789368320 ||| 2^30) 103100055552 q12Shape34T360)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T353OK,q12Shape34T360OK⟩

private def q12Shape34T340 : Tree 12 := .split 25 q12Shape34T341 q12Shape34T352
private theorem q12Shape34T340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103100055552 q12Shape34T340=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 (103100055552 ||| 2^25) q12Shape34T341 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755813888 ||| 2^25) 103100055552 q12Shape34T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T341OK,q12Shape34T352OK⟩

private def q12Shape34T362 : Tree 12 := (.split 27 (.split 30 (.split 32 (.split 22 (.split 23 (.split 28 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,2,3,8,10,11}))) (.tip (.cover {0,1,2,3,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape34T362OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549757911040 103131512832 q12Shape34T362=true := by decide

private def q12Shape34T363 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T363OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549791465472 103097958400 q12Shape34T363=true := by decide

private def q12Shape34T361 : Tree 12 := .split 25 q12Shape34T362 q12Shape34T363
private theorem q12Shape34T361OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549757911040 103097958400 q12Shape34T361=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549757911040 (103097958400 ||| 2^25) q12Shape34T362 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549757911040 ||| 2^25) 103097958400 q12Shape34T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T362OK,q12Shape34T363OK⟩

private def q12Shape34T339 : Tree 12 := .split 21 q12Shape34T340 q12Shape34T361
private theorem q12Shape34T339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103097958400 q12Shape34T339=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 (103097958400 ||| 2^21) q12Shape34T340 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755813888 ||| 2^21) 103097958400 q12Shape34T361)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T340OK,q12Shape34T361OK⟩

private def q12Shape34T366 : Tree 12 := (.split 30 (.split 31 (.split 21 (.split 22 (.split 23 (.split 28 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,2,3,9,10,11}))) (.tip (.cover {0,1,2,3,9,10,11}))) (.tip (.cover {0,1,2,3,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape34T366OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756862464 103197573120 q12Shape34T366=true := by decide

private def q12Shape34T367 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape34T367OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549823971328 103130464256 q12Shape34T367=true := by decide

private def q12Shape34T365 : Tree 12 := .split 26 q12Shape34T366 q12Shape34T367
private theorem q12Shape34T365OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756862464 103130464256 q12Shape34T365=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756862464 (103130464256 ||| 2^26) q12Shape34T366 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756862464 ||| 2^26) 103130464256 q12Shape34T367)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T366OK,q12Shape34T367OK⟩

private def q12Shape34T368 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape34T368OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549790416896 103096909824 q12Shape34T368=true := by decide

private def q12Shape34T364 : Tree 12 := .split 25 q12Shape34T365 q12Shape34T368
private theorem q12Shape34T364OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756862464 103096909824 q12Shape34T364=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756862464 (103096909824 ||| 2^25) q12Shape34T365 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756862464 ||| 2^25) 103096909824 q12Shape34T368)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T365OK,q12Shape34T368OK⟩

private def q12Shape34T338 : Tree 12 := .split 20 q12Shape34T339 q12Shape34T364
private theorem q12Shape34T338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103096909824 q12Shape34T338=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 (103096909824 ||| 2^20) q12Shape34T339 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755813888 ||| 2^20) 103096909824 q12Shape34T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T339OK,q12Shape34T364OK⟩

private def q12Shape34T376 : Tree 12 := (.split 29 (.split 33 (.split 22 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.split 23 (.tip (.cover {0,2,3,7,8,9,10})) (.split 37 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,5,6,8,10,11})))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape34T376OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 111115894784 q12Shape34T376=true := by decide

private def q12Shape34T377 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T377OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550024773632 110847459328 q12Shape34T377=true := by decide

private def q12Shape34T375 : Tree 12 := .split 28 q12Shape34T376 q12Shape34T377
private theorem q12Shape34T375OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 110847459328 q12Shape34T375=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 (110847459328 ||| 2^28) q12Shape34T376 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756338176 ||| 2^28) 110847459328 q12Shape34T377)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T376OK,q12Shape34T377OK⟩

private def q12Shape34T378 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T378OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 554051305472 106552492032 q12Shape34T378=true := by decide

private def q12Shape34T374 : Tree 12 := .split 32 q12Shape34T375 q12Shape34T378
private theorem q12Shape34T374OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 106552492032 q12Shape34T374=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 (106552492032 ||| 2^32) q12Shape34T375 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756338176 ||| 2^32) 106552492032 q12Shape34T378)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T375OK,q12Shape34T378OK⟩

private def q12Shape34T379 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T379OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 551903821824 104405008384 q12Shape34T379=true := by decide

private def q12Shape34T373 : Tree 12 := .split 31 q12Shape34T374 q12Shape34T379
private theorem q12Shape34T373OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 104405008384 q12Shape34T373=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 (104405008384 ||| 2^31) q12Shape34T374 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756338176 ||| 2^31) 104405008384 q12Shape34T379)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T374OK,q12Shape34T379OK⟩

private def q12Shape34T380 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T380OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550830080000 103331266560 q12Shape34T380=true := by decide

private def q12Shape34T372 : Tree 12 := .split 30 q12Shape34T373 q12Shape34T380
private theorem q12Shape34T372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 103331266560 q12Shape34T372=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 (103331266560 ||| 2^30) q12Shape34T373 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756338176 ||| 2^30) 103331266560 q12Shape34T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T373OK,q12Shape34T380OK⟩

private def q12Shape34T381 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T381OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549890555904 103197048832 q12Shape34T381=true := by decide

private def q12Shape34T371 : Tree 12 := .split 27 q12Shape34T372 q12Shape34T381
private theorem q12Shape34T371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 103197048832 q12Shape34T371=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 (103197048832 ||| 2^27) q12Shape34T372 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756338176 ||| 2^27) 103197048832 q12Shape34T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T372OK,q12Shape34T381OK⟩

private def q12Shape34T382 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T382OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549823447040 103129939968 q12Shape34T382=true := by decide

private def q12Shape34T370 : Tree 12 := .split 26 q12Shape34T371 q12Shape34T382
private theorem q12Shape34T370OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 103129939968 q12Shape34T370=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 (103129939968 ||| 2^26) q12Shape34T371 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756338176 ||| 2^26) 103129939968 q12Shape34T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T371OK,q12Shape34T382OK⟩

private def q12Shape34T383 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape34T383OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549789892608 103096385536 q12Shape34T383=true := by decide

private def q12Shape34T369 : Tree 12 := .split 25 q12Shape34T370 q12Shape34T383
private theorem q12Shape34T369OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 103096385536 q12Shape34T369=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549756338176 (103096385536 ||| 2^25) q12Shape34T370 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549756338176 ||| 2^25) 103096385536 q12Shape34T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T370OK,q12Shape34T383OK⟩

private def q12Shape34T337 : Tree 12 := .split 19 q12Shape34T338 q12Shape34T369
private theorem q12Shape34T337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103096385536 q12Shape34T337=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 (103096385536 ||| 2^19) q12Shape34T338 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549755813888 ||| 2^19) 103096385536 q12Shape34T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T338OK,q12Shape34T369OK⟩

def q12Shape34P6 : Tree 12 := q12Shape34T337
theorem q12Shape34P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549755813888 103096385536 q12Shape34P6=true := q12Shape34T337OK

end Graffiti384b.EffectiveSearch.Q12
