import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T394 : Tree 12 := (.tip (.cover {0,1,2,3,9,10,11}))
private theorem q12Shape34T394OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 587592499200 q12Shape34T394=true := by decide

private def q12Shape34T395 : Tree 12 := (.split 22 (.split 23 (.split 28 (.split 29 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.tip (.cover {0,2,3,7,8,9,10})) (.split 44 (.tip (.cover {0,2,3,6,7,8,9})) (.tip (.cover {0,1,4,5,6,7,10}))))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T395OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 70866960384 585445015552 q12Shape34T395=true := by decide

private def q12Shape34T393 : Tree 12 := .split 31 q12Shape34T394 q12Shape34T395
private theorem q12Shape34T393OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 585445015552 q12Shape34T393=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (585445015552 ||| 2^31) q12Shape34T394 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^31) 585445015552 q12Shape34T395)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T394OK,q12Shape34T395OK⟩

private def q12Shape34T396 : Tree 12 := (.split 31 (.tip (.cover {0,1,2,3,7,10,11})) (.split 32 (.split 22 (.split 23 (.split 28 (.split 37 (.tip (.cover {0,2,3,6,8,9,11})) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))))
private theorem q12Shape34T396OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69793218560 584371273728 q12Shape34T396=true := by decide

private def q12Shape34T392 : Tree 12 := .split 30 q12Shape34T393 q12Shape34T396
private theorem q12Shape34T392OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 584371273728 q12Shape34T392=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (584371273728 ||| 2^30) q12Shape34T393 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^30) 584371273728 q12Shape34T396)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T393OK,q12Shape34T396OK⟩

private def q12Shape34T397 : Tree 12 := (.split 31 (.split 30 (.tip (.cover {0,1,2,3,9,10,11})) (.split 32 (.split 22 (.split 23 (.split 28 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape34T397OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68853694464 584237056000 q12Shape34T397=true := by decide

private def q12Shape34T391 : Tree 12 := .split 27 q12Shape34T392 q12Shape34T397
private theorem q12Shape34T391OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 584237056000 q12Shape34T391=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (584237056000 ||| 2^27) q12Shape34T392 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^27) 584237056000 q12Shape34T397)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T392OK,q12Shape34T397OK⟩

private def q12Shape34T401 : Tree 12 := (.split 22 (.split 23 (.split 33 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.split 29 (.tip (.cover {0,2,3,7,8,9,10})) (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,5,6,7,10})))) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape34T401OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786585600 591686139904 q12Shape34T401=true := by decide

private def q12Shape34T402 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T402OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 73081552896 587391172608 q12Shape34T402=true := by decide

private def q12Shape34T400 : Tree 12 := .split 32 q12Shape34T401 q12Shape34T402
private theorem q12Shape34T400OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786585600 587391172608 q12Shape34T400=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786585600 (587391172608 ||| 2^32) q12Shape34T401 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68786585600 ||| 2^32) 587391172608 q12Shape34T402)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T401OK,q12Shape34T402OK⟩

private def q12Shape34T403 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape34T403OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 70934069248 585243688960 q12Shape34T403=true := by decide

private def q12Shape34T399 : Tree 12 := .split 31 q12Shape34T400 q12Shape34T403
private theorem q12Shape34T399OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786585600 585243688960 q12Shape34T399=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786585600 (585243688960 ||| 2^31) q12Shape34T400 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68786585600 ||| 2^31) 585243688960 q12Shape34T403)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T400OK,q12Shape34T403OK⟩

private def q12Shape34T404 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T404OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69860327424 584169947136 q12Shape34T404=true := by decide

private def q12Shape34T398 : Tree 12 := .split 30 q12Shape34T399 q12Shape34T404
private theorem q12Shape34T398OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786585600 584169947136 q12Shape34T398=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68786585600 (584169947136 ||| 2^30) q12Shape34T399 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68786585600 ||| 2^30) 584169947136 q12Shape34T404)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T399OK,q12Shape34T404OK⟩

private def q12Shape34T390 : Tree 12 := .split 26 q12Shape34T391 q12Shape34T398
private theorem q12Shape34T390OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 584169947136 q12Shape34T390=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (584169947136 ||| 2^26) q12Shape34T391 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^26) 584169947136 q12Shape34T398)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T391OK,q12Shape34T398OK⟩

private def q12Shape34T405 : Tree 12 := (.split 30 (.split 31 (.split 22 (.split 23 (.split 33 (.split 28 (.tip (.cover {0,2,3,7,8,9,11})) (.split 37 (.tip (.cover {0,2,3,5,8,9,11})) (.tip (.cover {0,2,3,8,9,10,11})))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape34T405OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68753031168 584136392704 q12Shape34T405=true := by decide

private def q12Shape34T389 : Tree 12 := .split 25 q12Shape34T390 q12Shape34T405
private theorem q12Shape34T389OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 584136392704 q12Shape34T389=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (584136392704 ||| 2^25) q12Shape34T390 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^25) 584136392704 q12Shape34T405)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T390OK,q12Shape34T405OK⟩

private def q12Shape34T407 : Tree 12 := (.split 27 (.split 31 (.split 32 (.split 22 (.split 23 (.split 28 (.split 33 (.tip (.cover {0,2,3,7,8,9,11})) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,2,3,7,10,11}))) (.tip (.cover {0,1,2,3,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape34T407OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68721573888 584201404416 q12Shape34T407=true := by decide

private def q12Shape34T408 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape34T408OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68788682752 584134295552 q12Shape34T408=true := by decide

private def q12Shape34T406 : Tree 12 := .split 26 q12Shape34T407 q12Shape34T408
private theorem q12Shape34T406OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68721573888 584134295552 q12Shape34T406=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68721573888 (584134295552 ||| 2^26) q12Shape34T407 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68721573888 ||| 2^26) 584134295552 q12Shape34T408)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T407OK,q12Shape34T408OK⟩

private def q12Shape34T388 : Tree 12 := .split 21 q12Shape34T389 q12Shape34T406
private theorem q12Shape34T388OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 584134295552 q12Shape34T388=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (584134295552 ||| 2^21) q12Shape34T389 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^21) 584134295552 q12Shape34T406)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T389OK,q12Shape34T406OK⟩

private def q12Shape34T415 : Tree 12 := (.split 28 (.split 29 (.split 33 (.split 22 (.tip (.cover {0,2,3,7,8,9,11})) (.split 34 (.split 23 (.tip (.cover {0,2,3,7,8,9,10})) (.split 44 (.tip (.cover {0,2,3,4,7,8,9})) (.tip (.cover {0,1,4,5,6,7,10})))) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape34T415OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 591884320768 q12Shape34T415=true := by decide

private def q12Shape34T416 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T416OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 73015492608 587589353472 q12Shape34T416=true := by decide

private def q12Shape34T414 : Tree 12 := .split 32 q12Shape34T415 q12Shape34T416
private theorem q12Shape34T414OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 587589353472 q12Shape34T414=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 (587589353472 ||| 2^32) q12Shape34T415 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720525312 ||| 2^32) 587589353472 q12Shape34T416)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T415OK,q12Shape34T416OK⟩

private def q12Shape34T417 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T417OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 70868008960 585441869824 q12Shape34T417=true := by decide

private def q12Shape34T413 : Tree 12 := .split 31 q12Shape34T414 q12Shape34T417
private theorem q12Shape34T413OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 585441869824 q12Shape34T413=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 (585441869824 ||| 2^31) q12Shape34T414 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720525312 ||| 2^31) 585441869824 q12Shape34T417)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T414OK,q12Shape34T417OK⟩

private def q12Shape34T418 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T418OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69794267136 584368128000 q12Shape34T418=true := by decide

private def q12Shape34T412 : Tree 12 := .split 30 q12Shape34T413 q12Shape34T418
private theorem q12Shape34T412OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 584368128000 q12Shape34T412=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 (584368128000 ||| 2^30) q12Shape34T413 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720525312 ||| 2^30) 584368128000 q12Shape34T418)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T413OK,q12Shape34T418OK⟩

private def q12Shape34T419 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T419OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68854743040 584233910272 q12Shape34T419=true := by decide

private def q12Shape34T411 : Tree 12 := .split 27 q12Shape34T412 q12Shape34T419
private theorem q12Shape34T411OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 584233910272 q12Shape34T411=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 (584233910272 ||| 2^27) q12Shape34T412 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720525312 ||| 2^27) 584233910272 q12Shape34T419)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T412OK,q12Shape34T419OK⟩

private def q12Shape34T420 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape34T420OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68787634176 584166801408 q12Shape34T420=true := by decide

private def q12Shape34T410 : Tree 12 := .split 26 q12Shape34T411 q12Shape34T420
private theorem q12Shape34T410OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 584166801408 q12Shape34T410=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 (584166801408 ||| 2^26) q12Shape34T411 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720525312 ||| 2^26) 584166801408 q12Shape34T420)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T411OK,q12Shape34T420OK⟩

private def q12Shape34T421 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T421OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68754079744 584133246976 q12Shape34T421=true := by decide

private def q12Shape34T409 : Tree 12 := .split 25 q12Shape34T410 q12Shape34T421
private theorem q12Shape34T409OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 584133246976 q12Shape34T409=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720525312 (584133246976 ||| 2^25) q12Shape34T410 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720525312 ||| 2^25) 584133246976 q12Shape34T421)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T410OK,q12Shape34T421OK⟩

private def q12Shape34T387 : Tree 12 := .split 20 q12Shape34T388 q12Shape34T409
private theorem q12Shape34T387OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 584133246976 q12Shape34T387=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (584133246976 ||| 2^20) q12Shape34T388 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^20) 584133246976 q12Shape34T409)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T388OK,q12Shape34T409OK⟩

private def q12Shape34T424 : Tree 12 := (.split 30 (.split 31 (.split 28 (.split 29 (.split 33 (.split 22 (.tip (.cover {0,2,3,7,8,9,11})) (.split 37 (.tip (.cover {0,2,3,4,8,9,11})) (.tip (.cover {0,2,3,8,9,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape34T424OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720001024 584233385984 q12Shape34T424=true := by decide

private def q12Shape34T425 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape34T425OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68787109888 584166277120 q12Shape34T425=true := by decide

private def q12Shape34T423 : Tree 12 := .split 26 q12Shape34T424 q12Shape34T425
private theorem q12Shape34T423OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720001024 584166277120 q12Shape34T423=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720001024 (584166277120 ||| 2^26) q12Shape34T424 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720001024 ||| 2^26) 584166277120 q12Shape34T425)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T424OK,q12Shape34T425OK⟩

private def q12Shape34T426 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape34T426OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68753555456 584132722688 q12Shape34T426=true := by decide

private def q12Shape34T422 : Tree 12 := .split 25 q12Shape34T423 q12Shape34T426
private theorem q12Shape34T422OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720001024 584132722688 q12Shape34T422=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68720001024 (584132722688 ||| 2^25) q12Shape34T423 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68720001024 ||| 2^25) 584132722688 q12Shape34T426)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T423OK,q12Shape34T426OK⟩

private def q12Shape34T386 : Tree 12 := .split 19 q12Shape34T387 q12Shape34T422
private theorem q12Shape34T386OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 584132722688 q12Shape34T386=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (584132722688 ||| 2^19) q12Shape34T387 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^19) 584132722688 q12Shape34T422)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T387OK,q12Shape34T422OK⟩

private def q12Shape34T427 : Tree 12 := (.split 21 (.split 27 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape34T427OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 618475290624 34376908800 q12Shape34T427=true := by decide

private def q12Shape34T385 : Tree 12 := .split 39 q12Shape34T386 q12Shape34T427
private theorem q12Shape34T385OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 34376908800 q12Shape34T385=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 (34376908800 ||| 2^39) q12Shape34T386 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68719476736 ||| 2^39) 34376908800 q12Shape34T427)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T386OK,q12Shape34T427OK⟩

def q12Shape34P7 : Tree 12 := q12Shape34T385
theorem q12Shape34P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68719476736 34376908800 q12Shape34P7=true := q12Shape34T385OK

end Graffiti384b.EffectiveSearch.Q12
