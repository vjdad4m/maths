import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T479 : Tree 12 := (.tip (.cover {0,1,2,3,6,10,11}))
private theorem q12Shape34T479OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 653073973248 q12Shape34T479=true := by decide

private def q12Shape34T480 : Tree 12 := (.split 32 (.split 22 (.split 23 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,2,3,6,10,11})))
private theorem q12Shape34T480OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 150994944 652939755520 q12Shape34T480=true := by decide

private def q12Shape34T478 : Tree 12 := .split 27 q12Shape34T479 q12Shape34T480
private theorem q12Shape34T478OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 652939755520 q12Shape34T478=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (652939755520 ||| 2^27) q12Shape34T479 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^27) 652939755520 q12Shape34T480)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T479OK,q12Shape34T480OK⟩

private def q12Shape34T482 : Tree 12 := (.split 31 (.split 22 (.split 23 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,2,3,6,10,11})))
private theorem q12Shape34T482OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 83886080 653006864384 q12Shape34T482=true := by decide

private def q12Shape34T483 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T483OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 218103808 652872646656 q12Shape34T483=true := by decide

private def q12Shape34T481 : Tree 12 := .split 27 q12Shape34T482 q12Shape34T483
private theorem q12Shape34T481OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 83886080 652872646656 q12Shape34T481=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 83886080 (652872646656 ||| 2^27) q12Shape34T482 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (83886080 ||| 2^27) 652872646656 q12Shape34T483)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T482OK,q12Shape34T483OK⟩

private def q12Shape34T477 : Tree 12 := .split 26 q12Shape34T478 q12Shape34T481
private theorem q12Shape34T477OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 652872646656 q12Shape34T477=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (652872646656 ||| 2^26) q12Shape34T478 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^26) 652872646656 q12Shape34T481)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T478OK,q12Shape34T481OK⟩

private def q12Shape34T486 : Tree 12 := (.split 30 (.split 22 (.split 23 (.split 37 (.split 38 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,2,3,6,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,2,3,6,10,11})))
private theorem q12Shape34T486OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 50331648 653040418816 q12Shape34T486=true := by decide

private def q12Shape34T487 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T487OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 184549376 652906201088 q12Shape34T487=true := by decide

private def q12Shape34T485 : Tree 12 := .split 27 q12Shape34T486 q12Shape34T487
private theorem q12Shape34T485OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 50331648 652906201088 q12Shape34T485=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 50331648 (652906201088 ||| 2^27) q12Shape34T486 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (50331648 ||| 2^27) 652906201088 q12Shape34T487)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T486OK,q12Shape34T487OK⟩

private def q12Shape34T488 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T488OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 117440512 652839092224 q12Shape34T488=true := by decide

private def q12Shape34T484 : Tree 12 := .split 26 q12Shape34T485 q12Shape34T488
private theorem q12Shape34T484OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 50331648 652839092224 q12Shape34T484=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 50331648 (652839092224 ||| 2^26) q12Shape34T485 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (50331648 ||| 2^26) 652839092224 q12Shape34T488)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T485OK,q12Shape34T488OK⟩

private def q12Shape34T476 : Tree 12 := .split 25 q12Shape34T477 q12Shape34T484
private theorem q12Shape34T476OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 652839092224 q12Shape34T476=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (652839092224 ||| 2^25) q12Shape34T477 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^25) 652839092224 q12Shape34T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T477OK,q12Shape34T484OK⟩

private def q12Shape34T497 : Tree 12 := (.split 37 (.split 38 (.split 40 (.split 27 (.split 32 (.split 22 (.tip (.cover {0,1,2,3,5,9,11})) (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {1,2,3,4,5,9,11}))) (.tip (.cover {1,2,3,4,6,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape34T497OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 682733993984 q12Shape34T497=true := by decide

private def q12Shape34T498 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T498OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17198743552 665554124800 q12Shape34T498=true := by decide

private def q12Shape34T496 : Tree 12 := .split 34 q12Shape34T497 q12Shape34T498
private theorem q12Shape34T496OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 665554124800 q12Shape34T496=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (665554124800 ||| 2^34) q12Shape34T497 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^34) 665554124800 q12Shape34T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T497OK,q12Shape34T498OK⟩

private def q12Shape34T499 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T499OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8608808960 656964190208 q12Shape34T499=true := by decide

private def q12Shape34T495 : Tree 12 := .split 33 q12Shape34T496 q12Shape34T499
private theorem q12Shape34T495OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 656964190208 q12Shape34T495=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (656964190208 ||| 2^33) q12Shape34T496 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^33) 656964190208 q12Shape34T499)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T496OK,q12Shape34T499OK⟩

private def q12Shape34T500 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T500OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 555745280 656427319296 q12Shape34T500=true := by decide

private def q12Shape34T494 : Tree 12 := .split 29 q12Shape34T495 q12Shape34T500
private theorem q12Shape34T494OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 656427319296 q12Shape34T494=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (656427319296 ||| 2^29) q12Shape34T495 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^29) 656427319296 q12Shape34T500)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T495OK,q12Shape34T500OK⟩

private def q12Shape34T501 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T501OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 287309824 656158883840 q12Shape34T501=true := by decide

private def q12Shape34T493 : Tree 12 := .split 28 q12Shape34T494 q12Shape34T501
private theorem q12Shape34T493OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 656158883840 q12Shape34T493=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (656158883840 ||| 2^28) q12Shape34T494 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^28) 656158883840 q12Shape34T501)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T494OK,q12Shape34T501OK⟩

private def q12Shape34T502 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T502OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2166358016 654011400192 q12Shape34T502=true := by decide

private def q12Shape34T492 : Tree 12 := .split 31 q12Shape34T493 q12Shape34T502
private theorem q12Shape34T492OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 654011400192 q12Shape34T492=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (654011400192 ||| 2^31) q12Shape34T493 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^31) 654011400192 q12Shape34T502)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T493OK,q12Shape34T502OK⟩

private def q12Shape34T503 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T503OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1092616192 652937658368 q12Shape34T503=true := by decide

private def q12Shape34T491 : Tree 12 := .split 30 q12Shape34T492 q12Shape34T503
private theorem q12Shape34T491OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 652937658368 q12Shape34T491=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (652937658368 ||| 2^30) q12Shape34T492 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^30) 652937658368 q12Shape34T503)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T492OK,q12Shape34T503OK⟩

private def q12Shape34T504 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T504OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 85983232 652870549504 q12Shape34T504=true := by decide

private def q12Shape34T490 : Tree 12 := .split 26 q12Shape34T491 q12Shape34T504
private theorem q12Shape34T490OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 652870549504 q12Shape34T490=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (652870549504 ||| 2^26) q12Shape34T491 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^26) 652870549504 q12Shape34T504)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T491OK,q12Shape34T504OK⟩

private def q12Shape34T505 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T505OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 52428800 652836995072 q12Shape34T505=true := by decide

private def q12Shape34T489 : Tree 12 := .split 25 q12Shape34T490 q12Shape34T505
private theorem q12Shape34T489OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 652836995072 q12Shape34T489=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18874368 (652836995072 ||| 2^25) q12Shape34T490 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (18874368 ||| 2^25) 652836995072 q12Shape34T505)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T490OK,q12Shape34T505OK⟩

private def q12Shape34T475 : Tree 12 := .split 21 q12Shape34T476 q12Shape34T489
private theorem q12Shape34T475OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 652836995072 q12Shape34T475=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (652836995072 ||| 2^21) q12Shape34T476 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^21) 652836995072 q12Shape34T489)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T476OK,q12Shape34T489OK⟩

private def q12Shape34T515 : Tree 12 := (.split 37 (.split 38 (.split 42 (.split 26 (.split 31 (.split 22 (.tip (.cover {0,1,2,3,5,8,11})) (.split 40 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {1,2,3,4,5,8,11}))) (.tip (.cover {1,2,3,4,6,8,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11})))
private theorem q12Shape34T515OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 684949635072 q12Shape34T515=true := by decide

private def q12Shape34T516 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T516OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17197694976 667769765888 q12Shape34T516=true := by decide

private def q12Shape34T514 : Tree 12 := .split 34 q12Shape34T515 q12Shape34T516
private theorem q12Shape34T514OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 667769765888 q12Shape34T514=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (667769765888 ||| 2^34) q12Shape34T515 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^34) 667769765888 q12Shape34T516)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T515OK,q12Shape34T516OK⟩

private def q12Shape34T517 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T517OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8607760384 659179831296 q12Shape34T517=true := by decide

private def q12Shape34T513 : Tree 12 := .split 33 q12Shape34T514 q12Shape34T517
private theorem q12Shape34T513OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 659179831296 q12Shape34T513=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (659179831296 ||| 2^33) q12Shape34T514 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^33) 659179831296 q12Shape34T517)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T514OK,q12Shape34T517OK⟩

private def q12Shape34T518 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T518OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 554696704 658642960384 q12Shape34T518=true := by decide

private def q12Shape34T512 : Tree 12 := .split 29 q12Shape34T513 q12Shape34T518
private theorem q12Shape34T512OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 658642960384 q12Shape34T512=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (658642960384 ||| 2^29) q12Shape34T513 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^29) 658642960384 q12Shape34T518)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T513OK,q12Shape34T518OK⟩

private def q12Shape34T519 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T519OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 286261248 658374524928 q12Shape34T519=true := by decide

private def q12Shape34T511 : Tree 12 := .split 28 q12Shape34T512 q12Shape34T519
private theorem q12Shape34T511OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 658374524928 q12Shape34T511=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (658374524928 ||| 2^28) q12Shape34T512 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^28) 658374524928 q12Shape34T519)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T512OK,q12Shape34T519OK⟩

private def q12Shape34T520 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T520OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4312793088 654079557632 q12Shape34T520=true := by decide

private def q12Shape34T510 : Tree 12 := .split 32 q12Shape34T511 q12Shape34T520
private theorem q12Shape34T510OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 654079557632 q12Shape34T510=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (654079557632 ||| 2^32) q12Shape34T511 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^32) 654079557632 q12Shape34T520)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T511OK,q12Shape34T520OK⟩

private def q12Shape34T521 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T521OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1091567616 653005815808 q12Shape34T521=true := by decide

private def q12Shape34T509 : Tree 12 := .split 30 q12Shape34T510 q12Shape34T521
private theorem q12Shape34T509OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 653005815808 q12Shape34T509=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (653005815808 ||| 2^30) q12Shape34T510 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^30) 653005815808 q12Shape34T521)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T510OK,q12Shape34T521OK⟩

private def q12Shape34T522 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T522OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 152043520 652871598080 q12Shape34T522=true := by decide

private def q12Shape34T508 : Tree 12 := .split 27 q12Shape34T509 q12Shape34T522
private theorem q12Shape34T508OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 652871598080 q12Shape34T508=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (652871598080 ||| 2^27) q12Shape34T509 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^27) 652871598080 q12Shape34T522)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T509OK,q12Shape34T522OK⟩

private def q12Shape34T523 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T523OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 51380224 652838043648 q12Shape34T523=true := by decide

private def q12Shape34T507 : Tree 12 := .split 25 q12Shape34T508 q12Shape34T523
private theorem q12Shape34T507OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 652838043648 q12Shape34T507=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (652838043648 ||| 2^25) q12Shape34T508 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^25) 652838043648 q12Shape34T523)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T508OK,q12Shape34T523OK⟩

private def q12Shape34T524 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T524OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 19922944 652835946496 q12Shape34T524=true := by decide

private def q12Shape34T506 : Tree 12 := .split 21 q12Shape34T507 q12Shape34T524
private theorem q12Shape34T506OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 652835946496 q12Shape34T506=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17825792 (652835946496 ||| 2^21) q12Shape34T507 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17825792 ||| 2^21) 652835946496 q12Shape34T524)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T507OK,q12Shape34T524OK⟩

private def q12Shape34T474 : Tree 12 := .split 20 q12Shape34T475 q12Shape34T506
private theorem q12Shape34T474OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 652835946496 q12Shape34T474=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (652835946496 ||| 2^20) q12Shape34T475 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^20) 652835946496 q12Shape34T506)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T475OK,q12Shape34T506OK⟩

private def q12Shape34T535 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 25 (.split 30 (.split 22 (.tip (.cover {0,1,2,3,5,7,11})) (.split 37 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {1,2,3,4,5,7,11}))) (.tip (.cover {1,2,3,4,6,7,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11})))
private theorem q12Shape34T535OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 686057455616 q12Shape34T535=true := by decide

private def q12Shape34T536 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T536OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17197170688 668877586432 q12Shape34T536=true := by decide

private def q12Shape34T534 : Tree 12 := .split 34 q12Shape34T535 q12Shape34T536
private theorem q12Shape34T534OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 668877586432 q12Shape34T534=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (668877586432 ||| 2^34) q12Shape34T535 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^34) 668877586432 q12Shape34T536)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T535OK,q12Shape34T536OK⟩

private def q12Shape34T537 : Tree 12 := (.tip (.cover {1,2,3,4,5,10,11}))
private theorem q12Shape34T537OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 8607236096 660287651840 q12Shape34T537=true := by decide

private def q12Shape34T533 : Tree 12 := .split 33 q12Shape34T534 q12Shape34T537
private theorem q12Shape34T533OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 660287651840 q12Shape34T533=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (660287651840 ||| 2^33) q12Shape34T534 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^33) 660287651840 q12Shape34T537)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T534OK,q12Shape34T537OK⟩

private def q12Shape34T538 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T538OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 554172416 659750780928 q12Shape34T538=true := by decide

private def q12Shape34T532 : Tree 12 := .split 29 q12Shape34T533 q12Shape34T538
private theorem q12Shape34T532OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 659750780928 q12Shape34T532=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (659750780928 ||| 2^29) q12Shape34T533 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^29) 659750780928 q12Shape34T538)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T533OK,q12Shape34T538OK⟩

private def q12Shape34T539 : Tree 12 := (.tip (.cover {1,2,3,4,6,10,11}))
private theorem q12Shape34T539OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 285736960 659482345472 q12Shape34T539=true := by decide

private def q12Shape34T531 : Tree 12 := .split 28 q12Shape34T532 q12Shape34T539
private theorem q12Shape34T531OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 659482345472 q12Shape34T531=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (659482345472 ||| 2^28) q12Shape34T532 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^28) 659482345472 q12Shape34T539)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T532OK,q12Shape34T539OK⟩

private def q12Shape34T540 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T540OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 4312268800 655187378176 q12Shape34T540=true := by decide

private def q12Shape34T530 : Tree 12 := .split 32 q12Shape34T531 q12Shape34T540
private theorem q12Shape34T530OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 655187378176 q12Shape34T530=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (655187378176 ||| 2^32) q12Shape34T531 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^32) 655187378176 q12Shape34T540)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T531OK,q12Shape34T540OK⟩

private def q12Shape34T541 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape34T541OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2164785152 653039894528 q12Shape34T541=true := by decide

private def q12Shape34T529 : Tree 12 := .split 31 q12Shape34T530 q12Shape34T541
private theorem q12Shape34T529OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 653039894528 q12Shape34T529=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (653039894528 ||| 2^31) q12Shape34T530 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^31) 653039894528 q12Shape34T541)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T530OK,q12Shape34T541OK⟩

private def q12Shape34T542 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T542OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 151519232 652905676800 q12Shape34T542=true := by decide

private def q12Shape34T528 : Tree 12 := .split 27 q12Shape34T529 q12Shape34T542
private theorem q12Shape34T528OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 652905676800 q12Shape34T528=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (652905676800 ||| 2^27) q12Shape34T529 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^27) 652905676800 q12Shape34T542)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T529OK,q12Shape34T542OK⟩

private def q12Shape34T543 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T543OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 84410368 652838567936 q12Shape34T543=true := by decide

private def q12Shape34T527 : Tree 12 := .split 26 q12Shape34T528 q12Shape34T543
private theorem q12Shape34T527OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 652838567936 q12Shape34T527=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (652838567936 ||| 2^26) q12Shape34T528 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^26) 652838567936 q12Shape34T543)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T528OK,q12Shape34T543OK⟩

private def q12Shape34T544 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T544OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 19398656 652836470784 q12Shape34T544=true := by decide

private def q12Shape34T526 : Tree 12 := .split 21 q12Shape34T527 q12Shape34T544
private theorem q12Shape34T526OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 652836470784 q12Shape34T526=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (652836470784 ||| 2^21) q12Shape34T527 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^21) 652836470784 q12Shape34T544)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T527OK,q12Shape34T544OK⟩

private def q12Shape34T545 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T545OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 18350080 652835422208 q12Shape34T545=true := by decide

private def q12Shape34T525 : Tree 12 := .split 20 q12Shape34T526 q12Shape34T545
private theorem q12Shape34T525OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 652835422208 q12Shape34T525=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 17301504 (652835422208 ||| 2^20) q12Shape34T526 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (17301504 ||| 2^20) 652835422208 q12Shape34T545)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T526OK,q12Shape34T545OK⟩

private def q12Shape34T473 : Tree 12 := .split 19 q12Shape34T474 q12Shape34T525
private theorem q12Shape34T473OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 652835422208 q12Shape34T473=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 (652835422208 ||| 2^19) q12Shape34T474 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (16777216 ||| 2^19) 652835422208 q12Shape34T525)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T474OK,q12Shape34T525OK⟩

def q12Shape34P9 : Tree 12 := q12Shape34T473
theorem q12Shape34P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 16777216 652835422208 q12Shape34P9=true := q12Shape34T473OK

end Graffiti384b.EffectiveSearch.Q12
