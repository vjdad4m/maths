import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape34T559 : Tree 12 := (.split 28 (.split 40 (.tip (.cover {0,1,2,3,6,9,11})) (.split 42 (.tip (.cover {0,1,2,3,6,8,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.split 33 (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,8,10,11}))))
private theorem q12Shape34T559OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 523163795456 q12Shape34T559=true := by decide

private def q12Shape34T560 : Tree 12 := (.split 28 (.split 40 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape34T560OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 554067558400 518868828160 q12Shape34T560=true := by decide

private def q12Shape34T558 : Tree 12 := .split 32 q12Shape34T559 q12Shape34T560
private theorem q12Shape34T558OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 518868828160 q12Shape34T558=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (518868828160 ||| 2^32) q12Shape34T559 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^32) 518868828160 q12Shape34T560)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T559OK,q12Shape34T560OK⟩

private def q12Shape34T561 : Tree 12 := (.split 32 (.split 28 (.split 42 (.tip (.cover {0,1,2,3,6,8,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape34T561OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 551920074752 516721344512 q12Shape34T561=true := by decide

private def q12Shape34T557 : Tree 12 := .split 31 q12Shape34T558 q12Shape34T561
private theorem q12Shape34T557OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 516721344512 q12Shape34T557=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (516721344512 ||| 2^31) q12Shape34T558 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^31) 516721344512 q12Shape34T561)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T558OK,q12Shape34T561OK⟩

private def q12Shape34T562 : Tree 12 := (.split 32 (.split 33 (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape34T562OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549906808832 516587126784 q12Shape34T562=true := by decide

private def q12Shape34T556 : Tree 12 := .split 27 q12Shape34T557 q12Shape34T562
private theorem q12Shape34T556OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 516587126784 q12Shape34T556=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (516587126784 ||| 2^27) q12Shape34T557 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^27) 516587126784 q12Shape34T562)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T557OK,q12Shape34T562OK⟩

private def q12Shape34T563 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T563OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 824650498048 241709219840 q12Shape34T563=true := by decide

private def q12Shape34T555 : Tree 12 := .split 38 q12Shape34T556 q12Shape34T563
private theorem q12Shape34T555OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 241709219840 q12Shape34T555=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (241709219840 ||| 2^38) q12Shape34T556 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^38) 241709219840 q12Shape34T563)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T556OK,q12Shape34T563OK⟩

private def q12Shape34T564 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T564OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 687211544576 104270266368 q12Shape34T564=true := by decide

private def q12Shape34T554 : Tree 12 := .split 37 q12Shape34T555 q12Shape34T564
private theorem q12Shape34T554OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 104270266368 q12Shape34T554=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (104270266368 ||| 2^37) q12Shape34T555 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^37) 104270266368 q12Shape34T564)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T555OK,q12Shape34T564OK⟩

private def q12Shape34T565 : Tree 12 := (.split 27 (.split 31 (.split 33 (.split 34 (.split 37 (.split 42 (.tip (.cover {0,1,2,3,5,8,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape34T565OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549839699968 104203157504 q12Shape34T565=true := by decide

private def q12Shape34T553 : Tree 12 := .split 26 q12Shape34T554 q12Shape34T565
private theorem q12Shape34T553OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 104203157504 q12Shape34T553=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (104203157504 ||| 2^26) q12Shape34T554 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^26) 104203157504 q12Shape34T565)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T554OK,q12Shape34T565OK⟩

private def q12Shape34T566 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T566OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549780979712 104194768896 q12Shape34T566=true := by decide

private def q12Shape34T552 : Tree 12 := .split 23 q12Shape34T553 q12Shape34T566
private theorem q12Shape34T552OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 104194768896 q12Shape34T552=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (104194768896 ||| 2^23) q12Shape34T553 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^23) 104194768896 q12Shape34T566)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T553OK,q12Shape34T566OK⟩

private def q12Shape34T567 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T567OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549776785408 104190574592 q12Shape34T567=true := by decide

private def q12Shape34T551 : Tree 12 := .split 22 q12Shape34T552 q12Shape34T567
private theorem q12Shape34T551OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 104190574592 q12Shape34T551=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (104190574592 ||| 2^22) q12Shape34T552 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^22) 104190574592 q12Shape34T567)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T552OK,q12Shape34T567OK⟩

private def q12Shape34T568 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape34T568OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 550846332928 103116832768 q12Shape34T568=true := by decide

private def q12Shape34T550 : Tree 12 := .split 30 q12Shape34T551 q12Shape34T568
private theorem q12Shape34T550OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 103116832768 q12Shape34T550=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (103116832768 ||| 2^30) q12Shape34T551 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^30) 103116832768 q12Shape34T568)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T551OK,q12Shape34T568OK⟩

private def q12Shape34T569 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T569OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549806145536 103083278336 q12Shape34T569=true := by decide

private def q12Shape34T549 : Tree 12 := .split 25 q12Shape34T550 q12Shape34T569
private theorem q12Shape34T549OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 103083278336 q12Shape34T549=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (103083278336 ||| 2^25) q12Shape34T550 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^25) 103083278336 q12Shape34T569)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T550OK,q12Shape34T569OK⟩

private def q12Shape34T570 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape34T570OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549774688256 103081181184 q12Shape34T570=true := by decide

private def q12Shape34T548 : Tree 12 := .split 21 q12Shape34T549 q12Shape34T570
private theorem q12Shape34T548OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 103081181184 q12Shape34T548=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (103081181184 ||| 2^21) q12Shape34T549 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^21) 103081181184 q12Shape34T570)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T549OK,q12Shape34T570OK⟩

private def q12Shape34T571 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T571OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549773639680 103080132608 q12Shape34T571=true := by decide

private def q12Shape34T547 : Tree 12 := .split 20 q12Shape34T548 q12Shape34T571
private theorem q12Shape34T547OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 103080132608 q12Shape34T547=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (103080132608 ||| 2^20) q12Shape34T548 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^20) 103080132608 q12Shape34T571)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T548OK,q12Shape34T571OK⟩

private def q12Shape34T572 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape34T572OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549773115392 103079608320 q12Shape34T572=true := by decide

private def q12Shape34T546 : Tree 12 := .split 19 q12Shape34T547 q12Shape34T572
private theorem q12Shape34T546OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 103079608320 q12Shape34T546=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 (103079608320 ||| 2^19) q12Shape34T547 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (549772591104 ||| 2^19) 103079608320 q12Shape34T572)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T547OK,q12Shape34T572OK⟩

def q12Shape34P10 : Tree 12 := q12Shape34T546
theorem q12Shape34P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 549772591104 103079608320 q12Shape34P10=true := q12Shape34T546OK

private def q12Shape34T588 : Tree 12 := (.split 28 (.split 37 (.tip (.cover {0,1,2,3,6,9,11})) (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,8,10,11})))) (.split 33 (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,8,10,11}))))
private theorem q12Shape34T588OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 3890418155520 q12Shape34T588=true := by decide

private def q12Shape34T589 : Tree 12 := (.split 28 (.split 37 (.tip (.cover {0,1,2,3,6,9,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape34T589OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 73031221248 3886123188224 q12Shape34T589=true := by decide

private def q12Shape34T587 : Tree 12 := .split 32 q12Shape34T588 q12Shape34T589
private theorem q12Shape34T587OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 3886123188224 q12Shape34T587=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (3886123188224 ||| 2^32) q12Shape34T588 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^32) 3886123188224 q12Shape34T589)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T588OK,q12Shape34T589OK⟩

private def q12Shape34T590 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T590OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 2267759509504 1687099932672 q12Shape34T590=true := by decide

private def q12Shape34T586 : Tree 12 := .split 41 q12Shape34T587 q12Shape34T590
private theorem q12Shape34T586OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 1687099932672 q12Shape34T586=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (1687099932672 ||| 2^41) q12Shape34T587 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^41) 1687099932672 q12Shape34T590)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T587OK,q12Shape34T590OK⟩

private def q12Shape34T591 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T591OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 1168247881728 587588304896 q12Shape34T591=true := by decide

private def q12Shape34T585 : Tree 12 := .split 40 q12Shape34T586 q12Shape34T591
private theorem q12Shape34T585OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 587588304896 q12Shape34T585=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (587588304896 ||| 2^40) q12Shape34T586 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^40) 587588304896 q12Shape34T591)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T586OK,q12Shape34T591OK⟩

private def q12Shape34T592 : Tree 12 := (.split 32 (.split 28 (.split 29 (.split 37 (.tip (.cover {0,2,3,6,8,9,11})) (.split 44 (.tip (.cover {0,2,3,6,7,8,9})) (.tip (.cover {0,1,4,5,7,8,11})))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape34T592OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 69809995776 586514563072 q12Shape34T592=true := by decide

private def q12Shape34T584 : Tree 12 := .split 30 q12Shape34T585 q12Shape34T592
private theorem q12Shape34T584OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 586514563072 q12Shape34T584=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (586514563072 ||| 2^30) q12Shape34T585 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^30) 586514563072 q12Shape34T592)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T585OK,q12Shape34T592OK⟩

private def q12Shape34T593 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 37 (.split 40 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape34T593OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68870471680 586380345344 q12Shape34T593=true := by decide

private def q12Shape34T583 : Tree 12 := .split 27 q12Shape34T584 q12Shape34T593
private theorem q12Shape34T583OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 586380345344 q12Shape34T583=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (586380345344 ||| 2^27) q12Shape34T584 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^27) 586380345344 q12Shape34T593)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T584OK,q12Shape34T593OK⟩

private def q12Shape34T594 : Tree 12 := (.split 27 (.split 30 (.split 33 (.split 34 (.split 37 (.tip (.cover {0,2,3,5,8,9,11})) (.split 32 (.split 44 (.tip (.cover {0,2,3,5,7,8,9})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,6,8,10,11})))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape34T594OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68769808384 586346790912 q12Shape34T594=true := by decide

private def q12Shape34T582 : Tree 12 := .split 25 q12Shape34T583 q12Shape34T594
private theorem q12Shape34T582OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 586346790912 q12Shape34T582=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (586346790912 ||| 2^25) q12Shape34T583 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^25) 586346790912 q12Shape34T594)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T583OK,q12Shape34T594OK⟩

private def q12Shape34T595 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T595OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68744642560 586338402304 q12Shape34T595=true := by decide

private def q12Shape34T581 : Tree 12 := .split 23 q12Shape34T582 q12Shape34T595
private theorem q12Shape34T581OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 586338402304 q12Shape34T581=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (586338402304 ||| 2^23) q12Shape34T582 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^23) 586338402304 q12Shape34T595)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T582OK,q12Shape34T595OK⟩

private def q12Shape34T596 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T596OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68740448256 586334208000 q12Shape34T596=true := by decide

private def q12Shape34T580 : Tree 12 := .split 22 q12Shape34T581 q12Shape34T596
private theorem q12Shape34T580OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 586334208000 q12Shape34T580=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (586334208000 ||| 2^22) q12Shape34T581 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^22) 586334208000 q12Shape34T596)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T581OK,q12Shape34T596OK⟩

private def q12Shape34T597 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape34T597OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 70883737600 584186724352 q12Shape34T597=true := by decide

private def q12Shape34T579 : Tree 12 := .split 31 q12Shape34T580 q12Shape34T597
private theorem q12Shape34T579OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 584186724352 q12Shape34T579=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (584186724352 ||| 2^31) q12Shape34T580 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^31) 584186724352 q12Shape34T597)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T580OK,q12Shape34T597OK⟩

private def q12Shape34T598 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T598OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68803362816 584119615488 q12Shape34T598=true := by decide

private def q12Shape34T578 : Tree 12 := .split 26 q12Shape34T579 q12Shape34T598
private theorem q12Shape34T578OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 584119615488 q12Shape34T578=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (584119615488 ||| 2^26) q12Shape34T579 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^26) 584119615488 q12Shape34T598)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T579OK,q12Shape34T598OK⟩

private def q12Shape34T599 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape34T599OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68738351104 584117518336 q12Shape34T599=true := by decide

private def q12Shape34T577 : Tree 12 := .split 21 q12Shape34T578 q12Shape34T599
private theorem q12Shape34T577OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 584117518336 q12Shape34T577=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (584117518336 ||| 2^21) q12Shape34T578 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^21) 584117518336 q12Shape34T599)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T578OK,q12Shape34T599OK⟩

private def q12Shape34T600 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape34T600OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68737302528 584116469760 q12Shape34T600=true := by decide

private def q12Shape34T576 : Tree 12 := .split 20 q12Shape34T577 q12Shape34T600
private theorem q12Shape34T576OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 584116469760 q12Shape34T576=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (584116469760 ||| 2^20) q12Shape34T577 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^20) 584116469760 q12Shape34T600)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T577OK,q12Shape34T600OK⟩

private def q12Shape34T601 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape34T601OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736778240 584115945472 q12Shape34T601=true := by decide

private def q12Shape34T575 : Tree 12 := .split 19 q12Shape34T576 q12Shape34T601
private theorem q12Shape34T575OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 584115945472 q12Shape34T575=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (584115945472 ||| 2^19) q12Shape34T576 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^19) 584115945472 q12Shape34T601)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T576OK,q12Shape34T601OK⟩

private def q12Shape34T602 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape34T602OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 618492067840 34360131584 q12Shape34T602=true := by decide

private def q12Shape34T574 : Tree 12 := .split 39 q12Shape34T575 q12Shape34T602
private theorem q12Shape34T574OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 34360131584 q12Shape34T574=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 (34360131584 ||| 2^39) q12Shape34T575 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) (68736253952 ||| 2^39) 34360131584 q12Shape34T602)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape34T575OK,q12Shape34T602OK⟩

def q12Shape34P11 : Tree 12 := q12Shape34T574
theorem q12Shape34P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,2⟩) 68736253952 34360131584 q12Shape34P11=true := q12Shape34T574OK

end Graffiti384b.EffectiveSearch.Q12
