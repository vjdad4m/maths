import Q12Shape35Part0
import Q12Shape35Part1

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape35M88 : Tree 12 := .split 26 q12Shape35P0 q12Shape35P1
private theorem q12Shape35M88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 34410070016 q12Shape35M88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (34410070016 ||| 2^26) q12Shape35P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^26) 34410070016 q12Shape35P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35P0OK,q12Shape35P1OK⟩
private def q12Shape35M112 : Tree 12 := .split 25 q12Shape35M88 q12Shape35P2
private theorem q12Shape35M112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 34376515584 q12Shape35M112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (34376515584 ||| 2^25) q12Shape35M88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^25) 34376515584 q12Shape35P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35M88OK,q12Shape35P2OK⟩
private def q12Shape35M124 : Tree 12 := .split 35 q12Shape35M112 q12Shape35P3
private theorem q12Shape35M124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 16777216 q12Shape35M124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (16777216 ||| 2^35) q12Shape35M112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^35) 16777216 q12Shape35P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35M112OK,q12Shape35P3OK⟩
private def q12Shape35M138 : Tree 12 := .split 24 q12Shape35M124 q12Shape35P4
private theorem q12Shape35M138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 0 q12Shape35M138=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (0 ||| 2^24) q12Shape35M124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^24) 0 q12Shape35P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35M124OK,q12Shape35P4OK⟩

theorem q12Shape35_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 35) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 35) b) (adj 12 (forms 35) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) adj_mono b H q12Shape35M138 q12Shape35M138OK

#print axioms q12Shape35_cover

end Graffiti384b.EffectiveSearch.Q12
