import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape35T7 : Tree 12 := (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 34 (.split 43 (.tip (.cover {0,2,3,4,7,8,10})) (.split 37 (.split 40 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))) (.split 36 (.split 39 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))))
private theorem q12Shape35T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 51522830336 q12Shape35T7=true := by decide

private def q12Shape35T8 : Tree 12 := (.split 36 (.split 39 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape35T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 8589934592 42932895744 q12Shape35T8=true := by decide

private def q12Shape35T6 : Tree 12 := .split 33 q12Shape35T7 q12Shape35T8
private theorem q12Shape35T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 42932895744 q12Shape35T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (42932895744 ||| 2^33) q12Shape35T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^33) 42932895744 q12Shape35T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T7OK,q12Shape35T8OK⟩

private def q12Shape35T12 : Tree 12 := (.split 39 (.split 40 (.split 33 (.tip (.cover {0,1,2,3,4,9,11})) (.split 41 (.split 34 (.tip (.cover {1,2,3,4,5,9,10})) (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.split 43 (.tip (.cover {1,2,3,4,5,6,10})) (.tip (.cover {0,1,5,6,7,8,9}))))) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape35T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4294967296 519674265600 q12Shape35T12=true := by decide

private def q12Shape35T13 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 279172874240 244796358656 q12Shape35T13=true := by decide

private def q12Shape35T11 : Tree 12 := .split 38 q12Shape35T12 q12Shape35T13
private theorem q12Shape35T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4294967296 244796358656 q12Shape35T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4294967296 (244796358656 ||| 2^38) q12Shape35T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (4294967296 ||| 2^38) 244796358656 q12Shape35T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T12OK,q12Shape35T13OK⟩

private def q12Shape35T14 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 141733920768 107357405184 q12Shape35T14=true := by decide

private def q12Shape35T10 : Tree 12 := .split 37 q12Shape35T11 q12Shape35T14
private theorem q12Shape35T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4294967296 107357405184 q12Shape35T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4294967296 (107357405184 ||| 2^37) q12Shape35T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (4294967296 ||| 2^37) 107357405184 q12Shape35T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T11OK,q12Shape35T14OK⟩

private def q12Shape35T15 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 73014444032 38637928448 q12Shape35T15=true := by decide

private def q12Shape35T9 : Tree 12 := .split 36 q12Shape35T10 q12Shape35T15
private theorem q12Shape35T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4294967296 38637928448 q12Shape35T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4294967296 (38637928448 ||| 2^36) q12Shape35T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (4294967296 ||| 2^36) 38637928448 q12Shape35T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T10OK,q12Shape35T15OK⟩

private def q12Shape35T5 : Tree 12 := .split 32 q12Shape35T6 q12Shape35T9
private theorem q12Shape35T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 38637928448 q12Shape35T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (38637928448 ||| 2^32) q12Shape35T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^32) 38637928448 q12Shape35T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T6OK,q12Shape35T9OK⟩

private def q12Shape35T16 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 36 (.split 39 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape35T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 536870912 38101057536 q12Shape35T16=true := by decide

private def q12Shape35T4 : Tree 12 := .split 29 q12Shape35T5 q12Shape35T16
private theorem q12Shape35T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 38101057536 q12Shape35T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (38101057536 ||| 2^29) q12Shape35T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^29) 38101057536 q12Shape35T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T5OK,q12Shape35T16OK⟩

private def q12Shape35T17 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 36 (.split 39 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape35T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 268435456 37832622080 q12Shape35T17=true := by decide

private def q12Shape35T3 : Tree 12 := .split 28 q12Shape35T4 q12Shape35T17
private theorem q12Shape35T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 37832622080 q12Shape35T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (37832622080 ||| 2^28) q12Shape35T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^28) 37832622080 q12Shape35T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T4OK,q12Shape35T17OK⟩

private def q12Shape35T24 : Tree 12 := (.split 39 (.split 40 (.split 28 (.tip (.cover {0,1,2,3,4,9,11})) (.split 41 (.split 29 (.tip (.cover {1,2,3,4,6,9,10})) (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.split 43 (.tip (.cover {1,2,3,4,5,6,10})) (.tip (.cover {0,1,5,6,7,8,9}))))) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape35T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 548799512576 q12Shape35T24=true := by decide

private def q12Shape35T25 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 275012124672 273921605632 q12Shape35T25=true := by decide

private def q12Shape35T23 : Tree 12 := .split 38 q12Shape35T24 q12Shape35T25
private theorem q12Shape35T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 273921605632 q12Shape35T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 (273921605632 ||| 2^38) q12Shape35T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (134217728 ||| 2^38) 273921605632 q12Shape35T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T24OK,q12Shape35T25OK⟩

private def q12Shape35T26 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 137573171200 136482652160 q12Shape35T26=true := by decide

private def q12Shape35T22 : Tree 12 := .split 37 q12Shape35T23 q12Shape35T26
private theorem q12Shape35T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 136482652160 q12Shape35T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 (136482652160 ||| 2^37) q12Shape35T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (134217728 ||| 2^37) 136482652160 q12Shape35T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T23OK,q12Shape35T26OK⟩

private def q12Shape35T27 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 68853694464 67763175424 q12Shape35T27=true := by decide

private def q12Shape35T21 : Tree 12 := .split 36 q12Shape35T22 q12Shape35T27
private theorem q12Shape35T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 67763175424 q12Shape35T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 (67763175424 ||| 2^36) q12Shape35T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (134217728 ||| 2^36) 67763175424 q12Shape35T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T22OK,q12Shape35T27OK⟩

private def q12Shape35T28 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape35T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 17314086912 50583306240 q12Shape35T28=true := by decide

private def q12Shape35T20 : Tree 12 := .split 34 q12Shape35T21 q12Shape35T28
private theorem q12Shape35T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 50583306240 q12Shape35T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 (50583306240 ||| 2^34) q12Shape35T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (134217728 ||| 2^34) 50583306240 q12Shape35T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T21OK,q12Shape35T28OK⟩

private def q12Shape35T29 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape35T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 8724152320 41993371648 q12Shape35T29=true := by decide

private def q12Shape35T19 : Tree 12 := .split 33 q12Shape35T20 q12Shape35T29
private theorem q12Shape35T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 41993371648 q12Shape35T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 (41993371648 ||| 2^33) q12Shape35T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (134217728 ||| 2^33) 41993371648 q12Shape35T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T20OK,q12Shape35T29OK⟩

private def q12Shape35T30 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape35T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4429185024 37698404352 q12Shape35T30=true := by decide

private def q12Shape35T18 : Tree 12 := .split 32 q12Shape35T19 q12Shape35T30
private theorem q12Shape35T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 37698404352 q12Shape35T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 134217728 (37698404352 ||| 2^32) q12Shape35T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (134217728 ||| 2^32) 37698404352 q12Shape35T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T19OK,q12Shape35T30OK⟩

private def q12Shape35T2 : Tree 12 := .split 27 q12Shape35T3 q12Shape35T18
private theorem q12Shape35T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 37698404352 q12Shape35T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (37698404352 ||| 2^27) q12Shape35T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^27) 37698404352 q12Shape35T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T3OK,q12Shape35T18OK⟩

private def q12Shape35T39 : Tree 12 := (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 39 (.split 40 (.split 43 (.split 34 (.tip (.cover {0,2,3,4,7,8,10})) (.split 41 (.tip (.cover {1,2,3,4,5,6,10})) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape35T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 530411683840 q12Shape35T39=true := by decide

private def q12Shape35T40 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape35T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 10737418240 521821749248 q12Shape35T40=true := by decide

private def q12Shape35T38 : Tree 12 := .split 33 q12Shape35T39 q12Shape35T40
private theorem q12Shape35T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 521821749248 q12Shape35T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (521821749248 ||| 2^33) q12Shape35T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^33) 521821749248 q12Shape35T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T39OK,q12Shape35T40OK⟩

private def q12Shape35T41 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape35T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 6442450944 517526781952 q12Shape35T41=true := by decide

private def q12Shape35T37 : Tree 12 := .split 32 q12Shape35T38 q12Shape35T41
private theorem q12Shape35T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 517526781952 q12Shape35T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (517526781952 ||| 2^32) q12Shape35T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^32) 517526781952 q12Shape35T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T38OK,q12Shape35T41OK⟩

private def q12Shape35T42 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 277025390592 242648875008 q12Shape35T42=true := by decide

private def q12Shape35T36 : Tree 12 := .split 38 q12Shape35T37 q12Shape35T42
private theorem q12Shape35T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 242648875008 q12Shape35T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (242648875008 ||| 2^38) q12Shape35T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^38) 242648875008 q12Shape35T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T37OK,q12Shape35T42OK⟩

private def q12Shape35T43 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 139586437120 105209921536 q12Shape35T43=true := by decide

private def q12Shape35T35 : Tree 12 := .split 37 q12Shape35T36 q12Shape35T43
private theorem q12Shape35T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 105209921536 q12Shape35T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (105209921536 ||| 2^37) q12Shape35T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^37) 105209921536 q12Shape35T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T36OK,q12Shape35T43OK⟩

private def q12Shape35T44 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 70866960384 36490444800 q12Shape35T44=true := by decide

private def q12Shape35T34 : Tree 12 := .split 36 q12Shape35T35 q12Shape35T44
private theorem q12Shape35T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 36490444800 q12Shape35T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (36490444800 ||| 2^36) q12Shape35T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^36) 36490444800 q12Shape35T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T35OK,q12Shape35T44OK⟩

private def q12Shape35T45 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape35T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2684354560 35953573888 q12Shape35T45=true := by decide

private def q12Shape35T33 : Tree 12 := .split 29 q12Shape35T34 q12Shape35T45
private theorem q12Shape35T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 35953573888 q12Shape35T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (35953573888 ||| 2^29) q12Shape35T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^29) 35953573888 q12Shape35T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T34OK,q12Shape35T45OK⟩

private def q12Shape35T46 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape35T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2415919104 35685138432 q12Shape35T46=true := by decide

private def q12Shape35T32 : Tree 12 := .split 28 q12Shape35T33 q12Shape35T46
private theorem q12Shape35T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 35685138432 q12Shape35T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (35685138432 ||| 2^28) q12Shape35T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^28) 35685138432 q12Shape35T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T33OK,q12Shape35T46OK⟩

private def q12Shape35T47 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape35T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2281701376 35550920704 q12Shape35T47=true := by decide

private def q12Shape35T31 : Tree 12 := .split 27 q12Shape35T32 q12Shape35T47
private theorem q12Shape35T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 35550920704 q12Shape35T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2147483648 (35550920704 ||| 2^27) q12Shape35T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (2147483648 ||| 2^27) 35550920704 q12Shape35T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T32OK,q12Shape35T47OK⟩

private def q12Shape35T1 : Tree 12 := .split 31 q12Shape35T2 q12Shape35T31
private theorem q12Shape35T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 35550920704 q12Shape35T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (35550920704 ||| 2^31) q12Shape35T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^31) 35550920704 q12Shape35T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T2OK,q12Shape35T31OK⟩

private def q12Shape35T57 : Tree 12 := (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 36 (.split 37 (.split 43 (.split 34 (.tip (.cover {0,2,3,4,7,8,10})) (.split 38 (.tip (.cover {1,2,3,4,5,6,10})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape35T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 3898739785728 q12Shape35T57=true := by decide

private def q12Shape35T58 : Tree 12 := (.split 36 (.split 37 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape35T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 9663676416 3890149851136 q12Shape35T58=true := by decide

private def q12Shape35T56 : Tree 12 := .split 33 q12Shape35T57 q12Shape35T58
private theorem q12Shape35T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 3890149851136 q12Shape35T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (3890149851136 ||| 2^33) q12Shape35T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^33) 3890149851136 q12Shape35T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T57OK,q12Shape35T58OK⟩

private def q12Shape35T59 : Tree 12 := (.split 36 (.split 37 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape35T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 5368709120 3885854883840 q12Shape35T59=true := by decide

private def q12Shape35T55 : Tree 12 := .split 32 q12Shape35T56 q12Shape35T59
private theorem q12Shape35T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 3885854883840 q12Shape35T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (3885854883840 ||| 2^32) q12Shape35T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^32) 3885854883840 q12Shape35T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T56OK,q12Shape35T59OK⟩

private def q12Shape35T60 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2200096997376 1686831628288 q12Shape35T60=true := by decide

private def q12Shape35T54 : Tree 12 := .split 41 q12Shape35T55 q12Shape35T60
private theorem q12Shape35T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 1686831628288 q12Shape35T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (1686831628288 ||| 2^41) q12Shape35T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^41) 1686831628288 q12Shape35T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T55OK,q12Shape35T60OK⟩

private def q12Shape35T61 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1100585369600 587320000512 q12Shape35T61=true := by decide

private def q12Shape35T53 : Tree 12 := .split 40 q12Shape35T54 q12Shape35T61
private theorem q12Shape35T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 587320000512 q12Shape35T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (587320000512 ||| 2^40) q12Shape35T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^40) 587320000512 q12Shape35T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T54OK,q12Shape35T61OK⟩

private def q12Shape35T62 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 550829555712 37564186624 q12Shape35T62=true := by decide

private def q12Shape35T52 : Tree 12 := .split 39 q12Shape35T53 q12Shape35T62
private theorem q12Shape35T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 37564186624 q12Shape35T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (37564186624 ||| 2^39) q12Shape35T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^39) 37564186624 q12Shape35T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T53OK,q12Shape35T62OK⟩

private def q12Shape35T63 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1610612736 37027315712 q12Shape35T63=true := by decide

private def q12Shape35T51 : Tree 12 := .split 29 q12Shape35T52 q12Shape35T63
private theorem q12Shape35T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 37027315712 q12Shape35T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (37027315712 ||| 2^29) q12Shape35T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^29) 37027315712 q12Shape35T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T52OK,q12Shape35T63OK⟩

private def q12Shape35T64 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1342177280 36758880256 q12Shape35T64=true := by decide

private def q12Shape35T50 : Tree 12 := .split 28 q12Shape35T51 q12Shape35T64
private theorem q12Shape35T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 36758880256 q12Shape35T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (36758880256 ||| 2^28) q12Shape35T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^28) 36758880256 q12Shape35T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T51OK,q12Shape35T64OK⟩

private def q12Shape35T65 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1207959552 36624662528 q12Shape35T65=true := by decide

private def q12Shape35T49 : Tree 12 := .split 27 q12Shape35T50 q12Shape35T65
private theorem q12Shape35T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 36624662528 q12Shape35T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (36624662528 ||| 2^27) q12Shape35T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^27) 36624662528 q12Shape35T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T50OK,q12Shape35T65OK⟩

private def q12Shape35T66 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 3221225472 34477178880 q12Shape35T66=true := by decide

private def q12Shape35T48 : Tree 12 := .split 31 q12Shape35T49 q12Shape35T66
private theorem q12Shape35T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 34477178880 q12Shape35T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1073741824 (34477178880 ||| 2^31) q12Shape35T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (1073741824 ||| 2^31) 34477178880 q12Shape35T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T49OK,q12Shape35T66OK⟩

private def q12Shape35T0 : Tree 12 := .split 30 q12Shape35T1 q12Shape35T48
private theorem q12Shape35T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 34477178880 q12Shape35T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 (34477178880 ||| 2^30) q12Shape35T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (0 ||| 2^30) 34477178880 q12Shape35T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T1OK,q12Shape35T48OK⟩

def q12Shape35P0 : Tree 12 := q12Shape35T0
theorem q12Shape35P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 0 34477178880 q12Shape35P0=true := q12Shape35T0OK

end Graffiti384b.EffectiveSearch.Q12
