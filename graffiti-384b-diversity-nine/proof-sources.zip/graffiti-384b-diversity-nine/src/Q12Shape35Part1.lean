import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape35T77 : Tree 12 := (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 39 (.split 40 (.split 43 (.split 29 (.tip (.cover {0,2,3,4,7,8,10})) (.split 41 (.tip (.cover {1,2,3,4,5,6,10})) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))))
private theorem q12Shape35T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 549135056896 q12Shape35T77=true := by decide

private def q12Shape35T78 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape35T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 335544320 548866621440 q12Shape35T78=true := by decide

private def q12Shape35T76 : Tree 12 := .split 28 q12Shape35T77 q12Shape35T78
private theorem q12Shape35T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 548866621440 q12Shape35T76=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (548866621440 ||| 2^28) q12Shape35T77 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^28) 548866621440 q12Shape35T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T77OK,q12Shape35T78OK⟩

private def q12Shape35T79 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape35T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 201326592 548732403712 q12Shape35T79=true := by decide

private def q12Shape35T75 : Tree 12 := .split 27 q12Shape35T76 q12Shape35T79
private theorem q12Shape35T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 548732403712 q12Shape35T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (548732403712 ||| 2^27) q12Shape35T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^27) 548732403712 q12Shape35T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T76OK,q12Shape35T79OK⟩

private def q12Shape35T80 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 274945015808 273854496768 q12Shape35T80=true := by decide

private def q12Shape35T74 : Tree 12 := .split 38 q12Shape35T75 q12Shape35T80
private theorem q12Shape35T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 273854496768 q12Shape35T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (273854496768 ||| 2^38) q12Shape35T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^38) 273854496768 q12Shape35T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T75OK,q12Shape35T80OK⟩

private def q12Shape35T81 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 137506062336 136415543296 q12Shape35T81=true := by decide

private def q12Shape35T73 : Tree 12 := .split 37 q12Shape35T74 q12Shape35T81
private theorem q12Shape35T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 136415543296 q12Shape35T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (136415543296 ||| 2^37) q12Shape35T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^37) 136415543296 q12Shape35T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T74OK,q12Shape35T81OK⟩

private def q12Shape35T82 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 68786585600 67696066560 q12Shape35T82=true := by decide

private def q12Shape35T72 : Tree 12 := .split 36 q12Shape35T73 q12Shape35T82
private theorem q12Shape35T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 67696066560 q12Shape35T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (67696066560 ||| 2^36) q12Shape35T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^36) 67696066560 q12Shape35T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T73OK,q12Shape35T82OK⟩

private def q12Shape35T83 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape35T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 17246978048 50516197376 q12Shape35T83=true := by decide

private def q12Shape35T71 : Tree 12 := .split 34 q12Shape35T72 q12Shape35T83
private theorem q12Shape35T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 50516197376 q12Shape35T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (50516197376 ||| 2^34) q12Shape35T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^34) 50516197376 q12Shape35T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T72OK,q12Shape35T83OK⟩

private def q12Shape35T84 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape35T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 8657043456 41926262784 q12Shape35T84=true := by decide

private def q12Shape35T70 : Tree 12 := .split 33 q12Shape35T71 q12Shape35T84
private theorem q12Shape35T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 41926262784 q12Shape35T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (41926262784 ||| 2^33) q12Shape35T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^33) 41926262784 q12Shape35T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T71OK,q12Shape35T84OK⟩

private def q12Shape35T85 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape35T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4362076160 37631295488 q12Shape35T85=true := by decide

private def q12Shape35T69 : Tree 12 := .split 32 q12Shape35T70 q12Shape35T85
private theorem q12Shape35T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 37631295488 q12Shape35T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (37631295488 ||| 2^32) q12Shape35T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^32) 37631295488 q12Shape35T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T70OK,q12Shape35T85OK⟩

private def q12Shape35T86 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape35T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2214592512 35483811840 q12Shape35T86=true := by decide

private def q12Shape35T68 : Tree 12 := .split 31 q12Shape35T69 q12Shape35T86
private theorem q12Shape35T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 35483811840 q12Shape35T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (35483811840 ||| 2^31) q12Shape35T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^31) 35483811840 q12Shape35T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T69OK,q12Shape35T86OK⟩

private def q12Shape35T87 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1140850688 34410070016 q12Shape35T87=true := by decide

private def q12Shape35T67 : Tree 12 := .split 30 q12Shape35T68 q12Shape35T87
private theorem q12Shape35T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 34410070016 q12Shape35T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 (34410070016 ||| 2^30) q12Shape35T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (67108864 ||| 2^30) 34410070016 q12Shape35T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T68OK,q12Shape35T87OK⟩

def q12Shape35P1 : Tree 12 := q12Shape35T67
theorem q12Shape35P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 67108864 34410070016 q12Shape35P1=true := q12Shape35T67OK

private def q12Shape35T100 : Tree 12 := (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 36 (.split 37 (.split 43 (.split 29 (.tip (.cover {0,2,3,4,7,8,10})) (.split 38 (.tip (.cover {1,2,3,4,5,6,10})) (.tip (.cover {0,1,6,8,9,10,11})))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))))
private theorem q12Shape35T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 3916422971392 q12Shape35T100=true := by decide

private def q12Shape35T101 : Tree 12 := (.split 36 (.split 37 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape35T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 301989888 3916154535936 q12Shape35T101=true := by decide

private def q12Shape35T99 : Tree 12 := .split 28 q12Shape35T100 q12Shape35T101
private theorem q12Shape35T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 3916154535936 q12Shape35T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (3916154535936 ||| 2^28) q12Shape35T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^28) 3916154535936 q12Shape35T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T100OK,q12Shape35T101OK⟩

private def q12Shape35T102 : Tree 12 := (.split 36 (.split 37 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape35T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 167772160 3916020318208 q12Shape35T102=true := by decide

private def q12Shape35T98 : Tree 12 := .split 27 q12Shape35T99 q12Shape35T102
private theorem q12Shape35T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 3916020318208 q12Shape35T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (3916020318208 ||| 2^27) q12Shape35T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^27) 3916020318208 q12Shape35T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T99OK,q12Shape35T102OK⟩

private def q12Shape35T103 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2199056809984 1716997062656 q12Shape35T103=true := by decide

private def q12Shape35T97 : Tree 12 := .split 41 q12Shape35T98 q12Shape35T103
private theorem q12Shape35T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 1716997062656 q12Shape35T97=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (1716997062656 ||| 2^41) q12Shape35T98 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^41) 1716997062656 q12Shape35T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T98OK,q12Shape35T103OK⟩

private def q12Shape35T104 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1099545182208 617485434880 q12Shape35T104=true := by decide

private def q12Shape35T96 : Tree 12 := .split 40 q12Shape35T97 q12Shape35T104
private theorem q12Shape35T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 617485434880 q12Shape35T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (617485434880 ||| 2^40) q12Shape35T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^40) 617485434880 q12Shape35T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T97OK,q12Shape35T104OK⟩

private def q12Shape35T105 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 549789368320 67729620992 q12Shape35T105=true := by decide

private def q12Shape35T95 : Tree 12 := .split 39 q12Shape35T96 q12Shape35T105
private theorem q12Shape35T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 67729620992 q12Shape35T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (67729620992 ||| 2^39) q12Shape35T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^39) 67729620992 q12Shape35T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T96OK,q12Shape35T105OK⟩

private def q12Shape35T106 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 17213423616 50549751808 q12Shape35T106=true := by decide

private def q12Shape35T94 : Tree 12 := .split 34 q12Shape35T95 q12Shape35T106
private theorem q12Shape35T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 50549751808 q12Shape35T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (50549751808 ||| 2^34) q12Shape35T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^34) 50549751808 q12Shape35T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T95OK,q12Shape35T106OK⟩

private def q12Shape35T107 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 8623489024 41959817216 q12Shape35T107=true := by decide

private def q12Shape35T93 : Tree 12 := .split 33 q12Shape35T94 q12Shape35T107
private theorem q12Shape35T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 41959817216 q12Shape35T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (41959817216 ||| 2^33) q12Shape35T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^33) 41959817216 q12Shape35T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T94OK,q12Shape35T107OK⟩

private def q12Shape35T108 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 4328521728 37664849920 q12Shape35T108=true := by decide

private def q12Shape35T92 : Tree 12 := .split 32 q12Shape35T93 q12Shape35T108
private theorem q12Shape35T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 37664849920 q12Shape35T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (37664849920 ||| 2^32) q12Shape35T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^32) 37664849920 q12Shape35T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T93OK,q12Shape35T108OK⟩

private def q12Shape35T109 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2181038080 35517366272 q12Shape35T109=true := by decide

private def q12Shape35T91 : Tree 12 := .split 31 q12Shape35T92 q12Shape35T109
private theorem q12Shape35T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 35517366272 q12Shape35T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (35517366272 ||| 2^31) q12Shape35T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^31) 35517366272 q12Shape35T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T92OK,q12Shape35T109OK⟩

private def q12Shape35T110 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape35T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1107296256 34443624448 q12Shape35T110=true := by decide

private def q12Shape35T90 : Tree 12 := .split 30 q12Shape35T91 q12Shape35T110
private theorem q12Shape35T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 34443624448 q12Shape35T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (34443624448 ||| 2^30) q12Shape35T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^30) 34443624448 q12Shape35T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T91OK,q12Shape35T110OK⟩

private def q12Shape35T111 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape35T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 100663296 34376515584 q12Shape35T111=true := by decide

private def q12Shape35T89 : Tree 12 := .split 26 q12Shape35T90 q12Shape35T111
private theorem q12Shape35T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 34376515584 q12Shape35T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 (34376515584 ||| 2^26) q12Shape35T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (33554432 ||| 2^26) 34376515584 q12Shape35T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T90OK,q12Shape35T111OK⟩

def q12Shape35P2 : Tree 12 := q12Shape35T89
theorem q12Shape35P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 33554432 34376515584 q12Shape35P2=true := q12Shape35T89OK

private def q12Shape35T118 : Tree 12 := (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 43 (.tip (.cover {0,2,3,4,7,8,10})) (.tip (.cover {0,1,5,6,7,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape35T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 3472883712 q12Shape35T118=true := by decide

private def q12Shape35T119 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape35T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34493956096 3338665984 q12Shape35T119=true := by decide

private def q12Shape35T117 : Tree 12 := .split 27 q12Shape35T118 q12Shape35T119
private theorem q12Shape35T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 3338665984 q12Shape35T117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 (3338665984 ||| 2^27) q12Shape35T118 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (34359738368 ||| 2^27) 3338665984 q12Shape35T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T118OK,q12Shape35T119OK⟩

private def q12Shape35T120 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 36507222016 1191182336 q12Shape35T120=true := by decide

private def q12Shape35T116 : Tree 12 := .split 31 q12Shape35T117 q12Shape35T120
private theorem q12Shape35T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 1191182336 q12Shape35T116=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 (1191182336 ||| 2^31) q12Shape35T117 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (34359738368 ||| 2^31) 1191182336 q12Shape35T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T117OK,q12Shape35T120OK⟩

private def q12Shape35T121 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape35T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 35433480192 117440512 q12Shape35T121=true := by decide

private def q12Shape35T115 : Tree 12 := .split 30 q12Shape35T116 q12Shape35T121
private theorem q12Shape35T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 117440512 q12Shape35T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 (117440512 ||| 2^30) q12Shape35T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (34359738368 ||| 2^30) 117440512 q12Shape35T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T116OK,q12Shape35T121OK⟩

private def q12Shape35T122 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34426847232 50331648 q12Shape35T122=true := by decide

private def q12Shape35T114 : Tree 12 := .split 26 q12Shape35T115 q12Shape35T122
private theorem q12Shape35T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 50331648 q12Shape35T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 (50331648 ||| 2^26) q12Shape35T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (34359738368 ||| 2^26) 50331648 q12Shape35T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T115OK,q12Shape35T122OK⟩

private def q12Shape35T123 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape35T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34393292800 16777216 q12Shape35T123=true := by decide

private def q12Shape35T113 : Tree 12 := .split 25 q12Shape35T114 q12Shape35T123
private theorem q12Shape35T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 16777216 q12Shape35T113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 (16777216 ||| 2^25) q12Shape35T114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (34359738368 ||| 2^25) 16777216 q12Shape35T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T114OK,q12Shape35T123OK⟩

def q12Shape35P3 : Tree 12 := q12Shape35T113
theorem q12Shape35P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34359738368 16777216 q12Shape35P3=true := q12Shape35T113OK

private def q12Shape35T131 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {1,2,3,4,5,6,11})) (.split 43 (.tip (.cover {1,2,3,4,5,6,10})) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape35T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 106401103872 q12Shape35T131=true := by decide

private def q12Shape35T132 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 68736253952 37681627136 q12Shape35T132=true := by decide

private def q12Shape35T130 : Tree 12 := .split 36 q12Shape35T131 q12Shape35T132
private theorem q12Shape35T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 37681627136 q12Shape35T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 (37681627136 ||| 2^36) q12Shape35T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (16777216 ||| 2^36) 37681627136 q12Shape35T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T131OK,q12Shape35T132OK⟩

private def q12Shape35T133 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape35T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 2164260864 35534143488 q12Shape35T133=true := by decide

private def q12Shape35T129 : Tree 12 := .split 31 q12Shape35T130 q12Shape35T133
private theorem q12Shape35T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 35534143488 q12Shape35T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 (35534143488 ||| 2^31) q12Shape35T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (16777216 ||| 2^31) 35534143488 q12Shape35T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T130OK,q12Shape35T133OK⟩

private def q12Shape35T134 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape35T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 1090519040 34460401664 q12Shape35T134=true := by decide

private def q12Shape35T128 : Tree 12 := .split 30 q12Shape35T129 q12Shape35T134
private theorem q12Shape35T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 34460401664 q12Shape35T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 (34460401664 ||| 2^30) q12Shape35T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (16777216 ||| 2^30) 34460401664 q12Shape35T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T129OK,q12Shape35T134OK⟩

private def q12Shape35T135 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape35T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 83886080 34393292800 q12Shape35T135=true := by decide

private def q12Shape35T127 : Tree 12 := .split 26 q12Shape35T128 q12Shape35T135
private theorem q12Shape35T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 34393292800 q12Shape35T127=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 (34393292800 ||| 2^26) q12Shape35T128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (16777216 ||| 2^26) 34393292800 q12Shape35T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T128OK,q12Shape35T135OK⟩

private def q12Shape35T136 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape35T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 50331648 34359738368 q12Shape35T136=true := by decide

private def q12Shape35T126 : Tree 12 := .split 25 q12Shape35T127 q12Shape35T136
private theorem q12Shape35T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 34359738368 q12Shape35T126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 (34359738368 ||| 2^25) q12Shape35T127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (16777216 ||| 2^25) 34359738368 q12Shape35T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T127OK,q12Shape35T136OK⟩

private def q12Shape35T137 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape35T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 34376515584 0 q12Shape35T137=true := by decide

private def q12Shape35T125 : Tree 12 := .split 35 q12Shape35T126 q12Shape35T137
private theorem q12Shape35T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 0 q12Shape35T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 (0 ||| 2^35) q12Shape35T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) (16777216 ||| 2^35) 0 q12Shape35T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape35T126OK,q12Shape35T137OK⟩

def q12Shape35P4 : Tree 12 := q12Shape35T125
theorem q12Shape35P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,3⟩) 16777216 0 q12Shape35P4=true := q12Shape35T125OK

end Graffiti384b.EffectiveSearch.Q12
