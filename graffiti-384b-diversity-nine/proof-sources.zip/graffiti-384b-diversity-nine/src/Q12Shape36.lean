import Q12Shape36Part0
import Q12Shape36Part1
import Q12Shape36Part2
import Q12Shape36Part3
import Q12Shape36Part4
import Q12Shape36Part5

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape36M68 : Tree 12 := .split 4 q12Shape36P2 q12Shape36P3
private theorem q12Shape36M68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586228580360 q12Shape36M68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (28586228580360 ||| 2^4) q12Shape36P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^4) 28586228580360 q12Shape36P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36P2OK,q12Shape36P3OK⟩
private def q12Shape36M80 : Tree 12 := .split 3 q12Shape36M68 q12Shape36P4
private theorem q12Shape36M80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586228580352 q12Shape36M80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (28586228580352 ||| 2^3) q12Shape36M68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^3) 28586228580352 q12Shape36P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M68OK,q12Shape36P4OK⟩
private def q12Shape36M82 : Tree 12 := .split 44 q12Shape36M80 q12Shape36P5
private theorem q12Shape36M82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 10994042535936 q12Shape36M82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (10994042535936 ||| 2^44) q12Shape36M80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^44) 10994042535936 q12Shape36P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M80OK,q12Shape36P5OK⟩
private def q12Shape36M84 : Tree 12 := .split 43 q12Shape36M82 q12Shape36P6
private theorem q12Shape36M84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 2197949513728 q12Shape36M84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (2197949513728 ||| 2^43) q12Shape36M82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^43) 2197949513728 q12Shape36P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M82OK,q12Shape36P6OK⟩
private def q12Shape36M85 : Tree 12 := .split 42 q12Shape36P1 q12Shape36M84
private theorem q12Shape36M85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 2199023255552 2197949513728 q12Shape36M85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 2199023255552 (2197949513728 ||| 2^42) q12Shape36P1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (2199023255552 ||| 2^42) 2197949513728 q12Shape36M84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36P1OK,q12Shape36M84OK⟩
private def q12Shape36M86 : Tree 12 := .split 41 q12Shape36P0 q12Shape36M85
private theorem q12Shape36M86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 2197949513728 q12Shape36M86=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (2197949513728 ||| 2^41) q12Shape36P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^41) 2197949513728 q12Shape36M85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36P0OK,q12Shape36M85OK⟩
private def q12Shape36M154 : Tree 12 := .split 4 q12Shape36P8 q12Shape36P9
private theorem q12Shape36M154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649984 25287693697032 q12Shape36M154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649984 (25287693697032 ||| 2^4) q12Shape36P8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649984 ||| 2^4) 25287693697032 q12Shape36P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36P8OK,q12Shape36P9OK⟩
private def q12Shape36M166 : Tree 12 := .split 3 q12Shape36M154 q12Shape36P10
private theorem q12Shape36M166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649984 25287693697024 q12Shape36M166=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649984 (25287693697024 ||| 2^3) q12Shape36M154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649984 ||| 2^3) 25287693697024 q12Shape36P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M154OK,q12Shape36P10OK⟩
private def q12Shape36M168 : Tree 12 := .split 44 q12Shape36M166 q12Shape36P11
private theorem q12Shape36M168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649984 7695507652608 q12Shape36M168=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649984 (7695507652608 ||| 2^44) q12Shape36M166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649984 ||| 2^44) 7695507652608 q12Shape36P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M166OK,q12Shape36P11OK⟩
private def q12Shape36M169 : Tree 12 := .split 43 q12Shape36P7 q12Shape36M168
private theorem q12Shape36M169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 7695507652608 q12Shape36M169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 (7695507652608 ||| 2^43) q12Shape36P7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (1099511627776 ||| 2^43) 7695507652608 q12Shape36M168)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36P7OK,q12Shape36M168OK⟩
private def q12Shape36M171 : Tree 12 := .split 42 q12Shape36M169 q12Shape36P12
private theorem q12Shape36M171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 3297461141504 q12Shape36M171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 (3297461141504 ||| 2^42) q12Shape36M169 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (1099511627776 ||| 2^42) 3297461141504 q12Shape36P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M169OK,q12Shape36P12OK⟩
private def q12Shape36M173 : Tree 12 := .split 41 q12Shape36M171 q12Shape36P13
private theorem q12Shape36M173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 1098437885952 q12Shape36M173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 (1098437885952 ||| 2^41) q12Shape36M171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (1099511627776 ||| 2^41) 1098437885952 q12Shape36P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M171OK,q12Shape36P13OK⟩
private def q12Shape36M174 : Tree 12 := .split 40 q12Shape36M86 q12Shape36M173
private theorem q12Shape36M174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 1098437885952 q12Shape36M174=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (1098437885952 ||| 2^40) q12Shape36M86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^40) 1098437885952 q12Shape36M173)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M86OK,q12Shape36M173OK⟩
private def q12Shape36M234 : Tree 12 := .split 11 q12Shape36P15 q12Shape36P16
private theorem q12Shape36M234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041356488728 q12Shape36M234=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 (17041356488728 ||| 2^11) q12Shape36P15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941858304 ||| 2^11) 17041356488728 q12Shape36P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36P15OK,q12Shape36P16OK⟩
private def q12Shape36M244 : Tree 12 := .split 4 q12Shape36M234 q12Shape36P17
private theorem q12Shape36M244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041356488712 q12Shape36M244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 (17041356488712 ||| 2^4) q12Shape36M234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941858304 ||| 2^4) 17041356488712 q12Shape36P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M234OK,q12Shape36P17OK⟩
private def q12Shape36M256 : Tree 12 := .split 3 q12Shape36M244 q12Shape36P18
private theorem q12Shape36M256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041356488704 q12Shape36M256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 (17041356488704 ||| 2^3) q12Shape36M244 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941858304 ||| 2^3) 17041356488704 q12Shape36P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M244OK,q12Shape36P18OK⟩
private def q12Shape36M257 : Tree 12 := .split 44 q12Shape36P14 q12Shape36M256
private theorem q12Shape36M257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 17041356488704 q12Shape36M257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 (17041356488704 ||| 2^44) q12Shape36P14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (549755813888 ||| 2^44) 17041356488704 q12Shape36M256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36P14OK,q12Shape36M256OK⟩
private def q12Shape36M259 : Tree 12 := .split 43 q12Shape36M257 q12Shape36P19
private theorem q12Shape36M259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 8245263466496 q12Shape36M259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 (8245263466496 ||| 2^43) q12Shape36M257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (549755813888 ||| 2^43) 8245263466496 q12Shape36P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M257OK,q12Shape36P19OK⟩
private def q12Shape36M261 : Tree 12 := .split 42 q12Shape36M259 q12Shape36P20
private theorem q12Shape36M261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 3847216955392 q12Shape36M261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 (3847216955392 ||| 2^42) q12Shape36M259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (549755813888 ||| 2^42) 3847216955392 q12Shape36P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M259OK,q12Shape36P20OK⟩
private def q12Shape36M263 : Tree 12 := .split 41 q12Shape36M261 q12Shape36P21
private theorem q12Shape36M263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 1648193699840 q12Shape36M263=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 (1648193699840 ||| 2^41) q12Shape36M261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (549755813888 ||| 2^41) 1648193699840 q12Shape36P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M261OK,q12Shape36P21OK⟩
private def q12Shape36M265 : Tree 12 := .split 40 q12Shape36M263 q12Shape36P22
private theorem q12Shape36M265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 548682072064 q12Shape36M265=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 (548682072064 ||| 2^40) q12Shape36M263 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (549755813888 ||| 2^40) 548682072064 q12Shape36P22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M263OK,q12Shape36P22OK⟩
private def q12Shape36M266 : Tree 12 := .split 39 q12Shape36M174 q12Shape36M265
private theorem q12Shape36M266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 548682072064 q12Shape36M266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (548682072064 ||| 2^39) q12Shape36M174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^39) 548682072064 q12Shape36M265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M174OK,q12Shape36M265OK⟩
private def q12Shape36M268 : Tree 12 := .split 38 q12Shape36M266 q12Shape36P23
private theorem q12Shape36M268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 273804165120 q12Shape36M268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (273804165120 ||| 2^38) q12Shape36M266 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^38) 273804165120 q12Shape36P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M266OK,q12Shape36P23OK⟩
private def q12Shape36M270 : Tree 12 := .split 37 q12Shape36M268 q12Shape36P24
private theorem q12Shape36M270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 136365211648 q12Shape36M270=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (136365211648 ||| 2^37) q12Shape36M268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^37) 136365211648 q12Shape36P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M268OK,q12Shape36P24OK⟩
private def q12Shape36M272 : Tree 12 := .split 36 q12Shape36M270 q12Shape36P25
private theorem q12Shape36M272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 67645734912 q12Shape36M272=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (67645734912 ||| 2^36) q12Shape36M270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^36) 67645734912 q12Shape36P25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M270OK,q12Shape36P25OK⟩
private def q12Shape36M274 : Tree 12 := .split 35 q12Shape36M272 q12Shape36P26
private theorem q12Shape36M274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 33285996544 q12Shape36M274=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (33285996544 ||| 2^35) q12Shape36M272 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^35) 33285996544 q12Shape36P26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M272OK,q12Shape36P26OK⟩
private def q12Shape36M276 : Tree 12 := .split 34 q12Shape36M274 q12Shape36P27
private theorem q12Shape36M276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 16106127360 q12Shape36M276=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (16106127360 ||| 2^34) q12Shape36M274 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^34) 16106127360 q12Shape36P27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M274OK,q12Shape36P27OK⟩
private def q12Shape36M278 : Tree 12 := .split 33 q12Shape36M276 q12Shape36P28
private theorem q12Shape36M278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 7516192768 q12Shape36M278=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (7516192768 ||| 2^33) q12Shape36M276 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^33) 7516192768 q12Shape36P28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M276OK,q12Shape36P28OK⟩
private def q12Shape36M280 : Tree 12 := .split 32 q12Shape36M278 q12Shape36P29
private theorem q12Shape36M280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 3221225472 q12Shape36M280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (3221225472 ||| 2^32) q12Shape36M278 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^32) 3221225472 q12Shape36P29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M278OK,q12Shape36P29OK⟩
private def q12Shape36M282 : Tree 12 := .split 31 q12Shape36M280 q12Shape36P30
private theorem q12Shape36M282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 1073741824 q12Shape36M282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (1073741824 ||| 2^31) q12Shape36M280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^31) 1073741824 q12Shape36P30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M280OK,q12Shape36P30OK⟩
private def q12Shape36M284 : Tree 12 := .split 30 q12Shape36M282 q12Shape36P31
private theorem q12Shape36M284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 0 q12Shape36M284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 (0 ||| 2^30) q12Shape36M282 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (0 ||| 2^30) 0 q12Shape36P31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36M282OK,q12Shape36P31OK⟩

theorem q12Shape36_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 36) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 36) b) (adj 12 (forms 36) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) adj_mono b H q12Shape36M284 q12Shape36M284OK

#print axioms q12Shape36_cover

end Graffiti384b.EffectiveSearch.Q12
