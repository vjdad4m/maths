import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape36T0 : Tree 12 := (.split 42 (.tip (.cover {2,3,4,5,6,7,11})) (.split 43 (.tip (.cover {2,3,4,5,6,7,10})) (.tip (.cover {0,1,6,7,8,10,11}))))
private theorem q12Shape36T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 4396972769280 q12Shape36T0=true := by decide

def q12Shape36P0 : Tree 12 := q12Shape36T0
theorem q12Shape36P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 0 4396972769280 q12Shape36P0=true := q12Shape36T0OK

private def q12Shape36T1 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,11}))
private theorem q12Shape36T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 2199023255552 6595996024832 q12Shape36T1=true := by decide

def q12Shape36P1 : Tree 12 := q12Shape36T1
theorem q12Shape36P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 2199023255552 6595996024832 q12Shape36P1=true := q12Shape36T1OK

private def q12Shape36T6 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586229372952 q12Shape36T6=true := by decide

private def q12Shape36T8 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape36T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070290944 28586245625880 q12Shape36T8=true := by decide

private def q12Shape36T11 : Tree 12 := (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.split 8 (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,2,3,5,7,9,11}))) (.tip (.cover {0,1,2,6,7,8,9})))))
private theorem q12Shape36T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597087068160 28586262403128 q12Shape36T11=true := by decide

private def q12Shape36T12 : Tree 12 := (.split 6 (.split 7 (.split 8 (.tip (.cover {0,1,3,4,5,8,9})) (.split 13 (.split 14 (.tip (.cover {0,1,4,5,8,10,11})) (.tip (.cover {0,2,3,5,7,8,10}))) (.tip (.cover {0,1,3,4,5,9,11})))) (.tip (.cover {0,1,2,6,7,9,11}))) (.tip (.cover {0,1,2,6,7,10,11})))
private theorem q12Shape36T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597087068192 28586262403096 q12Shape36T12=true := by decide

private def q12Shape36T10 : Tree 12 := .split 5 q12Shape36T11 q12Shape36T12
private theorem q12Shape36T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597087068160 28586262403096 q12Shape36T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597087068160 (28586262403096 ||| 2^5) q12Shape36T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597087068160 ||| 2^5) 28586262403096 q12Shape36T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T11OK,q12Shape36T12OK⟩

private def q12Shape36T13 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597120622592 28586228848664 q12Shape36T13=true := by decide

private def q12Shape36T9 : Tree 12 := .split 25 q12Shape36T10 q12Shape36T13
private theorem q12Shape36T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597087068160 28586228848664 q12Shape36T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597087068160 (28586228848664 ||| 2^25) q12Shape36T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597087068160 ||| 2^25) 28586228848664 q12Shape36T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T10OK,q12Shape36T13OK⟩

private def q12Shape36T7 : Tree 12 := .split 24 q12Shape36T8 q12Shape36T9
private theorem q12Shape36T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070290944 28586228848664 q12Shape36T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070290944 (28586228848664 ||| 2^24) q12Shape36T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070290944 ||| 2^24) 28586228848664 q12Shape36T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T8OK,q12Shape36T9OK⟩

private def q12Shape36T5 : Tree 12 := .split 19 q12Shape36T6 q12Shape36T7
private theorem q12Shape36T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586228848664 q12Shape36T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (28586228848664 ||| 2^19) q12Shape36T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^19) 28586228848664 q12Shape36T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T6OK,q12Shape36T7OK⟩

private def q12Shape36T17 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape36T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028800 28586279442456 q12Shape36T17=true := by decide

private def q12Shape36T19 : Tree 12 := (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.split 8 (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,2,3,4,7,9,11}))) (.tip (.cover {0,1,2,6,7,8,9})))))
private theorem q12Shape36T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103583232 28586245888056 q12Shape36T19=true := by decide

private def q12Shape36T20 : Tree 12 := (.split 6 (.split 7 (.split 8 (.tip (.cover {0,1,3,4,5,8,9})) (.split 13 (.split 14 (.tip (.cover {0,1,4,5,8,10,11})) (.tip (.cover {0,2,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,5,9,11})))) (.tip (.cover {0,1,2,6,7,9,11}))) (.tip (.cover {0,1,2,6,7,10,11})))
private theorem q12Shape36T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103583264 28586245888024 q12Shape36T20=true := by decide

private def q12Shape36T18 : Tree 12 := .split 5 q12Shape36T19 q12Shape36T20
private theorem q12Shape36T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103583232 28586245888024 q12Shape36T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103583232 (28586245888024 ||| 2^5) q12Shape36T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597103583232 ||| 2^5) 28586245888024 q12Shape36T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T19OK,q12Shape36T20OK⟩

private def q12Shape36T16 : Tree 12 := .split 25 q12Shape36T17 q12Shape36T18
private theorem q12Shape36T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028800 28586245888024 q12Shape36T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028800 (28586245888024 ||| 2^25) q12Shape36T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070028800 ||| 2^25) 28586245888024 q12Shape36T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T17OK,q12Shape36T18OK⟩

private def q12Shape36T21 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086806016 28586229110808 q12Shape36T21=true := by decide

private def q12Shape36T15 : Tree 12 := .split 24 q12Shape36T16 q12Shape36T21
private theorem q12Shape36T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028800 28586229110808 q12Shape36T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028800 (28586229110808 ||| 2^24) q12Shape36T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070028800 ||| 2^24) 28586229110808 q12Shape36T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T16OK,q12Shape36T21OK⟩

private def q12Shape36T22 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape36T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070553088 28586228586520 q12Shape36T22=true := by decide

private def q12Shape36T14 : Tree 12 := .split 19 q12Shape36T15 q12Shape36T22
private theorem q12Shape36T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028800 28586228586520 q12Shape36T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028800 (28586228586520 ||| 2^19) q12Shape36T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070028800 ||| 2^19) 28586228586520 q12Shape36T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T15OK,q12Shape36T22OK⟩

private def q12Shape36T4 : Tree 12 := .split 18 q12Shape36T5 q12Shape36T14
private theorem q12Shape36T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586228586520 q12Shape36T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (28586228586520 ||| 2^18) q12Shape36T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^18) 28586228586520 q12Shape36T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T5OK,q12Shape36T14OK⟩

private def q12Shape36T26 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape36T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770752 28586246146072 q12Shape36T26=true := by decide

private def q12Shape36T29 : Tree 12 := (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.split 8 (.split 13 (.tip (.cover {0,2,4,5,7,9,11})) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,2,6,7,8,9})))))
private theorem q12Shape36T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086547968 28586262923320 q12Shape36T29=true := by decide

private def q12Shape36T30 : Tree 12 := (.split 6 (.split 7 (.split 8 (.tip (.cover {0,1,3,4,5,8,9})) (.split 13 (.split 14 (.tip (.cover {0,2,4,5,7,8,10})) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11})))) (.tip (.cover {0,1,2,6,7,9,11}))) (.tip (.cover {0,1,2,6,7,10,11})))
private theorem q12Shape36T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086548000 28586262923288 q12Shape36T30=true := by decide

private def q12Shape36T28 : Tree 12 := .split 5 q12Shape36T29 q12Shape36T30
private theorem q12Shape36T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086547968 28586262923288 q12Shape36T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086547968 (28586262923288 ||| 2^5) q12Shape36T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597086547968 ||| 2^5) 28586262923288 q12Shape36T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T29OK,q12Shape36T30OK⟩

private def q12Shape36T31 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597120102400 28586229368856 q12Shape36T31=true := by decide

private def q12Shape36T27 : Tree 12 := .split 25 q12Shape36T28 q12Shape36T31
private theorem q12Shape36T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086547968 28586229368856 q12Shape36T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086547968 (28586229368856 ||| 2^25) q12Shape36T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597086547968 ||| 2^25) 28586229368856 q12Shape36T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T28OK,q12Shape36T31OK⟩

private def q12Shape36T25 : Tree 12 := .split 24 q12Shape36T26 q12Shape36T27
private theorem q12Shape36T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770752 28586229368856 q12Shape36T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770752 (28586229368856 ||| 2^24) q12Shape36T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069770752 ||| 2^24) 28586229368856 q12Shape36T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T26OK,q12Shape36T27OK⟩

private def q12Shape36T32 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,9}))
private theorem q12Shape36T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070295040 28586228844568 q12Shape36T32=true := by decide

private def q12Shape36T24 : Tree 12 := .split 19 q12Shape36T25 q12Shape36T32
private theorem q12Shape36T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770752 28586228844568 q12Shape36T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770752 (28586228844568 ||| 2^19) q12Shape36T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069770752 ||| 2^19) 28586228844568 q12Shape36T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T25OK,q12Shape36T32OK⟩

private def q12Shape36T37 : Tree 12 := (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.split 8 (.split 13 (.tip (.cover {0,2,4,5,7,9,11})) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,2,6,7,8,9})))))
private theorem q12Shape36T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 28586279438392 q12Shape36T37=true := by decide

private def q12Shape36T38 : Tree 12 := (.split 6 (.split 7 (.split 8 (.tip (.cover {0,1,3,4,5,8,9})) (.split 13 (.split 14 (.tip (.cover {0,2,4,5,7,8,10})) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11})))) (.tip (.cover {0,1,2,6,7,9,11}))) (.tip (.cover {0,1,2,6,7,10,11})))
private theorem q12Shape36T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032928 28586279438360 q12Shape36T38=true := by decide

private def q12Shape36T36 : Tree 12 := .split 5 q12Shape36T37 q12Shape36T38
private theorem q12Shape36T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 28586279438360 q12Shape36T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 (28586279438360 ||| 2^5) q12Shape36T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070032896 ||| 2^5) 28586279438360 q12Shape36T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T37OK,q12Shape36T38OK⟩

private def q12Shape36T39 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,9}))
private theorem q12Shape36T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103587328 28586245883928 q12Shape36T39=true := by decide

private def q12Shape36T35 : Tree 12 := .split 25 q12Shape36T36 q12Shape36T39
private theorem q12Shape36T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 28586245883928 q12Shape36T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 (28586245883928 ||| 2^25) q12Shape36T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070032896 ||| 2^25) 28586245883928 q12Shape36T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T36OK,q12Shape36T39OK⟩

private def q12Shape36T40 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape36T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086810112 28586229106712 q12Shape36T40=true := by decide

private def q12Shape36T34 : Tree 12 := .split 24 q12Shape36T35 q12Shape36T40
private theorem q12Shape36T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 28586229106712 q12Shape36T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 (28586229106712 ||| 2^24) q12Shape36T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070032896 ||| 2^24) 28586229106712 q12Shape36T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T35OK,q12Shape36T40OK⟩

private def q12Shape36T41 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape36T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070557184 28586228582424 q12Shape36T41=true := by decide

private def q12Shape36T33 : Tree 12 := .split 19 q12Shape36T34 q12Shape36T41
private theorem q12Shape36T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 28586228582424 q12Shape36T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070032896 (28586228582424 ||| 2^19) q12Shape36T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070032896 ||| 2^19) 28586228582424 q12Shape36T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T34OK,q12Shape36T41OK⟩

private def q12Shape36T23 : Tree 12 := .split 18 q12Shape36T24 q12Shape36T33
private theorem q12Shape36T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770752 28586228582424 q12Shape36T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770752 (28586228582424 ||| 2^18) q12Shape36T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069770752 ||| 2^18) 28586228582424 q12Shape36T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T24OK,q12Shape36T33OK⟩

private def q12Shape36T3 : Tree 12 := .split 12 q12Shape36T4 q12Shape36T23
private theorem q12Shape36T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586228582424 q12Shape36T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (28586228582424 ||| 2^12) q12Shape36T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^12) 28586228582424 q12Shape36T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T4OK,q12Shape36T23OK⟩

private def q12Shape36T47 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape36T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 28586279702552 q12Shape36T47=true := by decide

private def q12Shape36T49 : Tree 12 := (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.split 8 (.split 13 (.tip (.cover {1,2,4,5,6,9,11})) (.tip (.cover {0,1,3,7,9,10,11}))) (.tip (.cover {0,1,2,6,7,8,9})))))
private theorem q12Shape36T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103323136 28586246148152 q12Shape36T49=true := by decide

private def q12Shape36T50 : Tree 12 := (.split 6 (.split 7 (.split 8 (.tip (.cover {0,1,3,4,5,8,9})) (.split 13 (.split 14 (.tip (.cover {1,2,4,5,6,8,10})) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))) (.tip (.cover {0,1,2,6,7,9,11}))) (.tip (.cover {0,1,2,6,7,10,11})))
private theorem q12Shape36T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103323168 28586246148120 q12Shape36T50=true := by decide

private def q12Shape36T48 : Tree 12 := .split 5 q12Shape36T49 q12Shape36T50
private theorem q12Shape36T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103323136 28586246148120 q12Shape36T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103323136 (28586246148120 ||| 2^5) q12Shape36T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597103323136 ||| 2^5) 28586246148120 q12Shape36T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T49OK,q12Shape36T50OK⟩

private def q12Shape36T46 : Tree 12 := .split 25 q12Shape36T47 q12Shape36T48
private theorem q12Shape36T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 28586246148120 q12Shape36T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 (28586246148120 ||| 2^25) q12Shape36T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069768704 ||| 2^25) 28586246148120 q12Shape36T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T47OK,q12Shape36T48OK⟩

private def q12Shape36T51 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597086545920 28586229370904 q12Shape36T51=true := by decide

private def q12Shape36T45 : Tree 12 := .split 24 q12Shape36T46 q12Shape36T51
private theorem q12Shape36T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 28586229370904 q12Shape36T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 (28586229370904 ||| 2^24) q12Shape36T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069768704 ||| 2^24) 28586229370904 q12Shape36T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T46OK,q12Shape36T51OK⟩

private def q12Shape36T55 : Tree 12 := (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.split 8 (.split 13 (.tip (.cover {1,2,4,5,6,9,11})) (.tip (.cover {0,1,3,7,9,10,11}))) (.tip (.cover {0,1,2,6,7,8,9})))))
private theorem q12Shape36T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070292992 28586279178296 q12Shape36T55=true := by decide

private def q12Shape36T56 : Tree 12 := (.split 6 (.split 7 (.split 8 (.tip (.cover {0,1,3,4,5,8,9})) (.split 13 (.split 14 (.tip (.cover {1,2,4,5,6,8,10})) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))) (.tip (.cover {0,1,2,6,7,9,11}))) (.tip (.cover {0,1,2,6,7,10,11})))
private theorem q12Shape36T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070293024 28586279178264 q12Shape36T56=true := by decide

private def q12Shape36T54 : Tree 12 := .split 5 q12Shape36T55 q12Shape36T56
private theorem q12Shape36T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070292992 28586279178264 q12Shape36T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070292992 (28586279178264 ||| 2^5) q12Shape36T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070292992 ||| 2^5) 28586279178264 q12Shape36T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T55OK,q12Shape36T56OK⟩

private def q12Shape36T57 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,9}))
private theorem q12Shape36T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597103847424 28586245623832 q12Shape36T57=true := by decide

private def q12Shape36T53 : Tree 12 := .split 25 q12Shape36T54 q12Shape36T57
private theorem q12Shape36T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070292992 28586245623832 q12Shape36T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070292992 (28586245623832 ||| 2^25) q12Shape36T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070292992 ||| 2^25) 28586245623832 q12Shape36T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T54OK,q12Shape36T57OK⟩

private def q12Shape36T58 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape36T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597087070208 28586228846616 q12Shape36T58=true := by decide

private def q12Shape36T52 : Tree 12 := .split 24 q12Shape36T53 q12Shape36T58
private theorem q12Shape36T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070292992 28586228846616 q12Shape36T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070292992 (28586228846616 ||| 2^24) q12Shape36T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597070292992 ||| 2^24) 28586228846616 q12Shape36T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T53OK,q12Shape36T58OK⟩

private def q12Shape36T44 : Tree 12 := .split 19 q12Shape36T45 q12Shape36T52
private theorem q12Shape36T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 28586228846616 q12Shape36T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 (28586228846616 ||| 2^19) q12Shape36T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069768704 ||| 2^19) 28586228846616 q12Shape36T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T45OK,q12Shape36T52OK⟩

private def q12Shape36T59 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape36T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070030848 28586228584472 q12Shape36T59=true := by decide

private def q12Shape36T43 : Tree 12 := .split 18 q12Shape36T44 q12Shape36T59
private theorem q12Shape36T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 28586228584472 q12Shape36T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 (28586228584472 ||| 2^18) q12Shape36T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069768704 ||| 2^18) 28586228584472 q12Shape36T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T44OK,q12Shape36T59OK⟩

private def q12Shape36T60 : Tree 12 := (.tip (.cover {0,1,3,8,9,10,11}))
private theorem q12Shape36T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069772800 28586228580376 q12Shape36T60=true := by decide

private def q12Shape36T42 : Tree 12 := .split 12 q12Shape36T43 q12Shape36T60
private theorem q12Shape36T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 28586228580376 q12Shape36T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768704 (28586228580376 ||| 2^12) q12Shape36T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069768704 ||| 2^12) 28586228580376 q12Shape36T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T43OK,q12Shape36T60OK⟩

private def q12Shape36T2 : Tree 12 := .split 11 q12Shape36T3 q12Shape36T42
private theorem q12Shape36T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586228580376 q12Shape36T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 (28586228580376 ||| 2^11) q12Shape36T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766656 ||| 2^11) 28586228580376 q12Shape36T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T3OK,q12Shape36T42OK⟩

def q12Shape36P2 : Tree 12 := q12Shape36T2
theorem q12Shape36P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766656 28586228580376 q12Shape36P2=true := q12Shape36T2OK

end Graffiti384b.EffectiveSearch.Q12
