import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape36T64 : Tree 12 := (.split 19 (.split 24 (.tip (.cover {0,1,7,8,9,10,11})) (.split 25 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape36T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 28586228848648 q12Shape36T64=true := by decide

private def q12Shape36T65 : Tree 12 := (.split 19 (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape36T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028816 28586228586504 q12Shape36T65=true := by decide

private def q12Shape36T63 : Tree 12 := .split 18 q12Shape36T64 q12Shape36T65
private theorem q12Shape36T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 28586228586504 q12Shape36T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 (28586228586504 ||| 2^18) q12Shape36T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766672 ||| 2^18) 28586228586504 q12Shape36T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T64OK,q12Shape36T65OK⟩

private def q12Shape36T66 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,9}))
private theorem q12Shape36T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770768 28586228582408 q12Shape36T66=true := by decide

private def q12Shape36T62 : Tree 12 := .split 12 q12Shape36T63 q12Shape36T66
private theorem q12Shape36T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 28586228582408 q12Shape36T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 (28586228582408 ||| 2^12) q12Shape36T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766672 ||| 2^12) 28586228582408 q12Shape36T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T63OK,q12Shape36T66OK⟩

private def q12Shape36T67 : Tree 12 := (.split 12 (.split 18 (.split 19 (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape36T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768720 28586228580360 q12Shape36T67=true := by decide

private def q12Shape36T61 : Tree 12 := .split 11 q12Shape36T62 q12Shape36T67
private theorem q12Shape36T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 28586228580360 q12Shape36T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 (28586228580360 ||| 2^11) q12Shape36T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766672 ||| 2^11) 28586228580360 q12Shape36T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T62OK,q12Shape36T67OK⟩

def q12Shape36P3 : Tree 12 := q12Shape36T61
theorem q12Shape36P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766672 28586228580360 q12Shape36P3=true := q12Shape36T61OK

private def q12Shape36T74 : Tree 12 := (.split 24 (.split 25 (.tip (.cover {0,1,6,8,9,10,11})) (.split 5 (.split 6 (.tip (.cover {1,3,4,5,6,10,11})) (.tip (.cover {0,1,2,7,8,10,11}))) (.tip (.cover {0,1,2,7,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape36T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 28586229372944 q12Shape36T74=true := by decide

private def q12Shape36T75 : Tree 12 := (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,6,10,11})) (.tip (.cover {0,1,2,7,8,10,11}))) (.tip (.cover {0,1,2,7,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape36T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070290952 28586228848656 q12Shape36T75=true := by decide

private def q12Shape36T73 : Tree 12 := .split 19 q12Shape36T74 q12Shape36T75
private theorem q12Shape36T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 28586228848656 q12Shape36T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 (28586228848656 ||| 2^19) q12Shape36T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766664 ||| 2^19) 28586228848656 q12Shape36T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T74OK,q12Shape36T75OK⟩

private def q12Shape36T76 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape36T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597070028808 28586228586512 q12Shape36T76=true := by decide

private def q12Shape36T72 : Tree 12 := .split 18 q12Shape36T73 q12Shape36T76
private theorem q12Shape36T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 28586228586512 q12Shape36T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 (28586228586512 ||| 2^18) q12Shape36T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766664 ||| 2^18) 28586228586512 q12Shape36T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T73OK,q12Shape36T76OK⟩

private def q12Shape36T77 : Tree 12 := (.split 18 (.split 19 (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,6,10,11})) (.tip (.cover {0,1,2,7,8,10,11}))) (.tip (.cover {0,1,2,7,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape36T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069770760 28586228582416 q12Shape36T77=true := by decide

private def q12Shape36T71 : Tree 12 := .split 12 q12Shape36T72 q12Shape36T77
private theorem q12Shape36T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 28586228582416 q12Shape36T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 (28586228582416 ||| 2^12) q12Shape36T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766664 ||| 2^12) 28586228582416 q12Shape36T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T72OK,q12Shape36T77OK⟩

private def q12Shape36T78 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape36T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069768712 28586228580368 q12Shape36T78=true := by decide

private def q12Shape36T70 : Tree 12 := .split 11 q12Shape36T71 q12Shape36T78
private theorem q12Shape36T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 28586228580368 q12Shape36T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 (28586228580368 ||| 2^11) q12Shape36T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766664 ||| 2^11) 28586228580368 q12Shape36T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T71OK,q12Shape36T78OK⟩

private def q12Shape36T79 : Tree 12 := (.tip (.cover {0,1,2,8,9,10,11}))
private theorem q12Shape36T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766680 28586228580352 q12Shape36T79=true := by decide

private def q12Shape36T69 : Tree 12 := .split 4 q12Shape36T70 q12Shape36T79
private theorem q12Shape36T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 28586228580352 q12Shape36T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 (28586228580352 ||| 2^4) q12Shape36T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (6597069766664 ||| 2^4) 28586228580352 q12Shape36T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T70OK,q12Shape36T79OK⟩

def q12Shape36P4 : Tree 12 := q12Shape36T69
theorem q12Shape36P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 6597069766664 28586228580352 q12Shape36P4=true := q12Shape36T69OK

private def q12Shape36T81 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,10}))
private theorem q12Shape36T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 24189255811072 10994042535936 q12Shape36T81=true := by decide

def q12Shape36P5 : Tree 12 := q12Shape36T81
theorem q12Shape36P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 24189255811072 10994042535936 q12Shape36P5=true := q12Shape36T81OK

private def q12Shape36T83 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,10}))
private theorem q12Shape36T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 15393162788864 2197949513728 q12Shape36T83=true := by decide

def q12Shape36P6 : Tree 12 := q12Shape36T83
theorem q12Shape36P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 15393162788864 2197949513728 q12Shape36P6=true := q12Shape36T83OK

private def q12Shape36T87 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,10}))
private theorem q12Shape36T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 16491600674816 q12Shape36T87=true := by decide

def q12Shape36P7 : Tree 12 := q12Shape36T87
theorem q12Shape36P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 1099511627776 16491600674816 q12Shape36P7=true := q12Shape36T87OK

end Graffiti384b.EffectiveSearch.Q12
