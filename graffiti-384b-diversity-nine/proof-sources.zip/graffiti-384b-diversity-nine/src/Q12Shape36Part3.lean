import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape36T150 : Tree 12 := (.split 19 (.split 24 (.tip (.cover {0,1,7,8,9,10,11})) (.split 25 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {2,3,4,5,6,8,9})))
private theorem q12Shape36T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 25287693965320 q12Shape36T150=true := by decide

private def q12Shape36T151 : Tree 12 := (.split 19 (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape36T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604912144 25287693703176 q12Shape36T151=true := by decide

private def q12Shape36T149 : Tree 12 := .split 18 q12Shape36T150 q12Shape36T151
private theorem q12Shape36T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 25287693703176 q12Shape36T149=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 (25287693703176 ||| 2^18) q12Shape36T150 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604650000 ||| 2^18) 25287693703176 q12Shape36T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T150OK,q12Shape36T151OK⟩

private def q12Shape36T152 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,9}))
private theorem q12Shape36T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604654096 25287693699080 q12Shape36T152=true := by decide

private def q12Shape36T148 : Tree 12 := .split 12 q12Shape36T149 q12Shape36T152
private theorem q12Shape36T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 25287693699080 q12Shape36T148=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 (25287693699080 ||| 2^12) q12Shape36T149 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604650000 ||| 2^12) 25287693699080 q12Shape36T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T149OK,q12Shape36T152OK⟩

private def q12Shape36T153 : Tree 12 := (.split 12 (.split 18 (.split 19 (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {0,3,4,5,7,10,11})) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape36T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604652048 25287693697032 q12Shape36T153=true := by decide

private def q12Shape36T147 : Tree 12 := .split 11 q12Shape36T148 q12Shape36T153
private theorem q12Shape36T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 25287693697032 q12Shape36T147=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 (25287693697032 ||| 2^11) q12Shape36T148 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604650000 ||| 2^11) 25287693697032 q12Shape36T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T148OK,q12Shape36T153OK⟩

def q12Shape36P9 : Tree 12 := q12Shape36T147
theorem q12Shape36P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650000 25287693697032 q12Shape36P9=true := q12Shape36T147OK

private def q12Shape36T160 : Tree 12 := (.split 24 (.split 25 (.tip (.cover {0,1,6,8,9,10,11})) (.split 5 (.split 6 (.tip (.cover {1,3,4,5,6,10,11})) (.tip (.cover {0,1,2,7,8,10,11}))) (.tip (.cover {0,1,2,7,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape36T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 25287694489616 q12Shape36T160=true := by decide

private def q12Shape36T161 : Tree 12 := (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,6,10,11})) (.tip (.cover {0,1,2,7,8,10,11}))) (.tip (.cover {0,1,2,7,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape36T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895605174280 25287693965328 q12Shape36T161=true := by decide

private def q12Shape36T159 : Tree 12 := .split 19 q12Shape36T160 q12Shape36T161
private theorem q12Shape36T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 25287693965328 q12Shape36T159=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 (25287693965328 ||| 2^19) q12Shape36T160 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649992 ||| 2^19) 25287693965328 q12Shape36T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T160OK,q12Shape36T161OK⟩

private def q12Shape36T162 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape36T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604912136 25287693703184 q12Shape36T162=true := by decide

private def q12Shape36T158 : Tree 12 := .split 18 q12Shape36T159 q12Shape36T162
private theorem q12Shape36T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 25287693703184 q12Shape36T158=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 (25287693703184 ||| 2^18) q12Shape36T159 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649992 ||| 2^18) 25287693703184 q12Shape36T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T159OK,q12Shape36T162OK⟩

private def q12Shape36T163 : Tree 12 := (.split 18 (.split 19 (.split 24 (.split 25 (.split 5 (.split 6 (.tip (.cover {1,3,4,5,6,10,11})) (.tip (.cover {0,1,2,7,8,10,11}))) (.tip (.cover {0,1,2,7,9,10,11}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9}))) (.tip (.cover {2,3,4,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,8,9})))
private theorem q12Shape36T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604654088 25287693699088 q12Shape36T163=true := by decide

private def q12Shape36T157 : Tree 12 := .split 12 q12Shape36T158 q12Shape36T163
private theorem q12Shape36T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 25287693699088 q12Shape36T157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 (25287693699088 ||| 2^12) q12Shape36T158 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649992 ||| 2^12) 25287693699088 q12Shape36T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T158OK,q12Shape36T163OK⟩

private def q12Shape36T164 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,9}))
private theorem q12Shape36T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604652040 25287693697040 q12Shape36T164=true := by decide

private def q12Shape36T156 : Tree 12 := .split 11 q12Shape36T157 q12Shape36T164
private theorem q12Shape36T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 25287693697040 q12Shape36T156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 (25287693697040 ||| 2^11) q12Shape36T157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649992 ||| 2^11) 25287693697040 q12Shape36T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T157OK,q12Shape36T164OK⟩

private def q12Shape36T165 : Tree 12 := (.tip (.cover {0,1,2,8,9,10,11}))
private theorem q12Shape36T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604650008 25287693697024 q12Shape36T165=true := by decide

private def q12Shape36T155 : Tree 12 := .split 4 q12Shape36T156 q12Shape36T165
private theorem q12Shape36T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 25287693697024 q12Shape36T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 (25287693697024 ||| 2^4) q12Shape36T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (9895604649992 ||| 2^4) 25287693697024 q12Shape36T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T156OK,q12Shape36T165OK⟩

def q12Shape36P10 : Tree 12 := q12Shape36T155
theorem q12Shape36P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 9895604649992 25287693697024 q12Shape36P10=true := q12Shape36T155OK

private def q12Shape36T167 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,10}))
private theorem q12Shape36T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 27487790694400 7695507652608 q12Shape36T167=true := by decide

def q12Shape36P11 : Tree 12 := q12Shape36T167
theorem q12Shape36P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 27487790694400 7695507652608 q12Shape36P11=true := q12Shape36T167OK

private def q12Shape36T170 : Tree 12 := (.tip (.cover {0,1,6,7,8,9,11}))
private theorem q12Shape36T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 5497558138880 3297461141504 q12Shape36T170=true := by decide

def q12Shape36P12 : Tree 12 := q12Shape36T170
theorem q12Shape36P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 5497558138880 3297461141504 q12Shape36P12=true := q12Shape36T170OK

private def q12Shape36T172 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape36T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 3298534883328 1098437885952 q12Shape36T172=true := by decide

def q12Shape36P13 : Tree 12 := q12Shape36T172
theorem q12Shape36P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 3298534883328 1098437885952 q12Shape36P13=true := q12Shape36T172OK

private def q12Shape36T175 : Tree 12 := (.tip (.cover {2,3,4,5,6,7,8}))
private theorem q12Shape36T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 34633542533120 q12Shape36T175=true := by decide

def q12Shape36P14 : Tree 12 := q12Shape36T175
theorem q12Shape36P14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 549755813888 34633542533120 q12Shape36P14=true := q12Shape36T175OK

end Graffiti384b.EffectiveSearch.Q12
