import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape36T179 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041357281304 q12Shape36T179=true := by decide

private def q12Shape36T181 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape36T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942382592 17041373534232 q12Shape36T181=true := by decide

private def q12Shape36T184 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.split 8 (.tip (.cover {0,1,3,4,5,8,10})) (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,2,3,5,7,9,10}))))) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141959159808 17041390311480 q12Shape36T184=true := by decide

private def q12Shape36T185 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.tip (.cover {0,1,2,6,7,9,11}))) (.split 7 (.split 8 (.split 13 (.split 14 (.split 15 (.tip (.cover {0,1,4,5,8,9,11})) (.tip (.cover {0,2,3,5,7,8,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,2,6,7,8,10}))) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141959159840 17041390311448 q12Shape36T185=true := by decide

private def q12Shape36T183 : Tree 12 := .split 5 q12Shape36T184 q12Shape36T185
private theorem q12Shape36T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141959159808 17041390311448 q12Shape36T183=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141959159808 (17041390311448 ||| 2^5) q12Shape36T184 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141959159808 ||| 2^5) 17041390311448 q12Shape36T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T184OK,q12Shape36T185OK⟩

private def q12Shape36T186 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141992714240 17041356757016 q12Shape36T186=true := by decide

private def q12Shape36T182 : Tree 12 := .split 25 q12Shape36T183 q12Shape36T186
private theorem q12Shape36T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141959159808 17041356757016 q12Shape36T182=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141959159808 (17041356757016 ||| 2^25) q12Shape36T183 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141959159808 ||| 2^25) 17041356757016 q12Shape36T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T183OK,q12Shape36T186OK⟩

private def q12Shape36T180 : Tree 12 := .split 24 q12Shape36T181 q12Shape36T182
private theorem q12Shape36T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942382592 17041356757016 q12Shape36T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942382592 (17041356757016 ||| 2^24) q12Shape36T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942382592 ||| 2^24) 17041356757016 q12Shape36T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T181OK,q12Shape36T182OK⟩

private def q12Shape36T178 : Tree 12 := .split 19 q12Shape36T179 q12Shape36T180
private theorem q12Shape36T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041356757016 q12Shape36T178=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 (17041356757016 ||| 2^19) q12Shape36T179 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941858304 ||| 2^19) 17041356757016 q12Shape36T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T179OK,q12Shape36T180OK⟩

private def q12Shape36T190 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape36T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942120448 17041407350808 q12Shape36T190=true := by decide

private def q12Shape36T192 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.split 8 (.tip (.cover {0,1,3,4,5,8,10})) (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,2,3,4,7,9,10}))))) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141975674880 17041373796408 q12Shape36T192=true := by decide

private def q12Shape36T193 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.tip (.cover {0,1,2,6,7,9,11}))) (.split 7 (.split 8 (.split 13 (.split 14 (.split 15 (.tip (.cover {0,1,4,5,8,9,11})) (.tip (.cover {0,2,3,4,7,8,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,2,6,7,8,10}))) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141975674912 17041373796376 q12Shape36T193=true := by decide

private def q12Shape36T191 : Tree 12 := .split 5 q12Shape36T192 q12Shape36T193
private theorem q12Shape36T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141975674880 17041373796376 q12Shape36T191=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141975674880 (17041373796376 ||| 2^5) q12Shape36T192 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141975674880 ||| 2^5) 17041373796376 q12Shape36T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T192OK,q12Shape36T193OK⟩

private def q12Shape36T189 : Tree 12 := .split 25 q12Shape36T190 q12Shape36T191
private theorem q12Shape36T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942120448 17041373796376 q12Shape36T189=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942120448 (17041373796376 ||| 2^25) q12Shape36T190 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942120448 ||| 2^25) 17041373796376 q12Shape36T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T190OK,q12Shape36T191OK⟩

private def q12Shape36T194 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958897664 17041357019160 q12Shape36T194=true := by decide

private def q12Shape36T188 : Tree 12 := .split 24 q12Shape36T189 q12Shape36T194
private theorem q12Shape36T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942120448 17041357019160 q12Shape36T188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942120448 (17041357019160 ||| 2^24) q12Shape36T189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942120448 ||| 2^24) 17041357019160 q12Shape36T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T189OK,q12Shape36T194OK⟩

private def q12Shape36T195 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape36T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942644736 17041356494872 q12Shape36T195=true := by decide

private def q12Shape36T187 : Tree 12 := .split 19 q12Shape36T188 q12Shape36T195
private theorem q12Shape36T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942120448 17041356494872 q12Shape36T187=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942120448 (17041356494872 ||| 2^19) q12Shape36T188 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942120448 ||| 2^19) 17041356494872 q12Shape36T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T188OK,q12Shape36T195OK⟩

private def q12Shape36T177 : Tree 12 := .split 18 q12Shape36T178 q12Shape36T187
private theorem q12Shape36T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041356494872 q12Shape36T177=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 (17041356494872 ||| 2^18) q12Shape36T178 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941858304 ||| 2^18) 17041356494872 q12Shape36T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T178OK,q12Shape36T187OK⟩

private def q12Shape36T199 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape36T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941862400 17041374054424 q12Shape36T199=true := by decide

private def q12Shape36T202 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.split 8 (.tip (.cover {0,1,3,4,5,8,10})) (.split 13 (.tip (.cover {0,2,4,5,7,9,10})) (.tip (.cover {0,1,3,6,9,10,11}))))) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958639616 17041390831672 q12Shape36T202=true := by decide

private def q12Shape36T203 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.tip (.cover {0,1,2,6,7,9,11}))) (.split 7 (.split 8 (.split 13 (.split 14 (.split 15 (.tip (.cover {0,2,4,5,7,8,11})) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,2,6,7,8,10}))) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958639648 17041390831640 q12Shape36T203=true := by decide

private def q12Shape36T201 : Tree 12 := .split 5 q12Shape36T202 q12Shape36T203
private theorem q12Shape36T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958639616 17041390831640 q12Shape36T201=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958639616 (17041390831640 ||| 2^5) q12Shape36T202 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141958639616 ||| 2^5) 17041390831640 q12Shape36T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T202OK,q12Shape36T203OK⟩

private def q12Shape36T204 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape36T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141992194048 17041357277208 q12Shape36T204=true := by decide

private def q12Shape36T200 : Tree 12 := .split 25 q12Shape36T201 q12Shape36T204
private theorem q12Shape36T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958639616 17041357277208 q12Shape36T200=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958639616 (17041357277208 ||| 2^25) q12Shape36T201 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141958639616 ||| 2^25) 17041357277208 q12Shape36T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T201OK,q12Shape36T204OK⟩

private def q12Shape36T198 : Tree 12 := .split 24 q12Shape36T199 q12Shape36T200
private theorem q12Shape36T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941862400 17041357277208 q12Shape36T198=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941862400 (17041357277208 ||| 2^24) q12Shape36T199 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941862400 ||| 2^24) 17041357277208 q12Shape36T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T199OK,q12Shape36T200OK⟩

private def q12Shape36T205 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,10}))
private theorem q12Shape36T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942386688 17041356752920 q12Shape36T205=true := by decide

private def q12Shape36T197 : Tree 12 := .split 19 q12Shape36T198 q12Shape36T205
private theorem q12Shape36T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941862400 17041356752920 q12Shape36T197=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941862400 (17041356752920 ||| 2^19) q12Shape36T198 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941862400 ||| 2^19) 17041356752920 q12Shape36T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T198OK,q12Shape36T205OK⟩

private def q12Shape36T210 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.split 8 (.tip (.cover {0,1,3,4,5,8,10})) (.split 13 (.tip (.cover {0,2,4,5,7,9,10})) (.tip (.cover {0,1,3,6,9,10,11}))))) (.split 7 (.tip (.cover {0,1,3,4,5,9,11})) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 17041407346744 q12Shape36T210=true := by decide

private def q12Shape36T211 : Tree 12 := (.split 6 (.split 7 (.tip (.cover {0,1,3,4,5,8,11})) (.tip (.cover {0,1,2,6,7,9,11}))) (.split 7 (.split 8 (.split 13 (.split 14 (.split 15 (.tip (.cover {0,2,4,5,7,8,11})) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11}))) (.tip (.cover {0,1,2,6,7,8,10}))) (.tip (.cover {0,1,2,6,7,8,11}))))
private theorem q12Shape36T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124576 17041407346712 q12Shape36T211=true := by decide

private def q12Shape36T209 : Tree 12 := .split 5 q12Shape36T210 q12Shape36T211
private theorem q12Shape36T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 17041407346712 q12Shape36T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 (17041407346712 ||| 2^5) q12Shape36T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942124544 ||| 2^5) 17041407346712 q12Shape36T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T210OK,q12Shape36T211OK⟩

private def q12Shape36T212 : Tree 12 := (.tip (.cover {2,3,4,5,6,8,10}))
private theorem q12Shape36T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141975678976 17041373792280 q12Shape36T212=true := by decide

private def q12Shape36T208 : Tree 12 := .split 25 q12Shape36T209 q12Shape36T212
private theorem q12Shape36T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 17041373792280 q12Shape36T208=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 (17041373792280 ||| 2^25) q12Shape36T209 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942124544 ||| 2^25) 17041373792280 q12Shape36T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T209OK,q12Shape36T212OK⟩

private def q12Shape36T213 : Tree 12 := (.tip (.cover {2,3,4,5,7,8,10}))
private theorem q12Shape36T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141958901760 17041357015064 q12Shape36T213=true := by decide

private def q12Shape36T207 : Tree 12 := .split 24 q12Shape36T208 q12Shape36T213
private theorem q12Shape36T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 17041357015064 q12Shape36T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 (17041357015064 ||| 2^24) q12Shape36T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942124544 ||| 2^24) 17041357015064 q12Shape36T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T208OK,q12Shape36T213OK⟩

private def q12Shape36T214 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape36T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942648832 17041356490776 q12Shape36T214=true := by decide

private def q12Shape36T206 : Tree 12 := .split 19 q12Shape36T207 q12Shape36T214
private theorem q12Shape36T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 17041356490776 q12Shape36T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141942124544 (17041356490776 ||| 2^19) q12Shape36T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141942124544 ||| 2^19) 17041356490776 q12Shape36T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T207OK,q12Shape36T214OK⟩

private def q12Shape36T196 : Tree 12 := .split 18 q12Shape36T197 q12Shape36T206
private theorem q12Shape36T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941862400 17041356490776 q12Shape36T196=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941862400 (17041356490776 ||| 2^18) q12Shape36T197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941862400 ||| 2^18) 17041356490776 q12Shape36T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T197OK,q12Shape36T206OK⟩

private def q12Shape36T176 : Tree 12 := .split 12 q12Shape36T177 q12Shape36T196
private theorem q12Shape36T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041356490776 q12Shape36T176=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 (17041356490776 ||| 2^12) q12Shape36T177 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) (18141941858304 ||| 2^12) 17041356490776 q12Shape36T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape36T177OK,q12Shape36T196OK⟩

def q12Shape36P15 : Tree 12 := q12Shape36T176
theorem q12Shape36P15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,6,6,4⟩) 18141941858304 17041356490776 q12Shape36P15=true := q12Shape36T176OK

end Graffiti384b.EffectiveSearch.Q12
