import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape37T0 : Tree 12 := (.tip (.small 1))
private theorem q12Shape37T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 (forms 37)) 0 0 q12Shape37T0=true := by decide


theorem q12Shape37_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 37) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 37) b) (adj 12 (forms 37) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 (forms 37)) adj_mono b H q12Shape37T0 q12Shape37T0OK

#print axioms q12Shape37_cover
end Graffiti384b.EffectiveSearch.Q12
