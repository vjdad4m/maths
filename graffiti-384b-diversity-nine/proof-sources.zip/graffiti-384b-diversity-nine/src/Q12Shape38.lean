import Q12Shape38Part0

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q12Shape38_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 38) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 38) b) (adj 12 (forms 38) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) adj_mono b H q12Shape38P0 q12Shape38P0OK

#print axioms q12Shape38_cover

end Graffiti384b.EffectiveSearch.Q12
