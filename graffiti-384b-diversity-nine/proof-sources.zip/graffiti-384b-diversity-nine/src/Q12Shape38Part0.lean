import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape38T1 : Tree 12 := (.tip (.small 1))
private theorem q12Shape38T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 0 32 q12Shape38T1=true := by decide

private def q12Shape38T3 : Tree 12 := (.tip (.small 1))
private theorem q12Shape38T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 32 64 q12Shape38T3=true := by decide

private def q12Shape38T5 : Tree 12 := (.tip (.small 1))
private theorem q12Shape38T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 96 128 q12Shape38T5=true := by decide

private def q12Shape38T13 : Tree 12 := (.split 11 (.split 12 (.split 17 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,6,11})))) (.split 12 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))))
private theorem q12Shape38T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 1567 q12Shape38T13=true := by decide

private def q12Shape38T14 : Tree 12 := (.split 11 (.split 12 (.split 17 (.split 18 (.tip (.small 0)) (.tip (.cover {0,1,2,3,4,7,11}))) (.tip (.cover {1,2,3,4,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11})))
private theorem q12Shape38T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 1248 543 q12Shape38T14=true := by decide

private def q12Shape38T12 : Tree 12 := .split 10 q12Shape38T13 q12Shape38T14
private theorem q12Shape38T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 543 q12Shape38T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 (543 ||| 2^10) q12Shape38T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (224 ||| 2^10) 543 q12Shape38T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T13OK,q12Shape38T14OK⟩

private def q12Shape38T15 : Tree 12 := (.split 10 (.split 11 (.split 12 (.split 17 (.split 18 (.tip (.small 0)) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11})))
private theorem q12Shape38T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 736 31 q12Shape38T15=true := by decide

private def q12Shape38T11 : Tree 12 := .split 9 q12Shape38T12 q12Shape38T15
private theorem q12Shape38T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 31 q12Shape38T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 (31 ||| 2^9) q12Shape38T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (224 ||| 2^9) 31 q12Shape38T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T12OK,q12Shape38T15OK⟩

private def q12Shape38T16 : Tree 12 := (.split 9 (.split 10 (.split 11 (.split 12 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,6,11}))) (.tip (.cover {1,2,3,4,5,6,11}))) (.tip (.cover {0,1,2,3,4,5,11}))) (.tip (.cover {0,1,2,3,4,6,11}))) (.tip (.cover {0,1,2,3,5,6,11})))
private theorem q12Shape38T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 240 15 q12Shape38T16=true := by decide

private def q12Shape38T10 : Tree 12 := .split 4 q12Shape38T11 q12Shape38T16
private theorem q12Shape38T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 15 q12Shape38T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 (15 ||| 2^4) q12Shape38T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (224 ||| 2^4) 15 q12Shape38T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T11OK,q12Shape38T16OK⟩

private def q12Shape38T17 : Tree 12 := (.split 4 (.split 9 (.split 10 (.split 11 (.split 12 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,7,11}))) (.tip (.cover {0,1,2,3,4,5,11}))) (.tip (.cover {1,2,3,4,5,7,11}))) (.tip (.cover {0,1,2,3,4,7,11}))) (.tip (.cover {0,1,2,3,5,7,11}))) (.tip (.cover {0,1,2,3,4,5,11})))
private theorem q12Shape38T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 232 7 q12Shape38T17=true := by decide

private def q12Shape38T9 : Tree 12 := .split 3 q12Shape38T10 q12Shape38T17
private theorem q12Shape38T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 7 q12Shape38T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 (7 ||| 2^3) q12Shape38T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (224 ||| 2^3) 7 q12Shape38T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T10OK,q12Shape38T17OK⟩

private def q12Shape38T19 : Tree 12 := (.split 4 (.split 9 (.split 10 (.split 11 (.split 12 (.split 17 (.split 18 (.tip (.small 0)) (.tip (.cover {0,1,2,3,4,7,11}))) (.tip (.cover {1,2,3,4,6,7,11}))) (.tip (.cover {0,1,2,3,4,6,11}))) (.tip (.cover {0,1,2,3,4,7,11}))) (.tip (.cover {1,2,3,4,6,7,11}))) (.tip (.cover {0,1,2,3,6,7,11}))) (.tip (.cover {0,1,2,3,4,6,11})))
private theorem q12Shape38T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 228 11 q12Shape38T19=true := by decide

private def q12Shape38T20 : Tree 12 := (.tip (.cover {0,1,2,3,4,7,11}))
private theorem q12Shape38T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 236 3 q12Shape38T20=true := by decide

private def q12Shape38T18 : Tree 12 := .split 3 q12Shape38T19 q12Shape38T20
private theorem q12Shape38T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 228 3 q12Shape38T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 228 (3 ||| 2^3) q12Shape38T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (228 ||| 2^3) 3 q12Shape38T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T19OK,q12Shape38T20OK⟩

private def q12Shape38T8 : Tree 12 := .split 2 q12Shape38T9 q12Shape38T18
private theorem q12Shape38T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 3 q12Shape38T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 (3 ||| 2^2) q12Shape38T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (224 ||| 2^2) 3 q12Shape38T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T9OK,q12Shape38T18OK⟩

private def q12Shape38T23 : Tree 12 := (.split 4 (.split 9 (.split 10 (.split 11 (.split 12 (.split 17 (.split 18 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10,11}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,2,3,5,6,11}))) (.tip (.cover {0,1,2,3,5,7,11}))) (.tip (.cover {0,1,2,3,6,7,11}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,2,3,5,6,11})))
private theorem q12Shape38T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 226 13 q12Shape38T23=true := by decide

private def q12Shape38T24 : Tree 12 := (.tip (.cover {0,1,2,3,5,7,11}))
private theorem q12Shape38T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 234 5 q12Shape38T24=true := by decide

private def q12Shape38T22 : Tree 12 := .split 3 q12Shape38T23 q12Shape38T24
private theorem q12Shape38T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 226 5 q12Shape38T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 226 (5 ||| 2^3) q12Shape38T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (226 ||| 2^3) 5 q12Shape38T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T23OK,q12Shape38T24OK⟩

private def q12Shape38T25 : Tree 12 := (.tip (.cover {0,1,2,3,6,7,11}))
private theorem q12Shape38T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 230 1 q12Shape38T25=true := by decide

private def q12Shape38T21 : Tree 12 := .split 2 q12Shape38T22 q12Shape38T25
private theorem q12Shape38T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 226 1 q12Shape38T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 226 (1 ||| 2^2) q12Shape38T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (226 ||| 2^2) 1 q12Shape38T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T22OK,q12Shape38T25OK⟩

private def q12Shape38T7 : Tree 12 := .split 1 q12Shape38T8 q12Shape38T21
private theorem q12Shape38T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 1 q12Shape38T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 (1 ||| 2^1) q12Shape38T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (224 ||| 2^1) 1 q12Shape38T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T8OK,q12Shape38T21OK⟩

private def q12Shape38T29 : Tree 12 := (.split 4 (.split 9 (.split 10 (.split 11 (.split 12 (.split 17 (.split 18 (.tip (.small 0)) (.tip (.cover {0,1,2,4,5,7,11}))) (.tip (.cover {0,1,2,4,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))) (.tip (.cover {1,2,4,5,6,7,11}))) (.tip (.cover {0,1,2,4,5,6,11})))
private theorem q12Shape38T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 225 14 q12Shape38T29=true := by decide

private def q12Shape38T30 : Tree 12 := (.tip (.cover {0,1,2,4,5,7,11}))
private theorem q12Shape38T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 233 6 q12Shape38T30=true := by decide

private def q12Shape38T28 : Tree 12 := .split 3 q12Shape38T29 q12Shape38T30
private theorem q12Shape38T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 225 6 q12Shape38T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 225 (6 ||| 2^3) q12Shape38T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (225 ||| 2^3) 6 q12Shape38T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T29OK,q12Shape38T30OK⟩

private def q12Shape38T31 : Tree 12 := (.tip (.cover {0,1,2,4,6,7,11}))
private theorem q12Shape38T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 229 2 q12Shape38T31=true := by decide

private def q12Shape38T27 : Tree 12 := .split 2 q12Shape38T28 q12Shape38T31
private theorem q12Shape38T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 225 2 q12Shape38T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 225 (2 ||| 2^2) q12Shape38T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (225 ||| 2^2) 2 q12Shape38T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T28OK,q12Shape38T31OK⟩

private def q12Shape38T32 : Tree 12 := (.tip (.cover {0,1,2,5,6,7,11}))
private theorem q12Shape38T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 227 0 q12Shape38T32=true := by decide

private def q12Shape38T26 : Tree 12 := .split 1 q12Shape38T27 q12Shape38T32
private theorem q12Shape38T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 225 0 q12Shape38T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 225 (0 ||| 2^1) q12Shape38T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (225 ||| 2^1) 0 q12Shape38T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T27OK,q12Shape38T32OK⟩

private def q12Shape38T6 : Tree 12 := .split 0 q12Shape38T7 q12Shape38T26
private theorem q12Shape38T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 0 q12Shape38T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 224 (0 ||| 2^0) q12Shape38T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (224 ||| 2^0) 0 q12Shape38T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T7OK,q12Shape38T26OK⟩

private def q12Shape38T4 : Tree 12 := .split 7 q12Shape38T5 q12Shape38T6
private theorem q12Shape38T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 96 0 q12Shape38T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 96 (0 ||| 2^7) q12Shape38T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (96 ||| 2^7) 0 q12Shape38T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T5OK,q12Shape38T6OK⟩

private def q12Shape38T2 : Tree 12 := .split 6 q12Shape38T3 q12Shape38T4
private theorem q12Shape38T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 32 0 q12Shape38T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 32 (0 ||| 2^6) q12Shape38T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (32 ||| 2^6) 0 q12Shape38T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T3OK,q12Shape38T4OK⟩

private def q12Shape38T0 : Tree 12 := .split 5 q12Shape38T1 q12Shape38T2
private theorem q12Shape38T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 0 0 q12Shape38T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 0 (0 ||| 2^5) q12Shape38T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) (0 ||| 2^5) 0 q12Shape38T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape38T1OK,q12Shape38T2OK⟩

def q12Shape38P0 : Tree 12 := q12Shape38T0
theorem q12Shape38P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,1⟩) 0 0 q12Shape38P0=true := q12Shape38T0OK

end Graffiti384b.EffectiveSearch.Q12
