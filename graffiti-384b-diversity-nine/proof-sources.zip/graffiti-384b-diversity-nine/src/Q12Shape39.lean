import Q12Shape39Part0
import Q12Shape39Part1
import Q12Shape39Part2
import Q12Shape39Part3
import Q12Shape39Part4
import Q12Shape39Part5
import Q12Shape39Part6

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39M54 : Tree 12 := .split 24 q12Shape39P0 q12Shape39P1
private theorem q12Shape39M54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 917504 q12Shape39M54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 (917504 ||| 2^24) q12Shape39P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (0 ||| 2^24) 917504 q12Shape39P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39P0OK,q12Shape39P1OK⟩
private def q12Shape39M78 : Tree 12 := .split 19 q12Shape39M54 q12Shape39P2
private theorem q12Shape39M78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 393216 q12Shape39M78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 (393216 ||| 2^19) q12Shape39M54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (0 ||| 2^19) 393216 q12Shape39P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39M54OK,q12Shape39P2OK⟩
private def q12Shape39M117 : Tree 12 := .split 19 q12Shape39P3 q12Shape39P4
private theorem q12Shape39M117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 131072 q12Shape39M117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 (131072 ||| 2^19) q12Shape39P3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262144 ||| 2^19) 131072 q12Shape39P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39P3OK,q12Shape39P4OK⟩
private def q12Shape39M118 : Tree 12 := .split 18 q12Shape39M78 q12Shape39M117
private theorem q12Shape39M118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 131072 q12Shape39M118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 (131072 ||| 2^18) q12Shape39M78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (0 ||| 2^18) 131072 q12Shape39M117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39M78OK,q12Shape39M117OK⟩
private def q12Shape39M161 : Tree 12 := .split 19 q12Shape39P5 q12Shape39P6
private theorem q12Shape39M161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 262144 q12Shape39M161=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 (262144 ||| 2^19) q12Shape39P5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131072 ||| 2^19) 262144 q12Shape39P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39P5OK,q12Shape39P6OK⟩
private def q12Shape39M173 : Tree 12 := .split 18 q12Shape39M161 q12Shape39P7
private theorem q12Shape39M173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 0 q12Shape39M173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 (0 ||| 2^18) q12Shape39M161 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131072 ||| 2^18) 0 q12Shape39P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39M161OK,q12Shape39P7OK⟩
private def q12Shape39M174 : Tree 12 := .split 17 q12Shape39M118 q12Shape39M173
private theorem q12Shape39M174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 0 q12Shape39M174=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 (0 ||| 2^17) q12Shape39M118 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (0 ||| 2^17) 0 q12Shape39M173)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39M118OK,q12Shape39M173OK⟩

theorem q12Shape39_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 39) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 39) b) (adj 12 (forms 39) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) adj_mono b H q12Shape39M174 q12Shape39M174OK

#print axioms q12Shape39_cover

end Graffiti384b.EffectiveSearch.Q12
