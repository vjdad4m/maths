import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39T2 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape39T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 1124990976 q12Shape39T2=true := by decide

private def q12Shape39T4 : Tree 12 := (.split 39 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,5,6,10,11}))))))))
private theorem q12Shape39T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1073741824 51249153 q12Shape39T4=true := by decide

private def q12Shape39T6 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,5,6,10,11})))))))
private theorem q12Shape39T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1073741825 549807063040 q12Shape39T6=true := by decide

private def q12Shape39T8 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10,11})) (.tip (.cover {0,2,4,6,8,10,11}))) (.tip (.cover {0,2,5,6,8,10,11}))))))
private theorem q12Shape39T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555713 51249184 q12Shape39T8=true := by decide

private def q12Shape39T10 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10,11})) (.tip (.cover {0,2,4,6,9,10,11}))) (.tip (.cover {0,2,5,6,9,10,11})))))
private theorem q12Shape39T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555745 51249216 q12Shape39T10=true := by decide

private def q12Shape39T12 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape39T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555809 51257344 q12Shape39T12=true := by decide

private def q12Shape39T13 : Tree 12 := (.split 14 (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,5,6,10,11}))) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape39T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829564001 51249152 q12Shape39T13=true := by decide

private def q12Shape39T11 : Tree 12 := .split 13 q12Shape39T12 q12Shape39T13
private theorem q12Shape39T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555809 51249152 q12Shape39T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555809 (51249152 ||| 2^13) q12Shape39T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (550829555809 ||| 2^13) 51249152 q12Shape39T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T12OK,q12Shape39T13OK⟩

private def q12Shape39T9 : Tree 12 := .split 6 q12Shape39T10 q12Shape39T11
private theorem q12Shape39T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555745 51249152 q12Shape39T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555745 (51249152 ||| 2^6) q12Shape39T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (550829555745 ||| 2^6) 51249152 q12Shape39T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T10OK,q12Shape39T11OK⟩

private def q12Shape39T7 : Tree 12 := .split 5 q12Shape39T8 q12Shape39T9
private theorem q12Shape39T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555713 51249152 q12Shape39T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 550829555713 (51249152 ||| 2^5) q12Shape39T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (550829555713 ||| 2^5) 51249152 q12Shape39T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T8OK,q12Shape39T9OK⟩

private def q12Shape39T5 : Tree 12 := .split 39 q12Shape39T6 q12Shape39T7
private theorem q12Shape39T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1073741825 51249152 q12Shape39T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1073741825 (51249152 ||| 2^39) q12Shape39T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (1073741825 ||| 2^39) 51249152 q12Shape39T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T6OK,q12Shape39T7OK⟩

private def q12Shape39T3 : Tree 12 := .split 0 q12Shape39T4 q12Shape39T5
private theorem q12Shape39T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1073741824 51249152 q12Shape39T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1073741824 (51249152 ||| 2^0) q12Shape39T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (1073741824 ||| 2^0) 51249152 q12Shape39T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T4OK,q12Shape39T5OK⟩

private def q12Shape39T1 : Tree 12 := .split 30 q12Shape39T2 q12Shape39T3
private theorem q12Shape39T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 51249152 q12Shape39T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 (51249152 ||| 2^30) q12Shape39T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (0 ||| 2^30) 51249152 q12Shape39T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T2OK,q12Shape39T3OK⟩

private def q12Shape39T17 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554432 550847250433 q12Shape39T17=true := by decide

private def q12Shape39T18 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {0,1,2,5,6,10,11})))))))
private theorem q12Shape39T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368320 1091436545 q12Shape39T18=true := by decide

private def q12Shape39T16 : Tree 12 := .split 39 q12Shape39T17 q12Shape39T18
private theorem q12Shape39T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554432 1091436545 q12Shape39T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554432 (1091436545 ||| 2^39) q12Shape39T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (33554432 ||| 2^39) 1091436545 q12Shape39T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T17OK,q12Shape39T18OK⟩

private def q12Shape39T20 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {0,1,2,5,6,10,11})))))))
private theorem q12Shape39T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554433 550847250432 q12Shape39T20=true := by decide

private def q12Shape39T22 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,2,4,5,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))) (.tip (.cover {0,2,5,6,8,10,11}))))))
private theorem q12Shape39T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368321 1091436576 q12Shape39T22=true := by decide

private def q12Shape39T24 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,2,4,5,9,10,11}))) (.tip (.cover {2,4,6,7,9,10,11}))) (.tip (.cover {0,2,5,6,9,10,11})))))
private theorem q12Shape39T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368353 1091436608 q12Shape39T24=true := by decide

private def q12Shape39T26 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,4,6,7,9,10,11}))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape39T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368417 1091444736 q12Shape39T26=true := by decide

private def q12Shape39T27 : Tree 12 := (.split 14 (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))) (.tip (.cover {0,1,2,5,6,10,11}))) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape39T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789376609 1091436544 q12Shape39T27=true := by decide

private def q12Shape39T25 : Tree 12 := .split 13 q12Shape39T26 q12Shape39T27
private theorem q12Shape39T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368417 1091436544 q12Shape39T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368417 (1091436544 ||| 2^13) q12Shape39T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549789368417 ||| 2^13) 1091436544 q12Shape39T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T26OK,q12Shape39T27OK⟩

private def q12Shape39T23 : Tree 12 := .split 6 q12Shape39T24 q12Shape39T25
private theorem q12Shape39T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368353 1091436544 q12Shape39T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368353 (1091436544 ||| 2^6) q12Shape39T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549789368353 ||| 2^6) 1091436544 q12Shape39T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T24OK,q12Shape39T25OK⟩

private def q12Shape39T21 : Tree 12 := .split 5 q12Shape39T22 q12Shape39T23
private theorem q12Shape39T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368321 1091436544 q12Shape39T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549789368321 (1091436544 ||| 2^5) q12Shape39T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549789368321 ||| 2^5) 1091436544 q12Shape39T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T22OK,q12Shape39T23OK⟩

private def q12Shape39T19 : Tree 12 := .split 39 q12Shape39T20 q12Shape39T21
private theorem q12Shape39T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554433 1091436544 q12Shape39T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554433 (1091436544 ||| 2^39) q12Shape39T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (33554433 ||| 2^39) 1091436544 q12Shape39T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T20OK,q12Shape39T21OK⟩

private def q12Shape39T15 : Tree 12 := .split 0 q12Shape39T16 q12Shape39T19
private theorem q12Shape39T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554432 1091436544 q12Shape39T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554432 (1091436544 ||| 2^0) q12Shape39T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (33554432 ||| 2^0) 1091436544 q12Shape39T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T16OK,q12Shape39T19OK⟩

private def q12Shape39T28 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11})))) (.tip (.cover {0,1,4,7,8,10,11}))))
private theorem q12Shape39T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1107296256 17694720 q12Shape39T28=true := by decide

private def q12Shape39T14 : Tree 12 := .split 30 q12Shape39T15 q12Shape39T28
private theorem q12Shape39T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554432 17694720 q12Shape39T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33554432 (17694720 ||| 2^30) q12Shape39T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (33554432 ||| 2^30) 17694720 q12Shape39T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T15OK,q12Shape39T28OK⟩

private def q12Shape39T0 : Tree 12 := .split 25 q12Shape39T1 q12Shape39T14
private theorem q12Shape39T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 17694720 q12Shape39T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 (17694720 ||| 2^25) q12Shape39T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (0 ||| 2^25) 17694720 q12Shape39T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T1OK,q12Shape39T14OK⟩

def q12Shape39P0 : Tree 12 := q12Shape39T0
theorem q12Shape39P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 0 17694720 q12Shape39P0=true := q12Shape39T0OK

end Graffiti384b.EffectiveSearch.Q12
