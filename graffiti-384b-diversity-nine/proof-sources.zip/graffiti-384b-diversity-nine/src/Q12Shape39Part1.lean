import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39T33 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 550864027649 q12Shape39T33=true := by decide

private def q12Shape39T35 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591104 1108213793 q12Shape39T35=true := by decide

private def q12Shape39T36 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,5,7,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {0,1,2,5,7,10,11}))))))
private theorem q12Shape39T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591136 1108213761 q12Shape39T36=true := by decide

private def q12Shape39T34 : Tree 12 := .split 5 q12Shape39T35 q12Shape39T36
private theorem q12Shape39T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591104 1108213761 q12Shape39T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591104 (1108213761 ||| 2^5) q12Shape39T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549772591104 ||| 2^5) 1108213761 q12Shape39T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T35OK,q12Shape39T36OK⟩

private def q12Shape39T32 : Tree 12 := .split 39 q12Shape39T33 q12Shape39T34
private theorem q12Shape39T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 1108213761 q12Shape39T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 (1108213761 ||| 2^39) q12Shape39T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16777216 ||| 2^39) 1108213761 q12Shape39T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T33OK,q12Shape39T34OK⟩

private def q12Shape39T39 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777217 550864027680 q12Shape39T39=true := by decide

private def q12Shape39T40 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,5,7,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {0,1,2,5,7,10,11}))))))
private theorem q12Shape39T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777249 550864027648 q12Shape39T40=true := by decide

private def q12Shape39T38 : Tree 12 := .split 5 q12Shape39T39 q12Shape39T40
private theorem q12Shape39T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777217 550864027648 q12Shape39T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777217 (550864027648 ||| 2^5) q12Shape39T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16777217 ||| 2^5) 550864027648 q12Shape39T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T39OK,q12Shape39T40OK⟩

private def q12Shape39T42 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,2,4,5,8,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))) (.tip (.cover {0,2,5,7,8,10,11}))))))
private theorem q12Shape39T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591105 1108213792 q12Shape39T42=true := by decide

private def q12Shape39T44 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,2,4,5,9,10,11}))) (.tip (.cover {2,4,5,7,9,10,11}))) (.tip (.cover {2,4,6,7,9,10,11}))) (.tip (.cover {0,2,5,7,9,10,11})))))
private theorem q12Shape39T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591137 1108213824 q12Shape39T44=true := by decide

private def q12Shape39T46 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,4,5,7,9,10,11}))) (.tip (.cover {2,4,6,7,9,10,11}))) (.tip (.cover {0,1,2,5,7,10,11}))))
private theorem q12Shape39T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591201 1108221952 q12Shape39T46=true := by decide

private def q12Shape39T48 : Tree 12 := (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))) (.tip (.cover {0,1,2,5,7,10,11})))
private theorem q12Shape39T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772599393 1108230144 q12Shape39T48=true := by decide

private def q12Shape39T49 : Tree 12 := (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,5,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,5,7,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {0,1,2,5,7,10,11})))
private theorem q12Shape39T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772615777 1108213760 q12Shape39T49=true := by decide

private def q12Shape39T47 : Tree 12 := .split 14 q12Shape39T48 q12Shape39T49
private theorem q12Shape39T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772599393 1108213760 q12Shape39T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772599393 (1108213760 ||| 2^14) q12Shape39T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549772599393 ||| 2^14) 1108213760 q12Shape39T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T48OK,q12Shape39T49OK⟩

private def q12Shape39T45 : Tree 12 := .split 13 q12Shape39T46 q12Shape39T47
private theorem q12Shape39T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591201 1108213760 q12Shape39T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591201 (1108213760 ||| 2^13) q12Shape39T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549772591201 ||| 2^13) 1108213760 q12Shape39T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T46OK,q12Shape39T47OK⟩

private def q12Shape39T43 : Tree 12 := .split 6 q12Shape39T44 q12Shape39T45
private theorem q12Shape39T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591137 1108213760 q12Shape39T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591137 (1108213760 ||| 2^6) q12Shape39T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549772591137 ||| 2^6) 1108213760 q12Shape39T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T44OK,q12Shape39T45OK⟩

private def q12Shape39T41 : Tree 12 := .split 5 q12Shape39T42 q12Shape39T43
private theorem q12Shape39T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591105 1108213760 q12Shape39T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549772591105 (1108213760 ||| 2^5) q12Shape39T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549772591105 ||| 2^5) 1108213760 q12Shape39T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T42OK,q12Shape39T43OK⟩

private def q12Shape39T37 : Tree 12 := .split 39 q12Shape39T38 q12Shape39T41
private theorem q12Shape39T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777217 1108213760 q12Shape39T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777217 (1108213760 ||| 2^39) q12Shape39T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16777217 ||| 2^39) 1108213760 q12Shape39T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T38OK,q12Shape39T41OK⟩

private def q12Shape39T31 : Tree 12 := .split 0 q12Shape39T32 q12Shape39T37
private theorem q12Shape39T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 1108213760 q12Shape39T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 (1108213760 ||| 2^0) q12Shape39T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16777216 ||| 2^0) 1108213760 q12Shape39T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T32OK,q12Shape39T37OK⟩

private def q12Shape39T50 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape39T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1090519040 34471936 q12Shape39T50=true := by decide

private def q12Shape39T30 : Tree 12 := .split 30 q12Shape39T31 q12Shape39T50
private theorem q12Shape39T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 34471936 q12Shape39T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 (34471936 ||| 2^30) q12Shape39T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16777216 ||| 2^30) 34471936 q12Shape39T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T31OK,q12Shape39T50OK⟩

private def q12Shape39T52 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 50331648 1074659328 q12Shape39T52=true := by decide

private def q12Shape39T53 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1124073472 917504 q12Shape39T53=true := by decide

private def q12Shape39T51 : Tree 12 := .split 30 q12Shape39T52 q12Shape39T53
private theorem q12Shape39T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 50331648 917504 q12Shape39T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 50331648 (917504 ||| 2^30) q12Shape39T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (50331648 ||| 2^30) 917504 q12Shape39T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T52OK,q12Shape39T53OK⟩

private def q12Shape39T29 : Tree 12 := .split 25 q12Shape39T30 q12Shape39T51
private theorem q12Shape39T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 917504 q12Shape39T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 (917504 ||| 2^25) q12Shape39T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16777216 ||| 2^25) 917504 q12Shape39T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T30OK,q12Shape39T51OK⟩

def q12Shape39P1 : Tree 12 := q12Shape39T29
theorem q12Shape39P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16777216 917504 q12Shape39P1=true := q12Shape39T29OK

end Graffiti384b.EffectiveSearch.Q12
