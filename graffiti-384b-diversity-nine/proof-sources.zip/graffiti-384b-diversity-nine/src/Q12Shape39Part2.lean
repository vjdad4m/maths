import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39T60 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 550880280577 q12Shape39T60=true := by decide

private def q12Shape39T61 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {2,3,5,6,7,10,11})))))))
private theorem q12Shape39T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338176 1124466689 q12Shape39T61=true := by decide

private def q12Shape39T59 : Tree 12 := .split 39 q12Shape39T60 q12Shape39T61
private theorem q12Shape39T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 1124466689 q12Shape39T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 (1124466689 ||| 2^39) q12Shape39T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (524288 ||| 2^39) 1124466689 q12Shape39T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T60OK,q12Shape39T61OK⟩

private def q12Shape39T63 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {2,3,5,6,7,10,11})))))))
private theorem q12Shape39T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524289 550880280576 q12Shape39T63=true := by decide

private def q12Shape39T65 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,2,4,5,8,10,11}))) (.tip (.cover {0,2,4,6,8,10,11}))) (.tip (.cover {2,5,6,7,8,10,11}))))))
private theorem q12Shape39T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338177 1124466720 q12Shape39T65=true := by decide

private def q12Shape39T67 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,2,4,5,9,10,11}))) (.tip (.cover {0,2,4,6,9,10,11}))) (.tip (.cover {2,5,6,7,9,10,11})))))
private theorem q12Shape39T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338209 1124466752 q12Shape39T67=true := by decide

private def q12Shape39T69 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {2,5,6,7,9,10,11}))))
private theorem q12Shape39T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338273 1124474880 q12Shape39T69=true := by decide

private def q12Shape39T70 : Tree 12 := (.split 14 (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {2,5,6,7,8,10,11}))) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {2,3,5,6,7,10,11}))))
private theorem q12Shape39T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756346465 1124466688 q12Shape39T70=true := by decide

private def q12Shape39T68 : Tree 12 := .split 13 q12Shape39T69 q12Shape39T70
private theorem q12Shape39T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338273 1124466688 q12Shape39T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338273 (1124466688 ||| 2^13) q12Shape39T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756338273 ||| 2^13) 1124466688 q12Shape39T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T69OK,q12Shape39T70OK⟩

private def q12Shape39T66 : Tree 12 := .split 6 q12Shape39T67 q12Shape39T68
private theorem q12Shape39T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338209 1124466688 q12Shape39T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338209 (1124466688 ||| 2^6) q12Shape39T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756338209 ||| 2^6) 1124466688 q12Shape39T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T67OK,q12Shape39T68OK⟩

private def q12Shape39T64 : Tree 12 := .split 5 q12Shape39T65 q12Shape39T66
private theorem q12Shape39T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338177 1124466688 q12Shape39T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756338177 (1124466688 ||| 2^5) q12Shape39T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756338177 ||| 2^5) 1124466688 q12Shape39T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T65OK,q12Shape39T66OK⟩

private def q12Shape39T62 : Tree 12 := .split 39 q12Shape39T63 q12Shape39T64
private theorem q12Shape39T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524289 1124466688 q12Shape39T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524289 (1124466688 ||| 2^39) q12Shape39T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (524289 ||| 2^39) 1124466688 q12Shape39T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T63OK,q12Shape39T64OK⟩

private def q12Shape39T58 : Tree 12 := .split 0 q12Shape39T59 q12Shape39T62
private theorem q12Shape39T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 1124466688 q12Shape39T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 (1124466688 ||| 2^0) q12Shape39T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (524288 ||| 2^0) 1124466688 q12Shape39T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T59OK,q12Shape39T62OK⟩

private def q12Shape39T71 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape39T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1074266112 50724864 q12Shape39T71=true := by decide

private def q12Shape39T57 : Tree 12 := .split 30 q12Shape39T58 q12Shape39T71
private theorem q12Shape39T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 50724864 q12Shape39T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 (50724864 ||| 2^30) q12Shape39T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (524288 ||| 2^30) 50724864 q12Shape39T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T58OK,q12Shape39T71OK⟩

private def q12Shape39T72 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,6,7,10,11})))) (.tip (.cover {0,1,6,7,8,10,11})))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape39T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 34078720 17170432 q12Shape39T72=true := by decide

private def q12Shape39T56 : Tree 12 := .split 25 q12Shape39T57 q12Shape39T72
private theorem q12Shape39T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 17170432 q12Shape39T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 (17170432 ||| 2^25) q12Shape39T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (524288 ||| 2^25) 17170432 q12Shape39T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T57OK,q12Shape39T72OK⟩

private def q12Shape39T75 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17301504 1107689472 q12Shape39T75=true := by decide

private def q12Shape39T76 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1091043328 33947648 q12Shape39T76=true := by decide

private def q12Shape39T74 : Tree 12 := .split 30 q12Shape39T75 q12Shape39T76
private theorem q12Shape39T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17301504 33947648 q12Shape39T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17301504 (33947648 ||| 2^30) q12Shape39T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (17301504 ||| 2^30) 33947648 q12Shape39T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T75OK,q12Shape39T76OK⟩

private def q12Shape39T77 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape39T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 50855936 393216 q12Shape39T77=true := by decide

private def q12Shape39T73 : Tree 12 := .split 25 q12Shape39T74 q12Shape39T77
private theorem q12Shape39T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17301504 393216 q12Shape39T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17301504 (393216 ||| 2^25) q12Shape39T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (17301504 ||| 2^25) 393216 q12Shape39T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T74OK,q12Shape39T77OK⟩

private def q12Shape39T55 : Tree 12 := .split 24 q12Shape39T56 q12Shape39T73
private theorem q12Shape39T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 393216 q12Shape39T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 (393216 ||| 2^24) q12Shape39T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (524288 ||| 2^24) 393216 q12Shape39T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T56OK,q12Shape39T73OK⟩

def q12Shape39P2 : Tree 12 := q12Shape39T55
theorem q12Shape39P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 524288 393216 q12Shape39P2=true := q12Shape39T55OK

end Graffiti384b.EffectiveSearch.Q12
