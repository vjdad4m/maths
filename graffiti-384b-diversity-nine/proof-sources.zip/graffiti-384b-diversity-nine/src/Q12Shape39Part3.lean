import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39T84 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 550880542721 q12Shape39T84=true := by decide

private def q12Shape39T86 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076032 1124728865 q12Shape39T86=true := by decide

private def q12Shape39T87 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,5,7,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,3,5,6,7,10,11}))))))
private theorem q12Shape39T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076064 1124728833 q12Shape39T87=true := by decide

private def q12Shape39T85 : Tree 12 := .split 5 q12Shape39T86 q12Shape39T87
private theorem q12Shape39T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076032 1124728833 q12Shape39T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076032 (1124728833 ||| 2^5) q12Shape39T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756076032 ||| 2^5) 1124728833 q12Shape39T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T86OK,q12Shape39T87OK⟩

private def q12Shape39T83 : Tree 12 := .split 39 q12Shape39T84 q12Shape39T85
private theorem q12Shape39T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 1124728833 q12Shape39T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 (1124728833 ||| 2^39) q12Shape39T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262144 ||| 2^39) 1124728833 q12Shape39T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T84OK,q12Shape39T85OK⟩

private def q12Shape39T90 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262145 550880542752 q12Shape39T90=true := by decide

private def q12Shape39T91 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,5,7,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,3,5,6,7,10,11}))))))
private theorem q12Shape39T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262177 550880542720 q12Shape39T91=true := by decide

private def q12Shape39T89 : Tree 12 := .split 5 q12Shape39T90 q12Shape39T91
private theorem q12Shape39T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262145 550880542720 q12Shape39T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262145 (550880542720 ||| 2^5) q12Shape39T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262145 ||| 2^5) 550880542720 q12Shape39T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T90OK,q12Shape39T91OK⟩

private def q12Shape39T93 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,2,4,5,8,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {0,2,4,7,8,10,11}))) (.tip (.cover {2,5,6,7,8,10,11}))))))
private theorem q12Shape39T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076033 1124728864 q12Shape39T93=true := by decide

private def q12Shape39T95 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,2,4,5,9,10,11}))) (.tip (.cover {2,4,5,7,9,10,11}))) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {2,5,6,7,9,10,11})))))
private theorem q12Shape39T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076065 1124728896 q12Shape39T95=true := by decide

private def q12Shape39T97 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,4,5,7,9,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,5,6,7,9,10,11}))))
private theorem q12Shape39T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076129 1124737024 q12Shape39T97=true := by decide

private def q12Shape39T99 : Tree 12 := (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,5,6,7,8,10,11})))
private theorem q12Shape39T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756084321 1124745216 q12Shape39T99=true := by decide

private def q12Shape39T100 : Tree 12 := (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,5,10,11}))) (.tip (.cover {2,3,4,5,7,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,3,5,6,7,10,11})))
private theorem q12Shape39T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756100705 1124728832 q12Shape39T100=true := by decide

private def q12Shape39T98 : Tree 12 := .split 14 q12Shape39T99 q12Shape39T100
private theorem q12Shape39T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756084321 1124728832 q12Shape39T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756084321 (1124728832 ||| 2^14) q12Shape39T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756084321 ||| 2^14) 1124728832 q12Shape39T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T99OK,q12Shape39T100OK⟩

private def q12Shape39T96 : Tree 12 := .split 13 q12Shape39T97 q12Shape39T98
private theorem q12Shape39T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076129 1124728832 q12Shape39T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076129 (1124728832 ||| 2^13) q12Shape39T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756076129 ||| 2^13) 1124728832 q12Shape39T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T97OK,q12Shape39T98OK⟩

private def q12Shape39T94 : Tree 12 := .split 6 q12Shape39T95 q12Shape39T96
private theorem q12Shape39T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076065 1124728832 q12Shape39T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076065 (1124728832 ||| 2^6) q12Shape39T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756076065 ||| 2^6) 1124728832 q12Shape39T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T95OK,q12Shape39T96OK⟩

private def q12Shape39T92 : Tree 12 := .split 5 q12Shape39T93 q12Shape39T94
private theorem q12Shape39T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076033 1124728832 q12Shape39T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549756076033 (1124728832 ||| 2^5) q12Shape39T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549756076033 ||| 2^5) 1124728832 q12Shape39T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T93OK,q12Shape39T94OK⟩

private def q12Shape39T88 : Tree 12 := .split 39 q12Shape39T89 q12Shape39T92
private theorem q12Shape39T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262145 1124728832 q12Shape39T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262145 (1124728832 ||| 2^39) q12Shape39T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262145 ||| 2^39) 1124728832 q12Shape39T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T89OK,q12Shape39T92OK⟩

private def q12Shape39T82 : Tree 12 := .split 0 q12Shape39T83 q12Shape39T88
private theorem q12Shape39T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 1124728832 q12Shape39T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 (1124728832 ||| 2^0) q12Shape39T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262144 ||| 2^0) 1124728832 q12Shape39T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T83OK,q12Shape39T88OK⟩

private def q12Shape39T101 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11})))) (.tip (.cover {0,1,5,6,8,10,11}))))
private theorem q12Shape39T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1074003968 50987008 q12Shape39T101=true := by decide

private def q12Shape39T81 : Tree 12 := .split 30 q12Shape39T82 q12Shape39T101
private theorem q12Shape39T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 50987008 q12Shape39T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 (50987008 ||| 2^30) q12Shape39T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262144 ||| 2^30) 50987008 q12Shape39T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T82OK,q12Shape39T101OK⟩

private def q12Shape39T103 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33816576 1091174400 q12Shape39T103=true := by decide

private def q12Shape39T104 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1107558400 17432576 q12Shape39T104=true := by decide

private def q12Shape39T102 : Tree 12 := .split 30 q12Shape39T103 q12Shape39T104
private theorem q12Shape39T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33816576 17432576 q12Shape39T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33816576 (17432576 ||| 2^30) q12Shape39T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (33816576 ||| 2^30) 17432576 q12Shape39T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T103OK,q12Shape39T104OK⟩

private def q12Shape39T80 : Tree 12 := .split 25 q12Shape39T81 q12Shape39T102
private theorem q12Shape39T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 17432576 q12Shape39T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 (17432576 ||| 2^25) q12Shape39T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262144 ||| 2^25) 17432576 q12Shape39T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T81OK,q12Shape39T102OK⟩

private def q12Shape39T106 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,6,7,10,11})))) (.tip (.cover {0,1,6,7,8,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape39T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17039360 34209792 q12Shape39T106=true := by decide

private def q12Shape39T107 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape39T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 50593792 655360 q12Shape39T107=true := by decide

private def q12Shape39T105 : Tree 12 := .split 25 q12Shape39T106 q12Shape39T107
private theorem q12Shape39T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17039360 655360 q12Shape39T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17039360 (655360 ||| 2^25) q12Shape39T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (17039360 ||| 2^25) 655360 q12Shape39T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T106OK,q12Shape39T107OK⟩

private def q12Shape39T79 : Tree 12 := .split 24 q12Shape39T80 q12Shape39T105
private theorem q12Shape39T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 655360 q12Shape39T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 (655360 ||| 2^24) q12Shape39T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (262144 ||| 2^24) 655360 q12Shape39T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T80OK,q12Shape39T105OK⟩

def q12Shape39P3 : Tree 12 := q12Shape39T79
theorem q12Shape39P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 262144 655360 q12Shape39P3=true := q12Shape39T79OK

end Graffiti384b.EffectiveSearch.Q12
