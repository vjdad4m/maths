import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39T111 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 1124204544 q12Shape39T111=true := by decide

private def q12Shape39T112 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1074528256 50462720 q12Shape39T112=true := by decide

private def q12Shape39T110 : Tree 12 := .split 30 q12Shape39T111 q12Shape39T112
private theorem q12Shape39T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 50462720 q12Shape39T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 (50462720 ||| 2^30) q12Shape39T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (786432 ||| 2^30) 50462720 q12Shape39T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T111OK,q12Shape39T112OK⟩

private def q12Shape39T113 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape39T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 34340864 16908288 q12Shape39T113=true := by decide

private def q12Shape39T109 : Tree 12 := .split 25 q12Shape39T110 q12Shape39T113
private theorem q12Shape39T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 16908288 q12Shape39T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 (16908288 ||| 2^25) q12Shape39T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (786432 ||| 2^25) 16908288 q12Shape39T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T110OK,q12Shape39T113OK⟩

private def q12Shape39T115 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape39T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17563648 33685504 q12Shape39T115=true := by decide

private def q12Shape39T116 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.tip (.cover {3,4,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape39T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 51118080 131072 q12Shape39T116=true := by decide

private def q12Shape39T114 : Tree 12 := .split 25 q12Shape39T115 q12Shape39T116
private theorem q12Shape39T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17563648 131072 q12Shape39T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17563648 (131072 ||| 2^25) q12Shape39T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (17563648 ||| 2^25) 131072 q12Shape39T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T115OK,q12Shape39T116OK⟩

private def q12Shape39T108 : Tree 12 := .split 24 q12Shape39T109 q12Shape39T114
private theorem q12Shape39T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 131072 q12Shape39T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 (131072 ||| 2^24) q12Shape39T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (786432 ||| 2^24) 131072 q12Shape39T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T109OK,q12Shape39T114OK⟩

def q12Shape39P4 : Tree 12 := q12Shape39T108
theorem q12Shape39P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 786432 131072 q12Shape39P4=true := q12Shape39T108OK

end Graffiti384b.EffectiveSearch.Q12
