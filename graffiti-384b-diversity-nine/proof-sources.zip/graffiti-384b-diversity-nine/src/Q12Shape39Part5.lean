import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39T124 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 550880673793 q12Shape39T124=true := by decide

private def q12Shape39T126 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944960 1124859937 q12Shape39T126=true := by decide

private def q12Shape39T127 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {2,3,5,6,7,10,11}))))))
private theorem q12Shape39T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944992 1124859905 q12Shape39T127=true := by decide

private def q12Shape39T125 : Tree 12 := .split 5 q12Shape39T126 q12Shape39T127
private theorem q12Shape39T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944960 1124859905 q12Shape39T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944960 (1124859905 ||| 2^5) q12Shape39T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549755944960 ||| 2^5) 1124859905 q12Shape39T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T126OK,q12Shape39T127OK⟩

private def q12Shape39T123 : Tree 12 := .split 39 q12Shape39T124 q12Shape39T125
private theorem q12Shape39T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 1124859905 q12Shape39T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 (1124859905 ||| 2^39) q12Shape39T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131072 ||| 2^39) 1124859905 q12Shape39T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T124OK,q12Shape39T125OK⟩

private def q12Shape39T130 : Tree 12 := (.tip (.small 1))
private theorem q12Shape39T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131073 550880673824 q12Shape39T130=true := by decide

private def q12Shape39T131 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {2,3,5,6,7,10,11}))))))
private theorem q12Shape39T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131105 550880673792 q12Shape39T131=true := by decide

private def q12Shape39T129 : Tree 12 := .split 5 q12Shape39T130 q12Shape39T131
private theorem q12Shape39T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131073 550880673792 q12Shape39T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131073 (550880673792 ||| 2^5) q12Shape39T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131073 ||| 2^5) 550880673792 q12Shape39T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T130OK,q12Shape39T131OK⟩

private def q12Shape39T133 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,2,4,6,8,10,11}))) (.tip (.cover {0,2,4,7,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))) (.tip (.cover {2,5,6,7,8,10,11}))))))
private theorem q12Shape39T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944961 1124859936 q12Shape39T133=true := by decide

private def q12Shape39T135 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,2,4,6,9,10,11}))) (.tip (.cover {0,2,4,7,9,10,11}))) (.tip (.cover {2,4,6,7,9,10,11}))) (.tip (.cover {2,5,6,7,9,10,11})))))
private theorem q12Shape39T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944993 1124859968 q12Shape39T135=true := by decide

private def q12Shape39T137 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,4,6,7,9,10,11}))) (.tip (.cover {2,5,6,7,9,10,11}))))
private theorem q12Shape39T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755945057 1124868096 q12Shape39T137=true := by decide

private def q12Shape39T139 : Tree 12 := (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))) (.tip (.cover {2,5,6,7,8,10,11})))
private theorem q12Shape39T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755953249 1124876288 q12Shape39T139=true := by decide

private def q12Shape39T140 : Tree 12 := (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10,11})) (.tip (.cover {0,1,2,4,6,10,11}))) (.tip (.cover {0,1,2,4,7,10,11}))) (.tip (.cover {2,3,4,6,7,10,11}))) (.tip (.cover {2,3,5,6,7,10,11})))
private theorem q12Shape39T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755969633 1124859904 q12Shape39T140=true := by decide

private def q12Shape39T138 : Tree 12 := .split 14 q12Shape39T139 q12Shape39T140
private theorem q12Shape39T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755953249 1124859904 q12Shape39T138=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755953249 (1124859904 ||| 2^14) q12Shape39T139 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549755953249 ||| 2^14) 1124859904 q12Shape39T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T139OK,q12Shape39T140OK⟩

private def q12Shape39T136 : Tree 12 := .split 13 q12Shape39T137 q12Shape39T138
private theorem q12Shape39T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755945057 1124859904 q12Shape39T136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755945057 (1124859904 ||| 2^13) q12Shape39T137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549755945057 ||| 2^13) 1124859904 q12Shape39T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T137OK,q12Shape39T138OK⟩

private def q12Shape39T134 : Tree 12 := .split 6 q12Shape39T135 q12Shape39T136
private theorem q12Shape39T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944993 1124859904 q12Shape39T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944993 (1124859904 ||| 2^6) q12Shape39T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549755944993 ||| 2^6) 1124859904 q12Shape39T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T135OK,q12Shape39T136OK⟩

private def q12Shape39T132 : Tree 12 := .split 5 q12Shape39T133 q12Shape39T134
private theorem q12Shape39T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944961 1124859904 q12Shape39T132=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 549755944961 (1124859904 ||| 2^5) q12Shape39T133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (549755944961 ||| 2^5) 1124859904 q12Shape39T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T133OK,q12Shape39T134OK⟩

private def q12Shape39T128 : Tree 12 := .split 39 q12Shape39T129 q12Shape39T132
private theorem q12Shape39T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131073 1124859904 q12Shape39T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131073 (1124859904 ||| 2^39) q12Shape39T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131073 ||| 2^39) 1124859904 q12Shape39T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T129OK,q12Shape39T132OK⟩

private def q12Shape39T122 : Tree 12 := .split 0 q12Shape39T123 q12Shape39T128
private theorem q12Shape39T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 1124859904 q12Shape39T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 (1124859904 ||| 2^0) q12Shape39T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131072 ||| 2^0) 1124859904 q12Shape39T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T123OK,q12Shape39T128OK⟩

private def q12Shape39T141 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape39T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1073872896 51118080 q12Shape39T141=true := by decide

private def q12Shape39T121 : Tree 12 := .split 30 q12Shape39T122 q12Shape39T141
private theorem q12Shape39T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 51118080 q12Shape39T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 (51118080 ||| 2^30) q12Shape39T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131072 ||| 2^30) 51118080 q12Shape39T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T122OK,q12Shape39T141OK⟩

private def q12Shape39T143 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11})))) (.tip (.cover {0,1,5,6,8,10,11}))))
private theorem q12Shape39T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33685504 1091305472 q12Shape39T143=true := by decide

private def q12Shape39T144 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape39T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1107427328 17563648 q12Shape39T144=true := by decide

private def q12Shape39T142 : Tree 12 := .split 30 q12Shape39T143 q12Shape39T144
private theorem q12Shape39T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33685504 17563648 q12Shape39T142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33685504 (17563648 ||| 2^30) q12Shape39T143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (33685504 ||| 2^30) 17563648 q12Shape39T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T143OK,q12Shape39T144OK⟩

private def q12Shape39T120 : Tree 12 := .split 25 q12Shape39T121 q12Shape39T142
private theorem q12Shape39T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 17563648 q12Shape39T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 (17563648 ||| 2^25) q12Shape39T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131072 ||| 2^25) 17563648 q12Shape39T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T121OK,q12Shape39T142OK⟩

private def q12Shape39T147 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,10,11})))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape39T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16908288 1108082688 q12Shape39T147=true := by decide

private def q12Shape39T148 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape39T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1090650112 34340864 q12Shape39T148=true := by decide

private def q12Shape39T146 : Tree 12 := .split 30 q12Shape39T147 q12Shape39T148
private theorem q12Shape39T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16908288 34340864 q12Shape39T146=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16908288 (34340864 ||| 2^30) q12Shape39T147 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16908288 ||| 2^30) 34340864 q12Shape39T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T147OK,q12Shape39T148OK⟩

private def q12Shape39T149 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape39T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 50462720 786432 q12Shape39T149=true := by decide

private def q12Shape39T145 : Tree 12 := .split 25 q12Shape39T146 q12Shape39T149
private theorem q12Shape39T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16908288 786432 q12Shape39T145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 16908288 (786432 ||| 2^25) q12Shape39T146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (16908288 ||| 2^25) 786432 q12Shape39T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T146OK,q12Shape39T149OK⟩

private def q12Shape39T119 : Tree 12 := .split 24 q12Shape39T120 q12Shape39T145
private theorem q12Shape39T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 786432 q12Shape39T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 (786432 ||| 2^24) q12Shape39T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (131072 ||| 2^24) 786432 q12Shape39T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T120OK,q12Shape39T145OK⟩

def q12Shape39P5 : Tree 12 := q12Shape39T119
theorem q12Shape39P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 131072 786432 q12Shape39P5=true := q12Shape39T119OK

end Graffiti384b.EffectiveSearch.Q12
