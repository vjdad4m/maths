import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape39T153 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape39T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 1124335616 q12Shape39T153=true := by decide

private def q12Shape39T154 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape39T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1074397184 50593792 q12Shape39T154=true := by decide

private def q12Shape39T152 : Tree 12 := .split 30 q12Shape39T153 q12Shape39T154
private theorem q12Shape39T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 50593792 q12Shape39T152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 (50593792 ||| 2^30) q12Shape39T153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (655360 ||| 2^30) 50593792 q12Shape39T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T153OK,q12Shape39T154OK⟩

private def q12Shape39T155 : Tree 12 := (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11})))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape39T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 34209792 17039360 q12Shape39T155=true := by decide

private def q12Shape39T151 : Tree 12 := .split 25 q12Shape39T152 q12Shape39T155
private theorem q12Shape39T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 17039360 q12Shape39T151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 (17039360 ||| 2^25) q12Shape39T152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (655360 ||| 2^25) 17039360 q12Shape39T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T152OK,q12Shape39T155OK⟩

private def q12Shape39T158 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17432576 1107558400 q12Shape39T158=true := by decide

private def q12Shape39T159 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.tip (.cover {3,4,6,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1091174400 33816576 q12Shape39T159=true := by decide

private def q12Shape39T157 : Tree 12 := .split 30 q12Shape39T158 q12Shape39T159
private theorem q12Shape39T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17432576 33816576 q12Shape39T157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17432576 (33816576 ||| 2^30) q12Shape39T158 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (17432576 ||| 2^30) 33816576 q12Shape39T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T158OK,q12Shape39T159OK⟩

private def q12Shape39T160 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape39T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 50987008 262144 q12Shape39T160=true := by decide

private def q12Shape39T156 : Tree 12 := .split 25 q12Shape39T157 q12Shape39T160
private theorem q12Shape39T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17432576 262144 q12Shape39T156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17432576 (262144 ||| 2^25) q12Shape39T157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (17432576 ||| 2^25) 262144 q12Shape39T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T157OK,q12Shape39T160OK⟩

private def q12Shape39T150 : Tree 12 := .split 24 q12Shape39T151 q12Shape39T156
private theorem q12Shape39T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 262144 q12Shape39T150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 (262144 ||| 2^24) q12Shape39T151 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (655360 ||| 2^24) 262144 q12Shape39T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T151OK,q12Shape39T156OK⟩

def q12Shape39P6 : Tree 12 := q12Shape39T150
theorem q12Shape39P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 655360 262144 q12Shape39P6=true := q12Shape39T150OK

private def q12Shape39T166 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11})))) (.tip (.cover {0,1,4,7,8,10,11}))))
private theorem q12Shape39T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 1124597760 q12Shape39T166=true := by decide

private def q12Shape39T167 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape39T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1074135040 50855936 q12Shape39T167=true := by decide

private def q12Shape39T165 : Tree 12 := .split 30 q12Shape39T166 q12Shape39T167
private theorem q12Shape39T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 50855936 q12Shape39T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 (50855936 ||| 2^30) q12Shape39T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (393216 ||| 2^30) 50855936 q12Shape39T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T166OK,q12Shape39T167OK⟩

private def q12Shape39T169 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33947648 1091043328 q12Shape39T169=true := by decide

private def q12Shape39T170 : Tree 12 := (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.tip (.cover {3,4,7,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))))
private theorem q12Shape39T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 1107689472 17301504 q12Shape39T170=true := by decide

private def q12Shape39T168 : Tree 12 := .split 30 q12Shape39T169 q12Shape39T170
private theorem q12Shape39T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33947648 17301504 q12Shape39T168=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 33947648 (17301504 ||| 2^30) q12Shape39T169 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (33947648 ||| 2^30) 17301504 q12Shape39T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T169OK,q12Shape39T170OK⟩

private def q12Shape39T164 : Tree 12 := .split 25 q12Shape39T165 q12Shape39T168
private theorem q12Shape39T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 17301504 q12Shape39T164=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 (17301504 ||| 2^25) q12Shape39T165 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (393216 ||| 2^25) 17301504 q12Shape39T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T165OK,q12Shape39T168OK⟩

private def q12Shape39T171 : Tree 12 := (.split 25 (.split 30 (.split 0 (.split 39 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10,11}))) (.split 39 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11})))) (.tip (.cover {0,1,4,7,8,10,11})))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape39T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 17170432 524288 q12Shape39T171=true := by decide

private def q12Shape39T163 : Tree 12 := .split 24 q12Shape39T164 q12Shape39T171
private theorem q12Shape39T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 524288 q12Shape39T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 (524288 ||| 2^24) q12Shape39T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (393216 ||| 2^24) 524288 q12Shape39T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T164OK,q12Shape39T171OK⟩

private def q12Shape39T172 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape39T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 917504 0 q12Shape39T172=true := by decide

private def q12Shape39T162 : Tree 12 := .split 19 q12Shape39T163 q12Shape39T172
private theorem q12Shape39T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 0 q12Shape39T162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 (0 ||| 2^19) q12Shape39T163 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) (393216 ||| 2^19) 0 q12Shape39T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape39T163OK,q12Shape39T172OK⟩

def q12Shape39P7 : Tree 12 := q12Shape39T162
theorem q12Shape39P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,2⟩) 393216 0 q12Shape39P7=true := q12Shape39T162OK

end Graffiti384b.EffectiveSearch.Q12
