import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape3T1 : Tree 12 := (.split 9 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))))
private theorem q12Shape3T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 34376515587 q12Shape3T1=true := by decide

private def q12Shape3T3 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))
private theorem q12Shape3T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 2 34376516097 q12Shape3T3=true := by decide

private def q12Shape3T6 : Tree 12 := (.tip (.small 0))
private theorem q12Shape3T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 514 34376515597 q12Shape3T6=true := by decide

private def q12Shape3T7 : Tree 12 := (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))))) (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))) (.tip (.cover {0,1,2,5,9,10,11}))))
private theorem q12Shape3T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 522 34376515589 q12Shape3T7=true := by decide

private def q12Shape3T5 : Tree 12 := .split 3 q12Shape3T6 q12Shape3T7
private theorem q12Shape3T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 514 34376515589 q12Shape3T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 514 (34376515589 ||| 2^3) q12Shape3T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (514 ||| 2^3) 34376515589 q12Shape3T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T6OK,q12Shape3T7OK⟩

private def q12Shape3T9 : Tree 12 := (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))))) (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))) (.tip (.cover {0,1,2,6,9,10,11}))))
private theorem q12Shape3T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 518 34376515593 q12Shape3T9=true := by decide

private def q12Shape3T10 : Tree 12 := (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,7,9,10,11}))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape3T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 526 34376515585 q12Shape3T10=true := by decide

private def q12Shape3T8 : Tree 12 := .split 3 q12Shape3T9 q12Shape3T10
private theorem q12Shape3T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 518 34376515585 q12Shape3T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 518 (34376515585 ||| 2^3) q12Shape3T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (518 ||| 2^3) 34376515585 q12Shape3T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T9OK,q12Shape3T10OK⟩

private def q12Shape3T4 : Tree 12 := .split 2 q12Shape3T5 q12Shape3T8
private theorem q12Shape3T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 514 34376515585 q12Shape3T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 514 (34376515585 ||| 2^2) q12Shape3T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (514 ||| 2^2) 34376515585 q12Shape3T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T5OK,q12Shape3T8OK⟩

private def q12Shape3T2 : Tree 12 := .split 9 q12Shape3T3 q12Shape3T4
private theorem q12Shape3T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 2 34376515585 q12Shape3T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 2 (34376515585 ||| 2^9) q12Shape3T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (2 ||| 2^9) 34376515585 q12Shape3T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T3OK,q12Shape3T4OK⟩

private def q12Shape3T0 : Tree 12 := .split 1 q12Shape3T1 q12Shape3T2
private theorem q12Shape3T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 34376515585 q12Shape3T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 (34376515585 ||| 2^1) q12Shape3T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (0 ||| 2^1) 34376515585 q12Shape3T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T1OK,q12Shape3T2OK⟩

def q12Shape3P0 : Tree 12 := q12Shape3T0
theorem q12Shape3P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 0 34376515585 q12Shape3P0=true := q12Shape3T0OK

private def q12Shape3T12 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))
private theorem q12Shape3T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 1 34376516098 q12Shape3T12=true := by decide

private def q12Shape3T15 : Tree 12 := (.tip (.small 0))
private theorem q12Shape3T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 513 34376515598 q12Shape3T15=true := by decide

private def q12Shape3T16 : Tree 12 := (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))))) (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))) (.tip (.cover {0,1,2,5,9,10,11}))))
private theorem q12Shape3T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 521 34376515590 q12Shape3T16=true := by decide

private def q12Shape3T14 : Tree 12 := .split 3 q12Shape3T15 q12Shape3T16
private theorem q12Shape3T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 513 34376515590 q12Shape3T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 513 (34376515590 ||| 2^3) q12Shape3T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (513 ||| 2^3) 34376515590 q12Shape3T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T15OK,q12Shape3T16OK⟩

private def q12Shape3T18 : Tree 12 := (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))))) (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))) (.tip (.cover {0,1,2,6,9,10,11}))))
private theorem q12Shape3T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 517 34376515594 q12Shape3T18=true := by decide

private def q12Shape3T19 : Tree 12 := (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,7,9,10,11}))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape3T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 525 34376515586 q12Shape3T19=true := by decide

private def q12Shape3T17 : Tree 12 := .split 3 q12Shape3T18 q12Shape3T19
private theorem q12Shape3T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 517 34376515586 q12Shape3T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 517 (34376515586 ||| 2^3) q12Shape3T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (517 ||| 2^3) 34376515586 q12Shape3T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T18OK,q12Shape3T19OK⟩

private def q12Shape3T13 : Tree 12 := .split 2 q12Shape3T14 q12Shape3T17
private theorem q12Shape3T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 513 34376515586 q12Shape3T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 513 (34376515586 ||| 2^2) q12Shape3T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (513 ||| 2^2) 34376515586 q12Shape3T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T14OK,q12Shape3T17OK⟩

private def q12Shape3T11 : Tree 12 := .split 9 q12Shape3T12 q12Shape3T13
private theorem q12Shape3T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 1 34376515586 q12Shape3T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 1 (34376515586 ||| 2^9) q12Shape3T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (1 ||| 2^9) 34376515586 q12Shape3T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T12OK,q12Shape3T13OK⟩

def q12Shape3P1 : Tree 12 := q12Shape3T11
theorem q12Shape3P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 1 34376515586 q12Shape3P1=true := q12Shape3T11OK

end Graffiti384b.EffectiveSearch.Q12
