import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape3T23 : Tree 12 := (.tip (.small 0))
private theorem q12Shape3T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 34376516108 q12Shape3T23=true := by decide

private def q12Shape3T25 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11}))))))
private theorem q12Shape3T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 11 34376516116 q12Shape3T25=true := by decide

private def q12Shape3T26 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11}))))) (.tip (.cover {0,1,2,5,9,10,11})))
private theorem q12Shape3T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 27 34376516100 q12Shape3T26=true := by decide

private def q12Shape3T24 : Tree 12 := .split 4 q12Shape3T25 q12Shape3T26
private theorem q12Shape3T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 11 34376516100 q12Shape3T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 11 (34376516100 ||| 2^4) q12Shape3T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (11 ||| 2^4) 34376516100 q12Shape3T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T25OK,q12Shape3T26OK⟩

private def q12Shape3T22 : Tree 12 := .split 3 q12Shape3T23 q12Shape3T24
private theorem q12Shape3T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 34376516100 q12Shape3T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 (34376516100 ||| 2^3) q12Shape3T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (3 ||| 2^3) 34376516100 q12Shape3T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T23OK,q12Shape3T24OK⟩

private def q12Shape3T29 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11}))))))
private theorem q12Shape3T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 7 34376516120 q12Shape3T29=true := by decide

private def q12Shape3T30 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11}))))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape3T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 23 34376516104 q12Shape3T30=true := by decide

private def q12Shape3T28 : Tree 12 := .split 4 q12Shape3T29 q12Shape3T30
private theorem q12Shape3T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 7 34376516104 q12Shape3T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 7 (34376516104 ||| 2^4) q12Shape3T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (7 ||| 2^4) 34376516104 q12Shape3T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T29OK,q12Shape3T30OK⟩

private def q12Shape3T31 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape3T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 15 34376516096 q12Shape3T31=true := by decide

private def q12Shape3T27 : Tree 12 := .split 3 q12Shape3T28 q12Shape3T31
private theorem q12Shape3T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 7 34376516096 q12Shape3T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 7 (34376516096 ||| 2^3) q12Shape3T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (7 ||| 2^3) 34376516096 q12Shape3T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T28OK,q12Shape3T31OK⟩

private def q12Shape3T21 : Tree 12 := .split 2 q12Shape3T22 q12Shape3T27
private theorem q12Shape3T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 34376516096 q12Shape3T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 (34376516096 ||| 2^2) q12Shape3T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (3 ||| 2^2) 34376516096 q12Shape3T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T22OK,q12Shape3T27OK⟩

private def q12Shape3T35 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))))
private theorem q12Shape3T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 515 34376515612 q12Shape3T35=true := by decide

private def q12Shape3T36 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))) (.tip (.cover {1,2,5,6,9,10,11})))
private theorem q12Shape3T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 531 34376515596 q12Shape3T36=true := by decide

private def q12Shape3T34 : Tree 12 := .split 4 q12Shape3T35 q12Shape3T36
private theorem q12Shape3T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 515 34376515596 q12Shape3T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 515 (34376515596 ||| 2^4) q12Shape3T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (515 ||| 2^4) 34376515596 q12Shape3T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T35OK,q12Shape3T36OK⟩

private def q12Shape3T39 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10,11}))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,6,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape3T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 523 34376515636 q12Shape3T39=true := by decide

private def q12Shape3T40 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {1,2,3,5,9,10,11})))) (.split 11 (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {0,2,3,7,9,10,11}))) (.tip (.cover {0,1,2,3,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape3T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 555 34376515604 q12Shape3T40=true := by decide

private def q12Shape3T38 : Tree 12 := .split 5 q12Shape3T39 q12Shape3T40
private theorem q12Shape3T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 523 34376515604 q12Shape3T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 523 (34376515604 ||| 2^5) q12Shape3T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (523 ||| 2^5) 34376515604 q12Shape3T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T39OK,q12Shape3T40OK⟩

private def q12Shape3T42 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {1,2,3,5,9,10,11}))) (.tip (.cover {2,3,5,8,9,10,11})))) (.split 11 (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,2,3,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape3T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 539 34376515620 q12Shape3T42=true := by decide

private def q12Shape3T43 : Tree 12 := (.tip (.cover {0,1,2,5,9,10,11}))
private theorem q12Shape3T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 571 34376515588 q12Shape3T43=true := by decide

private def q12Shape3T41 : Tree 12 := .split 5 q12Shape3T42 q12Shape3T43
private theorem q12Shape3T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 539 34376515588 q12Shape3T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 539 (34376515588 ||| 2^5) q12Shape3T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (539 ||| 2^5) 34376515588 q12Shape3T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T42OK,q12Shape3T43OK⟩

private def q12Shape3T37 : Tree 12 := .split 4 q12Shape3T38 q12Shape3T41
private theorem q12Shape3T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 523 34376515588 q12Shape3T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 523 (34376515588 ||| 2^4) q12Shape3T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (523 ||| 2^4) 34376515588 q12Shape3T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T38OK,q12Shape3T41OK⟩

private def q12Shape3T33 : Tree 12 := .split 3 q12Shape3T34 q12Shape3T37
private theorem q12Shape3T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 515 34376515588 q12Shape3T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 515 (34376515588 ||| 2^3) q12Shape3T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (515 ||| 2^3) 34376515588 q12Shape3T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T34OK,q12Shape3T37OK⟩

private def q12Shape3T47 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10,11}))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,6,9,10,11})))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape3T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 519 34376515640 q12Shape3T47=true := by decide

private def q12Shape3T48 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {0,2,3,7,9,10,11}))) (.tip (.cover {0,1,2,3,9,10,11})))) (.split 11 (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {2,3,6,7,9,10,11}))) (.tip (.cover {1,2,3,6,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape3T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 551 34376515608 q12Shape3T48=true := by decide

private def q12Shape3T46 : Tree 12 := .split 5 q12Shape3T47 q12Shape3T48
private theorem q12Shape3T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 519 34376515608 q12Shape3T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 519 (34376515608 ||| 2^5) q12Shape3T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (519 ||| 2^5) 34376515608 q12Shape3T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T47OK,q12Shape3T48OK⟩

private def q12Shape3T50 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,2,3,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))) (.split 11 (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {1,2,3,6,9,10,11}))) (.tip (.cover {2,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape3T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 535 34376515624 q12Shape3T50=true := by decide

private def q12Shape3T51 : Tree 12 := (.tip (.cover {0,1,2,6,9,10,11}))
private theorem q12Shape3T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 567 34376515592 q12Shape3T51=true := by decide

private def q12Shape3T49 : Tree 12 := .split 5 q12Shape3T50 q12Shape3T51
private theorem q12Shape3T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 535 34376515592 q12Shape3T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 535 (34376515592 ||| 2^5) q12Shape3T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (535 ||| 2^5) 34376515592 q12Shape3T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T50OK,q12Shape3T51OK⟩

private def q12Shape3T45 : Tree 12 := .split 4 q12Shape3T46 q12Shape3T49
private theorem q12Shape3T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 519 34376515592 q12Shape3T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 519 (34376515592 ||| 2^4) q12Shape3T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (519 ||| 2^4) 34376515592 q12Shape3T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T46OK,q12Shape3T49OK⟩

private def q12Shape3T52 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape3T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 527 34376515584 q12Shape3T52=true := by decide

private def q12Shape3T44 : Tree 12 := .split 3 q12Shape3T45 q12Shape3T52
private theorem q12Shape3T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 519 34376515584 q12Shape3T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 519 (34376515584 ||| 2^3) q12Shape3T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (519 ||| 2^3) 34376515584 q12Shape3T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T45OK,q12Shape3T52OK⟩

private def q12Shape3T32 : Tree 12 := .split 2 q12Shape3T33 q12Shape3T44
private theorem q12Shape3T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 515 34376515584 q12Shape3T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 515 (34376515584 ||| 2^2) q12Shape3T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (515 ||| 2^2) 34376515584 q12Shape3T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T33OK,q12Shape3T44OK⟩

private def q12Shape3T20 : Tree 12 := .split 9 q12Shape3T21 q12Shape3T32
private theorem q12Shape3T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 34376515584 q12Shape3T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 (34376515584 ||| 2^9) q12Shape3T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (3 ||| 2^9) 34376515584 q12Shape3T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T21OK,q12Shape3T32OK⟩

def q12Shape3P2 : Tree 12 := q12Shape3T20
theorem q12Shape3P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 3 34376515584 q12Shape3P2=true := q12Shape3T20OK

end Graffiti384b.EffectiveSearch.Q12
