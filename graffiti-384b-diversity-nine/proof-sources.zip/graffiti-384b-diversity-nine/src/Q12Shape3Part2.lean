import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape3T57 : Tree 12 := (.split 9 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10,11})))))
private theorem q12Shape3T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738368 16777219 q12Shape3T57=true := by decide

private def q12Shape3T59 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10,11}))))
private theorem q12Shape3T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738370 16777729 q12Shape3T59=true := by decide

private def q12Shape3T62 : Tree 12 := (.tip (.small 0))
private theorem q12Shape3T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738882 16777229 q12Shape3T62=true := by decide

private def q12Shape3T63 : Tree 12 := (.split 4 (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.split 10 (.tip (.small 0)) (.tip (.cover {0,2,3,7,9,10,11})))) (.split 5 (.split 10 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))))
private theorem q12Shape3T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738890 16777221 q12Shape3T63=true := by decide

private def q12Shape3T61 : Tree 12 := .split 3 q12Shape3T62 q12Shape3T63
private theorem q12Shape3T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738882 16777221 q12Shape3T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738882 (16777221 ||| 2^3) q12Shape3T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738882 ||| 2^3) 16777221 q12Shape3T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T62OK,q12Shape3T63OK⟩

private def q12Shape3T65 : Tree 12 := (.split 4 (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.split 10 (.tip (.small 0)) (.tip (.cover {2,3,6,7,9,10,11})))) (.split 5 (.split 10 (.tip (.small 0)) (.tip (.cover {2,3,6,8,9,10,11}))) (.tip (.cover {0,1,2,6,9,10,11}))))
private theorem q12Shape3T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738886 16777225 q12Shape3T65=true := by decide

private def q12Shape3T66 : Tree 12 := (.tip (.cover {0,1,2,7,9,10,11}))
private theorem q12Shape3T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738894 16777217 q12Shape3T66=true := by decide

private def q12Shape3T64 : Tree 12 := .split 3 q12Shape3T65 q12Shape3T66
private theorem q12Shape3T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738886 16777217 q12Shape3T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738886 (16777217 ||| 2^3) q12Shape3T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738886 ||| 2^3) 16777217 q12Shape3T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T65OK,q12Shape3T66OK⟩

private def q12Shape3T60 : Tree 12 := .split 2 q12Shape3T61 q12Shape3T64
private theorem q12Shape3T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738882 16777217 q12Shape3T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738882 (16777217 ||| 2^2) q12Shape3T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738882 ||| 2^2) 16777217 q12Shape3T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T61OK,q12Shape3T64OK⟩

private def q12Shape3T58 : Tree 12 := .split 9 q12Shape3T59 q12Shape3T60
private theorem q12Shape3T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738370 16777217 q12Shape3T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738370 (16777217 ||| 2^9) q12Shape3T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738370 ||| 2^9) 16777217 q12Shape3T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T59OK,q12Shape3T60OK⟩

private def q12Shape3T56 : Tree 12 := .split 1 q12Shape3T57 q12Shape3T58
private theorem q12Shape3T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738368 16777217 q12Shape3T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738368 (16777217 ||| 2^1) q12Shape3T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738368 ||| 2^1) 16777217 q12Shape3T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T57OK,q12Shape3T58OK⟩

private def q12Shape3T69 : Tree 12 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10,11}))))
private theorem q12Shape3T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738369 16777730 q12Shape3T69=true := by decide

private def q12Shape3T72 : Tree 12 := (.tip (.small 0))
private theorem q12Shape3T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738881 16777230 q12Shape3T72=true := by decide

private def q12Shape3T73 : Tree 12 := (.split 4 (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.split 10 (.tip (.small 0)) (.tip (.cover {0,2,3,7,9,10,11})))) (.split 5 (.split 10 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,2,5,9,10,11}))))
private theorem q12Shape3T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738889 16777222 q12Shape3T73=true := by decide

private def q12Shape3T71 : Tree 12 := .split 3 q12Shape3T72 q12Shape3T73
private theorem q12Shape3T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738881 16777222 q12Shape3T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738881 (16777222 ||| 2^3) q12Shape3T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738881 ||| 2^3) 16777222 q12Shape3T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T72OK,q12Shape3T73OK⟩

private def q12Shape3T76 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))))
private theorem q12Shape3T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738885 16777242 q12Shape3T76=true := by decide

private def q12Shape3T77 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.tip (.cover {0,1,2,6,9,10,11})))
private theorem q12Shape3T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738901 16777226 q12Shape3T77=true := by decide

private def q12Shape3T75 : Tree 12 := .split 4 q12Shape3T76 q12Shape3T77
private theorem q12Shape3T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738885 16777226 q12Shape3T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738885 (16777226 ||| 2^4) q12Shape3T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738885 ||| 2^4) 16777226 q12Shape3T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T76OK,q12Shape3T77OK⟩

private def q12Shape3T78 : Tree 12 := (.tip (.cover {0,1,2,7,9,10,11}))
private theorem q12Shape3T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738893 16777218 q12Shape3T78=true := by decide

private def q12Shape3T74 : Tree 12 := .split 3 q12Shape3T75 q12Shape3T78
private theorem q12Shape3T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738885 16777218 q12Shape3T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738885 (16777218 ||| 2^3) q12Shape3T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738885 ||| 2^3) 16777218 q12Shape3T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T75OK,q12Shape3T78OK⟩

private def q12Shape3T70 : Tree 12 := .split 2 q12Shape3T71 q12Shape3T74
private theorem q12Shape3T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738881 16777218 q12Shape3T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738881 (16777218 ||| 2^2) q12Shape3T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738881 ||| 2^2) 16777218 q12Shape3T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T71OK,q12Shape3T74OK⟩

private def q12Shape3T68 : Tree 12 := .split 9 q12Shape3T69 q12Shape3T70
private theorem q12Shape3T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738369 16777218 q12Shape3T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738369 (16777218 ||| 2^9) q12Shape3T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738369 ||| 2^9) 16777218 q12Shape3T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T69OK,q12Shape3T70OK⟩

private def q12Shape3T81 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))))
private theorem q12Shape3T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738371 16777732 q12Shape3T81=true := by decide

private def q12Shape3T82 : Tree 12 := (.split 3 (.split 4 (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.tip (.cover {0,2,6,7,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,1,2,7,9,10,11})))
private theorem q12Shape3T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738375 16777728 q12Shape3T82=true := by decide

private def q12Shape3T80 : Tree 12 := .split 2 q12Shape3T81 q12Shape3T82
private theorem q12Shape3T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738371 16777728 q12Shape3T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738371 (16777728 ||| 2^2) q12Shape3T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738371 ||| 2^2) 16777728 q12Shape3T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T81OK,q12Shape3T82OK⟩

private def q12Shape3T86 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))))
private theorem q12Shape3T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738883 16777244 q12Shape3T86=true := by decide

private def q12Shape3T87 : Tree 12 := (.split 5 (.split 10 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10,11})))) (.tip (.cover {1,2,5,6,9,10,11})))
private theorem q12Shape3T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738899 16777228 q12Shape3T87=true := by decide

private def q12Shape3T85 : Tree 12 := .split 4 q12Shape3T86 q12Shape3T87
private theorem q12Shape3T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738883 16777228 q12Shape3T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738883 (16777228 ||| 2^4) q12Shape3T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738883 ||| 2^4) 16777228 q12Shape3T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T86OK,q12Shape3T87OK⟩

private def q12Shape3T90 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {2,3,5,8,9,10,11})))) (.split 11 (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {0,2,3,7,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,3,7,9,10,11}))))
private theorem q12Shape3T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738891 16777268 q12Shape3T90=true := by decide

private def q12Shape3T91 : Tree 12 := (.tip (.cover {0,2,5,7,9,10,11}))
private theorem q12Shape3T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738923 16777236 q12Shape3T91=true := by decide

private def q12Shape3T89 : Tree 12 := .split 5 q12Shape3T90 q12Shape3T91
private theorem q12Shape3T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738891 16777236 q12Shape3T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738891 (16777236 ||| 2^5) q12Shape3T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738891 ||| 2^5) 16777236 q12Shape3T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T90OK,q12Shape3T91OK⟩

private def q12Shape3T92 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape3T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738907 16777220 q12Shape3T92=true := by decide

private def q12Shape3T88 : Tree 12 := .split 4 q12Shape3T89 q12Shape3T92
private theorem q12Shape3T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738891 16777220 q12Shape3T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738891 (16777220 ||| 2^4) q12Shape3T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738891 ||| 2^4) 16777220 q12Shape3T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T89OK,q12Shape3T92OK⟩

private def q12Shape3T84 : Tree 12 := .split 3 q12Shape3T85 q12Shape3T88
private theorem q12Shape3T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738883 16777220 q12Shape3T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738883 (16777220 ||| 2^3) q12Shape3T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738883 ||| 2^3) 16777220 q12Shape3T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T85OK,q12Shape3T88OK⟩

private def q12Shape3T96 : Tree 12 := (.split 10 (.split 11 (.tip (.small 0)) (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {0,2,3,7,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))) (.split 11 (.split 12 (.split 13 (.tip (.small 1)) (.tip (.cover {2,3,6,7,9,10,11}))) (.tip (.cover {2,3,6,8,9,10,11}))) (.tip (.cover {0,1,3,7,9,10,11}))))
private theorem q12Shape3T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738887 16777272 q12Shape3T96=true := by decide

private def q12Shape3T97 : Tree 12 := (.tip (.cover {0,2,6,7,9,10,11}))
private theorem q12Shape3T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738919 16777240 q12Shape3T97=true := by decide

private def q12Shape3T95 : Tree 12 := .split 5 q12Shape3T96 q12Shape3T97
private theorem q12Shape3T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738887 16777240 q12Shape3T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738887 (16777240 ||| 2^5) q12Shape3T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738887 ||| 2^5) 16777240 q12Shape3T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T96OK,q12Shape3T97OK⟩

private def q12Shape3T98 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape3T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738903 16777224 q12Shape3T98=true := by decide

private def q12Shape3T94 : Tree 12 := .split 4 q12Shape3T95 q12Shape3T98
private theorem q12Shape3T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738887 16777224 q12Shape3T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738887 (16777224 ||| 2^4) q12Shape3T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738887 ||| 2^4) 16777224 q12Shape3T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T95OK,q12Shape3T98OK⟩

private def q12Shape3T99 : Tree 12 := (.tip (.cover {0,1,2,7,9,10,11}))
private theorem q12Shape3T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738895 16777216 q12Shape3T99=true := by decide

private def q12Shape3T93 : Tree 12 := .split 3 q12Shape3T94 q12Shape3T99
private theorem q12Shape3T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738887 16777216 q12Shape3T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738887 (16777216 ||| 2^3) q12Shape3T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738887 ||| 2^3) 16777216 q12Shape3T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T94OK,q12Shape3T99OK⟩

private def q12Shape3T83 : Tree 12 := .split 2 q12Shape3T84 q12Shape3T93
private theorem q12Shape3T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738883 16777216 q12Shape3T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738883 (16777216 ||| 2^2) q12Shape3T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738883 ||| 2^2) 16777216 q12Shape3T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T84OK,q12Shape3T93OK⟩

private def q12Shape3T79 : Tree 12 := .split 9 q12Shape3T80 q12Shape3T83
private theorem q12Shape3T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738371 16777216 q12Shape3T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738371 (16777216 ||| 2^9) q12Shape3T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738371 ||| 2^9) 16777216 q12Shape3T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T80OK,q12Shape3T83OK⟩

private def q12Shape3T67 : Tree 12 := .split 1 q12Shape3T68 q12Shape3T79
private theorem q12Shape3T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738369 16777216 q12Shape3T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738369 (16777216 ||| 2^1) q12Shape3T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738369 ||| 2^1) 16777216 q12Shape3T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T68OK,q12Shape3T79OK⟩

private def q12Shape3T55 : Tree 12 := .split 0 q12Shape3T56 q12Shape3T67
private theorem q12Shape3T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738368 16777216 q12Shape3T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738368 (16777216 ||| 2^0) q12Shape3T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) (34359738368 ||| 2^0) 16777216 q12Shape3T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape3T56OK,q12Shape3T67OK⟩

def q12Shape3P3 : Tree 12 := q12Shape3T55
theorem q12Shape3P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,3⟩) 34359738368 16777216 q12Shape3P3=true := q12Shape3T55OK

end Graffiti384b.EffectiveSearch.Q12
