import Q12Shape4Part0
import Q12Shape4Part1
import Q12Shape4Part2
import Q12Shape4Part3
import Q12Shape4Part4

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape4M44 : Tree 12 := .split 1 q12Shape4P0 q12Shape4P1
private theorem q12Shape4M44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 1 q12Shape4M44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 (1 ||| 2^1) q12Shape4P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (0 ||| 2^1) 1 q12Shape4P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4P0OK,q12Shape4P1OK⟩
private def q12Shape4M116 : Tree 12 := .split 2 q12Shape4P3 q12Shape4P4
private theorem q12Shape4M116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 0 q12Shape4M116=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 (0 ||| 2^2) q12Shape4P3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (3 ||| 2^2) 0 q12Shape4P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4P3OK,q12Shape4P4OK⟩
private def q12Shape4M117 : Tree 12 := .split 1 q12Shape4P2 q12Shape4M116
private theorem q12Shape4M117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1 0 q12Shape4M117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1 (0 ||| 2^1) q12Shape4P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1 ||| 2^1) 0 q12Shape4M116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4P2OK,q12Shape4M116OK⟩
private def q12Shape4M118 : Tree 12 := .split 0 q12Shape4M44 q12Shape4M117
private theorem q12Shape4M118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 0 q12Shape4M118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 (0 ||| 2^0) q12Shape4M44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (0 ||| 2^0) 0 q12Shape4M117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4M44OK,q12Shape4M117OK⟩

theorem q12Shape4_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 4) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 4) b) (adj 12 (forms 4) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) adj_mono b H q12Shape4M118 q12Shape4M118OK

#print axioms q12Shape4_cover

end Graffiti384b.EffectiveSearch.Q12
