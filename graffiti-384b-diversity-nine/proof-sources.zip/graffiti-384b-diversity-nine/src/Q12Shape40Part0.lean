import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape40T9 : Tree 12 := (.tip (.cover {0,2,3,4,8,10,11}))
private theorem q12Shape40T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 111652372480 q12Shape40T9=true := by decide

private def q12Shape40T12 : Tree 12 := (.split 37 (.tip (.cover {0,2,3,4,8,9,11})) (.split 38 (.tip (.cover {0,2,3,4,8,9,10})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 43 (.tip (.cover {0,2,3,4,7,8,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))))
private theorem q12Shape40T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 68719476736 68702699520 q12Shape40T12=true := by decide

private def q12Shape40T13 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape40T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 85899345920 51522830336 q12Shape40T13=true := by decide

private def q12Shape40T11 : Tree 12 := .split 34 q12Shape40T12 q12Shape40T13
private theorem q12Shape40T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 68719476736 51522830336 q12Shape40T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 68719476736 (51522830336 ||| 2^34) q12Shape40T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (68719476736 ||| 2^34) 51522830336 q12Shape40T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T12OK,q12Shape40T13OK⟩

private def q12Shape40T14 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape40T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 77309411328 42932895744 q12Shape40T14=true := by decide

private def q12Shape40T10 : Tree 12 := .split 33 q12Shape40T11 q12Shape40T14
private theorem q12Shape40T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 68719476736 42932895744 q12Shape40T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 68719476736 (42932895744 ||| 2^33) q12Shape40T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (68719476736 ||| 2^33) 42932895744 q12Shape40T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T11OK,q12Shape40T14OK⟩

private def q12Shape40T8 : Tree 12 := .split 36 q12Shape40T9 q12Shape40T10
private theorem q12Shape40T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 42932895744 q12Shape40T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (42932895744 ||| 2^36) q12Shape40T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^36) 42932895744 q12Shape40T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T9OK,q12Shape40T10OK⟩

private def q12Shape40T18 : Tree 12 := (.tip (.cover {0,2,3,4,8,9,11}))
private theorem q12Shape40T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4294967296 253386293248 q12Shape40T18=true := by decide

private def q12Shape40T19 : Tree 12 := (.split 38 (.split 34 (.tip (.cover {0,2,3,4,8,9,10})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {0,2,3,4,6,8,11})) (.split 43 (.tip (.cover {0,2,3,4,6,8,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape40T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 12884901888 244796358656 q12Shape40T19=true := by decide

private def q12Shape40T17 : Tree 12 := .split 33 q12Shape40T18 q12Shape40T19
private theorem q12Shape40T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4294967296 244796358656 q12Shape40T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4294967296 (244796358656 ||| 2^33) q12Shape40T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (4294967296 ||| 2^33) 244796358656 q12Shape40T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T18OK,q12Shape40T19OK⟩

private def q12Shape40T20 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape40T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 141733920768 107357405184 q12Shape40T20=true := by decide

private def q12Shape40T16 : Tree 12 := .split 37 q12Shape40T17 q12Shape40T20
private theorem q12Shape40T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4294967296 107357405184 q12Shape40T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4294967296 (107357405184 ||| 2^37) q12Shape40T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (4294967296 ||| 2^37) 107357405184 q12Shape40T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T17OK,q12Shape40T20OK⟩

private def q12Shape40T21 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape40T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 73014444032 38637928448 q12Shape40T21=true := by decide

private def q12Shape40T15 : Tree 12 := .split 36 q12Shape40T16 q12Shape40T21
private theorem q12Shape40T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4294967296 38637928448 q12Shape40T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4294967296 (38637928448 ||| 2^36) q12Shape40T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (4294967296 ||| 2^36) 38637928448 q12Shape40T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T16OK,q12Shape40T21OK⟩

private def q12Shape40T7 : Tree 12 := .split 32 q12Shape40T8 q12Shape40T15
private theorem q12Shape40T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 38637928448 q12Shape40T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (38637928448 ||| 2^32) q12Shape40T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^32) 38637928448 q12Shape40T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T8OK,q12Shape40T15OK⟩

private def q12Shape40T22 : Tree 12 := (.split 32 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape40T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 536870912 38101057536 q12Shape40T22=true := by decide

private def q12Shape40T6 : Tree 12 := .split 29 q12Shape40T7 q12Shape40T22
private theorem q12Shape40T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 38101057536 q12Shape40T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (38101057536 ||| 2^29) q12Shape40T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^29) 38101057536 q12Shape40T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T7OK,q12Shape40T22OK⟩

private def q12Shape40T23 : Tree 12 := (.split 32 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape40T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 268435456 37832622080 q12Shape40T23=true := by decide

private def q12Shape40T5 : Tree 12 := .split 28 q12Shape40T6 q12Shape40T23
private theorem q12Shape40T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 37832622080 q12Shape40T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (37832622080 ||| 2^28) q12Shape40T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^28) 37832622080 q12Shape40T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T6OK,q12Shape40T23OK⟩

private def q12Shape40T30 : Tree 12 := (.tip (.cover {0,2,3,4,8,9,11}))
private theorem q12Shape40T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 274190041088 q12Shape40T30=true := by decide

private def q12Shape40T31 : Tree 12 := (.split 38 (.split 29 (.tip (.cover {0,2,3,4,8,9,10})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {0,2,3,4,5,8,11})) (.split 43 (.tip (.cover {0,2,3,4,5,8,10})) (.tip (.cover {0,1,5,6,7,8,9})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape40T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 402653184 273921605632 q12Shape40T31=true := by decide

private def q12Shape40T29 : Tree 12 := .split 28 q12Shape40T30 q12Shape40T31
private theorem q12Shape40T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 273921605632 q12Shape40T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 (273921605632 ||| 2^28) q12Shape40T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (134217728 ||| 2^28) 273921605632 q12Shape40T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T30OK,q12Shape40T31OK⟩

private def q12Shape40T32 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape40T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 137573171200 136482652160 q12Shape40T32=true := by decide

private def q12Shape40T28 : Tree 12 := .split 37 q12Shape40T29 q12Shape40T32
private theorem q12Shape40T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 136482652160 q12Shape40T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 (136482652160 ||| 2^37) q12Shape40T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (134217728 ||| 2^37) 136482652160 q12Shape40T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T29OK,q12Shape40T32OK⟩

private def q12Shape40T33 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape40T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 68853694464 67763175424 q12Shape40T33=true := by decide

private def q12Shape40T27 : Tree 12 := .split 36 q12Shape40T28 q12Shape40T33
private theorem q12Shape40T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 67763175424 q12Shape40T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 (67763175424 ||| 2^36) q12Shape40T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (134217728 ||| 2^36) 67763175424 q12Shape40T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T28OK,q12Shape40T33OK⟩

private def q12Shape40T34 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape40T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 17314086912 50583306240 q12Shape40T34=true := by decide

private def q12Shape40T26 : Tree 12 := .split 34 q12Shape40T27 q12Shape40T34
private theorem q12Shape40T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 50583306240 q12Shape40T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 (50583306240 ||| 2^34) q12Shape40T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (134217728 ||| 2^34) 50583306240 q12Shape40T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T27OK,q12Shape40T34OK⟩

private def q12Shape40T35 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape40T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 8724152320 41993371648 q12Shape40T35=true := by decide

private def q12Shape40T25 : Tree 12 := .split 33 q12Shape40T26 q12Shape40T35
private theorem q12Shape40T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 41993371648 q12Shape40T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 (41993371648 ||| 2^33) q12Shape40T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (134217728 ||| 2^33) 41993371648 q12Shape40T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T26OK,q12Shape40T35OK⟩

private def q12Shape40T36 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape40T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 4429185024 37698404352 q12Shape40T36=true := by decide

private def q12Shape40T24 : Tree 12 := .split 32 q12Shape40T25 q12Shape40T36
private theorem q12Shape40T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 37698404352 q12Shape40T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 134217728 (37698404352 ||| 2^32) q12Shape40T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (134217728 ||| 2^32) 37698404352 q12Shape40T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T25OK,q12Shape40T36OK⟩

private def q12Shape40T4 : Tree 12 := .split 27 q12Shape40T5 q12Shape40T24
private theorem q12Shape40T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 37698404352 q12Shape40T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (37698404352 ||| 2^27) q12Shape40T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^27) 37698404352 q12Shape40T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T5OK,q12Shape40T24OK⟩

private def q12Shape40T38 : Tree 12 := (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape40T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 34359738368 3472883712 q12Shape40T38=true := by decide

private def q12Shape40T39 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape40T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 34493956096 3338665984 q12Shape40T39=true := by decide

private def q12Shape40T37 : Tree 12 := .split 27 q12Shape40T38 q12Shape40T39
private theorem q12Shape40T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 34359738368 3338665984 q12Shape40T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 34359738368 (3338665984 ||| 2^27) q12Shape40T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (34359738368 ||| 2^27) 3338665984 q12Shape40T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T38OK,q12Shape40T39OK⟩

private def q12Shape40T3 : Tree 12 := .split 35 q12Shape40T4 q12Shape40T37
private theorem q12Shape40T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 3338665984 q12Shape40T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (3338665984 ||| 2^35) q12Shape40T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^35) 3338665984 q12Shape40T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T4OK,q12Shape40T37OK⟩

private def q12Shape40T41 : Tree 12 := (.split 27 (.split 28 (.split 29 (.split 36 (.split 32 (.tip (.cover {0,2,3,4,8,10,11})) (.split 37 (.split 42 (.tip (.cover {0,2,3,4,6,8,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape40T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 2147483648 35550920704 q12Shape40T41=true := by decide

private def q12Shape40T42 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape40T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 36507222016 1191182336 q12Shape40T42=true := by decide

private def q12Shape40T40 : Tree 12 := .split 35 q12Shape40T41 q12Shape40T42
private theorem q12Shape40T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 2147483648 1191182336 q12Shape40T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 2147483648 (1191182336 ||| 2^35) q12Shape40T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (2147483648 ||| 2^35) 1191182336 q12Shape40T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T41OK,q12Shape40T42OK⟩

private def q12Shape40T2 : Tree 12 := .split 31 q12Shape40T3 q12Shape40T40
private theorem q12Shape40T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 1191182336 q12Shape40T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (1191182336 ||| 2^31) q12Shape40T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^31) 1191182336 q12Shape40T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T3OK,q12Shape40T40OK⟩

private def q12Shape40T45 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 36 (.split 27 (.tip (.cover {0,2,3,4,8,10,11})) (.split 37 (.split 42 (.tip (.cover {0,2,3,4,5,8,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape40T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 67108864 37631295488 q12Shape40T45=true := by decide

private def q12Shape40T46 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape40T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 34426847232 3271557120 q12Shape40T46=true := by decide

private def q12Shape40T44 : Tree 12 := .split 35 q12Shape40T45 q12Shape40T46
private theorem q12Shape40T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 67108864 3271557120 q12Shape40T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 67108864 (3271557120 ||| 2^35) q12Shape40T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (67108864 ||| 2^35) 3271557120 q12Shape40T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T45OK,q12Shape40T46OK⟩

private def q12Shape40T47 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape40T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 2214592512 1124073472 q12Shape40T47=true := by decide

private def q12Shape40T43 : Tree 12 := .split 31 q12Shape40T44 q12Shape40T47
private theorem q12Shape40T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 67108864 1124073472 q12Shape40T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 67108864 (1124073472 ||| 2^31) q12Shape40T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (67108864 ||| 2^31) 1124073472 q12Shape40T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T44OK,q12Shape40T47OK⟩

private def q12Shape40T1 : Tree 12 := .split 26 q12Shape40T2 q12Shape40T43
private theorem q12Shape40T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 1124073472 q12Shape40T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (1124073472 ||| 2^26) q12Shape40T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^26) 1124073472 q12Shape40T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T2OK,q12Shape40T43OK⟩

private def q12Shape40T59 : Tree 12 := (.split 42 (.tip (.cover {0,2,3,4,7,8,11})) (.split 36 (.split 37 (.split 43 (.split 34 (.tip (.cover {0,2,3,4,7,8,10})) (.split 38 (.tip (.cover {0,2,3,4,6,8,10})) (.tip (.cover {0,1,5,8,9,10,11})))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape40T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 3898739785728 q12Shape40T59=true := by decide

private def q12Shape40T60 : Tree 12 := (.split 36 (.split 37 (.split 42 (.tip (.cover {0,2,3,4,6,8,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape40T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 9663676416 3890149851136 q12Shape40T60=true := by decide

private def q12Shape40T58 : Tree 12 := .split 33 q12Shape40T59 q12Shape40T60
private theorem q12Shape40T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 3890149851136 q12Shape40T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (3890149851136 ||| 2^33) q12Shape40T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^33) 3890149851136 q12Shape40T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T59OK,q12Shape40T60OK⟩

private def q12Shape40T61 : Tree 12 := (.split 36 (.split 37 (.split 42 (.tip (.cover {0,2,3,4,6,8,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape40T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 5368709120 3885854883840 q12Shape40T61=true := by decide

private def q12Shape40T57 : Tree 12 := .split 32 q12Shape40T58 q12Shape40T61
private theorem q12Shape40T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 3885854883840 q12Shape40T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (3885854883840 ||| 2^32) q12Shape40T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^32) 3885854883840 q12Shape40T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T58OK,q12Shape40T61OK⟩

private def q12Shape40T62 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape40T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 2200096997376 1686831628288 q12Shape40T62=true := by decide

private def q12Shape40T56 : Tree 12 := .split 41 q12Shape40T57 q12Shape40T62
private theorem q12Shape40T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 1686831628288 q12Shape40T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (1686831628288 ||| 2^41) q12Shape40T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^41) 1686831628288 q12Shape40T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T57OK,q12Shape40T62OK⟩

private def q12Shape40T63 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape40T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1100585369600 587320000512 q12Shape40T63=true := by decide

private def q12Shape40T55 : Tree 12 := .split 40 q12Shape40T56 q12Shape40T63
private theorem q12Shape40T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 587320000512 q12Shape40T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (587320000512 ||| 2^40) q12Shape40T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^40) 587320000512 q12Shape40T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T56OK,q12Shape40T63OK⟩

private def q12Shape40T64 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape40T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 550829555712 37564186624 q12Shape40T64=true := by decide

private def q12Shape40T54 : Tree 12 := .split 39 q12Shape40T55 q12Shape40T64
private theorem q12Shape40T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 37564186624 q12Shape40T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (37564186624 ||| 2^39) q12Shape40T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^39) 37564186624 q12Shape40T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T55OK,q12Shape40T64OK⟩

private def q12Shape40T65 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape40T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1610612736 37027315712 q12Shape40T65=true := by decide

private def q12Shape40T53 : Tree 12 := .split 29 q12Shape40T54 q12Shape40T65
private theorem q12Shape40T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 37027315712 q12Shape40T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (37027315712 ||| 2^29) q12Shape40T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^29) 37027315712 q12Shape40T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T54OK,q12Shape40T65OK⟩

private def q12Shape40T66 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape40T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1342177280 36758880256 q12Shape40T66=true := by decide

private def q12Shape40T52 : Tree 12 := .split 28 q12Shape40T53 q12Shape40T66
private theorem q12Shape40T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 36758880256 q12Shape40T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (36758880256 ||| 2^28) q12Shape40T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^28) 36758880256 q12Shape40T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T53OK,q12Shape40T66OK⟩

private def q12Shape40T67 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape40T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1207959552 36624662528 q12Shape40T67=true := by decide

private def q12Shape40T51 : Tree 12 := .split 27 q12Shape40T52 q12Shape40T67
private theorem q12Shape40T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 36624662528 q12Shape40T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (36624662528 ||| 2^27) q12Shape40T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^27) 36624662528 q12Shape40T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T52OK,q12Shape40T67OK⟩

private def q12Shape40T68 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape40T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 35433480192 2264924160 q12Shape40T68=true := by decide

private def q12Shape40T50 : Tree 12 := .split 35 q12Shape40T51 q12Shape40T68
private theorem q12Shape40T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 2264924160 q12Shape40T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (2264924160 ||| 2^35) q12Shape40T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^35) 2264924160 q12Shape40T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T51OK,q12Shape40T68OK⟩

private def q12Shape40T69 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape40T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 3221225472 117440512 q12Shape40T69=true := by decide

private def q12Shape40T49 : Tree 12 := .split 31 q12Shape40T50 q12Shape40T69
private theorem q12Shape40T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 117440512 q12Shape40T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (117440512 ||| 2^31) q12Shape40T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^31) 117440512 q12Shape40T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T50OK,q12Shape40T69OK⟩

private def q12Shape40T70 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape40T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1140850688 50331648 q12Shape40T70=true := by decide

private def q12Shape40T48 : Tree 12 := .split 26 q12Shape40T49 q12Shape40T70
private theorem q12Shape40T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 50331648 q12Shape40T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 1073741824 (50331648 ||| 2^26) q12Shape40T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (1073741824 ||| 2^26) 50331648 q12Shape40T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T49OK,q12Shape40T70OK⟩

private def q12Shape40T0 : Tree 12 := .split 30 q12Shape40T1 q12Shape40T48
private theorem q12Shape40T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 50331648 q12Shape40T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 (50331648 ||| 2^30) q12Shape40T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) (0 ||| 2^30) 50331648 q12Shape40T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape40T1OK,q12Shape40T48OK⟩

def q12Shape40P0 : Tree 12 := q12Shape40T0
theorem q12Shape40P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,3⟩) 0 50331648 q12Shape40P0=true := q12Shape40T0OK

end Graffiti384b.EffectiveSearch.Q12
