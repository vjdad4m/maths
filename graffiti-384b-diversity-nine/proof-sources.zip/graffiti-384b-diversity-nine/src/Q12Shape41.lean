import Q12Shape41Part0

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q12Shape41_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 41) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 41) b) (adj 12 (forms 41) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) adj_mono b H q12Shape41P0 q12Shape41P0OK

#print axioms q12Shape41_cover

end Graffiti384b.EffectiveSearch.Q12
