import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape41T4 : Tree 12 := (.split 34 (.split 35 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.split 40 (.tip (.cover {0,2,3,4,5,9,11})) (.tip (.cover {0,1,6,7,9,10,11})))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape41T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 16106127360 q12Shape41T4=true := by decide

private def q12Shape41T5 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape41T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 8589934592 7516192768 q12Shape41T5=true := by decide

private def q12Shape41T3 : Tree 12 := .split 33 q12Shape41T4 q12Shape41T5
private theorem q12Shape41T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 7516192768 q12Shape41T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 (7516192768 ||| 2^33) q12Shape41T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) (0 ||| 2^33) 7516192768 q12Shape41T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape41T4OK,q12Shape41T5OK⟩

private def q12Shape41T6 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape41T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 4294967296 3221225472 q12Shape41T6=true := by decide

private def q12Shape41T2 : Tree 12 := .split 32 q12Shape41T3 q12Shape41T6
private theorem q12Shape41T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 3221225472 q12Shape41T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 (3221225472 ||| 2^32) q12Shape41T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) (0 ||| 2^32) 3221225472 q12Shape41T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape41T3OK,q12Shape41T6OK⟩

private def q12Shape41T7 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape41T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 2147483648 1073741824 q12Shape41T7=true := by decide

private def q12Shape41T1 : Tree 12 := .split 31 q12Shape41T2 q12Shape41T7
private theorem q12Shape41T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 1073741824 q12Shape41T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 (1073741824 ||| 2^31) q12Shape41T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) (0 ||| 2^31) 1073741824 q12Shape41T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape41T2OK,q12Shape41T7OK⟩

private def q12Shape41T8 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape41T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 1073741824 0 q12Shape41T8=true := by decide

private def q12Shape41T0 : Tree 12 := .split 30 q12Shape41T1 q12Shape41T8
private theorem q12Shape41T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 0 q12Shape41T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 (0 ||| 2^30) q12Shape41T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) (0 ||| 2^30) 0 q12Shape41T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape41T1OK,q12Shape41T8OK⟩

def q12Shape41P0 : Tree 12 := q12Shape41T0
theorem q12Shape41P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,5,4⟩) 0 0 q12Shape41P0=true := q12Shape41T0OK

end Graffiti384b.EffectiveSearch.Q12
