import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 0 17178112 q12Shape42T1=true := by decide

private def q12Shape42T3 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape42T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777216 925184 q12Shape42T3=true := by decide

private def q12Shape42T9 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 3849398394368 q12Shape42T9=true := by decide

private def q12Shape42T10 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040557056 1650375138816 q12Shape42T10=true := by decide

private def q12Shape42T8 : Tree 12 := .split 41 q12Shape42T9 q12Shape42T10
private theorem q12Shape42T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 1650375138816 q12Shape42T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 (1650375138816 ||| 2^41) q12Shape42T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17301504 ||| 2^41) 1650375138816 q12Shape42T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T9OK,q12Shape42T10OK⟩

private def q12Shape42T11 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528929280 550863511040 q12Shape42T11=true := by decide

private def q12Shape42T7 : Tree 12 := .split 40 q12Shape42T8 q12Shape42T11
private theorem q12Shape42T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 550863511040 q12Shape42T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 (550863511040 ||| 2^40) q12Shape42T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17301504 ||| 2^40) 550863511040 q12Shape42T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T8OK,q12Shape42T11OK⟩

private def q12Shape42T12 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549773115392 1107697152 q12Shape42T12=true := by decide

private def q12Shape42T6 : Tree 12 := .split 39 q12Shape42T7 q12Shape42T12
private theorem q12Shape42T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 1107697152 q12Shape42T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 (1107697152 ||| 2^39) q12Shape42T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17301504 ||| 2^39) 1107697152 q12Shape42T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T7OK,q12Shape42T12OK⟩

private def q12Shape42T19 : Tree 12 := (.split 23 (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape42T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 3848331992576 q12Shape42T19=true := by decide

private def q12Shape42T20 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1095237632 3848327798272 q12Shape42T20=true := by decide

private def q12Shape42T18 : Tree 12 := .split 22 q12Shape42T19 q12Shape42T20
private theorem q12Shape42T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 3848327798272 q12Shape42T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 (3848327798272 ||| 2^22) q12Shape42T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1091043328 ||| 2^22) 3848327798272 q12Shape42T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T19OK,q12Shape42T20OK⟩

private def q12Shape42T21 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1093140480 3848325701120 q12Shape42T21=true := by decide

private def q12Shape42T17 : Tree 12 := .split 21 q12Shape42T18 q12Shape42T21
private theorem q12Shape42T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 3848325701120 q12Shape42T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 (3848325701120 ||| 2^21) q12Shape42T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1091043328 ||| 2^21) 3848325701120 q12Shape42T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T18OK,q12Shape42T21OK⟩

private def q12Shape42T22 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1092091904 3848324652544 q12Shape42T22=true := by decide

private def q12Shape42T16 : Tree 12 := .split 20 q12Shape42T17 q12Shape42T22
private theorem q12Shape42T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 3848324652544 q12Shape42T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 (3848324652544 ||| 2^20) q12Shape42T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1091043328 ||| 2^20) 3848324652544 q12Shape42T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T17OK,q12Shape42T22OK⟩

private def q12Shape42T23 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200114298880 1649301396992 q12Shape42T23=true := by decide

private def q12Shape42T15 : Tree 12 := .split 41 q12Shape42T16 q12Shape42T23
private theorem q12Shape42T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 1649301396992 q12Shape42T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 (1649301396992 ||| 2^41) q12Shape42T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1091043328 ||| 2^41) 1649301396992 q12Shape42T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T16OK,q12Shape42T23OK⟩

private def q12Shape42T24 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100602671104 549789769216 q12Shape42T24=true := by decide

private def q12Shape42T14 : Tree 12 := .split 40 q12Shape42T15 q12Shape42T24
private theorem q12Shape42T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 549789769216 q12Shape42T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 (549789769216 ||| 2^40) q12Shape42T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1091043328 ||| 2^40) 549789769216 q12Shape42T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T15OK,q12Shape42T24OK⟩

private def q12Shape42T25 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550846857216 33955328 q12Shape42T25=true := by decide

private def q12Shape42T13 : Tree 12 := .split 39 q12Shape42T14 q12Shape42T25
private theorem q12Shape42T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 33955328 q12Shape42T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091043328 (33955328 ||| 2^39) q12Shape42T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1091043328 ||| 2^39) 33955328 q12Shape42T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T14OK,q12Shape42T25OK⟩

private def q12Shape42T5 : Tree 12 := .split 30 q12Shape42T6 q12Shape42T13
private theorem q12Shape42T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 33955328 q12Shape42T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 (33955328 ||| 2^30) q12Shape42T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17301504 ||| 2^30) 33955328 q12Shape42T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T6OK,q12Shape42T13OK⟩

private def q12Shape42T32 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape42T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 3849367985664 q12Shape42T32=true := by decide

private def q12Shape42T33 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 52953088 3849365888512 q12Shape42T33=true := by decide

private def q12Shape42T31 : Tree 12 := .split 21 q12Shape42T32 q12Shape42T33
private theorem q12Shape42T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 3849365888512 q12Shape42T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 (3849365888512 ||| 2^21) q12Shape42T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50855936 ||| 2^21) 3849365888512 q12Shape42T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T32OK,q12Shape42T33OK⟩

private def q12Shape42T34 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51904512 3849364839936 q12Shape42T34=true := by decide

private def q12Shape42T30 : Tree 12 := .split 20 q12Shape42T31 q12Shape42T34
private theorem q12Shape42T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 3849364839936 q12Shape42T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 (3849364839936 ||| 2^20) q12Shape42T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50855936 ||| 2^20) 3849364839936 q12Shape42T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T31OK,q12Shape42T34OK⟩

private def q12Shape42T35 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199074111488 1650341584384 q12Shape42T35=true := by decide

private def q12Shape42T29 : Tree 12 := .split 41 q12Shape42T30 q12Shape42T35
private theorem q12Shape42T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 1650341584384 q12Shape42T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 (1650341584384 ||| 2^41) q12Shape42T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50855936 ||| 2^41) 1650341584384 q12Shape42T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T30OK,q12Shape42T35OK⟩

private def q12Shape42T36 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099562483712 550829956608 q12Shape42T36=true := by decide

private def q12Shape42T28 : Tree 12 := .split 40 q12Shape42T29 q12Shape42T36
private theorem q12Shape42T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 550829956608 q12Shape42T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 (550829956608 ||| 2^40) q12Shape42T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50855936 ||| 2^40) 550829956608 q12Shape42T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T29OK,q12Shape42T36OK⟩

private def q12Shape42T37 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549806669824 1074142720 q12Shape42T37=true := by decide

private def q12Shape42T27 : Tree 12 := .split 39 q12Shape42T28 q12Shape42T37
private theorem q12Shape42T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 1074142720 q12Shape42T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 (1074142720 ||| 2^39) q12Shape42T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50855936 ||| 2^39) 1074142720 q12Shape42T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T28OK,q12Shape42T37OK⟩

private def q12Shape42T38 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1124597760 400896 q12Shape42T38=true := by decide

private def q12Shape42T26 : Tree 12 := .split 30 q12Shape42T27 q12Shape42T38
private theorem q12Shape42T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 400896 q12Shape42T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50855936 (400896 ||| 2^30) q12Shape42T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50855936 ||| 2^30) 400896 q12Shape42T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T27OK,q12Shape42T38OK⟩

private def q12Shape42T4 : Tree 12 := .split 25 q12Shape42T5 q12Shape42T26
private theorem q12Shape42T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 400896 q12Shape42T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17301504 (400896 ||| 2^25) q12Shape42T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17301504 ||| 2^25) 400896 q12Shape42T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T5OK,q12Shape42T26OK⟩

private def q12Shape42T2 : Tree 12 := .split 19 q12Shape42T3 q12Shape42T4
private theorem q12Shape42T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777216 400896 q12Shape42T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777216 (400896 ||| 2^19) q12Shape42T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16777216 ||| 2^19) 400896 q12Shape42T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T3OK,q12Shape42T4OK⟩

private def q12Shape42T0 : Tree 12 := .split 24 q12Shape42T1 q12Shape42T2
private theorem q12Shape42T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 0 400896 q12Shape42T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 0 (400896 ||| 2^24) q12Shape42T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (0 ||| 2^24) 400896 q12Shape42T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1OK,q12Shape42T2OK⟩

def q12Shape42P0 : Tree 12 := q12Shape42T0
theorem q12Shape42P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 0 400896 q12Shape42P0=true := q12Shape42T0OK

end Graffiti384b.EffectiveSearch.Q12
