import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T362 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T362OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2048 34477568 q12Shape42T362=true := by decide

private def q12Shape42T368 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T368OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 3849382139392 q12Shape42T368=true := by decide

private def q12Shape42T369 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T369OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199056812032 1650358883840 q12Shape42T369=true := by decide

private def q12Shape42T367 : Tree 12 := .split 41 q12Shape42T368 q12Shape42T369
private theorem q12Shape42T367OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 1650358883840 q12Shape42T367=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 (1650358883840 ||| 2^41) q12Shape42T368 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33556480 ||| 2^41) 1650358883840 q12Shape42T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T368OK,q12Shape42T369OK⟩

private def q12Shape42T370 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T370OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545184256 550847256064 q12Shape42T370=true := by decide

private def q12Shape42T366 : Tree 12 := .split 40 q12Shape42T367 q12Shape42T370
private theorem q12Shape42T366OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 550847256064 q12Shape42T366=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 (550847256064 ||| 2^40) q12Shape42T367 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33556480 ||| 2^40) 550847256064 q12Shape42T370)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T367OK,q12Shape42T370OK⟩

private def q12Shape42T371 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789370368 1091442176 q12Shape42T371=true := by decide

private def q12Shape42T365 : Tree 12 := .split 39 q12Shape42T366 q12Shape42T371
private theorem q12Shape42T365OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 1091442176 q12Shape42T365=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 (1091442176 ||| 2^39) q12Shape42T366 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33556480 ||| 2^39) 1091442176 q12Shape42T371)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T366OK,q12Shape42T371OK⟩

private def q12Shape42T379 : Tree 12 := (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,4,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape42T379OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 3848308520448 q12Shape42T379=true := by decide

private def q12Shape42T380 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T380OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200130553856 1649285264896 q12Shape42T380=true := by decide

private def q12Shape42T378 : Tree 12 := .split 41 q12Shape42T379 q12Shape42T380
private theorem q12Shape42T378OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 1649285264896 q12Shape42T378=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 (1649285264896 ||| 2^41) q12Shape42T379 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107298304 ||| 2^41) 1649285264896 q12Shape42T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T379OK,q12Shape42T380OK⟩

private def q12Shape42T381 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T381OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100618926080 549773637120 q12Shape42T381=true := by decide

private def q12Shape42T377 : Tree 12 := .split 40 q12Shape42T378 q12Shape42T381
private theorem q12Shape42T377OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 549773637120 q12Shape42T377=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 (549773637120 ||| 2^40) q12Shape42T378 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107298304 ||| 2^40) 549773637120 q12Shape42T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T378OK,q12Shape42T381OK⟩

private def q12Shape42T382 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T382OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550863112192 17823232 q12Shape42T382=true := by decide

private def q12Shape42T376 : Tree 12 := .split 39 q12Shape42T377 q12Shape42T382
private theorem q12Shape42T376OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 17823232 q12Shape42T376=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 (17823232 ||| 2^39) q12Shape42T377 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107298304 ||| 2^39) 17823232 q12Shape42T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T377OK,q12Shape42T382OK⟩

private def q12Shape42T383 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T383OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107363840 17757696 q12Shape42T383=true := by decide

private def q12Shape42T375 : Tree 12 := .split 16 q12Shape42T376 q12Shape42T383
private theorem q12Shape42T375OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 17757696 q12Shape42T375=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 (17757696 ||| 2^16) q12Shape42T376 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107298304 ||| 2^16) 17757696 q12Shape42T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T376OK,q12Shape42T383OK⟩

private def q12Shape42T384 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T384OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107331072 17724928 q12Shape42T384=true := by decide

private def q12Shape42T374 : Tree 12 := .split 15 q12Shape42T375 q12Shape42T384
private theorem q12Shape42T374OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 17724928 q12Shape42T374=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 (17724928 ||| 2^15) q12Shape42T375 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107298304 ||| 2^15) 17724928 q12Shape42T384)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T375OK,q12Shape42T384OK⟩

private def q12Shape42T385 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T385OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107314688 17708544 q12Shape42T385=true := by decide

private def q12Shape42T373 : Tree 12 := .split 14 q12Shape42T374 q12Shape42T385
private theorem q12Shape42T373OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 17708544 q12Shape42T373=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 (17708544 ||| 2^14) q12Shape42T374 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107298304 ||| 2^14) 17708544 q12Shape42T385)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T374OK,q12Shape42T385OK⟩

private def q12Shape42T386 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T386OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107306496 17700352 q12Shape42T386=true := by decide

private def q12Shape42T372 : Tree 12 := .split 13 q12Shape42T373 q12Shape42T386
private theorem q12Shape42T372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 17700352 q12Shape42T372=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107298304 (17700352 ||| 2^13) q12Shape42T373 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107298304 ||| 2^13) 17700352 q12Shape42T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T373OK,q12Shape42T386OK⟩

private def q12Shape42T364 : Tree 12 := .split 30 q12Shape42T365 q12Shape42T372
private theorem q12Shape42T364OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 17700352 q12Shape42T364=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 (17700352 ||| 2^30) q12Shape42T365 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33556480 ||| 2^30) 17700352 q12Shape42T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T365OK,q12Shape42T372OK⟩

private def q12Shape42T395 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T395OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 3849365485056 q12Shape42T395=true := by decide

private def q12Shape42T396 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T396OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199073589248 1650342229504 q12Shape42T396=true := by decide

private def q12Shape42T394 : Tree 12 := .split 41 q12Shape42T395 q12Shape42T396
private theorem q12Shape42T394OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 1650342229504 q12Shape42T394=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (1650342229504 ||| 2^41) q12Shape42T395 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^41) 1650342229504 q12Shape42T396)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T395OK,q12Shape42T396OK⟩

private def q12Shape42T397 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T397OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099561961472 550830601728 q12Shape42T397=true := by decide

private def q12Shape42T393 : Tree 12 := .split 40 q12Shape42T394 q12Shape42T397
private theorem q12Shape42T393OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 550830601728 q12Shape42T393=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (550830601728 ||| 2^40) q12Shape42T394 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^40) 550830601728 q12Shape42T397)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T394OK,q12Shape42T397OK⟩

private def q12Shape42T398 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T398OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549806147584 1074787840 q12Shape42T398=true := by decide

private def q12Shape42T392 : Tree 12 := .split 39 q12Shape42T393 q12Shape42T398
private theorem q12Shape42T392OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 1074787840 q12Shape42T392=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (1074787840 ||| 2^39) q12Shape42T393 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^39) 1074787840 q12Shape42T398)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T393OK,q12Shape42T398OK⟩

private def q12Shape42T399 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T399OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50399232 1074722304 q12Shape42T399=true := by decide

private def q12Shape42T391 : Tree 12 := .split 16 q12Shape42T392 q12Shape42T399
private theorem q12Shape42T391OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 1074722304 q12Shape42T391=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (1074722304 ||| 2^16) q12Shape42T392 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^16) 1074722304 q12Shape42T399)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T392OK,q12Shape42T399OK⟩

private def q12Shape42T400 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T400OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50366464 1074689536 q12Shape42T400=true := by decide

private def q12Shape42T390 : Tree 12 := .split 15 q12Shape42T391 q12Shape42T400
private theorem q12Shape42T390OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 1074689536 q12Shape42T390=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (1074689536 ||| 2^15) q12Shape42T391 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^15) 1074689536 q12Shape42T400)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T391OK,q12Shape42T400OK⟩

private def q12Shape42T401 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T401OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50350080 1074673152 q12Shape42T401=true := by decide

private def q12Shape42T389 : Tree 12 := .split 14 q12Shape42T390 q12Shape42T401
private theorem q12Shape42T389OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 1074673152 q12Shape42T389=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (1074673152 ||| 2^14) q12Shape42T390 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^14) 1074673152 q12Shape42T401)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T390OK,q12Shape42T401OK⟩

private def q12Shape42T402 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T402OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50341888 1074664960 q12Shape42T402=true := by decide

private def q12Shape42T388 : Tree 12 := .split 13 q12Shape42T389 q12Shape42T402
private theorem q12Shape42T388OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 1074664960 q12Shape42T388=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (1074664960 ||| 2^13) q12Shape42T389 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^13) 1074664960 q12Shape42T402)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T389OK,q12Shape42T402OK⟩

private def q12Shape42T403 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T403OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1124075520 923136 q12Shape42T403=true := by decide

private def q12Shape42T387 : Tree 12 := .split 30 q12Shape42T388 q12Shape42T403
private theorem q12Shape42T387OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 923136 q12Shape42T387=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333696 (923136 ||| 2^30) q12Shape42T388 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50333696 ||| 2^30) 923136 q12Shape42T403)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T388OK,q12Shape42T403OK⟩

private def q12Shape42T363 : Tree 12 := .split 24 q12Shape42T364 q12Shape42T387
private theorem q12Shape42T363OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 923136 q12Shape42T363=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556480 (923136 ||| 2^24) q12Shape42T364 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33556480 ||| 2^24) 923136 q12Shape42T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T364OK,q12Shape42T387OK⟩

private def q12Shape42T361 : Tree 12 := .split 25 q12Shape42T362 q12Shape42T363
private theorem q12Shape42T361OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2048 923136 q12Shape42T361=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2048 (923136 ||| 2^25) q12Shape42T362 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (2048 ||| 2^25) 923136 q12Shape42T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T362OK,q12Shape42T363OK⟩

def q12Shape42P11 : Tree 12 := q12Shape42T361
theorem q12Shape42P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2048 923136 q12Shape42P11=true := q12Shape42T361OK

end Graffiti384b.EffectiveSearch.Q12
