import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T410 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T410OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 3849415169536 q12Shape42T410=true := by decide

private def q12Shape42T411 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T411OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023781888 1650391913984 q12Shape42T411=true := by decide

private def q12Shape42T409 : Tree 12 := .split 41 q12Shape42T410 q12Shape42T411
private theorem q12Shape42T409OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 1650391913984 q12Shape42T409=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 (1650391913984 ||| 2^41) q12Shape42T410 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526336 ||| 2^41) 1650391913984 q12Shape42T411)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T410OK,q12Shape42T411OK⟩

private def q12Shape42T412 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T412OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512154112 550880286208 q12Shape42T412=true := by decide

private def q12Shape42T408 : Tree 12 := .split 40 q12Shape42T409 q12Shape42T412
private theorem q12Shape42T408OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 550880286208 q12Shape42T408=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 (550880286208 ||| 2^40) q12Shape42T409 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526336 ||| 2^40) 550880286208 q12Shape42T412)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T409OK,q12Shape42T412OK⟩

private def q12Shape42T413 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T413OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756340224 1124472320 q12Shape42T413=true := by decide

private def q12Shape42T407 : Tree 12 := .split 39 q12Shape42T408 q12Shape42T413
private theorem q12Shape42T407OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 1124472320 q12Shape42T407=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 (1124472320 ||| 2^39) q12Shape42T408 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526336 ||| 2^39) 1124472320 q12Shape42T413)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T408OK,q12Shape42T413OK⟩

private def q12Shape42T423 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {0,1,2,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T423OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 549822395904 q12Shape42T423=true := by decide

private def q12Shape42T424 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {0,1,2,5,6,7,9})) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T424OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550830082048 66582016 q12Shape42T424=true := by decide

private def q12Shape42T422 : Tree 12 := .split 39 q12Shape42T423 q12Shape42T424
private theorem q12Shape42T422OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 66582016 q12Shape42T422=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (66582016 ||| 2^39) q12Shape42T423 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^39) 66582016 q12Shape42T424)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T423OK,q12Shape42T424OK⟩

private def q12Shape42T425 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T425OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1082656768 58193408 q12Shape42T425=true := by decide

private def q12Shape42T421 : Tree 12 := .split 23 q12Shape42T422 q12Shape42T425
private theorem q12Shape42T421OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 58193408 q12Shape42T421=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (58193408 ||| 2^23) q12Shape42T422 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^23) 58193408 q12Shape42T425)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T422OK,q12Shape42T425OK⟩

private def q12Shape42T426 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T426OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1078462464 53999104 q12Shape42T426=true := by decide

private def q12Shape42T420 : Tree 12 := .split 22 q12Shape42T421 q12Shape42T426
private theorem q12Shape42T420OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 53999104 q12Shape42T420=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (53999104 ||| 2^22) q12Shape42T421 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^22) 53999104 q12Shape42T426)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T421OK,q12Shape42T426OK⟩

private def q12Shape42T427 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T427OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1076365312 51901952 q12Shape42T427=true := by decide

private def q12Shape42T419 : Tree 12 := .split 21 q12Shape42T420 q12Shape42T427
private theorem q12Shape42T419OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 51901952 q12Shape42T419=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (51901952 ||| 2^21) q12Shape42T420 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^21) 51901952 q12Shape42T427)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T420OK,q12Shape42T427OK⟩

private def q12Shape42T428 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T428OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1075316736 50853376 q12Shape42T428=true := by decide

private def q12Shape42T418 : Tree 12 := .split 20 q12Shape42T419 q12Shape42T428
private theorem q12Shape42T418OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 50853376 q12Shape42T418=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (50853376 ||| 2^20) q12Shape42T419 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^20) 50853376 q12Shape42T428)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T419OK,q12Shape42T428OK⟩

private def q12Shape42T429 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T429OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074333696 50787840 q12Shape42T429=true := by decide

private def q12Shape42T417 : Tree 12 := .split 16 q12Shape42T418 q12Shape42T429
private theorem q12Shape42T417OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 50787840 q12Shape42T417=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (50787840 ||| 2^16) q12Shape42T418 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^16) 50787840 q12Shape42T429)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T418OK,q12Shape42T429OK⟩

private def q12Shape42T430 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T430OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074300928 50755072 q12Shape42T430=true := by decide

private def q12Shape42T416 : Tree 12 := .split 15 q12Shape42T417 q12Shape42T430
private theorem q12Shape42T416OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 50755072 q12Shape42T416=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (50755072 ||| 2^15) q12Shape42T417 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^15) 50755072 q12Shape42T430)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T417OK,q12Shape42T430OK⟩

private def q12Shape42T431 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T431OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074284544 50738688 q12Shape42T431=true := by decide

private def q12Shape42T415 : Tree 12 := .split 14 q12Shape42T416 q12Shape42T431
private theorem q12Shape42T415OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 50738688 q12Shape42T415=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (50738688 ||| 2^14) q12Shape42T416 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^14) 50738688 q12Shape42T431)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T416OK,q12Shape42T431OK⟩

private def q12Shape42T432 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T432OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074276352 50730496 q12Shape42T432=true := by decide

private def q12Shape42T414 : Tree 12 := .split 13 q12Shape42T415 q12Shape42T432
private theorem q12Shape42T414OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 50730496 q12Shape42T414=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268160 (50730496 ||| 2^13) q12Shape42T415 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268160 ||| 2^13) 50730496 q12Shape42T432)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T415OK,q12Shape42T432OK⟩

private def q12Shape42T406 : Tree 12 := .split 30 q12Shape42T407 q12Shape42T414
private theorem q12Shape42T406OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 50730496 q12Shape42T406=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 (50730496 ||| 2^30) q12Shape42T407 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526336 ||| 2^30) 50730496 q12Shape42T414)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T407OK,q12Shape42T414OK⟩

private def q12Shape42T433 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T433OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34080768 17176064 q12Shape42T433=true := by decide

private def q12Shape42T405 : Tree 12 := .split 25 q12Shape42T406 q12Shape42T433
private theorem q12Shape42T405OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 17176064 q12Shape42T405=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 (17176064 ||| 2^25) q12Shape42T406 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526336 ||| 2^25) 17176064 q12Shape42T433)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T406OK,q12Shape42T433OK⟩

private def q12Shape42T434 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape42T434OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17303552 398848 q12Shape42T434=true := by decide

private def q12Shape42T404 : Tree 12 := .split 24 q12Shape42T405 q12Shape42T434
private theorem q12Shape42T404OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 398848 q12Shape42T404=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 (398848 ||| 2^24) q12Shape42T405 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526336 ||| 2^24) 398848 q12Shape42T434)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T405OK,q12Shape42T434OK⟩

def q12Shape42P12 : Tree 12 := q12Shape42T404
theorem q12Shape42P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526336 398848 q12Shape42P12=true := q12Shape42T404OK

end Graffiti384b.EffectiveSearch.Q12
