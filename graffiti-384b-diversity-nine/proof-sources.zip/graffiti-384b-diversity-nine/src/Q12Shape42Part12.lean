import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T437 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))))
private theorem q12Shape42T437OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264192 660992 q12Shape42T437=true := by decide

private def q12Shape42T448 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T448OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 3849415030272 q12Shape42T448=true := by decide

private def q12Shape42T449 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T449OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199024044032 1650391774720 q12Shape42T449=true := by decide

private def q12Shape42T447 : Tree 12 := .split 41 q12Shape42T448 q12Shape42T449
private theorem q12Shape42T447OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 1650391774720 q12Shape42T447=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (1650391774720 ||| 2^41) q12Shape42T448 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^41) 1650391774720 q12Shape42T449)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T448OK,q12Shape42T449OK⟩

private def q12Shape42T450 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T450OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512416256 550880146944 q12Shape42T450=true := by decide

private def q12Shape42T446 : Tree 12 := .split 40 q12Shape42T447 q12Shape42T450
private theorem q12Shape42T446OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 550880146944 q12Shape42T446=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (550880146944 ||| 2^40) q12Shape42T447 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^40) 550880146944 q12Shape42T450)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T447OK,q12Shape42T450OK⟩

private def q12Shape42T451 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T451OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756602368 1124333056 q12Shape42T451=true := by decide

private def q12Shape42T445 : Tree 12 := .split 39 q12Shape42T446 q12Shape42T451
private theorem q12Shape42T445OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 1124333056 q12Shape42T445=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (1124333056 ||| 2^39) q12Shape42T446 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^39) 1124333056 q12Shape42T451)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T446OK,q12Shape42T451OK⟩

private def q12Shape42T452 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T452OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 854016 1124267520 q12Shape42T452=true := by decide

private def q12Shape42T444 : Tree 12 := .split 16 q12Shape42T445 q12Shape42T452
private theorem q12Shape42T444OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 1124267520 q12Shape42T444=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (1124267520 ||| 2^16) q12Shape42T445 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^16) 1124267520 q12Shape42T452)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T445OK,q12Shape42T452OK⟩

private def q12Shape42T453 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T453OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 821248 1124234752 q12Shape42T453=true := by decide

private def q12Shape42T443 : Tree 12 := .split 15 q12Shape42T444 q12Shape42T453
private theorem q12Shape42T443OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 1124234752 q12Shape42T443=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (1124234752 ||| 2^15) q12Shape42T444 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^15) 1124234752 q12Shape42T453)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T444OK,q12Shape42T453OK⟩

private def q12Shape42T454 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T454OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 804864 1124218368 q12Shape42T454=true := by decide

private def q12Shape42T442 : Tree 12 := .split 14 q12Shape42T443 q12Shape42T454
private theorem q12Shape42T442OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 1124218368 q12Shape42T442=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (1124218368 ||| 2^14) q12Shape42T443 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^14) 1124218368 q12Shape42T454)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T443OK,q12Shape42T454OK⟩

private def q12Shape42T455 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T455OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 796672 1124210176 q12Shape42T455=true := by decide

private def q12Shape42T441 : Tree 12 := .split 13 q12Shape42T442 q12Shape42T455
private theorem q12Shape42T441OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 1124210176 q12Shape42T441=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (1124210176 ||| 2^13) q12Shape42T442 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^13) 1124210176 q12Shape42T455)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T442OK,q12Shape42T455OK⟩

private def q12Shape42T456 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T456OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074530304 50468352 q12Shape42T456=true := by decide

private def q12Shape42T440 : Tree 12 := .split 30 q12Shape42T441 q12Shape42T456
private theorem q12Shape42T440OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 50468352 q12Shape42T440=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (50468352 ||| 2^30) q12Shape42T441 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^30) 50468352 q12Shape42T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T441OK,q12Shape42T456OK⟩

private def q12Shape42T457 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T457OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34342912 16913920 q12Shape42T457=true := by decide

private def q12Shape42T439 : Tree 12 := .split 25 q12Shape42T440 q12Shape42T457
private theorem q12Shape42T439OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 16913920 q12Shape42T439=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (16913920 ||| 2^25) q12Shape42T440 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^25) 16913920 q12Shape42T457)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T440OK,q12Shape42T457OK⟩

private def q12Shape42T458 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape42T458OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17565696 136704 q12Shape42T458=true := by decide

private def q12Shape42T438 : Tree 12 := .split 24 q12Shape42T439 q12Shape42T458
private theorem q12Shape42T438OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 136704 q12Shape42T438=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788480 (136704 ||| 2^24) q12Shape42T439 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (788480 ||| 2^24) 136704 q12Shape42T458)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T439OK,q12Shape42T458OK⟩

private def q12Shape42T436 : Tree 12 := .split 19 q12Shape42T437 q12Shape42T438
private theorem q12Shape42T436OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264192 136704 q12Shape42T436=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264192 (136704 ||| 2^19) q12Shape42T437 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (264192 ||| 2^19) 136704 q12Shape42T438)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T437OK,q12Shape42T438OK⟩

def q12Shape42P13 : Tree 12 := q12Shape42T436
theorem q12Shape42P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264192 136704 q12Shape42P13=true := q12Shape42T436OK

end Graffiti384b.EffectiveSearch.Q12
