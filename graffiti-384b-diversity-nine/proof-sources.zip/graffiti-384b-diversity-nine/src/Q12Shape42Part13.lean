import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T467 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape42T467OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 3849415562752 q12Shape42T467=true := by decide

private def q12Shape42T468 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T468OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023388672 1650392307200 q12Shape42T468=true := by decide

private def q12Shape42T466 : Tree 12 := .split 41 q12Shape42T467 q12Shape42T468
private theorem q12Shape42T466OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 1650392307200 q12Shape42T466=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 (1650392307200 ||| 2^41) q12Shape42T467 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (133120 ||| 2^41) 1650392307200 q12Shape42T468)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T467OK,q12Shape42T468OK⟩

private def q12Shape42T469 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T469OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511760896 550880679424 q12Shape42T469=true := by decide

private def q12Shape42T465 : Tree 12 := .split 40 q12Shape42T466 q12Shape42T469
private theorem q12Shape42T465OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 550880679424 q12Shape42T465=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 (550880679424 ||| 2^40) q12Shape42T466 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (133120 ||| 2^40) 550880679424 q12Shape42T469)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T466OK,q12Shape42T469OK⟩

private def q12Shape42T470 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape42T470OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549755947008 1124865536 q12Shape42T470=true := by decide

private def q12Shape42T464 : Tree 12 := .split 39 q12Shape42T465 q12Shape42T470
private theorem q12Shape42T464OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 1124865536 q12Shape42T464=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 (1124865536 ||| 2^39) q12Shape42T465 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (133120 ||| 2^39) 1124865536 q12Shape42T470)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T465OK,q12Shape42T470OK⟩

private def q12Shape42T471 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape42T471OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073874944 51123712 q12Shape42T471=true := by decide

private def q12Shape42T463 : Tree 12 := .split 30 q12Shape42T464 q12Shape42T471
private theorem q12Shape42T463OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 51123712 q12Shape42T463=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 (51123712 ||| 2^30) q12Shape42T464 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (133120 ||| 2^30) 51123712 q12Shape42T471)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T464OK,q12Shape42T471OK⟩

private def q12Shape42T472 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T472OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33687552 17569280 q12Shape42T472=true := by decide

private def q12Shape42T462 : Tree 12 := .split 25 q12Shape42T463 q12Shape42T472
private theorem q12Shape42T462OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 17569280 q12Shape42T462=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 (17569280 ||| 2^25) q12Shape42T463 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (133120 ||| 2^25) 17569280 q12Shape42T472)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T463OK,q12Shape42T472OK⟩

private def q12Shape42T484 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {0,1,2,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape42T484OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 550879753728 q12Shape42T484=true := by decide

private def q12Shape42T485 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {0,1,2,5,6,7,9})) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape42T485OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772724224 1123939840 q12Shape42T485=true := by decide

private def q12Shape42T483 : Tree 12 := .split 39 q12Shape42T484 q12Shape42T485
private theorem q12Shape42T483OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1123939840 q12Shape42T483=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1123939840 ||| 2^39) q12Shape42T484 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^39) 1123939840 q12Shape42T485)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T484OK,q12Shape42T485OK⟩

private def q12Shape42T486 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T486OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 25298944 1115551232 q12Shape42T486=true := by decide

private def q12Shape42T482 : Tree 12 := .split 23 q12Shape42T483 q12Shape42T486
private theorem q12Shape42T482OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1115551232 q12Shape42T482=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1115551232 ||| 2^23) q12Shape42T483 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^23) 1115551232 q12Shape42T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T483OK,q12Shape42T486OK⟩

private def q12Shape42T487 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T487OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 21104640 1111356928 q12Shape42T487=true := by decide

private def q12Shape42T481 : Tree 12 := .split 22 q12Shape42T482 q12Shape42T487
private theorem q12Shape42T481OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1111356928 q12Shape42T481=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1111356928 ||| 2^22) q12Shape42T482 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^22) 1111356928 q12Shape42T487)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T482OK,q12Shape42T487OK⟩

private def q12Shape42T488 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T488OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 19007488 1109259776 q12Shape42T488=true := by decide

private def q12Shape42T480 : Tree 12 := .split 21 q12Shape42T481 q12Shape42T488
private theorem q12Shape42T480OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1109259776 q12Shape42T480=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1109259776 ||| 2^21) q12Shape42T481 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^21) 1109259776 q12Shape42T488)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T481OK,q12Shape42T488OK⟩

private def q12Shape42T489 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T489OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17958912 1108211200 q12Shape42T489=true := by decide

private def q12Shape42T479 : Tree 12 := .split 20 q12Shape42T480 q12Shape42T489
private theorem q12Shape42T479OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1108211200 q12Shape42T479=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1108211200 ||| 2^20) q12Shape42T480 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^20) 1108211200 q12Shape42T489)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T480OK,q12Shape42T489OK⟩

private def q12Shape42T490 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T490OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16975872 1108145664 q12Shape42T490=true := by decide

private def q12Shape42T478 : Tree 12 := .split 16 q12Shape42T479 q12Shape42T490
private theorem q12Shape42T478OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1108145664 q12Shape42T478=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1108145664 ||| 2^16) q12Shape42T479 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^16) 1108145664 q12Shape42T490)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T479OK,q12Shape42T490OK⟩

private def q12Shape42T491 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T491OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16943104 1108112896 q12Shape42T491=true := by decide

private def q12Shape42T477 : Tree 12 := .split 15 q12Shape42T478 q12Shape42T491
private theorem q12Shape42T477OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1108112896 q12Shape42T477=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1108112896 ||| 2^15) q12Shape42T478 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^15) 1108112896 q12Shape42T491)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T478OK,q12Shape42T491OK⟩

private def q12Shape42T492 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T492OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16926720 1108096512 q12Shape42T492=true := by decide

private def q12Shape42T476 : Tree 12 := .split 14 q12Shape42T477 q12Shape42T492
private theorem q12Shape42T476OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1108096512 q12Shape42T476=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1108096512 ||| 2^14) q12Shape42T477 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^14) 1108096512 q12Shape42T492)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T477OK,q12Shape42T492OK⟩

private def q12Shape42T493 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T493OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16918528 1108088320 q12Shape42T493=true := by decide

private def q12Shape42T475 : Tree 12 := .split 13 q12Shape42T476 q12Shape42T493
private theorem q12Shape42T475OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 1108088320 q12Shape42T475=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (1108088320 ||| 2^13) q12Shape42T476 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^13) 1108088320 q12Shape42T493)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T476OK,q12Shape42T493OK⟩

private def q12Shape42T494 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape42T494OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090652160 34346496 q12Shape42T494=true := by decide

private def q12Shape42T474 : Tree 12 := .split 30 q12Shape42T475 q12Shape42T494
private theorem q12Shape42T474OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 34346496 q12Shape42T474=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (34346496 ||| 2^30) q12Shape42T475 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^30) 34346496 q12Shape42T494)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T475OK,q12Shape42T494OK⟩

private def q12Shape42T495 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T495OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50464768 792064 q12Shape42T495=true := by decide

private def q12Shape42T473 : Tree 12 := .split 25 q12Shape42T474 q12Shape42T495
private theorem q12Shape42T473OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 792064 q12Shape42T473=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16910336 (792064 ||| 2^25) q12Shape42T474 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16910336 ||| 2^25) 792064 q12Shape42T495)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T474OK,q12Shape42T495OK⟩

private def q12Shape42T461 : Tree 12 := .split 24 q12Shape42T462 q12Shape42T473
private theorem q12Shape42T461OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 792064 q12Shape42T461=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 (792064 ||| 2^24) q12Shape42T462 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (133120 ||| 2^24) 792064 q12Shape42T473)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T462OK,q12Shape42T473OK⟩

private def q12Shape42T496 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T496OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 657408 267776 q12Shape42T496=true := by decide

private def q12Shape42T460 : Tree 12 := .split 19 q12Shape42T461 q12Shape42T496
private theorem q12Shape42T460OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 267776 q12Shape42T460=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 (267776 ||| 2^19) q12Shape42T461 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (133120 ||| 2^19) 267776 q12Shape42T496)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T461OK,q12Shape42T496OK⟩

def q12Shape42P14 : Tree 12 := q12Shape42T460
theorem q12Shape42P14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 133120 267776 q12Shape42P14=true := q12Shape42T460OK

end Graffiti384b.EffectiveSearch.Q12
