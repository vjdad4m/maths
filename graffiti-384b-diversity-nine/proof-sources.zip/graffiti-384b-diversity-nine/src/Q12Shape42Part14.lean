import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T508 : Tree 12 := (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,4,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,9})))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape42T508OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 3849415423488 q12Shape42T508=true := by decide

private def q12Shape42T509 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T509OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023650816 1650392167936 q12Shape42T509=true := by decide

private def q12Shape42T507 : Tree 12 := .split 41 q12Shape42T508 q12Shape42T509
private theorem q12Shape42T507OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 1650392167936 q12Shape42T507=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (1650392167936 ||| 2^41) q12Shape42T508 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^41) 1650392167936 q12Shape42T509)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T508OK,q12Shape42T509OK⟩

private def q12Shape42T510 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T510OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512023040 550880540160 q12Shape42T510=true := by decide

private def q12Shape42T506 : Tree 12 := .split 40 q12Shape42T507 q12Shape42T510
private theorem q12Shape42T506OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 550880540160 q12Shape42T506=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (550880540160 ||| 2^40) q12Shape42T507 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^40) 550880540160 q12Shape42T510)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T507OK,q12Shape42T510OK⟩

private def q12Shape42T511 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape42T511OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756209152 1124726272 q12Shape42T511=true := by decide

private def q12Shape42T505 : Tree 12 := .split 39 q12Shape42T506 q12Shape42T511
private theorem q12Shape42T505OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 1124726272 q12Shape42T505=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (1124726272 ||| 2^39) q12Shape42T506 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^39) 1124726272 q12Shape42T511)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T506OK,q12Shape42T511OK⟩

private def q12Shape42T512 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T512OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 460800 1124660736 q12Shape42T512=true := by decide

private def q12Shape42T504 : Tree 12 := .split 16 q12Shape42T505 q12Shape42T512
private theorem q12Shape42T504OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 1124660736 q12Shape42T504=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (1124660736 ||| 2^16) q12Shape42T505 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^16) 1124660736 q12Shape42T512)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T505OK,q12Shape42T512OK⟩

private def q12Shape42T513 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T513OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 428032 1124627968 q12Shape42T513=true := by decide

private def q12Shape42T503 : Tree 12 := .split 15 q12Shape42T504 q12Shape42T513
private theorem q12Shape42T503OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 1124627968 q12Shape42T503=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (1124627968 ||| 2^15) q12Shape42T504 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^15) 1124627968 q12Shape42T513)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T504OK,q12Shape42T513OK⟩

private def q12Shape42T514 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T514OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 411648 1124611584 q12Shape42T514=true := by decide

private def q12Shape42T502 : Tree 12 := .split 14 q12Shape42T503 q12Shape42T514
private theorem q12Shape42T502OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 1124611584 q12Shape42T502=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (1124611584 ||| 2^14) q12Shape42T503 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^14) 1124611584 q12Shape42T514)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T503OK,q12Shape42T514OK⟩

private def q12Shape42T515 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T515OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 403456 1124603392 q12Shape42T515=true := by decide

private def q12Shape42T501 : Tree 12 := .split 13 q12Shape42T502 q12Shape42T515
private theorem q12Shape42T501OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 1124603392 q12Shape42T501=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (1124603392 ||| 2^13) q12Shape42T502 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^13) 1124603392 q12Shape42T515)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T502OK,q12Shape42T515OK⟩

private def q12Shape42T516 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape42T516OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074137088 50861568 q12Shape42T516=true := by decide

private def q12Shape42T500 : Tree 12 := .split 30 q12Shape42T501 q12Shape42T516
private theorem q12Shape42T500OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 50861568 q12Shape42T500=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (50861568 ||| 2^30) q12Shape42T501 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^30) 50861568 q12Shape42T516)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T501OK,q12Shape42T516OK⟩

private def q12Shape42T517 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T517OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33949696 17307136 q12Shape42T517=true := by decide

private def q12Shape42T499 : Tree 12 := .split 25 q12Shape42T500 q12Shape42T517
private theorem q12Shape42T499OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 17307136 q12Shape42T499=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (17307136 ||| 2^25) q12Shape42T500 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^25) 17307136 q12Shape42T517)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T500OK,q12Shape42T517OK⟩

private def q12Shape42T518 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape42T518OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17172480 529920 q12Shape42T518=true := by decide

private def q12Shape42T498 : Tree 12 := .split 24 q12Shape42T499 q12Shape42T518
private theorem q12Shape42T498OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 529920 q12Shape42T498=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (529920 ||| 2^24) q12Shape42T499 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^24) 529920 q12Shape42T518)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T499OK,q12Shape42T518OK⟩

private def q12Shape42T519 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T519OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 919552 5632 q12Shape42T519=true := by decide

private def q12Shape42T497 : Tree 12 := .split 19 q12Shape42T498 q12Shape42T519
private theorem q12Shape42T497OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 5632 q12Shape42T497=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 (5632 ||| 2^19) q12Shape42T498 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (395264 ||| 2^19) 5632 q12Shape42T519)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T498OK,q12Shape42T519OK⟩

def q12Shape42P15 : Tree 12 := q12Shape42T497
theorem q12Shape42P15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 395264 5632 q12Shape42P15=true := q12Shape42T497OK

end Graffiti384b.EffectiveSearch.Q12
