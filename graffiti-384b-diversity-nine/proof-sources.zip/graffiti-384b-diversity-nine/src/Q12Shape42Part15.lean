import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T524 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T524OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 6144 51250688 q12Shape42T524=true := by decide

private def q12Shape42T529 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T529OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 3849382135296 q12Shape42T529=true := by decide

private def q12Shape42T530 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T530OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199056816128 1650358879744 q12Shape42T530=true := by decide

private def q12Shape42T528 : Tree 12 := .split 41 q12Shape42T529 q12Shape42T530
private theorem q12Shape42T528OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 1650358879744 q12Shape42T528=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 (1650358879744 ||| 2^41) q12Shape42T529 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33560576 ||| 2^41) 1650358879744 q12Shape42T530)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T529OK,q12Shape42T530OK⟩

private def q12Shape42T531 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T531OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545188352 550847251968 q12Shape42T531=true := by decide

private def q12Shape42T527 : Tree 12 := .split 40 q12Shape42T528 q12Shape42T531
private theorem q12Shape42T527OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 550847251968 q12Shape42T527=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 (550847251968 ||| 2^40) q12Shape42T528 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33560576 ||| 2^40) 550847251968 q12Shape42T531)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T528OK,q12Shape42T531OK⟩

private def q12Shape42T532 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T532OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789374464 1091438080 q12Shape42T532=true := by decide

private def q12Shape42T526 : Tree 12 := .split 39 q12Shape42T527 q12Shape42T532
private theorem q12Shape42T526OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 1091438080 q12Shape42T526=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 (1091438080 ||| 2^39) q12Shape42T527 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33560576 ||| 2^39) 1091438080 q12Shape42T532)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T527OK,q12Shape42T532OK⟩

private def q12Shape42T533 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T533OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107302400 17696256 q12Shape42T533=true := by decide

private def q12Shape42T525 : Tree 12 := .split 30 q12Shape42T526 q12Shape42T533
private theorem q12Shape42T525OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 17696256 q12Shape42T525=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33560576 (17696256 ||| 2^30) q12Shape42T526 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33560576 ||| 2^30) 17696256 q12Shape42T533)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T526OK,q12Shape42T533OK⟩

private def q12Shape42T523 : Tree 12 := .split 25 q12Shape42T524 q12Shape42T525
private theorem q12Shape42T523OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 6144 17696256 q12Shape42T523=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 6144 (17696256 ||| 2^25) q12Shape42T524 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (6144 ||| 2^25) 17696256 q12Shape42T525)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T524OK,q12Shape42T525OK⟩

private def q12Shape42T539 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T539OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 3849398912512 q12Shape42T539=true := by decide

private def q12Shape42T540 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T540OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040038912 1650375656960 q12Shape42T540=true := by decide

private def q12Shape42T538 : Tree 12 := .split 41 q12Shape42T539 q12Shape42T540
private theorem q12Shape42T538OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 1650375656960 q12Shape42T538=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 (1650375656960 ||| 2^41) q12Shape42T539 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16783360 ||| 2^41) 1650375656960 q12Shape42T540)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T539OK,q12Shape42T540OK⟩

private def q12Shape42T541 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T541OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528411136 550864029184 q12Shape42T541=true := by decide

private def q12Shape42T537 : Tree 12 := .split 40 q12Shape42T538 q12Shape42T541
private theorem q12Shape42T537OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 550864029184 q12Shape42T537=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 (550864029184 ||| 2^40) q12Shape42T538 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16783360 ||| 2^40) 550864029184 q12Shape42T541)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T538OK,q12Shape42T541OK⟩

private def q12Shape42T542 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T542OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772597248 1108215296 q12Shape42T542=true := by decide

private def q12Shape42T536 : Tree 12 := .split 39 q12Shape42T537 q12Shape42T542
private theorem q12Shape42T536OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 1108215296 q12Shape42T536=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 (1108215296 ||| 2^39) q12Shape42T537 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16783360 ||| 2^39) 1108215296 q12Shape42T542)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T537OK,q12Shape42T542OK⟩

private def q12Shape42T548 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {1,2,4,5,6,7,11})) (.split 26 (.tip (.cover {1,2,4,6,7,9,11})) (.tip (.cover {0,1,3,4,5,9,11})))) (.split 41 (.split 43 (.tip (.cover {1,2,4,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,9,10,11}))))
private theorem q12Shape42T548OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 550830597632 q12Shape42T548=true := by decide

private def q12Shape42T549 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {1,2,4,5,6,7,9})) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10,11}))) (.tip (.cover {2,3,4,5,9,10,11})))
private theorem q12Shape42T549OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549806151680 1074783744 q12Shape42T549=true := by decide

private def q12Shape42T547 : Tree 12 := .split 39 q12Shape42T548 q12Shape42T549
private theorem q12Shape42T547OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 1074783744 q12Shape42T547=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 (1074783744 ||| 2^39) q12Shape42T548 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50337792 ||| 2^39) 1074783744 q12Shape42T549)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T548OK,q12Shape42T549OK⟩

private def q12Shape42T550 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T550OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50403328 1074718208 q12Shape42T550=true := by decide

private def q12Shape42T546 : Tree 12 := .split 16 q12Shape42T547 q12Shape42T550
private theorem q12Shape42T546OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 1074718208 q12Shape42T546=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 (1074718208 ||| 2^16) q12Shape42T547 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50337792 ||| 2^16) 1074718208 q12Shape42T550)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T547OK,q12Shape42T550OK⟩

private def q12Shape42T551 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T551OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50370560 1074685440 q12Shape42T551=true := by decide

private def q12Shape42T545 : Tree 12 := .split 15 q12Shape42T546 q12Shape42T551
private theorem q12Shape42T545OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 1074685440 q12Shape42T545=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 (1074685440 ||| 2^15) q12Shape42T546 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50337792 ||| 2^15) 1074685440 q12Shape42T551)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T546OK,q12Shape42T551OK⟩

private def q12Shape42T552 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T552OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50354176 1074669056 q12Shape42T552=true := by decide

private def q12Shape42T544 : Tree 12 := .split 14 q12Shape42T545 q12Shape42T552
private theorem q12Shape42T544OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 1074669056 q12Shape42T544=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 (1074669056 ||| 2^14) q12Shape42T545 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50337792 ||| 2^14) 1074669056 q12Shape42T552)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T545OK,q12Shape42T552OK⟩

private def q12Shape42T553 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T553OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50345984 1074660864 q12Shape42T553=true := by decide

private def q12Shape42T543 : Tree 12 := .split 13 q12Shape42T544 q12Shape42T553
private theorem q12Shape42T543OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 1074660864 q12Shape42T543=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50337792 (1074660864 ||| 2^13) q12Shape42T544 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50337792 ||| 2^13) 1074660864 q12Shape42T553)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T544OK,q12Shape42T553OK⟩

private def q12Shape42T535 : Tree 12 := .split 25 q12Shape42T536 q12Shape42T543
private theorem q12Shape42T535OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 1074660864 q12Shape42T535=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 (1074660864 ||| 2^25) q12Shape42T536 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16783360 ||| 2^25) 1074660864 q12Shape42T543)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T536OK,q12Shape42T543OK⟩

private def q12Shape42T554 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T554OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090525184 919040 q12Shape42T554=true := by decide

private def q12Shape42T534 : Tree 12 := .split 30 q12Shape42T535 q12Shape42T554
private theorem q12Shape42T534OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 919040 q12Shape42T534=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16783360 (919040 ||| 2^30) q12Shape42T535 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16783360 ||| 2^30) 919040 q12Shape42T554)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T535OK,q12Shape42T554OK⟩

private def q12Shape42T522 : Tree 12 := .split 24 q12Shape42T523 q12Shape42T534
private theorem q12Shape42T522OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 6144 919040 q12Shape42T522=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 6144 (919040 ||| 2^24) q12Shape42T523 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (6144 ||| 2^24) 919040 q12Shape42T534)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T523OK,q12Shape42T534OK⟩

def q12Shape42P16 : Tree 12 := q12Shape42T522
theorem q12Shape42P16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 6144 919040 q12Shape42P16=true := q12Shape42T522OK

end Graffiti384b.EffectiveSearch.Q12
