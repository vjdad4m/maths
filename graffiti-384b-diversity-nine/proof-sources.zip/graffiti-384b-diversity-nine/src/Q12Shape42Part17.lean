import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T582 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape42T582OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 3849418573312 q12Shape42T582=true := by decide

private def q12Shape42T583 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T583OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2365440 3849416476160 q12Shape42T583=true := by decide

private def q12Shape42T581 : Tree 12 := .split 21 q12Shape42T582 q12Shape42T583
private theorem q12Shape42T581OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 3849416476160 q12Shape42T581=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (3849416476160 ||| 2^21) q12Shape42T582 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^21) 3849416476160 q12Shape42T583)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T582OK,q12Shape42T583OK⟩

private def q12Shape42T584 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T584OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1316864 3849415427584 q12Shape42T584=true := by decide

private def q12Shape42T580 : Tree 12 := .split 20 q12Shape42T581 q12Shape42T584
private theorem q12Shape42T580OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 3849415427584 q12Shape42T580=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (3849415427584 ||| 2^20) q12Shape42T581 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^20) 3849415427584 q12Shape42T584)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T581OK,q12Shape42T584OK⟩

private def q12Shape42T585 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T585OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023523840 1650392172032 q12Shape42T585=true := by decide

private def q12Shape42T579 : Tree 12 := .split 41 q12Shape42T580 q12Shape42T585
private theorem q12Shape42T579OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 1650392172032 q12Shape42T579=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (1650392172032 ||| 2^41) q12Shape42T580 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^41) 1650392172032 q12Shape42T585)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T580OK,q12Shape42T585OK⟩

private def q12Shape42T586 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T586OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511896064 550880544256 q12Shape42T586=true := by decide

private def q12Shape42T578 : Tree 12 := .split 40 q12Shape42T579 q12Shape42T586
private theorem q12Shape42T578OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 550880544256 q12Shape42T578=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (550880544256 ||| 2^40) q12Shape42T579 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^40) 550880544256 q12Shape42T586)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T579OK,q12Shape42T586OK⟩

private def q12Shape42T587 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T587OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756082176 1124730368 q12Shape42T587=true := by decide

private def q12Shape42T577 : Tree 12 := .split 39 q12Shape42T578 q12Shape42T587
private theorem q12Shape42T577OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 1124730368 q12Shape42T577=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (1124730368 ||| 2^39) q12Shape42T578 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^39) 1124730368 q12Shape42T587)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T578OK,q12Shape42T587OK⟩

private def q12Shape42T588 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T588OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074010112 50988544 q12Shape42T588=true := by decide

private def q12Shape42T576 : Tree 12 := .split 30 q12Shape42T577 q12Shape42T588
private theorem q12Shape42T576OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 50988544 q12Shape42T576=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (50988544 ||| 2^30) q12Shape42T577 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^30) 50988544 q12Shape42T588)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T577OK,q12Shape42T588OK⟩

private def q12Shape42T589 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape42T589OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33822720 17434112 q12Shape42T589=true := by decide

private def q12Shape42T575 : Tree 12 := .split 25 q12Shape42T576 q12Shape42T589
private theorem q12Shape42T575OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 17434112 q12Shape42T575=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (17434112 ||| 2^25) q12Shape42T576 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^25) 17434112 q12Shape42T589)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T576OK,q12Shape42T589OK⟩

private def q12Shape42T590 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape42T590OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17045504 656896 q12Shape42T590=true := by decide

private def q12Shape42T574 : Tree 12 := .split 24 q12Shape42T575 q12Shape42T590
private theorem q12Shape42T574OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 656896 q12Shape42T574=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (656896 ||| 2^24) q12Shape42T575 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^24) 656896 q12Shape42T590)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T575OK,q12Shape42T590OK⟩

private def q12Shape42T596 : Tree 12 := (.split 15 (.split 16 (.split 20 (.split 21 (.split 39 (.tip (.cover {1,2,5,6,7,10,11})) (.split 40 (.split 22 (.tip (.cover {1,2,5,6,7,9,11})) (.tip (.cover {0,1,3,4,5,8,11}))) (.tip (.cover {2,3,4,5,9,10,11})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))
private theorem q12Shape42T596OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 1124230656 q12Shape42T596=true := by decide

private def q12Shape42T597 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T597OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 808960 1124214272 q12Shape42T597=true := by decide

private def q12Shape42T595 : Tree 12 := .split 14 q12Shape42T596 q12Shape42T597
private theorem q12Shape42T595OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 1124214272 q12Shape42T595=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 (1124214272 ||| 2^14) q12Shape42T596 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (792576 ||| 2^14) 1124214272 q12Shape42T597)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T596OK,q12Shape42T597OK⟩

private def q12Shape42T598 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T598OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 800768 1124206080 q12Shape42T598=true := by decide

private def q12Shape42T594 : Tree 12 := .split 13 q12Shape42T595 q12Shape42T598
private theorem q12Shape42T594OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 1124206080 q12Shape42T594=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 (1124206080 ||| 2^13) q12Shape42T595 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (792576 ||| 2^13) 1124206080 q12Shape42T598)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T595OK,q12Shape42T598OK⟩

private def q12Shape42T599 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T599OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34347008 1090651648 q12Shape42T599=true := by decide

private def q12Shape42T593 : Tree 12 := .split 25 q12Shape42T594 q12Shape42T599
private theorem q12Shape42T593OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 1090651648 q12Shape42T593=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 (1090651648 ||| 2^25) q12Shape42T594 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (792576 ||| 2^25) 1090651648 q12Shape42T599)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T594OK,q12Shape42T599OK⟩

private def q12Shape42T600 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T600OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074534400 16909824 q12Shape42T600=true := by decide

private def q12Shape42T592 : Tree 12 := .split 30 q12Shape42T593 q12Shape42T600
private theorem q12Shape42T592OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 16909824 q12Shape42T592=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 (16909824 ||| 2^30) q12Shape42T593 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (792576 ||| 2^30) 16909824 q12Shape42T600)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T593OK,q12Shape42T600OK⟩

private def q12Shape42T601 : Tree 12 := (.split 25 (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {2,6,7,8,9,10,11})))
private theorem q12Shape42T601OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17569792 132608 q12Shape42T601=true := by decide

private def q12Shape42T591 : Tree 12 := .split 24 q12Shape42T592 q12Shape42T601
private theorem q12Shape42T591OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 132608 q12Shape42T591=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 792576 (132608 ||| 2^24) q12Shape42T592 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (792576 ||| 2^24) 132608 q12Shape42T601)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T592OK,q12Shape42T601OK⟩

private def q12Shape42T573 : Tree 12 := .split 19 q12Shape42T574 q12Shape42T591
private theorem q12Shape42T573OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 132608 q12Shape42T573=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 (132608 ||| 2^19) q12Shape42T574 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (268288 ||| 2^19) 132608 q12Shape42T591)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T574OK,q12Shape42T591OK⟩

def q12Shape42P18 : Tree 12 := q12Shape42T573
theorem q12Shape42P18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 268288 132608 q12Shape42P18=true := q12Shape42T573OK

private def q12Shape42T603 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T603OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 137216 1536 q12Shape42T603=true := by decide

def q12Shape42P19 : Tree 12 := q12Shape42T603
theorem q12Shape42P19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 137216 1536 q12Shape42P19=true := q12Shape42T603OK

end Graffiti384b.EffectiveSearch.Q12
