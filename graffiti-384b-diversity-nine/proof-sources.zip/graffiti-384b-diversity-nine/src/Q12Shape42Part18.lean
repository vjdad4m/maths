import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T608 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T608OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1024 1074665984 q12Shape42T608=true := by decide

private def q12Shape42T614 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape42T614OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 3848341953024 q12Shape42T614=true := by decide

private def q12Shape42T615 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T615OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200096998400 1649318697472 q12Shape42T615=true := by decide

private def q12Shape42T613 : Tree 12 := .split 41 q12Shape42T614 q12Shape42T615
private theorem q12Shape42T613OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 1649318697472 q12Shape42T613=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 (1649318697472 ||| 2^41) q12Shape42T614 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742848 ||| 2^41) 1649318697472 q12Shape42T615)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T614OK,q12Shape42T615OK⟩

private def q12Shape42T616 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T616OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585370624 549807069696 q12Shape42T616=true := by decide

private def q12Shape42T612 : Tree 12 := .split 40 q12Shape42T613 q12Shape42T616
private theorem q12Shape42T612OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 549807069696 q12Shape42T612=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 (549807069696 ||| 2^40) q12Shape42T613 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742848 ||| 2^40) 549807069696 q12Shape42T616)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T613OK,q12Shape42T616OK⟩

private def q12Shape42T617 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T617OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829556736 51255808 q12Shape42T617=true := by decide

private def q12Shape42T611 : Tree 12 := .split 39 q12Shape42T612 q12Shape42T617
private theorem q12Shape42T611OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 51255808 q12Shape42T611=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 (51255808 ||| 2^39) q12Shape42T612 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742848 ||| 2^39) 51255808 q12Shape42T617)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T612OK,q12Shape42T617OK⟩

private def q12Shape42T625 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape42T625OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 3848308521472 q12Shape42T625=true := by decide

private def q12Shape42T626 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T626OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200130552832 1649285265920 q12Shape42T626=true := by decide

private def q12Shape42T624 : Tree 12 := .split 41 q12Shape42T625 q12Shape42T626
private theorem q12Shape42T624OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 1649285265920 q12Shape42T624=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 (1649285265920 ||| 2^41) q12Shape42T625 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107297280 ||| 2^41) 1649285265920 q12Shape42T626)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T625OK,q12Shape42T626OK⟩

private def q12Shape42T627 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T627OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100618925056 549773638144 q12Shape42T627=true := by decide

private def q12Shape42T623 : Tree 12 := .split 40 q12Shape42T624 q12Shape42T627
private theorem q12Shape42T623OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 549773638144 q12Shape42T623=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 (549773638144 ||| 2^40) q12Shape42T624 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107297280 ||| 2^40) 549773638144 q12Shape42T627)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T624OK,q12Shape42T627OK⟩

private def q12Shape42T628 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T628OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550863111168 17824256 q12Shape42T628=true := by decide

private def q12Shape42T622 : Tree 12 := .split 39 q12Shape42T623 q12Shape42T628
private theorem q12Shape42T622OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 17824256 q12Shape42T622=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 (17824256 ||| 2^39) q12Shape42T623 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107297280 ||| 2^39) 17824256 q12Shape42T628)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T623OK,q12Shape42T628OK⟩

private def q12Shape42T629 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T629OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107362816 17758720 q12Shape42T629=true := by decide

private def q12Shape42T621 : Tree 12 := .split 16 q12Shape42T622 q12Shape42T629
private theorem q12Shape42T621OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 17758720 q12Shape42T621=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 (17758720 ||| 2^16) q12Shape42T622 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107297280 ||| 2^16) 17758720 q12Shape42T629)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T622OK,q12Shape42T629OK⟩

private def q12Shape42T630 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T630OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107330048 17725952 q12Shape42T630=true := by decide

private def q12Shape42T620 : Tree 12 := .split 15 q12Shape42T621 q12Shape42T630
private theorem q12Shape42T620OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 17725952 q12Shape42T620=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 (17725952 ||| 2^15) q12Shape42T621 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107297280 ||| 2^15) 17725952 q12Shape42T630)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T621OK,q12Shape42T630OK⟩

private def q12Shape42T631 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T631OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107313664 17709568 q12Shape42T631=true := by decide

private def q12Shape42T619 : Tree 12 := .split 14 q12Shape42T620 q12Shape42T631
private theorem q12Shape42T619OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 17709568 q12Shape42T619=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 (17709568 ||| 2^14) q12Shape42T620 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107297280 ||| 2^14) 17709568 q12Shape42T631)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T620OK,q12Shape42T631OK⟩

private def q12Shape42T632 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T632OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107305472 17701376 q12Shape42T632=true := by decide

private def q12Shape42T618 : Tree 12 := .split 13 q12Shape42T619 q12Shape42T632
private theorem q12Shape42T618OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 17701376 q12Shape42T618=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297280 (17701376 ||| 2^13) q12Shape42T619 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107297280 ||| 2^13) 17701376 q12Shape42T632)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T619OK,q12Shape42T632OK⟩

private def q12Shape42T610 : Tree 12 := .split 25 q12Shape42T611 q12Shape42T618
private theorem q12Shape42T610OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 17701376 q12Shape42T610=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 (17701376 ||| 2^25) q12Shape42T611 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742848 ||| 2^25) 17701376 q12Shape42T618)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T611OK,q12Shape42T618OK⟩

private def q12Shape42T641 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape42T641OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 3848325298688 q12Shape42T641=true := by decide

private def q12Shape42T642 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T642OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200113775616 1649302043136 q12Shape42T642=true := by decide

private def q12Shape42T640 : Tree 12 := .split 41 q12Shape42T641 q12Shape42T642
private theorem q12Shape42T640OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 1649302043136 q12Shape42T640=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (1649302043136 ||| 2^41) q12Shape42T641 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^41) 1649302043136 q12Shape42T642)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T641OK,q12Shape42T642OK⟩

private def q12Shape42T643 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T643OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100602147840 549790415360 q12Shape42T643=true := by decide

private def q12Shape42T639 : Tree 12 := .split 40 q12Shape42T640 q12Shape42T643
private theorem q12Shape42T639OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 549790415360 q12Shape42T639=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (549790415360 ||| 2^40) q12Shape42T640 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^40) 549790415360 q12Shape42T643)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T640OK,q12Shape42T643OK⟩

private def q12Shape42T644 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T644OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550846333952 34601472 q12Shape42T644=true := by decide

private def q12Shape42T638 : Tree 12 := .split 39 q12Shape42T639 q12Shape42T644
private theorem q12Shape42T638OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 34601472 q12Shape42T638=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (34601472 ||| 2^39) q12Shape42T639 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^39) 34601472 q12Shape42T644)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T639OK,q12Shape42T644OK⟩

private def q12Shape42T645 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T645OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090585600 34535936 q12Shape42T645=true := by decide

private def q12Shape42T637 : Tree 12 := .split 16 q12Shape42T638 q12Shape42T645
private theorem q12Shape42T637OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 34535936 q12Shape42T637=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (34535936 ||| 2^16) q12Shape42T638 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^16) 34535936 q12Shape42T645)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T638OK,q12Shape42T645OK⟩

private def q12Shape42T646 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T646OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090552832 34503168 q12Shape42T646=true := by decide

private def q12Shape42T636 : Tree 12 := .split 15 q12Shape42T637 q12Shape42T646
private theorem q12Shape42T636OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 34503168 q12Shape42T636=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (34503168 ||| 2^15) q12Shape42T637 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^15) 34503168 q12Shape42T646)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T637OK,q12Shape42T646OK⟩

private def q12Shape42T647 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T647OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090536448 34486784 q12Shape42T647=true := by decide

private def q12Shape42T635 : Tree 12 := .split 14 q12Shape42T636 q12Shape42T647
private theorem q12Shape42T635OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 34486784 q12Shape42T635=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (34486784 ||| 2^14) q12Shape42T636 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^14) 34486784 q12Shape42T647)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T636OK,q12Shape42T647OK⟩

private def q12Shape42T648 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T648OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090528256 34478592 q12Shape42T648=true := by decide

private def q12Shape42T634 : Tree 12 := .split 13 q12Shape42T635 q12Shape42T648
private theorem q12Shape42T634OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 34478592 q12Shape42T634=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (34478592 ||| 2^13) q12Shape42T635 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^13) 34478592 q12Shape42T648)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T635OK,q12Shape42T648OK⟩

private def q12Shape42T649 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T649OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1124074496 924160 q12Shape42T649=true := by decide

private def q12Shape42T633 : Tree 12 := .split 25 q12Shape42T634 q12Shape42T649
private theorem q12Shape42T633OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 924160 q12Shape42T633=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520064 (924160 ||| 2^25) q12Shape42T634 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090520064 ||| 2^25) 924160 q12Shape42T649)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T634OK,q12Shape42T649OK⟩

private def q12Shape42T609 : Tree 12 := .split 24 q12Shape42T610 q12Shape42T633
private theorem q12Shape42T609OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 924160 q12Shape42T609=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742848 (924160 ||| 2^24) q12Shape42T610 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742848 ||| 2^24) 924160 q12Shape42T633)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T610OK,q12Shape42T633OK⟩

private def q12Shape42T607 : Tree 12 := .split 30 q12Shape42T608 q12Shape42T609
private theorem q12Shape42T607OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1024 924160 q12Shape42T607=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1024 (924160 ||| 2^30) q12Shape42T608 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1024 ||| 2^30) 924160 q12Shape42T609)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T608OK,q12Shape42T609OK⟩

def q12Shape42P20 : Tree 12 := q12Shape42T607
theorem q12Shape42P20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1024 924160 q12Shape42P20=true := q12Shape42T607OK

end Graffiti384b.EffectiveSearch.Q12
