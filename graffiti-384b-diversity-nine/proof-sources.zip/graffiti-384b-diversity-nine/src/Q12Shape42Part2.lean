import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T78 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 786432 50470400 q12Shape42T78=true := by decide

private def q12Shape42T83 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 3849381355008 q12Shape42T83=true := by decide

private def q12Shape42T84 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199057596416 1650358099456 q12Shape42T84=true := by decide

private def q12Shape42T82 : Tree 12 := .split 41 q12Shape42T83 q12Shape42T84
private theorem q12Shape42T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 1650358099456 q12Shape42T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 (1650358099456 ||| 2^41) q12Shape42T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34340864 ||| 2^41) 1650358099456 q12Shape42T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T83OK,q12Shape42T84OK⟩

private def q12Shape42T85 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545968640 550846471680 q12Shape42T85=true := by decide

private def q12Shape42T81 : Tree 12 := .split 40 q12Shape42T82 q12Shape42T85
private theorem q12Shape42T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 550846471680 q12Shape42T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 (550846471680 ||| 2^40) q12Shape42T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34340864 ||| 2^40) 550846471680 q12Shape42T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T82OK,q12Shape42T85OK⟩

private def q12Shape42T86 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549790154752 1090657792 q12Shape42T86=true := by decide

private def q12Shape42T80 : Tree 12 := .split 39 q12Shape42T81 q12Shape42T86
private theorem q12Shape42T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 1090657792 q12Shape42T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 (1090657792 ||| 2^39) q12Shape42T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34340864 ||| 2^39) 1090657792 q12Shape42T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T81OK,q12Shape42T86OK⟩

private def q12Shape42T87 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1108082688 16915968 q12Shape42T87=true := by decide

private def q12Shape42T79 : Tree 12 := .split 30 q12Shape42T80 q12Shape42T87
private theorem q12Shape42T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 16915968 q12Shape42T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34340864 (16915968 ||| 2^30) q12Shape42T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34340864 ||| 2^30) 16915968 q12Shape42T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T80OK,q12Shape42T87OK⟩

private def q12Shape42T77 : Tree 12 := .split 25 q12Shape42T78 q12Shape42T79
private theorem q12Shape42T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 786432 16915968 q12Shape42T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 786432 (16915968 ||| 2^25) q12Shape42T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (786432 ||| 2^25) 16915968 q12Shape42T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T78OK,q12Shape42T79OK⟩

private def q12Shape42T93 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 3849398132224 q12Shape42T93=true := by decide

private def q12Shape42T94 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040819200 1650374876672 q12Shape42T94=true := by decide

private def q12Shape42T92 : Tree 12 := .split 41 q12Shape42T93 q12Shape42T94
private theorem q12Shape42T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 1650374876672 q12Shape42T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 (1650374876672 ||| 2^41) q12Shape42T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17563648 ||| 2^41) 1650374876672 q12Shape42T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T93OK,q12Shape42T94OK⟩

private def q12Shape42T95 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099529191424 550863248896 q12Shape42T95=true := by decide

private def q12Shape42T91 : Tree 12 := .split 40 q12Shape42T92 q12Shape42T95
private theorem q12Shape42T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 550863248896 q12Shape42T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 (550863248896 ||| 2^40) q12Shape42T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17563648 ||| 2^40) 550863248896 q12Shape42T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T92OK,q12Shape42T95OK⟩

private def q12Shape42T96 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549773377536 1107435008 q12Shape42T96=true := by decide

private def q12Shape42T90 : Tree 12 := .split 39 q12Shape42T91 q12Shape42T96
private theorem q12Shape42T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 1107435008 q12Shape42T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 (1107435008 ||| 2^39) q12Shape42T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17563648 ||| 2^39) 1107435008 q12Shape42T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T91OK,q12Shape42T96OK⟩

private def q12Shape42T100 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 42 (.tip (.cover {1,2,3,5,6,7,11})) (.split 26 (.tip (.cover {1,2,3,6,7,9,11})) (.tip (.cover {0,1,3,4,5,9,11})))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape42T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51118080 3849364577792 q12Shape42T100=true := by decide

private def q12Shape42T101 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,9,10}))) (.tip (.cover {2,3,4,5,8,9,10}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199074373632 1650341322240 q12Shape42T101=true := by decide

private def q12Shape42T99 : Tree 12 := .split 41 q12Shape42T100 q12Shape42T101
private theorem q12Shape42T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51118080 1650341322240 q12Shape42T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51118080 (1650341322240 ||| 2^41) q12Shape42T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (51118080 ||| 2^41) 1650341322240 q12Shape42T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T100OK,q12Shape42T101OK⟩

private def q12Shape42T102 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,9,11}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,8,9,11}))) (.tip (.cover {2,3,4,5,9,10,11})))
private theorem q12Shape42T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099562745856 550829694464 q12Shape42T102=true := by decide

private def q12Shape42T98 : Tree 12 := .split 40 q12Shape42T99 q12Shape42T102
private theorem q12Shape42T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51118080 550829694464 q12Shape42T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51118080 (550829694464 ||| 2^40) q12Shape42T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (51118080 ||| 2^40) 550829694464 q12Shape42T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T99OK,q12Shape42T102OK⟩

private def q12Shape42T103 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,8,10,11}))) (.tip (.cover {2,3,4,5,8,10,11}))) (.tip (.cover {2,3,4,5,9,10,11}))) (.tip (.cover {2,3,4,5,9,10,11})))
private theorem q12Shape42T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549806931968 1073880576 q12Shape42T103=true := by decide

private def q12Shape42T97 : Tree 12 := .split 39 q12Shape42T98 q12Shape42T103
private theorem q12Shape42T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51118080 1073880576 q12Shape42T97=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 51118080 (1073880576 ||| 2^39) q12Shape42T98 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (51118080 ||| 2^39) 1073880576 q12Shape42T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T98OK,q12Shape42T103OK⟩

private def q12Shape42T89 : Tree 12 := .split 25 q12Shape42T90 q12Shape42T97
private theorem q12Shape42T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 1073880576 q12Shape42T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 (1073880576 ||| 2^25) q12Shape42T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17563648 ||| 2^25) 1073880576 q12Shape42T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T90OK,q12Shape42T97OK⟩

private def q12Shape42T104 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091305472 138752 q12Shape42T104=true := by decide

private def q12Shape42T88 : Tree 12 := .split 30 q12Shape42T89 q12Shape42T104
private theorem q12Shape42T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 138752 q12Shape42T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17563648 (138752 ||| 2^30) q12Shape42T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17563648 ||| 2^30) 138752 q12Shape42T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T89OK,q12Shape42T104OK⟩

private def q12Shape42T76 : Tree 12 := .split 24 q12Shape42T77 q12Shape42T88
private theorem q12Shape42T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 786432 138752 q12Shape42T76=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 786432 (138752 ||| 2^24) q12Shape42T77 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (786432 ||| 2^24) 138752 q12Shape42T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T77OK,q12Shape42T88OK⟩

def q12Shape42P2 : Tree 12 := q12Shape42T76
theorem q12Shape42P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 786432 138752 q12Shape42P2=true := q12Shape42T76OK

end Graffiti384b.EffectiveSearch.Q12
