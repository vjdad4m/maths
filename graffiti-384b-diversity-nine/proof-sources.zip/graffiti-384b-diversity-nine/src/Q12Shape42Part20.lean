import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T691 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape42T691OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 3849415432704 q12Shape42T691=true := by decide

private def q12Shape42T692 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T692OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023518720 1650392177152 q12Shape42T692=true := by decide

private def q12Shape42T690 : Tree 12 := .split 41 q12Shape42T691 q12Shape42T692
private theorem q12Shape42T690OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 1650392177152 q12Shape42T690=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 (1650392177152 ||| 2^41) q12Shape42T691 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263168 ||| 2^41) 1650392177152 q12Shape42T692)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T691OK,q12Shape42T692OK⟩

private def q12Shape42T693 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T693OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511890944 550880549376 q12Shape42T693=true := by decide

private def q12Shape42T689 : Tree 12 := .split 40 q12Shape42T690 q12Shape42T693
private theorem q12Shape42T689OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 550880549376 q12Shape42T689=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 (550880549376 ||| 2^40) q12Shape42T690 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263168 ||| 2^40) 550880549376 q12Shape42T693)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T690OK,q12Shape42T693OK⟩

private def q12Shape42T694 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape42T694OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756077056 1124735488 q12Shape42T694=true := by decide

private def q12Shape42T688 : Tree 12 := .split 39 q12Shape42T689 q12Shape42T694
private theorem q12Shape42T688OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 1124735488 q12Shape42T688=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 (1124735488 ||| 2^39) q12Shape42T689 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263168 ||| 2^39) 1124735488 q12Shape42T694)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T689OK,q12Shape42T694OK⟩

private def q12Shape42T695 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T695OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074004992 50993664 q12Shape42T695=true := by decide

private def q12Shape42T687 : Tree 12 := .split 30 q12Shape42T688 q12Shape42T695
private theorem q12Shape42T687OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 50993664 q12Shape42T687=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 (50993664 ||| 2^30) q12Shape42T688 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263168 ||| 2^30) 50993664 q12Shape42T695)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T688OK,q12Shape42T695OK⟩

private def q12Shape42T696 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T696OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33817600 17439232 q12Shape42T696=true := by decide

private def q12Shape42T686 : Tree 12 := .split 25 q12Shape42T687 q12Shape42T696
private theorem q12Shape42T686OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 17439232 q12Shape42T686=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 (17439232 ||| 2^25) q12Shape42T687 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263168 ||| 2^25) 17439232 q12Shape42T696)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T687OK,q12Shape42T696OK⟩

private def q12Shape42T708 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {0,1,2,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape42T708OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 550879623680 q12Shape42T708=true := by decide

private def q12Shape42T709 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {0,1,2,5,6,7,9})) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape42T709OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772854272 1123809792 q12Shape42T709=true := by decide

private def q12Shape42T707 : Tree 12 := .split 39 q12Shape42T708 q12Shape42T709
private theorem q12Shape42T707OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 1123809792 q12Shape42T707=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (1123809792 ||| 2^39) q12Shape42T708 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^39) 1123809792 q12Shape42T709)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T708OK,q12Shape42T709OK⟩

private def q12Shape42T710 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T710OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 25428992 1115421184 q12Shape42T710=true := by decide

private def q12Shape42T706 : Tree 12 := .split 23 q12Shape42T707 q12Shape42T710
private theorem q12Shape42T706OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 1115421184 q12Shape42T706=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (1115421184 ||| 2^23) q12Shape42T707 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^23) 1115421184 q12Shape42T710)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T707OK,q12Shape42T710OK⟩

private def q12Shape42T711 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T711OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 21234688 1111226880 q12Shape42T711=true := by decide

private def q12Shape42T705 : Tree 12 := .split 22 q12Shape42T706 q12Shape42T711
private theorem q12Shape42T705OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 1111226880 q12Shape42T705=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (1111226880 ||| 2^22) q12Shape42T706 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^22) 1111226880 q12Shape42T711)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T706OK,q12Shape42T711OK⟩

private def q12Shape42T712 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T712OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 19137536 1109129728 q12Shape42T712=true := by decide

private def q12Shape42T704 : Tree 12 := .split 21 q12Shape42T705 q12Shape42T712
private theorem q12Shape42T704OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 1109129728 q12Shape42T704=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (1109129728 ||| 2^21) q12Shape42T705 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^21) 1109129728 q12Shape42T712)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T705OK,q12Shape42T712OK⟩

private def q12Shape42T713 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T713OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 18088960 1108081152 q12Shape42T713=true := by decide

private def q12Shape42T703 : Tree 12 := .split 20 q12Shape42T704 q12Shape42T713
private theorem q12Shape42T703OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 1108081152 q12Shape42T703=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (1108081152 ||| 2^20) q12Shape42T704 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^20) 1108081152 q12Shape42T713)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T704OK,q12Shape42T713OK⟩

private def q12Shape42T714 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T714OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090782208 34339328 q12Shape42T714=true := by decide

private def q12Shape42T702 : Tree 12 := .split 30 q12Shape42T703 q12Shape42T714
private theorem q12Shape42T702OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 34339328 q12Shape42T702=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (34339328 ||| 2^30) q12Shape42T703 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^30) 34339328 q12Shape42T714)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T703OK,q12Shape42T714OK⟩

private def q12Shape42T715 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T715OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17105920 34273792 q12Shape42T715=true := by decide

private def q12Shape42T701 : Tree 12 := .split 16 q12Shape42T702 q12Shape42T715
private theorem q12Shape42T701OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 34273792 q12Shape42T701=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (34273792 ||| 2^16) q12Shape42T702 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^16) 34273792 q12Shape42T715)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T702OK,q12Shape42T715OK⟩

private def q12Shape42T716 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T716OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17073152 34241024 q12Shape42T716=true := by decide

private def q12Shape42T700 : Tree 12 := .split 15 q12Shape42T701 q12Shape42T716
private theorem q12Shape42T700OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 34241024 q12Shape42T700=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (34241024 ||| 2^15) q12Shape42T701 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^15) 34241024 q12Shape42T716)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T701OK,q12Shape42T716OK⟩

private def q12Shape42T717 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T717OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17056768 34224640 q12Shape42T717=true := by decide

private def q12Shape42T699 : Tree 12 := .split 14 q12Shape42T700 q12Shape42T717
private theorem q12Shape42T699OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 34224640 q12Shape42T699=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (34224640 ||| 2^14) q12Shape42T700 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^14) 34224640 q12Shape42T717)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T700OK,q12Shape42T717OK⟩

private def q12Shape42T718 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T718OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17048576 34216448 q12Shape42T718=true := by decide

private def q12Shape42T698 : Tree 12 := .split 13 q12Shape42T699 q12Shape42T718
private theorem q12Shape42T698OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 34216448 q12Shape42T698=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (34216448 ||| 2^13) q12Shape42T699 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^13) 34216448 q12Shape42T718)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T699OK,q12Shape42T718OK⟩

private def q12Shape42T719 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T719OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50594816 662016 q12Shape42T719=true := by decide

private def q12Shape42T697 : Tree 12 := .split 25 q12Shape42T698 q12Shape42T719
private theorem q12Shape42T697OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 662016 q12Shape42T697=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040384 (662016 ||| 2^25) q12Shape42T698 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040384 ||| 2^25) 662016 q12Shape42T719)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T698OK,q12Shape42T719OK⟩

private def q12Shape42T685 : Tree 12 := .split 24 q12Shape42T686 q12Shape42T697
private theorem q12Shape42T685OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 662016 q12Shape42T685=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 (662016 ||| 2^24) q12Shape42T686 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263168 ||| 2^24) 662016 q12Shape42T697)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T686OK,q12Shape42T697OK⟩

private def q12Shape42T720 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T720OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 787456 137728 q12Shape42T720=true := by decide

private def q12Shape42T684 : Tree 12 := .split 19 q12Shape42T685 q12Shape42T720
private theorem q12Shape42T684OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 137728 q12Shape42T684=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 (137728 ||| 2^19) q12Shape42T685 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263168 ||| 2^19) 137728 q12Shape42T720)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T685OK,q12Shape42T720OK⟩

def q12Shape42P22 : Tree 12 := q12Shape42T684
theorem q12Shape42P22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263168 137728 q12Shape42P22=true := q12Shape42T684OK

end Graffiti384b.EffectiveSearch.Q12
