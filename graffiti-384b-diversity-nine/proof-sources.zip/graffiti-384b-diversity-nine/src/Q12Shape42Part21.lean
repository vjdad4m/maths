import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T723 : Tree 12 := (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))))
private theorem q12Shape42T723OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132096 793088 q12Shape42T723=true := by decide

private def q12Shape42T734 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape42T734OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 3849415162368 q12Shape42T734=true := by decide

private def q12Shape42T735 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T735OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023911936 1650391906816 q12Shape42T735=true := by decide

private def q12Shape42T733 : Tree 12 := .split 41 q12Shape42T734 q12Shape42T735
private theorem q12Shape42T733OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 1650391906816 q12Shape42T733=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (1650391906816 ||| 2^41) q12Shape42T734 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^41) 1650391906816 q12Shape42T735)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T734OK,q12Shape42T735OK⟩

private def q12Shape42T736 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T736OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512284160 550880279040 q12Shape42T736=true := by decide

private def q12Shape42T732 : Tree 12 := .split 40 q12Shape42T733 q12Shape42T736
private theorem q12Shape42T732OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 550880279040 q12Shape42T732=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (550880279040 ||| 2^40) q12Shape42T733 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^40) 550880279040 q12Shape42T736)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T733OK,q12Shape42T736OK⟩

private def q12Shape42T737 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T737OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756470272 1124465152 q12Shape42T737=true := by decide

private def q12Shape42T731 : Tree 12 := .split 39 q12Shape42T732 q12Shape42T737
private theorem q12Shape42T731OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 1124465152 q12Shape42T731=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (1124465152 ||| 2^39) q12Shape42T732 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^39) 1124465152 q12Shape42T737)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T732OK,q12Shape42T737OK⟩

private def q12Shape42T738 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T738OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 721920 1124399616 q12Shape42T738=true := by decide

private def q12Shape42T730 : Tree 12 := .split 16 q12Shape42T731 q12Shape42T738
private theorem q12Shape42T730OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 1124399616 q12Shape42T730=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (1124399616 ||| 2^16) q12Shape42T731 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^16) 1124399616 q12Shape42T738)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T731OK,q12Shape42T738OK⟩

private def q12Shape42T739 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T739OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 689152 1124366848 q12Shape42T739=true := by decide

private def q12Shape42T729 : Tree 12 := .split 15 q12Shape42T730 q12Shape42T739
private theorem q12Shape42T729OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 1124366848 q12Shape42T729=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (1124366848 ||| 2^15) q12Shape42T730 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^15) 1124366848 q12Shape42T739)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T730OK,q12Shape42T739OK⟩

private def q12Shape42T740 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T740OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 672768 1124350464 q12Shape42T740=true := by decide

private def q12Shape42T728 : Tree 12 := .split 14 q12Shape42T729 q12Shape42T740
private theorem q12Shape42T728OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 1124350464 q12Shape42T728=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (1124350464 ||| 2^14) q12Shape42T729 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^14) 1124350464 q12Shape42T740)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T729OK,q12Shape42T740OK⟩

private def q12Shape42T741 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T741OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 664576 1124342272 q12Shape42T741=true := by decide

private def q12Shape42T727 : Tree 12 := .split 13 q12Shape42T728 q12Shape42T741
private theorem q12Shape42T727OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 1124342272 q12Shape42T727=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (1124342272 ||| 2^13) q12Shape42T728 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^13) 1124342272 q12Shape42T741)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T728OK,q12Shape42T741OK⟩

private def q12Shape42T742 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T742OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074398208 50600448 q12Shape42T742=true := by decide

private def q12Shape42T726 : Tree 12 := .split 30 q12Shape42T727 q12Shape42T742
private theorem q12Shape42T726OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 50600448 q12Shape42T726=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (50600448 ||| 2^30) q12Shape42T727 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^30) 50600448 q12Shape42T742)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T727OK,q12Shape42T742OK⟩

private def q12Shape42T743 : Tree 12 := (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))))
private theorem q12Shape42T743OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34210816 17046016 q12Shape42T743=true := by decide

private def q12Shape42T725 : Tree 12 := .split 25 q12Shape42T726 q12Shape42T743
private theorem q12Shape42T725OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 17046016 q12Shape42T725=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (17046016 ||| 2^25) q12Shape42T726 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^25) 17046016 q12Shape42T743)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T726OK,q12Shape42T743OK⟩

private def q12Shape42T744 : Tree 12 := (.split 25 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape42T744OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17433600 268800 q12Shape42T744=true := by decide

private def q12Shape42T724 : Tree 12 := .split 24 q12Shape42T725 q12Shape42T744
private theorem q12Shape42T724OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 268800 q12Shape42T724=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656384 (268800 ||| 2^24) q12Shape42T725 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (656384 ||| 2^24) 268800 q12Shape42T744)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T725OK,q12Shape42T744OK⟩

private def q12Shape42T722 : Tree 12 := .split 19 q12Shape42T723 q12Shape42T724
private theorem q12Shape42T722OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132096 268800 q12Shape42T722=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132096 (268800 ||| 2^19) q12Shape42T723 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (132096 ||| 2^19) 268800 q12Shape42T724)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T723OK,q12Shape42T724OK⟩

def q12Shape42P23 : Tree 12 := q12Shape42T722
theorem q12Shape42P23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132096 268800 q12Shape42P23=true := q12Shape42T722OK

end Graffiti384b.EffectiveSearch.Q12
