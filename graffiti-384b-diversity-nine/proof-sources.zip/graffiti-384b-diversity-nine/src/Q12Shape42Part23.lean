import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T773 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T773OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 1124993536 q12Shape42T773=true := by decide

private def q12Shape42T777 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape42T777OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746944 3848341948928 q12Shape42T777=true := by decide

private def q12Shape42T778 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T778OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200097002496 1649318693376 q12Shape42T778=true := by decide

private def q12Shape42T776 : Tree 12 := .split 41 q12Shape42T777 q12Shape42T778
private theorem q12Shape42T776OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746944 1649318693376 q12Shape42T776=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746944 (1649318693376 ||| 2^41) q12Shape42T777 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746944 ||| 2^41) 1649318693376 q12Shape42T778)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T777OK,q12Shape42T778OK⟩

private def q12Shape42T779 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T779OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585374720 549807065600 q12Shape42T779=true := by decide

private def q12Shape42T775 : Tree 12 := .split 40 q12Shape42T776 q12Shape42T779
private theorem q12Shape42T775OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746944 549807065600 q12Shape42T775=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746944 (549807065600 ||| 2^40) q12Shape42T776 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746944 ||| 2^40) 549807065600 q12Shape42T779)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T776OK,q12Shape42T779OK⟩

private def q12Shape42T780 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T780OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829560832 51251712 q12Shape42T780=true := by decide

private def q12Shape42T774 : Tree 12 := .split 39 q12Shape42T775 q12Shape42T780
private theorem q12Shape42T774OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746944 51251712 q12Shape42T774=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746944 (51251712 ||| 2^39) q12Shape42T775 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746944 ||| 2^39) 51251712 q12Shape42T780)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T775OK,q12Shape42T780OK⟩

private def q12Shape42T772 : Tree 12 := .split 30 q12Shape42T773 q12Shape42T774
private theorem q12Shape42T772OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 51251712 q12Shape42T772=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 (51251712 ||| 2^30) q12Shape42T773 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (5120 ||| 2^30) 51251712 q12Shape42T774)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T773OK,q12Shape42T774OK⟩

private def q12Shape42T781 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T781OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559552 17697280 q12Shape42T781=true := by decide

private def q12Shape42T771 : Tree 12 := .split 25 q12Shape42T772 q12Shape42T781
private theorem q12Shape42T771OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 17697280 q12Shape42T771=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 (17697280 ||| 2^25) q12Shape42T772 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (5120 ||| 2^25) 17697280 q12Shape42T781)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T772OK,q12Shape42T781OK⟩

private def q12Shape42T787 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T787OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 3849398913536 q12Shape42T787=true := by decide

private def q12Shape42T788 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T788OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040037888 1650375657984 q12Shape42T788=true := by decide

private def q12Shape42T786 : Tree 12 := .split 41 q12Shape42T787 q12Shape42T788
private theorem q12Shape42T786OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 1650375657984 q12Shape42T786=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 (1650375657984 ||| 2^41) q12Shape42T787 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16782336 ||| 2^41) 1650375657984 q12Shape42T788)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T787OK,q12Shape42T788OK⟩

private def q12Shape42T789 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T789OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528410112 550864030208 q12Shape42T789=true := by decide

private def q12Shape42T785 : Tree 12 := .split 40 q12Shape42T786 q12Shape42T789
private theorem q12Shape42T785OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 550864030208 q12Shape42T785=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 (550864030208 ||| 2^40) q12Shape42T786 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16782336 ||| 2^40) 550864030208 q12Shape42T789)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T786OK,q12Shape42T789OK⟩

private def q12Shape42T790 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T790OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772596224 1108216320 q12Shape42T790=true := by decide

private def q12Shape42T784 : Tree 12 := .split 39 q12Shape42T785 q12Shape42T790
private theorem q12Shape42T784OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 1108216320 q12Shape42T784=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 (1108216320 ||| 2^39) q12Shape42T785 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16782336 ||| 2^39) 1108216320 q12Shape42T790)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T785OK,q12Shape42T790OK⟩

private def q12Shape42T796 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {1,2,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {1,2,4,5,6,7,10})) (.tip (.cover {2,3,4,6,8,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 41 (.split 43 (.tip (.cover {1,2,4,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,6,9,10,11}))))
private theorem q12Shape42T796OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 549790411264 q12Shape42T796=true := by decide

private def q12Shape42T797 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {1,2,4,5,6,7,9})) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {2,3,4,6,9,10,11}))) (.tip (.cover {2,3,4,6,9,10,11})))
private theorem q12Shape42T797OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550846338048 34597376 q12Shape42T797=true := by decide

private def q12Shape42T795 : Tree 12 := .split 39 q12Shape42T796 q12Shape42T797
private theorem q12Shape42T795OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 34597376 q12Shape42T795=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 (34597376 ||| 2^39) q12Shape42T796 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090524160 ||| 2^39) 34597376 q12Shape42T797)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T796OK,q12Shape42T797OK⟩

private def q12Shape42T798 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T798OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090589696 34531840 q12Shape42T798=true := by decide

private def q12Shape42T794 : Tree 12 := .split 16 q12Shape42T795 q12Shape42T798
private theorem q12Shape42T794OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 34531840 q12Shape42T794=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 (34531840 ||| 2^16) q12Shape42T795 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090524160 ||| 2^16) 34531840 q12Shape42T798)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T795OK,q12Shape42T798OK⟩

private def q12Shape42T799 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T799OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090556928 34499072 q12Shape42T799=true := by decide

private def q12Shape42T793 : Tree 12 := .split 15 q12Shape42T794 q12Shape42T799
private theorem q12Shape42T793OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 34499072 q12Shape42T793=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 (34499072 ||| 2^15) q12Shape42T794 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090524160 ||| 2^15) 34499072 q12Shape42T799)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T794OK,q12Shape42T799OK⟩

private def q12Shape42T800 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T800OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090540544 34482688 q12Shape42T800=true := by decide

private def q12Shape42T792 : Tree 12 := .split 14 q12Shape42T793 q12Shape42T800
private theorem q12Shape42T792OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 34482688 q12Shape42T792=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 (34482688 ||| 2^14) q12Shape42T793 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090524160 ||| 2^14) 34482688 q12Shape42T800)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T793OK,q12Shape42T800OK⟩

private def q12Shape42T801 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T801OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090532352 34474496 q12Shape42T801=true := by decide

private def q12Shape42T791 : Tree 12 := .split 13 q12Shape42T792 q12Shape42T801
private theorem q12Shape42T791OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 34474496 q12Shape42T791=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090524160 (34474496 ||| 2^13) q12Shape42T792 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090524160 ||| 2^13) 34474496 q12Shape42T801)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T792OK,q12Shape42T801OK⟩

private def q12Shape42T783 : Tree 12 := .split 30 q12Shape42T784 q12Shape42T791
private theorem q12Shape42T783OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 34474496 q12Shape42T783=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 (34474496 ||| 2^30) q12Shape42T784 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16782336 ||| 2^30) 34474496 q12Shape42T791)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T784OK,q12Shape42T791OK⟩

private def q12Shape42T802 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T802OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50336768 920064 q12Shape42T802=true := by decide

private def q12Shape42T782 : Tree 12 := .split 25 q12Shape42T783 q12Shape42T802
private theorem q12Shape42T782OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 920064 q12Shape42T782=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16782336 (920064 ||| 2^25) q12Shape42T783 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16782336 ||| 2^25) 920064 q12Shape42T802)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T783OK,q12Shape42T802OK⟩

private def q12Shape42T770 : Tree 12 := .split 24 q12Shape42T771 q12Shape42T782
private theorem q12Shape42T770OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 920064 q12Shape42T770=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 (920064 ||| 2^24) q12Shape42T771 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (5120 ||| 2^24) 920064 q12Shape42T782)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T771OK,q12Shape42T782OK⟩

def q12Shape42P25 : Tree 12 := q12Shape42T770
theorem q12Shape42P25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5120 920064 q12Shape42P25=true := q12Shape42T770OK

end Graffiti384b.EffectiveSearch.Q12
