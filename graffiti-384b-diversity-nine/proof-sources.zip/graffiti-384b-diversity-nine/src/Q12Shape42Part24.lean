import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T812 : Tree 12 := (.split 23 (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9})))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape42T812OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 3849422506496 q12Shape42T812=true := by decide

private def q12Shape42T813 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T813OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4723712 3849418312192 q12Shape42T813=true := by decide

private def q12Shape42T811 : Tree 12 := .split 22 q12Shape42T812 q12Shape42T813
private theorem q12Shape42T811OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 3849418312192 q12Shape42T811=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (3849418312192 ||| 2^22) q12Shape42T812 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^22) 3849418312192 q12Shape42T813)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T812OK,q12Shape42T813OK⟩

private def q12Shape42T814 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T814OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2626560 3849416215040 q12Shape42T814=true := by decide

private def q12Shape42T810 : Tree 12 := .split 21 q12Shape42T811 q12Shape42T814
private theorem q12Shape42T810OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 3849416215040 q12Shape42T810=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (3849416215040 ||| 2^21) q12Shape42T811 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^21) 3849416215040 q12Shape42T814)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T811OK,q12Shape42T814OK⟩

private def q12Shape42T815 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T815OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1577984 3849415166464 q12Shape42T815=true := by decide

private def q12Shape42T809 : Tree 12 := .split 20 q12Shape42T810 q12Shape42T815
private theorem q12Shape42T809OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 3849415166464 q12Shape42T809=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (3849415166464 ||| 2^20) q12Shape42T810 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^20) 3849415166464 q12Shape42T815)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T810OK,q12Shape42T815OK⟩

private def q12Shape42T816 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T816OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023784960 1650391910912 q12Shape42T816=true := by decide

private def q12Shape42T808 : Tree 12 := .split 41 q12Shape42T809 q12Shape42T816
private theorem q12Shape42T808OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 1650391910912 q12Shape42T808=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (1650391910912 ||| 2^41) q12Shape42T809 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^41) 1650391910912 q12Shape42T816)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T809OK,q12Shape42T816OK⟩

private def q12Shape42T817 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T817OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512157184 550880283136 q12Shape42T817=true := by decide

private def q12Shape42T807 : Tree 12 := .split 40 q12Shape42T808 q12Shape42T817
private theorem q12Shape42T807OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 550880283136 q12Shape42T807=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (550880283136 ||| 2^40) q12Shape42T808 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^40) 550880283136 q12Shape42T817)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T808OK,q12Shape42T817OK⟩

private def q12Shape42T818 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T818OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756343296 1124469248 q12Shape42T818=true := by decide

private def q12Shape42T806 : Tree 12 := .split 39 q12Shape42T807 q12Shape42T818
private theorem q12Shape42T806OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 1124469248 q12Shape42T806=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (1124469248 ||| 2^39) q12Shape42T807 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^39) 1124469248 q12Shape42T818)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T807OK,q12Shape42T818OK⟩

private def q12Shape42T819 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T819OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074271232 50727424 q12Shape42T819=true := by decide

private def q12Shape42T805 : Tree 12 := .split 30 q12Shape42T806 q12Shape42T819
private theorem q12Shape42T805OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 50727424 q12Shape42T805=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (50727424 ||| 2^30) q12Shape42T806 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^30) 50727424 q12Shape42T819)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T806OK,q12Shape42T819OK⟩

private def q12Shape42T820 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T820OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34083840 17172992 q12Shape42T820=true := by decide

private def q12Shape42T804 : Tree 12 := .split 25 q12Shape42T805 q12Shape42T820
private theorem q12Shape42T804OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 17172992 q12Shape42T804=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (17172992 ||| 2^25) q12Shape42T805 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^25) 17172992 q12Shape42T820)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T805OK,q12Shape42T820OK⟩

private def q12Shape42T821 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T821OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17306624 395776 q12Shape42T821=true := by decide

private def q12Shape42T803 : Tree 12 := .split 24 q12Shape42T804 q12Shape42T821
private theorem q12Shape42T803OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 395776 q12Shape42T803=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 (395776 ||| 2^24) q12Shape42T804 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (529408 ||| 2^24) 395776 q12Shape42T821)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T804OK,q12Shape42T821OK⟩

def q12Shape42P26 : Tree 12 := q12Shape42T803
theorem q12Shape42P26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 529408 395776 q12Shape42P26=true := q12Shape42T803OK

private def q12Shape42T823 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T823OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 267264 133632 q12Shape42T823=true := by decide

def q12Shape42P27 : Tree 12 := q12Shape42T823
theorem q12Shape42P27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 267264 133632 q12Shape42P27=true := q12Shape42T823OK

end Graffiti384b.EffectiveSearch.Q12
