import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T835 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape42T835OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 3849418705408 q12Shape42T835=true := by decide

private def q12Shape42T836 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T836OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2233344 3849416608256 q12Shape42T836=true := by decide

private def q12Shape42T834 : Tree 12 := .split 21 q12Shape42T835 q12Shape42T836
private theorem q12Shape42T834OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 3849416608256 q12Shape42T834=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (3849416608256 ||| 2^21) q12Shape42T835 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^21) 3849416608256 q12Shape42T836)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T835OK,q12Shape42T836OK⟩

private def q12Shape42T837 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T837OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1184768 3849415559680 q12Shape42T837=true := by decide

private def q12Shape42T833 : Tree 12 := .split 20 q12Shape42T834 q12Shape42T837
private theorem q12Shape42T833OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 3849415559680 q12Shape42T833=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (3849415559680 ||| 2^20) q12Shape42T834 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^20) 3849415559680 q12Shape42T837)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T834OK,q12Shape42T837OK⟩

private def q12Shape42T838 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T838OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023391744 1650392304128 q12Shape42T838=true := by decide

private def q12Shape42T832 : Tree 12 := .split 41 q12Shape42T833 q12Shape42T838
private theorem q12Shape42T832OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 1650392304128 q12Shape42T832=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (1650392304128 ||| 2^41) q12Shape42T833 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^41) 1650392304128 q12Shape42T838)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T833OK,q12Shape42T838OK⟩

private def q12Shape42T839 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T839OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511763968 550880676352 q12Shape42T839=true := by decide

private def q12Shape42T831 : Tree 12 := .split 40 q12Shape42T832 q12Shape42T839
private theorem q12Shape42T831OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 550880676352 q12Shape42T831=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (550880676352 ||| 2^40) q12Shape42T832 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^40) 550880676352 q12Shape42T839)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T832OK,q12Shape42T839OK⟩

private def q12Shape42T840 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T840OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549755950080 1124862464 q12Shape42T840=true := by decide

private def q12Shape42T830 : Tree 12 := .split 39 q12Shape42T831 q12Shape42T840
private theorem q12Shape42T830OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 1124862464 q12Shape42T830=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (1124862464 ||| 2^39) q12Shape42T831 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^39) 1124862464 q12Shape42T840)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T831OK,q12Shape42T840OK⟩

private def q12Shape42T841 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape42T841OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073878016 51120640 q12Shape42T841=true := by decide

private def q12Shape42T829 : Tree 12 := .split 30 q12Shape42T830 q12Shape42T841
private theorem q12Shape42T829OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 51120640 q12Shape42T829=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (51120640 ||| 2^30) q12Shape42T830 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^30) 51120640 q12Shape42T841)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T830OK,q12Shape42T841OK⟩

private def q12Shape42T842 : Tree 12 := (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))))
private theorem q12Shape42T842OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33690624 17566208 q12Shape42T842=true := by decide

private def q12Shape42T828 : Tree 12 := .split 25 q12Shape42T829 q12Shape42T842
private theorem q12Shape42T828OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 17566208 q12Shape42T828=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (17566208 ||| 2^25) q12Shape42T829 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^25) 17566208 q12Shape42T842)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T829OK,q12Shape42T842OK⟩

private def q12Shape42T843 : Tree 12 := (.split 25 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape42T843OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16913408 788992 q12Shape42T843=true := by decide

private def q12Shape42T827 : Tree 12 := .split 24 q12Shape42T828 q12Shape42T843
private theorem q12Shape42T827OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 788992 q12Shape42T827=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (788992 ||| 2^24) q12Shape42T828 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^24) 788992 q12Shape42T843)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T828OK,q12Shape42T843OK⟩

private def q12Shape42T849 : Tree 12 := (.split 15 (.split 16 (.split 20 (.split 21 (.split 39 (.tip (.cover {1,2,5,6,7,10,11})) (.split 40 (.split 22 (.tip (.cover {1,2,5,6,7,9,11})) (.tip (.cover {0,1,3,4,6,8,11}))) (.tip (.cover {2,3,4,6,9,10,11})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))
private theorem q12Shape42T849OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 1124362752 q12Shape42T849=true := by decide

private def q12Shape42T850 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T850OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 676864 1124346368 q12Shape42T850=true := by decide

private def q12Shape42T848 : Tree 12 := .split 14 q12Shape42T849 q12Shape42T850
private theorem q12Shape42T848OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 1124346368 q12Shape42T848=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 (1124346368 ||| 2^14) q12Shape42T849 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (660480 ||| 2^14) 1124346368 q12Shape42T850)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T849OK,q12Shape42T850OK⟩

private def q12Shape42T851 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T851OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 668672 1124338176 q12Shape42T851=true := by decide

private def q12Shape42T847 : Tree 12 := .split 13 q12Shape42T848 q12Shape42T851
private theorem q12Shape42T847OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 1124338176 q12Shape42T847=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 (1124338176 ||| 2^13) q12Shape42T848 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (660480 ||| 2^13) 1124338176 q12Shape42T851)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T848OK,q12Shape42T851OK⟩

private def q12Shape42T852 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T852OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074402304 50596352 q12Shape42T852=true := by decide

private def q12Shape42T846 : Tree 12 := .split 30 q12Shape42T847 q12Shape42T852
private theorem q12Shape42T846OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 50596352 q12Shape42T846=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 (50596352 ||| 2^30) q12Shape42T847 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (660480 ||| 2^30) 50596352 q12Shape42T852)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T847OK,q12Shape42T852OK⟩

private def q12Shape42T853 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T853OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34214912 17041920 q12Shape42T853=true := by decide

private def q12Shape42T845 : Tree 12 := .split 25 q12Shape42T846 q12Shape42T853
private theorem q12Shape42T845OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 17041920 q12Shape42T845=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 (17041920 ||| 2^25) q12Shape42T846 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (660480 ||| 2^25) 17041920 q12Shape42T853)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T846OK,q12Shape42T853OK⟩

private def q12Shape42T854 : Tree 12 := (.split 25 (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape42T854OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17437696 264704 q12Shape42T854=true := by decide

private def q12Shape42T844 : Tree 12 := .split 24 q12Shape42T845 q12Shape42T854
private theorem q12Shape42T844OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 264704 q12Shape42T844=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 660480 (264704 ||| 2^24) q12Shape42T845 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (660480 ||| 2^24) 264704 q12Shape42T854)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T845OK,q12Shape42T854OK⟩

private def q12Shape42T826 : Tree 12 := .split 19 q12Shape42T827 q12Shape42T844
private theorem q12Shape42T826OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 264704 q12Shape42T826=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (264704 ||| 2^19) q12Shape42T827 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^19) 264704 q12Shape42T844)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T827OK,q12Shape42T844OK⟩

private def q12Shape42T855 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T855OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 398336 2560 q12Shape42T855=true := by decide

private def q12Shape42T825 : Tree 12 := .split 18 q12Shape42T826 q12Shape42T855
private theorem q12Shape42T825OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 2560 q12Shape42T825=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 (2560 ||| 2^18) q12Shape42T826 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (136192 ||| 2^18) 2560 q12Shape42T855)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T826OK,q12Shape42T855OK⟩

def q12Shape42P28 : Tree 12 := q12Shape42T825
theorem q12Shape42P28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 136192 2560 q12Shape42P28=true := q12Shape42T825OK

end Graffiti384b.EffectiveSearch.Q12
