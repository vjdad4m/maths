import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T862 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T862OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 1124995584 q12Shape42T862=true := by decide

private def q12Shape42T866 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape42T866OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744896 3848341950976 q12Shape42T866=true := by decide

private def q12Shape42T867 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T867OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200097000448 1649318695424 q12Shape42T867=true := by decide

private def q12Shape42T865 : Tree 12 := .split 41 q12Shape42T866 q12Shape42T867
private theorem q12Shape42T865OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744896 1649318695424 q12Shape42T865=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744896 (1649318695424 ||| 2^41) q12Shape42T866 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744896 ||| 2^41) 1649318695424 q12Shape42T867)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T866OK,q12Shape42T867OK⟩

private def q12Shape42T868 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T868OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585372672 549807067648 q12Shape42T868=true := by decide

private def q12Shape42T864 : Tree 12 := .split 40 q12Shape42T865 q12Shape42T868
private theorem q12Shape42T864OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744896 549807067648 q12Shape42T864=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744896 (549807067648 ||| 2^40) q12Shape42T865 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744896 ||| 2^40) 549807067648 q12Shape42T868)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T865OK,q12Shape42T868OK⟩

private def q12Shape42T869 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T869OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829558784 51253760 q12Shape42T869=true := by decide

private def q12Shape42T863 : Tree 12 := .split 39 q12Shape42T864 q12Shape42T869
private theorem q12Shape42T863OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744896 51253760 q12Shape42T863=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744896 (51253760 ||| 2^39) q12Shape42T864 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744896 ||| 2^39) 51253760 q12Shape42T869)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T864OK,q12Shape42T869OK⟩

private def q12Shape42T861 : Tree 12 := .split 30 q12Shape42T862 q12Shape42T863
private theorem q12Shape42T861OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 51253760 q12Shape42T861=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 (51253760 ||| 2^30) q12Shape42T862 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (3072 ||| 2^30) 51253760 q12Shape42T863)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T862OK,q12Shape42T863OK⟩

private def q12Shape42T874 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T874OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 3849382138368 q12Shape42T874=true := by decide

private def q12Shape42T875 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T875OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199056813056 1650358882816 q12Shape42T875=true := by decide

private def q12Shape42T873 : Tree 12 := .split 41 q12Shape42T874 q12Shape42T875
private theorem q12Shape42T873OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 1650358882816 q12Shape42T873=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 (1650358882816 ||| 2^41) q12Shape42T874 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33557504 ||| 2^41) 1650358882816 q12Shape42T875)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T874OK,q12Shape42T875OK⟩

private def q12Shape42T876 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T876OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545185280 550847255040 q12Shape42T876=true := by decide

private def q12Shape42T872 : Tree 12 := .split 40 q12Shape42T873 q12Shape42T876
private theorem q12Shape42T872OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 550847255040 q12Shape42T872=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 (550847255040 ||| 2^40) q12Shape42T873 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33557504 ||| 2^40) 550847255040 q12Shape42T876)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T873OK,q12Shape42T876OK⟩

private def q12Shape42T877 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T877OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789371392 1091441152 q12Shape42T877=true := by decide

private def q12Shape42T871 : Tree 12 := .split 39 q12Shape42T872 q12Shape42T877
private theorem q12Shape42T871OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 1091441152 q12Shape42T871=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 (1091441152 ||| 2^39) q12Shape42T872 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33557504 ||| 2^39) 1091441152 q12Shape42T877)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T872OK,q12Shape42T877OK⟩

private def q12Shape42T883 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {1,2,4,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {1,2,4,5,6,7,10})) (.tip (.cover {2,3,4,7,8,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 41 (.split 43 (.tip (.cover {1,2,4,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,7,9,10,11}))))
private theorem q12Shape42T883OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 549773636096 q12Shape42T883=true := by decide

private def q12Shape42T884 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {1,2,4,5,6,7,9})) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {2,3,4,7,9,10,11}))) (.tip (.cover {2,3,4,7,9,10,11})))
private theorem q12Shape42T884OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550863113216 17822208 q12Shape42T884=true := by decide

private def q12Shape42T882 : Tree 12 := .split 39 q12Shape42T883 q12Shape42T884
private theorem q12Shape42T882OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 17822208 q12Shape42T882=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 (17822208 ||| 2^39) q12Shape42T883 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107299328 ||| 2^39) 17822208 q12Shape42T884)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T883OK,q12Shape42T884OK⟩

private def q12Shape42T885 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T885OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107364864 17756672 q12Shape42T885=true := by decide

private def q12Shape42T881 : Tree 12 := .split 16 q12Shape42T882 q12Shape42T885
private theorem q12Shape42T881OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 17756672 q12Shape42T881=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 (17756672 ||| 2^16) q12Shape42T882 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107299328 ||| 2^16) 17756672 q12Shape42T885)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T882OK,q12Shape42T885OK⟩

private def q12Shape42T886 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T886OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107332096 17723904 q12Shape42T886=true := by decide

private def q12Shape42T880 : Tree 12 := .split 15 q12Shape42T881 q12Shape42T886
private theorem q12Shape42T880OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 17723904 q12Shape42T880=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 (17723904 ||| 2^15) q12Shape42T881 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107299328 ||| 2^15) 17723904 q12Shape42T886)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T881OK,q12Shape42T886OK⟩

private def q12Shape42T887 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T887OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107315712 17707520 q12Shape42T887=true := by decide

private def q12Shape42T879 : Tree 12 := .split 14 q12Shape42T880 q12Shape42T887
private theorem q12Shape42T879OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 17707520 q12Shape42T879=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 (17707520 ||| 2^14) q12Shape42T880 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107299328 ||| 2^14) 17707520 q12Shape42T887)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T880OK,q12Shape42T887OK⟩

private def q12Shape42T888 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T888OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107307520 17699328 q12Shape42T888=true := by decide

private def q12Shape42T878 : Tree 12 := .split 13 q12Shape42T879 q12Shape42T888
private theorem q12Shape42T878OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 17699328 q12Shape42T878=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107299328 (17699328 ||| 2^13) q12Shape42T879 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107299328 ||| 2^13) 17699328 q12Shape42T888)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T879OK,q12Shape42T888OK⟩

private def q12Shape42T870 : Tree 12 := .split 30 q12Shape42T871 q12Shape42T878
private theorem q12Shape42T870OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 17699328 q12Shape42T870=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33557504 (17699328 ||| 2^30) q12Shape42T871 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33557504 ||| 2^30) 17699328 q12Shape42T878)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T871OK,q12Shape42T878OK⟩

private def q12Shape42T860 : Tree 12 := .split 25 q12Shape42T861 q12Shape42T870
private theorem q12Shape42T860OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 17699328 q12Shape42T860=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 (17699328 ||| 2^25) q12Shape42T861 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (3072 ||| 2^25) 17699328 q12Shape42T870)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T861OK,q12Shape42T870OK⟩

private def q12Shape42T889 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape42T889OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16780288 922112 q12Shape42T889=true := by decide

private def q12Shape42T859 : Tree 12 := .split 24 q12Shape42T860 q12Shape42T889
private theorem q12Shape42T859OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 922112 q12Shape42T859=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 (922112 ||| 2^24) q12Shape42T860 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (3072 ||| 2^24) 922112 q12Shape42T889)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T860OK,q12Shape42T889OK⟩

private def q12Shape42T890 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T890OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 527360 397824 q12Shape42T890=true := by decide

private def q12Shape42T858 : Tree 12 := .split 19 q12Shape42T859 q12Shape42T890
private theorem q12Shape42T858OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 397824 q12Shape42T858=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 (397824 ||| 2^19) q12Shape42T859 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (3072 ||| 2^19) 397824 q12Shape42T890)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T859OK,q12Shape42T890OK⟩

def q12Shape42P29 : Tree 12 := q12Shape42T858
theorem q12Shape42P29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3072 397824 q12Shape42P29=true := q12Shape42T858OK

end Graffiti384b.EffectiveSearch.Q12
