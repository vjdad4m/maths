import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T901 : Tree 12 := (.split 23 (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,9})))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape42T901OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 3849422770688 q12Shape42T901=true := by decide

private def q12Shape42T902 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T902OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4459520 3849418576384 q12Shape42T902=true := by decide

private def q12Shape42T900 : Tree 12 := .split 22 q12Shape42T901 q12Shape42T902
private theorem q12Shape42T900OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 3849418576384 q12Shape42T900=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (3849418576384 ||| 2^22) q12Shape42T901 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^22) 3849418576384 q12Shape42T902)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T901OK,q12Shape42T902OK⟩

private def q12Shape42T903 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T903OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2362368 3849416479232 q12Shape42T903=true := by decide

private def q12Shape42T899 : Tree 12 := .split 21 q12Shape42T900 q12Shape42T903
private theorem q12Shape42T899OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 3849416479232 q12Shape42T899=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (3849416479232 ||| 2^21) q12Shape42T900 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^21) 3849416479232 q12Shape42T903)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T900OK,q12Shape42T903OK⟩

private def q12Shape42T904 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T904OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1313792 3849415430656 q12Shape42T904=true := by decide

private def q12Shape42T898 : Tree 12 := .split 20 q12Shape42T899 q12Shape42T904
private theorem q12Shape42T898OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 3849415430656 q12Shape42T898=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (3849415430656 ||| 2^20) q12Shape42T899 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^20) 3849415430656 q12Shape42T904)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T899OK,q12Shape42T904OK⟩

private def q12Shape42T905 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T905OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023520768 1650392175104 q12Shape42T905=true := by decide

private def q12Shape42T897 : Tree 12 := .split 41 q12Shape42T898 q12Shape42T905
private theorem q12Shape42T897OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 1650392175104 q12Shape42T897=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (1650392175104 ||| 2^41) q12Shape42T898 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^41) 1650392175104 q12Shape42T905)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T898OK,q12Shape42T905OK⟩

private def q12Shape42T906 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T906OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511892992 550880547328 q12Shape42T906=true := by decide

private def q12Shape42T896 : Tree 12 := .split 40 q12Shape42T897 q12Shape42T906
private theorem q12Shape42T896OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 550880547328 q12Shape42T896=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (550880547328 ||| 2^40) q12Shape42T897 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^40) 550880547328 q12Shape42T906)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T897OK,q12Shape42T906OK⟩

private def q12Shape42T907 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape42T907OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756079104 1124733440 q12Shape42T907=true := by decide

private def q12Shape42T895 : Tree 12 := .split 39 q12Shape42T896 q12Shape42T907
private theorem q12Shape42T895OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 1124733440 q12Shape42T895=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (1124733440 ||| 2^39) q12Shape42T896 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^39) 1124733440 q12Shape42T907)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T896OK,q12Shape42T907OK⟩

private def q12Shape42T908 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T908OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074007040 50991616 q12Shape42T908=true := by decide

private def q12Shape42T894 : Tree 12 := .split 30 q12Shape42T895 q12Shape42T908
private theorem q12Shape42T894OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 50991616 q12Shape42T894=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (50991616 ||| 2^30) q12Shape42T895 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^30) 50991616 q12Shape42T908)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T895OK,q12Shape42T908OK⟩

private def q12Shape42T909 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T909OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33819648 17437184 q12Shape42T909=true := by decide

private def q12Shape42T893 : Tree 12 := .split 25 q12Shape42T894 q12Shape42T909
private theorem q12Shape42T893OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 17437184 q12Shape42T893=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (17437184 ||| 2^25) q12Shape42T894 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^25) 17437184 q12Shape42T909)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T894OK,q12Shape42T909OK⟩

private def q12Shape42T910 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape42T910OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17042432 659968 q12Shape42T910=true := by decide

private def q12Shape42T892 : Tree 12 := .split 24 q12Shape42T893 q12Shape42T910
private theorem q12Shape42T892OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 659968 q12Shape42T892=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (659968 ||| 2^24) q12Shape42T893 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^24) 659968 q12Shape42T910)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T893OK,q12Shape42T910OK⟩

private def q12Shape42T911 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T911OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 789504 135680 q12Shape42T911=true := by decide

private def q12Shape42T891 : Tree 12 := .split 19 q12Shape42T892 q12Shape42T911
private theorem q12Shape42T891OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 135680 q12Shape42T891=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 (135680 ||| 2^19) q12Shape42T892 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (265216 ||| 2^19) 135680 q12Shape42T911)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T892OK,q12Shape42T911OK⟩

def q12Shape42P30 : Tree 12 := q12Shape42T891
theorem q12Shape42P30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 265216 135680 q12Shape42P30=true := q12Shape42T891OK

end Graffiti384b.EffectiveSearch.Q12
