import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T954 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T954OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 1124998144 q12Shape42T954=true := by decide

private def q12Shape42T958 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape42T958OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742336 3848341953536 q12Shape42T958=true := by decide

private def q12Shape42T959 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T959OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200096997888 1649318697984 q12Shape42T959=true := by decide

private def q12Shape42T957 : Tree 12 := .split 41 q12Shape42T958 q12Shape42T959
private theorem q12Shape42T957OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742336 1649318697984 q12Shape42T957=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742336 (1649318697984 ||| 2^41) q12Shape42T958 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742336 ||| 2^41) 1649318697984 q12Shape42T959)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T958OK,q12Shape42T959OK⟩

private def q12Shape42T960 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T960OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585370112 549807070208 q12Shape42T960=true := by decide

private def q12Shape42T956 : Tree 12 := .split 40 q12Shape42T957 q12Shape42T960
private theorem q12Shape42T956OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742336 549807070208 q12Shape42T956=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742336 (549807070208 ||| 2^40) q12Shape42T957 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742336 ||| 2^40) 549807070208 q12Shape42T960)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T957OK,q12Shape42T960OK⟩

private def q12Shape42T961 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T961OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829556224 51256320 q12Shape42T961=true := by decide

private def q12Shape42T955 : Tree 12 := .split 39 q12Shape42T956 q12Shape42T961
private theorem q12Shape42T955OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742336 51256320 q12Shape42T955=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073742336 (51256320 ||| 2^39) q12Shape42T956 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073742336 ||| 2^39) 51256320 q12Shape42T961)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T956OK,q12Shape42T961OK⟩

private def q12Shape42T953 : Tree 12 := .split 30 q12Shape42T954 q12Shape42T955
private theorem q12Shape42T953OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 51256320 q12Shape42T953=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 (51256320 ||| 2^30) q12Shape42T954 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (512 ||| 2^30) 51256320 q12Shape42T955)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T954OK,q12Shape42T955OK⟩

private def q12Shape42T966 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape42T966OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 3849382140928 q12Shape42T966=true := by decide

private def q12Shape42T967 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T967OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199056810496 1650358885376 q12Shape42T967=true := by decide

private def q12Shape42T965 : Tree 12 := .split 41 q12Shape42T966 q12Shape42T967
private theorem q12Shape42T965OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 1650358885376 q12Shape42T965=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 (1650358885376 ||| 2^41) q12Shape42T966 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33554944 ||| 2^41) 1650358885376 q12Shape42T967)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T966OK,q12Shape42T967OK⟩

private def q12Shape42T968 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T968OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545182720 550847257600 q12Shape42T968=true := by decide

private def q12Shape42T964 : Tree 12 := .split 40 q12Shape42T965 q12Shape42T968
private theorem q12Shape42T964OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 550847257600 q12Shape42T964=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 (550847257600 ||| 2^40) q12Shape42T965 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33554944 ||| 2^40) 550847257600 q12Shape42T968)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T965OK,q12Shape42T968OK⟩

private def q12Shape42T969 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T969OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789368832 1091443712 q12Shape42T969=true := by decide

private def q12Shape42T963 : Tree 12 := .split 39 q12Shape42T964 q12Shape42T969
private theorem q12Shape42T963OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 1091443712 q12Shape42T963=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 (1091443712 ||| 2^39) q12Shape42T964 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33554944 ||| 2^39) 1091443712 q12Shape42T969)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T964OK,q12Shape42T969OK⟩

private def q12Shape42T970 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T970OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107296768 17701888 q12Shape42T970=true := by decide

private def q12Shape42T962 : Tree 12 := .split 30 q12Shape42T963 q12Shape42T970
private theorem q12Shape42T962OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 17701888 q12Shape42T962=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33554944 (17701888 ||| 2^30) q12Shape42T963 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33554944 ||| 2^30) 17701888 q12Shape42T970)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T963OK,q12Shape42T970OK⟩

private def q12Shape42T952 : Tree 12 := .split 25 q12Shape42T953 q12Shape42T962
private theorem q12Shape42T952OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 17701888 q12Shape42T952=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 (17701888 ||| 2^25) q12Shape42T953 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (512 ||| 2^25) 17701888 q12Shape42T962)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T953OK,q12Shape42T962OK⟩

private def q12Shape42T976 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,9}))))
private theorem q12Shape42T976OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 3849398918144 q12Shape42T976=true := by decide

private def q12Shape42T977 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T977OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040033280 1650375662592 q12Shape42T977=true := by decide

private def q12Shape42T975 : Tree 12 := .split 41 q12Shape42T976 q12Shape42T977
private theorem q12Shape42T975OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 1650375662592 q12Shape42T975=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 (1650375662592 ||| 2^41) q12Shape42T976 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16777728 ||| 2^41) 1650375662592 q12Shape42T977)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T976OK,q12Shape42T977OK⟩

private def q12Shape42T978 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,8,9}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T978OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528405504 550864034816 q12Shape42T978=true := by decide

private def q12Shape42T974 : Tree 12 := .split 40 q12Shape42T975 q12Shape42T978
private theorem q12Shape42T974OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 550864034816 q12Shape42T974=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 (550864034816 ||| 2^40) q12Shape42T975 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16777728 ||| 2^40) 550864034816 q12Shape42T978)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T975OK,q12Shape42T978OK⟩

private def q12Shape42T979 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape42T979OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772591616 1108220928 q12Shape42T979=true := by decide

private def q12Shape42T973 : Tree 12 := .split 39 q12Shape42T974 q12Shape42T979
private theorem q12Shape42T973OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 1108220928 q12Shape42T973=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 (1108220928 ||| 2^39) q12Shape42T974 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16777728 ||| 2^39) 1108220928 q12Shape42T979)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T974OK,q12Shape42T979OK⟩

private def q12Shape42T980 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T980OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090519552 34479104 q12Shape42T980=true := by decide

private def q12Shape42T972 : Tree 12 := .split 30 q12Shape42T973 q12Shape42T980
private theorem q12Shape42T972OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 34479104 q12Shape42T972=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 (34479104 ||| 2^30) q12Shape42T973 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16777728 ||| 2^30) 34479104 q12Shape42T980)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T973OK,q12Shape42T980OK⟩

private def q12Shape42T981 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T981OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50332160 924672 q12Shape42T981=true := by decide

private def q12Shape42T971 : Tree 12 := .split 25 q12Shape42T972 q12Shape42T981
private theorem q12Shape42T971OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 924672 q12Shape42T971=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16777728 (924672 ||| 2^25) q12Shape42T972 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16777728 ||| 2^25) 924672 q12Shape42T981)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T972OK,q12Shape42T981OK⟩

private def q12Shape42T951 : Tree 12 := .split 24 q12Shape42T952 q12Shape42T971
private theorem q12Shape42T951OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 924672 q12Shape42T951=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 (924672 ||| 2^24) q12Shape42T952 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (512 ||| 2^24) 924672 q12Shape42T971)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T952OK,q12Shape42T971OK⟩

def q12Shape42P33 : Tree 12 := q12Shape42T951
theorem q12Shape42P33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 512 924672 q12Shape42P33=true := q12Shape42T951OK

end Graffiti384b.EffectiveSearch.Q12
