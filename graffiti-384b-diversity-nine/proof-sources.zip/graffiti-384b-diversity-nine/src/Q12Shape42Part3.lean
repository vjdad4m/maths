import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T108 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131072 1074535936 q12Shape42T108=true := by decide

private def q12Shape42T114 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape42T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 3848341822976 q12Shape42T114=true := by decide

private def q12Shape42T115 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200097128448 1649318567424 q12Shape42T115=true := by decide

private def q12Shape42T113 : Tree 12 := .split 41 q12Shape42T114 q12Shape42T115
private theorem q12Shape42T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 1649318567424 q12Shape42T113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 (1649318567424 ||| 2^41) q12Shape42T114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073872896 ||| 2^41) 1649318567424 q12Shape42T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T114OK,q12Shape42T115OK⟩

private def q12Shape42T116 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585500672 549806939648 q12Shape42T116=true := by decide

private def q12Shape42T112 : Tree 12 := .split 40 q12Shape42T113 q12Shape42T116
private theorem q12Shape42T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 549806939648 q12Shape42T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 (549806939648 ||| 2^40) q12Shape42T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073872896 ||| 2^40) 549806939648 q12Shape42T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T113OK,q12Shape42T116OK⟩

private def q12Shape42T117 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829686784 51125760 q12Shape42T117=true := by decide

private def q12Shape42T111 : Tree 12 := .split 39 q12Shape42T112 q12Shape42T117
private theorem q12Shape42T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 51125760 q12Shape42T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 (51125760 ||| 2^39) q12Shape42T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073872896 ||| 2^39) 51125760 q12Shape42T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T112OK,q12Shape42T117OK⟩

private def q12Shape42T123 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9})))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape42T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 3848311414272 q12Shape42T123=true := by decide

private def q12Shape42T124 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1109524480 3848309317120 q12Shape42T124=true := by decide

private def q12Shape42T122 : Tree 12 := .split 21 q12Shape42T123 q12Shape42T124
private theorem q12Shape42T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 3848309317120 q12Shape42T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 (3848309317120 ||| 2^21) q12Shape42T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107427328 ||| 2^21) 3848309317120 q12Shape42T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T123OK,q12Shape42T124OK⟩

private def q12Shape42T125 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1108475904 3848308268544 q12Shape42T125=true := by decide

private def q12Shape42T121 : Tree 12 := .split 20 q12Shape42T122 q12Shape42T125
private theorem q12Shape42T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 3848308268544 q12Shape42T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 (3848308268544 ||| 2^20) q12Shape42T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107427328 ||| 2^20) 3848308268544 q12Shape42T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T122OK,q12Shape42T125OK⟩

private def q12Shape42T126 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200130682880 1649285012992 q12Shape42T126=true := by decide

private def q12Shape42T120 : Tree 12 := .split 41 q12Shape42T121 q12Shape42T126
private theorem q12Shape42T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 1649285012992 q12Shape42T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 (1649285012992 ||| 2^41) q12Shape42T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107427328 ||| 2^41) 1649285012992 q12Shape42T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T121OK,q12Shape42T126OK⟩

private def q12Shape42T127 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100619055104 549773385216 q12Shape42T127=true := by decide

private def q12Shape42T119 : Tree 12 := .split 40 q12Shape42T120 q12Shape42T127
private theorem q12Shape42T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 549773385216 q12Shape42T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 (549773385216 ||| 2^40) q12Shape42T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107427328 ||| 2^40) 549773385216 q12Shape42T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T120OK,q12Shape42T127OK⟩

private def q12Shape42T128 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550863241216 17571328 q12Shape42T128=true := by decide

private def q12Shape42T118 : Tree 12 := .split 39 q12Shape42T119 q12Shape42T128
private theorem q12Shape42T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 17571328 q12Shape42T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427328 (17571328 ||| 2^39) q12Shape42T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1107427328 ||| 2^39) 17571328 q12Shape42T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T119OK,q12Shape42T128OK⟩

private def q12Shape42T110 : Tree 12 := .split 25 q12Shape42T111 q12Shape42T118
private theorem q12Shape42T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 17571328 q12Shape42T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 (17571328 ||| 2^25) q12Shape42T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073872896 ||| 2^25) 17571328 q12Shape42T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T111OK,q12Shape42T118OK⟩

private def q12Shape42T135 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9})))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape42T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 3848328191488 q12Shape42T135=true := by decide

private def q12Shape42T136 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1092747264 3848326094336 q12Shape42T136=true := by decide

private def q12Shape42T134 : Tree 12 := .split 21 q12Shape42T135 q12Shape42T136
private theorem q12Shape42T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 3848326094336 q12Shape42T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 (3848326094336 ||| 2^21) q12Shape42T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090650112 ||| 2^21) 3848326094336 q12Shape42T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T135OK,q12Shape42T136OK⟩

private def q12Shape42T137 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1091698688 3848325045760 q12Shape42T137=true := by decide

private def q12Shape42T133 : Tree 12 := .split 20 q12Shape42T134 q12Shape42T137
private theorem q12Shape42T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 3848325045760 q12Shape42T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 (3848325045760 ||| 2^20) q12Shape42T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090650112 ||| 2^20) 3848325045760 q12Shape42T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T134OK,q12Shape42T137OK⟩

private def q12Shape42T138 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200113905664 1649301790208 q12Shape42T138=true := by decide

private def q12Shape42T132 : Tree 12 := .split 41 q12Shape42T133 q12Shape42T138
private theorem q12Shape42T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 1649301790208 q12Shape42T132=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 (1649301790208 ||| 2^41) q12Shape42T133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090650112 ||| 2^41) 1649301790208 q12Shape42T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T133OK,q12Shape42T138OK⟩

private def q12Shape42T139 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100602277888 549790162432 q12Shape42T139=true := by decide

private def q12Shape42T131 : Tree 12 := .split 40 q12Shape42T132 q12Shape42T139
private theorem q12Shape42T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 549790162432 q12Shape42T131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 (549790162432 ||| 2^40) q12Shape42T132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090650112 ||| 2^40) 549790162432 q12Shape42T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T132OK,q12Shape42T139OK⟩

private def q12Shape42T140 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550846464000 34348544 q12Shape42T140=true := by decide

private def q12Shape42T130 : Tree 12 := .split 39 q12Shape42T131 q12Shape42T140
private theorem q12Shape42T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 34348544 q12Shape42T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 (34348544 ||| 2^39) q12Shape42T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090650112 ||| 2^39) 34348544 q12Shape42T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T131OK,q12Shape42T140OK⟩

private def q12Shape42T141 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1124204544 794112 q12Shape42T141=true := by decide

private def q12Shape42T129 : Tree 12 := .split 25 q12Shape42T130 q12Shape42T141
private theorem q12Shape42T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 794112 q12Shape42T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650112 (794112 ||| 2^25) q12Shape42T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090650112 ||| 2^25) 794112 q12Shape42T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T130OK,q12Shape42T141OK⟩

private def q12Shape42T109 : Tree 12 := .split 24 q12Shape42T110 q12Shape42T129
private theorem q12Shape42T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 794112 q12Shape42T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073872896 (794112 ||| 2^24) q12Shape42T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073872896 ||| 2^24) 794112 q12Shape42T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T110OK,q12Shape42T129OK⟩

private def q12Shape42T107 : Tree 12 := .split 30 q12Shape42T108 q12Shape42T109
private theorem q12Shape42T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131072 794112 q12Shape42T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131072 (794112 ||| 2^30) q12Shape42T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (131072 ||| 2^30) 794112 q12Shape42T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T108OK,q12Shape42T109OK⟩

def q12Shape42P3 : Tree 12 := q12Shape42T107
theorem q12Shape42P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131072 794112 q12Shape42P3=true := q12Shape42T107OK

end Graffiti384b.EffectiveSearch.Q12
