import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T985 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T985OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 1124473856 q12Shape42T985=true := by decide

private def q12Shape42T993 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape42T993OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 3848341552128 q12Shape42T993=true := by decide

private def q12Shape42T994 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T994OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200097522176 1649318296576 q12Shape42T994=true := by decide

private def q12Shape42T992 : Tree 12 := .split 41 q12Shape42T993 q12Shape42T994
private theorem q12Shape42T992OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 1649318296576 q12Shape42T992=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 (1649318296576 ||| 2^41) q12Shape42T993 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074266624 ||| 2^41) 1649318296576 q12Shape42T994)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T993OK,q12Shape42T994OK⟩

private def q12Shape42T995 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T995OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585894400 549806668800 q12Shape42T995=true := by decide

private def q12Shape42T991 : Tree 12 := .split 40 q12Shape42T992 q12Shape42T995
private theorem q12Shape42T991OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 549806668800 q12Shape42T991=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 (549806668800 ||| 2^40) q12Shape42T992 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074266624 ||| 2^40) 549806668800 q12Shape42T995)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T992OK,q12Shape42T995OK⟩

private def q12Shape42T996 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T996OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550830080512 50854912 q12Shape42T996=true := by decide

private def q12Shape42T990 : Tree 12 := .split 39 q12Shape42T991 q12Shape42T996
private theorem q12Shape42T990OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 50854912 q12Shape42T990=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 (50854912 ||| 2^39) q12Shape42T991 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074266624 ||| 2^39) 50854912 q12Shape42T996)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T991OK,q12Shape42T996OK⟩

private def q12Shape42T997 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T997OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074332160 50789376 q12Shape42T997=true := by decide

private def q12Shape42T989 : Tree 12 := .split 16 q12Shape42T990 q12Shape42T997
private theorem q12Shape42T989OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 50789376 q12Shape42T989=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 (50789376 ||| 2^16) q12Shape42T990 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074266624 ||| 2^16) 50789376 q12Shape42T997)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T990OK,q12Shape42T997OK⟩

private def q12Shape42T998 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T998OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074299392 50756608 q12Shape42T998=true := by decide

private def q12Shape42T988 : Tree 12 := .split 15 q12Shape42T989 q12Shape42T998
private theorem q12Shape42T988OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 50756608 q12Shape42T988=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 (50756608 ||| 2^15) q12Shape42T989 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074266624 ||| 2^15) 50756608 q12Shape42T998)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T989OK,q12Shape42T998OK⟩

private def q12Shape42T999 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T999OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074283008 50740224 q12Shape42T999=true := by decide

private def q12Shape42T987 : Tree 12 := .split 14 q12Shape42T988 q12Shape42T999
private theorem q12Shape42T987OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 50740224 q12Shape42T987=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 (50740224 ||| 2^14) q12Shape42T988 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074266624 ||| 2^14) 50740224 q12Shape42T999)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T988OK,q12Shape42T999OK⟩

private def q12Shape42T1000 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1000OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074274816 50732032 q12Shape42T1000=true := by decide

private def q12Shape42T986 : Tree 12 := .split 13 q12Shape42T987 q12Shape42T1000
private theorem q12Shape42T986OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 50732032 q12Shape42T986=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074266624 (50732032 ||| 2^13) q12Shape42T987 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074266624 ||| 2^13) 50732032 q12Shape42T1000)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T987OK,q12Shape42T1000OK⟩

private def q12Shape42T984 : Tree 12 := .split 30 q12Shape42T985 q12Shape42T986
private theorem q12Shape42T984OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 50732032 q12Shape42T984=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 (50732032 ||| 2^30) q12Shape42T985 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (524800 ||| 2^30) 50732032 q12Shape42T986)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T985OK,q12Shape42T986OK⟩

private def q12Shape42T1009 : Tree 12 := (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,4,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9})))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11})))
private theorem q12Shape42T1009OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 3849381739520 q12Shape42T1009=true := by decide

private def q12Shape42T1010 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1010OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199057334784 1650358483968 q12Shape42T1010=true := by decide

private def q12Shape42T1008 : Tree 12 := .split 41 q12Shape42T1009 q12Shape42T1010
private theorem q12Shape42T1008OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 1650358483968 q12Shape42T1008=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (1650358483968 ||| 2^41) q12Shape42T1009 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^41) 1650358483968 q12Shape42T1010)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1009OK,q12Shape42T1010OK⟩

private def q12Shape42T1011 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1011OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545707008 550846856192 q12Shape42T1011=true := by decide

private def q12Shape42T1007 : Tree 12 := .split 40 q12Shape42T1008 q12Shape42T1011
private theorem q12Shape42T1007OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 550846856192 q12Shape42T1007=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (550846856192 ||| 2^40) q12Shape42T1008 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^40) 550846856192 q12Shape42T1011)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1008OK,q12Shape42T1011OK⟩

private def q12Shape42T1012 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T1012OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789893120 1091042304 q12Shape42T1012=true := by decide

private def q12Shape42T1006 : Tree 12 := .split 39 q12Shape42T1007 q12Shape42T1012
private theorem q12Shape42T1006OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 1091042304 q12Shape42T1006=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (1091042304 ||| 2^39) q12Shape42T1007 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^39) 1091042304 q12Shape42T1012)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1007OK,q12Shape42T1012OK⟩

private def q12Shape42T1013 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T1013OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107821056 17300480 q12Shape42T1013=true := by decide

private def q12Shape42T1005 : Tree 12 := .split 30 q12Shape42T1006 q12Shape42T1013
private theorem q12Shape42T1005OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 17300480 q12Shape42T1005=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (17300480 ||| 2^30) q12Shape42T1006 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^30) 17300480 q12Shape42T1013)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1006OK,q12Shape42T1013OK⟩

private def q12Shape42T1014 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1014OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34144768 17234944 q12Shape42T1014=true := by decide

private def q12Shape42T1004 : Tree 12 := .split 16 q12Shape42T1005 q12Shape42T1014
private theorem q12Shape42T1004OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 17234944 q12Shape42T1004=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (17234944 ||| 2^16) q12Shape42T1005 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^16) 17234944 q12Shape42T1014)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1005OK,q12Shape42T1014OK⟩

private def q12Shape42T1015 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1015OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34112000 17202176 q12Shape42T1015=true := by decide

private def q12Shape42T1003 : Tree 12 := .split 15 q12Shape42T1004 q12Shape42T1015
private theorem q12Shape42T1003OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 17202176 q12Shape42T1003=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (17202176 ||| 2^15) q12Shape42T1004 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^15) 17202176 q12Shape42T1015)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1004OK,q12Shape42T1015OK⟩

private def q12Shape42T1016 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1016OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34095616 17185792 q12Shape42T1016=true := by decide

private def q12Shape42T1002 : Tree 12 := .split 14 q12Shape42T1003 q12Shape42T1016
private theorem q12Shape42T1002OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 17185792 q12Shape42T1002=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (17185792 ||| 2^14) q12Shape42T1003 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^14) 17185792 q12Shape42T1016)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1003OK,q12Shape42T1016OK⟩

private def q12Shape42T1017 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1017OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34087424 17177600 q12Shape42T1017=true := by decide

private def q12Shape42T1001 : Tree 12 := .split 13 q12Shape42T1002 q12Shape42T1017
private theorem q12Shape42T1001OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 17177600 q12Shape42T1001=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34079232 (17177600 ||| 2^13) q12Shape42T1002 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (34079232 ||| 2^13) 17177600 q12Shape42T1017)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1002OK,q12Shape42T1017OK⟩

private def q12Shape42T983 : Tree 12 := .split 25 q12Shape42T984 q12Shape42T1001
private theorem q12Shape42T983OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 17177600 q12Shape42T983=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 (17177600 ||| 2^25) q12Shape42T984 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (524800 ||| 2^25) 17177600 q12Shape42T1001)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T984OK,q12Shape42T1001OK⟩

private def q12Shape42T1018 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T1018OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17302016 400384 q12Shape42T1018=true := by decide

private def q12Shape42T982 : Tree 12 := .split 24 q12Shape42T983 q12Shape42T1018
private theorem q12Shape42T982OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 400384 q12Shape42T982=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 (400384 ||| 2^24) q12Shape42T983 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (524800 ||| 2^24) 400384 q12Shape42T1018)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T983OK,q12Shape42T1018OK⟩

def q12Shape42P34 : Tree 12 := q12Shape42T982
theorem q12Shape42P34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 524800 400384 q12Shape42P34=true := q12Shape42T982OK

end Graffiti384b.EffectiveSearch.Q12
