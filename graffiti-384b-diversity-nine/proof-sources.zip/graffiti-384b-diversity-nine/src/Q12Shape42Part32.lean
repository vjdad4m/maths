import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1066 : Tree 12 := (.split 30 (.tip (.cover {0,2,4,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape42T1066OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 51125248 q12Shape42T1066=true := by decide

private def q12Shape42T1075 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape42T1075OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 3849382132736 q12Shape42T1075=true := by decide

private def q12Shape42T1076 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1076OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199056941568 1650358877184 q12Shape42T1076=true := by decide

private def q12Shape42T1074 : Tree 12 := .split 41 q12Shape42T1075 q12Shape42T1076
private theorem q12Shape42T1074OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 1650358877184 q12Shape42T1074=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (1650358877184 ||| 2^41) q12Shape42T1075 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^41) 1650358877184 q12Shape42T1076)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1075OK,q12Shape42T1076OK⟩

private def q12Shape42T1077 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1077OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545313792 550847249408 q12Shape42T1077=true := by decide

private def q12Shape42T1073 : Tree 12 := .split 40 q12Shape42T1074 q12Shape42T1077
private theorem q12Shape42T1073OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 550847249408 q12Shape42T1073=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (550847249408 ||| 2^40) q12Shape42T1074 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^40) 550847249408 q12Shape42T1077)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1074OK,q12Shape42T1077OK⟩

private def q12Shape42T1078 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T1078OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789499904 1091435520 q12Shape42T1078=true := by decide

private def q12Shape42T1072 : Tree 12 := .split 39 q12Shape42T1073 q12Shape42T1078
private theorem q12Shape42T1072OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 1091435520 q12Shape42T1072=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (1091435520 ||| 2^39) q12Shape42T1073 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^39) 1091435520 q12Shape42T1078)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1073OK,q12Shape42T1078OK⟩

private def q12Shape42T1079 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1079OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33751552 1091369984 q12Shape42T1079=true := by decide

private def q12Shape42T1071 : Tree 12 := .split 16 q12Shape42T1072 q12Shape42T1079
private theorem q12Shape42T1071OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 1091369984 q12Shape42T1071=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (1091369984 ||| 2^16) q12Shape42T1072 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^16) 1091369984 q12Shape42T1079)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1072OK,q12Shape42T1079OK⟩

private def q12Shape42T1080 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1080OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33718784 1091337216 q12Shape42T1080=true := by decide

private def q12Shape42T1070 : Tree 12 := .split 15 q12Shape42T1071 q12Shape42T1080
private theorem q12Shape42T1070OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 1091337216 q12Shape42T1070=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (1091337216 ||| 2^15) q12Shape42T1071 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^15) 1091337216 q12Shape42T1080)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1071OK,q12Shape42T1080OK⟩

private def q12Shape42T1081 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1081OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33702400 1091320832 q12Shape42T1081=true := by decide

private def q12Shape42T1069 : Tree 12 := .split 14 q12Shape42T1070 q12Shape42T1081
private theorem q12Shape42T1069OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 1091320832 q12Shape42T1069=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (1091320832 ||| 2^14) q12Shape42T1070 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^14) 1091320832 q12Shape42T1081)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1070OK,q12Shape42T1081OK⟩

private def q12Shape42T1082 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1082OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33694208 1091312640 q12Shape42T1082=true := by decide

private def q12Shape42T1068 : Tree 12 := .split 13 q12Shape42T1069 q12Shape42T1082
private theorem q12Shape42T1068OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 1091312640 q12Shape42T1068=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (1091312640 ||| 2^13) q12Shape42T1069 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^13) 1091312640 q12Shape42T1082)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1069OK,q12Shape42T1082OK⟩

private def q12Shape42T1083 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T1083OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107427840 17570816 q12Shape42T1083=true := by decide

private def q12Shape42T1067 : Tree 12 := .split 30 q12Shape42T1068 q12Shape42T1083
private theorem q12Shape42T1067OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 17570816 q12Shape42T1067=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33686016 (17570816 ||| 2^30) q12Shape42T1068 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33686016 ||| 2^30) 17570816 q12Shape42T1083)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1068OK,q12Shape42T1083OK⟩

private def q12Shape42T1065 : Tree 12 := .split 25 q12Shape42T1066 q12Shape42T1067
private theorem q12Shape42T1065OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 17570816 q12Shape42T1065=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 (17570816 ||| 2^25) q12Shape42T1066 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (131584 ||| 2^25) 17570816 q12Shape42T1067)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1066OK,q12Shape42T1067OK⟩

private def q12Shape42T1093 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,9}))))
private theorem q12Shape42T1093OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 3849398909952 q12Shape42T1093=true := by decide

private def q12Shape42T1094 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T1094OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040164352 1650375654400 q12Shape42T1094=true := by decide

private def q12Shape42T1092 : Tree 12 := .split 41 q12Shape42T1093 q12Shape42T1094
private theorem q12Shape42T1092OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 1650375654400 q12Shape42T1092=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (1650375654400 ||| 2^41) q12Shape42T1093 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^41) 1650375654400 q12Shape42T1094)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1093OK,q12Shape42T1094OK⟩

private def q12Shape42T1095 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,8,9}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T1095OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528536576 550864026624 q12Shape42T1095=true := by decide

private def q12Shape42T1091 : Tree 12 := .split 40 q12Shape42T1092 q12Shape42T1095
private theorem q12Shape42T1091OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 550864026624 q12Shape42T1091=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (550864026624 ||| 2^40) q12Shape42T1092 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^40) 550864026624 q12Shape42T1095)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1092OK,q12Shape42T1095OK⟩

private def q12Shape42T1096 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape42T1096OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772722688 1108212736 q12Shape42T1096=true := by decide

private def q12Shape42T1090 : Tree 12 := .split 39 q12Shape42T1091 q12Shape42T1096
private theorem q12Shape42T1090OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 1108212736 q12Shape42T1090=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (1108212736 ||| 2^39) q12Shape42T1091 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^39) 1108212736 q12Shape42T1096)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1091OK,q12Shape42T1096OK⟩

private def q12Shape42T1097 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1097OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16974336 1108147200 q12Shape42T1097=true := by decide

private def q12Shape42T1089 : Tree 12 := .split 16 q12Shape42T1090 q12Shape42T1097
private theorem q12Shape42T1089OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 1108147200 q12Shape42T1089=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (1108147200 ||| 2^16) q12Shape42T1090 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^16) 1108147200 q12Shape42T1097)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1090OK,q12Shape42T1097OK⟩

private def q12Shape42T1098 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1098OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16941568 1108114432 q12Shape42T1098=true := by decide

private def q12Shape42T1088 : Tree 12 := .split 15 q12Shape42T1089 q12Shape42T1098
private theorem q12Shape42T1088OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 1108114432 q12Shape42T1088=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (1108114432 ||| 2^15) q12Shape42T1089 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^15) 1108114432 q12Shape42T1098)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1089OK,q12Shape42T1098OK⟩

private def q12Shape42T1099 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1099OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16925184 1108098048 q12Shape42T1099=true := by decide

private def q12Shape42T1087 : Tree 12 := .split 14 q12Shape42T1088 q12Shape42T1099
private theorem q12Shape42T1087OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 1108098048 q12Shape42T1087=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (1108098048 ||| 2^14) q12Shape42T1088 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^14) 1108098048 q12Shape42T1099)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1088OK,q12Shape42T1099OK⟩

private def q12Shape42T1100 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16916992 1108089856 q12Shape42T1100=true := by decide

private def q12Shape42T1086 : Tree 12 := .split 13 q12Shape42T1087 q12Shape42T1100
private theorem q12Shape42T1086OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 1108089856 q12Shape42T1086=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (1108089856 ||| 2^13) q12Shape42T1087 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^13) 1108089856 q12Shape42T1100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1087OK,q12Shape42T1100OK⟩

private def q12Shape42T1101 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T1101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090650624 34348032 q12Shape42T1101=true := by decide

private def q12Shape42T1085 : Tree 12 := .split 30 q12Shape42T1086 q12Shape42T1101
private theorem q12Shape42T1085OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 34348032 q12Shape42T1085=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (34348032 ||| 2^30) q12Shape42T1086 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^30) 34348032 q12Shape42T1101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1086OK,q12Shape42T1101OK⟩

private def q12Shape42T1102 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50463232 793600 q12Shape42T1102=true := by decide

private def q12Shape42T1084 : Tree 12 := .split 25 q12Shape42T1085 q12Shape42T1102
private theorem q12Shape42T1084OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 793600 q12Shape42T1084=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16908800 (793600 ||| 2^25) q12Shape42T1085 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16908800 ||| 2^25) 793600 q12Shape42T1102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1085OK,q12Shape42T1102OK⟩

private def q12Shape42T1064 : Tree 12 := .split 24 q12Shape42T1065 q12Shape42T1084
private theorem q12Shape42T1064OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 793600 q12Shape42T1064=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 (793600 ||| 2^24) q12Shape42T1065 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (131584 ||| 2^24) 793600 q12Shape42T1084)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1065OK,q12Shape42T1084OK⟩

private def q12Shape42T1103 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape42T1103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 655872 269312 q12Shape42T1103=true := by decide

private def q12Shape42T1063 : Tree 12 := .split 19 q12Shape42T1064 q12Shape42T1103
private theorem q12Shape42T1063OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 269312 q12Shape42T1063=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 (269312 ||| 2^19) q12Shape42T1064 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (131584 ||| 2^19) 269312 q12Shape42T1103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1064OK,q12Shape42T1103OK⟩

private def q12Shape42T1104 : Tree 12 := (.split 19 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape42T1104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 393728 7168 q12Shape42T1104=true := by decide

private def q12Shape42T1062 : Tree 12 := .split 18 q12Shape42T1063 q12Shape42T1104
private theorem q12Shape42T1062OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 7168 q12Shape42T1062=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 (7168 ||| 2^18) q12Shape42T1063 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (131584 ||| 2^18) 7168 q12Shape42T1104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1063OK,q12Shape42T1104OK⟩

def q12Shape42P36 : Tree 12 := q12Shape42T1062
theorem q12Shape42P36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 131584 7168 q12Shape42P36=true := q12Shape42T1062OK

end Graffiti384b.EffectiveSearch.Q12
