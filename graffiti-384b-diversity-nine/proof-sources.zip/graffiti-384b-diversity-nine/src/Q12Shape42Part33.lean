import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1110 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T1110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 1124994048 q12Shape42T1110=true := by decide

private def q12Shape42T1116 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9})))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape42T1116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 3848345095168 q12Shape42T1116=true := by decide

private def q12Shape42T1117 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1075843584 3848342998016 q12Shape42T1117=true := by decide

private def q12Shape42T1115 : Tree 12 := .split 21 q12Shape42T1116 q12Shape42T1117
private theorem q12Shape42T1115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 3848342998016 q12Shape42T1115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 (3848342998016 ||| 2^21) q12Shape42T1116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746432 ||| 2^21) 3848342998016 q12Shape42T1117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1116OK,q12Shape42T1117OK⟩

private def q12Shape42T1118 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074795008 3848341949440 q12Shape42T1118=true := by decide

private def q12Shape42T1114 : Tree 12 := .split 20 q12Shape42T1115 q12Shape42T1118
private theorem q12Shape42T1114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 3848341949440 q12Shape42T1114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 (3848341949440 ||| 2^20) q12Shape42T1115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746432 ||| 2^20) 3848341949440 q12Shape42T1118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1115OK,q12Shape42T1118OK⟩

private def q12Shape42T1119 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200097001984 1649318693888 q12Shape42T1119=true := by decide

private def q12Shape42T1113 : Tree 12 := .split 41 q12Shape42T1114 q12Shape42T1119
private theorem q12Shape42T1113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 1649318693888 q12Shape42T1113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 (1649318693888 ||| 2^41) q12Shape42T1114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746432 ||| 2^41) 1649318693888 q12Shape42T1119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1114OK,q12Shape42T1119OK⟩

private def q12Shape42T1120 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585374208 549807066112 q12Shape42T1120=true := by decide

private def q12Shape42T1112 : Tree 12 := .split 40 q12Shape42T1113 q12Shape42T1120
private theorem q12Shape42T1112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 549807066112 q12Shape42T1112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 (549807066112 ||| 2^40) q12Shape42T1113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746432 ||| 2^40) 549807066112 q12Shape42T1120)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1113OK,q12Shape42T1120OK⟩

private def q12Shape42T1121 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T1121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829560320 51252224 q12Shape42T1121=true := by decide

private def q12Shape42T1111 : Tree 12 := .split 39 q12Shape42T1112 q12Shape42T1121
private theorem q12Shape42T1111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 51252224 q12Shape42T1111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073746432 (51252224 ||| 2^39) q12Shape42T1112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073746432 ||| 2^39) 51252224 q12Shape42T1121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1112OK,q12Shape42T1121OK⟩

private def q12Shape42T1109 : Tree 12 := .split 30 q12Shape42T1110 q12Shape42T1111
private theorem q12Shape42T1109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 51252224 q12Shape42T1109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 (51252224 ||| 2^30) q12Shape42T1110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (4608 ||| 2^30) 51252224 q12Shape42T1111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1110OK,q12Shape42T1111OK⟩

private def q12Shape42T1129 : Tree 12 := (.split 23 (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape42T1129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 3849389476864 q12Shape42T1129=true := by decide

private def q12Shape42T1130 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 37753344 3849385282560 q12Shape42T1130=true := by decide

private def q12Shape42T1128 : Tree 12 := .split 22 q12Shape42T1129 q12Shape42T1130
private theorem q12Shape42T1128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 3849385282560 q12Shape42T1128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 (3849385282560 ||| 2^22) q12Shape42T1129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33559040 ||| 2^22) 3849385282560 q12Shape42T1130)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1129OK,q12Shape42T1130OK⟩

private def q12Shape42T1131 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 35656192 3849383185408 q12Shape42T1131=true := by decide

private def q12Shape42T1127 : Tree 12 := .split 21 q12Shape42T1128 q12Shape42T1131
private theorem q12Shape42T1127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 3849383185408 q12Shape42T1127=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 (3849383185408 ||| 2^21) q12Shape42T1128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33559040 ||| 2^21) 3849383185408 q12Shape42T1131)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1128OK,q12Shape42T1131OK⟩

private def q12Shape42T1132 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34607616 3849382136832 q12Shape42T1132=true := by decide

private def q12Shape42T1126 : Tree 12 := .split 20 q12Shape42T1127 q12Shape42T1132
private theorem q12Shape42T1126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 3849382136832 q12Shape42T1126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 (3849382136832 ||| 2^20) q12Shape42T1127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33559040 ||| 2^20) 3849382136832 q12Shape42T1132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1127OK,q12Shape42T1132OK⟩

private def q12Shape42T1133 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199056814592 1650358881280 q12Shape42T1133=true := by decide

private def q12Shape42T1125 : Tree 12 := .split 41 q12Shape42T1126 q12Shape42T1133
private theorem q12Shape42T1125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 1650358881280 q12Shape42T1125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 (1650358881280 ||| 2^41) q12Shape42T1126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33559040 ||| 2^41) 1650358881280 q12Shape42T1133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1126OK,q12Shape42T1133OK⟩

private def q12Shape42T1134 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545186816 550847253504 q12Shape42T1134=true := by decide

private def q12Shape42T1124 : Tree 12 := .split 40 q12Shape42T1125 q12Shape42T1134
private theorem q12Shape42T1124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 550847253504 q12Shape42T1124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 (550847253504 ||| 2^40) q12Shape42T1125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33559040 ||| 2^40) 550847253504 q12Shape42T1134)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1125OK,q12Shape42T1134OK⟩

private def q12Shape42T1135 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T1135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789372928 1091439616 q12Shape42T1135=true := by decide

private def q12Shape42T1123 : Tree 12 := .split 39 q12Shape42T1124 q12Shape42T1135
private theorem q12Shape42T1123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 1091439616 q12Shape42T1123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 (1091439616 ||| 2^39) q12Shape42T1124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33559040 ||| 2^39) 1091439616 q12Shape42T1135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1124OK,q12Shape42T1135OK⟩

private def q12Shape42T1136 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape42T1136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107300864 17697792 q12Shape42T1136=true := by decide

private def q12Shape42T1122 : Tree 12 := .split 30 q12Shape42T1123 q12Shape42T1136
private theorem q12Shape42T1122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 17697792 q12Shape42T1122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33559040 (17697792 ||| 2^30) q12Shape42T1123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33559040 ||| 2^30) 17697792 q12Shape42T1136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1123OK,q12Shape42T1136OK⟩

private def q12Shape42T1108 : Tree 12 := .split 25 q12Shape42T1109 q12Shape42T1122
private theorem q12Shape42T1108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 17697792 q12Shape42T1108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 (17697792 ||| 2^25) q12Shape42T1109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (4608 ||| 2^25) 17697792 q12Shape42T1122)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1109OK,q12Shape42T1122OK⟩

private def q12Shape42T1137 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781824 920576 q12Shape42T1137=true := by decide

private def q12Shape42T1107 : Tree 12 := .split 24 q12Shape42T1108 q12Shape42T1137
private theorem q12Shape42T1107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 920576 q12Shape42T1107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 (920576 ||| 2^24) q12Shape42T1108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (4608 ||| 2^24) 920576 q12Shape42T1137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1108OK,q12Shape42T1137OK⟩

private def q12Shape42T1138 : Tree 12 := (.split 24 (.tip (.cover {0,2,7,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))))
private theorem q12Shape42T1138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 528896 396288 q12Shape42T1138=true := by decide

private def q12Shape42T1106 : Tree 12 := .split 19 q12Shape42T1107 q12Shape42T1138
private theorem q12Shape42T1106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 396288 q12Shape42T1106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 (396288 ||| 2^19) q12Shape42T1107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (4608 ||| 2^19) 396288 q12Shape42T1138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1107OK,q12Shape42T1138OK⟩

def q12Shape42P37 : Tree 12 := q12Shape42T1106
theorem q12Shape42P37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4608 396288 q12Shape42P37=true := q12Shape42T1106OK

end Graffiti384b.EffectiveSearch.Q12
