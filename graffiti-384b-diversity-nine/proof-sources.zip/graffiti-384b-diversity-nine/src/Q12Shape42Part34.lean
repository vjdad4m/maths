import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1146 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T1146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 3849415429120 q12Shape42T1146=true := by decide

private def q12Shape42T1147 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T1147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023522304 1650392173568 q12Shape42T1147=true := by decide

private def q12Shape42T1145 : Tree 12 := .split 41 q12Shape42T1146 q12Shape42T1147
private theorem q12Shape42T1145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 1650392173568 q12Shape42T1145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 (1650392173568 ||| 2^41) q12Shape42T1146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266752 ||| 2^41) 1650392173568 q12Shape42T1147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1146OK,q12Shape42T1147OK⟩

private def q12Shape42T1148 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T1148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511894528 550880545792 q12Shape42T1148=true := by decide

private def q12Shape42T1144 : Tree 12 := .split 40 q12Shape42T1145 q12Shape42T1148
private theorem q12Shape42T1144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 550880545792 q12Shape42T1144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 (550880545792 ||| 2^40) q12Shape42T1145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266752 ||| 2^40) 550880545792 q12Shape42T1148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1145OK,q12Shape42T1148OK⟩

private def q12Shape42T1149 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T1149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756080640 1124731904 q12Shape42T1149=true := by decide

private def q12Shape42T1143 : Tree 12 := .split 39 q12Shape42T1144 q12Shape42T1149
private theorem q12Shape42T1143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 1124731904 q12Shape42T1143=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 (1124731904 ||| 2^39) q12Shape42T1144 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266752 ||| 2^39) 1124731904 q12Shape42T1149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1144OK,q12Shape42T1149OK⟩

private def q12Shape42T1159 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {1,2,3,5,6,7,11})) (.split 31 (.tip (.cover {1,2,4,5,7,9,11})) (.tip (.cover {0,1,3,5,6,9,11})))) (.split 41 (.split 43 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,5,6,9,10,11}))))
private theorem q12Shape42T1159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 549822655488 q12Shape42T1159=true := by decide

private def q12Shape42T1160 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {2,3,5,6,9,10,11}))) (.tip (.cover {2,3,5,6,9,10,11})))
private theorem q12Shape42T1160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829822464 66841600 q12Shape42T1160=true := by decide

private def q12Shape42T1158 : Tree 12 := .split 39 q12Shape42T1159 q12Shape42T1160
private theorem q12Shape42T1158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 66841600 q12Shape42T1158=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (66841600 ||| 2^39) q12Shape42T1159 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^39) 66841600 q12Shape42T1160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1159OK,q12Shape42T1160OK⟩

private def q12Shape42T1161 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1082397184 58452992 q12Shape42T1161=true := by decide

private def q12Shape42T1157 : Tree 12 := .split 23 q12Shape42T1158 q12Shape42T1161
private theorem q12Shape42T1157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 58452992 q12Shape42T1157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (58452992 ||| 2^23) q12Shape42T1158 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^23) 58452992 q12Shape42T1161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1158OK,q12Shape42T1161OK⟩

private def q12Shape42T1162 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1078202880 54258688 q12Shape42T1162=true := by decide

private def q12Shape42T1156 : Tree 12 := .split 22 q12Shape42T1157 q12Shape42T1162
private theorem q12Shape42T1156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 54258688 q12Shape42T1156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (54258688 ||| 2^22) q12Shape42T1157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^22) 54258688 q12Shape42T1162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1157OK,q12Shape42T1162OK⟩

private def q12Shape42T1163 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1076105728 52161536 q12Shape42T1163=true := by decide

private def q12Shape42T1155 : Tree 12 := .split 21 q12Shape42T1156 q12Shape42T1163
private theorem q12Shape42T1155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 52161536 q12Shape42T1155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (52161536 ||| 2^21) q12Shape42T1156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^21) 52161536 q12Shape42T1163)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1156OK,q12Shape42T1163OK⟩

private def q12Shape42T1164 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1075057152 51112960 q12Shape42T1164=true := by decide

private def q12Shape42T1154 : Tree 12 := .split 20 q12Shape42T1155 q12Shape42T1164
private theorem q12Shape42T1154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 51112960 q12Shape42T1154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (51112960 ||| 2^20) q12Shape42T1155 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^20) 51112960 q12Shape42T1164)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1155OK,q12Shape42T1164OK⟩

private def q12Shape42T1165 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074074112 51047424 q12Shape42T1165=true := by decide

private def q12Shape42T1153 : Tree 12 := .split 16 q12Shape42T1154 q12Shape42T1165
private theorem q12Shape42T1153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 51047424 q12Shape42T1153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (51047424 ||| 2^16) q12Shape42T1154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^16) 51047424 q12Shape42T1165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1154OK,q12Shape42T1165OK⟩

private def q12Shape42T1166 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074041344 51014656 q12Shape42T1166=true := by decide

private def q12Shape42T1152 : Tree 12 := .split 15 q12Shape42T1153 q12Shape42T1166
private theorem q12Shape42T1152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 51014656 q12Shape42T1152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (51014656 ||| 2^15) q12Shape42T1153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^15) 51014656 q12Shape42T1166)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1153OK,q12Shape42T1166OK⟩

private def q12Shape42T1167 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074024960 50998272 q12Shape42T1167=true := by decide

private def q12Shape42T1151 : Tree 12 := .split 14 q12Shape42T1152 q12Shape42T1167
private theorem q12Shape42T1151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 50998272 q12Shape42T1151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (50998272 ||| 2^14) q12Shape42T1152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^14) 50998272 q12Shape42T1167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1152OK,q12Shape42T1167OK⟩

private def q12Shape42T1168 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074016768 50990080 q12Shape42T1168=true := by decide

private def q12Shape42T1150 : Tree 12 := .split 13 q12Shape42T1151 q12Shape42T1168
private theorem q12Shape42T1150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 50990080 q12Shape42T1150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008576 (50990080 ||| 2^13) q12Shape42T1151 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008576 ||| 2^13) 50990080 q12Shape42T1168)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1151OK,q12Shape42T1168OK⟩

private def q12Shape42T1142 : Tree 12 := .split 30 q12Shape42T1143 q12Shape42T1150
private theorem q12Shape42T1142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 50990080 q12Shape42T1142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 (50990080 ||| 2^30) q12Shape42T1143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266752 ||| 2^30) 50990080 q12Shape42T1150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1143OK,q12Shape42T1150OK⟩

private def q12Shape42T1169 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T1169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33821184 17435648 q12Shape42T1169=true := by decide

private def q12Shape42T1141 : Tree 12 := .split 25 q12Shape42T1142 q12Shape42T1169
private theorem q12Shape42T1141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 17435648 q12Shape42T1141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 (17435648 ||| 2^25) q12Shape42T1142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266752 ||| 2^25) 17435648 q12Shape42T1169)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1142OK,q12Shape42T1169OK⟩

private def q12Shape42T1170 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17043968 658432 q12Shape42T1170=true := by decide

private def q12Shape42T1140 : Tree 12 := .split 24 q12Shape42T1141 q12Shape42T1170
private theorem q12Shape42T1140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 658432 q12Shape42T1140=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 (658432 ||| 2^24) q12Shape42T1141 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266752 ||| 2^24) 658432 q12Shape42T1170)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1141OK,q12Shape42T1170OK⟩

private def q12Shape42T1171 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T1171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 791040 134144 q12Shape42T1171=true := by decide

private def q12Shape42T1139 : Tree 12 := .split 19 q12Shape42T1140 q12Shape42T1171
private theorem q12Shape42T1139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 134144 q12Shape42T1139=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 (134144 ||| 2^19) q12Shape42T1140 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266752 ||| 2^19) 134144 q12Shape42T1171)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1140OK,q12Shape42T1171OK⟩

def q12Shape42P38 : Tree 12 := q12Shape42T1139
theorem q12Shape42P38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266752 134144 q12Shape42P38=true := q12Shape42T1139OK

end Graffiti384b.EffectiveSearch.Q12
