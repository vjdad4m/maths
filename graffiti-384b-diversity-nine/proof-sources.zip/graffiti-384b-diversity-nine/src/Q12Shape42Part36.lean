import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1209 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape42T1209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 1124996096 q12Shape42T1209=true := by decide

private def q12Shape42T1215 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9})))) (.tip (.cover {0,2,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape42T1215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 3848345097216 q12Shape42T1215=true := by decide

private def q12Shape42T1216 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1075841536 3848343000064 q12Shape42T1216=true := by decide

private def q12Shape42T1214 : Tree 12 := .split 21 q12Shape42T1215 q12Shape42T1216
private theorem q12Shape42T1214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 3848343000064 q12Shape42T1214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 (3848343000064 ||| 2^21) q12Shape42T1215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744384 ||| 2^21) 3848343000064 q12Shape42T1216)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1215OK,q12Shape42T1216OK⟩

private def q12Shape42T1217 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074792960 3848341951488 q12Shape42T1217=true := by decide

private def q12Shape42T1213 : Tree 12 := .split 20 q12Shape42T1214 q12Shape42T1217
private theorem q12Shape42T1213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 3848341951488 q12Shape42T1213=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 (3848341951488 ||| 2^20) q12Shape42T1214 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744384 ||| 2^20) 3848341951488 q12Shape42T1217)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1214OK,q12Shape42T1217OK⟩

private def q12Shape42T1218 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200096999936 1649318695936 q12Shape42T1218=true := by decide

private def q12Shape42T1212 : Tree 12 := .split 41 q12Shape42T1213 q12Shape42T1218
private theorem q12Shape42T1212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 1649318695936 q12Shape42T1212=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 (1649318695936 ||| 2^41) q12Shape42T1213 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744384 ||| 2^41) 1649318695936 q12Shape42T1218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1213OK,q12Shape42T1218OK⟩

private def q12Shape42T1219 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100585372160 549807068160 q12Shape42T1219=true := by decide

private def q12Shape42T1211 : Tree 12 := .split 40 q12Shape42T1212 q12Shape42T1219
private theorem q12Shape42T1211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 549807068160 q12Shape42T1211=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 (549807068160 ||| 2^40) q12Shape42T1212 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744384 ||| 2^40) 549807068160 q12Shape42T1219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1212OK,q12Shape42T1219OK⟩

private def q12Shape42T1220 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T1220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829558272 51254272 q12Shape42T1220=true := by decide

private def q12Shape42T1210 : Tree 12 := .split 39 q12Shape42T1211 q12Shape42T1220
private theorem q12Shape42T1210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 51254272 q12Shape42T1210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1073744384 (51254272 ||| 2^39) q12Shape42T1211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1073744384 ||| 2^39) 51254272 q12Shape42T1220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1211OK,q12Shape42T1220OK⟩

private def q12Shape42T1208 : Tree 12 := .split 30 q12Shape42T1209 q12Shape42T1210
private theorem q12Shape42T1208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 51254272 q12Shape42T1208=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 (51254272 ||| 2^30) q12Shape42T1209 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (2560 ||| 2^30) 51254272 q12Shape42T1210)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1209OK,q12Shape42T1210OK⟩

private def q12Shape42T1221 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33556992 17699840 q12Shape42T1221=true := by decide

private def q12Shape42T1207 : Tree 12 := .split 25 q12Shape42T1208 q12Shape42T1221
private theorem q12Shape42T1207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 17699840 q12Shape42T1207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 (17699840 ||| 2^25) q12Shape42T1208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (2560 ||| 2^25) 17699840 q12Shape42T1221)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1208OK,q12Shape42T1221OK⟩

private def q12Shape42T1230 : Tree 12 := (.split 23 (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,3,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,9})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape42T1230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 3849406256128 q12Shape42T1230=true := by decide

private def q12Shape42T1231 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 20974080 3849402061824 q12Shape42T1231=true := by decide

private def q12Shape42T1229 : Tree 12 := .split 22 q12Shape42T1230 q12Shape42T1231
private theorem q12Shape42T1229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 3849402061824 q12Shape42T1229=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (3849402061824 ||| 2^22) q12Shape42T1230 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^22) 3849402061824 q12Shape42T1231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1230OK,q12Shape42T1231OK⟩

private def q12Shape42T1232 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 18876928 3849399964672 q12Shape42T1232=true := by decide

private def q12Shape42T1228 : Tree 12 := .split 21 q12Shape42T1229 q12Shape42T1232
private theorem q12Shape42T1228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 3849399964672 q12Shape42T1228=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (3849399964672 ||| 2^21) q12Shape42T1229 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^21) 3849399964672 q12Shape42T1232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1229OK,q12Shape42T1232OK⟩

private def q12Shape42T1233 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17828352 3849398916096 q12Shape42T1233=true := by decide

private def q12Shape42T1227 : Tree 12 := .split 20 q12Shape42T1228 q12Shape42T1233
private theorem q12Shape42T1227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 3849398916096 q12Shape42T1227=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (3849398916096 ||| 2^20) q12Shape42T1228 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^20) 3849398916096 q12Shape42T1233)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1228OK,q12Shape42T1233OK⟩

private def q12Shape42T1234 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T1234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040035328 1650375660544 q12Shape42T1234=true := by decide

private def q12Shape42T1226 : Tree 12 := .split 41 q12Shape42T1227 q12Shape42T1234
private theorem q12Shape42T1226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 1650375660544 q12Shape42T1226=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (1650375660544 ||| 2^41) q12Shape42T1227 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^41) 1650375660544 q12Shape42T1234)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1227OK,q12Shape42T1234OK⟩

private def q12Shape42T1235 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,8,9}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T1235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528407552 550864032768 q12Shape42T1235=true := by decide

private def q12Shape42T1225 : Tree 12 := .split 40 q12Shape42T1226 q12Shape42T1235
private theorem q12Shape42T1225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 550864032768 q12Shape42T1225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (550864032768 ||| 2^40) q12Shape42T1226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^40) 550864032768 q12Shape42T1235)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1226OK,q12Shape42T1235OK⟩

private def q12Shape42T1236 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape42T1236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772593664 1108218880 q12Shape42T1236=true := by decide

private def q12Shape42T1224 : Tree 12 := .split 39 q12Shape42T1225 q12Shape42T1236
private theorem q12Shape42T1224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 1108218880 q12Shape42T1224=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (1108218880 ||| 2^39) q12Shape42T1225 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^39) 1108218880 q12Shape42T1236)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1225OK,q12Shape42T1236OK⟩

private def q12Shape42T1237 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T1237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090521600 34477056 q12Shape42T1237=true := by decide

private def q12Shape42T1223 : Tree 12 := .split 30 q12Shape42T1224 q12Shape42T1237
private theorem q12Shape42T1223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 34477056 q12Shape42T1223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (34477056 ||| 2^30) q12Shape42T1224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^30) 34477056 q12Shape42T1237)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1224OK,q12Shape42T1237OK⟩

private def q12Shape42T1238 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50334208 922624 q12Shape42T1238=true := by decide

private def q12Shape42T1222 : Tree 12 := .split 25 q12Shape42T1223 q12Shape42T1238
private theorem q12Shape42T1222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 922624 q12Shape42T1222=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16779776 (922624 ||| 2^25) q12Shape42T1223 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16779776 ||| 2^25) 922624 q12Shape42T1238)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1223OK,q12Shape42T1238OK⟩

private def q12Shape42T1206 : Tree 12 := .split 24 q12Shape42T1207 q12Shape42T1222
private theorem q12Shape42T1206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 922624 q12Shape42T1206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 (922624 ||| 2^24) q12Shape42T1207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (2560 ||| 2^24) 922624 q12Shape42T1222)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1207OK,q12Shape42T1222OK⟩

def q12Shape42P40 : Tree 12 := q12Shape42T1206
theorem q12Shape42P40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2560 922624 q12Shape42P40=true := q12Shape42T1206OK

end Graffiti384b.EffectiveSearch.Q12
