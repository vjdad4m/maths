import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1245 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T1245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 3849415169024 q12Shape42T1245=true := by decide

private def q12Shape42T1246 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T1246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023782400 1650391913472 q12Shape42T1246=true := by decide

private def q12Shape42T1244 : Tree 12 := .split 41 q12Shape42T1245 q12Shape42T1246
private theorem q12Shape42T1244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 1650391913472 q12Shape42T1244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 (1650391913472 ||| 2^41) q12Shape42T1245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526848 ||| 2^41) 1650391913472 q12Shape42T1246)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1245OK,q12Shape42T1246OK⟩

private def q12Shape42T1247 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T1247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512154624 550880285696 q12Shape42T1247=true := by decide

private def q12Shape42T1243 : Tree 12 := .split 40 q12Shape42T1244 q12Shape42T1247
private theorem q12Shape42T1243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 550880285696 q12Shape42T1243=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 (550880285696 ||| 2^40) q12Shape42T1244 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526848 ||| 2^40) 550880285696 q12Shape42T1247)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1244OK,q12Shape42T1247OK⟩

private def q12Shape42T1248 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T1248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756340736 1124471808 q12Shape42T1248=true := by decide

private def q12Shape42T1242 : Tree 12 := .split 39 q12Shape42T1243 q12Shape42T1248
private theorem q12Shape42T1242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 1124471808 q12Shape42T1242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 (1124471808 ||| 2^39) q12Shape42T1243 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526848 ||| 2^39) 1124471808 q12Shape42T1248)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1243OK,q12Shape42T1248OK⟩

private def q12Shape42T1258 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {1,2,3,5,6,7,11})) (.split 31 (.tip (.cover {1,2,3,5,7,9,11})) (.tip (.cover {0,1,3,5,6,9,11})))) (.split 41 (.split 43 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,5,7,9,10,11}))))
private theorem q12Shape42T1258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 549822395392 q12Shape42T1258=true := by decide

private def q12Shape42T1259 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {2,3,5,7,9,10,11})))
private theorem q12Shape42T1259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550830082560 66581504 q12Shape42T1259=true := by decide

private def q12Shape42T1257 : Tree 12 := .split 39 q12Shape42T1258 q12Shape42T1259
private theorem q12Shape42T1257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 66581504 q12Shape42T1257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (66581504 ||| 2^39) q12Shape42T1258 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^39) 66581504 q12Shape42T1259)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1258OK,q12Shape42T1259OK⟩

private def q12Shape42T1260 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1082657280 58192896 q12Shape42T1260=true := by decide

private def q12Shape42T1256 : Tree 12 := .split 23 q12Shape42T1257 q12Shape42T1260
private theorem q12Shape42T1256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 58192896 q12Shape42T1256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (58192896 ||| 2^23) q12Shape42T1257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^23) 58192896 q12Shape42T1260)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1257OK,q12Shape42T1260OK⟩

private def q12Shape42T1261 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1078462976 53998592 q12Shape42T1261=true := by decide

private def q12Shape42T1255 : Tree 12 := .split 22 q12Shape42T1256 q12Shape42T1261
private theorem q12Shape42T1255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 53998592 q12Shape42T1255=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (53998592 ||| 2^22) q12Shape42T1256 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^22) 53998592 q12Shape42T1261)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1256OK,q12Shape42T1261OK⟩

private def q12Shape42T1262 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1076365824 51901440 q12Shape42T1262=true := by decide

private def q12Shape42T1254 : Tree 12 := .split 21 q12Shape42T1255 q12Shape42T1262
private theorem q12Shape42T1254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 51901440 q12Shape42T1254=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (51901440 ||| 2^21) q12Shape42T1255 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^21) 51901440 q12Shape42T1262)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1255OK,q12Shape42T1262OK⟩

private def q12Shape42T1263 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1075317248 50852864 q12Shape42T1263=true := by decide

private def q12Shape42T1253 : Tree 12 := .split 20 q12Shape42T1254 q12Shape42T1263
private theorem q12Shape42T1253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 50852864 q12Shape42T1253=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (50852864 ||| 2^20) q12Shape42T1254 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^20) 50852864 q12Shape42T1263)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1254OK,q12Shape42T1263OK⟩

private def q12Shape42T1264 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074334208 50787328 q12Shape42T1264=true := by decide

private def q12Shape42T1252 : Tree 12 := .split 16 q12Shape42T1253 q12Shape42T1264
private theorem q12Shape42T1252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 50787328 q12Shape42T1252=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (50787328 ||| 2^16) q12Shape42T1253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^16) 50787328 q12Shape42T1264)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1253OK,q12Shape42T1264OK⟩

private def q12Shape42T1265 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074301440 50754560 q12Shape42T1265=true := by decide

private def q12Shape42T1251 : Tree 12 := .split 15 q12Shape42T1252 q12Shape42T1265
private theorem q12Shape42T1251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 50754560 q12Shape42T1251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (50754560 ||| 2^15) q12Shape42T1252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^15) 50754560 q12Shape42T1265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1252OK,q12Shape42T1265OK⟩

private def q12Shape42T1266 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074285056 50738176 q12Shape42T1266=true := by decide

private def q12Shape42T1250 : Tree 12 := .split 14 q12Shape42T1251 q12Shape42T1266
private theorem q12Shape42T1250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 50738176 q12Shape42T1250=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (50738176 ||| 2^14) q12Shape42T1251 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^14) 50738176 q12Shape42T1266)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1251OK,q12Shape42T1266OK⟩

private def q12Shape42T1267 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T1267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074276864 50729984 q12Shape42T1267=true := by decide

private def q12Shape42T1249 : Tree 12 := .split 13 q12Shape42T1250 q12Shape42T1267
private theorem q12Shape42T1249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 50729984 q12Shape42T1249=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074268672 (50729984 ||| 2^13) q12Shape42T1250 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074268672 ||| 2^13) 50729984 q12Shape42T1267)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1250OK,q12Shape42T1267OK⟩

private def q12Shape42T1241 : Tree 12 := .split 30 q12Shape42T1242 q12Shape42T1249
private theorem q12Shape42T1241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 50729984 q12Shape42T1241=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 (50729984 ||| 2^30) q12Shape42T1242 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526848 ||| 2^30) 50729984 q12Shape42T1249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1242OK,q12Shape42T1249OK⟩

private def q12Shape42T1268 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34081280 17175552 q12Shape42T1268=true := by decide

private def q12Shape42T1240 : Tree 12 := .split 25 q12Shape42T1241 q12Shape42T1268
private theorem q12Shape42T1240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 17175552 q12Shape42T1240=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 (17175552 ||| 2^25) q12Shape42T1241 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526848 ||| 2^25) 17175552 q12Shape42T1268)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1241OK,q12Shape42T1268OK⟩

private def q12Shape42T1269 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T1269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17304064 398336 q12Shape42T1269=true := by decide

private def q12Shape42T1239 : Tree 12 := .split 24 q12Shape42T1240 q12Shape42T1269
private theorem q12Shape42T1239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 398336 q12Shape42T1239=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 (398336 ||| 2^24) q12Shape42T1240 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (526848 ||| 2^24) 398336 q12Shape42T1269)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1240OK,q12Shape42T1269OK⟩

def q12Shape42P41 : Tree 12 := q12Shape42T1239
theorem q12Shape42P41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 526848 398336 q12Shape42P41=true := q12Shape42T1239OK

private def q12Shape42T1272 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))))
private theorem q12Shape42T1272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264704 660480 q12Shape42T1272=true := by decide

private def q12Shape42T1273 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T1273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 788992 136192 q12Shape42T1273=true := by decide

private def q12Shape42T1271 : Tree 12 := .split 19 q12Shape42T1272 q12Shape42T1273
private theorem q12Shape42T1271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264704 136192 q12Shape42T1271=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264704 (136192 ||| 2^19) q12Shape42T1272 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (264704 ||| 2^19) 136192 q12Shape42T1273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1272OK,q12Shape42T1273OK⟩

def q12Shape42P42 : Tree 12 := q12Shape42T1271
theorem q12Shape42P42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 264704 136192 q12Shape42P42=true := q12Shape42T1271OK

end Graffiti384b.EffectiveSearch.Q12
