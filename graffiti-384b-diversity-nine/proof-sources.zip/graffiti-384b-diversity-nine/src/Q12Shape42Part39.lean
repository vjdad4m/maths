import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1314 : Tree 12 := (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))))
private theorem q12Shape42T1314OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1536 51255296 q12Shape42T1314=true := by decide

private def q12Shape42T1321 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,9})))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape42T1321OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 3849385285632 q12Shape42T1321=true := by decide

private def q12Shape42T1322 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1322OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 35653120 3849383188480 q12Shape42T1322=true := by decide

private def q12Shape42T1320 : Tree 12 := .split 21 q12Shape42T1321 q12Shape42T1322
private theorem q12Shape42T1320OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 3849383188480 q12Shape42T1320=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 (3849383188480 ||| 2^21) q12Shape42T1321 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33555968 ||| 2^21) 3849383188480 q12Shape42T1322)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1321OK,q12Shape42T1322OK⟩

private def q12Shape42T1323 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1323OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34604544 3849382139904 q12Shape42T1323=true := by decide

private def q12Shape42T1319 : Tree 12 := .split 20 q12Shape42T1320 q12Shape42T1323
private theorem q12Shape42T1319OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 3849382139904 q12Shape42T1319=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 (3849382139904 ||| 2^20) q12Shape42T1320 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33555968 ||| 2^20) 3849382139904 q12Shape42T1323)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1320OK,q12Shape42T1323OK⟩

private def q12Shape42T1324 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1324OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199056811520 1650358884352 q12Shape42T1324=true := by decide

private def q12Shape42T1318 : Tree 12 := .split 41 q12Shape42T1319 q12Shape42T1324
private theorem q12Shape42T1318OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 1650358884352 q12Shape42T1318=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 (1650358884352 ||| 2^41) q12Shape42T1319 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33555968 ||| 2^41) 1650358884352 q12Shape42T1324)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1319OK,q12Shape42T1324OK⟩

private def q12Shape42T1325 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape42T1325OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099545183744 550847256576 q12Shape42T1325=true := by decide

private def q12Shape42T1317 : Tree 12 := .split 40 q12Shape42T1318 q12Shape42T1325
private theorem q12Shape42T1317OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 550847256576 q12Shape42T1317=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 (550847256576 ||| 2^40) q12Shape42T1318 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33555968 ||| 2^40) 550847256576 q12Shape42T1325)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1318OK,q12Shape42T1325OK⟩

private def q12Shape42T1326 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape42T1326OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549789369856 1091442688 q12Shape42T1326=true := by decide

private def q12Shape42T1316 : Tree 12 := .split 39 q12Shape42T1317 q12Shape42T1326
private theorem q12Shape42T1316OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 1091442688 q12Shape42T1316=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 (1091442688 ||| 2^39) q12Shape42T1317 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33555968 ||| 2^39) 1091442688 q12Shape42T1326)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1317OK,q12Shape42T1326OK⟩

private def q12Shape42T1327 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T1327OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1107297792 17700864 q12Shape42T1327=true := by decide

private def q12Shape42T1315 : Tree 12 := .split 30 q12Shape42T1316 q12Shape42T1327
private theorem q12Shape42T1315OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 17700864 q12Shape42T1315=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33555968 (17700864 ||| 2^30) q12Shape42T1316 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (33555968 ||| 2^30) 17700864 q12Shape42T1327)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1316OK,q12Shape42T1327OK⟩

private def q12Shape42T1313 : Tree 12 := .split 25 q12Shape42T1314 q12Shape42T1315
private theorem q12Shape42T1313OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1536 17700864 q12Shape42T1313=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1536 (17700864 ||| 2^25) q12Shape42T1314 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1536 ||| 2^25) 17700864 q12Shape42T1315)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1314OK,q12Shape42T1315OK⟩

private def q12Shape42T1335 : Tree 12 := (.split 22 (.split 23 (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,9})))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape42T1335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 3849402062848 q12Shape42T1335=true := by decide

private def q12Shape42T1336 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 18875904 3849399965696 q12Shape42T1336=true := by decide

private def q12Shape42T1334 : Tree 12 := .split 21 q12Shape42T1335 q12Shape42T1336
private theorem q12Shape42T1334OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 3849399965696 q12Shape42T1334=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 (3849399965696 ||| 2^21) q12Shape42T1335 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16778752 ||| 2^21) 3849399965696 q12Shape42T1336)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1335OK,q12Shape42T1336OK⟩

private def q12Shape42T1337 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17827328 3849398917120 q12Shape42T1337=true := by decide

private def q12Shape42T1333 : Tree 12 := .split 20 q12Shape42T1334 q12Shape42T1337
private theorem q12Shape42T1333OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 3849398917120 q12Shape42T1333=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 (3849398917120 ||| 2^20) q12Shape42T1334 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16778752 ||| 2^20) 3849398917120 q12Shape42T1337)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1334OK,q12Shape42T1337OK⟩

private def q12Shape42T1338 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T1338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040034304 1650375661568 q12Shape42T1338=true := by decide

private def q12Shape42T1332 : Tree 12 := .split 41 q12Shape42T1333 q12Shape42T1338
private theorem q12Shape42T1332OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 1650375661568 q12Shape42T1332=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 (1650375661568 ||| 2^41) q12Shape42T1333 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16778752 ||| 2^41) 1650375661568 q12Shape42T1338)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1333OK,q12Shape42T1338OK⟩

private def q12Shape42T1339 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,8,9}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape42T1339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528406528 550864033792 q12Shape42T1339=true := by decide

private def q12Shape42T1331 : Tree 12 := .split 40 q12Shape42T1332 q12Shape42T1339
private theorem q12Shape42T1331OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 550864033792 q12Shape42T1331=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 (550864033792 ||| 2^40) q12Shape42T1332 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16778752 ||| 2^40) 550864033792 q12Shape42T1339)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1332OK,q12Shape42T1339OK⟩

private def q12Shape42T1340 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape42T1340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772592640 1108219904 q12Shape42T1340=true := by decide

private def q12Shape42T1330 : Tree 12 := .split 39 q12Shape42T1331 q12Shape42T1340
private theorem q12Shape42T1330OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 1108219904 q12Shape42T1330=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 (1108219904 ||| 2^39) q12Shape42T1331 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16778752 ||| 2^39) 1108219904 q12Shape42T1340)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1331OK,q12Shape42T1340OK⟩

private def q12Shape42T1341 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T1341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090520576 34478080 q12Shape42T1341=true := by decide

private def q12Shape42T1329 : Tree 12 := .split 30 q12Shape42T1330 q12Shape42T1341
private theorem q12Shape42T1329OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 34478080 q12Shape42T1329=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 (34478080 ||| 2^30) q12Shape42T1330 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16778752 ||| 2^30) 34478080 q12Shape42T1341)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1330OK,q12Shape42T1341OK⟩

private def q12Shape42T1342 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1342OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50333184 923648 q12Shape42T1342=true := by decide

private def q12Shape42T1328 : Tree 12 := .split 25 q12Shape42T1329 q12Shape42T1342
private theorem q12Shape42T1328OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 923648 q12Shape42T1328=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16778752 (923648 ||| 2^25) q12Shape42T1329 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16778752 ||| 2^25) 923648 q12Shape42T1342)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1329OK,q12Shape42T1342OK⟩

private def q12Shape42T1312 : Tree 12 := .split 24 q12Shape42T1313 q12Shape42T1328
private theorem q12Shape42T1312OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1536 923648 q12Shape42T1312=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1536 (923648 ||| 2^24) q12Shape42T1313 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1536 ||| 2^24) 923648 q12Shape42T1328)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1313OK,q12Shape42T1328OK⟩

def q12Shape42P45 : Tree 12 := q12Shape42T1312
theorem q12Shape42P45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1536 923648 q12Shape42P45=true := q12Shape42T1312OK

end Graffiti384b.EffectiveSearch.Q12
