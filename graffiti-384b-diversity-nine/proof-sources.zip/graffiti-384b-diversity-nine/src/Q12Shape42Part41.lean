import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T1378 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape42T1378OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 3849415432192 q12Shape42T1378=true := by decide

private def q12Shape42T1379 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T1379OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023519232 1650392176640 q12Shape42T1379=true := by decide

private def q12Shape42T1377 : Tree 12 := .split 41 q12Shape42T1378 q12Shape42T1379
private theorem q12Shape42T1377OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 1650392176640 q12Shape42T1377=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 (1650392176640 ||| 2^41) q12Shape42T1378 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263680 ||| 2^41) 1650392176640 q12Shape42T1379)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1378OK,q12Shape42T1379OK⟩

private def q12Shape42T1380 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape42T1380OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511891456 550880548864 q12Shape42T1380=true := by decide

private def q12Shape42T1376 : Tree 12 := .split 40 q12Shape42T1377 q12Shape42T1380
private theorem q12Shape42T1376OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 550880548864 q12Shape42T1376=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 (550880548864 ||| 2^40) q12Shape42T1377 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263680 ||| 2^40) 550880548864 q12Shape42T1380)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1377OK,q12Shape42T1380OK⟩

private def q12Shape42T1381 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape42T1381OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756077568 1124734976 q12Shape42T1381=true := by decide

private def q12Shape42T1375 : Tree 12 := .split 39 q12Shape42T1376 q12Shape42T1381
private theorem q12Shape42T1375OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 1124734976 q12Shape42T1375=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 (1124734976 ||| 2^39) q12Shape42T1376 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263680 ||| 2^39) 1124734976 q12Shape42T1381)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1376OK,q12Shape42T1381OK⟩

private def q12Shape42T1382 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T1382OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074005504 50993152 q12Shape42T1382=true := by decide

private def q12Shape42T1374 : Tree 12 := .split 30 q12Shape42T1375 q12Shape42T1382
private theorem q12Shape42T1374OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 50993152 q12Shape42T1374=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 (50993152 ||| 2^30) q12Shape42T1375 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263680 ||| 2^30) 50993152 q12Shape42T1382)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1375OK,q12Shape42T1382OK⟩

private def q12Shape42T1383 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape42T1383OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33818112 17438720 q12Shape42T1383=true := by decide

private def q12Shape42T1373 : Tree 12 := .split 25 q12Shape42T1374 q12Shape42T1383
private theorem q12Shape42T1373OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 17438720 q12Shape42T1373=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 (17438720 ||| 2^25) q12Shape42T1374 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263680 ||| 2^25) 17438720 q12Shape42T1383)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1374OK,q12Shape42T1383OK⟩

private def q12Shape42T1392 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 39 (.tip (.cover {1,2,3,6,7,10,11})) (.split 40 (.split 28 (.tip (.cover {1,2,3,6,7,9,11})) (.tip (.cover {0,1,3,5,7,8,11}))) (.tip (.cover {2,3,6,7,9,10,11})))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,2,4,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape42T1392OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 1111226368 q12Shape42T1392=true := by decide

private def q12Shape42T1393 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1393OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 19138048 1109129216 q12Shape42T1393=true := by decide

private def q12Shape42T1391 : Tree 12 := .split 21 q12Shape42T1392 q12Shape42T1393
private theorem q12Shape42T1391OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 1109129216 q12Shape42T1391=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (1109129216 ||| 2^21) q12Shape42T1392 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^21) 1109129216 q12Shape42T1393)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1392OK,q12Shape42T1393OK⟩

private def q12Shape42T1394 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T1394OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 18089472 1108080640 q12Shape42T1394=true := by decide

private def q12Shape42T1390 : Tree 12 := .split 20 q12Shape42T1391 q12Shape42T1394
private theorem q12Shape42T1390OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 1108080640 q12Shape42T1390=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (1108080640 ||| 2^20) q12Shape42T1391 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^20) 1108080640 q12Shape42T1394)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1391OK,q12Shape42T1394OK⟩

private def q12Shape42T1395 : Tree 12 := (.split 39 (.split 40 (.split 42 (.tip (.cover {1,2,4,5,6,7,11})) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T1395OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090782720 34338816 q12Shape42T1395=true := by decide

private def q12Shape42T1389 : Tree 12 := .split 30 q12Shape42T1390 q12Shape42T1395
private theorem q12Shape42T1389OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 34338816 q12Shape42T1389=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (34338816 ||| 2^30) q12Shape42T1390 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^30) 34338816 q12Shape42T1395)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1390OK,q12Shape42T1395OK⟩

private def q12Shape42T1396 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1396OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17106432 34273280 q12Shape42T1396=true := by decide

private def q12Shape42T1388 : Tree 12 := .split 16 q12Shape42T1389 q12Shape42T1396
private theorem q12Shape42T1388OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 34273280 q12Shape42T1388=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (34273280 ||| 2^16) q12Shape42T1389 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^16) 34273280 q12Shape42T1396)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1389OK,q12Shape42T1396OK⟩

private def q12Shape42T1397 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1397OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17073664 34240512 q12Shape42T1397=true := by decide

private def q12Shape42T1387 : Tree 12 := .split 15 q12Shape42T1388 q12Shape42T1397
private theorem q12Shape42T1387OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 34240512 q12Shape42T1387=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (34240512 ||| 2^15) q12Shape42T1388 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^15) 34240512 q12Shape42T1397)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1388OK,q12Shape42T1397OK⟩

private def q12Shape42T1398 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1398OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17057280 34224128 q12Shape42T1398=true := by decide

private def q12Shape42T1386 : Tree 12 := .split 14 q12Shape42T1387 q12Shape42T1398
private theorem q12Shape42T1386OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 34224128 q12Shape42T1386=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (34224128 ||| 2^14) q12Shape42T1387 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^14) 34224128 q12Shape42T1398)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1387OK,q12Shape42T1398OK⟩

private def q12Shape42T1399 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T1399OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17049088 34215936 q12Shape42T1399=true := by decide

private def q12Shape42T1385 : Tree 12 := .split 13 q12Shape42T1386 q12Shape42T1399
private theorem q12Shape42T1385OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 34215936 q12Shape42T1385=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (34215936 ||| 2^13) q12Shape42T1386 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^13) 34215936 q12Shape42T1399)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1386OK,q12Shape42T1399OK⟩

private def q12Shape42T1400 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T1400OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50595328 661504 q12Shape42T1400=true := by decide

private def q12Shape42T1384 : Tree 12 := .split 25 q12Shape42T1385 q12Shape42T1400
private theorem q12Shape42T1384OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 661504 q12Shape42T1384=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17040896 (661504 ||| 2^25) q12Shape42T1385 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (17040896 ||| 2^25) 661504 q12Shape42T1400)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1385OK,q12Shape42T1400OK⟩

private def q12Shape42T1372 : Tree 12 := .split 24 q12Shape42T1373 q12Shape42T1384
private theorem q12Shape42T1372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 661504 q12Shape42T1372=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 (661504 ||| 2^24) q12Shape42T1373 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263680 ||| 2^24) 661504 q12Shape42T1384)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1373OK,q12Shape42T1384OK⟩

private def q12Shape42T1401 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T1401OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 787968 137216 q12Shape42T1401=true := by decide

private def q12Shape42T1371 : Tree 12 := .split 19 q12Shape42T1372 q12Shape42T1401
private theorem q12Shape42T1371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 137216 q12Shape42T1371=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 (137216 ||| 2^19) q12Shape42T1372 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (263680 ||| 2^19) 137216 q12Shape42T1401)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1372OK,q12Shape42T1401OK⟩

def q12Shape42P47 : Tree 12 := q12Shape42T1371
theorem q12Shape42P47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 263680 137216 q12Shape42P47=true := q12Shape42T1371OK

private def q12Shape42T1405 : Tree 12 := (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))))
private theorem q12Shape42T1405OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132608 792576 q12Shape42T1405=true := by decide

private def q12Shape42T1406 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape42T1406OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 656896 268288 q12Shape42T1406=true := by decide

private def q12Shape42T1404 : Tree 12 := .split 19 q12Shape42T1405 q12Shape42T1406
private theorem q12Shape42T1404OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132608 268288 q12Shape42T1404=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132608 (268288 ||| 2^19) q12Shape42T1405 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (132608 ||| 2^19) 268288 q12Shape42T1406)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1405OK,q12Shape42T1406OK⟩

private def q12Shape42T1407 : Tree 12 := (.split 19 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape42T1407OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 394752 6144 q12Shape42T1407=true := by decide

private def q12Shape42T1403 : Tree 12 := .split 18 q12Shape42T1404 q12Shape42T1407
private theorem q12Shape42T1403OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132608 6144 q12Shape42T1403=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132608 (6144 ||| 2^18) q12Shape42T1404 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (132608 ||| 2^18) 6144 q12Shape42T1407)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T1404OK,q12Shape42T1407OK⟩

def q12Shape42P48 : Tree 12 := q12Shape42T1403
theorem q12Shape42P48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 132608 6144 q12Shape42P48=true := q12Shape42T1403OK

private def q12Shape42T1409 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T1409OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5632 2048 q12Shape42T1409=true := by decide

def q12Shape42P49 : Tree 12 := q12Shape42T1409
theorem q12Shape42P49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 5632 2048 q12Shape42P49=true := q12Shape42T1409OK

private def q12Shape42T1411 : Tree 12 := (.split 12 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape42T1411OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3584 0 q12Shape42T1411=true := by decide

def q12Shape42P50 : Tree 12 := q12Shape42T1411
theorem q12Shape42P50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 3584 0 q12Shape42P50=true := q12Shape42T1411OK

end Graffiti384b.EffectiveSearch.Q12
