import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T204 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4096 17174016 q12Shape42T204=true := by decide

private def q12Shape42T211 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 3849398914560 q12Shape42T211=true := by decide

private def q12Shape42T212 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199040036864 1650375659008 q12Shape42T212=true := by decide

private def q12Shape42T210 : Tree 12 := .split 41 q12Shape42T211 q12Shape42T212
private theorem q12Shape42T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 1650375659008 q12Shape42T210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 (1650375659008 ||| 2^41) q12Shape42T211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16781312 ||| 2^41) 1650375659008 q12Shape42T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T211OK,q12Shape42T212OK⟩

private def q12Shape42T213 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099528409088 550864031232 q12Shape42T213=true := by decide

private def q12Shape42T209 : Tree 12 := .split 40 q12Shape42T210 q12Shape42T213
private theorem q12Shape42T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 550864031232 q12Shape42T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 (550864031232 ||| 2^40) q12Shape42T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16781312 ||| 2^40) 550864031232 q12Shape42T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T210OK,q12Shape42T213OK⟩

private def q12Shape42T214 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549772595200 1108217344 q12Shape42T214=true := by decide

private def q12Shape42T208 : Tree 12 := .split 39 q12Shape42T209 q12Shape42T214
private theorem q12Shape42T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 1108217344 q12Shape42T208=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 (1108217344 ||| 2^39) q12Shape42T209 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16781312 ||| 2^39) 1108217344 q12Shape42T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T209OK,q12Shape42T214OK⟩

private def q12Shape42T222 : Tree 12 := (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,4,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape42T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 3848325295616 q12Shape42T222=true := by decide

private def q12Shape42T223 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2200113778688 1649302040064 q12Shape42T223=true := by decide

private def q12Shape42T221 : Tree 12 := .split 41 q12Shape42T222 q12Shape42T223
private theorem q12Shape42T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 1649302040064 q12Shape42T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 (1649302040064 ||| 2^41) q12Shape42T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090523136 ||| 2^41) 1649302040064 q12Shape42T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T222OK,q12Shape42T223OK⟩

private def q12Shape42T224 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1100602150912 549790412288 q12Shape42T224=true := by decide

private def q12Shape42T220 : Tree 12 := .split 40 q12Shape42T221 q12Shape42T224
private theorem q12Shape42T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 549790412288 q12Shape42T220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 (549790412288 ||| 2^40) q12Shape42T221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090523136 ||| 2^40) 549790412288 q12Shape42T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T221OK,q12Shape42T224OK⟩

private def q12Shape42T225 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550846337024 34598400 q12Shape42T225=true := by decide

private def q12Shape42T219 : Tree 12 := .split 39 q12Shape42T220 q12Shape42T225
private theorem q12Shape42T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 34598400 q12Shape42T219=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 (34598400 ||| 2^39) q12Shape42T220 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090523136 ||| 2^39) 34598400 q12Shape42T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T220OK,q12Shape42T225OK⟩

private def q12Shape42T226 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090588672 34532864 q12Shape42T226=true := by decide

private def q12Shape42T218 : Tree 12 := .split 16 q12Shape42T219 q12Shape42T226
private theorem q12Shape42T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 34532864 q12Shape42T218=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 (34532864 ||| 2^16) q12Shape42T219 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090523136 ||| 2^16) 34532864 q12Shape42T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T219OK,q12Shape42T226OK⟩

private def q12Shape42T227 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090555904 34500096 q12Shape42T227=true := by decide

private def q12Shape42T217 : Tree 12 := .split 15 q12Shape42T218 q12Shape42T227
private theorem q12Shape42T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 34500096 q12Shape42T217=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 (34500096 ||| 2^15) q12Shape42T218 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090523136 ||| 2^15) 34500096 q12Shape42T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T218OK,q12Shape42T227OK⟩

private def q12Shape42T228 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090539520 34483712 q12Shape42T228=true := by decide

private def q12Shape42T216 : Tree 12 := .split 14 q12Shape42T217 q12Shape42T228
private theorem q12Shape42T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 34483712 q12Shape42T216=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 (34483712 ||| 2^14) q12Shape42T217 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090523136 ||| 2^14) 34483712 q12Shape42T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T217OK,q12Shape42T228OK⟩

private def q12Shape42T229 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090531328 34475520 q12Shape42T229=true := by decide

private def q12Shape42T215 : Tree 12 := .split 13 q12Shape42T216 q12Shape42T229
private theorem q12Shape42T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 34475520 q12Shape42T215=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1090523136 (34475520 ||| 2^13) q12Shape42T216 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1090523136 ||| 2^13) 34475520 q12Shape42T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T216OK,q12Shape42T229OK⟩

private def q12Shape42T207 : Tree 12 := .split 30 q12Shape42T208 q12Shape42T215
private theorem q12Shape42T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 34475520 q12Shape42T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 (34475520 ||| 2^30) q12Shape42T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16781312 ||| 2^30) 34475520 q12Shape42T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T208OK,q12Shape42T215OK⟩

private def q12Shape42T238 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 3849365483008 q12Shape42T238=true := by decide

private def q12Shape42T239 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199073591296 1650342227456 q12Shape42T239=true := by decide

private def q12Shape42T237 : Tree 12 := .split 41 q12Shape42T238 q12Shape42T239
private theorem q12Shape42T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 1650342227456 q12Shape42T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (1650342227456 ||| 2^41) q12Shape42T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^41) 1650342227456 q12Shape42T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T238OK,q12Shape42T239OK⟩

private def q12Shape42T240 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099561963520 550830599680 q12Shape42T240=true := by decide

private def q12Shape42T236 : Tree 12 := .split 40 q12Shape42T237 q12Shape42T240
private theorem q12Shape42T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 550830599680 q12Shape42T236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (550830599680 ||| 2^40) q12Shape42T237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^40) 550830599680 q12Shape42T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T237OK,q12Shape42T240OK⟩

private def q12Shape42T241 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549806149632 1074785792 q12Shape42T241=true := by decide

private def q12Shape42T235 : Tree 12 := .split 39 q12Shape42T236 q12Shape42T241
private theorem q12Shape42T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 1074785792 q12Shape42T235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (1074785792 ||| 2^39) q12Shape42T236 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^39) 1074785792 q12Shape42T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T236OK,q12Shape42T241OK⟩

private def q12Shape42T242 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50401280 1074720256 q12Shape42T242=true := by decide

private def q12Shape42T234 : Tree 12 := .split 16 q12Shape42T235 q12Shape42T242
private theorem q12Shape42T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 1074720256 q12Shape42T234=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (1074720256 ||| 2^16) q12Shape42T235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^16) 1074720256 q12Shape42T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T235OK,q12Shape42T242OK⟩

private def q12Shape42T243 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50368512 1074687488 q12Shape42T243=true := by decide

private def q12Shape42T233 : Tree 12 := .split 15 q12Shape42T234 q12Shape42T243
private theorem q12Shape42T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 1074687488 q12Shape42T233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (1074687488 ||| 2^15) q12Shape42T234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^15) 1074687488 q12Shape42T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T234OK,q12Shape42T243OK⟩

private def q12Shape42T244 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50352128 1074671104 q12Shape42T244=true := by decide

private def q12Shape42T232 : Tree 12 := .split 14 q12Shape42T233 q12Shape42T244
private theorem q12Shape42T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 1074671104 q12Shape42T232=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (1074671104 ||| 2^14) q12Shape42T233 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^14) 1074671104 q12Shape42T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T233OK,q12Shape42T244OK⟩

private def q12Shape42T245 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape42T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50343936 1074662912 q12Shape42T245=true := by decide

private def q12Shape42T231 : Tree 12 := .split 13 q12Shape42T232 q12Shape42T245
private theorem q12Shape42T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 1074662912 q12Shape42T231=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (1074662912 ||| 2^13) q12Shape42T232 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^13) 1074662912 q12Shape42T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T232OK,q12Shape42T245OK⟩

private def q12Shape42T246 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1124077568 921088 q12Shape42T246=true := by decide

private def q12Shape42T230 : Tree 12 := .split 30 q12Shape42T231 q12Shape42T246
private theorem q12Shape42T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 921088 q12Shape42T230=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 50335744 (921088 ||| 2^30) q12Shape42T231 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (50335744 ||| 2^30) 921088 q12Shape42T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T231OK,q12Shape42T246OK⟩

private def q12Shape42T206 : Tree 12 := .split 25 q12Shape42T207 q12Shape42T230
private theorem q12Shape42T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 921088 q12Shape42T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 (921088 ||| 2^25) q12Shape42T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16781312 ||| 2^25) 921088 q12Shape42T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T207OK,q12Shape42T230OK⟩

private def q12Shape42T247 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape42T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17305600 396800 q12Shape42T247=true := by decide

private def q12Shape42T205 : Tree 12 := .split 19 q12Shape42T206 q12Shape42T247
private theorem q12Shape42T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 396800 q12Shape42T205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 16781312 (396800 ||| 2^19) q12Shape42T206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (16781312 ||| 2^19) 396800 q12Shape42T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T206OK,q12Shape42T247OK⟩

private def q12Shape42T203 : Tree 12 := .split 24 q12Shape42T204 q12Shape42T205
private theorem q12Shape42T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4096 396800 q12Shape42T203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4096 (396800 ||| 2^24) q12Shape42T204 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (4096 ||| 2^24) 396800 q12Shape42T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T204OK,q12Shape42T205OK⟩

def q12Shape42P6 : Tree 12 := q12Shape42T203
theorem q12Shape42P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 4096 396800 q12Shape42P6=true := q12Shape42T203OK

end Graffiti384b.EffectiveSearch.Q12
