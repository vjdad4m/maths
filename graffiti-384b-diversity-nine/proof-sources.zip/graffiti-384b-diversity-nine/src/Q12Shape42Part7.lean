import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T255 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 3849415429632 q12Shape42T255=true := by decide

private def q12Shape42T256 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023521792 1650392174080 q12Shape42T256=true := by decide

private def q12Shape42T254 : Tree 12 := .split 41 q12Shape42T255 q12Shape42T256
private theorem q12Shape42T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 1650392174080 q12Shape42T254=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 (1650392174080 ||| 2^41) q12Shape42T255 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266240 ||| 2^41) 1650392174080 q12Shape42T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T255OK,q12Shape42T256OK⟩

private def q12Shape42T257 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099511894016 550880546304 q12Shape42T257=true := by decide

private def q12Shape42T253 : Tree 12 := .split 40 q12Shape42T254 q12Shape42T257
private theorem q12Shape42T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 550880546304 q12Shape42T253=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 (550880546304 ||| 2^40) q12Shape42T254 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266240 ||| 2^40) 550880546304 q12Shape42T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T254OK,q12Shape42T257OK⟩

private def q12Shape42T258 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756080128 1124732416 q12Shape42T258=true := by decide

private def q12Shape42T252 : Tree 12 := .split 39 q12Shape42T253 q12Shape42T258
private theorem q12Shape42T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 1124732416 q12Shape42T252=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 (1124732416 ||| 2^39) q12Shape42T253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266240 ||| 2^39) 1124732416 q12Shape42T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T253OK,q12Shape42T258OK⟩

private def q12Shape42T268 : Tree 12 := (.split 40 (.split 42 (.tip (.cover {0,1,2,5,6,7,11})) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 41 (.split 43 (.tip (.cover {0,1,2,5,6,7,10})) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 549822656000 q12Shape42T268=true := by decide

private def q12Shape42T269 : Tree 12 := (.split 40 (.split 41 (.split 44 (.tip (.cover {0,1,2,5,6,7,9})) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 550829821952 66842112 q12Shape42T269=true := by decide

private def q12Shape42T267 : Tree 12 := .split 39 q12Shape42T268 q12Shape42T269
private theorem q12Shape42T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 66842112 q12Shape42T267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (66842112 ||| 2^39) q12Shape42T268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^39) 66842112 q12Shape42T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T268OK,q12Shape42T269OK⟩

private def q12Shape42T270 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1082396672 58453504 q12Shape42T270=true := by decide

private def q12Shape42T266 : Tree 12 := .split 23 q12Shape42T267 q12Shape42T270
private theorem q12Shape42T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 58453504 q12Shape42T266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (58453504 ||| 2^23) q12Shape42T267 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^23) 58453504 q12Shape42T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T267OK,q12Shape42T270OK⟩

private def q12Shape42T271 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1078202368 54259200 q12Shape42T271=true := by decide

private def q12Shape42T265 : Tree 12 := .split 22 q12Shape42T266 q12Shape42T271
private theorem q12Shape42T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 54259200 q12Shape42T265=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (54259200 ||| 2^22) q12Shape42T266 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^22) 54259200 q12Shape42T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T266OK,q12Shape42T271OK⟩

private def q12Shape42T272 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1076105216 52162048 q12Shape42T272=true := by decide

private def q12Shape42T264 : Tree 12 := .split 21 q12Shape42T265 q12Shape42T272
private theorem q12Shape42T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 52162048 q12Shape42T264=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (52162048 ||| 2^21) q12Shape42T265 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^21) 52162048 q12Shape42T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T265OK,q12Shape42T272OK⟩

private def q12Shape42T273 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1075056640 51113472 q12Shape42T273=true := by decide

private def q12Shape42T263 : Tree 12 := .split 20 q12Shape42T264 q12Shape42T273
private theorem q12Shape42T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 51113472 q12Shape42T263=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (51113472 ||| 2^20) q12Shape42T264 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^20) 51113472 q12Shape42T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T264OK,q12Shape42T273OK⟩

private def q12Shape42T274 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074073600 51047936 q12Shape42T274=true := by decide

private def q12Shape42T262 : Tree 12 := .split 16 q12Shape42T263 q12Shape42T274
private theorem q12Shape42T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 51047936 q12Shape42T262=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (51047936 ||| 2^16) q12Shape42T263 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^16) 51047936 q12Shape42T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T263OK,q12Shape42T274OK⟩

private def q12Shape42T275 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074040832 51015168 q12Shape42T275=true := by decide

private def q12Shape42T261 : Tree 12 := .split 15 q12Shape42T262 q12Shape42T275
private theorem q12Shape42T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 51015168 q12Shape42T261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (51015168 ||| 2^15) q12Shape42T262 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^15) 51015168 q12Shape42T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T262OK,q12Shape42T275OK⟩

private def q12Shape42T276 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074024448 50998784 q12Shape42T276=true := by decide

private def q12Shape42T260 : Tree 12 := .split 14 q12Shape42T261 q12Shape42T276
private theorem q12Shape42T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 50998784 q12Shape42T260=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (50998784 ||| 2^14) q12Shape42T261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^14) 50998784 q12Shape42T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T261OK,q12Shape42T276OK⟩

private def q12Shape42T277 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape42T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074016256 50990592 q12Shape42T277=true := by decide

private def q12Shape42T259 : Tree 12 := .split 13 q12Shape42T260 q12Shape42T277
private theorem q12Shape42T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 50990592 q12Shape42T259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074008064 (50990592 ||| 2^13) q12Shape42T260 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (1074008064 ||| 2^13) 50990592 q12Shape42T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T260OK,q12Shape42T277OK⟩

private def q12Shape42T251 : Tree 12 := .split 30 q12Shape42T252 q12Shape42T259
private theorem q12Shape42T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 50990592 q12Shape42T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 (50990592 ||| 2^30) q12Shape42T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266240 ||| 2^30) 50990592 q12Shape42T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T252OK,q12Shape42T259OK⟩

private def q12Shape42T278 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape42T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 33820672 17436160 q12Shape42T278=true := by decide

private def q12Shape42T250 : Tree 12 := .split 25 q12Shape42T251 q12Shape42T278
private theorem q12Shape42T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 17436160 q12Shape42T250=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 (17436160 ||| 2^25) q12Shape42T251 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266240 ||| 2^25) 17436160 q12Shape42T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T251OK,q12Shape42T278OK⟩

private def q12Shape42T279 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17043456 658944 q12Shape42T279=true := by decide

private def q12Shape42T249 : Tree 12 := .split 24 q12Shape42T250 q12Shape42T279
private theorem q12Shape42T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 658944 q12Shape42T249=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 (658944 ||| 2^24) q12Shape42T250 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266240 ||| 2^24) 658944 q12Shape42T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T250OK,q12Shape42T279OK⟩

private def q12Shape42T290 : Tree 12 := (.split 42 (.split 43 (.tip (.small 1)) (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,11})))) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape42T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 3849415028224 q12Shape42T290=true := by decide

private def q12Shape42T291 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199024046080 1650391772672 q12Shape42T291=true := by decide

private def q12Shape42T289 : Tree 12 := .split 41 q12Shape42T290 q12Shape42T291
private theorem q12Shape42T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 1650391772672 q12Shape42T289=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (1650391772672 ||| 2^41) q12Shape42T290 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^41) 1650391772672 q12Shape42T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T290OK,q12Shape42T291OK⟩

private def q12Shape42T292 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape42T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512418304 550880144896 q12Shape42T292=true := by decide

private def q12Shape42T288 : Tree 12 := .split 40 q12Shape42T289 q12Shape42T292
private theorem q12Shape42T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 550880144896 q12Shape42T288=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (550880144896 ||| 2^40) q12Shape42T289 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^40) 550880144896 q12Shape42T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T289OK,q12Shape42T292OK⟩

private def q12Shape42T293 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape42T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756604416 1124331008 q12Shape42T293=true := by decide

private def q12Shape42T287 : Tree 12 := .split 39 q12Shape42T288 q12Shape42T293
private theorem q12Shape42T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 1124331008 q12Shape42T287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (1124331008 ||| 2^39) q12Shape42T288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^39) 1124331008 q12Shape42T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T288OK,q12Shape42T293OK⟩

private def q12Shape42T294 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 856064 1124265472 q12Shape42T294=true := by decide

private def q12Shape42T286 : Tree 12 := .split 16 q12Shape42T287 q12Shape42T294
private theorem q12Shape42T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 1124265472 q12Shape42T286=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (1124265472 ||| 2^16) q12Shape42T287 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^16) 1124265472 q12Shape42T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T287OK,q12Shape42T294OK⟩

private def q12Shape42T295 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 823296 1124232704 q12Shape42T295=true := by decide

private def q12Shape42T285 : Tree 12 := .split 15 q12Shape42T286 q12Shape42T295
private theorem q12Shape42T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 1124232704 q12Shape42T285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (1124232704 ||| 2^15) q12Shape42T286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^15) 1124232704 q12Shape42T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T286OK,q12Shape42T295OK⟩

private def q12Shape42T296 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 806912 1124216320 q12Shape42T296=true := by decide

private def q12Shape42T284 : Tree 12 := .split 14 q12Shape42T285 q12Shape42T296
private theorem q12Shape42T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 1124216320 q12Shape42T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (1124216320 ||| 2^14) q12Shape42T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^14) 1124216320 q12Shape42T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T285OK,q12Shape42T296OK⟩

private def q12Shape42T297 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 798720 1124208128 q12Shape42T297=true := by decide

private def q12Shape42T283 : Tree 12 := .split 13 q12Shape42T284 q12Shape42T297
private theorem q12Shape42T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 1124208128 q12Shape42T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (1124208128 ||| 2^13) q12Shape42T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^13) 1124208128 q12Shape42T297)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T284OK,q12Shape42T297OK⟩

private def q12Shape42T298 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape42T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34344960 1090653696 q12Shape42T298=true := by decide

private def q12Shape42T282 : Tree 12 := .split 25 q12Shape42T283 q12Shape42T298
private theorem q12Shape42T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 1090653696 q12Shape42T282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (1090653696 ||| 2^25) q12Shape42T283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^25) 1090653696 q12Shape42T298)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T283OK,q12Shape42T298OK⟩

private def q12Shape42T299 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074532352 16911872 q12Shape42T299=true := by decide

private def q12Shape42T281 : Tree 12 := .split 30 q12Shape42T282 q12Shape42T299
private theorem q12Shape42T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 16911872 q12Shape42T281=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (16911872 ||| 2^30) q12Shape42T282 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^30) 16911872 q12Shape42T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T282OK,q12Shape42T299OK⟩

private def q12Shape42T300 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape42T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17567744 134656 q12Shape42T300=true := by decide

private def q12Shape42T280 : Tree 12 := .split 24 q12Shape42T281 q12Shape42T300
private theorem q12Shape42T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 134656 q12Shape42T280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 790528 (134656 ||| 2^24) q12Shape42T281 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (790528 ||| 2^24) 134656 q12Shape42T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T281OK,q12Shape42T300OK⟩

private def q12Shape42T248 : Tree 12 := .split 19 q12Shape42T249 q12Shape42T280
private theorem q12Shape42T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 134656 q12Shape42T248=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 (134656 ||| 2^19) q12Shape42T249 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (266240 ||| 2^19) 134656 q12Shape42T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T249OK,q12Shape42T280OK⟩

def q12Shape42P7 : Tree 12 := q12Shape42T248
theorem q12Shape42P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 266240 134656 q12Shape42P7=true := q12Shape42T248OK

end Graffiti384b.EffectiveSearch.Q12
