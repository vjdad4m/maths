import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape42T345 : Tree 12 := (.split 26 (.split 27 (.split 28 (.split 42 (.tip (.cover {0,1,2,4,6,7,11})) (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,9})))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape42T345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 3849415159296 q12Shape42T345=true := by decide

private def q12Shape42T346 : Tree 12 := (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T346OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 2199023915008 1650391903744 q12Shape42T346=true := by decide

private def q12Shape42T344 : Tree 12 := .split 41 q12Shape42T345 q12Shape42T346
private theorem q12Shape42T344OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 1650391903744 q12Shape42T344=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (1650391903744 ||| 2^41) q12Shape42T345 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^41) 1650391903744 q12Shape42T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T345OK,q12Shape42T346OK⟩

private def q12Shape42T347 : Tree 12 := (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape42T347OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1099512287232 550880275968 q12Shape42T347=true := by decide

private def q12Shape42T343 : Tree 12 := .split 40 q12Shape42T344 q12Shape42T347
private theorem q12Shape42T343OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 550880275968 q12Shape42T343=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (550880275968 ||| 2^40) q12Shape42T344 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^40) 550880275968 q12Shape42T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T344OK,q12Shape42T347OK⟩

private def q12Shape42T348 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape42T348OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 549756473344 1124462080 q12Shape42T348=true := by decide

private def q12Shape42T342 : Tree 12 := .split 39 q12Shape42T343 q12Shape42T348
private theorem q12Shape42T342OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 1124462080 q12Shape42T342=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (1124462080 ||| 2^39) q12Shape42T343 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^39) 1124462080 q12Shape42T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T343OK,q12Shape42T348OK⟩

private def q12Shape42T349 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 724992 1124396544 q12Shape42T349=true := by decide

private def q12Shape42T341 : Tree 12 := .split 16 q12Shape42T342 q12Shape42T349
private theorem q12Shape42T341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 1124396544 q12Shape42T341=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (1124396544 ||| 2^16) q12Shape42T342 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^16) 1124396544 q12Shape42T349)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T342OK,q12Shape42T349OK⟩

private def q12Shape42T350 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T350OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 692224 1124363776 q12Shape42T350=true := by decide

private def q12Shape42T340 : Tree 12 := .split 15 q12Shape42T341 q12Shape42T350
private theorem q12Shape42T340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 1124363776 q12Shape42T340=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (1124363776 ||| 2^15) q12Shape42T341 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^15) 1124363776 q12Shape42T350)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T341OK,q12Shape42T350OK⟩

private def q12Shape42T351 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 675840 1124347392 q12Shape42T351=true := by decide

private def q12Shape42T339 : Tree 12 := .split 14 q12Shape42T340 q12Shape42T351
private theorem q12Shape42T339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 1124347392 q12Shape42T339=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (1124347392 ||| 2^14) q12Shape42T340 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^14) 1124347392 q12Shape42T351)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T340OK,q12Shape42T351OK⟩

private def q12Shape42T352 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape42T352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 667648 1124339200 q12Shape42T352=true := by decide

private def q12Shape42T338 : Tree 12 := .split 13 q12Shape42T339 q12Shape42T352
private theorem q12Shape42T338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 1124339200 q12Shape42T338=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (1124339200 ||| 2^13) q12Shape42T339 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^13) 1124339200 q12Shape42T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T339OK,q12Shape42T352OK⟩

private def q12Shape42T353 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape42T353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 1074401280 50597376 q12Shape42T353=true := by decide

private def q12Shape42T337 : Tree 12 := .split 30 q12Shape42T338 q12Shape42T353
private theorem q12Shape42T337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 50597376 q12Shape42T337=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (50597376 ||| 2^30) q12Shape42T338 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^30) 50597376 q12Shape42T353)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T338OK,q12Shape42T353OK⟩

private def q12Shape42T354 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape42T354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 34213888 17042944 q12Shape42T354=true := by decide

private def q12Shape42T336 : Tree 12 := .split 25 q12Shape42T337 q12Shape42T354
private theorem q12Shape42T336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 17042944 q12Shape42T336=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (17042944 ||| 2^25) q12Shape42T337 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^25) 17042944 q12Shape42T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T337OK,q12Shape42T354OK⟩

private def q12Shape42T355 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape42T355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 17436672 265728 q12Shape42T355=true := by decide

private def q12Shape42T335 : Tree 12 := .split 24 q12Shape42T336 q12Shape42T355
private theorem q12Shape42T335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 265728 q12Shape42T335=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 (265728 ||| 2^24) q12Shape42T336 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) (659456 ||| 2^24) 265728 q12Shape42T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape42T336OK,q12Shape42T355OK⟩

def q12Shape42P9 : Tree 12 := q12Shape42T335
theorem q12Shape42P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 659456 265728 q12Shape42P9=true := q12Shape42T335OK

private def q12Shape42T357 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape42T357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 397312 3584 q12Shape42T357=true := by decide

def q12Shape42P10 : Tree 12 := q12Shape42T357
theorem q12Shape42P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,1⟩) 397312 3584 q12Shape42P10=true := q12Shape42T357OK

end Graffiti384b.EffectiveSearch.Q12
