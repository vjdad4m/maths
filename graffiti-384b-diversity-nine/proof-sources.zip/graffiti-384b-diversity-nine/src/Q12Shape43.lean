import Q12Shape43Part0
import Q12Shape43Part1
import Q12Shape43Part2
import Q12Shape43Part3
import Q12Shape43Part4
import Q12Shape43Part5
import Q12Shape43Part6
import Q12Shape43Part7

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape43M44 : Tree 12 := .split 25 q12Shape43P0 q12Shape43P1
private theorem q12Shape43M44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 17694720 q12Shape43M44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 (17694720 ||| 2^25) q12Shape43P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (0 ||| 2^25) 17694720 q12Shape43P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43P0OK,q12Shape43P1OK⟩
private def q12Shape43M82 : Tree 12 := .split 24 q12Shape43M44 q12Shape43P2
private theorem q12Shape43M82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 917504 q12Shape43M82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 (917504 ||| 2^24) q12Shape43M44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (0 ||| 2^24) 917504 q12Shape43P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M44OK,q12Shape43P2OK⟩
private def q12Shape43M120 : Tree 12 := .split 19 q12Shape43M82 q12Shape43P3
private theorem q12Shape43M120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 393216 q12Shape43M120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 (393216 ||| 2^19) q12Shape43M82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (0 ||| 2^19) 393216 q12Shape43P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M82OK,q12Shape43P3OK⟩
private def q12Shape43M169 : Tree 12 := .split 25 q12Shape43P4 q12Shape43P5
private theorem q12Shape43M169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 17432576 q12Shape43M169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (17432576 ||| 2^25) q12Shape43P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^25) 17432576 q12Shape43P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43P4OK,q12Shape43P5OK⟩
private def q12Shape43M171 : Tree 12 := .split 24 q12Shape43M169 q12Shape43P6
private theorem q12Shape43M171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 655360 q12Shape43M171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (655360 ||| 2^24) q12Shape43M169 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^24) 655360 q12Shape43P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M169OK,q12Shape43P6OK⟩
private def q12Shape43M173 : Tree 12 := .split 19 q12Shape43M171 q12Shape43P7
private theorem q12Shape43M173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 131072 q12Shape43M173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (131072 ||| 2^19) q12Shape43M171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^19) 131072 q12Shape43P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M171OK,q12Shape43P7OK⟩
private def q12Shape43M174 : Tree 12 := .split 18 q12Shape43M120 q12Shape43M173
private theorem q12Shape43M174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 131072 q12Shape43M174=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 (131072 ||| 2^18) q12Shape43M120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (0 ||| 2^18) 131072 q12Shape43M173)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M120OK,q12Shape43M173OK⟩
private def q12Shape43M233 : Tree 12 := .split 30 q12Shape43P8 q12Shape43P9
private theorem q12Shape43M233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 51118080 q12Shape43M233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (51118080 ||| 2^30) q12Shape43P8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^30) 51118080 q12Shape43P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43P8OK,q12Shape43P9OK⟩
private def q12Shape43M235 : Tree 12 := .split 25 q12Shape43M233 q12Shape43P10
private theorem q12Shape43M235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 17563648 q12Shape43M235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (17563648 ||| 2^25) q12Shape43M233 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^25) 17563648 q12Shape43P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M233OK,q12Shape43P10OK⟩
private def q12Shape43M237 : Tree 12 := .split 24 q12Shape43M235 q12Shape43P11
private theorem q12Shape43M237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 786432 q12Shape43M237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (786432 ||| 2^24) q12Shape43M235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^24) 786432 q12Shape43P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M235OK,q12Shape43P11OK⟩
private def q12Shape43M239 : Tree 12 := .split 19 q12Shape43M237 q12Shape43P12
private theorem q12Shape43M239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 262144 q12Shape43M239=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (262144 ||| 2^19) q12Shape43M237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^19) 262144 q12Shape43P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M237OK,q12Shape43P12OK⟩
private def q12Shape43M241 : Tree 12 := .split 18 q12Shape43M239 q12Shape43P13
private theorem q12Shape43M241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 0 q12Shape43M241=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (0 ||| 2^18) q12Shape43M239 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^18) 0 q12Shape43P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M239OK,q12Shape43P13OK⟩
private def q12Shape43M242 : Tree 12 := .split 17 q12Shape43M174 q12Shape43M241
private theorem q12Shape43M242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 0 q12Shape43M242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 0 (0 ||| 2^17) q12Shape43M174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (0 ||| 2^17) 0 q12Shape43M241)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43M174OK,q12Shape43M241OK⟩

theorem q12Shape43_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 43) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 43) b) (adj 12 (forms 43) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) adj_mono b H q12Shape43M242 q12Shape43M242OK

#print axioms q12Shape43_cover

end Graffiti384b.EffectiveSearch.Q12
