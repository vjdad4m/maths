import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape43T29 : Tree 12 := (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.split 31 (.split 32 (.tip (.cover {0,1,2,3,7,10,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,9,11})))) (.split 28 (.split 31 (.split 33 (.tip (.cover {0,1,2,3,7,9,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))))
private theorem q12Shape43T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 6048479838208 q12Shape43T29=true := by decide

private def q12Shape43T30 : Tree 12 := (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,2,3,6,7,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape43T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 100663296 6048412729344 q12Shape43T30=true := by decide

private def q12Shape43T28 : Tree 12 := .split 26 q12Shape43T29 q12Shape43T30
private theorem q12Shape43T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 6048412729344 q12Shape43T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (6048412729344 ||| 2^26) q12Shape43T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^26) 6048412729344 q12Shape43T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T29OK,q12Shape43T30OK⟩

private def q12Shape43T31 : Tree 12 := (.split 26 (.split 27 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,7,10,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape43T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 37748736 6048408535040 q12Shape43T31=true := by decide

private def q12Shape43T27 : Tree 12 := .split 22 q12Shape43T28 q12Shape43T31
private theorem q12Shape43T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 6048408535040 q12Shape43T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (6048408535040 ||| 2^22) q12Shape43T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^22) 6048408535040 q12Shape43T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T28OK,q12Shape43T31OK⟩

private def q12Shape43T32 : Tree 12 := (.split 22 (.split 26 (.split 28 (.split 31 (.split 33 (.tip (.cover {0,1,2,3,7,9,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape43T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 35651584 6048406437888 q12Shape43T32=true := by decide

private def q12Shape43T26 : Tree 12 := .split 21 q12Shape43T27 q12Shape43T32
private theorem q12Shape43T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 6048406437888 q12Shape43T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (6048406437888 ||| 2^21) q12Shape43T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^21) 6048406437888 q12Shape43T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T27OK,q12Shape43T32OK⟩

private def q12Shape43T33 : Tree 12 := (.split 21 (.split 22 (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape43T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 34603008 6048405389312 q12Shape43T33=true := by decide

private def q12Shape43T25 : Tree 12 := .split 20 q12Shape43T26 q12Shape43T33
private theorem q12Shape43T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 6048405389312 q12Shape43T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (6048405389312 ||| 2^20) q12Shape43T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^20) 6048405389312 q12Shape43T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T26OK,q12Shape43T33OK⟩

private def q12Shape43T34 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 26 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,7,10,11})) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape43T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4398080065536 1650358878208 q12Shape43T34=true := by decide

private def q12Shape43T24 : Tree 12 := .split 42 q12Shape43T25 q12Shape43T34
private theorem q12Shape43T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 1650358878208 q12Shape43T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (1650358878208 ||| 2^42) q12Shape43T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^42) 1650358878208 q12Shape43T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T25OK,q12Shape43T34OK⟩

private def q12Shape43T35 : Tree 12 := (.split 42 (.split 20 (.split 21 (.split 22 (.split 27 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,7,10,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape43T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099545182208 550847250432 q12Shape43T35=true := by decide

private def q12Shape43T23 : Tree 12 := .split 40 q12Shape43T24 q12Shape43T35
private theorem q12Shape43T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 550847250432 q12Shape43T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (550847250432 ||| 2^40) q12Shape43T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^40) 550847250432 q12Shape43T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T24OK,q12Shape43T35OK⟩

private def q12Shape43T37 : Tree 12 := (.split 42 (.split 20 (.split 21 (.split 22 (.split 28 (.split 31 (.split 33 (.tip (.cover {0,1,2,3,7,9,11})) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape43T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549789368320 1100603064320 q12Shape43T37=true := by decide

private def q12Shape43T38 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape43T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1649300996096 1091436544 q12Shape43T38=true := by decide

private def q12Shape43T36 : Tree 12 := .split 40 q12Shape43T37 q12Shape43T38
private theorem q12Shape43T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549789368320 1091436544 q12Shape43T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549789368320 (1091436544 ||| 2^40) q12Shape43T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (549789368320 ||| 2^40) 1091436544 q12Shape43T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T37OK,q12Shape43T38OK⟩

private def q12Shape43T22 : Tree 12 := .split 39 q12Shape43T23 q12Shape43T36
private theorem q12Shape43T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 1091436544 q12Shape43T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (1091436544 ||| 2^39) q12Shape43T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^39) 1091436544 q12Shape43T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T23OK,q12Shape43T36OK⟩

private def q12Shape43T41 : Tree 12 := (.split 42 (.split 20 (.split 21 (.split 22 (.split 35 (.split 36 (.split 37 (.tip (.cover {1,2,3,4,5,6,11})) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,9,11})))
private theorem q12Shape43T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1107296256 1649285136384 q12Shape43T41=true := by decide

private def q12Shape43T42 : Tree 12 := (.tip (.cover {0,1,4,7,8,9,11}))
private theorem q12Shape43T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1100618924032 549773508608 q12Shape43T42=true := by decide

private def q12Shape43T40 : Tree 12 := .split 40 q12Shape43T41 q12Shape43T42
private theorem q12Shape43T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1107296256 549773508608 q12Shape43T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1107296256 (549773508608 ||| 2^40) q12Shape43T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1107296256 ||| 2^40) 549773508608 q12Shape43T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T41OK,q12Shape43T42OK⟩

private def q12Shape43T43 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape43T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 550863110144 17694720 q12Shape43T43=true := by decide

private def q12Shape43T39 : Tree 12 := .split 39 q12Shape43T40 q12Shape43T43
private theorem q12Shape43T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1107296256 17694720 q12Shape43T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1107296256 (17694720 ||| 2^39) q12Shape43T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1107296256 ||| 2^39) 17694720 q12Shape43T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T40OK,q12Shape43T43OK⟩

private def q12Shape43T21 : Tree 12 := .split 30 q12Shape43T22 q12Shape43T39
private theorem q12Shape43T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 17694720 q12Shape43T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 (17694720 ||| 2^30) q12Shape43T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33554432 ||| 2^30) 17694720 q12Shape43T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T22OK,q12Shape43T39OK⟩

def q12Shape43P1 : Tree 12 := q12Shape43T21
theorem q12Shape43P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33554432 17694720 q12Shape43P1=true := q12Shape43T21OK

end Graffiti384b.EffectiveSearch.Q12
