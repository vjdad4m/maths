import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape43T54 : Tree 12 := (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.split 31 (.split 32 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))) (.split 28 (.split 31 (.split 33 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11}))))
private theorem q12Shape43T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 6048496615424 q12Shape43T54=true := by decide

private def q12Shape43T55 : Tree 12 := (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,5,7,11})) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape43T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 83886080 6048429506560 q12Shape43T55=true := by decide

private def q12Shape43T53 : Tree 12 := .split 26 q12Shape43T54 q12Shape43T55
private theorem q12Shape43T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 6048429506560 q12Shape43T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (6048429506560 ||| 2^26) q12Shape43T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^26) 6048429506560 q12Shape43T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T54OK,q12Shape43T55OK⟩

private def q12Shape43T56 : Tree 12 := (.split 26 (.split 27 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,5,10,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,9,11})))
private theorem q12Shape43T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 20971520 6048425312256 q12Shape43T56=true := by decide

private def q12Shape43T52 : Tree 12 := .split 22 q12Shape43T53 q12Shape43T56
private theorem q12Shape43T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 6048425312256 q12Shape43T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (6048425312256 ||| 2^22) q12Shape43T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^22) 6048425312256 q12Shape43T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T53OK,q12Shape43T56OK⟩

private def q12Shape43T57 : Tree 12 := (.split 22 (.split 26 (.split 28 (.split 31 (.split 33 (.split 35 (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape43T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 18874368 6048423215104 q12Shape43T57=true := by decide

private def q12Shape43T51 : Tree 12 := .split 21 q12Shape43T52 q12Shape43T57
private theorem q12Shape43T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 6048423215104 q12Shape43T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (6048423215104 ||| 2^21) q12Shape43T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^21) 6048423215104 q12Shape43T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T52OK,q12Shape43T57OK⟩

private def q12Shape43T60 : Tree 12 := (.split 27 (.split 28 (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,5,11})) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape43T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 17825792 6048428457984 q12Shape43T60=true := by decide

private def q12Shape43T61 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape43T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 22020096 6048424263680 q12Shape43T61=true := by decide

private def q12Shape43T59 : Tree 12 := .split 22 q12Shape43T60 q12Shape43T61
private theorem q12Shape43T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 17825792 6048424263680 q12Shape43T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 17825792 (6048424263680 ||| 2^22) q12Shape43T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (17825792 ||| 2^22) 6048424263680 q12Shape43T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T60OK,q12Shape43T61OK⟩

private def q12Shape43T62 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape43T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 19922944 6048422166528 q12Shape43T62=true := by decide

private def q12Shape43T58 : Tree 12 := .split 21 q12Shape43T59 q12Shape43T62
private theorem q12Shape43T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 17825792 6048422166528 q12Shape43T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 17825792 (6048422166528 ||| 2^21) q12Shape43T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (17825792 ||| 2^21) 6048422166528 q12Shape43T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T59OK,q12Shape43T62OK⟩

private def q12Shape43T50 : Tree 12 := .split 20 q12Shape43T51 q12Shape43T58
private theorem q12Shape43T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 6048422166528 q12Shape43T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (6048422166528 ||| 2^20) q12Shape43T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^20) 6048422166528 q12Shape43T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T51OK,q12Shape43T58OK⟩

private def q12Shape43T63 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 26 (.split 31 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,5,10,11})) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,4,5,7,9,11})))
private theorem q12Shape43T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4398063288320 1650375655424 q12Shape43T63=true := by decide

private def q12Shape43T49 : Tree 12 := .split 42 q12Shape43T50 q12Shape43T63
private theorem q12Shape43T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 1650375655424 q12Shape43T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (1650375655424 ||| 2^42) q12Shape43T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^42) 1650375655424 q12Shape43T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T50OK,q12Shape43T63OK⟩

private def q12Shape43T65 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 27 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,5,10,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,5,7,8,9,11})))
private theorem q12Shape43T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099528404992 4948910538752 q12Shape43T65=true := by decide

private def q12Shape43T66 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape43T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 5497574916096 550864027648 q12Shape43T66=true := by decide

private def q12Shape43T64 : Tree 12 := .split 42 q12Shape43T65 q12Shape43T66
private theorem q12Shape43T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099528404992 550864027648 q12Shape43T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099528404992 (550864027648 ||| 2^42) q12Shape43T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1099528404992 ||| 2^42) 550864027648 q12Shape43T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T65OK,q12Shape43T66OK⟩

private def q12Shape43T48 : Tree 12 := .split 40 q12Shape43T49 q12Shape43T64
private theorem q12Shape43T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 550864027648 q12Shape43T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (550864027648 ||| 2^40) q12Shape43T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^40) 550864027648 q12Shape43T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T49OK,q12Shape43T64OK⟩

private def q12Shape43T69 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 28 (.split 33 (.split 35 (.split 37 (.tip (.cover {0,1,2,3,5,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape43T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549772591104 5498666352640 q12Shape43T69=true := by decide

private def q12Shape43T70 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape43T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4947819102208 1100619841536 q12Shape43T70=true := by decide

private def q12Shape43T68 : Tree 12 := .split 42 q12Shape43T69 q12Shape43T70
private theorem q12Shape43T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549772591104 1100619841536 q12Shape43T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549772591104 (1100619841536 ||| 2^42) q12Shape43T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (549772591104 ||| 2^42) 1100619841536 q12Shape43T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T69OK,q12Shape43T70OK⟩

private def q12Shape43T71 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape43T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1649284218880 1108213760 q12Shape43T71=true := by decide

private def q12Shape43T67 : Tree 12 := .split 40 q12Shape43T68 q12Shape43T71
private theorem q12Shape43T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549772591104 1108213760 q12Shape43T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549772591104 (1108213760 ||| 2^40) q12Shape43T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (549772591104 ||| 2^40) 1108213760 q12Shape43T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T68OK,q12Shape43T71OK⟩

private def q12Shape43T47 : Tree 12 := .split 39 q12Shape43T48 q12Shape43T67
private theorem q12Shape43T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 1108213760 q12Shape43T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (1108213760 ||| 2^39) q12Shape43T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^39) 1108213760 q12Shape43T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T48OK,q12Shape43T67OK⟩

private def q12Shape43T74 : Tree 12 := (.split 42 (.split 20 (.split 21 (.split 22 (.split 31 (.split 32 (.split 33 (.tip (.cover {1,2,3,4,5,7,11})) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,8,9,11})))
private theorem q12Shape43T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1090519040 1649301913600 q12Shape43T74=true := by decide

private def q12Shape43T75 : Tree 12 := (.tip (.cover {0,1,4,6,8,9,11}))
private theorem q12Shape43T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1100602146816 549790285824 q12Shape43T75=true := by decide

private def q12Shape43T73 : Tree 12 := .split 40 q12Shape43T74 q12Shape43T75
private theorem q12Shape43T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1090519040 549790285824 q12Shape43T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1090519040 (549790285824 ||| 2^40) q12Shape43T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1090519040 ||| 2^40) 549790285824 q12Shape43T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T74OK,q12Shape43T75OK⟩

private def q12Shape43T76 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape43T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 550846332928 34471936 q12Shape43T76=true := by decide

private def q12Shape43T72 : Tree 12 := .split 39 q12Shape43T73 q12Shape43T76
private theorem q12Shape43T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1090519040 34471936 q12Shape43T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1090519040 (34471936 ||| 2^39) q12Shape43T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1090519040 ||| 2^39) 34471936 q12Shape43T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T73OK,q12Shape43T76OK⟩

private def q12Shape43T46 : Tree 12 := .split 30 q12Shape43T47 q12Shape43T72
private theorem q12Shape43T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 34471936 q12Shape43T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (34471936 ||| 2^30) q12Shape43T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^30) 34471936 q12Shape43T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T47OK,q12Shape43T72OK⟩

private def q12Shape43T79 : Tree 12 := (.split 42 (.split 20 (.split 21 (.split 22 (.split 26 (.split 27 (.split 28 (.tip (.cover {1,2,3,4,6,7,11})) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,8,9,11})))
private theorem q12Shape43T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 50331648 1649268359168 q12Shape43T79=true := by decide

private def q12Shape43T80 : Tree 12 := (.tip (.cover {0,1,4,5,8,9,11}))
private theorem q12Shape43T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099561959424 549756731392 q12Shape43T80=true := by decide

private def q12Shape43T78 : Tree 12 := .split 40 q12Shape43T79 q12Shape43T80
private theorem q12Shape43T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 50331648 549756731392 q12Shape43T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 50331648 (549756731392 ||| 2^40) q12Shape43T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (50331648 ||| 2^40) 549756731392 q12Shape43T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T79OK,q12Shape43T80OK⟩

private def q12Shape43T81 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape43T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549806145536 917504 q12Shape43T81=true := by decide

private def q12Shape43T77 : Tree 12 := .split 39 q12Shape43T78 q12Shape43T81
private theorem q12Shape43T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 50331648 917504 q12Shape43T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 50331648 (917504 ||| 2^39) q12Shape43T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (50331648 ||| 2^39) 917504 q12Shape43T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T78OK,q12Shape43T81OK⟩

private def q12Shape43T45 : Tree 12 := .split 25 q12Shape43T46 q12Shape43T77
private theorem q12Shape43T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 917504 q12Shape43T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 (917504 ||| 2^25) q12Shape43T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (16777216 ||| 2^25) 917504 q12Shape43T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T46OK,q12Shape43T77OK⟩

def q12Shape43P2 : Tree 12 := q12Shape43T45
theorem q12Shape43P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16777216 917504 q12Shape43P2=true := q12Shape43T45OK

end Graffiti384b.EffectiveSearch.Q12
