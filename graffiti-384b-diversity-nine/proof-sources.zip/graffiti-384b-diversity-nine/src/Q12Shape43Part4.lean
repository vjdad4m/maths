import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape43T130 : Tree 12 := (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,9,11}))))
private theorem q12Shape43T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 6048647348224 q12Shape43T130=true := by decide

private def q12Shape43T131 : Tree 12 := (.split 28 (.split 31 (.split 33 (.split 35 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape43T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 134479872 6048513130496 q12Shape43T131=true := by decide

private def q12Shape43T129 : Tree 12 := .split 27 q12Shape43T130 q12Shape43T131
private theorem q12Shape43T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 6048513130496 q12Shape43T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (6048513130496 ||| 2^27) q12Shape43T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^27) 6048513130496 q12Shape43T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T130OK,q12Shape43T131OK⟩

private def q12Shape43T132 : Tree 12 := (.split 27 (.split 28 (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,5,11})) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape43T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 67371008 6048446021632 q12Shape43T132=true := by decide

private def q12Shape43T128 : Tree 12 := .split 26 q12Shape43T129 q12Shape43T132
private theorem q12Shape43T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 6048446021632 q12Shape43T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (6048446021632 ||| 2^26) q12Shape43T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^26) 6048446021632 q12Shape43T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T129OK,q12Shape43T132OK⟩

private def q12Shape43T134 : Tree 12 := (.split 27 (.split 31 (.split 32 (.split 28 (.tip (.cover {0,1,2,3,4,7,11})) (.split 33 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,7,8,9,10,11})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape43T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4456448 6048508936192 q12Shape43T134=true := by decide

private def q12Shape43T135 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape43T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 71565312 6048441827328 q12Shape43T135=true := by decide

private def q12Shape43T133 : Tree 12 := .split 26 q12Shape43T134 q12Shape43T135
private theorem q12Shape43T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4456448 6048441827328 q12Shape43T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4456448 (6048441827328 ||| 2^26) q12Shape43T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (4456448 ||| 2^26) 6048441827328 q12Shape43T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T134OK,q12Shape43T135OK⟩

private def q12Shape43T127 : Tree 12 := .split 22 q12Shape43T128 q12Shape43T133
private theorem q12Shape43T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 6048441827328 q12Shape43T127=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (6048441827328 ||| 2^22) q12Shape43T128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^22) 6048441827328 q12Shape43T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T128OK,q12Shape43T133OK⟩

private def q12Shape43T138 : Tree 12 := (.split 28 (.split 31 (.split 32 (.split 33 (.split 27 (.tip (.cover {0,1,2,3,4,7,11})) (.split 35 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape43T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2359296 6048511033344 q12Shape43T138=true := by decide

private def q12Shape43T139 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape43T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 69468160 6048443924480 q12Shape43T139=true := by decide

private def q12Shape43T137 : Tree 12 := .split 26 q12Shape43T138 q12Shape43T139
private theorem q12Shape43T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2359296 6048443924480 q12Shape43T137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2359296 (6048443924480 ||| 2^26) q12Shape43T138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (2359296 ||| 2^26) 6048443924480 q12Shape43T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T138OK,q12Shape43T139OK⟩

private def q12Shape43T140 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape43T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 6553600 6048439730176 q12Shape43T140=true := by decide

private def q12Shape43T136 : Tree 12 := .split 22 q12Shape43T137 q12Shape43T140
private theorem q12Shape43T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2359296 6048439730176 q12Shape43T136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2359296 (6048439730176 ||| 2^22) q12Shape43T137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (2359296 ||| 2^22) 6048439730176 q12Shape43T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T137OK,q12Shape43T140OK⟩

private def q12Shape43T126 : Tree 12 := .split 21 q12Shape43T127 q12Shape43T136
private theorem q12Shape43T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 6048439730176 q12Shape43T126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (6048439730176 ||| 2^21) q12Shape43T127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^21) 6048439730176 q12Shape43T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T127OK,q12Shape43T136OK⟩

private def q12Shape43T145 : Tree 12 := (.split 31 (.split 32 (.split 33 (.split 26 (.tip (.cover {0,1,2,3,4,7,11})) (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,5,11})) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape43T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 6048847626240 q12Shape43T145=true := by decide

private def q12Shape43T146 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape43T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 269746176 6048579190784 q12Shape43T146=true := by decide

private def q12Shape43T144 : Tree 12 := .split 28 q12Shape43T145 q12Shape43T146
private theorem q12Shape43T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 6048579190784 q12Shape43T144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 (6048579190784 ||| 2^28) q12Shape43T145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1310720 ||| 2^28) 6048579190784 q12Shape43T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T145OK,q12Shape43T146OK⟩

private def q12Shape43T147 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape43T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 135528448 6048444973056 q12Shape43T147=true := by decide

private def q12Shape43T143 : Tree 12 := .split 27 q12Shape43T144 q12Shape43T147
private theorem q12Shape43T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 6048444973056 q12Shape43T143=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 (6048444973056 ||| 2^27) q12Shape43T144 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1310720 ||| 2^27) 6048444973056 q12Shape43T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T144OK,q12Shape43T147OK⟩

private def q12Shape43T148 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape43T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 5505024 6048440778752 q12Shape43T148=true := by decide

private def q12Shape43T142 : Tree 12 := .split 22 q12Shape43T143 q12Shape43T148
private theorem q12Shape43T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 6048440778752 q12Shape43T142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 (6048440778752 ||| 2^22) q12Shape43T143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1310720 ||| 2^22) 6048440778752 q12Shape43T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T143OK,q12Shape43T148OK⟩

private def q12Shape43T149 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape43T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 3407872 6048438681600 q12Shape43T149=true := by decide

private def q12Shape43T141 : Tree 12 := .split 21 q12Shape43T142 q12Shape43T149
private theorem q12Shape43T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 6048438681600 q12Shape43T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1310720 (6048438681600 ||| 2^21) q12Shape43T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1310720 ||| 2^21) 6048438681600 q12Shape43T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T142OK,q12Shape43T149OK⟩

private def q12Shape43T125 : Tree 12 := .split 20 q12Shape43T126 q12Shape43T141
private theorem q12Shape43T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 6048438681600 q12Shape43T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (6048438681600 ||| 2^20) q12Shape43T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^20) 6048438681600 q12Shape43T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T126OK,q12Shape43T141OK⟩

private def q12Shape43T150 : Tree 12 := (.split 20 (.split 26 (.split 27 (.split 28 (.split 31 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,9,11})))
private theorem q12Shape43T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4398046773248 1650392170496 q12Shape43T150=true := by decide

private def q12Shape43T124 : Tree 12 := .split 42 q12Shape43T125 q12Shape43T150
private theorem q12Shape43T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 1650392170496 q12Shape43T124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (1650392170496 ||| 2^42) q12Shape43T125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^42) 1650392170496 q12Shape43T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T125OK,q12Shape43T150OK⟩

private def q12Shape43T152 : Tree 12 := (.split 21 (.split 26 (.split 27 (.split 28 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape43T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099511889920 4948927053824 q12Shape43T152=true := by decide

private def q12Shape43T153 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape43T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 5497558401024 550880542720 q12Shape43T153=true := by decide

private def q12Shape43T151 : Tree 12 := .split 42 q12Shape43T152 q12Shape43T153
private theorem q12Shape43T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099511889920 550880542720 q12Shape43T151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099511889920 (550880542720 ||| 2^42) q12Shape43T152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1099511889920 ||| 2^42) 550880542720 q12Shape43T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T152OK,q12Shape43T153OK⟩

private def q12Shape43T123 : Tree 12 := .split 40 q12Shape43T124 q12Shape43T151
private theorem q12Shape43T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 550880542720 q12Shape43T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (550880542720 ||| 2^40) q12Shape43T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^40) 550880542720 q12Shape43T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T124OK,q12Shape43T151OK⟩

private def q12Shape43T156 : Tree 12 := (.split 22 (.split 26 (.split 27 (.split 28 (.split 33 (.split 35 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape43T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549756076032 5498682867712 q12Shape43T156=true := by decide

private def q12Shape43T157 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape43T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4947802587136 1100636356608 q12Shape43T157=true := by decide

private def q12Shape43T155 : Tree 12 := .split 42 q12Shape43T156 q12Shape43T157
private theorem q12Shape43T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549756076032 1100636356608 q12Shape43T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549756076032 (1100636356608 ||| 2^42) q12Shape43T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (549756076032 ||| 2^42) 1100636356608 q12Shape43T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T156OK,q12Shape43T157OK⟩

private def q12Shape43T158 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape43T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1649267703808 1124728832 q12Shape43T158=true := by decide

private def q12Shape43T154 : Tree 12 := .split 40 q12Shape43T155 q12Shape43T158
private theorem q12Shape43T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549756076032 1124728832 q12Shape43T154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549756076032 (1124728832 ||| 2^40) q12Shape43T155 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (549756076032 ||| 2^40) 1124728832 q12Shape43T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T155OK,q12Shape43T158OK⟩

private def q12Shape43T122 : Tree 12 := .split 39 q12Shape43T123 q12Shape43T154
private theorem q12Shape43T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 1124728832 q12Shape43T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (1124728832 ||| 2^39) q12Shape43T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^39) 1124728832 q12Shape43T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T123OK,q12Shape43T154OK⟩

private def q12Shape43T161 : Tree 12 := (.split 42 (.split 26 (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {1,2,3,4,5,7,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11})))
private theorem q12Shape43T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1074003968 1649318428672 q12Shape43T161=true := by decide

private def q12Shape43T162 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape43T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1100585631744 549806800896 q12Shape43T162=true := by decide

private def q12Shape43T160 : Tree 12 := .split 40 q12Shape43T161 q12Shape43T162
private theorem q12Shape43T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1074003968 549806800896 q12Shape43T160=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1074003968 (549806800896 ||| 2^40) q12Shape43T161 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1074003968 ||| 2^40) 549806800896 q12Shape43T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T161OK,q12Shape43T162OK⟩

private def q12Shape43T163 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape43T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 550829817856 50987008 q12Shape43T163=true := by decide

private def q12Shape43T159 : Tree 12 := .split 39 q12Shape43T160 q12Shape43T163
private theorem q12Shape43T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1074003968 50987008 q12Shape43T159=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1074003968 (50987008 ||| 2^39) q12Shape43T160 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1074003968 ||| 2^39) 50987008 q12Shape43T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T160OK,q12Shape43T163OK⟩

private def q12Shape43T121 : Tree 12 := .split 30 q12Shape43T122 q12Shape43T159
private theorem q12Shape43T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 50987008 q12Shape43T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 (50987008 ||| 2^30) q12Shape43T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (262144 ||| 2^30) 50987008 q12Shape43T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T122OK,q12Shape43T159OK⟩

def q12Shape43P4 : Tree 12 := q12Shape43T121
theorem q12Shape43P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 262144 50987008 q12Shape43P4=true := q12Shape43T121OK

end Graffiti384b.EffectiveSearch.Q12
