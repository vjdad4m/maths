import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape43T166 : Tree 12 := (.split 42 (.split 20 (.split 21 (.split 22 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,8,9,11})))
private theorem q12Shape43T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33816576 1649284874240 q12Shape43T166=true := by decide

private def q12Shape43T167 : Tree 12 := (.tip (.cover {0,1,4,5,8,9,11}))
private theorem q12Shape43T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099545444352 549773246464 q12Shape43T167=true := by decide

private def q12Shape43T165 : Tree 12 := .split 40 q12Shape43T166 q12Shape43T167
private theorem q12Shape43T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33816576 549773246464 q12Shape43T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33816576 (549773246464 ||| 2^40) q12Shape43T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33816576 ||| 2^40) 549773246464 q12Shape43T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T166OK,q12Shape43T167OK⟩

private def q12Shape43T168 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape43T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549789630464 17432576 q12Shape43T168=true := by decide

private def q12Shape43T164 : Tree 12 := .split 39 q12Shape43T165 q12Shape43T168
private theorem q12Shape43T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33816576 17432576 q12Shape43T164=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33816576 (17432576 ||| 2^39) q12Shape43T165 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (33816576 ||| 2^39) 17432576 q12Shape43T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T165OK,q12Shape43T168OK⟩

def q12Shape43P5 : Tree 12 := q12Shape43T164
theorem q12Shape43P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33816576 17432576 q12Shape43P5=true := q12Shape43T164OK

private def q12Shape43T170 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 31 (.split 32 (.split 33 (.tip (.cover {1,2,3,4,5,7,11})) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape43T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 17039360 655360 q12Shape43T170=true := by decide

def q12Shape43P6 : Tree 12 := q12Shape43T170
theorem q12Shape43P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 17039360 655360 q12Shape43P6=true := q12Shape43T170OK

private def q12Shape43T172 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 20 (.split 21 (.split 22 (.tip (.cover {1,2,3,5,6,7,11})) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape43T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 786432 131072 q12Shape43T172=true := by decide

def q12Shape43P7 : Tree 12 := q12Shape43T172
theorem q12Shape43P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 786432 131072 q12Shape43P7=true := q12Shape43T172OK

end Graffiti384b.EffectiveSearch.Q12
