import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape43T187 : Tree 12 := (.split 32 (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,9,11})))) (.split 33 (.split 35 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,7,8,11}))))
private theorem q12Shape43T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6051063398406 q12Shape43T187=true := by decide

private def q12Shape43T188 : Tree 12 := (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,6,11})) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape43T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2147614720 6048915914758 q12Shape43T188=true := by decide

private def q12Shape43T186 : Tree 12 := .split 31 q12Shape43T187 q12Shape43T188
private theorem q12Shape43T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048915914758 q12Shape43T186=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048915914758 ||| 2^31) q12Shape43T187 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^31) 6048915914758 q12Shape43T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T187OK,q12Shape43T188OK⟩

private def q12Shape43T189 : Tree 12 := (.tip (.cover {1,2,3,4,6,7,11}))
private theorem q12Shape43T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131076 6048915914754 q12Shape43T189=true := by decide

private def q12Shape43T185 : Tree 12 := .split 2 q12Shape43T186 q12Shape43T189
private theorem q12Shape43T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048915914754 q12Shape43T185=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048915914754 ||| 2^2) q12Shape43T186 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^2) 6048915914754 q12Shape43T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T186OK,q12Shape43T189OK⟩

private def q12Shape43T190 : Tree 12 := (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,5,7,11})) (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,9,11})))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,9,11})))
private theorem q12Shape43T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 268566528 6048647479298 q12Shape43T190=true := by decide

private def q12Shape43T184 : Tree 12 := .split 28 q12Shape43T185 q12Shape43T190
private theorem q12Shape43T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048647479298 q12Shape43T184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048647479298 ||| 2^28) q12Shape43T185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^28) 6048647479298 q12Shape43T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T185OK,q12Shape43T190OK⟩

private def q12Shape43T191 : Tree 12 := (.tip (.cover {1,2,3,5,6,7,11}))
private theorem q12Shape43T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131074 6048647479296 q12Shape43T191=true := by decide

private def q12Shape43T183 : Tree 12 := .split 1 q12Shape43T184 q12Shape43T191
private theorem q12Shape43T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048647479296 q12Shape43T183=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048647479296 ||| 2^1) q12Shape43T184 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^1) 6048647479296 q12Shape43T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T184OK,q12Shape43T191OK⟩

private def q12Shape43T192 : Tree 12 := (.split 28 (.split 31 (.split 33 (.split 32 (.tip (.cover {0,1,2,3,5,7,11})) (.split 35 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape43T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 134348800 6048513261568 q12Shape43T192=true := by decide

private def q12Shape43T182 : Tree 12 := .split 27 q12Shape43T183 q12Shape43T192
private theorem q12Shape43T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048513261568 q12Shape43T182=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048513261568 ||| 2^27) q12Shape43T183 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^27) 6048513261568 q12Shape43T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T183OK,q12Shape43T192OK⟩

private def q12Shape43T194 : Tree 12 := (.split 28 (.split 32 (.split 33 (.split 31 (.tip (.cover {0,1,2,3,5,7,11})) (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,6,11})) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,11})))
private theorem q12Shape43T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 67239936 6048580370432 q12Shape43T194=true := by decide

private def q12Shape43T195 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape43T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 201457664 6048446152704 q12Shape43T195=true := by decide

private def q12Shape43T193 : Tree 12 := .split 27 q12Shape43T194 q12Shape43T195
private theorem q12Shape43T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 67239936 6048446152704 q12Shape43T193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 67239936 (6048446152704 ||| 2^27) q12Shape43T194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (67239936 ||| 2^27) 6048446152704 q12Shape43T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T194OK,q12Shape43T195OK⟩

private def q12Shape43T181 : Tree 12 := .split 26 q12Shape43T182 q12Shape43T193
private theorem q12Shape43T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048446152704 q12Shape43T181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048446152704 ||| 2^26) q12Shape43T182 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^26) 6048446152704 q12Shape43T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T182OK,q12Shape43T193OK⟩

private def q12Shape43T197 : Tree 12 := (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,9,11})))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape43T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4325376 6048509067264 q12Shape43T197=true := by decide

private def q12Shape43T198 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape43T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 71434240 6048441958400 q12Shape43T198=true := by decide

private def q12Shape43T196 : Tree 12 := .split 26 q12Shape43T197 q12Shape43T198
private theorem q12Shape43T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4325376 6048441958400 q12Shape43T196=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4325376 (6048441958400 ||| 2^26) q12Shape43T197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (4325376 ||| 2^26) 6048441958400 q12Shape43T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T197OK,q12Shape43T198OK⟩

private def q12Shape43T180 : Tree 12 := .split 22 q12Shape43T181 q12Shape43T196
private theorem q12Shape43T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048441958400 q12Shape43T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048441958400 ||| 2^22) q12Shape43T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^22) 6048441958400 q12Shape43T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T181OK,q12Shape43T196OK⟩

private def q12Shape43T201 : Tree 12 := (.split 27 (.split 28 (.split 31 (.split 33 (.split 32 (.tip (.cover {0,1,2,3,4,7,11})) (.split 35 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape43T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2228224 6048511164416 q12Shape43T201=true := by decide

private def q12Shape43T202 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape43T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 69337088 6048444055552 q12Shape43T202=true := by decide

private def q12Shape43T200 : Tree 12 := .split 26 q12Shape43T201 q12Shape43T202
private theorem q12Shape43T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2228224 6048444055552 q12Shape43T200=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2228224 (6048444055552 ||| 2^26) q12Shape43T201 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (2228224 ||| 2^26) 6048444055552 q12Shape43T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T201OK,q12Shape43T202OK⟩

private def q12Shape43T203 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,11}))
private theorem q12Shape43T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 6422528 6048439861248 q12Shape43T203=true := by decide

private def q12Shape43T199 : Tree 12 := .split 22 q12Shape43T200 q12Shape43T203
private theorem q12Shape43T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2228224 6048439861248 q12Shape43T199=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 2228224 (6048439861248 ||| 2^22) q12Shape43T200 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (2228224 ||| 2^22) 6048439861248 q12Shape43T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T200OK,q12Shape43T203OK⟩

private def q12Shape43T179 : Tree 12 := .split 21 q12Shape43T180 q12Shape43T199
private theorem q12Shape43T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048439861248 q12Shape43T179=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048439861248 ||| 2^21) q12Shape43T180 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^21) 6048439861248 q12Shape43T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T180OK,q12Shape43T199OK⟩

private def q12Shape43T208 : Tree 12 := (.split 28 (.split 32 (.split 33 (.split 31 (.tip (.cover {0,1,2,3,4,7,11})) (.split 35 (.split 36 (.split 37 (.tip (.cover {0,1,2,3,4,6,11})) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape43T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 6048646430720 q12Shape43T208=true := by decide

private def q12Shape43T209 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape43T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 135397376 6048512212992 q12Shape43T209=true := by decide

private def q12Shape43T207 : Tree 12 := .split 27 q12Shape43T208 q12Shape43T209
private theorem q12Shape43T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 6048512212992 q12Shape43T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 (6048512212992 ||| 2^27) q12Shape43T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1179648 ||| 2^27) 6048512212992 q12Shape43T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T208OK,q12Shape43T209OK⟩

private def q12Shape43T210 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape43T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 68288512 6048445104128 q12Shape43T210=true := by decide

private def q12Shape43T206 : Tree 12 := .split 26 q12Shape43T207 q12Shape43T210
private theorem q12Shape43T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 6048445104128 q12Shape43T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 (6048445104128 ||| 2^26) q12Shape43T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1179648 ||| 2^26) 6048445104128 q12Shape43T210)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T207OK,q12Shape43T210OK⟩

private def q12Shape43T211 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape43T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 5373952 6048440909824 q12Shape43T211=true := by decide

private def q12Shape43T205 : Tree 12 := .split 22 q12Shape43T206 q12Shape43T211
private theorem q12Shape43T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 6048440909824 q12Shape43T205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 (6048440909824 ||| 2^22) q12Shape43T206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1179648 ||| 2^22) 6048440909824 q12Shape43T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T206OK,q12Shape43T211OK⟩

private def q12Shape43T212 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape43T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 3276800 6048438812672 q12Shape43T212=true := by decide

private def q12Shape43T204 : Tree 12 := .split 21 q12Shape43T205 q12Shape43T212
private theorem q12Shape43T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 6048438812672 q12Shape43T204=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1179648 (6048438812672 ||| 2^21) q12Shape43T205 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1179648 ||| 2^21) 6048438812672 q12Shape43T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T205OK,q12Shape43T212OK⟩

private def q12Shape43T178 : Tree 12 := .split 20 q12Shape43T179 q12Shape43T204
private theorem q12Shape43T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 6048438812672 q12Shape43T178=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (6048438812672 ||| 2^20) q12Shape43T179 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^20) 6048438812672 q12Shape43T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T179OK,q12Shape43T204OK⟩

private def q12Shape43T213 : Tree 12 := (.split 20 (.split 26 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,9,11})))
private theorem q12Shape43T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4398046642176 1650392301568 q12Shape43T213=true := by decide

private def q12Shape43T177 : Tree 12 := .split 42 q12Shape43T178 q12Shape43T213
private theorem q12Shape43T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 1650392301568 q12Shape43T177=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (1650392301568 ||| 2^42) q12Shape43T178 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^42) 1650392301568 q12Shape43T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T178OK,q12Shape43T213OK⟩

private def q12Shape43T215 : Tree 12 := (.split 21 (.split 27 (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.tip (.cover {0,1,2,3,4,10,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,8,11})))
private theorem q12Shape43T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099511758848 4948927184896 q12Shape43T215=true := by decide

private def q12Shape43T216 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape43T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 5497558269952 550880673792 q12Shape43T216=true := by decide

private def q12Shape43T214 : Tree 12 := .split 42 q12Shape43T215 q12Shape43T216
private theorem q12Shape43T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099511758848 550880673792 q12Shape43T214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1099511758848 (550880673792 ||| 2^42) q12Shape43T215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1099511758848 ||| 2^42) 550880673792 q12Shape43T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T215OK,q12Shape43T216OK⟩

private def q12Shape43T176 : Tree 12 := .split 40 q12Shape43T177 q12Shape43T214
private theorem q12Shape43T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 550880673792 q12Shape43T176=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (550880673792 ||| 2^40) q12Shape43T177 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^40) 550880673792 q12Shape43T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T177OK,q12Shape43T214OK⟩

private def q12Shape43T219 : Tree 12 := (.split 22 (.split 28 (.split 31 (.split 32 (.split 33 (.split 35 (.split 37 (.tip (.cover {0,1,2,3,4,9,11})) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,8,11})))
private theorem q12Shape43T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549755944960 5498682998784 q12Shape43T219=true := by decide

private def q12Shape43T220 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape43T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4947802456064 1100636487680 q12Shape43T220=true := by decide

private def q12Shape43T218 : Tree 12 := .split 42 q12Shape43T219 q12Shape43T220
private theorem q12Shape43T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549755944960 1100636487680 q12Shape43T218=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549755944960 (1100636487680 ||| 2^42) q12Shape43T219 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (549755944960 ||| 2^42) 1100636487680 q12Shape43T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T219OK,q12Shape43T220OK⟩

private def q12Shape43T221 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,11}))
private theorem q12Shape43T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1649267572736 1124859904 q12Shape43T221=true := by decide

private def q12Shape43T217 : Tree 12 := .split 40 q12Shape43T218 q12Shape43T221
private theorem q12Shape43T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549755944960 1124859904 q12Shape43T217=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 549755944960 (1124859904 ||| 2^40) q12Shape43T218 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (549755944960 ||| 2^40) 1124859904 q12Shape43T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T218OK,q12Shape43T221OK⟩

private def q12Shape43T175 : Tree 12 := .split 39 q12Shape43T176 q12Shape43T217
private theorem q12Shape43T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 1124859904 q12Shape43T175=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 (1124859904 ||| 2^39) q12Shape43T176 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (131072 ||| 2^39) 1124859904 q12Shape43T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T176OK,q12Shape43T217OK⟩

def q12Shape43P8 : Tree 12 := q12Shape43T175
theorem q12Shape43P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 131072 1124859904 q12Shape43P8=true := q12Shape43T175OK

end Graffiti384b.EffectiveSearch.Q12
