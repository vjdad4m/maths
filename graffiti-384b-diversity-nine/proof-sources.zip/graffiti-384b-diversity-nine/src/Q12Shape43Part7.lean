import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape43T227 : Tree 12 := (.split 22 (.split 26 (.split 27 (.split 28 (.split 31 (.split 32 (.split 33 (.tip (.cover {0,1,2,3,4,7,11})) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,6,8,9,11})))
private theorem q12Shape43T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 6047368216576 q12Shape43T227=true := by decide

private def q12Shape43T228 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape43T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1075970048 6047366119424 q12Shape43T228=true := by decide

private def q12Shape43T226 : Tree 12 := .split 21 q12Shape43T227 q12Shape43T228
private theorem q12Shape43T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 6047366119424 q12Shape43T226=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 (6047366119424 ||| 2^21) q12Shape43T227 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1073872896 ||| 2^21) 6047366119424 q12Shape43T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T227OK,q12Shape43T228OK⟩

private def q12Shape43T229 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape43T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1074921472 6047365070848 q12Shape43T229=true := by decide

private def q12Shape43T225 : Tree 12 := .split 20 q12Shape43T226 q12Shape43T229
private theorem q12Shape43T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 6047365070848 q12Shape43T225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 (6047365070848 ||| 2^20) q12Shape43T226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1073872896 ||| 2^20) 6047365070848 q12Shape43T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T226OK,q12Shape43T229OK⟩

private def q12Shape43T230 : Tree 12 := (.tip (.cover {0,1,4,6,8,9,11}))
private theorem q12Shape43T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 4399120384000 1649318559744 q12Shape43T230=true := by decide

private def q12Shape43T224 : Tree 12 := .split 42 q12Shape43T225 q12Shape43T230
private theorem q12Shape43T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 1649318559744 q12Shape43T224=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 (1649318559744 ||| 2^42) q12Shape43T225 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1073872896 ||| 2^42) 1649318559744 q12Shape43T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T225OK,q12Shape43T230OK⟩

private def q12Shape43T231 : Tree 12 := (.tip (.cover {0,1,4,6,8,9,11}))
private theorem q12Shape43T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1100585500672 549806931968 q12Shape43T231=true := by decide

private def q12Shape43T223 : Tree 12 := .split 40 q12Shape43T224 q12Shape43T231
private theorem q12Shape43T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 549806931968 q12Shape43T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 (549806931968 ||| 2^40) q12Shape43T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1073872896 ||| 2^40) 549806931968 q12Shape43T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T224OK,q12Shape43T231OK⟩

private def q12Shape43T232 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape43T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 550829686784 51118080 q12Shape43T232=true := by decide

private def q12Shape43T222 : Tree 12 := .split 39 q12Shape43T223 q12Shape43T232
private theorem q12Shape43T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 51118080 q12Shape43T222=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 (51118080 ||| 2^39) q12Shape43T223 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) (1073872896 ||| 2^39) 51118080 q12Shape43T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape43T223OK,q12Shape43T232OK⟩

def q12Shape43P9 : Tree 12 := q12Shape43T222
theorem q12Shape43P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 1073872896 51118080 q12Shape43P9=true := q12Shape43T222OK

private def q12Shape43T234 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 26 (.split 27 (.split 28 (.tip (.cover {1,2,3,4,6,7,11})) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape43T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33685504 17563648 q12Shape43T234=true := by decide

def q12Shape43P10 : Tree 12 := q12Shape43T234
theorem q12Shape43P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 33685504 17563648 q12Shape43P10=true := q12Shape43T234OK

private def q12Shape43T236 : Tree 12 := (.split 25 (.split 39 (.split 40 (.split 42 (.split 26 (.split 27 (.split 28 (.tip (.cover {1,2,3,4,6,7,11})) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape43T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16908288 786432 q12Shape43T236=true := by decide

def q12Shape43P11 : Tree 12 := q12Shape43T236
theorem q12Shape43P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 16908288 786432 q12Shape43P11=true := q12Shape43T236OK

private def q12Shape43T238 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 20 (.split 21 (.split 22 (.tip (.cover {1,2,3,5,6,7,11})) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape43T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 655360 262144 q12Shape43T238=true := by decide

def q12Shape43P12 : Tree 12 := q12Shape43T238
theorem q12Shape43P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 655360 262144 q12Shape43P12=true := q12Shape43T238OK

private def q12Shape43T240 : Tree 12 := (.split 19 (.split 39 (.split 40 (.split 42 (.split 20 (.split 21 (.split 22 (.tip (.cover {1,2,3,5,6,7,11})) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape43T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 393216 0 q12Shape43T240=true := by decide

def q12Shape43P13 : Tree 12 := q12Shape43T240
theorem q12Shape43P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,2⟩) 393216 0 q12Shape43P13=true := q12Shape43T240OK

end Graffiti384b.EffectiveSearch.Q12
