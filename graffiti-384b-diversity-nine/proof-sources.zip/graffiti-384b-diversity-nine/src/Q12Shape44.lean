import Q12Shape44Part0
import Q12Shape44Part1

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape44M72 : Tree 12 := .split 25 q12Shape44P0 q12Shape44P1
private theorem q12Shape44M72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,3⟩) 0 16777216 q12Shape44M72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,3⟩) 0 (16777216 ||| 2^25) q12Shape44P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,3⟩) (0 ||| 2^25) 16777216 q12Shape44P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape44P0OK,q12Shape44P1OK⟩
private def q12Shape44M92 : Tree 12 := .split 24 q12Shape44M72 q12Shape44P2
private theorem q12Shape44M92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,3⟩) 0 0 q12Shape44M92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,3⟩) 0 (0 ||| 2^24) q12Shape44M72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,3⟩) (0 ||| 2^24) 0 q12Shape44P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape44M72OK,q12Shape44P2OK⟩

theorem q12Shape44_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 44) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 44) b) (adj 12 (forms 44) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,3⟩) adj_mono b H q12Shape44M92 q12Shape44M92OK

#print axioms q12Shape44_cover

end Graffiti384b.EffectiveSearch.Q12
