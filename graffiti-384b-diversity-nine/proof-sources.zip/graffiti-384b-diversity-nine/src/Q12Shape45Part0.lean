import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape45T7 : Tree 12 := (.split 37 (.split 38 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.cover {0,2,3,4,5,8,11})) (.split 43 (.tip (.cover {0,2,3,4,5,8,10})) (.tip (.cover {0,1,6,7,8,10,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape45T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 136365211648 q12Shape45T7=true := by decide

private def q12Shape45T8 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape45T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 68719476736 67645734912 q12Shape45T8=true := by decide

private def q12Shape45T6 : Tree 12 := .split 36 q12Shape45T7 q12Shape45T8
private theorem q12Shape45T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 67645734912 q12Shape45T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 (67645734912 ||| 2^36) q12Shape45T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) (0 ||| 2^36) 67645734912 q12Shape45T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape45T7OK,q12Shape45T8OK⟩

private def q12Shape45T9 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape45T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 17179869184 50465865728 q12Shape45T9=true := by decide

private def q12Shape45T5 : Tree 12 := .split 34 q12Shape45T6 q12Shape45T9
private theorem q12Shape45T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 50465865728 q12Shape45T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 (50465865728 ||| 2^34) q12Shape45T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) (0 ||| 2^34) 50465865728 q12Shape45T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape45T6OK,q12Shape45T9OK⟩

private def q12Shape45T10 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape45T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 8589934592 41875931136 q12Shape45T10=true := by decide

private def q12Shape45T4 : Tree 12 := .split 33 q12Shape45T5 q12Shape45T10
private theorem q12Shape45T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 41875931136 q12Shape45T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 (41875931136 ||| 2^33) q12Shape45T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) (0 ||| 2^33) 41875931136 q12Shape45T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape45T5OK,q12Shape45T10OK⟩

private def q12Shape45T11 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape45T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 4294967296 37580963840 q12Shape45T11=true := by decide

private def q12Shape45T3 : Tree 12 := .split 32 q12Shape45T4 q12Shape45T11
private theorem q12Shape45T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 37580963840 q12Shape45T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 (37580963840 ||| 2^32) q12Shape45T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) (0 ||| 2^32) 37580963840 q12Shape45T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape45T4OK,q12Shape45T11OK⟩

private def q12Shape45T12 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape45T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 34359738368 3221225472 q12Shape45T12=true := by decide

private def q12Shape45T2 : Tree 12 := .split 35 q12Shape45T3 q12Shape45T12
private theorem q12Shape45T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 3221225472 q12Shape45T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 (3221225472 ||| 2^35) q12Shape45T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) (0 ||| 2^35) 3221225472 q12Shape45T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape45T3OK,q12Shape45T12OK⟩

private def q12Shape45T13 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape45T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 2147483648 1073741824 q12Shape45T13=true := by decide

private def q12Shape45T1 : Tree 12 := .split 31 q12Shape45T2 q12Shape45T13
private theorem q12Shape45T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 1073741824 q12Shape45T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 (1073741824 ||| 2^31) q12Shape45T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) (0 ||| 2^31) 1073741824 q12Shape45T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape45T2OK,q12Shape45T13OK⟩

private def q12Shape45T14 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape45T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 1073741824 0 q12Shape45T14=true := by decide

private def q12Shape45T0 : Tree 12 := .split 30 q12Shape45T1 q12Shape45T14
private theorem q12Shape45T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 0 q12Shape45T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 (0 ||| 2^30) q12Shape45T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) (0 ||| 2^30) 0 q12Shape45T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape45T1OK,q12Shape45T14OK⟩

def q12Shape45P0 : Tree 12 := q12Shape45T0
theorem q12Shape45P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,6,4⟩) 0 0 q12Shape45P0=true := q12Shape45T0OK

end Graffiti384b.EffectiveSearch.Q12
