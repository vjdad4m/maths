import Q12Shape46Part0
import Q12Shape46Part1
import Q12Shape46Part2
import Q12Shape46Part3
import Q12Shape46Part4
import Q12Shape46Part5
import Q12Shape46Part6
import Q12Shape46Part7
import Q12Shape46Part8
import Q12Shape46Part9
import Q12Shape46Part10

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape46M128 : Tree 12 := .split 25 q12Shape46P0 q12Shape46P1
private theorem q12Shape46M128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 17694720 q12Shape46M128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 (17694720 ||| 2^25) q12Shape46P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (0 ||| 2^25) 17694720 q12Shape46P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46P0OK,q12Shape46P1OK⟩
private def q12Shape46M209 : Tree 12 := .split 25 q12Shape46P2 q12Shape46P3
private theorem q12Shape46M209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 917504 q12Shape46M209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 (917504 ||| 2^25) q12Shape46P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16777216 ||| 2^25) 917504 q12Shape46P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46P2OK,q12Shape46P3OK⟩
private def q12Shape46M210 : Tree 12 := .split 24 q12Shape46M128 q12Shape46M209
private theorem q12Shape46M210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 917504 q12Shape46M210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 (917504 ||| 2^24) q12Shape46M128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (0 ||| 2^24) 917504 q12Shape46M209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M128OK,q12Shape46M209OK⟩
private def q12Shape46M273 : Tree 12 := .split 25 q12Shape46P4 q12Shape46P5
private theorem q12Shape46M273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 524288 17170432 q12Shape46M273=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 524288 (17170432 ||| 2^25) q12Shape46P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (524288 ||| 2^25) 17170432 q12Shape46P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46P4OK,q12Shape46P5OK⟩
private def q12Shape46M279 : Tree 12 := .split 24 q12Shape46M273 q12Shape46P6
private theorem q12Shape46M279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 524288 393216 q12Shape46M279=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 524288 (393216 ||| 2^24) q12Shape46M273 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (524288 ||| 2^24) 393216 q12Shape46P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M273OK,q12Shape46P6OK⟩
private def q12Shape46M280 : Tree 12 := .split 19 q12Shape46M210 q12Shape46M279
private theorem q12Shape46M280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 393216 q12Shape46M280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 (393216 ||| 2^19) q12Shape46M210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (0 ||| 2^19) 393216 q12Shape46M279)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M210OK,q12Shape46M279OK⟩
private def q12Shape46M345 : Tree 12 := .split 25 q12Shape46P7 q12Shape46P8
private theorem q12Shape46M345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 17432576 q12Shape46M345=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (17432576 ||| 2^25) q12Shape46P7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^25) 17432576 q12Shape46P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46P7OK,q12Shape46P8OK⟩
private def q12Shape46M349 : Tree 12 := .split 24 q12Shape46M345 q12Shape46P9
private theorem q12Shape46M349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 655360 q12Shape46M349=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (655360 ||| 2^24) q12Shape46M345 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^24) 655360 q12Shape46P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M345OK,q12Shape46P9OK⟩
private def q12Shape46M359 : Tree 12 := .split 19 q12Shape46M349 q12Shape46P10
private theorem q12Shape46M359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 131072 q12Shape46M359=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (131072 ||| 2^19) q12Shape46M349 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^19) 131072 q12Shape46P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M349OK,q12Shape46P10OK⟩
private def q12Shape46M360 : Tree 12 := .split 18 q12Shape46M280 q12Shape46M359
private theorem q12Shape46M360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 131072 q12Shape46M360=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 (131072 ||| 2^18) q12Shape46M280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (0 ||| 2^18) 131072 q12Shape46M359)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M280OK,q12Shape46M359OK⟩
private def q12Shape46M467 : Tree 12 := .split 39 q12Shape46P11 q12Shape46P12
private theorem q12Shape46M467OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 1124859904 q12Shape46M467=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 (1124859904 ||| 2^39) q12Shape46P11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (131072 ||| 2^39) 1124859904 q12Shape46P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46P11OK,q12Shape46P12OK⟩
private def q12Shape46M469 : Tree 12 := .split 30 q12Shape46M467 q12Shape46P13
private theorem q12Shape46M469OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 51118080 q12Shape46M469=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 (51118080 ||| 2^30) q12Shape46M467 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (131072 ||| 2^30) 51118080 q12Shape46P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M467OK,q12Shape46P13OK⟩
private def q12Shape46M473 : Tree 12 := .split 25 q12Shape46M469 q12Shape46P14
private theorem q12Shape46M473OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 17563648 q12Shape46M473=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 (17563648 ||| 2^25) q12Shape46M469 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (131072 ||| 2^25) 17563648 q12Shape46P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M469OK,q12Shape46P14OK⟩
private def q12Shape46M479 : Tree 12 := .split 24 q12Shape46M473 q12Shape46P15
private theorem q12Shape46M479OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 786432 q12Shape46M479=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 (786432 ||| 2^24) q12Shape46M473 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (131072 ||| 2^24) 786432 q12Shape46P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M473OK,q12Shape46P15OK⟩
private def q12Shape46M491 : Tree 12 := .split 19 q12Shape46M479 q12Shape46P16
private theorem q12Shape46M491OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 262144 q12Shape46M491=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 (262144 ||| 2^19) q12Shape46M479 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (131072 ||| 2^19) 262144 q12Shape46P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M479OK,q12Shape46P16OK⟩
private def q12Shape46M505 : Tree 12 := .split 18 q12Shape46M491 q12Shape46P17
private theorem q12Shape46M505OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 0 q12Shape46M505=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 131072 (0 ||| 2^18) q12Shape46M491 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (131072 ||| 2^18) 0 q12Shape46P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M491OK,q12Shape46P17OK⟩
private def q12Shape46M506 : Tree 12 := .split 17 q12Shape46M360 q12Shape46M505
private theorem q12Shape46M506OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 0 q12Shape46M506=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 (0 ||| 2^17) q12Shape46M360 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (0 ||| 2^17) 0 q12Shape46M505)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46M360OK,q12Shape46M505OK⟩

theorem q12Shape46_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 46) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 46) b) (adj 12 (forms 46) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) adj_mono b H q12Shape46M506 q12Shape46M506OK

#print axioms q12Shape46_cover

end Graffiti384b.EffectiveSearch.Q12
