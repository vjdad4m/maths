import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape46T1 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape46T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 1124990976 q12Shape46T1=true := by decide

private def q12Shape46T8 : Tree 12 := (.tip (.cover {1,2,3,4,5,6,7}))
private theorem q12Shape46T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 34634667524096 q12Shape46T8=true := by decide

private def q12Shape46T9 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape46T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17593259786240 17042481479680 q12Shape46T9=true := by decide

private def q12Shape46T7 : Tree 12 := .split 44 q12Shape46T8 q12Shape46T9
private theorem q12Shape46T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 17042481479680 q12Shape46T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 (17042481479680 ||| 2^44) q12Shape46T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1073741824 ||| 2^44) 17042481479680 q12Shape46T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T8OK,q12Shape46T9OK⟩

private def q12Shape46T11 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape46T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8797166764032 25838574501888 q12Shape46T11=true := by decide

private def q12Shape46T12 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape46T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 26389352808448 8246388457472 q12Shape46T12=true := by decide

private def q12Shape46T10 : Tree 12 := .split 44 q12Shape46T11 q12Shape46T12
private theorem q12Shape46T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8797166764032 8246388457472 q12Shape46T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8797166764032 (8246388457472 ||| 2^44) q12Shape46T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (8797166764032 ||| 2^44) 8246388457472 q12Shape46T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T11OK,q12Shape46T12OK⟩

private def q12Shape46T6 : Tree 12 := .split 43 q12Shape46T7 q12Shape46T10
private theorem q12Shape46T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 8246388457472 q12Shape46T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 (8246388457472 ||| 2^43) q12Shape46T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1073741824 ||| 2^43) 8246388457472 q12Shape46T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T7OK,q12Shape46T10OK⟩

private def q12Shape46T16 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,9,11})))
private theorem q12Shape46T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399120252928 30236622061568 q12Shape46T16=true := by decide

private def q12Shape46T17 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape46T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399121301504 30236621012992 q12Shape46T17=true := by decide

private def q12Shape46T15 : Tree 12 := .split 20 q12Shape46T16 q12Shape46T17
private theorem q12Shape46T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399120252928 30236621012992 q12Shape46T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399120252928 (30236621012992 ||| 2^20) q12Shape46T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4399120252928 ||| 2^20) 30236621012992 q12Shape46T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T16OK,q12Shape46T17OK⟩

private def q12Shape46T18 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape46T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 21991306297344 12644434968576 q12Shape46T18=true := by decide

private def q12Shape46T14 : Tree 12 := .split 44 q12Shape46T15 q12Shape46T18
private theorem q12Shape46T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399120252928 12644434968576 q12Shape46T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399120252928 (12644434968576 ||| 2^44) q12Shape46T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4399120252928 ||| 2^44) 12644434968576 q12Shape46T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T15OK,q12Shape46T18OK⟩

private def q12Shape46T19 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape46T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 13195213275136 3848341946368 q12Shape46T19=true := by decide

private def q12Shape46T13 : Tree 12 := .split 43 q12Shape46T14 q12Shape46T19
private theorem q12Shape46T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399120252928 3848341946368 q12Shape46T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4399120252928 (3848341946368 ||| 2^43) q12Shape46T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4399120252928 ||| 2^43) 3848341946368 q12Shape46T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T14OK,q12Shape46T19OK⟩

private def q12Shape46T5 : Tree 12 := .split 42 q12Shape46T6 q12Shape46T13
private theorem q12Shape46T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 3848341946368 q12Shape46T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 (3848341946368 ||| 2^42) q12Shape46T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1073741824 ||| 2^42) 3848341946368 q12Shape46T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T6OK,q12Shape46T13OK⟩

private def q12Shape46T23 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9,10})))
private theorem q12Shape46T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2200096997376 32435644268544 q12Shape46T23=true := by decide

private def q12Shape46T24 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape46T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 19792283041792 14843458224128 q12Shape46T24=true := by decide

private def q12Shape46T22 : Tree 12 := .split 44 q12Shape46T23 q12Shape46T24
private theorem q12Shape46T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2200096997376 14843458224128 q12Shape46T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2200096997376 (14843458224128 ||| 2^44) q12Shape46T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2200096997376 ||| 2^44) 14843458224128 q12Shape46T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T23OK,q12Shape46T24OK⟩

private def q12Shape46T25 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape46T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 10996190019584 6047365201920 q12Shape46T25=true := by decide

private def q12Shape46T21 : Tree 12 := .split 43 q12Shape46T22 q12Shape46T25
private theorem q12Shape46T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2200096997376 6047365201920 q12Shape46T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2200096997376 (6047365201920 ||| 2^43) q12Shape46T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2200096997376 ||| 2^43) 6047365201920 q12Shape46T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T22OK,q12Shape46T25OK⟩

private def q12Shape46T26 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape46T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 6598143508480 1649318690816 q12Shape46T26=true := by decide

private def q12Shape46T20 : Tree 12 := .split 42 q12Shape46T21 q12Shape46T26
private theorem q12Shape46T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2200096997376 1649318690816 q12Shape46T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2200096997376 (1649318690816 ||| 2^42) q12Shape46T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2200096997376 ||| 2^42) 1649318690816 q12Shape46T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T21OK,q12Shape46T26OK⟩

private def q12Shape46T4 : Tree 12 := .split 41 q12Shape46T5 q12Shape46T20
private theorem q12Shape46T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 1649318690816 q12Shape46T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 (1649318690816 ||| 2^41) q12Shape46T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1073741824 ||| 2^41) 1649318690816 q12Shape46T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T5OK,q12Shape46T20OK⟩

private def q12Shape46T32 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape46T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 33535156944896 q12Shape46T32=true := by decide

private def q12Shape46T33 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape46T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100586418176 33535155896320 q12Shape46T33=true := by decide

private def q12Shape46T31 : Tree 12 := .split 20 q12Shape46T32 q12Shape46T33
private theorem q12Shape46T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 33535155896320 q12Shape46T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 (33535155896320 ||| 2^20) q12Shape46T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1100585369600 ||| 2^20) 33535155896320 q12Shape46T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T32OK,q12Shape46T33OK⟩

private def q12Shape46T34 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape46T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 18692771414016 15942969851904 q12Shape46T34=true := by decide

private def q12Shape46T30 : Tree 12 := .split 44 q12Shape46T31 q12Shape46T34
private theorem q12Shape46T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 15942969851904 q12Shape46T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 (15942969851904 ||| 2^44) q12Shape46T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1100585369600 ||| 2^44) 15942969851904 q12Shape46T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T31OK,q12Shape46T34OK⟩

private def q12Shape46T35 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape46T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 9896678391808 7146876829696 q12Shape46T35=true := by decide

private def q12Shape46T29 : Tree 12 := .split 43 q12Shape46T30 q12Shape46T35
private theorem q12Shape46T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 7146876829696 q12Shape46T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 (7146876829696 ||| 2^43) q12Shape46T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1100585369600 ||| 2^43) 7146876829696 q12Shape46T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T30OK,q12Shape46T35OK⟩

private def q12Shape46T36 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape46T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 5498631880704 2748830318592 q12Shape46T36=true := by decide

private def q12Shape46T28 : Tree 12 := .split 42 q12Shape46T29 q12Shape46T36
private theorem q12Shape46T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 2748830318592 q12Shape46T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 (2748830318592 ||| 2^42) q12Shape46T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1100585369600 ||| 2^42) 2748830318592 q12Shape46T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T29OK,q12Shape46T36OK⟩

private def q12Shape46T37 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape46T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 3299608625152 549807063040 q12Shape46T37=true := by decide

private def q12Shape46T27 : Tree 12 := .split 41 q12Shape46T28 q12Shape46T37
private theorem q12Shape46T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 549807063040 q12Shape46T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1100585369600 (549807063040 ||| 2^41) q12Shape46T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1100585369600 ||| 2^41) 549807063040 q12Shape46T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T28OK,q12Shape46T37OK⟩

private def q12Shape46T3 : Tree 12 := .split 40 q12Shape46T4 q12Shape46T27
private theorem q12Shape46T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 549807063040 q12Shape46T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 (549807063040 ||| 2^40) q12Shape46T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1073741824 ||| 2^40) 549807063040 q12Shape46T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T4OK,q12Shape46T27OK⟩

private def q12Shape46T44 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape46T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 34084912758784 q12Shape46T44=true := by decide

private def q12Shape46T45 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape46T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550830604288 34084911710208 q12Shape46T45=true := by decide

private def q12Shape46T43 : Tree 12 := .split 20 q12Shape46T44 q12Shape46T45
private theorem q12Shape46T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 34084911710208 q12Shape46T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 (34084911710208 ||| 2^20) q12Shape46T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (550829555712 ||| 2^20) 34084911710208 q12Shape46T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T44OK,q12Shape46T45OK⟩

private def q12Shape46T46 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape46T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 18143015600128 16492725665792 q12Shape46T46=true := by decide

private def q12Shape46T42 : Tree 12 := .split 44 q12Shape46T43 q12Shape46T46
private theorem q12Shape46T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 16492725665792 q12Shape46T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 (16492725665792 ||| 2^44) q12Shape46T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (550829555712 ||| 2^44) 16492725665792 q12Shape46T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T43OK,q12Shape46T46OK⟩

private def q12Shape46T47 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape46T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 9346922577920 7696632643584 q12Shape46T47=true := by decide

private def q12Shape46T41 : Tree 12 := .split 43 q12Shape46T42 q12Shape46T47
private theorem q12Shape46T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 7696632643584 q12Shape46T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 (7696632643584 ||| 2^43) q12Shape46T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (550829555712 ||| 2^43) 7696632643584 q12Shape46T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T42OK,q12Shape46T47OK⟩

private def q12Shape46T48 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape46T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4948876066816 3298586132480 q12Shape46T48=true := by decide

private def q12Shape46T40 : Tree 12 := .split 42 q12Shape46T41 q12Shape46T48
private theorem q12Shape46T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 3298586132480 q12Shape46T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 (3298586132480 ||| 2^42) q12Shape46T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (550829555712 ||| 2^42) 3298586132480 q12Shape46T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T41OK,q12Shape46T48OK⟩

private def q12Shape46T49 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape46T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2749852811264 1099562876928 q12Shape46T49=true := by decide

private def q12Shape46T39 : Tree 12 := .split 41 q12Shape46T40 q12Shape46T49
private theorem q12Shape46T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 1099562876928 q12Shape46T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 (1099562876928 ||| 2^41) q12Shape46T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (550829555712 ||| 2^41) 1099562876928 q12Shape46T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T40OK,q12Shape46T49OK⟩

private def q12Shape46T50 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape46T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1650341183488 51249152 q12Shape46T50=true := by decide

private def q12Shape46T38 : Tree 12 := .split 40 q12Shape46T39 q12Shape46T50
private theorem q12Shape46T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 51249152 q12Shape46T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 550829555712 (51249152 ||| 2^40) q12Shape46T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (550829555712 ||| 2^40) 51249152 q12Shape46T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T39OK,q12Shape46T50OK⟩

private def q12Shape46T2 : Tree 12 := .split 39 q12Shape46T3 q12Shape46T38
private theorem q12Shape46T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 51249152 q12Shape46T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073741824 (51249152 ||| 2^39) q12Shape46T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1073741824 ||| 2^39) 51249152 q12Shape46T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T3OK,q12Shape46T38OK⟩

private def q12Shape46T0 : Tree 12 := .split 30 q12Shape46T1 q12Shape46T2
private theorem q12Shape46T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 51249152 q12Shape46T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 (51249152 ||| 2^30) q12Shape46T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (0 ||| 2^30) 51249152 q12Shape46T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T1OK,q12Shape46T2OK⟩

def q12Shape46P0 : Tree 12 := q12Shape46T0
theorem q12Shape46P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 0 51249152 q12Shape46P0=true := q12Shape46T0OK

end Graffiti384b.EffectiveSearch.Q12
