import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape46T135 : Tree 12 := (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.tip (.cover {0,1,2,3,6,7,10})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,9,10}))))
private theorem q12Shape46T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 17043538444288 q12Shape46T135=true := by decide

private def q12Shape46T138 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 28 (.tip (.cover {1,2,3,4,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9})))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,9,10})))
private theorem q12Shape46T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796109799424 25839632515072 q12Shape46T138=true := by decide

private def q12Shape46T139 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape46T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796110848000 25839631466496 q12Shape46T139=true := by decide

private def q12Shape46T137 : Tree 12 := .split 20 q12Shape46T138 q12Shape46T139
private theorem q12Shape46T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796109799424 25839631466496 q12Shape46T137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796109799424 (25839631466496 ||| 2^20) q12Shape46T138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (8796109799424 ||| 2^20) 25839631466496 q12Shape46T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T138OK,q12Shape46T139OK⟩

private def q12Shape46T140 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape46T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 26388295843840 8247445422080 q12Shape46T140=true := by decide

private def q12Shape46T136 : Tree 12 := .split 44 q12Shape46T137 q12Shape46T140
private theorem q12Shape46T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796109799424 8247445422080 q12Shape46T136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796109799424 (8247445422080 ||| 2^44) q12Shape46T137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (8796109799424 ||| 2^44) 8247445422080 q12Shape46T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T137OK,q12Shape46T140OK⟩

private def q12Shape46T134 : Tree 12 := .split 43 q12Shape46T135 q12Shape46T136
private theorem q12Shape46T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 8247445422080 q12Shape46T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 (8247445422080 ||| 2^43) q12Shape46T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16777216 ||| 2^43) 8247445422080 q12Shape46T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T135OK,q12Shape46T136OK⟩

private def q12Shape46T147 : Tree 12 := (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 29 (.tip (.cover {1,2,3,4,6,7,10})) (.tip (.cover {0,1,4,5,7,8,9})))) (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,11})))) (.tip (.cover {0,1,4,5,7,9,11})))
private theorem q12Shape46T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 30237693706240 q12Shape46T147=true := by decide

private def q12Shape46T148 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398071676928 30237685317632 q12Shape46T148=true := by decide

private def q12Shape46T146 : Tree 12 := .split 23 q12Shape46T147 q12Shape46T148
private theorem q12Shape46T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 30237685317632 q12Shape46T146=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 (30237685317632 ||| 2^23) q12Shape46T147 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398063288320 ||| 2^23) 30237685317632 q12Shape46T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T147OK,q12Shape46T148OK⟩

private def q12Shape46T149 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape46T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398067482624 30237681123328 q12Shape46T149=true := by decide

private def q12Shape46T145 : Tree 12 := .split 22 q12Shape46T146 q12Shape46T149
private theorem q12Shape46T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 30237681123328 q12Shape46T145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 (30237681123328 ||| 2^22) q12Shape46T146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398063288320 ||| 2^22) 30237681123328 q12Shape46T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T146OK,q12Shape46T149OK⟩

private def q12Shape46T150 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape46T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398065385472 30237679026176 q12Shape46T150=true := by decide

private def q12Shape46T144 : Tree 12 := .split 21 q12Shape46T145 q12Shape46T150
private theorem q12Shape46T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 30237679026176 q12Shape46T144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 (30237679026176 ||| 2^21) q12Shape46T145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398063288320 ||| 2^21) 30237679026176 q12Shape46T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T145OK,q12Shape46T150OK⟩

private def q12Shape46T151 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape46T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398064336896 30237677977600 q12Shape46T151=true := by decide

private def q12Shape46T143 : Tree 12 := .split 20 q12Shape46T144 q12Shape46T151
private theorem q12Shape46T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 30237677977600 q12Shape46T143=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 (30237677977600 ||| 2^20) q12Shape46T144 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398063288320 ||| 2^20) 30237677977600 q12Shape46T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T144OK,q12Shape46T151OK⟩

private def q12Shape46T152 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 21990249332736 12645491933184 q12Shape46T152=true := by decide

private def q12Shape46T142 : Tree 12 := .split 44 q12Shape46T143 q12Shape46T152
private theorem q12Shape46T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 12645491933184 q12Shape46T142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 (12645491933184 ||| 2^44) q12Shape46T143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398063288320 ||| 2^44) 12645491933184 q12Shape46T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T143OK,q12Shape46T152OK⟩

private def q12Shape46T153 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 13194156310528 3849398910976 q12Shape46T153=true := by decide

private def q12Shape46T141 : Tree 12 := .split 43 q12Shape46T142 q12Shape46T153
private theorem q12Shape46T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 3849398910976 q12Shape46T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398063288320 (3849398910976 ||| 2^43) q12Shape46T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398063288320 ||| 2^43) 3849398910976 q12Shape46T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T142OK,q12Shape46T153OK⟩

private def q12Shape46T133 : Tree 12 := .split 42 q12Shape46T134 q12Shape46T141
private theorem q12Shape46T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 3849398910976 q12Shape46T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 (3849398910976 ||| 2^42) q12Shape46T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16777216 ||| 2^42) 3849398910976 q12Shape46T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T134OK,q12Shape46T141OK⟩

private def q12Shape46T159 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.split 27 (.split 28 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,9})))
private theorem q12Shape46T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 32436704378880 q12Shape46T159=true := by decide

private def q12Shape46T160 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199042129920 32436702281728 q12Shape46T160=true := by decide

private def q12Shape46T158 : Tree 12 := .split 21 q12Shape46T159 q12Shape46T160
private theorem q12Shape46T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 32436702281728 q12Shape46T158=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 (32436702281728 ||| 2^21) q12Shape46T159 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199040032768 ||| 2^21) 32436702281728 q12Shape46T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T159OK,q12Shape46T160OK⟩

private def q12Shape46T161 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,10}))
private theorem q12Shape46T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199041081344 32436701233152 q12Shape46T161=true := by decide

private def q12Shape46T157 : Tree 12 := .split 20 q12Shape46T158 q12Shape46T161
private theorem q12Shape46T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 32436701233152 q12Shape46T157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 (32436701233152 ||| 2^20) q12Shape46T158 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199040032768 ||| 2^20) 32436701233152 q12Shape46T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T158OK,q12Shape46T161OK⟩

private def q12Shape46T162 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape46T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 19791226077184 14844515188736 q12Shape46T162=true := by decide

private def q12Shape46T156 : Tree 12 := .split 44 q12Shape46T157 q12Shape46T162
private theorem q12Shape46T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 14844515188736 q12Shape46T156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 (14844515188736 ||| 2^44) q12Shape46T157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199040032768 ||| 2^44) 14844515188736 q12Shape46T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T157OK,q12Shape46T162OK⟩

private def q12Shape46T163 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape46T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 10995133054976 6048422166528 q12Shape46T163=true := by decide

private def q12Shape46T155 : Tree 12 := .split 43 q12Shape46T156 q12Shape46T163
private theorem q12Shape46T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 6048422166528 q12Shape46T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 (6048422166528 ||| 2^43) q12Shape46T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199040032768 ||| 2^43) 6048422166528 q12Shape46T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T156OK,q12Shape46T163OK⟩

private def q12Shape46T164 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 6597086543872 1650375655424 q12Shape46T164=true := by decide

private def q12Shape46T154 : Tree 12 := .split 42 q12Shape46T155 q12Shape46T164
private theorem q12Shape46T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 1650375655424 q12Shape46T154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199040032768 (1650375655424 ||| 2^42) q12Shape46T155 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199040032768 ||| 2^42) 1650375655424 q12Shape46T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T155OK,q12Shape46T164OK⟩

private def q12Shape46T132 : Tree 12 := .split 41 q12Shape46T133 q12Shape46T154
private theorem q12Shape46T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 1650375655424 q12Shape46T132=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 (1650375655424 ||| 2^41) q12Shape46T133 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16777216 ||| 2^41) 1650375655424 q12Shape46T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T133OK,q12Shape46T154OK⟩

private def q12Shape46T174 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 29 (.tip (.cover {1,2,3,4,6,7,10})) (.tip (.cover {0,1,4,5,7,8,9})))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape46T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 33536295698432 q12Shape46T174=true := by decide

private def q12Shape46T175 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape46T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099595513856 33536228589568 q12Shape46T175=true := by decide

private def q12Shape46T173 : Tree 12 := .split 26 q12Shape46T174 q12Shape46T175
private theorem q12Shape46T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 33536228589568 q12Shape46T173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (33536228589568 ||| 2^26) q12Shape46T174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^26) 33536228589568 q12Shape46T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T174OK,q12Shape46T175OK⟩

private def q12Shape46T176 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099536793600 33536220200960 q12Shape46T176=true := by decide

private def q12Shape46T172 : Tree 12 := .split 23 q12Shape46T173 q12Shape46T176
private theorem q12Shape46T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 33536220200960 q12Shape46T172=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (33536220200960 ||| 2^23) q12Shape46T173 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^23) 33536220200960 q12Shape46T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T173OK,q12Shape46T176OK⟩

private def q12Shape46T177 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape46T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099532599296 33536216006656 q12Shape46T177=true := by decide

private def q12Shape46T171 : Tree 12 := .split 22 q12Shape46T172 q12Shape46T177
private theorem q12Shape46T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 33536216006656 q12Shape46T171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (33536216006656 ||| 2^22) q12Shape46T172 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^22) 33536216006656 q12Shape46T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T172OK,q12Shape46T177OK⟩

private def q12Shape46T178 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape46T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099530502144 33536213909504 q12Shape46T178=true := by decide

private def q12Shape46T170 : Tree 12 := .split 21 q12Shape46T171 q12Shape46T178
private theorem q12Shape46T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 33536213909504 q12Shape46T170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (33536213909504 ||| 2^21) q12Shape46T171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^21) 33536213909504 q12Shape46T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T171OK,q12Shape46T178OK⟩

private def q12Shape46T179 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape46T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099529453568 33536212860928 q12Shape46T179=true := by decide

private def q12Shape46T169 : Tree 12 := .split 20 q12Shape46T170 q12Shape46T179
private theorem q12Shape46T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 33536212860928 q12Shape46T169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (33536212860928 ||| 2^20) q12Shape46T170 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^20) 33536212860928 q12Shape46T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T170OK,q12Shape46T179OK⟩

private def q12Shape46T180 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape46T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 18691714449408 15944026816512 q12Shape46T180=true := by decide

private def q12Shape46T168 : Tree 12 := .split 44 q12Shape46T169 q12Shape46T180
private theorem q12Shape46T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 15944026816512 q12Shape46T168=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (15944026816512 ||| 2^44) q12Shape46T169 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^44) 15944026816512 q12Shape46T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T169OK,q12Shape46T180OK⟩

private def q12Shape46T181 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 9895621427200 7147933794304 q12Shape46T181=true := by decide

private def q12Shape46T167 : Tree 12 := .split 43 q12Shape46T168 q12Shape46T181
private theorem q12Shape46T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 7147933794304 q12Shape46T167=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (7147933794304 ||| 2^43) q12Shape46T168 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^43) 7147933794304 q12Shape46T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T168OK,q12Shape46T181OK⟩

private def q12Shape46T182 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape46T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 5497574916096 2749887283200 q12Shape46T182=true := by decide

private def q12Shape46T166 : Tree 12 := .split 42 q12Shape46T167 q12Shape46T182
private theorem q12Shape46T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 2749887283200 q12Shape46T166=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (2749887283200 ||| 2^42) q12Shape46T167 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^42) 2749887283200 q12Shape46T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T167OK,q12Shape46T182OK⟩

private def q12Shape46T183 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 3298551660544 550864027648 q12Shape46T183=true := by decide

private def q12Shape46T165 : Tree 12 := .split 41 q12Shape46T166 q12Shape46T183
private theorem q12Shape46T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 550864027648 q12Shape46T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099528404992 (550864027648 ||| 2^41) q12Shape46T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099528404992 ||| 2^41) 550864027648 q12Shape46T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T166OK,q12Shape46T183OK⟩

private def q12Shape46T131 : Tree 12 := .split 40 q12Shape46T132 q12Shape46T165
private theorem q12Shape46T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 550864027648 q12Shape46T131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 (550864027648 ||| 2^40) q12Shape46T132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16777216 ||| 2^40) 550864027648 q12Shape46T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T132OK,q12Shape46T165OK⟩

private def q12Shape46T194 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,9})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11}))))
private theorem q12Shape46T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 34086051512320 q12Shape46T194=true := by decide

private def q12Shape46T195 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape46T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549839699968 34085984403456 q12Shape46T195=true := by decide

private def q12Shape46T193 : Tree 12 := .split 26 q12Shape46T194 q12Shape46T195
private theorem q12Shape46T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 34085984403456 q12Shape46T193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (34085984403456 ||| 2^26) q12Shape46T194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^26) 34085984403456 q12Shape46T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T194OK,q12Shape46T195OK⟩

private def q12Shape46T196 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549780979712 34085976014848 q12Shape46T196=true := by decide

private def q12Shape46T192 : Tree 12 := .split 23 q12Shape46T193 q12Shape46T196
private theorem q12Shape46T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 34085976014848 q12Shape46T192=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (34085976014848 ||| 2^23) q12Shape46T193 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^23) 34085976014848 q12Shape46T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T193OK,q12Shape46T196OK⟩

private def q12Shape46T197 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape46T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549776785408 34085971820544 q12Shape46T197=true := by decide

private def q12Shape46T191 : Tree 12 := .split 22 q12Shape46T192 q12Shape46T197
private theorem q12Shape46T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 34085971820544 q12Shape46T191=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (34085971820544 ||| 2^22) q12Shape46T192 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^22) 34085971820544 q12Shape46T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T192OK,q12Shape46T197OK⟩

private def q12Shape46T198 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape46T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549774688256 34085969723392 q12Shape46T198=true := by decide

private def q12Shape46T190 : Tree 12 := .split 21 q12Shape46T191 q12Shape46T198
private theorem q12Shape46T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 34085969723392 q12Shape46T190=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (34085969723392 ||| 2^21) q12Shape46T191 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^21) 34085969723392 q12Shape46T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T191OK,q12Shape46T198OK⟩

private def q12Shape46T199 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape46T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549773639680 34085968674816 q12Shape46T199=true := by decide

private def q12Shape46T189 : Tree 12 := .split 20 q12Shape46T190 q12Shape46T199
private theorem q12Shape46T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 34085968674816 q12Shape46T189=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (34085968674816 ||| 2^20) q12Shape46T190 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^20) 34085968674816 q12Shape46T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T190OK,q12Shape46T199OK⟩

private def q12Shape46T200 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 18141958635520 16493782630400 q12Shape46T200=true := by decide

private def q12Shape46T188 : Tree 12 := .split 44 q12Shape46T189 q12Shape46T200
private theorem q12Shape46T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 16493782630400 q12Shape46T188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (16493782630400 ||| 2^44) q12Shape46T189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^44) 16493782630400 q12Shape46T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T189OK,q12Shape46T200OK⟩

private def q12Shape46T201 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape46T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 9345865613312 7697689608192 q12Shape46T201=true := by decide

private def q12Shape46T187 : Tree 12 := .split 43 q12Shape46T188 q12Shape46T201
private theorem q12Shape46T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 7697689608192 q12Shape46T187=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (7697689608192 ||| 2^43) q12Shape46T188 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^43) 7697689608192 q12Shape46T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T188OK,q12Shape46T201OK⟩

private def q12Shape46T202 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape46T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4947819102208 3299643097088 q12Shape46T202=true := by decide

private def q12Shape46T186 : Tree 12 := .split 42 q12Shape46T187 q12Shape46T202
private theorem q12Shape46T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 3299643097088 q12Shape46T186=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (3299643097088 ||| 2^42) q12Shape46T187 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^42) 3299643097088 q12Shape46T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T187OK,q12Shape46T202OK⟩

private def q12Shape46T203 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2748795846656 1100619841536 q12Shape46T203=true := by decide

private def q12Shape46T185 : Tree 12 := .split 41 q12Shape46T186 q12Shape46T203
private theorem q12Shape46T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 1100619841536 q12Shape46T185=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (1100619841536 ||| 2^41) q12Shape46T186 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^41) 1100619841536 q12Shape46T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T186OK,q12Shape46T203OK⟩

private def q12Shape46T204 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape46T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1649284218880 1108213760 q12Shape46T204=true := by decide

private def q12Shape46T184 : Tree 12 := .split 40 q12Shape46T185 q12Shape46T204
private theorem q12Shape46T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 1108213760 q12Shape46T184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549772591104 (1108213760 ||| 2^40) q12Shape46T185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549772591104 ||| 2^40) 1108213760 q12Shape46T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T185OK,q12Shape46T204OK⟩

private def q12Shape46T130 : Tree 12 := .split 39 q12Shape46T131 q12Shape46T184
private theorem q12Shape46T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 1108213760 q12Shape46T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 (1108213760 ||| 2^39) q12Shape46T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16777216 ||| 2^39) 1108213760 q12Shape46T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T131OK,q12Shape46T184OK⟩

private def q12Shape46T205 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape46T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1090519040 34471936 q12Shape46T205=true := by decide

private def q12Shape46T129 : Tree 12 := .split 30 q12Shape46T130 q12Shape46T205
private theorem q12Shape46T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 34471936 q12Shape46T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 (34471936 ||| 2^30) q12Shape46T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16777216 ||| 2^30) 34471936 q12Shape46T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T130OK,q12Shape46T205OK⟩

def q12Shape46P2 : Tree 12 := q12Shape46T129
theorem q12Shape46P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16777216 34471936 q12Shape46P2=true := q12Shape46T129OK

end Graffiti384b.EffectiveSearch.Q12
