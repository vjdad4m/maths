import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape46T207 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape46T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 50331648 1074659328 q12Shape46T207=true := by decide

private def q12Shape46T208 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape46T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1124073472 917504 q12Shape46T208=true := by decide

private def q12Shape46T206 : Tree 12 := .split 30 q12Shape46T207 q12Shape46T208
private theorem q12Shape46T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 50331648 917504 q12Shape46T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 50331648 (917504 ||| 2^30) q12Shape46T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (50331648 ||| 2^30) 917504 q12Shape46T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T207OK,q12Shape46T208OK⟩

def q12Shape46P3 : Tree 12 := q12Shape46T206
theorem q12Shape46P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 50331648 917504 q12Shape46P3=true := q12Shape46T206OK

end Graffiti384b.EffectiveSearch.Q12
