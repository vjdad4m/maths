import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape46T288 : Tree 12 := (.tip (.cover {1,2,3,4,5,6,7}))
private theorem q12Shape46T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 34635741003776 q12Shape46T288=true := by decide

private def q12Shape46T289 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {1,2,3,5,6,7,10}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,9,10})))
private theorem q12Shape46T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17592186306560 17043554959360 q12Shape46T289=true := by decide

private def q12Shape46T287 : Tree 12 := .split 44 q12Shape46T288 q12Shape46T289
private theorem q12Shape46T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 17043554959360 q12Shape46T287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (17043554959360 ||| 2^44) q12Shape46T288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^44) 17043554959360 q12Shape46T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T288OK,q12Shape46T289OK⟩

private def q12Shape46T292 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 22 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))))
private theorem q12Shape46T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796093284352 25839649030144 q12Shape46T292=true := by decide

private def q12Shape46T293 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape46T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796094332928 25839647981568 q12Shape46T293=true := by decide

private def q12Shape46T291 : Tree 12 := .split 20 q12Shape46T292 q12Shape46T293
private theorem q12Shape46T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796093284352 25839647981568 q12Shape46T291=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796093284352 (25839647981568 ||| 2^20) q12Shape46T292 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (8796093284352 ||| 2^20) 25839647981568 q12Shape46T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T292OK,q12Shape46T293OK⟩

private def q12Shape46T294 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape46T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 26388279328768 8247461937152 q12Shape46T294=true := by decide

private def q12Shape46T290 : Tree 12 := .split 44 q12Shape46T291 q12Shape46T294
private theorem q12Shape46T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796093284352 8247461937152 q12Shape46T290=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 8796093284352 (8247461937152 ||| 2^44) q12Shape46T291 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (8796093284352 ||| 2^44) 8247461937152 q12Shape46T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T291OK,q12Shape46T294OK⟩

private def q12Shape46T286 : Tree 12 := .split 43 q12Shape46T287 q12Shape46T290
private theorem q12Shape46T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 8247461937152 q12Shape46T286=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (8247461937152 ||| 2^43) q12Shape46T287 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^43) 8247461937152 q12Shape46T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T287OK,q12Shape46T290OK⟩

private def q12Shape46T299 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 23 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,4,5,7,8,9}))))
private theorem q12Shape46T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 30237697638400 q12Shape46T299=true := by decide

private def q12Shape46T300 : Tree 12 := (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape46T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398048870400 30237695541248 q12Shape46T300=true := by decide

private def q12Shape46T298 : Tree 12 := .split 21 q12Shape46T299 q12Shape46T300
private theorem q12Shape46T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 30237695541248 q12Shape46T298=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 (30237695541248 ||| 2^21) q12Shape46T299 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398046773248 ||| 2^21) 30237695541248 q12Shape46T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T299OK,q12Shape46T300OK⟩

private def q12Shape46T301 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape46T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398047821824 30237694492672 q12Shape46T301=true := by decide

private def q12Shape46T297 : Tree 12 := .split 20 q12Shape46T298 q12Shape46T301
private theorem q12Shape46T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 30237694492672 q12Shape46T297=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 (30237694492672 ||| 2^20) q12Shape46T298 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398046773248 ||| 2^20) 30237694492672 q12Shape46T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T298OK,q12Shape46T301OK⟩

private def q12Shape46T302 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 21990232817664 12645508448256 q12Shape46T302=true := by decide

private def q12Shape46T296 : Tree 12 := .split 44 q12Shape46T297 q12Shape46T302
private theorem q12Shape46T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 12645508448256 q12Shape46T296=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 (12645508448256 ||| 2^44) q12Shape46T297 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398046773248 ||| 2^44) 12645508448256 q12Shape46T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T297OK,q12Shape46T302OK⟩

private def q12Shape46T303 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 13194139795456 3849415426048 q12Shape46T303=true := by decide

private def q12Shape46T295 : Tree 12 := .split 43 q12Shape46T296 q12Shape46T303
private theorem q12Shape46T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 3849415426048 q12Shape46T295=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4398046773248 (3849415426048 ||| 2^43) q12Shape46T296 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (4398046773248 ||| 2^43) 3849415426048 q12Shape46T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T296OK,q12Shape46T303OK⟩

private def q12Shape46T285 : Tree 12 := .split 42 q12Shape46T286 q12Shape46T295
private theorem q12Shape46T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 3849415426048 q12Shape46T285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (3849415426048 ||| 2^42) q12Shape46T286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^42) 3849415426048 q12Shape46T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T286OK,q12Shape46T295OK⟩

private def q12Shape46T308 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10})))
private theorem q12Shape46T308OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 32436718796800 q12Shape46T308=true := by decide

private def q12Shape46T309 : Tree 12 := (.split 21 (.split 22 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10})))
private theorem q12Shape46T309OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199024566272 32436717748224 q12Shape46T309=true := by decide

private def q12Shape46T307 : Tree 12 := .split 20 q12Shape46T308 q12Shape46T309
private theorem q12Shape46T307OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 32436717748224 q12Shape46T307=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 (32436717748224 ||| 2^20) q12Shape46T308 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199023517696 ||| 2^20) 32436717748224 q12Shape46T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T308OK,q12Shape46T309OK⟩

private def q12Shape46T310 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape46T310OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 19791209562112 14844531703808 q12Shape46T310=true := by decide

private def q12Shape46T306 : Tree 12 := .split 44 q12Shape46T307 q12Shape46T310
private theorem q12Shape46T306OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 14844531703808 q12Shape46T306=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 (14844531703808 ||| 2^44) q12Shape46T307 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199023517696 ||| 2^44) 14844531703808 q12Shape46T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T307OK,q12Shape46T310OK⟩

private def q12Shape46T311 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape46T311OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 10995116539904 6048438681600 q12Shape46T311=true := by decide

private def q12Shape46T305 : Tree 12 := .split 43 q12Shape46T306 q12Shape46T311
private theorem q12Shape46T305OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 6048438681600 q12Shape46T305=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 (6048438681600 ||| 2^43) q12Shape46T306 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199023517696 ||| 2^43) 6048438681600 q12Shape46T311)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T306OK,q12Shape46T311OK⟩

private def q12Shape46T312 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T312OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 6597070028800 1650392170496 q12Shape46T312=true := by decide

private def q12Shape46T304 : Tree 12 := .split 42 q12Shape46T305 q12Shape46T312
private theorem q12Shape46T304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 1650392170496 q12Shape46T304=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2199023517696 (1650392170496 ||| 2^42) q12Shape46T305 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (2199023517696 ||| 2^42) 1650392170496 q12Shape46T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T305OK,q12Shape46T312OK⟩

private def q12Shape46T284 : Tree 12 := .split 41 q12Shape46T285 q12Shape46T304
private theorem q12Shape46T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 1650392170496 q12Shape46T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (1650392170496 ||| 2^41) q12Shape46T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^41) 1650392170496 q12Shape46T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T285OK,q12Shape46T304OK⟩

private def q12Shape46T319 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 23 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,4,5,7,8,9}))))
private theorem q12Shape46T319OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 33536232521728 q12Shape46T319=true := by decide

private def q12Shape46T320 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape46T320OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099513987072 33536230424576 q12Shape46T320=true := by decide

private def q12Shape46T318 : Tree 12 := .split 21 q12Shape46T319 q12Shape46T320
private theorem q12Shape46T318OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 33536230424576 q12Shape46T318=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 (33536230424576 ||| 2^21) q12Shape46T319 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099511889920 ||| 2^21) 33536230424576 q12Shape46T320)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T319OK,q12Shape46T320OK⟩

private def q12Shape46T321 : Tree 12 := (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape46T321OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099512938496 33536229376000 q12Shape46T321=true := by decide

private def q12Shape46T317 : Tree 12 := .split 20 q12Shape46T318 q12Shape46T321
private theorem q12Shape46T317OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 33536229376000 q12Shape46T317=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 (33536229376000 ||| 2^20) q12Shape46T318 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099511889920 ||| 2^20) 33536229376000 q12Shape46T321)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T318OK,q12Shape46T321OK⟩

private def q12Shape46T322 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape46T322OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 18691697934336 15944043331584 q12Shape46T322=true := by decide

private def q12Shape46T316 : Tree 12 := .split 44 q12Shape46T317 q12Shape46T322
private theorem q12Shape46T316OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 15944043331584 q12Shape46T316=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 (15944043331584 ||| 2^44) q12Shape46T317 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099511889920 ||| 2^44) 15944043331584 q12Shape46T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T317OK,q12Shape46T322OK⟩

private def q12Shape46T323 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T323OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 9895604912128 7147950309376 q12Shape46T323=true := by decide

private def q12Shape46T315 : Tree 12 := .split 43 q12Shape46T316 q12Shape46T323
private theorem q12Shape46T315OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 7147950309376 q12Shape46T315=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 (7147950309376 ||| 2^43) q12Shape46T316 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099511889920 ||| 2^43) 7147950309376 q12Shape46T323)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T316OK,q12Shape46T323OK⟩

private def q12Shape46T324 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape46T324OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 5497558401024 2749903798272 q12Shape46T324=true := by decide

private def q12Shape46T314 : Tree 12 := .split 42 q12Shape46T315 q12Shape46T324
private theorem q12Shape46T314OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 2749903798272 q12Shape46T314=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 (2749903798272 ||| 2^42) q12Shape46T315 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099511889920 ||| 2^42) 2749903798272 q12Shape46T324)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T315OK,q12Shape46T324OK⟩

private def q12Shape46T325 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape46T325OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 3298535145472 550880542720 q12Shape46T325=true := by decide

private def q12Shape46T313 : Tree 12 := .split 41 q12Shape46T314 q12Shape46T325
private theorem q12Shape46T313OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 550880542720 q12Shape46T313=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1099511889920 (550880542720 ||| 2^41) q12Shape46T314 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (1099511889920 ||| 2^41) 550880542720 q12Shape46T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T314OK,q12Shape46T325OK⟩

private def q12Shape46T283 : Tree 12 := .split 40 q12Shape46T284 q12Shape46T313
private theorem q12Shape46T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 550880542720 q12Shape46T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (550880542720 ||| 2^40) q12Shape46T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^40) 550880542720 q12Shape46T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T284OK,q12Shape46T313OK⟩

private def q12Shape46T333 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape46T333OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 34085988335616 q12Shape46T333=true := by decide

private def q12Shape46T334 : Tree 12 := (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape46T334OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549758173184 34085986238464 q12Shape46T334=true := by decide

private def q12Shape46T332 : Tree 12 := .split 21 q12Shape46T333 q12Shape46T334
private theorem q12Shape46T332OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 34085986238464 q12Shape46T332=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 (34085986238464 ||| 2^21) q12Shape46T333 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549756076032 ||| 2^21) 34085986238464 q12Shape46T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T333OK,q12Shape46T334OK⟩

private def q12Shape46T335 : Tree 12 := (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape46T335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549757124608 34085985189888 q12Shape46T335=true := by decide

private def q12Shape46T331 : Tree 12 := .split 20 q12Shape46T332 q12Shape46T335
private theorem q12Shape46T331OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 34085985189888 q12Shape46T331=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 (34085985189888 ||| 2^20) q12Shape46T332 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549756076032 ||| 2^20) 34085985189888 q12Shape46T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T332OK,q12Shape46T335OK⟩

private def q12Shape46T336 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 18141942120448 16493799145472 q12Shape46T336=true := by decide

private def q12Shape46T330 : Tree 12 := .split 44 q12Shape46T331 q12Shape46T336
private theorem q12Shape46T330OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 16493799145472 q12Shape46T330=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 (16493799145472 ||| 2^44) q12Shape46T331 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549756076032 ||| 2^44) 16493799145472 q12Shape46T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T331OK,q12Shape46T336OK⟩

private def q12Shape46T337 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape46T337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 9345849098240 7697706123264 q12Shape46T337=true := by decide

private def q12Shape46T329 : Tree 12 := .split 43 q12Shape46T330 q12Shape46T337
private theorem q12Shape46T329OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 7697706123264 q12Shape46T329=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 (7697706123264 ||| 2^43) q12Shape46T330 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549756076032 ||| 2^43) 7697706123264 q12Shape46T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T330OK,q12Shape46T337OK⟩

private def q12Shape46T338 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape46T338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4947802587136 3299659612160 q12Shape46T338=true := by decide

private def q12Shape46T328 : Tree 12 := .split 42 q12Shape46T329 q12Shape46T338
private theorem q12Shape46T328OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 3299659612160 q12Shape46T328=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 (3299659612160 ||| 2^42) q12Shape46T329 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549756076032 ||| 2^42) 3299659612160 q12Shape46T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T329OK,q12Shape46T338OK⟩

private def q12Shape46T339 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape46T339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2748779331584 1100636356608 q12Shape46T339=true := by decide

private def q12Shape46T327 : Tree 12 := .split 41 q12Shape46T328 q12Shape46T339
private theorem q12Shape46T327OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 1100636356608 q12Shape46T327=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 (1100636356608 ||| 2^41) q12Shape46T328 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549756076032 ||| 2^41) 1100636356608 q12Shape46T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T328OK,q12Shape46T339OK⟩

private def q12Shape46T340 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape46T340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1649267703808 1124728832 q12Shape46T340=true := by decide

private def q12Shape46T326 : Tree 12 := .split 40 q12Shape46T327 q12Shape46T340
private theorem q12Shape46T326OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 1124728832 q12Shape46T326=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756076032 (1124728832 ||| 2^40) q12Shape46T327 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549756076032 ||| 2^40) 1124728832 q12Shape46T340)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T327OK,q12Shape46T340OK⟩

private def q12Shape46T282 : Tree 12 := .split 39 q12Shape46T283 q12Shape46T326
private theorem q12Shape46T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 1124728832 q12Shape46T282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (1124728832 ||| 2^39) q12Shape46T283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^39) 1124728832 q12Shape46T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T283OK,q12Shape46T326OK⟩

private def q12Shape46T341 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape46T341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1074003968 50987008 q12Shape46T341=true := by decide

private def q12Shape46T281 : Tree 12 := .split 30 q12Shape46T282 q12Shape46T341
private theorem q12Shape46T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 50987008 q12Shape46T281=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 (50987008 ||| 2^30) q12Shape46T282 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (262144 ||| 2^30) 50987008 q12Shape46T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T282OK,q12Shape46T341OK⟩

def q12Shape46P7 : Tree 12 := q12Shape46T281
theorem q12Shape46P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 262144 50987008 q12Shape46P7=true := q12Shape46T281OK

end Graffiti384b.EffectiveSearch.Q12
