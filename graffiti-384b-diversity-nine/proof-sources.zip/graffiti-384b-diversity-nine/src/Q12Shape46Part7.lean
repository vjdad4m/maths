import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape46T343 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape46T343OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33816576 1091174400 q12Shape46T343=true := by decide

private def q12Shape46T344 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape46T344OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1107558400 17432576 q12Shape46T344=true := by decide

private def q12Shape46T342 : Tree 12 := .split 30 q12Shape46T343 q12Shape46T344
private theorem q12Shape46T342OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33816576 17432576 q12Shape46T342=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33816576 (17432576 ||| 2^30) q12Shape46T343 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (33816576 ||| 2^30) 17432576 q12Shape46T344)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T343OK,q12Shape46T344OK⟩

def q12Shape46P8 : Tree 12 := q12Shape46T342
theorem q12Shape46P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33816576 17432576 q12Shape46P8=true := q12Shape46T342OK

private def q12Shape46T347 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape46T347OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17039360 34209792 q12Shape46T347=true := by decide

private def q12Shape46T348 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape46T348OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 50593792 655360 q12Shape46T348=true := by decide

private def q12Shape46T346 : Tree 12 := .split 25 q12Shape46T347 q12Shape46T348
private theorem q12Shape46T346OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17039360 655360 q12Shape46T346=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17039360 (655360 ||| 2^25) q12Shape46T347 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (17039360 ||| 2^25) 655360 q12Shape46T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T347OK,q12Shape46T348OK⟩

def q12Shape46P9 : Tree 12 := q12Shape46T346
theorem q12Shape46P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17039360 655360 q12Shape46P9=true := q12Shape46T346OK

private def q12Shape46T353 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape46T353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 1124204544 q12Shape46T353=true := by decide

private def q12Shape46T354 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape46T354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1074528256 50462720 q12Shape46T354=true := by decide

private def q12Shape46T352 : Tree 12 := .split 30 q12Shape46T353 q12Shape46T354
private theorem q12Shape46T352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 50462720 q12Shape46T352=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 (50462720 ||| 2^30) q12Shape46T353 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (786432 ||| 2^30) 50462720 q12Shape46T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T353OK,q12Shape46T354OK⟩

private def q12Shape46T355 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape46T355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 34340864 16908288 q12Shape46T355=true := by decide

private def q12Shape46T351 : Tree 12 := .split 25 q12Shape46T352 q12Shape46T355
private theorem q12Shape46T351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 16908288 q12Shape46T351=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 (16908288 ||| 2^25) q12Shape46T352 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (786432 ||| 2^25) 16908288 q12Shape46T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T352OK,q12Shape46T355OK⟩

private def q12Shape46T357 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape46T357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17563648 33685504 q12Shape46T357=true := by decide

private def q12Shape46T358 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape46T358OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 51118080 131072 q12Shape46T358=true := by decide

private def q12Shape46T356 : Tree 12 := .split 25 q12Shape46T357 q12Shape46T358
private theorem q12Shape46T356OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17563648 131072 q12Shape46T356=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 17563648 (131072 ||| 2^25) q12Shape46T357 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (17563648 ||| 2^25) 131072 q12Shape46T358)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T357OK,q12Shape46T358OK⟩

private def q12Shape46T350 : Tree 12 := .split 24 q12Shape46T351 q12Shape46T356
private theorem q12Shape46T350OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 131072 q12Shape46T350=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 (131072 ||| 2^24) q12Shape46T351 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (786432 ||| 2^24) 131072 q12Shape46T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T351OK,q12Shape46T356OK⟩

def q12Shape46P10 : Tree 12 := q12Shape46T350
theorem q12Shape46P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 786432 131072 q12Shape46P10=true := q12Shape46T350OK

end Graffiti384b.EffectiveSearch.Q12
