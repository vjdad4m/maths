import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape46T455 : Tree 12 := (.split 28 (.split 29 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,4,6,7,8,10}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape46T455OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 34086202376192 q12Shape46T455=true := by decide

private def q12Shape46T456 : Tree 12 := (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,9})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11})))
private theorem q12Shape46T456OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549890162688 34086068158464 q12Shape46T456=true := by decide

private def q12Shape46T454 : Tree 12 := .split 27 q12Shape46T455 q12Shape46T456
private theorem q12Shape46T454OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 34086068158464 q12Shape46T454=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (34086068158464 ||| 2^27) q12Shape46T455 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^27) 34086068158464 q12Shape46T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T455OK,q12Shape46T456OK⟩

private def q12Shape46T457 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,5,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape46T457OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549823053824 34086001049600 q12Shape46T457=true := by decide

private def q12Shape46T453 : Tree 12 := .split 26 q12Shape46T454 q12Shape46T457
private theorem q12Shape46T453OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 34086001049600 q12Shape46T453=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (34086001049600 ||| 2^26) q12Shape46T454 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^26) 34086001049600 q12Shape46T457)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T454OK,q12Shape46T457OK⟩

private def q12Shape46T458 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,10}))
private theorem q12Shape46T458OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549764333568 34085992660992 q12Shape46T458=true := by decide

private def q12Shape46T452 : Tree 12 := .split 23 q12Shape46T453 q12Shape46T458
private theorem q12Shape46T452OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 34085992660992 q12Shape46T452=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (34085992660992 ||| 2^23) q12Shape46T453 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^23) 34085992660992 q12Shape46T458)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T453OK,q12Shape46T458OK⟩

private def q12Shape46T459 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,11}))
private theorem q12Shape46T459OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549760139264 34085988466688 q12Shape46T459=true := by decide

private def q12Shape46T451 : Tree 12 := .split 22 q12Shape46T452 q12Shape46T459
private theorem q12Shape46T451OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 34085988466688 q12Shape46T451=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (34085988466688 ||| 2^22) q12Shape46T452 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^22) 34085988466688 q12Shape46T459)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T452OK,q12Shape46T459OK⟩

private def q12Shape46T460 : Tree 12 := (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,6,7,8,10}))) (.tip (.cover {0,1,4,6,7,8,11})))
private theorem q12Shape46T460OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549758042112 34085986369536 q12Shape46T460=true := by decide

private def q12Shape46T450 : Tree 12 := .split 21 q12Shape46T451 q12Shape46T460
private theorem q12Shape46T450OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 34085986369536 q12Shape46T450=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (34085986369536 ||| 2^21) q12Shape46T451 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^21) 34085986369536 q12Shape46T460)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T451OK,q12Shape46T460OK⟩

private def q12Shape46T461 : Tree 12 := (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,6,7,8,10}))) (.tip (.cover {0,1,4,6,7,8,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape46T461OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549756993536 34085985320960 q12Shape46T461=true := by decide

private def q12Shape46T449 : Tree 12 := .split 20 q12Shape46T450 q12Shape46T461
private theorem q12Shape46T449OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 34085985320960 q12Shape46T449=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (34085985320960 ||| 2^20) q12Shape46T450 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^20) 34085985320960 q12Shape46T461)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T450OK,q12Shape46T461OK⟩

private def q12Shape46T462 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,10}))
private theorem q12Shape46T462OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 18141941989376 16493799276544 q12Shape46T462=true := by decide

private def q12Shape46T448 : Tree 12 := .split 44 q12Shape46T449 q12Shape46T462
private theorem q12Shape46T448OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 16493799276544 q12Shape46T448=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (16493799276544 ||| 2^44) q12Shape46T449 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^44) 16493799276544 q12Shape46T462)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T449OK,q12Shape46T462OK⟩

private def q12Shape46T463 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,10}))
private theorem q12Shape46T463OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 9345848967168 7697706254336 q12Shape46T463=true := by decide

private def q12Shape46T447 : Tree 12 := .split 43 q12Shape46T448 q12Shape46T463
private theorem q12Shape46T447OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 7697706254336 q12Shape46T447=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (7697706254336 ||| 2^43) q12Shape46T448 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^43) 7697706254336 q12Shape46T463)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T448OK,q12Shape46T463OK⟩

private def q12Shape46T464 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape46T464OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 4947802456064 3299659743232 q12Shape46T464=true := by decide

private def q12Shape46T446 : Tree 12 := .split 42 q12Shape46T447 q12Shape46T464
private theorem q12Shape46T446OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 3299659743232 q12Shape46T446=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (3299659743232 ||| 2^42) q12Shape46T447 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^42) 3299659743232 q12Shape46T464)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T447OK,q12Shape46T464OK⟩

private def q12Shape46T465 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,10}))
private theorem q12Shape46T465OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 2748779200512 1100636487680 q12Shape46T465=true := by decide

private def q12Shape46T445 : Tree 12 := .split 41 q12Shape46T446 q12Shape46T465
private theorem q12Shape46T445OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 1100636487680 q12Shape46T445=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (1100636487680 ||| 2^41) q12Shape46T446 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^41) 1100636487680 q12Shape46T465)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T446OK,q12Shape46T465OK⟩

private def q12Shape46T466 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,11}))
private theorem q12Shape46T466OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1649267572736 1124859904 q12Shape46T466=true := by decide

private def q12Shape46T444 : Tree 12 := .split 40 q12Shape46T445 q12Shape46T466
private theorem q12Shape46T444OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 1124859904 q12Shape46T444=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 (1124859904 ||| 2^40) q12Shape46T445 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (549755944960 ||| 2^40) 1124859904 q12Shape46T466)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T445OK,q12Shape46T466OK⟩

def q12Shape46P12 : Tree 12 := q12Shape46T444
theorem q12Shape46P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 549755944960 1124859904 q12Shape46P12=true := q12Shape46T444OK

private def q12Shape46T468 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape46T468OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073872896 51118080 q12Shape46T468=true := by decide

def q12Shape46P13 : Tree 12 := q12Shape46T468
theorem q12Shape46P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1073872896 51118080 q12Shape46P13=true := q12Shape46T468OK

private def q12Shape46T471 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape46T471OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33685504 1091305472 q12Shape46T471=true := by decide

private def q12Shape46T472 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape46T472OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1107427328 17563648 q12Shape46T472=true := by decide

private def q12Shape46T470 : Tree 12 := .split 30 q12Shape46T471 q12Shape46T472
private theorem q12Shape46T470OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33685504 17563648 q12Shape46T470=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33685504 (17563648 ||| 2^30) q12Shape46T471 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (33685504 ||| 2^30) 17563648 q12Shape46T472)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T471OK,q12Shape46T472OK⟩

def q12Shape46P14 : Tree 12 := q12Shape46T470
theorem q12Shape46P14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 33685504 17563648 q12Shape46P14=true := q12Shape46T470OK

private def q12Shape46T476 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape46T476OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16908288 1108082688 q12Shape46T476=true := by decide

private def q12Shape46T477 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape46T477OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 1090650112 34340864 q12Shape46T477=true := by decide

private def q12Shape46T475 : Tree 12 := .split 30 q12Shape46T476 q12Shape46T477
private theorem q12Shape46T475OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16908288 34340864 q12Shape46T475=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16908288 (34340864 ||| 2^30) q12Shape46T476 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16908288 ||| 2^30) 34340864 q12Shape46T477)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T476OK,q12Shape46T477OK⟩

private def q12Shape46T478 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape46T478OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 50462720 786432 q12Shape46T478=true := by decide

private def q12Shape46T474 : Tree 12 := .split 25 q12Shape46T475 q12Shape46T478
private theorem q12Shape46T474OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16908288 786432 q12Shape46T474=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16908288 (786432 ||| 2^25) q12Shape46T475 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) (16908288 ||| 2^25) 786432 q12Shape46T478)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape46T475OK,q12Shape46T478OK⟩

def q12Shape46P15 : Tree 12 := q12Shape46T474
theorem q12Shape46P15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,2⟩) 16908288 786432 q12Shape46P15=true := q12Shape46T474OK

end Graffiti384b.EffectiveSearch.Q12
