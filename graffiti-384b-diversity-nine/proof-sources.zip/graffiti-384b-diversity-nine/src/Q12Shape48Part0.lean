import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape48T10 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape48T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 660351221880 q12Shape48T10=true := by decide

private def q12Shape48T13 : Tree 12 := (.split 13 (.tip (.cover {0,1,4,5,9,10,11})) (.tip (.cover {0,4,5,8,9,10,11})))
private theorem q12Shape48T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 64 660351227960 q12Shape48T13=true := by decide

private def q12Shape48T14 : Tree 12 := (.split 13 (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,7,9,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.split 19 (.split 20 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11})))
private theorem q12Shape48T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4160 660351223864 q12Shape48T14=true := by decide

private def q12Shape48T12 : Tree 12 := .split 12 q12Shape48T13 q12Shape48T14
private theorem q12Shape48T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 64 660351223864 q12Shape48T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 64 (660351223864 ||| 2^12) q12Shape48T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (64 ||| 2^12) 660351223864 q12Shape48T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T13OK,q12Shape48T14OK⟩

private def q12Shape48T15 : Tree 12 := (.split 12 (.split 13 (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,6,9,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.split 20 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,9,10,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape48T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2112 660351221816 q12Shape48T15=true := by decide

private def q12Shape48T11 : Tree 12 := .split 11 q12Shape48T12 q12Shape48T15
private theorem q12Shape48T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 64 660351221816 q12Shape48T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 64 (660351221816 ||| 2^11) q12Shape48T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (64 ||| 2^11) 660351221816 q12Shape48T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T12OK,q12Shape48T15OK⟩

private def q12Shape48T9 : Tree 12 := .split 6 q12Shape48T10 q12Shape48T11
private theorem q12Shape48T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 660351221816 q12Shape48T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (660351221816 ||| 2^6) q12Shape48T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^6) 660351221816 q12Shape48T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T10OK,q12Shape48T11OK⟩

private def q12Shape48T19 : Tree 12 := (.split 13 (.split 14 (.tip (.cover {0,1,4,5,8,10,11})) (.tip (.cover {0,4,5,8,9,10,11}))) (.tip (.cover {0,1,3,4,5,10,11})))
private theorem q12Shape48T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 32 660351227992 q12Shape48T19=true := by decide

private def q12Shape48T22 : Tree 12 := (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,7,8,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 19 (.split 20 (.split 21 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))))
private theorem q12Shape48T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4128 660351248472 q12Shape48T22=true := by decide

private def q12Shape48T23 : Tree 12 := (.tip (.cover {0,1,3,6,8,10,11}))
private theorem q12Shape48T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 20512 660351232088 q12Shape48T23=true := by decide

private def q12Shape48T21 : Tree 12 := .split 14 q12Shape48T22 q12Shape48T23
private theorem q12Shape48T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4128 660351232088 q12Shape48T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4128 (660351232088 ||| 2^14) q12Shape48T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (4128 ||| 2^14) 660351232088 q12Shape48T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T22OK,q12Shape48T23OK⟩

private def q12Shape48T24 : Tree 12 := (.tip (.cover {0,1,3,6,9,10,11}))
private theorem q12Shape48T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 12320 660351223896 q12Shape48T24=true := by decide

private def q12Shape48T20 : Tree 12 := .split 13 q12Shape48T21 q12Shape48T24
private theorem q12Shape48T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4128 660351223896 q12Shape48T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4128 (660351223896 ||| 2^13) q12Shape48T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (4128 ||| 2^13) 660351223896 q12Shape48T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T21OK,q12Shape48T24OK⟩

private def q12Shape48T18 : Tree 12 := .split 12 q12Shape48T19 q12Shape48T20
private theorem q12Shape48T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 32 660351223896 q12Shape48T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 32 (660351223896 ||| 2^12) q12Shape48T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (32 ||| 2^12) 660351223896 q12Shape48T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T19OK,q12Shape48T20OK⟩

private def q12Shape48T27 : Tree 12 := (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,8,10,11})) (.tip (.cover {0,3,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 20 (.split 21 (.tip (.cover {1,2,5,6,7,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape48T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2080 660351234136 q12Shape48T27=true := by decide

private def q12Shape48T28 : Tree 12 := (.tip (.cover {0,1,3,7,9,10,11}))
private theorem q12Shape48T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 10272 660351225944 q12Shape48T28=true := by decide

private def q12Shape48T26 : Tree 12 := .split 13 q12Shape48T27 q12Shape48T28
private theorem q12Shape48T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2080 660351225944 q12Shape48T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2080 (660351225944 ||| 2^13) q12Shape48T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (2080 ||| 2^13) 660351225944 q12Shape48T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T27OK,q12Shape48T28OK⟩

private def q12Shape48T29 : Tree 12 := (.tip (.cover {0,1,3,8,9,10,11}))
private theorem q12Shape48T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 6176 660351221848 q12Shape48T29=true := by decide

private def q12Shape48T25 : Tree 12 := .split 12 q12Shape48T26 q12Shape48T29
private theorem q12Shape48T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2080 660351221848 q12Shape48T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2080 (660351221848 ||| 2^12) q12Shape48T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (2080 ||| 2^12) 660351221848 q12Shape48T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T26OK,q12Shape48T29OK⟩

private def q12Shape48T17 : Tree 12 := .split 11 q12Shape48T18 q12Shape48T25
private theorem q12Shape48T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 32 660351221848 q12Shape48T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 32 (660351221848 ||| 2^11) q12Shape48T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (32 ||| 2^11) 660351221848 q12Shape48T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T18OK,q12Shape48T25OK⟩

private def q12Shape48T30 : Tree 12 := (.tip (.cover {0,1,2,6,7,10,11}))
private theorem q12Shape48T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 96 660351221784 q12Shape48T30=true := by decide

private def q12Shape48T16 : Tree 12 := .split 6 q12Shape48T17 q12Shape48T30
private theorem q12Shape48T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 32 660351221784 q12Shape48T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 32 (660351221784 ||| 2^6) q12Shape48T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (32 ||| 2^6) 660351221784 q12Shape48T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T17OK,q12Shape48T30OK⟩

private def q12Shape48T8 : Tree 12 := .split 5 q12Shape48T9 q12Shape48T16
private theorem q12Shape48T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 660351221784 q12Shape48T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (660351221784 ||| 2^5) q12Shape48T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^5) 660351221784 q12Shape48T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T9OK,q12Shape48T16OK⟩

private def q12Shape48T36 : Tree 12 := (.split 14 (.tip (.cover {0,1,4,5,7,10,11})) (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,7,9,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,9,10,11}))) (.split 19 (.split 20 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))))
private theorem q12Shape48T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 660351236200 q12Shape48T36=true := by decide

private def q12Shape48T38 : Tree 12 := (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,7,8,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 19 (.split 20 (.split 21 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))))
private theorem q12Shape48T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8208 660351244392 q12Shape48T38=true := by decide

private def q12Shape48T39 : Tree 12 := (.tip (.cover {0,1,3,6,7,10,11}))
private theorem q12Shape48T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 24592 660351228008 q12Shape48T39=true := by decide

private def q12Shape48T37 : Tree 12 := .split 14 q12Shape48T38 q12Shape48T39
private theorem q12Shape48T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8208 660351228008 q12Shape48T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8208 (660351228008 ||| 2^14) q12Shape48T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (8208 ||| 2^14) 660351228008 q12Shape48T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T38OK,q12Shape48T39OK⟩

private def q12Shape48T35 : Tree 12 := .split 13 q12Shape48T36 q12Shape48T37
private theorem q12Shape48T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 660351228008 q12Shape48T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 (660351228008 ||| 2^13) q12Shape48T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (16 ||| 2^13) 660351228008 q12Shape48T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T36OK,q12Shape48T37OK⟩

private def q12Shape48T40 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape48T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4112 660351223912 q12Shape48T40=true := by decide

private def q12Shape48T34 : Tree 12 := .split 12 q12Shape48T35 q12Shape48T40
private theorem q12Shape48T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 660351223912 q12Shape48T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 (660351223912 ||| 2^12) q12Shape48T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (16 ||| 2^12) 660351223912 q12Shape48T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T35OK,q12Shape48T40OK⟩

private def q12Shape48T41 : Tree 12 := (.split 12 (.split 13 (.split 14 (.tip (.cover {1,4,5,6,7,10,11})) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape48T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2064 660351221864 q12Shape48T41=true := by decide

private def q12Shape48T33 : Tree 12 := .split 11 q12Shape48T34 q12Shape48T41
private theorem q12Shape48T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 660351221864 q12Shape48T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 (660351221864 ||| 2^11) q12Shape48T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (16 ||| 2^11) 660351221864 q12Shape48T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T34OK,q12Shape48T41OK⟩

private def q12Shape48T42 : Tree 12 := (.tip (.cover {0,1,2,6,8,10,11}))
private theorem q12Shape48T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 80 660351221800 q12Shape48T42=true := by decide

private def q12Shape48T32 : Tree 12 := .split 6 q12Shape48T33 q12Shape48T42
private theorem q12Shape48T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 660351221800 q12Shape48T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 (660351221800 ||| 2^6) q12Shape48T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (16 ||| 2^6) 660351221800 q12Shape48T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T33OK,q12Shape48T42OK⟩

private def q12Shape48T43 : Tree 12 := (.tip (.cover {0,1,2,6,9,10,11}))
private theorem q12Shape48T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 48 660351221768 q12Shape48T43=true := by decide

private def q12Shape48T31 : Tree 12 := .split 5 q12Shape48T32 q12Shape48T43
private theorem q12Shape48T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 660351221768 q12Shape48T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 16 (660351221768 ||| 2^5) q12Shape48T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (16 ||| 2^5) 660351221768 q12Shape48T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T32OK,q12Shape48T43OK⟩

private def q12Shape48T7 : Tree 12 := .split 4 q12Shape48T8 q12Shape48T31
private theorem q12Shape48T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 660351221768 q12Shape48T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (660351221768 ||| 2^4) q12Shape48T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^4) 660351221768 q12Shape48T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T8OK,q12Shape48T31OK⟩

private def q12Shape48T50 : Tree 12 := (.split 14 (.tip (.cover {0,1,4,5,6,10,11})) (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,5,6,9,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.split 20 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,9,10,11}))))
private theorem q12Shape48T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 660351236208 q12Shape48T50=true := by decide

private def q12Shape48T51 : Tree 12 := (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,8,10,11})) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 20 (.split 21 (.tip (.cover {1,3,5,6,7,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,3,6,7,10,11})))
private theorem q12Shape48T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8200 660351228016 q12Shape48T51=true := by decide

private def q12Shape48T49 : Tree 12 := .split 13 q12Shape48T50 q12Shape48T51
private theorem q12Shape48T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 660351228016 q12Shape48T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 (660351228016 ||| 2^13) q12Shape48T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (8 ||| 2^13) 660351228016 q12Shape48T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T50OK,q12Shape48T51OK⟩

private def q12Shape48T52 : Tree 12 := (.split 13 (.split 14 (.tip (.cover {1,4,5,6,7,10,11})) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11})))
private theorem q12Shape48T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4104 660351223920 q12Shape48T52=true := by decide

private def q12Shape48T48 : Tree 12 := .split 12 q12Shape48T49 q12Shape48T52
private theorem q12Shape48T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 660351223920 q12Shape48T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 (660351223920 ||| 2^12) q12Shape48T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (8 ||| 2^12) 660351223920 q12Shape48T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T49OK,q12Shape48T52OK⟩

private def q12Shape48T53 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape48T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2056 660351221872 q12Shape48T53=true := by decide

private def q12Shape48T47 : Tree 12 := .split 11 q12Shape48T48 q12Shape48T53
private theorem q12Shape48T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 660351221872 q12Shape48T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 (660351221872 ||| 2^11) q12Shape48T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (8 ||| 2^11) 660351221872 q12Shape48T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T48OK,q12Shape48T53OK⟩

private def q12Shape48T54 : Tree 12 := (.tip (.cover {0,1,2,7,8,10,11}))
private theorem q12Shape48T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 72 660351221808 q12Shape48T54=true := by decide

private def q12Shape48T46 : Tree 12 := .split 6 q12Shape48T47 q12Shape48T54
private theorem q12Shape48T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 660351221808 q12Shape48T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 (660351221808 ||| 2^6) q12Shape48T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (8 ||| 2^6) 660351221808 q12Shape48T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T47OK,q12Shape48T54OK⟩

private def q12Shape48T55 : Tree 12 := (.tip (.cover {0,1,2,7,9,10,11}))
private theorem q12Shape48T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 40 660351221776 q12Shape48T55=true := by decide

private def q12Shape48T45 : Tree 12 := .split 5 q12Shape48T46 q12Shape48T55
private theorem q12Shape48T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 660351221776 q12Shape48T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 (660351221776 ||| 2^5) q12Shape48T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (8 ||| 2^5) 660351221776 q12Shape48T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T46OK,q12Shape48T55OK⟩

private def q12Shape48T56 : Tree 12 := (.tip (.cover {0,1,2,8,9,10,11}))
private theorem q12Shape48T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 24 660351221760 q12Shape48T56=true := by decide

private def q12Shape48T44 : Tree 12 := .split 4 q12Shape48T45 q12Shape48T56
private theorem q12Shape48T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 660351221760 q12Shape48T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 8 (660351221760 ||| 2^4) q12Shape48T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (8 ||| 2^4) 660351221760 q12Shape48T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T45OK,q12Shape48T56OK⟩

private def q12Shape48T6 : Tree 12 := .split 3 q12Shape48T7 q12Shape48T44
private theorem q12Shape48T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 660351221760 q12Shape48T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (660351221760 ||| 2^3) q12Shape48T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^3) 660351221760 q12Shape48T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T7OK,q12Shape48T44OK⟩

private def q12Shape48T57 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape48T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 68719476736 591631745024 q12Shape48T57=true := by decide

private def q12Shape48T5 : Tree 12 := .split 36 q12Shape48T6 q12Shape48T57
private theorem q12Shape48T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 591631745024 q12Shape48T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (591631745024 ||| 2^36) q12Shape48T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^36) 591631745024 q12Shape48T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T6OK,q12Shape48T57OK⟩

private def q12Shape48T58 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape48T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 34359738368 557272006656 q12Shape48T58=true := by decide

private def q12Shape48T4 : Tree 12 := .split 35 q12Shape48T5 q12Shape48T58
private theorem q12Shape48T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 557272006656 q12Shape48T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (557272006656 ||| 2^35) q12Shape48T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^35) 557272006656 q12Shape48T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T5OK,q12Shape48T58OK⟩

private def q12Shape48T59 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape48T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 4294967296 552977039360 q12Shape48T59=true := by decide

private def q12Shape48T3 : Tree 12 := .split 32 q12Shape48T4 q12Shape48T59
private theorem q12Shape48T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 552977039360 q12Shape48T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (552977039360 ||| 2^32) q12Shape48T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^32) 552977039360 q12Shape48T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T4OK,q12Shape48T59OK⟩

private def q12Shape48T60 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape48T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 2147483648 550829555712 q12Shape48T60=true := by decide

private def q12Shape48T2 : Tree 12 := .split 31 q12Shape48T3 q12Shape48T60
private theorem q12Shape48T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 550829555712 q12Shape48T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (550829555712 ||| 2^31) q12Shape48T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^31) 550829555712 q12Shape48T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T3OK,q12Shape48T60OK⟩

private def q12Shape48T61 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape48T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 549755813888 1073741824 q12Shape48T61=true := by decide

private def q12Shape48T1 : Tree 12 := .split 39 q12Shape48T2 q12Shape48T61
private theorem q12Shape48T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 1073741824 q12Shape48T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (1073741824 ||| 2^39) q12Shape48T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^39) 1073741824 q12Shape48T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T2OK,q12Shape48T61OK⟩

private def q12Shape48T62 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape48T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 1073741824 0 q12Shape48T62=true := by decide

private def q12Shape48T0 : Tree 12 := .split 30 q12Shape48T1 q12Shape48T62
private theorem q12Shape48T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 0 q12Shape48T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 (0 ||| 2^30) q12Shape48T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) (0 ||| 2^30) 0 q12Shape48T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape48T1OK,q12Shape48T62OK⟩

def q12Shape48P0 : Tree 12 := q12Shape48T0
theorem q12Shape48P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,7,7,4⟩) 0 0 q12Shape48P0=true := q12Shape48T0OK

end Graffiti384b.EffectiveSearch.Q12
