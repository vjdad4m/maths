import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape49T0 : Tree 12 := (.tip (.small 1))
private theorem q12Shape49T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 0 64 q12Shape49T0=true := by decide

def q12Shape49P0 : Tree 12 := q12Shape49T0
theorem q12Shape49P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 0 64 q12Shape49P0=true := q12Shape49T0OK

end Graffiti384b.EffectiveSearch.Q12
