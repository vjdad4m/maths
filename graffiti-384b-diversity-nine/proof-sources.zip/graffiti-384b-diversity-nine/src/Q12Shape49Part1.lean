import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape49T2 : Tree 12 := (.tip (.small 1))
private theorem q12Shape49T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 64 128 q12Shape49T2=true := by decide

private def q12Shape49T4 : Tree 12 := (.tip (.small 1))
private theorem q12Shape49T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 192 256 q12Shape49T4=true := by decide

private def q12Shape49T14 : Tree 12 := (.split 12 (.split 13 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.split 18 (.tip (.cover {0,5,7,8,9,10,11})) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,6,7})))) (.split 13 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,6,8}))) (.tip (.cover {1,2,4,5,6,7,8}))))
private theorem q12Shape49T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 3647 q12Shape49T14=true := by decide

private def q12Shape49T15 : Tree 12 := (.split 12 (.split 13 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,7,8}))) (.tip (.cover {1,2,4,5,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8})))
private theorem q12Shape49T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 2496 1599 q12Shape49T15=true := by decide

private def q12Shape49T13 : Tree 12 := .split 11 q12Shape49T14 q12Shape49T15
private theorem q12Shape49T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 1599 q12Shape49T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (1599 ||| 2^11) q12Shape49T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^11) 1599 q12Shape49T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T14OK,q12Shape49T15OK⟩

private def q12Shape49T16 : Tree 12 := (.split 11 (.split 12 (.split 13 (.split 17 (.split 18 (.tip (.cover {0,5,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,7,8}))) (.tip (.cover {1,2,3,4,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8})))
private theorem q12Shape49T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 1472 575 q12Shape49T16=true := by decide

private def q12Shape49T12 : Tree 12 := .split 10 q12Shape49T13 q12Shape49T16
private theorem q12Shape49T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 575 q12Shape49T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (575 ||| 2^10) q12Shape49T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^10) 575 q12Shape49T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T13OK,q12Shape49T16OK⟩

private def q12Shape49T19 : Tree 12 := (.split 12 (.split 13 (.split 17 (.split 18 (.split 19 (.split 20 (.split 24 (.tip (.cover {0,3,7,8,9,10,11})) (.tip (.cover {0,1,2,3,5,7,8}))) (.tip (.cover {1,2,3,5,6,7,8}))) (.tip (.cover {1,2,3,5,6,7,8}))) (.tip (.cover {1,2,3,5,6,7,8}))) (.tip (.cover {1,2,3,5,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8})))
private theorem q12Shape49T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 960 3135 q12Shape49T19=true := by decide

private def q12Shape49T20 : Tree 12 := (.tip (.cover {1,2,4,5,6,7,8}))
private theorem q12Shape49T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 3008 1087 q12Shape49T20=true := by decide

private def q12Shape49T18 : Tree 12 := .split 11 q12Shape49T19 q12Shape49T20
private theorem q12Shape49T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 960 1087 q12Shape49T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 960 (1087 ||| 2^11) q12Shape49T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (960 ||| 2^11) 1087 q12Shape49T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T19OK,q12Shape49T20OK⟩

private def q12Shape49T21 : Tree 12 := (.tip (.cover {1,2,4,5,6,7,8}))
private theorem q12Shape49T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 1984 63 q12Shape49T21=true := by decide

private def q12Shape49T17 : Tree 12 := .split 10 q12Shape49T18 q12Shape49T21
private theorem q12Shape49T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 960 63 q12Shape49T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 960 (63 ||| 2^10) q12Shape49T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (960 ||| 2^10) 63 q12Shape49T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T18OK,q12Shape49T21OK⟩

private def q12Shape49T11 : Tree 12 := .split 9 q12Shape49T12 q12Shape49T17
private theorem q12Shape49T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 63 q12Shape49T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (63 ||| 2^9) q12Shape49T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^9) 63 q12Shape49T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T12OK,q12Shape49T17OK⟩

private def q12Shape49T22 : Tree 12 := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,6,7}))) (.tip (.cover {1,2,3,4,5,6,7}))) (.tip (.cover {0,1,2,3,4,5,6}))) (.tip (.cover {0,1,2,3,4,5,7}))) (.tip (.cover {0,1,2,3,4,6,7}))) (.tip (.cover {0,1,2,3,5,6,7})))
private theorem q12Shape49T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 480 31 q12Shape49T22=true := by decide

private def q12Shape49T10 : Tree 12 := .split 5 q12Shape49T11 q12Shape49T22
private theorem q12Shape49T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 31 q12Shape49T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (31 ||| 2^5) q12Shape49T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^5) 31 q12Shape49T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T11OK,q12Shape49T22OK⟩

private def q12Shape49T23 : Tree 12 := (.split 5 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,6,8}))) (.tip (.cover {0,1,2,3,4,5,6}))) (.tip (.cover {1,2,3,4,5,6,8}))) (.tip (.cover {0,1,2,3,4,5,8}))) (.tip (.cover {0,1,2,3,4,6,8}))) (.tip (.cover {0,1,2,3,5,6,8}))) (.tip (.cover {0,1,2,3,4,5,6})))
private theorem q12Shape49T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 464 15 q12Shape49T23=true := by decide

private def q12Shape49T9 : Tree 12 := .split 4 q12Shape49T10 q12Shape49T23
private theorem q12Shape49T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 15 q12Shape49T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (15 ||| 2^4) q12Shape49T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^4) 15 q12Shape49T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T10OK,q12Shape49T23OK⟩

private def q12Shape49T25 : Tree 12 := (.split 5 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 17 (.tip (.cover {0,6,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,7,8}))) (.tip (.cover {0,1,2,3,4,5,7}))) (.tip (.cover {0,1,2,3,4,5,8}))) (.tip (.cover {1,2,3,4,5,7,8}))) (.tip (.cover {0,1,2,3,4,7,8}))) (.tip (.cover {0,1,2,3,5,7,8}))) (.tip (.cover {0,1,2,3,4,5,7})))
private theorem q12Shape49T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 456 23 q12Shape49T25=true := by decide

private def q12Shape49T26 : Tree 12 := (.tip (.cover {0,1,2,3,4,5,8}))
private theorem q12Shape49T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 472 7 q12Shape49T26=true := by decide

private def q12Shape49T24 : Tree 12 := .split 4 q12Shape49T25 q12Shape49T26
private theorem q12Shape49T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 456 7 q12Shape49T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 456 (7 ||| 2^4) q12Shape49T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (456 ||| 2^4) 7 q12Shape49T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T25OK,q12Shape49T26OK⟩

private def q12Shape49T8 : Tree 12 := .split 3 q12Shape49T9 q12Shape49T24
private theorem q12Shape49T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 7 q12Shape49T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (7 ||| 2^3) q12Shape49T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^3) 7 q12Shape49T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T9OK,q12Shape49T24OK⟩

private def q12Shape49T30 : Tree 12 := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 17 (.split 18 (.tip (.cover {0,5,7,8,9,10,11})) (.tip (.cover {0,1,2,3,4,7,8}))) (.tip (.cover {1,2,3,4,6,7,8}))) (.tip (.cover {0,1,2,3,4,6,7}))) (.tip (.cover {0,1,2,3,4,6,8}))) (.tip (.cover {0,1,2,3,4,7,8}))) (.tip (.cover {1,2,3,4,6,7,8}))) (.tip (.cover {0,1,2,3,6,7,8})))
private theorem q12Shape49T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 452 59 q12Shape49T30=true := by decide

private def q12Shape49T31 : Tree 12 := (.tip (.cover {0,1,2,3,4,6,7}))
private theorem q12Shape49T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 484 27 q12Shape49T31=true := by decide

private def q12Shape49T29 : Tree 12 := .split 5 q12Shape49T30 q12Shape49T31
private theorem q12Shape49T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 452 27 q12Shape49T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 452 (27 ||| 2^5) q12Shape49T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (452 ||| 2^5) 27 q12Shape49T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T30OK,q12Shape49T31OK⟩

private def q12Shape49T32 : Tree 12 := (.tip (.cover {0,1,2,3,4,6,8}))
private theorem q12Shape49T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 468 11 q12Shape49T32=true := by decide

private def q12Shape49T28 : Tree 12 := .split 4 q12Shape49T29 q12Shape49T32
private theorem q12Shape49T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 452 11 q12Shape49T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 452 (11 ||| 2^4) q12Shape49T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (452 ||| 2^4) 11 q12Shape49T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T29OK,q12Shape49T32OK⟩

private def q12Shape49T33 : Tree 12 := (.tip (.cover {0,1,2,3,4,7,8}))
private theorem q12Shape49T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 460 3 q12Shape49T33=true := by decide

private def q12Shape49T27 : Tree 12 := .split 3 q12Shape49T28 q12Shape49T33
private theorem q12Shape49T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 452 3 q12Shape49T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 452 (3 ||| 2^3) q12Shape49T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (452 ||| 2^3) 3 q12Shape49T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T28OK,q12Shape49T33OK⟩

private def q12Shape49T7 : Tree 12 := .split 2 q12Shape49T8 q12Shape49T27
private theorem q12Shape49T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 3 q12Shape49T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (3 ||| 2^2) q12Shape49T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^2) 3 q12Shape49T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T8OK,q12Shape49T27OK⟩

private def q12Shape49T41 : Tree 12 := (.split 12 (.split 13 (.split 17 (.split 18 (.split 19 (.split 20 (.split 24 (.tip (.cover {0,2,7,8,9,10,11})) (.tip (.cover {0,1,2,3,5,7,8}))) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {0,6,7,8,9,10,11}))) (.tip (.cover {1,2,3,5,6,7,8}))) (.tip (.cover {0,1,2,3,5,6,7}))) (.tip (.cover {0,1,2,3,5,6,8})))
private theorem q12Shape49T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 3645 q12Shape49T41=true := by decide

private def q12Shape49T42 : Tree 12 := (.tip (.cover {0,1,2,3,5,7,8}))
private theorem q12Shape49T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 2498 1597 q12Shape49T42=true := by decide

private def q12Shape49T40 : Tree 12 := .split 11 q12Shape49T41 q12Shape49T42
private theorem q12Shape49T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 1597 q12Shape49T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 (1597 ||| 2^11) q12Shape49T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (450 ||| 2^11) 1597 q12Shape49T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T41OK,q12Shape49T42OK⟩

private def q12Shape49T43 : Tree 12 := (.tip (.cover {0,1,2,3,6,7,8}))
private theorem q12Shape49T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 1474 573 q12Shape49T43=true := by decide

private def q12Shape49T39 : Tree 12 := .split 10 q12Shape49T40 q12Shape49T43
private theorem q12Shape49T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 573 q12Shape49T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 (573 ||| 2^10) q12Shape49T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (450 ||| 2^10) 573 q12Shape49T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T40OK,q12Shape49T43OK⟩

private def q12Shape49T44 : Tree 12 := (.tip (.cover {1,2,3,5,6,7,8}))
private theorem q12Shape49T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 962 61 q12Shape49T44=true := by decide

private def q12Shape49T38 : Tree 12 := .split 9 q12Shape49T39 q12Shape49T44
private theorem q12Shape49T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 61 q12Shape49T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 (61 ||| 2^9) q12Shape49T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (450 ||| 2^9) 61 q12Shape49T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T39OK,q12Shape49T44OK⟩

private def q12Shape49T45 : Tree 12 := (.tip (.cover {0,1,2,3,5,6,7}))
private theorem q12Shape49T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 482 29 q12Shape49T45=true := by decide

private def q12Shape49T37 : Tree 12 := .split 5 q12Shape49T38 q12Shape49T45
private theorem q12Shape49T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 29 q12Shape49T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 (29 ||| 2^5) q12Shape49T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (450 ||| 2^5) 29 q12Shape49T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T38OK,q12Shape49T45OK⟩

private def q12Shape49T46 : Tree 12 := (.tip (.cover {0,1,2,3,5,6,8}))
private theorem q12Shape49T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 466 13 q12Shape49T46=true := by decide

private def q12Shape49T36 : Tree 12 := .split 4 q12Shape49T37 q12Shape49T46
private theorem q12Shape49T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 13 q12Shape49T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 (13 ||| 2^4) q12Shape49T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (450 ||| 2^4) 13 q12Shape49T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T37OK,q12Shape49T46OK⟩

private def q12Shape49T47 : Tree 12 := (.tip (.cover {0,1,2,3,5,7,8}))
private theorem q12Shape49T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 458 5 q12Shape49T47=true := by decide

private def q12Shape49T35 : Tree 12 := .split 3 q12Shape49T36 q12Shape49T47
private theorem q12Shape49T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 5 q12Shape49T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 (5 ||| 2^3) q12Shape49T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (450 ||| 2^3) 5 q12Shape49T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T36OK,q12Shape49T47OK⟩

private def q12Shape49T48 : Tree 12 := (.tip (.cover {0,1,2,3,6,7,8}))
private theorem q12Shape49T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 454 1 q12Shape49T48=true := by decide

private def q12Shape49T34 : Tree 12 := .split 2 q12Shape49T35 q12Shape49T48
private theorem q12Shape49T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 1 q12Shape49T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 450 (1 ||| 2^2) q12Shape49T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (450 ||| 2^2) 1 q12Shape49T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T35OK,q12Shape49T48OK⟩

private def q12Shape49T6 : Tree 12 := .split 1 q12Shape49T7 q12Shape49T34
private theorem q12Shape49T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 1 q12Shape49T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (1 ||| 2^1) q12Shape49T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^1) 1 q12Shape49T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T7OK,q12Shape49T34OK⟩

private def q12Shape49T57 : Tree 12 := (.split 12 (.split 13 (.split 17 (.split 18 (.split 19 (.split 20 (.split 24 (.tip (.cover {0,2,7,8,9,10,11})) (.tip (.cover {0,1,2,4,5,7,8}))) (.tip (.cover {0,1,2,4,5,6,7}))) (.tip (.cover {0,1,2,4,5,6,8}))) (.tip (.cover {0,1,2,4,5,7,8}))) (.tip (.cover {0,1,2,4,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8}))) (.tip (.cover {1,2,4,5,6,7,8})))
private theorem q12Shape49T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 3646 q12Shape49T57=true := by decide

private def q12Shape49T58 : Tree 12 := (.tip (.cover {1,2,4,5,6,7,8}))
private theorem q12Shape49T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 2497 1598 q12Shape49T58=true := by decide

private def q12Shape49T56 : Tree 12 := .split 11 q12Shape49T57 q12Shape49T58
private theorem q12Shape49T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 1598 q12Shape49T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (1598 ||| 2^11) q12Shape49T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^11) 1598 q12Shape49T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T57OK,q12Shape49T58OK⟩

private def q12Shape49T59 : Tree 12 := (.tip (.cover {1,2,4,5,6,7,8}))
private theorem q12Shape49T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 1473 574 q12Shape49T59=true := by decide

private def q12Shape49T55 : Tree 12 := .split 10 q12Shape49T56 q12Shape49T59
private theorem q12Shape49T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 574 q12Shape49T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (574 ||| 2^10) q12Shape49T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^10) 574 q12Shape49T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T56OK,q12Shape49T59OK⟩

private def q12Shape49T60 : Tree 12 := (.tip (.cover {1,2,4,5,6,7,8}))
private theorem q12Shape49T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 961 62 q12Shape49T60=true := by decide

private def q12Shape49T54 : Tree 12 := .split 9 q12Shape49T55 q12Shape49T60
private theorem q12Shape49T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 62 q12Shape49T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (62 ||| 2^9) q12Shape49T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^9) 62 q12Shape49T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T55OK,q12Shape49T60OK⟩

private def q12Shape49T61 : Tree 12 := (.tip (.cover {0,1,2,4,5,6,7}))
private theorem q12Shape49T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 481 30 q12Shape49T61=true := by decide

private def q12Shape49T53 : Tree 12 := .split 5 q12Shape49T54 q12Shape49T61
private theorem q12Shape49T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 30 q12Shape49T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (30 ||| 2^5) q12Shape49T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^5) 30 q12Shape49T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T54OK,q12Shape49T61OK⟩

private def q12Shape49T62 : Tree 12 := (.tip (.cover {0,1,2,4,5,6,8}))
private theorem q12Shape49T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 465 14 q12Shape49T62=true := by decide

private def q12Shape49T52 : Tree 12 := .split 4 q12Shape49T53 q12Shape49T62
private theorem q12Shape49T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 14 q12Shape49T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (14 ||| 2^4) q12Shape49T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^4) 14 q12Shape49T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T53OK,q12Shape49T62OK⟩

private def q12Shape49T63 : Tree 12 := (.tip (.cover {0,1,2,4,5,7,8}))
private theorem q12Shape49T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 457 6 q12Shape49T63=true := by decide

private def q12Shape49T51 : Tree 12 := .split 3 q12Shape49T52 q12Shape49T63
private theorem q12Shape49T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 6 q12Shape49T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (6 ||| 2^3) q12Shape49T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^3) 6 q12Shape49T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T52OK,q12Shape49T63OK⟩

private def q12Shape49T64 : Tree 12 := (.tip (.cover {0,1,2,4,6,7,8}))
private theorem q12Shape49T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 453 2 q12Shape49T64=true := by decide

private def q12Shape49T50 : Tree 12 := .split 2 q12Shape49T51 q12Shape49T64
private theorem q12Shape49T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 2 q12Shape49T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (2 ||| 2^2) q12Shape49T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^2) 2 q12Shape49T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T51OK,q12Shape49T64OK⟩

private def q12Shape49T65 : Tree 12 := (.tip (.cover {0,1,2,5,6,7,8}))
private theorem q12Shape49T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 451 0 q12Shape49T65=true := by decide

private def q12Shape49T49 : Tree 12 := .split 1 q12Shape49T50 q12Shape49T65
private theorem q12Shape49T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 0 q12Shape49T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 449 (0 ||| 2^1) q12Shape49T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (449 ||| 2^1) 0 q12Shape49T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T50OK,q12Shape49T65OK⟩

private def q12Shape49T5 : Tree 12 := .split 0 q12Shape49T6 q12Shape49T49
private theorem q12Shape49T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 0 q12Shape49T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 448 (0 ||| 2^0) q12Shape49T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (448 ||| 2^0) 0 q12Shape49T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T6OK,q12Shape49T49OK⟩

private def q12Shape49T3 : Tree 12 := .split 8 q12Shape49T4 q12Shape49T5
private theorem q12Shape49T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 192 0 q12Shape49T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 192 (0 ||| 2^8) q12Shape49T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (192 ||| 2^8) 0 q12Shape49T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T4OK,q12Shape49T5OK⟩

private def q12Shape49T1 : Tree 12 := .split 7 q12Shape49T2 q12Shape49T3
private theorem q12Shape49T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 64 0 q12Shape49T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 64 (0 ||| 2^7) q12Shape49T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) (64 ||| 2^7) 0 q12Shape49T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape49T2OK,q12Shape49T3OK⟩

def q12Shape49P1 : Tree 12 := q12Shape49T1
theorem q12Shape49P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,1⟩) 64 0 q12Shape49P1=true := q12Shape49T1OK

end Graffiti384b.EffectiveSearch.Q12
