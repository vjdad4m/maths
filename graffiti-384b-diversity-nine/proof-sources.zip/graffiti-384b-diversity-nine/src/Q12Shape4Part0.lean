import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape4T1 : Tree 12 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))))
private theorem q12Shape4T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 7 q12Shape4T1=true := by decide

private def q12Shape4T3 : Tree 12 := (.split 10 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))))
private theorem q12Shape4T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 4 515 q12Shape4T3=true := by decide

private def q12Shape4T5 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))
private theorem q12Shape4T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 516 1027 q12Shape4T5=true := by decide

private def q12Shape4T7 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))
private theorem q12Shape4T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1540 131075 q12Shape4T7=true := by decide

private def q12Shape4T9 : Tree 12 := (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape4T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132612 11 q12Shape4T9=true := by decide

private def q12Shape4T10 : Tree 12 := (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover {1,3,6,8,9,10,11}))) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132620 3 q12Shape4T10=true := by decide

private def q12Shape4T8 : Tree 12 := .split 3 q12Shape4T9 q12Shape4T10
private theorem q12Shape4T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132612 3 q12Shape4T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132612 (3 ||| 2^3) q12Shape4T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132612 ||| 2^3) 3 q12Shape4T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T9OK,q12Shape4T10OK⟩

private def q12Shape4T6 : Tree 12 := .split 17 q12Shape4T7 q12Shape4T8
private theorem q12Shape4T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1540 3 q12Shape4T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1540 (3 ||| 2^17) q12Shape4T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1540 ||| 2^17) 3 q12Shape4T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T7OK,q12Shape4T8OK⟩

private def q12Shape4T4 : Tree 12 := .split 10 q12Shape4T5 q12Shape4T6
private theorem q12Shape4T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 516 3 q12Shape4T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 516 (3 ||| 2^10) q12Shape4T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (516 ||| 2^10) 3 q12Shape4T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T5OK,q12Shape4T6OK⟩

private def q12Shape4T2 : Tree 12 := .split 9 q12Shape4T3 q12Shape4T4
private theorem q12Shape4T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 4 3 q12Shape4T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 4 (3 ||| 2^9) q12Shape4T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (4 ||| 2^9) 3 q12Shape4T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T3OK,q12Shape4T4OK⟩

private def q12Shape4T0 : Tree 12 := .split 2 q12Shape4T1 q12Shape4T2
private theorem q12Shape4T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 3 q12Shape4T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 (3 ||| 2^2) q12Shape4T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (0 ||| 2^2) 3 q12Shape4T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T1OK,q12Shape4T2OK⟩

def q12Shape4P0 : Tree 12 := q12Shape4T0
theorem q12Shape4P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 0 3 q12Shape4P0=true := q12Shape4T0OK

end Graffiti384b.EffectiveSearch.Q12
