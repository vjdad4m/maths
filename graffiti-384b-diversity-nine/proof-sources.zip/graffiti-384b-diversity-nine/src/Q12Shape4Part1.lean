import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape4T13 : Tree 12 := (.split 10 (.tip (.small 0)) (.split 17 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))))
private theorem q12Shape4T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 2 517 q12Shape4T13=true := by decide

private def q12Shape4T15 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))
private theorem q12Shape4T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 514 1029 q12Shape4T15=true := by decide

private def q12Shape4T17 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))
private theorem q12Shape4T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1538 131077 q12Shape4T17=true := by decide

private def q12Shape4T19 : Tree 12 := (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape4T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132610 13 q12Shape4T19=true := by decide

private def q12Shape4T20 : Tree 12 := (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover {1,3,6,8,9,10,11}))) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132618 5 q12Shape4T20=true := by decide

private def q12Shape4T18 : Tree 12 := .split 3 q12Shape4T19 q12Shape4T20
private theorem q12Shape4T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132610 5 q12Shape4T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132610 (5 ||| 2^3) q12Shape4T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132610 ||| 2^3) 5 q12Shape4T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T19OK,q12Shape4T20OK⟩

private def q12Shape4T16 : Tree 12 := .split 17 q12Shape4T17 q12Shape4T18
private theorem q12Shape4T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1538 5 q12Shape4T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1538 (5 ||| 2^17) q12Shape4T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1538 ||| 2^17) 5 q12Shape4T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T17OK,q12Shape4T18OK⟩

private def q12Shape4T14 : Tree 12 := .split 10 q12Shape4T15 q12Shape4T16
private theorem q12Shape4T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 514 5 q12Shape4T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 514 (5 ||| 2^10) q12Shape4T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (514 ||| 2^10) 5 q12Shape4T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T15OK,q12Shape4T16OK⟩

private def q12Shape4T12 : Tree 12 := .split 9 q12Shape4T13 q12Shape4T14
private theorem q12Shape4T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 2 5 q12Shape4T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 2 (5 ||| 2^9) q12Shape4T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (2 ||| 2^9) 5 q12Shape4T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T13OK,q12Shape4T14OK⟩

private def q12Shape4T23 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))
private theorem q12Shape4T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 6 1537 q12Shape4T23=true := by decide

private def q12Shape4T25 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))
private theorem q12Shape4T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1030 131585 q12Shape4T25=true := by decide

private def q12Shape4T27 : Tree 12 := (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.split 11 (.tip (.small 0)) (.tip (.cover {1,2,6,8,9,10,11}))))
private theorem q12Shape4T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132102 521 q12Shape4T27=true := by decide

private def q12Shape4T28 : Tree 12 := (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover {0,2,7,8,9,10,11}))) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132110 513 q12Shape4T28=true := by decide

private def q12Shape4T26 : Tree 12 := .split 3 q12Shape4T27 q12Shape4T28
private theorem q12Shape4T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132102 513 q12Shape4T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132102 (513 ||| 2^3) q12Shape4T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132102 ||| 2^3) 513 q12Shape4T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T27OK,q12Shape4T28OK⟩

private def q12Shape4T24 : Tree 12 := .split 17 q12Shape4T25 q12Shape4T26
private theorem q12Shape4T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1030 513 q12Shape4T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1030 (513 ||| 2^17) q12Shape4T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1030 ||| 2^17) 513 q12Shape4T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T25OK,q12Shape4T26OK⟩

private def q12Shape4T22 : Tree 12 := .split 10 q12Shape4T23 q12Shape4T24
private theorem q12Shape4T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 6 513 q12Shape4T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 6 (513 ||| 2^10) q12Shape4T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (6 ||| 2^10) 513 q12Shape4T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T23OK,q12Shape4T24OK⟩

private def q12Shape4T31 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))
private theorem q12Shape4T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 518 132097 q12Shape4T31=true := by decide

private def q12Shape4T33 : Tree 12 := (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.split 11 (.tip (.small 0)) (.tip (.cover {1,2,6,8,9,10,11}))))
private theorem q12Shape4T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131590 1033 q12Shape4T33=true := by decide

private def q12Shape4T34 : Tree 12 := (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover {0,2,7,8,9,10,11}))) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131598 1025 q12Shape4T34=true := by decide

private def q12Shape4T32 : Tree 12 := .split 3 q12Shape4T33 q12Shape4T34
private theorem q12Shape4T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131590 1025 q12Shape4T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131590 (1025 ||| 2^3) q12Shape4T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (131590 ||| 2^3) 1025 q12Shape4T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T33OK,q12Shape4T34OK⟩

private def q12Shape4T30 : Tree 12 := .split 17 q12Shape4T31 q12Shape4T32
private theorem q12Shape4T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 518 1025 q12Shape4T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 518 (1025 ||| 2^17) q12Shape4T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (518 ||| 2^17) 1025 q12Shape4T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T31OK,q12Shape4T32OK⟩

private def q12Shape4T37 : Tree 12 := (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape4T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1542 131081 q12Shape4T37=true := by decide

private def q12Shape4T38 : Tree 12 := (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {2,3,7,8,9,10,11}))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1550 131073 q12Shape4T38=true := by decide

private def q12Shape4T36 : Tree 12 := .split 3 q12Shape4T37 q12Shape4T38
private theorem q12Shape4T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1542 131073 q12Shape4T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1542 (131073 ||| 2^3) q12Shape4T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1542 ||| 2^3) 131073 q12Shape4T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T37OK,q12Shape4T38OK⟩

private def q12Shape4T41 : Tree 12 := (.split 11 (.split 12 (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 12 (.split 18 (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11}))))
private theorem q12Shape4T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132614 25 q12Shape4T41=true := by decide

private def q12Shape4T42 : Tree 12 := (.split 11 (.split 12 (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {2,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11})))
private theorem q12Shape4T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132630 9 q12Shape4T42=true := by decide

private def q12Shape4T40 : Tree 12 := .split 4 q12Shape4T41 q12Shape4T42
private theorem q12Shape4T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132614 9 q12Shape4T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132614 (9 ||| 2^4) q12Shape4T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132614 ||| 2^4) 9 q12Shape4T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T41OK,q12Shape4T42OK⟩

private def q12Shape4T43 : Tree 12 := (.split 4 (.split 11 (.split 12 (.split 18 (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))) (.tip (.cover {2,3,7,8,9,10,11}))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132622 1 q12Shape4T43=true := by decide

private def q12Shape4T39 : Tree 12 := .split 3 q12Shape4T40 q12Shape4T43
private theorem q12Shape4T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132614 1 q12Shape4T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132614 (1 ||| 2^3) q12Shape4T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132614 ||| 2^3) 1 q12Shape4T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T40OK,q12Shape4T43OK⟩

private def q12Shape4T35 : Tree 12 := .split 17 q12Shape4T36 q12Shape4T39
private theorem q12Shape4T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1542 1 q12Shape4T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1542 (1 ||| 2^17) q12Shape4T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1542 ||| 2^17) 1 q12Shape4T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T36OK,q12Shape4T39OK⟩

private def q12Shape4T29 : Tree 12 := .split 10 q12Shape4T30 q12Shape4T35
private theorem q12Shape4T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 518 1 q12Shape4T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 518 (1 ||| 2^10) q12Shape4T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (518 ||| 2^10) 1 q12Shape4T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T30OK,q12Shape4T35OK⟩

private def q12Shape4T21 : Tree 12 := .split 9 q12Shape4T22 q12Shape4T29
private theorem q12Shape4T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 6 1 q12Shape4T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 6 (1 ||| 2^9) q12Shape4T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (6 ||| 2^9) 1 q12Shape4T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T22OK,q12Shape4T29OK⟩

private def q12Shape4T11 : Tree 12 := .split 2 q12Shape4T12 q12Shape4T21
private theorem q12Shape4T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 2 1 q12Shape4T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 2 (1 ||| 2^2) q12Shape4T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (2 ||| 2^2) 1 q12Shape4T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T12OK,q12Shape4T21OK⟩

def q12Shape4P1 : Tree 12 := q12Shape4T11
theorem q12Shape4P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 2 1 q12Shape4P1=true := q12Shape4T11OK

end Graffiti384b.EffectiveSearch.Q12
