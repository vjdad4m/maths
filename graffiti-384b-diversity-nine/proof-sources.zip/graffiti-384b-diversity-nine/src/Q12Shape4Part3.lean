import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape4T76 : Tree 12 := (.split 17 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11})))))
private theorem q12Shape4T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 1540 q12Shape4T76=true := by decide

private def q12Shape4T78 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))
private theorem q12Shape4T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1027 131588 q12Shape4T78=true := by decide

private def q12Shape4T80 : Tree 12 := (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.split 11 (.tip (.small 0)) (.split 12 (.split 18 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))))
private theorem q12Shape4T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132099 524 q12Shape4T80=true := by decide

private def q12Shape4T81 : Tree 12 := (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132107 516 q12Shape4T81=true := by decide

private def q12Shape4T79 : Tree 12 := .split 3 q12Shape4T80 q12Shape4T81
private theorem q12Shape4T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132099 516 q12Shape4T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132099 (516 ||| 2^3) q12Shape4T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132099 ||| 2^3) 516 q12Shape4T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T80OK,q12Shape4T81OK⟩

private def q12Shape4T77 : Tree 12 := .split 17 q12Shape4T78 q12Shape4T79
private theorem q12Shape4T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1027 516 q12Shape4T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1027 (516 ||| 2^17) q12Shape4T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1027 ||| 2^17) 516 q12Shape4T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T78OK,q12Shape4T79OK⟩

private def q12Shape4T75 : Tree 12 := .split 10 q12Shape4T76 q12Shape4T77
private theorem q12Shape4T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 516 q12Shape4T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 (516 ||| 2^10) q12Shape4T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (3 ||| 2^10) 516 q12Shape4T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T76OK,q12Shape4T77OK⟩

private def q12Shape4T84 : Tree 12 := (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10,11}))))
private theorem q12Shape4T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 515 132100 q12Shape4T84=true := by decide

private def q12Shape4T86 : Tree 12 := (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.split 11 (.tip (.small 0)) (.split 12 (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))))
private theorem q12Shape4T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131587 1036 q12Shape4T86=true := by decide

private def q12Shape4T87 : Tree 12 := (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131595 1028 q12Shape4T87=true := by decide

private def q12Shape4T85 : Tree 12 := .split 3 q12Shape4T86 q12Shape4T87
private theorem q12Shape4T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131587 1028 q12Shape4T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131587 (1028 ||| 2^3) q12Shape4T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (131587 ||| 2^3) 1028 q12Shape4T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T86OK,q12Shape4T87OK⟩

private def q12Shape4T83 : Tree 12 := .split 17 q12Shape4T84 q12Shape4T85
private theorem q12Shape4T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 515 1028 q12Shape4T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 515 (1028 ||| 2^17) q12Shape4T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (515 ||| 2^17) 1028 q12Shape4T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T84OK,q12Shape4T85OK⟩

private def q12Shape4T89 : Tree 12 := (.split 3 (.split 4 (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11}))) (.split 11 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10,11})))) (.split 4 (.split 11 (.split 12 (.tip (.small 1)) (.tip (.cover {1,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {0,1,2,8,9,10,11}))))
private theorem q12Shape4T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1539 131076 q12Shape4T89=true := by decide

private def q12Shape4T91 : Tree 12 := (.split 4 (.split 11 (.split 12 (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {1,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))) (.split 11 (.split 12 (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {1,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))))
private theorem q12Shape4T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132611 12 q12Shape4T91=true := by decide

private def q12Shape4T92 : Tree 12 := (.split 4 (.split 11 (.split 12 (.split 18 (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {1,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {0,1,2,8,9,10,11})))
private theorem q12Shape4T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132619 4 q12Shape4T92=true := by decide

private def q12Shape4T90 : Tree 12 := .split 3 q12Shape4T91 q12Shape4T92
private theorem q12Shape4T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132611 4 q12Shape4T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132611 (4 ||| 2^3) q12Shape4T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132611 ||| 2^3) 4 q12Shape4T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T91OK,q12Shape4T92OK⟩

private def q12Shape4T88 : Tree 12 := .split 17 q12Shape4T89 q12Shape4T90
private theorem q12Shape4T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1539 4 q12Shape4T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1539 (4 ||| 2^17) q12Shape4T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1539 ||| 2^17) 4 q12Shape4T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T89OK,q12Shape4T90OK⟩

private def q12Shape4T82 : Tree 12 := .split 10 q12Shape4T83 q12Shape4T88
private theorem q12Shape4T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 515 4 q12Shape4T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 515 (4 ||| 2^10) q12Shape4T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (515 ||| 2^10) 4 q12Shape4T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T83OK,q12Shape4T88OK⟩

private def q12Shape4T74 : Tree 12 := .split 9 q12Shape4T75 q12Shape4T82
private theorem q12Shape4T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 4 q12Shape4T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 (4 ||| 2^9) q12Shape4T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (3 ||| 2^9) 4 q12Shape4T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T75OK,q12Shape4T82OK⟩

def q12Shape4P3 : Tree 12 := q12Shape4T74
theorem q12Shape4P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 3 4 q12Shape4P3=true := q12Shape4T74OK

end Graffiti384b.EffectiveSearch.Q12
