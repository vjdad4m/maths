import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape4T95 : Tree 12 := (.split 17 (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10,11}))) (.split 3 (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {1,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11}))))
private theorem q12Shape4T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 7 1536 q12Shape4T95=true := by decide

private def q12Shape4T97 : Tree 12 := (.split 3 (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {1,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape4T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1031 131584 q12Shape4T97=true := by decide

private def q12Shape4T101 : Tree 12 := (.split 12 (.split 18 (.tip (.small 0)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,8,9,10,11})))) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))))
private theorem q12Shape4T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132103 2584 q12Shape4T101=true := by decide

private def q12Shape4T102 : Tree 12 := (.split 12 (.split 18 (.split 19 (.tip (.small 1)) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {3,4,7,8,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11})))
private theorem q12Shape4T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 134151 536 q12Shape4T102=true := by decide

private def q12Shape4T100 : Tree 12 := .split 11 q12Shape4T101 q12Shape4T102
private theorem q12Shape4T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132103 536 q12Shape4T100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132103 (536 ||| 2^11) q12Shape4T101 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132103 ||| 2^11) 536 q12Shape4T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T101OK,q12Shape4T102OK⟩

private def q12Shape4T103 : Tree 12 := (.tip (.cover {1,2,6,8,9,10,11}))
private theorem q12Shape4T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132119 520 q12Shape4T103=true := by decide

private def q12Shape4T99 : Tree 12 := .split 4 q12Shape4T100 q12Shape4T103
private theorem q12Shape4T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132103 520 q12Shape4T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132103 (520 ||| 2^4) q12Shape4T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132103 ||| 2^4) 520 q12Shape4T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T100OK,q12Shape4T103OK⟩

private def q12Shape4T104 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape4T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132111 512 q12Shape4T104=true := by decide

private def q12Shape4T98 : Tree 12 := .split 3 q12Shape4T99 q12Shape4T104
private theorem q12Shape4T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132103 512 q12Shape4T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132103 (512 ||| 2^3) q12Shape4T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (132103 ||| 2^3) 512 q12Shape4T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T99OK,q12Shape4T104OK⟩

private def q12Shape4T96 : Tree 12 := .split 17 q12Shape4T97 q12Shape4T98
private theorem q12Shape4T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1031 512 q12Shape4T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1031 (512 ||| 2^17) q12Shape4T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1031 ||| 2^17) 512 q12Shape4T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T97OK,q12Shape4T98OK⟩

private def q12Shape4T94 : Tree 12 := .split 10 q12Shape4T95 q12Shape4T96
private theorem q12Shape4T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 7 512 q12Shape4T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 7 (512 ||| 2^10) q12Shape4T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (7 ||| 2^10) 512 q12Shape4T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T95OK,q12Shape4T96OK⟩

private def q12Shape4T107 : Tree 12 := (.split 3 (.split 4 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10,11})))) (.tip (.cover {1,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape4T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 519 132096 q12Shape4T107=true := by decide

private def q12Shape4T110 : Tree 12 := (.split 11 (.split 12 (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11}))) (.split 18 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10,11})))) (.split 12 (.split 18 (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,8,9,10,11}))) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {0,1,3,8,9,10,11}))))
private theorem q12Shape4T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131591 1048 q12Shape4T110=true := by decide

private def q12Shape4T111 : Tree 12 := (.tip (.cover {1,2,6,8,9,10,11}))
private theorem q12Shape4T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131607 1032 q12Shape4T111=true := by decide

private def q12Shape4T109 : Tree 12 := .split 4 q12Shape4T110 q12Shape4T111
private theorem q12Shape4T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131591 1032 q12Shape4T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131591 (1032 ||| 2^4) q12Shape4T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (131591 ||| 2^4) 1032 q12Shape4T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T110OK,q12Shape4T111OK⟩

private def q12Shape4T112 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape4T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131599 1024 q12Shape4T112=true := by decide

private def q12Shape4T108 : Tree 12 := .split 3 q12Shape4T109 q12Shape4T112
private theorem q12Shape4T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131591 1024 q12Shape4T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 131591 (1024 ||| 2^3) q12Shape4T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (131591 ||| 2^3) 1024 q12Shape4T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T109OK,q12Shape4T112OK⟩

private def q12Shape4T106 : Tree 12 := .split 17 q12Shape4T107 q12Shape4T108
private theorem q12Shape4T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 519 1024 q12Shape4T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 519 (1024 ||| 2^17) q12Shape4T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (519 ||| 2^17) 1024 q12Shape4T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T107OK,q12Shape4T108OK⟩

private def q12Shape4T114 : Tree 12 := (.split 3 (.split 4 (.split 11 (.split 12 (.split 18 (.tip (.small 0)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,8,9,10,11})))) (.tip (.cover {1,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {1,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape4T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1543 131072 q12Shape4T114=true := by decide

private def q12Shape4T115 : Tree 12 := (.split 3 (.split 4 (.split 11 (.split 12 (.split 18 (.tip (.cover {0,5,7,8,9,10,11})) (.tip (.cover {0,4,7,8,9,10,11}))) (.tip (.cover {1,3,6,8,9,10,11}))) (.tip (.cover {0,3,7,8,9,10,11}))) (.tip (.cover {1,2,6,8,9,10,11}))) (.tip (.cover {0,2,7,8,9,10,11})))
private theorem q12Shape4T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 132615 0 q12Shape4T115=true := by decide

private def q12Shape4T113 : Tree 12 := .split 17 q12Shape4T114 q12Shape4T115
private theorem q12Shape4T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1543 0 q12Shape4T113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 1543 (0 ||| 2^17) q12Shape4T114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (1543 ||| 2^17) 0 q12Shape4T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T114OK,q12Shape4T115OK⟩

private def q12Shape4T105 : Tree 12 := .split 10 q12Shape4T106 q12Shape4T113
private theorem q12Shape4T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 519 0 q12Shape4T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 519 (0 ||| 2^10) q12Shape4T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (519 ||| 2^10) 0 q12Shape4T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T106OK,q12Shape4T113OK⟩

private def q12Shape4T93 : Tree 12 := .split 9 q12Shape4T94 q12Shape4T105
private theorem q12Shape4T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 7 0 q12Shape4T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 7 (0 ||| 2^9) q12Shape4T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) (7 ||| 2^9) 0 q12Shape4T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape4T94OK,q12Shape4T105OK⟩

def q12Shape4P4 : Tree 12 := q12Shape4T93
theorem q12Shape4P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,5,5,4⟩) 7 0 q12Shape4P4=true := q12Shape4T93OK

end Graffiti384b.EffectiveSearch.Q12
