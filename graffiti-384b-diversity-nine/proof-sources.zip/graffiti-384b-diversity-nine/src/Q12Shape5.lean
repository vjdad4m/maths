import Q12Shape5Part0
import Q12Shape5Part1
import Q12Shape5Part2
import Q12Shape5Part3
import Q12Shape5Part4
import Q12Shape5Part5
import Q12Shape5Part6
import Q12Shape5Part7
import Q12Shape5Part8
import Q12Shape5Part9
import Q12Shape5Part10
import Q12Shape5Part11
import Q12Shape5Part12
import Q12Shape5Part13
import Q12Shape5Part14
import Q12Shape5Part15
import Q12Shape5Part16
import Q12Shape5Part17
import Q12Shape5Part18
import Q12Shape5Part19
import Q12Shape5Part20
import Q12Shape5Part21
import Q12Shape5Part22
import Q12Shape5Part23
import Q12Shape5Part24
import Q12Shape5Part25
import Q12Shape5Part26
import Q12Shape5Part27
import Q12Shape5Part28
import Q12Shape5Part29
import Q12Shape5Part30

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5M67 : Tree 12 := .split 19 q12Shape5P1 q12Shape5P2
private theorem q12Shape5M67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262144 138752 q12Shape5M67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262144 (138752 ||| 2^19) q12Shape5P1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (262144 ||| 2^19) 138752 q12Shape5P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P1OK,q12Shape5P2OK⟩
private def q12Shape5M68 : Tree 12 := .split 18 q12Shape5P0 q12Shape5M67
private theorem q12Shape5M68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 138752 q12Shape5M68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 (138752 ||| 2^18) q12Shape5P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (0 ||| 2^18) 138752 q12Shape5M67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P0OK,q12Shape5M67OK⟩
private def q12Shape5M113 : Tree 12 := .split 19 q12Shape5P3 q12Shape5P4
private theorem q12Shape5M113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131072 269824 q12Shape5M113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131072 (269824 ||| 2^19) q12Shape5P3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (131072 ||| 2^19) 269824 q12Shape5P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P3OK,q12Shape5P4OK⟩
private def q12Shape5M137 : Tree 12 := .split 18 q12Shape5M113 q12Shape5P5
private theorem q12Shape5M137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131072 7680 q12Shape5M137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131072 (7680 ||| 2^18) q12Shape5M113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (131072 ||| 2^18) 7680 q12Shape5P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M113OK,q12Shape5P5OK⟩
private def q12Shape5M138 : Tree 12 := .split 17 q12Shape5M68 q12Shape5M137
private theorem q12Shape5M138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 7680 q12Shape5M138=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 (7680 ||| 2^17) q12Shape5M68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (0 ||| 2^17) 7680 q12Shape5M137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M68OK,q12Shape5M137OK⟩
private def q12Shape5M189 : Tree 12 := .split 18 q12Shape5P6 q12Shape5P7
private theorem q12Shape5M189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 134656 q12Shape5M189=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 (134656 ||| 2^18) q12Shape5P6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4096 ||| 2^18) 134656 q12Shape5P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P6OK,q12Shape5P7OK⟩
private def q12Shape5M221 : Tree 12 := .split 17 q12Shape5M189 q12Shape5P8
private theorem q12Shape5M221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 3584 q12Shape5M221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 (3584 ||| 2^17) q12Shape5M189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4096 ||| 2^17) 3584 q12Shape5P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M189OK,q12Shape5P8OK⟩
private def q12Shape5M222 : Tree 12 := .split 12 q12Shape5M138 q12Shape5M221
private theorem q12Shape5M222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 3584 q12Shape5M222=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 (3584 ||| 2^12) q12Shape5M138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (0 ||| 2^12) 3584 q12Shape5M221)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M138OK,q12Shape5M221OK⟩
private def q12Shape5M259 : Tree 12 := .split 19 q12Shape5P9 q12Shape5P10
private theorem q12Shape5M259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 398848 q12Shape5M259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 (398848 ||| 2^19) q12Shape5P9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2048 ||| 2^19) 398848 q12Shape5P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P9OK,q12Shape5P10OK⟩
private def q12Shape5M273 : Tree 12 := .split 18 q12Shape5M259 q12Shape5P11
private theorem q12Shape5M273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 136704 q12Shape5M273=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 (136704 ||| 2^18) q12Shape5M259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2048 ||| 2^18) 136704 q12Shape5P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M259OK,q12Shape5P11OK⟩
private def q12Shape5M309 : Tree 12 := .split 17 q12Shape5M273 q12Shape5P12
private theorem q12Shape5M309OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 5632 q12Shape5M309=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 (5632 ||| 2^17) q12Shape5M273 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2048 ||| 2^17) 5632 q12Shape5P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M273OK,q12Shape5P12OK⟩
private def q12Shape5M368 : Tree 12 := .split 18 q12Shape5P13 q12Shape5P14
private theorem q12Shape5M368OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 6144 132608 q12Shape5M368=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 6144 (132608 ||| 2^18) q12Shape5P13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (6144 ||| 2^18) 132608 q12Shape5P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P13OK,q12Shape5P14OK⟩
private def q12Shape5M370 : Tree 12 := .split 17 q12Shape5M368 q12Shape5P15
private theorem q12Shape5M370OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 6144 1536 q12Shape5M370=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 6144 (1536 ||| 2^17) q12Shape5M368 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (6144 ||| 2^17) 1536 q12Shape5P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M368OK,q12Shape5P15OK⟩
private def q12Shape5M371 : Tree 12 := .split 12 q12Shape5M309 q12Shape5M370
private theorem q12Shape5M371OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 1536 q12Shape5M371=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 (1536 ||| 2^12) q12Shape5M309 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2048 ||| 2^12) 1536 q12Shape5M370)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M309OK,q12Shape5M370OK⟩
private def q12Shape5M372 : Tree 12 := .split 11 q12Shape5M222 q12Shape5M371
private theorem q12Shape5M372OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 1536 q12Shape5M372=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 (1536 ||| 2^11) q12Shape5M222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (0 ||| 2^11) 1536 q12Shape5M371)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M222OK,q12Shape5M371OK⟩
private def q12Shape5M411 : Tree 12 := .split 19 q12Shape5P16 q12Shape5P17
private theorem q12Shape5M411OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 399872 q12Shape5M411=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 (399872 ||| 2^19) q12Shape5P16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1024 ||| 2^19) 399872 q12Shape5P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P16OK,q12Shape5P17OK⟩
private def q12Shape5M433 : Tree 12 := .split 18 q12Shape5M411 q12Shape5P18
private theorem q12Shape5M433OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 137728 q12Shape5M433=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 (137728 ||| 2^18) q12Shape5M411 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1024 ||| 2^18) 137728 q12Shape5P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M411OK,q12Shape5P18OK⟩
private def q12Shape5M461 : Tree 12 := .split 17 q12Shape5M433 q12Shape5P19
private theorem q12Shape5M461OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 6656 q12Shape5M461=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 (6656 ||| 2^17) q12Shape5M433 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1024 ||| 2^17) 6656 q12Shape5P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M433OK,q12Shape5P19OK⟩
private def q12Shape5M524 : Tree 12 := .split 17 q12Shape5P20 q12Shape5P21
private theorem q12Shape5M524OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 2560 q12Shape5M524=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 (2560 ||| 2^17) q12Shape5P20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (5120 ||| 2^17) 2560 q12Shape5P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P20OK,q12Shape5P21OK⟩
private def q12Shape5M525 : Tree 12 := .split 12 q12Shape5M461 q12Shape5M524
private theorem q12Shape5M525OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 2560 q12Shape5M525=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 (2560 ||| 2^12) q12Shape5M461 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1024 ||| 2^12) 2560 q12Shape5M524)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M461OK,q12Shape5M524OK⟩
private def q12Shape5M590 : Tree 12 := .split 17 q12Shape5P22 q12Shape5P23
private theorem q12Shape5M590OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 3072 4608 q12Shape5M590=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 3072 (4608 ||| 2^17) q12Shape5P22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (3072 ||| 2^17) 4608 q12Shape5P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P22OK,q12Shape5P23OK⟩
private def q12Shape5M592 : Tree 12 := .split 12 q12Shape5M590 q12Shape5P24
private theorem q12Shape5M592OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 3072 512 q12Shape5M592=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 3072 (512 ||| 2^12) q12Shape5M590 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (3072 ||| 2^12) 512 q12Shape5P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M590OK,q12Shape5P24OK⟩
private def q12Shape5M593 : Tree 12 := .split 11 q12Shape5M525 q12Shape5M592
private theorem q12Shape5M593OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 512 q12Shape5M593=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 (512 ||| 2^11) q12Shape5M525 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1024 ||| 2^11) 512 q12Shape5M592)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M525OK,q12Shape5M592OK⟩
private def q12Shape5M594 : Tree 12 := .split 10 q12Shape5M372 q12Shape5M593
private theorem q12Shape5M594OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 512 q12Shape5M594=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 (512 ||| 2^10) q12Shape5M372 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (0 ||| 2^10) 512 q12Shape5M593)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M372OK,q12Shape5M593OK⟩
private def q12Shape5M637 : Tree 12 := .split 19 q12Shape5P25 q12Shape5P26
private theorem q12Shape5M637OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 400384 q12Shape5M637=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (400384 ||| 2^19) q12Shape5P25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^19) 400384 q12Shape5P26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P25OK,q12Shape5P26OK⟩
private def q12Shape5M659 : Tree 12 := .split 18 q12Shape5M637 q12Shape5P27
private theorem q12Shape5M659OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 138240 q12Shape5M659=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (138240 ||| 2^18) q12Shape5M637 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^18) 138240 q12Shape5P27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M637OK,q12Shape5P27OK⟩
private def q12Shape5M683 : Tree 12 := .split 17 q12Shape5M659 q12Shape5P28
private theorem q12Shape5M683OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 7168 q12Shape5M683=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (7168 ||| 2^17) q12Shape5M659 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^17) 7168 q12Shape5P28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M659OK,q12Shape5P28OK⟩
private def q12Shape5M742 : Tree 12 := .split 17 q12Shape5P29 q12Shape5P30
private theorem q12Shape5M742OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 3072 q12Shape5M742=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 (3072 ||| 2^17) q12Shape5P29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4608 ||| 2^17) 3072 q12Shape5P30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P29OK,q12Shape5P30OK⟩
private def q12Shape5M743 : Tree 12 := .split 12 q12Shape5M683 q12Shape5M742
private theorem q12Shape5M743OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 3072 q12Shape5M743=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (3072 ||| 2^12) q12Shape5M683 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^12) 3072 q12Shape5M742)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M683OK,q12Shape5M742OK⟩
private def q12Shape5M782 : Tree 12 := .split 18 q12Shape5P31 q12Shape5P32
private theorem q12Shape5M782OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2560 136192 q12Shape5M782=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2560 (136192 ||| 2^18) q12Shape5P31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2560 ||| 2^18) 136192 q12Shape5P32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P31OK,q12Shape5P32OK⟩
private def q12Shape5M806 : Tree 12 := .split 17 q12Shape5M782 q12Shape5P33
private theorem q12Shape5M806OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2560 5120 q12Shape5M806=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2560 (5120 ||| 2^17) q12Shape5M782 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2560 ||| 2^17) 5120 q12Shape5P33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M782OK,q12Shape5P33OK⟩
private def q12Shape5M808 : Tree 12 := .split 12 q12Shape5M806 q12Shape5P34
private theorem q12Shape5M808OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2560 1024 q12Shape5M808=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2560 (1024 ||| 2^12) q12Shape5M806 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2560 ||| 2^12) 1024 q12Shape5P34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M806OK,q12Shape5P34OK⟩
private def q12Shape5M809 : Tree 12 := .split 11 q12Shape5M743 q12Shape5M808
private theorem q12Shape5M809OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 1024 q12Shape5M809=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (1024 ||| 2^11) q12Shape5M743 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^11) 1024 q12Shape5M808)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M743OK,q12Shape5M808OK⟩
private def q12Shape5M868 : Tree 12 := .split 18 q12Shape5P35 q12Shape5P36
private theorem q12Shape5M868OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 137216 q12Shape5M868=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 (137216 ||| 2^18) q12Shape5P35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1536 ||| 2^18) 137216 q12Shape5P36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5P35OK,q12Shape5P36OK⟩
private def q12Shape5M874 : Tree 12 := .split 17 q12Shape5M868 q12Shape5P37
private theorem q12Shape5M874OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 6144 q12Shape5M874=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 (6144 ||| 2^17) q12Shape5M868 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1536 ||| 2^17) 6144 q12Shape5P37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M868OK,q12Shape5P37OK⟩
private def q12Shape5M876 : Tree 12 := .split 12 q12Shape5M874 q12Shape5P38
private theorem q12Shape5M876OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 2048 q12Shape5M876=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 (2048 ||| 2^12) q12Shape5M874 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1536 ||| 2^12) 2048 q12Shape5P38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M874OK,q12Shape5P38OK⟩
private def q12Shape5M878 : Tree 12 := .split 11 q12Shape5M876 q12Shape5P39
private theorem q12Shape5M878OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 0 q12Shape5M878=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 (0 ||| 2^11) q12Shape5M876 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1536 ||| 2^11) 0 q12Shape5P39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M876OK,q12Shape5P39OK⟩
private def q12Shape5M879 : Tree 12 := .split 10 q12Shape5M809 q12Shape5M878
private theorem q12Shape5M879OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 0 q12Shape5M879=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (0 ||| 2^10) q12Shape5M809 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^10) 0 q12Shape5M878)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M809OK,q12Shape5M878OK⟩
private def q12Shape5M880 : Tree 12 := .split 9 q12Shape5M594 q12Shape5M879
private theorem q12Shape5M880OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 0 q12Shape5M880=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 (0 ||| 2^9) q12Shape5M594 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (0 ||| 2^9) 0 q12Shape5M879)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5M594OK,q12Shape5M879OK⟩

theorem q12Shape5_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 5) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 5) b) (adj 12 (forms 5) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) adj_mono b H q12Shape5M880 q12Shape5M880OK

#print axioms q12Shape5_cover

end Graffiti384b.EffectiveSearch.Q12
