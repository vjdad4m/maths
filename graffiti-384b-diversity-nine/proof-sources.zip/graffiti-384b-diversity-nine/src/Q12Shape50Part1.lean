import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T27 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))))
private theorem q12Shape50T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 3323854848 q12Shape50T27=true := by decide

private def q12Shape50T28 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))))
private theorem q12Shape50T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2164260864 1176371200 q12Shape50T28=true := by decide

private def q12Shape50T26 : Tree 12 := .split 31 q12Shape50T27 q12Shape50T28
private theorem q12Shape50T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 1176371200 q12Shape50T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 (1176371200 ||| 2^31) q12Shape50T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (16777216 ||| 2^31) 1176371200 q12Shape50T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T27OK,q12Shape50T28OK⟩

private def q12Shape50T29 : Tree 12 := (.split 31 (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11}))))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1090519040 102629376 q12Shape50T29=true := by decide

private def q12Shape50T25 : Tree 12 := .split 30 q12Shape50T26 q12Shape50T29
private theorem q12Shape50T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 102629376 q12Shape50T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 (102629376 ||| 2^30) q12Shape50T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (16777216 ||| 2^30) 102629376 q12Shape50T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T26OK,q12Shape50T29OK⟩

private def q12Shape50T31 : Tree 12 := (.split 31 (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11}))))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape50T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 83886080 1109262336 q12Shape50T31=true := by decide

private def q12Shape50T34 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1157627904 36542742528 q12Shape50T34=true := by decide

private def q12Shape50T35 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35517366272 2183004160 q12Shape50T35=true := by decide

private def q12Shape50T33 : Tree 12 := .split 35 q12Shape50T34 q12Shape50T35
private theorem q12Shape50T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1157627904 2183004160 q12Shape50T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1157627904 (2183004160 ||| 2^35) q12Shape50T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1157627904 ||| 2^35) 2183004160 q12Shape50T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T34OK,q12Shape50T35OK⟩

private def q12Shape50T36 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 3305111552 35520512 q12Shape50T36=true := by decide

private def q12Shape50T32 : Tree 12 := .split 31 q12Shape50T33 q12Shape50T36
private theorem q12Shape50T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1157627904 35520512 q12Shape50T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1157627904 (35520512 ||| 2^31) q12Shape50T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1157627904 ||| 2^31) 35520512 q12Shape50T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T33OK,q12Shape50T36OK⟩

private def q12Shape50T30 : Tree 12 := .split 30 q12Shape50T31 q12Shape50T32
private theorem q12Shape50T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 83886080 35520512 q12Shape50T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 83886080 (35520512 ||| 2^30) q12Shape50T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (83886080 ||| 2^30) 35520512 q12Shape50T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T31OK,q12Shape50T32OK⟩

private def q12Shape50T24 : Tree 12 := .split 26 q12Shape50T25 q12Shape50T30
private theorem q12Shape50T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 35520512 q12Shape50T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 (35520512 ||| 2^26) q12Shape50T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (16777216 ||| 2^26) 35520512 q12Shape50T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T25OK,q12Shape50T30OK⟩

private def q12Shape50T40 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))))
private theorem q12Shape50T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50331648 3290300416 q12Shape50T40=true := by decide

private def q12Shape50T42 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2197815296 35502555136 q12Shape50T42=true := by decide

private def q12Shape50T43 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,8,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 36557553664 1142816768 q12Shape50T43=true := by decide

private def q12Shape50T41 : Tree 12 := .split 35 q12Shape50T42 q12Shape50T43
private theorem q12Shape50T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2197815296 1142816768 q12Shape50T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2197815296 (1142816768 ||| 2^35) q12Shape50T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (2197815296 ||| 2^35) 1142816768 q12Shape50T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T42OK,q12Shape50T43OK⟩

private def q12Shape50T39 : Tree 12 := .split 31 q12Shape50T40 q12Shape50T41
private theorem q12Shape50T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50331648 1142816768 q12Shape50T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50331648 (1142816768 ||| 2^31) q12Shape50T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (50331648 ||| 2^31) 1142816768 q12Shape50T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T40OK,q12Shape50T41OK⟩

private def q12Shape50T44 : Tree 12 := (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1124073472 69074944 q12Shape50T44=true := by decide

private def q12Shape50T38 : Tree 12 := .split 30 q12Shape50T39 q12Shape50T44
private theorem q12Shape50T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50331648 69074944 q12Shape50T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50331648 (69074944 ||| 2^30) q12Shape50T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (50331648 ||| 2^30) 69074944 q12Shape50T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T39OK,q12Shape50T44OK⟩

private def q12Shape50T45 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 117440512 1966080 q12Shape50T45=true := by decide

private def q12Shape50T37 : Tree 12 := .split 26 q12Shape50T38 q12Shape50T45
private theorem q12Shape50T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50331648 1966080 q12Shape50T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50331648 (1966080 ||| 2^26) q12Shape50T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (50331648 ||| 2^26) 1966080 q12Shape50T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T38OK,q12Shape50T45OK⟩

private def q12Shape50T23 : Tree 12 := .split 25 q12Shape50T24 q12Shape50T37
private theorem q12Shape50T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 1966080 q12Shape50T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 (1966080 ||| 2^25) q12Shape50T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (16777216 ||| 2^25) 1966080 q12Shape50T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T24OK,q12Shape50T37OK⟩

def q12Shape50P1 : Tree 12 := q12Shape50T23
theorem q12Shape50P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 16777216 1966080 q12Shape50P1=true := q12Shape50T23OK

end Graffiti384b.EffectiveSearch.Q12
