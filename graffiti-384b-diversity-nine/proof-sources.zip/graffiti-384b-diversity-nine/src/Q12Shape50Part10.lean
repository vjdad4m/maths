import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T273 : Tree 12 := (.split 31 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11})))) (.tip (.cover {0,1,4,6,7,9,11}))))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 1192493056 q12Shape50T273=true := by decide

private def q12Shape50T274 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8,11})))) (.tip (.cover {0,1,4,6,8,9,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074397184 118751232 q12Shape50T274=true := by decide

private def q12Shape50T272 : Tree 12 := .split 30 q12Shape50T273 q12Shape50T274
private theorem q12Shape50T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 118751232 q12Shape50T272=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 (118751232 ||| 2^30) q12Shape50T273 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (655360 ||| 2^30) 118751232 q12Shape50T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T273OK,q12Shape50T274OK⟩

private def q12Shape50T278 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67764224 37632606208 q12Shape50T278=true := by decide

private def q12Shape50T279 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,6,8,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34427502592 3272867840 q12Shape50T279=true := by decide

private def q12Shape50T277 : Tree 12 := .split 35 q12Shape50T278 q12Shape50T279
private theorem q12Shape50T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67764224 3272867840 q12Shape50T277=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67764224 (3272867840 ||| 2^35) q12Shape50T278 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67764224 ||| 2^35) 3272867840 q12Shape50T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T278OK,q12Shape50T279OK⟩

private def q12Shape50T280 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2215247872 1125384192 q12Shape50T280=true := by decide

private def q12Shape50T276 : Tree 12 := .split 31 q12Shape50T277 q12Shape50T280
private theorem q12Shape50T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67764224 1125384192 q12Shape50T276=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67764224 (1125384192 ||| 2^31) q12Shape50T277 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67764224 ||| 2^31) 1125384192 q12Shape50T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T277OK,q12Shape50T280OK⟩

private def q12Shape50T281 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape50T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1141506048 51642368 q12Shape50T281=true := by decide

private def q12Shape50T275 : Tree 12 := .split 30 q12Shape50T276 q12Shape50T281
private theorem q12Shape50T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67764224 51642368 q12Shape50T275=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67764224 (51642368 ||| 2^30) q12Shape50T276 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67764224 ||| 2^30) 51642368 q12Shape50T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T276OK,q12Shape50T281OK⟩

private def q12Shape50T271 : Tree 12 := .split 26 q12Shape50T272 q12Shape50T275
private theorem q12Shape50T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 51642368 q12Shape50T271=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 (51642368 ||| 2^26) q12Shape50T272 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (655360 ||| 2^26) 51642368 q12Shape50T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T272OK,q12Shape50T275OK⟩

private def q12Shape50T282 : Tree 12 := (.split 26 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape50T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34209792 18087936 q12Shape50T282=true := by decide

private def q12Shape50T270 : Tree 12 := .split 25 q12Shape50T271 q12Shape50T282
private theorem q12Shape50T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 18087936 q12Shape50T270=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 (18087936 ||| 2^25) q12Shape50T271 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (655360 ||| 2^25) 18087936 q12Shape50T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T271OK,q12Shape50T282OK⟩

private def q12Shape50T286 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11})))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17432576 1175715840 q12Shape50T286=true := by decide

private def q12Shape50T287 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,6,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1091174400 101974016 q12Shape50T287=true := by decide

private def q12Shape50T285 : Tree 12 := .split 30 q12Shape50T286 q12Shape50T287
private theorem q12Shape50T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17432576 101974016 q12Shape50T285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17432576 (101974016 ||| 2^30) q12Shape50T286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17432576 ||| 2^30) 101974016 q12Shape50T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T286OK,q12Shape50T287OK⟩

private def q12Shape50T288 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84541440 34865152 q12Shape50T288=true := by decide

private def q12Shape50T284 : Tree 12 := .split 26 q12Shape50T285 q12Shape50T288
private theorem q12Shape50T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17432576 34865152 q12Shape50T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17432576 (34865152 ||| 2^26) q12Shape50T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17432576 ||| 2^26) 34865152 q12Shape50T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T285OK,q12Shape50T288OK⟩

private def q12Shape50T289 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape50T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50987008 1310720 q12Shape50T289=true := by decide

private def q12Shape50T283 : Tree 12 := .split 25 q12Shape50T284 q12Shape50T289
private theorem q12Shape50T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17432576 1310720 q12Shape50T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17432576 (1310720 ||| 2^25) q12Shape50T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17432576 ||| 2^25) 1310720 q12Shape50T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T284OK,q12Shape50T289OK⟩

private def q12Shape50T269 : Tree 12 := .split 24 q12Shape50T270 q12Shape50T283
private theorem q12Shape50T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 1310720 q12Shape50T269=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 (1310720 ||| 2^24) q12Shape50T270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (655360 ||| 2^24) 1310720 q12Shape50T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T270OK,q12Shape50T283OK⟩

private def q12Shape50T290 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1703936 262144 q12Shape50T290=true := by decide

private def q12Shape50T268 : Tree 12 := .split 20 q12Shape50T269 q12Shape50T290
private theorem q12Shape50T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 262144 q12Shape50T268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 (262144 ||| 2^20) q12Shape50T269 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (655360 ||| 2^20) 262144 q12Shape50T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T269OK,q12Shape50T290OK⟩

def q12Shape50P10 : Tree 12 := q12Shape50T268
theorem q12Shape50P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 655360 262144 q12Shape50P10=true := q12Shape50T268OK

end Graffiti384b.EffectiveSearch.Q12
