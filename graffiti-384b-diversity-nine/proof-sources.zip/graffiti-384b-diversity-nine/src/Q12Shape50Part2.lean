import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T51 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape50T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 1192099840 q12Shape50T51=true := by decide

private def q12Shape50T54 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074790400 36625580032 q12Shape50T54=true := by decide

private def q12Shape50T55 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35434528768 2265841664 q12Shape50T55=true := by decide

private def q12Shape50T53 : Tree 12 := .split 35 q12Shape50T54 q12Shape50T55
private theorem q12Shape50T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074790400 2265841664 q12Shape50T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074790400 (2265841664 ||| 2^35) q12Shape50T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1074790400 ||| 2^35) 2265841664 q12Shape50T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T54OK,q12Shape50T55OK⟩

private def q12Shape50T56 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape50T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 3222274048 118358016 q12Shape50T56=true := by decide

private def q12Shape50T52 : Tree 12 := .split 31 q12Shape50T53 q12Shape50T56
private theorem q12Shape50T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074790400 118358016 q12Shape50T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074790400 (118358016 ||| 2^31) q12Shape50T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1074790400 ||| 2^31) 118358016 q12Shape50T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T53OK,q12Shape50T56OK⟩

private def q12Shape50T50 : Tree 12 := .split 30 q12Shape50T51 q12Shape50T52
private theorem q12Shape50T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 118358016 q12Shape50T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 (118358016 ||| 2^30) q12Shape50T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1048576 ||| 2^30) 118358016 q12Shape50T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T51OK,q12Shape50T52OK⟩

private def q12Shape50T57 : Tree 12 := (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape50T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68157440 51249152 q12Shape50T57=true := by decide

private def q12Shape50T49 : Tree 12 := .split 26 q12Shape50T50 q12Shape50T57
private theorem q12Shape50T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 51249152 q12Shape50T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 (51249152 ||| 2^26) q12Shape50T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1048576 ||| 2^26) 51249152 q12Shape50T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T50OK,q12Shape50T57OK⟩

private def q12Shape50T62 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 37665767424 q12Shape50T62=true := by decide

private def q12Shape50T63 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34394341376 3306029056 q12Shape50T63=true := by decide

private def q12Shape50T61 : Tree 12 := .split 35 q12Shape50T62 q12Shape50T63
private theorem q12Shape50T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 3306029056 q12Shape50T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 (3306029056 ||| 2^35) q12Shape50T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34603008 ||| 2^35) 3306029056 q12Shape50T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T62OK,q12Shape50T63OK⟩

private def q12Shape50T64 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape50T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2182086656 1158545408 q12Shape50T64=true := by decide

private def q12Shape50T60 : Tree 12 := .split 31 q12Shape50T61 q12Shape50T64
private theorem q12Shape50T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 1158545408 q12Shape50T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 (1158545408 ||| 2^31) q12Shape50T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34603008 ||| 2^31) 1158545408 q12Shape50T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T61OK,q12Shape50T64OK⟩

private def q12Shape50T65 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape50T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1108344832 84803584 q12Shape50T65=true := by decide

private def q12Shape50T59 : Tree 12 := .split 30 q12Shape50T60 q12Shape50T65
private theorem q12Shape50T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 84803584 q12Shape50T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 (84803584 ||| 2^30) q12Shape50T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34603008 ||| 2^30) 84803584 q12Shape50T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T60OK,q12Shape50T65OK⟩

private def q12Shape50T67 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape50T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 101711872 1091436544 q12Shape50T67=true := by decide

private def q12Shape50T68 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape50T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1175453696 17694720 q12Shape50T68=true := by decide

private def q12Shape50T66 : Tree 12 := .split 30 q12Shape50T67 q12Shape50T68
private theorem q12Shape50T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 101711872 17694720 q12Shape50T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 101711872 (17694720 ||| 2^30) q12Shape50T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (101711872 ||| 2^30) 17694720 q12Shape50T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T67OK,q12Shape50T68OK⟩

private def q12Shape50T58 : Tree 12 := .split 26 q12Shape50T59 q12Shape50T66
private theorem q12Shape50T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 17694720 q12Shape50T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34603008 (17694720 ||| 2^26) q12Shape50T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34603008 ||| 2^26) 17694720 q12Shape50T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T59OK,q12Shape50T66OK⟩

private def q12Shape50T48 : Tree 12 := .split 25 q12Shape50T49 q12Shape50T58
private theorem q12Shape50T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 17694720 q12Shape50T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 (17694720 ||| 2^25) q12Shape50T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1048576 ||| 2^25) 17694720 q12Shape50T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T49OK,q12Shape50T58OK⟩

private def q12Shape50T73 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape50T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 3322806272 q12Shape50T73=true := by decide

private def q12Shape50T74 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape50T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2165309440 1175322624 q12Shape50T74=true := by decide

private def q12Shape50T72 : Tree 12 := .split 31 q12Shape50T73 q12Shape50T74
private theorem q12Shape50T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 1175322624 q12Shape50T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 (1175322624 ||| 2^31) q12Shape50T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17825792 ||| 2^31) 1175322624 q12Shape50T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T73OK,q12Shape50T74OK⟩

private def q12Shape50T75 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1091567616 101580800 q12Shape50T75=true := by decide

private def q12Shape50T71 : Tree 12 := .split 30 q12Shape50T72 q12Shape50T75
private theorem q12Shape50T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 101580800 q12Shape50T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 (101580800 ||| 2^30) q12Shape50T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17825792 ||| 2^30) 101580800 q12Shape50T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T72OK,q12Shape50T75OK⟩

private def q12Shape50T77 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape50T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84934656 1108213760 q12Shape50T77=true := by decide

private def q12Shape50T78 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1158676480 34471936 q12Shape50T78=true := by decide

private def q12Shape50T76 : Tree 12 := .split 30 q12Shape50T77 q12Shape50T78
private theorem q12Shape50T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84934656 34471936 q12Shape50T76=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84934656 (34471936 ||| 2^30) q12Shape50T77 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (84934656 ||| 2^30) 34471936 q12Shape50T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T77OK,q12Shape50T78OK⟩

private def q12Shape50T70 : Tree 12 := .split 26 q12Shape50T71 q12Shape50T76
private theorem q12Shape50T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 34471936 q12Shape50T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 (34471936 ||| 2^26) q12Shape50T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17825792 ||| 2^26) 34471936 q12Shape50T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T71OK,q12Shape50T76OK⟩

private def q12Shape50T79 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 51380224 917504 q12Shape50T79=true := by decide

private def q12Shape50T69 : Tree 12 := .split 25 q12Shape50T70 q12Shape50T79
private theorem q12Shape50T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 917504 q12Shape50T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17825792 (917504 ||| 2^25) q12Shape50T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17825792 ||| 2^25) 917504 q12Shape50T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T70OK,q12Shape50T79OK⟩

private def q12Shape50T47 : Tree 12 := .split 24 q12Shape50T48 q12Shape50T69
private theorem q12Shape50T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 917504 q12Shape50T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 (917504 ||| 2^24) q12Shape50T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1048576 ||| 2^24) 917504 q12Shape50T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T48OK,q12Shape50T69OK⟩

def q12Shape50P2 : Tree 12 := q12Shape50T47
theorem q12Shape50P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1048576 917504 q12Shape50P2=true := q12Shape50T47OK

end Graffiti384b.EffectiveSearch.Q12
