import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T86 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape50T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 3340107776 q12Shape50T86=true := by decide

private def q12Shape50T88 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2148007936 35552362496 q12Shape50T88=true := by decide

private def q12Shape50T89 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 36507746304 1192624128 q12Shape50T89=true := by decide

private def q12Shape50T87 : Tree 12 := .split 35 q12Shape50T88 q12Shape50T89
private theorem q12Shape50T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2148007936 1192624128 q12Shape50T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2148007936 (1192624128 ||| 2^35) q12Shape50T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (2148007936 ||| 2^35) 1192624128 q12Shape50T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T88OK,q12Shape50T89OK⟩

private def q12Shape50T85 : Tree 12 := .split 31 q12Shape50T86 q12Shape50T87
private theorem q12Shape50T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 1192624128 q12Shape50T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 (1192624128 ||| 2^31) q12Shape50T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (524288 ||| 2^31) 1192624128 q12Shape50T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T86OK,q12Shape50T87OK⟩

private def q12Shape50T90 : Tree 12 := (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,5,7,9,10,11}))))
private theorem q12Shape50T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074266112 118882304 q12Shape50T90=true := by decide

private def q12Shape50T84 : Tree 12 := .split 30 q12Shape50T85 q12Shape50T90
private theorem q12Shape50T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 118882304 q12Shape50T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 (118882304 ||| 2^30) q12Shape50T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (524288 ||| 2^30) 118882304 q12Shape50T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T85OK,q12Shape50T90OK⟩

private def q12Shape50T94 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67633152 37632737280 q12Shape50T94=true := by decide

private def q12Shape50T95 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34427371520 3272998912 q12Shape50T95=true := by decide

private def q12Shape50T93 : Tree 12 := .split 35 q12Shape50T94 q12Shape50T95
private theorem q12Shape50T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67633152 3272998912 q12Shape50T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67633152 (3272998912 ||| 2^35) q12Shape50T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67633152 ||| 2^35) 3272998912 q12Shape50T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T94OK,q12Shape50T95OK⟩

private def q12Shape50T96 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape50T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2215116800 1125515264 q12Shape50T96=true := by decide

private def q12Shape50T92 : Tree 12 := .split 31 q12Shape50T93 q12Shape50T96
private theorem q12Shape50T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67633152 1125515264 q12Shape50T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67633152 (1125515264 ||| 2^31) q12Shape50T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67633152 ||| 2^31) 1125515264 q12Shape50T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T93OK,q12Shape50T96OK⟩

private def q12Shape50T97 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape50T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1141374976 51773440 q12Shape50T97=true := by decide

private def q12Shape50T91 : Tree 12 := .split 30 q12Shape50T92 q12Shape50T97
private theorem q12Shape50T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67633152 51773440 q12Shape50T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67633152 (51773440 ||| 2^30) q12Shape50T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67633152 ||| 2^30) 51773440 q12Shape50T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T92OK,q12Shape50T97OK⟩

private def q12Shape50T83 : Tree 12 := .split 26 q12Shape50T84 q12Shape50T91
private theorem q12Shape50T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 51773440 q12Shape50T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 (51773440 ||| 2^26) q12Shape50T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (524288 ||| 2^26) 51773440 q12Shape50T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T84OK,q12Shape50T91OK⟩

private def q12Shape50T99 : Tree 12 := (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape50T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34078720 85327872 q12Shape50T99=true := by decide

private def q12Shape50T101 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape50T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 101187584 1091960832 q12Shape50T101=true := by decide

private def q12Shape50T102 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape50T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1174929408 18219008 q12Shape50T102=true := by decide

private def q12Shape50T100 : Tree 12 := .split 30 q12Shape50T101 q12Shape50T102
private theorem q12Shape50T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 101187584 18219008 q12Shape50T100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 101187584 (18219008 ||| 2^30) q12Shape50T101 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (101187584 ||| 2^30) 18219008 q12Shape50T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T101OK,q12Shape50T102OK⟩

private def q12Shape50T98 : Tree 12 := .split 26 q12Shape50T99 q12Shape50T100
private theorem q12Shape50T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34078720 18219008 q12Shape50T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34078720 (18219008 ||| 2^26) q12Shape50T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34078720 ||| 2^26) 18219008 q12Shape50T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T99OK,q12Shape50T100OK⟩

private def q12Shape50T82 : Tree 12 := .split 25 q12Shape50T83 q12Shape50T98
private theorem q12Shape50T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 18219008 q12Shape50T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 (18219008 ||| 2^25) q12Shape50T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (524288 ||| 2^25) 18219008 q12Shape50T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T83OK,q12Shape50T98OK⟩

private def q12Shape50T106 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11})))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17301504 1175846912 q12Shape50T106=true := by decide

private def q12Shape50T107 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11})))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1091043328 102105088 q12Shape50T107=true := by decide

private def q12Shape50T105 : Tree 12 := .split 30 q12Shape50T106 q12Shape50T107
private theorem q12Shape50T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17301504 102105088 q12Shape50T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17301504 (102105088 ||| 2^30) q12Shape50T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17301504 ||| 2^30) 102105088 q12Shape50T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T106OK,q12Shape50T107OK⟩

private def q12Shape50T108 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84410368 34996224 q12Shape50T108=true := by decide

private def q12Shape50T104 : Tree 12 := .split 26 q12Shape50T105 q12Shape50T108
private theorem q12Shape50T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17301504 34996224 q12Shape50T104=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17301504 (34996224 ||| 2^26) q12Shape50T105 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17301504 ||| 2^26) 34996224 q12Shape50T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T105OK,q12Shape50T108OK⟩

private def q12Shape50T111 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11})))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50855936 1142292480 q12Shape50T111=true := by decide

private def q12Shape50T112 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape50T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1124597760 68550656 q12Shape50T112=true := by decide

private def q12Shape50T110 : Tree 12 := .split 30 q12Shape50T111 q12Shape50T112
private theorem q12Shape50T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50855936 68550656 q12Shape50T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50855936 (68550656 ||| 2^30) q12Shape50T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (50855936 ||| 2^30) 68550656 q12Shape50T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T111OK,q12Shape50T112OK⟩

private def q12Shape50T113 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 117964800 1441792 q12Shape50T113=true := by decide

private def q12Shape50T109 : Tree 12 := .split 26 q12Shape50T110 q12Shape50T113
private theorem q12Shape50T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50855936 1441792 q12Shape50T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50855936 (1441792 ||| 2^26) q12Shape50T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (50855936 ||| 2^26) 1441792 q12Shape50T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T110OK,q12Shape50T113OK⟩

private def q12Shape50T103 : Tree 12 := .split 25 q12Shape50T104 q12Shape50T109
private theorem q12Shape50T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17301504 1441792 q12Shape50T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17301504 (1441792 ||| 2^25) q12Shape50T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17301504 ||| 2^25) 1441792 q12Shape50T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T104OK,q12Shape50T109OK⟩

private def q12Shape50T81 : Tree 12 := .split 24 q12Shape50T82 q12Shape50T103
private theorem q12Shape50T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 1441792 q12Shape50T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 (1441792 ||| 2^24) q12Shape50T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (524288 ||| 2^24) 1441792 q12Shape50T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T82OK,q12Shape50T103OK⟩

def q12Shape50P3 : Tree 12 := q12Shape50T81
theorem q12Shape50P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 524288 1441792 q12Shape50P3=true := q12Shape50T81OK

end Graffiti384b.EffectiveSearch.Q12
