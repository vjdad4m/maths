import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T118 : Tree 12 := (.split 31 (.tip (.cover {0,2,3,4,9,10,11})) (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,5,8,9,10,11}))))
private theorem q12Shape50T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 1191575552 q12Shape50T118=true := by decide

private def q12Shape50T120 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape50T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075314688 2265317376 q12Shape50T120=true := by decide

private def q12Shape50T121 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape50T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 3222798336 117833728 q12Shape50T121=true := by decide

private def q12Shape50T119 : Tree 12 := .split 31 q12Shape50T120 q12Shape50T121
private theorem q12Shape50T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075314688 117833728 q12Shape50T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075314688 (117833728 ||| 2^31) q12Shape50T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1075314688 ||| 2^31) 117833728 q12Shape50T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T120OK,q12Shape50T121OK⟩

private def q12Shape50T117 : Tree 12 := .split 30 q12Shape50T118 q12Shape50T119
private theorem q12Shape50T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 117833728 q12Shape50T117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 (117833728 ||| 2^30) q12Shape50T118 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1572864 ||| 2^30) 117833728 q12Shape50T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T118OK,q12Shape50T119OK⟩

private def q12Shape50T123 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape50T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68681728 1124466688 q12Shape50T123=true := by decide

private def q12Shape50T124 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape50T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1142423552 50724864 q12Shape50T124=true := by decide

private def q12Shape50T122 : Tree 12 := .split 30 q12Shape50T123 q12Shape50T124
private theorem q12Shape50T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68681728 50724864 q12Shape50T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68681728 (50724864 ||| 2^30) q12Shape50T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (68681728 ||| 2^30) 50724864 q12Shape50T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T123OK,q12Shape50T124OK⟩

private def q12Shape50T116 : Tree 12 := .split 26 q12Shape50T117 q12Shape50T122
private theorem q12Shape50T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 50724864 q12Shape50T116=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 (50724864 ||| 2^26) q12Shape50T117 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1572864 ||| 2^26) 50724864 q12Shape50T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T117OK,q12Shape50T122OK⟩

private def q12Shape50T127 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape50T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35127296 1158021120 q12Shape50T127=true := by decide

private def q12Shape50T128 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape50T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1108869120 84279296 q12Shape50T128=true := by decide

private def q12Shape50T126 : Tree 12 := .split 30 q12Shape50T127 q12Shape50T128
private theorem q12Shape50T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35127296 84279296 q12Shape50T126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35127296 (84279296 ||| 2^30) q12Shape50T127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (35127296 ||| 2^30) 84279296 q12Shape50T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T127OK,q12Shape50T128OK⟩

private def q12Shape50T129 : Tree 12 := (.split 30 (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11})))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape50T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 102236160 17170432 q12Shape50T129=true := by decide

private def q12Shape50T125 : Tree 12 := .split 26 q12Shape50T126 q12Shape50T129
private theorem q12Shape50T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35127296 17170432 q12Shape50T125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35127296 (17170432 ||| 2^26) q12Shape50T126 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (35127296 ||| 2^26) 17170432 q12Shape50T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T126OK,q12Shape50T129OK⟩

private def q12Shape50T115 : Tree 12 := .split 25 q12Shape50T116 q12Shape50T125
private theorem q12Shape50T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 17170432 q12Shape50T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 (17170432 ||| 2^25) q12Shape50T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1572864 ||| 2^25) 17170432 q12Shape50T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T116OK,q12Shape50T125OK⟩

private def q12Shape50T130 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18350080 393216 q12Shape50T130=true := by decide

private def q12Shape50T114 : Tree 12 := .split 24 q12Shape50T115 q12Shape50T130
private theorem q12Shape50T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 393216 q12Shape50T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 (393216 ||| 2^24) q12Shape50T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1572864 ||| 2^24) 393216 q12Shape50T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T115OK,q12Shape50T130OK⟩

def q12Shape50P4 : Tree 12 := q12Shape50T114
theorem q12Shape50P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1572864 393216 q12Shape50P4=true := q12Shape50T114OK

end Graffiti384b.EffectiveSearch.Q12
