import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T138 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))))
private theorem q12Shape50T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 3340369920 q12Shape50T138=true := by decide

private def q12Shape50T139 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))))
private theorem q12Shape50T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2147745792 1192886272 q12Shape50T139=true := by decide

private def q12Shape50T137 : Tree 12 := .split 31 q12Shape50T138 q12Shape50T139
private theorem q12Shape50T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 1192886272 q12Shape50T137=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 (1192886272 ||| 2^31) q12Shape50T138 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (262144 ||| 2^31) 1192886272 q12Shape50T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T138OK,q12Shape50T139OK⟩

private def q12Shape50T140 : Tree 12 := (.split 31 (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11}))))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape50T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074003968 119144448 q12Shape50T140=true := by decide

private def q12Shape50T136 : Tree 12 := .split 30 q12Shape50T137 q12Shape50T140
private theorem q12Shape50T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 119144448 q12Shape50T136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 (119144448 ||| 2^30) q12Shape50T137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (262144 ||| 2^30) 119144448 q12Shape50T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T137OK,q12Shape50T140OK⟩

private def q12Shape50T143 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape50T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67371008 3273261056 q12Shape50T143=true := by decide

private def q12Shape50T144 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape50T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2214854656 1125777408 q12Shape50T144=true := by decide

private def q12Shape50T142 : Tree 12 := .split 31 q12Shape50T143 q12Shape50T144
private theorem q12Shape50T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67371008 1125777408 q12Shape50T142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67371008 (1125777408 ||| 2^31) q12Shape50T143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67371008 ||| 2^31) 1125777408 q12Shape50T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T143OK,q12Shape50T144OK⟩

private def q12Shape50T145 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape50T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1141112832 52035584 q12Shape50T145=true := by decide

private def q12Shape50T141 : Tree 12 := .split 30 q12Shape50T142 q12Shape50T145
private theorem q12Shape50T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67371008 52035584 q12Shape50T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 67371008 (52035584 ||| 2^30) q12Shape50T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (67371008 ||| 2^30) 52035584 q12Shape50T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T142OK,q12Shape50T145OK⟩

private def q12Shape50T135 : Tree 12 := .split 26 q12Shape50T136 q12Shape50T141
private theorem q12Shape50T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 52035584 q12Shape50T135=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 (52035584 ||| 2^26) q12Shape50T136 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (262144 ||| 2^26) 52035584 q12Shape50T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T136OK,q12Shape50T141OK⟩

private def q12Shape50T148 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11})))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape50T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 33816576 1159331840 q12Shape50T148=true := by decide

private def q12Shape50T149 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11})))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape50T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1107558400 85590016 q12Shape50T149=true := by decide

private def q12Shape50T147 : Tree 12 := .split 30 q12Shape50T148 q12Shape50T149
private theorem q12Shape50T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 33816576 85590016 q12Shape50T147=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 33816576 (85590016 ||| 2^30) q12Shape50T148 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (33816576 ||| 2^30) 85590016 q12Shape50T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T148OK,q12Shape50T149OK⟩

private def q12Shape50T150 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 100925440 18481152 q12Shape50T150=true := by decide

private def q12Shape50T146 : Tree 12 := .split 26 q12Shape50T147 q12Shape50T150
private theorem q12Shape50T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 33816576 18481152 q12Shape50T146=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 33816576 (18481152 ||| 2^26) q12Shape50T147 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (33816576 ||| 2^26) 18481152 q12Shape50T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T147OK,q12Shape50T150OK⟩

private def q12Shape50T134 : Tree 12 := .split 25 q12Shape50T135 q12Shape50T146
private theorem q12Shape50T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 18481152 q12Shape50T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 (18481152 ||| 2^25) q12Shape50T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (262144 ||| 2^25) 18481152 q12Shape50T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T135OK,q12Shape50T146OK⟩

private def q12Shape50T153 : Tree 12 := (.split 30 (.split 31 (.split 35 (.tip (.cover {0,2,3,6,9,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape50T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17039360 102367232 q12Shape50T153=true := by decide

private def q12Shape50T155 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape50T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84148224 1109000192 q12Shape50T155=true := by decide

private def q12Shape50T156 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape50T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1157890048 35258368 q12Shape50T156=true := by decide

private def q12Shape50T154 : Tree 12 := .split 30 q12Shape50T155 q12Shape50T156
private theorem q12Shape50T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84148224 35258368 q12Shape50T154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 84148224 (35258368 ||| 2^30) q12Shape50T155 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (84148224 ||| 2^30) 35258368 q12Shape50T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T155OK,q12Shape50T156OK⟩

private def q12Shape50T152 : Tree 12 := .split 26 q12Shape50T153 q12Shape50T154
private theorem q12Shape50T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17039360 35258368 q12Shape50T152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17039360 (35258368 ||| 2^26) q12Shape50T153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17039360 ||| 2^26) 35258368 q12Shape50T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T153OK,q12Shape50T154OK⟩

private def q12Shape50T159 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8,11})))) (.tip (.cover {0,1,4,5,8,9,11})))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape50T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50593792 1142554624 q12Shape50T159=true := by decide

private def q12Shape50T160 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape50T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1124335616 68812800 q12Shape50T160=true := by decide

private def q12Shape50T158 : Tree 12 := .split 30 q12Shape50T159 q12Shape50T160
private theorem q12Shape50T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50593792 68812800 q12Shape50T158=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50593792 (68812800 ||| 2^30) q12Shape50T159 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (50593792 ||| 2^30) 68812800 q12Shape50T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T159OK,q12Shape50T160OK⟩

private def q12Shape50T161 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 117702656 1703936 q12Shape50T161=true := by decide

private def q12Shape50T157 : Tree 12 := .split 26 q12Shape50T158 q12Shape50T161
private theorem q12Shape50T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50593792 1703936 q12Shape50T157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 50593792 (1703936 ||| 2^26) q12Shape50T158 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (50593792 ||| 2^26) 1703936 q12Shape50T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T158OK,q12Shape50T161OK⟩

private def q12Shape50T151 : Tree 12 := .split 25 q12Shape50T152 q12Shape50T157
private theorem q12Shape50T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17039360 1703936 q12Shape50T151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17039360 (1703936 ||| 2^25) q12Shape50T152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17039360 ||| 2^25) 1703936 q12Shape50T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T152OK,q12Shape50T157OK⟩

private def q12Shape50T133 : Tree 12 := .split 24 q12Shape50T134 q12Shape50T151
private theorem q12Shape50T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 1703936 q12Shape50T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 (1703936 ||| 2^24) q12Shape50T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (262144 ||| 2^24) 1703936 q12Shape50T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T134OK,q12Shape50T151OK⟩

def q12Shape50P5 : Tree 12 := q12Shape50T133
theorem q12Shape50P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 262144 1703936 q12Shape50P5=true := q12Shape50T133OK

end Graffiti384b.EffectiveSearch.Q12
