import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T166 : Tree 12 := (.split 31 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11}))))) (.tip (.cover {0,2,3,8,9,10,11})))
private theorem q12Shape50T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 1191837696 q12Shape50T166=true := by decide

private def q12Shape50T169 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075052544 36625317888 q12Shape50T169=true := by decide

private def q12Shape50T170 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 35434790912 2265579520 q12Shape50T170=true := by decide

private def q12Shape50T168 : Tree 12 := .split 35 q12Shape50T169 q12Shape50T170
private theorem q12Shape50T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075052544 2265579520 q12Shape50T168=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075052544 (2265579520 ||| 2^35) q12Shape50T169 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1075052544 ||| 2^35) 2265579520 q12Shape50T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T169OK,q12Shape50T170OK⟩

private def q12Shape50T171 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape50T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 3222536192 118095872 q12Shape50T171=true := by decide

private def q12Shape50T167 : Tree 12 := .split 31 q12Shape50T168 q12Shape50T171
private theorem q12Shape50T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075052544 118095872 q12Shape50T167=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1075052544 (118095872 ||| 2^31) q12Shape50T168 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1075052544 ||| 2^31) 118095872 q12Shape50T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T168OK,q12Shape50T171OK⟩

private def q12Shape50T165 : Tree 12 := .split 30 q12Shape50T166 q12Shape50T167
private theorem q12Shape50T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 118095872 q12Shape50T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 (118095872 ||| 2^30) q12Shape50T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1310720 ||| 2^30) 118095872 q12Shape50T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T166OK,q12Shape50T167OK⟩

private def q12Shape50T173 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape50T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68419584 1124728832 q12Shape50T173=true := by decide

private def q12Shape50T174 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape50T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1142161408 50987008 q12Shape50T174=true := by decide

private def q12Shape50T172 : Tree 12 := .split 30 q12Shape50T173 q12Shape50T174
private theorem q12Shape50T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68419584 50987008 q12Shape50T172=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68419584 (50987008 ||| 2^30) q12Shape50T173 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (68419584 ||| 2^30) 50987008 q12Shape50T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T173OK,q12Shape50T174OK⟩

private def q12Shape50T164 : Tree 12 := .split 26 q12Shape50T165 q12Shape50T172
private theorem q12Shape50T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 50987008 q12Shape50T164=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 (50987008 ||| 2^26) q12Shape50T165 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1310720 ||| 2^26) 50987008 q12Shape50T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T165OK,q12Shape50T172OK⟩

private def q12Shape50T175 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34865152 17432576 q12Shape50T175=true := by decide

private def q12Shape50T163 : Tree 12 := .split 25 q12Shape50T164 q12Shape50T175
private theorem q12Shape50T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 17432576 q12Shape50T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 (17432576 ||| 2^25) q12Shape50T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1310720 ||| 2^25) 17432576 q12Shape50T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T164OK,q12Shape50T175OK⟩

private def q12Shape50T179 : Tree 12 := (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape50T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18087936 1175060480 q12Shape50T179=true := by decide

private def q12Shape50T180 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1091829760 101318656 q12Shape50T180=true := by decide

private def q12Shape50T178 : Tree 12 := .split 30 q12Shape50T179 q12Shape50T180
private theorem q12Shape50T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18087936 101318656 q12Shape50T178=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18087936 (101318656 ||| 2^30) q12Shape50T179 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (18087936 ||| 2^30) 101318656 q12Shape50T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T179OK,q12Shape50T180OK⟩

private def q12Shape50T181 : Tree 12 := (.split 30 (.split 31 (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 85196800 34209792 q12Shape50T181=true := by decide

private def q12Shape50T177 : Tree 12 := .split 26 q12Shape50T178 q12Shape50T181
private theorem q12Shape50T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18087936 34209792 q12Shape50T177=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18087936 (34209792 ||| 2^26) q12Shape50T178 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (18087936 ||| 2^26) 34209792 q12Shape50T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T178OK,q12Shape50T181OK⟩

private def q12Shape50T182 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 51642368 655360 q12Shape50T182=true := by decide

private def q12Shape50T176 : Tree 12 := .split 25 q12Shape50T177 q12Shape50T182
private theorem q12Shape50T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18087936 655360 q12Shape50T176=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 18087936 (655360 ||| 2^25) q12Shape50T177 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (18087936 ||| 2^25) 655360 q12Shape50T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T177OK,q12Shape50T182OK⟩

private def q12Shape50T162 : Tree 12 := .split 24 q12Shape50T163 q12Shape50T176
private theorem q12Shape50T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 655360 q12Shape50T162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 (655360 ||| 2^24) q12Shape50T163 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1310720 ||| 2^24) 655360 q12Shape50T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T163OK,q12Shape50T176OK⟩

def q12Shape50P6 : Tree 12 := q12Shape50T162
theorem q12Shape50P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1310720 655360 q12Shape50P6=true := q12Shape50T162OK

end Graffiti384b.EffectiveSearch.Q12
