import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape50T245 : Tree 12 := (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11})))) (.tip (.cover {0,1,4,6,7,9,11})))))
private theorem q12Shape50T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 3339452416 q12Shape50T245=true := by decide

private def q12Shape50T246 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11})))) (.tip (.cover {0,1,4,6,7,9,11})))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape50T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2148663296 1191968768 q12Shape50T246=true := by decide

private def q12Shape50T244 : Tree 12 := .split 31 q12Shape50T245 q12Shape50T246
private theorem q12Shape50T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 1191968768 q12Shape50T244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 (1191968768 ||| 2^31) q12Shape50T245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1179648 ||| 2^31) 1191968768 q12Shape50T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T245OK,q12Shape50T246OK⟩

private def q12Shape50T247 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1074921472 118226944 q12Shape50T247=true := by decide

private def q12Shape50T243 : Tree 12 := .split 30 q12Shape50T244 q12Shape50T247
private theorem q12Shape50T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 118226944 q12Shape50T243=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 (118226944 ||| 2^30) q12Shape50T244 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1179648 ||| 2^30) 118226944 q12Shape50T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T244OK,q12Shape50T247OK⟩

private def q12Shape50T248 : Tree 12 := (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape50T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 68288512 51118080 q12Shape50T248=true := by decide

private def q12Shape50T242 : Tree 12 := .split 26 q12Shape50T243 q12Shape50T248
private theorem q12Shape50T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 51118080 q12Shape50T242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 (51118080 ||| 2^26) q12Shape50T243 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1179648 ||| 2^26) 51118080 q12Shape50T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T243OK,q12Shape50T248OK⟩

private def q12Shape50T253 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 37665636352 q12Shape50T253=true := by decide

private def q12Shape50T254 : Tree 12 := (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,6,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,9,11}))))
private theorem q12Shape50T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34394472448 3305897984 q12Shape50T254=true := by decide

private def q12Shape50T252 : Tree 12 := .split 35 q12Shape50T253 q12Shape50T254
private theorem q12Shape50T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 3305897984 q12Shape50T252=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 (3305897984 ||| 2^35) q12Shape50T253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34734080 ||| 2^35) 3305897984 q12Shape50T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T253OK,q12Shape50T254OK⟩

private def q12Shape50T255 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape50T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2182217728 1158414336 q12Shape50T255=true := by decide

private def q12Shape50T251 : Tree 12 := .split 31 q12Shape50T252 q12Shape50T255
private theorem q12Shape50T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 1158414336 q12Shape50T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 (1158414336 ||| 2^31) q12Shape50T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34734080 ||| 2^31) 1158414336 q12Shape50T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T252OK,q12Shape50T255OK⟩

private def q12Shape50T256 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1108475904 84672512 q12Shape50T256=true := by decide

private def q12Shape50T250 : Tree 12 := .split 30 q12Shape50T251 q12Shape50T256
private theorem q12Shape50T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 84672512 q12Shape50T250=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 (84672512 ||| 2^30) q12Shape50T251 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34734080 ||| 2^30) 84672512 q12Shape50T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T251OK,q12Shape50T256OK⟩

private def q12Shape50T257 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape50T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 101842944 17563648 q12Shape50T257=true := by decide

private def q12Shape50T249 : Tree 12 := .split 26 q12Shape50T250 q12Shape50T257
private theorem q12Shape50T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 17563648 q12Shape50T249=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 34734080 (17563648 ||| 2^26) q12Shape50T250 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (34734080 ||| 2^26) 17563648 q12Shape50T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T250OK,q12Shape50T257OK⟩

private def q12Shape50T241 : Tree 12 := .split 25 q12Shape50T242 q12Shape50T249
private theorem q12Shape50T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 17563648 q12Shape50T241=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 (17563648 ||| 2^25) q12Shape50T242 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1179648 ||| 2^25) 17563648 q12Shape50T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T242OK,q12Shape50T249OK⟩

private def q12Shape50T262 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,5,7,9,10,11})))
private theorem q12Shape50T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 3322675200 q12Shape50T262=true := by decide

private def q12Shape50T263 : Tree 12 := (.split 35 (.split 0 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,9,11}))) (.split 42 (.split 6 (.tip (.small 1)) (.tip (.cover {3,4,6,7,9,10,11}))) (.tip (.cover {0,1,4,5,7,9,11})))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape50T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 2165440512 1175191552 q12Shape50T263=true := by decide

private def q12Shape50T261 : Tree 12 := .split 31 q12Shape50T262 q12Shape50T263
private theorem q12Shape50T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 1175191552 q12Shape50T261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 (1175191552 ||| 2^31) q12Shape50T262 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17956864 ||| 2^31) 1175191552 q12Shape50T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T262OK,q12Shape50T263OK⟩

private def q12Shape50T264 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape50T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1091698688 101449728 q12Shape50T264=true := by decide

private def q12Shape50T260 : Tree 12 := .split 30 q12Shape50T261 q12Shape50T264
private theorem q12Shape50T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 101449728 q12Shape50T260=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 (101449728 ||| 2^30) q12Shape50T261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17956864 ||| 2^30) 101449728 q12Shape50T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T261OK,q12Shape50T264OK⟩

private def q12Shape50T265 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape50T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 85065728 34340864 q12Shape50T265=true := by decide

private def q12Shape50T259 : Tree 12 := .split 26 q12Shape50T260 q12Shape50T265
private theorem q12Shape50T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 34340864 q12Shape50T259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 (34340864 ||| 2^26) q12Shape50T260 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17956864 ||| 2^26) 34340864 q12Shape50T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T260OK,q12Shape50T265OK⟩

private def q12Shape50T266 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape50T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 51511296 786432 q12Shape50T266=true := by decide

private def q12Shape50T258 : Tree 12 := .split 25 q12Shape50T259 q12Shape50T266
private theorem q12Shape50T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 786432 q12Shape50T258=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 17956864 (786432 ||| 2^25) q12Shape50T259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (17956864 ||| 2^25) 786432 q12Shape50T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T259OK,q12Shape50T266OK⟩

private def q12Shape50T240 : Tree 12 := .split 24 q12Shape50T241 q12Shape50T258
private theorem q12Shape50T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 786432 q12Shape50T240=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 (786432 ||| 2^24) q12Shape50T241 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) (1179648 ||| 2^24) 786432 q12Shape50T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape50T241OK,q12Shape50T258OK⟩

def q12Shape50P9 : Tree 12 := q12Shape50T240
theorem q12Shape50P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,2⟩) 1179648 786432 q12Shape50P9=true := q12Shape50T240OK

end Graffiti384b.EffectiveSearch.Q12
