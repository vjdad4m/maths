import Q12Shape51Part0
import Q12Shape51Part1
import Q12Shape51Part2
import Q12Shape51Part3
import Q12Shape51Part4
import Q12Shape51Part5
import Q12Shape51Part6
import Q12Shape51Part7
import Q12Shape51Part8

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51M62 : Tree 12 := .split 31 q12Shape51P0 q12Shape51P1
private theorem q12Shape51M62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 1191182336 q12Shape51M62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 (1191182336 ||| 2^31) q12Shape51P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (0 ||| 2^31) 1191182336 q12Shape51P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51P0OK,q12Shape51P1OK⟩
private def q12Shape51M103 : Tree 12 := .split 0 q12Shape51P2 q12Shape51P3
private theorem q12Shape51M103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 36624662528 q12Shape51M103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 (36624662528 ||| 2^0) q12Shape51P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741824 ||| 2^0) 36624662528 q12Shape51P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51P2OK,q12Shape51P3OK⟩
private def q12Shape51M105 : Tree 12 := .split 35 q12Shape51M103 q12Shape51P4
private theorem q12Shape51M105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 2264924160 q12Shape51M105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 (2264924160 ||| 2^35) q12Shape51M103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741824 ||| 2^35) 2264924160 q12Shape51P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M103OK,q12Shape51P4OK⟩
private def q12Shape51M107 : Tree 12 := .split 31 q12Shape51M105 q12Shape51P5
private theorem q12Shape51M107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 117440512 q12Shape51M107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 (117440512 ||| 2^31) q12Shape51M105 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741824 ||| 2^31) 117440512 q12Shape51P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M105OK,q12Shape51P5OK⟩
private def q12Shape51M108 : Tree 12 := .split 30 q12Shape51M62 q12Shape51M107
private theorem q12Shape51M108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 117440512 q12Shape51M108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 (117440512 ||| 2^30) q12Shape51M62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (0 ||| 2^30) 117440512 q12Shape51M107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M62OK,q12Shape51M107OK⟩
private def q12Shape51M145 : Tree 12 := .split 31 q12Shape51P6 q12Shape51P7
private theorem q12Shape51M145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 67108864 1124073472 q12Shape51M145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 67108864 (1124073472 ||| 2^31) q12Shape51P6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (67108864 ||| 2^31) 1124073472 q12Shape51P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51P6OK,q12Shape51P7OK⟩
private def q12Shape51M147 : Tree 12 := .split 30 q12Shape51M145 q12Shape51P8
private theorem q12Shape51M147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 67108864 50331648 q12Shape51M147=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 67108864 (50331648 ||| 2^30) q12Shape51M145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (67108864 ||| 2^30) 50331648 q12Shape51P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M145OK,q12Shape51P8OK⟩
private def q12Shape51M148 : Tree 12 := .split 26 q12Shape51M108 q12Shape51M147
private theorem q12Shape51M148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 50331648 q12Shape51M148=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 (50331648 ||| 2^26) q12Shape51M108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (0 ||| 2^26) 50331648 q12Shape51M147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M108OK,q12Shape51M147OK⟩
private def q12Shape51M197 : Tree 12 := .split 0 q12Shape51P9 q12Shape51P10
private theorem q12Shape51M197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 37664849920 q12Shape51M197=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 (37664849920 ||| 2^0) q12Shape51P9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554432 ||| 2^0) 37664849920 q12Shape51P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51P9OK,q12Shape51P10OK⟩
private def q12Shape51M199 : Tree 12 := .split 35 q12Shape51M197 q12Shape51P11
private theorem q12Shape51M199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 3305111552 q12Shape51M199=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 (3305111552 ||| 2^35) q12Shape51M197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554432 ||| 2^35) 3305111552 q12Shape51P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M197OK,q12Shape51P11OK⟩
private def q12Shape51M201 : Tree 12 := .split 31 q12Shape51M199 q12Shape51P12
private theorem q12Shape51M201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 1157627904 q12Shape51M201=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 (1157627904 ||| 2^31) q12Shape51M199 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554432 ||| 2^31) 1157627904 q12Shape51P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M199OK,q12Shape51P12OK⟩
private def q12Shape51M203 : Tree 12 := .split 30 q12Shape51M201 q12Shape51P13
private theorem q12Shape51M203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 83886080 q12Shape51M203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 (83886080 ||| 2^30) q12Shape51M201 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554432 ||| 2^30) 83886080 q12Shape51P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M201OK,q12Shape51P13OK⟩
private def q12Shape51M205 : Tree 12 := .split 26 q12Shape51M203 q12Shape51P14
private theorem q12Shape51M205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 16777216 q12Shape51M205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554432 (16777216 ||| 2^26) q12Shape51M203 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554432 ||| 2^26) 16777216 q12Shape51P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M203OK,q12Shape51P14OK⟩
private def q12Shape51M206 : Tree 12 := .split 25 q12Shape51M148 q12Shape51M205
private theorem q12Shape51M206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 16777216 q12Shape51M206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 (16777216 ||| 2^25) q12Shape51M148 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (0 ||| 2^25) 16777216 q12Shape51M205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M148OK,q12Shape51M205OK⟩
private def q12Shape51M255 : Tree 12 := .split 0 q12Shape51P15 q12Shape51P16
private theorem q12Shape51M255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 37681627136 q12Shape51M255=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 (37681627136 ||| 2^0) q12Shape51P15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777216 ||| 2^0) 37681627136 q12Shape51P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51P15OK,q12Shape51P16OK⟩
private def q12Shape51M257 : Tree 12 := .split 35 q12Shape51M255 q12Shape51P17
private theorem q12Shape51M257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 3321888768 q12Shape51M257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 (3321888768 ||| 2^35) q12Shape51M255 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777216 ||| 2^35) 3321888768 q12Shape51P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M255OK,q12Shape51P17OK⟩
private def q12Shape51M259 : Tree 12 := .split 31 q12Shape51M257 q12Shape51P18
private theorem q12Shape51M259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 1174405120 q12Shape51M259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 (1174405120 ||| 2^31) q12Shape51M257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777216 ||| 2^31) 1174405120 q12Shape51P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M257OK,q12Shape51P18OK⟩
private def q12Shape51M261 : Tree 12 := .split 30 q12Shape51M259 q12Shape51P19
private theorem q12Shape51M261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 100663296 q12Shape51M261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 (100663296 ||| 2^30) q12Shape51M259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777216 ||| 2^30) 100663296 q12Shape51P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M259OK,q12Shape51P19OK⟩
private def q12Shape51M263 : Tree 12 := .split 26 q12Shape51M261 q12Shape51P20
private theorem q12Shape51M263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 33554432 q12Shape51M263=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 (33554432 ||| 2^26) q12Shape51M261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777216 ||| 2^26) 33554432 q12Shape51P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M261OK,q12Shape51P20OK⟩
private def q12Shape51M265 : Tree 12 := .split 25 q12Shape51M263 q12Shape51P21
private theorem q12Shape51M265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 0 q12Shape51M265=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 (0 ||| 2^25) q12Shape51M263 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777216 ||| 2^25) 0 q12Shape51P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M263OK,q12Shape51P21OK⟩
private def q12Shape51M266 : Tree 12 := .split 24 q12Shape51M206 q12Shape51M265
private theorem q12Shape51M266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 0 q12Shape51M266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 (0 ||| 2^24) q12Shape51M206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (0 ||| 2^24) 0 q12Shape51M265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51M206OK,q12Shape51M265OK⟩

theorem q12Shape51_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 51) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 51) b) (adj 12 (forms 51) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) adj_mono b H q12Shape51M266 q12Shape51M266OK

#print axioms q12Shape51_cover

end Graffiti384b.EffectiveSearch.Q12
