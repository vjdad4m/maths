import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51T1 : Tree 12 := (.tip (.cover {0,2,3,4,9,10,11}))
private theorem q12Shape51T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 37698404352 q12Shape51T1=true := by decide

private def q12Shape51T4 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))))))
private theorem q12Shape51T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738368 3338665987 q12Shape51T4=true := by decide

private def q12Shape51T6 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))))
private theorem q12Shape51T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738370 3338666497 q12Shape51T6=true := by decide

private def q12Shape51T8 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))))
private theorem q12Shape51T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738882 3338666049 q12Shape51T8=true := by decide

private def q12Shape51T9 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11})))) (.split 21 (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11}))))
private theorem q12Shape51T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738946 3338665985 q12Shape51T9=true := by decide

private def q12Shape51T7 : Tree 12 := .split 6 q12Shape51T8 q12Shape51T9
private theorem q12Shape51T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738882 3338665985 q12Shape51T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738882 (3338665985 ||| 2^6) q12Shape51T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738882 ||| 2^6) 3338665985 q12Shape51T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T8OK,q12Shape51T9OK⟩

private def q12Shape51T5 : Tree 12 := .split 9 q12Shape51T6 q12Shape51T7
private theorem q12Shape51T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738370 3338665985 q12Shape51T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738370 (3338665985 ||| 2^9) q12Shape51T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738370 ||| 2^9) 3338665985 q12Shape51T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T6OK,q12Shape51T7OK⟩

private def q12Shape51T3 : Tree 12 := .split 1 q12Shape51T4 q12Shape51T5
private theorem q12Shape51T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738368 3338665985 q12Shape51T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738368 (3338665985 ||| 2^1) q12Shape51T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738368 ||| 2^1) 3338665985 q12Shape51T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T4OK,q12Shape51T5OK⟩

private def q12Shape51T12 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))))
private theorem q12Shape51T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738369 3338666498 q12Shape51T12=true := by decide

private def q12Shape51T14 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))))
private theorem q12Shape51T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738881 3338666050 q12Shape51T14=true := by decide

private def q12Shape51T15 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11})))) (.split 21 (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11}))))
private theorem q12Shape51T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738945 3338665986 q12Shape51T15=true := by decide

private def q12Shape51T13 : Tree 12 := .split 6 q12Shape51T14 q12Shape51T15
private theorem q12Shape51T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738881 3338665986 q12Shape51T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738881 (3338665986 ||| 2^6) q12Shape51T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738881 ||| 2^6) 3338665986 q12Shape51T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T14OK,q12Shape51T15OK⟩

private def q12Shape51T11 : Tree 12 := .split 9 q12Shape51T12 q12Shape51T13
private theorem q12Shape51T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738369 3338665986 q12Shape51T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738369 (3338665986 ||| 2^9) q12Shape51T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738369 ||| 2^9) 3338665986 q12Shape51T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T12OK,q12Shape51T13OK⟩

private def q12Shape51T18 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))))
private theorem q12Shape51T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738371 3338666560 q12Shape51T18=true := by decide

private def q12Shape51T19 : Tree 12 := (.split 14 (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11})))) (.split 21 (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11}))))
private theorem q12Shape51T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738435 3338666496 q12Shape51T19=true := by decide

private def q12Shape51T17 : Tree 12 := .split 6 q12Shape51T18 q12Shape51T19
private theorem q12Shape51T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738371 3338666496 q12Shape51T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738371 (3338666496 ||| 2^6) q12Shape51T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738371 ||| 2^6) 3338666496 q12Shape51T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T18OK,q12Shape51T19OK⟩

private def q12Shape51T22 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11}))))
private theorem q12Shape51T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738883 3338682432 q12Shape51T22=true := by decide

private def q12Shape51T23 : Tree 12 := (.split 21 (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11}))) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11}))))
private theorem q12Shape51T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359755267 3338666048 q12Shape51T23=true := by decide

private def q12Shape51T21 : Tree 12 := .split 14 q12Shape51T22 q12Shape51T23
private theorem q12Shape51T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738883 3338666048 q12Shape51T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738883 (3338666048 ||| 2^14) q12Shape51T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738883 ||| 2^14) 3338666048 q12Shape51T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T22OK,q12Shape51T23OK⟩

private def q12Shape51T25 : Tree 12 := (.split 21 (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))))
private theorem q12Shape51T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738947 3338682368 q12Shape51T25=true := by decide

private def q12Shape51T26 : Tree 12 := (.split 21 (.split 2 (.split 3 (.tip (.cover {0,3,4,7,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11})))
private theorem q12Shape51T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359755331 3338665984 q12Shape51T26=true := by decide

private def q12Shape51T24 : Tree 12 := .split 14 q12Shape51T25 q12Shape51T26
private theorem q12Shape51T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738947 3338665984 q12Shape51T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738947 (3338665984 ||| 2^14) q12Shape51T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738947 ||| 2^14) 3338665984 q12Shape51T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T25OK,q12Shape51T26OK⟩

private def q12Shape51T20 : Tree 12 := .split 6 q12Shape51T21 q12Shape51T24
private theorem q12Shape51T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738883 3338665984 q12Shape51T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738883 (3338665984 ||| 2^6) q12Shape51T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738883 ||| 2^6) 3338665984 q12Shape51T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T21OK,q12Shape51T24OK⟩

private def q12Shape51T16 : Tree 12 := .split 9 q12Shape51T17 q12Shape51T20
private theorem q12Shape51T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738371 3338665984 q12Shape51T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738371 (3338665984 ||| 2^9) q12Shape51T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738371 ||| 2^9) 3338665984 q12Shape51T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T17OK,q12Shape51T20OK⟩

private def q12Shape51T10 : Tree 12 := .split 1 q12Shape51T11 q12Shape51T16
private theorem q12Shape51T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738369 3338665984 q12Shape51T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738369 (3338665984 ||| 2^1) q12Shape51T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738369 ||| 2^1) 3338665984 q12Shape51T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T11OK,q12Shape51T16OK⟩

private def q12Shape51T2 : Tree 12 := .split 0 q12Shape51T3 q12Shape51T10
private theorem q12Shape51T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738368 3338665984 q12Shape51T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34359738368 (3338665984 ||| 2^0) q12Shape51T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (34359738368 ||| 2^0) 3338665984 q12Shape51T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T3OK,q12Shape51T10OK⟩

private def q12Shape51T0 : Tree 12 := .split 35 q12Shape51T1 q12Shape51T2
private theorem q12Shape51T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 3338665984 q12Shape51T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 (3338665984 ||| 2^35) q12Shape51T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (0 ||| 2^35) 3338665984 q12Shape51T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T1OK,q12Shape51T2OK⟩

def q12Shape51P0 : Tree 12 := q12Shape51T0
theorem q12Shape51P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 0 3338665984 q12Shape51P0=true := q12Shape51T0OK

end Graffiti384b.EffectiveSearch.Q12
