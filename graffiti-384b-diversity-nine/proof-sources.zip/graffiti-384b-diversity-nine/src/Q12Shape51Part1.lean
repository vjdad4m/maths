import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51T30 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11}))))))
private theorem q12Shape51T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 35550920707 q12Shape51T30=true := by decide

private def q12Shape51T32 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))))
private theorem q12Shape51T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483650 35550921217 q12Shape51T32=true := by decide

private def q12Shape51T34 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))))
private theorem q12Shape51T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484162 35550920769 q12Shape51T34=true := by decide

private def q12Shape51T36 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11})))) (.tip (.cover {0,1,2,6,7,10,11}))))
private theorem q12Shape51T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484226 35550937089 q12Shape51T36=true := by decide

private def q12Shape51T37 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11})))
private theorem q12Shape51T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147500610 35550920705 q12Shape51T37=true := by decide

private def q12Shape51T35 : Tree 12 := .split 14 q12Shape51T36 q12Shape51T37
private theorem q12Shape51T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484226 35550920705 q12Shape51T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484226 (35550920705 ||| 2^14) q12Shape51T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147484226 ||| 2^14) 35550920705 q12Shape51T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T36OK,q12Shape51T37OK⟩

private def q12Shape51T33 : Tree 12 := .split 6 q12Shape51T34 q12Shape51T35
private theorem q12Shape51T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484162 35550920705 q12Shape51T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484162 (35550920705 ||| 2^6) q12Shape51T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147484162 ||| 2^6) 35550920705 q12Shape51T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T34OK,q12Shape51T35OK⟩

private def q12Shape51T31 : Tree 12 := .split 9 q12Shape51T32 q12Shape51T33
private theorem q12Shape51T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483650 35550920705 q12Shape51T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483650 (35550920705 ||| 2^9) q12Shape51T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483650 ||| 2^9) 35550920705 q12Shape51T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T32OK,q12Shape51T33OK⟩

private def q12Shape51T29 : Tree 12 := .split 1 q12Shape51T30 q12Shape51T31
private theorem q12Shape51T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 35550920705 q12Shape51T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 (35550920705 ||| 2^1) q12Shape51T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483648 ||| 2^1) 35550920705 q12Shape51T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T30OK,q12Shape51T31OK⟩

private def q12Shape51T40 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10,11})))))
private theorem q12Shape51T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483649 35550921218 q12Shape51T40=true := by decide

private def q12Shape51T42 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,5,6,7,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))))
private theorem q12Shape51T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484161 35550920770 q12Shape51T42=true := by decide

private def q12Shape51T44 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))))
private theorem q12Shape51T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484225 35550937090 q12Shape51T44=true := by decide

private def q12Shape51T45 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11})))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11})))
private theorem q12Shape51T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147500609 35550920706 q12Shape51T45=true := by decide

private def q12Shape51T43 : Tree 12 := .split 14 q12Shape51T44 q12Shape51T45
private theorem q12Shape51T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484225 35550920706 q12Shape51T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484225 (35550920706 ||| 2^14) q12Shape51T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147484225 ||| 2^14) 35550920706 q12Shape51T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T44OK,q12Shape51T45OK⟩

private def q12Shape51T41 : Tree 12 := .split 6 q12Shape51T42 q12Shape51T43
private theorem q12Shape51T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484161 35550920706 q12Shape51T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484161 (35550920706 ||| 2^6) q12Shape51T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147484161 ||| 2^6) 35550920706 q12Shape51T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T42OK,q12Shape51T43OK⟩

private def q12Shape51T39 : Tree 12 := .split 9 q12Shape51T40 q12Shape51T41
private theorem q12Shape51T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483649 35550920706 q12Shape51T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483649 (35550920706 ||| 2^9) q12Shape51T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483649 ||| 2^9) 35550920706 q12Shape51T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T40OK,q12Shape51T41OK⟩

private def q12Shape51T48 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))))
private theorem q12Shape51T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483651 35550921280 q12Shape51T48=true := by decide

private def q12Shape51T50 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))))
private theorem q12Shape51T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483715 35550937600 q12Shape51T50=true := by decide

private def q12Shape51T51 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11})))
private theorem q12Shape51T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147500099 35550921216 q12Shape51T51=true := by decide

private def q12Shape51T49 : Tree 12 := .split 14 q12Shape51T50 q12Shape51T51
private theorem q12Shape51T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483715 35550921216 q12Shape51T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483715 (35550921216 ||| 2^14) q12Shape51T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483715 ||| 2^14) 35550921216 q12Shape51T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T50OK,q12Shape51T51OK⟩

private def q12Shape51T47 : Tree 12 := .split 6 q12Shape51T48 q12Shape51T49
private theorem q12Shape51T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483651 35550921216 q12Shape51T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483651 (35550921216 ||| 2^6) q12Shape51T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483651 ||| 2^6) 35550921216 q12Shape51T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T48OK,q12Shape51T49OK⟩

private def q12Shape51T54 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11})))) (.tip (.cover {0,2,6,7,9,10,11}))))
private theorem q12Shape51T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484163 35550937152 q12Shape51T54=true := by decide

private def q12Shape51T56 : Tree 12 := (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11})))) (.tip (.cover {0,2,6,7,9,10,11})))
private theorem q12Shape51T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147500547 35553017920 q12Shape51T56=true := by decide

private def q12Shape51T57 : Tree 12 := (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {0,2,6,7,9,10,11})))
private theorem q12Shape51T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2149597699 35550920768 q12Shape51T57=true := by decide

private def q12Shape51T55 : Tree 12 := .split 21 q12Shape51T56 q12Shape51T57
private theorem q12Shape51T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147500547 35550920768 q12Shape51T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147500547 (35550920768 ||| 2^21) q12Shape51T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147500547 ||| 2^21) 35550920768 q12Shape51T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T56OK,q12Shape51T57OK⟩

private def q12Shape51T53 : Tree 12 := .split 14 q12Shape51T54 q12Shape51T55
private theorem q12Shape51T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484163 35550920768 q12Shape51T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484163 (35550920768 ||| 2^14) q12Shape51T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147484163 ||| 2^14) 35550920768 q12Shape51T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T54OK,q12Shape51T55OK⟩

private def q12Shape51T59 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))))
private theorem q12Shape51T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484227 35550937088 q12Shape51T59=true := by decide

private def q12Shape51T60 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,7,10,11}))) (.tip (.cover {0,5,6,7,9,10,11})))
private theorem q12Shape51T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147500611 35550920704 q12Shape51T60=true := by decide

private def q12Shape51T58 : Tree 12 := .split 14 q12Shape51T59 q12Shape51T60
private theorem q12Shape51T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484227 35550920704 q12Shape51T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484227 (35550920704 ||| 2^14) q12Shape51T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147484227 ||| 2^14) 35550920704 q12Shape51T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T59OK,q12Shape51T60OK⟩

private def q12Shape51T52 : Tree 12 := .split 6 q12Shape51T53 q12Shape51T58
private theorem q12Shape51T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484163 35550920704 q12Shape51T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147484163 (35550920704 ||| 2^6) q12Shape51T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147484163 ||| 2^6) 35550920704 q12Shape51T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T53OK,q12Shape51T58OK⟩

private def q12Shape51T46 : Tree 12 := .split 9 q12Shape51T47 q12Shape51T52
private theorem q12Shape51T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483651 35550920704 q12Shape51T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483651 (35550920704 ||| 2^9) q12Shape51T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483651 ||| 2^9) 35550920704 q12Shape51T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T47OK,q12Shape51T52OK⟩

private def q12Shape51T38 : Tree 12 := .split 1 q12Shape51T39 q12Shape51T46
private theorem q12Shape51T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483649 35550920704 q12Shape51T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483649 (35550920704 ||| 2^1) q12Shape51T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483649 ||| 2^1) 35550920704 q12Shape51T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T39OK,q12Shape51T46OK⟩

private def q12Shape51T28 : Tree 12 := .split 0 q12Shape51T29 q12Shape51T38
private theorem q12Shape51T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 35550920704 q12Shape51T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 (35550920704 ||| 2^0) q12Shape51T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483648 ||| 2^0) 35550920704 q12Shape51T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T29OK,q12Shape51T38OK⟩

private def q12Shape51T61 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape51T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 36507222016 1191182336 q12Shape51T61=true := by decide

private def q12Shape51T27 : Tree 12 := .split 35 q12Shape51T28 q12Shape51T61
private theorem q12Shape51T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 1191182336 q12Shape51T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 (1191182336 ||| 2^35) q12Shape51T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (2147483648 ||| 2^35) 1191182336 q12Shape51T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T28OK,q12Shape51T61OK⟩

def q12Shape51P1 : Tree 12 := q12Shape51T27
theorem q12Shape51P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2147483648 1191182336 q12Shape51P1=true := q12Shape51T27OK

end Graffiti384b.EffectiveSearch.Q12
