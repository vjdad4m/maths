import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51T64 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11}))))))
private theorem q12Shape51T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 36624662531 q12Shape51T64=true := by decide

private def q12Shape51T66 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))))
private theorem q12Shape51T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741826 36624663041 q12Shape51T66=true := by decide

private def q12Shape51T68 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))))
private theorem q12Shape51T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742338 36624662593 q12Shape51T68=true := by decide

private def q12Shape51T71 : Tree 12 := (.tip (.small 1))
private theorem q12Shape51T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742402 36626776065 q12Shape51T71=true := by decide

private def q12Shape51T72 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11})))) (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {0,1,2,5,8,10,11})))) (.tip (.cover {0,1,2,6,8,10,11})))
private theorem q12Shape51T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1075839554 36624678913 q12Shape51T72=true := by decide

private def q12Shape51T70 : Tree 12 := .split 21 q12Shape51T71 q12Shape51T72
private theorem q12Shape51T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742402 36624678913 q12Shape51T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742402 (36624678913 ||| 2^21) q12Shape51T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742402 ||| 2^21) 36624678913 q12Shape51T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T71OK,q12Shape51T72OK⟩

private def q12Shape51T73 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,3,5,6,8,10,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,5,6,8,9,10,11})))
private theorem q12Shape51T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758786 36624662529 q12Shape51T73=true := by decide

private def q12Shape51T69 : Tree 12 := .split 14 q12Shape51T70 q12Shape51T73
private theorem q12Shape51T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742402 36624662529 q12Shape51T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742402 (36624662529 ||| 2^14) q12Shape51T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742402 ||| 2^14) 36624662529 q12Shape51T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T70OK,q12Shape51T73OK⟩

private def q12Shape51T67 : Tree 12 := .split 6 q12Shape51T68 q12Shape51T69
private theorem q12Shape51T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742338 36624662529 q12Shape51T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742338 (36624662529 ||| 2^6) q12Shape51T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742338 ||| 2^6) 36624662529 q12Shape51T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T68OK,q12Shape51T69OK⟩

private def q12Shape51T65 : Tree 12 := .split 9 q12Shape51T66 q12Shape51T67
private theorem q12Shape51T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741826 36624662529 q12Shape51T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741826 (36624662529 ||| 2^9) q12Shape51T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741826 ||| 2^9) 36624662529 q12Shape51T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T66OK,q12Shape51T67OK⟩

private def q12Shape51T63 : Tree 12 := .split 1 q12Shape51T64 q12Shape51T65
private theorem q12Shape51T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 36624662529 q12Shape51T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 (36624662529 ||| 2^1) q12Shape51T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741824 ||| 2^1) 36624662529 q12Shape51T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T64OK,q12Shape51T65OK⟩

def q12Shape51P2 : Tree 12 := q12Shape51T63
theorem q12Shape51P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741824 36624662529 q12Shape51P2=true := q12Shape51T63OK

end Graffiti384b.EffectiveSearch.Q12
