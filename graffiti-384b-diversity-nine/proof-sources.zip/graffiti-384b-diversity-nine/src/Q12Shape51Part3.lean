import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51T76 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))))
private theorem q12Shape51T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741825 36624663042 q12Shape51T76=true := by decide

private def q12Shape51T78 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,5,7,8,9,10,11}))) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))))
private theorem q12Shape51T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742337 36624662594 q12Shape51T78=true := by decide

private def q12Shape51T80 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,4,5,6,8,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,8,10,11}))))
private theorem q12Shape51T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742401 36624678914 q12Shape51T80=true := by decide

private def q12Shape51T82 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11})))) (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {0,1,2,5,8,10,11})))) (.tip (.cover {0,1,2,6,8,10,11})))
private theorem q12Shape51T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758785 36626759682 q12Shape51T82=true := by decide

private def q12Shape51T83 : Tree 12 := (.tip (.cover {0,5,6,8,9,10,11}))
private theorem q12Shape51T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1075855937 36624662530 q12Shape51T83=true := by decide

private def q12Shape51T81 : Tree 12 := .split 21 q12Shape51T82 q12Shape51T83
private theorem q12Shape51T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758785 36624662530 q12Shape51T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758785 (36624662530 ||| 2^21) q12Shape51T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073758785 ||| 2^21) 36624662530 q12Shape51T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T82OK,q12Shape51T83OK⟩

private def q12Shape51T79 : Tree 12 := .split 14 q12Shape51T80 q12Shape51T81
private theorem q12Shape51T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742401 36624662530 q12Shape51T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742401 (36624662530 ||| 2^14) q12Shape51T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742401 ||| 2^14) 36624662530 q12Shape51T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T80OK,q12Shape51T81OK⟩

private def q12Shape51T77 : Tree 12 := .split 6 q12Shape51T78 q12Shape51T79
private theorem q12Shape51T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742337 36624662530 q12Shape51T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742337 (36624662530 ||| 2^6) q12Shape51T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742337 ||| 2^6) 36624662530 q12Shape51T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T78OK,q12Shape51T79OK⟩

private def q12Shape51T75 : Tree 12 := .split 9 q12Shape51T76 q12Shape51T77
private theorem q12Shape51T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741825 36624662530 q12Shape51T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741825 (36624662530 ||| 2^9) q12Shape51T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741825 ||| 2^9) 36624662530 q12Shape51T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T76OK,q12Shape51T77OK⟩

private def q12Shape51T86 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {2,5,6,8,9,10,11}))) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))))
private theorem q12Shape51T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741827 36624663104 q12Shape51T86=true := by decide

private def q12Shape51T88 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,6,8,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,8,10,11}))))
private theorem q12Shape51T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741891 36624679424 q12Shape51T88=true := by decide

private def q12Shape51T89 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,6,8,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,5,6,8,9,10,11})))
private theorem q12Shape51T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758275 36624663040 q12Shape51T89=true := by decide

private def q12Shape51T87 : Tree 12 := .split 14 q12Shape51T88 q12Shape51T89
private theorem q12Shape51T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741891 36624663040 q12Shape51T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741891 (36624663040 ||| 2^14) q12Shape51T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741891 ||| 2^14) 36624663040 q12Shape51T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T88OK,q12Shape51T89OK⟩

private def q12Shape51T85 : Tree 12 := .split 6 q12Shape51T86 q12Shape51T87
private theorem q12Shape51T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741827 36624663040 q12Shape51T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741827 (36624663040 ||| 2^6) q12Shape51T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741827 ||| 2^6) 36624663040 q12Shape51T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T86OK,q12Shape51T87OK⟩

private def q12Shape51T93 : Tree 12 := (.tip (.small 1))
private theorem q12Shape51T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742339 36626776128 q12Shape51T93=true := by decide

private def q12Shape51T94 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11})))) (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,2,3,4,9,10,11})))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape51T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1075839491 36624678976 q12Shape51T94=true := by decide

private def q12Shape51T92 : Tree 12 := .split 21 q12Shape51T93 q12Shape51T94
private theorem q12Shape51T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742339 36624678976 q12Shape51T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742339 (36624678976 ||| 2^21) q12Shape51T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742339 ||| 2^21) 36624678976 q12Shape51T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T93OK,q12Shape51T94OK⟩

private def q12Shape51T96 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11})))) (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,2,3,4,9,10,11})))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape51T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758723 36626759744 q12Shape51T96=true := by decide

private def q12Shape51T97 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {2,5,6,8,9,10,11}))) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {0,2,6,8,9,10,11})))
private theorem q12Shape51T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1075855875 36624662592 q12Shape51T97=true := by decide

private def q12Shape51T95 : Tree 12 := .split 21 q12Shape51T96 q12Shape51T97
private theorem q12Shape51T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758723 36624662592 q12Shape51T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758723 (36624662592 ||| 2^21) q12Shape51T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073758723 ||| 2^21) 36624662592 q12Shape51T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T96OK,q12Shape51T97OK⟩

private def q12Shape51T91 : Tree 12 := .split 14 q12Shape51T92 q12Shape51T95
private theorem q12Shape51T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742339 36624662592 q12Shape51T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742339 (36624662592 ||| 2^14) q12Shape51T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742339 ||| 2^14) 36624662592 q12Shape51T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T92OK,q12Shape51T95OK⟩

private def q12Shape51T100 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,6,8,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,8,10,11})))
private theorem q12Shape51T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742403 36626776064 q12Shape51T100=true := by decide

private def q12Shape51T101 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,4,5,6,8,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,8,10,11})))
private theorem q12Shape51T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1075839555 36624678912 q12Shape51T101=true := by decide

private def q12Shape51T99 : Tree 12 := .split 21 q12Shape51T100 q12Shape51T101
private theorem q12Shape51T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742403 36624678912 q12Shape51T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742403 (36624678912 ||| 2^21) q12Shape51T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742403 ||| 2^21) 36624678912 q12Shape51T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T100OK,q12Shape51T101OK⟩

private def q12Shape51T102 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,6,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,3,5,6,8,10,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,5,6,8,9,10,11})))
private theorem q12Shape51T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073758787 36624662528 q12Shape51T102=true := by decide

private def q12Shape51T98 : Tree 12 := .split 14 q12Shape51T99 q12Shape51T102
private theorem q12Shape51T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742403 36624662528 q12Shape51T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742403 (36624662528 ||| 2^14) q12Shape51T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742403 ||| 2^14) 36624662528 q12Shape51T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T99OK,q12Shape51T102OK⟩

private def q12Shape51T90 : Tree 12 := .split 6 q12Shape51T91 q12Shape51T98
private theorem q12Shape51T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742339 36624662528 q12Shape51T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073742339 (36624662528 ||| 2^6) q12Shape51T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073742339 ||| 2^6) 36624662528 q12Shape51T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T91OK,q12Shape51T98OK⟩

private def q12Shape51T84 : Tree 12 := .split 9 q12Shape51T85 q12Shape51T90
private theorem q12Shape51T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741827 36624662528 q12Shape51T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741827 (36624662528 ||| 2^9) q12Shape51T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741827 ||| 2^9) 36624662528 q12Shape51T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T85OK,q12Shape51T90OK⟩

private def q12Shape51T74 : Tree 12 := .split 1 q12Shape51T75 q12Shape51T84
private theorem q12Shape51T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741825 36624662528 q12Shape51T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741825 (36624662528 ||| 2^1) q12Shape51T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (1073741825 ||| 2^1) 36624662528 q12Shape51T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T75OK,q12Shape51T84OK⟩

def q12Shape51P3 : Tree 12 := q12Shape51T74
theorem q12Shape51P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1073741825 36624662528 q12Shape51P3=true := q12Shape51T74OK

private def q12Shape51T104 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape51T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35433480192 2264924160 q12Shape51T104=true := by decide

def q12Shape51P4 : Tree 12 := q12Shape51T104
theorem q12Shape51P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35433480192 2264924160 q12Shape51P4=true := q12Shape51T104OK

private def q12Shape51T106 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape51T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 3221225472 117440512 q12Shape51T106=true := by decide

def q12Shape51P5 : Tree 12 := q12Shape51T106
theorem q12Shape51P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 3221225472 117440512 q12Shape51P5=true := q12Shape51T106OK

end Graffiti384b.EffectiveSearch.Q12
