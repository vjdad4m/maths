import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51T164 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))))
private theorem q12Shape51T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554433 37664850434 q12Shape51T164=true := by decide

private def q12Shape51T166 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,6,7,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,5,6,8,9,10,11})))))
private theorem q12Shape51T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554945 37664849986 q12Shape51T166=true := by decide

private def q12Shape51T168 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,4,5,6,8,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))))
private theorem q12Shape51T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555009 37664866306 q12Shape51T168=true := by decide

private def q12Shape51T171 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11})))) (.tip (.cover {0,1,2,5,8,10,11})))
private theorem q12Shape51T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571393 37666947078 q12Shape51T171=true := by decide

private def q12Shape51T172 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {0,1,2,6,8,10,11}))) (.tip (.cover {0,1,2,5,8,10,11})))
private theorem q12Shape51T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571397 37666947074 q12Shape51T172=true := by decide

private def q12Shape51T170 : Tree 12 := .split 2 q12Shape51T171 q12Shape51T172
private theorem q12Shape51T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571393 37666947074 q12Shape51T170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571393 (37666947074 ||| 2^2) q12Shape51T171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33571393 ||| 2^2) 37666947074 q12Shape51T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T171OK,q12Shape51T172OK⟩

private def q12Shape51T173 : Tree 12 := (.tip (.cover {0,5,6,8,9,10,11}))
private theorem q12Shape51T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35668545 37664849922 q12Shape51T173=true := by decide

private def q12Shape51T169 : Tree 12 := .split 21 q12Shape51T170 q12Shape51T173
private theorem q12Shape51T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571393 37664849922 q12Shape51T169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571393 (37664849922 ||| 2^21) q12Shape51T170 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33571393 ||| 2^21) 37664849922 q12Shape51T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T170OK,q12Shape51T173OK⟩

private def q12Shape51T167 : Tree 12 := .split 14 q12Shape51T168 q12Shape51T169
private theorem q12Shape51T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555009 37664849922 q12Shape51T167=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555009 (37664849922 ||| 2^14) q12Shape51T168 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33555009 ||| 2^14) 37664849922 q12Shape51T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T168OK,q12Shape51T169OK⟩

private def q12Shape51T165 : Tree 12 := .split 6 q12Shape51T166 q12Shape51T167
private theorem q12Shape51T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554945 37664849922 q12Shape51T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554945 (37664849922 ||| 2^6) q12Shape51T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554945 ||| 2^6) 37664849922 q12Shape51T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T166OK,q12Shape51T167OK⟩

private def q12Shape51T163 : Tree 12 := .split 9 q12Shape51T164 q12Shape51T165
private theorem q12Shape51T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554433 37664849922 q12Shape51T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554433 (37664849922 ||| 2^9) q12Shape51T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554433 ||| 2^9) 37664849922 q12Shape51T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T164OK,q12Shape51T165OK⟩

private def q12Shape51T176 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {2,5,6,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {2,6,7,8,9,10,11})))))
private theorem q12Shape51T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554435 37664850496 q12Shape51T176=true := by decide

private def q12Shape51T178 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,6,8,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11}))))
private theorem q12Shape51T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554499 37664866816 q12Shape51T178=true := by decide

private def q12Shape51T179 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,6,8,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11}))) (.tip (.cover {0,5,6,8,9,10,11})))
private theorem q12Shape51T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33570883 37664850432 q12Shape51T179=true := by decide

private def q12Shape51T177 : Tree 12 := .split 14 q12Shape51T178 q12Shape51T179
private theorem q12Shape51T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554499 37664850432 q12Shape51T177=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554499 (37664850432 ||| 2^14) q12Shape51T178 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554499 ||| 2^14) 37664850432 q12Shape51T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T178OK,q12Shape51T179OK⟩

private def q12Shape51T175 : Tree 12 := .split 6 q12Shape51T176 q12Shape51T177
private theorem q12Shape51T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554435 37664850432 q12Shape51T175=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554435 (37664850432 ||| 2^6) q12Shape51T176 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554435 ||| 2^6) 37664850432 q12Shape51T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T176OK,q12Shape51T177OK⟩

private def q12Shape51T183 : Tree 12 := (.tip (.small 1))
private theorem q12Shape51T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554947 37666963520 q12Shape51T183=true := by decide

private def q12Shape51T185 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11})))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape51T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35652099 37664866372 q12Shape51T185=true := by decide

private def q12Shape51T186 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,2,3,4,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape51T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35652103 37664866368 q12Shape51T186=true := by decide

private def q12Shape51T184 : Tree 12 := .split 2 q12Shape51T185 q12Shape51T186
private theorem q12Shape51T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35652099 37664866368 q12Shape51T184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35652099 (37664866368 ||| 2^2) q12Shape51T185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (35652099 ||| 2^2) 37664866368 q12Shape51T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T185OK,q12Shape51T186OK⟩

private def q12Shape51T182 : Tree 12 := .split 21 q12Shape51T183 q12Shape51T184
private theorem q12Shape51T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554947 37664866368 q12Shape51T182=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554947 (37664866368 ||| 2^21) q12Shape51T183 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554947 ||| 2^21) 37664866368 q12Shape51T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T183OK,q12Shape51T184OK⟩

private def q12Shape51T189 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11})))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape51T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571331 37666947140 q12Shape51T189=true := by decide

private def q12Shape51T190 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {0,2,3,4,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape51T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571335 37666947136 q12Shape51T190=true := by decide

private def q12Shape51T188 : Tree 12 := .split 2 q12Shape51T189 q12Shape51T190
private theorem q12Shape51T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571331 37666947136 q12Shape51T188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571331 (37666947136 ||| 2^2) q12Shape51T189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33571331 ||| 2^2) 37666947136 q12Shape51T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T189OK,q12Shape51T190OK⟩

private def q12Shape51T191 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,6,9,10,11}))) (.tip (.cover {2,5,6,8,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {2,6,7,8,9,10,11})))
private theorem q12Shape51T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35668483 37664849984 q12Shape51T191=true := by decide

private def q12Shape51T187 : Tree 12 := .split 21 q12Shape51T188 q12Shape51T191
private theorem q12Shape51T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571331 37664849984 q12Shape51T187=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571331 (37664849984 ||| 2^21) q12Shape51T188 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33571331 ||| 2^21) 37664849984 q12Shape51T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T188OK,q12Shape51T191OK⟩

private def q12Shape51T181 : Tree 12 := .split 14 q12Shape51T182 q12Shape51T187
private theorem q12Shape51T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554947 37664849984 q12Shape51T181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554947 (37664849984 ||| 2^14) q12Shape51T182 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554947 ||| 2^14) 37664849984 q12Shape51T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T182OK,q12Shape51T187OK⟩

private def q12Shape51T194 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {1,2,5,6,8,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape51T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555011 37666963456 q12Shape51T194=true := by decide

private def q12Shape51T195 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,4,5,6,8,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11})))
private theorem q12Shape51T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 35652163 37664866304 q12Shape51T195=true := by decide

private def q12Shape51T193 : Tree 12 := .split 21 q12Shape51T194 q12Shape51T195
private theorem q12Shape51T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555011 37664866304 q12Shape51T193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555011 (37664866304 ||| 2^21) q12Shape51T194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33555011 ||| 2^21) 37664866304 q12Shape51T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T194OK,q12Shape51T195OK⟩

private def q12Shape51T196 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,6,10,11}))) (.tip (.cover {2,3,5,6,8,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {0,5,6,8,9,10,11})))
private theorem q12Shape51T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33571395 37664849920 q12Shape51T196=true := by decide

private def q12Shape51T192 : Tree 12 := .split 14 q12Shape51T193 q12Shape51T196
private theorem q12Shape51T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555011 37664849920 q12Shape51T192=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33555011 (37664849920 ||| 2^14) q12Shape51T193 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33555011 ||| 2^14) 37664849920 q12Shape51T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T193OK,q12Shape51T196OK⟩

private def q12Shape51T180 : Tree 12 := .split 6 q12Shape51T181 q12Shape51T192
private theorem q12Shape51T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554947 37664849920 q12Shape51T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554947 (37664849920 ||| 2^6) q12Shape51T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554947 ||| 2^6) 37664849920 q12Shape51T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T181OK,q12Shape51T192OK⟩

private def q12Shape51T174 : Tree 12 := .split 9 q12Shape51T175 q12Shape51T180
private theorem q12Shape51T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554435 37664849920 q12Shape51T174=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554435 (37664849920 ||| 2^9) q12Shape51T175 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554435 ||| 2^9) 37664849920 q12Shape51T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T175OK,q12Shape51T180OK⟩

private def q12Shape51T162 : Tree 12 := .split 1 q12Shape51T163 q12Shape51T174
private theorem q12Shape51T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554433 37664849920 q12Shape51T162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554433 (37664849920 ||| 2^1) q12Shape51T163 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (33554433 ||| 2^1) 37664849920 q12Shape51T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T163OK,q12Shape51T174OK⟩

def q12Shape51P10 : Tree 12 := q12Shape51T162
theorem q12Shape51P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 33554433 37664849920 q12Shape51P10=true := q12Shape51T162OK

private def q12Shape51T198 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape51T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34393292800 3305111552 q12Shape51T198=true := by decide

def q12Shape51P11 : Tree 12 := q12Shape51T198
theorem q12Shape51P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34393292800 3305111552 q12Shape51P11=true := q12Shape51T198OK

private def q12Shape51T200 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape51T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2181038080 1157627904 q12Shape51T200=true := by decide

def q12Shape51P12 : Tree 12 := q12Shape51T200
theorem q12Shape51P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2181038080 1157627904 q12Shape51P12=true := q12Shape51T200OK

private def q12Shape51T202 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape51T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1107296256 83886080 q12Shape51T202=true := by decide

def q12Shape51P13 : Tree 12 := q12Shape51T202
theorem q12Shape51P13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1107296256 83886080 q12Shape51P13=true := q12Shape51T202OK

private def q12Shape51T204 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape51T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 100663296 16777216 q12Shape51T204=true := by decide

def q12Shape51P14 : Tree 12 := q12Shape51T204
theorem q12Shape51P14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 100663296 16777216 q12Shape51P14=true := q12Shape51T204OK

end Graffiti384b.EffectiveSearch.Q12
