import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51T208 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10,11}))))))
private theorem q12Shape51T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 37681627139 q12Shape51T208=true := by decide

private def q12Shape51T210 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape51T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777218 37681627649 q12Shape51T210=true := by decide

private def q12Shape51T212 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,6,7,8,9,10,11}))) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape51T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777730 37681627201 q12Shape51T212=true := by decide

private def q12Shape51T215 : Tree 12 := (.tip (.small 1))
private theorem q12Shape51T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777794 37683740673 q12Shape51T215=true := by decide

private def q12Shape51T217 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))))
private theorem q12Shape51T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874946 37681643525 q12Shape51T217=true := by decide

private def q12Shape51T218 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {0,1,2,7,8,10,11})))
private theorem q12Shape51T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874950 37681643521 q12Shape51T218=true := by decide

private def q12Shape51T216 : Tree 12 := .split 2 q12Shape51T217 q12Shape51T218
private theorem q12Shape51T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874946 37681643521 q12Shape51T216=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874946 (37681643521 ||| 2^2) q12Shape51T217 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (18874946 ||| 2^2) 37681643521 q12Shape51T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T217OK,q12Shape51T218OK⟩

private def q12Shape51T214 : Tree 12 := .split 21 q12Shape51T215 q12Shape51T216
private theorem q12Shape51T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777794 37681643521 q12Shape51T214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777794 (37681643521 ||| 2^21) q12Shape51T215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777794 ||| 2^21) 37681643521 q12Shape51T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T215OK,q12Shape51T216OK⟩

private def q12Shape51T219 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {0,5,7,8,9,10,11})))
private theorem q12Shape51T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794178 37681627137 q12Shape51T219=true := by decide

private def q12Shape51T213 : Tree 12 := .split 14 q12Shape51T214 q12Shape51T219
private theorem q12Shape51T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777794 37681627137 q12Shape51T213=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777794 (37681627137 ||| 2^14) q12Shape51T214 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777794 ||| 2^14) 37681627137 q12Shape51T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T214OK,q12Shape51T219OK⟩

private def q12Shape51T211 : Tree 12 := .split 6 q12Shape51T212 q12Shape51T213
private theorem q12Shape51T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777730 37681627137 q12Shape51T211=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777730 (37681627137 ||| 2^6) q12Shape51T212 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777730 ||| 2^6) 37681627137 q12Shape51T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T212OK,q12Shape51T213OK⟩

private def q12Shape51T209 : Tree 12 := .split 9 q12Shape51T210 q12Shape51T211
private theorem q12Shape51T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777218 37681627137 q12Shape51T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777218 (37681627137 ||| 2^9) q12Shape51T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777218 ||| 2^9) 37681627137 q12Shape51T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T210OK,q12Shape51T211OK⟩

private def q12Shape51T207 : Tree 12 := .split 1 q12Shape51T208 q12Shape51T209
private theorem q12Shape51T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 37681627137 q12Shape51T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 (37681627137 ||| 2^1) q12Shape51T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777216 ||| 2^1) 37681627137 q12Shape51T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T208OK,q12Shape51T209OK⟩

def q12Shape51P15 : Tree 12 := q12Shape51T207
theorem q12Shape51P15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777216 37681627137 q12Shape51P15=true := q12Shape51T207OK

end Graffiti384b.EffectiveSearch.Q12
