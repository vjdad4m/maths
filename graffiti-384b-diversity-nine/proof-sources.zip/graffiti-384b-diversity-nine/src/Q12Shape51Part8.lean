import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape51T222 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape51T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777217 37681627650 q12Shape51T222=true := by decide

private def q12Shape51T224 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,6,7,8,9,10,11}))) (.tip (.cover {0,5,7,8,9,10,11})))))
private theorem q12Shape51T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777729 37681627202 q12Shape51T224=true := by decide

private def q12Shape51T226 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11}))))
private theorem q12Shape51T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777793 37681643522 q12Shape51T226=true := by decide

private def q12Shape51T229 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))))
private theorem q12Shape51T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794177 37683724294 q12Shape51T229=true := by decide

private def q12Shape51T230 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {0,1,2,7,8,10,11})))
private theorem q12Shape51T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794181 37683724290 q12Shape51T230=true := by decide

private def q12Shape51T228 : Tree 12 := .split 2 q12Shape51T229 q12Shape51T230
private theorem q12Shape51T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794177 37683724290 q12Shape51T228=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794177 (37683724290 ||| 2^2) q12Shape51T229 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16794177 ||| 2^2) 37683724290 q12Shape51T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T229OK,q12Shape51T230OK⟩

private def q12Shape51T231 : Tree 12 := (.tip (.cover {0,5,7,8,9,10,11}))
private theorem q12Shape51T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18891329 37681627138 q12Shape51T231=true := by decide

private def q12Shape51T227 : Tree 12 := .split 21 q12Shape51T228 q12Shape51T231
private theorem q12Shape51T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794177 37681627138 q12Shape51T227=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794177 (37681627138 ||| 2^21) q12Shape51T228 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16794177 ||| 2^21) 37681627138 q12Shape51T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T228OK,q12Shape51T231OK⟩

private def q12Shape51T225 : Tree 12 := .split 14 q12Shape51T226 q12Shape51T227
private theorem q12Shape51T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777793 37681627138 q12Shape51T225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777793 (37681627138 ||| 2^14) q12Shape51T226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777793 ||| 2^14) 37681627138 q12Shape51T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T226OK,q12Shape51T227OK⟩

private def q12Shape51T223 : Tree 12 := .split 6 q12Shape51T224 q12Shape51T225
private theorem q12Shape51T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777729 37681627138 q12Shape51T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777729 (37681627138 ||| 2^6) q12Shape51T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777729 ||| 2^6) 37681627138 q12Shape51T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T224OK,q12Shape51T225OK⟩

private def q12Shape51T221 : Tree 12 := .split 9 q12Shape51T222 q12Shape51T223
private theorem q12Shape51T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777217 37681627138 q12Shape51T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777217 (37681627138 ||| 2^9) q12Shape51T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777217 ||| 2^9) 37681627138 q12Shape51T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T222OK,q12Shape51T223OK⟩

private def q12Shape51T234 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {2,6,7,8,9,10,11})))))
private theorem q12Shape51T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777219 37681627712 q12Shape51T234=true := by decide

private def q12Shape51T236 : Tree 12 := (.split 21 (.tip (.small 1)) (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11}))))
private theorem q12Shape51T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777283 37681644032 q12Shape51T236=true := by decide

private def q12Shape51T237 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11}))) (.tip (.cover {0,5,7,8,9,10,11})))
private theorem q12Shape51T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16793667 37681627648 q12Shape51T237=true := by decide

private def q12Shape51T235 : Tree 12 := .split 14 q12Shape51T236 q12Shape51T237
private theorem q12Shape51T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777283 37681627648 q12Shape51T235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777283 (37681627648 ||| 2^14) q12Shape51T236 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777283 ||| 2^14) 37681627648 q12Shape51T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T236OK,q12Shape51T237OK⟩

private def q12Shape51T233 : Tree 12 := .split 6 q12Shape51T234 q12Shape51T235
private theorem q12Shape51T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777219 37681627648 q12Shape51T233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777219 (37681627648 ||| 2^6) q12Shape51T234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777219 ||| 2^6) 37681627648 q12Shape51T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T234OK,q12Shape51T235OK⟩

private def q12Shape51T241 : Tree 12 := (.tip (.small 1))
private theorem q12Shape51T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777731 37683740736 q12Shape51T241=true := by decide

private def q12Shape51T243 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))))
private theorem q12Shape51T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874883 37681643588 q12Shape51T243=true := by decide

private def q12Shape51T244 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,3,4,9,10,11})))
private theorem q12Shape51T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874887 37681643584 q12Shape51T244=true := by decide

private def q12Shape51T242 : Tree 12 := .split 2 q12Shape51T243 q12Shape51T244
private theorem q12Shape51T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874883 37681643584 q12Shape51T242=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874883 (37681643584 ||| 2^2) q12Shape51T243 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (18874883 ||| 2^2) 37681643584 q12Shape51T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T243OK,q12Shape51T244OK⟩

private def q12Shape51T240 : Tree 12 := .split 21 q12Shape51T241 q12Shape51T242
private theorem q12Shape51T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777731 37681643584 q12Shape51T240=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777731 (37681643584 ||| 2^21) q12Shape51T241 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777731 ||| 2^21) 37681643584 q12Shape51T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T241OK,q12Shape51T242OK⟩

private def q12Shape51T247 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))))
private theorem q12Shape51T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794115 37683724356 q12Shape51T247=true := by decide

private def q12Shape51T248 : Tree 12 := (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {0,2,3,4,9,10,11})))
private theorem q12Shape51T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794119 37683724352 q12Shape51T248=true := by decide

private def q12Shape51T246 : Tree 12 := .split 2 q12Shape51T247 q12Shape51T248
private theorem q12Shape51T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794115 37683724352 q12Shape51T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794115 (37683724352 ||| 2^2) q12Shape51T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16794115 ||| 2^2) 37683724352 q12Shape51T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T247OK,q12Shape51T248OK⟩

private def q12Shape51T249 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,2,5,7,9,10,11}))) (.tip (.cover {0,2,5,8,9,10,11}))) (.tip (.cover {2,5,7,8,9,10,11}))) (.tip (.cover {2,6,7,8,9,10,11})))
private theorem q12Shape51T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18891267 37681627200 q12Shape51T249=true := by decide

private def q12Shape51T245 : Tree 12 := .split 21 q12Shape51T246 q12Shape51T249
private theorem q12Shape51T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794115 37681627200 q12Shape51T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794115 (37681627200 ||| 2^21) q12Shape51T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16794115 ||| 2^21) 37681627200 q12Shape51T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T246OK,q12Shape51T249OK⟩

private def q12Shape51T239 : Tree 12 := .split 14 q12Shape51T240 q12Shape51T245
private theorem q12Shape51T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777731 37681627200 q12Shape51T239=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777731 (37681627200 ||| 2^14) q12Shape51T240 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777731 ||| 2^14) 37681627200 q12Shape51T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T240OK,q12Shape51T245OK⟩

private def q12Shape51T252 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {1,2,5,7,8,10,11}))) (.tip (.cover {1,2,6,7,8,10,11})))
private theorem q12Shape51T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777795 37683740672 q12Shape51T252=true := by decide

private def q12Shape51T253 : Tree 12 := (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {2,4,5,7,8,10,11}))) (.tip (.cover {2,4,6,7,8,10,11})))
private theorem q12Shape51T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 18874947 37681643520 q12Shape51T253=true := by decide

private def q12Shape51T251 : Tree 12 := .split 21 q12Shape51T252 q12Shape51T253
private theorem q12Shape51T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777795 37681643520 q12Shape51T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777795 (37681643520 ||| 2^21) q12Shape51T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777795 ||| 2^21) 37681643520 q12Shape51T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T252OK,q12Shape51T253OK⟩

private def q12Shape51T254 : Tree 12 := (.split 21 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.cover {0,3,4,5,9,10,11})) (.tip (.cover {0,1,2,5,7,10,11}))) (.tip (.cover {0,1,2,5,8,10,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {0,5,7,8,9,10,11})))
private theorem q12Shape51T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16794179 37681627136 q12Shape51T254=true := by decide

private def q12Shape51T250 : Tree 12 := .split 14 q12Shape51T251 q12Shape51T254
private theorem q12Shape51T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777795 37681627136 q12Shape51T250=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777795 (37681627136 ||| 2^14) q12Shape51T251 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777795 ||| 2^14) 37681627136 q12Shape51T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T251OK,q12Shape51T254OK⟩

private def q12Shape51T238 : Tree 12 := .split 6 q12Shape51T239 q12Shape51T250
private theorem q12Shape51T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777731 37681627136 q12Shape51T238=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777731 (37681627136 ||| 2^6) q12Shape51T239 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777731 ||| 2^6) 37681627136 q12Shape51T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T239OK,q12Shape51T250OK⟩

private def q12Shape51T232 : Tree 12 := .split 9 q12Shape51T233 q12Shape51T238
private theorem q12Shape51T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777219 37681627136 q12Shape51T232=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777219 (37681627136 ||| 2^9) q12Shape51T233 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777219 ||| 2^9) 37681627136 q12Shape51T238)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T233OK,q12Shape51T238OK⟩

private def q12Shape51T220 : Tree 12 := .split 1 q12Shape51T221 q12Shape51T232
private theorem q12Shape51T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777217 37681627136 q12Shape51T220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777217 (37681627136 ||| 2^1) q12Shape51T221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) (16777217 ||| 2^1) 37681627136 q12Shape51T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape51T221OK,q12Shape51T232OK⟩

def q12Shape51P16 : Tree 12 := q12Shape51T220
theorem q12Shape51P16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 16777217 37681627136 q12Shape51P16=true := q12Shape51T220OK

private def q12Shape51T256 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape51T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34376515584 3321888768 q12Shape51T256=true := by decide

def q12Shape51P17 : Tree 12 := q12Shape51T256
theorem q12Shape51P17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 34376515584 3321888768 q12Shape51P17=true := q12Shape51T256OK

private def q12Shape51T258 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape51T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2164260864 1174405120 q12Shape51T258=true := by decide

def q12Shape51P18 : Tree 12 := q12Shape51T258
theorem q12Shape51P18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 2164260864 1174405120 q12Shape51P18=true := q12Shape51T258OK

private def q12Shape51T260 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape51T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1090519040 100663296 q12Shape51T260=true := by decide

def q12Shape51P19 : Tree 12 := q12Shape51T260
theorem q12Shape51P19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 1090519040 100663296 q12Shape51P19=true := q12Shape51T260OK

private def q12Shape51T262 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape51T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 83886080 33554432 q12Shape51T262=true := by decide

def q12Shape51P20 : Tree 12 := q12Shape51T262
theorem q12Shape51P20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 83886080 33554432 q12Shape51P20=true := q12Shape51T262OK

private def q12Shape51T264 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape51T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 50331648 0 q12Shape51T264=true := by decide

def q12Shape51P21 : Tree 12 := q12Shape51T264
theorem q12Shape51P21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,3⟩) 50331648 0 q12Shape51P21=true := q12Shape51T264OK

end Graffiti384b.EffectiveSearch.Q12
