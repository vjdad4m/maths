import Q12Shape52Part0

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q12Shape52_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 52) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 52) b) (adj 12 (forms 52) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) adj_mono b H q12Shape52P0 q12Shape52P0OK

#print axioms q12Shape52_cover

end Graffiti384b.EffectiveSearch.Q12
