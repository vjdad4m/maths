import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape52T3 : Tree 12 := (.split 32 (.split 33 (.split 34 (.split 36 (.split 37 (.split 38 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape52T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 37580963840 q12Shape52T3=true := by decide

private def q12Shape52T4 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape52T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 34359738368 3221225472 q12Shape52T4=true := by decide

private def q12Shape52T2 : Tree 12 := .split 35 q12Shape52T3 q12Shape52T4
private theorem q12Shape52T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 3221225472 q12Shape52T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 (3221225472 ||| 2^35) q12Shape52T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) (0 ||| 2^35) 3221225472 q12Shape52T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape52T3OK,q12Shape52T4OK⟩

private def q12Shape52T5 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape52T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 2147483648 1073741824 q12Shape52T5=true := by decide

private def q12Shape52T1 : Tree 12 := .split 31 q12Shape52T2 q12Shape52T5
private theorem q12Shape52T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 1073741824 q12Shape52T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 (1073741824 ||| 2^31) q12Shape52T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) (0 ||| 2^31) 1073741824 q12Shape52T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape52T2OK,q12Shape52T5OK⟩

private def q12Shape52T6 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape52T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 1073741824 0 q12Shape52T6=true := by decide

private def q12Shape52T0 : Tree 12 := .split 30 q12Shape52T1 q12Shape52T6
private theorem q12Shape52T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 0 q12Shape52T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 (0 ||| 2^30) q12Shape52T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) (0 ||| 2^30) 0 q12Shape52T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape52T1OK,q12Shape52T6OK⟩

def q12Shape52P0 : Tree 12 := q12Shape52T0
theorem q12Shape52P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,5,4⟩) 0 0 q12Shape52P0=true := q12Shape52T0OK

end Graffiti384b.EffectiveSearch.Q12
