import Q12Shape53Part0
import Q12Shape53Part1
import Q12Shape53Part2
import Q12Shape53Part3
import Q12Shape53Part4

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape53M76 : Tree 12 := .split 20 q12Shape53P0 q12Shape53P1
private theorem q12Shape53M76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 917504 q12Shape53M76=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 (917504 ||| 2^20) q12Shape53P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (0 ||| 2^20) 917504 q12Shape53P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53P0OK,q12Shape53P1OK⟩
private def q12Shape53M122 : Tree 12 := .split 19 q12Shape53M76 q12Shape53P2
private theorem q12Shape53M122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 393216 q12Shape53M122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 (393216 ||| 2^19) q12Shape53M76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (0 ||| 2^19) 393216 q12Shape53P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53M76OK,q12Shape53P2OK⟩
private def q12Shape53M170 : Tree 12 := .split 18 q12Shape53M122 q12Shape53P3
private theorem q12Shape53M170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 131072 q12Shape53M170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 (131072 ||| 2^18) q12Shape53M122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (0 ||| 2^18) 131072 q12Shape53P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53M122OK,q12Shape53P3OK⟩
private def q12Shape53M255 : Tree 12 := .split 18 q12Shape53P4 q12Shape53P5
private theorem q12Shape53M255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 0 q12Shape53M255=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (0 ||| 2^18) q12Shape53P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^18) 0 q12Shape53P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53P4OK,q12Shape53P5OK⟩
private def q12Shape53M256 : Tree 12 := .split 17 q12Shape53M170 q12Shape53M255
private theorem q12Shape53M256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 0 q12Shape53M256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 (0 ||| 2^17) q12Shape53M170 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (0 ||| 2^17) 0 q12Shape53M255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53M170OK,q12Shape53M255OK⟩

theorem q12Shape53_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 53) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 53) b) (adj 12 (forms 53) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) adj_mono b H q12Shape53M256 q12Shape53M256OK

#print axioms q12Shape53_cover

end Graffiti384b.EffectiveSearch.Q12
