import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape53T3 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape53T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 1126039552 q12Shape53T3=true := by decide

private def q12Shape53T5 : Tree 12 := (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,2,3,6,9,10,11})))
private theorem q12Shape53T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073741824 119406592 q12Shape53T5=true := by decide

private def q12Shape53T8 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1140850688 13194191831040 q12Shape53T8=true := by decide

private def q12Shape53T9 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8797233872896 4398098808832 q12Shape53T9=true := by decide

private def q12Shape53T7 : Tree 12 := .split 43 q12Shape53T8 q12Shape53T9
private theorem q12Shape53T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1140850688 4398098808832 q12Shape53T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1140850688 (4398098808832 ||| 2^43) q12Shape53T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1140850688 ||| 2^43) 4398098808832 q12Shape53T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T8OK,q12Shape53T9OK⟩

private def q12Shape53T10 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4399187361792 52297728 q12Shape53T10=true := by decide

private def q12Shape53T6 : Tree 12 := .split 42 q12Shape53T7 q12Shape53T10
private theorem q12Shape53T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1140850688 52297728 q12Shape53T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1140850688 (52297728 ||| 2^42) q12Shape53T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1140850688 ||| 2^42) 52297728 q12Shape53T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T7OK,q12Shape53T10OK⟩

private def q12Shape53T4 : Tree 12 := .split 26 q12Shape53T5 q12Shape53T6
private theorem q12Shape53T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073741824 52297728 q12Shape53T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073741824 (52297728 ||| 2^26) q12Shape53T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073741824 ||| 2^26) 52297728 q12Shape53T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T5OK,q12Shape53T6OK⟩

private def q12Shape53T2 : Tree 12 := .split 30 q12Shape53T3 q12Shape53T4
private theorem q12Shape53T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 52297728 q12Shape53T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 (52297728 ||| 2^30) q12Shape53T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (0 ||| 2^30) 52297728 q12Shape53T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T3OK,q12Shape53T4OK⟩

private def q12Shape53T13 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape53T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33554432 2233335808 q12Shape53T13=true := by decide

private def q12Shape53T16 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2181038080 13194225385472 q12Shape53T16=true := by decide

private def q12Shape53T17 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8798274060288 4398132363264 q12Shape53T17=true := by decide

private def q12Shape53T15 : Tree 12 := .split 43 q12Shape53T16 q12Shape53T17
private theorem q12Shape53T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2181038080 4398132363264 q12Shape53T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2181038080 (4398132363264 ||| 2^43) q12Shape53T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2181038080 ||| 2^43) 4398132363264 q12Shape53T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T16OK,q12Shape53T17OK⟩

private def q12Shape53T18 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4400227549184 85852160 q12Shape53T18=true := by decide

private def q12Shape53T14 : Tree 12 := .split 42 q12Shape53T15 q12Shape53T18
private theorem q12Shape53T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2181038080 85852160 q12Shape53T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2181038080 (85852160 ||| 2^42) q12Shape53T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2181038080 ||| 2^42) 85852160 q12Shape53T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T15OK,q12Shape53T18OK⟩

private def q12Shape53T12 : Tree 12 := .split 31 q12Shape53T13 q12Shape53T14
private theorem q12Shape53T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33554432 85852160 q12Shape53T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33554432 (85852160 ||| 2^31) q12Shape53T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (33554432 ||| 2^31) 85852160 q12Shape53T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T13OK,q12Shape53T14OK⟩

private def q12Shape53T21 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 100663296 13194158276608 q12Shape53T21=true := by decide

private def q12Shape53T22 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796193685504 4398065254400 q12Shape53T22=true := by decide

private def q12Shape53T20 : Tree 12 := .split 43 q12Shape53T21 q12Shape53T22
private theorem q12Shape53T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 100663296 4398065254400 q12Shape53T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 100663296 (4398065254400 ||| 2^43) q12Shape53T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (100663296 ||| 2^43) 4398065254400 q12Shape53T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T21OK,q12Shape53T22OK⟩

private def q12Shape53T23 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398147174400 18743296 q12Shape53T23=true := by decide

private def q12Shape53T19 : Tree 12 := .split 42 q12Shape53T20 q12Shape53T23
private theorem q12Shape53T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 100663296 18743296 q12Shape53T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 100663296 (18743296 ||| 2^42) q12Shape53T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (100663296 ||| 2^42) 18743296 q12Shape53T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T20OK,q12Shape53T23OK⟩

private def q12Shape53T11 : Tree 12 := .split 26 q12Shape53T12 q12Shape53T19
private theorem q12Shape53T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33554432 18743296 q12Shape53T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33554432 (18743296 ||| 2^26) q12Shape53T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (33554432 ||| 2^26) 18743296 q12Shape53T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T12OK,q12Shape53T19OK⟩

private def q12Shape53T1 : Tree 12 := .split 25 q12Shape53T2 q12Shape53T11
private theorem q12Shape53T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 18743296 q12Shape53T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 (18743296 ||| 2^25) q12Shape53T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (0 ||| 2^25) 18743296 q12Shape53T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T2OK,q12Shape53T11OK⟩

private def q12Shape53T27 : Tree 12 := (.tip (.cover {0,2,3,6,9,10,11}))
private theorem q12Shape53T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16777216 34462367744 q12Shape53T27=true := by decide

private def q12Shape53T30 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,10})))
private theorem q12Shape53T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34376515584 13194242162688 q12Shape53T30=true := by decide

private def q12Shape53T31 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape53T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8830469537792 4398149140480 q12Shape53T31=true := by decide

private def q12Shape53T29 : Tree 12 := .split 43 q12Shape53T30 q12Shape53T31
private theorem q12Shape53T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34376515584 4398149140480 q12Shape53T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34376515584 (4398149140480 ||| 2^43) q12Shape53T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34376515584 ||| 2^43) 4398149140480 q12Shape53T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T30OK,q12Shape53T31OK⟩

private def q12Shape53T32 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape53T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4432423026688 102629376 q12Shape53T32=true := by decide

private def q12Shape53T28 : Tree 12 := .split 42 q12Shape53T29 q12Shape53T32
private theorem q12Shape53T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34376515584 102629376 q12Shape53T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34376515584 (102629376 ||| 2^42) q12Shape53T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34376515584 ||| 2^42) 102629376 q12Shape53T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T29OK,q12Shape53T32OK⟩

private def q12Shape53T26 : Tree 12 := .split 35 q12Shape53T27 q12Shape53T28
private theorem q12Shape53T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16777216 102629376 q12Shape53T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16777216 (102629376 ||| 2^35) q12Shape53T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16777216 ||| 2^35) 102629376 q12Shape53T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T27OK,q12Shape53T28OK⟩

private def q12Shape53T35 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,10})))
private theorem q12Shape53T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 83886080 13194175053824 q12Shape53T35=true := by decide

private def q12Shape53T36 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape53T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796176908288 4398082031616 q12Shape53T36=true := by decide

private def q12Shape53T34 : Tree 12 := .split 43 q12Shape53T35 q12Shape53T36
private theorem q12Shape53T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 83886080 4398082031616 q12Shape53T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 83886080 (4398082031616 ||| 2^43) q12Shape53T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (83886080 ||| 2^43) 4398082031616 q12Shape53T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T35OK,q12Shape53T36OK⟩

private def q12Shape53T37 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape53T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398130397184 35520512 q12Shape53T37=true := by decide

private def q12Shape53T33 : Tree 12 := .split 42 q12Shape53T34 q12Shape53T37
private theorem q12Shape53T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 83886080 35520512 q12Shape53T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 83886080 (35520512 ||| 2^42) q12Shape53T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (83886080 ||| 2^42) 35520512 q12Shape53T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T34OK,q12Shape53T37OK⟩

private def q12Shape53T25 : Tree 12 := .split 26 q12Shape53T26 q12Shape53T33
private theorem q12Shape53T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16777216 35520512 q12Shape53T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16777216 (35520512 ||| 2^26) q12Shape53T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16777216 ||| 2^26) 35520512 q12Shape53T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T26OK,q12Shape53T33OK⟩

private def q12Shape53T41 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,9,10})))
private theorem q12Shape53T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50331648 13194208608256 q12Shape53T41=true := by decide

private def q12Shape53T42 : Tree 12 := (.tip (.cover {0,1,4,5,8,9,10}))
private theorem q12Shape53T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796143353856 4398115586048 q12Shape53T42=true := by decide

private def q12Shape53T40 : Tree 12 := .split 43 q12Shape53T41 q12Shape53T42
private theorem q12Shape53T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50331648 4398115586048 q12Shape53T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50331648 (4398115586048 ||| 2^43) q12Shape53T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (50331648 ||| 2^43) 4398115586048 q12Shape53T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T41OK,q12Shape53T42OK⟩

private def q12Shape53T43 : Tree 12 := (.tip (.cover {0,1,4,5,8,9,11}))
private theorem q12Shape53T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398096842752 69074944 q12Shape53T43=true := by decide

private def q12Shape53T39 : Tree 12 := .split 42 q12Shape53T40 q12Shape53T43
private theorem q12Shape53T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50331648 69074944 q12Shape53T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50331648 (69074944 ||| 2^42) q12Shape53T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (50331648 ||| 2^42) 69074944 q12Shape53T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T40OK,q12Shape53T43OK⟩

private def q12Shape53T44 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape53T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 117440512 1966080 q12Shape53T44=true := by decide

private def q12Shape53T38 : Tree 12 := .split 26 q12Shape53T39 q12Shape53T44
private theorem q12Shape53T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50331648 1966080 q12Shape53T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50331648 (1966080 ||| 2^26) q12Shape53T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (50331648 ||| 2^26) 1966080 q12Shape53T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T39OK,q12Shape53T44OK⟩

private def q12Shape53T24 : Tree 12 := .split 25 q12Shape53T25 q12Shape53T38
private theorem q12Shape53T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16777216 1966080 q12Shape53T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16777216 (1966080 ||| 2^25) q12Shape53T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16777216 ||| 2^25) 1966080 q12Shape53T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T25OK,q12Shape53T38OK⟩

private def q12Shape53T0 : Tree 12 := .split 24 q12Shape53T1 q12Shape53T24
private theorem q12Shape53T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 1966080 q12Shape53T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 (1966080 ||| 2^24) q12Shape53T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (0 ||| 2^24) 1966080 q12Shape53T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T1OK,q12Shape53T24OK⟩

def q12Shape53P0 : Tree 12 := q12Shape53T0
theorem q12Shape53P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 0 1966080 q12Shape53P0=true := q12Shape53T0OK

end Graffiti384b.EffectiveSearch.Q12
