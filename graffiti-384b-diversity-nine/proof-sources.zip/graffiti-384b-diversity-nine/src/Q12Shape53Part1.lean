import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape53T48 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape53T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 1124990976 q12Shape53T48=true := by decide

private def q12Shape53T52 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1074790400 13194257891328 q12Shape53T52=true := by decide

private def q12Shape53T53 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8797167812608 4398164869120 q12Shape53T53=true := by decide

private def q12Shape53T51 : Tree 12 := .split 43 q12Shape53T52 q12Shape53T53
private theorem q12Shape53T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1074790400 4398164869120 q12Shape53T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1074790400 (4398164869120 ||| 2^43) q12Shape53T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1074790400 ||| 2^43) 4398164869120 q12Shape53T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T52OK,q12Shape53T53OK⟩

private def q12Shape53T54 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4399121301504 118358016 q12Shape53T54=true := by decide

private def q12Shape53T50 : Tree 12 := .split 42 q12Shape53T51 q12Shape53T54
private theorem q12Shape53T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1074790400 118358016 q12Shape53T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1074790400 (118358016 ||| 2^42) q12Shape53T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1074790400 ||| 2^42) 118358016 q12Shape53T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T51OK,q12Shape53T54OK⟩

private def q12Shape53T55 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape53T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1141899264 51249152 q12Shape53T55=true := by decide

private def q12Shape53T49 : Tree 12 := .split 26 q12Shape53T50 q12Shape53T55
private theorem q12Shape53T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1074790400 51249152 q12Shape53T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1074790400 (51249152 ||| 2^26) q12Shape53T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1074790400 ||| 2^26) 51249152 q12Shape53T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T50OK,q12Shape53T55OK⟩

private def q12Shape53T47 : Tree 12 := .split 30 q12Shape53T48 q12Shape53T49
private theorem q12Shape53T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 51249152 q12Shape53T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 (51249152 ||| 2^30) q12Shape53T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1048576 ||| 2^30) 51249152 q12Shape53T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T48OK,q12Shape53T49OK⟩

private def q12Shape53T60 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 13197378453504 q12Shape53T60=true := by decide

private def q12Shape53T61 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796127625216 4401285431296 q12Shape53T61=true := by decide

private def q12Shape53T59 : Tree 12 := .split 43 q12Shape53T60 q12Shape53T61
private theorem q12Shape53T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 4401285431296 q12Shape53T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 (4401285431296 ||| 2^43) q12Shape53T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34603008 ||| 2^43) 4401285431296 q12Shape53T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T60OK,q12Shape53T61OK⟩

private def q12Shape53T62 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398081114112 3238920192 q12Shape53T62=true := by decide

private def q12Shape53T58 : Tree 12 := .split 42 q12Shape53T59 q12Shape53T62
private theorem q12Shape53T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 3238920192 q12Shape53T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 (3238920192 ||| 2^42) q12Shape53T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34603008 ||| 2^42) 3238920192 q12Shape53T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T59OK,q12Shape53T62OK⟩

private def q12Shape53T63 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape53T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2182086656 1091436544 q12Shape53T63=true := by decide

private def q12Shape53T57 : Tree 12 := .split 31 q12Shape53T58 q12Shape53T63
private theorem q12Shape53T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 1091436544 q12Shape53T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 (1091436544 ||| 2^31) q12Shape53T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34603008 ||| 2^31) 1091436544 q12Shape53T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T58OK,q12Shape53T63OK⟩

private def q12Shape53T64 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape53T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1108344832 17694720 q12Shape53T64=true := by decide

private def q12Shape53T56 : Tree 12 := .split 30 q12Shape53T57 q12Shape53T64
private theorem q12Shape53T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 17694720 q12Shape53T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34603008 (17694720 ||| 2^30) q12Shape53T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34603008 ||| 2^30) 17694720 q12Shape53T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T57OK,q12Shape53T64OK⟩

private def q12Shape53T46 : Tree 12 := .split 25 q12Shape53T47 q12Shape53T56
private theorem q12Shape53T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 17694720 q12Shape53T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 (17694720 ||| 2^25) q12Shape53T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1048576 ||| 2^25) 17694720 q12Shape53T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T47OK,q12Shape53T56OK⟩

private def q12Shape53T70 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,7,9,10})))
private theorem q12Shape53T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 13229607485440 q12Shape53T70=true := by decide

private def q12Shape53T71 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape53T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796110848000 4433514463232 q12Shape53T71=true := by decide

private def q12Shape53T69 : Tree 12 := .split 43 q12Shape53T70 q12Shape53T71
private theorem q12Shape53T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 4433514463232 q12Shape53T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 (4433514463232 ||| 2^43) q12Shape53T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17825792 ||| 2^43) 4433514463232 q12Shape53T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T70OK,q12Shape53T71OK⟩

private def q12Shape53T72 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape53T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398064336896 35467952128 q12Shape53T72=true := by decide

private def q12Shape53T68 : Tree 12 := .split 42 q12Shape53T69 q12Shape53T72
private theorem q12Shape53T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 35467952128 q12Shape53T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 (35467952128 ||| 2^42) q12Shape53T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17825792 ||| 2^42) 35467952128 q12Shape53T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T69OK,q12Shape53T72OK⟩

private def q12Shape53T73 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape53T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34377564160 1108213760 q12Shape53T73=true := by decide

private def q12Shape53T67 : Tree 12 := .split 35 q12Shape53T68 q12Shape53T73
private theorem q12Shape53T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 1108213760 q12Shape53T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 (1108213760 ||| 2^35) q12Shape53T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17825792 ||| 2^35) 1108213760 q12Shape53T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T68OK,q12Shape53T73OK⟩

private def q12Shape53T74 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape53T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1091567616 34471936 q12Shape53T74=true := by decide

private def q12Shape53T66 : Tree 12 := .split 30 q12Shape53T67 q12Shape53T74
private theorem q12Shape53T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 34471936 q12Shape53T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 (34471936 ||| 2^30) q12Shape53T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17825792 ||| 2^30) 34471936 q12Shape53T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T67OK,q12Shape53T74OK⟩

private def q12Shape53T75 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape53T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 51380224 917504 q12Shape53T75=true := by decide

private def q12Shape53T65 : Tree 12 := .split 25 q12Shape53T66 q12Shape53T75
private theorem q12Shape53T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 917504 q12Shape53T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17825792 (917504 ||| 2^25) q12Shape53T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17825792 ||| 2^25) 917504 q12Shape53T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T66OK,q12Shape53T75OK⟩

private def q12Shape53T45 : Tree 12 := .split 24 q12Shape53T46 q12Shape53T65
private theorem q12Shape53T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 917504 q12Shape53T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 (917504 ||| 2^24) q12Shape53T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1048576 ||| 2^24) 917504 q12Shape53T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T46OK,q12Shape53T65OK⟩

def q12Shape53P1 : Tree 12 := q12Shape53T45
theorem q12Shape53P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1048576 917504 q12Shape53P1=true := q12Shape53T45OK

private def q12Shape53T82 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape53T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 2266365952 q12Shape53T82=true := by decide

private def q12Shape53T85 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2148007936 13194258415616 q12Shape53T85=true := by decide

private def q12Shape53T86 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8798241030144 4398165393408 q12Shape53T86=true := by decide

private def q12Shape53T84 : Tree 12 := .split 43 q12Shape53T85 q12Shape53T86
private theorem q12Shape53T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2148007936 4398165393408 q12Shape53T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2148007936 (4398165393408 ||| 2^43) q12Shape53T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2148007936 ||| 2^43) 4398165393408 q12Shape53T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T85OK,q12Shape53T86OK⟩

private def q12Shape53T87 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4400194519040 118882304 q12Shape53T87=true := by decide

private def q12Shape53T83 : Tree 12 := .split 42 q12Shape53T84 q12Shape53T87
private theorem q12Shape53T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2148007936 118882304 q12Shape53T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2148007936 (118882304 ||| 2^42) q12Shape53T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2148007936 ||| 2^42) 118882304 q12Shape53T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T84OK,q12Shape53T87OK⟩

private def q12Shape53T81 : Tree 12 := .split 31 q12Shape53T82 q12Shape53T83
private theorem q12Shape53T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 118882304 q12Shape53T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 (118882304 ||| 2^31) q12Shape53T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (524288 ||| 2^31) 118882304 q12Shape53T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T82OK,q12Shape53T83OK⟩

private def q12Shape53T92 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 13197412532224 q12Shape53T92=true := by decide

private def q12Shape53T93 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796160655360 4401319510016 q12Shape53T93=true := by decide

private def q12Shape53T91 : Tree 12 := .split 43 q12Shape53T92 q12Shape53T93
private theorem q12Shape53T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 4401319510016 q12Shape53T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 (4401319510016 ||| 2^43) q12Shape53T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (67633152 ||| 2^43) 4401319510016 q12Shape53T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T92OK,q12Shape53T93OK⟩

private def q12Shape53T94 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398114144256 3272998912 q12Shape53T94=true := by decide

private def q12Shape53T90 : Tree 12 := .split 42 q12Shape53T91 q12Shape53T94
private theorem q12Shape53T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 3272998912 q12Shape53T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 (3272998912 ||| 2^42) q12Shape53T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (67633152 ||| 2^42) 3272998912 q12Shape53T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T91OK,q12Shape53T94OK⟩

private def q12Shape53T95 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape53T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2215116800 1125515264 q12Shape53T95=true := by decide

private def q12Shape53T89 : Tree 12 := .split 31 q12Shape53T90 q12Shape53T95
private theorem q12Shape53T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 1125515264 q12Shape53T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 (1125515264 ||| 2^31) q12Shape53T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (67633152 ||| 2^31) 1125515264 q12Shape53T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T90OK,q12Shape53T95OK⟩

private def q12Shape53T96 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape53T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1141374976 51773440 q12Shape53T96=true := by decide

private def q12Shape53T88 : Tree 12 := .split 30 q12Shape53T89 q12Shape53T96
private theorem q12Shape53T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 51773440 q12Shape53T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67633152 (51773440 ||| 2^30) q12Shape53T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (67633152 ||| 2^30) 51773440 q12Shape53T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T89OK,q12Shape53T96OK⟩

private def q12Shape53T80 : Tree 12 := .split 26 q12Shape53T81 q12Shape53T88
private theorem q12Shape53T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 51773440 q12Shape53T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 (51773440 ||| 2^26) q12Shape53T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (524288 ||| 2^26) 51773440 q12Shape53T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T81OK,q12Shape53T88OK⟩

private def q12Shape53T100 : Tree 12 := (.tip (.cover {0,2,3,7,9,10,11}))
private theorem q12Shape53T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34078720 3306553344 q12Shape53T100=true := by decide

private def q12Shape53T104 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape53T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 101187584 13231738716160 q12Shape53T104=true := by decide

private def q12Shape53T105 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape53T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796194209792 4435645693952 q12Shape53T105=true := by decide

private def q12Shape53T103 : Tree 12 := .split 43 q12Shape53T104 q12Shape53T105
private theorem q12Shape53T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 101187584 4435645693952 q12Shape53T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 101187584 (4435645693952 ||| 2^43) q12Shape53T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (101187584 ||| 2^43) 4435645693952 q12Shape53T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T104OK,q12Shape53T105OK⟩

private def q12Shape53T106 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape53T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398147698688 37599182848 q12Shape53T106=true := by decide

private def q12Shape53T102 : Tree 12 := .split 42 q12Shape53T103 q12Shape53T106
private theorem q12Shape53T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 101187584 37599182848 q12Shape53T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 101187584 (37599182848 ||| 2^42) q12Shape53T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (101187584 ||| 2^42) 37599182848 q12Shape53T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T103OK,q12Shape53T106OK⟩

private def q12Shape53T107 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape53T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34460925952 3239444480 q12Shape53T107=true := by decide

private def q12Shape53T101 : Tree 12 := .split 35 q12Shape53T102 q12Shape53T107
private theorem q12Shape53T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 101187584 3239444480 q12Shape53T101=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 101187584 (3239444480 ||| 2^35) q12Shape53T102 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (101187584 ||| 2^35) 3239444480 q12Shape53T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T102OK,q12Shape53T107OK⟩

private def q12Shape53T99 : Tree 12 := .split 26 q12Shape53T100 q12Shape53T101
private theorem q12Shape53T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34078720 3239444480 q12Shape53T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34078720 (3239444480 ||| 2^26) q12Shape53T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34078720 ||| 2^26) 3239444480 q12Shape53T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T100OK,q12Shape53T101OK⟩

private def q12Shape53T108 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape53T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2181562368 1091960832 q12Shape53T108=true := by decide

private def q12Shape53T98 : Tree 12 := .split 31 q12Shape53T99 q12Shape53T108
private theorem q12Shape53T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34078720 1091960832 q12Shape53T98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34078720 (1091960832 ||| 2^31) q12Shape53T99 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34078720 ||| 2^31) 1091960832 q12Shape53T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T99OK,q12Shape53T108OK⟩

private def q12Shape53T109 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape53T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1107820544 18219008 q12Shape53T109=true := by decide

private def q12Shape53T97 : Tree 12 := .split 30 q12Shape53T98 q12Shape53T109
private theorem q12Shape53T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34078720 18219008 q12Shape53T97=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34078720 (18219008 ||| 2^30) q12Shape53T98 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34078720 ||| 2^30) 18219008 q12Shape53T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T98OK,q12Shape53T109OK⟩

private def q12Shape53T79 : Tree 12 := .split 25 q12Shape53T80 q12Shape53T97
private theorem q12Shape53T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 18219008 q12Shape53T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 (18219008 ||| 2^25) q12Shape53T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (524288 ||| 2^25) 18219008 q12Shape53T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T80OK,q12Shape53T97OK⟩

private def q12Shape53T115 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,5,8,9,10})))
private theorem q12Shape53T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 13230715305984 q12Shape53T115=true := by decide

private def q12Shape53T116 : Tree 12 := (.tip (.cover {0,1,4,5,8,9,10}))
private theorem q12Shape53T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796110323712 4434622283776 q12Shape53T116=true := by decide

private def q12Shape53T114 : Tree 12 := .split 43 q12Shape53T115 q12Shape53T116
private theorem q12Shape53T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 4434622283776 q12Shape53T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 (4434622283776 ||| 2^43) q12Shape53T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17301504 ||| 2^43) 4434622283776 q12Shape53T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T115OK,q12Shape53T116OK⟩

private def q12Shape53T117 : Tree 12 := (.tip (.cover {0,1,4,5,8,9,11}))
private theorem q12Shape53T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398063812608 36575772672 q12Shape53T117=true := by decide

private def q12Shape53T113 : Tree 12 := .split 42 q12Shape53T114 q12Shape53T117
private theorem q12Shape53T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 36575772672 q12Shape53T113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 (36575772672 ||| 2^42) q12Shape53T114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17301504 ||| 2^42) 36575772672 q12Shape53T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T114OK,q12Shape53T117OK⟩

private def q12Shape53T118 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape53T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34377039872 2216034304 q12Shape53T118=true := by decide

private def q12Shape53T112 : Tree 12 := .split 35 q12Shape53T113 q12Shape53T118
private theorem q12Shape53T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 2216034304 q12Shape53T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 (2216034304 ||| 2^35) q12Shape53T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17301504 ||| 2^35) 2216034304 q12Shape53T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T113OK,q12Shape53T118OK⟩

private def q12Shape53T119 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape53T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2164785152 68550656 q12Shape53T119=true := by decide

private def q12Shape53T111 : Tree 12 := .split 31 q12Shape53T112 q12Shape53T119
private theorem q12Shape53T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 68550656 q12Shape53T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 (68550656 ||| 2^31) q12Shape53T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17301504 ||| 2^31) 68550656 q12Shape53T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T112OK,q12Shape53T119OK⟩

private def q12Shape53T120 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape53T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 84410368 1441792 q12Shape53T120=true := by decide

private def q12Shape53T110 : Tree 12 := .split 26 q12Shape53T111 q12Shape53T120
private theorem q12Shape53T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 1441792 q12Shape53T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17301504 (1441792 ||| 2^26) q12Shape53T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (17301504 ||| 2^26) 1441792 q12Shape53T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T111OK,q12Shape53T120OK⟩

private def q12Shape53T78 : Tree 12 := .split 24 q12Shape53T79 q12Shape53T110
private theorem q12Shape53T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 1441792 q12Shape53T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 (1441792 ||| 2^24) q12Shape53T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (524288 ||| 2^24) 1441792 q12Shape53T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T79OK,q12Shape53T110OK⟩

private def q12Shape53T121 : Tree 12 := (.split 24 (.split 42 (.split 43 (.split 44 (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,9,10,11})))
private theorem q12Shape53T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1572864 393216 q12Shape53T121=true := by decide

private def q12Shape53T77 : Tree 12 := .split 20 q12Shape53T78 q12Shape53T121
private theorem q12Shape53T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 393216 q12Shape53T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 (393216 ||| 2^20) q12Shape53T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (524288 ||| 2^20) 393216 q12Shape53T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T78OK,q12Shape53T121OK⟩

def q12Shape53P2 : Tree 12 := q12Shape53T77
theorem q12Shape53P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 524288 393216 q12Shape53P2=true := q12Shape53T77OK

end Graffiti384b.EffectiveSearch.Q12
