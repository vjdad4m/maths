import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape53T179 : Tree 12 := (.tip (.cover {0,2,3,4,9,10,11}))
private theorem q12Shape53T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 37700239360 q12Shape53T179=true := by decide

private def q12Shape53T185 : Tree 12 := (.split 23 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,6,7,9,10})))
private theorem q12Shape53T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 30789672370176 q12Shape53T185=true := by decide

private def q12Shape53T186 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape53T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34364063744 30789668175872 q12Shape53T186=true := by decide

private def q12Shape53T184 : Tree 12 := .split 22 q12Shape53T185 q12Shape53T186
private theorem q12Shape53T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 30789668175872 q12Shape53T184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 (30789668175872 ||| 2^22) q12Shape53T185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34359869440 ||| 2^22) 30789668175872 q12Shape53T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T185OK,q12Shape53T186OK⟩

private def q12Shape53T187 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape53T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34361966592 30789666078720 q12Shape53T187=true := by decide

private def q12Shape53T183 : Tree 12 := .split 21 q12Shape53T184 q12Shape53T187
private theorem q12Shape53T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 30789666078720 q12Shape53T183=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 (30789666078720 ||| 2^21) q12Shape53T184 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34359869440 ||| 2^21) 30789666078720 q12Shape53T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T184OK,q12Shape53T187OK⟩

private def q12Shape53T188 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,10}))
private theorem q12Shape53T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17626545913856 13197480034304 q12Shape53T188=true := by decide

private def q12Shape53T182 : Tree 12 := .split 44 q12Shape53T183 q12Shape53T188
private theorem q12Shape53T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 13197480034304 q12Shape53T182=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 (13197480034304 ||| 2^44) q12Shape53T183 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34359869440 ||| 2^44) 13197480034304 q12Shape53T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T183OK,q12Shape53T188OK⟩

private def q12Shape53T189 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,10}))
private theorem q12Shape53T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8830452891648 4401387012096 q12Shape53T189=true := by decide

private def q12Shape53T181 : Tree 12 := .split 43 q12Shape53T182 q12Shape53T189
private theorem q12Shape53T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 4401387012096 q12Shape53T181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 (4401387012096 ||| 2^43) q12Shape53T182 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34359869440 ||| 2^43) 4401387012096 q12Shape53T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T182OK,q12Shape53T189OK⟩

private def q12Shape53T190 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape53T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4432406380544 3340500992 q12Shape53T190=true := by decide

private def q12Shape53T180 : Tree 12 := .split 42 q12Shape53T181 q12Shape53T190
private theorem q12Shape53T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 3340500992 q12Shape53T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34359869440 (3340500992 ||| 2^42) q12Shape53T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (34359869440 ||| 2^42) 3340500992 q12Shape53T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T181OK,q12Shape53T190OK⟩

private def q12Shape53T178 : Tree 12 := .split 35 q12Shape53T179 q12Shape53T180
private theorem q12Shape53T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 3340500992 q12Shape53T178=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (3340500992 ||| 2^35) q12Shape53T179 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^35) 3340500992 q12Shape53T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T179OK,q12Shape53T180OK⟩

private def q12Shape53T197 : Tree 12 := (.split 23 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,4,6,7,9,10})))
private theorem q12Shape53T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 30821884624896 q12Shape53T197=true := by decide

private def q12Shape53T198 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape53T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2151809024 30821880430592 q12Shape53T198=true := by decide

private def q12Shape53T196 : Tree 12 := .split 22 q12Shape53T197 q12Shape53T198
private theorem q12Shape53T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 30821880430592 q12Shape53T196=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 (30821880430592 ||| 2^22) q12Shape53T197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2147614720 ||| 2^22) 30821880430592 q12Shape53T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T197OK,q12Shape53T198OK⟩

private def q12Shape53T199 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape53T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2149711872 30821878333440 q12Shape53T199=true := by decide

private def q12Shape53T195 : Tree 12 := .split 21 q12Shape53T196 q12Shape53T199
private theorem q12Shape53T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 30821878333440 q12Shape53T195=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 (30821878333440 ||| 2^21) q12Shape53T196 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2147614720 ||| 2^21) 30821878333440 q12Shape53T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T196OK,q12Shape53T199OK⟩

private def q12Shape53T200 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,10}))
private theorem q12Shape53T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17594333659136 13229692289024 q12Shape53T200=true := by decide

private def q12Shape53T194 : Tree 12 := .split 44 q12Shape53T195 q12Shape53T200
private theorem q12Shape53T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 13229692289024 q12Shape53T194=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 (13229692289024 ||| 2^44) q12Shape53T195 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2147614720 ||| 2^44) 13229692289024 q12Shape53T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T195OK,q12Shape53T200OK⟩

private def q12Shape53T201 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,10}))
private theorem q12Shape53T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8798240636928 4433599266816 q12Shape53T201=true := by decide

private def q12Shape53T193 : Tree 12 := .split 43 q12Shape53T194 q12Shape53T201
private theorem q12Shape53T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 4433599266816 q12Shape53T193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 (4433599266816 ||| 2^43) q12Shape53T194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2147614720 ||| 2^43) 4433599266816 q12Shape53T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T194OK,q12Shape53T201OK⟩

private def q12Shape53T202 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape53T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4400194125824 35552755712 q12Shape53T202=true := by decide

private def q12Shape53T192 : Tree 12 := .split 42 q12Shape53T193 q12Shape53T202
private theorem q12Shape53T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 35552755712 q12Shape53T192=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 (35552755712 ||| 2^42) q12Shape53T193 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2147614720 ||| 2^42) 35552755712 q12Shape53T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T193OK,q12Shape53T202OK⟩

private def q12Shape53T203 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape53T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 36507353088 1193017344 q12Shape53T203=true := by decide

private def q12Shape53T191 : Tree 12 := .split 35 q12Shape53T192 q12Shape53T203
private theorem q12Shape53T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 1193017344 q12Shape53T191=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2147614720 (1193017344 ||| 2^35) q12Shape53T192 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (2147614720 ||| 2^35) 1193017344 q12Shape53T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T192OK,q12Shape53T203OK⟩

private def q12Shape53T177 : Tree 12 := .split 31 q12Shape53T178 q12Shape53T191
private theorem q12Shape53T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 1193017344 q12Shape53T177=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (1193017344 ||| 2^31) q12Shape53T178 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^31) 1193017344 q12Shape53T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T178OK,q12Shape53T191OK⟩

private def q12Shape53T211 : Tree 12 := (.split 23 (.split 27 (.split 28 (.split 29 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,7,8})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,9,10})))
private theorem q12Shape53T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 30822958366720 q12Shape53T211=true := by decide

private def q12Shape53T212 : Tree 12 := (.tip (.cover {0,1,4,6,8,9,11}))
private theorem q12Shape53T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1078067200 30822954172416 q12Shape53T212=true := by decide

private def q12Shape53T210 : Tree 12 := .split 22 q12Shape53T211 q12Shape53T212
private theorem q12Shape53T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 30822954172416 q12Shape53T210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 (30822954172416 ||| 2^22) q12Shape53T211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073872896 ||| 2^22) 30822954172416 q12Shape53T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T211OK,q12Shape53T212OK⟩

private def q12Shape53T213 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape53T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1075970048 30822952075264 q12Shape53T213=true := by decide

private def q12Shape53T209 : Tree 12 := .split 21 q12Shape53T210 q12Shape53T213
private theorem q12Shape53T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 30822952075264 q12Shape53T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 (30822952075264 ||| 2^21) q12Shape53T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073872896 ||| 2^21) 30822952075264 q12Shape53T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T210OK,q12Shape53T213OK⟩

private def q12Shape53T214 : Tree 12 := (.tip (.cover {0,1,4,6,8,9,10}))
private theorem q12Shape53T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 17593259917312 13230766030848 q12Shape53T214=true := by decide

private def q12Shape53T208 : Tree 12 := .split 44 q12Shape53T209 q12Shape53T214
private theorem q12Shape53T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 13230766030848 q12Shape53T208=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 (13230766030848 ||| 2^44) q12Shape53T209 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073872896 ||| 2^44) 13230766030848 q12Shape53T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T209OK,q12Shape53T214OK⟩

private def q12Shape53T215 : Tree 12 := (.tip (.cover {0,1,4,6,8,9,10}))
private theorem q12Shape53T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8797166895104 4434673008640 q12Shape53T215=true := by decide

private def q12Shape53T207 : Tree 12 := .split 43 q12Shape53T208 q12Shape53T215
private theorem q12Shape53T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 4434673008640 q12Shape53T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 (4434673008640 ||| 2^43) q12Shape53T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073872896 ||| 2^43) 4434673008640 q12Shape53T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T208OK,q12Shape53T215OK⟩

private def q12Shape53T216 : Tree 12 := (.tip (.cover {0,1,4,6,8,9,11}))
private theorem q12Shape53T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4399120384000 36626497536 q12Shape53T216=true := by decide

private def q12Shape53T206 : Tree 12 := .split 42 q12Shape53T207 q12Shape53T216
private theorem q12Shape53T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 36626497536 q12Shape53T206=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 (36626497536 ||| 2^42) q12Shape53T207 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073872896 ||| 2^42) 36626497536 q12Shape53T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T207OK,q12Shape53T216OK⟩

private def q12Shape53T217 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape53T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 35433611264 2266759168 q12Shape53T217=true := by decide

private def q12Shape53T205 : Tree 12 := .split 35 q12Shape53T206 q12Shape53T217
private theorem q12Shape53T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 2266759168 q12Shape53T205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 (2266759168 ||| 2^35) q12Shape53T206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073872896 ||| 2^35) 2266759168 q12Shape53T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T206OK,q12Shape53T217OK⟩

private def q12Shape53T218 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape53T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 3221356544 119275520 q12Shape53T218=true := by decide

private def q12Shape53T204 : Tree 12 := .split 31 q12Shape53T205 q12Shape53T218
private theorem q12Shape53T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 119275520 q12Shape53T204=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1073872896 (119275520 ||| 2^31) q12Shape53T205 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (1073872896 ||| 2^31) 119275520 q12Shape53T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T205OK,q12Shape53T218OK⟩

private def q12Shape53T176 : Tree 12 := .split 30 q12Shape53T177 q12Shape53T204
private theorem q12Shape53T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 119275520 q12Shape53T176=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (119275520 ||| 2^30) q12Shape53T177 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^30) 119275520 q12Shape53T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T177OK,q12Shape53T204OK⟩

private def q12Shape53T222 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,5,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,9,10})))
private theorem q12Shape53T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67239936 13195265441792 q12Shape53T222=true := by decide

private def q12Shape53T223 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,10}))
private theorem q12Shape53T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796160262144 4399172419584 q12Shape53T223=true := by decide

private def q12Shape53T221 : Tree 12 := .split 43 q12Shape53T222 q12Shape53T223
private theorem q12Shape53T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67239936 4399172419584 q12Shape53T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67239936 (4399172419584 ||| 2^43) q12Shape53T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (67239936 ||| 2^43) 4399172419584 q12Shape53T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T222OK,q12Shape53T223OK⟩

private def q12Shape53T224 : Tree 12 := (.tip (.cover {0,1,5,6,7,9,11}))
private theorem q12Shape53T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398113751040 1125908480 q12Shape53T224=true := by decide

private def q12Shape53T220 : Tree 12 := .split 42 q12Shape53T221 q12Shape53T224
private theorem q12Shape53T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67239936 1125908480 q12Shape53T220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67239936 (1125908480 ||| 2^42) q12Shape53T221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (67239936 ||| 2^42) 1125908480 q12Shape53T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T221OK,q12Shape53T224OK⟩

private def q12Shape53T225 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape53T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1140981760 52166656 q12Shape53T225=true := by decide

private def q12Shape53T219 : Tree 12 := .split 30 q12Shape53T220 q12Shape53T225
private theorem q12Shape53T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67239936 52166656 q12Shape53T219=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 67239936 (52166656 ||| 2^30) q12Shape53T220 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (67239936 ||| 2^30) 52166656 q12Shape53T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T220OK,q12Shape53T225OK⟩

private def q12Shape53T175 : Tree 12 := .split 26 q12Shape53T176 q12Shape53T219
private theorem q12Shape53T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 52166656 q12Shape53T175=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (52166656 ||| 2^26) q12Shape53T176 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^26) 52166656 q12Shape53T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T176OK,q12Shape53T219OK⟩

private def q12Shape53T230 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,2,3,7,9,10,11}))) (.tip (.cover {0,2,3,7,9,10,11}))) (.tip (.cover {0,2,3,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,9,10})))
private theorem q12Shape53T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 13196372738048 q12Shape53T230=true := by decide

private def q12Shape53T231 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,10}))
private theorem q12Shape53T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796126707712 4400279715840 q12Shape53T231=true := by decide

private def q12Shape53T229 : Tree 12 := .split 43 q12Shape53T230 q12Shape53T231
private theorem q12Shape53T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 4400279715840 q12Shape53T229=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 (4400279715840 ||| 2^43) q12Shape53T230 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (33685504 ||| 2^43) 4400279715840 q12Shape53T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T230OK,q12Shape53T231OK⟩

private def q12Shape53T232 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape53T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398080196608 2233204736 q12Shape53T232=true := by decide

private def q12Shape53T228 : Tree 12 := .split 42 q12Shape53T229 q12Shape53T232
private theorem q12Shape53T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 2233204736 q12Shape53T228=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 (2233204736 ||| 2^42) q12Shape53T229 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (33685504 ||| 2^42) 2233204736 q12Shape53T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T229OK,q12Shape53T232OK⟩

private def q12Shape53T233 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape53T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 2181169152 85721088 q12Shape53T233=true := by decide

private def q12Shape53T227 : Tree 12 := .split 31 q12Shape53T228 q12Shape53T233
private theorem q12Shape53T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 85721088 q12Shape53T227=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 (85721088 ||| 2^31) q12Shape53T228 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (33685504 ||| 2^31) 85721088 q12Shape53T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T228OK,q12Shape53T233OK⟩

private def q12Shape53T234 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape53T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 100794368 18612224 q12Shape53T234=true := by decide

private def q12Shape53T226 : Tree 12 := .split 26 q12Shape53T227 q12Shape53T234
private theorem q12Shape53T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 18612224 q12Shape53T226=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 33685504 (18612224 ||| 2^26) q12Shape53T227 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (33685504 ||| 2^26) 18612224 q12Shape53T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T227OK,q12Shape53T234OK⟩

private def q12Shape53T174 : Tree 12 := .split 25 q12Shape53T175 q12Shape53T226
private theorem q12Shape53T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 18612224 q12Shape53T174=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (18612224 ||| 2^25) q12Shape53T175 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^25) 18612224 q12Shape53T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T175OK,q12Shape53T226OK⟩

private def q12Shape53T240 : Tree 12 := (.split 44 (.split 21 (.split 22 (.split 23 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,2,3,6,9,10,11}))) (.tip (.cover {0,2,3,6,9,10,11}))) (.tip (.cover {0,2,3,6,9,10,11}))) (.tip (.cover {0,1,5,7,8,9,10})))
private theorem q12Shape53T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 13228601769984 q12Shape53T240=true := by decide

private def q12Shape53T241 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,10}))
private theorem q12Shape53T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 8796109930496 4432508747776 q12Shape53T241=true := by decide

private def q12Shape53T239 : Tree 12 := .split 43 q12Shape53T240 q12Shape53T241
private theorem q12Shape53T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 4432508747776 q12Shape53T239=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 (4432508747776 ||| 2^43) q12Shape53T240 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16908288 ||| 2^43) 4432508747776 q12Shape53T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T240OK,q12Shape53T241OK⟩

private def q12Shape53T242 : Tree 12 := (.tip (.cover {0,1,5,7,8,9,11}))
private theorem q12Shape53T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 4398063419392 34462236672 q12Shape53T242=true := by decide

private def q12Shape53T238 : Tree 12 := .split 42 q12Shape53T239 q12Shape53T242
private theorem q12Shape53T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 34462236672 q12Shape53T238=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 (34462236672 ||| 2^42) q12Shape53T239 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16908288 ||| 2^42) 34462236672 q12Shape53T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T239OK,q12Shape53T242OK⟩

private def q12Shape53T243 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape53T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 34376646656 102498304 q12Shape53T243=true := by decide

private def q12Shape53T237 : Tree 12 := .split 35 q12Shape53T238 q12Shape53T243
private theorem q12Shape53T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 102498304 q12Shape53T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 (102498304 ||| 2^35) q12Shape53T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16908288 ||| 2^35) 102498304 q12Shape53T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T238OK,q12Shape53T243OK⟩

private def q12Shape53T244 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape53T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 84017152 35389440 q12Shape53T244=true := by decide

private def q12Shape53T236 : Tree 12 := .split 26 q12Shape53T237 q12Shape53T244
private theorem q12Shape53T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 35389440 q12Shape53T236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 (35389440 ||| 2^26) q12Shape53T237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16908288 ||| 2^26) 35389440 q12Shape53T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T237OK,q12Shape53T244OK⟩

private def q12Shape53T245 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape53T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 50462720 1835008 q12Shape53T245=true := by decide

private def q12Shape53T235 : Tree 12 := .split 25 q12Shape53T236 q12Shape53T245
private theorem q12Shape53T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 1835008 q12Shape53T235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 16908288 (1835008 ||| 2^25) q12Shape53T236 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (16908288 ||| 2^25) 1835008 q12Shape53T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T236OK,q12Shape53T245OK⟩

private def q12Shape53T173 : Tree 12 := .split 24 q12Shape53T174 q12Shape53T235
private theorem q12Shape53T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 1835008 q12Shape53T173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (1835008 ||| 2^24) q12Shape53T174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^24) 1835008 q12Shape53T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T174OK,q12Shape53T235OK⟩

private def q12Shape53T246 : Tree 12 := (.split 30 (.split 42 (.split 43 (.split 44 (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,10}))) (.tip (.cover {0,1,4,6,7,9,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape53T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1179648 786432 q12Shape53T246=true := by decide

private def q12Shape53T172 : Tree 12 := .split 20 q12Shape53T173 q12Shape53T246
private theorem q12Shape53T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 786432 q12Shape53T172=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (786432 ||| 2^20) q12Shape53T173 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^20) 786432 q12Shape53T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T173OK,q12Shape53T246OK⟩

private def q12Shape53T248 : Tree 12 := (.split 31 (.split 42 (.split 43 (.split 44 (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape53T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 655360 1310720 q12Shape53T248=true := by decide

private def q12Shape53T249 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape53T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1703936 262144 q12Shape53T249=true := by decide

private def q12Shape53T247 : Tree 12 := .split 20 q12Shape53T248 q12Shape53T249
private theorem q12Shape53T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 655360 262144 q12Shape53T247=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 655360 (262144 ||| 2^20) q12Shape53T248 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (655360 ||| 2^20) 262144 q12Shape53T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T248OK,q12Shape53T249OK⟩

private def q12Shape53T171 : Tree 12 := .split 19 q12Shape53T172 q12Shape53T247
private theorem q12Shape53T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 262144 q12Shape53T171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 (262144 ||| 2^19) q12Shape53T172 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (131072 ||| 2^19) 262144 q12Shape53T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T172OK,q12Shape53T247OK⟩

def q12Shape53P4 : Tree 12 := q12Shape53T171
theorem q12Shape53P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 131072 262144 q12Shape53P4=true := q12Shape53T171OK

end Graffiti384b.EffectiveSearch.Q12
