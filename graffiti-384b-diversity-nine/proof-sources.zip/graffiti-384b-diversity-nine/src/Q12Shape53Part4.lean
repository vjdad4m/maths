import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape53T252 : Tree 12 := (.split 35 (.split 42 (.split 43 (.split 44 (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,9,10,11})))
private theorem q12Shape53T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 393216 1572864 q12Shape53T252=true := by decide

private def q12Shape53T253 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape53T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 1441792 524288 q12Shape53T253=true := by decide

private def q12Shape53T251 : Tree 12 := .split 20 q12Shape53T252 q12Shape53T253
private theorem q12Shape53T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 393216 524288 q12Shape53T251=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 393216 (524288 ||| 2^20) q12Shape53T252 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (393216 ||| 2^20) 524288 q12Shape53T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T252OK,q12Shape53T253OK⟩

private def q12Shape53T254 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape53T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 917504 0 q12Shape53T254=true := by decide

private def q12Shape53T250 : Tree 12 := .split 19 q12Shape53T251 q12Shape53T254
private theorem q12Shape53T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 393216 0 q12Shape53T250=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 393216 (0 ||| 2^19) q12Shape53T251 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) (393216 ||| 2^19) 0 q12Shape53T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape53T251OK,q12Shape53T254OK⟩

def q12Shape53P5 : Tree 12 := q12Shape53T250
theorem q12Shape53P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,2⟩) 393216 0 q12Shape53P5=true := q12Shape53T250OK

end Graffiti384b.EffectiveSearch.Q12
