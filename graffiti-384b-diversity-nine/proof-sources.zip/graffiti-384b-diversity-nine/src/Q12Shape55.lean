import Q12Shape55Part0

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q12Shape55_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 55) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 55) b) (adj 12 (forms 55) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) adj_mono b H q12Shape55P0 q12Shape55P0OK

#print axioms q12Shape55_cover

end Graffiti384b.EffectiveSearch.Q12
