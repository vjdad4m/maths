import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape55T9 : Tree 12 := (.split 6 (.tip (.cover {0,1,3,4,5,10,11})) (.tip (.cover {0,3,4,5,9,10,11})))
private theorem q12Shape55T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 660351221816 q12Shape55T9=true := by decide

private def q12Shape55T13 : Tree 12 := (.split 13 (.split 14 (.tip (.cover {0,1,4,5,8,10,11})) (.tip (.cover {0,2,4,5,9,10,11}))) (.tip (.cover {0,1,3,4,5,10,11})))
private theorem q12Shape55T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 32 660351227992 q12Shape55T13=true := by decide

private def q12Shape55T16 : Tree 12 := (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,7,8,10,11})) (.tip (.cover {0,2,3,5,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 19 (.split 20 (.split 21 (.tip (.cover {1,5,6,7,8,10,11})) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))))
private theorem q12Shape55T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4128 660351248472 q12Shape55T16=true := by decide

private def q12Shape55T17 : Tree 12 := (.tip (.cover {0,1,3,6,8,10,11}))
private theorem q12Shape55T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 20512 660351232088 q12Shape55T17=true := by decide

private def q12Shape55T15 : Tree 12 := .split 14 q12Shape55T16 q12Shape55T17
private theorem q12Shape55T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4128 660351232088 q12Shape55T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4128 (660351232088 ||| 2^14) q12Shape55T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (4128 ||| 2^14) 660351232088 q12Shape55T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T16OK,q12Shape55T17OK⟩

private def q12Shape55T18 : Tree 12 := (.tip (.cover {0,1,3,6,9,10,11}))
private theorem q12Shape55T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 12320 660351223896 q12Shape55T18=true := by decide

private def q12Shape55T14 : Tree 12 := .split 13 q12Shape55T15 q12Shape55T18
private theorem q12Shape55T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4128 660351223896 q12Shape55T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4128 (660351223896 ||| 2^13) q12Shape55T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (4128 ||| 2^13) 660351223896 q12Shape55T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T15OK,q12Shape55T18OK⟩

private def q12Shape55T12 : Tree 12 := .split 12 q12Shape55T13 q12Shape55T14
private theorem q12Shape55T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 32 660351223896 q12Shape55T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 32 (660351223896 ||| 2^12) q12Shape55T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (32 ||| 2^12) 660351223896 q12Shape55T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T13OK,q12Shape55T14OK⟩

private def q12Shape55T21 : Tree 12 := (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,8,10,11})) (.tip (.cover {0,2,3,5,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 20 (.split 21 (.tip (.cover {1,5,6,7,8,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape55T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2080 660351234136 q12Shape55T21=true := by decide

private def q12Shape55T22 : Tree 12 := (.tip (.cover {0,1,3,7,9,10,11}))
private theorem q12Shape55T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 10272 660351225944 q12Shape55T22=true := by decide

private def q12Shape55T20 : Tree 12 := .split 13 q12Shape55T21 q12Shape55T22
private theorem q12Shape55T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2080 660351225944 q12Shape55T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2080 (660351225944 ||| 2^13) q12Shape55T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (2080 ||| 2^13) 660351225944 q12Shape55T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T21OK,q12Shape55T22OK⟩

private def q12Shape55T23 : Tree 12 := (.tip (.cover {0,1,3,8,9,10,11}))
private theorem q12Shape55T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 6176 660351221848 q12Shape55T23=true := by decide

private def q12Shape55T19 : Tree 12 := .split 12 q12Shape55T20 q12Shape55T23
private theorem q12Shape55T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2080 660351221848 q12Shape55T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2080 (660351221848 ||| 2^12) q12Shape55T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (2080 ||| 2^12) 660351221848 q12Shape55T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T20OK,q12Shape55T23OK⟩

private def q12Shape55T11 : Tree 12 := .split 11 q12Shape55T12 q12Shape55T19
private theorem q12Shape55T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 32 660351221848 q12Shape55T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 32 (660351221848 ||| 2^11) q12Shape55T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (32 ||| 2^11) 660351221848 q12Shape55T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T12OK,q12Shape55T19OK⟩

private def q12Shape55T24 : Tree 12 := (.tip (.cover {0,1,2,6,7,10,11}))
private theorem q12Shape55T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 96 660351221784 q12Shape55T24=true := by decide

private def q12Shape55T10 : Tree 12 := .split 6 q12Shape55T11 q12Shape55T24
private theorem q12Shape55T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 32 660351221784 q12Shape55T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 32 (660351221784 ||| 2^6) q12Shape55T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (32 ||| 2^6) 660351221784 q12Shape55T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T11OK,q12Shape55T24OK⟩

private def q12Shape55T8 : Tree 12 := .split 5 q12Shape55T9 q12Shape55T10
private theorem q12Shape55T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 660351221784 q12Shape55T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (660351221784 ||| 2^5) q12Shape55T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^5) 660351221784 q12Shape55T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T9OK,q12Shape55T10OK⟩

private def q12Shape55T30 : Tree 12 := (.split 14 (.tip (.cover {0,1,4,5,7,10,11})) (.tip (.cover {0,2,4,5,9,10,11})))
private theorem q12Shape55T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 660351236200 q12Shape55T30=true := by decide

private def q12Shape55T32 : Tree 12 := (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,7,8,10,11})) (.tip (.cover {0,2,3,5,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.split 19 (.split 20 (.split 21 (.tip (.cover {1,5,6,7,8,10,11})) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))))
private theorem q12Shape55T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8208 660351244392 q12Shape55T32=true := by decide

private def q12Shape55T33 : Tree 12 := (.tip (.cover {0,1,3,6,7,10,11}))
private theorem q12Shape55T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 24592 660351228008 q12Shape55T33=true := by decide

private def q12Shape55T31 : Tree 12 := .split 14 q12Shape55T32 q12Shape55T33
private theorem q12Shape55T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8208 660351228008 q12Shape55T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8208 (660351228008 ||| 2^14) q12Shape55T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (8208 ||| 2^14) 660351228008 q12Shape55T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T32OK,q12Shape55T33OK⟩

private def q12Shape55T29 : Tree 12 := .split 13 q12Shape55T30 q12Shape55T31
private theorem q12Shape55T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 660351228008 q12Shape55T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 (660351228008 ||| 2^13) q12Shape55T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (16 ||| 2^13) 660351228008 q12Shape55T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T30OK,q12Shape55T31OK⟩

private def q12Shape55T34 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape55T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4112 660351223912 q12Shape55T34=true := by decide

private def q12Shape55T28 : Tree 12 := .split 12 q12Shape55T29 q12Shape55T34
private theorem q12Shape55T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 660351223912 q12Shape55T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 (660351223912 ||| 2^12) q12Shape55T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (16 ||| 2^12) 660351223912 q12Shape55T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T29OK,q12Shape55T34OK⟩

private def q12Shape55T36 : Tree 12 := (.split 13 (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,7,10,11})) (.tip (.cover {0,2,3,5,9,10,11}))) (.split 21 (.tip (.cover {1,5,6,7,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,3,7,8,10,11}))) (.tip (.cover {0,1,3,7,9,10,11})))
private theorem q12Shape55T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2064 660351225960 q12Shape55T36=true := by decide

private def q12Shape55T37 : Tree 12 := (.tip (.cover {0,1,3,8,9,10,11}))
private theorem q12Shape55T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 6160 660351221864 q12Shape55T37=true := by decide

private def q12Shape55T35 : Tree 12 := .split 12 q12Shape55T36 q12Shape55T37
private theorem q12Shape55T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2064 660351221864 q12Shape55T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2064 (660351221864 ||| 2^12) q12Shape55T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (2064 ||| 2^12) 660351221864 q12Shape55T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T36OK,q12Shape55T37OK⟩

private def q12Shape55T27 : Tree 12 := .split 11 q12Shape55T28 q12Shape55T35
private theorem q12Shape55T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 660351221864 q12Shape55T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 (660351221864 ||| 2^11) q12Shape55T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (16 ||| 2^11) 660351221864 q12Shape55T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T28OK,q12Shape55T35OK⟩

private def q12Shape55T38 : Tree 12 := (.tip (.cover {0,1,2,6,8,10,11}))
private theorem q12Shape55T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 80 660351221800 q12Shape55T38=true := by decide

private def q12Shape55T26 : Tree 12 := .split 6 q12Shape55T27 q12Shape55T38
private theorem q12Shape55T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 660351221800 q12Shape55T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 (660351221800 ||| 2^6) q12Shape55T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (16 ||| 2^6) 660351221800 q12Shape55T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T27OK,q12Shape55T38OK⟩

private def q12Shape55T39 : Tree 12 := (.tip (.cover {0,1,2,6,9,10,11}))
private theorem q12Shape55T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 48 660351221768 q12Shape55T39=true := by decide

private def q12Shape55T25 : Tree 12 := .split 5 q12Shape55T26 q12Shape55T39
private theorem q12Shape55T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 660351221768 q12Shape55T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 16 (660351221768 ||| 2^5) q12Shape55T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (16 ||| 2^5) 660351221768 q12Shape55T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T26OK,q12Shape55T39OK⟩

private def q12Shape55T7 : Tree 12 := .split 4 q12Shape55T8 q12Shape55T25
private theorem q12Shape55T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 660351221768 q12Shape55T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (660351221768 ||| 2^4) q12Shape55T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^4) 660351221768 q12Shape55T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T8OK,q12Shape55T25OK⟩

private def q12Shape55T46 : Tree 12 := (.split 14 (.tip (.cover {0,1,4,5,6,10,11})) (.tip (.cover {0,2,4,5,9,10,11})))
private theorem q12Shape55T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 660351236208 q12Shape55T46=true := by decide

private def q12Shape55T47 : Tree 12 := (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,8,10,11})) (.tip (.cover {0,2,3,5,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 20 (.split 21 (.tip (.cover {1,5,6,7,8,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,3,6,7,10,11})))
private theorem q12Shape55T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8200 660351228016 q12Shape55T47=true := by decide

private def q12Shape55T45 : Tree 12 := .split 13 q12Shape55T46 q12Shape55T47
private theorem q12Shape55T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 660351228016 q12Shape55T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 (660351228016 ||| 2^13) q12Shape55T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (8 ||| 2^13) 660351228016 q12Shape55T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T46OK,q12Shape55T47OK⟩

private def q12Shape55T48 : Tree 12 := (.split 13 (.split 14 (.split 18 (.split 19 (.split 20 (.split 21 (.tip (.cover {0,1,5,6,7,10,11})) (.tip (.cover {0,2,3,5,9,10,11}))) (.split 21 (.tip (.cover {1,5,6,7,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,3,6,9,10,11})))
private theorem q12Shape55T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4104 660351223920 q12Shape55T48=true := by decide

private def q12Shape55T44 : Tree 12 := .split 12 q12Shape55T45 q12Shape55T48
private theorem q12Shape55T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 660351223920 q12Shape55T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 (660351223920 ||| 2^12) q12Shape55T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (8 ||| 2^12) 660351223920 q12Shape55T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T45OK,q12Shape55T48OK⟩

private def q12Shape55T49 : Tree 12 := (.tip (.cover {0,1,3,4,5,10,11}))
private theorem q12Shape55T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2056 660351221872 q12Shape55T49=true := by decide

private def q12Shape55T43 : Tree 12 := .split 11 q12Shape55T44 q12Shape55T49
private theorem q12Shape55T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 660351221872 q12Shape55T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 (660351221872 ||| 2^11) q12Shape55T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (8 ||| 2^11) 660351221872 q12Shape55T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T44OK,q12Shape55T49OK⟩

private def q12Shape55T50 : Tree 12 := (.tip (.cover {0,1,2,7,8,10,11}))
private theorem q12Shape55T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 72 660351221808 q12Shape55T50=true := by decide

private def q12Shape55T42 : Tree 12 := .split 6 q12Shape55T43 q12Shape55T50
private theorem q12Shape55T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 660351221808 q12Shape55T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 (660351221808 ||| 2^6) q12Shape55T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (8 ||| 2^6) 660351221808 q12Shape55T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T43OK,q12Shape55T50OK⟩

private def q12Shape55T51 : Tree 12 := (.tip (.cover {0,1,2,7,9,10,11}))
private theorem q12Shape55T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 40 660351221776 q12Shape55T51=true := by decide

private def q12Shape55T41 : Tree 12 := .split 5 q12Shape55T42 q12Shape55T51
private theorem q12Shape55T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 660351221776 q12Shape55T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 (660351221776 ||| 2^5) q12Shape55T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (8 ||| 2^5) 660351221776 q12Shape55T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T42OK,q12Shape55T51OK⟩

private def q12Shape55T52 : Tree 12 := (.tip (.cover {0,1,2,8,9,10,11}))
private theorem q12Shape55T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 24 660351221760 q12Shape55T52=true := by decide

private def q12Shape55T40 : Tree 12 := .split 4 q12Shape55T41 q12Shape55T52
private theorem q12Shape55T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 660351221760 q12Shape55T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 8 (660351221760 ||| 2^4) q12Shape55T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (8 ||| 2^4) 660351221760 q12Shape55T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T41OK,q12Shape55T52OK⟩

private def q12Shape55T6 : Tree 12 := .split 3 q12Shape55T7 q12Shape55T40
private theorem q12Shape55T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 660351221760 q12Shape55T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (660351221760 ||| 2^3) q12Shape55T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^3) 660351221760 q12Shape55T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T7OK,q12Shape55T40OK⟩

private def q12Shape55T53 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape55T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 549755813888 110595407872 q12Shape55T53=true := by decide

private def q12Shape55T5 : Tree 12 := .split 39 q12Shape55T6 q12Shape55T53
private theorem q12Shape55T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 110595407872 q12Shape55T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (110595407872 ||| 2^39) q12Shape55T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^39) 110595407872 q12Shape55T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T6OK,q12Shape55T53OK⟩

private def q12Shape55T54 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape55T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 68719476736 41875931136 q12Shape55T54=true := by decide

private def q12Shape55T4 : Tree 12 := .split 36 q12Shape55T5 q12Shape55T54
private theorem q12Shape55T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 41875931136 q12Shape55T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (41875931136 ||| 2^36) q12Shape55T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^36) 41875931136 q12Shape55T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T5OK,q12Shape55T54OK⟩

private def q12Shape55T55 : Tree 12 := (.tip (.cover {0,1,6,7,8,10,11}))
private theorem q12Shape55T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 4294967296 37580963840 q12Shape55T55=true := by decide

private def q12Shape55T3 : Tree 12 := .split 32 q12Shape55T4 q12Shape55T55
private theorem q12Shape55T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 37580963840 q12Shape55T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (37580963840 ||| 2^32) q12Shape55T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^32) 37580963840 q12Shape55T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T4OK,q12Shape55T55OK⟩

private def q12Shape55T56 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape55T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 34359738368 3221225472 q12Shape55T56=true := by decide

private def q12Shape55T2 : Tree 12 := .split 35 q12Shape55T3 q12Shape55T56
private theorem q12Shape55T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 3221225472 q12Shape55T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (3221225472 ||| 2^35) q12Shape55T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^35) 3221225472 q12Shape55T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T3OK,q12Shape55T56OK⟩

private def q12Shape55T57 : Tree 12 := (.tip (.cover {0,1,6,7,9,10,11}))
private theorem q12Shape55T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 2147483648 1073741824 q12Shape55T57=true := by decide

private def q12Shape55T1 : Tree 12 := .split 31 q12Shape55T2 q12Shape55T57
private theorem q12Shape55T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 1073741824 q12Shape55T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (1073741824 ||| 2^31) q12Shape55T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^31) 1073741824 q12Shape55T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T2OK,q12Shape55T57OK⟩

private def q12Shape55T58 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape55T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 1073741824 0 q12Shape55T58=true := by decide

private def q12Shape55T0 : Tree 12 := .split 30 q12Shape55T1 q12Shape55T58
private theorem q12Shape55T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 0 q12Shape55T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 (0 ||| 2^30) q12Shape55T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) (0 ||| 2^30) 0 q12Shape55T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape55T1OK,q12Shape55T58OK⟩

def q12Shape55P0 : Tree 12 := q12Shape55T0
theorem q12Shape55P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,8,6,4⟩) 0 0 q12Shape55P0=true := q12Shape55T0OK

end Graffiti384b.EffectiveSearch.Q12
