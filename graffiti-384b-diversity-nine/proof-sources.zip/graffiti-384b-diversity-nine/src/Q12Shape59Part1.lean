import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape59T30 : Tree 12 := (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))) (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape59T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 119406592 q12Shape59T30=true := by decide

private def q12Shape59T31 : Tree 12 := (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))))
private theorem q12Shape59T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 69206016 52297728 q12Shape59T31=true := by decide

private def q12Shape59T29 : Tree 12 := .split 26 q12Shape59T30 q12Shape59T31
private theorem q12Shape59T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 52297728 q12Shape59T29=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 (52297728 ||| 2^26) q12Shape59T30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2097152 ||| 2^26) 52297728 q12Shape59T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T30OK,q12Shape59T31OK⟩

private def q12Shape59T32 : Tree 12 := (.split 26 (.split 27 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,7,8,10,11})))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 35651584 18743296 q12Shape59T32=true := by decide

private def q12Shape59T28 : Tree 12 := .split 25 q12Shape59T29 q12Shape59T32
private theorem q12Shape59T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 18743296 q12Shape59T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 (18743296 ||| 2^25) q12Shape59T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2097152 ||| 2^25) 18743296 q12Shape59T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T29OK,q12Shape59T32OK⟩

private def q12Shape59T36 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape59T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18874368 236847104 q12Shape59T36=true := by decide

private def q12Shape59T37 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape59T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 153092096 102629376 q12Shape59T37=true := by decide

private def q12Shape59T35 : Tree 12 := .split 27 q12Shape59T36 q12Shape59T37
private theorem q12Shape59T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18874368 102629376 q12Shape59T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18874368 (102629376 ||| 2^27) q12Shape59T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (18874368 ||| 2^27) 102629376 q12Shape59T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T36OK,q12Shape59T37OK⟩

private def q12Shape59T38 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape59T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 85983232 35520512 q12Shape59T38=true := by decide

private def q12Shape59T34 : Tree 12 := .split 26 q12Shape59T35 q12Shape59T38
private theorem q12Shape59T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18874368 35520512 q12Shape59T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18874368 (35520512 ||| 2^26) q12Shape59T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (18874368 ||| 2^26) 35520512 q12Shape59T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T35OK,q12Shape59T38OK⟩

private def q12Shape59T39 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 52428800 1966080 q12Shape59T39=true := by decide

private def q12Shape59T33 : Tree 12 := .split 25 q12Shape59T34 q12Shape59T39
private theorem q12Shape59T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18874368 1966080 q12Shape59T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18874368 (1966080 ||| 2^25) q12Shape59T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (18874368 ||| 2^25) 1966080 q12Shape59T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T34OK,q12Shape59T39OK⟩

private def q12Shape59T27 : Tree 12 := .split 24 q12Shape59T28 q12Shape59T33
private theorem q12Shape59T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 1966080 q12Shape59T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 (1966080 ||| 2^24) q12Shape59T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2097152 ||| 2^24) 1966080 q12Shape59T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T28OK,q12Shape59T33OK⟩

def q12Shape59P1 : Tree 12 := q12Shape59T27
theorem q12Shape59P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2097152 1966080 q12Shape59P1=true := q12Shape59T27OK

private def q12Shape59T45 : Tree 12 := (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))))) (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))))
private theorem q12Shape59T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 120455168 q12Shape59T45=true := by decide

private def q12Shape59T46 : Tree 12 := (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,6,8,9,10,11}))) (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))))
private theorem q12Shape59T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 68157440 53346304 q12Shape59T46=true := by decide

private def q12Shape59T44 : Tree 12 := .split 26 q12Shape59T45 q12Shape59T46
private theorem q12Shape59T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 53346304 q12Shape59T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 (53346304 ||| 2^26) q12Shape59T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1048576 ||| 2^26) 53346304 q12Shape59T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T45OK,q12Shape59T46OK⟩

private def q12Shape59T48 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34603008 86900736 q12Shape59T48=true := by decide

private def q12Shape59T49 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 101711872 19791872 q12Shape59T49=true := by decide

private def q12Shape59T47 : Tree 12 := .split 26 q12Shape59T48 q12Shape59T49
private theorem q12Shape59T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34603008 19791872 q12Shape59T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34603008 (19791872 ||| 2^26) q12Shape59T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (34603008 ||| 2^26) 19791872 q12Shape59T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T48OK,q12Shape59T49OK⟩

private def q12Shape59T43 : Tree 12 := .split 25 q12Shape59T44 q12Shape59T47
private theorem q12Shape59T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 19791872 q12Shape59T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 (19791872 ||| 2^25) q12Shape59T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1048576 ||| 2^25) 19791872 q12Shape59T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T44OK,q12Shape59T47OK⟩

private def q12Shape59T54 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,5,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,5,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 1311637504 q12Shape59T54=true := by decide

private def q12Shape59T55 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape59T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1091567616 237895680 q12Shape59T55=true := by decide

private def q12Shape59T53 : Tree 12 := .split 30 q12Shape59T54 q12Shape59T55
private theorem q12Shape59T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 237895680 q12Shape59T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 (237895680 ||| 2^30) q12Shape59T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17825792 ||| 2^30) 237895680 q12Shape59T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T54OK,q12Shape59T55OK⟩

private def q12Shape59T56 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape59T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 152043520 103677952 q12Shape59T56=true := by decide

private def q12Shape59T52 : Tree 12 := .split 27 q12Shape59T53 q12Shape59T56
private theorem q12Shape59T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 103677952 q12Shape59T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 (103677952 ||| 2^27) q12Shape59T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17825792 ||| 2^27) 103677952 q12Shape59T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T53OK,q12Shape59T56OK⟩

private def q12Shape59T57 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,5,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape59T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 84934656 36569088 q12Shape59T57=true := by decide

private def q12Shape59T51 : Tree 12 := .split 26 q12Shape59T52 q12Shape59T57
private theorem q12Shape59T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 36569088 q12Shape59T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 (36569088 ||| 2^26) q12Shape59T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17825792 ||| 2^26) 36569088 q12Shape59T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T52OK,q12Shape59T57OK⟩

private def q12Shape59T58 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 51380224 3014656 q12Shape59T58=true := by decide

private def q12Shape59T50 : Tree 12 := .split 25 q12Shape59T51 q12Shape59T58
private theorem q12Shape59T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 3014656 q12Shape59T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17825792 (3014656 ||| 2^25) q12Shape59T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17825792 ||| 2^25) 3014656 q12Shape59T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T51OK,q12Shape59T58OK⟩

private def q12Shape59T42 : Tree 12 := .split 24 q12Shape59T43 q12Shape59T50
private theorem q12Shape59T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 3014656 q12Shape59T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 (3014656 ||| 2^24) q12Shape59T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1048576 ||| 2^24) 3014656 q12Shape59T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T43OK,q12Shape59T50OK⟩

private def q12Shape59T61 : Tree 12 := (.split 26 (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))) (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))))
private theorem q12Shape59T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3145728 51249152 q12Shape59T61=true := by decide

private def q12Shape59T62 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape59T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 36700160 17694720 q12Shape59T62=true := by decide

private def q12Shape59T60 : Tree 12 := .split 25 q12Shape59T61 q12Shape59T62
private theorem q12Shape59T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3145728 17694720 q12Shape59T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3145728 (17694720 ||| 2^25) q12Shape59T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (3145728 ||| 2^25) 17694720 q12Shape59T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T61OK,q12Shape59T62OK⟩

private def q12Shape59T63 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape59T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 19922944 917504 q12Shape59T63=true := by decide

private def q12Shape59T59 : Tree 12 := .split 24 q12Shape59T60 q12Shape59T63
private theorem q12Shape59T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3145728 917504 q12Shape59T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3145728 (917504 ||| 2^24) q12Shape59T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (3145728 ||| 2^24) 917504 q12Shape59T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T60OK,q12Shape59T63OK⟩

private def q12Shape59T41 : Tree 12 := .split 21 q12Shape59T42 q12Shape59T59
private theorem q12Shape59T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 917504 q12Shape59T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 (917504 ||| 2^21) q12Shape59T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1048576 ||| 2^21) 917504 q12Shape59T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T42OK,q12Shape59T59OK⟩

def q12Shape59P2 : Tree 12 := q12Shape59T41
theorem q12Shape59P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1048576 917504 q12Shape59P2=true := q12Shape59T41OK

end Graffiti384b.EffectiveSearch.Q12
