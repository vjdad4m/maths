import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape59T71 : Tree 12 := (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))) (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))))
private theorem q12Shape59T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 255197184 q12Shape59T71=true := by decide

private def q12Shape59T72 : Tree 12 := (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape59T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 134742016 120979456 q12Shape59T72=true := by decide

private def q12Shape59T70 : Tree 12 := .split 27 q12Shape59T71 q12Shape59T72
private theorem q12Shape59T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 120979456 q12Shape59T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 (120979456 ||| 2^27) q12Shape59T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (524288 ||| 2^27) 120979456 q12Shape59T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T71OK,q12Shape59T72OK⟩

private def q12Shape59T73 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67633152 53870592 q12Shape59T73=true := by decide

private def q12Shape59T69 : Tree 12 := .split 26 q12Shape59T70 q12Shape59T73
private theorem q12Shape59T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 53870592 q12Shape59T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 (53870592 ||| 2^26) q12Shape59T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (524288 ||| 2^26) 53870592 q12Shape59T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T70OK,q12Shape59T73OK⟩

private def q12Shape59T75 : Tree 12 := (.split 27 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))))
private theorem q12Shape59T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34078720 87425024 q12Shape59T75=true := by decide

private def q12Shape59T76 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 101187584 20316160 q12Shape59T76=true := by decide

private def q12Shape59T74 : Tree 12 := .split 26 q12Shape59T75 q12Shape59T76
private theorem q12Shape59T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34078720 20316160 q12Shape59T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34078720 (20316160 ||| 2^26) q12Shape59T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (34078720 ||| 2^26) 20316160 q12Shape59T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T75OK,q12Shape59T76OK⟩

private def q12Shape59T68 : Tree 12 := .split 25 q12Shape59T69 q12Shape59T74
private theorem q12Shape59T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 20316160 q12Shape59T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 (20316160 ||| 2^25) q12Shape59T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (524288 ||| 2^25) 20316160 q12Shape59T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T69OK,q12Shape59T74OK⟩

private def q12Shape59T81 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 1312161792 q12Shape59T81=true := by decide

private def q12Shape59T82 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1091043328 238419968 q12Shape59T82=true := by decide

private def q12Shape59T80 : Tree 12 := .split 30 q12Shape59T81 q12Shape59T82
private theorem q12Shape59T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 238419968 q12Shape59T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 (238419968 ||| 2^30) q12Shape59T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17301504 ||| 2^30) 238419968 q12Shape59T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T81OK,q12Shape59T82OK⟩

private def q12Shape59T83 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 151519232 104202240 q12Shape59T83=true := by decide

private def q12Shape59T79 : Tree 12 := .split 27 q12Shape59T80 q12Shape59T83
private theorem q12Shape59T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 104202240 q12Shape59T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 (104202240 ||| 2^27) q12Shape59T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17301504 ||| 2^27) 104202240 q12Shape59T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T80OK,q12Shape59T83OK⟩

private def q12Shape59T84 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 84410368 37093376 q12Shape59T84=true := by decide

private def q12Shape59T78 : Tree 12 := .split 26 q12Shape59T79 q12Shape59T84
private theorem q12Shape59T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 37093376 q12Shape59T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 (37093376 ||| 2^26) q12Shape59T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17301504 ||| 2^26) 37093376 q12Shape59T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T79OK,q12Shape59T84OK⟩

private def q12Shape59T86 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape59T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 50855936 70647808 q12Shape59T86=true := by decide

private def q12Shape59T87 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 117964800 3538944 q12Shape59T87=true := by decide

private def q12Shape59T85 : Tree 12 := .split 26 q12Shape59T86 q12Shape59T87
private theorem q12Shape59T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 50855936 3538944 q12Shape59T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 50855936 (3538944 ||| 2^26) q12Shape59T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (50855936 ||| 2^26) 3538944 q12Shape59T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T86OK,q12Shape59T87OK⟩

private def q12Shape59T77 : Tree 12 := .split 25 q12Shape59T78 q12Shape59T85
private theorem q12Shape59T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 3538944 q12Shape59T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17301504 (3538944 ||| 2^25) q12Shape59T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17301504 ||| 2^25) 3538944 q12Shape59T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T78OK,q12Shape59T85OK⟩

private def q12Shape59T67 : Tree 12 := .split 24 q12Shape59T68 q12Shape59T77
private theorem q12Shape59T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 3538944 q12Shape59T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 (3538944 ||| 2^24) q12Shape59T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (524288 ||| 2^24) 3538944 q12Shape59T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T68OK,q12Shape59T77OK⟩

private def q12Shape59T90 : Tree 12 := (.split 26 (.split 27 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))) (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2621440 51773440 q12Shape59T90=true := by decide

private def q12Shape59T91 : Tree 12 := (.split 26 (.split 27 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,7,8,10,11})))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 36175872 18219008 q12Shape59T91=true := by decide

private def q12Shape59T89 : Tree 12 := .split 25 q12Shape59T90 q12Shape59T91
private theorem q12Shape59T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2621440 18219008 q12Shape59T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2621440 (18219008 ||| 2^25) q12Shape59T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2621440 ||| 2^25) 18219008 q12Shape59T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T90OK,q12Shape59T91OK⟩

private def q12Shape59T92 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 19398656 1441792 q12Shape59T92=true := by decide

private def q12Shape59T88 : Tree 12 := .split 24 q12Shape59T89 q12Shape59T92
private theorem q12Shape59T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2621440 1441792 q12Shape59T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2621440 (1441792 ||| 2^24) q12Shape59T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2621440 ||| 2^24) 1441792 q12Shape59T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T89OK,q12Shape59T92OK⟩

private def q12Shape59T66 : Tree 12 := .split 21 q12Shape59T67 q12Shape59T88
private theorem q12Shape59T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 1441792 q12Shape59T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 (1441792 ||| 2^21) q12Shape59T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (524288 ||| 2^21) 1441792 q12Shape59T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T67OK,q12Shape59T88OK⟩

private def q12Shape59T97 : Tree 12 := (.split 27 (.split 30 (.split 31 (.tip (.cover {0,2,3,4,9,10,11})) (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))) (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 119930880 q12Shape59T97=true := by decide

private def q12Shape59T98 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 68681728 52822016 q12Shape59T98=true := by decide

private def q12Shape59T96 : Tree 12 := .split 26 q12Shape59T97 q12Shape59T98
private theorem q12Shape59T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 52822016 q12Shape59T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 (52822016 ||| 2^26) q12Shape59T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1572864 ||| 2^26) 52822016 q12Shape59T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T97OK,q12Shape59T98OK⟩

private def q12Shape59T100 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 35127296 86376448 q12Shape59T100=true := by decide

private def q12Shape59T101 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 102236160 19267584 q12Shape59T101=true := by decide

private def q12Shape59T99 : Tree 12 := .split 26 q12Shape59T100 q12Shape59T101
private theorem q12Shape59T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 35127296 19267584 q12Shape59T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 35127296 (19267584 ||| 2^26) q12Shape59T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (35127296 ||| 2^26) 19267584 q12Shape59T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T100OK,q12Shape59T101OK⟩

private def q12Shape59T95 : Tree 12 := .split 25 q12Shape59T96 q12Shape59T99
private theorem q12Shape59T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 19267584 q12Shape59T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 (19267584 ||| 2^25) q12Shape59T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1572864 ||| 2^25) 19267584 q12Shape59T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T96OK,q12Shape59T99OK⟩

private def q12Shape59T102 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18350080 2490368 q12Shape59T102=true := by decide

private def q12Shape59T94 : Tree 12 := .split 24 q12Shape59T95 q12Shape59T102
private theorem q12Shape59T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 2490368 q12Shape59T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 (2490368 ||| 2^24) q12Shape59T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1572864 ||| 2^24) 2490368 q12Shape59T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T95OK,q12Shape59T102OK⟩

private def q12Shape59T103 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape59T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3670016 393216 q12Shape59T103=true := by decide

private def q12Shape59T93 : Tree 12 := .split 21 q12Shape59T94 q12Shape59T103
private theorem q12Shape59T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 393216 q12Shape59T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1572864 (393216 ||| 2^21) q12Shape59T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1572864 ||| 2^21) 393216 q12Shape59T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T94OK,q12Shape59T103OK⟩

private def q12Shape59T65 : Tree 12 := .split 20 q12Shape59T66 q12Shape59T93
private theorem q12Shape59T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 393216 q12Shape59T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 (393216 ||| 2^20) q12Shape59T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (524288 ||| 2^20) 393216 q12Shape59T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T66OK,q12Shape59T93OK⟩

def q12Shape59P3 : Tree 12 := q12Shape59T65
theorem q12Shape59P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 524288 393216 q12Shape59P3=true := q12Shape59T65OK

end Graffiti384b.EffectiveSearch.Q12
