import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape59T157 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,2,3,8,9,10,11}))) (.tip (.cover {0,2,3,8,9,10,11}))) (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))))
private theorem q12Shape59T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 254410752 q12Shape59T157=true := by decide

private def q12Shape59T158 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape59T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 135528448 120193024 q12Shape59T158=true := by decide

private def q12Shape59T156 : Tree 12 := .split 27 q12Shape59T157 q12Shape59T158
private theorem q12Shape59T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 120193024 q12Shape59T156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 (120193024 ||| 2^27) q12Shape59T157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1310720 ||| 2^27) 120193024 q12Shape59T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T157OK,q12Shape59T158OK⟩

private def q12Shape59T159 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape59T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 68419584 53084160 q12Shape59T159=true := by decide

private def q12Shape59T155 : Tree 12 := .split 26 q12Shape59T156 q12Shape59T159
private theorem q12Shape59T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 53084160 q12Shape59T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 (53084160 ||| 2^26) q12Shape59T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1310720 ||| 2^26) 53084160 q12Shape59T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T156OK,q12Shape59T159OK⟩

private def q12Shape59T160 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34865152 19529728 q12Shape59T160=true := by decide

private def q12Shape59T154 : Tree 12 := .split 25 q12Shape59T155 q12Shape59T160
private theorem q12Shape59T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 19529728 q12Shape59T154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 (19529728 ||| 2^25) q12Shape59T155 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1310720 ||| 2^25) 19529728 q12Shape59T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T155OK,q12Shape59T160OK⟩

private def q12Shape59T163 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,5,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape59T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18087936 103415808 q12Shape59T163=true := by decide

private def q12Shape59T164 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape59T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 85196800 36306944 q12Shape59T164=true := by decide

private def q12Shape59T162 : Tree 12 := .split 26 q12Shape59T163 q12Shape59T164
private theorem q12Shape59T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18087936 36306944 q12Shape59T162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18087936 (36306944 ||| 2^26) q12Shape59T163 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (18087936 ||| 2^26) 36306944 q12Shape59T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T163OK,q12Shape59T164OK⟩

private def q12Shape59T165 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 51642368 2752512 q12Shape59T165=true := by decide

private def q12Shape59T161 : Tree 12 := .split 25 q12Shape59T162 q12Shape59T165
private theorem q12Shape59T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18087936 2752512 q12Shape59T161=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 18087936 (2752512 ||| 2^25) q12Shape59T162 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (18087936 ||| 2^25) 2752512 q12Shape59T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T162OK,q12Shape59T165OK⟩

private def q12Shape59T153 : Tree 12 := .split 24 q12Shape59T154 q12Shape59T161
private theorem q12Shape59T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 2752512 q12Shape59T153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 (2752512 ||| 2^24) q12Shape59T154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1310720 ||| 2^24) 2752512 q12Shape59T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T154OK,q12Shape59T161OK⟩

private def q12Shape59T166 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape59T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3407872 655360 q12Shape59T166=true := by decide

private def q12Shape59T152 : Tree 12 := .split 21 q12Shape59T153 q12Shape59T166
private theorem q12Shape59T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 655360 q12Shape59T152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 (655360 ||| 2^21) q12Shape59T153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1310720 ||| 2^21) 655360 q12Shape59T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T153OK,q12Shape59T166OK⟩

def q12Shape59P5 : Tree 12 := q12Shape59T152
theorem q12Shape59P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1310720 655360 q12Shape59P5=true := q12Shape59T152OK

private def q12Shape59T174 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,2,3,7,9,10,11}))) (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))) (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,5,6,9,10,11}))))
private theorem q12Shape59T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 254935040 q12Shape59T174=true := by decide

private def q12Shape59T175 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 135004160 120717312 q12Shape59T175=true := by decide

private def q12Shape59T173 : Tree 12 := .split 27 q12Shape59T174 q12Shape59T175
private theorem q12Shape59T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 120717312 q12Shape59T173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 (120717312 ||| 2^27) q12Shape59T174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (786432 ||| 2^27) 120717312 q12Shape59T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T174OK,q12Shape59T175OK⟩

private def q12Shape59T176 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67895296 53608448 q12Shape59T176=true := by decide

private def q12Shape59T172 : Tree 12 := .split 26 q12Shape59T173 q12Shape59T176
private theorem q12Shape59T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 53608448 q12Shape59T172=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 (53608448 ||| 2^26) q12Shape59T173 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (786432 ||| 2^26) 53608448 q12Shape59T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T173OK,q12Shape59T176OK⟩

private def q12Shape59T178 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape59T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34340864 87162880 q12Shape59T178=true := by decide

private def q12Shape59T179 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 101449728 20054016 q12Shape59T179=true := by decide

private def q12Shape59T177 : Tree 12 := .split 26 q12Shape59T178 q12Shape59T179
private theorem q12Shape59T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34340864 20054016 q12Shape59T177=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34340864 (20054016 ||| 2^26) q12Shape59T178 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (34340864 ||| 2^26) 20054016 q12Shape59T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T178OK,q12Shape59T179OK⟩

private def q12Shape59T171 : Tree 12 := .split 25 q12Shape59T172 q12Shape59T177
private theorem q12Shape59T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 20054016 q12Shape59T171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 (20054016 ||| 2^25) q12Shape59T172 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (786432 ||| 2^25) 20054016 q12Shape59T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T172OK,q12Shape59T177OK⟩

private def q12Shape59T182 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape59T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17563648 103940096 q12Shape59T182=true := by decide

private def q12Shape59T183 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 84672512 36831232 q12Shape59T183=true := by decide

private def q12Shape59T181 : Tree 12 := .split 26 q12Shape59T182 q12Shape59T183
private theorem q12Shape59T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17563648 36831232 q12Shape59T181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17563648 (36831232 ||| 2^26) q12Shape59T182 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17563648 ||| 2^26) 36831232 q12Shape59T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T182OK,q12Shape59T183OK⟩

private def q12Shape59T185 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape59T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 51118080 70385664 q12Shape59T185=true := by decide

private def q12Shape59T186 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 118226944 3276800 q12Shape59T186=true := by decide

private def q12Shape59T184 : Tree 12 := .split 26 q12Shape59T185 q12Shape59T186
private theorem q12Shape59T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 51118080 3276800 q12Shape59T184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 51118080 (3276800 ||| 2^26) q12Shape59T185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (51118080 ||| 2^26) 3276800 q12Shape59T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T185OK,q12Shape59T186OK⟩

private def q12Shape59T180 : Tree 12 := .split 25 q12Shape59T181 q12Shape59T184
private theorem q12Shape59T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17563648 3276800 q12Shape59T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17563648 (3276800 ||| 2^25) q12Shape59T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17563648 ||| 2^25) 3276800 q12Shape59T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T181OK,q12Shape59T184OK⟩

private def q12Shape59T170 : Tree 12 := .split 24 q12Shape59T171 q12Shape59T180
private theorem q12Shape59T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 3276800 q12Shape59T170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 (3276800 ||| 2^24) q12Shape59T171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (786432 ||| 2^24) 3276800 q12Shape59T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T171OK,q12Shape59T180OK⟩

private def q12Shape59T187 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2883584 1179648 q12Shape59T187=true := by decide

private def q12Shape59T169 : Tree 12 := .split 21 q12Shape59T170 q12Shape59T187
private theorem q12Shape59T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 1179648 q12Shape59T169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 (1179648 ||| 2^21) q12Shape59T170 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (786432 ||| 2^21) 1179648 q12Shape59T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T170OK,q12Shape59T187OK⟩

private def q12Shape59T188 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1835008 131072 q12Shape59T188=true := by decide

private def q12Shape59T168 : Tree 12 := .split 20 q12Shape59T169 q12Shape59T188
private theorem q12Shape59T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 131072 q12Shape59T168=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 (131072 ||| 2^20) q12Shape59T169 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (786432 ||| 2^20) 131072 q12Shape59T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T169OK,q12Shape59T188OK⟩

def q12Shape59P6 : Tree 12 := q12Shape59T168
theorem q12Shape59P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 786432 131072 q12Shape59P6=true := q12Shape59T168OK

end Graffiti384b.EffectiveSearch.Q12
