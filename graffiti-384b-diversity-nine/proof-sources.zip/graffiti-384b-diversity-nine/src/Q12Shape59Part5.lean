import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape59T198 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 3476815872 q12Shape59T198=true := by decide

private def q12Shape59T199 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11})))
private theorem q12Shape59T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2147614720 1329332224 q12Shape59T199=true := by decide

private def q12Shape59T197 : Tree 12 := .split 31 q12Shape59T198 q12Shape59T199
private theorem q12Shape59T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 1329332224 q12Shape59T197=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 (1329332224 ||| 2^31) q12Shape59T198 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (131072 ||| 2^31) 1329332224 q12Shape59T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T198OK,q12Shape59T199OK⟩

private def q12Shape59T200 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1073872896 255590400 q12Shape59T200=true := by decide

private def q12Shape59T196 : Tree 12 := .split 30 q12Shape59T197 q12Shape59T200
private theorem q12Shape59T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 255590400 q12Shape59T196=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 (255590400 ||| 2^30) q12Shape59T197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (131072 ||| 2^30) 255590400 q12Shape59T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T197OK,q12Shape59T200OK⟩

private def q12Shape59T201 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape59T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 134348800 121372672 q12Shape59T201=true := by decide

private def q12Shape59T195 : Tree 12 := .split 27 q12Shape59T196 q12Shape59T201
private theorem q12Shape59T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 121372672 q12Shape59T195=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 (121372672 ||| 2^27) q12Shape59T196 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (131072 ||| 2^27) 121372672 q12Shape59T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T196OK,q12Shape59T201OK⟩

private def q12Shape59T204 : Tree 12 := (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,5,6,7,10,11}))) (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67239936 1262223360 q12Shape59T204=true := by decide

private def q12Shape59T205 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape59T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1140981760 188481536 q12Shape59T205=true := by decide

private def q12Shape59T203 : Tree 12 := .split 30 q12Shape59T204 q12Shape59T205
private theorem q12Shape59T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67239936 188481536 q12Shape59T203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67239936 (188481536 ||| 2^30) q12Shape59T204 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (67239936 ||| 2^30) 188481536 q12Shape59T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T204OK,q12Shape59T205OK⟩

private def q12Shape59T206 : Tree 12 := (.tip (.cover {0,1,5,6,7,10,11}))
private theorem q12Shape59T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 201457664 54263808 q12Shape59T206=true := by decide

private def q12Shape59T202 : Tree 12 := .split 27 q12Shape59T203 q12Shape59T206
private theorem q12Shape59T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67239936 54263808 q12Shape59T202=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67239936 (54263808 ||| 2^27) q12Shape59T203 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (67239936 ||| 2^27) 54263808 q12Shape59T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T203OK,q12Shape59T206OK⟩

private def q12Shape59T194 : Tree 12 := .split 26 q12Shape59T195 q12Shape59T202
private theorem q12Shape59T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 54263808 q12Shape59T194=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 (54263808 ||| 2^26) q12Shape59T195 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (131072 ||| 2^26) 54263808 q12Shape59T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T195OK,q12Shape59T202OK⟩

private def q12Shape59T210 : Tree 12 := (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape59T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33685504 1295777792 q12Shape59T210=true := by decide

private def q12Shape59T211 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1107427328 222035968 q12Shape59T211=true := by decide

private def q12Shape59T209 : Tree 12 := .split 30 q12Shape59T210 q12Shape59T211
private theorem q12Shape59T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33685504 222035968 q12Shape59T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33685504 (222035968 ||| 2^30) q12Shape59T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (33685504 ||| 2^30) 222035968 q12Shape59T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T210OK,q12Shape59T211OK⟩

private def q12Shape59T212 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape59T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 167903232 87818240 q12Shape59T212=true := by decide

private def q12Shape59T208 : Tree 12 := .split 27 q12Shape59T209 q12Shape59T212
private theorem q12Shape59T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33685504 87818240 q12Shape59T208=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33685504 (87818240 ||| 2^27) q12Shape59T209 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (33685504 ||| 2^27) 87818240 q12Shape59T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T209OK,q12Shape59T212OK⟩

private def q12Shape59T213 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape59T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 100794368 20709376 q12Shape59T213=true := by decide

private def q12Shape59T207 : Tree 12 := .split 26 q12Shape59T208 q12Shape59T213
private theorem q12Shape59T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33685504 20709376 q12Shape59T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33685504 (20709376 ||| 2^26) q12Shape59T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (33685504 ||| 2^26) 20709376 q12Shape59T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T208OK,q12Shape59T213OK⟩

private def q12Shape59T193 : Tree 12 := .split 25 q12Shape59T194 q12Shape59T207
private theorem q12Shape59T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 20709376 q12Shape59T193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 (20709376 ||| 2^25) q12Shape59T194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (131072 ||| 2^25) 20709376 q12Shape59T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T194OK,q12Shape59T207OK⟩

private def q12Shape59T218 : Tree 12 := (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.tip (.cover {0,1,5,7,9,10,11}))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 1312555008 q12Shape59T218=true := by decide

private def q12Shape59T219 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1090650112 238813184 q12Shape59T219=true := by decide

private def q12Shape59T217 : Tree 12 := .split 30 q12Shape59T218 q12Shape59T219
private theorem q12Shape59T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 238813184 q12Shape59T217=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 (238813184 ||| 2^30) q12Shape59T218 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (16908288 ||| 2^30) 238813184 q12Shape59T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T218OK,q12Shape59T219OK⟩

private def q12Shape59T220 : Tree 12 := (.tip (.cover {0,1,5,7,8,10,11}))
private theorem q12Shape59T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 151126016 104595456 q12Shape59T220=true := by decide

private def q12Shape59T216 : Tree 12 := .split 27 q12Shape59T217 q12Shape59T220
private theorem q12Shape59T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 104595456 q12Shape59T216=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 (104595456 ||| 2^27) q12Shape59T217 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (16908288 ||| 2^27) 104595456 q12Shape59T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T217OK,q12Shape59T220OK⟩

private def q12Shape59T221 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape59T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 84017152 37486592 q12Shape59T221=true := by decide

private def q12Shape59T215 : Tree 12 := .split 26 q12Shape59T216 q12Shape59T221
private theorem q12Shape59T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 37486592 q12Shape59T215=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 (37486592 ||| 2^26) q12Shape59T216 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (16908288 ||| 2^26) 37486592 q12Shape59T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T216OK,q12Shape59T221OK⟩

private def q12Shape59T222 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape59T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 50462720 3932160 q12Shape59T222=true := by decide

private def q12Shape59T214 : Tree 12 := .split 25 q12Shape59T215 q12Shape59T222
private theorem q12Shape59T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 3932160 q12Shape59T214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 16908288 (3932160 ||| 2^25) q12Shape59T215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (16908288 ||| 2^25) 3932160 q12Shape59T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T215OK,q12Shape59T222OK⟩

private def q12Shape59T192 : Tree 12 := .split 24 q12Shape59T193 q12Shape59T214
private theorem q12Shape59T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 3932160 q12Shape59T192=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 (3932160 ||| 2^24) q12Shape59T193 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (131072 ||| 2^24) 3932160 q12Shape59T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T193OK,q12Shape59T214OK⟩

private def q12Shape59T226 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape59T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2228224 119275520 q12Shape59T226=true := by decide

private def q12Shape59T227 : Tree 12 := (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape59T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 69337088 52166656 q12Shape59T227=true := by decide

private def q12Shape59T225 : Tree 12 := .split 26 q12Shape59T226 q12Shape59T227
private theorem q12Shape59T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2228224 52166656 q12Shape59T225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2228224 (52166656 ||| 2^26) q12Shape59T226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2228224 ||| 2^26) 52166656 q12Shape59T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T226OK,q12Shape59T227OK⟩

private def q12Shape59T228 : Tree 12 := (.split 26 (.split 27 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 35782656 18612224 q12Shape59T228=true := by decide

private def q12Shape59T224 : Tree 12 := .split 25 q12Shape59T225 q12Shape59T228
private theorem q12Shape59T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2228224 18612224 q12Shape59T224=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2228224 (18612224 ||| 2^25) q12Shape59T225 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2228224 ||| 2^25) 18612224 q12Shape59T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T225OK,q12Shape59T228OK⟩

private def q12Shape59T230 : Tree 12 := (.split 26 (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,5,9,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape59T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 19005440 35389440 q12Shape59T230=true := by decide

private def q12Shape59T231 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 52559872 1835008 q12Shape59T231=true := by decide

private def q12Shape59T229 : Tree 12 := .split 25 q12Shape59T230 q12Shape59T231
private theorem q12Shape59T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 19005440 1835008 q12Shape59T229=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 19005440 (1835008 ||| 2^25) q12Shape59T230 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (19005440 ||| 2^25) 1835008 q12Shape59T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T230OK,q12Shape59T231OK⟩

private def q12Shape59T223 : Tree 12 := .split 24 q12Shape59T224 q12Shape59T229
private theorem q12Shape59T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2228224 1835008 q12Shape59T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2228224 (1835008 ||| 2^24) q12Shape59T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (2228224 ||| 2^24) 1835008 q12Shape59T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T224OK,q12Shape59T229OK⟩

private def q12Shape59T191 : Tree 12 := .split 21 q12Shape59T192 q12Shape59T223
private theorem q12Shape59T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 1835008 q12Shape59T191=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 (1835008 ||| 2^21) q12Shape59T192 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (131072 ||| 2^21) 1835008 q12Shape59T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T192OK,q12Shape59T223OK⟩

def q12Shape59P7 : Tree 12 := q12Shape59T191
theorem q12Shape59P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 131072 1835008 q12Shape59P7=true := q12Shape59T191OK

end Graffiti384b.EffectiveSearch.Q12
