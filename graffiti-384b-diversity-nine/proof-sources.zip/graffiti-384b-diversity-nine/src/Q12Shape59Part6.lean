import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape59T238 : Tree 12 := (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,4,6,7,10,11}))) (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 1328283648 q12Shape59T238=true := by decide

private def q12Shape59T239 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape59T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1074921472 254541824 q12Shape59T239=true := by decide

private def q12Shape59T237 : Tree 12 := .split 30 q12Shape59T238 q12Shape59T239
private theorem q12Shape59T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 254541824 q12Shape59T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 (254541824 ||| 2^30) q12Shape59T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1179648 ||| 2^30) 254541824 q12Shape59T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T238OK,q12Shape59T239OK⟩

private def q12Shape59T240 : Tree 12 := (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 135397376 120324096 q12Shape59T240=true := by decide

private def q12Shape59T236 : Tree 12 := .split 27 q12Shape59T237 q12Shape59T240
private theorem q12Shape59T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 120324096 q12Shape59T236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 (120324096 ||| 2^27) q12Shape59T237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1179648 ||| 2^27) 120324096 q12Shape59T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T237OK,q12Shape59T240OK⟩

private def q12Shape59T241 : Tree 12 := (.split 27 (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape59T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 68288512 53215232 q12Shape59T241=true := by decide

private def q12Shape59T235 : Tree 12 := .split 26 q12Shape59T236 q12Shape59T241
private theorem q12Shape59T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 53215232 q12Shape59T235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 (53215232 ||| 2^26) q12Shape59T236 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1179648 ||| 2^26) 53215232 q12Shape59T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T236OK,q12Shape59T241OK⟩

private def q12Shape59T242 : Tree 12 := (.split 26 (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape59T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34734080 19660800 q12Shape59T242=true := by decide

private def q12Shape59T234 : Tree 12 := .split 25 q12Shape59T235 q12Shape59T242
private theorem q12Shape59T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 19660800 q12Shape59T234=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 (19660800 ||| 2^25) q12Shape59T235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1179648 ||| 2^25) 19660800 q12Shape59T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T235OK,q12Shape59T242OK⟩

private def q12Shape59T247 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,5,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))) (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,8,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 1311506432 q12Shape59T247=true := by decide

private def q12Shape59T248 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape59T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1091698688 237764608 q12Shape59T248=true := by decide

private def q12Shape59T246 : Tree 12 := .split 30 q12Shape59T247 q12Shape59T248
private theorem q12Shape59T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 237764608 q12Shape59T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 (237764608 ||| 2^30) q12Shape59T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17956864 ||| 2^30) 237764608 q12Shape59T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T247OK,q12Shape59T248OK⟩

private def q12Shape59T249 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape59T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 152174592 103546880 q12Shape59T249=true := by decide

private def q12Shape59T245 : Tree 12 := .split 27 q12Shape59T246 q12Shape59T249
private theorem q12Shape59T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 103546880 q12Shape59T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 (103546880 ||| 2^27) q12Shape59T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17956864 ||| 2^27) 103546880 q12Shape59T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T246OK,q12Shape59T249OK⟩

private def q12Shape59T250 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape59T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 85065728 36438016 q12Shape59T250=true := by decide

private def q12Shape59T244 : Tree 12 := .split 26 q12Shape59T245 q12Shape59T250
private theorem q12Shape59T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 36438016 q12Shape59T244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 (36438016 ||| 2^26) q12Shape59T245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17956864 ||| 2^26) 36438016 q12Shape59T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T245OK,q12Shape59T250OK⟩

private def q12Shape59T251 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 51511296 2883584 q12Shape59T251=true := by decide

private def q12Shape59T243 : Tree 12 := .split 25 q12Shape59T244 q12Shape59T251
private theorem q12Shape59T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 2883584 q12Shape59T243=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17956864 (2883584 ||| 2^25) q12Shape59T244 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17956864 ||| 2^25) 2883584 q12Shape59T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T244OK,q12Shape59T251OK⟩

private def q12Shape59T233 : Tree 12 := .split 24 q12Shape59T234 q12Shape59T243
private theorem q12Shape59T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 2883584 q12Shape59T233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 (2883584 ||| 2^24) q12Shape59T234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1179648 ||| 2^24) 2883584 q12Shape59T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T234OK,q12Shape59T243OK⟩

private def q12Shape59T252 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape59T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 3276800 786432 q12Shape59T252=true := by decide

private def q12Shape59T232 : Tree 12 := .split 21 q12Shape59T233 q12Shape59T252
private theorem q12Shape59T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 786432 q12Shape59T232=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 (786432 ||| 2^21) q12Shape59T233 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (1179648 ||| 2^21) 786432 q12Shape59T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T233OK,q12Shape59T252OK⟩

def q12Shape59P8 : Tree 12 := q12Shape59T232
theorem q12Shape59P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1179648 786432 q12Shape59P8=true := q12Shape59T232OK

private def q12Shape59T261 : Tree 12 := (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 1328807936 q12Shape59T261=true := by decide

private def q12Shape59T262 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1074397184 255066112 q12Shape59T262=true := by decide

private def q12Shape59T260 : Tree 12 := .split 30 q12Shape59T261 q12Shape59T262
private theorem q12Shape59T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 255066112 q12Shape59T260=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 (255066112 ||| 2^30) q12Shape59T261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (655360 ||| 2^30) 255066112 q12Shape59T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T261OK,q12Shape59T262OK⟩

private def q12Shape59T263 : Tree 12 := (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape59T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 134873088 120848384 q12Shape59T263=true := by decide

private def q12Shape59T259 : Tree 12 := .split 27 q12Shape59T260 q12Shape59T263
private theorem q12Shape59T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 120848384 q12Shape59T259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 (120848384 ||| 2^27) q12Shape59T260 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (655360 ||| 2^27) 120848384 q12Shape59T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T260OK,q12Shape59T263OK⟩

private def q12Shape59T264 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,2,3,7,8,10,11})) (.tip (.cover {0,1,4,5,6,10,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape59T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67764224 53739520 q12Shape59T264=true := by decide

private def q12Shape59T258 : Tree 12 := .split 26 q12Shape59T259 q12Shape59T264
private theorem q12Shape59T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 53739520 q12Shape59T258=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 (53739520 ||| 2^26) q12Shape59T259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (655360 ||| 2^26) 53739520 q12Shape59T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T259OK,q12Shape59T264OK⟩

private def q12Shape59T265 : Tree 12 := (.split 26 (.split 27 (.split 30 (.split 31 (.tip (.cover {0,2,3,7,9,10,11})) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape59T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 34209792 20185088 q12Shape59T265=true := by decide

private def q12Shape59T257 : Tree 12 := .split 25 q12Shape59T258 q12Shape59T265
private theorem q12Shape59T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 20185088 q12Shape59T257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 (20185088 ||| 2^25) q12Shape59T258 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (655360 ||| 2^25) 20185088 q12Shape59T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T258OK,q12Shape59T265OK⟩

private def q12Shape59T270 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 1312030720 q12Shape59T270=true := by decide

private def q12Shape59T271 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1091174400 238288896 q12Shape59T271=true := by decide

private def q12Shape59T269 : Tree 12 := .split 30 q12Shape59T270 q12Shape59T271
private theorem q12Shape59T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 238288896 q12Shape59T269=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 (238288896 ||| 2^30) q12Shape59T270 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17432576 ||| 2^30) 238288896 q12Shape59T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T270OK,q12Shape59T271OK⟩

private def q12Shape59T272 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 151650304 104071168 q12Shape59T272=true := by decide

private def q12Shape59T268 : Tree 12 := .split 27 q12Shape59T269 q12Shape59T272
private theorem q12Shape59T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 104071168 q12Shape59T268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 (104071168 ||| 2^27) q12Shape59T269 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17432576 ||| 2^27) 104071168 q12Shape59T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T269OK,q12Shape59T272OK⟩

private def q12Shape59T273 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 84541440 36962304 q12Shape59T273=true := by decide

private def q12Shape59T267 : Tree 12 := .split 26 q12Shape59T268 q12Shape59T273
private theorem q12Shape59T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 36962304 q12Shape59T267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 (36962304 ||| 2^26) q12Shape59T268 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17432576 ||| 2^26) 36962304 q12Shape59T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T268OK,q12Shape59T273OK⟩

private def q12Shape59T274 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape59T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 50987008 3407872 q12Shape59T274=true := by decide

private def q12Shape59T266 : Tree 12 := .split 25 q12Shape59T267 q12Shape59T274
private theorem q12Shape59T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 3407872 q12Shape59T266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17432576 (3407872 ||| 2^25) q12Shape59T267 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (17432576 ||| 2^25) 3407872 q12Shape59T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T267OK,q12Shape59T274OK⟩

private def q12Shape59T256 : Tree 12 := .split 24 q12Shape59T257 q12Shape59T266
private theorem q12Shape59T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 3407872 q12Shape59T256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 (3407872 ||| 2^24) q12Shape59T257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (655360 ||| 2^24) 3407872 q12Shape59T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T257OK,q12Shape59T266OK⟩

private def q12Shape59T275 : Tree 12 := (.tip (.cover {0,1,4,6,8,10,11}))
private theorem q12Shape59T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2752512 1310720 q12Shape59T275=true := by decide

private def q12Shape59T255 : Tree 12 := .split 21 q12Shape59T256 q12Shape59T275
private theorem q12Shape59T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 1310720 q12Shape59T255=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 (1310720 ||| 2^21) q12Shape59T256 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (655360 ||| 2^21) 1310720 q12Shape59T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T256OK,q12Shape59T275OK⟩

private def q12Shape59T276 : Tree 12 := (.tip (.cover {0,1,4,6,9,10,11}))
private theorem q12Shape59T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1703936 262144 q12Shape59T276=true := by decide

private def q12Shape59T254 : Tree 12 := .split 20 q12Shape59T255 q12Shape59T276
private theorem q12Shape59T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 262144 q12Shape59T254=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 (262144 ||| 2^20) q12Shape59T255 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (655360 ||| 2^20) 262144 q12Shape59T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T255OK,q12Shape59T276OK⟩

def q12Shape59P9 : Tree 12 := q12Shape59T254
theorem q12Shape59P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 655360 262144 q12Shape59P9=true := q12Shape59T254OK

end Graffiti384b.EffectiveSearch.Q12
