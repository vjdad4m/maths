import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape59T286 : Tree 12 := (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,6,7,10,11})))) (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,6,7,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 1329070080 q12Shape59T286=true := by decide

private def q12Shape59T287 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1074135040 255328256 q12Shape59T287=true := by decide

private def q12Shape59T285 : Tree 12 := .split 30 q12Shape59T286 q12Shape59T287
private theorem q12Shape59T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 255328256 q12Shape59T285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (255328256 ||| 2^30) q12Shape59T286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^30) 255328256 q12Shape59T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T286OK,q12Shape59T287OK⟩

private def q12Shape59T288 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,5,7,10,11})))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape59T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 134610944 121110528 q12Shape59T288=true := by decide

private def q12Shape59T284 : Tree 12 := .split 27 q12Shape59T285 q12Shape59T288
private theorem q12Shape59T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 121110528 q12Shape59T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (121110528 ||| 2^27) q12Shape59T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^27) 121110528 q12Shape59T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T285OK,q12Shape59T288OK⟩

private def q12Shape59T291 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,4,5,7,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,7,10,11}))))
private theorem q12Shape59T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67502080 1261961216 q12Shape59T291=true := by decide

private def q12Shape59T292 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape59T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1141243904 188219392 q12Shape59T292=true := by decide

private def q12Shape59T290 : Tree 12 := .split 30 q12Shape59T291 q12Shape59T292
private theorem q12Shape59T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67502080 188219392 q12Shape59T290=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67502080 (188219392 ||| 2^30) q12Shape59T291 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (67502080 ||| 2^30) 188219392 q12Shape59T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T291OK,q12Shape59T292OK⟩

private def q12Shape59T293 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape59T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 201719808 54001664 q12Shape59T293=true := by decide

private def q12Shape59T289 : Tree 12 := .split 27 q12Shape59T290 q12Shape59T293
private theorem q12Shape59T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67502080 54001664 q12Shape59T289=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 67502080 (54001664 ||| 2^27) q12Shape59T290 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (67502080 ||| 2^27) 54001664 q12Shape59T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T290OK,q12Shape59T293OK⟩

private def q12Shape59T283 : Tree 12 := .split 26 q12Shape59T284 q12Shape59T289
private theorem q12Shape59T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 54001664 q12Shape59T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (54001664 ||| 2^26) q12Shape59T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^26) 54001664 q12Shape59T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T284OK,q12Shape59T289OK⟩

private def q12Shape59T297 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape59T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33947648 1295515648 q12Shape59T297=true := by decide

private def q12Shape59T298 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,9,10,11})))
private theorem q12Shape59T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1107689472 221773824 q12Shape59T298=true := by decide

private def q12Shape59T296 : Tree 12 := .split 30 q12Shape59T297 q12Shape59T298
private theorem q12Shape59T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33947648 221773824 q12Shape59T296=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33947648 (221773824 ||| 2^30) q12Shape59T297 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (33947648 ||| 2^30) 221773824 q12Shape59T298)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T297OK,q12Shape59T298OK⟩

private def q12Shape59T299 : Tree 12 := (.tip (.cover {0,1,4,5,8,10,11}))
private theorem q12Shape59T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 168165376 87556096 q12Shape59T299=true := by decide

private def q12Shape59T295 : Tree 12 := .split 27 q12Shape59T296 q12Shape59T299
private theorem q12Shape59T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33947648 87556096 q12Shape59T295=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33947648 (87556096 ||| 2^27) q12Shape59T296 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (33947648 ||| 2^27) 87556096 q12Shape59T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T296OK,q12Shape59T299OK⟩

private def q12Shape59T300 : Tree 12 := (.tip (.cover {0,1,4,5,9,10,11}))
private theorem q12Shape59T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 101056512 20447232 q12Shape59T300=true := by decide

private def q12Shape59T294 : Tree 12 := .split 26 q12Shape59T295 q12Shape59T300
private theorem q12Shape59T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33947648 20447232 q12Shape59T294=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 33947648 (20447232 ||| 2^26) q12Shape59T295 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (33947648 ||| 2^26) 20447232 q12Shape59T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T295OK,q12Shape59T300OK⟩

private def q12Shape59T282 : Tree 12 := .split 25 q12Shape59T283 q12Shape59T294
private theorem q12Shape59T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 20447232 q12Shape59T282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (20447232 ||| 2^25) q12Shape59T283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^25) 20447232 q12Shape59T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T283OK,q12Shape59T294OK⟩

private def q12Shape59T301 : Tree 12 := (.split 25 (.split 26 (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape59T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 17170432 3670016 q12Shape59T301=true := by decide

private def q12Shape59T281 : Tree 12 := .split 24 q12Shape59T282 q12Shape59T301
private theorem q12Shape59T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 3670016 q12Shape59T281=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (3670016 ||| 2^24) q12Shape59T282 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^24) 3670016 q12Shape59T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T282OK,q12Shape59T301OK⟩

private def q12Shape59T302 : Tree 12 := (.tip (.cover {0,1,4,7,8,10,11}))
private theorem q12Shape59T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 2490368 1572864 q12Shape59T302=true := by decide

private def q12Shape59T280 : Tree 12 := .split 21 q12Shape59T281 q12Shape59T302
private theorem q12Shape59T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 1572864 q12Shape59T280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (1572864 ||| 2^21) q12Shape59T281 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^21) 1572864 q12Shape59T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T281OK,q12Shape59T302OK⟩

private def q12Shape59T303 : Tree 12 := (.tip (.cover {0,1,4,7,9,10,11}))
private theorem q12Shape59T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 1441792 524288 q12Shape59T303=true := by decide

private def q12Shape59T279 : Tree 12 := .split 20 q12Shape59T280 q12Shape59T303
private theorem q12Shape59T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 524288 q12Shape59T279=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (524288 ||| 2^20) q12Shape59T280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^20) 524288 q12Shape59T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T280OK,q12Shape59T303OK⟩

private def q12Shape59T304 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape59T304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 917504 0 q12Shape59T304=true := by decide

private def q12Shape59T278 : Tree 12 := .split 19 q12Shape59T279 q12Shape59T304
private theorem q12Shape59T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 0 q12Shape59T278=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 (0 ||| 2^19) q12Shape59T279 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) (393216 ||| 2^19) 0 q12Shape59T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape59T279OK,q12Shape59T304OK⟩

def q12Shape59P10 : Tree 12 := q12Shape59T278
theorem q12Shape59P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,2⟩) 393216 0 q12Shape59P10=true := q12Shape59T278OK

end Graffiti384b.EffectiveSearch.Q12
