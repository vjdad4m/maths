import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T1 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 17178112 q12Shape5T1=true := by decide

private def q12Shape5T3 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.tip (.cover {0,2,5,8,9,10,11})))
private theorem q12Shape5T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777216 925184 q12Shape5T3=true := by decide

private def q12Shape5T8 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10,11})))))))
private theorem q12Shape5T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 1650375138816 q12Shape5T8=true := by decide

private def q12Shape5T9 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528929280 550863511040 q12Shape5T9=true := by decide

private def q12Shape5T7 : Tree 12 := .split 40 q12Shape5T8 q12Shape5T9
private theorem q12Shape5T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 550863511040 q12Shape5T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 (550863511040 ||| 2^40) q12Shape5T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17301504 ||| 2^40) 550863511040 q12Shape5T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T8OK,q12Shape5T9OK⟩

private def q12Shape5T10 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549773115392 1107697152 q12Shape5T10=true := by decide

private def q12Shape5T6 : Tree 12 := .split 39 q12Shape5T7 q12Shape5T10
private theorem q12Shape5T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 1107697152 q12Shape5T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 (1107697152 ||| 2^39) q12Shape5T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17301504 ||| 2^39) 1107697152 q12Shape5T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T7OK,q12Shape5T10OK⟩

private def q12Shape5T13 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091043328 1649301396992 q12Shape5T13=true := by decide

private def q12Shape5T14 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100602671104 549789769216 q12Shape5T14=true := by decide

private def q12Shape5T12 : Tree 12 := .split 40 q12Shape5T13 q12Shape5T14
private theorem q12Shape5T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091043328 549789769216 q12Shape5T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091043328 (549789769216 ||| 2^40) q12Shape5T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1091043328 ||| 2^40) 549789769216 q12Shape5T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T13OK,q12Shape5T14OK⟩

private def q12Shape5T15 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550846857216 33955328 q12Shape5T15=true := by decide

private def q12Shape5T11 : Tree 12 := .split 39 q12Shape5T12 q12Shape5T15
private theorem q12Shape5T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091043328 33955328 q12Shape5T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091043328 (33955328 ||| 2^39) q12Shape5T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1091043328 ||| 2^39) 33955328 q12Shape5T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T12OK,q12Shape5T15OK⟩

private def q12Shape5T5 : Tree 12 := .split 30 q12Shape5T6 q12Shape5T11
private theorem q12Shape5T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 33955328 q12Shape5T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 (33955328 ||| 2^30) q12Shape5T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17301504 ||| 2^30) 33955328 q12Shape5T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T6OK,q12Shape5T11OK⟩

private def q12Shape5T19 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50855936 1650341584384 q12Shape5T19=true := by decide

private def q12Shape5T20 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099562483712 550829956608 q12Shape5T20=true := by decide

private def q12Shape5T18 : Tree 12 := .split 40 q12Shape5T19 q12Shape5T20
private theorem q12Shape5T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50855936 550829956608 q12Shape5T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50855936 (550829956608 ||| 2^40) q12Shape5T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50855936 ||| 2^40) 550829956608 q12Shape5T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T19OK,q12Shape5T20OK⟩

private def q12Shape5T21 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549806669824 1074142720 q12Shape5T21=true := by decide

private def q12Shape5T17 : Tree 12 := .split 39 q12Shape5T18 q12Shape5T21
private theorem q12Shape5T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50855936 1074142720 q12Shape5T17=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50855936 (1074142720 ||| 2^39) q12Shape5T18 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50855936 ||| 2^39) 1074142720 q12Shape5T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T18OK,q12Shape5T21OK⟩

private def q12Shape5T22 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1124597760 400896 q12Shape5T22=true := by decide

private def q12Shape5T16 : Tree 12 := .split 30 q12Shape5T17 q12Shape5T22
private theorem q12Shape5T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50855936 400896 q12Shape5T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50855936 (400896 ||| 2^30) q12Shape5T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50855936 ||| 2^30) 400896 q12Shape5T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T17OK,q12Shape5T22OK⟩

private def q12Shape5T4 : Tree 12 := .split 25 q12Shape5T5 q12Shape5T16
private theorem q12Shape5T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 400896 q12Shape5T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17301504 (400896 ||| 2^25) q12Shape5T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17301504 ||| 2^25) 400896 q12Shape5T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T5OK,q12Shape5T16OK⟩

private def q12Shape5T2 : Tree 12 := .split 19 q12Shape5T3 q12Shape5T4
private theorem q12Shape5T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777216 400896 q12Shape5T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777216 (400896 ||| 2^19) q12Shape5T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16777216 ||| 2^19) 400896 q12Shape5T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T3OK,q12Shape5T4OK⟩

private def q12Shape5T0 : Tree 12 := .split 24 q12Shape5T1 q12Shape5T2
private theorem q12Shape5T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 400896 q12Shape5T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 (400896 ||| 2^24) q12Shape5T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (0 ||| 2^24) 400896 q12Shape5T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T1OK,q12Shape5T2OK⟩

def q12Shape5P0 : Tree 12 := q12Shape5T0
theorem q12Shape5P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 0 400896 q12Shape5P0=true := q12Shape5T0OK

end Graffiti384b.EffectiveSearch.Q12
