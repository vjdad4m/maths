import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T24 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape5T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262144 34217472 q12Shape5T24=true := by decide

private def q12Shape5T29 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))))
private theorem q12Shape5T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 1650358623744 q12Shape5T29=true := by decide

private def q12Shape5T30 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545444352 550846995968 q12Shape5T30=true := by decide

private def q12Shape5T28 : Tree 12 := .split 40 q12Shape5T29 q12Shape5T30
private theorem q12Shape5T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 550846995968 q12Shape5T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 (550846995968 ||| 2^40) q12Shape5T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33816576 ||| 2^40) 550846995968 q12Shape5T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T29OK,q12Shape5T30OK⟩

private def q12Shape5T31 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789630464 1091182080 q12Shape5T31=true := by decide

private def q12Shape5T27 : Tree 12 := .split 39 q12Shape5T28 q12Shape5T31
private theorem q12Shape5T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 1091182080 q12Shape5T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 (1091182080 ||| 2^39) q12Shape5T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33816576 ||| 2^39) 1091182080 q12Shape5T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T28OK,q12Shape5T31OK⟩

private def q12Shape5T34 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107558400 1649284881920 q12Shape5T34=true := by decide

private def q12Shape5T35 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100619186176 549773254144 q12Shape5T35=true := by decide

private def q12Shape5T33 : Tree 12 := .split 40 q12Shape5T34 q12Shape5T35
private theorem q12Shape5T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107558400 549773254144 q12Shape5T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107558400 (549773254144 ||| 2^40) q12Shape5T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1107558400 ||| 2^40) 549773254144 q12Shape5T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T34OK,q12Shape5T35OK⟩

private def q12Shape5T36 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550863372288 17440256 q12Shape5T36=true := by decide

private def q12Shape5T32 : Tree 12 := .split 39 q12Shape5T33 q12Shape5T36
private theorem q12Shape5T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107558400 17440256 q12Shape5T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107558400 (17440256 ||| 2^39) q12Shape5T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1107558400 ||| 2^39) 17440256 q12Shape5T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T33OK,q12Shape5T36OK⟩

private def q12Shape5T26 : Tree 12 := .split 30 q12Shape5T27 q12Shape5T32
private theorem q12Shape5T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 17440256 q12Shape5T26=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 (17440256 ||| 2^30) q12Shape5T27 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33816576 ||| 2^30) 17440256 q12Shape5T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T27OK,q12Shape5T32OK⟩

private def q12Shape5T40 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50593792 1650341846528 q12Shape5T40=true := by decide

private def q12Shape5T41 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099562221568 550830218752 q12Shape5T41=true := by decide

private def q12Shape5T39 : Tree 12 := .split 40 q12Shape5T40 q12Shape5T41
private theorem q12Shape5T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50593792 550830218752 q12Shape5T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50593792 (550830218752 ||| 2^40) q12Shape5T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50593792 ||| 2^40) 550830218752 q12Shape5T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T40OK,q12Shape5T41OK⟩

private def q12Shape5T42 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549806407680 1074404864 q12Shape5T42=true := by decide

private def q12Shape5T38 : Tree 12 := .split 39 q12Shape5T39 q12Shape5T42
private theorem q12Shape5T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50593792 1074404864 q12Shape5T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50593792 (1074404864 ||| 2^39) q12Shape5T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50593792 ||| 2^39) 1074404864 q12Shape5T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T39OK,q12Shape5T42OK⟩

private def q12Shape5T43 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape5T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1124335616 663040 q12Shape5T43=true := by decide

private def q12Shape5T37 : Tree 12 := .split 30 q12Shape5T38 q12Shape5T43
private theorem q12Shape5T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50593792 663040 q12Shape5T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50593792 (663040 ||| 2^30) q12Shape5T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50593792 ||| 2^30) 663040 q12Shape5T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T38OK,q12Shape5T43OK⟩

private def q12Shape5T25 : Tree 12 := .split 24 q12Shape5T26 q12Shape5T37
private theorem q12Shape5T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 663040 q12Shape5T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33816576 (663040 ||| 2^24) q12Shape5T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33816576 ||| 2^24) 663040 q12Shape5T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T26OK,q12Shape5T37OK⟩

private def q12Shape5T23 : Tree 12 := .split 25 q12Shape5T24 q12Shape5T25
private theorem q12Shape5T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262144 663040 q12Shape5T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262144 (663040 ||| 2^25) q12Shape5T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (262144 ||| 2^25) 663040 q12Shape5T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T24OK,q12Shape5T25OK⟩

def q12Shape5P1 : Tree 12 := q12Shape5T23
theorem q12Shape5P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262144 663040 q12Shape5P1=true := q12Shape5T23OK

end Graffiti384b.EffectiveSearch.Q12
