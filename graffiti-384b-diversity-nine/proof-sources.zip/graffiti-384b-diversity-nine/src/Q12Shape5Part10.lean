import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T249 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10,11})))))))
private theorem q12Shape5T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 1650391913984 q12Shape5T249=true := by decide

private def q12Shape5T250 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512154112 550880286208 q12Shape5T250=true := by decide

private def q12Shape5T248 : Tree 12 := .split 40 q12Shape5T249 q12Shape5T250
private theorem q12Shape5T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 550880286208 q12Shape5T248=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 (550880286208 ||| 2^40) q12Shape5T249 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (526336 ||| 2^40) 550880286208 q12Shape5T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T249OK,q12Shape5T250OK⟩

private def q12Shape5T251 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756340224 1124472320 q12Shape5T251=true := by decide

private def q12Shape5T247 : Tree 12 := .split 39 q12Shape5T248 q12Shape5T251
private theorem q12Shape5T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 1124472320 q12Shape5T247=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 (1124472320 ||| 2^39) q12Shape5T248 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (526336 ||| 2^39) 1124472320 q12Shape5T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T248OK,q12Shape5T251OK⟩

private def q12Shape5T254 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074268160 1649318172160 q12Shape5T254=true := by decide

private def q12Shape5T255 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585895936 549806544384 q12Shape5T255=true := by decide

private def q12Shape5T253 : Tree 12 := .split 40 q12Shape5T254 q12Shape5T255
private theorem q12Shape5T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074268160 549806544384 q12Shape5T253=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074268160 (549806544384 ||| 2^40) q12Shape5T254 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074268160 ||| 2^40) 549806544384 q12Shape5T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T254OK,q12Shape5T255OK⟩

private def q12Shape5T256 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550830082048 50730496 q12Shape5T256=true := by decide

private def q12Shape5T252 : Tree 12 := .split 39 q12Shape5T253 q12Shape5T256
private theorem q12Shape5T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074268160 50730496 q12Shape5T252=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074268160 (50730496 ||| 2^39) q12Shape5T253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074268160 ||| 2^39) 50730496 q12Shape5T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T253OK,q12Shape5T256OK⟩

private def q12Shape5T246 : Tree 12 := .split 30 q12Shape5T247 q12Shape5T252
private theorem q12Shape5T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 50730496 q12Shape5T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 (50730496 ||| 2^30) q12Shape5T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (526336 ||| 2^30) 50730496 q12Shape5T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T247OK,q12Shape5T252OK⟩

private def q12Shape5T257 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080768 17176064 q12Shape5T257=true := by decide

private def q12Shape5T245 : Tree 12 := .split 25 q12Shape5T246 q12Shape5T257
private theorem q12Shape5T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 17176064 q12Shape5T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 (17176064 ||| 2^25) q12Shape5T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (526336 ||| 2^25) 17176064 q12Shape5T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T246OK,q12Shape5T257OK⟩

private def q12Shape5T258 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17303552 398848 q12Shape5T258=true := by decide

private def q12Shape5T244 : Tree 12 := .split 24 q12Shape5T245 q12Shape5T258
private theorem q12Shape5T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 398848 q12Shape5T244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 (398848 ||| 2^24) q12Shape5T245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (526336 ||| 2^24) 398848 q12Shape5T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T245OK,q12Shape5T258OK⟩

def q12Shape5P10 : Tree 12 := q12Shape5T244
theorem q12Shape5P10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 526336 398848 q12Shape5P10=true := q12Shape5T244OK

private def q12Shape5T261 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))))
private theorem q12Shape5T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264192 660992 q12Shape5T261=true := by decide

private def q12Shape5T267 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 1650391651840 q12Shape5T267=true := by decide

private def q12Shape5T268 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512416256 550880024064 q12Shape5T268=true := by decide

private def q12Shape5T266 : Tree 12 := .split 40 q12Shape5T267 q12Shape5T268
private theorem q12Shape5T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 550880024064 q12Shape5T266=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 (550880024064 ||| 2^40) q12Shape5T267 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (788480 ||| 2^40) 550880024064 q12Shape5T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T267OK,q12Shape5T268OK⟩

private def q12Shape5T269 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756602368 1124210176 q12Shape5T269=true := by decide

private def q12Shape5T265 : Tree 12 := .split 39 q12Shape5T266 q12Shape5T269
private theorem q12Shape5T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 1124210176 q12Shape5T265=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 (1124210176 ||| 2^39) q12Shape5T266 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (788480 ||| 2^39) 1124210176 q12Shape5T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T266OK,q12Shape5T269OK⟩

private def q12Shape5T270 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape5T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074530304 50468352 q12Shape5T270=true := by decide

private def q12Shape5T264 : Tree 12 := .split 30 q12Shape5T265 q12Shape5T270
private theorem q12Shape5T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 50468352 q12Shape5T264=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 (50468352 ||| 2^30) q12Shape5T265 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (788480 ||| 2^30) 50468352 q12Shape5T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T265OK,q12Shape5T270OK⟩

private def q12Shape5T271 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34342912 16913920 q12Shape5T271=true := by decide

private def q12Shape5T263 : Tree 12 := .split 25 q12Shape5T264 q12Shape5T271
private theorem q12Shape5T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 16913920 q12Shape5T263=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 (16913920 ||| 2^25) q12Shape5T264 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (788480 ||| 2^25) 16913920 q12Shape5T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T264OK,q12Shape5T271OK⟩

private def q12Shape5T272 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape5T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17565696 136704 q12Shape5T272=true := by decide

private def q12Shape5T262 : Tree 12 := .split 24 q12Shape5T263 q12Shape5T272
private theorem q12Shape5T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 136704 q12Shape5T262=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788480 (136704 ||| 2^24) q12Shape5T263 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (788480 ||| 2^24) 136704 q12Shape5T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T263OK,q12Shape5T272OK⟩

private def q12Shape5T260 : Tree 12 := .split 19 q12Shape5T261 q12Shape5T262
private theorem q12Shape5T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264192 136704 q12Shape5T260=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264192 (136704 ||| 2^19) q12Shape5T261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (264192 ||| 2^19) 136704 q12Shape5T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T261OK,q12Shape5T262OK⟩

def q12Shape5P11 : Tree 12 := q12Shape5T260
theorem q12Shape5P11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264192 136704 q12Shape5P11=true := q12Shape5T260OK

end Graffiti384b.EffectiveSearch.Q12
