import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T281 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))))))
private theorem q12Shape5T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 1650392307200 q12Shape5T281=true := by decide

private def q12Shape5T282 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape5T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511760896 550880679424 q12Shape5T282=true := by decide

private def q12Shape5T280 : Tree 12 := .split 40 q12Shape5T281 q12Shape5T282
private theorem q12Shape5T280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 550880679424 q12Shape5T280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 (550880679424 ||| 2^40) q12Shape5T281 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133120 ||| 2^40) 550880679424 q12Shape5T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T281OK,q12Shape5T282OK⟩

private def q12Shape5T283 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape5T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549755947008 1124865536 q12Shape5T283=true := by decide

private def q12Shape5T279 : Tree 12 := .split 39 q12Shape5T280 q12Shape5T283
private theorem q12Shape5T279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 1124865536 q12Shape5T279=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 (1124865536 ||| 2^39) q12Shape5T280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133120 ||| 2^39) 1124865536 q12Shape5T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T280OK,q12Shape5T283OK⟩

private def q12Shape5T284 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073874944 51123712 q12Shape5T284=true := by decide

private def q12Shape5T278 : Tree 12 := .split 30 q12Shape5T279 q12Shape5T284
private theorem q12Shape5T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 51123712 q12Shape5T278=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 (51123712 ||| 2^30) q12Shape5T279 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133120 ||| 2^30) 51123712 q12Shape5T284)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T279OK,q12Shape5T284OK⟩

private def q12Shape5T285 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33687552 17569280 q12Shape5T285=true := by decide

private def q12Shape5T277 : Tree 12 := .split 25 q12Shape5T278 q12Shape5T285
private theorem q12Shape5T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 17569280 q12Shape5T277=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 (17569280 ||| 2^25) q12Shape5T278 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133120 ||| 2^25) 17569280 q12Shape5T285)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T278OK,q12Shape5T285OK⟩

private def q12Shape5T290 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape5T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 1650375529984 q12Shape5T290=true := by decide

private def q12Shape5T291 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape5T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528538112 550863902208 q12Shape5T291=true := by decide

private def q12Shape5T289 : Tree 12 := .split 40 q12Shape5T290 q12Shape5T291
private theorem q12Shape5T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 550863902208 q12Shape5T289=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 (550863902208 ||| 2^40) q12Shape5T290 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910336 ||| 2^40) 550863902208 q12Shape5T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T290OK,q12Shape5T291OK⟩

private def q12Shape5T292 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape5T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772724224 1108088320 q12Shape5T292=true := by decide

private def q12Shape5T288 : Tree 12 := .split 39 q12Shape5T289 q12Shape5T292
private theorem q12Shape5T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 1108088320 q12Shape5T288=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 (1108088320 ||| 2^39) q12Shape5T289 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910336 ||| 2^39) 1108088320 q12Shape5T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T289OK,q12Shape5T292OK⟩

private def q12Shape5T293 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090652160 34346496 q12Shape5T293=true := by decide

private def q12Shape5T287 : Tree 12 := .split 30 q12Shape5T288 q12Shape5T293
private theorem q12Shape5T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 34346496 q12Shape5T287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 (34346496 ||| 2^30) q12Shape5T288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910336 ||| 2^30) 34346496 q12Shape5T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T288OK,q12Shape5T293OK⟩

private def q12Shape5T294 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50464768 792064 q12Shape5T294=true := by decide

private def q12Shape5T286 : Tree 12 := .split 25 q12Shape5T287 q12Shape5T294
private theorem q12Shape5T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 792064 q12Shape5T286=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910336 (792064 ||| 2^25) q12Shape5T287 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910336 ||| 2^25) 792064 q12Shape5T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T287OK,q12Shape5T294OK⟩

private def q12Shape5T276 : Tree 12 := .split 24 q12Shape5T277 q12Shape5T286
private theorem q12Shape5T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 792064 q12Shape5T276=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 (792064 ||| 2^24) q12Shape5T277 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133120 ||| 2^24) 792064 q12Shape5T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T277OK,q12Shape5T286OK⟩

private def q12Shape5T295 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 657408 267776 q12Shape5T295=true := by decide

private def q12Shape5T275 : Tree 12 := .split 19 q12Shape5T276 q12Shape5T295
private theorem q12Shape5T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 267776 q12Shape5T275=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 (267776 ||| 2^19) q12Shape5T276 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133120 ||| 2^19) 267776 q12Shape5T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T276OK,q12Shape5T295OK⟩

private def q12Shape5T302 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape5T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 1650392045056 q12Shape5T302=true := by decide

private def q12Shape5T303 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape5T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512023040 550880417280 q12Shape5T303=true := by decide

private def q12Shape5T301 : Tree 12 := .split 40 q12Shape5T302 q12Shape5T303
private theorem q12Shape5T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 550880417280 q12Shape5T301=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 (550880417280 ||| 2^40) q12Shape5T302 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (395264 ||| 2^40) 550880417280 q12Shape5T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T302OK,q12Shape5T303OK⟩

private def q12Shape5T304 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape5T304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756209152 1124603392 q12Shape5T304=true := by decide

private def q12Shape5T300 : Tree 12 := .split 39 q12Shape5T301 q12Shape5T304
private theorem q12Shape5T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 1124603392 q12Shape5T300=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 (1124603392 ||| 2^39) q12Shape5T301 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (395264 ||| 2^39) 1124603392 q12Shape5T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T301OK,q12Shape5T304OK⟩

private def q12Shape5T305 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T305OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074137088 50861568 q12Shape5T305=true := by decide

private def q12Shape5T299 : Tree 12 := .split 30 q12Shape5T300 q12Shape5T305
private theorem q12Shape5T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 50861568 q12Shape5T299=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 (50861568 ||| 2^30) q12Shape5T300 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (395264 ||| 2^30) 50861568 q12Shape5T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T300OK,q12Shape5T305OK⟩

private def q12Shape5T306 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T306OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33949696 17307136 q12Shape5T306=true := by decide

private def q12Shape5T298 : Tree 12 := .split 25 q12Shape5T299 q12Shape5T306
private theorem q12Shape5T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 17307136 q12Shape5T298=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 (17307136 ||| 2^25) q12Shape5T299 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (395264 ||| 2^25) 17307136 q12Shape5T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T299OK,q12Shape5T306OK⟩

private def q12Shape5T307 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))))
private theorem q12Shape5T307OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17172480 529920 q12Shape5T307=true := by decide

private def q12Shape5T297 : Tree 12 := .split 24 q12Shape5T298 q12Shape5T307
private theorem q12Shape5T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 529920 q12Shape5T297=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 (529920 ||| 2^24) q12Shape5T298 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (395264 ||| 2^24) 529920 q12Shape5T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T298OK,q12Shape5T307OK⟩

private def q12Shape5T308 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T308OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 919552 5632 q12Shape5T308=true := by decide

private def q12Shape5T296 : Tree 12 := .split 19 q12Shape5T297 q12Shape5T308
private theorem q12Shape5T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 5632 q12Shape5T296=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395264 (5632 ||| 2^19) q12Shape5T297 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (395264 ||| 2^19) 5632 q12Shape5T308)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T297OK,q12Shape5T308OK⟩

private def q12Shape5T274 : Tree 12 := .split 18 q12Shape5T275 q12Shape5T296
private theorem q12Shape5T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 5632 q12Shape5T274=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 (5632 ||| 2^18) q12Shape5T275 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133120 ||| 2^18) 5632 q12Shape5T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T275OK,q12Shape5T296OK⟩

def q12Shape5P12 : Tree 12 := q12Shape5T274
theorem q12Shape5P12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133120 5632 q12Shape5P12=true := q12Shape5T274OK

end Graffiti384b.EffectiveSearch.Q12
