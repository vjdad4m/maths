import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T351 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T351OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 1650392172032 q12Shape5T351=true := by decide

private def q12Shape5T352 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T352OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511896064 550880544256 q12Shape5T352=true := by decide

private def q12Shape5T350 : Tree 12 := .split 40 q12Shape5T351 q12Shape5T352
private theorem q12Shape5T350OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 550880544256 q12Shape5T350=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 (550880544256 ||| 2^40) q12Shape5T351 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (268288 ||| 2^40) 550880544256 q12Shape5T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T351OK,q12Shape5T352OK⟩

private def q12Shape5T353 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T353OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756082176 1124730368 q12Shape5T353=true := by decide

private def q12Shape5T349 : Tree 12 := .split 39 q12Shape5T350 q12Shape5T353
private theorem q12Shape5T349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 1124730368 q12Shape5T349=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 (1124730368 ||| 2^39) q12Shape5T350 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (268288 ||| 2^39) 1124730368 q12Shape5T353)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T350OK,q12Shape5T353OK⟩

private def q12Shape5T354 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape5T354OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074010112 50988544 q12Shape5T354=true := by decide

private def q12Shape5T348 : Tree 12 := .split 30 q12Shape5T349 q12Shape5T354
private theorem q12Shape5T348OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 50988544 q12Shape5T348=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 (50988544 ||| 2^30) q12Shape5T349 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (268288 ||| 2^30) 50988544 q12Shape5T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T349OK,q12Shape5T354OK⟩

private def q12Shape5T355 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape5T355OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33822720 17434112 q12Shape5T355=true := by decide

private def q12Shape5T347 : Tree 12 := .split 25 q12Shape5T348 q12Shape5T355
private theorem q12Shape5T347OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 17434112 q12Shape5T347=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 (17434112 ||| 2^25) q12Shape5T348 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (268288 ||| 2^25) 17434112 q12Shape5T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T348OK,q12Shape5T355OK⟩

private def q12Shape5T356 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape5T356OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17045504 656896 q12Shape5T356=true := by decide

private def q12Shape5T346 : Tree 12 := .split 24 q12Shape5T347 q12Shape5T356
private theorem q12Shape5T346OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 656896 q12Shape5T346=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 (656896 ||| 2^24) q12Shape5T347 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (268288 ||| 2^24) 656896 q12Shape5T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T347OK,q12Shape5T356OK⟩

private def q12Shape5T362 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T362OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 1650391647744 q12Shape5T362=true := by decide

private def q12Shape5T363 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,8,9,11}))) (.tip (.cover {2,3,4,5,9,10,11})))
private theorem q12Shape5T363OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512420352 550880019968 q12Shape5T363=true := by decide

private def q12Shape5T361 : Tree 12 := .split 40 q12Shape5T362 q12Shape5T363
private theorem q12Shape5T361OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 550880019968 q12Shape5T361=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 (550880019968 ||| 2^40) q12Shape5T362 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (792576 ||| 2^40) 550880019968 q12Shape5T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T362OK,q12Shape5T363OK⟩

private def q12Shape5T364 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,10,11}))) (.tip (.cover {2,3,4,5,8,10,11}))) (.tip (.cover {2,3,4,5,9,10,11}))) (.tip (.cover {2,3,4,5,9,10,11})))
private theorem q12Shape5T364OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756606464 1124206080 q12Shape5T364=true := by decide

private def q12Shape5T360 : Tree 12 := .split 39 q12Shape5T361 q12Shape5T364
private theorem q12Shape5T360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 1124206080 q12Shape5T360=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 (1124206080 ||| 2^39) q12Shape5T361 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (792576 ||| 2^39) 1124206080 q12Shape5T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T361OK,q12Shape5T364OK⟩

private def q12Shape5T365 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T365OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34347008 1090651648 q12Shape5T365=true := by decide

private def q12Shape5T359 : Tree 12 := .split 25 q12Shape5T360 q12Shape5T365
private theorem q12Shape5T359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 1090651648 q12Shape5T359=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 (1090651648 ||| 2^25) q12Shape5T360 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (792576 ||| 2^25) 1090651648 q12Shape5T365)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T360OK,q12Shape5T365OK⟩

private def q12Shape5T366 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T366OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074534400 16909824 q12Shape5T366=true := by decide

private def q12Shape5T358 : Tree 12 := .split 30 q12Shape5T359 q12Shape5T366
private theorem q12Shape5T358OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 16909824 q12Shape5T358=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 (16909824 ||| 2^30) q12Shape5T359 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (792576 ||| 2^30) 16909824 q12Shape5T366)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T359OK,q12Shape5T366OK⟩

private def q12Shape5T367 : Tree 12 := (.split 25 (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {2,6,7,8,9,10,11})))
private theorem q12Shape5T367OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17569792 132608 q12Shape5T367=true := by decide

private def q12Shape5T357 : Tree 12 := .split 24 q12Shape5T358 q12Shape5T367
private theorem q12Shape5T357OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 132608 q12Shape5T357=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 792576 (132608 ||| 2^24) q12Shape5T358 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (792576 ||| 2^24) 132608 q12Shape5T367)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T358OK,q12Shape5T367OK⟩

private def q12Shape5T345 : Tree 12 := .split 19 q12Shape5T346 q12Shape5T357
private theorem q12Shape5T345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 132608 q12Shape5T345=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 (132608 ||| 2^19) q12Shape5T346 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (268288 ||| 2^19) 132608 q12Shape5T357)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T346OK,q12Shape5T357OK⟩

def q12Shape5P14 : Tree 12 := q12Shape5T345
theorem q12Shape5P14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 268288 132608 q12Shape5P14=true := q12Shape5T345OK

private def q12Shape5T369 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T369OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 137216 1536 q12Shape5T369=true := by decide

def q12Shape5P15 : Tree 12 := q12Shape5T369
theorem q12Shape5P15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 137216 1536 q12Shape5P15=true := q12Shape5T369OK

end Graffiti384b.EffectiveSearch.Q12
