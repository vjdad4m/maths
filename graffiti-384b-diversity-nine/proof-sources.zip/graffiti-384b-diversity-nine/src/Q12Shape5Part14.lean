import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T374 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape5T374OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 1074665984 q12Shape5T374=true := by decide

private def q12Shape5T379 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,6,8,9,10,11}))))))
private theorem q12Shape5T379OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 1649318697472 q12Shape5T379=true := by decide

private def q12Shape5T380 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,6,8,9,10,11}))))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T380OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585370624 549807069696 q12Shape5T380=true := by decide

private def q12Shape5T378 : Tree 12 := .split 40 q12Shape5T379 q12Shape5T380
private theorem q12Shape5T378OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 549807069696 q12Shape5T378=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 (549807069696 ||| 2^40) q12Shape5T379 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073742848 ||| 2^40) 549807069696 q12Shape5T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T379OK,q12Shape5T380OK⟩

private def q12Shape5T381 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,6,8,9,10,11}))))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T381OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550829556736 51255808 q12Shape5T381=true := by decide

private def q12Shape5T377 : Tree 12 := .split 39 q12Shape5T378 q12Shape5T381
private theorem q12Shape5T377OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 51255808 q12Shape5T377=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 (51255808 ||| 2^39) q12Shape5T378 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073742848 ||| 2^39) 51255808 q12Shape5T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T378OK,q12Shape5T381OK⟩

private def q12Shape5T384 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T384OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107297280 1649285143040 q12Shape5T384=true := by decide

private def q12Shape5T385 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T385OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100618925056 549773515264 q12Shape5T385=true := by decide

private def q12Shape5T383 : Tree 12 := .split 40 q12Shape5T384 q12Shape5T385
private theorem q12Shape5T383OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107297280 549773515264 q12Shape5T383=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107297280 (549773515264 ||| 2^40) q12Shape5T384 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1107297280 ||| 2^40) 549773515264 q12Shape5T385)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T384OK,q12Shape5T385OK⟩

private def q12Shape5T386 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T386OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550863111168 17701376 q12Shape5T386=true := by decide

private def q12Shape5T382 : Tree 12 := .split 39 q12Shape5T383 q12Shape5T386
private theorem q12Shape5T382OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107297280 17701376 q12Shape5T382=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107297280 (17701376 ||| 2^39) q12Shape5T383 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1107297280 ||| 2^39) 17701376 q12Shape5T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T383OK,q12Shape5T386OK⟩

private def q12Shape5T376 : Tree 12 := .split 25 q12Shape5T377 q12Shape5T382
private theorem q12Shape5T376OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 17701376 q12Shape5T376=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 (17701376 ||| 2^25) q12Shape5T377 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073742848 ||| 2^25) 17701376 q12Shape5T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T377OK,q12Shape5T382OK⟩

private def q12Shape5T390 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T390OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520064 1649301920256 q12Shape5T390=true := by decide

private def q12Shape5T391 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T391OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100602147840 549790292480 q12Shape5T391=true := by decide

private def q12Shape5T389 : Tree 12 := .split 40 q12Shape5T390 q12Shape5T391
private theorem q12Shape5T389OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520064 549790292480 q12Shape5T389=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520064 (549790292480 ||| 2^40) q12Shape5T390 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1090520064 ||| 2^40) 549790292480 q12Shape5T391)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T390OK,q12Shape5T391OK⟩

private def q12Shape5T392 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T392OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550846333952 34478592 q12Shape5T392=true := by decide

private def q12Shape5T388 : Tree 12 := .split 39 q12Shape5T389 q12Shape5T392
private theorem q12Shape5T388OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520064 34478592 q12Shape5T388=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520064 (34478592 ||| 2^39) q12Shape5T389 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1090520064 ||| 2^39) 34478592 q12Shape5T392)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T389OK,q12Shape5T392OK⟩

private def q12Shape5T393 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape5T393OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1124074496 924160 q12Shape5T393=true := by decide

private def q12Shape5T387 : Tree 12 := .split 25 q12Shape5T388 q12Shape5T393
private theorem q12Shape5T387OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520064 924160 q12Shape5T387=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520064 (924160 ||| 2^25) q12Shape5T388 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1090520064 ||| 2^25) 924160 q12Shape5T393)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T388OK,q12Shape5T393OK⟩

private def q12Shape5T375 : Tree 12 := .split 24 q12Shape5T376 q12Shape5T387
private theorem q12Shape5T375OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 924160 q12Shape5T375=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742848 (924160 ||| 2^24) q12Shape5T376 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073742848 ||| 2^24) 924160 q12Shape5T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T376OK,q12Shape5T387OK⟩

private def q12Shape5T373 : Tree 12 := .split 30 q12Shape5T374 q12Shape5T375
private theorem q12Shape5T373OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 924160 q12Shape5T373=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 (924160 ||| 2^30) q12Shape5T374 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1024 ||| 2^30) 924160 q12Shape5T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T374OK,q12Shape5T375OK⟩

def q12Shape5P16 : Tree 12 := q12Shape5T373
theorem q12Shape5P16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1024 924160 q12Shape5P16=true := q12Shape5T373OK

end Graffiti384b.EffectiveSearch.Q12
