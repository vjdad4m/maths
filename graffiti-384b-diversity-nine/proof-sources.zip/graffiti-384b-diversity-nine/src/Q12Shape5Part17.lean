import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T436 : Tree 12 := (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11}))))
private theorem q12Shape5T436OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 132096 793088 q12Shape5T436=true := by decide

private def q12Shape5T442 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T442OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 1650391783936 q12Shape5T442=true := by decide

private def q12Shape5T443 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T443OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512284160 550880156160 q12Shape5T443=true := by decide

private def q12Shape5T441 : Tree 12 := .split 40 q12Shape5T442 q12Shape5T443
private theorem q12Shape5T441OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 550880156160 q12Shape5T441=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 (550880156160 ||| 2^40) q12Shape5T442 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (656384 ||| 2^40) 550880156160 q12Shape5T443)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T442OK,q12Shape5T443OK⟩

private def q12Shape5T444 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T444OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756470272 1124342272 q12Shape5T444=true := by decide

private def q12Shape5T440 : Tree 12 := .split 39 q12Shape5T441 q12Shape5T444
private theorem q12Shape5T440OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 1124342272 q12Shape5T440=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 (1124342272 ||| 2^39) q12Shape5T441 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (656384 ||| 2^39) 1124342272 q12Shape5T444)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T441OK,q12Shape5T444OK⟩

private def q12Shape5T445 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T445OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074398208 50600448 q12Shape5T445=true := by decide

private def q12Shape5T439 : Tree 12 := .split 30 q12Shape5T440 q12Shape5T445
private theorem q12Shape5T439OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 50600448 q12Shape5T439=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 (50600448 ||| 2^30) q12Shape5T440 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (656384 ||| 2^30) 50600448 q12Shape5T445)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T440OK,q12Shape5T445OK⟩

private def q12Shape5T446 : Tree 12 := (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11}))))
private theorem q12Shape5T446OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34210816 17046016 q12Shape5T446=true := by decide

private def q12Shape5T438 : Tree 12 := .split 25 q12Shape5T439 q12Shape5T446
private theorem q12Shape5T438OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 17046016 q12Shape5T438=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 (17046016 ||| 2^25) q12Shape5T439 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (656384 ||| 2^25) 17046016 q12Shape5T446)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T439OK,q12Shape5T446OK⟩

private def q12Shape5T447 : Tree 12 := (.split 25 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape5T447OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17433600 268800 q12Shape5T447=true := by decide

private def q12Shape5T437 : Tree 12 := .split 24 q12Shape5T438 q12Shape5T447
private theorem q12Shape5T437OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 268800 q12Shape5T437=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 656384 (268800 ||| 2^24) q12Shape5T438 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (656384 ||| 2^24) 268800 q12Shape5T447)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T438OK,q12Shape5T447OK⟩

private def q12Shape5T435 : Tree 12 := .split 19 q12Shape5T436 q12Shape5T437
private theorem q12Shape5T435OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 132096 268800 q12Shape5T435=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 132096 (268800 ||| 2^19) q12Shape5T436 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (132096 ||| 2^19) 268800 q12Shape5T437)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T436OK,q12Shape5T437OK⟩

private def q12Shape5T454 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape5T454OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 1650392046080 q12Shape5T454=true := by decide

private def q12Shape5T455 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape5T455OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512022016 550880418304 q12Shape5T455=true := by decide

private def q12Shape5T453 : Tree 12 := .split 40 q12Shape5T454 q12Shape5T455
private theorem q12Shape5T453OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 550880418304 q12Shape5T453=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 (550880418304 ||| 2^40) q12Shape5T454 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (394240 ||| 2^40) 550880418304 q12Shape5T455)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T454OK,q12Shape5T455OK⟩

private def q12Shape5T456 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape5T456OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756208128 1124604416 q12Shape5T456=true := by decide

private def q12Shape5T452 : Tree 12 := .split 39 q12Shape5T453 q12Shape5T456
private theorem q12Shape5T452OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 1124604416 q12Shape5T452=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 (1124604416 ||| 2^39) q12Shape5T453 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (394240 ||| 2^39) 1124604416 q12Shape5T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T453OK,q12Shape5T456OK⟩

private def q12Shape5T457 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T457OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074136064 50862592 q12Shape5T457=true := by decide

private def q12Shape5T451 : Tree 12 := .split 30 q12Shape5T452 q12Shape5T457
private theorem q12Shape5T451OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 50862592 q12Shape5T451=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 (50862592 ||| 2^30) q12Shape5T452 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (394240 ||| 2^30) 50862592 q12Shape5T457)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T452OK,q12Shape5T457OK⟩

private def q12Shape5T458 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T458OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33948672 17308160 q12Shape5T458=true := by decide

private def q12Shape5T450 : Tree 12 := .split 25 q12Shape5T451 q12Shape5T458
private theorem q12Shape5T450OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 17308160 q12Shape5T450=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 (17308160 ||| 2^25) q12Shape5T451 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (394240 ||| 2^25) 17308160 q12Shape5T458)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T451OK,q12Shape5T458OK⟩

private def q12Shape5T459 : Tree 12 := (.split 25 (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape5T459OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17171456 530944 q12Shape5T459=true := by decide

private def q12Shape5T449 : Tree 12 := .split 24 q12Shape5T450 q12Shape5T459
private theorem q12Shape5T449OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 530944 q12Shape5T449=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 (530944 ||| 2^24) q12Shape5T450 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (394240 ||| 2^24) 530944 q12Shape5T459)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T450OK,q12Shape5T459OK⟩

private def q12Shape5T460 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T460OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 918528 6656 q12Shape5T460=true := by decide

private def q12Shape5T448 : Tree 12 := .split 19 q12Shape5T449 q12Shape5T460
private theorem q12Shape5T448OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 6656 q12Shape5T448=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 394240 (6656 ||| 2^19) q12Shape5T449 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (394240 ||| 2^19) 6656 q12Shape5T460)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T449OK,q12Shape5T460OK⟩

private def q12Shape5T434 : Tree 12 := .split 18 q12Shape5T435 q12Shape5T448
private theorem q12Shape5T434OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 132096 6656 q12Shape5T434=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 132096 (6656 ||| 2^18) q12Shape5T435 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (132096 ||| 2^18) 6656 q12Shape5T448)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T435OK,q12Shape5T448OK⟩

def q12Shape5P19 : Tree 12 := q12Shape5T434
theorem q12Shape5P19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 132096 6656 q12Shape5P19=true := q12Shape5T434OK

end Graffiti384b.EffectiveSearch.Q12
