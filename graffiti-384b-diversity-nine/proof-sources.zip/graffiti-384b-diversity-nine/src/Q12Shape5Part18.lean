import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T467 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape5T467OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 1124993536 q12Shape5T467=true := by decide

private def q12Shape5T470 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T470OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746944 1649318693376 q12Shape5T470=true := by decide

private def q12Shape5T471 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T471OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585374720 549807065600 q12Shape5T471=true := by decide

private def q12Shape5T469 : Tree 12 := .split 40 q12Shape5T470 q12Shape5T471
private theorem q12Shape5T469OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746944 549807065600 q12Shape5T469=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746944 (549807065600 ||| 2^40) q12Shape5T470 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073746944 ||| 2^40) 549807065600 q12Shape5T471)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T470OK,q12Shape5T471OK⟩

private def q12Shape5T472 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T472OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550829560832 51251712 q12Shape5T472=true := by decide

private def q12Shape5T468 : Tree 12 := .split 39 q12Shape5T469 q12Shape5T472
private theorem q12Shape5T468OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746944 51251712 q12Shape5T468=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746944 (51251712 ||| 2^39) q12Shape5T469 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073746944 ||| 2^39) 51251712 q12Shape5T472)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T469OK,q12Shape5T472OK⟩

private def q12Shape5T466 : Tree 12 := .split 30 q12Shape5T467 q12Shape5T468
private theorem q12Shape5T466OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 51251712 q12Shape5T466=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 (51251712 ||| 2^30) q12Shape5T467 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (5120 ||| 2^30) 51251712 q12Shape5T468)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T467OK,q12Shape5T468OK⟩

private def q12Shape5T473 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T473OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559552 17697280 q12Shape5T473=true := by decide

private def q12Shape5T465 : Tree 12 := .split 25 q12Shape5T466 q12Shape5T473
private theorem q12Shape5T465OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 17697280 q12Shape5T465=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 (17697280 ||| 2^25) q12Shape5T466 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (5120 ||| 2^25) 17697280 q12Shape5T473)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T466OK,q12Shape5T473OK⟩

private def q12Shape5T478 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T478OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 1650375657984 q12Shape5T478=true := by decide

private def q12Shape5T479 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T479OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528410112 550864030208 q12Shape5T479=true := by decide

private def q12Shape5T477 : Tree 12 := .split 40 q12Shape5T478 q12Shape5T479
private theorem q12Shape5T477OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 550864030208 q12Shape5T477=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 (550864030208 ||| 2^40) q12Shape5T478 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16782336 ||| 2^40) 550864030208 q12Shape5T479)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T478OK,q12Shape5T479OK⟩

private def q12Shape5T480 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T480OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772596224 1108216320 q12Shape5T480=true := by decide

private def q12Shape5T476 : Tree 12 := .split 39 q12Shape5T477 q12Shape5T480
private theorem q12Shape5T476OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 1108216320 q12Shape5T476=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 (1108216320 ||| 2^39) q12Shape5T477 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16782336 ||| 2^39) 1108216320 q12Shape5T480)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T477OK,q12Shape5T480OK⟩

private def q12Shape5T483 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,6,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,6,8,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T483OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090524160 1649301916160 q12Shape5T483=true := by decide

private def q12Shape5T484 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,6,8,9,11}))) (.tip (.cover {2,3,4,6,9,10,11})))
private theorem q12Shape5T484OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100602151936 549790288384 q12Shape5T484=true := by decide

private def q12Shape5T482 : Tree 12 := .split 40 q12Shape5T483 q12Shape5T484
private theorem q12Shape5T482OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090524160 549790288384 q12Shape5T482=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090524160 (549790288384 ||| 2^40) q12Shape5T483 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1090524160 ||| 2^40) 549790288384 q12Shape5T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T483OK,q12Shape5T484OK⟩

private def q12Shape5T485 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,6,8,10,11}))) (.tip (.cover {2,3,4,6,8,10,11}))) (.tip (.cover {2,3,4,6,9,10,11}))) (.tip (.cover {2,3,4,6,9,10,11})))
private theorem q12Shape5T485OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550846338048 34474496 q12Shape5T485=true := by decide

private def q12Shape5T481 : Tree 12 := .split 39 q12Shape5T482 q12Shape5T485
private theorem q12Shape5T481OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090524160 34474496 q12Shape5T481=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090524160 (34474496 ||| 2^39) q12Shape5T482 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1090524160 ||| 2^39) 34474496 q12Shape5T485)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T482OK,q12Shape5T485OK⟩

private def q12Shape5T475 : Tree 12 := .split 30 q12Shape5T476 q12Shape5T481
private theorem q12Shape5T475OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 34474496 q12Shape5T475=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 (34474496 ||| 2^30) q12Shape5T476 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16782336 ||| 2^30) 34474496 q12Shape5T481)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T476OK,q12Shape5T481OK⟩

private def q12Shape5T486 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape5T486OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50336768 920064 q12Shape5T486=true := by decide

private def q12Shape5T474 : Tree 12 := .split 25 q12Shape5T475 q12Shape5T486
private theorem q12Shape5T474OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 920064 q12Shape5T474=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16782336 (920064 ||| 2^25) q12Shape5T475 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16782336 ||| 2^25) 920064 q12Shape5T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T475OK,q12Shape5T486OK⟩

private def q12Shape5T464 : Tree 12 := .split 24 q12Shape5T465 q12Shape5T474
private theorem q12Shape5T464OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 920064 q12Shape5T464=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 (920064 ||| 2^24) q12Shape5T465 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (5120 ||| 2^24) 920064 q12Shape5T474)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T465OK,q12Shape5T474OK⟩

private def q12Shape5T492 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T492OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 1650391910912 q12Shape5T492=true := by decide

private def q12Shape5T493 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T493OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512157184 550880283136 q12Shape5T493=true := by decide

private def q12Shape5T491 : Tree 12 := .split 40 q12Shape5T492 q12Shape5T493
private theorem q12Shape5T491OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 550880283136 q12Shape5T491=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 (550880283136 ||| 2^40) q12Shape5T492 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (529408 ||| 2^40) 550880283136 q12Shape5T493)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T492OK,q12Shape5T493OK⟩

private def q12Shape5T494 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T494OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756343296 1124469248 q12Shape5T494=true := by decide

private def q12Shape5T490 : Tree 12 := .split 39 q12Shape5T491 q12Shape5T494
private theorem q12Shape5T490OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 1124469248 q12Shape5T490=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 (1124469248 ||| 2^39) q12Shape5T491 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (529408 ||| 2^39) 1124469248 q12Shape5T494)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T491OK,q12Shape5T494OK⟩

private def q12Shape5T495 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T495OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074271232 50727424 q12Shape5T495=true := by decide

private def q12Shape5T489 : Tree 12 := .split 30 q12Shape5T490 q12Shape5T495
private theorem q12Shape5T489OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 50727424 q12Shape5T489=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 (50727424 ||| 2^30) q12Shape5T490 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (529408 ||| 2^30) 50727424 q12Shape5T495)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T490OK,q12Shape5T495OK⟩

private def q12Shape5T496 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T496OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34083840 17172992 q12Shape5T496=true := by decide

private def q12Shape5T488 : Tree 12 := .split 25 q12Shape5T489 q12Shape5T496
private theorem q12Shape5T488OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 17172992 q12Shape5T488=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 (17172992 ||| 2^25) q12Shape5T489 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (529408 ||| 2^25) 17172992 q12Shape5T496)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T489OK,q12Shape5T496OK⟩

private def q12Shape5T497 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T497OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17306624 395776 q12Shape5T497=true := by decide

private def q12Shape5T487 : Tree 12 := .split 24 q12Shape5T488 q12Shape5T497
private theorem q12Shape5T487OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 395776 q12Shape5T487=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 529408 (395776 ||| 2^24) q12Shape5T488 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (529408 ||| 2^24) 395776 q12Shape5T497)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T488OK,q12Shape5T497OK⟩

private def q12Shape5T463 : Tree 12 := .split 19 q12Shape5T464 q12Shape5T487
private theorem q12Shape5T463OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 395776 q12Shape5T463=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 (395776 ||| 2^19) q12Shape5T464 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (5120 ||| 2^19) 395776 q12Shape5T487)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T464OK,q12Shape5T487OK⟩

private def q12Shape5T498 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T498OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 267264 133632 q12Shape5T498=true := by decide

private def q12Shape5T462 : Tree 12 := .split 18 q12Shape5T463 q12Shape5T498
private theorem q12Shape5T462OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 133632 q12Shape5T462=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 (133632 ||| 2^18) q12Shape5T463 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (5120 ||| 2^18) 133632 q12Shape5T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T463OK,q12Shape5T498OK⟩

def q12Shape5P20 : Tree 12 := q12Shape5T462
theorem q12Shape5P20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 5120 133632 q12Shape5P20=true := q12Shape5T462OK

end Graffiti384b.EffectiveSearch.Q12
