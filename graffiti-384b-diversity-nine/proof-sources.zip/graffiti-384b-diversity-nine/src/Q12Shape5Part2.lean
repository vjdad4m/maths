import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T46 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape5T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 786432 50470400 q12Shape5T46=true := by decide

private def q12Shape5T50 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34340864 1650358099456 q12Shape5T50=true := by decide

private def q12Shape5T51 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545968640 550846471680 q12Shape5T51=true := by decide

private def q12Shape5T49 : Tree 12 := .split 40 q12Shape5T50 q12Shape5T51
private theorem q12Shape5T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34340864 550846471680 q12Shape5T49=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34340864 (550846471680 ||| 2^40) q12Shape5T50 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34340864 ||| 2^40) 550846471680 q12Shape5T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T50OK,q12Shape5T51OK⟩

private def q12Shape5T52 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549790154752 1090657792 q12Shape5T52=true := by decide

private def q12Shape5T48 : Tree 12 := .split 39 q12Shape5T49 q12Shape5T52
private theorem q12Shape5T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34340864 1090657792 q12Shape5T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34340864 (1090657792 ||| 2^39) q12Shape5T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34340864 ||| 2^39) 1090657792 q12Shape5T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T49OK,q12Shape5T52OK⟩

private def q12Shape5T53 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1108082688 16915968 q12Shape5T53=true := by decide

private def q12Shape5T47 : Tree 12 := .split 30 q12Shape5T48 q12Shape5T53
private theorem q12Shape5T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34340864 16915968 q12Shape5T47=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34340864 (16915968 ||| 2^30) q12Shape5T48 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34340864 ||| 2^30) 16915968 q12Shape5T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T48OK,q12Shape5T53OK⟩

private def q12Shape5T45 : Tree 12 := .split 25 q12Shape5T46 q12Shape5T47
private theorem q12Shape5T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 786432 16915968 q12Shape5T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 786432 (16915968 ||| 2^25) q12Shape5T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (786432 ||| 2^25) 16915968 q12Shape5T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T46OK,q12Shape5T47OK⟩

private def q12Shape5T58 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 1650374876672 q12Shape5T58=true := by decide

private def q12Shape5T59 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099529191424 550863248896 q12Shape5T59=true := by decide

private def q12Shape5T57 : Tree 12 := .split 40 q12Shape5T58 q12Shape5T59
private theorem q12Shape5T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 550863248896 q12Shape5T57=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 (550863248896 ||| 2^40) q12Shape5T58 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17563648 ||| 2^40) 550863248896 q12Shape5T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T58OK,q12Shape5T59OK⟩

private def q12Shape5T60 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549773377536 1107435008 q12Shape5T60=true := by decide

private def q12Shape5T56 : Tree 12 := .split 39 q12Shape5T57 q12Shape5T60
private theorem q12Shape5T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 1107435008 q12Shape5T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 (1107435008 ||| 2^39) q12Shape5T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17563648 ||| 2^39) 1107435008 q12Shape5T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T57OK,q12Shape5T60OK⟩

private def q12Shape5T63 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 51118080 1650341322240 q12Shape5T63=true := by decide

private def q12Shape5T64 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,8,9,11}))) (.tip (.cover {2,3,4,5,9,10,11})))
private theorem q12Shape5T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099562745856 550829694464 q12Shape5T64=true := by decide

private def q12Shape5T62 : Tree 12 := .split 40 q12Shape5T63 q12Shape5T64
private theorem q12Shape5T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 51118080 550829694464 q12Shape5T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 51118080 (550829694464 ||| 2^40) q12Shape5T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (51118080 ||| 2^40) 550829694464 q12Shape5T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T63OK,q12Shape5T64OK⟩

private def q12Shape5T65 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,10,11}))) (.tip (.cover {2,3,4,5,8,10,11}))) (.tip (.cover {2,3,4,5,9,10,11}))) (.tip (.cover {2,3,4,5,9,10,11})))
private theorem q12Shape5T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549806931968 1073880576 q12Shape5T65=true := by decide

private def q12Shape5T61 : Tree 12 := .split 39 q12Shape5T62 q12Shape5T65
private theorem q12Shape5T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 51118080 1073880576 q12Shape5T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 51118080 (1073880576 ||| 2^39) q12Shape5T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (51118080 ||| 2^39) 1073880576 q12Shape5T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T62OK,q12Shape5T65OK⟩

private def q12Shape5T55 : Tree 12 := .split 25 q12Shape5T56 q12Shape5T61
private theorem q12Shape5T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 1073880576 q12Shape5T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 (1073880576 ||| 2^25) q12Shape5T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17563648 ||| 2^25) 1073880576 q12Shape5T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T56OK,q12Shape5T61OK⟩

private def q12Shape5T66 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape5T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091305472 138752 q12Shape5T66=true := by decide

private def q12Shape5T54 : Tree 12 := .split 30 q12Shape5T55 q12Shape5T66
private theorem q12Shape5T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 138752 q12Shape5T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17563648 (138752 ||| 2^30) q12Shape5T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17563648 ||| 2^30) 138752 q12Shape5T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T55OK,q12Shape5T66OK⟩

private def q12Shape5T44 : Tree 12 := .split 24 q12Shape5T45 q12Shape5T54
private theorem q12Shape5T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 786432 138752 q12Shape5T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 786432 (138752 ||| 2^24) q12Shape5T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (786432 ||| 2^24) 138752 q12Shape5T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T45OK,q12Shape5T54OK⟩

def q12Shape5P2 : Tree 12 := q12Shape5T44
theorem q12Shape5P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 786432 138752 q12Shape5P2=true := q12Shape5T44OK

end Graffiti384b.EffectiveSearch.Q12
