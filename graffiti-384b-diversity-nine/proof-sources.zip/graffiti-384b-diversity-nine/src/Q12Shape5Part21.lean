import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T570 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape5T570OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 1650392306176 q12Shape5T570=true := by decide

private def q12Shape5T571 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape5T571OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511761920 550880678400 q12Shape5T571=true := by decide

private def q12Shape5T569 : Tree 12 := .split 40 q12Shape5T570 q12Shape5T571
private theorem q12Shape5T569OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 550880678400 q12Shape5T569=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 (550880678400 ||| 2^40) q12Shape5T570 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (134144 ||| 2^40) 550880678400 q12Shape5T571)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T570OK,q12Shape5T571OK⟩

private def q12Shape5T572 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape5T572OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549755948032 1124864512 q12Shape5T572=true := by decide

private def q12Shape5T568 : Tree 12 := .split 39 q12Shape5T569 q12Shape5T572
private theorem q12Shape5T568OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 1124864512 q12Shape5T568=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 (1124864512 ||| 2^39) q12Shape5T569 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (134144 ||| 2^39) 1124864512 q12Shape5T572)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T569OK,q12Shape5T572OK⟩

private def q12Shape5T573 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T573OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073875968 51122688 q12Shape5T573=true := by decide

private def q12Shape5T567 : Tree 12 := .split 30 q12Shape5T568 q12Shape5T573
private theorem q12Shape5T567OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 51122688 q12Shape5T567=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 (51122688 ||| 2^30) q12Shape5T568 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (134144 ||| 2^30) 51122688 q12Shape5T573)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T568OK,q12Shape5T573OK⟩

private def q12Shape5T574 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T574OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33688576 17568256 q12Shape5T574=true := by decide

private def q12Shape5T566 : Tree 12 := .split 25 q12Shape5T567 q12Shape5T574
private theorem q12Shape5T566OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 17568256 q12Shape5T566=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 (17568256 ||| 2^25) q12Shape5T567 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (134144 ||| 2^25) 17568256 q12Shape5T574)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T567OK,q12Shape5T574OK⟩

private def q12Shape5T575 : Tree 12 := (.split 25 (.split 30 (.tip (.cover {0,2,5,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape5T575OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16911360 791040 q12Shape5T575=true := by decide

private def q12Shape5T565 : Tree 12 := .split 24 q12Shape5T566 q12Shape5T575
private theorem q12Shape5T565OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 791040 q12Shape5T565=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 (791040 ||| 2^24) q12Shape5T566 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (134144 ||| 2^24) 791040 q12Shape5T575)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T566OK,q12Shape5T575OK⟩

private def q12Shape5T576 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T576OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 658432 266752 q12Shape5T576=true := by decide

private def q12Shape5T564 : Tree 12 := .split 19 q12Shape5T565 q12Shape5T576
private theorem q12Shape5T564OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 266752 q12Shape5T564=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 (266752 ||| 2^19) q12Shape5T565 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (134144 ||| 2^19) 266752 q12Shape5T576)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T565OK,q12Shape5T576OK⟩

private def q12Shape5T583 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,9,10}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape5T583OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 1650392044032 q12Shape5T583=true := by decide

private def q12Shape5T584 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {2,3,4,7,8,9,11}))) (.tip (.cover {2,3,4,7,9,10,11})))
private theorem q12Shape5T584OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512024064 550880416256 q12Shape5T584=true := by decide

private def q12Shape5T582 : Tree 12 := .split 40 q12Shape5T583 q12Shape5T584
private theorem q12Shape5T582OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 550880416256 q12Shape5T582=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 (550880416256 ||| 2^40) q12Shape5T583 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (396288 ||| 2^40) 550880416256 q12Shape5T584)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T583OK,q12Shape5T584OK⟩

private def q12Shape5T585 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,10,11}))) (.tip (.cover {2,3,4,7,8,10,11}))) (.tip (.cover {2,3,4,7,9,10,11}))) (.tip (.cover {2,3,4,7,9,10,11})))
private theorem q12Shape5T585OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756210176 1124602368 q12Shape5T585=true := by decide

private def q12Shape5T581 : Tree 12 := .split 39 q12Shape5T582 q12Shape5T585
private theorem q12Shape5T581OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 1124602368 q12Shape5T581=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 (1124602368 ||| 2^39) q12Shape5T582 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (396288 ||| 2^39) 1124602368 q12Shape5T585)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T582OK,q12Shape5T585OK⟩

private def q12Shape5T586 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T586OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074138112 50860544 q12Shape5T586=true := by decide

private def q12Shape5T580 : Tree 12 := .split 30 q12Shape5T581 q12Shape5T586
private theorem q12Shape5T580OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 50860544 q12Shape5T580=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 (50860544 ||| 2^30) q12Shape5T581 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (396288 ||| 2^30) 50860544 q12Shape5T586)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T581OK,q12Shape5T586OK⟩

private def q12Shape5T587 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))) (.tip (.cover {2,5,6,8,9,10,11})))
private theorem q12Shape5T587OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33950720 17306112 q12Shape5T587=true := by decide

private def q12Shape5T579 : Tree 12 := .split 25 q12Shape5T580 q12Shape5T587
private theorem q12Shape5T579OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 17306112 q12Shape5T579=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 (17306112 ||| 2^25) q12Shape5T580 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (396288 ||| 2^25) 17306112 q12Shape5T587)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T580OK,q12Shape5T587OK⟩

private def q12Shape5T588 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.tip (.cover {0,1,5,8,9,10,11})))
private theorem q12Shape5T588OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17173504 528896 q12Shape5T588=true := by decide

private def q12Shape5T578 : Tree 12 := .split 24 q12Shape5T579 q12Shape5T588
private theorem q12Shape5T578OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 528896 q12Shape5T578=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 (528896 ||| 2^24) q12Shape5T579 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (396288 ||| 2^24) 528896 q12Shape5T588)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T579OK,q12Shape5T588OK⟩

private def q12Shape5T589 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T589OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 920576 4608 q12Shape5T589=true := by decide

private def q12Shape5T577 : Tree 12 := .split 19 q12Shape5T578 q12Shape5T589
private theorem q12Shape5T577OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 4608 q12Shape5T577=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 396288 (4608 ||| 2^19) q12Shape5T578 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (396288 ||| 2^19) 4608 q12Shape5T589)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T578OK,q12Shape5T589OK⟩

private def q12Shape5T563 : Tree 12 := .split 18 q12Shape5T564 q12Shape5T577
private theorem q12Shape5T563OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 4608 q12Shape5T563=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 (4608 ||| 2^18) q12Shape5T564 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (134144 ||| 2^18) 4608 q12Shape5T577)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T564OK,q12Shape5T577OK⟩

def q12Shape5P23 : Tree 12 := q12Shape5T563
theorem q12Shape5P23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 134144 4608 q12Shape5P23=true := q12Shape5T563OK

private def q12Shape5T591 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T591OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 7168 512 q12Shape5T591=true := by decide

def q12Shape5P24 : Tree 12 := q12Shape5T591
theorem q12Shape5P24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 7168 512 q12Shape5P24=true := q12Shape5T591OK

end Graffiti384b.EffectiveSearch.Q12
