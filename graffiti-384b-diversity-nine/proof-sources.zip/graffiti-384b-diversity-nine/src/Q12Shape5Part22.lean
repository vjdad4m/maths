import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T598 : Tree 12 := (.tip (.small 0))
private theorem q12Shape5T598OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 1124998144 q12Shape5T598=true := by decide

private def q12Shape5T601 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,8,9,10,11})))))
private theorem q12Shape5T601OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742336 1649318697984 q12Shape5T601=true := by decide

private def q12Shape5T602 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,8,9,10,11})))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T602OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585370112 549807070208 q12Shape5T602=true := by decide

private def q12Shape5T600 : Tree 12 := .split 40 q12Shape5T601 q12Shape5T602
private theorem q12Shape5T600OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742336 549807070208 q12Shape5T600=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742336 (549807070208 ||| 2^40) q12Shape5T601 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073742336 ||| 2^40) 549807070208 q12Shape5T602)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T601OK,q12Shape5T602OK⟩

private def q12Shape5T603 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,8,9,10,11})))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T603OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550829556224 51256320 q12Shape5T603=true := by decide

private def q12Shape5T599 : Tree 12 := .split 39 q12Shape5T600 q12Shape5T603
private theorem q12Shape5T599OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742336 51256320 q12Shape5T599=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073742336 (51256320 ||| 2^39) q12Shape5T600 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073742336 ||| 2^39) 51256320 q12Shape5T603)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T600OK,q12Shape5T603OK⟩

private def q12Shape5T597 : Tree 12 := .split 30 q12Shape5T598 q12Shape5T599
private theorem q12Shape5T597OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 51256320 q12Shape5T597=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (51256320 ||| 2^30) q12Shape5T598 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^30) 51256320 q12Shape5T599)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T598OK,q12Shape5T599OK⟩

private def q12Shape5T607 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))
private theorem q12Shape5T607OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33554944 1650358885376 q12Shape5T607=true := by decide

private def q12Shape5T608 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T608OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545182720 550847257600 q12Shape5T608=true := by decide

private def q12Shape5T606 : Tree 12 := .split 40 q12Shape5T607 q12Shape5T608
private theorem q12Shape5T606OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33554944 550847257600 q12Shape5T606=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33554944 (550847257600 ||| 2^40) q12Shape5T607 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33554944 ||| 2^40) 550847257600 q12Shape5T608)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T607OK,q12Shape5T608OK⟩

private def q12Shape5T609 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T609OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789368832 1091443712 q12Shape5T609=true := by decide

private def q12Shape5T605 : Tree 12 := .split 39 q12Shape5T606 q12Shape5T609
private theorem q12Shape5T605OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33554944 1091443712 q12Shape5T605=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33554944 (1091443712 ||| 2^39) q12Shape5T606 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33554944 ||| 2^39) 1091443712 q12Shape5T609)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T606OK,q12Shape5T609OK⟩

private def q12Shape5T610 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T610OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107296768 17701888 q12Shape5T610=true := by decide

private def q12Shape5T604 : Tree 12 := .split 30 q12Shape5T605 q12Shape5T610
private theorem q12Shape5T604OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33554944 17701888 q12Shape5T604=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33554944 (17701888 ||| 2^30) q12Shape5T605 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33554944 ||| 2^30) 17701888 q12Shape5T610)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T605OK,q12Shape5T610OK⟩

private def q12Shape5T596 : Tree 12 := .split 25 q12Shape5T597 q12Shape5T604
private theorem q12Shape5T596OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 17701888 q12Shape5T596=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (17701888 ||| 2^25) q12Shape5T597 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^25) 17701888 q12Shape5T604)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T597OK,q12Shape5T604OK⟩

private def q12Shape5T615 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))
private theorem q12Shape5T615OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 1650375662592 q12Shape5T615=true := by decide

private def q12Shape5T616 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape5T616OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528405504 550864034816 q12Shape5T616=true := by decide

private def q12Shape5T614 : Tree 12 := .split 40 q12Shape5T615 q12Shape5T616
private theorem q12Shape5T614OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 550864034816 q12Shape5T614=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 (550864034816 ||| 2^40) q12Shape5T615 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16777728 ||| 2^40) 550864034816 q12Shape5T616)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T615OK,q12Shape5T616OK⟩

private def q12Shape5T617 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape5T617OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772591616 1108220928 q12Shape5T617=true := by decide

private def q12Shape5T613 : Tree 12 := .split 39 q12Shape5T614 q12Shape5T617
private theorem q12Shape5T613OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 1108220928 q12Shape5T613=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 (1108220928 ||| 2^39) q12Shape5T614 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16777728 ||| 2^39) 1108220928 q12Shape5T617)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T614OK,q12Shape5T617OK⟩

private def q12Shape5T618 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T618OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090519552 34479104 q12Shape5T618=true := by decide

private def q12Shape5T612 : Tree 12 := .split 30 q12Shape5T613 q12Shape5T618
private theorem q12Shape5T612OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 34479104 q12Shape5T612=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 (34479104 ||| 2^30) q12Shape5T613 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16777728 ||| 2^30) 34479104 q12Shape5T618)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T613OK,q12Shape5T618OK⟩

private def q12Shape5T619 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T619OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50332160 924672 q12Shape5T619=true := by decide

private def q12Shape5T611 : Tree 12 := .split 25 q12Shape5T612 q12Shape5T619
private theorem q12Shape5T611OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 924672 q12Shape5T611=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16777728 (924672 ||| 2^25) q12Shape5T612 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16777728 ||| 2^25) 924672 q12Shape5T619)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T612OK,q12Shape5T619OK⟩

private def q12Shape5T595 : Tree 12 := .split 24 q12Shape5T596 q12Shape5T611
private theorem q12Shape5T595OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 924672 q12Shape5T595=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 (924672 ||| 2^24) q12Shape5T596 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (512 ||| 2^24) 924672 q12Shape5T611)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T596OK,q12Shape5T611OK⟩

def q12Shape5P25 : Tree 12 := q12Shape5T595
theorem q12Shape5P25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 512 924672 q12Shape5P25=true := q12Shape5T595OK

end Graffiti384b.EffectiveSearch.Q12
