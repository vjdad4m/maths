import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T623 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape5T623OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 1124473856 q12Shape5T623=true := by decide

private def q12Shape5T626 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape5T626OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074266624 1649318173696 q12Shape5T626=true := by decide

private def q12Shape5T627 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T627OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585894400 549806545920 q12Shape5T627=true := by decide

private def q12Shape5T625 : Tree 12 := .split 40 q12Shape5T626 q12Shape5T627
private theorem q12Shape5T625OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074266624 549806545920 q12Shape5T625=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074266624 (549806545920 ||| 2^40) q12Shape5T626 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074266624 ||| 2^40) 549806545920 q12Shape5T627)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T626OK,q12Shape5T627OK⟩

private def q12Shape5T628 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T628OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550830080512 50732032 q12Shape5T628=true := by decide

private def q12Shape5T624 : Tree 12 := .split 39 q12Shape5T625 q12Shape5T628
private theorem q12Shape5T624OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074266624 50732032 q12Shape5T624=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074266624 (50732032 ||| 2^39) q12Shape5T625 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074266624 ||| 2^39) 50732032 q12Shape5T628)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T625OK,q12Shape5T628OK⟩

private def q12Shape5T622 : Tree 12 := .split 30 q12Shape5T623 q12Shape5T624
private theorem q12Shape5T622OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 50732032 q12Shape5T622=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 (50732032 ||| 2^30) q12Shape5T623 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (524800 ||| 2^30) 50732032 q12Shape5T624)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T623OK,q12Shape5T624OK⟩

private def q12Shape5T632 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape5T632OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34079232 1650358361088 q12Shape5T632=true := by decide

private def q12Shape5T633 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T633OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545707008 550846733312 q12Shape5T633=true := by decide

private def q12Shape5T631 : Tree 12 := .split 40 q12Shape5T632 q12Shape5T633
private theorem q12Shape5T631OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34079232 550846733312 q12Shape5T631=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34079232 (550846733312 ||| 2^40) q12Shape5T632 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34079232 ||| 2^40) 550846733312 q12Shape5T633)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T632OK,q12Shape5T633OK⟩

private def q12Shape5T634 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T634OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789893120 1090919424 q12Shape5T634=true := by decide

private def q12Shape5T630 : Tree 12 := .split 39 q12Shape5T631 q12Shape5T634
private theorem q12Shape5T630OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34079232 1090919424 q12Shape5T630=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34079232 (1090919424 ||| 2^39) q12Shape5T631 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34079232 ||| 2^39) 1090919424 q12Shape5T634)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T631OK,q12Shape5T634OK⟩

private def q12Shape5T635 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T635OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107821056 17177600 q12Shape5T635=true := by decide

private def q12Shape5T629 : Tree 12 := .split 30 q12Shape5T630 q12Shape5T635
private theorem q12Shape5T629OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34079232 17177600 q12Shape5T629=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34079232 (17177600 ||| 2^30) q12Shape5T630 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34079232 ||| 2^30) 17177600 q12Shape5T635)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T630OK,q12Shape5T635OK⟩

private def q12Shape5T621 : Tree 12 := .split 25 q12Shape5T622 q12Shape5T629
private theorem q12Shape5T621OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 17177600 q12Shape5T621=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 (17177600 ||| 2^25) q12Shape5T622 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (524800 ||| 2^25) 17177600 q12Shape5T629)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T622OK,q12Shape5T629OK⟩

private def q12Shape5T636 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T636OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17302016 400384 q12Shape5T636=true := by decide

private def q12Shape5T620 : Tree 12 := .split 24 q12Shape5T621 q12Shape5T636
private theorem q12Shape5T620OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 400384 q12Shape5T620=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 (400384 ||| 2^24) q12Shape5T621 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (524800 ||| 2^24) 400384 q12Shape5T636)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T621OK,q12Shape5T636OK⟩

def q12Shape5P26 : Tree 12 := q12Shape5T620
theorem q12Shape5P26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 524800 400384 q12Shape5P26=true := q12Shape5T620OK

private def q12Shape5T642 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape5T642OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 1124736000 q12Shape5T642=true := by decide

private def q12Shape5T645 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape5T645OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074004480 1649318435840 q12Shape5T645=true := by decide

private def q12Shape5T646 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T646OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585632256 549806808064 q12Shape5T646=true := by decide

private def q12Shape5T644 : Tree 12 := .split 40 q12Shape5T645 q12Shape5T646
private theorem q12Shape5T644OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074004480 549806808064 q12Shape5T644=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074004480 (549806808064 ||| 2^40) q12Shape5T645 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074004480 ||| 2^40) 549806808064 q12Shape5T646)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T645OK,q12Shape5T646OK⟩

private def q12Shape5T647 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T647OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550829818368 50994176 q12Shape5T647=true := by decide

private def q12Shape5T643 : Tree 12 := .split 39 q12Shape5T644 q12Shape5T647
private theorem q12Shape5T643OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074004480 50994176 q12Shape5T643=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074004480 (50994176 ||| 2^39) q12Shape5T644 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074004480 ||| 2^39) 50994176 q12Shape5T647)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T644OK,q12Shape5T647OK⟩

private def q12Shape5T641 : Tree 12 := .split 30 q12Shape5T642 q12Shape5T643
private theorem q12Shape5T641OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 50994176 q12Shape5T641=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 (50994176 ||| 2^30) q12Shape5T642 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (262656 ||| 2^30) 50994176 q12Shape5T643)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T642OK,q12Shape5T643OK⟩

private def q12Shape5T648 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T648OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33817088 17439744 q12Shape5T648=true := by decide

private def q12Shape5T640 : Tree 12 := .split 25 q12Shape5T641 q12Shape5T648
private theorem q12Shape5T640OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 17439744 q12Shape5T640=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 (17439744 ||| 2^25) q12Shape5T641 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (262656 ||| 2^25) 17439744 q12Shape5T648)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T641OK,q12Shape5T648OK⟩

private def q12Shape5T653 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9}))))
private theorem q12Shape5T653OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 1650375400448 q12Shape5T653=true := by decide

private def q12Shape5T654 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,9}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape5T654OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528667648 550863772672 q12Shape5T654=true := by decide

private def q12Shape5T652 : Tree 12 := .split 40 q12Shape5T653 q12Shape5T654
private theorem q12Shape5T652OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 550863772672 q12Shape5T652=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 (550863772672 ||| 2^40) q12Shape5T653 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17039872 ||| 2^40) 550863772672 q12Shape5T654)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T653OK,q12Shape5T654OK⟩

private def q12Shape5T655 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape5T655OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772853760 1107958784 q12Shape5T655=true := by decide

private def q12Shape5T651 : Tree 12 := .split 39 q12Shape5T652 q12Shape5T655
private theorem q12Shape5T651OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 1107958784 q12Shape5T651=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 (1107958784 ||| 2^39) q12Shape5T652 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17039872 ||| 2^39) 1107958784 q12Shape5T655)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T652OK,q12Shape5T655OK⟩

private def q12Shape5T656 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T656OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090781696 34216960 q12Shape5T656=true := by decide

private def q12Shape5T650 : Tree 12 := .split 30 q12Shape5T651 q12Shape5T656
private theorem q12Shape5T650OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 34216960 q12Shape5T650=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 (34216960 ||| 2^30) q12Shape5T651 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17039872 ||| 2^30) 34216960 q12Shape5T656)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T651OK,q12Shape5T656OK⟩

private def q12Shape5T657 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T657OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50594304 662528 q12Shape5T657=true := by decide

private def q12Shape5T649 : Tree 12 := .split 25 q12Shape5T650 q12Shape5T657
private theorem q12Shape5T649OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 662528 q12Shape5T649=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17039872 (662528 ||| 2^25) q12Shape5T650 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17039872 ||| 2^25) 662528 q12Shape5T657)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T650OK,q12Shape5T657OK⟩

private def q12Shape5T639 : Tree 12 := .split 24 q12Shape5T640 q12Shape5T649
private theorem q12Shape5T639OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 662528 q12Shape5T639=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 (662528 ||| 2^24) q12Shape5T640 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (262656 ||| 2^24) 662528 q12Shape5T649)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T640OK,q12Shape5T649OK⟩

private def q12Shape5T658 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T658OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 786944 138240 q12Shape5T658=true := by decide

private def q12Shape5T638 : Tree 12 := .split 19 q12Shape5T639 q12Shape5T658
private theorem q12Shape5T638OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 138240 q12Shape5T638=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 (138240 ||| 2^19) q12Shape5T639 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (262656 ||| 2^19) 138240 q12Shape5T658)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T639OK,q12Shape5T658OK⟩

def q12Shape5P27 : Tree 12 := q12Shape5T638
theorem q12Shape5P27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 262656 138240 q12Shape5P27=true := q12Shape5T638OK

end Graffiti384b.EffectiveSearch.Q12
