import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T664 : Tree 12 := (.split 30 (.tip (.cover {0,2,4,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))))
private theorem q12Shape5T664OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 51125248 q12Shape5T664=true := by decide

private def q12Shape5T668 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape5T668OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33686016 1650358754304 q12Shape5T668=true := by decide

private def q12Shape5T669 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T669OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545313792 550847126528 q12Shape5T669=true := by decide

private def q12Shape5T667 : Tree 12 := .split 40 q12Shape5T668 q12Shape5T669
private theorem q12Shape5T667OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33686016 550847126528 q12Shape5T667=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33686016 (550847126528 ||| 2^40) q12Shape5T668 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33686016 ||| 2^40) 550847126528 q12Shape5T669)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T668OK,q12Shape5T669OK⟩

private def q12Shape5T670 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T670OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789499904 1091312640 q12Shape5T670=true := by decide

private def q12Shape5T666 : Tree 12 := .split 39 q12Shape5T667 q12Shape5T670
private theorem q12Shape5T666OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33686016 1091312640 q12Shape5T666=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33686016 (1091312640 ||| 2^39) q12Shape5T667 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33686016 ||| 2^39) 1091312640 q12Shape5T670)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T667OK,q12Shape5T670OK⟩

private def q12Shape5T671 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T671OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107427840 17570816 q12Shape5T671=true := by decide

private def q12Shape5T665 : Tree 12 := .split 30 q12Shape5T666 q12Shape5T671
private theorem q12Shape5T665OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33686016 17570816 q12Shape5T665=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33686016 (17570816 ||| 2^30) q12Shape5T666 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33686016 ||| 2^30) 17570816 q12Shape5T671)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T666OK,q12Shape5T671OK⟩

private def q12Shape5T663 : Tree 12 := .split 25 q12Shape5T664 q12Shape5T665
private theorem q12Shape5T663OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 17570816 q12Shape5T663=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 (17570816 ||| 2^25) q12Shape5T664 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (131584 ||| 2^25) 17570816 q12Shape5T665)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T664OK,q12Shape5T665OK⟩

private def q12Shape5T676 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9}))))
private theorem q12Shape5T676OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 1650375531520 q12Shape5T676=true := by decide

private def q12Shape5T677 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,9}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape5T677OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528536576 550863903744 q12Shape5T677=true := by decide

private def q12Shape5T675 : Tree 12 := .split 40 q12Shape5T676 q12Shape5T677
private theorem q12Shape5T675OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 550863903744 q12Shape5T675=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 (550863903744 ||| 2^40) q12Shape5T676 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16908800 ||| 2^40) 550863903744 q12Shape5T677)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T676OK,q12Shape5T677OK⟩

private def q12Shape5T678 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape5T678OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772722688 1108089856 q12Shape5T678=true := by decide

private def q12Shape5T674 : Tree 12 := .split 39 q12Shape5T675 q12Shape5T678
private theorem q12Shape5T674OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 1108089856 q12Shape5T674=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 (1108089856 ||| 2^39) q12Shape5T675 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16908800 ||| 2^39) 1108089856 q12Shape5T678)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T675OK,q12Shape5T678OK⟩

private def q12Shape5T679 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T679OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090650624 34348032 q12Shape5T679=true := by decide

private def q12Shape5T673 : Tree 12 := .split 30 q12Shape5T674 q12Shape5T679
private theorem q12Shape5T673OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 34348032 q12Shape5T673=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 (34348032 ||| 2^30) q12Shape5T674 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16908800 ||| 2^30) 34348032 q12Shape5T679)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T674OK,q12Shape5T679OK⟩

private def q12Shape5T680 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T680OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50463232 793600 q12Shape5T680=true := by decide

private def q12Shape5T672 : Tree 12 := .split 25 q12Shape5T673 q12Shape5T680
private theorem q12Shape5T672OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 793600 q12Shape5T672=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16908800 (793600 ||| 2^25) q12Shape5T673 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16908800 ||| 2^25) 793600 q12Shape5T680)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T673OK,q12Shape5T680OK⟩

private def q12Shape5T662 : Tree 12 := .split 24 q12Shape5T663 q12Shape5T672
private theorem q12Shape5T662OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 793600 q12Shape5T662=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 (793600 ||| 2^24) q12Shape5T663 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (131584 ||| 2^24) 793600 q12Shape5T672)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T663OK,q12Shape5T672OK⟩

private def q12Shape5T681 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T681OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655872 269312 q12Shape5T681=true := by decide

private def q12Shape5T661 : Tree 12 := .split 19 q12Shape5T662 q12Shape5T681
private theorem q12Shape5T661OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 269312 q12Shape5T661=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 (269312 ||| 2^19) q12Shape5T662 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (131584 ||| 2^19) 269312 q12Shape5T681)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T662OK,q12Shape5T681OK⟩

private def q12Shape5T682 : Tree 12 := (.split 19 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape5T682OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 393728 7168 q12Shape5T682=true := by decide

private def q12Shape5T660 : Tree 12 := .split 18 q12Shape5T661 q12Shape5T682
private theorem q12Shape5T660OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 7168 q12Shape5T660=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 (7168 ||| 2^18) q12Shape5T661 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (131584 ||| 2^18) 7168 q12Shape5T682)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T661OK,q12Shape5T682OK⟩

def q12Shape5P28 : Tree 12 := q12Shape5T660
theorem q12Shape5P28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 131584 7168 q12Shape5P28=true := q12Shape5T660OK

end Graffiti384b.EffectiveSearch.Q12
