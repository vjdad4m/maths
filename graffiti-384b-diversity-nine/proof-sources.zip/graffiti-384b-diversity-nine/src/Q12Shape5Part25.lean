import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T689 : Tree 12 := (.tip (.cover {0,2,3,8,9,10,11}))
private theorem q12Shape5T689OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 1124994048 q12Shape5T689=true := by decide

private def q12Shape5T692 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape5T692OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746432 1649318693888 q12Shape5T692=true := by decide

private def q12Shape5T693 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T693OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585374208 549807066112 q12Shape5T693=true := by decide

private def q12Shape5T691 : Tree 12 := .split 40 q12Shape5T692 q12Shape5T693
private theorem q12Shape5T691OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746432 549807066112 q12Shape5T691=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746432 (549807066112 ||| 2^40) q12Shape5T692 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073746432 ||| 2^40) 549807066112 q12Shape5T693)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T692OK,q12Shape5T693OK⟩

private def q12Shape5T694 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T694OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550829560320 51252224 q12Shape5T694=true := by decide

private def q12Shape5T690 : Tree 12 := .split 39 q12Shape5T691 q12Shape5T694
private theorem q12Shape5T690OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746432 51252224 q12Shape5T690=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073746432 (51252224 ||| 2^39) q12Shape5T691 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1073746432 ||| 2^39) 51252224 q12Shape5T694)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T691OK,q12Shape5T694OK⟩

private def q12Shape5T688 : Tree 12 := .split 30 q12Shape5T689 q12Shape5T690
private theorem q12Shape5T688OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 51252224 q12Shape5T688=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 (51252224 ||| 2^30) q12Shape5T689 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4608 ||| 2^30) 51252224 q12Shape5T690)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T689OK,q12Shape5T690OK⟩

private def q12Shape5T698 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape5T698OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559040 1650358881280 q12Shape5T698=true := by decide

private def q12Shape5T699 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T699OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545186816 550847253504 q12Shape5T699=true := by decide

private def q12Shape5T697 : Tree 12 := .split 40 q12Shape5T698 q12Shape5T699
private theorem q12Shape5T697OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559040 550847253504 q12Shape5T697=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559040 (550847253504 ||| 2^40) q12Shape5T698 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33559040 ||| 2^40) 550847253504 q12Shape5T699)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T698OK,q12Shape5T699OK⟩

private def q12Shape5T700 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T700OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789372928 1091439616 q12Shape5T700=true := by decide

private def q12Shape5T696 : Tree 12 := .split 39 q12Shape5T697 q12Shape5T700
private theorem q12Shape5T696OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559040 1091439616 q12Shape5T696=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559040 (1091439616 ||| 2^39) q12Shape5T697 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33559040 ||| 2^39) 1091439616 q12Shape5T700)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T697OK,q12Shape5T700OK⟩

private def q12Shape5T701 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T701OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107300864 17697792 q12Shape5T701=true := by decide

private def q12Shape5T695 : Tree 12 := .split 30 q12Shape5T696 q12Shape5T701
private theorem q12Shape5T695OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559040 17697792 q12Shape5T695=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33559040 (17697792 ||| 2^30) q12Shape5T696 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33559040 ||| 2^30) 17697792 q12Shape5T701)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T696OK,q12Shape5T701OK⟩

private def q12Shape5T687 : Tree 12 := .split 25 q12Shape5T688 q12Shape5T695
private theorem q12Shape5T687OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 17697792 q12Shape5T687=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 (17697792 ||| 2^25) q12Shape5T688 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4608 ||| 2^25) 17697792 q12Shape5T695)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T688OK,q12Shape5T695OK⟩

private def q12Shape5T702 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T702OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781824 920576 q12Shape5T702=true := by decide

private def q12Shape5T686 : Tree 12 := .split 24 q12Shape5T687 q12Shape5T702
private theorem q12Shape5T686OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 920576 q12Shape5T686=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 (920576 ||| 2^24) q12Shape5T687 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4608 ||| 2^24) 920576 q12Shape5T702)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T687OK,q12Shape5T702OK⟩

private def q12Shape5T703 : Tree 12 := (.split 24 (.tip (.cover {0,2,7,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))))
private theorem q12Shape5T703OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 528896 396288 q12Shape5T703=true := by decide

private def q12Shape5T685 : Tree 12 := .split 19 q12Shape5T686 q12Shape5T703
private theorem q12Shape5T685OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 396288 q12Shape5T685=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 (396288 ||| 2^19) q12Shape5T686 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4608 ||| 2^19) 396288 q12Shape5T703)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T686OK,q12Shape5T703OK⟩

private def q12Shape5T710 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T710OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 1650392173568 q12Shape5T710=true := by decide

private def q12Shape5T711 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T711OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511894528 550880545792 q12Shape5T711=true := by decide

private def q12Shape5T709 : Tree 12 := .split 40 q12Shape5T710 q12Shape5T711
private theorem q12Shape5T709OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 550880545792 q12Shape5T709=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 (550880545792 ||| 2^40) q12Shape5T710 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266752 ||| 2^40) 550880545792 q12Shape5T711)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T710OK,q12Shape5T711OK⟩

private def q12Shape5T712 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T712OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756080640 1124731904 q12Shape5T712=true := by decide

private def q12Shape5T708 : Tree 12 := .split 39 q12Shape5T709 q12Shape5T712
private theorem q12Shape5T708OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 1124731904 q12Shape5T708=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 (1124731904 ||| 2^39) q12Shape5T709 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266752 ||| 2^39) 1124731904 q12Shape5T712)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T709OK,q12Shape5T712OK⟩

private def q12Shape5T715 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,6,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,6,8,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T715OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008576 1649318431744 q12Shape5T715=true := by decide

private def q12Shape5T716 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,5,6,8,9,11}))) (.tip (.cover {2,3,5,6,9,10,11})))
private theorem q12Shape5T716OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585636352 549806803968 q12Shape5T716=true := by decide

private def q12Shape5T714 : Tree 12 := .split 40 q12Shape5T715 q12Shape5T716
private theorem q12Shape5T714OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008576 549806803968 q12Shape5T714=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008576 (549806803968 ||| 2^40) q12Shape5T715 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074008576 ||| 2^40) 549806803968 q12Shape5T716)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T715OK,q12Shape5T716OK⟩

private def q12Shape5T717 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,6,8,10,11}))) (.tip (.cover {2,3,5,6,8,10,11}))) (.tip (.cover {2,3,5,6,9,10,11}))) (.tip (.cover {2,3,5,6,9,10,11})))
private theorem q12Shape5T717OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550829822464 50990080 q12Shape5T717=true := by decide

private def q12Shape5T713 : Tree 12 := .split 39 q12Shape5T714 q12Shape5T717
private theorem q12Shape5T713OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008576 50990080 q12Shape5T713=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008576 (50990080 ||| 2^39) q12Shape5T714 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074008576 ||| 2^39) 50990080 q12Shape5T717)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T714OK,q12Shape5T717OK⟩

private def q12Shape5T707 : Tree 12 := .split 30 q12Shape5T708 q12Shape5T713
private theorem q12Shape5T707OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 50990080 q12Shape5T707=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 (50990080 ||| 2^30) q12Shape5T708 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266752 ||| 2^30) 50990080 q12Shape5T713)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T708OK,q12Shape5T713OK⟩

private def q12Shape5T718 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T718OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33821184 17435648 q12Shape5T718=true := by decide

private def q12Shape5T706 : Tree 12 := .split 25 q12Shape5T707 q12Shape5T718
private theorem q12Shape5T706OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 17435648 q12Shape5T706=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 (17435648 ||| 2^25) q12Shape5T707 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266752 ||| 2^25) 17435648 q12Shape5T718)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T707OK,q12Shape5T718OK⟩

private def q12Shape5T719 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T719OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17043968 658432 q12Shape5T719=true := by decide

private def q12Shape5T705 : Tree 12 := .split 24 q12Shape5T706 q12Shape5T719
private theorem q12Shape5T705OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 658432 q12Shape5T705=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 (658432 ||| 2^24) q12Shape5T706 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266752 ||| 2^24) 658432 q12Shape5T719)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T706OK,q12Shape5T719OK⟩

private def q12Shape5T720 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T720OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 791040 134144 q12Shape5T720=true := by decide

private def q12Shape5T704 : Tree 12 := .split 19 q12Shape5T705 q12Shape5T720
private theorem q12Shape5T704OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 134144 q12Shape5T704=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266752 (134144 ||| 2^19) q12Shape5T705 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266752 ||| 2^19) 134144 q12Shape5T720)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T705OK,q12Shape5T720OK⟩

private def q12Shape5T684 : Tree 12 := .split 18 q12Shape5T685 q12Shape5T704
private theorem q12Shape5T684OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 134144 q12Shape5T684=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 (134144 ||| 2^18) q12Shape5T685 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4608 ||| 2^18) 134144 q12Shape5T704)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T685OK,q12Shape5T704OK⟩

def q12Shape5P29 : Tree 12 := q12Shape5T684
theorem q12Shape5P29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4608 134144 q12Shape5P29=true := q12Shape5T684OK

end Graffiti384b.EffectiveSearch.Q12
