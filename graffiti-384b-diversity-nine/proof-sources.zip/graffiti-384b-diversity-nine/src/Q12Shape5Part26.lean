import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T728 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T728OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 1650392304640 q12Shape5T728=true := by decide

private def q12Shape5T729 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T729OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511763456 550880676864 q12Shape5T729=true := by decide

private def q12Shape5T727 : Tree 12 := .split 40 q12Shape5T728 q12Shape5T729
private theorem q12Shape5T727OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 550880676864 q12Shape5T727=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 (550880676864 ||| 2^40) q12Shape5T728 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135680 ||| 2^40) 550880676864 q12Shape5T729)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T728OK,q12Shape5T729OK⟩

private def q12Shape5T730 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T730OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549755949568 1124862976 q12Shape5T730=true := by decide

private def q12Shape5T726 : Tree 12 := .split 39 q12Shape5T727 q12Shape5T730
private theorem q12Shape5T726OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 1124862976 q12Shape5T726=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 (1124862976 ||| 2^39) q12Shape5T727 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135680 ||| 2^39) 1124862976 q12Shape5T730)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T727OK,q12Shape5T730OK⟩

private def q12Shape5T731 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T731OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073877504 51121152 q12Shape5T731=true := by decide

private def q12Shape5T725 : Tree 12 := .split 30 q12Shape5T726 q12Shape5T731
private theorem q12Shape5T725OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 51121152 q12Shape5T725=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 (51121152 ||| 2^30) q12Shape5T726 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135680 ||| 2^30) 51121152 q12Shape5T731)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T726OK,q12Shape5T731OK⟩

private def q12Shape5T735 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,6,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,6,8,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T735OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33690112 1650358750208 q12Shape5T735=true := by decide

private def q12Shape5T736 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {2,3,5,6,8,9,11}))) (.tip (.cover {2,3,5,6,9,10,11})))
private theorem q12Shape5T736OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545317888 550847122432 q12Shape5T736=true := by decide

private def q12Shape5T734 : Tree 12 := .split 40 q12Shape5T735 q12Shape5T736
private theorem q12Shape5T734OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33690112 550847122432 q12Shape5T734=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33690112 (550847122432 ||| 2^40) q12Shape5T735 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33690112 ||| 2^40) 550847122432 q12Shape5T736)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T735OK,q12Shape5T736OK⟩

private def q12Shape5T737 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,6,8,10,11}))) (.tip (.cover {2,3,5,6,8,10,11}))) (.tip (.cover {2,3,5,6,9,10,11}))) (.tip (.cover {2,3,5,6,9,10,11})))
private theorem q12Shape5T737OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789504000 1091308544 q12Shape5T737=true := by decide

private def q12Shape5T733 : Tree 12 := .split 39 q12Shape5T734 q12Shape5T737
private theorem q12Shape5T733OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33690112 1091308544 q12Shape5T733=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33690112 (1091308544 ||| 2^39) q12Shape5T734 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33690112 ||| 2^39) 1091308544 q12Shape5T737)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T734OK,q12Shape5T737OK⟩

private def q12Shape5T738 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,9,10}))) (.tip (.cover {0,1,3,7,8,9,11}))) (.tip (.cover {0,1,3,7,8,10,11})))
private theorem q12Shape5T738OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107431936 17566720 q12Shape5T738=true := by decide

private def q12Shape5T732 : Tree 12 := .split 30 q12Shape5T733 q12Shape5T738
private theorem q12Shape5T732OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33690112 17566720 q12Shape5T732=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33690112 (17566720 ||| 2^30) q12Shape5T733 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33690112 ||| 2^30) 17566720 q12Shape5T738)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T733OK,q12Shape5T738OK⟩

private def q12Shape5T724 : Tree 12 := .split 25 q12Shape5T725 q12Shape5T732
private theorem q12Shape5T724OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 17566720 q12Shape5T724=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 (17566720 ||| 2^25) q12Shape5T725 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135680 ||| 2^25) 17566720 q12Shape5T732)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T725OK,q12Shape5T732OK⟩

private def q12Shape5T739 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T739OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16912896 789504 q12Shape5T739=true := by decide

private def q12Shape5T723 : Tree 12 := .split 24 q12Shape5T724 q12Shape5T739
private theorem q12Shape5T723OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 789504 q12Shape5T723=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 (789504 ||| 2^24) q12Shape5T724 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135680 ||| 2^24) 789504 q12Shape5T739)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T724OK,q12Shape5T739OK⟩

private def q12Shape5T740 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T740OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659968 265216 q12Shape5T740=true := by decide

private def q12Shape5T722 : Tree 12 := .split 19 q12Shape5T723 q12Shape5T740
private theorem q12Shape5T722OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 265216 q12Shape5T722=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 (265216 ||| 2^19) q12Shape5T723 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135680 ||| 2^19) 265216 q12Shape5T740)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T723OK,q12Shape5T740OK⟩

private def q12Shape5T741 : Tree 12 := (.split 19 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape5T741OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 397824 3072 q12Shape5T741=true := by decide

private def q12Shape5T721 : Tree 12 := .split 18 q12Shape5T722 q12Shape5T741
private theorem q12Shape5T721OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 3072 q12Shape5T721=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 (3072 ||| 2^18) q12Shape5T722 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135680 ||| 2^18) 3072 q12Shape5T741)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T722OK,q12Shape5T741OK⟩

def q12Shape5P30 : Tree 12 := q12Shape5T721
theorem q12Shape5P30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135680 3072 q12Shape5P30=true := q12Shape5T721OK

end Graffiti384b.EffectiveSearch.Q12
