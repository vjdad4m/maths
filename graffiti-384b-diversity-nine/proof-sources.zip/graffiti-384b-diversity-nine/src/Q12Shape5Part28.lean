import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T780 : Tree 12 := (.split 25 (.tip (.cover {0,2,6,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11}))))
private theorem q12Shape5T780OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264704 660480 q12Shape5T780=true := by decide

private def q12Shape5T781 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T781OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 788992 136192 q12Shape5T781=true := by decide

private def q12Shape5T779 : Tree 12 := .split 19 q12Shape5T780 q12Shape5T781
private theorem q12Shape5T779OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264704 136192 q12Shape5T779=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264704 (136192 ||| 2^19) q12Shape5T780 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (264704 ||| 2^19) 136192 q12Shape5T781)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T780OK,q12Shape5T781OK⟩

def q12Shape5P32 : Tree 12 := q12Shape5T779
theorem q12Shape5P32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 264704 136192 q12Shape5P32=true := q12Shape5T779OK

private def q12Shape5T790 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape5T790OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 1650392306688 q12Shape5T790=true := by decide

private def q12Shape5T791 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,10,11}))) (.tip (.cover {0,1,3,4,7,8,9})))
private theorem q12Shape5T791OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511761408 550880678912 q12Shape5T791=true := by decide

private def q12Shape5T789 : Tree 12 := .split 40 q12Shape5T790 q12Shape5T791
private theorem q12Shape5T789OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 550880678912 q12Shape5T789=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 (550880678912 ||| 2^40) q12Shape5T790 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133632 ||| 2^40) 550880678912 q12Shape5T791)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T790OK,q12Shape5T791OK⟩

private def q12Shape5T792 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,7,9,11}))) (.tip (.cover {0,1,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8,11})))
private theorem q12Shape5T792OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549755947520 1124865024 q12Shape5T792=true := by decide

private def q12Shape5T788 : Tree 12 := .split 39 q12Shape5T789 q12Shape5T792
private theorem q12Shape5T788OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 1124865024 q12Shape5T788=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 (1124865024 ||| 2^39) q12Shape5T789 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133632 ||| 2^39) 1124865024 q12Shape5T792)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T789OK,q12Shape5T792OK⟩

private def q12Shape5T793 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape5T793OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073875456 51123200 q12Shape5T793=true := by decide

private def q12Shape5T787 : Tree 12 := .split 30 q12Shape5T788 q12Shape5T793
private theorem q12Shape5T787OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 51123200 q12Shape5T787=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 (51123200 ||| 2^30) q12Shape5T788 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133632 ||| 2^30) 51123200 q12Shape5T793)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T788OK,q12Shape5T793OK⟩

private def q12Shape5T794 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T794OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33688064 17568768 q12Shape5T794=true := by decide

private def q12Shape5T786 : Tree 12 := .split 25 q12Shape5T787 q12Shape5T794
private theorem q12Shape5T786OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 17568768 q12Shape5T786=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 (17568768 ||| 2^25) q12Shape5T787 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133632 ||| 2^25) 17568768 q12Shape5T794)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T787OK,q12Shape5T794OK⟩

private def q12Shape5T799 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,9,10}))) (.tip (.cover {0,1,3,4,7,8,9}))))
private theorem q12Shape5T799OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 1650375529472 q12Shape5T799=true := by decide

private def q12Shape5T800 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8,9}))) (.tip (.cover {2,3,5,7,8,9,11}))) (.tip (.cover {2,3,5,7,9,10,11})))
private theorem q12Shape5T800OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528538624 550863901696 q12Shape5T800=true := by decide

private def q12Shape5T798 : Tree 12 := .split 40 q12Shape5T799 q12Shape5T800
private theorem q12Shape5T798OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 550863901696 q12Shape5T798=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 (550863901696 ||| 2^40) q12Shape5T799 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910848 ||| 2^40) 550863901696 q12Shape5T800)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T799OK,q12Shape5T800OK⟩

private def q12Shape5T801 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {2,3,5,7,8,10,11}))) (.tip (.cover {2,3,5,7,9,10,11}))) (.tip (.cover {2,3,5,7,9,10,11})))
private theorem q12Shape5T801OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772724736 1108087808 q12Shape5T801=true := by decide

private def q12Shape5T797 : Tree 12 := .split 39 q12Shape5T798 q12Shape5T801
private theorem q12Shape5T797OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 1108087808 q12Shape5T797=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 (1108087808 ||| 2^39) q12Shape5T798 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910848 ||| 2^39) 1108087808 q12Shape5T801)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T798OK,q12Shape5T801OK⟩

private def q12Shape5T802 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T802OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090652672 34345984 q12Shape5T802=true := by decide

private def q12Shape5T796 : Tree 12 := .split 30 q12Shape5T797 q12Shape5T802
private theorem q12Shape5T796OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 34345984 q12Shape5T796=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 (34345984 ||| 2^30) q12Shape5T797 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910848 ||| 2^30) 34345984 q12Shape5T802)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T797OK,q12Shape5T802OK⟩

private def q12Shape5T803 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T803OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50465280 791552 q12Shape5T803=true := by decide

private def q12Shape5T795 : Tree 12 := .split 25 q12Shape5T796 q12Shape5T803
private theorem q12Shape5T795OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 791552 q12Shape5T795=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16910848 (791552 ||| 2^25) q12Shape5T796 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16910848 ||| 2^25) 791552 q12Shape5T803)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T796OK,q12Shape5T803OK⟩

private def q12Shape5T785 : Tree 12 := .split 24 q12Shape5T786 q12Shape5T795
private theorem q12Shape5T785OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 791552 q12Shape5T785=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 (791552 ||| 2^24) q12Shape5T786 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133632 ||| 2^24) 791552 q12Shape5T795)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T786OK,q12Shape5T795OK⟩

private def q12Shape5T804 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T804OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 657920 267264 q12Shape5T804=true := by decide

private def q12Shape5T784 : Tree 12 := .split 19 q12Shape5T785 q12Shape5T804
private theorem q12Shape5T784OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 267264 q12Shape5T784=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 (267264 ||| 2^19) q12Shape5T785 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133632 ||| 2^19) 267264 q12Shape5T804)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T785OK,q12Shape5T804OK⟩

private def q12Shape5T805 : Tree 12 := (.split 19 (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,8,9,10,11})))
private theorem q12Shape5T805OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 395776 5120 q12Shape5T805=true := by decide

private def q12Shape5T783 : Tree 12 := .split 18 q12Shape5T784 q12Shape5T805
private theorem q12Shape5T783OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 5120 q12Shape5T783=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 (5120 ||| 2^18) q12Shape5T784 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (133632 ||| 2^18) 5120 q12Shape5T805)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T784OK,q12Shape5T805OK⟩

def q12Shape5P33 : Tree 12 := q12Shape5T783
theorem q12Shape5P33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 133632 5120 q12Shape5P33=true := q12Shape5T783OK

private def q12Shape5T807 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T807OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 6656 1024 q12Shape5T807=true := by decide

def q12Shape5P34 : Tree 12 := q12Shape5T807
theorem q12Shape5P34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 6656 1024 q12Shape5P34=true := q12Shape5T807OK

end Graffiti384b.EffectiveSearch.Q12
