import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T813 : Tree 12 := (.split 30 (.tip (.cover {0,2,3,8,9,10,11})) (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11}))))
private theorem q12Shape5T813OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 51255296 q12Shape5T813=true := by decide

private def q12Shape5T817 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9}))))
private theorem q12Shape5T817OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33555968 1650358884352 q12Shape5T817=true := by decide

private def q12Shape5T818 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8,9}))) (.tip (.cover {0,1,3,5,6,10,11}))) (.tip (.cover {0,1,3,5,6,8,9})))
private theorem q12Shape5T818OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545183744 550847256576 q12Shape5T818=true := by decide

private def q12Shape5T816 : Tree 12 := .split 40 q12Shape5T817 q12Shape5T818
private theorem q12Shape5T816OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33555968 550847256576 q12Shape5T816=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33555968 (550847256576 ||| 2^40) q12Shape5T817 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33555968 ||| 2^40) 550847256576 q12Shape5T818)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T817OK,q12Shape5T818OK⟩

private def q12Shape5T819 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,9,10}))) (.tip (.cover {0,1,3,5,6,9,11}))) (.tip (.cover {0,1,3,5,6,8,10}))) (.tip (.cover {0,1,3,5,6,8,11})))
private theorem q12Shape5T819OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789369856 1091442688 q12Shape5T819=true := by decide

private def q12Shape5T815 : Tree 12 := .split 39 q12Shape5T816 q12Shape5T819
private theorem q12Shape5T815OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33555968 1091442688 q12Shape5T815=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33555968 (1091442688 ||| 2^39) q12Shape5T816 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33555968 ||| 2^39) 1091442688 q12Shape5T819)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T816OK,q12Shape5T819OK⟩

private def q12Shape5T820 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T820OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107297792 17700864 q12Shape5T820=true := by decide

private def q12Shape5T814 : Tree 12 := .split 30 q12Shape5T815 q12Shape5T820
private theorem q12Shape5T814OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33555968 17700864 q12Shape5T814=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33555968 (17700864 ||| 2^30) q12Shape5T815 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33555968 ||| 2^30) 17700864 q12Shape5T820)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T815OK,q12Shape5T820OK⟩

private def q12Shape5T812 : Tree 12 := .split 25 q12Shape5T813 q12Shape5T814
private theorem q12Shape5T812OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 17700864 q12Shape5T812=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 (17700864 ||| 2^25) q12Shape5T813 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1536 ||| 2^25) 17700864 q12Shape5T814)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T813OK,q12Shape5T814OK⟩

private def q12Shape5T825 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9}))))
private theorem q12Shape5T825OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 1650375661568 q12Shape5T825=true := by decide

private def q12Shape5T826 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8,9}))) (.tip (.cover {0,1,3,5,7,10,11}))) (.tip (.cover {0,1,3,5,7,8,9})))
private theorem q12Shape5T826OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528406528 550864033792 q12Shape5T826=true := by decide

private def q12Shape5T824 : Tree 12 := .split 40 q12Shape5T825 q12Shape5T826
private theorem q12Shape5T824OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 550864033792 q12Shape5T824=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 (550864033792 ||| 2^40) q12Shape5T825 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16778752 ||| 2^40) 550864033792 q12Shape5T826)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T825OK,q12Shape5T826OK⟩

private def q12Shape5T827 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9,10}))) (.tip (.cover {0,1,3,5,7,9,11}))) (.tip (.cover {0,1,3,5,7,8,10}))) (.tip (.cover {0,1,3,5,7,8,11})))
private theorem q12Shape5T827OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772592640 1108219904 q12Shape5T827=true := by decide

private def q12Shape5T823 : Tree 12 := .split 39 q12Shape5T824 q12Shape5T827
private theorem q12Shape5T823OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 1108219904 q12Shape5T823=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 (1108219904 ||| 2^39) q12Shape5T824 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16778752 ||| 2^39) 1108219904 q12Shape5T827)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T824OK,q12Shape5T827OK⟩

private def q12Shape5T828 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T828OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090520576 34478080 q12Shape5T828=true := by decide

private def q12Shape5T822 : Tree 12 := .split 30 q12Shape5T823 q12Shape5T828
private theorem q12Shape5T822OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 34478080 q12Shape5T822=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 (34478080 ||| 2^30) q12Shape5T823 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16778752 ||| 2^30) 34478080 q12Shape5T828)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T823OK,q12Shape5T828OK⟩

private def q12Shape5T829 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T829OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333184 923648 q12Shape5T829=true := by decide

private def q12Shape5T821 : Tree 12 := .split 25 q12Shape5T822 q12Shape5T829
private theorem q12Shape5T821OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 923648 q12Shape5T821=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16778752 (923648 ||| 2^25) q12Shape5T822 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16778752 ||| 2^25) 923648 q12Shape5T829)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T822OK,q12Shape5T829OK⟩

private def q12Shape5T811 : Tree 12 := .split 24 q12Shape5T812 q12Shape5T821
private theorem q12Shape5T811OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 923648 q12Shape5T811=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 (923648 ||| 2^24) q12Shape5T812 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1536 ||| 2^24) 923648 q12Shape5T821)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T812OK,q12Shape5T821OK⟩

private def q12Shape5T835 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T835OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 1650391914496 q12Shape5T835=true := by decide

private def q12Shape5T836 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T836OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512153600 550880286720 q12Shape5T836=true := by decide

private def q12Shape5T834 : Tree 12 := .split 40 q12Shape5T835 q12Shape5T836
private theorem q12Shape5T834OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 550880286720 q12Shape5T834=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 (550880286720 ||| 2^40) q12Shape5T835 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (525824 ||| 2^40) 550880286720 q12Shape5T836)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T835OK,q12Shape5T836OK⟩

private def q12Shape5T837 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T837OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756339712 1124472832 q12Shape5T837=true := by decide

private def q12Shape5T833 : Tree 12 := .split 39 q12Shape5T834 q12Shape5T837
private theorem q12Shape5T833OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 1124472832 q12Shape5T833=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 (1124472832 ||| 2^39) q12Shape5T834 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (525824 ||| 2^39) 1124472832 q12Shape5T837)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T834OK,q12Shape5T837OK⟩

private def q12Shape5T838 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T838OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074267648 50731008 q12Shape5T838=true := by decide

private def q12Shape5T832 : Tree 12 := .split 30 q12Shape5T833 q12Shape5T838
private theorem q12Shape5T832OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 50731008 q12Shape5T832=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 (50731008 ||| 2^30) q12Shape5T833 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (525824 ||| 2^30) 50731008 q12Shape5T838)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T833OK,q12Shape5T838OK⟩

private def q12Shape5T842 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,9,10}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T842OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080256 1650358360064 q12Shape5T842=true := by decide

private def q12Shape5T843 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {2,3,6,7,8,9,11}))) (.tip (.cover {2,3,6,7,9,10,11})))
private theorem q12Shape5T843OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545708032 550846732288 q12Shape5T843=true := by decide

private def q12Shape5T841 : Tree 12 := .split 40 q12Shape5T842 q12Shape5T843
private theorem q12Shape5T841OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080256 550846732288 q12Shape5T841=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080256 (550846732288 ||| 2^40) q12Shape5T842 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34080256 ||| 2^40) 550846732288 q12Shape5T843)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T842OK,q12Shape5T843OK⟩

private def q12Shape5T844 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {2,3,6,7,8,10,11}))) (.tip (.cover {2,3,6,7,9,10,11}))) (.tip (.cover {2,3,6,7,9,10,11})))
private theorem q12Shape5T844OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789894144 1090918400 q12Shape5T844=true := by decide

private def q12Shape5T840 : Tree 12 := .split 39 q12Shape5T841 q12Shape5T844
private theorem q12Shape5T840OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080256 1090918400 q12Shape5T840=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080256 (1090918400 ||| 2^39) q12Shape5T841 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34080256 ||| 2^39) 1090918400 q12Shape5T844)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T841OK,q12Shape5T844OK⟩

private def q12Shape5T845 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T845OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107822080 17176576 q12Shape5T845=true := by decide

private def q12Shape5T839 : Tree 12 := .split 30 q12Shape5T840 q12Shape5T845
private theorem q12Shape5T839OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080256 17176576 q12Shape5T839=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34080256 (17176576 ||| 2^30) q12Shape5T840 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (34080256 ||| 2^30) 17176576 q12Shape5T845)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T840OK,q12Shape5T845OK⟩

private def q12Shape5T831 : Tree 12 := .split 25 q12Shape5T832 q12Shape5T839
private theorem q12Shape5T831OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 17176576 q12Shape5T831=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 (17176576 ||| 2^25) q12Shape5T832 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (525824 ||| 2^25) 17176576 q12Shape5T839)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T832OK,q12Shape5T839OK⟩

private def q12Shape5T846 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape5T846OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17303040 399360 q12Shape5T846=true := by decide

private def q12Shape5T830 : Tree 12 := .split 24 q12Shape5T831 q12Shape5T846
private theorem q12Shape5T830OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 399360 q12Shape5T830=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 525824 (399360 ||| 2^24) q12Shape5T831 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (525824 ||| 2^24) 399360 q12Shape5T846)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T831OK,q12Shape5T846OK⟩

private def q12Shape5T810 : Tree 12 := .split 19 q12Shape5T811 q12Shape5T830
private theorem q12Shape5T810OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 399360 q12Shape5T810=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 (399360 ||| 2^19) q12Shape5T811 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1536 ||| 2^19) 399360 q12Shape5T830)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T811OK,q12Shape5T830OK⟩

def q12Shape5P35 : Tree 12 := q12Shape5T810
theorem q12Shape5P35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1536 399360 q12Shape5P35=true := q12Shape5T810OK

end Graffiti384b.EffectiveSearch.Q12
