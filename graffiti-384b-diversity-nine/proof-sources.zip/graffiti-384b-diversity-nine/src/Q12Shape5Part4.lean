import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T93 : Tree 12 := (.tip (.cover {0,2,4,8,9,10,11}))
private theorem q12Shape5T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 1124343296 q12Shape5T93=true := by decide

private def q12Shape5T96 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074397184 1649318043136 q12Shape5T96=true := by decide

private def q12Shape5T97 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100586024960 549806415360 q12Shape5T97=true := by decide

private def q12Shape5T95 : Tree 12 := .split 40 q12Shape5T96 q12Shape5T97
private theorem q12Shape5T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074397184 549806415360 q12Shape5T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074397184 (549806415360 ||| 2^40) q12Shape5T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074397184 ||| 2^40) 549806415360 q12Shape5T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T96OK,q12Shape5T97OK⟩

private def q12Shape5T98 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550830211072 50601472 q12Shape5T98=true := by decide

private def q12Shape5T94 : Tree 12 := .split 39 q12Shape5T95 q12Shape5T98
private theorem q12Shape5T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074397184 50601472 q12Shape5T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074397184 (50601472 ||| 2^39) q12Shape5T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074397184 ||| 2^39) 50601472 q12Shape5T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T95OK,q12Shape5T98OK⟩

private def q12Shape5T92 : Tree 12 := .split 30 q12Shape5T93 q12Shape5T94
private theorem q12Shape5T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 50601472 q12Shape5T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 (50601472 ||| 2^30) q12Shape5T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (655360 ||| 2^30) 50601472 q12Shape5T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T93OK,q12Shape5T94OK⟩

private def q12Shape5T99 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34209792 17047040 q12Shape5T99=true := by decide

private def q12Shape5T91 : Tree 12 := .split 25 q12Shape5T92 q12Shape5T99
private theorem q12Shape5T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 17047040 q12Shape5T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 (17047040 ||| 2^25) q12Shape5T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (655360 ||| 2^25) 17047040 q12Shape5T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T92OK,q12Shape5T99OK⟩

private def q12Shape5T104 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 1650375007744 q12Shape5T104=true := by decide

private def q12Shape5T105 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099529060352 550863379968 q12Shape5T105=true := by decide

private def q12Shape5T103 : Tree 12 := .split 40 q12Shape5T104 q12Shape5T105
private theorem q12Shape5T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 550863379968 q12Shape5T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 (550863379968 ||| 2^40) q12Shape5T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17432576 ||| 2^40) 550863379968 q12Shape5T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T104OK,q12Shape5T105OK⟩

private def q12Shape5T106 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549773246464 1107566080 q12Shape5T106=true := by decide

private def q12Shape5T102 : Tree 12 := .split 39 q12Shape5T103 q12Shape5T106
private theorem q12Shape5T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 1107566080 q12Shape5T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 (1107566080 ||| 2^39) q12Shape5T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17432576 ||| 2^39) 1107566080 q12Shape5T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T103OK,q12Shape5T106OK⟩

private def q12Shape5T109 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,6,8,10,11})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,6,8,9,10}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091174400 1649301265920 q12Shape5T109=true := by decide

private def q12Shape5T110 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {2,3,4,6,8,9,11}))) (.tip (.cover {2,3,4,6,9,10,11})))
private theorem q12Shape5T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100602802176 549789638144 q12Shape5T110=true := by decide

private def q12Shape5T108 : Tree 12 := .split 40 q12Shape5T109 q12Shape5T110
private theorem q12Shape5T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091174400 549789638144 q12Shape5T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091174400 (549789638144 ||| 2^40) q12Shape5T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1091174400 ||| 2^40) 549789638144 q12Shape5T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T109OK,q12Shape5T110OK⟩

private def q12Shape5T111 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {2,3,4,6,8,10,11}))) (.tip (.cover {2,3,4,6,8,10,11}))) (.tip (.cover {2,3,4,6,9,10,11}))) (.tip (.cover {2,3,4,6,9,10,11})))
private theorem q12Shape5T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550846988288 33824256 q12Shape5T111=true := by decide

private def q12Shape5T107 : Tree 12 := .split 39 q12Shape5T108 q12Shape5T111
private theorem q12Shape5T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091174400 33824256 q12Shape5T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1091174400 (33824256 ||| 2^39) q12Shape5T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1091174400 ||| 2^39) 33824256 q12Shape5T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T108OK,q12Shape5T111OK⟩

private def q12Shape5T101 : Tree 12 := .split 30 q12Shape5T102 q12Shape5T107
private theorem q12Shape5T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 33824256 q12Shape5T101=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 (33824256 ||| 2^30) q12Shape5T102 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17432576 ||| 2^30) 33824256 q12Shape5T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T102OK,q12Shape5T107OK⟩

private def q12Shape5T112 : Tree 12 := (.tip (.cover {0,2,5,8,9,10,11}))
private theorem q12Shape5T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50987008 269824 q12Shape5T112=true := by decide

private def q12Shape5T100 : Tree 12 := .split 25 q12Shape5T101 q12Shape5T112
private theorem q12Shape5T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 269824 q12Shape5T100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17432576 (269824 ||| 2^25) q12Shape5T101 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (17432576 ||| 2^25) 269824 q12Shape5T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T101OK,q12Shape5T112OK⟩

private def q12Shape5T90 : Tree 12 := .split 24 q12Shape5T91 q12Shape5T100
private theorem q12Shape5T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 269824 q12Shape5T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 (269824 ||| 2^24) q12Shape5T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (655360 ||| 2^24) 269824 q12Shape5T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T91OK,q12Shape5T100OK⟩

def q12Shape5P4 : Tree 12 := q12Shape5T90
theorem q12Shape5P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 655360 269824 q12Shape5P4=true := q12Shape5T90OK

end Graffiti384b.EffectiveSearch.Q12
