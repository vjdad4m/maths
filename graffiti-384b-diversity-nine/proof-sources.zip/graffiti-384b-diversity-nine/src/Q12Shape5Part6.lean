import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T140 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 17174016 q12Shape5T140=true := by decide

private def q12Shape5T146 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11})))))))
private theorem q12Shape5T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 1650375659008 q12Shape5T146=true := by decide

private def q12Shape5T147 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099528409088 550864031232 q12Shape5T147=true := by decide

private def q12Shape5T145 : Tree 12 := .split 40 q12Shape5T146 q12Shape5T147
private theorem q12Shape5T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 550864031232 q12Shape5T145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 (550864031232 ||| 2^40) q12Shape5T146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16781312 ||| 2^40) 550864031232 q12Shape5T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T146OK,q12Shape5T147OK⟩

private def q12Shape5T148 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549772595200 1108217344 q12Shape5T148=true := by decide

private def q12Shape5T144 : Tree 12 := .split 39 q12Shape5T145 q12Shape5T148
private theorem q12Shape5T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 1108217344 q12Shape5T144=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 (1108217344 ||| 2^39) q12Shape5T145 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16781312 ||| 2^39) 1108217344 q12Shape5T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T145OK,q12Shape5T148OK⟩

private def q12Shape5T151 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090523136 1649301917184 q12Shape5T151=true := by decide

private def q12Shape5T152 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100602150912 549790289408 q12Shape5T152=true := by decide

private def q12Shape5T150 : Tree 12 := .split 40 q12Shape5T151 q12Shape5T152
private theorem q12Shape5T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090523136 549790289408 q12Shape5T150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090523136 (549790289408 ||| 2^40) q12Shape5T151 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1090523136 ||| 2^40) 549790289408 q12Shape5T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T151OK,q12Shape5T152OK⟩

private def q12Shape5T153 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550846337024 34475520 q12Shape5T153=true := by decide

private def q12Shape5T149 : Tree 12 := .split 39 q12Shape5T150 q12Shape5T153
private theorem q12Shape5T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090523136 34475520 q12Shape5T149=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1090523136 (34475520 ||| 2^39) q12Shape5T150 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1090523136 ||| 2^39) 34475520 q12Shape5T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T150OK,q12Shape5T153OK⟩

private def q12Shape5T143 : Tree 12 := .split 30 q12Shape5T144 q12Shape5T149
private theorem q12Shape5T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 34475520 q12Shape5T143=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 (34475520 ||| 2^30) q12Shape5T144 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16781312 ||| 2^30) 34475520 q12Shape5T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T144OK,q12Shape5T149OK⟩

private def q12Shape5T157 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50335744 1650342104576 q12Shape5T157=true := by decide

private def q12Shape5T158 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099561963520 550830476800 q12Shape5T158=true := by decide

private def q12Shape5T156 : Tree 12 := .split 40 q12Shape5T157 q12Shape5T158
private theorem q12Shape5T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50335744 550830476800 q12Shape5T156=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50335744 (550830476800 ||| 2^40) q12Shape5T157 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50335744 ||| 2^40) 550830476800 q12Shape5T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T157OK,q12Shape5T158OK⟩

private def q12Shape5T159 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549806149632 1074662912 q12Shape5T159=true := by decide

private def q12Shape5T155 : Tree 12 := .split 39 q12Shape5T156 q12Shape5T159
private theorem q12Shape5T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50335744 1074662912 q12Shape5T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50335744 (1074662912 ||| 2^39) q12Shape5T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50335744 ||| 2^39) 1074662912 q12Shape5T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T156OK,q12Shape5T159OK⟩

private def q12Shape5T160 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1124077568 921088 q12Shape5T160=true := by decide

private def q12Shape5T154 : Tree 12 := .split 30 q12Shape5T155 q12Shape5T160
private theorem q12Shape5T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50335744 921088 q12Shape5T154=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50335744 (921088 ||| 2^30) q12Shape5T155 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50335744 ||| 2^30) 921088 q12Shape5T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T155OK,q12Shape5T160OK⟩

private def q12Shape5T142 : Tree 12 := .split 25 q12Shape5T143 q12Shape5T154
private theorem q12Shape5T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 921088 q12Shape5T142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 (921088 ||| 2^25) q12Shape5T143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16781312 ||| 2^25) 921088 q12Shape5T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T143OK,q12Shape5T154OK⟩

private def q12Shape5T161 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape5T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17305600 396800 q12Shape5T161=true := by decide

private def q12Shape5T141 : Tree 12 := .split 19 q12Shape5T142 q12Shape5T161
private theorem q12Shape5T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 396800 q12Shape5T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16781312 (396800 ||| 2^19) q12Shape5T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (16781312 ||| 2^19) 396800 q12Shape5T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T142OK,q12Shape5T161OK⟩

private def q12Shape5T139 : Tree 12 := .split 24 q12Shape5T140 q12Shape5T141
private theorem q12Shape5T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 396800 q12Shape5T139=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 (396800 ||| 2^24) q12Shape5T140 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (4096 ||| 2^24) 396800 q12Shape5T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T140OK,q12Shape5T141OK⟩

def q12Shape5P6 : Tree 12 := q12Shape5T139
theorem q12Shape5P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 4096 396800 q12Shape5P6=true := q12Shape5T139OK

end Graffiti384b.EffectiveSearch.Q12
