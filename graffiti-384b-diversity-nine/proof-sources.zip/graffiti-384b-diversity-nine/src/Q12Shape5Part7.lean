import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T168 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11})))))))
private theorem q12Shape5T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 1650392174080 q12Shape5T168=true := by decide

private def q12Shape5T169 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511894016 550880546304 q12Shape5T169=true := by decide

private def q12Shape5T167 : Tree 12 := .split 40 q12Shape5T168 q12Shape5T169
private theorem q12Shape5T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 550880546304 q12Shape5T167=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 (550880546304 ||| 2^40) q12Shape5T168 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266240 ||| 2^40) 550880546304 q12Shape5T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T168OK,q12Shape5T169OK⟩

private def q12Shape5T170 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756080128 1124732416 q12Shape5T170=true := by decide

private def q12Shape5T166 : Tree 12 := .split 39 q12Shape5T167 q12Shape5T170
private theorem q12Shape5T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 1124732416 q12Shape5T166=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 (1124732416 ||| 2^39) q12Shape5T167 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266240 ||| 2^39) 1124732416 q12Shape5T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T167OK,q12Shape5T170OK⟩

private def q12Shape5T173 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008064 1649318432256 q12Shape5T173=true := by decide

private def q12Shape5T174 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100585635840 549806804480 q12Shape5T174=true := by decide

private def q12Shape5T172 : Tree 12 := .split 40 q12Shape5T173 q12Shape5T174
private theorem q12Shape5T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008064 549806804480 q12Shape5T172=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008064 (549806804480 ||| 2^40) q12Shape5T173 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074008064 ||| 2^40) 549806804480 q12Shape5T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T173OK,q12Shape5T174OK⟩

private def q12Shape5T175 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550829821952 50990592 q12Shape5T175=true := by decide

private def q12Shape5T171 : Tree 12 := .split 39 q12Shape5T172 q12Shape5T175
private theorem q12Shape5T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008064 50990592 q12Shape5T171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074008064 (50990592 ||| 2^39) q12Shape5T172 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1074008064 ||| 2^39) 50990592 q12Shape5T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T172OK,q12Shape5T175OK⟩

private def q12Shape5T165 : Tree 12 := .split 30 q12Shape5T166 q12Shape5T171
private theorem q12Shape5T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 50990592 q12Shape5T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 (50990592 ||| 2^30) q12Shape5T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266240 ||| 2^30) 50990592 q12Shape5T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T166OK,q12Shape5T171OK⟩

private def q12Shape5T176 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape5T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33820672 17436160 q12Shape5T176=true := by decide

private def q12Shape5T164 : Tree 12 := .split 25 q12Shape5T165 q12Shape5T176
private theorem q12Shape5T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 17436160 q12Shape5T164=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 (17436160 ||| 2^25) q12Shape5T165 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266240 ||| 2^25) 17436160 q12Shape5T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T165OK,q12Shape5T176OK⟩

private def q12Shape5T177 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17043456 658944 q12Shape5T177=true := by decide

private def q12Shape5T163 : Tree 12 := .split 24 q12Shape5T164 q12Shape5T177
private theorem q12Shape5T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 658944 q12Shape5T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 (658944 ||| 2^24) q12Shape5T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266240 ||| 2^24) 658944 q12Shape5T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T164OK,q12Shape5T177OK⟩

private def q12Shape5T183 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 1650391649792 q12Shape5T183=true := by decide

private def q12Shape5T184 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512418304 550880022016 q12Shape5T184=true := by decide

private def q12Shape5T182 : Tree 12 := .split 40 q12Shape5T183 q12Shape5T184
private theorem q12Shape5T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 550880022016 q12Shape5T182=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 (550880022016 ||| 2^40) q12Shape5T183 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (790528 ||| 2^40) 550880022016 q12Shape5T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T183OK,q12Shape5T184OK⟩

private def q12Shape5T185 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756604416 1124208128 q12Shape5T185=true := by decide

private def q12Shape5T181 : Tree 12 := .split 39 q12Shape5T182 q12Shape5T185
private theorem q12Shape5T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 1124208128 q12Shape5T181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 (1124208128 ||| 2^39) q12Shape5T182 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (790528 ||| 2^39) 1124208128 q12Shape5T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T182OK,q12Shape5T185OK⟩

private def q12Shape5T186 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape5T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34344960 1090653696 q12Shape5T186=true := by decide

private def q12Shape5T180 : Tree 12 := .split 25 q12Shape5T181 q12Shape5T186
private theorem q12Shape5T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 1090653696 q12Shape5T180=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 (1090653696 ||| 2^25) q12Shape5T181 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (790528 ||| 2^25) 1090653696 q12Shape5T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T181OK,q12Shape5T186OK⟩

private def q12Shape5T187 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074532352 16911872 q12Shape5T187=true := by decide

private def q12Shape5T179 : Tree 12 := .split 30 q12Shape5T180 q12Shape5T187
private theorem q12Shape5T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 16911872 q12Shape5T179=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 (16911872 ||| 2^30) q12Shape5T180 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (790528 ||| 2^30) 16911872 q12Shape5T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T180OK,q12Shape5T187OK⟩

private def q12Shape5T188 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,9,10}))) (.tip (.cover {0,1,3,6,8,9,11}))) (.tip (.cover {0,1,3,6,8,10,11})))
private theorem q12Shape5T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17567744 134656 q12Shape5T188=true := by decide

private def q12Shape5T178 : Tree 12 := .split 24 q12Shape5T179 q12Shape5T188
private theorem q12Shape5T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 134656 q12Shape5T178=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 790528 (134656 ||| 2^24) q12Shape5T179 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (790528 ||| 2^24) 134656 q12Shape5T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T179OK,q12Shape5T188OK⟩

private def q12Shape5T162 : Tree 12 := .split 19 q12Shape5T163 q12Shape5T178
private theorem q12Shape5T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 134656 q12Shape5T162=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 (134656 ||| 2^19) q12Shape5T163 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (266240 ||| 2^19) 134656 q12Shape5T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T163OK,q12Shape5T178OK⟩

def q12Shape5P7 : Tree 12 := q12Shape5T162
theorem q12Shape5P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 266240 134656 q12Shape5P7=true := q12Shape5T162OK

end Graffiti384b.EffectiveSearch.Q12
