import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T197 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))))))
private theorem q12Shape5T197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 1650392305152 q12Shape5T197=true := by decide

private def q12Shape5T198 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099511762944 550880677376 q12Shape5T198=true := by decide

private def q12Shape5T196 : Tree 12 := .split 40 q12Shape5T197 q12Shape5T198
private theorem q12Shape5T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 550880677376 q12Shape5T196=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 (550880677376 ||| 2^40) q12Shape5T197 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135168 ||| 2^40) 550880677376 q12Shape5T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T197OK,q12Shape5T198OK⟩

private def q12Shape5T199 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,3,8,9,10,11}))))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549755949056 1124863488 q12Shape5T199=true := by decide

private def q12Shape5T195 : Tree 12 := .split 39 q12Shape5T196 q12Shape5T199
private theorem q12Shape5T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 1124863488 q12Shape5T195=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 (1124863488 ||| 2^39) q12Shape5T196 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135168 ||| 2^39) 1124863488 q12Shape5T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T196OK,q12Shape5T199OK⟩

private def q12Shape5T200 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape5T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1073876992 51121664 q12Shape5T200=true := by decide

private def q12Shape5T194 : Tree 12 := .split 30 q12Shape5T195 q12Shape5T200
private theorem q12Shape5T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 51121664 q12Shape5T194=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 (51121664 ||| 2^30) q12Shape5T195 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135168 ||| 2^30) 51121664 q12Shape5T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T195OK,q12Shape5T200OK⟩

private def q12Shape5T204 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33689600 1650358750720 q12Shape5T204=true := by decide

private def q12Shape5T205 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545317376 550847122944 q12Shape5T205=true := by decide

private def q12Shape5T203 : Tree 12 := .split 40 q12Shape5T204 q12Shape5T205
private theorem q12Shape5T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33689600 550847122944 q12Shape5T203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33689600 (550847122944 ||| 2^40) q12Shape5T204 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33689600 ||| 2^40) 550847122944 q12Shape5T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T204OK,q12Shape5T205OK⟩

private def q12Shape5T206 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789503488 1091309056 q12Shape5T206=true := by decide

private def q12Shape5T202 : Tree 12 := .split 39 q12Shape5T203 q12Shape5T206
private theorem q12Shape5T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33689600 1091309056 q12Shape5T202=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33689600 (1091309056 ||| 2^39) q12Shape5T203 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33689600 ||| 2^39) 1091309056 q12Shape5T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T203OK,q12Shape5T206OK⟩

private def q12Shape5T207 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape5T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107431424 17567232 q12Shape5T207=true := by decide

private def q12Shape5T201 : Tree 12 := .split 30 q12Shape5T202 q12Shape5T207
private theorem q12Shape5T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33689600 17567232 q12Shape5T201=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33689600 (17567232 ||| 2^30) q12Shape5T202 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33689600 ||| 2^30) 17567232 q12Shape5T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T202OK,q12Shape5T207OK⟩

private def q12Shape5T193 : Tree 12 := .split 25 q12Shape5T194 q12Shape5T201
private theorem q12Shape5T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 17567232 q12Shape5T193=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 (17567232 ||| 2^25) q12Shape5T194 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135168 ||| 2^25) 17567232 q12Shape5T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T194OK,q12Shape5T201OK⟩

private def q12Shape5T208 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 16912384 790016 q12Shape5T208=true := by decide

private def q12Shape5T192 : Tree 12 := .split 24 q12Shape5T193 q12Shape5T208
private theorem q12Shape5T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 790016 q12Shape5T192=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 (790016 ||| 2^24) q12Shape5T193 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135168 ||| 2^24) 790016 q12Shape5T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T193OK,q12Shape5T208OK⟩

private def q12Shape5T214 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9}))))
private theorem q12Shape5T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 1650391780864 q12Shape5T214=true := by decide

private def q12Shape5T215 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,8,9}))) (.tip (.cover {0,1,3,4,6,10,11}))) (.tip (.cover {0,1,3,4,6,8,9})))
private theorem q12Shape5T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099512287232 550880153088 q12Shape5T215=true := by decide

private def q12Shape5T213 : Tree 12 := .split 40 q12Shape5T214 q12Shape5T215
private theorem q12Shape5T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 550880153088 q12Shape5T213=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 (550880153088 ||| 2^40) q12Shape5T214 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (659456 ||| 2^40) 550880153088 q12Shape5T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T214OK,q12Shape5T215OK⟩

private def q12Shape5T216 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,9,10}))) (.tip (.cover {0,1,3,4,6,9,11}))) (.tip (.cover {0,1,3,4,6,8,10}))) (.tip (.cover {0,1,3,4,6,8,11})))
private theorem q12Shape5T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549756473344 1124339200 q12Shape5T216=true := by decide

private def q12Shape5T212 : Tree 12 := .split 39 q12Shape5T213 q12Shape5T216
private theorem q12Shape5T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 1124339200 q12Shape5T212=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 (1124339200 ||| 2^39) q12Shape5T213 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (659456 ||| 2^39) 1124339200 q12Shape5T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T213OK,q12Shape5T216OK⟩

private def q12Shape5T217 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape5T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1074401280 50597376 q12Shape5T217=true := by decide

private def q12Shape5T211 : Tree 12 := .split 30 q12Shape5T212 q12Shape5T217
private theorem q12Shape5T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 50597376 q12Shape5T211=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 (50597376 ||| 2^30) q12Shape5T212 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (659456 ||| 2^30) 50597376 q12Shape5T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T212OK,q12Shape5T217OK⟩

private def q12Shape5T218 : Tree 12 := (.tip (.cover {0,2,7,8,9,10,11}))
private theorem q12Shape5T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 34213888 17042944 q12Shape5T218=true := by decide

private def q12Shape5T210 : Tree 12 := .split 25 q12Shape5T211 q12Shape5T218
private theorem q12Shape5T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 17042944 q12Shape5T210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 (17042944 ||| 2^25) q12Shape5T211 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (659456 ||| 2^25) 17042944 q12Shape5T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T211OK,q12Shape5T218OK⟩

private def q12Shape5T219 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,9,10}))) (.tip (.cover {0,1,3,5,8,9,11}))) (.tip (.cover {0,1,3,5,8,10,11})))
private theorem q12Shape5T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 17436672 265728 q12Shape5T219=true := by decide

private def q12Shape5T209 : Tree 12 := .split 24 q12Shape5T210 q12Shape5T219
private theorem q12Shape5T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 265728 q12Shape5T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 659456 (265728 ||| 2^24) q12Shape5T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (659456 ||| 2^24) 265728 q12Shape5T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T210OK,q12Shape5T219OK⟩

private def q12Shape5T191 : Tree 12 := .split 19 q12Shape5T192 q12Shape5T209
private theorem q12Shape5T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 265728 q12Shape5T191=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 (265728 ||| 2^19) q12Shape5T192 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135168 ||| 2^19) 265728 q12Shape5T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T192OK,q12Shape5T209OK⟩

private def q12Shape5T220 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,8,9,11}))) (.tip (.cover {0,1,3,4,8,10,11})))
private theorem q12Shape5T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 397312 3584 q12Shape5T220=true := by decide

private def q12Shape5T190 : Tree 12 := .split 18 q12Shape5T191 q12Shape5T220
private theorem q12Shape5T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 3584 q12Shape5T190=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 (3584 ||| 2^18) q12Shape5T191 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (135168 ||| 2^18) 3584 q12Shape5T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T191OK,q12Shape5T220OK⟩

def q12Shape5P8 : Tree 12 := q12Shape5T190
theorem q12Shape5P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 135168 3584 q12Shape5P8=true := q12Shape5T190OK

end Graffiti384b.EffectiveSearch.Q12
