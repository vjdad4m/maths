import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape5T224 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape5T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 34477568 q12Shape5T224=true := by decide

private def q12Shape5T229 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))))
private theorem q12Shape5T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 1650358883840 q12Shape5T229=true := by decide

private def q12Shape5T230 : Tree 12 := (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099545184256 550847256064 q12Shape5T230=true := by decide

private def q12Shape5T228 : Tree 12 := .split 40 q12Shape5T229 q12Shape5T230
private theorem q12Shape5T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 550847256064 q12Shape5T228=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 (550847256064 ||| 2^40) q12Shape5T229 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33556480 ||| 2^40) 550847256064 q12Shape5T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T229OK,q12Shape5T230OK⟩

private def q12Shape5T231 : Tree 12 := (.split 40 (.split 41 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,5,8,9,10,11})))))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549789370368 1091442176 q12Shape5T231=true := by decide

private def q12Shape5T227 : Tree 12 := .split 39 q12Shape5T228 q12Shape5T231
private theorem q12Shape5T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 1091442176 q12Shape5T227=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 (1091442176 ||| 2^39) q12Shape5T228 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33556480 ||| 2^39) 1091442176 q12Shape5T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T228OK,q12Shape5T231OK⟩

private def q12Shape5T234 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107298304 1649285142016 q12Shape5T234=true := by decide

private def q12Shape5T235 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1100618926080 549773514240 q12Shape5T235=true := by decide

private def q12Shape5T233 : Tree 12 := .split 40 q12Shape5T234 q12Shape5T235
private theorem q12Shape5T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107298304 549773514240 q12Shape5T233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107298304 (549773514240 ||| 2^40) q12Shape5T234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1107298304 ||| 2^40) 549773514240 q12Shape5T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T234OK,q12Shape5T235OK⟩

private def q12Shape5T236 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 550863112192 17700352 q12Shape5T236=true := by decide

private def q12Shape5T232 : Tree 12 := .split 39 q12Shape5T233 q12Shape5T236
private theorem q12Shape5T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107298304 17700352 q12Shape5T232=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1107298304 (17700352 ||| 2^39) q12Shape5T233 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (1107298304 ||| 2^39) 17700352 q12Shape5T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T233OK,q12Shape5T236OK⟩

private def q12Shape5T226 : Tree 12 := .split 30 q12Shape5T227 q12Shape5T232
private theorem q12Shape5T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 17700352 q12Shape5T226=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 (17700352 ||| 2^30) q12Shape5T227 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33556480 ||| 2^30) 17700352 q12Shape5T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T227OK,q12Shape5T232OK⟩

private def q12Shape5T240 : Tree 12 := (.split 41 (.split 42 (.tip (.small 1)) (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9})))) (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9}))))
private theorem q12Shape5T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333696 1650342106624 q12Shape5T240=true := by decide

private def q12Shape5T241 : Tree 12 := (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,8,9}))) (.tip (.cover {0,1,3,4,5,10,11}))) (.tip (.cover {0,1,3,4,5,8,9})))
private theorem q12Shape5T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1099561961472 550830478848 q12Shape5T241=true := by decide

private def q12Shape5T239 : Tree 12 := .split 40 q12Shape5T240 q12Shape5T241
private theorem q12Shape5T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333696 550830478848 q12Shape5T239=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333696 (550830478848 ||| 2^40) q12Shape5T240 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50333696 ||| 2^40) 550830478848 q12Shape5T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T240OK,q12Shape5T241OK⟩

private def q12Shape5T242 : Tree 12 := (.split 40 (.split 41 (.split 42 (.split 43 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,9,10}))) (.tip (.cover {0,1,3,4,5,9,11}))) (.tip (.cover {0,1,3,4,5,8,10}))) (.tip (.cover {0,1,3,4,5,8,11})))
private theorem q12Shape5T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 549806147584 1074664960 q12Shape5T242=true := by decide

private def q12Shape5T238 : Tree 12 := .split 39 q12Shape5T239 q12Shape5T242
private theorem q12Shape5T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333696 1074664960 q12Shape5T238=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333696 (1074664960 ||| 2^39) q12Shape5T239 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50333696 ||| 2^39) 1074664960 q12Shape5T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T239OK,q12Shape5T242OK⟩

private def q12Shape5T243 : Tree 12 := (.tip (.cover {0,2,6,8,9,10,11}))
private theorem q12Shape5T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 1124075520 923136 q12Shape5T243=true := by decide

private def q12Shape5T237 : Tree 12 := .split 30 q12Shape5T238 q12Shape5T243
private theorem q12Shape5T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333696 923136 q12Shape5T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 50333696 (923136 ||| 2^30) q12Shape5T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (50333696 ||| 2^30) 923136 q12Shape5T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T238OK,q12Shape5T243OK⟩

private def q12Shape5T225 : Tree 12 := .split 24 q12Shape5T226 q12Shape5T237
private theorem q12Shape5T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 923136 q12Shape5T225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 33556480 (923136 ||| 2^24) q12Shape5T226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (33556480 ||| 2^24) 923136 q12Shape5T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T226OK,q12Shape5T237OK⟩

private def q12Shape5T223 : Tree 12 := .split 25 q12Shape5T224 q12Shape5T225
private theorem q12Shape5T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 923136 q12Shape5T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 (923136 ||| 2^25) q12Shape5T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) (2048 ||| 2^25) 923136 q12Shape5T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape5T224OK,q12Shape5T225OK⟩

def q12Shape5P9 : Tree 12 := q12Shape5T223
theorem q12Shape5P9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,1⟩) 2048 923136 q12Shape5P9=true := q12Shape5T223OK

end Graffiti384b.EffectiveSearch.Q12
