import Q12Shape6Part0
import Q12Shape6Part1
import Q12Shape6Part2
import Q12Shape6Part3
import Q12Shape6Part4
import Q12Shape6Part5
import Q12Shape6Part6
import Q12Shape6Part7
import Q12Shape6Part8

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6M66 : Tree 12 := .split 25 q12Shape6P0 q12Shape6P1
private theorem q12Shape6M66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 17694720 q12Shape6M66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 (17694720 ||| 2^25) q12Shape6P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (0 ||| 2^25) 17694720 q12Shape6P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6P0OK,q12Shape6P1OK⟩
private def q12Shape6M104 : Tree 12 := .split 24 q12Shape6M66 q12Shape6P2
private theorem q12Shape6M104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 917504 q12Shape6M104=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 (917504 ||| 2^24) q12Shape6M66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (0 ||| 2^24) 917504 q12Shape6P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6M66OK,q12Shape6P2OK⟩
private def q12Shape6M145 : Tree 12 := .split 24 q12Shape6P3 q12Shape6P4
private theorem q12Shape6M145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 393216 q12Shape6M145=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 (393216 ||| 2^24) q12Shape6P3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (524288 ||| 2^24) 393216 q12Shape6P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6P3OK,q12Shape6P4OK⟩
private def q12Shape6M146 : Tree 12 := .split 19 q12Shape6M104 q12Shape6M145
private theorem q12Shape6M146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 393216 q12Shape6M146=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 (393216 ||| 2^19) q12Shape6M104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (0 ||| 2^19) 393216 q12Shape6M145)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6M104OK,q12Shape6M145OK⟩
private def q12Shape6M187 : Tree 12 := .split 24 q12Shape6P5 q12Shape6P6
private theorem q12Shape6M187OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 655360 q12Shape6M187=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 (655360 ||| 2^24) q12Shape6P5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (262144 ||| 2^24) 655360 q12Shape6P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6P5OK,q12Shape6P6OK⟩
private def q12Shape6M197 : Tree 12 := .split 19 q12Shape6M187 q12Shape6P7
private theorem q12Shape6M197OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 131072 q12Shape6M197=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 (131072 ||| 2^19) q12Shape6M187 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (262144 ||| 2^19) 131072 q12Shape6P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6M187OK,q12Shape6P7OK⟩
private def q12Shape6M198 : Tree 12 := .split 18 q12Shape6M146 q12Shape6M197
private theorem q12Shape6M198OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 131072 q12Shape6M198=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 (131072 ||| 2^18) q12Shape6M146 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (0 ||| 2^18) 131072 q12Shape6M197)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6M146OK,q12Shape6M197OK⟩
private def q12Shape6M241 : Tree 12 := .split 24 q12Shape6P8 q12Shape6P9
private theorem q12Shape6M241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 786432 q12Shape6M241=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (786432 ||| 2^24) q12Shape6P8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^24) 786432 q12Shape6P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6P8OK,q12Shape6P9OK⟩
private def q12Shape6M253 : Tree 12 := .split 19 q12Shape6M241 q12Shape6P10
private theorem q12Shape6M253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 262144 q12Shape6M253=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (262144 ||| 2^19) q12Shape6M241 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^19) 262144 q12Shape6P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6M241OK,q12Shape6P10OK⟩
private def q12Shape6M267 : Tree 12 := .split 18 q12Shape6M253 q12Shape6P11
private theorem q12Shape6M267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 0 q12Shape6M267=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (0 ||| 2^18) q12Shape6M253 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^18) 0 q12Shape6P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6M253OK,q12Shape6P11OK⟩
private def q12Shape6M268 : Tree 12 := .split 17 q12Shape6M198 q12Shape6M267
private theorem q12Shape6M268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 0 q12Shape6M268=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 0 (0 ||| 2^17) q12Shape6M198 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (0 ||| 2^17) 0 q12Shape6M267)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6M198OK,q12Shape6M267OK⟩

theorem q12Shape6_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 6) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 6) b) (adj 12 (forms 6) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) adj_mono b H q12Shape6M268 q12Shape6M268OK

#print axioms q12Shape6_cover

end Graffiti384b.EffectiveSearch.Q12
