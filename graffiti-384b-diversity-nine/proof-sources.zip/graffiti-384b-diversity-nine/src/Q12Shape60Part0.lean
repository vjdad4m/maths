import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape60T6 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape60T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 3472883712 q12Shape60T6=true := by decide

private def q12Shape60T7 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape60T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 2147483648 1325400064 q12Shape60T7=true := by decide

private def q12Shape60T5 : Tree 12 := .split 31 q12Shape60T6 q12Shape60T7
private theorem q12Shape60T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 1325400064 q12Shape60T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 (1325400064 ||| 2^31) q12Shape60T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (0 ||| 2^31) 1325400064 q12Shape60T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T6OK,q12Shape60T7OK⟩

private def q12Shape60T8 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape60T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 1073741824 251658240 q12Shape60T8=true := by decide

private def q12Shape60T4 : Tree 12 := .split 30 q12Shape60T5 q12Shape60T8
private theorem q12Shape60T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 251658240 q12Shape60T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 (251658240 ||| 2^30) q12Shape60T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (0 ||| 2^30) 251658240 q12Shape60T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T5OK,q12Shape60T8OK⟩

private def q12Shape60T9 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape60T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 134217728 117440512 q12Shape60T9=true := by decide

private def q12Shape60T3 : Tree 12 := .split 27 q12Shape60T4 q12Shape60T9
private theorem q12Shape60T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 117440512 q12Shape60T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 (117440512 ||| 2^27) q12Shape60T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (0 ||| 2^27) 117440512 q12Shape60T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T4OK,q12Shape60T9OK⟩

private def q12Shape60T10 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape60T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 67108864 50331648 q12Shape60T10=true := by decide

private def q12Shape60T2 : Tree 12 := .split 26 q12Shape60T3 q12Shape60T10
private theorem q12Shape60T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 50331648 q12Shape60T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 (50331648 ||| 2^26) q12Shape60T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (0 ||| 2^26) 50331648 q12Shape60T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T3OK,q12Shape60T10OK⟩

private def q12Shape60T12 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape60T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 33554432 83886080 q12Shape60T12=true := by decide

private def q12Shape60T13 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape60T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 100663296 16777216 q12Shape60T13=true := by decide

private def q12Shape60T11 : Tree 12 := .split 26 q12Shape60T12 q12Shape60T13
private theorem q12Shape60T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 33554432 16777216 q12Shape60T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 33554432 (16777216 ||| 2^26) q12Shape60T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (33554432 ||| 2^26) 16777216 q12Shape60T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T12OK,q12Shape60T13OK⟩

private def q12Shape60T1 : Tree 12 := .split 25 q12Shape60T2 q12Shape60T11
private theorem q12Shape60T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 16777216 q12Shape60T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 (16777216 ||| 2^25) q12Shape60T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (0 ||| 2^25) 16777216 q12Shape60T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T2OK,q12Shape60T11OK⟩

private def q12Shape60T16 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape60T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 16777216 100663296 q12Shape60T16=true := by decide

private def q12Shape60T17 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape60T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 83886080 33554432 q12Shape60T17=true := by decide

private def q12Shape60T15 : Tree 12 := .split 26 q12Shape60T16 q12Shape60T17
private theorem q12Shape60T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 16777216 33554432 q12Shape60T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 16777216 (33554432 ||| 2^26) q12Shape60T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (16777216 ||| 2^26) 33554432 q12Shape60T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T16OK,q12Shape60T17OK⟩

private def q12Shape60T18 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape60T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 50331648 0 q12Shape60T18=true := by decide

private def q12Shape60T14 : Tree 12 := .split 25 q12Shape60T15 q12Shape60T18
private theorem q12Shape60T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 16777216 0 q12Shape60T14=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 16777216 (0 ||| 2^25) q12Shape60T15 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (16777216 ||| 2^25) 0 q12Shape60T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T15OK,q12Shape60T18OK⟩

private def q12Shape60T0 : Tree 12 := .split 24 q12Shape60T1 q12Shape60T14
private theorem q12Shape60T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 0 q12Shape60T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 (0 ||| 2^24) q12Shape60T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) (0 ||| 2^24) 0 q12Shape60T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape60T1OK,q12Shape60T14OK⟩

def q12Shape60P0 : Tree 12 := q12Shape60T0
theorem q12Shape60P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,5,3⟩) 0 0 q12Shape60P0=true := q12Shape60T0OK

end Graffiti384b.EffectiveSearch.Q12
