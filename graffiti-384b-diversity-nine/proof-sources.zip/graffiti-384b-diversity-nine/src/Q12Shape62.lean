import Q12Shape62Part0
import Q12Shape62Part1
import Q12Shape62Part2
import Q12Shape62Part3

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape62M78 : Tree 12 := .split 1 q12Shape62P0 q12Shape62P1
private theorem q12Shape62M78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 1 q12Shape62M78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (1 ||| 2^1) q12Shape62P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^1) 1 q12Shape62P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62P0OK,q12Shape62P1OK⟩
private def q12Shape62M157 : Tree 12 := .split 1 q12Shape62P2 q12Shape62P3
private theorem q12Shape62M157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1 0 q12Shape62M157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1 (0 ||| 2^1) q12Shape62P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (1 ||| 2^1) 0 q12Shape62P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62P2OK,q12Shape62P3OK⟩
private def q12Shape62M158 : Tree 12 := .split 0 q12Shape62M78 q12Shape62M157
private theorem q12Shape62M158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 0 q12Shape62M158=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (0 ||| 2^0) q12Shape62M78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^0) 0 q12Shape62M157)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62M78OK,q12Shape62M157OK⟩

theorem q12Shape62_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 62) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 62) b) (adj 12 (forms 62) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) adj_mono b H q12Shape62M158 q12Shape62M158OK

#print axioms q12Shape62_cover

end Graffiti384b.EffectiveSearch.Q12
