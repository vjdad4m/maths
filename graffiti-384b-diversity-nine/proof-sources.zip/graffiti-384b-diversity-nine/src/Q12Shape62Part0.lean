import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape62T7 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape62T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 3472884227 q12Shape62T7=true := by decide

private def q12Shape62T8 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2147483648 1325400579 q12Shape62T8=true := by decide

private def q12Shape62T6 : Tree 12 := .split 31 q12Shape62T7 q12Shape62T8
private theorem q12Shape62T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 1325400579 q12Shape62T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (1325400579 ||| 2^31) q12Shape62T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^31) 1325400579 q12Shape62T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T7OK,q12Shape62T8OK⟩

private def q12Shape62T9 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape62T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1073741824 251658755 q12Shape62T9=true := by decide

private def q12Shape62T5 : Tree 12 := .split 30 q12Shape62T6 q12Shape62T9
private theorem q12Shape62T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 251658755 q12Shape62T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (251658755 ||| 2^30) q12Shape62T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^30) 251658755 q12Shape62T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T6OK,q12Shape62T9OK⟩

private def q12Shape62T10 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 134217728 117441027 q12Shape62T10=true := by decide

private def q12Shape62T4 : Tree 12 := .split 27 q12Shape62T5 q12Shape62T10
private theorem q12Shape62T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 117441027 q12Shape62T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (117441027 ||| 2^27) q12Shape62T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^27) 117441027 q12Shape62T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T5OK,q12Shape62T10OK⟩

private def q12Shape62T11 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 67108864 50332163 q12Shape62T11=true := by decide

private def q12Shape62T3 : Tree 12 := .split 26 q12Shape62T4 q12Shape62T11
private theorem q12Shape62T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 50332163 q12Shape62T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (50332163 ||| 2^26) q12Shape62T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^26) 50332163 q12Shape62T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T4OK,q12Shape62T11OK⟩

private def q12Shape62T13 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554432 83886595 q12Shape62T13=true := by decide

private def q12Shape62T14 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape62T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 100663296 16777731 q12Shape62T14=true := by decide

private def q12Shape62T12 : Tree 12 := .split 26 q12Shape62T13 q12Shape62T14
private theorem q12Shape62T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554432 16777731 q12Shape62T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554432 (16777731 ||| 2^26) q12Shape62T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (33554432 ||| 2^26) 16777731 q12Shape62T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T13OK,q12Shape62T14OK⟩

private def q12Shape62T2 : Tree 12 := .split 25 q12Shape62T3 q12Shape62T12
private theorem q12Shape62T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 16777731 q12Shape62T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (16777731 ||| 2^25) q12Shape62T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^25) 16777731 q12Shape62T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T3OK,q12Shape62T12OK⟩

private def q12Shape62T17 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape62T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777216 100663811 q12Shape62T17=true := by decide

private def q12Shape62T18 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape62T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 83886080 33554947 q12Shape62T18=true := by decide

private def q12Shape62T16 : Tree 12 := .split 26 q12Shape62T17 q12Shape62T18
private theorem q12Shape62T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777216 33554947 q12Shape62T16=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777216 (33554947 ||| 2^26) q12Shape62T17 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777216 ||| 2^26) 33554947 q12Shape62T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T17OK,q12Shape62T18OK⟩

private def q12Shape62T19 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape62T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 50331648 515 q12Shape62T19=true := by decide

private def q12Shape62T15 : Tree 12 := .split 25 q12Shape62T16 q12Shape62T19
private theorem q12Shape62T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777216 515 q12Shape62T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777216 (515 ||| 2^25) q12Shape62T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777216 ||| 2^25) 515 q12Shape62T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T16OK,q12Shape62T19OK⟩

private def q12Shape62T1 : Tree 12 := .split 24 q12Shape62T2 q12Shape62T15
private theorem q12Shape62T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 515 q12Shape62T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (515 ||| 2^24) q12Shape62T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^24) 515 q12Shape62T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T2OK,q12Shape62T15OK⟩

private def q12Shape62T26 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape62T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 3472883715 q12Shape62T26=true := by decide

private def q12Shape62T27 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2147484160 1325400067 q12Shape62T27=true := by decide

private def q12Shape62T25 : Tree 12 := .split 31 q12Shape62T26 q12Shape62T27
private theorem q12Shape62T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 1325400067 q12Shape62T25=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 (1325400067 ||| 2^31) q12Shape62T26 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (512 ||| 2^31) 1325400067 q12Shape62T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T26OK,q12Shape62T27OK⟩

private def q12Shape62T28 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape62T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1073742336 251658243 q12Shape62T28=true := by decide

private def q12Shape62T24 : Tree 12 := .split 30 q12Shape62T25 q12Shape62T28
private theorem q12Shape62T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 251658243 q12Shape62T24=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 (251658243 ||| 2^30) q12Shape62T25 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (512 ||| 2^30) 251658243 q12Shape62T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T25OK,q12Shape62T28OK⟩

private def q12Shape62T29 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 134218240 117440515 q12Shape62T29=true := by decide

private def q12Shape62T23 : Tree 12 := .split 27 q12Shape62T24 q12Shape62T29
private theorem q12Shape62T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 117440515 q12Shape62T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 (117440515 ||| 2^27) q12Shape62T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (512 ||| 2^27) 117440515 q12Shape62T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T24OK,q12Shape62T29OK⟩

private def q12Shape62T30 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 67109376 50331651 q12Shape62T30=true := by decide

private def q12Shape62T22 : Tree 12 := .split 26 q12Shape62T23 q12Shape62T30
private theorem q12Shape62T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 50331651 q12Shape62T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 (50331651 ||| 2^26) q12Shape62T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (512 ||| 2^26) 50331651 q12Shape62T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T23OK,q12Shape62T30OK⟩

private def q12Shape62T32 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554944 83886083 q12Shape62T32=true := by decide

private def q12Shape62T33 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape62T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 100663808 16777219 q12Shape62T33=true := by decide

private def q12Shape62T31 : Tree 12 := .split 26 q12Shape62T32 q12Shape62T33
private theorem q12Shape62T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554944 16777219 q12Shape62T31=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554944 (16777219 ||| 2^26) q12Shape62T32 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (33554944 ||| 2^26) 16777219 q12Shape62T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T32OK,q12Shape62T33OK⟩

private def q12Shape62T21 : Tree 12 := .split 25 q12Shape62T22 q12Shape62T31
private theorem q12Shape62T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 16777219 q12Shape62T21=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 (16777219 ||| 2^25) q12Shape62T22 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (512 ||| 2^25) 16777219 q12Shape62T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T22OK,q12Shape62T31OK⟩

private def q12Shape62T36 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape62T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777728 100663299 q12Shape62T36=true := by decide

private def q12Shape62T37 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape62T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 83886592 33554435 q12Shape62T37=true := by decide

private def q12Shape62T35 : Tree 12 := .split 26 q12Shape62T36 q12Shape62T37
private theorem q12Shape62T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777728 33554435 q12Shape62T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777728 (33554435 ||| 2^26) q12Shape62T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777728 ||| 2^26) 33554435 q12Shape62T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T36OK,q12Shape62T37OK⟩

private def q12Shape62T38 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape62T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 50332160 3 q12Shape62T38=true := by decide

private def q12Shape62T34 : Tree 12 := .split 25 q12Shape62T35 q12Shape62T38
private theorem q12Shape62T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777728 3 q12Shape62T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777728 (3 ||| 2^25) q12Shape62T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777728 ||| 2^25) 3 q12Shape62T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T35OK,q12Shape62T38OK⟩

private def q12Shape62T20 : Tree 12 := .split 24 q12Shape62T21 q12Shape62T34
private theorem q12Shape62T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 3 q12Shape62T20=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 512 (3 ||| 2^24) q12Shape62T21 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (512 ||| 2^24) 3 q12Shape62T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T21OK,q12Shape62T34OK⟩

private def q12Shape62T0 : Tree 12 := .split 9 q12Shape62T1 q12Shape62T20
private theorem q12Shape62T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 3 q12Shape62T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 (3 ||| 2^9) q12Shape62T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (0 ||| 2^9) 3 q12Shape62T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T1OK,q12Shape62T20OK⟩

def q12Shape62P0 : Tree 12 := q12Shape62T0
theorem q12Shape62P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 0 3 q12Shape62P0=true := q12Shape62T0OK

end Graffiti384b.EffectiveSearch.Q12
