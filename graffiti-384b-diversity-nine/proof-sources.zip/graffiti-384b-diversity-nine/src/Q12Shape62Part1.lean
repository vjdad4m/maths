import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape62T46 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape62T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 3472884225 q12Shape62T46=true := by decide

private def q12Shape62T47 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2147483650 1325400577 q12Shape62T47=true := by decide

private def q12Shape62T45 : Tree 12 := .split 31 q12Shape62T46 q12Shape62T47
private theorem q12Shape62T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 1325400577 q12Shape62T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 (1325400577 ||| 2^31) q12Shape62T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (2 ||| 2^31) 1325400577 q12Shape62T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T46OK,q12Shape62T47OK⟩

private def q12Shape62T48 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape62T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1073741826 251658753 q12Shape62T48=true := by decide

private def q12Shape62T44 : Tree 12 := .split 30 q12Shape62T45 q12Shape62T48
private theorem q12Shape62T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 251658753 q12Shape62T44=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 (251658753 ||| 2^30) q12Shape62T45 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (2 ||| 2^30) 251658753 q12Shape62T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T45OK,q12Shape62T48OK⟩

private def q12Shape62T49 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 134217730 117441025 q12Shape62T49=true := by decide

private def q12Shape62T43 : Tree 12 := .split 27 q12Shape62T44 q12Shape62T49
private theorem q12Shape62T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 117441025 q12Shape62T43=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 (117441025 ||| 2^27) q12Shape62T44 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (2 ||| 2^27) 117441025 q12Shape62T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T44OK,q12Shape62T49OK⟩

private def q12Shape62T50 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 67108866 50332161 q12Shape62T50=true := by decide

private def q12Shape62T42 : Tree 12 := .split 26 q12Shape62T43 q12Shape62T50
private theorem q12Shape62T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 50332161 q12Shape62T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 (50332161 ||| 2^26) q12Shape62T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (2 ||| 2^26) 50332161 q12Shape62T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T43OK,q12Shape62T50OK⟩

private def q12Shape62T52 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554434 83886593 q12Shape62T52=true := by decide

private def q12Shape62T53 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape62T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 100663298 16777729 q12Shape62T53=true := by decide

private def q12Shape62T51 : Tree 12 := .split 26 q12Shape62T52 q12Shape62T53
private theorem q12Shape62T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554434 16777729 q12Shape62T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554434 (16777729 ||| 2^26) q12Shape62T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (33554434 ||| 2^26) 16777729 q12Shape62T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T52OK,q12Shape62T53OK⟩

private def q12Shape62T41 : Tree 12 := .split 25 q12Shape62T42 q12Shape62T51
private theorem q12Shape62T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 16777729 q12Shape62T41=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 (16777729 ||| 2^25) q12Shape62T42 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (2 ||| 2^25) 16777729 q12Shape62T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T42OK,q12Shape62T51OK⟩

private def q12Shape62T56 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape62T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777218 100663809 q12Shape62T56=true := by decide

private def q12Shape62T57 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape62T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 83886082 33554945 q12Shape62T57=true := by decide

private def q12Shape62T55 : Tree 12 := .split 26 q12Shape62T56 q12Shape62T57
private theorem q12Shape62T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777218 33554945 q12Shape62T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777218 (33554945 ||| 2^26) q12Shape62T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777218 ||| 2^26) 33554945 q12Shape62T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T56OK,q12Shape62T57OK⟩

private def q12Shape62T58 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape62T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 50331650 513 q12Shape62T58=true := by decide

private def q12Shape62T54 : Tree 12 := .split 25 q12Shape62T55 q12Shape62T58
private theorem q12Shape62T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777218 513 q12Shape62T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777218 (513 ||| 2^25) q12Shape62T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777218 ||| 2^25) 513 q12Shape62T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T55OK,q12Shape62T58OK⟩

private def q12Shape62T40 : Tree 12 := .split 24 q12Shape62T41 q12Shape62T54
private theorem q12Shape62T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 513 q12Shape62T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 (513 ||| 2^24) q12Shape62T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (2 ||| 2^24) 513 q12Shape62T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T41OK,q12Shape62T54OK⟩

private def q12Shape62T65 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape62T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 3472883713 q12Shape62T65=true := by decide

private def q12Shape62T66 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2147484162 1325400065 q12Shape62T66=true := by decide

private def q12Shape62T64 : Tree 12 := .split 31 q12Shape62T65 q12Shape62T66
private theorem q12Shape62T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 1325400065 q12Shape62T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 (1325400065 ||| 2^31) q12Shape62T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (514 ||| 2^31) 1325400065 q12Shape62T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T65OK,q12Shape62T66OK⟩

private def q12Shape62T67 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape62T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1073742338 251658241 q12Shape62T67=true := by decide

private def q12Shape62T63 : Tree 12 := .split 30 q12Shape62T64 q12Shape62T67
private theorem q12Shape62T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 251658241 q12Shape62T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 (251658241 ||| 2^30) q12Shape62T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (514 ||| 2^30) 251658241 q12Shape62T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T64OK,q12Shape62T67OK⟩

private def q12Shape62T68 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 134218242 117440513 q12Shape62T68=true := by decide

private def q12Shape62T62 : Tree 12 := .split 27 q12Shape62T63 q12Shape62T68
private theorem q12Shape62T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 117440513 q12Shape62T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 (117440513 ||| 2^27) q12Shape62T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (514 ||| 2^27) 117440513 q12Shape62T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T63OK,q12Shape62T68OK⟩

private def q12Shape62T69 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 67109378 50331649 q12Shape62T69=true := by decide

private def q12Shape62T61 : Tree 12 := .split 26 q12Shape62T62 q12Shape62T69
private theorem q12Shape62T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 50331649 q12Shape62T61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 (50331649 ||| 2^26) q12Shape62T62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (514 ||| 2^26) 50331649 q12Shape62T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T62OK,q12Shape62T69OK⟩

private def q12Shape62T71 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554946 83886081 q12Shape62T71=true := by decide

private def q12Shape62T72 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape62T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 100663810 16777217 q12Shape62T72=true := by decide

private def q12Shape62T70 : Tree 12 := .split 26 q12Shape62T71 q12Shape62T72
private theorem q12Shape62T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554946 16777217 q12Shape62T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554946 (16777217 ||| 2^26) q12Shape62T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (33554946 ||| 2^26) 16777217 q12Shape62T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T71OK,q12Shape62T72OK⟩

private def q12Shape62T60 : Tree 12 := .split 25 q12Shape62T61 q12Shape62T70
private theorem q12Shape62T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 16777217 q12Shape62T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 (16777217 ||| 2^25) q12Shape62T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (514 ||| 2^25) 16777217 q12Shape62T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T61OK,q12Shape62T70OK⟩

private def q12Shape62T75 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape62T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777730 100663297 q12Shape62T75=true := by decide

private def q12Shape62T76 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape62T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 83886594 33554433 q12Shape62T76=true := by decide

private def q12Shape62T74 : Tree 12 := .split 26 q12Shape62T75 q12Shape62T76
private theorem q12Shape62T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777730 33554433 q12Shape62T74=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777730 (33554433 ||| 2^26) q12Shape62T75 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777730 ||| 2^26) 33554433 q12Shape62T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T75OK,q12Shape62T76OK⟩

private def q12Shape62T77 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape62T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 50332162 1 q12Shape62T77=true := by decide

private def q12Shape62T73 : Tree 12 := .split 25 q12Shape62T74 q12Shape62T77
private theorem q12Shape62T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777730 1 q12Shape62T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777730 (1 ||| 2^25) q12Shape62T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777730 ||| 2^25) 1 q12Shape62T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T74OK,q12Shape62T77OK⟩

private def q12Shape62T59 : Tree 12 := .split 24 q12Shape62T60 q12Shape62T73
private theorem q12Shape62T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 1 q12Shape62T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 514 (1 ||| 2^24) q12Shape62T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (514 ||| 2^24) 1 q12Shape62T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T60OK,q12Shape62T73OK⟩

private def q12Shape62T39 : Tree 12 := .split 9 q12Shape62T40 q12Shape62T59
private theorem q12Shape62T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 1 q12Shape62T39=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 (1 ||| 2^9) q12Shape62T40 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (2 ||| 2^9) 1 q12Shape62T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T40OK,q12Shape62T59OK⟩

def q12Shape62P1 : Tree 12 := q12Shape62T39
theorem q12Shape62P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2 1 q12Shape62P1=true := q12Shape62T39OK

end Graffiti384b.EffectiveSearch.Q12
