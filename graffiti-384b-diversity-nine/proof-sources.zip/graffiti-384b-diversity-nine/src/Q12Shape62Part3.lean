import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape62T125 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape62T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 3472884224 q12Shape62T125=true := by decide

private def q12Shape62T126 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2147483651 1325400576 q12Shape62T126=true := by decide

private def q12Shape62T124 : Tree 12 := .split 31 q12Shape62T125 q12Shape62T126
private theorem q12Shape62T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 1325400576 q12Shape62T124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 (1325400576 ||| 2^31) q12Shape62T125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (3 ||| 2^31) 1325400576 q12Shape62T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T125OK,q12Shape62T126OK⟩

private def q12Shape62T127 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape62T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1073741827 251658752 q12Shape62T127=true := by decide

private def q12Shape62T123 : Tree 12 := .split 30 q12Shape62T124 q12Shape62T127
private theorem q12Shape62T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 251658752 q12Shape62T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 (251658752 ||| 2^30) q12Shape62T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (3 ||| 2^30) 251658752 q12Shape62T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T124OK,q12Shape62T127OK⟩

private def q12Shape62T128 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 134217731 117441024 q12Shape62T128=true := by decide

private def q12Shape62T122 : Tree 12 := .split 27 q12Shape62T123 q12Shape62T128
private theorem q12Shape62T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 117441024 q12Shape62T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 (117441024 ||| 2^27) q12Shape62T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (3 ||| 2^27) 117441024 q12Shape62T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T123OK,q12Shape62T128OK⟩

private def q12Shape62T129 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 67108867 50332160 q12Shape62T129=true := by decide

private def q12Shape62T121 : Tree 12 := .split 26 q12Shape62T122 q12Shape62T129
private theorem q12Shape62T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 50332160 q12Shape62T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 (50332160 ||| 2^26) q12Shape62T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (3 ||| 2^26) 50332160 q12Shape62T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T122OK,q12Shape62T129OK⟩

private def q12Shape62T131 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554435 83886592 q12Shape62T131=true := by decide

private def q12Shape62T132 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape62T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 100663299 16777728 q12Shape62T132=true := by decide

private def q12Shape62T130 : Tree 12 := .split 26 q12Shape62T131 q12Shape62T132
private theorem q12Shape62T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554435 16777728 q12Shape62T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554435 (16777728 ||| 2^26) q12Shape62T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (33554435 ||| 2^26) 16777728 q12Shape62T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T131OK,q12Shape62T132OK⟩

private def q12Shape62T120 : Tree 12 := .split 25 q12Shape62T121 q12Shape62T130
private theorem q12Shape62T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 16777728 q12Shape62T120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 (16777728 ||| 2^25) q12Shape62T121 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (3 ||| 2^25) 16777728 q12Shape62T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T121OK,q12Shape62T130OK⟩

private def q12Shape62T135 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape62T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777219 100663808 q12Shape62T135=true := by decide

private def q12Shape62T136 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape62T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 83886083 33554944 q12Shape62T136=true := by decide

private def q12Shape62T134 : Tree 12 := .split 26 q12Shape62T135 q12Shape62T136
private theorem q12Shape62T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777219 33554944 q12Shape62T134=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777219 (33554944 ||| 2^26) q12Shape62T135 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777219 ||| 2^26) 33554944 q12Shape62T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T135OK,q12Shape62T136OK⟩

private def q12Shape62T137 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape62T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 50331651 512 q12Shape62T137=true := by decide

private def q12Shape62T133 : Tree 12 := .split 25 q12Shape62T134 q12Shape62T137
private theorem q12Shape62T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777219 512 q12Shape62T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777219 (512 ||| 2^25) q12Shape62T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777219 ||| 2^25) 512 q12Shape62T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T134OK,q12Shape62T137OK⟩

private def q12Shape62T119 : Tree 12 := .split 24 q12Shape62T120 q12Shape62T133
private theorem q12Shape62T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 512 q12Shape62T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 (512 ||| 2^24) q12Shape62T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (3 ||| 2^24) 512 q12Shape62T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T120OK,q12Shape62T133OK⟩

private def q12Shape62T144 : Tree 12 := (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11})))) (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))))
private theorem q12Shape62T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 3472883712 q12Shape62T144=true := by decide

private def q12Shape62T145 : Tree 12 := (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T145OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 2147484163 1325400064 q12Shape62T145=true := by decide

private def q12Shape62T143 : Tree 12 := .split 31 q12Shape62T144 q12Shape62T145
private theorem q12Shape62T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 1325400064 q12Shape62T143=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 (1325400064 ||| 2^31) q12Shape62T144 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (515 ||| 2^31) 1325400064 q12Shape62T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T144OK,q12Shape62T145OK⟩

private def q12Shape62T146 : Tree 12 := (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,6,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11})))
private theorem q12Shape62T146OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 1073742339 251658240 q12Shape62T146=true := by decide

private def q12Shape62T142 : Tree 12 := .split 30 q12Shape62T143 q12Shape62T146
private theorem q12Shape62T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 251658240 q12Shape62T142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 (251658240 ||| 2^30) q12Shape62T143 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (515 ||| 2^30) 251658240 q12Shape62T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T143OK,q12Shape62T146OK⟩

private def q12Shape62T147 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.tip (.cover {0,2,3,4,9,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 134218243 117440512 q12Shape62T147=true := by decide

private def q12Shape62T141 : Tree 12 := .split 27 q12Shape62T142 q12Shape62T147
private theorem q12Shape62T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 117440512 q12Shape62T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 (117440512 ||| 2^27) q12Shape62T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (515 ||| 2^27) 117440512 q12Shape62T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T142OK,q12Shape62T147OK⟩

private def q12Shape62T148 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.tip (.cover {0,2,3,4,8,10,11})) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,5,6,7,10,11})))
private theorem q12Shape62T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 67109379 50331648 q12Shape62T148=true := by decide

private def q12Shape62T140 : Tree 12 := .split 26 q12Shape62T141 q12Shape62T148
private theorem q12Shape62T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 50331648 q12Shape62T140=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 (50331648 ||| 2^26) q12Shape62T141 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (515 ||| 2^26) 50331648 q12Shape62T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T141OK,q12Shape62T148OK⟩

private def q12Shape62T150 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,7,8,9,10,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape62T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554947 83886080 q12Shape62T150=true := by decide

private def q12Shape62T151 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape62T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 100663811 16777216 q12Shape62T151=true := by decide

private def q12Shape62T149 : Tree 12 := .split 26 q12Shape62T150 q12Shape62T151
private theorem q12Shape62T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554947 16777216 q12Shape62T149=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 33554947 (16777216 ||| 2^26) q12Shape62T150 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (33554947 ||| 2^26) 16777216 q12Shape62T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T150OK,q12Shape62T151OK⟩

private def q12Shape62T139 : Tree 12 := .split 25 q12Shape62T140 q12Shape62T149
private theorem q12Shape62T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 16777216 q12Shape62T139=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 (16777216 ||| 2^25) q12Shape62T140 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (515 ||| 2^25) 16777216 q12Shape62T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T140OK,q12Shape62T149OK⟩

private def q12Shape62T154 : Tree 12 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,8,10,11}))) (.tip (.cover {0,1,5,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape62T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777731 100663296 q12Shape62T154=true := by decide

private def q12Shape62T155 : Tree 12 := (.tip (.cover {0,1,5,7,9,10,11}))
private theorem q12Shape62T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 83886595 33554432 q12Shape62T155=true := by decide

private def q12Shape62T153 : Tree 12 := .split 26 q12Shape62T154 q12Shape62T155
private theorem q12Shape62T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777731 33554432 q12Shape62T153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777731 (33554432 ||| 2^26) q12Shape62T154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777731 ||| 2^26) 33554432 q12Shape62T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T154OK,q12Shape62T155OK⟩

private def q12Shape62T156 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape62T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 50332163 0 q12Shape62T156=true := by decide

private def q12Shape62T152 : Tree 12 := .split 25 q12Shape62T153 q12Shape62T156
private theorem q12Shape62T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777731 0 q12Shape62T152=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 16777731 (0 ||| 2^25) q12Shape62T153 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (16777731 ||| 2^25) 0 q12Shape62T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T153OK,q12Shape62T156OK⟩

private def q12Shape62T138 : Tree 12 := .split 24 q12Shape62T139 q12Shape62T152
private theorem q12Shape62T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 0 q12Shape62T138=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 515 (0 ||| 2^24) q12Shape62T139 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (515 ||| 2^24) 0 q12Shape62T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T139OK,q12Shape62T152OK⟩

private def q12Shape62T118 : Tree 12 := .split 9 q12Shape62T119 q12Shape62T138
private theorem q12Shape62T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 0 q12Shape62T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 (0 ||| 2^9) q12Shape62T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) (3 ||| 2^9) 0 q12Shape62T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape62T119OK,q12Shape62T138OK⟩

def q12Shape62P3 : Tree 12 := q12Shape62T118
theorem q12Shape62P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,3⟩) 3 0 q12Shape62P3=true := q12Shape62T118OK

end Graffiti384b.EffectiveSearch.Q12
