import Q12Shape63Part0
import Q12Shape63Part1
import Q12Shape63Part2
import Q12Shape63Part3
import Q12Shape63Part4
import Q12Shape63Part5
import Q12Shape63Part6
import Q12Shape63Part7

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape63M30 : Tree 12 := .split 2 q12Shape63P0 q12Shape63P1
private theorem q12Shape63M30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 3 q12Shape63M30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 (3 ||| 2^2) q12Shape63P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (0 ||| 2^2) 3 q12Shape63P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63P0OK,q12Shape63P1OK⟩
private def q12Shape63M61 : Tree 12 := .split 2 q12Shape63P2 q12Shape63P3
private theorem q12Shape63M61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 2 1 q12Shape63M61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 2 (1 ||| 2^2) q12Shape63P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (2 ||| 2^2) 1 q12Shape63P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63P2OK,q12Shape63P3OK⟩
private def q12Shape63M62 : Tree 12 := .split 1 q12Shape63M30 q12Shape63M61
private theorem q12Shape63M62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 1 q12Shape63M62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 (1 ||| 2^1) q12Shape63M30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (0 ||| 2^1) 1 q12Shape63M61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63M30OK,q12Shape63M61OK⟩
private def q12Shape63M93 : Tree 12 := .split 2 q12Shape63P4 q12Shape63P5
private theorem q12Shape63M93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1 2 q12Shape63M93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1 (2 ||| 2^2) q12Shape63P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1 ||| 2^2) 2 q12Shape63P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63P4OK,q12Shape63P5OK⟩
private def q12Shape63M124 : Tree 12 := .split 2 q12Shape63P6 q12Shape63P7
private theorem q12Shape63M124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 0 q12Shape63M124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 (0 ||| 2^2) q12Shape63P6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (3 ||| 2^2) 0 q12Shape63P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63P6OK,q12Shape63P7OK⟩
private def q12Shape63M125 : Tree 12 := .split 1 q12Shape63M93 q12Shape63M124
private theorem q12Shape63M125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1 0 q12Shape63M125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1 (0 ||| 2^1) q12Shape63M93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1 ||| 2^1) 0 q12Shape63M124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63M93OK,q12Shape63M124OK⟩
private def q12Shape63M126 : Tree 12 := .split 0 q12Shape63M62 q12Shape63M125
private theorem q12Shape63M126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 0 q12Shape63M126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 (0 ||| 2^0) q12Shape63M62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (0 ||| 2^0) 0 q12Shape63M125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63M62OK,q12Shape63M125OK⟩

theorem q12Shape63_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 63) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 63) b) (adj 12 (forms 63) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) adj_mono b H q12Shape63M126 q12Shape63M126OK

#print axioms q12Shape63_cover

end Graffiti384b.EffectiveSearch.Q12
