import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape63T3 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 132615 q12Shape63T3=true := by decide

private def q12Shape63T4 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131072 1543 q12Shape63T4=true := by decide

private def q12Shape63T2 : Tree 12 := .split 17 q12Shape63T3 q12Shape63T4
private theorem q12Shape63T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 1543 q12Shape63T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 (1543 ||| 2^17) q12Shape63T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (0 ||| 2^17) 1543 q12Shape63T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T3OK,q12Shape63T4OK⟩

private def q12Shape63T6 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1024 131591 q12Shape63T6=true := by decide

private def q12Shape63T7 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132096 519 q12Shape63T7=true := by decide

private def q12Shape63T5 : Tree 12 := .split 17 q12Shape63T6 q12Shape63T7
private theorem q12Shape63T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1024 519 q12Shape63T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1024 (519 ||| 2^17) q12Shape63T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1024 ||| 2^17) 519 q12Shape63T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T6OK,q12Shape63T7OK⟩

private def q12Shape63T1 : Tree 12 := .split 10 q12Shape63T2 q12Shape63T5
private theorem q12Shape63T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 519 q12Shape63T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 (519 ||| 2^10) q12Shape63T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (0 ||| 2^10) 519 q12Shape63T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T2OK,q12Shape63T5OK⟩

private def q12Shape63T10 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 512 132103 q12Shape63T10=true := by decide

private def q12Shape63T11 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131584 1031 q12Shape63T11=true := by decide

private def q12Shape63T9 : Tree 12 := .split 17 q12Shape63T10 q12Shape63T11
private theorem q12Shape63T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 512 1031 q12Shape63T9=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 512 (1031 ||| 2^17) q12Shape63T10 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (512 ||| 2^17) 1031 q12Shape63T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T10OK,q12Shape63T11OK⟩

private def q12Shape63T13 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1536 131079 q12Shape63T13=true := by decide

private def q12Shape63T14 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132608 7 q12Shape63T14=true := by decide

private def q12Shape63T12 : Tree 12 := .split 17 q12Shape63T13 q12Shape63T14
private theorem q12Shape63T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1536 7 q12Shape63T12=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1536 (7 ||| 2^17) q12Shape63T13 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1536 ||| 2^17) 7 q12Shape63T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T13OK,q12Shape63T14OK⟩

private def q12Shape63T8 : Tree 12 := .split 10 q12Shape63T9 q12Shape63T12
private theorem q12Shape63T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 512 7 q12Shape63T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 512 (7 ||| 2^10) q12Shape63T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (512 ||| 2^10) 7 q12Shape63T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T9OK,q12Shape63T12OK⟩

private def q12Shape63T0 : Tree 12 := .split 9 q12Shape63T1 q12Shape63T8
private theorem q12Shape63T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 7 q12Shape63T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 (7 ||| 2^9) q12Shape63T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (0 ||| 2^9) 7 q12Shape63T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T1OK,q12Shape63T8OK⟩

def q12Shape63P0 : Tree 12 := q12Shape63T0
theorem q12Shape63P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 0 7 q12Shape63P0=true := q12Shape63T0OK

end Graffiti384b.EffectiveSearch.Q12
