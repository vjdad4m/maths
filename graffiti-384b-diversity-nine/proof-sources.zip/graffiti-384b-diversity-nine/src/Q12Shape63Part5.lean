import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape63T81 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 132610 q12Shape63T81=true := by decide

private def q12Shape63T82 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131077 1538 q12Shape63T82=true := by decide

private def q12Shape63T80 : Tree 12 := .split 17 q12Shape63T81 q12Shape63T82
private theorem q12Shape63T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 1538 q12Shape63T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 (1538 ||| 2^17) q12Shape63T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (5 ||| 2^17) 1538 q12Shape63T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T81OK,q12Shape63T82OK⟩

private def q12Shape63T84 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1029 131586 q12Shape63T84=true := by decide

private def q12Shape63T85 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132101 514 q12Shape63T85=true := by decide

private def q12Shape63T83 : Tree 12 := .split 17 q12Shape63T84 q12Shape63T85
private theorem q12Shape63T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1029 514 q12Shape63T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1029 (514 ||| 2^17) q12Shape63T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1029 ||| 2^17) 514 q12Shape63T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T84OK,q12Shape63T85OK⟩

private def q12Shape63T79 : Tree 12 := .split 10 q12Shape63T80 q12Shape63T83
private theorem q12Shape63T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 514 q12Shape63T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 (514 ||| 2^10) q12Shape63T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (5 ||| 2^10) 514 q12Shape63T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T80OK,q12Shape63T83OK⟩

private def q12Shape63T88 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 517 132098 q12Shape63T88=true := by decide

private def q12Shape63T89 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131589 1026 q12Shape63T89=true := by decide

private def q12Shape63T87 : Tree 12 := .split 17 q12Shape63T88 q12Shape63T89
private theorem q12Shape63T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 517 1026 q12Shape63T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 517 (1026 ||| 2^17) q12Shape63T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (517 ||| 2^17) 1026 q12Shape63T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T88OK,q12Shape63T89OK⟩

private def q12Shape63T91 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1541 131074 q12Shape63T91=true := by decide

private def q12Shape63T92 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132613 2 q12Shape63T92=true := by decide

private def q12Shape63T90 : Tree 12 := .split 17 q12Shape63T91 q12Shape63T92
private theorem q12Shape63T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1541 2 q12Shape63T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1541 (2 ||| 2^17) q12Shape63T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1541 ||| 2^17) 2 q12Shape63T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T91OK,q12Shape63T92OK⟩

private def q12Shape63T86 : Tree 12 := .split 10 q12Shape63T87 q12Shape63T90
private theorem q12Shape63T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 517 2 q12Shape63T86=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 517 (2 ||| 2^10) q12Shape63T87 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (517 ||| 2^10) 2 q12Shape63T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T87OK,q12Shape63T90OK⟩

private def q12Shape63T78 : Tree 12 := .split 9 q12Shape63T79 q12Shape63T86
private theorem q12Shape63T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 2 q12Shape63T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 (2 ||| 2^9) q12Shape63T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (5 ||| 2^9) 2 q12Shape63T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T79OK,q12Shape63T86OK⟩

def q12Shape63P5 : Tree 12 := q12Shape63T78
theorem q12Shape63P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 5 2 q12Shape63P5=true := q12Shape63T78OK

end Graffiti384b.EffectiveSearch.Q12
