import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape63T97 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 132612 q12Shape63T97=true := by decide

private def q12Shape63T98 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131075 1540 q12Shape63T98=true := by decide

private def q12Shape63T96 : Tree 12 := .split 17 q12Shape63T97 q12Shape63T98
private theorem q12Shape63T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 1540 q12Shape63T96=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 (1540 ||| 2^17) q12Shape63T97 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (3 ||| 2^17) 1540 q12Shape63T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T97OK,q12Shape63T98OK⟩

private def q12Shape63T100 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1027 131588 q12Shape63T100=true := by decide

private def q12Shape63T101 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132099 516 q12Shape63T101=true := by decide

private def q12Shape63T99 : Tree 12 := .split 17 q12Shape63T100 q12Shape63T101
private theorem q12Shape63T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1027 516 q12Shape63T99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1027 (516 ||| 2^17) q12Shape63T100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1027 ||| 2^17) 516 q12Shape63T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T100OK,q12Shape63T101OK⟩

private def q12Shape63T95 : Tree 12 := .split 10 q12Shape63T96 q12Shape63T99
private theorem q12Shape63T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 516 q12Shape63T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 (516 ||| 2^10) q12Shape63T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (3 ||| 2^10) 516 q12Shape63T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T96OK,q12Shape63T99OK⟩

private def q12Shape63T104 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 515 132100 q12Shape63T104=true := by decide

private def q12Shape63T105 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131587 1028 q12Shape63T105=true := by decide

private def q12Shape63T103 : Tree 12 := .split 17 q12Shape63T104 q12Shape63T105
private theorem q12Shape63T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 515 1028 q12Shape63T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 515 (1028 ||| 2^17) q12Shape63T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (515 ||| 2^17) 1028 q12Shape63T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T104OK,q12Shape63T105OK⟩

private def q12Shape63T107 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1539 131076 q12Shape63T107=true := by decide

private def q12Shape63T108 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132611 4 q12Shape63T108=true := by decide

private def q12Shape63T106 : Tree 12 := .split 17 q12Shape63T107 q12Shape63T108
private theorem q12Shape63T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1539 4 q12Shape63T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1539 (4 ||| 2^17) q12Shape63T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1539 ||| 2^17) 4 q12Shape63T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T107OK,q12Shape63T108OK⟩

private def q12Shape63T102 : Tree 12 := .split 10 q12Shape63T103 q12Shape63T106
private theorem q12Shape63T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 515 4 q12Shape63T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 515 (4 ||| 2^10) q12Shape63T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (515 ||| 2^10) 4 q12Shape63T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T103OK,q12Shape63T106OK⟩

private def q12Shape63T94 : Tree 12 := .split 9 q12Shape63T95 q12Shape63T102
private theorem q12Shape63T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 4 q12Shape63T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 (4 ||| 2^9) q12Shape63T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (3 ||| 2^9) 4 q12Shape63T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T95OK,q12Shape63T102OK⟩

def q12Shape63P6 : Tree 12 := q12Shape63T94
theorem q12Shape63P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 3 4 q12Shape63P6=true := q12Shape63T94OK

end Graffiti384b.EffectiveSearch.Q12
