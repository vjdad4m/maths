import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape63T112 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 132608 q12Shape63T112=true := by decide

private def q12Shape63T113 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131079 1536 q12Shape63T113=true := by decide

private def q12Shape63T111 : Tree 12 := .split 17 q12Shape63T112 q12Shape63T113
private theorem q12Shape63T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 1536 q12Shape63T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 (1536 ||| 2^17) q12Shape63T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (7 ||| 2^17) 1536 q12Shape63T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T112OK,q12Shape63T113OK⟩

private def q12Shape63T115 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1031 131584 q12Shape63T115=true := by decide

private def q12Shape63T116 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132103 512 q12Shape63T116=true := by decide

private def q12Shape63T114 : Tree 12 := .split 17 q12Shape63T115 q12Shape63T116
private theorem q12Shape63T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1031 512 q12Shape63T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1031 (512 ||| 2^17) q12Shape63T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1031 ||| 2^17) 512 q12Shape63T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T115OK,q12Shape63T116OK⟩

private def q12Shape63T110 : Tree 12 := .split 10 q12Shape63T111 q12Shape63T114
private theorem q12Shape63T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 512 q12Shape63T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 (512 ||| 2^10) q12Shape63T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (7 ||| 2^10) 512 q12Shape63T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T111OK,q12Shape63T114OK⟩

private def q12Shape63T119 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 519 132096 q12Shape63T119=true := by decide

private def q12Shape63T120 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 131591 1024 q12Shape63T120=true := by decide

private def q12Shape63T118 : Tree 12 := .split 17 q12Shape63T119 q12Shape63T120
private theorem q12Shape63T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 519 1024 q12Shape63T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 519 (1024 ||| 2^17) q12Shape63T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (519 ||| 2^17) 1024 q12Shape63T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T119OK,q12Shape63T120OK⟩

private def q12Shape63T122 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1543 131072 q12Shape63T122=true := by decide

private def q12Shape63T123 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape63T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 132615 0 q12Shape63T123=true := by decide

private def q12Shape63T121 : Tree 12 := .split 17 q12Shape63T122 q12Shape63T123
private theorem q12Shape63T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1543 0 q12Shape63T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 1543 (0 ||| 2^17) q12Shape63T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (1543 ||| 2^17) 0 q12Shape63T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T122OK,q12Shape63T123OK⟩

private def q12Shape63T117 : Tree 12 := .split 10 q12Shape63T118 q12Shape63T121
private theorem q12Shape63T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 519 0 q12Shape63T117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 519 (0 ||| 2^10) q12Shape63T118 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (519 ||| 2^10) 0 q12Shape63T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T118OK,q12Shape63T121OK⟩

private def q12Shape63T109 : Tree 12 := .split 9 q12Shape63T110 q12Shape63T117
private theorem q12Shape63T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 0 q12Shape63T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 (0 ||| 2^9) q12Shape63T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) (7 ||| 2^9) 0 q12Shape63T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape63T110OK,q12Shape63T117OK⟩

def q12Shape63P7 : Tree 12 := q12Shape63T109
theorem q12Shape63P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,6,4⟩) 7 0 q12Shape63P7=true := q12Shape63T109OK

end Graffiti384b.EffectiveSearch.Q12
