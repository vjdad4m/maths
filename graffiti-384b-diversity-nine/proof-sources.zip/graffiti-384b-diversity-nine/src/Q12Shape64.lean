import Q12Shape64Part0
import Q12Shape64Part1
import Q12Shape64Part2
import Q12Shape64Part3
import Q12Shape64Part4
import Q12Shape64Part5
import Q12Shape64Part6
import Q12Shape64Part7

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape64M30 : Tree 12 := .split 2 q12Shape64P0 q12Shape64P1
private theorem q12Shape64M30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 0 3 q12Shape64M30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 0 (3 ||| 2^2) q12Shape64P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (0 ||| 2^2) 3 q12Shape64P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64P0OK,q12Shape64P1OK⟩
private def q12Shape64M61 : Tree 12 := .split 2 q12Shape64P2 q12Shape64P3
private theorem q12Shape64M61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 2 1 q12Shape64M61=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 2 (1 ||| 2^2) q12Shape64P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (2 ||| 2^2) 1 q12Shape64P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64P2OK,q12Shape64P3OK⟩
private def q12Shape64M62 : Tree 12 := .split 1 q12Shape64M30 q12Shape64M61
private theorem q12Shape64M62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 0 1 q12Shape64M62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 0 (1 ||| 2^1) q12Shape64M30 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (0 ||| 2^1) 1 q12Shape64M61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64M30OK,q12Shape64M61OK⟩
private def q12Shape64M93 : Tree 12 := .split 2 q12Shape64P4 q12Shape64P5
private theorem q12Shape64M93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 2 q12Shape64M93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 (2 ||| 2^2) q12Shape64P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1 ||| 2^2) 2 q12Shape64P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64P4OK,q12Shape64P5OK⟩
private def q12Shape64M124 : Tree 12 := .split 2 q12Shape64P6 q12Shape64P7
private theorem q12Shape64M124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 3 0 q12Shape64M124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 3 (0 ||| 2^2) q12Shape64P6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (3 ||| 2^2) 0 q12Shape64P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64P6OK,q12Shape64P7OK⟩
private def q12Shape64M125 : Tree 12 := .split 1 q12Shape64M93 q12Shape64M124
private theorem q12Shape64M125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 0 q12Shape64M125=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 (0 ||| 2^1) q12Shape64M93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1 ||| 2^1) 0 q12Shape64M124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64M93OK,q12Shape64M124OK⟩
private def q12Shape64M126 : Tree 12 := .split 0 q12Shape64M62 q12Shape64M125
private theorem q12Shape64M126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 0 0 q12Shape64M126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 0 (0 ||| 2^0) q12Shape64M62 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (0 ||| 2^0) 0 q12Shape64M125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64M62OK,q12Shape64M125OK⟩

theorem q12Shape64_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 64) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 64) b) (adj 12 (forms 64) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) adj_mono b H q12Shape64M126 q12Shape64M126OK

#print axioms q12Shape64_cover

end Graffiti384b.EffectiveSearch.Q12
