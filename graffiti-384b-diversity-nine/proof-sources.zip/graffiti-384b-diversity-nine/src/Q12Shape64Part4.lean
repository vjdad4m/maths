import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape64T66 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 132614 q12Shape64T66=true := by decide

private def q12Shape64T67 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 131073 1542 q12Shape64T67=true := by decide

private def q12Shape64T65 : Tree 12 := .split 17 q12Shape64T66 q12Shape64T67
private theorem q12Shape64T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 1542 q12Shape64T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 (1542 ||| 2^17) q12Shape64T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1 ||| 2^17) 1542 q12Shape64T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T66OK,q12Shape64T67OK⟩

private def q12Shape64T69 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1025 131590 q12Shape64T69=true := by decide

private def q12Shape64T70 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 132097 518 q12Shape64T70=true := by decide

private def q12Shape64T68 : Tree 12 := .split 17 q12Shape64T69 q12Shape64T70
private theorem q12Shape64T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1025 518 q12Shape64T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1025 (518 ||| 2^17) q12Shape64T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1025 ||| 2^17) 518 q12Shape64T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T69OK,q12Shape64T70OK⟩

private def q12Shape64T64 : Tree 12 := .split 10 q12Shape64T65 q12Shape64T68
private theorem q12Shape64T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 518 q12Shape64T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 (518 ||| 2^10) q12Shape64T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1 ||| 2^10) 518 q12Shape64T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T65OK,q12Shape64T68OK⟩

private def q12Shape64T73 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 513 132102 q12Shape64T73=true := by decide

private def q12Shape64T74 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 131585 1030 q12Shape64T74=true := by decide

private def q12Shape64T72 : Tree 12 := .split 17 q12Shape64T73 q12Shape64T74
private theorem q12Shape64T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 513 1030 q12Shape64T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 513 (1030 ||| 2^17) q12Shape64T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (513 ||| 2^17) 1030 q12Shape64T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T73OK,q12Shape64T74OK⟩

private def q12Shape64T76 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1537 131078 q12Shape64T76=true := by decide

private def q12Shape64T77 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 132609 6 q12Shape64T77=true := by decide

private def q12Shape64T75 : Tree 12 := .split 17 q12Shape64T76 q12Shape64T77
private theorem q12Shape64T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1537 6 q12Shape64T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1537 (6 ||| 2^17) q12Shape64T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1537 ||| 2^17) 6 q12Shape64T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T76OK,q12Shape64T77OK⟩

private def q12Shape64T71 : Tree 12 := .split 10 q12Shape64T72 q12Shape64T75
private theorem q12Shape64T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 513 6 q12Shape64T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 513 (6 ||| 2^10) q12Shape64T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (513 ||| 2^10) 6 q12Shape64T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T72OK,q12Shape64T75OK⟩

private def q12Shape64T63 : Tree 12 := .split 9 q12Shape64T64 q12Shape64T71
private theorem q12Shape64T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 6 q12Shape64T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 (6 ||| 2^9) q12Shape64T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1 ||| 2^9) 6 q12Shape64T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T64OK,q12Shape64T71OK⟩

def q12Shape64P4 : Tree 12 := q12Shape64T63
theorem q12Shape64P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1 6 q12Shape64P4=true := q12Shape64T63OK

end Graffiti384b.EffectiveSearch.Q12
