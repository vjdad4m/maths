import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape64T81 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 132610 q12Shape64T81=true := by decide

private def q12Shape64T82 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 131077 1538 q12Shape64T82=true := by decide

private def q12Shape64T80 : Tree 12 := .split 17 q12Shape64T81 q12Shape64T82
private theorem q12Shape64T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 1538 q12Shape64T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 (1538 ||| 2^17) q12Shape64T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (5 ||| 2^17) 1538 q12Shape64T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T81OK,q12Shape64T82OK⟩

private def q12Shape64T84 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1029 131586 q12Shape64T84=true := by decide

private def q12Shape64T85 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 132101 514 q12Shape64T85=true := by decide

private def q12Shape64T83 : Tree 12 := .split 17 q12Shape64T84 q12Shape64T85
private theorem q12Shape64T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1029 514 q12Shape64T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1029 (514 ||| 2^17) q12Shape64T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1029 ||| 2^17) 514 q12Shape64T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T84OK,q12Shape64T85OK⟩

private def q12Shape64T79 : Tree 12 := .split 10 q12Shape64T80 q12Shape64T83
private theorem q12Shape64T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 514 q12Shape64T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 (514 ||| 2^10) q12Shape64T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (5 ||| 2^10) 514 q12Shape64T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T80OK,q12Shape64T83OK⟩

private def q12Shape64T88 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 517 132098 q12Shape64T88=true := by decide

private def q12Shape64T89 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 131589 1026 q12Shape64T89=true := by decide

private def q12Shape64T87 : Tree 12 := .split 17 q12Shape64T88 q12Shape64T89
private theorem q12Shape64T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 517 1026 q12Shape64T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 517 (1026 ||| 2^17) q12Shape64T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (517 ||| 2^17) 1026 q12Shape64T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T88OK,q12Shape64T89OK⟩

private def q12Shape64T91 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1541 131074 q12Shape64T91=true := by decide

private def q12Shape64T92 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 132613 2 q12Shape64T92=true := by decide

private def q12Shape64T90 : Tree 12 := .split 17 q12Shape64T91 q12Shape64T92
private theorem q12Shape64T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1541 2 q12Shape64T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1541 (2 ||| 2^17) q12Shape64T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1541 ||| 2^17) 2 q12Shape64T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T91OK,q12Shape64T92OK⟩

private def q12Shape64T86 : Tree 12 := .split 10 q12Shape64T87 q12Shape64T90
private theorem q12Shape64T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 517 2 q12Shape64T86=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 517 (2 ||| 2^10) q12Shape64T87 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (517 ||| 2^10) 2 q12Shape64T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T87OK,q12Shape64T90OK⟩

private def q12Shape64T78 : Tree 12 := .split 9 q12Shape64T79 q12Shape64T86
private theorem q12Shape64T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 2 q12Shape64T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 (2 ||| 2^9) q12Shape64T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (5 ||| 2^9) 2 q12Shape64T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T79OK,q12Shape64T86OK⟩

def q12Shape64P5 : Tree 12 := q12Shape64T78
theorem q12Shape64P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 5 2 q12Shape64P5=true := q12Shape64T78OK

end Graffiti384b.EffectiveSearch.Q12
