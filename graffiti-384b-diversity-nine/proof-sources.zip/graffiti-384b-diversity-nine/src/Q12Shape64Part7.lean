import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape64T112 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 132608 q12Shape64T112=true := by decide

private def q12Shape64T113 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 131079 1536 q12Shape64T113=true := by decide

private def q12Shape64T111 : Tree 12 := .split 17 q12Shape64T112 q12Shape64T113
private theorem q12Shape64T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 1536 q12Shape64T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 (1536 ||| 2^17) q12Shape64T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (7 ||| 2^17) 1536 q12Shape64T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T112OK,q12Shape64T113OK⟩

private def q12Shape64T115 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1031 131584 q12Shape64T115=true := by decide

private def q12Shape64T116 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 132103 512 q12Shape64T116=true := by decide

private def q12Shape64T114 : Tree 12 := .split 17 q12Shape64T115 q12Shape64T116
private theorem q12Shape64T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1031 512 q12Shape64T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1031 (512 ||| 2^17) q12Shape64T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1031 ||| 2^17) 512 q12Shape64T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T115OK,q12Shape64T116OK⟩

private def q12Shape64T110 : Tree 12 := .split 10 q12Shape64T111 q12Shape64T114
private theorem q12Shape64T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 512 q12Shape64T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 (512 ||| 2^10) q12Shape64T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (7 ||| 2^10) 512 q12Shape64T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T111OK,q12Shape64T114OK⟩

private def q12Shape64T119 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 519 132096 q12Shape64T119=true := by decide

private def q12Shape64T120 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 131591 1024 q12Shape64T120=true := by decide

private def q12Shape64T118 : Tree 12 := .split 17 q12Shape64T119 q12Shape64T120
private theorem q12Shape64T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 519 1024 q12Shape64T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 519 (1024 ||| 2^17) q12Shape64T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (519 ||| 2^17) 1024 q12Shape64T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T119OK,q12Shape64T120OK⟩

private def q12Shape64T122 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1543 131072 q12Shape64T122=true := by decide

private def q12Shape64T123 : Tree 12 := (.split 30 (.split 31 (.split 32 (.split 35 (.split 36 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape64T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 132615 0 q12Shape64T123=true := by decide

private def q12Shape64T121 : Tree 12 := .split 17 q12Shape64T122 q12Shape64T123
private theorem q12Shape64T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1543 0 q12Shape64T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 1543 (0 ||| 2^17) q12Shape64T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (1543 ||| 2^17) 0 q12Shape64T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T122OK,q12Shape64T123OK⟩

private def q12Shape64T117 : Tree 12 := .split 10 q12Shape64T118 q12Shape64T121
private theorem q12Shape64T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 519 0 q12Shape64T117=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 519 (0 ||| 2^10) q12Shape64T118 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (519 ||| 2^10) 0 q12Shape64T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T118OK,q12Shape64T121OK⟩

private def q12Shape64T109 : Tree 12 := .split 9 q12Shape64T110 q12Shape64T117
private theorem q12Shape64T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 0 q12Shape64T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 (0 ||| 2^9) q12Shape64T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) (7 ||| 2^9) 0 q12Shape64T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape64T110OK,q12Shape64T117OK⟩

def q12Shape64P7 : Tree 12 := q12Shape64T109
theorem q12Shape64P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,9,7,4⟩) 7 0 q12Shape64P7=true := q12Shape64T109OK

end Graffiti384b.EffectiveSearch.Q12
