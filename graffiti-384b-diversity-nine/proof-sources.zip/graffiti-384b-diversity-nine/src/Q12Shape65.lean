import Q12Shape65Part0

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q12Shape65_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 65) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 65) b) (adj 12 (forms 65) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨true,10,5,3⟩) adj_mono b H q12Shape65P0 q12Shape65P0OK

#print axioms q12Shape65_cover

end Graffiti384b.EffectiveSearch.Q12
