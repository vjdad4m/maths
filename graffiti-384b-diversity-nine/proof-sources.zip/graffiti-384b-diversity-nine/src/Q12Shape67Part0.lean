import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape67T1 : Tree 12 := (.split 31 (.split 32 (.split 33 (.split 35 (.split 36 (.split 37 (.split 39 (.tip (.cover {0,2,3,4,5,10,11})) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,7,9,10,11})))
private theorem q12Shape67T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,10,6,4⟩) 0 1073741824 q12Shape67T1=true := by decide

private def q12Shape67T2 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape67T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,10,6,4⟩) 1073741824 0 q12Shape67T2=true := by decide

private def q12Shape67T0 : Tree 12 := .split 30 q12Shape67T1 q12Shape67T2
private theorem q12Shape67T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,10,6,4⟩) 0 0 q12Shape67T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,10,6,4⟩) 0 (0 ||| 2^30) q12Shape67T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,10,6,4⟩) (0 ||| 2^30) 0 q12Shape67T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape67T1OK,q12Shape67T2OK⟩

def q12Shape67P0 : Tree 12 := q12Shape67T0
theorem q12Shape67P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨true,10,6,4⟩) 0 0 q12Shape67P0=true := q12Shape67T0OK

end Graffiti384b.EffectiveSearch.Q12
