import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6T37 : Tree 12 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))))
private theorem q12Shape6T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 6048405389312 q12Shape6T37=true := by decide

private def q12Shape6T39 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))))
private theorem q12Shape6T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065536 1650358878209 q12Shape6T39=true := by decide

private def q12Shape6T41 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11})))))))
private theorem q12Shape6T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065537 1650358878240 q12Shape6T41=true := by decide

private def q12Shape6T43 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))))
private theorem q12Shape6T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065569 1650358878272 q12Shape6T43=true := by decide

private def q12Shape6T44 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))) (.tip (.cover {0,1,2,4,5,6,11})))
private theorem q12Shape6T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065633 1650358878208 q12Shape6T44=true := by decide

private def q12Shape6T42 : Tree 12 := .split 6 q12Shape6T43 q12Shape6T44
private theorem q12Shape6T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065569 1650358878208 q12Shape6T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065569 (1650358878208 ||| 2^6) q12Shape6T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398080065569 ||| 2^6) 1650358878208 q12Shape6T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T43OK,q12Shape6T44OK⟩

private def q12Shape6T40 : Tree 12 := .split 5 q12Shape6T41 q12Shape6T42
private theorem q12Shape6T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065537 1650358878208 q12Shape6T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065537 (1650358878208 ||| 2^5) q12Shape6T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398080065537 ||| 2^5) 1650358878208 q12Shape6T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T41OK,q12Shape6T42OK⟩

private def q12Shape6T38 : Tree 12 := .split 0 q12Shape6T39 q12Shape6T40
private theorem q12Shape6T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065536 1650358878208 q12Shape6T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398080065536 (1650358878208 ||| 2^0) q12Shape6T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398080065536 ||| 2^0) 1650358878208 q12Shape6T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T39OK,q12Shape6T40OK⟩

private def q12Shape6T36 : Tree 12 := .split 42 q12Shape6T37 q12Shape6T38
private theorem q12Shape6T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 1650358878208 q12Shape6T36=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 (1650358878208 ||| 2^42) q12Shape6T37 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (33554432 ||| 2^42) 1650358878208 q12Shape6T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T37OK,q12Shape6T38OK⟩

private def q12Shape6T47 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))))
private theorem q12Shape6T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182208 4948893761537 q12Shape6T47=true := by decide

private def q12Shape6T49 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11})))))))
private theorem q12Shape6T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182209 4948893761568 q12Shape6T49=true := by decide

private def q12Shape6T51 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))))
private theorem q12Shape6T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182241 4948893761600 q12Shape6T51=true := by decide

private def q12Shape6T52 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))) (.tip (.cover {0,1,2,4,5,6,11})))
private theorem q12Shape6T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182305 4948893761536 q12Shape6T52=true := by decide

private def q12Shape6T50 : Tree 12 := .split 6 q12Shape6T51 q12Shape6T52
private theorem q12Shape6T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182241 4948893761536 q12Shape6T50=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182241 (4948893761536 ||| 2^6) q12Shape6T51 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099545182241 ||| 2^6) 4948893761536 q12Shape6T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T51OK,q12Shape6T52OK⟩

private def q12Shape6T48 : Tree 12 := .split 5 q12Shape6T49 q12Shape6T50
private theorem q12Shape6T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182209 4948893761536 q12Shape6T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182209 (4948893761536 ||| 2^5) q12Shape6T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099545182209 ||| 2^5) 4948893761536 q12Shape6T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T49OK,q12Shape6T50OK⟩

private def q12Shape6T46 : Tree 12 := .split 0 q12Shape6T47 q12Shape6T48
private theorem q12Shape6T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182208 4948893761536 q12Shape6T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182208 (4948893761536 ||| 2^0) q12Shape6T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099545182208 ||| 2^0) 4948893761536 q12Shape6T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T47OK,q12Shape6T48OK⟩

private def q12Shape6T53 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape6T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 5497591693312 550847250432 q12Shape6T53=true := by decide

private def q12Shape6T45 : Tree 12 := .split 42 q12Shape6T46 q12Shape6T53
private theorem q12Shape6T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182208 550847250432 q12Shape6T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099545182208 (550847250432 ||| 2^42) q12Shape6T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099545182208 ||| 2^42) 550847250432 q12Shape6T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T46OK,q12Shape6T53OK⟩

private def q12Shape6T35 : Tree 12 := .split 40 q12Shape6T36 q12Shape6T45
private theorem q12Shape6T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 550847250432 q12Shape6T35=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 (550847250432 ||| 2^40) q12Shape6T36 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (33554432 ||| 2^40) 550847250432 q12Shape6T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T36OK,q12Shape6T45OK⟩

private def q12Shape6T57 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))))
private theorem q12Shape6T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368320 5498649575425 q12Shape6T57=true := by decide

private def q12Shape6T59 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11})))))))
private theorem q12Shape6T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368321 5498649575456 q12Shape6T59=true := by decide

private def q12Shape6T61 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))))
private theorem q12Shape6T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368353 5498649575488 q12Shape6T61=true := by decide

private def q12Shape6T62 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,4,5,6,7,11})))) (.tip (.cover {0,1,2,4,5,6,11})))
private theorem q12Shape6T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368417 5498649575424 q12Shape6T62=true := by decide

private def q12Shape6T60 : Tree 12 := .split 6 q12Shape6T61 q12Shape6T62
private theorem q12Shape6T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368353 5498649575424 q12Shape6T60=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368353 (5498649575424 ||| 2^6) q12Shape6T61 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549789368353 ||| 2^6) 5498649575424 q12Shape6T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T61OK,q12Shape6T62OK⟩

private def q12Shape6T58 : Tree 12 := .split 5 q12Shape6T59 q12Shape6T60
private theorem q12Shape6T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368321 5498649575424 q12Shape6T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368321 (5498649575424 ||| 2^5) q12Shape6T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549789368321 ||| 2^5) 5498649575424 q12Shape6T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T59OK,q12Shape6T60OK⟩

private def q12Shape6T56 : Tree 12 := .split 0 q12Shape6T57 q12Shape6T58
private theorem q12Shape6T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368320 5498649575424 q12Shape6T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368320 (5498649575424 ||| 2^0) q12Shape6T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549789368320 ||| 2^0) 5498649575424 q12Shape6T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T57OK,q12Shape6T58OK⟩

private def q12Shape6T63 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape6T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4947835879424 1100603064320 q12Shape6T63=true := by decide

private def q12Shape6T55 : Tree 12 := .split 42 q12Shape6T56 q12Shape6T63
private theorem q12Shape6T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368320 1100603064320 q12Shape6T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368320 (1100603064320 ||| 2^42) q12Shape6T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549789368320 ||| 2^42) 1100603064320 q12Shape6T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T56OK,q12Shape6T63OK⟩

private def q12Shape6T64 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape6T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1649300996096 1091436544 q12Shape6T64=true := by decide

private def q12Shape6T54 : Tree 12 := .split 40 q12Shape6T55 q12Shape6T64
private theorem q12Shape6T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368320 1091436544 q12Shape6T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549789368320 (1091436544 ||| 2^40) q12Shape6T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549789368320 ||| 2^40) 1091436544 q12Shape6T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T55OK,q12Shape6T64OK⟩

private def q12Shape6T34 : Tree 12 := .split 39 q12Shape6T35 q12Shape6T54
private theorem q12Shape6T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 1091436544 q12Shape6T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 (1091436544 ||| 2^39) q12Shape6T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (33554432 ||| 2^39) 1091436544 q12Shape6T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T35OK,q12Shape6T54OK⟩

private def q12Shape6T65 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10,11}))))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape6T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1107296256 17694720 q12Shape6T65=true := by decide

private def q12Shape6T33 : Tree 12 := .split 30 q12Shape6T34 q12Shape6T65
private theorem q12Shape6T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 17694720 q12Shape6T33=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 (17694720 ||| 2^30) q12Shape6T34 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (33554432 ||| 2^30) 17694720 q12Shape6T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T34OK,q12Shape6T65OK⟩

def q12Shape6P1 : Tree 12 := q12Shape6T33
theorem q12Shape6P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33554432 17694720 q12Shape6P1=true := q12Shape6T33OK

end Graffiti384b.EffectiveSearch.Q12
