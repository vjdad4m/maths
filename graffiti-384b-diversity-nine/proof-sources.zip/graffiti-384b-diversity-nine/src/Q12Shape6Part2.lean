import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6T72 : Tree 12 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))))
private theorem q12Shape6T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 6048422166528 q12Shape6T72=true := by decide

private def q12Shape6T74 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))))
private theorem q12Shape6T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288320 1650375655425 q12Shape6T74=true := by decide

private def q12Shape6T76 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11})))))))
private theorem q12Shape6T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288321 1650375655456 q12Shape6T76=true := by decide

private def q12Shape6T78 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))))
private theorem q12Shape6T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288353 1650375655488 q12Shape6T78=true := by decide

private def q12Shape6T79 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))) (.tip (.cover {0,1,2,4,5,7,11})))
private theorem q12Shape6T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288417 1650375655424 q12Shape6T79=true := by decide

private def q12Shape6T77 : Tree 12 := .split 6 q12Shape6T78 q12Shape6T79
private theorem q12Shape6T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288353 1650375655424 q12Shape6T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288353 (1650375655424 ||| 2^6) q12Shape6T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398063288353 ||| 2^6) 1650375655424 q12Shape6T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T78OK,q12Shape6T79OK⟩

private def q12Shape6T75 : Tree 12 := .split 5 q12Shape6T76 q12Shape6T77
private theorem q12Shape6T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288321 1650375655424 q12Shape6T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288321 (1650375655424 ||| 2^5) q12Shape6T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398063288321 ||| 2^5) 1650375655424 q12Shape6T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T76OK,q12Shape6T77OK⟩

private def q12Shape6T73 : Tree 12 := .split 0 q12Shape6T74 q12Shape6T75
private theorem q12Shape6T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288320 1650375655424 q12Shape6T73=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398063288320 (1650375655424 ||| 2^0) q12Shape6T74 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398063288320 ||| 2^0) 1650375655424 q12Shape6T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T74OK,q12Shape6T75OK⟩

private def q12Shape6T71 : Tree 12 := .split 42 q12Shape6T72 q12Shape6T73
private theorem q12Shape6T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 1650375655424 q12Shape6T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 (1650375655424 ||| 2^42) q12Shape6T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (16777216 ||| 2^42) 1650375655424 q12Shape6T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T72OK,q12Shape6T73OK⟩

private def q12Shape6T82 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))))
private theorem q12Shape6T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404992 4948910538753 q12Shape6T82=true := by decide

private def q12Shape6T84 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11})))))))
private theorem q12Shape6T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404993 4948910538784 q12Shape6T84=true := by decide

private def q12Shape6T86 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))))
private theorem q12Shape6T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528405025 4948910538816 q12Shape6T86=true := by decide

private def q12Shape6T87 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))) (.tip (.cover {0,1,2,4,5,7,11})))
private theorem q12Shape6T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528405089 4948910538752 q12Shape6T87=true := by decide

private def q12Shape6T85 : Tree 12 := .split 6 q12Shape6T86 q12Shape6T87
private theorem q12Shape6T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528405025 4948910538752 q12Shape6T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528405025 (4948910538752 ||| 2^6) q12Shape6T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099528405025 ||| 2^6) 4948910538752 q12Shape6T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T86OK,q12Shape6T87OK⟩

private def q12Shape6T83 : Tree 12 := .split 5 q12Shape6T84 q12Shape6T85
private theorem q12Shape6T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404993 4948910538752 q12Shape6T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404993 (4948910538752 ||| 2^5) q12Shape6T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099528404993 ||| 2^5) 4948910538752 q12Shape6T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T84OK,q12Shape6T85OK⟩

private def q12Shape6T81 : Tree 12 := .split 0 q12Shape6T82 q12Shape6T83
private theorem q12Shape6T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404992 4948910538752 q12Shape6T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404992 (4948910538752 ||| 2^0) q12Shape6T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099528404992 ||| 2^0) 4948910538752 q12Shape6T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T82OK,q12Shape6T83OK⟩

private def q12Shape6T88 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape6T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 5497574916096 550864027648 q12Shape6T88=true := by decide

private def q12Shape6T80 : Tree 12 := .split 42 q12Shape6T81 q12Shape6T88
private theorem q12Shape6T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404992 550864027648 q12Shape6T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099528404992 (550864027648 ||| 2^42) q12Shape6T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099528404992 ||| 2^42) 550864027648 q12Shape6T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T81OK,q12Shape6T88OK⟩

private def q12Shape6T70 : Tree 12 := .split 40 q12Shape6T71 q12Shape6T80
private theorem q12Shape6T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 550864027648 q12Shape6T70=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 (550864027648 ||| 2^40) q12Shape6T71 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (16777216 ||| 2^40) 550864027648 q12Shape6T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T71OK,q12Shape6T80OK⟩

private def q12Shape6T92 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))))
private theorem q12Shape6T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591104 5498666352641 q12Shape6T92=true := by decide

private def q12Shape6T94 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11})))))))
private theorem q12Shape6T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591105 5498666352672 q12Shape6T94=true := by decide

private def q12Shape6T96 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))))
private theorem q12Shape6T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591137 5498666352704 q12Shape6T96=true := by decide

private def q12Shape6T97 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,4,5,6,7,11})))) (.tip (.cover {0,1,2,4,5,7,11})))
private theorem q12Shape6T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591201 5498666352640 q12Shape6T97=true := by decide

private def q12Shape6T95 : Tree 12 := .split 6 q12Shape6T96 q12Shape6T97
private theorem q12Shape6T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591137 5498666352640 q12Shape6T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591137 (5498666352640 ||| 2^6) q12Shape6T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549772591137 ||| 2^6) 5498666352640 q12Shape6T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T96OK,q12Shape6T97OK⟩

private def q12Shape6T93 : Tree 12 := .split 5 q12Shape6T94 q12Shape6T95
private theorem q12Shape6T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591105 5498666352640 q12Shape6T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591105 (5498666352640 ||| 2^5) q12Shape6T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549772591105 ||| 2^5) 5498666352640 q12Shape6T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T94OK,q12Shape6T95OK⟩

private def q12Shape6T91 : Tree 12 := .split 0 q12Shape6T92 q12Shape6T93
private theorem q12Shape6T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591104 5498666352640 q12Shape6T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591104 (5498666352640 ||| 2^0) q12Shape6T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549772591104 ||| 2^0) 5498666352640 q12Shape6T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T92OK,q12Shape6T93OK⟩

private def q12Shape6T98 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape6T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4947819102208 1100619841536 q12Shape6T98=true := by decide

private def q12Shape6T90 : Tree 12 := .split 42 q12Shape6T91 q12Shape6T98
private theorem q12Shape6T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591104 1100619841536 q12Shape6T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591104 (1100619841536 ||| 2^42) q12Shape6T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549772591104 ||| 2^42) 1100619841536 q12Shape6T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T91OK,q12Shape6T98OK⟩

private def q12Shape6T99 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape6T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1649284218880 1108213760 q12Shape6T99=true := by decide

private def q12Shape6T89 : Tree 12 := .split 40 q12Shape6T90 q12Shape6T99
private theorem q12Shape6T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591104 1108213760 q12Shape6T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549772591104 (1108213760 ||| 2^40) q12Shape6T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549772591104 ||| 2^40) 1108213760 q12Shape6T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T90OK,q12Shape6T99OK⟩

private def q12Shape6T69 : Tree 12 := .split 39 q12Shape6T70 q12Shape6T89
private theorem q12Shape6T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 1108213760 q12Shape6T69=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 (1108213760 ||| 2^39) q12Shape6T70 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (16777216 ||| 2^39) 1108213760 q12Shape6T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T70OK,q12Shape6T89OK⟩

private def q12Shape6T100 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11}))))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape6T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1090519040 34471936 q12Shape6T100=true := by decide

private def q12Shape6T68 : Tree 12 := .split 30 q12Shape6T69 q12Shape6T100
private theorem q12Shape6T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 34471936 q12Shape6T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 (34471936 ||| 2^30) q12Shape6T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (16777216 ||| 2^30) 34471936 q12Shape6T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T69OK,q12Shape6T100OK⟩

private def q12Shape6T102 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 50331648 1074659328 q12Shape6T102=true := by decide

private def q12Shape6T103 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1124073472 917504 q12Shape6T103=true := by decide

private def q12Shape6T101 : Tree 12 := .split 30 q12Shape6T102 q12Shape6T103
private theorem q12Shape6T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 50331648 917504 q12Shape6T101=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 50331648 (917504 ||| 2^30) q12Shape6T102 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (50331648 ||| 2^30) 917504 q12Shape6T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T102OK,q12Shape6T103OK⟩

private def q12Shape6T67 : Tree 12 := .split 25 q12Shape6T68 q12Shape6T101
private theorem q12Shape6T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 917504 q12Shape6T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 (917504 ||| 2^25) q12Shape6T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (16777216 ||| 2^25) 917504 q12Shape6T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T68OK,q12Shape6T101OK⟩

def q12Shape6P2 : Tree 12 := q12Shape6T67
theorem q12Shape6P2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 16777216 917504 q12Shape6P2=true := q12Shape6T67OK

end Graffiti384b.EffectiveSearch.Q12
