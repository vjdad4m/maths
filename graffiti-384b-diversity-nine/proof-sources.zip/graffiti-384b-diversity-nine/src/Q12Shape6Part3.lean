import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6T110 : Tree 12 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11}))))))
private theorem q12Shape6T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 6048438419456 q12Shape6T110=true := by decide

private def q12Shape6T112 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))))
private theorem q12Shape6T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035392 1650391908353 q12Shape6T112=true := by decide

private def q12Shape6T114 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11})))))))
private theorem q12Shape6T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035393 1650391908384 q12Shape6T114=true := by decide

private def q12Shape6T116 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))))
private theorem q12Shape6T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035425 1650391908416 q12Shape6T116=true := by decide

private def q12Shape6T117 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))) (.tip (.cover {0,1,2,4,5,6,11})))
private theorem q12Shape6T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035489 1650391908352 q12Shape6T117=true := by decide

private def q12Shape6T115 : Tree 12 := .split 6 q12Shape6T116 q12Shape6T117
private theorem q12Shape6T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035425 1650391908352 q12Shape6T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035425 (1650391908352 ||| 2^6) q12Shape6T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398047035425 ||| 2^6) 1650391908352 q12Shape6T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T116OK,q12Shape6T117OK⟩

private def q12Shape6T113 : Tree 12 := .split 5 q12Shape6T114 q12Shape6T115
private theorem q12Shape6T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035393 1650391908352 q12Shape6T113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035393 (1650391908352 ||| 2^5) q12Shape6T114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398047035393 ||| 2^5) 1650391908352 q12Shape6T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T114OK,q12Shape6T115OK⟩

private def q12Shape6T111 : Tree 12 := .split 0 q12Shape6T112 q12Shape6T113
private theorem q12Shape6T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035392 1650391908352 q12Shape6T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398047035392 (1650391908352 ||| 2^0) q12Shape6T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398047035392 ||| 2^0) 1650391908352 q12Shape6T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T112OK,q12Shape6T113OK⟩

private def q12Shape6T109 : Tree 12 := .split 42 q12Shape6T110 q12Shape6T111
private theorem q12Shape6T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 1650391908352 q12Shape6T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 (1650391908352 ||| 2^42) q12Shape6T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (524288 ||| 2^42) 1650391908352 q12Shape6T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T110OK,q12Shape6T111OK⟩

private def q12Shape6T120 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))))
private theorem q12Shape6T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152064 4948926791681 q12Shape6T120=true := by decide

private def q12Shape6T122 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11})))))))
private theorem q12Shape6T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152065 4948926791712 q12Shape6T122=true := by decide

private def q12Shape6T124 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))))
private theorem q12Shape6T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152097 4948926791744 q12Shape6T124=true := by decide

private def q12Shape6T125 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))) (.tip (.cover {0,1,2,4,5,6,11})))
private theorem q12Shape6T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152161 4948926791680 q12Shape6T125=true := by decide

private def q12Shape6T123 : Tree 12 := .split 6 q12Shape6T124 q12Shape6T125
private theorem q12Shape6T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152097 4948926791680 q12Shape6T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152097 (4948926791680 ||| 2^6) q12Shape6T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099512152097 ||| 2^6) 4948926791680 q12Shape6T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T124OK,q12Shape6T125OK⟩

private def q12Shape6T121 : Tree 12 := .split 5 q12Shape6T122 q12Shape6T123
private theorem q12Shape6T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152065 4948926791680 q12Shape6T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152065 (4948926791680 ||| 2^5) q12Shape6T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099512152065 ||| 2^5) 4948926791680 q12Shape6T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T122OK,q12Shape6T123OK⟩

private def q12Shape6T119 : Tree 12 := .split 0 q12Shape6T120 q12Shape6T121
private theorem q12Shape6T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152064 4948926791680 q12Shape6T119=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152064 (4948926791680 ||| 2^0) q12Shape6T120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099512152064 ||| 2^0) 4948926791680 q12Shape6T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T120OK,q12Shape6T121OK⟩

private def q12Shape6T126 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape6T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 5497558663168 550880280576 q12Shape6T126=true := by decide

private def q12Shape6T118 : Tree 12 := .split 42 q12Shape6T119 q12Shape6T126
private theorem q12Shape6T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152064 550880280576 q12Shape6T118=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099512152064 (550880280576 ||| 2^42) q12Shape6T119 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099512152064 ||| 2^42) 550880280576 q12Shape6T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T119OK,q12Shape6T126OK⟩

private def q12Shape6T108 : Tree 12 := .split 40 q12Shape6T109 q12Shape6T118
private theorem q12Shape6T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 550880280576 q12Shape6T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 (550880280576 ||| 2^40) q12Shape6T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (524288 ||| 2^40) 550880280576 q12Shape6T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T109OK,q12Shape6T118OK⟩

private def q12Shape6T130 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6,11})))))
private theorem q12Shape6T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338176 5498682605569 q12Shape6T130=true := by decide

private def q12Shape6T132 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11})))))))
private theorem q12Shape6T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338177 5498682605600 q12Shape6T132=true := by decide

private def q12Shape6T134 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6,11}))))))
private theorem q12Shape6T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338209 5498682605632 q12Shape6T134=true := by decide

private def q12Shape6T135 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,4,5,6,7,11})))) (.tip (.cover {0,1,2,4,5,6,11})))
private theorem q12Shape6T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338273 5498682605568 q12Shape6T135=true := by decide

private def q12Shape6T133 : Tree 12 := .split 6 q12Shape6T134 q12Shape6T135
private theorem q12Shape6T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338209 5498682605568 q12Shape6T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338209 (5498682605568 ||| 2^6) q12Shape6T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756338209 ||| 2^6) 5498682605568 q12Shape6T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T134OK,q12Shape6T135OK⟩

private def q12Shape6T131 : Tree 12 := .split 5 q12Shape6T132 q12Shape6T133
private theorem q12Shape6T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338177 5498682605568 q12Shape6T131=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338177 (5498682605568 ||| 2^5) q12Shape6T132 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756338177 ||| 2^5) 5498682605568 q12Shape6T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T132OK,q12Shape6T133OK⟩

private def q12Shape6T129 : Tree 12 := .split 0 q12Shape6T130 q12Shape6T131
private theorem q12Shape6T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338176 5498682605568 q12Shape6T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338176 (5498682605568 ||| 2^0) q12Shape6T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756338176 ||| 2^0) 5498682605568 q12Shape6T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T130OK,q12Shape6T131OK⟩

private def q12Shape6T136 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape6T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4947802849280 1100636094464 q12Shape6T136=true := by decide

private def q12Shape6T128 : Tree 12 := .split 42 q12Shape6T129 q12Shape6T136
private theorem q12Shape6T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338176 1100636094464 q12Shape6T128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338176 (1100636094464 ||| 2^42) q12Shape6T129 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756338176 ||| 2^42) 1100636094464 q12Shape6T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T129OK,q12Shape6T136OK⟩

private def q12Shape6T137 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape6T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1649267965952 1124466688 q12Shape6T137=true := by decide

private def q12Shape6T127 : Tree 12 := .split 40 q12Shape6T128 q12Shape6T137
private theorem q12Shape6T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338176 1124466688 q12Shape6T127=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756338176 (1124466688 ||| 2^40) q12Shape6T128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756338176 ||| 2^40) 1124466688 q12Shape6T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T128OK,q12Shape6T137OK⟩

private def q12Shape6T107 : Tree 12 := .split 39 q12Shape6T108 q12Shape6T127
private theorem q12Shape6T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 1124466688 q12Shape6T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 (1124466688 ||| 2^39) q12Shape6T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (524288 ||| 2^39) 1124466688 q12Shape6T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T108OK,q12Shape6T127OK⟩

private def q12Shape6T138 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,10,11}))))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape6T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1074266112 50724864 q12Shape6T138=true := by decide

private def q12Shape6T106 : Tree 12 := .split 30 q12Shape6T107 q12Shape6T138
private theorem q12Shape6T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 50724864 q12Shape6T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 (50724864 ||| 2^30) q12Shape6T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (524288 ||| 2^30) 50724864 q12Shape6T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T107OK,q12Shape6T138OK⟩

private def q12Shape6T139 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,6,7,10,11}))))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape6T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 34078720 17170432 q12Shape6T139=true := by decide

private def q12Shape6T105 : Tree 12 := .split 25 q12Shape6T106 q12Shape6T139
private theorem q12Shape6T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 17170432 q12Shape6T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 (17170432 ||| 2^25) q12Shape6T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (524288 ||| 2^25) 17170432 q12Shape6T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T106OK,q12Shape6T139OK⟩

def q12Shape6P3 : Tree 12 := q12Shape6T105
theorem q12Shape6P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 524288 17170432 q12Shape6P3=true := q12Shape6T105OK

end Graffiti384b.EffectiveSearch.Q12
