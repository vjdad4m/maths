import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6T142 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17301504 1107689472 q12Shape6T142=true := by decide

private def q12Shape6T143 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T143OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1091043328 33947648 q12Shape6T143=true := by decide

private def q12Shape6T141 : Tree 12 := .split 30 q12Shape6T142 q12Shape6T143
private theorem q12Shape6T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17301504 33947648 q12Shape6T141=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17301504 (33947648 ||| 2^30) q12Shape6T142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (17301504 ||| 2^30) 33947648 q12Shape6T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T142OK,q12Shape6T143OK⟩

private def q12Shape6T144 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape6T144OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 50855936 393216 q12Shape6T144=true := by decide

private def q12Shape6T140 : Tree 12 := .split 25 q12Shape6T141 q12Shape6T144
private theorem q12Shape6T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17301504 393216 q12Shape6T140=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17301504 (393216 ||| 2^25) q12Shape6T141 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (17301504 ||| 2^25) 393216 q12Shape6T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T141OK,q12Shape6T144OK⟩

def q12Shape6P4 : Tree 12 := q12Shape6T140
theorem q12Shape6P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17301504 393216 q12Shape6P4=true := q12Shape6T140OK

end Graffiti384b.EffectiveSearch.Q12
