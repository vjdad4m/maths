import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6T152 : Tree 12 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11}))))))
private theorem q12Shape6T152OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 6048438681600 q12Shape6T152=true := by decide

private def q12Shape6T154 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))))
private theorem q12Shape6T154OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773248 1650392170497 q12Shape6T154=true := by decide

private def q12Shape6T156 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11})))))))
private theorem q12Shape6T156OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773249 1650392170528 q12Shape6T156=true := by decide

private def q12Shape6T158 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))))
private theorem q12Shape6T158OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773281 1650392170560 q12Shape6T158=true := by decide

private def q12Shape6T159 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))) (.tip (.cover {0,1,2,4,5,7,11})))
private theorem q12Shape6T159OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773345 1650392170496 q12Shape6T159=true := by decide

private def q12Shape6T157 : Tree 12 := .split 6 q12Shape6T158 q12Shape6T159
private theorem q12Shape6T157OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773281 1650392170496 q12Shape6T157=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773281 (1650392170496 ||| 2^6) q12Shape6T158 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398046773281 ||| 2^6) 1650392170496 q12Shape6T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T158OK,q12Shape6T159OK⟩

private def q12Shape6T155 : Tree 12 := .split 5 q12Shape6T156 q12Shape6T157
private theorem q12Shape6T155OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773249 1650392170496 q12Shape6T155=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773249 (1650392170496 ||| 2^5) q12Shape6T156 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398046773249 ||| 2^5) 1650392170496 q12Shape6T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T156OK,q12Shape6T157OK⟩

private def q12Shape6T153 : Tree 12 := .split 0 q12Shape6T154 q12Shape6T155
private theorem q12Shape6T153OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773248 1650392170496 q12Shape6T153=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046773248 (1650392170496 ||| 2^0) q12Shape6T154 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398046773248 ||| 2^0) 1650392170496 q12Shape6T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T154OK,q12Shape6T155OK⟩

private def q12Shape6T151 : Tree 12 := .split 42 q12Shape6T152 q12Shape6T153
private theorem q12Shape6T151OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 1650392170496 q12Shape6T151=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 (1650392170496 ||| 2^42) q12Shape6T152 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (262144 ||| 2^42) 1650392170496 q12Shape6T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T152OK,q12Shape6T153OK⟩

private def q12Shape6T162 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))))
private theorem q12Shape6T162OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889920 4948927053825 q12Shape6T162=true := by decide

private def q12Shape6T164 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11})))))))
private theorem q12Shape6T164OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889921 4948927053856 q12Shape6T164=true := by decide

private def q12Shape6T166 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))))
private theorem q12Shape6T166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889953 4948927053888 q12Shape6T166=true := by decide

private def q12Shape6T167 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))) (.tip (.cover {0,1,2,4,5,7,11})))
private theorem q12Shape6T167OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511890017 4948927053824 q12Shape6T167=true := by decide

private def q12Shape6T165 : Tree 12 := .split 6 q12Shape6T166 q12Shape6T167
private theorem q12Shape6T165OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889953 4948927053824 q12Shape6T165=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889953 (4948927053824 ||| 2^6) q12Shape6T166 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511889953 ||| 2^6) 4948927053824 q12Shape6T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T166OK,q12Shape6T167OK⟩

private def q12Shape6T163 : Tree 12 := .split 5 q12Shape6T164 q12Shape6T165
private theorem q12Shape6T163OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889921 4948927053824 q12Shape6T163=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889921 (4948927053824 ||| 2^5) q12Shape6T164 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511889921 ||| 2^5) 4948927053824 q12Shape6T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T164OK,q12Shape6T165OK⟩

private def q12Shape6T161 : Tree 12 := .split 0 q12Shape6T162 q12Shape6T163
private theorem q12Shape6T161OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889920 4948927053824 q12Shape6T161=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889920 (4948927053824 ||| 2^0) q12Shape6T162 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511889920 ||| 2^0) 4948927053824 q12Shape6T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T162OK,q12Shape6T163OK⟩

private def q12Shape6T168 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape6T168OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 5497558401024 550880542720 q12Shape6T168=true := by decide

private def q12Shape6T160 : Tree 12 := .split 42 q12Shape6T161 q12Shape6T168
private theorem q12Shape6T160OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889920 550880542720 q12Shape6T160=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511889920 (550880542720 ||| 2^42) q12Shape6T161 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511889920 ||| 2^42) 550880542720 q12Shape6T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T161OK,q12Shape6T168OK⟩

private def q12Shape6T150 : Tree 12 := .split 40 q12Shape6T151 q12Shape6T160
private theorem q12Shape6T150OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 550880542720 q12Shape6T150=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 (550880542720 ||| 2^40) q12Shape6T151 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (262144 ||| 2^40) 550880542720 q12Shape6T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T151OK,q12Shape6T160OK⟩

private def q12Shape6T172 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7,11})))))
private theorem q12Shape6T172OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076032 5498682867713 q12Shape6T172=true := by decide

private def q12Shape6T174 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11})))))))
private theorem q12Shape6T174OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076033 5498682867744 q12Shape6T174=true := by decide

private def q12Shape6T176 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7,11}))))))
private theorem q12Shape6T176OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076065 5498682867776 q12Shape6T176=true := by decide

private def q12Shape6T177 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,4,5,6,7,11})))) (.tip (.cover {0,1,2,4,5,7,11})))
private theorem q12Shape6T177OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076129 5498682867712 q12Shape6T177=true := by decide

private def q12Shape6T175 : Tree 12 := .split 6 q12Shape6T176 q12Shape6T177
private theorem q12Shape6T175OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076065 5498682867712 q12Shape6T175=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076065 (5498682867712 ||| 2^6) q12Shape6T176 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756076065 ||| 2^6) 5498682867712 q12Shape6T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T176OK,q12Shape6T177OK⟩

private def q12Shape6T173 : Tree 12 := .split 5 q12Shape6T174 q12Shape6T175
private theorem q12Shape6T173OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076033 5498682867712 q12Shape6T173=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076033 (5498682867712 ||| 2^5) q12Shape6T174 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756076033 ||| 2^5) 5498682867712 q12Shape6T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T174OK,q12Shape6T175OK⟩

private def q12Shape6T171 : Tree 12 := .split 0 q12Shape6T172 q12Shape6T173
private theorem q12Shape6T171OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076032 5498682867712 q12Shape6T171=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076032 (5498682867712 ||| 2^0) q12Shape6T172 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756076032 ||| 2^0) 5498682867712 q12Shape6T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T172OK,q12Shape6T173OK⟩

private def q12Shape6T178 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape6T178OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4947802587136 1100636356608 q12Shape6T178=true := by decide

private def q12Shape6T170 : Tree 12 := .split 42 q12Shape6T171 q12Shape6T178
private theorem q12Shape6T170OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076032 1100636356608 q12Shape6T170=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076032 (1100636356608 ||| 2^42) q12Shape6T171 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756076032 ||| 2^42) 1100636356608 q12Shape6T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T171OK,q12Shape6T178OK⟩

private def q12Shape6T179 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape6T179OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1649267703808 1124728832 q12Shape6T179=true := by decide

private def q12Shape6T169 : Tree 12 := .split 40 q12Shape6T170 q12Shape6T179
private theorem q12Shape6T169OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076032 1124728832 q12Shape6T169=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549756076032 (1124728832 ||| 2^40) q12Shape6T170 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549756076032 ||| 2^40) 1124728832 q12Shape6T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T170OK,q12Shape6T179OK⟩

private def q12Shape6T149 : Tree 12 := .split 39 q12Shape6T150 q12Shape6T169
private theorem q12Shape6T149OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 1124728832 q12Shape6T149=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 (1124728832 ||| 2^39) q12Shape6T150 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (262144 ||| 2^39) 1124728832 q12Shape6T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T150OK,q12Shape6T169OK⟩

private def q12Shape6T180 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11}))))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape6T180OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1074003968 50987008 q12Shape6T180=true := by decide

private def q12Shape6T148 : Tree 12 := .split 30 q12Shape6T149 q12Shape6T180
private theorem q12Shape6T148OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 50987008 q12Shape6T148=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 (50987008 ||| 2^30) q12Shape6T149 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (262144 ||| 2^30) 50987008 q12Shape6T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T149OK,q12Shape6T180OK⟩

private def q12Shape6T182 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T182OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33816576 1091174400 q12Shape6T182=true := by decide

private def q12Shape6T183 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T183OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1107558400 17432576 q12Shape6T183=true := by decide

private def q12Shape6T181 : Tree 12 := .split 30 q12Shape6T182 q12Shape6T183
private theorem q12Shape6T181OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33816576 17432576 q12Shape6T181=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33816576 (17432576 ||| 2^30) q12Shape6T182 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (33816576 ||| 2^30) 17432576 q12Shape6T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T182OK,q12Shape6T183OK⟩

private def q12Shape6T147 : Tree 12 := .split 25 q12Shape6T148 q12Shape6T181
private theorem q12Shape6T147OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 17432576 q12Shape6T147=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 (17432576 ||| 2^25) q12Shape6T148 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (262144 ||| 2^25) 17432576 q12Shape6T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T148OK,q12Shape6T181OK⟩

def q12Shape6P5 : Tree 12 := q12Shape6T147
theorem q12Shape6P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 262144 17432576 q12Shape6P5=true := q12Shape6T147OK

end Graffiti384b.EffectiveSearch.Q12
