import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6T185 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,6,7,10,11}))))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape6T185OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17039360 34209792 q12Shape6T185=true := by decide

private def q12Shape6T186 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape6T186OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 50593792 655360 q12Shape6T186=true := by decide

private def q12Shape6T184 : Tree 12 := .split 25 q12Shape6T185 q12Shape6T186
private theorem q12Shape6T184OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17039360 655360 q12Shape6T184=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17039360 (655360 ||| 2^25) q12Shape6T185 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (17039360 ||| 2^25) 655360 q12Shape6T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T185OK,q12Shape6T186OK⟩

def q12Shape6P6 : Tree 12 := q12Shape6T184
theorem q12Shape6P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17039360 655360 q12Shape6P6=true := q12Shape6T184OK

private def q12Shape6T191 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T191OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 1124204544 q12Shape6T191=true := by decide

private def q12Shape6T192 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape6T192OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1074528256 50462720 q12Shape6T192=true := by decide

private def q12Shape6T190 : Tree 12 := .split 30 q12Shape6T191 q12Shape6T192
private theorem q12Shape6T190OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 50462720 q12Shape6T190=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 (50462720 ||| 2^30) q12Shape6T191 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (786432 ||| 2^30) 50462720 q12Shape6T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T191OK,q12Shape6T192OK⟩

private def q12Shape6T193 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape6T193OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 34340864 16908288 q12Shape6T193=true := by decide

private def q12Shape6T189 : Tree 12 := .split 25 q12Shape6T190 q12Shape6T193
private theorem q12Shape6T189OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 16908288 q12Shape6T189=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 (16908288 ||| 2^25) q12Shape6T190 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (786432 ||| 2^25) 16908288 q12Shape6T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T190OK,q12Shape6T193OK⟩

private def q12Shape6T195 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10,11}))))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape6T195OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17563648 33685504 q12Shape6T195=true := by decide

private def q12Shape6T196 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {3,4,5,8,9,10,11})))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape6T196OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 51118080 131072 q12Shape6T196=true := by decide

private def q12Shape6T194 : Tree 12 := .split 25 q12Shape6T195 q12Shape6T196
private theorem q12Shape6T194OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17563648 131072 q12Shape6T194=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 17563648 (131072 ||| 2^25) q12Shape6T195 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (17563648 ||| 2^25) 131072 q12Shape6T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T195OK,q12Shape6T196OK⟩

private def q12Shape6T188 : Tree 12 := .split 24 q12Shape6T189 q12Shape6T194
private theorem q12Shape6T188OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 131072 q12Shape6T188=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 (131072 ||| 2^24) q12Shape6T189 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (786432 ||| 2^24) 131072 q12Shape6T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T189OK,q12Shape6T194OK⟩

def q12Shape6P7 : Tree 12 := q12Shape6T188
theorem q12Shape6P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 786432 131072 q12Shape6P7=true := q12Shape6T188OK

end Graffiti384b.EffectiveSearch.Q12
