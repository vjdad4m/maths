import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape6T204 : Tree 12 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11}))))))
private theorem q12Shape6T204OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 6048438812672 q12Shape6T204=true := by decide

private def q12Shape6T206 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11})))))
private theorem q12Shape6T206OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642176 1650392301569 q12Shape6T206=true := by decide

private def q12Shape6T208 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11})))))))
private theorem q12Shape6T208OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642177 1650392301600 q12Shape6T208=true := by decide

private def q12Shape6T210 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11}))))))
private theorem q12Shape6T210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642209 1650392301632 q12Shape6T210=true := by decide

private def q12Shape6T211 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11}))))) (.tip (.cover {0,1,2,4,6,7,11})))
private theorem q12Shape6T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642273 1650392301568 q12Shape6T211=true := by decide

private def q12Shape6T209 : Tree 12 := .split 6 q12Shape6T210 q12Shape6T211
private theorem q12Shape6T209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642209 1650392301568 q12Shape6T209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642209 (1650392301568 ||| 2^6) q12Shape6T210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398046642209 ||| 2^6) 1650392301568 q12Shape6T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T210OK,q12Shape6T211OK⟩

private def q12Shape6T207 : Tree 12 := .split 5 q12Shape6T208 q12Shape6T209
private theorem q12Shape6T207OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642177 1650392301568 q12Shape6T207=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642177 (1650392301568 ||| 2^5) q12Shape6T208 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398046642177 ||| 2^5) 1650392301568 q12Shape6T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T208OK,q12Shape6T209OK⟩

private def q12Shape6T205 : Tree 12 := .split 0 q12Shape6T206 q12Shape6T207
private theorem q12Shape6T205OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642176 1650392301568 q12Shape6T205=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4398046642176 (1650392301568 ||| 2^0) q12Shape6T206 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (4398046642176 ||| 2^0) 1650392301568 q12Shape6T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T206OK,q12Shape6T207OK⟩

private def q12Shape6T203 : Tree 12 := .split 42 q12Shape6T204 q12Shape6T205
private theorem q12Shape6T203OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 1650392301568 q12Shape6T203=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (1650392301568 ||| 2^42) q12Shape6T204 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^42) 1650392301568 q12Shape6T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T204OK,q12Shape6T205OK⟩

private def q12Shape6T214 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11})))))
private theorem q12Shape6T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758848 4948927184897 q12Shape6T214=true := by decide

private def q12Shape6T216 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11})))))))
private theorem q12Shape6T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758849 4948927184928 q12Shape6T216=true := by decide

private def q12Shape6T218 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11}))))))
private theorem q12Shape6T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758881 4948927184960 q12Shape6T218=true := by decide

private def q12Shape6T219 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11}))))) (.tip (.cover {0,1,2,4,6,7,11})))
private theorem q12Shape6T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758945 4948927184896 q12Shape6T219=true := by decide

private def q12Shape6T217 : Tree 12 := .split 6 q12Shape6T218 q12Shape6T219
private theorem q12Shape6T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758881 4948927184896 q12Shape6T217=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758881 (4948927184896 ||| 2^6) q12Shape6T218 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511758881 ||| 2^6) 4948927184896 q12Shape6T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T218OK,q12Shape6T219OK⟩

private def q12Shape6T215 : Tree 12 := .split 5 q12Shape6T216 q12Shape6T217
private theorem q12Shape6T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758849 4948927184896 q12Shape6T215=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758849 (4948927184896 ||| 2^5) q12Shape6T216 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511758849 ||| 2^5) 4948927184896 q12Shape6T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T216OK,q12Shape6T217OK⟩

private def q12Shape6T213 : Tree 12 := .split 0 q12Shape6T214 q12Shape6T215
private theorem q12Shape6T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758848 4948927184896 q12Shape6T213=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758848 (4948927184896 ||| 2^0) q12Shape6T214 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511758848 ||| 2^0) 4948927184896 q12Shape6T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T214OK,q12Shape6T215OK⟩

private def q12Shape6T220 : Tree 12 := (.tip (.cover {0,1,4,6,7,10,11}))
private theorem q12Shape6T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 5497558269952 550880673792 q12Shape6T220=true := by decide

private def q12Shape6T212 : Tree 12 := .split 42 q12Shape6T213 q12Shape6T220
private theorem q12Shape6T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758848 550880673792 q12Shape6T212=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1099511758848 (550880673792 ||| 2^42) q12Shape6T213 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (1099511758848 ||| 2^42) 550880673792 q12Shape6T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T213OK,q12Shape6T220OK⟩

private def q12Shape6T202 : Tree 12 := .split 40 q12Shape6T203 q12Shape6T212
private theorem q12Shape6T202OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 550880673792 q12Shape6T202=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (550880673792 ||| 2^40) q12Shape6T203 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^40) 550880673792 q12Shape6T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T203OK,q12Shape6T212OK⟩

private def q12Shape6T224 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7,11})))))
private theorem q12Shape6T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944960 5498682998785 q12Shape6T224=true := by decide

private def q12Shape6T226 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11})))))))
private theorem q12Shape6T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944961 5498682998816 q12Shape6T226=true := by decide

private def q12Shape6T228 : Tree 12 := (.split 7 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7,11}))))))
private theorem q12Shape6T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944993 5498682998848 q12Shape6T228=true := by decide

private def q12Shape6T229 : Tree 12 := (.split 7 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,4,5,6,7,11})))) (.tip (.cover {0,1,2,4,6,7,11})))
private theorem q12Shape6T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755945057 5498682998784 q12Shape6T229=true := by decide

private def q12Shape6T227 : Tree 12 := .split 6 q12Shape6T228 q12Shape6T229
private theorem q12Shape6T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944993 5498682998784 q12Shape6T227=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944993 (5498682998784 ||| 2^6) q12Shape6T228 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549755944993 ||| 2^6) 5498682998784 q12Shape6T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T228OK,q12Shape6T229OK⟩

private def q12Shape6T225 : Tree 12 := .split 5 q12Shape6T226 q12Shape6T227
private theorem q12Shape6T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944961 5498682998784 q12Shape6T225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944961 (5498682998784 ||| 2^5) q12Shape6T226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549755944961 ||| 2^5) 5498682998784 q12Shape6T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T226OK,q12Shape6T227OK⟩

private def q12Shape6T223 : Tree 12 := .split 0 q12Shape6T224 q12Shape6T225
private theorem q12Shape6T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944960 5498682998784 q12Shape6T223=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944960 (5498682998784 ||| 2^0) q12Shape6T224 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549755944960 ||| 2^0) 5498682998784 q12Shape6T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T224OK,q12Shape6T225OK⟩

private def q12Shape6T230 : Tree 12 := (.tip (.cover {0,1,4,6,7,9,11}))
private theorem q12Shape6T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 4947802456064 1100636487680 q12Shape6T230=true := by decide

private def q12Shape6T222 : Tree 12 := .split 42 q12Shape6T223 q12Shape6T230
private theorem q12Shape6T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944960 1100636487680 q12Shape6T222=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944960 (1100636487680 ||| 2^42) q12Shape6T223 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549755944960 ||| 2^42) 1100636487680 q12Shape6T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T223OK,q12Shape6T230OK⟩

private def q12Shape6T231 : Tree 12 := (.tip (.cover {0,1,4,6,7,8,11}))
private theorem q12Shape6T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1649267572736 1124859904 q12Shape6T231=true := by decide

private def q12Shape6T221 : Tree 12 := .split 40 q12Shape6T222 q12Shape6T231
private theorem q12Shape6T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944960 1124859904 q12Shape6T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 549755944960 (1124859904 ||| 2^40) q12Shape6T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (549755944960 ||| 2^40) 1124859904 q12Shape6T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T222OK,q12Shape6T231OK⟩

private def q12Shape6T201 : Tree 12 := .split 39 q12Shape6T202 q12Shape6T221
private theorem q12Shape6T201OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 1124859904 q12Shape6T201=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (1124859904 ||| 2^39) q12Shape6T202 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^39) 1124859904 q12Shape6T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T202OK,q12Shape6T221OK⟩

private def q12Shape6T232 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11}))))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape6T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1073872896 51118080 q12Shape6T232=true := by decide

private def q12Shape6T200 : Tree 12 := .split 30 q12Shape6T201 q12Shape6T232
private theorem q12Shape6T200OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 51118080 q12Shape6T200=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (51118080 ||| 2^30) q12Shape6T201 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^30) 51118080 q12Shape6T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T201OK,q12Shape6T232OK⟩

private def q12Shape6T234 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11}))))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape6T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33685504 1091305472 q12Shape6T234=true := by decide

private def q12Shape6T235 : Tree 12 := (.split 39 (.split 40 (.split 42 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10,11}))))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape6T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 1107427328 17563648 q12Shape6T235=true := by decide

private def q12Shape6T233 : Tree 12 := .split 30 q12Shape6T234 q12Shape6T235
private theorem q12Shape6T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33685504 17563648 q12Shape6T233=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 33685504 (17563648 ||| 2^30) q12Shape6T234 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (33685504 ||| 2^30) 17563648 q12Shape6T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T234OK,q12Shape6T235OK⟩

private def q12Shape6T199 : Tree 12 := .split 25 q12Shape6T200 q12Shape6T233
private theorem q12Shape6T199OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 17563648 q12Shape6T199=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 (17563648 ||| 2^25) q12Shape6T200 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) (131072 ||| 2^25) 17563648 q12Shape6T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape6T200OK,q12Shape6T233OK⟩

def q12Shape6P8 : Tree 12 := q12Shape6T199
theorem q12Shape6P8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,2⟩) 131072 17563648 q12Shape6P8=true := q12Shape6T199OK

end Graffiti384b.EffectiveSearch.Q12
