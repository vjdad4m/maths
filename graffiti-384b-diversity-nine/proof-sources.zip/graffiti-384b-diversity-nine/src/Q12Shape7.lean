import Q12Shape7Part0
import Q12Shape7Part1
import Q12Shape7Part2
import Q12Shape7Part3
import Q12Shape7Part4
import Q12Shape7Part5
import Q12Shape7Part6

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape7M98 : Tree 12 := .split 1 q12Shape7P2 q12Shape7P3
private theorem q12Shape7M98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813889 1124073472 q12Shape7M98=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813889 (1124073472 ||| 2^1) q12Shape7P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813889 ||| 2^1) 1124073472 q12Shape7P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7P2OK,q12Shape7P3OK⟩
private def q12Shape7M99 : Tree 12 := .split 0 q12Shape7P1 q12Shape7M98
private theorem q12Shape7M99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 1124073472 q12Shape7M99=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 (1124073472 ||| 2^0) q12Shape7P1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813888 ||| 2^0) 1124073472 q12Shape7M98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7P1OK,q12Shape7M98OK⟩
private def q12Shape7M100 : Tree 12 := .split 39 q12Shape7P0 q12Shape7M99
private theorem q12Shape7M100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 1124073472 q12Shape7M100=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 (1124073472 ||| 2^39) q12Shape7P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (0 ||| 2^39) 1124073472 q12Shape7M99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7P0OK,q12Shape7M99OK⟩
private def q12Shape7M120 : Tree 12 := .split 30 q12Shape7M100 q12Shape7P4
private theorem q12Shape7M120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 50331648 q12Shape7M120=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 (50331648 ||| 2^30) q12Shape7M100 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (0 ||| 2^30) 50331648 q12Shape7P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7M100OK,q12Shape7P4OK⟩
private def q12Shape7M142 : Tree 12 := .split 25 q12Shape7M120 q12Shape7P5
private theorem q12Shape7M142OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 16777216 q12Shape7M142=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 (16777216 ||| 2^25) q12Shape7M120 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (0 ||| 2^25) 16777216 q12Shape7P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7M120OK,q12Shape7P5OK⟩
private def q12Shape7M166 : Tree 12 := .split 24 q12Shape7M142 q12Shape7P6
private theorem q12Shape7M166OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 0 q12Shape7M166=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 (0 ||| 2^24) q12Shape7M142 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (0 ||| 2^24) 0 q12Shape7P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7M142OK,q12Shape7P6OK⟩

theorem q12Shape7_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 7) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 7) b) (adj 12 (forms 7) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) adj_mono b H q12Shape7M166 q12Shape7M166OK

#print axioms q12Shape7_cover

end Graffiti384b.EffectiveSearch.Q12
