import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape7T2 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10,11})))))))))
private theorem q12Shape7T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 550879887363 q12Shape7T2=true := by decide

private def q12Shape7T4 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10,11}))))))))
private theorem q12Shape7T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 2 550879887873 q12Shape7T4=true := by decide

private def q12Shape7T6 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))))))
private theorem q12Shape7T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 514 550879887393 q12Shape7T6=true := by decide

private def q12Shape7T8 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11}))))))
private theorem q12Shape7T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 546 550879887425 q12Shape7T8=true := by decide

private def q12Shape7T9 : Tree 12 := (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11}))))) (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))) (.tip (.cover {2,3,5,6,7,10,11}))))
private theorem q12Shape7T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 610 550879887361 q12Shape7T9=true := by decide

private def q12Shape7T7 : Tree 12 := .split 6 q12Shape7T8 q12Shape7T9
private theorem q12Shape7T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 546 550879887361 q12Shape7T7=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 546 (550879887361 ||| 2^6) q12Shape7T8 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (546 ||| 2^6) 550879887361 q12Shape7T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T8OK,q12Shape7T9OK⟩

private def q12Shape7T5 : Tree 12 := .split 5 q12Shape7T6 q12Shape7T7
private theorem q12Shape7T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 514 550879887361 q12Shape7T5=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 514 (550879887361 ||| 2^5) q12Shape7T6 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (514 ||| 2^5) 550879887361 q12Shape7T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T6OK,q12Shape7T7OK⟩

private def q12Shape7T3 : Tree 12 := .split 9 q12Shape7T4 q12Shape7T5
private theorem q12Shape7T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 2 550879887361 q12Shape7T3=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 2 (550879887361 ||| 2^9) q12Shape7T4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (2 ||| 2^9) 550879887361 q12Shape7T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T4OK,q12Shape7T5OK⟩

private def q12Shape7T1 : Tree 12 := .split 1 q12Shape7T2 q12Shape7T3
private theorem q12Shape7T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 550879887361 q12Shape7T1=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 (550879887361 ||| 2^1) q12Shape7T2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (0 ||| 2^1) 550879887361 q12Shape7T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T2OK,q12Shape7T3OK⟩

private def q12Shape7T12 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10,11}))))))))
private theorem q12Shape7T12OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1 550879887874 q12Shape7T12=true := by decide

private def q12Shape7T14 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,5,6,7,10,11})))))
private theorem q12Shape7T14OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 513 550879887394 q12Shape7T14=true := by decide

private def q12Shape7T16 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,5,6,7,10,11}))))
private theorem q12Shape7T16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 545 550879887426 q12Shape7T16=true := by decide

private def q12Shape7T17 : Tree 12 := (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {2,4,5,6,7,10,11}))))) (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {2,4,5,6,7,10,11})))) (.tip (.cover {1,3,5,6,7,10,11}))))
private theorem q12Shape7T17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 609 550879887362 q12Shape7T17=true := by decide

private def q12Shape7T15 : Tree 12 := .split 6 q12Shape7T16 q12Shape7T17
private theorem q12Shape7T15OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 545 550879887362 q12Shape7T15=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 545 (550879887362 ||| 2^6) q12Shape7T16 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (545 ||| 2^6) 550879887362 q12Shape7T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T16OK,q12Shape7T17OK⟩

private def q12Shape7T13 : Tree 12 := .split 5 q12Shape7T14 q12Shape7T15
private theorem q12Shape7T13OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 513 550879887362 q12Shape7T13=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 513 (550879887362 ||| 2^5) q12Shape7T14 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (513 ||| 2^5) 550879887362 q12Shape7T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T14OK,q12Shape7T15OK⟩

private def q12Shape7T11 : Tree 12 := .split 9 q12Shape7T12 q12Shape7T13
private theorem q12Shape7T11OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1 550879887362 q12Shape7T11=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1 (550879887362 ||| 2^9) q12Shape7T12 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1 ||| 2^9) 550879887362 q12Shape7T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T12OK,q12Shape7T13OK⟩

private def q12Shape7T20 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {3,4,5,6,7,10,11})))))))
private theorem q12Shape7T20OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 3 550879887904 q12Shape7T20=true := by decide

private def q12Shape7T21 : Tree 12 := (.split 6 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {3,4,5,6,7,10,11})))))) (.tip (.cover {1,2,5,6,7,10,11})))
private theorem q12Shape7T21OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 35 550879887872 q12Shape7T21=true := by decide

private def q12Shape7T19 : Tree 12 := .split 5 q12Shape7T20 q12Shape7T21
private theorem q12Shape7T19OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 3 550879887872 q12Shape7T19=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 3 (550879887872 ||| 2^5) q12Shape7T20 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (3 ||| 2^5) 550879887872 q12Shape7T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T20OK,q12Shape7T21OK⟩

private def q12Shape7T24 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {1,3,5,6,7,10,11}))))
private theorem q12Shape7T24OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 515 550879887456 q12Shape7T24=true := by decide

private def q12Shape7T25 : Tree 12 := (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11}))))) (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))) (.tip (.cover {1,3,5,6,7,10,11}))))
private theorem q12Shape7T25OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 579 550879887392 q12Shape7T25=true := by decide

private def q12Shape7T23 : Tree 12 := .split 6 q12Shape7T24 q12Shape7T25
private theorem q12Shape7T23OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 515 550879887392 q12Shape7T23=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 515 (550879887392 ||| 2^6) q12Shape7T24 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (515 ||| 2^6) 550879887392 q12Shape7T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T24OK,q12Shape7T25OK⟩

private def q12Shape7T26 : Tree 12 := (.split 6 (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11}))))) (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11}))) (.tip (.cover {1,3,5,6,7,10,11})))) (.tip (.cover {1,2,5,6,7,10,11})))
private theorem q12Shape7T26OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 547 550879887360 q12Shape7T26=true := by decide

private def q12Shape7T22 : Tree 12 := .split 5 q12Shape7T23 q12Shape7T26
private theorem q12Shape7T22OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 515 550879887360 q12Shape7T22=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 515 (550879887360 ||| 2^5) q12Shape7T23 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (515 ||| 2^5) 550879887360 q12Shape7T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T23OK,q12Shape7T26OK⟩

private def q12Shape7T18 : Tree 12 := .split 9 q12Shape7T19 q12Shape7T22
private theorem q12Shape7T18OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 3 550879887360 q12Shape7T18=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 3 (550879887360 ||| 2^9) q12Shape7T19 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (3 ||| 2^9) 550879887360 q12Shape7T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T19OK,q12Shape7T22OK⟩

private def q12Shape7T10 : Tree 12 := .split 1 q12Shape7T11 q12Shape7T18
private theorem q12Shape7T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1 550879887360 q12Shape7T10=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1 (550879887360 ||| 2^1) q12Shape7T11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1 ||| 2^1) 550879887360 q12Shape7T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T11OK,q12Shape7T18OK⟩

private def q12Shape7T0 : Tree 12 := .split 0 q12Shape7T1 q12Shape7T10
private theorem q12Shape7T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 550879887360 q12Shape7T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 (550879887360 ||| 2^0) q12Shape7T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (0 ||| 2^0) 550879887360 q12Shape7T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T1OK,q12Shape7T10OK⟩

def q12Shape7P0 : Tree 12 := q12Shape7T0
theorem q12Shape7P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 0 550879887360 q12Shape7P0=true := q12Shape7T0OK

end Graffiti384b.EffectiveSearch.Q12
