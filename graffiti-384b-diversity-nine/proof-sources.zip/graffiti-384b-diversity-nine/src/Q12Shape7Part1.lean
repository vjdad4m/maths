import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape7T29 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))))))
private theorem q12Shape7T29OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 1124073987 q12Shape7T29=true := by decide

private def q12Shape7T31 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))))))
private theorem q12Shape7T31OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814400 1124073507 q12Shape7T31=true := by decide

private def q12Shape7T33 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))))
private theorem q12Shape7T33OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814432 1124073539 q12Shape7T33=true := by decide

private def q12Shape7T35 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))))
private theorem q12Shape7T35OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814496 1124081667 q12Shape7T35=true := by decide

private def q12Shape7T36 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {1,5,6,7,8,10,11}))))
private theorem q12Shape7T36OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822688 1124073475 q12Shape7T36=true := by decide

private def q12Shape7T34 : Tree 12 := .split 13 q12Shape7T35 q12Shape7T36
private theorem q12Shape7T34OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814496 1124073475 q12Shape7T34=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814496 (1124073475 ||| 2^13) q12Shape7T35 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814496 ||| 2^13) 1124073475 q12Shape7T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T35OK,q12Shape7T36OK⟩

private def q12Shape7T32 : Tree 12 := .split 6 q12Shape7T33 q12Shape7T34
private theorem q12Shape7T32OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814432 1124073475 q12Shape7T32=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814432 (1124073475 ||| 2^6) q12Shape7T33 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814432 ||| 2^6) 1124073475 q12Shape7T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T33OK,q12Shape7T34OK⟩

private def q12Shape7T30 : Tree 12 := .split 5 q12Shape7T31 q12Shape7T32
private theorem q12Shape7T30OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814400 1124073475 q12Shape7T30=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814400 (1124073475 ||| 2^5) q12Shape7T31 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814400 ||| 2^5) 1124073475 q12Shape7T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T31OK,q12Shape7T32OK⟩

private def q12Shape7T28 : Tree 12 := .split 9 q12Shape7T29 q12Shape7T30
private theorem q12Shape7T28OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 1124073475 q12Shape7T28=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 (1124073475 ||| 2^9) q12Shape7T29 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813888 ||| 2^9) 1124073475 q12Shape7T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T29OK,q12Shape7T30OK⟩

private def q12Shape7T39 : Tree 12 := (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))))))
private theorem q12Shape7T39OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813890 1124074017 q12Shape7T39=true := by decide

private def q12Shape7T41 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11})))))
private theorem q12Shape7T41OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813922 1124074049 q12Shape7T41=true := by decide

private def q12Shape7T43 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))))
private theorem q12Shape7T43OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813986 1124082177 q12Shape7T43=true := by decide

private def q12Shape7T44 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {1,5,6,7,8,10,11}))))
private theorem q12Shape7T44OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822178 1124073985 q12Shape7T44=true := by decide

private def q12Shape7T42 : Tree 12 := .split 13 q12Shape7T43 q12Shape7T44
private theorem q12Shape7T42OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813986 1124073985 q12Shape7T42=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813986 (1124073985 ||| 2^13) q12Shape7T43 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813986 ||| 2^13) 1124073985 q12Shape7T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T43OK,q12Shape7T44OK⟩

private def q12Shape7T40 : Tree 12 := .split 6 q12Shape7T41 q12Shape7T42
private theorem q12Shape7T40OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813922 1124073985 q12Shape7T40=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813922 (1124073985 ||| 2^6) q12Shape7T41 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813922 ||| 2^6) 1124073985 q12Shape7T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T41OK,q12Shape7T42OK⟩

private def q12Shape7T38 : Tree 12 := .split 5 q12Shape7T39 q12Shape7T40
private theorem q12Shape7T38OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813890 1124073985 q12Shape7T38=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813890 (1124073985 ||| 2^5) q12Shape7T39 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813890 ||| 2^5) 1124073985 q12Shape7T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T39OK,q12Shape7T40OK⟩

private def q12Shape7T47 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11}))))))
private theorem q12Shape7T47OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814402 1124073569 q12Shape7T47=true := by decide

private def q12Shape7T49 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {4,5,6,7,9,10,11}))))
private theorem q12Shape7T49OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814466 1124081697 q12Shape7T49=true := by decide

private def q12Shape7T50 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {4,5,6,7,9,10,11}))))
private theorem q12Shape7T50OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822658 1124073505 q12Shape7T50=true := by decide

private def q12Shape7T48 : Tree 12 := .split 13 q12Shape7T49 q12Shape7T50
private theorem q12Shape7T48OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814466 1124073505 q12Shape7T48=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814466 (1124073505 ||| 2^13) q12Shape7T49 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814466 ||| 2^13) 1124073505 q12Shape7T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T49OK,q12Shape7T50OK⟩

private def q12Shape7T46 : Tree 12 := .split 6 q12Shape7T47 q12Shape7T48
private theorem q12Shape7T46OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814402 1124073505 q12Shape7T46=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814402 (1124073505 ||| 2^6) q12Shape7T47 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814402 ||| 2^6) 1124073505 q12Shape7T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T47OK,q12Shape7T48OK⟩

private def q12Shape7T53 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))))
private theorem q12Shape7T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814434 1124081729 q12Shape7T53=true := by decide

private def q12Shape7T54 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10,11}))) (.tip (.cover {1,5,6,7,8,10,11}))))
private theorem q12Shape7T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822626 1124073537 q12Shape7T54=true := by decide

private def q12Shape7T52 : Tree 12 := .split 13 q12Shape7T53 q12Shape7T54
private theorem q12Shape7T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814434 1124073537 q12Shape7T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814434 (1124073537 ||| 2^13) q12Shape7T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814434 ||| 2^13) 1124073537 q12Shape7T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T53OK,q12Shape7T54OK⟩

private def q12Shape7T56 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {4,5,6,7,9,10,11}))))
private theorem q12Shape7T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814498 1124081665 q12Shape7T56=true := by decide

private def q12Shape7T57 : Tree 12 := (.split 14 (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10,11}))) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {2,3,5,6,7,10,11})))
private theorem q12Shape7T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822690 1124073473 q12Shape7T57=true := by decide

private def q12Shape7T55 : Tree 12 := .split 13 q12Shape7T56 q12Shape7T57
private theorem q12Shape7T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814498 1124073473 q12Shape7T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814498 (1124073473 ||| 2^13) q12Shape7T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814498 ||| 2^13) 1124073473 q12Shape7T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T56OK,q12Shape7T57OK⟩

private def q12Shape7T51 : Tree 12 := .split 6 q12Shape7T52 q12Shape7T55
private theorem q12Shape7T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814434 1124073473 q12Shape7T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814434 (1124073473 ||| 2^6) q12Shape7T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814434 ||| 2^6) 1124073473 q12Shape7T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T52OK,q12Shape7T55OK⟩

private def q12Shape7T45 : Tree 12 := .split 5 q12Shape7T46 q12Shape7T51
private theorem q12Shape7T45OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814402 1124073473 q12Shape7T45=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814402 (1124073473 ||| 2^5) q12Shape7T46 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814402 ||| 2^5) 1124073473 q12Shape7T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T46OK,q12Shape7T51OK⟩

private def q12Shape7T37 : Tree 12 := .split 9 q12Shape7T38 q12Shape7T45
private theorem q12Shape7T37OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813890 1124073473 q12Shape7T37=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813890 (1124073473 ||| 2^9) q12Shape7T38 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813890 ||| 2^9) 1124073473 q12Shape7T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T38OK,q12Shape7T45OK⟩

private def q12Shape7T27 : Tree 12 := .split 1 q12Shape7T28 q12Shape7T37
private theorem q12Shape7T27OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 1124073473 q12Shape7T27=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 (1124073473 ||| 2^1) q12Shape7T28 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813888 ||| 2^1) 1124073473 q12Shape7T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T28OK,q12Shape7T37OK⟩

def q12Shape7P1 : Tree 12 := q12Shape7T27
theorem q12Shape7P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813888 1124073473 q12Shape7P1=true := q12Shape7T27OK

end Graffiti384b.EffectiveSearch.Q12
