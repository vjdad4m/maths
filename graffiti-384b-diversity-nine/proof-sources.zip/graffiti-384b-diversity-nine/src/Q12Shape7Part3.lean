import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape7T78 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {3,4,5,6,7,10,11}))))))
private theorem q12Shape7T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 1124074080 q12Shape7T78=true := by decide

private def q12Shape7T80 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))))
private theorem q12Shape7T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813955 1124082208 q12Shape7T80=true := by decide

private def q12Shape7T81 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10,11}))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {2,5,6,7,8,10,11}))))
private theorem q12Shape7T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822147 1124074016 q12Shape7T81=true := by decide

private def q12Shape7T79 : Tree 12 := .split 13 q12Shape7T80 q12Shape7T81
private theorem q12Shape7T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813955 1124074016 q12Shape7T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813955 (1124074016 ||| 2^13) q12Shape7T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813955 ||| 2^13) 1124074016 q12Shape7T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T80OK,q12Shape7T81OK⟩

private def q12Shape7T77 : Tree 12 := .split 6 q12Shape7T78 q12Shape7T79
private theorem q12Shape7T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 1124074016 q12Shape7T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 (1124074016 ||| 2^6) q12Shape7T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813891 ||| 2^6) 1124074016 q12Shape7T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T78OK,q12Shape7T79OK⟩

private def q12Shape7T84 : Tree 12 := (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10,11})))))
private theorem q12Shape7T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813923 1124082240 q12Shape7T84=true := by decide

private def q12Shape7T85 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10,11}))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10,11}))) (.tip (.cover {1,5,6,7,8,10,11}))))
private theorem q12Shape7T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822115 1124074048 q12Shape7T85=true := by decide

private def q12Shape7T83 : Tree 12 := .split 13 q12Shape7T84 q12Shape7T85
private theorem q12Shape7T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813923 1124074048 q12Shape7T83=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813923 (1124074048 ||| 2^13) q12Shape7T84 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813923 ||| 2^13) 1124074048 q12Shape7T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T84OK,q12Shape7T85OK⟩

private def q12Shape7T86 : Tree 12 := (.tip (.cover {1,2,5,6,7,10,11}))
private theorem q12Shape7T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813987 1124073984 q12Shape7T86=true := by decide

private def q12Shape7T82 : Tree 12 := .split 6 q12Shape7T83 q12Shape7T86
private theorem q12Shape7T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813923 1124073984 q12Shape7T82=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813923 (1124073984 ||| 2^6) q12Shape7T83 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813923 ||| 2^6) 1124073984 q12Shape7T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T83OK,q12Shape7T86OK⟩

private def q12Shape7T76 : Tree 12 := .split 5 q12Shape7T77 q12Shape7T82
private theorem q12Shape7T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 1124073984 q12Shape7T76=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 (1124073984 ||| 2^5) q12Shape7T77 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813891 ||| 2^5) 1124073984 q12Shape7T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T77OK,q12Shape7T82OK⟩

private def q12Shape7T89 : Tree 12 := (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11}))))) (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))) (.tip (.cover {1,3,5,6,7,10,11}))))
private theorem q12Shape7T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814403 1124073568 q12Shape7T89=true := by decide

private def q12Shape7T91 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {4,5,6,7,9,10,11}))))
private theorem q12Shape7T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814467 1124081696 q12Shape7T91=true := by decide

private def q12Shape7T92 : Tree 12 := (.split 14 (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {3,5,6,7,9,10,11}))) (.tip (.cover {2,5,6,7,8,10,11}))) (.tip (.cover {1,3,5,6,7,10,11})))
private theorem q12Shape7T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822659 1124073504 q12Shape7T92=true := by decide

private def q12Shape7T90 : Tree 12 := .split 13 q12Shape7T91 q12Shape7T92
private theorem q12Shape7T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814467 1124073504 q12Shape7T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814467 (1124073504 ||| 2^13) q12Shape7T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814467 ||| 2^13) 1124073504 q12Shape7T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T91OK,q12Shape7T92OK⟩

private def q12Shape7T88 : Tree 12 := .split 6 q12Shape7T89 q12Shape7T90
private theorem q12Shape7T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814403 1124073504 q12Shape7T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814403 (1124073504 ||| 2^6) q12Shape7T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814403 ||| 2^6) 1124073504 q12Shape7T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T89OK,q12Shape7T90OK⟩

private def q12Shape7T95 : Tree 12 := (.split 14 (.split 20 (.tip (.small 1)) (.split 21 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10,11})))) (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10,11}))) (.tip (.cover {3,5,6,7,8,10,11}))))
private theorem q12Shape7T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814435 1124081728 q12Shape7T95=true := by decide

private def q12Shape7T96 : Tree 12 := (.split 14 (.split 20 (.split 21 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10,11}))) (.tip (.cover {1,5,6,7,8,10,11}))) (.tip (.cover {1,3,5,6,7,10,11})))
private theorem q12Shape7T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755822627 1124073536 q12Shape7T96=true := by decide

private def q12Shape7T94 : Tree 12 := .split 13 q12Shape7T95 q12Shape7T96
private theorem q12Shape7T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814435 1124073536 q12Shape7T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814435 (1124073536 ||| 2^13) q12Shape7T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814435 ||| 2^13) 1124073536 q12Shape7T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T95OK,q12Shape7T96OK⟩

private def q12Shape7T97 : Tree 12 := (.tip (.cover {1,2,5,6,7,10,11}))
private theorem q12Shape7T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814499 1124073472 q12Shape7T97=true := by decide

private def q12Shape7T93 : Tree 12 := .split 6 q12Shape7T94 q12Shape7T97
private theorem q12Shape7T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814435 1124073472 q12Shape7T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814435 (1124073472 ||| 2^6) q12Shape7T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814435 ||| 2^6) 1124073472 q12Shape7T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T94OK,q12Shape7T97OK⟩

private def q12Shape7T87 : Tree 12 := .split 5 q12Shape7T88 q12Shape7T93
private theorem q12Shape7T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814403 1124073472 q12Shape7T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755814403 (1124073472 ||| 2^5) q12Shape7T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755814403 ||| 2^5) 1124073472 q12Shape7T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T88OK,q12Shape7T93OK⟩

private def q12Shape7T75 : Tree 12 := .split 9 q12Shape7T76 q12Shape7T87
private theorem q12Shape7T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 1124073472 q12Shape7T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 (1124073472 ||| 2^9) q12Shape7T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (549755813891 ||| 2^9) 1124073472 q12Shape7T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T76OK,q12Shape7T87OK⟩

def q12Shape7P3 : Tree 12 := q12Shape7T75
theorem q12Shape7P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549755813891 1124073472 q12Shape7P3=true := q12Shape7T75OK

end Graffiti384b.EffectiveSearch.Q12
