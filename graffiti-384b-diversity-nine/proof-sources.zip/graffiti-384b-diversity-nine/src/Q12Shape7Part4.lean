import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape7T104 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11})))))
private theorem q12Shape7T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 549806145539 q12Shape7T104=true := by decide

private def q12Shape7T106 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741826 549806146049 q12Shape7T106=true := by decide

private def q12Shape7T107 : Tree 12 := (.split 5 (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))) (.split 6 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742338 549806145537 q12Shape7T107=true := by decide

private def q12Shape7T105 : Tree 12 := .split 9 q12Shape7T106 q12Shape7T107
private theorem q12Shape7T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741826 549806145537 q12Shape7T105=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741826 (549806145537 ||| 2^9) q12Shape7T106 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073741826 ||| 2^9) 549806145537 q12Shape7T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T106OK,q12Shape7T107OK⟩

private def q12Shape7T103 : Tree 12 := .split 1 q12Shape7T104 q12Shape7T105
private theorem q12Shape7T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 549806145537 q12Shape7T103=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 (549806145537 ||| 2^1) q12Shape7T104 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073741824 ||| 2^1) 549806145537 q12Shape7T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T104OK,q12Shape7T105OK⟩

private def q12Shape7T110 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741825 549806146050 q12Shape7T110=true := by decide

private def q12Shape7T111 : Tree 12 := (.split 5 (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))) (.split 6 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742337 549806145538 q12Shape7T111=true := by decide

private def q12Shape7T109 : Tree 12 := .split 9 q12Shape7T110 q12Shape7T111
private theorem q12Shape7T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741825 549806145538 q12Shape7T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741825 (549806145538 ||| 2^9) q12Shape7T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073741825 ||| 2^9) 549806145538 q12Shape7T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T110OK,q12Shape7T111OK⟩

private def q12Shape7T113 : Tree 12 := (.split 5 (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))) (.split 6 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741827 549806146048 q12Shape7T113=true := by decide

private def q12Shape7T116 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))
private theorem q12Shape7T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742339 549806145632 q12Shape7T116=true := by decide

private def q12Shape7T117 : Tree 12 := (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))) (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,1,3,5,6,10,11}))))
private theorem q12Shape7T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742403 549806145568 q12Shape7T117=true := by decide

private def q12Shape7T115 : Tree 12 := .split 6 q12Shape7T116 q12Shape7T117
private theorem q12Shape7T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742339 549806145568 q12Shape7T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742339 (549806145568 ||| 2^6) q12Shape7T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073742339 ||| 2^6) 549806145568 q12Shape7T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T116OK,q12Shape7T117OK⟩

private def q12Shape7T118 : Tree 12 := (.split 6 (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))) (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11})))
private theorem q12Shape7T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742371 549806145536 q12Shape7T118=true := by decide

private def q12Shape7T114 : Tree 12 := .split 5 q12Shape7T115 q12Shape7T118
private theorem q12Shape7T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742339 549806145536 q12Shape7T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073742339 (549806145536 ||| 2^5) q12Shape7T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073742339 ||| 2^5) 549806145536 q12Shape7T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T115OK,q12Shape7T118OK⟩

private def q12Shape7T112 : Tree 12 := .split 9 q12Shape7T113 q12Shape7T114
private theorem q12Shape7T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741827 549806145536 q12Shape7T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741827 (549806145536 ||| 2^9) q12Shape7T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073741827 ||| 2^9) 549806145536 q12Shape7T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T113OK,q12Shape7T114OK⟩

private def q12Shape7T108 : Tree 12 := .split 1 q12Shape7T109 q12Shape7T112
private theorem q12Shape7T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741825 549806145536 q12Shape7T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741825 (549806145536 ||| 2^1) q12Shape7T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073741825 ||| 2^1) 549806145536 q12Shape7T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T109OK,q12Shape7T112OK⟩

private def q12Shape7T102 : Tree 12 := .split 0 q12Shape7T103 q12Shape7T108
private theorem q12Shape7T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 549806145536 q12Shape7T102=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 (549806145536 ||| 2^0) q12Shape7T103 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073741824 ||| 2^0) 549806145536 q12Shape7T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T103OK,q12Shape7T108OK⟩

private def q12Shape7T119 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape7T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 550829555712 50331648 q12Shape7T119=true := by decide

private def q12Shape7T101 : Tree 12 := .split 39 q12Shape7T102 q12Shape7T119
private theorem q12Shape7T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 50331648 q12Shape7T101=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 (50331648 ||| 2^39) q12Shape7T102 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (1073741824 ||| 2^39) 50331648 q12Shape7T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T102OK,q12Shape7T119OK⟩

def q12Shape7P4 : Tree 12 := q12Shape7T101
theorem q12Shape7P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1073741824 50331648 q12Shape7P4=true := q12Shape7T101OK

end Graffiti384b.EffectiveSearch.Q12
