import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape7T125 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11})))))
private theorem q12Shape7T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 550846332931 q12Shape7T125=true := by decide

private def q12Shape7T127 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554434 550846333441 q12Shape7T127=true := by decide

private def q12Shape7T128 : Tree 12 := (.split 5 (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))) (.split 6 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554946 550846332929 q12Shape7T128=true := by decide

private def q12Shape7T126 : Tree 12 := .split 9 q12Shape7T127 q12Shape7T128
private theorem q12Shape7T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554434 550846332929 q12Shape7T126=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554434 (550846332929 ||| 2^9) q12Shape7T127 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554434 ||| 2^9) 550846332929 q12Shape7T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T127OK,q12Shape7T128OK⟩

private def q12Shape7T124 : Tree 12 := .split 1 q12Shape7T125 q12Shape7T126
private theorem q12Shape7T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 550846332929 q12Shape7T124=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 (550846332929 ||| 2^1) q12Shape7T125 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554432 ||| 2^1) 550846332929 q12Shape7T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T125OK,q12Shape7T126OK⟩

private def q12Shape7T131 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T131OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554433 550846333442 q12Shape7T131=true := by decide

private def q12Shape7T132 : Tree 12 := (.split 5 (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))) (.split 6 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T132OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554945 550846332930 q12Shape7T132=true := by decide

private def q12Shape7T130 : Tree 12 := .split 9 q12Shape7T131 q12Shape7T132
private theorem q12Shape7T130OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554433 550846332930 q12Shape7T130=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554433 (550846332930 ||| 2^9) q12Shape7T131 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554433 ||| 2^9) 550846332930 q12Shape7T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T131OK,q12Shape7T132OK⟩

private def q12Shape7T134 : Tree 12 := (.split 5 (.split 6 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))) (.split 6 (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11}))))
private theorem q12Shape7T134OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554435 550846333440 q12Shape7T134=true := by decide

private def q12Shape7T137 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10,11}))))
private theorem q12Shape7T137OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554947 550846333024 q12Shape7T137=true := by decide

private def q12Shape7T138 : Tree 12 := (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))) (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,1,3,5,6,10,11}))))
private theorem q12Shape7T138OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33555011 550846332960 q12Shape7T138=true := by decide

private def q12Shape7T136 : Tree 12 := .split 6 q12Shape7T137 q12Shape7T138
private theorem q12Shape7T136OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554947 550846332960 q12Shape7T136=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554947 (550846332960 ||| 2^6) q12Shape7T137 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554947 ||| 2^6) 550846332960 q12Shape7T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T137OK,q12Shape7T138OK⟩

private def q12Shape7T139 : Tree 12 := (.split 6 (.split 13 (.split 14 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11})))) (.split 14 (.split 20 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10,11}))) (.tip (.cover {0,1,3,5,6,10,11})))) (.tip (.cover {0,1,2,5,6,10,11})))
private theorem q12Shape7T139OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554979 550846332928 q12Shape7T139=true := by decide

private def q12Shape7T135 : Tree 12 := .split 5 q12Shape7T136 q12Shape7T139
private theorem q12Shape7T135OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554947 550846332928 q12Shape7T135=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554947 (550846332928 ||| 2^5) q12Shape7T136 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554947 ||| 2^5) 550846332928 q12Shape7T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T136OK,q12Shape7T139OK⟩

private def q12Shape7T133 : Tree 12 := .split 9 q12Shape7T134 q12Shape7T135
private theorem q12Shape7T133OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554435 550846332928 q12Shape7T133=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554435 (550846332928 ||| 2^9) q12Shape7T134 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554435 ||| 2^9) 550846332928 q12Shape7T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T134OK,q12Shape7T135OK⟩

private def q12Shape7T129 : Tree 12 := .split 1 q12Shape7T130 q12Shape7T133
private theorem q12Shape7T129OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554433 550846332928 q12Shape7T129=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554433 (550846332928 ||| 2^1) q12Shape7T130 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554433 ||| 2^1) 550846332928 q12Shape7T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T130OK,q12Shape7T133OK⟩

private def q12Shape7T123 : Tree 12 := .split 0 q12Shape7T124 q12Shape7T129
private theorem q12Shape7T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 550846332928 q12Shape7T123=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 (550846332928 ||| 2^0) q12Shape7T124 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554432 ||| 2^0) 550846332928 q12Shape7T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T124OK,q12Shape7T129OK⟩

private def q12Shape7T140 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape7T140OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 549789368320 1090519040 q12Shape7T140=true := by decide

private def q12Shape7T122 : Tree 12 := .split 39 q12Shape7T123 q12Shape7T140
private theorem q12Shape7T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 1090519040 q12Shape7T122=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 (1090519040 ||| 2^39) q12Shape7T123 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554432 ||| 2^39) 1090519040 q12Shape7T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T123OK,q12Shape7T140OK⟩

private def q12Shape7T141 : Tree 12 := (.tip (.cover {0,1,7,8,9,10,11}))
private theorem q12Shape7T141OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 1107296256 16777216 q12Shape7T141=true := by decide

private def q12Shape7T121 : Tree 12 := .split 30 q12Shape7T122 q12Shape7T141
private theorem q12Shape7T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 16777216 q12Shape7T121=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 (16777216 ||| 2^30) q12Shape7T122 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) (33554432 ||| 2^30) 16777216 q12Shape7T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape7T122OK,q12Shape7T141OK⟩

def q12Shape7P5 : Tree 12 := q12Shape7T121
theorem q12Shape7P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,3⟩) 33554432 16777216 q12Shape7P5=true := q12Shape7T121OK

end Graffiti384b.EffectiveSearch.Q12
