import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape8T1 : Tree 12 := (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))))
private theorem q12Shape8T1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 0 1073741831 q12Shape8T1=true := by decide

private def q12Shape8T3 : Tree 12 := (.split 10 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10,11})))))))
private theorem q12Shape8T3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 4 1073742339 q12Shape8T3=true := by decide

private def q12Shape8T5 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))
private theorem q12Shape8T5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 516 1073742851 q12Shape8T5=true := by decide

private def q12Shape8T7 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape8T7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1540 1073872899 q12Shape8T7=true := by decide

private def q12Shape8T9 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))))
private theorem q12Shape8T9OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132612 1073741859 q12Shape8T9=true := by decide

private def q12Shape8T10 : Tree 12 := (.split 13 (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))) (.split 20 (.split 26 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {5,6,7,8,9,10,11}))))
private theorem q12Shape8T10OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132644 1073741827 q12Shape8T10=true := by decide

private def q12Shape8T8 : Tree 12 := .split 5 q12Shape8T9 q12Shape8T10
private theorem q12Shape8T8OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132612 1073741827 q12Shape8T8=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132612 (1073741827 ||| 2^5) q12Shape8T9 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (132612 ||| 2^5) 1073741827 q12Shape8T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T9OK,q12Shape8T10OK⟩

private def q12Shape8T6 : Tree 12 := .split 17 q12Shape8T7 q12Shape8T8
private theorem q12Shape8T6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1540 1073741827 q12Shape8T6=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1540 (1073741827 ||| 2^17) q12Shape8T7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (1540 ||| 2^17) 1073741827 q12Shape8T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T7OK,q12Shape8T8OK⟩

private def q12Shape8T4 : Tree 12 := .split 10 q12Shape8T5 q12Shape8T6
private theorem q12Shape8T4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 516 1073741827 q12Shape8T4=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 516 (1073741827 ||| 2^10) q12Shape8T5 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (516 ||| 2^10) 1073741827 q12Shape8T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T5OK,q12Shape8T6OK⟩

private def q12Shape8T2 : Tree 12 := .split 9 q12Shape8T3 q12Shape8T4
private theorem q12Shape8T2OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 4 1073741827 q12Shape8T2=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 4 (1073741827 ||| 2^9) q12Shape8T3 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (4 ||| 2^9) 1073741827 q12Shape8T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T3OK,q12Shape8T4OK⟩

private def q12Shape8T0 : Tree 12 := .split 2 q12Shape8T1 q12Shape8T2
private theorem q12Shape8T0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 0 1073741827 q12Shape8T0=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 0 (1073741827 ||| 2^2) q12Shape8T1 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (0 ||| 2^2) 1073741827 q12Shape8T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T1OK,q12Shape8T2OK⟩

def q12Shape8P0 : Tree 12 := q12Shape8T0
theorem q12Shape8P0OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 0 1073741827 q12Shape8P0=true := q12Shape8T0OK

end Graffiti384b.EffectiveSearch.Q12
