import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape8T65 : Tree 12 := (.split 17 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11})))))))
private theorem q12Shape8T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 1073743364 q12Shape8T65=true := by decide

private def q12Shape8T67 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape8T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1027 1073873412 q12Shape8T67=true := by decide

private def q12Shape8T69 : Tree 12 := (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {3,4,6,7,9,10,11}))))
private theorem q12Shape8T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132099 1073742372 q12Shape8T69=true := by decide

private def q12Shape8T70 : Tree 12 := (.split 13 (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10,11})))) (.split 20 (.split 26 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10,11}))) (.tip (.cover {3,4,6,7,9,10,11}))))
private theorem q12Shape8T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132131 1073742340 q12Shape8T70=true := by decide

private def q12Shape8T68 : Tree 12 := .split 5 q12Shape8T69 q12Shape8T70
private theorem q12Shape8T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132099 1073742340 q12Shape8T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132099 (1073742340 ||| 2^5) q12Shape8T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (132099 ||| 2^5) 1073742340 q12Shape8T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T69OK,q12Shape8T70OK⟩

private def q12Shape8T66 : Tree 12 := .split 17 q12Shape8T67 q12Shape8T68
private theorem q12Shape8T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1027 1073742340 q12Shape8T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1027 (1073742340 ||| 2^17) q12Shape8T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (1027 ||| 2^17) 1073742340 q12Shape8T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T67OK,q12Shape8T68OK⟩

private def q12Shape8T64 : Tree 12 := .split 10 q12Shape8T65 q12Shape8T66
private theorem q12Shape8T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 1073742340 q12Shape8T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 (1073742340 ||| 2^10) q12Shape8T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (3 ||| 2^10) 1073742340 q12Shape8T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T65OK,q12Shape8T66OK⟩

private def q12Shape8T73 : Tree 12 := (.split 5 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10,11}))))))
private theorem q12Shape8T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 515 1073873924 q12Shape8T73=true := by decide

private def q12Shape8T74 : Tree 12 := (.split 5 (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10,11})))) (.split 13 (.split 20 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10,11}))) (.split 20 (.split 26 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10,11}))) (.tip (.cover {1,4,6,7,9,10,11})))))
private theorem q12Shape8T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 131587 1073742852 q12Shape8T74=true := by decide

private def q12Shape8T72 : Tree 12 := .split 17 q12Shape8T73 q12Shape8T74
private theorem q12Shape8T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 515 1073742852 q12Shape8T72=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 515 (1073742852 ||| 2^17) q12Shape8T73 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (515 ||| 2^17) 1073742852 q12Shape8T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T73OK,q12Shape8T74OK⟩

private def q12Shape8T76 : Tree 12 := (.split 5 (.split 13 (.tip (.small 1)) (.tip (.cover {1,3,6,7,9,10,11}))) (.split 13 (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10,11})))) (.tip (.cover {1,3,6,7,9,10,11}))))
private theorem q12Shape8T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1539 1073872900 q12Shape8T76=true := by decide

private def q12Shape8T77 : Tree 12 := (.split 5 (.split 13 (.split 20 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10,11}))) (.tip (.cover {1,3,6,7,9,10,11}))) (.split 13 (.split 20 (.split 26 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10,11}))) (.tip (.cover {1,4,6,7,9,10,11}))) (.tip (.cover {1,3,6,7,9,10,11}))))
private theorem q12Shape8T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132611 1073741828 q12Shape8T77=true := by decide

private def q12Shape8T75 : Tree 12 := .split 17 q12Shape8T76 q12Shape8T77
private theorem q12Shape8T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1539 1073741828 q12Shape8T75=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1539 (1073741828 ||| 2^17) q12Shape8T76 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (1539 ||| 2^17) 1073741828 q12Shape8T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T76OK,q12Shape8T77OK⟩

private def q12Shape8T71 : Tree 12 := .split 10 q12Shape8T72 q12Shape8T75
private theorem q12Shape8T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 515 1073741828 q12Shape8T71=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 515 (1073741828 ||| 2^10) q12Shape8T72 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (515 ||| 2^10) 1073741828 q12Shape8T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T72OK,q12Shape8T75OK⟩

private def q12Shape8T63 : Tree 12 := .split 9 q12Shape8T64 q12Shape8T71
private theorem q12Shape8T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 1073741828 q12Shape8T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 (1073741828 ||| 2^9) q12Shape8T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (3 ||| 2^9) 1073741828 q12Shape8T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T64OK,q12Shape8T71OK⟩

private def q12Shape8T80 : Tree 12 := (.split 17 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10,11}))) (.split 5 (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10,11}))))) (.tip (.cover {1,2,6,7,9,10,11}))))
private theorem q12Shape8T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 7 1073743360 q12Shape8T80=true := by decide

private def q12Shape8T82 : Tree 12 := (.split 5 (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10,11}))))) (.tip (.cover {1,2,6,7,9,10,11})))
private theorem q12Shape8T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1031 1073873408 q12Shape8T82=true := by decide

private def q12Shape8T83 : Tree 12 := (.split 5 (.split 13 (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11})))) (.split 20 (.split 26 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10,11}))) (.tip (.cover {3,4,6,7,9,10,11})))) (.tip (.cover {1,2,6,7,9,10,11})))
private theorem q12Shape8T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132103 1073742336 q12Shape8T83=true := by decide

private def q12Shape8T81 : Tree 12 := .split 17 q12Shape8T82 q12Shape8T83
private theorem q12Shape8T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1031 1073742336 q12Shape8T81=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1031 (1073742336 ||| 2^17) q12Shape8T82 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (1031 ||| 2^17) 1073742336 q12Shape8T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T82OK,q12Shape8T83OK⟩

private def q12Shape8T79 : Tree 12 := .split 10 q12Shape8T80 q12Shape8T81
private theorem q12Shape8T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 7 1073742336 q12Shape8T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 7 (1073742336 ||| 2^10) q12Shape8T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (7 ||| 2^10) 1073742336 q12Shape8T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T80OK,q12Shape8T81OK⟩

private def q12Shape8T86 : Tree 12 := (.split 5 (.split 13 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10,11}))))) (.tip (.cover {1,2,6,7,9,10,11})))
private theorem q12Shape8T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 519 1073873920 q12Shape8T86=true := by decide

private def q12Shape8T87 : Tree 12 := (.split 5 (.split 13 (.split 20 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10,11}))) (.split 20 (.split 26 (.tip (.small 1)) (.tip (.cover {3,5,6,7,9,10,11}))) (.tip (.cover {1,4,6,7,9,10,11})))) (.tip (.cover {1,2,6,7,9,10,11})))
private theorem q12Shape8T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 131591 1073742848 q12Shape8T87=true := by decide

private def q12Shape8T85 : Tree 12 := .split 17 q12Shape8T86 q12Shape8T87
private theorem q12Shape8T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 519 1073742848 q12Shape8T85=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 519 (1073742848 ||| 2^17) q12Shape8T86 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (519 ||| 2^17) 1073742848 q12Shape8T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T86OK,q12Shape8T87OK⟩

private def q12Shape8T89 : Tree 12 := (.split 5 (.split 13 (.split 20 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover {4,5,6,7,9,10,11})))) (.tip (.cover {1,3,6,7,9,10,11}))) (.tip (.cover {1,2,6,7,9,10,11})))
private theorem q12Shape8T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1543 1073872896 q12Shape8T89=true := by decide

private def q12Shape8T90 : Tree 12 := (.split 5 (.split 13 (.split 20 (.tip (.cover {1,5,6,7,9,10,11})) (.tip (.cover {1,4,6,7,9,10,11}))) (.tip (.cover {1,3,6,7,9,10,11}))) (.tip (.cover {1,2,6,7,9,10,11})))
private theorem q12Shape8T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 132615 1073741824 q12Shape8T90=true := by decide

private def q12Shape8T88 : Tree 12 := .split 17 q12Shape8T89 q12Shape8T90
private theorem q12Shape8T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1543 1073741824 q12Shape8T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1543 (1073741824 ||| 2^17) q12Shape8T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (1543 ||| 2^17) 1073741824 q12Shape8T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T89OK,q12Shape8T90OK⟩

private def q12Shape8T84 : Tree 12 := .split 10 q12Shape8T85 q12Shape8T88
private theorem q12Shape8T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 519 1073741824 q12Shape8T84=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 519 (1073741824 ||| 2^10) q12Shape8T85 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (519 ||| 2^10) 1073741824 q12Shape8T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T85OK,q12Shape8T88OK⟩

private def q12Shape8T78 : Tree 12 := .split 9 q12Shape8T79 q12Shape8T84
private theorem q12Shape8T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 7 1073741824 q12Shape8T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 7 (1073741824 ||| 2^9) q12Shape8T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (7 ||| 2^9) 1073741824 q12Shape8T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T79OK,q12Shape8T84OK⟩

private def q12Shape8T62 : Tree 12 := .split 2 q12Shape8T63 q12Shape8T78
private theorem q12Shape8T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 1073741824 q12Shape8T62=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 (1073741824 ||| 2^2) q12Shape8T63 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) (3 ||| 2^2) 1073741824 q12Shape8T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape8T63OK,q12Shape8T78OK⟩

def q12Shape8P3 : Tree 12 := q12Shape8T62
theorem q12Shape8P3OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 3 1073741824 q12Shape8P3=true := q12Shape8T62OK

private def q12Shape8T93 : Tree 12 := (.tip (.cover {0,1,6,8,9,10,11}))
private theorem q12Shape8T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1073741824 0 q12Shape8T93=true := by decide

def q12Shape8P4 : Tree 12 := q12Shape8T93
theorem q12Shape8P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,5,4⟩) 1073741824 0 q12Shape8P4=true := q12Shape8T93OK

end Graffiti384b.EffectiveSearch.Q12
