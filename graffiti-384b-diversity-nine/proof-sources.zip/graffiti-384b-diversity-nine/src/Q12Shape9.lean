import Q12Shape9Part0
import Q12Shape9Part1
import Q12Shape9Part2
import Q12Shape9Part3
import Q12Shape9Part4
import Q12Shape9Part5
import Q12Shape9Part6
import Q12Shape9Part7
import Q12Shape9Part8
import Q12Shape9Part9
import Q12Shape9Part10

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape9M128 : Tree 12 := .split 25 q12Shape9P0 q12Shape9P1
private theorem q12Shape9M128OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 17694720 q12Shape9M128=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 (17694720 ||| 2^25) q12Shape9P0 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (0 ||| 2^25) 17694720 q12Shape9P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9P0OK,q12Shape9P1OK⟩
private def q12Shape9M209 : Tree 12 := .split 25 q12Shape9P2 q12Shape9P3
private theorem q12Shape9M209OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 16777216 917504 q12Shape9M209=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 16777216 (917504 ||| 2^25) q12Shape9P2 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (16777216 ||| 2^25) 917504 q12Shape9P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9P2OK,q12Shape9P3OK⟩
private def q12Shape9M210 : Tree 12 := .split 24 q12Shape9M128 q12Shape9M209
private theorem q12Shape9M210OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 917504 q12Shape9M210=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 (917504 ||| 2^24) q12Shape9M128 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (0 ||| 2^24) 917504 q12Shape9M209)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M128OK,q12Shape9M209OK⟩
private def q12Shape9M273 : Tree 12 := .split 25 q12Shape9P4 q12Shape9P5
private theorem q12Shape9M273OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 17170432 q12Shape9M273=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (17170432 ||| 2^25) q12Shape9P4 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^25) 17170432 q12Shape9P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9P4OK,q12Shape9P5OK⟩
private def q12Shape9M279 : Tree 12 := .split 24 q12Shape9M273 q12Shape9P6
private theorem q12Shape9M279OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 393216 q12Shape9M279=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (393216 ||| 2^24) q12Shape9M273 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^24) 393216 q12Shape9P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M273OK,q12Shape9P6OK⟩
private def q12Shape9M280 : Tree 12 := .split 19 q12Shape9M210 q12Shape9M279
private theorem q12Shape9M280OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 393216 q12Shape9M280=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 (393216 ||| 2^19) q12Shape9M210 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (0 ||| 2^19) 393216 q12Shape9M279)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M210OK,q12Shape9M279OK⟩
private def q12Shape9M345 : Tree 12 := .split 25 q12Shape9P7 q12Shape9P8
private theorem q12Shape9M345OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 17432576 q12Shape9M345=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (17432576 ||| 2^25) q12Shape9P7 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^25) 17432576 q12Shape9P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9P7OK,q12Shape9P8OK⟩
private def q12Shape9M349 : Tree 12 := .split 24 q12Shape9M345 q12Shape9P9
private theorem q12Shape9M349OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 655360 q12Shape9M349=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (655360 ||| 2^24) q12Shape9M345 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^24) 655360 q12Shape9P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M345OK,q12Shape9P9OK⟩
private def q12Shape9M359 : Tree 12 := .split 19 q12Shape9M349 q12Shape9P10
private theorem q12Shape9M359OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 131072 q12Shape9M359=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (131072 ||| 2^19) q12Shape9M349 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^19) 131072 q12Shape9P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M349OK,q12Shape9P10OK⟩
private def q12Shape9M360 : Tree 12 := .split 18 q12Shape9M280 q12Shape9M359
private theorem q12Shape9M360OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 131072 q12Shape9M360=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 (131072 ||| 2^18) q12Shape9M280 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (0 ||| 2^18) 131072 q12Shape9M359)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M280OK,q12Shape9M359OK⟩
private def q12Shape9M467 : Tree 12 := .split 39 q12Shape9P11 q12Shape9P12
private theorem q12Shape9M467OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 1124859904 q12Shape9M467=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 (1124859904 ||| 2^39) q12Shape9P11 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (131072 ||| 2^39) 1124859904 q12Shape9P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9P11OK,q12Shape9P12OK⟩
private def q12Shape9M469 : Tree 12 := .split 30 q12Shape9M467 q12Shape9P13
private theorem q12Shape9M469OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 51118080 q12Shape9M469=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 (51118080 ||| 2^30) q12Shape9M467 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (131072 ||| 2^30) 51118080 q12Shape9P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M467OK,q12Shape9P13OK⟩
private def q12Shape9M473 : Tree 12 := .split 25 q12Shape9M469 q12Shape9P14
private theorem q12Shape9M473OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 17563648 q12Shape9M473=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 (17563648 ||| 2^25) q12Shape9M469 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (131072 ||| 2^25) 17563648 q12Shape9P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M469OK,q12Shape9P14OK⟩
private def q12Shape9M479 : Tree 12 := .split 24 q12Shape9M473 q12Shape9P15
private theorem q12Shape9M479OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 786432 q12Shape9M479=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 (786432 ||| 2^24) q12Shape9M473 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (131072 ||| 2^24) 786432 q12Shape9P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M473OK,q12Shape9P15OK⟩
private def q12Shape9M491 : Tree 12 := .split 19 q12Shape9M479 q12Shape9P16
private theorem q12Shape9M491OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 262144 q12Shape9M491=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 (262144 ||| 2^19) q12Shape9M479 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (131072 ||| 2^19) 262144 q12Shape9P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M479OK,q12Shape9P16OK⟩
private def q12Shape9M505 : Tree 12 := .split 18 q12Shape9M491 q12Shape9P17
private theorem q12Shape9M505OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 0 q12Shape9M505=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 131072 (0 ||| 2^18) q12Shape9M491 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (131072 ||| 2^18) 0 q12Shape9P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M491OK,q12Shape9P17OK⟩
private def q12Shape9M506 : Tree 12 := .split 17 q12Shape9M360 q12Shape9M505
private theorem q12Shape9M506OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 0 q12Shape9M506=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 0 (0 ||| 2^17) q12Shape9M360 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (0 ||| 2^17) 0 q12Shape9M505)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9M360OK,q12Shape9M505OK⟩

theorem q12Shape9_cover (b : Nat→Bool) (H : Ranked (adj 12 (forms 9) b) (root (n:=12) (by decide))) :
    ∃ D : Finset (Label 12),D.card≤7 ∧ Effective (adj 12 (forms 9) b) (adj 12 (forms 9) b) D :=
  checked_fast_tree (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) adj_mono b H q12Shape9M506 q12Shape9M506OK

#print axioms q12Shape9_cover

end Graffiti384b.EffectiveSearch.Q12
