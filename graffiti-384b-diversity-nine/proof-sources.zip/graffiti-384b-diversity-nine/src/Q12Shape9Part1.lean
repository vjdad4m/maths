import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape9T57 : Tree 12 := (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.tip (.cover {0,1,2,3,6,7,10})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,9,10}))))
private theorem q12Shape9T57OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 17043521667072 q12Shape9T57=true := by decide

private def q12Shape9T60 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9}))) (.split 28 (.tip (.cover {1,2,3,4,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9})))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,9,10})))
private theorem q12Shape9T60OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796126576640 25839615737856 q12Shape9T60=true := by decide

private def q12Shape9T61 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape9T61OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796127625216 25839614689280 q12Shape9T61=true := by decide

private def q12Shape9T59 : Tree 12 := .split 20 q12Shape9T60 q12Shape9T61
private theorem q12Shape9T59OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796126576640 25839614689280 q12Shape9T59=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796126576640 (25839614689280 ||| 2^20) q12Shape9T60 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (8796126576640 ||| 2^20) 25839614689280 q12Shape9T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T60OK,q12Shape9T61OK⟩

private def q12Shape9T62 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape9T62OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 26388312621056 8247428644864 q12Shape9T62=true := by decide

private def q12Shape9T58 : Tree 12 := .split 44 q12Shape9T59 q12Shape9T62
private theorem q12Shape9T58OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796126576640 8247428644864 q12Shape9T58=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796126576640 (8247428644864 ||| 2^44) q12Shape9T59 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (8796126576640 ||| 2^44) 8247428644864 q12Shape9T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T59OK,q12Shape9T62OK⟩

private def q12Shape9T56 : Tree 12 := .split 43 q12Shape9T57 q12Shape9T58
private theorem q12Shape9T56OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 8247428644864 q12Shape9T56=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 (8247428644864 ||| 2^43) q12Shape9T57 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (33554432 ||| 2^43) 8247428644864 q12Shape9T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T57OK,q12Shape9T58OK⟩

private def q12Shape9T69 : Tree 12 := (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9}))) (.split 29 (.tip (.cover {1,2,3,4,6,7,10})) (.tip (.cover {0,1,4,5,6,8,9})))) (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,11})))) (.tip (.cover {0,1,4,5,6,9,11})))
private theorem q12Shape9T69OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 30237676929024 q12Shape9T69=true := by decide

private def q12Shape9T70 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T70OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398088454144 30237668540416 q12Shape9T70=true := by decide

private def q12Shape9T68 : Tree 12 := .split 23 q12Shape9T69 q12Shape9T70
private theorem q12Shape9T68OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 30237668540416 q12Shape9T68=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 (30237668540416 ||| 2^23) q12Shape9T69 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398080065536 ||| 2^23) 30237668540416 q12Shape9T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T69OK,q12Shape9T70OK⟩

private def q12Shape9T71 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape9T71OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398084259840 30237664346112 q12Shape9T71=true := by decide

private def q12Shape9T67 : Tree 12 := .split 22 q12Shape9T68 q12Shape9T71
private theorem q12Shape9T67OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 30237664346112 q12Shape9T67=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 (30237664346112 ||| 2^22) q12Shape9T68 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398080065536 ||| 2^22) 30237664346112 q12Shape9T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T68OK,q12Shape9T71OK⟩

private def q12Shape9T72 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape9T72OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398082162688 30237662248960 q12Shape9T72=true := by decide

private def q12Shape9T66 : Tree 12 := .split 21 q12Shape9T67 q12Shape9T72
private theorem q12Shape9T66OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 30237662248960 q12Shape9T66=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 (30237662248960 ||| 2^21) q12Shape9T67 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398080065536 ||| 2^21) 30237662248960 q12Shape9T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T67OK,q12Shape9T72OK⟩

private def q12Shape9T73 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape9T73OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398081114112 30237661200384 q12Shape9T73=true := by decide

private def q12Shape9T65 : Tree 12 := .split 20 q12Shape9T66 q12Shape9T73
private theorem q12Shape9T65OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 30237661200384 q12Shape9T65=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 (30237661200384 ||| 2^20) q12Shape9T66 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398080065536 ||| 2^20) 30237661200384 q12Shape9T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T66OK,q12Shape9T73OK⟩

private def q12Shape9T74 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T74OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 21990266109952 12645475155968 q12Shape9T74=true := by decide

private def q12Shape9T64 : Tree 12 := .split 44 q12Shape9T65 q12Shape9T74
private theorem q12Shape9T64OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 12645475155968 q12Shape9T64=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 (12645475155968 ||| 2^44) q12Shape9T65 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398080065536 ||| 2^44) 12645475155968 q12Shape9T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T65OK,q12Shape9T74OK⟩

private def q12Shape9T75 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T75OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 13194173087744 3849382133760 q12Shape9T75=true := by decide

private def q12Shape9T63 : Tree 12 := .split 43 q12Shape9T64 q12Shape9T75
private theorem q12Shape9T63OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 3849382133760 q12Shape9T63=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398080065536 (3849382133760 ||| 2^43) q12Shape9T64 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398080065536 ||| 2^43) 3849382133760 q12Shape9T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T64OK,q12Shape9T75OK⟩

private def q12Shape9T55 : Tree 12 := .split 42 q12Shape9T56 q12Shape9T63
private theorem q12Shape9T55OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 3849382133760 q12Shape9T55=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 (3849382133760 ||| 2^42) q12Shape9T56 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (33554432 ||| 2^42) 3849382133760 q12Shape9T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T56OK,q12Shape9T63OK⟩

private def q12Shape9T81 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.split 27 (.split 28 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,10})))) (.tip (.cover {0,1,5,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,8,9})))
private theorem q12Shape9T81OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 32436687601664 q12Shape9T81=true := by decide

private def q12Shape9T82 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T82OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199058907136 32436685504512 q12Shape9T82=true := by decide

private def q12Shape9T80 : Tree 12 := .split 21 q12Shape9T81 q12Shape9T82
private theorem q12Shape9T80OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 32436685504512 q12Shape9T80=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 (32436685504512 ||| 2^21) q12Shape9T81 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199056809984 ||| 2^21) 32436685504512 q12Shape9T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T81OK,q12Shape9T82OK⟩

private def q12Shape9T83 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,10}))
private theorem q12Shape9T83OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199057858560 32436684455936 q12Shape9T83=true := by decide

private def q12Shape9T79 : Tree 12 := .split 20 q12Shape9T80 q12Shape9T83
private theorem q12Shape9T79OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 32436684455936 q12Shape9T79=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 (32436684455936 ||| 2^20) q12Shape9T80 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199056809984 ||| 2^20) 32436684455936 q12Shape9T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T80OK,q12Shape9T83OK⟩

private def q12Shape9T84 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape9T84OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 19791242854400 14844498411520 q12Shape9T84=true := by decide

private def q12Shape9T78 : Tree 12 := .split 44 q12Shape9T79 q12Shape9T84
private theorem q12Shape9T78OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 14844498411520 q12Shape9T78=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 (14844498411520 ||| 2^44) q12Shape9T79 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199056809984 ||| 2^44) 14844498411520 q12Shape9T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T79OK,q12Shape9T84OK⟩

private def q12Shape9T85 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape9T85OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 10995149832192 6048405389312 q12Shape9T85=true := by decide

private def q12Shape9T77 : Tree 12 := .split 43 q12Shape9T78 q12Shape9T85
private theorem q12Shape9T77OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 6048405389312 q12Shape9T77=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 (6048405389312 ||| 2^43) q12Shape9T78 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199056809984 ||| 2^43) 6048405389312 q12Shape9T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T78OK,q12Shape9T85OK⟩

private def q12Shape9T86 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T86OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 6597103321088 1650358878208 q12Shape9T86=true := by decide

private def q12Shape9T76 : Tree 12 := .split 42 q12Shape9T77 q12Shape9T86
private theorem q12Shape9T76OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 1650358878208 q12Shape9T76=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199056809984 (1650358878208 ||| 2^42) q12Shape9T77 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199056809984 ||| 2^42) 1650358878208 q12Shape9T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T77OK,q12Shape9T86OK⟩

private def q12Shape9T54 : Tree 12 := .split 41 q12Shape9T55 q12Shape9T76
private theorem q12Shape9T54OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 1650358878208 q12Shape9T54=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 (1650358878208 ||| 2^41) q12Shape9T55 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (33554432 ||| 2^41) 1650358878208 q12Shape9T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T55OK,q12Shape9T76OK⟩

private def q12Shape9T96 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.split 29 (.tip (.cover {1,2,3,4,6,7,10})) (.tip (.cover {0,1,4,5,6,8,9})))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape9T96OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 33536278921216 q12Shape9T96=true := by decide

private def q12Shape9T97 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape9T97OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099612291072 33536211812352 q12Shape9T97=true := by decide

private def q12Shape9T95 : Tree 12 := .split 26 q12Shape9T96 q12Shape9T97
private theorem q12Shape9T95OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 33536211812352 q12Shape9T95=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (33536211812352 ||| 2^26) q12Shape9T96 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^26) 33536211812352 q12Shape9T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T96OK,q12Shape9T97OK⟩

private def q12Shape9T98 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T98OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099553570816 33536203423744 q12Shape9T98=true := by decide

private def q12Shape9T94 : Tree 12 := .split 23 q12Shape9T95 q12Shape9T98
private theorem q12Shape9T94OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 33536203423744 q12Shape9T94=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (33536203423744 ||| 2^23) q12Shape9T95 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^23) 33536203423744 q12Shape9T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T95OK,q12Shape9T98OK⟩

private def q12Shape9T99 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape9T99OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099549376512 33536199229440 q12Shape9T99=true := by decide

private def q12Shape9T93 : Tree 12 := .split 22 q12Shape9T94 q12Shape9T99
private theorem q12Shape9T93OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 33536199229440 q12Shape9T93=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (33536199229440 ||| 2^22) q12Shape9T94 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^22) 33536199229440 q12Shape9T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T94OK,q12Shape9T99OK⟩

private def q12Shape9T100 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape9T100OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099547279360 33536197132288 q12Shape9T100=true := by decide

private def q12Shape9T92 : Tree 12 := .split 21 q12Shape9T93 q12Shape9T100
private theorem q12Shape9T92OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 33536197132288 q12Shape9T92=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (33536197132288 ||| 2^21) q12Shape9T93 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^21) 33536197132288 q12Shape9T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T93OK,q12Shape9T100OK⟩

private def q12Shape9T101 : Tree 12 := (.tip (.cover {0,1,5,6,8,9,11}))
private theorem q12Shape9T101OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099546230784 33536196083712 q12Shape9T101=true := by decide

private def q12Shape9T91 : Tree 12 := .split 20 q12Shape9T92 q12Shape9T101
private theorem q12Shape9T91OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 33536196083712 q12Shape9T91=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (33536196083712 ||| 2^20) q12Shape9T92 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^20) 33536196083712 q12Shape9T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T92OK,q12Shape9T101OK⟩

private def q12Shape9T102 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape9T102OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 18691731226624 15944010039296 q12Shape9T102=true := by decide

private def q12Shape9T90 : Tree 12 := .split 44 q12Shape9T91 q12Shape9T102
private theorem q12Shape9T90OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 15944010039296 q12Shape9T90=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (15944010039296 ||| 2^44) q12Shape9T91 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^44) 15944010039296 q12Shape9T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T91OK,q12Shape9T102OK⟩

private def q12Shape9T103 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T103OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 9895638204416 7147917017088 q12Shape9T103=true := by decide

private def q12Shape9T89 : Tree 12 := .split 43 q12Shape9T90 q12Shape9T103
private theorem q12Shape9T89OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 7147917017088 q12Shape9T89=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (7147917017088 ||| 2^43) q12Shape9T90 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^43) 7147917017088 q12Shape9T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T90OK,q12Shape9T103OK⟩

private def q12Shape9T104 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape9T104OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 5497591693312 2749870505984 q12Shape9T104=true := by decide

private def q12Shape9T88 : Tree 12 := .split 42 q12Shape9T89 q12Shape9T104
private theorem q12Shape9T88OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 2749870505984 q12Shape9T88=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (2749870505984 ||| 2^42) q12Shape9T89 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^42) 2749870505984 q12Shape9T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T89OK,q12Shape9T104OK⟩

private def q12Shape9T105 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T105OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 3298568437760 550847250432 q12Shape9T105=true := by decide

private def q12Shape9T87 : Tree 12 := .split 41 q12Shape9T88 q12Shape9T105
private theorem q12Shape9T87OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 550847250432 q12Shape9T87=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099545182208 (550847250432 ||| 2^41) q12Shape9T88 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099545182208 ||| 2^41) 550847250432 q12Shape9T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T88OK,q12Shape9T105OK⟩

private def q12Shape9T53 : Tree 12 := .split 40 q12Shape9T54 q12Shape9T87
private theorem q12Shape9T53OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 550847250432 q12Shape9T53=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 (550847250432 ||| 2^40) q12Shape9T54 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (33554432 ||| 2^40) 550847250432 q12Shape9T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T54OK,q12Shape9T87OK⟩

private def q12Shape9T116 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,9})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11}))))
private theorem q12Shape9T116OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 34086034735104 q12Shape9T116=true := by decide

private def q12Shape9T117 : Tree 12 := (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,6,7,8})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape9T117OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549856477184 34085967626240 q12Shape9T117=true := by decide

private def q12Shape9T115 : Tree 12 := .split 26 q12Shape9T116 q12Shape9T117
private theorem q12Shape9T115OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 34085967626240 q12Shape9T115=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (34085967626240 ||| 2^26) q12Shape9T116 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^26) 34085967626240 q12Shape9T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T116OK,q12Shape9T117OK⟩

private def q12Shape9T118 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T118OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549797756928 34085959237632 q12Shape9T118=true := by decide

private def q12Shape9T114 : Tree 12 := .split 23 q12Shape9T115 q12Shape9T118
private theorem q12Shape9T114OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 34085959237632 q12Shape9T114=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (34085959237632 ||| 2^23) q12Shape9T115 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^23) 34085959237632 q12Shape9T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T115OK,q12Shape9T118OK⟩

private def q12Shape9T119 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape9T119OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549793562624 34085955043328 q12Shape9T119=true := by decide

private def q12Shape9T113 : Tree 12 := .split 22 q12Shape9T114 q12Shape9T119
private theorem q12Shape9T113OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 34085955043328 q12Shape9T113=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (34085955043328 ||| 2^22) q12Shape9T114 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^22) 34085955043328 q12Shape9T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T114OK,q12Shape9T119OK⟩

private def q12Shape9T120 : Tree 12 := (.tip (.cover {0,1,5,6,9,10,11}))
private theorem q12Shape9T120OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549791465472 34085952946176 q12Shape9T120=true := by decide

private def q12Shape9T112 : Tree 12 := .split 21 q12Shape9T113 q12Shape9T120
private theorem q12Shape9T112OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 34085952946176 q12Shape9T112=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (34085952946176 ||| 2^21) q12Shape9T113 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^21) 34085952946176 q12Shape9T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T113OK,q12Shape9T120OK⟩

private def q12Shape9T121 : Tree 12 := (.tip (.cover {0,1,5,6,8,10,11}))
private theorem q12Shape9T121OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549790416896 34085951897600 q12Shape9T121=true := by decide

private def q12Shape9T111 : Tree 12 := .split 20 q12Shape9T112 q12Shape9T121
private theorem q12Shape9T111OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 34085951897600 q12Shape9T111=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (34085951897600 ||| 2^20) q12Shape9T112 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^20) 34085951897600 q12Shape9T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T112OK,q12Shape9T121OK⟩

private def q12Shape9T122 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T122OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 18141975412736 16493765853184 q12Shape9T122=true := by decide

private def q12Shape9T110 : Tree 12 := .split 44 q12Shape9T111 q12Shape9T122
private theorem q12Shape9T110OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 16493765853184 q12Shape9T110=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (16493765853184 ||| 2^44) q12Shape9T111 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^44) 16493765853184 q12Shape9T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T111OK,q12Shape9T122OK⟩

private def q12Shape9T123 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape9T123OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 9345882390528 7697672830976 q12Shape9T123=true := by decide

private def q12Shape9T109 : Tree 12 := .split 43 q12Shape9T110 q12Shape9T123
private theorem q12Shape9T109OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 7697672830976 q12Shape9T109=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (7697672830976 ||| 2^43) q12Shape9T110 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^43) 7697672830976 q12Shape9T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T110OK,q12Shape9T123OK⟩

private def q12Shape9T124 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape9T124OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4947835879424 3299626319872 q12Shape9T124=true := by decide

private def q12Shape9T108 : Tree 12 := .split 42 q12Shape9T109 q12Shape9T124
private theorem q12Shape9T108OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 3299626319872 q12Shape9T108=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (3299626319872 ||| 2^42) q12Shape9T109 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^42) 3299626319872 q12Shape9T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T109OK,q12Shape9T124OK⟩

private def q12Shape9T125 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T125OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2748812623872 1100603064320 q12Shape9T125=true := by decide

private def q12Shape9T107 : Tree 12 := .split 41 q12Shape9T108 q12Shape9T125
private theorem q12Shape9T107OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 1100603064320 q12Shape9T107=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (1100603064320 ||| 2^41) q12Shape9T108 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^41) 1100603064320 q12Shape9T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T108OK,q12Shape9T125OK⟩

private def q12Shape9T126 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape9T126OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1649300996096 1091436544 q12Shape9T126=true := by decide

private def q12Shape9T106 : Tree 12 := .split 40 q12Shape9T107 q12Shape9T126
private theorem q12Shape9T106OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 1091436544 q12Shape9T106=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549789368320 (1091436544 ||| 2^40) q12Shape9T107 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549789368320 ||| 2^40) 1091436544 q12Shape9T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T107OK,q12Shape9T126OK⟩

private def q12Shape9T52 : Tree 12 := .split 39 q12Shape9T53 q12Shape9T106
private theorem q12Shape9T52OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 1091436544 q12Shape9T52=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 (1091436544 ||| 2^39) q12Shape9T53 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (33554432 ||| 2^39) 1091436544 q12Shape9T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T53OK,q12Shape9T106OK⟩

private def q12Shape9T127 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape9T127OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1107296256 17694720 q12Shape9T127=true := by decide

private def q12Shape9T51 : Tree 12 := .split 30 q12Shape9T52 q12Shape9T127
private theorem q12Shape9T51OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 17694720 q12Shape9T51=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 (17694720 ||| 2^30) q12Shape9T52 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (33554432 ||| 2^30) 17694720 q12Shape9T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T52OK,q12Shape9T127OK⟩

def q12Shape9P1 : Tree 12 := q12Shape9T51
theorem q12Shape9P1OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33554432 17694720 q12Shape9P1=true := q12Shape9T51OK

end Graffiti384b.EffectiveSearch.Q12
