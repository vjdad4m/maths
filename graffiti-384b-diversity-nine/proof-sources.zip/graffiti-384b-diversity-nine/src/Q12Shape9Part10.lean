import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape9T483 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape9T483OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 1124335616 q12Shape9T483=true := by decide

private def q12Shape9T484 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape9T484OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1074397184 50593792 q12Shape9T484=true := by decide

private def q12Shape9T482 : Tree 12 := .split 30 q12Shape9T483 q12Shape9T484
private theorem q12Shape9T482OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 50593792 q12Shape9T482=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 (50593792 ||| 2^30) q12Shape9T483 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (655360 ||| 2^30) 50593792 q12Shape9T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T483OK,q12Shape9T484OK⟩

private def q12Shape9T485 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape9T485OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 34209792 17039360 q12Shape9T485=true := by decide

private def q12Shape9T481 : Tree 12 := .split 25 q12Shape9T482 q12Shape9T485
private theorem q12Shape9T481OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 17039360 q12Shape9T481=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 (17039360 ||| 2^25) q12Shape9T482 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (655360 ||| 2^25) 17039360 q12Shape9T485)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T482OK,q12Shape9T485OK⟩

private def q12Shape9T488 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape9T488OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17432576 1107558400 q12Shape9T488=true := by decide

private def q12Shape9T489 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape9T489OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1091174400 33816576 q12Shape9T489=true := by decide

private def q12Shape9T487 : Tree 12 := .split 30 q12Shape9T488 q12Shape9T489
private theorem q12Shape9T487OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17432576 33816576 q12Shape9T487=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17432576 (33816576 ||| 2^30) q12Shape9T488 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (17432576 ||| 2^30) 33816576 q12Shape9T489)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T488OK,q12Shape9T489OK⟩

private def q12Shape9T490 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape9T490OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 50987008 262144 q12Shape9T490=true := by decide

private def q12Shape9T486 : Tree 12 := .split 25 q12Shape9T487 q12Shape9T490
private theorem q12Shape9T486OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17432576 262144 q12Shape9T486=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17432576 (262144 ||| 2^25) q12Shape9T487 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (17432576 ||| 2^25) 262144 q12Shape9T490)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T487OK,q12Shape9T490OK⟩

private def q12Shape9T480 : Tree 12 := .split 24 q12Shape9T481 q12Shape9T486
private theorem q12Shape9T480OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 262144 q12Shape9T480=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 (262144 ||| 2^24) q12Shape9T481 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (655360 ||| 2^24) 262144 q12Shape9T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T481OK,q12Shape9T486OK⟩

def q12Shape9P16 : Tree 12 := q12Shape9T480
theorem q12Shape9P16OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 655360 262144 q12Shape9P16=true := q12Shape9T480OK

private def q12Shape9T496 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11})))
private theorem q12Shape9T496OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 1124597760 q12Shape9T496=true := by decide

private def q12Shape9T497 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,6,8,10,11})))
private theorem q12Shape9T497OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1074135040 50855936 q12Shape9T497=true := by decide

private def q12Shape9T495 : Tree 12 := .split 30 q12Shape9T496 q12Shape9T497
private theorem q12Shape9T495OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 50855936 q12Shape9T495=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 (50855936 ||| 2^30) q12Shape9T496 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (393216 ||| 2^30) 50855936 q12Shape9T497)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T496OK,q12Shape9T497OK⟩

private def q12Shape9T499 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape9T499OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33947648 1091043328 q12Shape9T499=true := by decide

private def q12Shape9T500 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape9T500OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1107689472 17301504 q12Shape9T500=true := by decide

private def q12Shape9T498 : Tree 12 := .split 30 q12Shape9T499 q12Shape9T500
private theorem q12Shape9T498OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33947648 17301504 q12Shape9T498=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 33947648 (17301504 ||| 2^30) q12Shape9T499 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (33947648 ||| 2^30) 17301504 q12Shape9T500)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T499OK,q12Shape9T500OK⟩

private def q12Shape9T494 : Tree 12 := .split 25 q12Shape9T495 q12Shape9T498
private theorem q12Shape9T494OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 17301504 q12Shape9T494=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 (17301504 ||| 2^25) q12Shape9T495 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (393216 ||| 2^25) 17301504 q12Shape9T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T495OK,q12Shape9T498OK⟩

private def q12Shape9T502 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,6,8,9,10,11})))
private theorem q12Shape9T502OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17170432 34078720 q12Shape9T502=true := by decide

private def q12Shape9T503 : Tree 12 := (.tip (.cover {0,1,5,8,9,10,11}))
private theorem q12Shape9T503OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 50724864 524288 q12Shape9T503=true := by decide

private def q12Shape9T501 : Tree 12 := .split 25 q12Shape9T502 q12Shape9T503
private theorem q12Shape9T501OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17170432 524288 q12Shape9T501=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17170432 (524288 ||| 2^25) q12Shape9T502 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (17170432 ||| 2^25) 524288 q12Shape9T503)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T502OK,q12Shape9T503OK⟩

private def q12Shape9T493 : Tree 12 := .split 24 q12Shape9T494 q12Shape9T501
private theorem q12Shape9T493OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 524288 q12Shape9T493=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 (524288 ||| 2^24) q12Shape9T494 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (393216 ||| 2^24) 524288 q12Shape9T501)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T494OK,q12Shape9T501OK⟩

private def q12Shape9T504 : Tree 12 := (.tip (.cover {0,1,4,8,9,10,11}))
private theorem q12Shape9T504OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 917504 0 q12Shape9T504=true := by decide

private def q12Shape9T492 : Tree 12 := .split 19 q12Shape9T493 q12Shape9T504
private theorem q12Shape9T492OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 0 q12Shape9T492=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 (0 ||| 2^19) q12Shape9T493 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (393216 ||| 2^19) 0 q12Shape9T504)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T493OK,q12Shape9T504OK⟩

def q12Shape9P17 : Tree 12 := q12Shape9T492
theorem q12Shape9P17OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 393216 0 q12Shape9P17=true := q12Shape9T492OK

end Graffiti384b.EffectiveSearch.Q12
