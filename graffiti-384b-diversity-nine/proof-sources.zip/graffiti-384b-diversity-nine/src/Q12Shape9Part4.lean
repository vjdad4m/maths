import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape9T218 : Tree 12 := (.tip (.cover {1,2,3,4,5,6,7}))
private theorem q12Shape9T218OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 34635740741632 q12Shape9T218=true := by decide

private def q12Shape9T219 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {1,2,3,5,6,7,10}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,9,10})))
private theorem q12Shape9T219OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17592186568704 17043554697216 q12Shape9T219=true := by decide

private def q12Shape9T217 : Tree 12 := .split 44 q12Shape9T218 q12Shape9T219
private theorem q12Shape9T217OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 17043554697216 q12Shape9T217=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (17043554697216 ||| 2^44) q12Shape9T218 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^44) 17043554697216 q12Shape9T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T218OK,q12Shape9T219OK⟩

private def q12Shape9T222 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.split 22 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9}))))
private theorem q12Shape9T222OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093546496 25839648768000 q12Shape9T222=true := by decide

private def q12Shape9T223 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape9T223OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796094595072 25839647719424 q12Shape9T223=true := by decide

private def q12Shape9T221 : Tree 12 := .split 20 q12Shape9T222 q12Shape9T223
private theorem q12Shape9T221OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093546496 25839647719424 q12Shape9T221=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093546496 (25839647719424 ||| 2^20) q12Shape9T222 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (8796093546496 ||| 2^20) 25839647719424 q12Shape9T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T222OK,q12Shape9T223OK⟩

private def q12Shape9T224 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape9T224OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 26388279590912 8247461675008 q12Shape9T224=true := by decide

private def q12Shape9T220 : Tree 12 := .split 44 q12Shape9T221 q12Shape9T224
private theorem q12Shape9T220OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093546496 8247461675008 q12Shape9T220=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093546496 (8247461675008 ||| 2^44) q12Shape9T221 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (8796093546496 ||| 2^44) 8247461675008 q12Shape9T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T221OK,q12Shape9T224OK⟩

private def q12Shape9T216 : Tree 12 := .split 43 q12Shape9T217 q12Shape9T220
private theorem q12Shape9T216OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 8247461675008 q12Shape9T216=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (8247461675008 ||| 2^43) q12Shape9T217 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^43) 8247461675008 q12Shape9T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T217OK,q12Shape9T220OK⟩

private def q12Shape9T229 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.split 23 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,4,5,6,8,9}))))
private theorem q12Shape9T229OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 30237697376256 q12Shape9T229=true := by decide

private def q12Shape9T230 : Tree 12 := (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape9T230OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398049132544 30237695279104 q12Shape9T230=true := by decide

private def q12Shape9T228 : Tree 12 := .split 21 q12Shape9T229 q12Shape9T230
private theorem q12Shape9T228OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 30237695279104 q12Shape9T228=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 (30237695279104 ||| 2^21) q12Shape9T229 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398047035392 ||| 2^21) 30237695279104 q12Shape9T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T229OK,q12Shape9T230OK⟩

private def q12Shape9T231 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape9T231OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398048083968 30237694230528 q12Shape9T231=true := by decide

private def q12Shape9T227 : Tree 12 := .split 20 q12Shape9T228 q12Shape9T231
private theorem q12Shape9T227OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 30237694230528 q12Shape9T227=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 (30237694230528 ||| 2^20) q12Shape9T228 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398047035392 ||| 2^20) 30237694230528 q12Shape9T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T228OK,q12Shape9T231OK⟩

private def q12Shape9T232 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T232OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 21990233079808 12645508186112 q12Shape9T232=true := by decide

private def q12Shape9T226 : Tree 12 := .split 44 q12Shape9T227 q12Shape9T232
private theorem q12Shape9T226OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 12645508186112 q12Shape9T226=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 (12645508186112 ||| 2^44) q12Shape9T227 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398047035392 ||| 2^44) 12645508186112 q12Shape9T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T227OK,q12Shape9T232OK⟩

private def q12Shape9T233 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T233OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 13194140057600 3849415163904 q12Shape9T233=true := by decide

private def q12Shape9T225 : Tree 12 := .split 43 q12Shape9T226 q12Shape9T233
private theorem q12Shape9T225OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 3849415163904 q12Shape9T225=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047035392 (3849415163904 ||| 2^43) q12Shape9T226 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398047035392 ||| 2^43) 3849415163904 q12Shape9T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T226OK,q12Shape9T233OK⟩

private def q12Shape9T215 : Tree 12 := .split 42 q12Shape9T216 q12Shape9T225
private theorem q12Shape9T215OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 3849415163904 q12Shape9T215=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (3849415163904 ||| 2^42) q12Shape9T216 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^42) 3849415163904 q12Shape9T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T216OK,q12Shape9T225OK⟩

private def q12Shape9T238 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,6,8,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,10})))
private theorem q12Shape9T238OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 32436718534656 q12Shape9T238=true := by decide

private def q12Shape9T239 : Tree 12 := (.split 21 (.split 22 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,8,10})))
private theorem q12Shape9T239OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199024828416 32436717486080 q12Shape9T239=true := by decide

private def q12Shape9T237 : Tree 12 := .split 20 q12Shape9T238 q12Shape9T239
private theorem q12Shape9T237OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 32436717486080 q12Shape9T237=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 (32436717486080 ||| 2^20) q12Shape9T238 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023779840 ||| 2^20) 32436717486080 q12Shape9T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T238OK,q12Shape9T239OK⟩

private def q12Shape9T240 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape9T240OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 19791209824256 14844531441664 q12Shape9T240=true := by decide

private def q12Shape9T236 : Tree 12 := .split 44 q12Shape9T237 q12Shape9T240
private theorem q12Shape9T236OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 14844531441664 q12Shape9T236=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 (14844531441664 ||| 2^44) q12Shape9T237 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023779840 ||| 2^44) 14844531441664 q12Shape9T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T237OK,q12Shape9T240OK⟩

private def q12Shape9T241 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape9T241OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 10995116802048 6048438419456 q12Shape9T241=true := by decide

private def q12Shape9T235 : Tree 12 := .split 43 q12Shape9T236 q12Shape9T241
private theorem q12Shape9T235OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 6048438419456 q12Shape9T235=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 (6048438419456 ||| 2^43) q12Shape9T236 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023779840 ||| 2^43) 6048438419456 q12Shape9T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T236OK,q12Shape9T241OK⟩

private def q12Shape9T242 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T242OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 6597070290944 1650391908352 q12Shape9T242=true := by decide

private def q12Shape9T234 : Tree 12 := .split 42 q12Shape9T235 q12Shape9T242
private theorem q12Shape9T234OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 1650391908352 q12Shape9T234=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023779840 (1650391908352 ||| 2^42) q12Shape9T235 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023779840 ||| 2^42) 1650391908352 q12Shape9T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T235OK,q12Shape9T242OK⟩

private def q12Shape9T214 : Tree 12 := .split 41 q12Shape9T215 q12Shape9T234
private theorem q12Shape9T214OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 1650391908352 q12Shape9T214=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (1650391908352 ||| 2^41) q12Shape9T215 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^41) 1650391908352 q12Shape9T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T215OK,q12Shape9T234OK⟩

private def q12Shape9T249 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,6,8,9,11}))) (.tip (.cover {0,1,4,5,6,8,9}))) (.split 23 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,4,5,6,8,9}))))
private theorem q12Shape9T249OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 33536232259584 q12Shape9T249=true := by decide

private def q12Shape9T250 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape9T250OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099514249216 33536230162432 q12Shape9T250=true := by decide

private def q12Shape9T248 : Tree 12 := .split 21 q12Shape9T249 q12Shape9T250
private theorem q12Shape9T248OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 33536230162432 q12Shape9T248=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 (33536230162432 ||| 2^21) q12Shape9T249 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099512152064 ||| 2^21) 33536230162432 q12Shape9T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T249OK,q12Shape9T250OK⟩

private def q12Shape9T251 : Tree 12 := (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,9,11}))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape9T251OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099513200640 33536229113856 q12Shape9T251=true := by decide

private def q12Shape9T247 : Tree 12 := .split 20 q12Shape9T248 q12Shape9T251
private theorem q12Shape9T247OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 33536229113856 q12Shape9T247=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 (33536229113856 ||| 2^20) q12Shape9T248 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099512152064 ||| 2^20) 33536229113856 q12Shape9T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T248OK,q12Shape9T251OK⟩

private def q12Shape9T252 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape9T252OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 18691698196480 15944043069440 q12Shape9T252=true := by decide

private def q12Shape9T246 : Tree 12 := .split 44 q12Shape9T247 q12Shape9T252
private theorem q12Shape9T246OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 15944043069440 q12Shape9T246=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 (15944043069440 ||| 2^44) q12Shape9T247 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099512152064 ||| 2^44) 15944043069440 q12Shape9T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T247OK,q12Shape9T252OK⟩

private def q12Shape9T253 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T253OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 9895605174272 7147950047232 q12Shape9T253=true := by decide

private def q12Shape9T245 : Tree 12 := .split 43 q12Shape9T246 q12Shape9T253
private theorem q12Shape9T245OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 7147950047232 q12Shape9T245=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 (7147950047232 ||| 2^43) q12Shape9T246 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099512152064 ||| 2^43) 7147950047232 q12Shape9T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T246OK,q12Shape9T253OK⟩

private def q12Shape9T254 : Tree 12 := (.tip (.cover {0,1,4,5,6,10,11}))
private theorem q12Shape9T254OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 5497558663168 2749903536128 q12Shape9T254=true := by decide

private def q12Shape9T244 : Tree 12 := .split 42 q12Shape9T245 q12Shape9T254
private theorem q12Shape9T244OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 2749903536128 q12Shape9T244=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 (2749903536128 ||| 2^42) q12Shape9T245 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099512152064 ||| 2^42) 2749903536128 q12Shape9T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T245OK,q12Shape9T254OK⟩

private def q12Shape9T255 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,9}))
private theorem q12Shape9T255OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 3298535407616 550880280576 q12Shape9T255=true := by decide

private def q12Shape9T243 : Tree 12 := .split 41 q12Shape9T244 q12Shape9T255
private theorem q12Shape9T243OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 550880280576 q12Shape9T243=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512152064 (550880280576 ||| 2^41) q12Shape9T244 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099512152064 ||| 2^41) 550880280576 q12Shape9T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T244OK,q12Shape9T255OK⟩

private def q12Shape9T213 : Tree 12 := .split 40 q12Shape9T214 q12Shape9T243
private theorem q12Shape9T213OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 550880280576 q12Shape9T213=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (550880280576 ||| 2^40) q12Shape9T214 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^40) 550880280576 q12Shape9T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T214OK,q12Shape9T243OK⟩

private def q12Shape9T263 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,6,9,10,11}))) (.tip (.cover {0,1,4,6,8,10,11}))) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape9T263OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 34085988073472 q12Shape9T263=true := by decide

private def q12Shape9T264 : Tree 12 := (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11})))
private theorem q12Shape9T264OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549758435328 34085985976320 q12Shape9T264=true := by decide

private def q12Shape9T262 : Tree 12 := .split 21 q12Shape9T263 q12Shape9T264
private theorem q12Shape9T262OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 34085985976320 q12Shape9T262=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 (34085985976320 ||| 2^21) q12Shape9T263 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756338176 ||| 2^21) 34085985976320 q12Shape9T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T263OK,q12Shape9T264OK⟩

private def q12Shape9T265 : Tree 12 := (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,8,11}))) (.tip (.cover {0,1,4,5,6,10,11})))
private theorem q12Shape9T265OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549757386752 34085984927744 q12Shape9T265=true := by decide

private def q12Shape9T261 : Tree 12 := .split 20 q12Shape9T262 q12Shape9T265
private theorem q12Shape9T261OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 34085984927744 q12Shape9T261=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 (34085984927744 ||| 2^20) q12Shape9T262 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756338176 ||| 2^20) 34085984927744 q12Shape9T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T262OK,q12Shape9T265OK⟩

private def q12Shape9T266 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T266OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 18141942382592 16493798883328 q12Shape9T266=true := by decide

private def q12Shape9T260 : Tree 12 := .split 44 q12Shape9T261 q12Shape9T266
private theorem q12Shape9T260OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 16493798883328 q12Shape9T260=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 (16493798883328 ||| 2^44) q12Shape9T261 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756338176 ||| 2^44) 16493798883328 q12Shape9T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T261OK,q12Shape9T266OK⟩

private def q12Shape9T267 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,10}))
private theorem q12Shape9T267OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 9345849360384 7697705861120 q12Shape9T267=true := by decide

private def q12Shape9T259 : Tree 12 := .split 43 q12Shape9T260 q12Shape9T267
private theorem q12Shape9T259OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 7697705861120 q12Shape9T259=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 (7697705861120 ||| 2^43) q12Shape9T260 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756338176 ||| 2^43) 7697705861120 q12Shape9T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T260OK,q12Shape9T267OK⟩

private def q12Shape9T268 : Tree 12 := (.tip (.cover {0,1,4,5,6,9,11}))
private theorem q12Shape9T268OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4947802849280 3299659350016 q12Shape9T268=true := by decide

private def q12Shape9T258 : Tree 12 := .split 42 q12Shape9T259 q12Shape9T268
private theorem q12Shape9T258OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 3299659350016 q12Shape9T258=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 (3299659350016 ||| 2^42) q12Shape9T259 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756338176 ||| 2^42) 3299659350016 q12Shape9T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T259OK,q12Shape9T268OK⟩

private def q12Shape9T269 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,10}))
private theorem q12Shape9T269OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2748779593728 1100636094464 q12Shape9T269=true := by decide

private def q12Shape9T257 : Tree 12 := .split 41 q12Shape9T258 q12Shape9T269
private theorem q12Shape9T257OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 1100636094464 q12Shape9T257=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 (1100636094464 ||| 2^41) q12Shape9T258 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756338176 ||| 2^41) 1100636094464 q12Shape9T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T258OK,q12Shape9T269OK⟩

private def q12Shape9T270 : Tree 12 := (.tip (.cover {0,1,4,5,6,8,11}))
private theorem q12Shape9T270OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1649267965952 1124466688 q12Shape9T270=true := by decide

private def q12Shape9T256 : Tree 12 := .split 40 q12Shape9T257 q12Shape9T270
private theorem q12Shape9T256OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 1124466688 q12Shape9T256=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756338176 (1124466688 ||| 2^40) q12Shape9T257 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756338176 ||| 2^40) 1124466688 q12Shape9T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T257OK,q12Shape9T270OK⟩

private def q12Shape9T212 : Tree 12 := .split 39 q12Shape9T213 q12Shape9T256
private theorem q12Shape9T212OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 1124466688 q12Shape9T212=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (1124466688 ||| 2^39) q12Shape9T213 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^39) 1124466688 q12Shape9T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T213OK,q12Shape9T256OK⟩

private def q12Shape9T271 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,9,10}))) (.tip (.cover {0,1,5,7,8,9,11}))) (.tip (.cover {0,1,5,7,8,10,11})))
private theorem q12Shape9T271OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1074266112 50724864 q12Shape9T271=true := by decide

private def q12Shape9T211 : Tree 12 := .split 30 q12Shape9T212 q12Shape9T271
private theorem q12Shape9T211OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 50724864 q12Shape9T211=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 (50724864 ||| 2^30) q12Shape9T212 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (524288 ||| 2^30) 50724864 q12Shape9T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T212OK,q12Shape9T271OK⟩

def q12Shape9P4 : Tree 12 := q12Shape9T211
theorem q12Shape9P4OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 524288 50724864 q12Shape9P4=true := q12Shape9T211OK

end Graffiti384b.EffectiveSearch.Q12
