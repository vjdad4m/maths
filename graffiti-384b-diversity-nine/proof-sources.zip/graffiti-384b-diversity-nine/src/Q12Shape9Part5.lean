import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape9T272 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,9,11}))) (.tip (.cover {0,1,6,7,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape9T272OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 34078720 17170432 q12Shape9T272=true := by decide

def q12Shape9P5 : Tree 12 := q12Shape9T272
theorem q12Shape9P5OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 34078720 17170432 q12Shape9P5=true := q12Shape9T272OK

private def q12Shape9T276 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape9T276OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17301504 1107689472 q12Shape9T276=true := by decide

private def q12Shape9T277 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11})))
private theorem q12Shape9T277OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1091043328 33947648 q12Shape9T277=true := by decide

private def q12Shape9T275 : Tree 12 := .split 30 q12Shape9T276 q12Shape9T277
private theorem q12Shape9T275OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17301504 33947648 q12Shape9T275=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17301504 (33947648 ||| 2^30) q12Shape9T276 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (17301504 ||| 2^30) 33947648 q12Shape9T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T276OK,q12Shape9T277OK⟩

private def q12Shape9T278 : Tree 12 := (.split 30 (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,9,10}))) (.tip (.cover {0,1,4,5,8,9,11}))) (.tip (.cover {0,1,4,5,8,10,11}))) (.tip (.cover {0,1,7,8,9,10,11})))
private theorem q12Shape9T278OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 50855936 393216 q12Shape9T278=true := by decide

private def q12Shape9T274 : Tree 12 := .split 25 q12Shape9T275 q12Shape9T278
private theorem q12Shape9T274OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17301504 393216 q12Shape9T274=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17301504 (393216 ||| 2^25) q12Shape9T275 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (17301504 ||| 2^25) 393216 q12Shape9T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T275OK,q12Shape9T278OK⟩

def q12Shape9P6 : Tree 12 := q12Shape9T274
theorem q12Shape9P6OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17301504 393216 q12Shape9P6=true := q12Shape9T274OK

end Graffiti384b.EffectiveSearch.Q12
