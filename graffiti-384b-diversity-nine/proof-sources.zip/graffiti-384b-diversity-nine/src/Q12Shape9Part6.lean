import Q12GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q12
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q12Shape9T288 : Tree 12 := (.tip (.cover {1,2,3,4,5,6,7}))
private theorem q12Shape9T288OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 34635741003776 q12Shape9T288=true := by decide

private def q12Shape9T289 : Tree 12 := (.split 20 (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {1,2,3,5,6,7,10}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,9,10})))
private theorem q12Shape9T289OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 17592186306560 17043554959360 q12Shape9T289=true := by decide

private def q12Shape9T287 : Tree 12 := .split 44 q12Shape9T288 q12Shape9T289
private theorem q12Shape9T287OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 17043554959360 q12Shape9T287=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (17043554959360 ||| 2^44) q12Shape9T288 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^44) 17043554959360 q12Shape9T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T288OK,q12Shape9T289OK⟩

private def q12Shape9T292 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 22 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))))
private theorem q12Shape9T292OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093284352 25839649030144 q12Shape9T292=true := by decide

private def q12Shape9T293 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape9T293OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796094332928 25839647981568 q12Shape9T293=true := by decide

private def q12Shape9T291 : Tree 12 := .split 20 q12Shape9T292 q12Shape9T293
private theorem q12Shape9T291OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093284352 25839647981568 q12Shape9T291=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093284352 (25839647981568 ||| 2^20) q12Shape9T292 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (8796093284352 ||| 2^20) 25839647981568 q12Shape9T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T292OK,q12Shape9T293OK⟩

private def q12Shape9T294 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape9T294OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 26388279328768 8247461937152 q12Shape9T294=true := by decide

private def q12Shape9T290 : Tree 12 := .split 44 q12Shape9T291 q12Shape9T294
private theorem q12Shape9T290OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093284352 8247461937152 q12Shape9T290=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 8796093284352 (8247461937152 ||| 2^44) q12Shape9T291 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (8796093284352 ||| 2^44) 8247461937152 q12Shape9T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T291OK,q12Shape9T294OK⟩

private def q12Shape9T286 : Tree 12 := .split 43 q12Shape9T287 q12Shape9T290
private theorem q12Shape9T286OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 8247461937152 q12Shape9T286=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (8247461937152 ||| 2^43) q12Shape9T287 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^43) 8247461937152 q12Shape9T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T287OK,q12Shape9T290OK⟩

private def q12Shape9T299 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 23 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,4,5,7,8,9}))))
private theorem q12Shape9T299OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 30237697638400 q12Shape9T299=true := by decide

private def q12Shape9T300 : Tree 12 := (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape9T300OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398048870400 30237695541248 q12Shape9T300=true := by decide

private def q12Shape9T298 : Tree 12 := .split 21 q12Shape9T299 q12Shape9T300
private theorem q12Shape9T298OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 30237695541248 q12Shape9T298=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 (30237695541248 ||| 2^21) q12Shape9T299 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398046773248 ||| 2^21) 30237695541248 q12Shape9T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T299OK,q12Shape9T300OK⟩

private def q12Shape9T301 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape9T301OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398047821824 30237694492672 q12Shape9T301=true := by decide

private def q12Shape9T297 : Tree 12 := .split 20 q12Shape9T298 q12Shape9T301
private theorem q12Shape9T297OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 30237694492672 q12Shape9T297=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 (30237694492672 ||| 2^20) q12Shape9T298 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398046773248 ||| 2^20) 30237694492672 q12Shape9T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T298OK,q12Shape9T301OK⟩

private def q12Shape9T302 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape9T302OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 21990232817664 12645508448256 q12Shape9T302=true := by decide

private def q12Shape9T296 : Tree 12 := .split 44 q12Shape9T297 q12Shape9T302
private theorem q12Shape9T296OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 12645508448256 q12Shape9T296=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 (12645508448256 ||| 2^44) q12Shape9T297 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398046773248 ||| 2^44) 12645508448256 q12Shape9T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T297OK,q12Shape9T302OK⟩

private def q12Shape9T303 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape9T303OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 13194139795456 3849415426048 q12Shape9T303=true := by decide

private def q12Shape9T295 : Tree 12 := .split 43 q12Shape9T296 q12Shape9T303
private theorem q12Shape9T295OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 3849415426048 q12Shape9T295=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4398046773248 (3849415426048 ||| 2^43) q12Shape9T296 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (4398046773248 ||| 2^43) 3849415426048 q12Shape9T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T296OK,q12Shape9T303OK⟩

private def q12Shape9T285 : Tree 12 := .split 42 q12Shape9T286 q12Shape9T295
private theorem q12Shape9T285OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 3849415426048 q12Shape9T285=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (3849415426048 ||| 2^42) q12Shape9T286 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^42) 3849415426048 q12Shape9T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T286OK,q12Shape9T295OK⟩

private def q12Shape9T308 : Tree 12 := (.split 21 (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,6,7,11})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,7,8,9,10}))) (.tip (.cover {1,2,3,5,6,7,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10})))
private theorem q12Shape9T308OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 32436718796800 q12Shape9T308=true := by decide

private def q12Shape9T309 : Tree 12 := (.split 21 (.split 22 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,8,10})))
private theorem q12Shape9T309OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199024566272 32436717748224 q12Shape9T309=true := by decide

private def q12Shape9T307 : Tree 12 := .split 20 q12Shape9T308 q12Shape9T309
private theorem q12Shape9T307OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 32436717748224 q12Shape9T307=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 (32436717748224 ||| 2^20) q12Shape9T308 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023517696 ||| 2^20) 32436717748224 q12Shape9T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T308OK,q12Shape9T309OK⟩

private def q12Shape9T310 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape9T310OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 19791209562112 14844531703808 q12Shape9T310=true := by decide

private def q12Shape9T306 : Tree 12 := .split 44 q12Shape9T307 q12Shape9T310
private theorem q12Shape9T306OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 14844531703808 q12Shape9T306=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 (14844531703808 ||| 2^44) q12Shape9T307 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023517696 ||| 2^44) 14844531703808 q12Shape9T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T307OK,q12Shape9T310OK⟩

private def q12Shape9T311 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape9T311OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 10995116539904 6048438681600 q12Shape9T311=true := by decide

private def q12Shape9T305 : Tree 12 := .split 43 q12Shape9T306 q12Shape9T311
private theorem q12Shape9T305OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 6048438681600 q12Shape9T305=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 (6048438681600 ||| 2^43) q12Shape9T306 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023517696 ||| 2^43) 6048438681600 q12Shape9T311)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T306OK,q12Shape9T311OK⟩

private def q12Shape9T312 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape9T312OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 6597070028800 1650392170496 q12Shape9T312=true := by decide

private def q12Shape9T304 : Tree 12 := .split 42 q12Shape9T305 q12Shape9T312
private theorem q12Shape9T304OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 1650392170496 q12Shape9T304=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2199023517696 (1650392170496 ||| 2^42) q12Shape9T305 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (2199023517696 ||| 2^42) 1650392170496 q12Shape9T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T305OK,q12Shape9T312OK⟩

private def q12Shape9T284 : Tree 12 := .split 41 q12Shape9T285 q12Shape9T304
private theorem q12Shape9T284OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 1650392170496 q12Shape9T284=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (1650392170496 ||| 2^41) q12Shape9T285 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^41) 1650392170496 q12Shape9T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T285OK,q12Shape9T304OK⟩

private def q12Shape9T319 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,8,9,11}))) (.tip (.cover {0,1,4,5,7,8,9}))) (.split 23 (.tip (.cover {1,2,3,5,6,7,10})) (.tip (.cover {0,1,4,5,7,8,9}))))
private theorem q12Shape9T319OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 33536232521728 q12Shape9T319=true := by decide

private def q12Shape9T320 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape9T320OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099513987072 33536230424576 q12Shape9T320=true := by decide

private def q12Shape9T318 : Tree 12 := .split 21 q12Shape9T319 q12Shape9T320
private theorem q12Shape9T318OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 33536230424576 q12Shape9T318=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 (33536230424576 ||| 2^21) q12Shape9T319 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099511889920 ||| 2^21) 33536230424576 q12Shape9T320)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T319OK,q12Shape9T320OK⟩

private def q12Shape9T321 : Tree 12 := (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,9,11}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape9T321OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099512938496 33536229376000 q12Shape9T321=true := by decide

private def q12Shape9T317 : Tree 12 := .split 20 q12Shape9T318 q12Shape9T321
private theorem q12Shape9T317OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 33536229376000 q12Shape9T317=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 (33536229376000 ||| 2^20) q12Shape9T318 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099511889920 ||| 2^20) 33536229376000 q12Shape9T321)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T318OK,q12Shape9T321OK⟩

private def q12Shape9T322 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape9T322OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 18691697934336 15944043331584 q12Shape9T322=true := by decide

private def q12Shape9T316 : Tree 12 := .split 44 q12Shape9T317 q12Shape9T322
private theorem q12Shape9T316OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 15944043331584 q12Shape9T316=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 (15944043331584 ||| 2^44) q12Shape9T317 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099511889920 ||| 2^44) 15944043331584 q12Shape9T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T317OK,q12Shape9T322OK⟩

private def q12Shape9T323 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape9T323OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 9895604912128 7147950309376 q12Shape9T323=true := by decide

private def q12Shape9T315 : Tree 12 := .split 43 q12Shape9T316 q12Shape9T323
private theorem q12Shape9T315OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 7147950309376 q12Shape9T315=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 (7147950309376 ||| 2^43) q12Shape9T316 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099511889920 ||| 2^43) 7147950309376 q12Shape9T323)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T316OK,q12Shape9T323OK⟩

private def q12Shape9T324 : Tree 12 := (.tip (.cover {0,1,4,5,7,10,11}))
private theorem q12Shape9T324OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 5497558401024 2749903798272 q12Shape9T324=true := by decide

private def q12Shape9T314 : Tree 12 := .split 42 q12Shape9T315 q12Shape9T324
private theorem q12Shape9T314OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 2749903798272 q12Shape9T314=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 (2749903798272 ||| 2^42) q12Shape9T315 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099511889920 ||| 2^42) 2749903798272 q12Shape9T324)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T315OK,q12Shape9T324OK⟩

private def q12Shape9T325 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,9}))
private theorem q12Shape9T325OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 3298535145472 550880542720 q12Shape9T325=true := by decide

private def q12Shape9T313 : Tree 12 := .split 41 q12Shape9T314 q12Shape9T325
private theorem q12Shape9T313OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 550880542720 q12Shape9T313=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1099511889920 (550880542720 ||| 2^41) q12Shape9T314 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (1099511889920 ||| 2^41) 550880542720 q12Shape9T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T314OK,q12Shape9T325OK⟩

private def q12Shape9T283 : Tree 12 := .split 40 q12Shape9T284 q12Shape9T313
private theorem q12Shape9T283OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 550880542720 q12Shape9T283=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (550880542720 ||| 2^40) q12Shape9T284 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^40) 550880542720 q12Shape9T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T284OK,q12Shape9T313OK⟩

private def q12Shape9T333 : Tree 12 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,6,7,8})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,7,9,10,11}))) (.tip (.cover {0,1,4,7,8,10,11}))) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape9T333OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 34085988335616 q12Shape9T333=true := by decide

private def q12Shape9T334 : Tree 12 := (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,9})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11})))
private theorem q12Shape9T334OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549758173184 34085986238464 q12Shape9T334=true := by decide

private def q12Shape9T332 : Tree 12 := .split 21 q12Shape9T333 q12Shape9T334
private theorem q12Shape9T332OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 34085986238464 q12Shape9T332=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 (34085986238464 ||| 2^21) q12Shape9T333 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756076032 ||| 2^21) 34085986238464 q12Shape9T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T333OK,q12Shape9T334OK⟩

private def q12Shape9T335 : Tree 12 := (.split 21 (.split 22 (.split 23 (.tip (.cover {1,2,3,5,6,7,8})) (.tip (.cover {0,1,4,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8,11}))) (.tip (.cover {0,1,4,5,7,10,11})))
private theorem q12Shape9T335OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549757124608 34085985189888 q12Shape9T335=true := by decide

private def q12Shape9T331 : Tree 12 := .split 20 q12Shape9T332 q12Shape9T335
private theorem q12Shape9T331OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 34085985189888 q12Shape9T331=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 (34085985189888 ||| 2^20) q12Shape9T332 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756076032 ||| 2^20) 34085985189888 q12Shape9T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T332OK,q12Shape9T335OK⟩

private def q12Shape9T336 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape9T336OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 18141942120448 16493799145472 q12Shape9T336=true := by decide

private def q12Shape9T330 : Tree 12 := .split 44 q12Shape9T331 q12Shape9T336
private theorem q12Shape9T330OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 16493799145472 q12Shape9T330=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 (16493799145472 ||| 2^44) q12Shape9T331 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756076032 ||| 2^44) 16493799145472 q12Shape9T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T331OK,q12Shape9T336OK⟩

private def q12Shape9T337 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,10}))
private theorem q12Shape9T337OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 9345849098240 7697706123264 q12Shape9T337=true := by decide

private def q12Shape9T329 : Tree 12 := .split 43 q12Shape9T330 q12Shape9T337
private theorem q12Shape9T329OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 7697706123264 q12Shape9T329=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 (7697706123264 ||| 2^43) q12Shape9T330 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756076032 ||| 2^43) 7697706123264 q12Shape9T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T330OK,q12Shape9T337OK⟩

private def q12Shape9T338 : Tree 12 := (.tip (.cover {0,1,4,5,7,9,11}))
private theorem q12Shape9T338OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 4947802587136 3299659612160 q12Shape9T338=true := by decide

private def q12Shape9T328 : Tree 12 := .split 42 q12Shape9T329 q12Shape9T338
private theorem q12Shape9T328OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 3299659612160 q12Shape9T328=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 (3299659612160 ||| 2^42) q12Shape9T329 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756076032 ||| 2^42) 3299659612160 q12Shape9T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T329OK,q12Shape9T338OK⟩

private def q12Shape9T339 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,10}))
private theorem q12Shape9T339OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 2748779331584 1100636356608 q12Shape9T339=true := by decide

private def q12Shape9T327 : Tree 12 := .split 41 q12Shape9T328 q12Shape9T339
private theorem q12Shape9T327OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 1100636356608 q12Shape9T327=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 (1100636356608 ||| 2^41) q12Shape9T328 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756076032 ||| 2^41) 1100636356608 q12Shape9T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T328OK,q12Shape9T339OK⟩

private def q12Shape9T340 : Tree 12 := (.tip (.cover {0,1,4,5,7,8,11}))
private theorem q12Shape9T340OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1649267703808 1124728832 q12Shape9T340=true := by decide

private def q12Shape9T326 : Tree 12 := .split 40 q12Shape9T327 q12Shape9T340
private theorem q12Shape9T326OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 1124728832 q12Shape9T326=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 549756076032 (1124728832 ||| 2^40) q12Shape9T327 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (549756076032 ||| 2^40) 1124728832 q12Shape9T340)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T327OK,q12Shape9T340OK⟩

private def q12Shape9T282 : Tree 12 := .split 39 q12Shape9T283 q12Shape9T326
private theorem q12Shape9T282OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 1124728832 q12Shape9T282=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (1124728832 ||| 2^39) q12Shape9T283 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^39) 1124728832 q12Shape9T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T283OK,q12Shape9T326OK⟩

private def q12Shape9T341 : Tree 12 := (.split 39 (.split 40 (.split 41 (.split 42 (.split 43 (.split 44 (.tip (.cover {1,2,3,4,5,6,7})) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,9,11}))) (.tip (.cover {0,1,5,6,8,10,11})))
private theorem q12Shape9T341OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 1074003968 50987008 q12Shape9T341=true := by decide

private def q12Shape9T281 : Tree 12 := .split 30 q12Shape9T282 q12Shape9T341
private theorem q12Shape9T281OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 50987008 q12Shape9T281=true := by
  change (fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 (50987008 ||| 2^30) q12Shape9T282 &&
    fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) (262144 ||| 2^30) 50987008 q12Shape9T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q12Shape9T282OK,q12Shape9T341OK⟩

def q12Shape9P7 : Tree 12 := q12Shape9T281
theorem q12Shape9P7OK : fastTreeOK (root (n:=12) (by decide)) (adj 12 ⟨false,6,6,2⟩) 262144 50987008 q12Shape9P7=true := q12Shape9T281OK

end Graffiti384b.EffectiveSearch.Q12
