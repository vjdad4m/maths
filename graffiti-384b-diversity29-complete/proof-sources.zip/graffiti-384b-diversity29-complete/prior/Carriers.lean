import PrivateFront
import TwoGaps
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph Four29 FiveChoice
open private Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A collection of private paired contacts. Each point has a mate from the same collection. -/
structure PetalSet (W C : Finset V) (a : V) (U : Finset V) : Prop where
  inside : U⊆privateAt G W C a
  paired : ∀x∈U,∃m∈U,G.Adj x m

theorem PetalSet.join {W C : Finset V} {a : V} {U S : Finset V}
    (H : PetalSet G W C a U) (D : PetalSet G W C a S) : PetalSet G W C a (U∪S) := by
  refine ⟨union_subset H.inside D.inside,?_⟩
  intro x xm
  rcases mem_union.mp xm with xu|xs
  · obtain ⟨m,mu,xm⟩ := H.paired x xu; exact ⟨m,mem_union_left _ mu,xm⟩
  · obtain ⟨m,ms,xm⟩ := D.paired x xs; exact ⟨m,mem_union_right _ ms,xm⟩

private theorem petal_data {e f a : V} {p : Finset V} (pm : p∈petals G e f a)
    (inc : p⊆privateAt G (roots G e f) (triangleContacts G e f) a) :
    PetalSet G (roots G e f) (triangleContacts G e f) a p := by
  obtain ⟨_,sz,cl⟩ := Repair.edge_info G (mem_filter.mp pm).1
  refine ⟨inc,?_⟩
  intro x xm
  obtain ⟨m,mm,ne⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) x
  exact ⟨m,mm,cl x xm m mm ne.symm⟩

theorem carriers {e f a b : V} (D : Data G e f) (de : G.degree e=2) (df : G.degree f=2)
    (sep : Disjoint (G.neighborFinset e) (G.neighborFinset f))
    (no3 : ∀u∈roots G e f,∀x∈roots G e f,∀y∈roots G e f,G.Adj u x → G.Adj u y → ¬G.Adj x y)
    (aw : a∈roots G e f) (bw : b∈roots G e f) (ab : a≠b)
    (wa : Weak G (roots G e f) (triangleContacts G e f) a) (wb : Weak G (roots G e f) (triangleContacts G e f) b)
    (order : trianglesAt G a<trianglesAt G b) :
    let W := roots G e f; let C := triangleContacts G e f
    ∃U S : Finset V,PetalSet G W C a U ∧ PetalSet G W C b S ∧ Disjoint U S ∧ U.card=2 ∧ S.card=4 := by
  classical
  obtain ⟨ai,_,an,_⟩ := private_pairs G D de df sep no3 aw wa
  obtain ⟨bi,dis,bn,_⟩ := private_pairs G D de df sep no3 bw wb
  have ar := D.rich a (D.highRoots aw)
  obtain ⟨p,pm⟩ := card_pos.mp (by omega : 0<(petals G e f a).card)
  obtain ⟨r,rm⟩ := card_pos.mp (by omega : 0<(petals G e f b).card)
  obtain ⟨s,sm,sr⟩ := exists_ne_of_one_lt_card (by omega : 1<(petals G e f b).card) r
  have atA := petal_data G pm (ai p pm)
  have atB := (petal_data G rm (bi r rm)).join G (petal_data G sm (bi s sm))
  refine ⟨p,r∪s,atA,atB,disjoint_left.mpr (fun x xp xb => ab
    ((mem_filter.mp (atB.inside xb)).2.2 a aw (mem_filter.mp (atA.inside xp)).2.1)),
    link_two G a p (mem_filter.mp pm).1,?_⟩
  rw [card_union_of_disjoint (show Disjoint r s from dis rm sm sr.symm),link_two G b r (mem_filter.mp rm).1,link_two G b s (mem_filter.mp sm).1]
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.carriers
