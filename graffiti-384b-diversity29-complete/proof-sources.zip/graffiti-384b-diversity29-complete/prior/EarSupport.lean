import RootPairs
import ChoicePatch
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph LowSample Four29 FiveChoice
open private Repair.edge_info from Repair384b
open private Prune.links Prune.link_in_core from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem shape_sets {e f : V} (D : Data G e f) (de : G.degree e=2) (df : G.degree f=2) :
    let W := roots G e f; let C := triangleContacts G e f; let E : Finset V := {e,f}
    Disjoint W C ∧ Disjoint W E ∧ Disjoint E C ∧
      (∀v∈E,2≤nbr G v W) ∧ (∀a∈W,∃v∈E,G.Adj a v) := by
  classical
  let W := roots G e f
  let C := triangleContacts G e f
  let E : Finset V := {e,f}
  have he : Disjoint (high G) E := disjoint_left.mpr (fun _ hi ue =>
    (mem_sdiff.mp (D.earSet.symm ▸ ue : _∈twos G)).2 hi)
  have cp : C⊆pool G e f := filter_subset ..
  refine ⟨disjoint_left.mpr (fun _ aw vc => (mem_sdiff.mp (cp vc)).2 aw),
    he.mono_left D.highRoots,he.symm.mono_right (cp.trans sdiff_subset),?_,?_⟩
  · intro v vm
    have count {x : V} (n : G.neighborFinset x⊆W) (dg : G.degree x=2) : 2≤nbr G x W := by
      have inc : G.neighborFinset x⊆W.filter (G.Adj x) := fun u um => mem_filter.mpr ⟨n um,(G.mem_neighborFinset ..).mp um⟩
      simpa only [card_neighborFinset_eq_degree,dg] using card_le_card inc
    rcases mem_insert.mp vm with rfl|y
    · exact count subset_union_left de
    · obtain rfl := mem_singleton.mp y; exact count subset_union_right df
  · intro a aw
    rcases mem_union.mp aw with ae|af
    · exact ⟨e,by simp,((G.mem_neighborFinset ..).mp ae).symm⟩
    · exact ⟨f,by simp,((G.mem_neighborFinset ..).mp af).symm⟩

theorem link_region {e f a x : V} (D : Data G e f) (aw : a∈roots G e f) {p : Finset V}
    (pm : p∈link G a) (xp : x∈p) :
    x∈({e,f}:Finset V) ∨ x∈roots G e f ∨ x∈triangleContacts G e f := by
  by_cases hi : x∈high G
  · by_cases root : x∈roots G e f
    · exact Or.inr (Or.inl root)
    · exact Or.inr (Or.inr (mem_filter.mpr ⟨mem_sdiff.mpr ⟨hi,root⟩,a,aw,mem_biUnion.mpr ⟨p,pm,xp⟩⟩))
  · have nl := Prune.link_in_core G (show p∈Prune.links G a from pm) xp
    exact Or.inl (D.earSet ▸ (mem_sdiff.mpr ⟨nl,hi⟩ : x∈twos G))

/-- There is at most one ear-containing triangle at each of the four roots. -/
theorem ear_link {e f a : V} (de : G.degree e=2) (df : G.degree f=2)
    (dis : Disjoint (G.neighborFinset e) (G.neighborFinset f)) :
    ((link G a).filter (fun p => ¬Disjoint p ({e,f}:Finset V))).card≤1 := by
  classical
  have atEar {z : V} (dg : G.degree z=2) (za : G.Adj z a) {p : Finset V} (pm : p∈link G a) (zp : z∈p) :
      p=insert z ((G.neighborFinset z).erase a) := by
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info G pm
    obtain ⟨b,bp,ne⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) z
    have zb := cl z zp b bp ne.symm
    have ab := (G.mem_neighborFinset ..).mp (sub bp)
    have zmem := (G.mem_neighborFinset ..).mpr za
    have inc : ({a,b}:Finset V)⊆G.neighborFinset z := insert_subset zmem (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr zb))
    have eq := eq_of_subset_of_card_le inc (by rw [card_neighborFinset_eq_degree,dg,card_pair ab.ne])
    have pair := eq_of_subset_of_card_le (insert_subset zp (singleton_subset_iff.mpr bp)) (by rw [sz,card_pair ne.symm])
    rw [←eq,←pair]; simp [ab.ne.symm,ab.ne]
  have classify {p : Finset V} (m : p∈(link G a).filter (fun z => ¬Disjoint z ({e,f}:Finset V))) :
      (e∈p ∧ a∈G.neighborFinset e) ∨ (f∈p ∧ a∈G.neighborFinset f) := by
    obtain ⟨pm,notDis⟩ := mem_filter.mp m
    obtain ⟨v,vp,ve⟩ := not_disjoint_iff.mp notDis
    have av := (G.mem_neighborFinset ..).mp ((Repair.edge_info G pm).1 vp)
    rcases mem_insert.mp ve with rfl|vf
    · exact Or.inl ⟨vp,(G.mem_neighborFinset ..).mpr av.symm⟩
    · obtain rfl := mem_singleton.mp vf; exact Or.inr ⟨vp,(G.mem_neighborFinset ..).mpr av.symm⟩
  apply card_le_one.mpr
  intro p pm r rm
  rcases classify pm with ⟨ep,ae⟩|⟨fp,af⟩ <;> rcases classify rm with ⟨er,are⟩|⟨fr,arf⟩
  · exact (atEar de ((G.mem_neighborFinset ..).mp ae) (mem_filter.mp pm).1 ep).trans
      (atEar de ((G.mem_neighborFinset ..).mp are) (mem_filter.mp rm).1 er).symm
  · exact (disjoint_left.mp dis ae arf).elim
  · exact (disjoint_left.mp dis are af).elim
  · exact (atEar df ((G.mem_neighborFinset ..).mp af) (mem_filter.mp pm).1 fp).trans
      (atEar df ((G.mem_neighborFinset ..).mp arf) (mem_filter.mp rm).1 fr).symm
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.shape_sets
#print axioms Graffiti384b.PrivatePatch.link_region
#print axioms Graffiti384b.PrivatePatch.ear_link
