import PrivateLinks
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph Four29 FiveChoice
open private Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A thirteen-triangle root needs at least four adjacent contact vertices.
The ear contributes at most one triangle, and at most two root neighbors
are available. -/
theorem major_contacts {e f r : V} (D : Data G e f) (de : G.degree e=2) (df : G.degree f=2)
    (sep : Disjoint (G.neighborFinset e) (G.neighborFinset f)) (rw' : r∈roots G e f)
    (few : nbr G r (roots G e f)≤2) (score : 13≤trianglesAt G r) :
    4≤((triangleContacts G e f).filter (G.Adj r)).card := by
  classical
  let W := (roots G e f).filter (G.Adj r)
  let B := (triangleContacts G e f).filter (G.Adj r)
  have inc : petals G e f r⊆(W∪B).powersetCard 2 := by
    intro p pm
    obtain ⟨hit,off⟩ := mem_filter.mp pm
    obtain ⟨sub,sz,_⟩ := Repair.edge_info G hit
    apply mem_powersetCard.mpr ⟨?_,sz⟩
    intro x xm
    have rx := (G.mem_neighborFinset ..).mp (sub xm)
    rcases link_region G D rw' hit xm with ear|root|contact
    · exact (disjoint_left.mp off xm ear).elim
    · exact mem_union_left _ (mem_filter.mpr ⟨root,rx⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨contact,rx⟩)
  by_contra! low
  have wlen : W.card≤2 := few
  change B.card<4 at low
  have blen : B.card≤3 := by omega
  have cap : (W∪B).card≤5 := (card_union_le ..).trans (by omega)
  have ct := card_le_card inc
  rw [card_powersetCard] at ct
  have cmp := Nat.choose_le_choose 2 cap
  change _≤10 at cmp
  have ear := ear_link G de df sep (a:=r)
  have total := filter_card_add_filter_neg_card_eq_card (s:=link G r) (fun p => Disjoint p ({e,f}:Finset V))
  change (petals G e f r).card+_=trianglesAt G r at total
  omega

/-- The entire private matching at a weak root is unavailable to any
other root when counting that root's contact neighbors. -/
theorem weak_region {e f a : V} (D : Data G e f) (de : G.degree e=2) (df : G.degree f=2)
    (sep : Disjoint (G.neighborFinset e) (G.neighborFinset f))
    (no3 : ∀u∈roots G e f,∀x∈roots G e f,∀y∈roots G e f,G.Adj u x → G.Adj u y → ¬G.Adj x y)
    (aw : a∈roots G e f) (w : Weak G (roots G e f) (triangleContacts G e f) a) :
    2*trianglesAt G a≤(privateAt G (roots G e f) (triangleContacts G e f) a).card+2 := by
  obtain ⟨inc,_,ct,size⟩ := private_pairs G D de df sep no3 aw w
  have sub := card_le_card (biUnion_subset.mpr inc : (petals G e f a).biUnion id ⊆ _)
  omega
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.major_contacts
#print axioms Graffiti384b.PrivatePatch.weak_region
