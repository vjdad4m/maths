import Carriers
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph Four29 SixFront
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The two unprotected roots have disjoint reserves of free, paired contacts. -/
structure Board (e f a b : V) (P Q U S : Finset V) : Prop where
  data : Data G e f
  quota : (types G).card≤(nonleaves G).card
  bad : bound G<gamma G
  frame : TwoGaps G P Q a b
  ear1 : e∈P∪Q
  ear2 : f∈P∪Q
  dis : Disjoint U S
  freeU : Disjoint U (P∪Q)
  freeS : Disjoint S (P∪Q)
  touchU : ∀x∈U,G.Adj a x
  touchS : ∀x∈S,G.Adj b x
  pairU : ∀x∈U,∃m∈U,G.Adj x m
  pairS : ∀x∈S,∃m∈S,G.Adj x m
  hasU : U.Nonempty
  hasS : S.Nonempty

variable {e f a b : V} {P Q U S : Finset V}

theorem Board.swap (H : Board G e f a b P Q U S) : Board G e f b a P Q S U :=
  ⟨H.data,H.quota,H.bad,H.frame.swap G,H.ear1,H.ear2,H.dis.symm,H.freeS,H.freeU,H.touchS,H.touchU,
    H.pairS,H.pairU,H.hasS,H.hasU⟩

theorem Board.both (H : Board G e f a b P Q U S) {I J : Finset V} (piece : Piece G P Q I J)
    (ar : Reaches G Q J a) (br : Reaches G Q J b) : False :=
  (not_lt_of_ge (extension_bound G H.data H.quota H.ear1 H.ear2 (extend_both G H.frame piece ar br))) H.bad

theorem Board.one (H : Board G e f a b P Q U S) {I J : Finset V} (piece : Piece G P Q I J)
    (ar : Reaches G Q J a) (spare : Disjoint S (I∪J)) : False := by
  let B := extend_one G H.frame piece ar
  obtain ⟨y,ys⟩ := H.hasS
  obtain ⟨z,zs,yz⟩ := H.pairS y ys
  have outside {v : V} (vs : v∈S) : v∉(P∪I)∪(Q∪J) := by
    intro h
    rcases mem_union.mp h with h|h <;> rcases mem_union.mp h with h|h
    · exact disjoint_left.mp H.freeS vs (mem_union_left _ h)
    · exact disjoint_left.mp spare vs (mem_union_left _ h)
    · exact disjoint_left.mp H.freeS vs (mem_union_right _ h)
    · exact disjoint_left.mp spare vs (mem_union_right _ h)
  have old : P∪Q⊆(P∪I)∪(Q∪J) := union_subset_union subset_union_left subset_union_left
  exact (not_lt_of_ge (FreeGap.free_triangle G H.data H.quota B (old H.ear1) (old H.ear2)
    (outside ys) (outside zs) (H.touchS y ys) (H.touchS z zs) yz)) H.bad

/-- A reserved point can see just its own root among the current pins. -/
theorem Board.pin (H : Board G e f a b P Q U S) {x z : V} (xu : x∈U) (xz : G.Adj x z)
    (zp : z∈P∪Q) : z=a := by
  by_contra ne
  have xo := disjoint_left.mp H.freeU xu
  have xq : x∉Q := fun m => xo (mem_union_right _ m)
  have ax := H.touchU x xu
  rcases mem_union.mp zp with zl|zr
  · exact H.one G (piece_two G H.frame.apart H.frame.aLeft zl xo (Ne.symm ne) ax xz)
      ⟨x,mem_singleton_self _,xq,ax⟩ (by simpa using H.dis.symm.mono_right (singleton_subset_iff.mpr xu))
  · obtain ⟨m,mu,xm⟩ := H.pairU x xu
    have mo := disjoint_left.mp H.freeU mu
    have am := H.touchU m mu
    apply H.one G (piece_three G H.frame.apart H.frame.aLeft zr mo xo am xm.symm xz)
      ⟨m,mem_singleton_self _,fun h => mo (mem_union_right _ h),am⟩
    exact H.dis.symm.mono_right (union_subset (singleton_subset_iff.mpr xu) (singleton_subset_iff.mpr mu))

theorem Board.no_cross (H : Board G e f a b P Q U S) {x y : V} (xu : x∈U) (ys : y∈S) : ¬G.Adj x y := by
  intro xy
  obtain ⟨m,mu,xm⟩ := H.pairU x xu
  have mo := disjoint_left.mp H.freeU mu
  have xo := disjoint_left.mp H.freeU xu
  have yo := disjoint_left.mp H.freeS ys
  have am := H.touchU m mu
  have by' := H.touchS y ys
  apply H.both G (piece_four G H.frame.apart H.frame.aLeft H.frame.bLeft mo xo yo
    (fun eq => disjoint_left.mp H.dis mu (eq ▸ ys)) am xm.symm xy by'.symm)
  · exact ⟨m,mem_insert_self ..,fun h => mo (mem_union_right _ h),am⟩
  · exact ⟨y,mem_insert_of_mem (mem_singleton_self _),fun h => yo (mem_union_right _ h),by'⟩

/-- An outside common neighbor of two reserved points produces a four-cycle
or a four-edge return between the roots. -/
theorem Board.no_common (H : Board G e f a b P Q U S) {x y z : V}
    (xu : x∈U) (ys : y∈U∪S) (ne : x≠y) (za : z≠a) (zs : z∉S) (xz : G.Adj x z) :
    ¬G.Adj y z := by
  intro yz
  have zo : z∉P∪Q := fun h => za (H.pin G xu xz h)
  have xo := disjoint_left.mp H.freeU xu
  have ax := H.touchU x xu
  have xq : x∉Q := fun h => xo (mem_union_right _ h)
  rcases mem_union.mp ys with yu|ys
  · have yo := disjoint_left.mp H.freeU yu
    have ay := H.touchU y yu
    apply H.one G (piece_four G H.frame.apart H.frame.aLeft H.frame.aLeft xo zo yo ne ax xz yz.symm ay.symm)
      ⟨x,mem_insert_self ..,xq,ax⟩
    apply disjoint_union_right.mpr ⟨by simpa using zs,?_⟩
    exact H.dis.symm.mono_right (insert_subset xu (singleton_subset_iff.mpr yu))
  · have yo := disjoint_left.mp H.freeS ys
    have by' := H.touchS y ys
    apply H.both G (piece_four G H.frame.apart H.frame.aLeft H.frame.bLeft xo zo yo ne ax xz yz.symm by'.symm)
      ⟨x,mem_insert_self ..,xq,ax⟩
    exact ⟨y,mem_insert_of_mem (mem_singleton_self _),fun h => yo (mem_union_right _ h),by'⟩
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.Board.pin
#print axioms Graffiti384b.PrivatePatch.Board.no_cross
#print axioms Graffiti384b.PrivatePatch.Board.no_common
