import MajorContacts
import TwoWeak
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph Four29 LowSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Exactly two weak anchors survive. Their two private matching regions,
together with the large anchor's contacts, give a numerical certificate. -/
theorem private_front {e f : V} (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    (bad : bound G<gamma G) (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f) :
    let W := roots G e f; let C := triangleContacts G e f
    ∃a∈W,∃b∈W,a≠b ∧ Weak G W C a ∧ Weak G W C b ∧
      (∀v∈W,Weak G W C v → v=a ∨ v=b) ∧
      2*(trianglesAt G a+trianglesAt G b)≤C.card ∧ 10≤C.card ∧ C.card≤14 := by
  classical
  let W := roots G e f
  let C := triangleContacts G e f
  let A := privateAt G W C
  obtain ⟨⟨m,mw,ms⟩,_,te,elim',_⟩ := five_contact_residual G t h q bad de df ef
  have hi : C.card≤14 := te.trans elim'
  have D := data_of_failure G t h q bad de df ef
  obtain ⟨sep,few,no3⟩ := root_shape G t q h bad de df ef
  let B := C.filter (G.Adj m)
  have four : 4≤B.card := major_contacts G D de df sep mw (few m mw) ms
  have wsize {x : V} (xw : x∈W) (wk : Weak G W C x) : 2*trianglesAt G x≤(A x).card+2 :=
    weak_region G D de df sep no3 xw wk
  have reg (x : V) : A x⊆C := filter_subset ..
  have rich {x : V} (xw : x∈W) := D.rich x (D.highRoots xw)
  have inj {x y : V} (xw : x∈W) (yw : y∈W) (ne : x≠y) : trianglesAt G x≠trianglesAt G y :=
    fun eq => ne (D.scoreInj (D.highRoots xw) (D.highRoots yw) eq)
  have db {x : V} (xw : x∈W) (wk : Weak G W C x) : Disjoint (A x) B := by
    have nm : m≠x := by
      rintro rfl; have cmp := wsize xw wk; have sz := card_le_card (reg m); omega
    exact disjoint_left.mpr (fun u ux um => nm ((mem_filter.mp ux).2.2 m mw (mem_filter.mp um).2))
  have dp {x y : V} (xw : x∈W) (ne : x≠y) : Disjoint (A x) (A y) := disjoint_left.mpr
    (fun _ ux uy => ne ((mem_filter.mp uy).2.2 x xw (mem_filter.mp ux).2.1))
  obtain ⟨a,aw,b,bw,ab,wa,wb⟩ := two_weak G t q h bad de df ef
  have dis := dp aw ab
  have cmp := card_le_card (union_subset (union_subset (reg a) (reg b)) (filter_subset (G.Adj m) C))
  rw [card_union_of_disjoint (disjoint_union_left.mpr ⟨db aw wa,db bw wb⟩),card_union_of_disjoint dis] at cmp
  have aCost := wsize aw wa
  have bCost := wsize bw wb
  have ar := rich aw
  have br := rich bw
  have diff := inj aw bw ab
  have budget : 2*(trianglesAt G a+trianglesAt G b)≤C.card := by omega
  have ten : 10≤C.card := by omega
  refine ⟨a,aw,b,bw,ab,wa,wb,?_,budget,ten,hi⟩
  intro v vw wv
  by_cases va : v=a
  · exact Or.inl va
  apply Or.inr
  by_contra vb
  have cmp3 := card_le_card (union_subset (union_subset (union_subset (reg a) (reg b)) (reg v)) (filter_subset (G.Adj m) C))
  rw [card_union_of_disjoint (disjoint_union_left.mpr ⟨disjoint_union_left.mpr ⟨db aw wa,db bw wb⟩,db vw wv⟩),
    card_union_of_disjoint (disjoint_union_left.mpr ⟨dp aw (Ne.symm va),dp bw (Ne.symm vb)⟩),card_union_of_disjoint dis] at cmp3
  have vr := rich vw
  have differentA := inj vw aw va
  have differentB := inj vw bw vb
  have vCost := wsize vw wv
  omega

/-- This covers seven, eight and nine contacts at every graph order. -/
theorem up_to_nine {e f : V} (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f)
    (small : (triangleContacts G e f).card≤9) : gamma G≤bound G := by
  apply Nat.le_of_not_gt; intro bad
  obtain ⟨_,_,_,_,_,_,_,_,_,lo,_⟩ := private_front G t q h bad de df ef
  omega
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.private_front
#print axioms Graffiti384b.PrivatePatch.up_to_nine
