import EarSupport
import WeakRootPatch
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph Four29 FiveChoice
open private Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def petals (e f a : V) := (link G a).filter (fun p => Disjoint p ({e,f}:Finset V))

/-- Away from its ear triangle, a weak root has a matching of private pairs. -/
theorem private_pairs {e f a : V} (D : Data G e f) (de : G.degree e=2) (df : G.degree f=2)
    (sep : Disjoint (G.neighborFinset e) (G.neighborFinset f))
    (no3 : ∀u∈roots G e f,∀x∈roots G e f,∀y∈roots G e f,G.Adj u x → G.Adj u y → ¬G.Adj x y)
    (aw : a∈roots G e f) (weak : Weak G (roots G e f) (triangleContacts G e f) a) :
    let F := petals G e f a
    (∀p∈F,p⊆privateAt G (roots G e f) (triangleContacts G e f) a) ∧
    F.toSet.PairwiseDisjoint id ∧ trianglesAt G a≤F.card+1 ∧ (F.biUnion id).card=2*F.card := by
  classical
  let W := roots G e f
  let C := triangleContacts G e f
  let A := privateAt G W C a
  let F := petals G e f a
  have own {x : V} (xc : x∈C) (ax : G.Adj a x) : x∈A := by
    refine mem_filter.mpr ⟨xc,ax,?_⟩
    intro b bw bx; by_contra ne
    have cnt := PinnedColor34.two G ne bx.symm ax.symm bw aw
    exact weak.1 x (mem_filter.mpr ⟨xc,cnt⟩) ax
  have inc (p : Finset V) (pm : p∈F) : p⊆A := by
    obtain ⟨hit,off⟩ := mem_filter.mp pm
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info G hit
    intro x xm
    obtain ⟨y,ym,yx⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) x
    have ax := (G.mem_neighborFinset ..).mp (sub xm)
    have ay := (G.mem_neighborFinset ..).mp (sub ym)
    have xy := cl x xm y ym yx.symm
    rcases link_region G D aw hit xm with ear|xw|xc
    · exact (disjoint_left.mp off xm ear).elim
    · rcases link_region G D aw hit ym with ear|yw|yc
      · exact (disjoint_left.mp off ym ear).elim
      · exact (no3 a aw x xw y yw ax ay xy).elim
      · have only := (mem_filter.mp (own yc ay)).2.2 x xw xy
        exact (ax.ne only.symm).elim
    · exact own xc ax
  have dis : F.toSet.PairwiseDisjoint id := by
    intro p pm r rm ne
    apply disjoint_left.mpr
    intro y yp yr
    have edge {l : Finset V} (lm : l∈F) (yl : y∈l) : ∃x∈l,G.Adj y x ∧ l={y,x} := by
      obtain ⟨_,sz,cl⟩ := Repair.edge_info G (mem_filter.mp lm).1
      obtain ⟨x,xm,xy⟩ := exists_ne_of_one_lt_card (by omega : 1<l.card) y
      exact ⟨x,xm,cl y yl x xm xy.symm,(eq_of_subset_of_card_le (insert_subset yl (singleton_subset_iff.mpr xm))
        (by rw [sz,card_pair xy.symm])).symm⟩
    obtain ⟨x,xp,yx,px⟩ := edge pm yp
    obtain ⟨z,zr,yz,rz⟩ := edge rm yr
    have diff : x≠z := fun eq => ne (px.trans (eq ▸ rz.symm))
    exact weak.2 ⟨x,inc p pm xp,y,inc p pm yp,z,inc r rm zr,diff,yx.symm,yz⟩
  have ct := filter_card_add_filter_neg_card_eq_card (s:=link G a) (fun p => Disjoint p ({e,f}:Finset V))
  have lost := ear_link G de df sep (a:=a)
  have ss : trianglesAt G a≤F.card+1 := by change (link G a).card≤_; change F.card+_=_ at ct; omega
  refine ⟨inc,dis,ss,?_⟩
  rw [card_biUnion dis]
  calc ∑p∈F,(id p).card = ∑ _p∈F,2 := sum_congr rfl (fun p pm => link_two G a p (mem_filter.mp pm).1)
       _ = 2*F.card := by simp [Nat.mul_comm]
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.private_pairs
