import ForkClosure
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph Four29
open private Repair.nbr_add from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem apart_roots {e f : V} (D : Data G e f) (de : G.degree e=2) (df : G.degree f=2) :
    Disjoint (G.neighborFinset e) (G.neighborFinset f) := by
  have sz := card_union_add_card_inter (G.neighborFinset e) (G.neighborFinset f)
  change (roots G e f).card+_= _ at sz
  rw [D.rootsSize,card_neighborFinset_eq_degree,card_neighborFinset_eq_degree,de,df] at sz
  exact disjoint_iff_inter_eq_empty.mpr (card_eq_zero.mp (by omega))

private theorem cross {e f : V} (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    (bad : bound G<gamma G) (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f)
    {a : V} (am : a∈G.neighborFinset e) : nbr G a (G.neighborFinset f)≤1 := by
  classical
  have D := data_of_failure G t h q bad de df ef
  obtain ⟨a',b',ab',en⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G e).trans de)
  obtain ⟨b,ne,first⟩ : ∃b,b≠a ∧ G.neighborFinset e={b,a} := by
    rw [en,mem_insert,mem_singleton] at am
    rcases am with rfl|rfl
    · exact ⟨_,ab'.symm,en.trans (pair_comm ..)⟩
    · exact ⟨_,ab',en⟩
  obtain ⟨c,d,cd,second⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G f).trans df)
  let l : Fin 6→V := ![b,a,c,d,e,f]
  let W := roots G e f
  let E : Finset V := {e,f}
  have we : Disjoint W E := disjoint_left.mpr (fun _ uw ue => (mem_sdiff.mp (D.earSet.symm ▸ ue : _∈LowSample.twos G)).2 (D.highRoots uw))
  have size : (W∪E).card=6 := by rw [card_union_of_disjoint we,D.rootsSize,show E.card=2 from card_pair ef]
  have inside : W∪E ⊆ univ.image l := by
    intro v vm
    change v∈(G.neighborFinset e∪G.neighborFinset f)∪{e,f} at vm
    rw [first,second] at vm
    simp only [mem_union,mem_insert,mem_singleton] at vm
    rcases vm with ((rfl|rfl)|(rfl|rfl))|(rfl|rfl)
    all_goals first | exact mem_image.mpr ⟨0,mem_univ _,rfl⟩ | exact mem_image.mpr ⟨1,mem_univ _,rfl⟩ |
      exact mem_image.mpr ⟨2,mem_univ _,rfl⟩ | exact mem_image.mpr ⟨3,mem_univ _,rfl⟩ |
      exact mem_image.mpr ⟨4,mem_univ _,rfl⟩ | exact mem_image.mpr ⟨5,mem_univ _,rfl⟩
  have inj := (card_image_iff (s:=univ) (f:=l)).mp (Nat.le_antisymm card_image_le (by
    have cmp := card_le_card inside; rw [size] at cmp; simpa using cmp))
  let emb : Fin 6 ↪ V := ⟨l,fun _ _ eq => inj (mem_univ _) (mem_univ _) eq⟩
  by_contra! no
  have all : (G.neighborFinset f).filter (G.Adj a)=G.neighborFinset f :=
    eq_of_subset_of_card_le (filter_subset ..) (by rw [card_neighborFinset_eq_degree,df]; exact no)
  have ad {z : V} (zm : z∈G.neighborFinset f) : G.Adj a z := (mem_filter.mp (all.symm ▸ zm)).2
  exact (not_lt_of_ge (SixFront.fork G t q h emb first second (ad (second ▸ mem_insert_self ..))
    (ad (second ▸ mem_insert_of_mem (mem_singleton_self _))))) bad

/-- In a failing exact profile the four-root graph has degree at most two
and no triangle. Inside the opposite ear pair each root can see at most one vertex. -/
theorem root_shape {e f : V} (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    (bad : bound G<gamma G) (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f) :
    Disjoint (G.neighborFinset e) (G.neighborFinset f) ∧
    (∀a∈roots G e f,nbr G a (roots G e f)≤2) ∧
    ∀a∈roots G e f,∀x∈roots G e f,∀y∈roots G e f,G.Adj a x → G.Adj a y → ¬G.Adj x y := by
  have D := data_of_failure G t h q bad de df ef
  have dis := apart_roots G D de df
  have ab := fun {a} (m : a∈G.neighborFinset e) => cross G t q h bad de df ef m
  have ba := fun {a} (m : a∈G.neighborFinset f) => cross G t q h bad df de ef.symm m
  have own (s : Finset V) (k : s.card=2) (v : V) (m : v∈s) : nbr G v s≤1 := by
    have sub : s.filter (G.Adj v)⊆s.erase v := fun x xm => mem_erase.mpr ⟨(mem_filter.mp xm).2.ne.symm,(mem_filter.mp xm).1⟩
    have cmp := card_le_card sub
    rwa [card_erase_of_mem m,k] at cmp
  refine ⟨dis,?_,?_⟩
  · intro a aw
    rw [roots,Repair.nbr_add G a dis]
    rcases mem_union.mp aw with ea|fa
    · have l := own _ ((card_neighborFinset_eq_degree G e).trans de) _ ea
      have r := ab ea
      omega
    · have r := own _ ((card_neighborFinset_eq_degree G f).trans df) _ fa
      have l := ba fa
      omega
  · intro a aw x xw y yw ax ay xy
    have contradict {S : Finset V} {v i j : V} (cap : nbr G v S≤1) (im : i∈S) (jm : j∈S)
        (vi : G.Adj v i) (vj : G.Adj v j) (ne : i≠j) : False :=
      (by have := PinnedColor34.two G ne vi vj im jm; omega)
    have ee := own _ ((card_neighborFinset_eq_degree G e).trans de)
    have ff := own _ ((card_neighborFinset_eq_degree G f).trans df)
    rcases mem_union.mp aw with a1|a2 <;> rcases mem_union.mp xw with x1|x2 <;> rcases mem_union.mp yw with y1|y2
    all_goals first | exact contradict (ee _ a1) x1 y1 ax ay xy.ne | exact contradict (ff _ a2) x2 y2 ax ay xy.ne |
      exact contradict (ab a1) x2 y2 ax ay xy.ne | exact contradict (ba a2) x1 y1 ax ay xy.ne |
      exact contradict (ab x1) a2 y2 ax.symm xy ay.ne | exact contradict (ba x2) a1 y1 ax.symm xy ay.ne |
      exact contradict (ab y1) a2 x2 ay.symm xy.symm ax.ne | exact contradict (ba y2) a1 x1 ay.symm xy.symm ax.ne

end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.root_shape
