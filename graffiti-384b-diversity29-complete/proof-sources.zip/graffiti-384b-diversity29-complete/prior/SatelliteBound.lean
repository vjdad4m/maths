import PinBoard
import SatelliteCount
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph Four29 FiveChoice LowSample
open private Repair.edge_info from Repair384b
open private Prune.links Prune.link_in_core from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
variable {e f a b : V} {P Q U S : Finset V}

/-- A second triangle on the root edge gives a four-cycle. -/
theorem Board.unique_mate (H : Board G e f a b P Q U S) {x m z : V}
    (xu : x∈U) (mu : m∈U) (xm : G.Adj x m) (az : G.Adj a z) (xz : G.Adj x z) : z=m := by
  by_contra ne
  have zo : z∉P∪Q := fun p => az.ne (H.pin G xu xz p).symm
  have zs : z∉S := fun s => H.no_cross G xu s xz
  have mo := disjoint_left.mp H.freeU mu
  have xo := disjoint_left.mp H.freeU xu
  have am := H.touchU m mu
  apply H.one G (piece_four G H.frame.apart H.frame.aLeft H.frame.aLeft mo xo zo (Ne.symm ne)
    am xm.symm xz az.symm) ⟨m,mem_insert_self ..,fun h => mo (mem_union_right _ h),am⟩
  apply disjoint_union_right.mpr ⟨H.dis.symm.mono_right (singleton_subset_iff.mpr xu),?_⟩
  exact disjoint_left.mpr (fun y ys yp => (mem_insert.mp yp).elim
    (fun eq => disjoint_left.mp H.dis mu (eq ▸ ys)) (fun eq => zs ((mem_singleton.mp eq) ▸ ys)))

def satellites (e f : V) (K : Finset V) (x : V) := (pool G e f\K).filter (G.Adj x)

/-- Apart from the triangle through its own root and mate, every triangle
at a carrier has both remaining vertices in its satellite set. -/
theorem Board.score_bound (H : Board G e f a b P Q U S)
    (wp : roots G e f⊆P) {x : V} (xu : x∈U) :
    trianglesAt G x≤1+(satellites G e f (U∪S) x).card.choose 2 := by
  classical
  let K := U∪S
  let N := satellites G e f K x
  obtain ⟨m,mu,xm⟩ := H.pairU x xu
  have same {z : V} (zu : z∈U) (xz : G.Adj x z) : z=m := H.unique_mate G xu mu xm (H.touchU z zu) xz
  have member {p : Finset V} (pm : p∈link G x) {z : V} (zp : z∈p) (za : z≠a) (zm : z≠m) : z∈N := by
    have xz := (G.mem_neighborFinset ..).mp ((Repair.edge_info G pm).1 zp)
    have unpinned : z∉P∪Q := fun mem => za (H.pin G xu xz mem)
    have highZ : z∈high G := by
      by_contra lo
      have ear : z∈twos G := mem_sdiff.mpr ⟨Prune.link_in_core G (show p∈Prune.links G x from pm) zp,lo⟩
      rw [H.data.earSet,mem_insert,mem_singleton] at ear
      exact unpinned (ear.elim (fun eq => eq ▸ H.ear1) (fun eq => eq ▸ H.ear2))
    have nr : z∉roots G e f := fun wr => unpinned (mem_union_left _ (wp wr))
    have nk : z∉K := fun zK => (mem_union.mp zK).elim (fun zu => zm (same zu xz)) (fun zs => H.no_cross G xu zs xz)
    exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨highZ,nr⟩,nk⟩,xz⟩
  have only {p : Finset V} (pm : p∈link G x) {z w : V} (pair : p={z,w}) (zw : G.Adj z w)
      (wz : G.Adj x w) (mark : z=a ∨ z=m) : p={a,m} := by
    rcases mark with rfl|rfl
    · exact (H.unique_mate G xu mu xm zw wz) ▸ pair
    · have wa : w=a := by
        by_contra neq
        exact H.no_common G xu (mem_union_left _ mu) xm.ne neq (fun ws => H.no_cross G xu ws wz) wz zw
      rw [pair,wa,pair_comm]
  have inc : link G x⊆insert ({a,m}:Finset V) (N.powersetCard 2) := by
    intro p pm
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info G pm
    obtain ⟨u,v,ne,pair⟩ := card_eq_two.mp sz
    have up : u∈p := pair ▸ mem_insert_self ..
    have vp : v∈p := pair ▸ mem_insert_of_mem (mem_singleton_self _)
    have uv := cl u up v vp ne
    have xu' := (G.mem_neighborFinset ..).mp (sub up)
    have xv := (G.mem_neighborFinset ..).mp (sub vp)
    apply mem_insert.mpr
    by_cases un : u=a ∨ u=m
    · exact Or.inl (only pm pair uv xv un)
    by_cases vn : v=a ∨ v=m
    · exact Or.inl (only pm (pair.trans (pair_comm ..)) uv.symm xu' vn)
    apply Or.inr (mem_powersetCard.mpr ⟨?_,sz⟩)
    rw [pair]
    exact insert_subset (member pm up (fun eq => un (Or.inl eq)) (fun eq => un (Or.inr eq)))
      (singleton_subset_iff.mpr (member pm vp (fun eq => vn (Or.inl eq)) (fun eq => vn (Or.inr eq))))
  have cap := (card_le_card inc).trans (card_insert_le ..)
  rw [card_powersetCard] at cap
  simpa only [Nat.add_comm 1] using cap

/-- Six carriers on a two-gap board are impossible in the twenty-seven-high-vertex profile. -/
theorem Board.impossible (H : Board G e f a b P Q U S) (aw : a∈roots G e f) (bw : b∈roots G e f)
    (wp : roots G e f⊆P) (ins : U∪S⊆pool G e f) (six : (U∪S).card=6) : False := by
  classical
  let K := U∪S
  let B := satellites G e f K
  have sc (x : V) (xk : x∈K) : trianglesAt G x≤1+(B x).card.choose 2 := by
    rcases mem_union.mp xk with xu|xs
    · exact H.score_bound G wp xu
    · simpa only [B,K,union_comm S U] using (H.swap G).score_bound G wp xs
  obtain ⟨x,xk,y,yk,ne,z,zx,zy⟩ := satellite_collision G H.data K B six ins (fun _ _ => filter_subset ..) sc
  obtain ⟨zk,xz⟩ := mem_filter.mp zx
  have yz := (mem_filter.mp zy).2
  obtain ⟨zp,notK⟩ := mem_sdiff.mp zk
  have nr := (mem_sdiff.mp zp).2
  rcases mem_union.mp xk with xu|xs
  · exact H.no_common G (z:=z) xu yk ne (fun eq => nr (eq ▸ aw)) (fun zs => notK (mem_union_right _ zs)) xz yz
  · exact (H.swap G).no_common G (z:=z) xs (union_comm U S ▸ yk) ne (fun eq => nr (eq ▸ bw))
      (fun zu => notK (mem_union_left _ zu)) xz yz
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.Board.unique_mate
#print axioms Graffiti384b.PrivatePatch.Board.score_bound
#print axioms Graffiti384b.PrivatePatch.Board.impossible
