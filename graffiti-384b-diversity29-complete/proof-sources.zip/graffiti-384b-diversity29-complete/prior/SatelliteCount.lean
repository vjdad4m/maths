import FreeTriangle
import ChoicePatch
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph LowSample Four29
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
/-- Six distinct scores at least two need at least eighteen separate
satellite vertices if each point contributes only one additional triangle. -/
theorem satellite_count (K : Finset V) (B : V → Finset V) (s : V → ℕ)
    (six : K.card=6) (rich : ∀x∈K,2≤s x) (inj : Set.InjOn s (K : Set V))
    (sc : ∀x∈K,s x≤1+(B x).card.choose 2) (apart : K.toSet.PairwiseDisjoint B) :
    18≤(K.biUnion B).card := by
  classical
  let Z := K.filter (fun x => (B x).card≤2)
  have mono {x : V} (xk : x∈K) {d : ℕ} (le : (B x).card≤d) :=
    (sc x xk).trans (Nat.add_le_add_left (Nat.choose_le_choose 2 le) 1)
  have small : Z.card≤1 := by
    apply card_le_one.mpr
    intro x xm y ym
    obtain ⟨xk,xc⟩ := mem_filter.mp xm
    obtain ⟨yk,yc⟩ := mem_filter.mp ym
    have bx := mono xk xc
    have by' := mono yk yc
    have rx := rich x xk
    have ry := rich y yk
    apply inj xk yk
    simp at bx by'; omega
  obtain ⟨z,zk,large⟩ : ∃z∈K,4≤(B z).card := by
    by_contra! no
    have sub : K.image s⊆range 5 := by
      intro u um
      obtain ⟨x,xk,rfl⟩ := mem_image.mp um
      have bd := mono xk (by have := no x xk; omega : (B x).card≤3)
      exact mem_range.mpr (by change s x≤1+3 at bd; omega)
    have cnt := card_le_card sub
    rw [card_image_of_injOn inj,card_range,six] at cnt; omega
  have minTwo (x : V) (xk : x∈K) : 2≤(B x).card := by
    by_contra! no
    have bd := mono xk (by omega : (B x).card≤1)
    have rx := rich x xk
    change s x≤1+0 at bd; omega
  have term (x : V) (xk : x∈K) : 2+(if x∈K\Z then 1 else 0)+(if x=z then 1 else 0)≤(B x).card := by
    have base := minTwo x xk
    by_cases xz : x=z
    · subst x; split <;> simp_all
      omega
    · by_cases out : x∈K\Z
      · have n := (mem_sdiff.mp out).2
        have bigger : ¬(B x).card≤2 := fun m => n (mem_filter.mpr ⟨xk,m⟩)
        simp [xz,out]; omega
      · simpa [xz,out] using base
  have total := sum_le_sum term
  rw [←card_biUnion apart] at total
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,sum_boole,filter_mem_eq_inter,inter_eq_right.mpr (sdiff_subset (s:=K) (t:=Z))] at total
  have eqz : (K.filter (fun x => x=z))={z} := by ext x; simp; rintro rfl; exact zk
  have rem := card_sdiff_add_card_eq_card (show Z⊆K from filter_subset ..)
  simp [eqz,zk,six] at total
  omega

/-- In the 27-high profile at most seventeen high vertices remain outside
four roots and six private points. Hence two of the satellite sets meet. -/
theorem satellite_collision {e f : V} (D : Data G e f)
    (K : Finset V) (B : V→Finset V) (six : K.card=6) (kp : K⊆pool G e f)
    (inside : ∀x∈K,B x⊆pool G e f\K)
    (sc : ∀x∈K,trianglesAt G x≤1+(B x).card.choose 2) :
    ∃x∈K,∃y∈K,x≠y ∧ ∃z∈B x,z∈B y := by
  classical
  by_contra! no
  have dis : K.toSet.PairwiseDisjoint B := by
    intro x xk y yk ne
    exact disjoint_left.mpr (fun z zx zy => no x xk y yk ne z zx zy)
  have kh := kp.trans (sdiff_subset (s:=high G) (t:=roots G e f))
  have ct := satellite_count K B (trianglesAt G) six (fun x xk => D.rich x (kh xk)) (D.scoreInj.mono kh) sc dis
  have cap := card_le_card (show K.biUnion B⊆pool G e f\K from biUnion_subset.mpr inside)
  rw [card_sdiff kp,D.poolSize,six] at cap
  omega
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.satellite_count
#print axioms Graffiti384b.PrivatePatch.satellite_collision
