import PrivateLinks
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph LowSample Four29 FiveChoice SixFront Exterior
open private Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Every counterexample in the exact profile must have two different weak
anchors, irrespective of the triangle-contact count. -/
theorem two_weak {e f : V} (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    (bad : bound G<gamma G) (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f) :
    ∃a∈roots G e f,∃b∈roots G e f,a≠b ∧ Weak G (roots G e f) (triangleContacts G e f) a ∧
      Weak G (roots G e f) (triangleContacts G e f) b := by
  classical
  let W := roots G e f
  let C := triangleContacts G e f
  let E : Finset V := {e,f}
  have D := data_of_failure G t h q bad de df ef
  obtain ⟨wc,we,ec,es,touch⟩ := shape_sets G D de df
  obtain ⟨P,Q,wp,eq',dis,right,left,one,free⟩ := assemble G wc we ec es touch
  have ep : e∈P∪Q := mem_union_right _ (eq' (mem_insert_self ..))
  have fp : f∈P∪Q := mem_union_right _ (eq' (mem_insert_of_mem (mem_singleton_self _)))
  have blocked : ∃a∈W,Weak G W C a := by
    by_contra! no
    apply (not_lt_of_ge (extension_bound G D (by omega) ep fp ?_) bad)
    refine ⟨P,Q,Subset.rfl,Subset.rfl,dis,?_,right⟩
    intro v vm; apply left v vm; by_cases vw : v∈W
    · exact Or.inr (no v vw)
    · exact Or.inl vw
  obtain ⟨a,aw,weak⟩ := blocked
  by_contra! no
  have only {v : V} (vw : v∈W) (va : v≠a) : ¬Weak G W C v := fun w => no a aw v vw va.symm weak w
  have gap : Gap G P Q a := ⟨dis,wp aw,one a aw,fun v vm va => left v vm (by
    by_cases vw : v∈W
    · exact Or.inr (only vw va)
    · exact Or.inl vw),right⟩
  obtain ⟨sep,_,no3⟩ := root_shape G t q h bad de df ef
  obtain ⟨inc,_,sc,_⟩ := private_pairs G D de df sep no3 aw weak
  have rich := D.rich a (D.highRoots aw)
  obtain ⟨p,pm⟩ := card_pos.mp (by omega : 0<(petals G e f a).card)
  obtain ⟨sub,sz,cl⟩ := Repair.edge_info G (mem_filter.mp pm).1
  obtain ⟨x,y,ne,pair⟩ := card_eq_two.mp sz
  have xm : x∈p := pair ▸ mem_insert_self ..
  have ym : y∈p := pair ▸ mem_insert_of_mem (mem_singleton_self _)
  exact (not_lt_of_ge (FreeGap.free_triangle G D (by omega) gap ep fp
    (disjoint_left.mp (free a aw weak) (inc p pm xm)) (disjoint_left.mp (free a aw weak) (inc p pm ym))
    ((G.mem_neighborFinset ..).mp (sub xm)) ((G.mem_neighborFinset ..).mp (sub ym)) (cl x xm y ym ne))) bad
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.two_weak
