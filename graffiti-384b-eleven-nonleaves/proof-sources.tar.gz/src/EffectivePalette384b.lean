import Proof384b
namespace Graffiti384b.EffectivePalette
open Finset
set_option linter.unusedSectionVars false

def positive {V : Type*} [Fintype V] (score : V→ℕ) : Finset ℕ :=
  (univ.filter fun v=>0<score v).image score

theorem erase_redundant {V : Type*} [Fintype V] [DecidableEq V]
    (score : V→ℕ) (S : Finset V)
    (redundant : ∀ v∈S, 0<score v→∃ w∉S, score w=score v) :
    (positive score).card≤Fintype.card V-S.card := by
  let T : Finset V := univ \ S
  have sub : positive score ⊆ T.image score := by
    intro n hn
    obtain ⟨v,hv,rfl⟩ := mem_image.mp hn
    by_cases hs : v ∈ S
    · obtain ⟨w,hw,he⟩ := redundant v hs (mem_filter.mp hv).2
      exact mem_image.mpr ⟨w,by simp [T,hw],he⟩
    · exact mem_image.mpr ⟨v,by simp [T,hs],rfl⟩
  exact (card_le_card sub).trans (card_image_le.trans_eq (card_sdiff (subset_univ _)))

theorem interval_cap {V : Type*} [Fintype V] [DecidableEq V]
    (score : V→ℕ) (S : Finset V) (l u : ℕ)
    (bounds : ∀ v∈S, l≤score v ∧ score v<l+u) :
    (positive score).card≤u+(Fintype.card V-S.card) := by
  let T : Finset V := univ \ S
  have sub : positive score ⊆ Ico l (l+u) ∪ (T.image score) := by
    intro n hn
    obtain ⟨v,hv,rfl⟩ := mem_image.mp hn
    by_cases hs : v ∈ S
    · exact mem_union_left _ (mem_Ico.mpr (bounds v hs))
    · exact mem_union_right _ (mem_image.mpr ⟨v,by simp [T,hs],rfl⟩)
  have ct : T.card=Fintype.card V-S.card := card_sdiff (subset_univ _)
  have ci : (Ico l (l+u)).card=u := by simp [Nat.card_Ico]
  calc
    _ ≤ (Ico l (l+u) ∪ T.image score).card := card_le_card sub
    _ ≤ (Ico l (l+u)).card+(T.image score).card := card_union_le _ _
    _ ≤ _ := by rw [ci, ←ct]; exact Nat.add_le_add_left card_image_le _

#print axioms erase_redundant
#print axioms interval_cap
end Graffiti384b.EffectivePalette
