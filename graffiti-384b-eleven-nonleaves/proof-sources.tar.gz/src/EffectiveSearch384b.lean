import EffectivePalette384b
import Mathlib.Data.Fin.VecNotation

namespace Graffiti384b.EffectiveSearch
open Finset
set_option linter.unusedSectionVars false
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

abbrev Label (n : ℕ) := Fin n
abbrev Rel (n : ℕ) := Label n→Label n→Bool

def orderedPairs (n : ℕ) : List (Label n × Label n) :=
  (List.ofFn (fun i : Label n=>i)).flatMap fun i =>
    ((List.ofFn (fun j : Label n=>j)).filter (fun j=>decide (i<j))).map fun j=>(i,j)

def score {n : ℕ} (E : Rel n) (v : Label n) : Nat :=
  ((orderedPairs n).filter fun ij=>E v ij.1 && E v ij.2 && E ij.1 ij.2).length

private theorem length_filter_mono {α : Type} (a b : α→Bool) (l : List α)
    (inc : ∀ x,a x=true→b x=true) : (l.filter a).length≤(l.filter b).length := by
  induction l with
  | nil => simp
  | cons x xs ih =>
    by_cases h : a x=true
    · simp [List.filter_cons,h,inc _ h,ih]
    · have z : a x=false := Bool.eq_false_iff.mpr h
      cases e : b x <;> simp [List.filter_cons,z,e] <;> omega

theorem score_mono {n : ℕ} {E F : Rel n} (h : ∀ i j,E i j=true→F i j=true) (v : Label n) :
    score E v≤score F v := by
  unfold score
  apply length_filter_mono
  intro z hz
  simp only [Bool.and_eq_true] at hz ⊢
  exact ⟨⟨h _ _ hz.1.1,h _ _ hz.1.2⟩,h _ _ hz.2⟩

def Effective {n : ℕ} (lo hi : Rel n) (D : Finset (Label n)) : Prop :=
  ∀ v : Label n, v∉D →
    (∃ x y : Label n, x∈D ∧ y∈D ∧ x≠y ∧ lo v x=true ∧ lo v y=true) ∨
    (∀ w : Label n, w∉D → hi v w=false)

instance {n : ℕ} (lo hi : Rel n) (D : Finset (Label n)) : Decidable (Effective lo hi D) := by
  unfold Effective
  infer_instance

theorem effective_mono {n : ℕ} {lo hi E : Rel n} {D : Finset (Label n)}
    (L : ∀ i j,lo i j=true→E i j=true) (U : ∀ i j,E i j=true→hi i j=true)
    (h : Effective lo hi D) : Effective E E D := by
  intro v hv
  rcases h v hv with ⟨x,y,hx,hy,hn,ex,ey⟩|off
  · exact Or.inl ⟨x,y,hx,hy,hn,L _ _ ex,L _ _ ey⟩
  · exact Or.inr (fun w hw=>Bool.eq_false_iff.mpr (fun et=>by
      have et' := U _ _ et
      simp [off w hw] at et'))

def palette {n : ℕ} (E : Rel n) : Finset Nat := (univ.filter fun i=>0<score E i).image (score E)

structure Ranked {n : ℕ} (E : Rel n) (anchor : Fin 2 → Label n) : Prop where
  palette_large : 8≤(palette E).card
  large : ∀ r : Fin 2, 7≤score E (anchor r)
  top : ∀ (S : Finset (Label n)), (∀ v∈S,2≤v.val)→n-7≤S.card→∀ (j : Fin 2),
    ¬ (∀ v∈S,score E (anchor j)≤score E v)

def dropOK {n : ℕ} (lo hi : Rel n) (S : Finset (Label n)) (v : Label n) : Option (Label n)→Prop
  | none => score hi v=0
  | some w => w∉S ∧ score lo v=score hi v ∧ score lo w=score hi w ∧ score lo v=score lo w

instance {n : ℕ} (lo hi : Rel n) (S : Finset (Label n)) (v : Label n) (o : Option (Label n)) :
    Decidable (dropOK lo hi S v o) := by
  cases o <;> unfold dropOK <;> infer_instance

def band {n : ℕ} (lo hi : Rel n) (l u : Nat) : Finset (Label n) :=
  univ.filter fun i=>l≤score lo i ∧ score hi i<l+u

inductive Reason (n : ℕ)
  | small (r : Fin 2)
  | unordered (S : Finset (Label n)) (r : Fin 2)
  | drop (S : Finset (Label n)) (witness : Label n → Option (Label n))
  | cover (D : Finset (Label n))
  | interval (l u : Nat)

def validReason {n : ℕ} (anchor : Fin 2 → Label n) (lo hi : Rel n) : Reason n→Prop
  | .small r => score hi (anchor r)<7
  | .unordered S r => (∀ v∈S,2≤v.val) ∧ n-7≤S.card ∧
      ∀ v∈S, score hi (anchor r)≤score lo v
  | .drop S p => n-7≤S.card ∧ ∀ v∈S, dropOK lo hi S v (p v)
  | .cover D => D.card≤n-5 ∧ Effective lo hi D
  | .interval l u => u+(n-(band lo hi l u).card)<8

instance {n : ℕ} (anchor : Fin 2 → Label n) (lo hi : Rel n) (r : Reason n) :
    Decidable (validReason anchor lo hi r) := by
  cases r <;> unfold validReason <;> infer_instance

theorem reason_sound {n : ℕ} {anchor : Fin 2 → Label n} {lo hi E : Rel n}
    (H : Ranked E anchor)
    (L : ∀ i j,lo i j=true→E i j=true) (U : ∀ i j,E i j=true→hi i j=true)
    (r : Reason n) (valid : validReason anchor lo hi r) :
    ∃ D, D.card≤n-5 ∧ Effective E E D := by
  have low := score_mono L
  have high := score_mono U
  cases r with
  | small j =>
    have x := H.large j
    have y := high (anchor j)
    unfold validReason at valid
    omega
  | unordered S j =>
    obtain ⟨out,sz,ord⟩ := valid
    exact (H.top S out sz j (fun v hv=>(high _).trans ((ord v hv).trans (low _)))).elim
  | drop S p =>
    obtain ⟨sz,hp⟩ := valid
    have tr : ∀ v∈S, 0<score E v→∃ w∉S, score E w=score E v := by
      intro v hv pos
      have h := hp v hv
      cases z : p v with
      | none =>
        rw [z] at h
        have hu := high v
        unfold dropOK at h
        omega
      | some w =>
        rw [z] at h
        obtain ⟨nw,vv,ww,vw⟩ := h
        have h₁ := low v
        have h₂ := high v
        have h₃ := low w
        have h₄ := high w
        exact ⟨w,nw,by omega⟩
    have h := EffectivePalette.erase_redundant (score E) S tr
    simp only [Label,Fintype.card_fin] at h
    change (palette E).card≤n-S.card at h
    have := H.palette_large
    omega
  | cover D =>
    exact ⟨D,valid.1,effective_mono L U valid.2⟩
  | interval l u =>
    have h := EffectivePalette.interval_cap (score E) (band lo hi l u) l u (by
      intro v hv
      obtain ⟨hl,hu⟩ := (mem_filter.mp hv).2
      exact ⟨hl.trans (low v),lt_of_le_of_lt (high v) hu⟩)
    simp only [Label,Fintype.card_fin] at h
    change (palette E).card≤u+(n-(band lo hi l u).card) at h
    have cut : u+(n-(band lo hi l u).card)<8 := valid
    have := H.palette_large
    omega


inductive Tree (n : ℕ)
  | tip (r : Reason n)
  | split (i : Nat) (no yes : Tree n)

def treeOK {n : ℕ} (anchor : Fin 2→Label n)
    (model : (Nat→Bool)→Rel n) (on off : Nat) : Tree n→Bool
  | .tip r => decide (validReason anchor (model (fun j=>on.testBit j))
                                 (model (fun j=>!off.testBit j)) r)
  | .split i no yes =>
    treeOK anchor model on (off ||| 2^i) no && treeOK anchor model (on ||| 2^i) off yes

theorem tree_sound {n : ℕ} (anchor : Fin 2→Label n) (model : (Nat→Bool)→Rel n)
    (mono : ∀ (a b : Nat→Bool), (∀ j,a j=true→b j=true)→
      ∀ i j,model a i j=true→model b i j=true)
    (b : Nat→Bool) (H : Ranked (model b) anchor) (T : Tree n) (on off : Nat)
    (O : ∀ j,on.testBit j=true→b j=true)
    (Z : ∀ j,off.testBit j=true→b j=false)
    (valid : treeOK anchor model on off T=true) :
    ∃ D, D.card≤n-5 ∧ Effective (model b) (model b) D := by
  induction T generalizing on off with
  | tip r =>
    apply reason_sound H (mono _ _ O) (mono _ _ ?_) r (of_decide_eq_true valid)
    intro i bi
    change (!off.testBit i)=true
    cases e : off.testBit i
    · rfl
    · exact Bool.noConfusion (bi.symm.trans (Z i e))
  | split i no yes ihN ihY =>
    simp only [treeOK,Bool.and_eq_true] at valid
    obtain ⟨hn,hy⟩ := valid
    cases v : b i
    · apply ihN on (off|||2^i) O ?_ hn
      intro j h
      rw [Nat.testBit_or,Bool.or_eq_true,Nat.testBit_two_pow,decide_eq_true_eq] at h
      rcases h with h|rfl
      · exact Z j h
      · exact v
    · apply ihY (on|||2^i) off ?_ Z hy
      intro j h
      rw [Nat.testBit_or,Bool.or_eq_true,Nat.testBit_two_pow,decide_eq_true_eq] at h
      rcases h with h|rfl
      · exact O j h
      · exact v

theorem checked_tree {n : ℕ} (anchor : Fin 2→Label n) (model : (Nat→Bool)→Rel n)
    (mono : ∀ (a b : Nat→Bool), (∀ j,a j=true→b j=true)→
      ∀ i j,model a i j=true→model b i j=true)
    (b : Nat→Bool) (H : Ranked (model b) anchor) (T : Tree n)
    (valid : treeOK anchor model 0 0 T=true) :
    ∃ D, D.card≤n-5 ∧ Effective (model b) (model b) D :=
  tree_sound anchor model mono b H T 0 0 (by simp) (by simp) valid

#print axioms checked_tree

end Graffiti384b.EffectiveSearch
