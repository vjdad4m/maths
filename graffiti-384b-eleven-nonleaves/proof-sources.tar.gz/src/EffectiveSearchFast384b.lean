import EffectiveSearch384b

namespace Graffiti384b.EffectiveSearch
open Finset

def FastEffective {n : ℕ} (lo hi : Rel n) (D : Finset (Label n)) : Prop :=
  ∀ v : Label n,v∉D → 2 ≤ (D.filter fun w=>lo v w=true).card ∨
    (∀ w : Label n,w∉D → hi v w=false)

instance {n : ℕ} (lo hi : Rel n) (D : Finset (Label n)) : Decidable (FastEffective lo hi D) := by
  unfold FastEffective
  infer_instance

theorem fastEffective_sound {n : ℕ} {lo hi : Rel n} {D : Finset (Label n)}
    (h : FastEffective lo hi D) : Effective lo hi D := by
  intro v hv
  rcases h v hv with many|none
  · have two : 1 < (D.filter fun w=>lo v w=true).card := by omega
    obtain ⟨x,hx,y,hy,ne⟩ := Finset.one_lt_card.mp two
    obtain ⟨hx',ex⟩ := mem_filter.mp hx
    obtain ⟨hy',ey⟩ := mem_filter.mp hy
    exact Or.inl ⟨x,y,hx',hy',ne,ex,ey⟩
  · exact Or.inr none

def fastReason {n : ℕ} (anchor : Fin 2 → Label n) (lo hi : Rel n) : Reason n→Bool
  | .cover D => decide (D.card≤n-5 ∧ FastEffective lo hi D)
  | other => decide (validReason anchor lo hi other)

theorem fastReason_sound {n : ℕ} {anchor : Fin 2 → Label n} {lo hi : Rel n}
    (r : Reason n) (h : fastReason anchor lo hi r=true) : validReason anchor lo hi r := by
  cases r with
  | cover D =>
    obtain ⟨sz,cap⟩ : D.card≤n-5 ∧ FastEffective lo hi D := of_decide_eq_true h
    exact ⟨sz,fastEffective_sound cap⟩
  | small | unordered | drop | interval => exact of_decide_eq_true h

def fastTreeOK {n : ℕ} (anchor : Fin 2→Label n)
    (model : (Nat→Bool)→Rel n) (on off : Nat) : Tree n→Bool
  | .tip r => fastReason anchor (model (fun j=>on.testBit j))
                                 (model (fun j=>!off.testBit j)) r
  | .split i no yes =>
    fastTreeOK anchor model on (off ||| 2^i) no && fastTreeOK anchor model (on ||| 2^i) off yes

theorem fastTree_sound {n : ℕ} (anchor : Fin 2→Label n) (model : (Nat→Bool)→Rel n)
    (on off : Nat) (T : Tree n) (h : fastTreeOK anchor model on off T=true) :
    treeOK anchor model on off T=true := by
  induction T generalizing on off with
  | tip r => exact decide_eq_true (fastReason_sound r h)
  | split i N Y ihN ihY =>
    simp only [fastTreeOK,Bool.and_eq_true] at h
    simp only [treeOK,Bool.and_eq_true]
    exact ⟨ihN _ _ h.1,ihY _ _ h.2⟩

theorem checked_fast_tree {n : ℕ} (anchor : Fin 2→Label n) (model : (Nat→Bool)→Rel n)
    (mono : ∀ (a b : Nat→Bool), (∀ j,a j=true→b j=true)→
      ∀ i j,model a i j=true→model b i j=true)
    (b : Nat→Bool) (H : Ranked (model b) anchor) (T : Tree n)
    (valid : fastTreeOK anchor model 0 0 T=true) :
    ∃ D, D.card≤n-5 ∧ Effective (model b) (model b) D :=
  checked_tree anchor model mono b H T (fastTree_sound anchor model 0 0 T valid)

#print axioms checked_fast_tree
end Graffiti384b.EffectiveSearch
