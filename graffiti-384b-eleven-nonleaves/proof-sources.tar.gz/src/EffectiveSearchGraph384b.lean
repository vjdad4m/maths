import EffectiveSearchShape384b
import EffectiveSearchScore384b
import Q9Original384b

namespace Graffiti384b.EffectiveSearch
open SimpleGraph Finset
set_option linter.unusedSectionVars false

variable {n : ℕ} (G : SimpleGraph (Label n)) [DecidableRel G.Adj]

private theorem degree_triangle_bound {W : Type*} [Fintype W] [DecidableEq W] (J : SimpleGraph W)
    [DecidableRel J.Adj] (v : W) : trianglesAt J v≤(J.degree v).choose 2 := by
  unfold trianglesAt
  exact (card_filter_le _ _).trans_eq (by rw [card_powersetCard,card_neighborFinset_eq_degree])

def trianglePalette : Finset Nat :=
  (univ.filter fun v=>0<trianglesAt G v).image (trianglesAt G)

theorem model_palette
    (pair_nodup : (orderedPairs n).Nodup)
    (pair_iff : ∀ i j : Label n,(i,j)∈orderedPairs n↔i<j) (p : (Label n) ≃ (Label n)) (E : Rel n)
    (fits : ∀ i j,E i j=true↔G.Adj (p i) (p j)) :
    palette E = trianglePalette G := by
  ext q
  simp only [palette, trianglePalette, mem_image, mem_filter, mem_univ, true_and,
    score_eq_triangles G p E pair_nodup pair_iff fits]
  constructor
  · rintro ⟨v,hv,he⟩
    exact ⟨p v,hv,he⟩
  · rintro ⟨v,hv,he⟩
    obtain ⟨i,rfl⟩ := p.surjective v
    exact ⟨i,hv,he⟩

theorem top_two_values (hP : 8 ≤ (trianglePalette G).card) :
    ∃ x y : (Label n), trianglesAt G y < trianglesAt G x ∧ 7 ≤ trianglesAt G y ∧
      (∀ v, trianglesAt G v ≤ trianglesAt G x) ∧
      (∀ v, trianglesAt G v ≠ trianglesAt G x → trianglesAt G v ≤ trianglesAt G y) := by
  let P := trianglePalette G
  have hP0 : 0<P.card := by change 8≤P.card at hP; omega
  obtain ⟨X,Xm,MX⟩ := exists_max_image P id (card_pos.mp hP0)
  let Q := P.erase X
  have hQ : 7≤Q.card := by
    change 8≤P.card at hP
    simp only [Q, card_erase_of_mem Xm]
    omega
  obtain ⟨Y,Ym,MY⟩ := exists_max_image Q id (card_pos.mp (by omega))
  obtain ⟨YX,YP⟩ := mem_erase.mp Ym
  have YXlt : Y<X := lt_of_le_of_ne (MX _ YP) YX
  have rangeS : Q ⊆ (Finset.range (Y+1)).erase 0 := by
    intro z zQ
    have hm := MY _ zQ
    have zP := (mem_erase.mp zQ).2
    obtain ⟨v,vp,rfl⟩ := mem_image.mp zP
    exact mem_erase.mpr ⟨by have := (mem_filter.mp vp).2; omega,
      mem_range.mpr (by simpa using Nat.lt_succ_of_le hm)⟩
  have cr := card_le_card rangeS
  rw [Finset.card_erase_of_mem (show 0∈Finset.range (Y+1) by simp), card_range] at cr
  have Y7 : 7≤Y := by omega
  obtain ⟨x,xm,hx⟩ := mem_image.mp Xm
  obtain ⟨y,ym,hy⟩ := mem_image.mp YP
  refine ⟨x,y,by omega,by omega,?_,?_⟩
  · intro v
    by_cases vv : 0<trianglesAt G v
    · have h := MX _ (mem_image.mpr ⟨v,mem_filter.mpr ⟨mem_univ _,vv⟩,rfl⟩)
      change trianglesAt G v≤X at h
      omega
    · omega
  · intro v n
    by_cases vv : 0<trianglesAt G v
    · have h := MY _ (mem_erase.mpr ⟨by omega,
        mem_image.mpr ⟨v,mem_filter.mpr ⟨mem_univ _,vv⟩,rfl⟩⟩)
      change trianglesAt G v≤Y at h
      omega
    · omega

private theorem five_degree {v : (Label n)} (score : 7≤trianglesAt G v) : 5≤G.degree v := by
  have le := degree_triangle_bound G v
  by_contra low
  have d4 : G.degree v≤4 := Nat.lt_succ_iff.mp (Nat.lt_of_not_ge low)
  have r := Nat.choose_le_choose 2 d4
  have n4 : (4:Nat).choose 2=6 := by decide
  omega



theorem quota_from_normalized {h : 2≤n}
    (pair_nodup : (orderedPairs n).Nodup)
    (pair_iff : ∀ i j : Label n,(i,j)∈orderedPairs n↔i<j)
    (normalized : ∀ x y : Label n, x≠y → 5≤G.degree x → 5≤G.degree y →
      (G.neighborFinset x ∩ G.neighborFinset y).card≤4 →
      ∃ (p : Label n ≃ Label n) (E : Rel n),
        ((p (root h 0)=x ∧ p (root h 1)=y) ∨
          (p (root h 0)=y ∧ p (root h 1)=x)) ∧
        (∀ i j,E i j=true↔G.Adj (p i) (p j)) ∧
        (Ranked E (root h) → ∃ D : Finset (Label n), D.card≤n-5 ∧ Effective E E D))
    (diverse : 8≤(trianglePalette G).card) :
    ∃ D : Finset (Label n),D.card≤n-5 ∧ Q9Original.Effective G D := by
  obtain ⟨x,y,ord,yl,mx,my⟩ := top_two_values G diverse
  have xy : x≠y := fun eq=>by rw [eq] at ord; omega
  have xl : 7≤trianglesAt G x := le_trans yl ord.le
  by_cases large : 5≤(G.neighborFinset x∩G.neighborFinset y).card
  · obtain ⟨S,sub,sz⟩ := exists_subset_card_eq large
    have count : Sᶜ.card=n-5 := by rw [card_compl,sz,Fintype.card_fin]
    refine ⟨Sᶜ,count.le,?_⟩
    intro z zo
    have zin : z∈S := by simpa using zo
    have edges := mem_inter.mp (sub zin)
    have xa := (G.mem_neighborFinset _ _).mp edges.1
    have ya := (G.mem_neighborFinset _ _).mp edges.2
    have xo : x∈Sᶜ := mem_compl.mpr (fun xs=>G.loopless x
      ((G.mem_neighborFinset _ _).mp (mem_inter.mp (sub xs)).1))
    have yo : y∈Sᶜ := mem_compl.mpr (fun ys=>G.loopless y
      ((G.mem_neighborFinset _ _).mp (mem_inter.mp (sub ys)).2))
    exact Or.inl ⟨x,y,xo,yo,xy,xa.symm,ya.symm⟩
  obtain ⟨p,E,roots,fit,covers⟩ := normalized x y xy
    (five_degree G xl) (five_degree G yl) (by omega)
  have ex := score_eq_triangles G p E pair_nodup pair_iff fit
  have pa := model_palette G pair_nodup pair_iff p E fit
  have atAnchor (r : Fin 2) : p (root h r)=x ∨ p (root h r)=y := by
    fin_cases r
    · exact roots.imp And.left And.left
    · exact roots.symm.imp And.right And.right
  have rank : Ranked E (root h) := by
    refine ⟨by rwa [pa],?_,?_⟩
    · intro r
      rw [ex]
      rcases atAnchor r with hr|hr
      · rwa [hr]
      · rwa [hr]
    · intro S out sz r hh
      have notRoot (j : Fin 2) : root h j∉S := by
        intro mem
        have bad := out _ mem
        change 2≤j.val at bad
        have lim := j.isLt
        omega
      have valClass (i : Label n) (hi : trianglesAt G y≤score E i) :
          trianglesAt G (p i)=trianglesAt G x ∨ trianglesAt G (p i)=trianglesAt G y := by
        by_cases m : trianglesAt G (p i)=trianglesAt G x
        · exact Or.inl m
        · exact Or.inr (by have := my _ m; rw [ex] at hi; omega)
      have R (i : Label n) (im : i∈S) : ∃ a, a∉S ∧ score E a=score E i := by
        have lo : trianglesAt G y≤score E i := by
          apply le_trans _ (hh _ im)
          rw [ex]
          rcases atAnchor r with hx|hy
          · simpa [hx] using ord.le
          · simp [hy]
        have atOriginal : ∃ j : Fin 2, trianglesAt G (p (root h j))=trianglesAt G (p i) := by
          rcases valClass i lo with a|b <;> rcases roots with ⟨hx,hy⟩|⟨hy,hx⟩
          · exact ⟨0,by simpa only [a] using congrArg (trianglesAt G) hx⟩
          · exact ⟨1,by simpa only [a] using congrArg (trianglesAt G) hx⟩
          · exact ⟨1,by simpa only [b] using congrArg (trianglesAt G) hy⟩
          · exact ⟨0,by simpa only [b] using congrArg (trianglesAt G) hy⟩
        obtain ⟨j,jj⟩ := atOriginal
        exact ⟨root h j,notRoot j,by simpa only [ex] using jj⟩
      have contra := EffectivePalette.erase_redundant (score E) S (fun i im _=>R i im)
      simp only [Label,Fintype.card_fin] at contra
      change (palette E).card≤n-S.card at contra
      rw [pa] at contra
      omega
  obtain ⟨D,sz,witness⟩ := covers rank
  let T := D.map p.toEmbedding
  have count : T.card≤n-5 := by simpa [T] using sz
  refine ⟨T,count,?_⟩
  have mem (u : Label n) : p u∈T↔u∈D := by simp [T]
  intro u hu
  obtain ⟨v,rfl⟩ := p.surjective u
  rcases witness v (fun hv=>hu ((mem v).2 hv)) with ⟨i,j,ii,jj,ij,vi,vj⟩|off
  · exact Or.inl ⟨p i,p j,(mem i).2 ii,(mem j).2 jj,
      fun e=>ij (p.injective e),(fit _ _).1 vi,(fit _ _).1 vj⟩
  · right
    intro w hw vw
    obtain ⟨j,rfl⟩ := p.surjective w
    have f := off j (fun hj=>hw ((mem j).2 hj))
    exact Bool.noConfusion (((fit _ _).2 vw).symm.trans f)

theorem trianglePalette_eq_positiveScores :
    trianglePalette G = Q9Original.PositiveScores G := by
  ext t
  simp only [trianglePalette,Q9Original.PositiveScores,types,mem_erase,mem_image,mem_filter,
    mem_univ,true_and]
  constructor
  · rintro ⟨i,hi,rfl⟩
    exact ⟨Nat.ne_of_gt hi,i,rfl⟩
  · rintro ⟨ht,i,rfl⟩
    exact ⟨i,Nat.pos_of_ne_zero ht,rfl⟩

#print axioms quota_from_normalized
end Graffiti384b.EffectiveSearch
