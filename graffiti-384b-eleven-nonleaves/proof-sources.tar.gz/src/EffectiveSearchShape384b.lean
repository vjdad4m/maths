import EffectiveSearch384b

namespace Graffiti384b.EffectiveSearch
structure Shape where
  edge01 : Bool
  d0 : ℕ
  d1 : ℕ
  common : ℕ

def slot (n i j : Nat) : Nat := ((i-2)*(2*n-3-i))/2 + (j-i-1)

def anchorZero (s : Shape) (r : Nat) : Bool :=
  decide (r<s.d0-(if s.edge01 then 1 else 0))

def anchorOne (s : Shape) (r : Nat) : Bool :=
  let a := s.d0-(if s.edge01 then 1 else 0)
  let b := s.d1-(if s.edge01 then 1 else 0)
  decide (r<s.common ∨ (a≤r ∧ r<a+b-s.common))

def adj (n : ℕ) (s : Shape) (b : Nat→Bool) (u v : Label n) : Bool :=
  let i := min u.val v.val
  let j := max u.val v.val
  if i=j then false else
  if i=0 then if j=1 then s.edge01 else anchorZero s (j-2)
  else if i=1 then anchorOne s (j-2)
  else b (slot n i j)

theorem adj_mono {n : ℕ} {s : Shape} (a b : Nat→Bool)
    (h : ∀ j,a j=true→b j=true) (i j : Label n) :
    adj n s a i j=true→adj n s b i j=true := by
  dsimp [adj]
  split <;> (try exact id)
  split <;> (try exact id)
  split
  · exact id
  · exact h _


def root {n : ℕ} (h : 2≤n) (r : Fin 2) : Label n := ⟨r.val,r.isLt.trans_le h⟩

#print axioms adj_mono

end Graffiti384b.EffectiveSearch
