import Q9Original384b

namespace Graffiti384b.GenericEffective
open Finset SimpleGraph Q9Original
open private Prune.outside_zero from Prune384b
open private Q8Original.triangle_comap from Q8Original384b

/-- Lift the effective-retention certificate for a core of order `n` to its
ambient graph. The finite checker sees only the core, including how many
distinct positive scores it must exhibit. -/
theorem nonleaf_of_finite_effective
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (n threshold : ℕ) (order : (nonleaves G).card = n)
    (diverse : threshold+1 ≤ (types G).card)
    (quota : ∀ (K : SimpleGraph (Fin n)) (dk : DecidableRel K.Adj),
      letI := dk
      (types G).card ≤ (PositiveScores K).card+1 →
      threshold ≤ (PositiveScores K).card →
        ∃ D : Finset (Fin n), ((types G).card+1)/2 ≤ n-D.card ∧ Effective K D) :
    gamma G ≤ bound G := by
  classical
  let P := nonleaves G
  let H := G.induce (P : Set V)
  let e : Fin n ≃ P := (Fintype.equivFinOfCardEq ((Fintype.card_coe P).trans order)).symm
  let K := H.comap (e : Fin n→P)
  let dk : DecidableRel K.Adj := inferInstanceAs (DecidableRel (H.comap (e : Fin n→P)).Adj)
  let f : Fin n ↪ V := e.toEmbedding.trans (Function.Embedding.subtype _)
  have finP (i : Fin n) : f i ∈ P := (e i).property
  have allP (v : V) (hv : v∈P) : ∃ j, f j=v := by
    exact ⟨e.symm ⟨v,hv⟩,congrArg Subtype.val (e.apply_symm_apply ⟨v,hv⟩)⟩
  have score (i : Fin n) : trianglesAt K i = trianglesAt G (f i) :=
    (Q8Original.triangle_comap H e i).trans (Prune.counts_preserved G P Subset.rfl (e i))
  have cover : types G ⊆ insert 0 (PositiveScores K) := by
    intro s hs
    obtain ⟨v,_,rfl⟩ := mem_image.mp hs
    by_cases z : trianglesAt G v = 0
    · rw [z]; exact mem_insert_self _ _
    have vp : v∈P := Classical.byContradiction fun no =>
      z (Prune.outside_zero G no)
    obtain ⟨i,hi⟩ := allP v vp
    have t : trianglesAt K i = trianglesAt G v := (score i).trans (congrArg (trianglesAt G) hi)
    apply mem_insert_of_mem
    exact mem_erase.mpr ⟨z,mem_image.mpr ⟨i,mem_univ _,t⟩⟩
  have cc := card_le_card cover
  have inc := card_insert_le 0 (PositiveScores K)
  obtain ⟨D,dcard,eff⟩ := quota K dk (by omega) (by omega)
  let O := Dᶜ.map f
  have ocard : ((types G).card+1)/2 ≤ O.card := by
    have eqn := card_compl D
    rw [Fintype.card_fin] at eqn
    change ((types G).card+1)/2 ≤ (Dᶜ.map f).card
    rw [card_map,eqn]
    omega
  have sub : O ⊆ P := by
    intro v hv
    obtain ⟨i,_,rfl⟩ := mem_map.mp hv
    exact finP i
  have ambient_eff (v : V) (vo : v∈O) : 2 ≤ EffectiveSupport.capacity G P O v := by
    obtain ⟨i,hi,rfl⟩ := mem_map.mp vo
    have noD := mem_compl.mp hi
    rcases eff i noD with ⟨x,y,hx,hy,hxy,hix,hiy⟩ | none
    · have retain (j : Fin n) (hj : j∈D) : f j∈P\O := by
        refine mem_sdiff.mpr ⟨finP j,?_⟩
        intro hm
        obtain ⟨k,km,eq⟩ := mem_map.mp hm
        exact mem_compl.mp km ((f.injective eq).symm ▸ hj)
      have card : 1 < ((P\O).filter (G.Adj (f i))).card :=
        one_lt_card.mpr ⟨f x,mem_filter.mpr ⟨retain x hx,hix⟩,
          f y,mem_filter.mpr ⟨retain y hy,hiy⟩,fun eq => hxy (f.injective eq)⟩
      unfold EffectiveSupport.capacity nbr
      omega
    · have zero : nbr G (f i) O = 0 := by
        unfold nbr
        rw [card_eq_zero]
        apply subset_empty.mp
        intro w hw
        obtain ⟨ho,ad⟩ := mem_filter.mp hw
        obtain ⟨j,hj,rfl⟩ := mem_map.mp ho
        exact False.elim (none j (mem_compl.mp hj) ad)
      have crit := EffectiveSupport.capacity_failure G P O sub (f i)
      omega
  have nonleaf (v : V) (vo : v∈O) : 2 ≤ G.degree v := (mem_filter.mp (sub vo)).2
  have g := EffectiveSupport.gamma_le_from_effective G P O sub nonleaf ambient_eff
  unfold bound
  omega

end Graffiti384b.GenericEffective

#print axioms Graffiti384b.GenericEffective.nonleaf_of_finite_effective
