import Q11GeometryBridge384b
import GenericEffective384b

namespace Graffiti384b.EffectiveSearch.Q11
open SimpleGraph Finset

/-- At diversity nine, any checked finite cover on this board gives five
omissions in arbitrary ambient graphs with the same nonleaf order. -/
theorem exact_of_nine_types_from_covers
    (covers : ∀ (s : Fin 46) (bits : Nat→Bool),
      Ranked (adj 11 (forms s) bits) (root (by decide)) →
        ∃ D : Finset (Label 11), D.card≤6 ∧
          Effective (adj 11 (forms s) bits) (adj 11 (forms s) bits) D)
    {X : Type*} [Fintype X] [DecidableEq X] (G : SimpleGraph X) [DecidableRel G.Adj]
    (order : (nonleaves G).card = 11) (diverse : (types G).card=9) :
    gamma G ≤ bound G := by
  apply GenericEffective.nonleaf_of_finite_effective G 11 8 order (by omega)
  intro K dk
  letI := dk
  intro _ pos
  obtain ⟨D,bd,eff⟩ := quota_from_covers K covers pos
  exact ⟨D,by omega,eff⟩

#print axioms exact_of_nine_types_from_covers
end Graffiti384b.EffectiveSearch.Q11
