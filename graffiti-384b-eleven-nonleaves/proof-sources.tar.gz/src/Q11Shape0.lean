import Q11Shape0Part0
import Q11Shape0Part1
import Q11Shape0Part2
import Q11Shape0Part3
import Q11Shape0Part4
import Q11Shape0Part5
import Q11Shape0Part6

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0M79 : Tree 11 := .split 10 q11Shape0P1 q11Shape0P2
private theorem q11Shape0M79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 256 q11Shape0M79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 (256 ||| 2^10) q11Shape0P1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (512 ||| 2^10) 256 q11Shape0P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0P1OK,q11Shape0P2OK⟩
private def q11Shape0M80 : Tree 11 := .split 9 q11Shape0P0 q11Shape0M79
private theorem q11Shape0M80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 256 q11Shape0M80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 (256 ||| 2^9) q11Shape0P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (0 ||| 2^9) 256 q11Shape0M79)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0P0OK,q11Shape0M79OK⟩
private def q11Shape0M133 : Tree 11 := .split 10 q11Shape0P3 q11Shape0P4
private theorem q11Shape0M133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 512 q11Shape0M133=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 (512 ||| 2^10) q11Shape0P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (256 ||| 2^10) 512 q11Shape0P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0P3OK,q11Shape0P4OK⟩
private def q11Shape0M180 : Tree 11 := .split 10 q11Shape0P5 q11Shape0P6
private theorem q11Shape0M180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 0 q11Shape0M180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 (0 ||| 2^10) q11Shape0P5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (768 ||| 2^10) 0 q11Shape0P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0P5OK,q11Shape0P6OK⟩
private def q11Shape0M181 : Tree 11 := .split 9 q11Shape0M133 q11Shape0M180
private theorem q11Shape0M181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 0 q11Shape0M181=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 (0 ||| 2^9) q11Shape0M133 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (256 ||| 2^9) 0 q11Shape0M180)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0M133OK,q11Shape0M180OK⟩
private def q11Shape0M182 : Tree 11 := .split 8 q11Shape0M80 q11Shape0M181
private theorem q11Shape0M182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 0 q11Shape0M182=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 (0 ||| 2^8) q11Shape0M80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (0 ||| 2^8) 0 q11Shape0M181)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0M80OK,q11Shape0M181OK⟩

theorem q11Shape0_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 0) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 0) b) (adj 11 (forms 0) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) adj_mono b H q11Shape0M182 q11Shape0M182OK

#print axioms q11Shape0_cover

end Graffiti384b.EffectiveSearch.Q11
