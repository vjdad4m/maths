import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0T2 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 34560 q11Shape0T2=true := by decide

private def q11Shape0T4 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 32768 67328 q11Shape0T4=true := by decide

private def q11Shape0T6 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98304 2098944 q11Shape0T6=true := by decide

private def q11Shape0T9 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2195456 3221227264 q11Shape0T9=true := by decide

private def q11Shape0T10 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149679104 1073743616 q11Shape0T10=true := by decide

private def q11Shape0T8 : Tree 11 := .split 31 q11Shape0T9 q11Shape0T10
private theorem q11Shape0T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2195456 1073743616 q11Shape0T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2195456 (1073743616 ||| 2^31) q11Shape0T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2195456 ||| 2^31) 1073743616 q11Shape0T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T9OK,q11Shape0T10OK⟩

private def q11Shape0T11 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075937280 1792 q11Shape0T11=true := by decide

private def q11Shape0T7 : Tree 11 := .split 30 q11Shape0T8 q11Shape0T11
private theorem q11Shape0T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2195456 1792 q11Shape0T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2195456 (1792 ||| 2^30) q11Shape0T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2195456 ||| 2^30) 1792 q11Shape0T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T8OK,q11Shape0T11OK⟩

private def q11Shape0T5 : Tree 11 := .split 21 q11Shape0T6 q11Shape0T7
private theorem q11Shape0T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98304 1792 q11Shape0T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98304 (1792 ||| 2^21) q11Shape0T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (98304 ||| 2^21) 1792 q11Shape0T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T6OK,q11Shape0T7OK⟩

private def q11Shape0T3 : Tree 11 := .split 16 q11Shape0T4 q11Shape0T5
private theorem q11Shape0T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 32768 1792 q11Shape0T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 32768 (1792 ||| 2^16) q11Shape0T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (32768 ||| 2^16) 1792 q11Shape0T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T4OK,q11Shape0T5OK⟩

private def q11Shape0T1 : Tree 11 := .split 15 q11Shape0T2 q11Shape0T3
private theorem q11Shape0T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 1792 q11Shape0T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 (1792 ||| 2^15) q11Shape0T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (0 ||| 2^15) 1792 q11Shape0T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T2OK,q11Shape0T3OK⟩

private def q11Shape0T13 : Tree 11 := (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))))
private theorem q11Shape0T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1024 33536 q11Shape0T13=true := by decide

private def q11Shape0T16 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33792 2163456 q11Shape0T16=true := by decide

private def q11Shape0T19 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130944 3221291776 q11Shape0T19=true := by decide

private def q11Shape0T20 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149614592 1073808128 q11Shape0T20=true := by decide

private def q11Shape0T18 : Tree 11 := .split 31 q11Shape0T19 q11Shape0T20
private theorem q11Shape0T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130944 1073808128 q11Shape0T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130944 (1073808128 ||| 2^31) q11Shape0T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2130944 ||| 2^31) 1073808128 q11Shape0T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T19OK,q11Shape0T20OK⟩

private def q11Shape0T21 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075872768 66304 q11Shape0T21=true := by decide

private def q11Shape0T17 : Tree 11 := .split 30 q11Shape0T18 q11Shape0T21
private theorem q11Shape0T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130944 66304 q11Shape0T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130944 (66304 ||| 2^30) q11Shape0T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2130944 ||| 2^30) 66304 q11Shape0T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T18OK,q11Shape0T21OK⟩

private def q11Shape0T15 : Tree 11 := .split 21 q11Shape0T16 q11Shape0T17
private theorem q11Shape0T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33792 66304 q11Shape0T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33792 (66304 ||| 2^21) q11Shape0T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33792 ||| 2^21) 66304 q11Shape0T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T16OK,q11Shape0T17OK⟩

private def q11Shape0T25 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99328 3223323392 q11Shape0T25=true := by decide

private def q11Shape0T26 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147582976 1075839744 q11Shape0T26=true := by decide

private def q11Shape0T24 : Tree 11 := .split 31 q11Shape0T25 q11Shape0T26
private theorem q11Shape0T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99328 1075839744 q11Shape0T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99328 (1075839744 ||| 2^31) q11Shape0T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99328 ||| 2^31) 1075839744 q11Shape0T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T25OK,q11Shape0T26OK⟩

private def q11Shape0T27 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073841152 2097920 q11Shape0T27=true := by decide

private def q11Shape0T23 : Tree 11 := .split 30 q11Shape0T24 q11Shape0T27
private theorem q11Shape0T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99328 2097920 q11Shape0T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99328 (2097920 ||| 2^30) q11Shape0T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99328 ||| 2^30) 2097920 q11Shape0T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T24OK,q11Shape0T27OK⟩

private def q11Shape0T28 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape0T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2196480 768 q11Shape0T28=true := by decide

private def q11Shape0T22 : Tree 11 := .split 21 q11Shape0T23 q11Shape0T28
private theorem q11Shape0T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99328 768 q11Shape0T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99328 (768 ||| 2^21) q11Shape0T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99328 ||| 2^21) 768 q11Shape0T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T23OK,q11Shape0T28OK⟩

private def q11Shape0T14 : Tree 11 := .split 16 q11Shape0T15 q11Shape0T22
private theorem q11Shape0T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33792 768 q11Shape0T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33792 (768 ||| 2^16) q11Shape0T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33792 ||| 2^16) 768 q11Shape0T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T15OK,q11Shape0T22OK⟩

private def q11Shape0T12 : Tree 11 := .split 15 q11Shape0T13 q11Shape0T14
private theorem q11Shape0T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1024 768 q11Shape0T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1024 (768 ||| 2^15) q11Shape0T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1024 ||| 2^15) 768 q11Shape0T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T13OK,q11Shape0T14OK⟩

private def q11Shape0T0 : Tree 11 := .split 10 q11Shape0T1 q11Shape0T12
private theorem q11Shape0T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 768 q11Shape0T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 (768 ||| 2^10) q11Shape0T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (0 ||| 2^10) 768 q11Shape0T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T1OK,q11Shape0T12OK⟩

def q11Shape0P0 : Tree 11 := q11Shape0T0
theorem q11Shape0P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 0 768 q11Shape0P0=true := q11Shape0T0OK

end Graffiti384b.EffectiveSearch.Q11
