import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0T31 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 99584 q11Shape0T31=true := by decide

private def q11Shape0T33 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66048 2131200 q11Shape0T33=true := by decide

private def q11Shape0T36 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163200 3221259520 q11Shape0T36=true := by decide

private def q11Shape0T37 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149646848 1073775872 q11Shape0T37=true := by decide

private def q11Shape0T35 : Tree 11 := .split 31 q11Shape0T36 q11Shape0T37
private theorem q11Shape0T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163200 1073775872 q11Shape0T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163200 (1073775872 ||| 2^31) q11Shape0T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2163200 ||| 2^31) 1073775872 q11Shape0T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T36OK,q11Shape0T37OK⟩

private def q11Shape0T38 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075905024 34048 q11Shape0T38=true := by decide

private def q11Shape0T34 : Tree 11 := .split 30 q11Shape0T35 q11Shape0T38
private theorem q11Shape0T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163200 34048 q11Shape0T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163200 (34048 ||| 2^30) q11Shape0T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2163200 ||| 2^30) 34048 q11Shape0T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T35OK,q11Shape0T38OK⟩

private def q11Shape0T32 : Tree 11 := .split 21 q11Shape0T33 q11Shape0T34
private theorem q11Shape0T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66048 34048 q11Shape0T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66048 (34048 ||| 2^21) q11Shape0T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (66048 ||| 2^21) 34048 q11Shape0T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T33OK,q11Shape0T34OK⟩

private def q11Shape0T30 : Tree 11 := .split 16 q11Shape0T31 q11Shape0T32
private theorem q11Shape0T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 34048 q11Shape0T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 (34048 ||| 2^16) q11Shape0T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (512 ||| 2^16) 34048 q11Shape0T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T31OK,q11Shape0T32OK⟩

private def q11Shape0T40 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape0T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33280 66816 q11Shape0T40=true := by decide

private def q11Shape0T44 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98816 3223323904 q11Shape0T44=true := by decide

private def q11Shape0T45 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147582464 1075840256 q11Shape0T45=true := by decide

private def q11Shape0T43 : Tree 11 := .split 31 q11Shape0T44 q11Shape0T45
private theorem q11Shape0T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98816 1075840256 q11Shape0T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98816 (1075840256 ||| 2^31) q11Shape0T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (98816 ||| 2^31) 1075840256 q11Shape0T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T44OK,q11Shape0T45OK⟩

private def q11Shape0T46 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073840640 2098432 q11Shape0T46=true := by decide

private def q11Shape0T42 : Tree 11 := .split 30 q11Shape0T43 q11Shape0T46
private theorem q11Shape0T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98816 2098432 q11Shape0T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98816 (2098432 ||| 2^30) q11Shape0T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (98816 ||| 2^30) 2098432 q11Shape0T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T43OK,q11Shape0T46OK⟩

private def q11Shape0T47 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape0T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2195968 1280 q11Shape0T47=true := by decide

private def q11Shape0T41 : Tree 11 := .split 21 q11Shape0T42 q11Shape0T47
private theorem q11Shape0T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98816 1280 q11Shape0T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98816 (1280 ||| 2^21) q11Shape0T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (98816 ||| 2^21) 1280 q11Shape0T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T42OK,q11Shape0T47OK⟩

private def q11Shape0T39 : Tree 11 := .split 16 q11Shape0T40 q11Shape0T41
private theorem q11Shape0T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33280 1280 q11Shape0T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33280 (1280 ||| 2^16) q11Shape0T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33280 ||| 2^16) 1280 q11Shape0T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T40OK,q11Shape0T41OK⟩

private def q11Shape0T29 : Tree 11 := .split 15 q11Shape0T30 q11Shape0T39
private theorem q11Shape0T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 1280 q11Shape0T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 (1280 ||| 2^15) q11Shape0T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (512 ||| 2^15) 1280 q11Shape0T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T30OK,q11Shape0T39OK⟩

def q11Shape0P1 : Tree 11 := q11Shape0T29
theorem q11Shape0P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 512 1280 q11Shape0P1=true := q11Shape0T29OK

end Graffiti384b.EffectiveSearch.Q11
