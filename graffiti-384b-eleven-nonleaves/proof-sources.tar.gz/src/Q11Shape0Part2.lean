import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0T51 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 2195712 q11Shape0T51=true := by decide

private def q11Shape0T54 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098688 3221324032 q11Shape0T54=true := by decide

private def q11Shape0T55 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149582336 1073840384 q11Shape0T55=true := by decide

private def q11Shape0T53 : Tree 11 := .split 31 q11Shape0T54 q11Shape0T55
private theorem q11Shape0T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098688 1073840384 q11Shape0T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098688 (1073840384 ||| 2^31) q11Shape0T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2098688 ||| 2^31) 1073840384 q11Shape0T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T54OK,q11Shape0T55OK⟩

private def q11Shape0T56 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075840512 98560 q11Shape0T56=true := by decide

private def q11Shape0T52 : Tree 11 := .split 30 q11Shape0T53 q11Shape0T56
private theorem q11Shape0T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098688 98560 q11Shape0T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098688 (98560 ||| 2^30) q11Shape0T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2098688 ||| 2^30) 98560 q11Shape0T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T53OK,q11Shape0T56OK⟩

private def q11Shape0T50 : Tree 11 := .split 21 q11Shape0T51 q11Shape0T52
private theorem q11Shape0T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 98560 q11Shape0T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 (98560 ||| 2^21) q11Shape0T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1536 ||| 2^21) 98560 q11Shape0T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T51OK,q11Shape0T52OK⟩

private def q11Shape0T60 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67072 3223355648 q11Shape0T60=true := by decide

private def q11Shape0T61 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147550720 1075872000 q11Shape0T61=true := by decide

private def q11Shape0T59 : Tree 11 := .split 31 q11Shape0T60 q11Shape0T61
private theorem q11Shape0T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67072 1075872000 q11Shape0T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67072 (1075872000 ||| 2^31) q11Shape0T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (67072 ||| 2^31) 1075872000 q11Shape0T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T60OK,q11Shape0T61OK⟩

private def q11Shape0T62 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073808896 2130176 q11Shape0T62=true := by decide

private def q11Shape0T58 : Tree 11 := .split 30 q11Shape0T59 q11Shape0T62
private theorem q11Shape0T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67072 2130176 q11Shape0T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67072 (2130176 ||| 2^30) q11Shape0T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (67072 ||| 2^30) 2130176 q11Shape0T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T59OK,q11Shape0T62OK⟩

private def q11Shape0T63 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape0T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2164224 33024 q11Shape0T63=true := by decide

private def q11Shape0T57 : Tree 11 := .split 21 q11Shape0T58 q11Shape0T63
private theorem q11Shape0T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67072 33024 q11Shape0T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67072 (33024 ||| 2^21) q11Shape0T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (67072 ||| 2^21) 33024 q11Shape0T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T58OK,q11Shape0T63OK⟩

private def q11Shape0T49 : Tree 11 := .split 16 q11Shape0T50 q11Shape0T57
private theorem q11Shape0T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 33024 q11Shape0T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 (33024 ||| 2^16) q11Shape0T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1536 ||| 2^16) 33024 q11Shape0T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T50OK,q11Shape0T57OK⟩

private def q11Shape0T68 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 3223388416 q11Shape0T68=true := by decide

private def q11Shape0T69 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147517952 1075904768 q11Shape0T69=true := by decide

private def q11Shape0T67 : Tree 11 := .split 31 q11Shape0T68 q11Shape0T69
private theorem q11Shape0T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 1075904768 q11Shape0T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 (1075904768 ||| 2^31) q11Shape0T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34304 ||| 2^31) 1075904768 q11Shape0T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T68OK,q11Shape0T69OK⟩

private def q11Shape0T70 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073776128 2162944 q11Shape0T70=true := by decide

private def q11Shape0T66 : Tree 11 := .split 30 q11Shape0T67 q11Shape0T70
private theorem q11Shape0T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 2162944 q11Shape0T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 (2162944 ||| 2^30) q11Shape0T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34304 ||| 2^30) 2162944 q11Shape0T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T67OK,q11Shape0T70OK⟩

private def q11Shape0T71 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape0T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2131456 65792 q11Shape0T71=true := by decide

private def q11Shape0T65 : Tree 11 := .split 21 q11Shape0T66 q11Shape0T71
private theorem q11Shape0T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 65792 q11Shape0T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 (65792 ||| 2^21) q11Shape0T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34304 ||| 2^21) 65792 q11Shape0T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T66OK,q11Shape0T71OK⟩

private def q11Shape0T75 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,4,7,9,10})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99840 3223322880 q11Shape0T75=true := by decide

private def q11Shape0T76 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,8,9,10})))
private theorem q11Shape0T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147583488 1075839232 q11Shape0T76=true := by decide

private def q11Shape0T74 : Tree 11 := .split 31 q11Shape0T75 q11Shape0T76
private theorem q11Shape0T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99840 1075839232 q11Shape0T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99840 (1075839232 ||| 2^31) q11Shape0T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99840 ||| 2^31) 1075839232 q11Shape0T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T75OK,q11Shape0T76OK⟩

private def q11Shape0T77 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,4,7,9,10}))) (.tip (.cover {2,3,4,7,9,10}))) (.tip (.cover {2,3,4,8,9,10}))) (.tip (.cover {2,3,4,8,9,10})))
private theorem q11Shape0T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073841664 2097408 q11Shape0T77=true := by decide

private def q11Shape0T73 : Tree 11 := .split 30 q11Shape0T74 q11Shape0T77
private theorem q11Shape0T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99840 2097408 q11Shape0T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99840 (2097408 ||| 2^30) q11Shape0T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99840 ||| 2^30) 2097408 q11Shape0T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T74OK,q11Shape0T77OK⟩

private def q11Shape0T78 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape0T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2196992 256 q11Shape0T78=true := by decide

private def q11Shape0T72 : Tree 11 := .split 21 q11Shape0T73 q11Shape0T78
private theorem q11Shape0T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99840 256 q11Shape0T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99840 (256 ||| 2^21) q11Shape0T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99840 ||| 2^21) 256 q11Shape0T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T73OK,q11Shape0T78OK⟩

private def q11Shape0T64 : Tree 11 := .split 16 q11Shape0T65 q11Shape0T72
private theorem q11Shape0T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 256 q11Shape0T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34304 (256 ||| 2^16) q11Shape0T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34304 ||| 2^16) 256 q11Shape0T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T65OK,q11Shape0T72OK⟩

private def q11Shape0T48 : Tree 11 := .split 15 q11Shape0T49 q11Shape0T64
private theorem q11Shape0T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 256 q11Shape0T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 (256 ||| 2^15) q11Shape0T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1536 ||| 2^15) 256 q11Shape0T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T49OK,q11Shape0T64OK⟩

def q11Shape0P2 : Tree 11 := q11Shape0T48
theorem q11Shape0P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1536 256 q11Shape0P2=true := q11Shape0T48OK

end Graffiti384b.EffectiveSearch.Q11
