import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0T83 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 99840 q11Shape0T83=true := by decide

private def q11Shape0T85 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 65792 2131456 q11Shape0T85=true := by decide

private def q11Shape0T88 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape0T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2162944 3221259776 q11Shape0T88=true := by decide

private def q11Shape0T89 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape0T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149646592 1073776128 q11Shape0T89=true := by decide

private def q11Shape0T87 : Tree 11 := .split 31 q11Shape0T88 q11Shape0T89
private theorem q11Shape0T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2162944 1073776128 q11Shape0T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2162944 (1073776128 ||| 2^31) q11Shape0T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2162944 ||| 2^31) 1073776128 q11Shape0T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T88OK,q11Shape0T89OK⟩

private def q11Shape0T90 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape0T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075904768 34304 q11Shape0T90=true := by decide

private def q11Shape0T86 : Tree 11 := .split 30 q11Shape0T87 q11Shape0T90
private theorem q11Shape0T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2162944 34304 q11Shape0T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2162944 (34304 ||| 2^30) q11Shape0T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2162944 ||| 2^30) 34304 q11Shape0T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T87OK,q11Shape0T90OK⟩

private def q11Shape0T84 : Tree 11 := .split 21 q11Shape0T85 q11Shape0T86
private theorem q11Shape0T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 65792 34304 q11Shape0T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 65792 (34304 ||| 2^21) q11Shape0T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (65792 ||| 2^21) 34304 q11Shape0T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T85OK,q11Shape0T86OK⟩

private def q11Shape0T82 : Tree 11 := .split 16 q11Shape0T83 q11Shape0T84
private theorem q11Shape0T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 34304 q11Shape0T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 (34304 ||| 2^16) q11Shape0T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (256 ||| 2^16) 34304 q11Shape0T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T83OK,q11Shape0T84OK⟩

private def q11Shape0T93 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33024 2164224 q11Shape0T93=true := by decide

private def q11Shape0T96 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape0T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130176 3221292544 q11Shape0T96=true := by decide

private def q11Shape0T97 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape0T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149613824 1073808896 q11Shape0T97=true := by decide

private def q11Shape0T95 : Tree 11 := .split 31 q11Shape0T96 q11Shape0T97
private theorem q11Shape0T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130176 1073808896 q11Shape0T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130176 (1073808896 ||| 2^31) q11Shape0T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2130176 ||| 2^31) 1073808896 q11Shape0T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T96OK,q11Shape0T97OK⟩

private def q11Shape0T98 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape0T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075872000 67072 q11Shape0T98=true := by decide

private def q11Shape0T94 : Tree 11 := .split 30 q11Shape0T95 q11Shape0T98
private theorem q11Shape0T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130176 67072 q11Shape0T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130176 (67072 ||| 2^30) q11Shape0T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2130176 ||| 2^30) 67072 q11Shape0T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T95OK,q11Shape0T98OK⟩

private def q11Shape0T92 : Tree 11 := .split 21 q11Shape0T93 q11Shape0T94
private theorem q11Shape0T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33024 67072 q11Shape0T92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33024 (67072 ||| 2^21) q11Shape0T93 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33024 ||| 2^21) 67072 q11Shape0T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T93OK,q11Shape0T94OK⟩

private def q11Shape0T100 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape0T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98560 2098688 q11Shape0T100=true := by decide

private def q11Shape0T101 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape0T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2195712 1536 q11Shape0T101=true := by decide

private def q11Shape0T99 : Tree 11 := .split 21 q11Shape0T100 q11Shape0T101
private theorem q11Shape0T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98560 1536 q11Shape0T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 98560 (1536 ||| 2^21) q11Shape0T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (98560 ||| 2^21) 1536 q11Shape0T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T100OK,q11Shape0T101OK⟩

private def q11Shape0T91 : Tree 11 := .split 16 q11Shape0T92 q11Shape0T99
private theorem q11Shape0T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33024 1536 q11Shape0T91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33024 (1536 ||| 2^16) q11Shape0T92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33024 ||| 2^16) 1536 q11Shape0T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T92OK,q11Shape0T99OK⟩

private def q11Shape0T81 : Tree 11 := .split 15 q11Shape0T82 q11Shape0T91
private theorem q11Shape0T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 1536 q11Shape0T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 (1536 ||| 2^15) q11Shape0T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (256 ||| 2^15) 1536 q11Shape0T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T82OK,q11Shape0T91OK⟩

def q11Shape0P3 : Tree 11 := q11Shape0T81
theorem q11Shape0P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 256 1536 q11Shape0P3=true := q11Shape0T81OK

end Graffiti384b.EffectiveSearch.Q11
