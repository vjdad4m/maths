import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0T105 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 2195968 q11Shape0T105=true := by decide

private def q11Shape0T108 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape0T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098432 3221324288 q11Shape0T108=true := by decide

private def q11Shape0T109 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape0T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149582080 1073840640 q11Shape0T109=true := by decide

private def q11Shape0T107 : Tree 11 := .split 31 q11Shape0T108 q11Shape0T109
private theorem q11Shape0T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098432 1073840640 q11Shape0T107=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098432 (1073840640 ||| 2^31) q11Shape0T108 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2098432 ||| 2^31) 1073840640 q11Shape0T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T108OK,q11Shape0T109OK⟩

private def q11Shape0T110 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape0T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075840256 98816 q11Shape0T110=true := by decide

private def q11Shape0T106 : Tree 11 := .split 30 q11Shape0T107 q11Shape0T110
private theorem q11Shape0T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098432 98816 q11Shape0T106=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098432 (98816 ||| 2^30) q11Shape0T107 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2098432 ||| 2^30) 98816 q11Shape0T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T107OK,q11Shape0T110OK⟩

private def q11Shape0T104 : Tree 11 := .split 21 q11Shape0T105 q11Shape0T106
private theorem q11Shape0T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 98816 q11Shape0T104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 (98816 ||| 2^21) q11Shape0T105 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1280 ||| 2^21) 98816 q11Shape0T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T105OK,q11Shape0T106OK⟩

private def q11Shape0T114 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape0T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66816 3223355904 q11Shape0T114=true := by decide

private def q11Shape0T115 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape0T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147550464 1075872256 q11Shape0T115=true := by decide

private def q11Shape0T113 : Tree 11 := .split 31 q11Shape0T114 q11Shape0T115
private theorem q11Shape0T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66816 1075872256 q11Shape0T113=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66816 (1075872256 ||| 2^31) q11Shape0T114 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (66816 ||| 2^31) 1075872256 q11Shape0T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T114OK,q11Shape0T115OK⟩

private def q11Shape0T116 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape0T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073808640 2130432 q11Shape0T116=true := by decide

private def q11Shape0T112 : Tree 11 := .split 30 q11Shape0T113 q11Shape0T116
private theorem q11Shape0T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66816 2130432 q11Shape0T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66816 (2130432 ||| 2^30) q11Shape0T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (66816 ||| 2^30) 2130432 q11Shape0T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T113OK,q11Shape0T116OK⟩

private def q11Shape0T117 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape0T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163968 33280 q11Shape0T117=true := by decide

private def q11Shape0T111 : Tree 11 := .split 21 q11Shape0T112 q11Shape0T117
private theorem q11Shape0T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66816 33280 q11Shape0T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66816 (33280 ||| 2^21) q11Shape0T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (66816 ||| 2^21) 33280 q11Shape0T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T112OK,q11Shape0T117OK⟩

private def q11Shape0T103 : Tree 11 := .split 16 q11Shape0T104 q11Shape0T111
private theorem q11Shape0T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 33280 q11Shape0T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 (33280 ||| 2^16) q11Shape0T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1280 ||| 2^16) 33280 q11Shape0T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T104OK,q11Shape0T111OK⟩

private def q11Shape0T122 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 3223388672 q11Shape0T122=true := by decide

private def q11Shape0T123 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147517696 1075905024 q11Shape0T123=true := by decide

private def q11Shape0T121 : Tree 11 := .split 31 q11Shape0T122 q11Shape0T123
private theorem q11Shape0T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 1075905024 q11Shape0T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 (1075905024 ||| 2^31) q11Shape0T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34048 ||| 2^31) 1075905024 q11Shape0T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T122OK,q11Shape0T123OK⟩

private def q11Shape0T124 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073775872 2163200 q11Shape0T124=true := by decide

private def q11Shape0T120 : Tree 11 := .split 30 q11Shape0T121 q11Shape0T124
private theorem q11Shape0T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 2163200 q11Shape0T120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 (2163200 ||| 2^30) q11Shape0T121 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34048 ||| 2^30) 2163200 q11Shape0T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T121OK,q11Shape0T124OK⟩

private def q11Shape0T127 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,5,7,9,10})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2131200 3221291520 q11Shape0T127=true := by decide

private def q11Shape0T128 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {2,3,5,7,8,10}))) (.tip (.cover {2,3,5,8,9,10})))
private theorem q11Shape0T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149614848 1073807872 q11Shape0T128=true := by decide

private def q11Shape0T126 : Tree 11 := .split 31 q11Shape0T127 q11Shape0T128
private theorem q11Shape0T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2131200 1073807872 q11Shape0T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2131200 (1073807872 ||| 2^31) q11Shape0T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2131200 ||| 2^31) 1073807872 q11Shape0T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T127OK,q11Shape0T128OK⟩

private def q11Shape0T129 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,5,7,9,10}))) (.tip (.cover {2,3,5,7,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10})))
private theorem q11Shape0T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075873024 66048 q11Shape0T129=true := by decide

private def q11Shape0T125 : Tree 11 := .split 30 q11Shape0T126 q11Shape0T129
private theorem q11Shape0T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2131200 66048 q11Shape0T125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2131200 (66048 ||| 2^30) q11Shape0T126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2131200 ||| 2^30) 66048 q11Shape0T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T126OK,q11Shape0T129OK⟩

private def q11Shape0T119 : Tree 11 := .split 21 q11Shape0T120 q11Shape0T125
private theorem q11Shape0T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 66048 q11Shape0T119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 (66048 ||| 2^21) q11Shape0T120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34048 ||| 2^21) 66048 q11Shape0T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T120OK,q11Shape0T125OK⟩

private def q11Shape0T131 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape0T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99584 2097664 q11Shape0T131=true := by decide

private def q11Shape0T132 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape0T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2196736 512 q11Shape0T132=true := by decide

private def q11Shape0T130 : Tree 11 := .split 21 q11Shape0T131 q11Shape0T132
private theorem q11Shape0T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99584 512 q11Shape0T130=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99584 (512 ||| 2^21) q11Shape0T131 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99584 ||| 2^21) 512 q11Shape0T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T131OK,q11Shape0T132OK⟩

private def q11Shape0T118 : Tree 11 := .split 16 q11Shape0T119 q11Shape0T130
private theorem q11Shape0T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 512 q11Shape0T118=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34048 (512 ||| 2^16) q11Shape0T119 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34048 ||| 2^16) 512 q11Shape0T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T119OK,q11Shape0T130OK⟩

private def q11Shape0T102 : Tree 11 := .split 15 q11Shape0T103 q11Shape0T118
private theorem q11Shape0T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 512 q11Shape0T102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 (512 ||| 2^15) q11Shape0T103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1280 ||| 2^15) 512 q11Shape0T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T103OK,q11Shape0T118OK⟩

def q11Shape0P4 : Tree 11 := q11Shape0T102
theorem q11Shape0P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1280 512 q11Shape0P4=true := q11Shape0T102OK

end Graffiti384b.EffectiveSearch.Q11
