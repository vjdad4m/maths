import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0T137 : Tree 11 := (.tip (.small 0))
private theorem q11Shape0T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 2196480 q11Shape0T137=true := by decide

private def q11Shape0T140 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape0T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2097920 3221324800 q11Shape0T140=true := by decide

private def q11Shape0T141 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape0T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149581568 1073841152 q11Shape0T141=true := by decide

private def q11Shape0T139 : Tree 11 := .split 31 q11Shape0T140 q11Shape0T141
private theorem q11Shape0T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2097920 1073841152 q11Shape0T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2097920 (1073841152 ||| 2^31) q11Shape0T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2097920 ||| 2^31) 1073841152 q11Shape0T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T140OK,q11Shape0T141OK⟩

private def q11Shape0T142 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape0T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075839744 99328 q11Shape0T142=true := by decide

private def q11Shape0T138 : Tree 11 := .split 30 q11Shape0T139 q11Shape0T142
private theorem q11Shape0T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2097920 99328 q11Shape0T138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2097920 (99328 ||| 2^30) q11Shape0T139 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2097920 ||| 2^30) 99328 q11Shape0T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T139OK,q11Shape0T142OK⟩

private def q11Shape0T136 : Tree 11 := .split 21 q11Shape0T137 q11Shape0T138
private theorem q11Shape0T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 99328 q11Shape0T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 (99328 ||| 2^21) q11Shape0T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (768 ||| 2^21) 99328 q11Shape0T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T137OK,q11Shape0T138OK⟩

private def q11Shape0T146 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66304 3223356416 q11Shape0T146=true := by decide

private def q11Shape0T147 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape0T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147549952 1075872768 q11Shape0T147=true := by decide

private def q11Shape0T145 : Tree 11 := .split 31 q11Shape0T146 q11Shape0T147
private theorem q11Shape0T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66304 1075872768 q11Shape0T145=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66304 (1075872768 ||| 2^31) q11Shape0T146 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (66304 ||| 2^31) 1075872768 q11Shape0T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T146OK,q11Shape0T147OK⟩

private def q11Shape0T148 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape0T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073808128 2130944 q11Shape0T148=true := by decide

private def q11Shape0T144 : Tree 11 := .split 30 q11Shape0T145 q11Shape0T148
private theorem q11Shape0T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66304 2130944 q11Shape0T144=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66304 (2130944 ||| 2^30) q11Shape0T145 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (66304 ||| 2^30) 2130944 q11Shape0T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T145OK,q11Shape0T148OK⟩

private def q11Shape0T151 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,6,7,9,10})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape0T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163456 3221259264 q11Shape0T151=true := by decide

private def q11Shape0T152 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape0T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2149647104 1073775616 q11Shape0T152=true := by decide

private def q11Shape0T150 : Tree 11 := .split 31 q11Shape0T151 q11Shape0T152
private theorem q11Shape0T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163456 1073775616 q11Shape0T150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163456 (1073775616 ||| 2^31) q11Shape0T151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2163456 ||| 2^31) 1073775616 q11Shape0T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T151OK,q11Shape0T152OK⟩

private def q11Shape0T153 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape0T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1075905280 33792 q11Shape0T153=true := by decide

private def q11Shape0T149 : Tree 11 := .split 30 q11Shape0T150 q11Shape0T153
private theorem q11Shape0T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163456 33792 q11Shape0T149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2163456 (33792 ||| 2^30) q11Shape0T150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (2163456 ||| 2^30) 33792 q11Shape0T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T150OK,q11Shape0T153OK⟩

private def q11Shape0T143 : Tree 11 := .split 21 q11Shape0T144 q11Shape0T149
private theorem q11Shape0T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66304 33792 q11Shape0T143=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 66304 (33792 ||| 2^21) q11Shape0T144 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (66304 ||| 2^21) 33792 q11Shape0T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T144OK,q11Shape0T149OK⟩

private def q11Shape0T135 : Tree 11 := .split 16 q11Shape0T136 q11Shape0T143
private theorem q11Shape0T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 33792 q11Shape0T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 (33792 ||| 2^16) q11Shape0T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (768 ||| 2^16) 33792 q11Shape0T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T136OK,q11Shape0T143OK⟩

private def q11Shape0T158 : Tree 11 := (.split 32 (.split 33 (.tip (.small 1)) (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,8})))) (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,1,3,6,7,8}))))
private theorem q11Shape0T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 3223389184 q11Shape0T158=true := by decide

private def q11Shape0T159 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,8}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,1,3,6,7,8})))
private theorem q11Shape0T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2147517184 1075905536 q11Shape0T159=true := by decide

private def q11Shape0T157 : Tree 11 := .split 31 q11Shape0T158 q11Shape0T159
private theorem q11Shape0T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 1075905536 q11Shape0T157=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 (1075905536 ||| 2^31) q11Shape0T158 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33536 ||| 2^31) 1075905536 q11Shape0T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T158OK,q11Shape0T159OK⟩

private def q11Shape0T160 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9}))) (.tip (.cover {0,1,3,6,8,10}))) (.tip (.cover {0,1,3,6,7,9}))) (.tip (.cover {0,1,3,6,7,10})))
private theorem q11Shape0T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1073775360 2163712 q11Shape0T160=true := by decide

private def q11Shape0T156 : Tree 11 := .split 30 q11Shape0T157 q11Shape0T160
private theorem q11Shape0T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 2163712 q11Shape0T156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 (2163712 ||| 2^30) q11Shape0T157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33536 ||| 2^30) 2163712 q11Shape0T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T157OK,q11Shape0T160OK⟩

private def q11Shape0T161 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape0T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2130688 66560 q11Shape0T161=true := by decide

private def q11Shape0T155 : Tree 11 := .split 21 q11Shape0T156 q11Shape0T161
private theorem q11Shape0T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 66560 q11Shape0T155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 (66560 ||| 2^21) q11Shape0T156 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33536 ||| 2^21) 66560 q11Shape0T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T156OK,q11Shape0T161OK⟩

private def q11Shape0T163 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape0T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99072 2098176 q11Shape0T163=true := by decide

private def q11Shape0T164 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape0T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2196224 1024 q11Shape0T164=true := by decide

private def q11Shape0T162 : Tree 11 := .split 21 q11Shape0T163 q11Shape0T164
private theorem q11Shape0T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99072 1024 q11Shape0T162=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 99072 (1024 ||| 2^21) q11Shape0T163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (99072 ||| 2^21) 1024 q11Shape0T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T163OK,q11Shape0T164OK⟩

private def q11Shape0T154 : Tree 11 := .split 16 q11Shape0T155 q11Shape0T162
private theorem q11Shape0T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 1024 q11Shape0T154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 33536 (1024 ||| 2^16) q11Shape0T155 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (33536 ||| 2^16) 1024 q11Shape0T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T155OK,q11Shape0T162OK⟩

private def q11Shape0T134 : Tree 11 := .split 15 q11Shape0T135 q11Shape0T154
private theorem q11Shape0T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 1024 q11Shape0T134=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 (1024 ||| 2^15) q11Shape0T135 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (768 ||| 2^15) 1024 q11Shape0T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T135OK,q11Shape0T154OK⟩

def q11Shape0P5 : Tree 11 := q11Shape0T134
theorem q11Shape0P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 768 1024 q11Shape0P5=true := q11Shape0T134OK

end Graffiti384b.EffectiveSearch.Q11
