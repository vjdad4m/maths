import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape0T168 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 2195456 q11Shape0T168=true := by decide

private def q11Shape0T169 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2098944 98304 q11Shape0T169=true := by decide

private def q11Shape0T167 : Tree 11 := .split 21 q11Shape0T168 q11Shape0T169
private theorem q11Shape0T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 98304 q11Shape0T167=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 (98304 ||| 2^21) q11Shape0T168 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1792 ||| 2^21) 98304 q11Shape0T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T168OK,q11Shape0T169OK⟩

private def q11Shape0T171 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67328 2129920 q11Shape0T171=true := by decide

private def q11Shape0T172 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2164480 32768 q11Shape0T172=true := by decide

private def q11Shape0T170 : Tree 11 := .split 21 q11Shape0T171 q11Shape0T172
private theorem q11Shape0T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67328 32768 q11Shape0T170=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 67328 (32768 ||| 2^21) q11Shape0T171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (67328 ||| 2^21) 32768 q11Shape0T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T171OK,q11Shape0T172OK⟩

private def q11Shape0T166 : Tree 11 := .split 16 q11Shape0T167 q11Shape0T170
private theorem q11Shape0T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 32768 q11Shape0T166=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 (32768 ||| 2^16) q11Shape0T167 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1792 ||| 2^16) 32768 q11Shape0T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T167OK,q11Shape0T170OK⟩

private def q11Shape0T175 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34560 2162688 q11Shape0T175=true := by decide

private def q11Shape0T176 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2131712 65536 q11Shape0T176=true := by decide

private def q11Shape0T174 : Tree 11 := .split 21 q11Shape0T175 q11Shape0T176
private theorem q11Shape0T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34560 65536 q11Shape0T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34560 (65536 ||| 2^21) q11Shape0T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34560 ||| 2^21) 65536 q11Shape0T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T175OK,q11Shape0T176OK⟩

private def q11Shape0T178 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 100096 2097152 q11Shape0T178=true := by decide

private def q11Shape0T179 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape0T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 2197248 0 q11Shape0T179=true := by decide

private def q11Shape0T177 : Tree 11 := .split 21 q11Shape0T178 q11Shape0T179
private theorem q11Shape0T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 100096 0 q11Shape0T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 100096 (0 ||| 2^21) q11Shape0T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (100096 ||| 2^21) 0 q11Shape0T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T178OK,q11Shape0T179OK⟩

private def q11Shape0T173 : Tree 11 := .split 16 q11Shape0T174 q11Shape0T177
private theorem q11Shape0T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34560 0 q11Shape0T173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 34560 (0 ||| 2^16) q11Shape0T174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (34560 ||| 2^16) 0 q11Shape0T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T174OK,q11Shape0T177OK⟩

private def q11Shape0T165 : Tree 11 := .split 15 q11Shape0T166 q11Shape0T173
private theorem q11Shape0T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 0 q11Shape0T165=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 (0 ||| 2^15) q11Shape0T166 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) (1792 ||| 2^15) 0 q11Shape0T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape0T166OK,q11Shape0T173OK⟩

def q11Shape0P6 : Tree 11 := q11Shape0T165
theorem q11Shape0P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,1⟩) 1792 0 q11Shape0P6=true := q11Shape0T165OK

end Graffiti384b.EffectiveSearch.Q11
