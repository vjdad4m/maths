import Q11Shape1Part0
import Q11Shape1Part1
import Q11Shape1Part2
import Q11Shape1Part3
import Q11Shape1Part4
import Q11Shape1Part5

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape1M50 : Tree 11 := .split 21 q11Shape1P0 q11Shape1P1
private theorem q11Shape1M50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 98304 q11Shape1M50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 (98304 ||| 2^21) q11Shape1P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (0 ||| 2^21) 98304 q11Shape1P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1P0OK,q11Shape1P1OK⟩
private def q11Shape1M107 : Tree 11 := .split 21 q11Shape1P2 q11Shape1P3
private theorem q11Shape1M107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 32768 q11Shape1M107=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 (32768 ||| 2^21) q11Shape1P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (65536 ||| 2^21) 32768 q11Shape1P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1P2OK,q11Shape1P3OK⟩
private def q11Shape1M108 : Tree 11 := .split 16 q11Shape1M50 q11Shape1M107
private theorem q11Shape1M108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 32768 q11Shape1M108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 (32768 ||| 2^16) q11Shape1M50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (0 ||| 2^16) 32768 q11Shape1M107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1M50OK,q11Shape1M107OK⟩
private def q11Shape1M163 : Tree 11 := .split 21 q11Shape1P4 q11Shape1P5
private theorem q11Shape1M163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 65536 q11Shape1M163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 (65536 ||| 2^21) q11Shape1P4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32768 ||| 2^21) 65536 q11Shape1P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1P4OK,q11Shape1P5OK⟩
private def q11Shape1M199 : Tree 11 := .split 16 q11Shape1M163 q11Shape1P6
private theorem q11Shape1M199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 0 q11Shape1M199=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 (0 ||| 2^16) q11Shape1M163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32768 ||| 2^16) 0 q11Shape1P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1M163OK,q11Shape1P6OK⟩
private def q11Shape1M200 : Tree 11 := .split 15 q11Shape1M108 q11Shape1M199
private theorem q11Shape1M200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 0 q11Shape1M200=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 (0 ||| 2^15) q11Shape1M108 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (0 ||| 2^15) 0 q11Shape1M199)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1M108OK,q11Shape1M199OK⟩

theorem q11Shape1_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 1) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 1) b) (adj 11 (forms 1) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) adj_mono b H q11Shape1M200 q11Shape1M200OK

#print axioms q11Shape1_cover

end Graffiti384b.EffectiveSearch.Q11
