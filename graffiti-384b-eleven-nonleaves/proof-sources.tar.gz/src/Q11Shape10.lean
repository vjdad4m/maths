import Q11Shape10Part0
import Q11Shape10Part1
import Q11Shape10Part2
import Q11Shape10Part3
import Q11Shape10Part4

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape10M32 : Tree 11 := .split 1 q11Shape10P0 q11Shape10P1
private theorem q11Shape10M32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 1275068417 q11Shape10M32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 (1275068417 ||| 2^1) q11Shape10P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (0 ||| 2^1) 1275068417 q11Shape10P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10P0OK,q11Shape10P1OK⟩
private def q11Shape10M90 : Tree 11 := .split 2 q11Shape10P3 q11Shape10P4
private theorem q11Shape10M90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 1275068416 q11Shape10M90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 (1275068416 ||| 2^2) q11Shape10P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (3 ||| 2^2) 1275068416 q11Shape10P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10P3OK,q11Shape10P4OK⟩
private def q11Shape10M91 : Tree 11 := .split 1 q11Shape10P2 q11Shape10M90
private theorem q11Shape10M91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 1275068416 q11Shape10M91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 (1275068416 ||| 2^1) q11Shape10P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (1 ||| 2^1) 1275068416 q11Shape10M90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10P2OK,q11Shape10M90OK⟩
private def q11Shape10M92 : Tree 11 := .split 0 q11Shape10M32 q11Shape10M91
private theorem q11Shape10M92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 1275068416 q11Shape10M92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 (1275068416 ||| 2^0) q11Shape10M32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (0 ||| 2^0) 1275068416 q11Shape10M91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10M32OK,q11Shape10M91OK⟩
private def q11Shape10M94 : Tree 11 := .split 30 q11Shape10M92 q11Shape10P5
private theorem q11Shape10M94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 201326592 q11Shape10M94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 (201326592 ||| 2^30) q11Shape10M92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (0 ||| 2^30) 201326592 q11Shape10P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10M92OK,q11Shape10P5OK⟩
private def q11Shape10M96 : Tree 11 := .split 27 q11Shape10M94 q11Shape10P6
private theorem q11Shape10M96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 67108864 q11Shape10M96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 (67108864 ||| 2^27) q11Shape10M94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (0 ||| 2^27) 67108864 q11Shape10P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10M94OK,q11Shape10P6OK⟩
private def q11Shape10M98 : Tree 11 := .split 26 q11Shape10M96 q11Shape10P7
private theorem q11Shape10M98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 0 q11Shape10M98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 (0 ||| 2^26) q11Shape10M96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (0 ||| 2^26) 0 q11Shape10P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10M96OK,q11Shape10P7OK⟩

theorem q11Shape10_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 10) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 10) b) (adj 11 (forms 10) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) adj_mono b H q11Shape10M98 q11Shape10M98OK

#print axioms q11Shape10_cover

end Graffiti384b.EffectiveSearch.Q11
