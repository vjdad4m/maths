import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape10T1 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.unordered {3,4,5,9} 1)))))))))
private theorem q11Shape10T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 1275068423 q11Shape10T1=true := by decide

private def q11Shape10T3 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))))))
private theorem q11Shape10T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 4 1275068675 q11Shape10T3=true := by decide

private def q11Shape10T5 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape10T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 260 1275068931 q11Shape10T5=true := by decide

private def q11Shape10T7 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape10T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 772 1275101187 q11Shape10T7=true := by decide

private def q11Shape10T8 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))) (.split 19 (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))) (.tip (.cover {1,5,6,7,8,10})))))
private theorem q11Shape10T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33540 1275068419 q11Shape10T8=true := by decide

private def q11Shape10T6 : Tree 11 := .split 15 q11Shape10T7 q11Shape10T8
private theorem q11Shape10T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 772 1275068419 q11Shape10T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 772 (1275068419 ||| 2^15) q11Shape10T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (772 ||| 2^15) 1275068419 q11Shape10T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T7OK,q11Shape10T8OK⟩

private def q11Shape10T4 : Tree 11 := .split 9 q11Shape10T5 q11Shape10T6
private theorem q11Shape10T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 260 1275068419 q11Shape10T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 260 (1275068419 ||| 2^9) q11Shape10T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (260 ||| 2^9) 1275068419 q11Shape10T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T5OK,q11Shape10T6OK⟩

private def q11Shape10T2 : Tree 11 := .split 8 q11Shape10T3 q11Shape10T4
private theorem q11Shape10T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 4 1275068419 q11Shape10T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 4 (1275068419 ||| 2^8) q11Shape10T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (4 ||| 2^8) 1275068419 q11Shape10T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T3OK,q11Shape10T4OK⟩

private def q11Shape10T0 : Tree 11 := .split 2 q11Shape10T1 q11Shape10T2
private theorem q11Shape10T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 1275068419 q11Shape10T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 (1275068419 ||| 2^2) q11Shape10T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (0 ||| 2^2) 1275068419 q11Shape10T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T1OK,q11Shape10T2OK⟩

def q11Shape10P0 : Tree 11 := q11Shape10T0
theorem q11Shape10P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 0 1275068419 q11Shape10P0=true := q11Shape10T0OK

end Graffiti384b.EffectiveSearch.Q11
