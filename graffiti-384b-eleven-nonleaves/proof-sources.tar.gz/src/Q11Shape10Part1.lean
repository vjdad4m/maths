import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape10T11 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))))
private theorem q11Shape10T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 2 1275068677 q11Shape10T11=true := by decide

private def q11Shape10T13 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10})))))
private theorem q11Shape10T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 258 1275068933 q11Shape10T13=true := by decide

private def q11Shape10T15 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape10T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 770 1275101189 q11Shape10T15=true := by decide

private def q11Shape10T16 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10}))) (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10})))) (.tip (.cover {1,4,6,7,8,10}))))
private theorem q11Shape10T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33538 1275068421 q11Shape10T16=true := by decide

private def q11Shape10T14 : Tree 11 := .split 15 q11Shape10T15 q11Shape10T16
private theorem q11Shape10T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 770 1275068421 q11Shape10T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 770 (1275068421 ||| 2^15) q11Shape10T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (770 ||| 2^15) 1275068421 q11Shape10T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T15OK,q11Shape10T16OK⟩

private def q11Shape10T12 : Tree 11 := .split 9 q11Shape10T13 q11Shape10T14
private theorem q11Shape10T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 258 1275068421 q11Shape10T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 258 (1275068421 ||| 2^9) q11Shape10T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (258 ||| 2^9) 1275068421 q11Shape10T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T13OK,q11Shape10T14OK⟩

private def q11Shape10T10 : Tree 11 := .split 8 q11Shape10T11 q11Shape10T12
private theorem q11Shape10T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 2 1275068421 q11Shape10T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 2 (1275068421 ||| 2^8) q11Shape10T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (2 ||| 2^8) 1275068421 q11Shape10T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T11OK,q11Shape10T12OK⟩

private def q11Shape10T19 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.unordered {2,4,5,9} 1)))))))
private theorem q11Shape10T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 6 1275069185 q11Shape10T19=true := by decide

private def q11Shape10T21 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape10T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 518 1275101441 q11Shape10T21=true := by decide

private def q11Shape10T22 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))) (.split 19 (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))) (.tip (.cover {1,5,6,7,8,10})))))
private theorem q11Shape10T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33286 1275068673 q11Shape10T22=true := by decide

private def q11Shape10T20 : Tree 11 := .split 15 q11Shape10T21 q11Shape10T22
private theorem q11Shape10T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 518 1275068673 q11Shape10T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 518 (1275068673 ||| 2^15) q11Shape10T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (518 ||| 2^15) 1275068673 q11Shape10T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T21OK,q11Shape10T22OK⟩

private def q11Shape10T18 : Tree 11 := .split 9 q11Shape10T19 q11Shape10T20
private theorem q11Shape10T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 6 1275068673 q11Shape10T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 6 (1275068673 ||| 2^9) q11Shape10T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (6 ||| 2^9) 1275068673 q11Shape10T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T19OK,q11Shape10T20OK⟩

private def q11Shape10T25 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape10T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 262 1275101697 q11Shape10T25=true := by decide

private def q11Shape10T26 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10}))) (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10})))) (.tip (.cover {1,4,6,7,8,10}))))
private theorem q11Shape10T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33030 1275068929 q11Shape10T26=true := by decide

private def q11Shape10T24 : Tree 11 := .split 15 q11Shape10T25 q11Shape10T26
private theorem q11Shape10T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 262 1275068929 q11Shape10T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 262 (1275068929 ||| 2^15) q11Shape10T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (262 ||| 2^15) 1275068929 q11Shape10T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T25OK,q11Shape10T26OK⟩

private def q11Shape10T29 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10}))))
private theorem q11Shape10T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 774 1275109377 q11Shape10T29=true := by decide

private def q11Shape10T30 : Tree 11 := (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10})))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {4,5,6,7,8,10}))))
private theorem q11Shape10T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 8966 1275101185 q11Shape10T30=true := by decide

private def q11Shape10T28 : Tree 11 := .split 13 q11Shape10T29 q11Shape10T30
private theorem q11Shape10T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 774 1275101185 q11Shape10T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 774 (1275101185 ||| 2^13) q11Shape10T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (774 ||| 2^13) 1275101185 q11Shape10T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T29OK,q11Shape10T30OK⟩

private def q11Shape10T31 : Tree 11 := (.split 13 (.split 19 (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.tip (.cover {1,4,6,7,8,10}))) (.split 19 (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {1,5,6,7,8,10}))) (.tip (.cover {1,4,6,7,8,10}))))
private theorem q11Shape10T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33542 1275068417 q11Shape10T31=true := by decide

private def q11Shape10T27 : Tree 11 := .split 15 q11Shape10T28 q11Shape10T31
private theorem q11Shape10T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 774 1275068417 q11Shape10T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 774 (1275068417 ||| 2^15) q11Shape10T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (774 ||| 2^15) 1275068417 q11Shape10T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T28OK,q11Shape10T31OK⟩

private def q11Shape10T23 : Tree 11 := .split 9 q11Shape10T24 q11Shape10T27
private theorem q11Shape10T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 262 1275068417 q11Shape10T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 262 (1275068417 ||| 2^9) q11Shape10T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (262 ||| 2^9) 1275068417 q11Shape10T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T24OK,q11Shape10T27OK⟩

private def q11Shape10T17 : Tree 11 := .split 8 q11Shape10T18 q11Shape10T23
private theorem q11Shape10T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 6 1275068417 q11Shape10T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 6 (1275068417 ||| 2^8) q11Shape10T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (6 ||| 2^8) 1275068417 q11Shape10T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T18OK,q11Shape10T23OK⟩

private def q11Shape10T9 : Tree 11 := .split 2 q11Shape10T10 q11Shape10T17
private theorem q11Shape10T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 2 1275068417 q11Shape10T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 2 (1275068417 ||| 2^2) q11Shape10T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (2 ||| 2^2) 1275068417 q11Shape10T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T10OK,q11Shape10T17OK⟩

def q11Shape10P1 : Tree 11 := q11Shape10T9
theorem q11Shape10P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 2 1275068417 q11Shape10P1=true := q11Shape10T9OK

end Graffiti384b.EffectiveSearch.Q11
