import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape10T35 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))))
private theorem q11Shape10T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 1275068678 q11Shape10T35=true := by decide

private def q11Shape10T37 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape10T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 257 1275068934 q11Shape10T37=true := by decide

private def q11Shape10T38 : Tree 11 := (.split 15 (.split 13 (.tip (.small 1)) (.tip (.cover {1,3,6,7,8,10}))) (.split 13 (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10}))))) (.tip (.cover {1,3,6,7,8,10}))))
private theorem q11Shape10T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 769 1275068422 q11Shape10T38=true := by decide

private def q11Shape10T36 : Tree 11 := .split 9 q11Shape10T37 q11Shape10T38
private theorem q11Shape10T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 257 1275068422 q11Shape10T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 257 (1275068422 ||| 2^9) q11Shape10T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (257 ||| 2^9) 1275068422 q11Shape10T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T37OK,q11Shape10T38OK⟩

private def q11Shape10T34 : Tree 11 := .split 8 q11Shape10T35 q11Shape10T36
private theorem q11Shape10T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 1275068422 q11Shape10T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 (1275068422 ||| 2^8) q11Shape10T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (1 ||| 2^8) 1275068422 q11Shape10T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T35OK,q11Shape10T36OK⟩

private def q11Shape10T41 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape10T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 5 1275069186 q11Shape10T41=true := by decide

private def q11Shape10T43 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.unordered {2,3,5,9} 1))))))
private theorem q11Shape10T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 517 1275101442 q11Shape10T43=true := by decide

private def q11Shape10T44 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))) (.split 19 (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))) (.tip (.cover {1,5,6,7,8,10})))))
private theorem q11Shape10T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33285 1275068674 q11Shape10T44=true := by decide

private def q11Shape10T42 : Tree 11 := .split 15 q11Shape10T43 q11Shape10T44
private theorem q11Shape10T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 517 1275068674 q11Shape10T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 517 (1275068674 ||| 2^15) q11Shape10T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (517 ||| 2^15) 1275068674 q11Shape10T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T43OK,q11Shape10T44OK⟩

private def q11Shape10T40 : Tree 11 := .split 9 q11Shape10T41 q11Shape10T42
private theorem q11Shape10T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 5 1275068674 q11Shape10T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 5 (1275068674 ||| 2^9) q11Shape10T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (5 ||| 2^9) 1275068674 q11Shape10T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T41OK,q11Shape10T42OK⟩

private def q11Shape10T47 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape10T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 261 1275101698 q11Shape10T47=true := by decide

private def q11Shape10T49 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,4,6,7,8,10})))))
private theorem q11Shape10T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33029 1275077122 q11Shape10T49=true := by decide

private def q11Shape10T50 : Tree 11 := (.split 19 (.split 24 (.tip (.small 1)) (.tip (.cover {3,5,6,7,8,10}))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {2,4,6,7,8,10}))) (.tip (.cover {3,5,6,7,8,10}))))
private theorem q11Shape10T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 41221 1275068930 q11Shape10T50=true := by decide

private def q11Shape10T48 : Tree 11 := .split 13 q11Shape10T49 q11Shape10T50
private theorem q11Shape10T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33029 1275068930 q11Shape10T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33029 (1275068930 ||| 2^13) q11Shape10T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (33029 ||| 2^13) 1275068930 q11Shape10T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T49OK,q11Shape10T50OK⟩

private def q11Shape10T46 : Tree 11 := .split 15 q11Shape10T47 q11Shape10T48
private theorem q11Shape10T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 261 1275068930 q11Shape10T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 261 (1275068930 ||| 2^15) q11Shape10T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (261 ||| 2^15) 1275068930 q11Shape10T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T47OK,q11Shape10T48OK⟩

private def q11Shape10T52 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10}))))) (.tip (.cover {1,3,6,7,8,10})))
private theorem q11Shape10T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 773 1275101186 q11Shape10T52=true := by decide

private def q11Shape10T53 : Tree 11 := (.split 13 (.split 19 (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {2,4,6,7,8,10}))) (.tip (.cover {1,5,6,7,8,10})))) (.tip (.cover {1,3,6,7,8,10})))
private theorem q11Shape10T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33541 1275068418 q11Shape10T53=true := by decide

private def q11Shape10T51 : Tree 11 := .split 15 q11Shape10T52 q11Shape10T53
private theorem q11Shape10T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 773 1275068418 q11Shape10T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 773 (1275068418 ||| 2^15) q11Shape10T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (773 ||| 2^15) 1275068418 q11Shape10T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T52OK,q11Shape10T53OK⟩

private def q11Shape10T45 : Tree 11 := .split 9 q11Shape10T46 q11Shape10T51
private theorem q11Shape10T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 261 1275068418 q11Shape10T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 261 (1275068418 ||| 2^9) q11Shape10T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (261 ||| 2^9) 1275068418 q11Shape10T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T46OK,q11Shape10T51OK⟩

private def q11Shape10T39 : Tree 11 := .split 8 q11Shape10T40 q11Shape10T45
private theorem q11Shape10T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 5 1275068418 q11Shape10T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 5 (1275068418 ||| 2^8) q11Shape10T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (5 ||| 2^8) 1275068418 q11Shape10T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T40OK,q11Shape10T45OK⟩

private def q11Shape10T33 : Tree 11 := .split 2 q11Shape10T34 q11Shape10T39
private theorem q11Shape10T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 1275068418 q11Shape10T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 (1275068418 ||| 2^2) q11Shape10T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (1 ||| 2^2) 1275068418 q11Shape10T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T34OK,q11Shape10T39OK⟩

def q11Shape10P2 : Tree 11 := q11Shape10T33
theorem q11Shape10P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1 1275068418 q11Shape10P2=true := q11Shape10T33OK

end Graffiti384b.EffectiveSearch.Q11
