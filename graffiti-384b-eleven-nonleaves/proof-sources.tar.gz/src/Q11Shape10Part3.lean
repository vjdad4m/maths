import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape10T56 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape10T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 1275069188 q11Shape10T56=true := by decide

private def q11Shape10T58 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape10T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 515 1275101444 q11Shape10T58=true := by decide

private def q11Shape10T59 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10}))))) (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10})))) (.tip (.cover {3,4,6,7,8,10}))))
private theorem q11Shape10T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33283 1275068676 q11Shape10T59=true := by decide

private def q11Shape10T57 : Tree 11 := .split 15 q11Shape10T58 q11Shape10T59
private theorem q11Shape10T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 515 1275068676 q11Shape10T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 515 (1275068676 ||| 2^15) q11Shape10T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (515 ||| 2^15) 1275068676 q11Shape10T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T58OK,q11Shape10T59OK⟩

private def q11Shape10T55 : Tree 11 := .split 9 q11Shape10T56 q11Shape10T57
private theorem q11Shape10T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 1275068676 q11Shape10T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 (1275068676 ||| 2^9) q11Shape10T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (3 ||| 2^9) 1275068676 q11Shape10T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T56OK,q11Shape10T57OK⟩

private def q11Shape10T62 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.unordered {2,3,4,9} 1))))))
private theorem q11Shape10T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 259 1275101700 q11Shape10T62=true := by decide

private def q11Shape10T63 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,6,7,8,10}))) (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10})))) (.tip (.cover {1,4,6,7,8,10}))))
private theorem q11Shape10T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33027 1275068932 q11Shape10T63=true := by decide

private def q11Shape10T61 : Tree 11 := .split 15 q11Shape10T62 q11Shape10T63
private theorem q11Shape10T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 259 1275068932 q11Shape10T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 259 (1275068932 ||| 2^15) q11Shape10T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (259 ||| 2^15) 1275068932 q11Shape10T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T62OK,q11Shape10T63OK⟩

private def q11Shape10T65 : Tree 11 := (.split 13 (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10}))))) (.tip (.cover {1,3,6,7,8,10})))
private theorem q11Shape10T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 771 1275101188 q11Shape10T65=true := by decide

private def q11Shape10T66 : Tree 11 := (.split 13 (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10})))) (.tip (.cover {1,4,6,7,8,10}))) (.tip (.cover {1,3,6,7,8,10})))
private theorem q11Shape10T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33539 1275068420 q11Shape10T66=true := by decide

private def q11Shape10T64 : Tree 11 := .split 15 q11Shape10T65 q11Shape10T66
private theorem q11Shape10T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 771 1275068420 q11Shape10T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 771 (1275068420 ||| 2^15) q11Shape10T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (771 ||| 2^15) 1275068420 q11Shape10T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T65OK,q11Shape10T66OK⟩

private def q11Shape10T60 : Tree 11 := .split 9 q11Shape10T61 q11Shape10T64
private theorem q11Shape10T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 259 1275068420 q11Shape10T60=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 259 (1275068420 ||| 2^9) q11Shape10T61 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (259 ||| 2^9) 1275068420 q11Shape10T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T61OK,q11Shape10T64OK⟩

private def q11Shape10T54 : Tree 11 := .split 8 q11Shape10T55 q11Shape10T60
private theorem q11Shape10T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 1275068420 q11Shape10T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 (1275068420 ||| 2^8) q11Shape10T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (3 ||| 2^8) 1275068420 q11Shape10T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T55OK,q11Shape10T60OK⟩

def q11Shape10P3 : Tree 11 := q11Shape10T54
theorem q11Shape10P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 3 1275068420 q11Shape10P3=true := q11Shape10T54OK

end Graffiti384b.EffectiveSearch.Q11
