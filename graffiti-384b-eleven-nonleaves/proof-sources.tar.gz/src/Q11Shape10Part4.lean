import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape10T70 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10})))))
private theorem q11Shape10T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 1275101952 q11Shape10T70=true := by decide

private def q11Shape10T72 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))))
private theorem q11Shape10T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 32775 1275077376 q11Shape10T72=true := by decide

private def q11Shape10T73 : Tree 11 := (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10}))) (.tip (.cover {2,6,7,8,9,10}))))
private theorem q11Shape10T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 40967 1275069184 q11Shape10T73=true := by decide

private def q11Shape10T71 : Tree 11 := .split 13 q11Shape10T72 q11Shape10T73
private theorem q11Shape10T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 32775 1275069184 q11Shape10T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 32775 (1275069184 ||| 2^13) q11Shape10T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (32775 ||| 2^13) 1275069184 q11Shape10T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T72OK,q11Shape10T73OK⟩

private def q11Shape10T69 : Tree 11 := .split 15 q11Shape10T70 q11Shape10T71
private theorem q11Shape10T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 1275069184 q11Shape10T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 (1275069184 ||| 2^15) q11Shape10T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (7 ||| 2^15) 1275069184 q11Shape10T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T70OK,q11Shape10T71OK⟩

private def q11Shape10T76 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))))
private theorem q11Shape10T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 519 1275109632 q11Shape10T76=true := by decide

private def q11Shape10T77 : Tree 11 := (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10}))) (.tip (.cover {2,6,7,8,9,10}))))
private theorem q11Shape10T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 8711 1275101440 q11Shape10T77=true := by decide

private def q11Shape10T75 : Tree 11 := .split 13 q11Shape10T76 q11Shape10T77
private theorem q11Shape10T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 519 1275101440 q11Shape10T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 519 (1275101440 ||| 2^13) q11Shape10T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (519 ||| 2^13) 1275101440 q11Shape10T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T76OK,q11Shape10T77OK⟩

private def q11Shape10T79 : Tree 11 := (.split 19 (.split 24 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10}))) (.tip (.cover {1,5,6,7,8,10}))))
private theorem q11Shape10T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33287 1275076864 q11Shape10T79=true := by decide

private def q11Shape10T80 : Tree 11 := (.split 19 (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10}))) (.tip (.cover {1,5,6,7,8,10}))) (.tip (.cover {3,4,6,7,8,10})))
private theorem q11Shape10T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 41479 1275068672 q11Shape10T80=true := by decide

private def q11Shape10T78 : Tree 11 := .split 13 q11Shape10T79 q11Shape10T80
private theorem q11Shape10T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33287 1275068672 q11Shape10T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33287 (1275068672 ||| 2^13) q11Shape10T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (33287 ||| 2^13) 1275068672 q11Shape10T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T79OK,q11Shape10T80OK⟩

private def q11Shape10T74 : Tree 11 := .split 15 q11Shape10T75 q11Shape10T78
private theorem q11Shape10T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 519 1275068672 q11Shape10T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 519 (1275068672 ||| 2^15) q11Shape10T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (519 ||| 2^15) 1275068672 q11Shape10T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T75OK,q11Shape10T78OK⟩

private def q11Shape10T68 : Tree 11 := .split 9 q11Shape10T69 q11Shape10T74
private theorem q11Shape10T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 1275068672 q11Shape10T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 (1275068672 ||| 2^9) q11Shape10T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (7 ||| 2^9) 1275068672 q11Shape10T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T69OK,q11Shape10T74OK⟩

private def q11Shape10T84 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))))
private theorem q11Shape10T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 263 1275109888 q11Shape10T84=true := by decide

private def q11Shape10T85 : Tree 11 := (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10}))) (.tip (.cover {2,6,7,8,9,10}))))
private theorem q11Shape10T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 8455 1275101696 q11Shape10T85=true := by decide

private def q11Shape10T83 : Tree 11 := .split 13 q11Shape10T84 q11Shape10T85
private theorem q11Shape10T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 263 1275101696 q11Shape10T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 263 (1275101696 ||| 2^13) q11Shape10T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (263 ||| 2^13) 1275101696 q11Shape10T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T84OK,q11Shape10T85OK⟩

private def q11Shape10T86 : Tree 11 := (.split 13 (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))) (.tip (.cover {1,4,6,7,8,10}))) (.split 19 (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10}))) (.tip (.cover {3,5,6,7,8,10}))) (.tip (.cover {1,4,6,7,8,10}))))
private theorem q11Shape10T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33031 1275068928 q11Shape10T86=true := by decide

private def q11Shape10T82 : Tree 11 := .split 15 q11Shape10T83 q11Shape10T86
private theorem q11Shape10T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 263 1275068928 q11Shape10T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 263 (1275068928 ||| 2^15) q11Shape10T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (263 ||| 2^15) 1275068928 q11Shape10T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T83OK,q11Shape10T86OK⟩

private def q11Shape10T88 : Tree 11 := (.split 13 (.split 19 (.split 24 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10})))) (.split 24 (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,6,7,8,10}))) (.tip (.cover {4,5,6,7,8,10})))) (.tip (.cover {1,3,6,7,8,10})))
private theorem q11Shape10T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 775 1275101184 q11Shape10T88=true := by decide

private def q11Shape10T89 : Tree 11 := (.split 13 (.tip (.unordered {2,3,4,5} 1)) (.tip (.cover {1,3,6,7,8,10})))
private theorem q11Shape10T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 33543 1275068416 q11Shape10T89=true := by decide

private def q11Shape10T87 : Tree 11 := .split 15 q11Shape10T88 q11Shape10T89
private theorem q11Shape10T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 775 1275068416 q11Shape10T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 775 (1275068416 ||| 2^15) q11Shape10T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (775 ||| 2^15) 1275068416 q11Shape10T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T88OK,q11Shape10T89OK⟩

private def q11Shape10T81 : Tree 11 := .split 9 q11Shape10T82 q11Shape10T87
private theorem q11Shape10T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 263 1275068416 q11Shape10T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 263 (1275068416 ||| 2^9) q11Shape10T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (263 ||| 2^9) 1275068416 q11Shape10T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T82OK,q11Shape10T87OK⟩

private def q11Shape10T67 : Tree 11 := .split 8 q11Shape10T68 q11Shape10T81
private theorem q11Shape10T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 1275068416 q11Shape10T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 (1275068416 ||| 2^8) q11Shape10T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) (7 ||| 2^8) 1275068416 q11Shape10T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape10T68OK,q11Shape10T81OK⟩

def q11Shape10P4 : Tree 11 := q11Shape10T67
theorem q11Shape10P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 7 1275068416 q11Shape10P4=true := q11Shape10T67OK

private def q11Shape10T93 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape10T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1073741824 201326592 q11Shape10T93=true := by decide

def q11Shape10P5 : Tree 11 := q11Shape10T93
theorem q11Shape10P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 1073741824 201326592 q11Shape10P5=true := q11Shape10T93OK

private def q11Shape10T95 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape10T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 134217728 67108864 q11Shape10T95=true := by decide

def q11Shape10P6 : Tree 11 := q11Shape10T95
theorem q11Shape10P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 134217728 67108864 q11Shape10P6=true := q11Shape10T95OK

private def q11Shape10T97 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape10T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 67108864 0 q11Shape10T97=true := by decide

def q11Shape10P7 : Tree 11 := q11Shape10T97
theorem q11Shape10P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,4⟩) 67108864 0 q11Shape10P7=true := q11Shape10T97OK

end Graffiti384b.EffectiveSearch.Q11
