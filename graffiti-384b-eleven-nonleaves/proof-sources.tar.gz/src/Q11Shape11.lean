import Q11Shape11Part0

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q11Shape11_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 11) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 11) b) (adj 11 (forms 11) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) adj_mono b H q11Shape11P0 q11Shape11P0OK

#print axioms q11Shape11_cover

end Graffiti384b.EffectiveSearch.Q11
