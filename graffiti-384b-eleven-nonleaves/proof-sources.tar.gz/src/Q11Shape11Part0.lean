import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape11T3 : Tree 11 := (.split 35 (.split 28 (.split 29 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9})))
private theorem q11Shape11T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 1275068416 q11Shape11T3=true := by decide

private def q11Shape11T4 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape11T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 1073741824 201326592 q11Shape11T4=true := by decide

private def q11Shape11T2 : Tree 11 := .split 30 q11Shape11T3 q11Shape11T4
private theorem q11Shape11T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 201326592 q11Shape11T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 (201326592 ||| 2^30) q11Shape11T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) (0 ||| 2^30) 201326592 q11Shape11T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape11T3OK,q11Shape11T4OK⟩

private def q11Shape11T5 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape11T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 134217728 67108864 q11Shape11T5=true := by decide

private def q11Shape11T1 : Tree 11 := .split 27 q11Shape11T2 q11Shape11T5
private theorem q11Shape11T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 67108864 q11Shape11T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 (67108864 ||| 2^27) q11Shape11T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) (0 ||| 2^27) 67108864 q11Shape11T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape11T2OK,q11Shape11T5OK⟩

private def q11Shape11T6 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape11T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 67108864 0 q11Shape11T6=true := by decide

private def q11Shape11T0 : Tree 11 := .split 26 q11Shape11T1 q11Shape11T6
private theorem q11Shape11T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 0 q11Shape11T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 (0 ||| 2^26) q11Shape11T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) (0 ||| 2^26) 0 q11Shape11T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape11T1OK,q11Shape11T6OK⟩

def q11Shape11P0 : Tree 11 := q11Shape11T0
theorem q11Shape11P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,6,4⟩) 0 0 q11Shape11P0=true := q11Shape11T0OK

end Graffiti384b.EffectiveSearch.Q11
