import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape13T0 : Tree 11 := (.tip (.small 0))
private theorem q11Shape13T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 13)) 0 0 q11Shape13T0=true := by decide


theorem q11Shape13_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 13) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 13) b) (adj 11 (forms 13) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 13)) adj_mono b H q11Shape13T0 q11Shape13T0OK

#print axioms q11Shape13_cover
end Graffiti384b.EffectiveSearch.Q11
