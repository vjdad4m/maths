import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape14T0 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover {0,1,3,6,9,10})))))))
private theorem q11Shape14T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 14)) 0 0 q11Shape14T0=true := by decide


theorem q11Shape14_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 14) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 14) b) (adj 11 (forms 14) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 14)) adj_mono b H q11Shape14T0 q11Shape14T0OK

#print axioms q11Shape14_cover
end Graffiti384b.EffectiveSearch.Q11
