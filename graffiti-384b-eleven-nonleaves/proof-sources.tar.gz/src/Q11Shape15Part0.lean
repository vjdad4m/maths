import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape15T2 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10})))))))))
private theorem q11Shape15T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 0 67141632 q11Shape15T2=true := by decide

private def q11Shape15T3 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,7,8,9,10}))))))))
private theorem q11Shape15T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67108864 32768 q11Shape15T3=true := by decide

private def q11Shape15T1 : Tree 11 := .split 26 q11Shape15T2 q11Shape15T3
private theorem q11Shape15T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 0 32768 q11Shape15T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 0 (32768 ||| 2^26) q11Shape15T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (0 ||| 2^26) 32768 q11Shape15T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T2OK,q11Shape15T3OK⟩

private def q11Shape15T6 : Tree 11 := (.tip (.small 1))
private theorem q11Shape15T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32768 67108865 q11Shape15T6=true := by decide

private def q11Shape15T8 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,4,8,9,10})))))))
private theorem q11Shape15T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32769 67108866 q11Shape15T8=true := by decide

private def q11Shape15T10 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {1,2,5,8,9,10}))))))
private theorem q11Shape15T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32771 67108868 q11Shape15T10=true := by decide

private def q11Shape15T12 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10})))))
private theorem q11Shape15T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32775 67109120 q11Shape15T12=true := by decide

private def q11Shape15T13 : Tree 11 := (.split 9 (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10})))) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,1,2,8,9,10})))))
private theorem q11Shape15T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 33031 67108864 q11Shape15T13=true := by decide

private def q11Shape15T11 : Tree 11 := .split 8 q11Shape15T12 q11Shape15T13
private theorem q11Shape15T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32775 67108864 q11Shape15T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32775 (67108864 ||| 2^8) q11Shape15T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (32775 ||| 2^8) 67108864 q11Shape15T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T12OK,q11Shape15T13OK⟩

private def q11Shape15T9 : Tree 11 := .split 2 q11Shape15T10 q11Shape15T11
private theorem q11Shape15T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32771 67108864 q11Shape15T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32771 (67108864 ||| 2^2) q11Shape15T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (32771 ||| 2^2) 67108864 q11Shape15T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T10OK,q11Shape15T11OK⟩

private def q11Shape15T7 : Tree 11 := .split 1 q11Shape15T8 q11Shape15T9
private theorem q11Shape15T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32769 67108864 q11Shape15T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32769 (67108864 ||| 2^1) q11Shape15T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (32769 ||| 2^1) 67108864 q11Shape15T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T8OK,q11Shape15T9OK⟩

private def q11Shape15T5 : Tree 11 := .split 0 q11Shape15T6 q11Shape15T7
private theorem q11Shape15T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32768 67108864 q11Shape15T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32768 (67108864 ||| 2^0) q11Shape15T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (32768 ||| 2^0) 67108864 q11Shape15T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T6OK,q11Shape15T7OK⟩

private def q11Shape15T15 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,7,8,9,10})))))))
private theorem q11Shape15T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141632 1 q11Shape15T15=true := by decide

private def q11Shape15T17 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,7,8,9,10}))))))
private theorem q11Shape15T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141633 2 q11Shape15T17=true := by decide

private def q11Shape15T19 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {2,5,6,8,9,10}))) (.tip (.cover {2,5,7,8,9,10})))))
private theorem q11Shape15T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141635 4 q11Shape15T19=true := by decide

private def q11Shape15T21 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {2,5,6,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))))
private theorem q11Shape15T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141639 256 q11Shape15T21=true := by decide

private def q11Shape15T22 : Tree 11 := (.split 9 (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,7,8,9,10}))) (.split 3 (.split 4 (.tip (.small 1)) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,7,8,9,10}))))
private theorem q11Shape15T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141895 0 q11Shape15T22=true := by decide

private def q11Shape15T20 : Tree 11 := .split 8 q11Shape15T21 q11Shape15T22
private theorem q11Shape15T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141639 0 q11Shape15T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141639 (0 ||| 2^8) q11Shape15T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (67141639 ||| 2^8) 0 q11Shape15T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T21OK,q11Shape15T22OK⟩

private def q11Shape15T18 : Tree 11 := .split 2 q11Shape15T19 q11Shape15T20
private theorem q11Shape15T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141635 0 q11Shape15T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141635 (0 ||| 2^2) q11Shape15T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (67141635 ||| 2^2) 0 q11Shape15T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T19OK,q11Shape15T20OK⟩

private def q11Shape15T16 : Tree 11 := .split 1 q11Shape15T17 q11Shape15T18
private theorem q11Shape15T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141633 0 q11Shape15T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141633 (0 ||| 2^1) q11Shape15T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (67141633 ||| 2^1) 0 q11Shape15T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T17OK,q11Shape15T18OK⟩

private def q11Shape15T14 : Tree 11 := .split 0 q11Shape15T15 q11Shape15T16
private theorem q11Shape15T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141632 0 q11Shape15T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 67141632 (0 ||| 2^0) q11Shape15T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (67141632 ||| 2^0) 0 q11Shape15T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T15OK,q11Shape15T16OK⟩

private def q11Shape15T4 : Tree 11 := .split 26 q11Shape15T5 q11Shape15T14
private theorem q11Shape15T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32768 0 q11Shape15T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 32768 (0 ||| 2^26) q11Shape15T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (32768 ||| 2^26) 0 q11Shape15T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T5OK,q11Shape15T14OK⟩

private def q11Shape15T0 : Tree 11 := .split 15 q11Shape15T1 q11Shape15T4
private theorem q11Shape15T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 0 0 q11Shape15T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 0 (0 ||| 2^15) q11Shape15T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) (0 ||| 2^15) 0 q11Shape15T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape15T1OK,q11Shape15T4OK⟩

def q11Shape15P0 : Tree 11 := q11Shape15T0
theorem q11Shape15P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,2⟩) 0 0 q11Shape15P0=true := q11Shape15T0OK

end Graffiti384b.EffectiveSearch.Q11
