import Q11Shape16Part0
import Q11Shape16Part1
import Q11Shape16Part2
import Q11Shape16Part3
import Q11Shape16Part4
import Q11Shape16Part5
import Q11Shape16Part6
import Q11Shape16Part7
import Q11Shape16Part8
import Q11Shape16Part9
import Q11Shape16Part10
import Q11Shape16Part11
import Q11Shape16Part12
import Q11Shape16Part13
import Q11Shape16Part14
import Q11Shape16Part15
import Q11Shape16Part16
import Q11Shape16Part17

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16M121 : Tree 11 := .split 32 q11Shape16P1 q11Shape16P2
private theorem q11Shape16M121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2147483648 2145386496 q11Shape16M121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2147483648 (2145386496 ||| 2^32) q11Shape16P1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2147483648 ||| 2^32) 2145386496 q11Shape16P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16P1OK,q11Shape16P2OK⟩
private def q11Shape16M122 : Tree 11 := .split 31 q11Shape16P0 q11Shape16M121
private theorem q11Shape16M122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 2145386496 q11Shape16M122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (2145386496 ||| 2^31) q11Shape16P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^31) 2145386496 q11Shape16M121)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16P0OK,q11Shape16M121OK⟩
private def q11Shape16M195 : Tree 11 := .split 32 q11Shape16P3 q11Shape16P4
private theorem q11Shape16M195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 3219128320 q11Shape16M195=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 (3219128320 ||| 2^32) q11Shape16P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1073741824 ||| 2^32) 3219128320 q11Shape16P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16P3OK,q11Shape16P4OK⟩
private def q11Shape16M256 : Tree 11 := .split 32 q11Shape16P5 q11Shape16P6
private theorem q11Shape16M256OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 1071644672 q11Shape16M256=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 (1071644672 ||| 2^32) q11Shape16P5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (3221225472 ||| 2^32) 1071644672 q11Shape16P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16P5OK,q11Shape16P6OK⟩
private def q11Shape16M257 : Tree 11 := .split 31 q11Shape16M195 q11Shape16M256
private theorem q11Shape16M257OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 1071644672 q11Shape16M257=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 (1071644672 ||| 2^31) q11Shape16M195 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1073741824 ||| 2^31) 1071644672 q11Shape16M256)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M195OK,q11Shape16M256OK⟩
private def q11Shape16M258 : Tree 11 := .split 30 q11Shape16M122 q11Shape16M257
private theorem q11Shape16M258OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 1071644672 q11Shape16M258=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (1071644672 ||| 2^30) q11Shape16M122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^30) 1071644672 q11Shape16M257)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M122OK,q11Shape16M257OK⟩
private def q11Shape16M266 : Tree 11 := .split 29 q11Shape16M258 q11Shape16P7
private theorem q11Shape16M266OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 534773760 q11Shape16M266=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (534773760 ||| 2^29) q11Shape16M258 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^29) 534773760 q11Shape16P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M258OK,q11Shape16P7OK⟩
private def q11Shape16M292 : Tree 11 := .split 28 q11Shape16M266 q11Shape16P8
private theorem q11Shape16M292OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 266338304 q11Shape16M292=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (266338304 ||| 2^28) q11Shape16M266 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^28) 266338304 q11Shape16P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M266OK,q11Shape16P8OK⟩
private def q11Shape16M340 : Tree 11 := .split 27 q11Shape16M292 q11Shape16P9
private theorem q11Shape16M340OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 132120576 q11Shape16M340=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (132120576 ||| 2^27) q11Shape16M292 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^27) 132120576 q11Shape16P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M292OK,q11Shape16P9OK⟩
private def q11Shape16M417 : Tree 11 := .split 27 q11Shape16P10 q11Shape16P11
private theorem q11Shape16M417OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 65011712 q11Shape16M417=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 (65011712 ||| 2^27) q11Shape16P10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (67108864 ||| 2^27) 65011712 q11Shape16P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16P10OK,q11Shape16P11OK⟩
private def q11Shape16M418 : Tree 11 := .split 26 q11Shape16M340 q11Shape16M417
private theorem q11Shape16M418OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 65011712 q11Shape16M418=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (65011712 ||| 2^26) q11Shape16M340 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^26) 65011712 q11Shape16M417)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M340OK,q11Shape16M417OK⟩
private def q11Shape16M432 : Tree 11 := .split 25 q11Shape16M418 q11Shape16P12
private theorem q11Shape16M432OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 31457280 q11Shape16M432=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (31457280 ||| 2^25) q11Shape16M418 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^25) 31457280 q11Shape16P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M418OK,q11Shape16P12OK⟩
private def q11Shape16M470 : Tree 11 := .split 24 q11Shape16M432 q11Shape16P13
private theorem q11Shape16M470OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 14680064 q11Shape16M470=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (14680064 ||| 2^24) q11Shape16M432 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^24) 14680064 q11Shape16P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M432OK,q11Shape16P13OK⟩
private def q11Shape16M529 : Tree 11 := .split 24 q11Shape16P14 q11Shape16P15
private theorem q11Shape16M529OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 1012924416 q11Shape16M529=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (1012924416 ||| 2^24) q11Shape16P14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^24) 1012924416 q11Shape16P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16P14OK,q11Shape16P15OK⟩
private def q11Shape16M531 : Tree 11 := .split 29 q11Shape16M529 q11Shape16P16
private theorem q11Shape16M531OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 476053504 q11Shape16M531=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (476053504 ||| 2^29) q11Shape16M529 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^29) 476053504 q11Shape16P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M529OK,q11Shape16P16OK⟩
private def q11Shape16M533 : Tree 11 := .split 28 q11Shape16M531 q11Shape16P17
private theorem q11Shape16M533OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 207618048 q11Shape16M533=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (207618048 ||| 2^28) q11Shape16M531 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^28) 207618048 q11Shape16P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M531OK,q11Shape16P17OK⟩
private def q11Shape16M535 : Tree 11 := .split 27 q11Shape16M533 q11Shape16P18
private theorem q11Shape16M535OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 73400320 q11Shape16M535=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (73400320 ||| 2^27) q11Shape16M533 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^27) 73400320 q11Shape16P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M533OK,q11Shape16P18OK⟩
private def q11Shape16M537 : Tree 11 := .split 26 q11Shape16M535 q11Shape16P19
private theorem q11Shape16M537OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 6291456 q11Shape16M537=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (6291456 ||| 2^26) q11Shape16M535 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^26) 6291456 q11Shape16P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M535OK,q11Shape16P19OK⟩
private def q11Shape16M538 : Tree 11 := .split 23 q11Shape16M470 q11Shape16M537
private theorem q11Shape16M538OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 6291456 q11Shape16M538=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (6291456 ||| 2^23) q11Shape16M470 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^23) 6291456 q11Shape16M537)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M470OK,q11Shape16M537OK⟩
private def q11Shape16M605 : Tree 11 := .split 24 q11Shape16P20 q11Shape16P21
private theorem q11Shape16M605OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 1017118720 q11Shape16M605=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (1017118720 ||| 2^24) q11Shape16P20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^24) 1017118720 q11Shape16P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16P20OK,q11Shape16P21OK⟩
private def q11Shape16M649 : Tree 11 := .split 23 q11Shape16M605 q11Shape16P22
private theorem q11Shape16M649OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 1008730112 q11Shape16M649=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (1008730112 ||| 2^23) q11Shape16M605 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^23) 1008730112 q11Shape16P22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M605OK,q11Shape16P22OK⟩
private def q11Shape16M651 : Tree 11 := .split 29 q11Shape16M649 q11Shape16P23
private theorem q11Shape16M651OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 471859200 q11Shape16M651=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (471859200 ||| 2^29) q11Shape16M649 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^29) 471859200 q11Shape16P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M649OK,q11Shape16P23OK⟩
private def q11Shape16M653 : Tree 11 := .split 28 q11Shape16M651 q11Shape16P24
private theorem q11Shape16M653OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 203423744 q11Shape16M653=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (203423744 ||| 2^28) q11Shape16M651 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^28) 203423744 q11Shape16P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M651OK,q11Shape16P24OK⟩
private def q11Shape16M655 : Tree 11 := .split 27 q11Shape16M653 q11Shape16P25
private theorem q11Shape16M655OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 69206016 q11Shape16M655=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (69206016 ||| 2^27) q11Shape16M653 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^27) 69206016 q11Shape16P25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M653OK,q11Shape16P25OK⟩
private def q11Shape16M657 : Tree 11 := .split 26 q11Shape16M655 q11Shape16P26
private theorem q11Shape16M657OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 2097152 q11Shape16M657=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (2097152 ||| 2^26) q11Shape16M655 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^26) 2097152 q11Shape16P26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M655OK,q11Shape16P26OK⟩
private def q11Shape16M658 : Tree 11 := .split 22 q11Shape16M538 q11Shape16M657
private theorem q11Shape16M658OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 2097152 q11Shape16M658=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (2097152 ||| 2^22) q11Shape16M538 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^22) 2097152 q11Shape16M657)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M538OK,q11Shape16M657OK⟩
private def q11Shape16M692 : Tree 11 := .split 21 q11Shape16M658 q11Shape16P27
private theorem q11Shape16M692OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 0 q11Shape16M692=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (0 ||| 2^21) q11Shape16M658 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^21) 0 q11Shape16P27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16M658OK,q11Shape16P27OK⟩

theorem q11Shape16_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 16) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 16) b) (adj 11 (forms 16) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 16)) adj_mono b H q11Shape16M692 q11Shape16M692OK

#print axioms q11Shape16_cover

end Graffiti384b.EffectiveSearch.Q11
