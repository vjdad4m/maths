import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T1 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape16T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 12882804736 q11Shape16T1=true := by decide

private def q11Shape16T4 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape16T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8589934592 25767706624 q11Shape16T4=true := by decide

private def q11Shape16T6 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape16T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25769803776 42947575808 q11Shape16T6=true := by decide

private def q11Shape16T9 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 60129542144 8587837956 q11Shape16T9=true := by decide

private def q11Shape16T10 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,9})))
private theorem q11Shape16T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 60129542656 8587837444 q11Shape16T10=true := by decide

private def q11Shape16T8 : Tree 11 := .split 9 q11Shape16T9 q11Shape16T10
private theorem q11Shape16T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 60129542144 8587837444 q11Shape16T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 60129542144 (8587837444 ||| 2^9) q11Shape16T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (60129542144 ||| 2^9) 8587837444 q11Shape16T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T9OK,q11Shape16T10OK⟩

private def q11Shape16T11 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {2,3,4,6,8,9})))
private theorem q11Shape16T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 60129542148 8587837440 q11Shape16T11=true := by decide

private def q11Shape16T7 : Tree 11 := .split 2 q11Shape16T8 q11Shape16T11
private theorem q11Shape16T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 60129542144 8587837440 q11Shape16T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 60129542144 (8587837440 ||| 2^2) q11Shape16T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (60129542144 ||| 2^2) 8587837440 q11Shape16T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T8OK,q11Shape16T11OK⟩

private def q11Shape16T5 : Tree 11 := .split 35 q11Shape16T6 q11Shape16T7
private theorem q11Shape16T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25769803776 8587837440 q11Shape16T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25769803776 (8587837440 ||| 2^35) q11Shape16T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (25769803776 ||| 2^35) 8587837440 q11Shape16T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T6OK,q11Shape16T7OK⟩

private def q11Shape16T3 : Tree 11 := .split 34 q11Shape16T4 q11Shape16T5
private theorem q11Shape16T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8589934592 8587837440 q11Shape16T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8589934592 (8587837440 ||| 2^34) q11Shape16T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8589934592 ||| 2^34) 8587837440 q11Shape16T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T4OK,q11Shape16T5OK⟩

private def q11Shape16T16 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,4,6,7,9,10}))) (.tip (.cover {0,4,6,8,9,10})))))))
private theorem q11Shape16T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 55832478212 q11Shape16T16=true := by decide

private def q11Shape16T17 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,6,7,9,10}))) (.tip (.cover {0,3,6,8,9,10})))))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884902400 55832477700 q11Shape16T17=true := by decide

private def q11Shape16T15 : Tree 11 := .split 9 q11Shape16T16 q11Shape16T17
private theorem q11Shape16T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 55832477700 q11Shape16T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 (55832477700 ||| 2^9) q11Shape16T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901888 ||| 2^9) 55832477700 q11Shape16T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T16OK,q11Shape16T17OK⟩

private def q11Shape16T21 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901892 55832510977 q11Shape16T21=true := by decide

private def q11Shape16T23 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901893 55832510978 q11Shape16T23=true := by decide

private def q11Shape16T25 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901895 55832511232 q11Shape16T25=true := by decide

private def q11Shape16T28 : Tree 11 := (.split 3 (.tip (.small 1)) (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.split 11 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,4,5,6,9,10})))))
private theorem q11Shape16T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884902151 55832577536 q11Shape16T28=true := by decide

private def q11Shape16T29 : Tree 11 := (.split 3 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {1,4,5,7,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {2,3,4,5,7,8})))
private theorem q11Shape16T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884967687 55832512000 q11Shape16T29=true := by decide

private def q11Shape16T27 : Tree 11 := .split 16 q11Shape16T28 q11Shape16T29
private theorem q11Shape16T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884902151 55832512000 q11Shape16T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884902151 (55832512000 ||| 2^16) q11Shape16T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884902151 ||| 2^16) 55832512000 q11Shape16T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T28OK,q11Shape16T29OK⟩

private def q11Shape16T30 : Tree 11 := (.split 16 (.split 3 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {4,5,6,7,9,10}))) (.tip (.cover {4,5,6,8,9,10}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8})))
private theorem q11Shape16T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884903175 55832510976 q11Shape16T30=true := by decide

private def q11Shape16T26 : Tree 11 := .split 10 q11Shape16T27 q11Shape16T30
private theorem q11Shape16T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884902151 55832510976 q11Shape16T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884902151 (55832510976 ||| 2^10) q11Shape16T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884902151 ||| 2^10) 55832510976 q11Shape16T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T27OK,q11Shape16T30OK⟩

private def q11Shape16T24 : Tree 11 := .split 8 q11Shape16T25 q11Shape16T26
private theorem q11Shape16T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901895 55832510976 q11Shape16T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901895 (55832510976 ||| 2^8) q11Shape16T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901895 ||| 2^8) 55832510976 q11Shape16T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T25OK,q11Shape16T26OK⟩

private def q11Shape16T22 : Tree 11 := .split 1 q11Shape16T23 q11Shape16T24
private theorem q11Shape16T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901893 55832510976 q11Shape16T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901893 (55832510976 ||| 2^1) q11Shape16T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901893 ||| 2^1) 55832510976 q11Shape16T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T23OK,q11Shape16T24OK⟩

private def q11Shape16T20 : Tree 11 := .split 0 q11Shape16T21 q11Shape16T22
private theorem q11Shape16T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901892 55832510976 q11Shape16T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901892 (55832510976 ||| 2^0) q11Shape16T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901892 ||| 2^0) 55832510976 q11Shape16T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T21OK,q11Shape16T22OK⟩

private def q11Shape16T31 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape16T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884934660 55832478208 q11Shape16T31=true := by decide

private def q11Shape16T19 : Tree 11 := .split 15 q11Shape16T20 q11Shape16T31
private theorem q11Shape16T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901892 55832478208 q11Shape16T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901892 (55832478208 ||| 2^15) q11Shape16T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901892 ||| 2^15) 55832478208 q11Shape16T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T20OK,q11Shape16T31OK⟩

private def q11Shape16T32 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape16T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884902404 55832477696 q11Shape16T32=true := by decide

private def q11Shape16T18 : Tree 11 := .split 9 q11Shape16T19 q11Shape16T32
private theorem q11Shape16T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901892 55832477696 q11Shape16T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901892 (55832477696 ||| 2^9) q11Shape16T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901892 ||| 2^9) 55832477696 q11Shape16T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T19OK,q11Shape16T32OK⟩

private def q11Shape16T14 : Tree 11 := .split 2 q11Shape16T15 q11Shape16T18
private theorem q11Shape16T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 55832477696 q11Shape16T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 (55832477696 ||| 2^2) q11Shape16T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901888 ||| 2^2) 55832477696 q11Shape16T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T15OK,q11Shape16T18OK⟩

private def q11Shape16T35 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47244640256 21472739844 q11Shape16T35=true := by decide

private def q11Shape16T36 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47244640768 21472739332 q11Shape16T36=true := by decide

private def q11Shape16T34 : Tree 11 := .split 9 q11Shape16T35 q11Shape16T36
private theorem q11Shape16T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47244640256 21472739332 q11Shape16T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47244640256 (21472739332 ||| 2^9) q11Shape16T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (47244640256 ||| 2^9) 21472739332 q11Shape16T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T35OK,q11Shape16T36OK⟩

private def q11Shape16T37 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47244640260 21472739328 q11Shape16T37=true := by decide

private def q11Shape16T33 : Tree 11 := .split 2 q11Shape16T34 q11Shape16T37
private theorem q11Shape16T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47244640256 21472739328 q11Shape16T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47244640256 (21472739328 ||| 2^2) q11Shape16T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (47244640256 ||| 2^2) 21472739328 q11Shape16T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T34OK,q11Shape16T37OK⟩

private def q11Shape16T13 : Tree 11 := .split 35 q11Shape16T14 q11Shape16T33
private theorem q11Shape16T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 21472739328 q11Shape16T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 (21472739328 ||| 2^35) q11Shape16T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901888 ||| 2^35) 21472739328 q11Shape16T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T14OK,q11Shape16T33OK⟩

private def q11Shape16T41 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771072 38652609028 q11Shape16T41=true := by decide

private def q11Shape16T42 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771584 38652608516 q11Shape16T42=true := by decide

private def q11Shape16T40 : Tree 11 := .split 9 q11Shape16T41 q11Shape16T42
private theorem q11Shape16T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771072 38652608516 q11Shape16T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771072 (38652608516 ||| 2^9) q11Shape16T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (30064771072 ||| 2^9) 38652608516 q11Shape16T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T41OK,q11Shape16T42OK⟩

private def q11Shape16T43 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771076 38652608512 q11Shape16T43=true := by decide

private def q11Shape16T39 : Tree 11 := .split 2 q11Shape16T40 q11Shape16T43
private theorem q11Shape16T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771072 38652608512 q11Shape16T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771072 (38652608512 ||| 2^2) q11Shape16T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (30064771072 ||| 2^2) 38652608512 q11Shape16T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T40OK,q11Shape16T43OK⟩

private def q11Shape16T46 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 64424509440 4292870660 q11Shape16T46=true := by decide

private def q11Shape16T47 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,10})))
private theorem q11Shape16T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 64424509952 4292870148 q11Shape16T47=true := by decide

private def q11Shape16T45 : Tree 11 := .split 9 q11Shape16T46 q11Shape16T47
private theorem q11Shape16T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 64424509440 4292870148 q11Shape16T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 64424509440 (4292870148 ||| 2^9) q11Shape16T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (64424509440 ||| 2^9) 4292870148 q11Shape16T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T46OK,q11Shape16T47OK⟩

private def q11Shape16T48 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,8,10})))
private theorem q11Shape16T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 64424509444 4292870144 q11Shape16T48=true := by decide

private def q11Shape16T44 : Tree 11 := .split 2 q11Shape16T45 q11Shape16T48
private theorem q11Shape16T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 64424509440 4292870144 q11Shape16T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 64424509440 (4292870144 ||| 2^2) q11Shape16T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (64424509440 ||| 2^2) 4292870144 q11Shape16T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T45OK,q11Shape16T48OK⟩

private def q11Shape16T38 : Tree 11 := .split 35 q11Shape16T39 q11Shape16T44
private theorem q11Shape16T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771072 4292870144 q11Shape16T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30064771072 (4292870144 ||| 2^35) q11Shape16T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (30064771072 ||| 2^35) 4292870144 q11Shape16T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T39OK,q11Shape16T44OK⟩

private def q11Shape16T12 : Tree 11 := .split 34 q11Shape16T13 q11Shape16T38
private theorem q11Shape16T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 4292870144 q11Shape16T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12884901888 (4292870144 ||| 2^34) q11Shape16T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12884901888 ||| 2^34) 4292870144 q11Shape16T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T13OK,q11Shape16T38OK⟩

private def q11Shape16T2 : Tree 11 := .split 32 q11Shape16T3 q11Shape16T12
private theorem q11Shape16T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8589934592 4292870144 q11Shape16T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8589934592 (4292870144 ||| 2^32) q11Shape16T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8589934592 ||| 2^32) 4292870144 q11Shape16T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T3OK,q11Shape16T12OK⟩

private def q11Shape16T0 : Tree 11 := .split 33 q11Shape16T1 q11Shape16T2
private theorem q11Shape16T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 4292870144 q11Shape16T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 (4292870144 ||| 2^33) q11Shape16T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (0 ||| 2^33) 4292870144 q11Shape16T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T1OK,q11Shape16T2OK⟩

def q11Shape16P0 : Tree 11 := q11Shape16T0
theorem q11Shape16P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 0 4292870144 q11Shape16P0=true := q11Shape16T0OK

end Graffiti384b.EffectiveSearch.Q11
