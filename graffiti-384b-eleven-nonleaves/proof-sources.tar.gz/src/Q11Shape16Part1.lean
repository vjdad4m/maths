import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T50 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape16T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2147483648 23620222976 q11Shape16T50=true := by decide

private def q11Shape16T55 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,4,6,7,9,10}))) (.tip (.cover {0,4,6,8,9,10})))))))
private theorem q11Shape16T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 49390027268 q11Shape16T55=true := by decide

private def q11Shape16T56 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,6,7,9,10}))) (.tip (.cover {0,3,6,8,9,10})))))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327353344 49390026756 q11Shape16T56=true := by decide

private def q11Shape16T54 : Tree 11 := .split 9 q11Shape16T55 q11Shape16T56
private theorem q11Shape16T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 49390026756 q11Shape16T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 (49390026756 ||| 2^9) q11Shape16T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352832 ||| 2^9) 49390026756 q11Shape16T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T55OK,q11Shape16T56OK⟩

private def q11Shape16T60 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352836 49390060033 q11Shape16T60=true := by decide

private def q11Shape16T62 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352837 49390060034 q11Shape16T62=true := by decide

private def q11Shape16T64 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352839 49390060288 q11Shape16T64=true := by decide

private def q11Shape16T67 : Tree 11 := (.split 3 (.tip (.small 1)) (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.split 11 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,4,5,6,9,10})))))
private theorem q11Shape16T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327353095 49390126592 q11Shape16T67=true := by decide

private def q11Shape16T68 : Tree 11 := (.split 3 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {1,4,5,7,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {2,3,4,5,7,8})))
private theorem q11Shape16T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327418631 49390061056 q11Shape16T68=true := by decide

private def q11Shape16T66 : Tree 11 := .split 16 q11Shape16T67 q11Shape16T68
private theorem q11Shape16T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327353095 49390061056 q11Shape16T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327353095 (49390061056 ||| 2^16) q11Shape16T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327353095 ||| 2^16) 49390061056 q11Shape16T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T67OK,q11Shape16T68OK⟩

private def q11Shape16T69 : Tree 11 := (.split 16 (.split 3 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {4,5,6,7,9,10}))) (.tip (.cover {4,5,6,8,9,10}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8})))
private theorem q11Shape16T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327354119 49390060032 q11Shape16T69=true := by decide

private def q11Shape16T65 : Tree 11 := .split 10 q11Shape16T66 q11Shape16T69
private theorem q11Shape16T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327353095 49390060032 q11Shape16T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327353095 (49390060032 ||| 2^10) q11Shape16T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327353095 ||| 2^10) 49390060032 q11Shape16T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T66OK,q11Shape16T69OK⟩

private def q11Shape16T63 : Tree 11 := .split 8 q11Shape16T64 q11Shape16T65
private theorem q11Shape16T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352839 49390060032 q11Shape16T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352839 (49390060032 ||| 2^8) q11Shape16T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352839 ||| 2^8) 49390060032 q11Shape16T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T64OK,q11Shape16T65OK⟩

private def q11Shape16T61 : Tree 11 := .split 1 q11Shape16T62 q11Shape16T63
private theorem q11Shape16T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352837 49390060032 q11Shape16T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352837 (49390060032 ||| 2^1) q11Shape16T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352837 ||| 2^1) 49390060032 q11Shape16T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T62OK,q11Shape16T63OK⟩

private def q11Shape16T59 : Tree 11 := .split 0 q11Shape16T60 q11Shape16T61
private theorem q11Shape16T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352836 49390060032 q11Shape16T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352836 (49390060032 ||| 2^0) q11Shape16T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352836 ||| 2^0) 49390060032 q11Shape16T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T60OK,q11Shape16T61OK⟩

private def q11Shape16T70 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape16T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327385604 49390027264 q11Shape16T70=true := by decide

private def q11Shape16T58 : Tree 11 := .split 15 q11Shape16T59 q11Shape16T70
private theorem q11Shape16T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352836 49390027264 q11Shape16T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352836 (49390027264 ||| 2^15) q11Shape16T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352836 ||| 2^15) 49390027264 q11Shape16T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T59OK,q11Shape16T70OK⟩

private def q11Shape16T71 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape16T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327353348 49390026752 q11Shape16T71=true := by decide

private def q11Shape16T57 : Tree 11 := .split 9 q11Shape16T58 q11Shape16T71
private theorem q11Shape16T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352836 49390026752 q11Shape16T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352836 (49390026752 ||| 2^9) q11Shape16T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352836 ||| 2^9) 49390026752 q11Shape16T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T58OK,q11Shape16T71OK⟩

private def q11Shape16T53 : Tree 11 := .split 2 q11Shape16T54 q11Shape16T57
private theorem q11Shape16T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 49390026752 q11Shape16T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 (49390026752 ||| 2^2) q11Shape16T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352832 ||| 2^2) 49390026752 q11Shape16T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T54OK,q11Shape16T57OK⟩

private def q11Shape16T74 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53687091200 15030288900 q11Shape16T74=true := by decide

private def q11Shape16T75 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53687091712 15030288388 q11Shape16T75=true := by decide

private def q11Shape16T73 : Tree 11 := .split 9 q11Shape16T74 q11Shape16T75
private theorem q11Shape16T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53687091200 15030288388 q11Shape16T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53687091200 (15030288388 ||| 2^9) q11Shape16T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (53687091200 ||| 2^9) 15030288388 q11Shape16T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T74OK,q11Shape16T75OK⟩

private def q11Shape16T76 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53687091204 15030288384 q11Shape16T76=true := by decide

private def q11Shape16T72 : Tree 11 := .split 2 q11Shape16T73 q11Shape16T76
private theorem q11Shape16T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53687091200 15030288384 q11Shape16T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53687091200 (15030288384 ||| 2^2) q11Shape16T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (53687091200 ||| 2^2) 15030288384 q11Shape16T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T73OK,q11Shape16T76OK⟩

private def q11Shape16T52 : Tree 11 := .split 35 q11Shape16T53 q11Shape16T72
private theorem q11Shape16T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 15030288384 q11Shape16T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 (15030288384 ||| 2^35) q11Shape16T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352832 ||| 2^35) 15030288384 q11Shape16T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T53OK,q11Shape16T72OK⟩

private def q11Shape16T80 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287424 40800092676 q11Shape16T80=true := by decide

private def q11Shape16T81 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287936 40800092164 q11Shape16T81=true := by decide

private def q11Shape16T79 : Tree 11 := .split 9 q11Shape16T80 q11Shape16T81
private theorem q11Shape16T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287424 40800092164 q11Shape16T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287424 (40800092164 ||| 2^9) q11Shape16T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (27917287424 ||| 2^9) 40800092164 q11Shape16T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T80OK,q11Shape16T81OK⟩

private def q11Shape16T82 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287428 40800092160 q11Shape16T82=true := by decide

private def q11Shape16T78 : Tree 11 := .split 2 q11Shape16T79 q11Shape16T82
private theorem q11Shape16T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287424 40800092160 q11Shape16T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287424 (40800092160 ||| 2^2) q11Shape16T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (27917287424 ||| 2^2) 40800092160 q11Shape16T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T79OK,q11Shape16T82OK⟩

private def q11Shape16T85 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62277025792 6440354308 q11Shape16T85=true := by decide

private def q11Shape16T86 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,9})))
private theorem q11Shape16T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62277026304 6440353796 q11Shape16T86=true := by decide

private def q11Shape16T84 : Tree 11 := .split 9 q11Shape16T85 q11Shape16T86
private theorem q11Shape16T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62277025792 6440353796 q11Shape16T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62277025792 (6440353796 ||| 2^9) q11Shape16T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (62277025792 ||| 2^9) 6440353796 q11Shape16T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T85OK,q11Shape16T86OK⟩

private def q11Shape16T87 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {2,3,4,6,8,9})))
private theorem q11Shape16T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62277025796 6440353792 q11Shape16T87=true := by decide

private def q11Shape16T83 : Tree 11 := .split 2 q11Shape16T84 q11Shape16T87
private theorem q11Shape16T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62277025792 6440353792 q11Shape16T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62277025792 (6440353792 ||| 2^2) q11Shape16T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (62277025792 ||| 2^2) 6440353792 q11Shape16T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T84OK,q11Shape16T87OK⟩

private def q11Shape16T77 : Tree 11 := .split 35 q11Shape16T78 q11Shape16T83
private theorem q11Shape16T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287424 6440353792 q11Shape16T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 27917287424 (6440353792 ||| 2^35) q11Shape16T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (27917287424 ||| 2^35) 6440353792 q11Shape16T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T78OK,q11Shape16T83OK⟩

private def q11Shape16T51 : Tree 11 := .split 33 q11Shape16T52 q11Shape16T77
private theorem q11Shape16T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 6440353792 q11Shape16T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19327352832 (6440353792 ||| 2^33) q11Shape16T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19327352832 ||| 2^33) 6440353792 q11Shape16T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T52OK,q11Shape16T77OK⟩

private def q11Shape16T49 : Tree 11 := .split 34 q11Shape16T50 q11Shape16T51
private theorem q11Shape16T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2147483648 6440353792 q11Shape16T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2147483648 (6440353792 ||| 2^34) q11Shape16T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2147483648 ||| 2^34) 6440353792 q11Shape16T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T50OK,q11Shape16T51OK⟩

def q11Shape16P1 : Tree 11 := q11Shape16T49
theorem q11Shape16P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2147483648 6440353792 q11Shape16P1=true := q11Shape16T49OK

end Graffiti384b.EffectiveSearch.Q11
