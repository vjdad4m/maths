import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T391 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape16T391OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 35230056448 q11Shape16T391=true := by decide

private def q11Shape16T396 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape16T396OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 16976445440 q11Shape16T396=true := by decide

private def q11Shape16T400 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,9,10}))))))
private theorem q11Shape16T400OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806784 33082573316 q11Shape16T400=true := by decide

private def q11Shape16T401 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,9,10})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T401OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634807296 33082572804 q11Shape16T401=true := by decide

private def q11Shape16T399 : Tree 11 := .split 9 q11Shape16T400 q11Shape16T401
private theorem q11Shape16T399OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806784 33082572804 q11Shape16T399=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806784 (33082572804 ||| 2^9) q11Shape16T400 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35634806784 ||| 2^9) 33082572804 q11Shape16T401)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T400OK,q11Shape16T401OK⟩

private def q11Shape16T402 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,9,10})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T402OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806788 33082572800 q11Shape16T402=true := by decide

private def q11Shape16T398 : Tree 11 := .split 2 q11Shape16T399 q11Shape16T402
private theorem q11Shape16T398OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806784 33082572800 q11Shape16T398=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806784 (33082572800 ||| 2^2) q11Shape16T399 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35634806784 ||| 2^2) 33082572800 q11Shape16T402)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T399OK,q11Shape16T402OK⟩

private def q11Shape16T403 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape16T403OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52814675968 15902703616 q11Shape16T403=true := by decide

private def q11Shape16T397 : Tree 11 := .split 34 q11Shape16T398 q11Shape16T403
private theorem q11Shape16T397OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806784 15902703616 q11Shape16T397=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35634806784 (15902703616 ||| 2^34) q11Shape16T398 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35634806784 ||| 2^34) 15902703616 q11Shape16T403)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T398OK,q11Shape16T403OK⟩

private def q11Shape16T395 : Tree 11 := .split 30 q11Shape16T396 q11Shape16T397
private theorem q11Shape16T395OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 15902703616 q11Shape16T395=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 (15902703616 ||| 2^30) q11Shape16T396 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34561064960 ||| 2^30) 15902703616 q11Shape16T397)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T396OK,q11Shape16T397OK⟩

private def q11Shape16T404 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape16T404OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 43150999552 7312769024 q11Shape16T404=true := by decide

private def q11Shape16T394 : Tree 11 := .split 33 q11Shape16T395 q11Shape16T404
private theorem q11Shape16T394OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 7312769024 q11Shape16T394=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 (7312769024 ||| 2^33) q11Shape16T395 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34561064960 ||| 2^33) 7312769024 q11Shape16T404)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T395OK,q11Shape16T404OK⟩

private def q11Shape16T405 : Tree 11 := (.tip (.cover {0,1,5,7,8,9}))
private theorem q11Shape16T405OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 38856032256 3017801728 q11Shape16T405=true := by decide

private def q11Shape16T393 : Tree 11 := .split 32 q11Shape16T394 q11Shape16T405
private theorem q11Shape16T393OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 3017801728 q11Shape16T393=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 (3017801728 ||| 2^32) q11Shape16T394 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34561064960 ||| 2^32) 3017801728 q11Shape16T405)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T394OK,q11Shape16T405OK⟩

private def q11Shape16T406 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape16T406OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36708548608 870318080 q11Shape16T406=true := by decide

private def q11Shape16T392 : Tree 11 := .split 31 q11Shape16T393 q11Shape16T406
private theorem q11Shape16T392OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 870318080 q11Shape16T392=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34561064960 (870318080 ||| 2^31) q11Shape16T393 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34561064960 ||| 2^31) 870318080 q11Shape16T406)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T393OK,q11Shape16T406OK⟩

private def q11Shape16T390 : Tree 11 := .split 35 q11Shape16T391 q11Shape16T392
private theorem q11Shape16T390OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 870318080 q11Shape16T390=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 (870318080 ||| 2^35) q11Shape16T391 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (201326592 ||| 2^35) 870318080 q11Shape16T392)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T391OK,q11Shape16T392OK⟩

private def q11Shape16T408 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,7,9})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape16T408OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 738197504 1407188992 q11Shape16T408=true := by decide

private def q11Shape16T409 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T409OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1811939328 333447168 q11Shape16T409=true := by decide

private def q11Shape16T407 : Tree 11 := .split 30 q11Shape16T408 q11Shape16T409
private theorem q11Shape16T407OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 738197504 333447168 q11Shape16T407=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 738197504 (333447168 ||| 2^30) q11Shape16T408 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (738197504 ||| 2^30) 333447168 q11Shape16T409)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T408OK,q11Shape16T409OK⟩

private def q11Shape16T389 : Tree 11 := .split 29 q11Shape16T390 q11Shape16T407
private theorem q11Shape16T389OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 333447168 q11Shape16T389=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 (333447168 ||| 2^29) q11Shape16T390 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (201326592 ||| 2^29) 333447168 q11Shape16T407)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T390OK,q11Shape16T407OK⟩

private def q11Shape16T412 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,8,10})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape16T412OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 469762048 1675624448 q11Shape16T412=true := by decide

private def q11Shape16T413 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape16T413OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1543503872 601882624 q11Shape16T413=true := by decide

private def q11Shape16T411 : Tree 11 := .split 30 q11Shape16T412 q11Shape16T413
private theorem q11Shape16T411OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 469762048 601882624 q11Shape16T411=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 469762048 (601882624 ||| 2^30) q11Shape16T412 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (469762048 ||| 2^30) 601882624 q11Shape16T413)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T412OK,q11Shape16T413OK⟩

private def q11Shape16T415 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape16T415OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1006632960 1138753536 q11Shape16T415=true := by decide

private def q11Shape16T416 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape16T416OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2080374784 65011712 q11Shape16T416=true := by decide

private def q11Shape16T414 : Tree 11 := .split 30 q11Shape16T415 q11Shape16T416
private theorem q11Shape16T414OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1006632960 65011712 q11Shape16T414=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1006632960 (65011712 ||| 2^30) q11Shape16T415 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1006632960 ||| 2^30) 65011712 q11Shape16T416)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T415OK,q11Shape16T416OK⟩

private def q11Shape16T410 : Tree 11 := .split 29 q11Shape16T411 q11Shape16T414
private theorem q11Shape16T410OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 469762048 65011712 q11Shape16T410=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 469762048 (65011712 ||| 2^29) q11Shape16T411 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (469762048 ||| 2^29) 65011712 q11Shape16T414)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T411OK,q11Shape16T414OK⟩

private def q11Shape16T388 : Tree 11 := .split 28 q11Shape16T389 q11Shape16T410
private theorem q11Shape16T388OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 65011712 q11Shape16T388=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 (65011712 ||| 2^28) q11Shape16T389 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (201326592 ||| 2^28) 65011712 q11Shape16T410)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T389OK,q11Shape16T410OK⟩

def q11Shape16P11 : Tree 11 := q11Shape16T388
theorem q11Shape16P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 201326592 65011712 q11Shape16P11=true := q11Shape16T388OK

private def q11Shape16T424 : Tree 11 := (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10})))
private theorem q11Shape16T424OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 2111832064 q11Shape16T424=true := by decide

private def q11Shape16T426 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,5,6,7})) (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape16T426OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1107296256 3185573888 q11Shape16T426=true := by decide

private def q11Shape16T427 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T427OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3254779904 1038090240 q11Shape16T427=true := by decide

private def q11Shape16T425 : Tree 11 := .split 31 q11Shape16T426 q11Shape16T427
private theorem q11Shape16T425OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1107296256 1038090240 q11Shape16T425=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1107296256 (1038090240 ||| 2^31) q11Shape16T426 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1107296256 ||| 2^31) 1038090240 q11Shape16T427)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T426OK,q11Shape16T427OK⟩

private def q11Shape16T423 : Tree 11 := .split 30 q11Shape16T424 q11Shape16T425
private theorem q11Shape16T423OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 1038090240 q11Shape16T423=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 (1038090240 ||| 2^30) q11Shape16T424 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (33554432 ||| 2^30) 1038090240 q11Shape16T425)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T424OK,q11Shape16T425OK⟩

private def q11Shape16T428 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T428OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 570425344 501219328 q11Shape16T428=true := by decide

private def q11Shape16T422 : Tree 11 := .split 29 q11Shape16T423 q11Shape16T428
private theorem q11Shape16T422OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 501219328 q11Shape16T422=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 (501219328 ||| 2^29) q11Shape16T423 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (33554432 ||| 2^29) 501219328 q11Shape16T428)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T423OK,q11Shape16T428OK⟩

private def q11Shape16T429 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T429OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 301989888 232783872 q11Shape16T429=true := by decide

private def q11Shape16T421 : Tree 11 := .split 28 q11Shape16T422 q11Shape16T429
private theorem q11Shape16T421OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 232783872 q11Shape16T421=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 (232783872 ||| 2^28) q11Shape16T422 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (33554432 ||| 2^28) 232783872 q11Shape16T429)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T422OK,q11Shape16T429OK⟩

private def q11Shape16T430 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T430OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 167772160 98566144 q11Shape16T430=true := by decide

private def q11Shape16T420 : Tree 11 := .split 27 q11Shape16T421 q11Shape16T430
private theorem q11Shape16T420OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 98566144 q11Shape16T420=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 (98566144 ||| 2^27) q11Shape16T421 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (33554432 ||| 2^27) 98566144 q11Shape16T430)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T421OK,q11Shape16T430OK⟩

private def q11Shape16T431 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T431OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 100663296 31457280 q11Shape16T431=true := by decide

private def q11Shape16T419 : Tree 11 := .split 26 q11Shape16T420 q11Shape16T431
private theorem q11Shape16T419OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 31457280 q11Shape16T419=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 (31457280 ||| 2^26) q11Shape16T420 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (33554432 ||| 2^26) 31457280 q11Shape16T431)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T420OK,q11Shape16T431OK⟩

def q11Shape16P12 : Tree 11 := q11Shape16T419
theorem q11Shape16P12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33554432 31457280 q11Shape16P12=true := q11Shape16T419OK

end Graffiti384b.EffectiveSearch.Q11
