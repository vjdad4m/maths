import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T439 : Tree 11 := (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10})))
private theorem q11Shape16T439OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 2128609280 q11Shape16T439=true := by decide

private def q11Shape16T441 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,5,6,7})) (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape16T441OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1090519040 3202351104 q11Shape16T441=true := by decide

private def q11Shape16T442 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T442OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3238002688 1054867456 q11Shape16T442=true := by decide

private def q11Shape16T440 : Tree 11 := .split 31 q11Shape16T441 q11Shape16T442
private theorem q11Shape16T440OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1090519040 1054867456 q11Shape16T440=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1090519040 (1054867456 ||| 2^31) q11Shape16T441 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1090519040 ||| 2^31) 1054867456 q11Shape16T442)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T441OK,q11Shape16T442OK⟩

private def q11Shape16T438 : Tree 11 := .split 30 q11Shape16T439 q11Shape16T440
private theorem q11Shape16T438OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 1054867456 q11Shape16T438=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 (1054867456 ||| 2^30) q11Shape16T439 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16777216 ||| 2^30) 1054867456 q11Shape16T440)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T439OK,q11Shape16T440OK⟩

private def q11Shape16T444 : Tree 11 := (.tip (.cover {2,3,4,6,9,10}))
private theorem q11Shape16T444OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 50331648 2095054848 q11Shape16T444=true := by decide

private def q11Shape16T450 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape16T450OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 67593306112 q11Shape16T450=true := by decide

private def q11Shape16T453 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,9})) (.tip (.cover {3,4,5,6,8,9}))))))
private theorem q11Shape16T453OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811840 33233568260 q11Shape16T453=true := by decide

private def q11Shape16T455 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,9})) (.tip (.cover {2,4,5,6,8,9}))))))
private theorem q11Shape16T455OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483812352 33233600516 q11Shape16T455=true := by decide

private def q11Shape16T456 : Tree 11 := (.split 3 (.split 19 (.split 20 (.split 10 (.split 1 (.tip (.small 1)) (.tip (.cover {1,4,5,7,8,9}))) (.split 17 (.tip (.cover {1,2,3,5,8,9})) (.tip (.cover {2,4,5,6,8,9})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T456OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483845120 33233567748 q11Shape16T456=true := by decide

private def q11Shape16T454 : Tree 11 := .split 15 q11Shape16T455 q11Shape16T456
private theorem q11Shape16T454OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483812352 33233567748 q11Shape16T454=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483812352 (33233567748 ||| 2^15) q11Shape16T455 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35483812352 ||| 2^15) 33233567748 q11Shape16T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T455OK,q11Shape16T456OK⟩

private def q11Shape16T452 : Tree 11 := .split 9 q11Shape16T453 q11Shape16T454
private theorem q11Shape16T452OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811840 33233567748 q11Shape16T452=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811840 (33233567748 ||| 2^9) q11Shape16T453 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35483811840 ||| 2^9) 33233567748 q11Shape16T454)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T453OK,q11Shape16T454OK⟩

private def q11Shape16T459 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,9})) (.tip (.cover {2,4,5,6,8,9}))))))
private theorem q11Shape16T459OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811844 33233601024 q11Shape16T459=true := by decide

private def q11Shape16T460 : Tree 11 := (.split 10 (.split 19 (.split 20 (.split 11 (.split 0 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,4,5,8,9}))) (.tip (.cover {1,2,4,5,8,9}))) (.tip (.cover {0,3,5,6,8,9}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T460OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483844612 33233568256 q11Shape16T460=true := by decide

private def q11Shape16T458 : Tree 11 := .split 15 q11Shape16T459 q11Shape16T460
private theorem q11Shape16T458OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811844 33233568256 q11Shape16T458=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811844 (33233568256 ||| 2^15) q11Shape16T459 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35483811844 ||| 2^15) 33233568256 q11Shape16T460)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T459OK,q11Shape16T460OK⟩

private def q11Shape16T461 : Tree 11 := (.split 15 (.split 16 (.split 17 (.split 1 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,3,5,8,9}))) (.tip (.cover {1,2,3,5,8,9}))) (.tip (.cover {0,4,5,6,8,9}))) (.tip (.cover {0,5,6,7,8,9}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T461OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483812356 33233567744 q11Shape16T461=true := by decide

private def q11Shape16T457 : Tree 11 := .split 9 q11Shape16T458 q11Shape16T461
private theorem q11Shape16T457OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811844 33233567744 q11Shape16T457=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811844 (33233567744 ||| 2^9) q11Shape16T458 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35483811844 ||| 2^9) 33233567744 q11Shape16T461)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T458OK,q11Shape16T461OK⟩

private def q11Shape16T451 : Tree 11 := .split 2 q11Shape16T452 q11Shape16T457
private theorem q11Shape16T451OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811840 33233567744 q11Shape16T451=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35483811840 (33233567744 ||| 2^2) q11Shape16T452 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35483811840 ||| 2^2) 33233567744 q11Shape16T457)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T452OK,q11Shape16T457OK⟩

private def q11Shape16T449 : Tree 11 := .split 35 q11Shape16T450 q11Shape16T451
private theorem q11Shape16T449OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 33233567744 q11Shape16T449=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 (33233567744 ||| 2^35) q11Shape16T450 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1124073472 ||| 2^35) 33233567744 q11Shape16T451)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T450OK,q11Shape16T451OK⟩

private def q11Shape16T462 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape16T462OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 18303942656 16053698560 q11Shape16T462=true := by decide

private def q11Shape16T448 : Tree 11 := .split 34 q11Shape16T449 q11Shape16T462
private theorem q11Shape16T448OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 16053698560 q11Shape16T448=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 (16053698560 ||| 2^34) q11Shape16T449 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1124073472 ||| 2^34) 16053698560 q11Shape16T462)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T449OK,q11Shape16T462OK⟩

private def q11Shape16T463 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape16T463OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9714008064 7463763968 q11Shape16T463=true := by decide

private def q11Shape16T447 : Tree 11 := .split 33 q11Shape16T448 q11Shape16T463
private theorem q11Shape16T447OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 7463763968 q11Shape16T447=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 (7463763968 ||| 2^33) q11Shape16T448 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1124073472 ||| 2^33) 7463763968 q11Shape16T463)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T448OK,q11Shape16T463OK⟩

private def q11Shape16T464 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T464OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5419040768 3168796672 q11Shape16T464=true := by decide

private def q11Shape16T446 : Tree 11 := .split 32 q11Shape16T447 q11Shape16T464
private theorem q11Shape16T446OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 3168796672 q11Shape16T446=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 (3168796672 ||| 2^32) q11Shape16T447 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1124073472 ||| 2^32) 3168796672 q11Shape16T464)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T447OK,q11Shape16T464OK⟩

private def q11Shape16T465 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T465OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3271557120 1021313024 q11Shape16T465=true := by decide

private def q11Shape16T445 : Tree 11 := .split 31 q11Shape16T446 q11Shape16T465
private theorem q11Shape16T445OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 1021313024 q11Shape16T445=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1124073472 (1021313024 ||| 2^31) q11Shape16T446 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1124073472 ||| 2^31) 1021313024 q11Shape16T465)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T446OK,q11Shape16T465OK⟩

private def q11Shape16T443 : Tree 11 := .split 30 q11Shape16T444 q11Shape16T445
private theorem q11Shape16T443OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 50331648 1021313024 q11Shape16T443=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 50331648 (1021313024 ||| 2^30) q11Shape16T444 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (50331648 ||| 2^30) 1021313024 q11Shape16T445)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T444OK,q11Shape16T445OK⟩

private def q11Shape16T437 : Tree 11 := .split 25 q11Shape16T438 q11Shape16T443
private theorem q11Shape16T437OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 1021313024 q11Shape16T437=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 (1021313024 ||| 2^25) q11Shape16T438 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16777216 ||| 2^25) 1021313024 q11Shape16T443)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T438OK,q11Shape16T443OK⟩

private def q11Shape16T466 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T466OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 553648128 484442112 q11Shape16T466=true := by decide

private def q11Shape16T436 : Tree 11 := .split 29 q11Shape16T437 q11Shape16T466
private theorem q11Shape16T436OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 484442112 q11Shape16T436=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 (484442112 ||| 2^29) q11Shape16T437 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16777216 ||| 2^29) 484442112 q11Shape16T466)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T437OK,q11Shape16T466OK⟩

private def q11Shape16T467 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T467OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 285212672 216006656 q11Shape16T467=true := by decide

private def q11Shape16T435 : Tree 11 := .split 28 q11Shape16T436 q11Shape16T467
private theorem q11Shape16T435OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 216006656 q11Shape16T435=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 (216006656 ||| 2^28) q11Shape16T436 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16777216 ||| 2^28) 216006656 q11Shape16T467)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T436OK,q11Shape16T467OK⟩

private def q11Shape16T468 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T468OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 150994944 81788928 q11Shape16T468=true := by decide

private def q11Shape16T434 : Tree 11 := .split 27 q11Shape16T435 q11Shape16T468
private theorem q11Shape16T434OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 81788928 q11Shape16T434=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 (81788928 ||| 2^27) q11Shape16T435 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16777216 ||| 2^27) 81788928 q11Shape16T468)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T435OK,q11Shape16T468OK⟩

private def q11Shape16T469 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T469OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 83886080 14680064 q11Shape16T469=true := by decide

private def q11Shape16T433 : Tree 11 := .split 26 q11Shape16T434 q11Shape16T469
private theorem q11Shape16T433OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 14680064 q11Shape16T433=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 (14680064 ||| 2^26) q11Shape16T434 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16777216 ||| 2^26) 14680064 q11Shape16T469)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T434OK,q11Shape16T469OK⟩

def q11Shape16P13 : Tree 11 := q11Shape16T433
theorem q11Shape16P13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16777216 14680064 q11Shape16P13=true := q11Shape16T433OK

end Graffiti384b.EffectiveSearch.Q11
