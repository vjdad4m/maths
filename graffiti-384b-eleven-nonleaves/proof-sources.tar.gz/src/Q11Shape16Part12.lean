import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T474 : Tree 11 := (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 35 (.split 32 (.tip (.cover {2,3,4,5,6,8})) (.split 34 (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,1,6,7,8,9})))) (.tip (.cover {0,1,6,7,8,10}))))
private theorem q11Shape16T474OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 4284481536 q11Shape16T474=true := by decide

private def q11Shape16T475 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.split 35 (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,1,5,6,7,10})))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape16T475OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2155872256 2136997888 q11Shape16T475=true := by decide

private def q11Shape16T473 : Tree 11 := .split 31 q11Shape16T474 q11Shape16T475
private theorem q11Shape16T473OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 2136997888 q11Shape16T473=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (2136997888 ||| 2^31) q11Shape16T474 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^31) 2136997888 q11Shape16T475)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T474OK,q11Shape16T475OK⟩

private def q11Shape16T477 : Tree 11 := (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.split 33 (.split 34 (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10})))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape16T477OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1082130432 3210739712 q11Shape16T477=true := by decide

private def q11Shape16T478 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T478OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3229614080 1063256064 q11Shape16T478=true := by decide

private def q11Shape16T476 : Tree 11 := .split 31 q11Shape16T477 q11Shape16T478
private theorem q11Shape16T476OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1082130432 1063256064 q11Shape16T476=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1082130432 (1063256064 ||| 2^31) q11Shape16T477 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1082130432 ||| 2^31) 1063256064 q11Shape16T478)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T477OK,q11Shape16T478OK⟩

private def q11Shape16T472 : Tree 11 := .split 30 q11Shape16T473 q11Shape16T476
private theorem q11Shape16T472OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 1063256064 q11Shape16T472=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (1063256064 ||| 2^30) q11Shape16T473 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^30) 1063256064 q11Shape16T476)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T473OK,q11Shape16T476OK⟩

private def q11Shape16T480 : Tree 11 := (.tip (.cover {2,3,4,6,8,10}))
private theorem q11Shape16T480OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41943040 3177185280 q11Shape16T480=true := by decide

private def q11Shape16T485 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape16T485OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 32168214528 q11Shape16T485=true := by decide

private def q11Shape16T489 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,9})) (.tip (.cover {3,4,5,6,8,9}))))))
private theorem q11Shape16T489OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295872 49348084228 q11Shape16T489=true := by decide

private def q11Shape16T491 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,9})) (.tip (.cover {2,4,5,6,8,9}))))))
private theorem q11Shape16T491OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369296384 49348116484 q11Shape16T491=true := by decide

private def q11Shape16T492 : Tree 11 := (.split 3 (.split 18 (.split 20 (.split 10 (.split 1 (.tip (.small 1)) (.tip (.cover {1,4,5,7,8,9}))) (.split 17 (.tip (.cover {1,2,3,5,8,9})) (.tip (.cover {2,4,5,6,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T492OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369329152 49348083716 q11Shape16T492=true := by decide

private def q11Shape16T490 : Tree 11 := .split 15 q11Shape16T491 q11Shape16T492
private theorem q11Shape16T490OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369296384 49348083716 q11Shape16T490=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369296384 (49348083716 ||| 2^15) q11Shape16T491 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19369296384 ||| 2^15) 49348083716 q11Shape16T492)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T491OK,q11Shape16T492OK⟩

private def q11Shape16T488 : Tree 11 := .split 9 q11Shape16T489 q11Shape16T490
private theorem q11Shape16T488OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295872 49348083716 q11Shape16T488=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295872 (49348083716 ||| 2^9) q11Shape16T489 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19369295872 ||| 2^9) 49348083716 q11Shape16T490)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T489OK,q11Shape16T490OK⟩

private def q11Shape16T495 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,9})) (.tip (.cover {2,4,5,6,8,9}))))))
private theorem q11Shape16T495OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295876 49348116992 q11Shape16T495=true := by decide

private def q11Shape16T496 : Tree 11 := (.split 10 (.split 18 (.split 20 (.split 11 (.split 0 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,4,5,8,9}))) (.tip (.cover {1,2,4,5,8,9}))) (.tip (.cover {0,3,5,6,8,9}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T496OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369328644 49348084224 q11Shape16T496=true := by decide

private def q11Shape16T494 : Tree 11 := .split 15 q11Shape16T495 q11Shape16T496
private theorem q11Shape16T494OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295876 49348084224 q11Shape16T494=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295876 (49348084224 ||| 2^15) q11Shape16T495 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19369295876 ||| 2^15) 49348084224 q11Shape16T496)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T495OK,q11Shape16T496OK⟩

private def q11Shape16T497 : Tree 11 := (.split 15 (.split 16 (.split 17 (.split 1 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,3,5,8,9}))) (.tip (.cover {1,2,3,5,8,9}))) (.tip (.cover {0,4,5,6,8,9}))) (.tip (.cover {0,5,6,7,8,9}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T497OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369296388 49348083712 q11Shape16T497=true := by decide

private def q11Shape16T493 : Tree 11 := .split 9 q11Shape16T494 q11Shape16T497
private theorem q11Shape16T493OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295876 49348083712 q11Shape16T493=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295876 (49348083712 ||| 2^9) q11Shape16T494 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19369295876 ||| 2^9) 49348083712 q11Shape16T497)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T494OK,q11Shape16T497OK⟩

private def q11Shape16T487 : Tree 11 := .split 2 q11Shape16T488 q11Shape16T493
private theorem q11Shape16T487OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295872 49348083712 q11Shape16T487=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295872 (49348083712 ||| 2^2) q11Shape16T488 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19369295872 ||| 2^2) 49348083712 q11Shape16T493)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T488OK,q11Shape16T493OK⟩

private def q11Shape16T498 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape16T498OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53729034240 14988345344 q11Shape16T498=true := by decide

private def q11Shape16T486 : Tree 11 := .split 35 q11Shape16T487 q11Shape16T498
private theorem q11Shape16T486OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295872 14988345344 q11Shape16T486=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19369295872 (14988345344 ||| 2^35) q11Shape16T487 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19369295872 ||| 2^35) 14988345344 q11Shape16T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T487OK,q11Shape16T498OK⟩

private def q11Shape16T484 : Tree 11 := .split 34 q11Shape16T485 q11Shape16T486
private theorem q11Shape16T484OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 14988345344 q11Shape16T484=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 (14988345344 ||| 2^34) q11Shape16T485 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2189426688 ||| 2^34) 14988345344 q11Shape16T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T485OK,q11Shape16T486OK⟩

private def q11Shape16T499 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape16T499OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10779361280 6398410752 q11Shape16T499=true := by decide

private def q11Shape16T483 : Tree 11 := .split 33 q11Shape16T484 q11Shape16T499
private theorem q11Shape16T483OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 6398410752 q11Shape16T483=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 (6398410752 ||| 2^33) q11Shape16T484 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2189426688 ||| 2^33) 6398410752 q11Shape16T499)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T484OK,q11Shape16T499OK⟩

private def q11Shape16T500 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T500OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6484393984 2103443456 q11Shape16T500=true := by decide

private def q11Shape16T482 : Tree 11 := .split 32 q11Shape16T483 q11Shape16T500
private theorem q11Shape16T482OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 2103443456 q11Shape16T482=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 (2103443456 ||| 2^32) q11Shape16T483 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2189426688 ||| 2^32) 2103443456 q11Shape16T500)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T483OK,q11Shape16T500OK⟩

private def q11Shape16T501 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T501OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3263168512 1029701632 q11Shape16T501=true := by decide

private def q11Shape16T481 : Tree 11 := .split 30 q11Shape16T482 q11Shape16T501
private theorem q11Shape16T481OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 1029701632 q11Shape16T481=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2189426688 (1029701632 ||| 2^30) q11Shape16T482 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2189426688 ||| 2^30) 1029701632 q11Shape16T501)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T482OK,q11Shape16T501OK⟩

private def q11Shape16T479 : Tree 11 := .split 31 q11Shape16T480 q11Shape16T481
private theorem q11Shape16T479OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41943040 1029701632 q11Shape16T479=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41943040 (1029701632 ||| 2^31) q11Shape16T480 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (41943040 ||| 2^31) 1029701632 q11Shape16T481)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T480OK,q11Shape16T481OK⟩

private def q11Shape16T471 : Tree 11 := .split 25 q11Shape16T472 q11Shape16T479
private theorem q11Shape16T471OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 1029701632 q11Shape16T471=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 (1029701632 ||| 2^25) q11Shape16T472 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8388608 ||| 2^25) 1029701632 q11Shape16T479)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T472OK,q11Shape16T479OK⟩

def q11Shape16P14 : Tree 11 := q11Shape16T471
theorem q11Shape16P14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8388608 1029701632 q11Shape16P14=true := q11Shape16T471OK

end Graffiti384b.EffectiveSearch.Q11
