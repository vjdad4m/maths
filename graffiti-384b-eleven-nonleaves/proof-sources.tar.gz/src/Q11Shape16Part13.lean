import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T504 : Tree 11 := (.tip (.cover {2,3,4,6,8,9}))
private theorem q11Shape16T504OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25165824 5341446144 q11Shape16T504=true := by decide

private def q11Shape16T508 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape16T508OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4320133120 12857638912 q11Shape16T508=true := by decide

private def q11Shape16T513 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {3,4,5,6,8,10}))))))
private theorem q11Shape16T513OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 55807312388 q11Shape16T513=true := by decide

private def q11Shape16T515 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {2,4,5,6,8,10}))))))
private theorem q11Shape16T515OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910068224 55807344644 q11Shape16T515=true := by decide

private def q11Shape16T516 : Tree 11 := (.split 3 (.split 18 (.split 19 (.split 10 (.split 1 (.tip (.small 1)) (.tip (.cover {1,4,5,7,8,10}))) (.split 17 (.tip (.cover {1,2,3,5,8,10})) (.tip (.cover {2,4,5,6,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {0,5,6,7,8,10})))
private theorem q11Shape16T516OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910100992 55807311876 q11Shape16T516=true := by decide

private def q11Shape16T514 : Tree 11 := .split 15 q11Shape16T515 q11Shape16T516
private theorem q11Shape16T514OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910068224 55807311876 q11Shape16T514=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910068224 (55807311876 ||| 2^15) q11Shape16T515 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12910068224 ||| 2^15) 55807311876 q11Shape16T516)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T515OK,q11Shape16T516OK⟩

private def q11Shape16T512 : Tree 11 := .split 9 q11Shape16T513 q11Shape16T514
private theorem q11Shape16T512OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 55807311876 q11Shape16T512=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 (55807311876 ||| 2^9) q11Shape16T513 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12910067712 ||| 2^9) 55807311876 q11Shape16T514)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T513OK,q11Shape16T514OK⟩

private def q11Shape16T519 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {2,4,5,6,8,10}))))))
private theorem q11Shape16T519OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067716 55807345152 q11Shape16T519=true := by decide

private def q11Shape16T520 : Tree 11 := (.split 10 (.split 18 (.split 19 (.split 11 (.split 0 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,4,5,8,10}))) (.tip (.cover {1,2,4,5,8,10}))) (.tip (.cover {0,3,5,6,8,10}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {0,5,6,7,8,10})))
private theorem q11Shape16T520OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910100484 55807312384 q11Shape16T520=true := by decide

private def q11Shape16T518 : Tree 11 := .split 15 q11Shape16T519 q11Shape16T520
private theorem q11Shape16T518OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067716 55807312384 q11Shape16T518=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067716 (55807312384 ||| 2^15) q11Shape16T519 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12910067716 ||| 2^15) 55807312384 q11Shape16T520)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T519OK,q11Shape16T520OK⟩

private def q11Shape16T521 : Tree 11 := (.split 15 (.split 16 (.split 17 (.split 1 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,3,5,8,10}))) (.tip (.cover {1,2,3,5,8,10}))) (.tip (.cover {0,4,5,6,8,10}))) (.tip (.cover {0,5,6,7,8,10}))) (.tip (.cover {0,5,6,7,8,10})))
private theorem q11Shape16T521OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910068228 55807311872 q11Shape16T521=true := by decide

private def q11Shape16T517 : Tree 11 := .split 9 q11Shape16T518 q11Shape16T521
private theorem q11Shape16T517OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067716 55807311872 q11Shape16T517=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067716 (55807311872 ||| 2^9) q11Shape16T518 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12910067716 ||| 2^9) 55807311872 q11Shape16T521)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T518OK,q11Shape16T521OK⟩

private def q11Shape16T511 : Tree 11 := .split 2 q11Shape16T512 q11Shape16T517
private theorem q11Shape16T511OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 55807311872 q11Shape16T511=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 (55807311872 ||| 2^2) q11Shape16T512 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12910067712 ||| 2^2) 55807311872 q11Shape16T517)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T512OK,q11Shape16T517OK⟩

private def q11Shape16T522 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape16T522OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47269806080 21447573504 q11Shape16T522=true := by decide

private def q11Shape16T510 : Tree 11 := .split 35 q11Shape16T511 q11Shape16T522
private theorem q11Shape16T510OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 21447573504 q11Shape16T510=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 (21447573504 ||| 2^35) q11Shape16T511 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12910067712 ||| 2^35) 21447573504 q11Shape16T522)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T511OK,q11Shape16T522OK⟩

private def q11Shape16T523 : Tree 11 := (.tip (.cover {0,1,5,6,7,8}))
private theorem q11Shape16T523OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30089936896 4267704320 q11Shape16T523=true := by decide

private def q11Shape16T509 : Tree 11 := .split 34 q11Shape16T510 q11Shape16T523
private theorem q11Shape16T509OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 4267704320 q11Shape16T509=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12910067712 (4267704320 ||| 2^34) q11Shape16T510 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12910067712 ||| 2^34) 4267704320 q11Shape16T523)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T510OK,q11Shape16T523OK⟩

private def q11Shape16T507 : Tree 11 := .split 33 q11Shape16T508 q11Shape16T509
private theorem q11Shape16T507OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4320133120 4267704320 q11Shape16T507=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4320133120 (4267704320 ||| 2^33) q11Shape16T508 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4320133120 ||| 2^33) 4267704320 q11Shape16T509)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T508OK,q11Shape16T509OK⟩

private def q11Shape16T524 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T524OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6467616768 2120220672 q11Shape16T524=true := by decide

private def q11Shape16T506 : Tree 11 := .split 31 q11Shape16T507 q11Shape16T524
private theorem q11Shape16T506OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4320133120 2120220672 q11Shape16T506=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4320133120 (2120220672 ||| 2^31) q11Shape16T507 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4320133120 ||| 2^31) 2120220672 q11Shape16T524)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T507OK,q11Shape16T524OK⟩

private def q11Shape16T525 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape16T525OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5393874944 1046478848 q11Shape16T525=true := by decide

private def q11Shape16T505 : Tree 11 := .split 30 q11Shape16T506 q11Shape16T525
private theorem q11Shape16T505OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4320133120 1046478848 q11Shape16T505=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4320133120 (1046478848 ||| 2^30) q11Shape16T506 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4320133120 ||| 2^30) 1046478848 q11Shape16T525)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T506OK,q11Shape16T525OK⟩

private def q11Shape16T503 : Tree 11 := .split 32 q11Shape16T504 q11Shape16T505
private theorem q11Shape16T503OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25165824 1046478848 q11Shape16T503=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25165824 (1046478848 ||| 2^32) q11Shape16T504 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (25165824 ||| 2^32) 1046478848 q11Shape16T505)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T504OK,q11Shape16T505OK⟩

private def q11Shape16T527 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape16T527OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 58720256 2086666240 q11Shape16T527=true := by decide

private def q11Shape16T528 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape16T528OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1132462080 1012924416 q11Shape16T528=true := by decide

private def q11Shape16T526 : Tree 11 := .split 30 q11Shape16T527 q11Shape16T528
private theorem q11Shape16T526OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 58720256 1012924416 q11Shape16T526=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 58720256 (1012924416 ||| 2^30) q11Shape16T527 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (58720256 ||| 2^30) 1012924416 q11Shape16T528)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T527OK,q11Shape16T528OK⟩

private def q11Shape16T502 : Tree 11 := .split 25 q11Shape16T503 q11Shape16T526
private theorem q11Shape16T502OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25165824 1012924416 q11Shape16T502=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25165824 (1012924416 ||| 2^25) q11Shape16T503 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (25165824 ||| 2^25) 1012924416 q11Shape16T526)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T503OK,q11Shape16T526OK⟩

def q11Shape16P15 : Tree 11 := q11Shape16T502
theorem q11Shape16P15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25165824 1012924416 q11Shape16P15=true := q11Shape16T502OK

private def q11Shape16T530 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T530OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 545259520 476053504 q11Shape16T530=true := by decide

def q11Shape16P16 : Tree 11 := q11Shape16T530
theorem q11Shape16P16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 545259520 476053504 q11Shape16P16=true := q11Shape16T530OK

private def q11Shape16T532 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T532OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 276824064 207618048 q11Shape16T532=true := by decide

def q11Shape16P17 : Tree 11 := q11Shape16T532
theorem q11Shape16P17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 276824064 207618048 q11Shape16P17=true := q11Shape16T532OK

private def q11Shape16T534 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T534OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 142606336 73400320 q11Shape16T534=true := by decide

def q11Shape16P18 : Tree 11 := q11Shape16T534
theorem q11Shape16P18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 142606336 73400320 q11Shape16P18=true := q11Shape16T534OK

private def q11Shape16T536 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T536OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 75497472 6291456 q11Shape16T536=true := by decide

def q11Shape16P19 : Tree 11 := q11Shape16T536
theorem q11Shape16P19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 75497472 6291456 q11Shape16P19=true := q11Shape16T536OK

end Graffiti384b.EffectiveSearch.Q11
