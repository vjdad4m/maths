import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T542 : Tree 11 := (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.split 32 (.tip (.cover {2,3,4,5,6,9})) (.split 35 (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,1,5,6,8,10})))) (.tip (.cover {0,1,6,7,9,10}))))
private theorem q11Shape16T542OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 4288675840 q11Shape16T542=true := by decide

private def q11Shape16T543 : Tree 11 := (.split 33 (.split 35 (.split 34 (.tip (.cover {2,3,4,5,6,7})) (.split 32 (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,1,6,7,8,9})))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,10})))
private theorem q11Shape16T543OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2151677952 2141192192 q11Shape16T543=true := by decide

private def q11Shape16T541 : Tree 11 := .split 31 q11Shape16T542 q11Shape16T543
private theorem q11Shape16T541OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 2141192192 q11Shape16T541=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (2141192192 ||| 2^31) q11Shape16T542 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^31) 2141192192 q11Shape16T543)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T542OK,q11Shape16T543OK⟩

private def q11Shape16T545 : Tree 11 := (.split 34 (.split 35 (.tip (.cover {2,3,4,5,6,7})) (.split 31 (.split 32 (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10})))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape16T545OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1077936128 9657384960 q11Shape16T545=true := by decide

private def q11Shape16T546 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape16T546OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9667870720 1067450368 q11Shape16T546=true := by decide

private def q11Shape16T544 : Tree 11 := .split 33 q11Shape16T545 q11Shape16T546
private theorem q11Shape16T544OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1077936128 1067450368 q11Shape16T544=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1077936128 (1067450368 ||| 2^33) q11Shape16T545 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1077936128 ||| 2^33) 1067450368 q11Shape16T546)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T545OK,q11Shape16T546OK⟩

private def q11Shape16T540 : Tree 11 := .split 30 q11Shape16T541 q11Shape16T544
private theorem q11Shape16T540OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 1067450368 q11Shape16T540=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (1067450368 ||| 2^30) q11Shape16T541 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^30) 1067450368 q11Shape16T544)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T541OK,q11Shape16T544OK⟩

private def q11Shape16T548 : Tree 11 := (.tip (.cover {2,3,4,6,7,10}))
private theorem q11Shape16T548OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37748736 9623830528 q11Shape16T548=true := by decide

private def q11Shape16T553 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape16T553OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 25729957888 q11Shape16T553=true := by decide

private def q11Shape16T557 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 18 (.tip (.cover {2,3,5,6,7,9})) (.tip (.cover {3,4,5,6,7,9}))))))
private theorem q11Shape16T557OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650624 55794729476 q11Shape16T557=true := by decide

private def q11Shape16T560 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 18 (.tip (.cover {2,3,5,6,7,9})) (.tip (.cover {2,4,5,6,7,9}))))))
private theorem q11Shape16T560OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922651136 55794892804 q11Shape16T560=true := by decide

private def q11Shape16T561 : Tree 11 := (.split 3 (.split 20 (.split 11 (.split 10 (.split 1 (.tip (.small 1)) (.tip (.cover {1,4,5,7,8,9}))) (.split 18 (.tip (.cover {1,2,3,5,7,9})) (.tip (.cover {2,4,5,6,7,9})))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T561OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922683904 55794860036 q11Shape16T561=true := by decide

private def q11Shape16T559 : Tree 11 := .split 15 q11Shape16T560 q11Shape16T561
private theorem q11Shape16T559OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922651136 55794860036 q11Shape16T559=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922651136 (55794860036 ||| 2^15) q11Shape16T560 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922651136 ||| 2^15) 55794860036 q11Shape16T561)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T560OK,q11Shape16T561OK⟩

private def q11Shape16T562 : Tree 11 := (.tip (.cover {2,3,4,6,8,10}))
private theorem q11Shape16T562OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922782208 55794728964 q11Shape16T562=true := by decide

private def q11Shape16T558 : Tree 11 := .split 17 q11Shape16T559 q11Shape16T562
private theorem q11Shape16T558OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922651136 55794728964 q11Shape16T558=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922651136 (55794728964 ||| 2^17) q11Shape16T559 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922651136 ||| 2^17) 55794728964 q11Shape16T562)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T559OK,q11Shape16T562OK⟩

private def q11Shape16T556 : Tree 11 := .split 9 q11Shape16T557 q11Shape16T558
private theorem q11Shape16T556OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650624 55794728964 q11Shape16T556=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650624 (55794728964 ||| 2^9) q11Shape16T557 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922650624 ||| 2^9) 55794728964 q11Shape16T558)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T557OK,q11Shape16T558OK⟩

private def q11Shape16T566 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 18 (.tip (.cover {2,3,5,6,7,9})) (.tip (.cover {2,4,5,6,7,9}))))))
private theorem q11Shape16T566OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650628 55794893312 q11Shape16T566=true := by decide

private def q11Shape16T567 : Tree 11 := (.split 10 (.split 20 (.split 11 (.split 12 (.split 0 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,4,5,7,9}))) (.tip (.cover {1,2,4,5,7,9}))) (.tip (.cover {0,3,5,6,7,9}))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T567OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922683396 55794860544 q11Shape16T567=true := by decide

private def q11Shape16T565 : Tree 11 := .split 15 q11Shape16T566 q11Shape16T567
private theorem q11Shape16T565OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650628 55794860544 q11Shape16T565=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650628 (55794860544 ||| 2^15) q11Shape16T566 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922650628 ||| 2^15) 55794860544 q11Shape16T567)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T566OK,q11Shape16T567OK⟩

private def q11Shape16T568 : Tree 11 := (.tip (.cover {2,3,4,6,8,10}))
private theorem q11Shape16T568OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922781700 55794729472 q11Shape16T568=true := by decide

private def q11Shape16T564 : Tree 11 := .split 17 q11Shape16T565 q11Shape16T568
private theorem q11Shape16T564OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650628 55794729472 q11Shape16T564=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650628 (55794729472 ||| 2^17) q11Shape16T565 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922650628 ||| 2^17) 55794729472 q11Shape16T568)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T565OK,q11Shape16T568OK⟩

private def q11Shape16T569 : Tree 11 := (.split 15 (.split 16 (.split 17 (.split 18 (.split 1 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,3,5,7,9}))) (.tip (.cover {1,2,3,5,7,9}))) (.tip (.cover {0,4,5,6,7,9}))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {0,5,6,7,8,9}))) (.tip (.cover {0,5,6,7,8,9})))
private theorem q11Shape16T569OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922651140 55794728960 q11Shape16T569=true := by decide

private def q11Shape16T563 : Tree 11 := .split 9 q11Shape16T564 q11Shape16T569
private theorem q11Shape16T563OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650628 55794728960 q11Shape16T563=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650628 (55794728960 ||| 2^9) q11Shape16T564 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922650628 ||| 2^9) 55794728960 q11Shape16T569)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T564OK,q11Shape16T569OK⟩

private def q11Shape16T555 : Tree 11 := .split 2 q11Shape16T556 q11Shape16T563
private theorem q11Shape16T555OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650624 55794728960 q11Shape16T555=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650624 (55794728960 ||| 2^2) q11Shape16T556 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922650624 ||| 2^2) 55794728960 q11Shape16T563)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T556OK,q11Shape16T563OK⟩

private def q11Shape16T570 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape16T570OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47282388992 21434990592 q11Shape16T570=true := by decide

private def q11Shape16T554 : Tree 11 := .split 35 q11Shape16T555 q11Shape16T570
private theorem q11Shape16T554OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650624 21434990592 q11Shape16T554=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12922650624 (21434990592 ||| 2^35) q11Shape16T555 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12922650624 ||| 2^35) 21434990592 q11Shape16T570)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T555OK,q11Shape16T570OK⟩

private def q11Shape16T552 : Tree 11 := .split 32 q11Shape16T553 q11Shape16T554
private theorem q11Shape16T552OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 21434990592 q11Shape16T552=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 (21434990592 ||| 2^32) q11Shape16T553 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8627683328 ||| 2^32) 21434990592 q11Shape16T554)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T553OK,q11Shape16T554OK⟩

private def q11Shape16T571 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape16T571OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25807552512 4255121408 q11Shape16T571=true := by decide

private def q11Shape16T551 : Tree 11 := .split 34 q11Shape16T552 q11Shape16T571
private theorem q11Shape16T551OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 4255121408 q11Shape16T551=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 (4255121408 ||| 2^34) q11Shape16T552 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8627683328 ||| 2^34) 4255121408 q11Shape16T571)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T552OK,q11Shape16T571OK⟩

private def q11Shape16T572 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape16T572OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10775166976 2107637760 q11Shape16T572=true := by decide

private def q11Shape16T550 : Tree 11 := .split 31 q11Shape16T551 q11Shape16T572
private theorem q11Shape16T550OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 2107637760 q11Shape16T550=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 (2107637760 ||| 2^31) q11Shape16T551 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8627683328 ||| 2^31) 2107637760 q11Shape16T572)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T551OK,q11Shape16T572OK⟩

private def q11Shape16T573 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape16T573OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9701425152 1033895936 q11Shape16T573=true := by decide

private def q11Shape16T549 : Tree 11 := .split 30 q11Shape16T550 q11Shape16T573
private theorem q11Shape16T549OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 1033895936 q11Shape16T549=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 8627683328 (1033895936 ||| 2^30) q11Shape16T550 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (8627683328 ||| 2^30) 1033895936 q11Shape16T573)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T550OK,q11Shape16T573OK⟩

private def q11Shape16T547 : Tree 11 := .split 33 q11Shape16T548 q11Shape16T549
private theorem q11Shape16T547OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37748736 1033895936 q11Shape16T547=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37748736 (1033895936 ||| 2^33) q11Shape16T548 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (37748736 ||| 2^33) 1033895936 q11Shape16T549)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T548OK,q11Shape16T549OK⟩

private def q11Shape16T539 : Tree 11 := .split 25 q11Shape16T540 q11Shape16T547
private theorem q11Shape16T539OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 1033895936 q11Shape16T539=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 (1033895936 ||| 2^25) q11Shape16T540 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4194304 ||| 2^25) 1033895936 q11Shape16T547)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T540OK,q11Shape16T547OK⟩

def q11Shape16P20 : Tree 11 := q11Shape16T539
theorem q11Shape16P20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4194304 1033895936 q11Shape16P20=true := q11Shape16T539OK

end Graffiti384b.EffectiveSearch.Q11
