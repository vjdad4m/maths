import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T576 : Tree 11 := (.tip (.cover {2,3,4,6,7,9}))
private theorem q11Shape16T576OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20971520 18230542336 q11Shape16T576=true := by decide

private def q11Shape16T581 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape16T581OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 17156800512 q11Shape16T581=true := by decide

private def q11Shape16T585 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 18 (.tip (.cover {2,3,5,6,7,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape16T585OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324352 49369055748 q11Shape16T585=true := by decide

private def q11Shape16T588 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 18 (.tip (.cover {2,3,5,6,7,10})) (.tip (.cover {2,4,5,6,7,10}))))))
private theorem q11Shape16T588OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324864 49369219076 q11Shape16T588=true := by decide

private def q11Shape16T589 : Tree 11 := (.split 3 (.split 19 (.split 11 (.split 10 (.split 1 (.tip (.small 1)) (.tip (.cover {1,4,5,7,8,10}))) (.split 18 (.tip (.cover {1,2,3,5,7,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,5,6,7,8,10})))
private theorem q11Shape16T589OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348357632 49369186308 q11Shape16T589=true := by decide

private def q11Shape16T587 : Tree 11 := .split 15 q11Shape16T588 q11Shape16T589
private theorem q11Shape16T587OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324864 49369186308 q11Shape16T587=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324864 (49369186308 ||| 2^15) q11Shape16T588 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324864 ||| 2^15) 49369186308 q11Shape16T589)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T588OK,q11Shape16T589OK⟩

private def q11Shape16T590 : Tree 11 := (.tip (.cover {2,3,4,6,8,9}))
private theorem q11Shape16T590OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348455936 49369055236 q11Shape16T590=true := by decide

private def q11Shape16T586 : Tree 11 := .split 17 q11Shape16T587 q11Shape16T590
private theorem q11Shape16T586OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324864 49369055236 q11Shape16T586=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324864 (49369055236 ||| 2^17) q11Shape16T587 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324864 ||| 2^17) 49369055236 q11Shape16T590)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T587OK,q11Shape16T590OK⟩

private def q11Shape16T584 : Tree 11 := .split 9 q11Shape16T585 q11Shape16T586
private theorem q11Shape16T584OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324352 49369055236 q11Shape16T584=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324352 (49369055236 ||| 2^9) q11Shape16T585 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324352 ||| 2^9) 49369055236 q11Shape16T586)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T585OK,q11Shape16T586OK⟩

private def q11Shape16T594 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 18 (.tip (.cover {2,3,5,6,7,10})) (.tip (.cover {2,4,5,6,7,10}))))))
private theorem q11Shape16T594OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324356 49369219584 q11Shape16T594=true := by decide

private def q11Shape16T595 : Tree 11 := (.split 10 (.split 19 (.split 11 (.split 12 (.split 0 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,4,5,7,10}))) (.tip (.cover {1,2,4,5,7,10}))) (.tip (.cover {0,3,5,6,7,10}))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {0,5,6,7,8,10})))
private theorem q11Shape16T595OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348357124 49369186816 q11Shape16T595=true := by decide

private def q11Shape16T593 : Tree 11 := .split 15 q11Shape16T594 q11Shape16T595
private theorem q11Shape16T593OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324356 49369186816 q11Shape16T593=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324356 (49369186816 ||| 2^15) q11Shape16T594 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324356 ||| 2^15) 49369186816 q11Shape16T595)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T594OK,q11Shape16T595OK⟩

private def q11Shape16T596 : Tree 11 := (.tip (.cover {2,3,4,6,8,9}))
private theorem q11Shape16T596OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348455428 49369055744 q11Shape16T596=true := by decide

private def q11Shape16T592 : Tree 11 := .split 17 q11Shape16T593 q11Shape16T596
private theorem q11Shape16T592OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324356 49369055744 q11Shape16T592=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324356 (49369055744 ||| 2^17) q11Shape16T593 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324356 ||| 2^17) 49369055744 q11Shape16T596)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T593OK,q11Shape16T596OK⟩

private def q11Shape16T597 : Tree 11 := (.split 15 (.split 16 (.split 17 (.split 18 (.split 1 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,3,5,7,10}))) (.tip (.cover {1,2,3,5,7,10}))) (.tip (.cover {0,4,5,6,7,10}))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {0,5,6,7,8,10}))) (.tip (.cover {0,5,6,7,8,10})))
private theorem q11Shape16T597OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324868 49369055232 q11Shape16T597=true := by decide

private def q11Shape16T591 : Tree 11 := .split 9 q11Shape16T592 q11Shape16T597
private theorem q11Shape16T591OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324356 49369055232 q11Shape16T591=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324356 (49369055232 ||| 2^9) q11Shape16T592 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324356 ||| 2^9) 49369055232 q11Shape16T597)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T592OK,q11Shape16T597OK⟩

private def q11Shape16T583 : Tree 11 := .split 2 q11Shape16T584 q11Shape16T591
private theorem q11Shape16T583OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324352 49369055232 q11Shape16T583=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324352 (49369055232 ||| 2^2) q11Shape16T584 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324352 ||| 2^2) 49369055232 q11Shape16T591)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T584OK,q11Shape16T591OK⟩

private def q11Shape16T598 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape16T598OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 53708062720 15009316864 q11Shape16T598=true := by decide

private def q11Shape16T582 : Tree 11 := .split 35 q11Shape16T583 q11Shape16T598
private theorem q11Shape16T582OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324352 15009316864 q11Shape16T582=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19348324352 (15009316864 ||| 2^35) q11Shape16T583 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19348324352 ||| 2^35) 15009316864 q11Shape16T598)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T583OK,q11Shape16T598OK⟩

private def q11Shape16T580 : Tree 11 := .split 31 q11Shape16T581 q11Shape16T582
private theorem q11Shape16T580OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 15009316864 q11Shape16T580=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 (15009316864 ||| 2^31) q11Shape16T581 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17200840704 ||| 2^31) 15009316864 q11Shape16T582)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T581OK,q11Shape16T582OK⟩

private def q11Shape16T599 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape16T599OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 25790775296 6419382272 q11Shape16T599=true := by decide

private def q11Shape16T579 : Tree 11 := .split 33 q11Shape16T580 q11Shape16T599
private theorem q11Shape16T579OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 6419382272 q11Shape16T579=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 (6419382272 ||| 2^33) q11Shape16T580 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17200840704 ||| 2^33) 6419382272 q11Shape16T599)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T580OK,q11Shape16T599OK⟩

private def q11Shape16T600 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape16T600OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 21495808000 2124414976 q11Shape16T600=true := by decide

private def q11Shape16T578 : Tree 11 := .split 32 q11Shape16T579 q11Shape16T600
private theorem q11Shape16T578OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 2124414976 q11Shape16T578=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 (2124414976 ||| 2^32) q11Shape16T579 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17200840704 ||| 2^32) 2124414976 q11Shape16T600)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T579OK,q11Shape16T600OK⟩

private def q11Shape16T601 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape16T601OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 18274582528 1050673152 q11Shape16T601=true := by decide

private def q11Shape16T577 : Tree 11 := .split 30 q11Shape16T578 q11Shape16T601
private theorem q11Shape16T577OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 1050673152 q11Shape16T577=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17200840704 (1050673152 ||| 2^30) q11Shape16T578 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17200840704 ||| 2^30) 1050673152 q11Shape16T601)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T578OK,q11Shape16T601OK⟩

private def q11Shape16T575 : Tree 11 := .split 34 q11Shape16T576 q11Shape16T577
private theorem q11Shape16T575OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20971520 1050673152 q11Shape16T575=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20971520 (1050673152 ||| 2^34) q11Shape16T576 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (20971520 ||| 2^34) 1050673152 q11Shape16T577)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T576OK,q11Shape16T577OK⟩

private def q11Shape16T603 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape16T603OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 54525952 2090860544 q11Shape16T603=true := by decide

private def q11Shape16T604 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape16T604OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1128267776 1017118720 q11Shape16T604=true := by decide

private def q11Shape16T602 : Tree 11 := .split 30 q11Shape16T603 q11Shape16T604
private theorem q11Shape16T602OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 54525952 1017118720 q11Shape16T602=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 54525952 (1017118720 ||| 2^30) q11Shape16T603 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (54525952 ||| 2^30) 1017118720 q11Shape16T604)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T603OK,q11Shape16T604OK⟩

private def q11Shape16T574 : Tree 11 := .split 25 q11Shape16T575 q11Shape16T602
private theorem q11Shape16T574OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20971520 1017118720 q11Shape16T574=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20971520 (1017118720 ||| 2^25) q11Shape16T575 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (20971520 ||| 2^25) 1017118720 q11Shape16T602)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T575OK,q11Shape16T602OK⟩

def q11Shape16P21 : Tree 11 := q11Shape16T574
theorem q11Shape16P21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20971520 1017118720 q11Shape16P21=true := q11Shape16T574OK

end Graffiti384b.EffectiveSearch.Q11
