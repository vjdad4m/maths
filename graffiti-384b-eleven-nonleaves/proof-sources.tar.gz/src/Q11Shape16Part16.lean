import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T609 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape16T609OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 35418800128 q11Shape16T609=true := by decide

private def q11Shape16T614 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape16T614OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 17165189120 q11Shape16T614=true := by decide

private def q11Shape16T618 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 19 (.tip (.cover {2,3,5,6,7,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape16T618OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063104 33271316996 q11Shape16T618=true := by decide

private def q11Shape16T622 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 19 (.tip (.cover {2,3,5,6,7,10})) (.tip (.cover {2,4,5,6,7,10}))))))
private theorem q11Shape16T622OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063616 33271742468 q11Shape16T622=true := by decide

private def q11Shape16T623 : Tree 11 := (.split 3 (.split 11 (.split 12 (.split 10 (.split 1 (.tip (.small 1)) (.tip (.cover {1,4,5,7,9,10}))) (.split 19 (.tip (.cover {1,2,3,5,7,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {0,5,6,7,9,10})))
private theorem q11Shape16T623OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446096384 33271709700 q11Shape16T623=true := by decide

private def q11Shape16T621 : Tree 11 := .split 15 q11Shape16T622 q11Shape16T623
private theorem q11Shape16T621OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063616 33271709700 q11Shape16T621=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063616 (33271709700 ||| 2^15) q11Shape16T622 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063616 ||| 2^15) 33271709700 q11Shape16T623)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T622OK,q11Shape16T623OK⟩

private def q11Shape16T624 : Tree 11 := (.tip (.cover {2,3,4,6,7,9}))
private theorem q11Shape16T624OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446325760 33271447556 q11Shape16T624=true := by decide

private def q11Shape16T620 : Tree 11 := .split 18 q11Shape16T621 q11Shape16T624
private theorem q11Shape16T620OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063616 33271447556 q11Shape16T620=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063616 (33271447556 ||| 2^18) q11Shape16T621 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063616 ||| 2^18) 33271447556 q11Shape16T624)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T621OK,q11Shape16T624OK⟩

private def q11Shape16T625 : Tree 11 := (.tip (.cover {2,3,4,6,8,9}))
private theorem q11Shape16T625OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446194688 33271316484 q11Shape16T625=true := by decide

private def q11Shape16T619 : Tree 11 := .split 17 q11Shape16T620 q11Shape16T625
private theorem q11Shape16T619OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063616 33271316484 q11Shape16T619=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063616 (33271316484 ||| 2^17) q11Shape16T620 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063616 ||| 2^17) 33271316484 q11Shape16T625)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T620OK,q11Shape16T625OK⟩

private def q11Shape16T617 : Tree 11 := .split 9 q11Shape16T618 q11Shape16T619
private theorem q11Shape16T617OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063104 33271316484 q11Shape16T617=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063104 (33271316484 ||| 2^9) q11Shape16T618 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063104 ||| 2^9) 33271316484 q11Shape16T619)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T618OK,q11Shape16T619OK⟩

private def q11Shape16T630 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 19 (.tip (.cover {2,3,5,6,7,10})) (.tip (.cover {2,4,5,6,7,10}))))))
private theorem q11Shape16T630OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 33271742976 q11Shape16T630=true := by decide

private def q11Shape16T631 : Tree 11 := (.split 10 (.split 11 (.split 12 (.split 13 (.split 0 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,4,5,7,10}))) (.tip (.cover {1,2,4,5,7,10}))) (.tip (.cover {0,3,5,6,7,10}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {0,5,6,7,9,10})))
private theorem q11Shape16T631OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446095876 33271710208 q11Shape16T631=true := by decide

private def q11Shape16T629 : Tree 11 := .split 15 q11Shape16T630 q11Shape16T631
private theorem q11Shape16T629OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 33271710208 q11Shape16T629=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 (33271710208 ||| 2^15) q11Shape16T630 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063108 ||| 2^15) 33271710208 q11Shape16T631)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T630OK,q11Shape16T631OK⟩

private def q11Shape16T632 : Tree 11 := (.tip (.cover {2,3,4,6,7,9}))
private theorem q11Shape16T632OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446325252 33271448064 q11Shape16T632=true := by decide

private def q11Shape16T628 : Tree 11 := .split 18 q11Shape16T629 q11Shape16T632
private theorem q11Shape16T628OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 33271448064 q11Shape16T628=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 (33271448064 ||| 2^18) q11Shape16T629 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063108 ||| 2^18) 33271448064 q11Shape16T632)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T629OK,q11Shape16T632OK⟩

private def q11Shape16T633 : Tree 11 := (.tip (.cover {2,3,4,6,8,9}))
private theorem q11Shape16T633OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446194180 33271316992 q11Shape16T633=true := by decide

private def q11Shape16T627 : Tree 11 := .split 17 q11Shape16T628 q11Shape16T633
private theorem q11Shape16T627OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 33271316992 q11Shape16T627=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 (33271316992 ||| 2^17) q11Shape16T628 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063108 ||| 2^17) 33271316992 q11Shape16T633)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T628OK,q11Shape16T633OK⟩

private def q11Shape16T634 : Tree 11 := (.split 15 (.split 16 (.split 17 (.split 18 (.split 19 (.split 1 (.split 8 (.tip (.small 0)) (.tip (.cover {1,2,3,5,7,10}))) (.tip (.cover {1,2,3,5,7,10}))) (.tip (.cover {0,4,5,6,7,10}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,5,6,7,9,10})))
private theorem q11Shape16T634OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063620 33271316480 q11Shape16T634=true := by decide

private def q11Shape16T626 : Tree 11 := .split 9 q11Shape16T627 q11Shape16T634
private theorem q11Shape16T626OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 33271316480 q11Shape16T626=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063108 (33271316480 ||| 2^9) q11Shape16T627 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063108 ||| 2^9) 33271316480 q11Shape16T634)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T627OK,q11Shape16T634OK⟩

private def q11Shape16T616 : Tree 11 := .split 2 q11Shape16T617 q11Shape16T626
private theorem q11Shape16T616OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063104 33271316480 q11Shape16T616=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063104 (33271316480 ||| 2^2) q11Shape16T617 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063104 ||| 2^2) 33271316480 q11Shape16T626)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T617OK,q11Shape16T626OK⟩

private def q11Shape16T635 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape16T635OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52625932288 16091447296 q11Shape16T635=true := by decide

private def q11Shape16T615 : Tree 11 := .split 34 q11Shape16T616 q11Shape16T635
private theorem q11Shape16T615OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063104 16091447296 q11Shape16T615=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35446063104 (16091447296 ||| 2^34) q11Shape16T616 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35446063104 ||| 2^34) 16091447296 q11Shape16T635)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T616OK,q11Shape16T635OK⟩

private def q11Shape16T613 : Tree 11 := .split 30 q11Shape16T614 q11Shape16T615
private theorem q11Shape16T613OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 16091447296 q11Shape16T613=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 (16091447296 ||| 2^30) q11Shape16T614 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34372321280 ||| 2^30) 16091447296 q11Shape16T615)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T614OK,q11Shape16T615OK⟩

private def q11Shape16T636 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape16T636OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 42962255872 7501512704 q11Shape16T636=true := by decide

private def q11Shape16T612 : Tree 11 := .split 33 q11Shape16T613 q11Shape16T636
private theorem q11Shape16T612OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 7501512704 q11Shape16T612=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 (7501512704 ||| 2^33) q11Shape16T613 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34372321280 ||| 2^33) 7501512704 q11Shape16T636)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T613OK,q11Shape16T636OK⟩

private def q11Shape16T637 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape16T637OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 38667288576 3206545408 q11Shape16T637=true := by decide

private def q11Shape16T611 : Tree 11 := .split 32 q11Shape16T612 q11Shape16T637
private theorem q11Shape16T611OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 3206545408 q11Shape16T611=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 (3206545408 ||| 2^32) q11Shape16T612 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34372321280 ||| 2^32) 3206545408 q11Shape16T637)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T612OK,q11Shape16T637OK⟩

private def q11Shape16T638 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape16T638OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36519804928 1059061760 q11Shape16T638=true := by decide

private def q11Shape16T610 : Tree 11 := .split 31 q11Shape16T611 q11Shape16T638
private theorem q11Shape16T610OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 1059061760 q11Shape16T610=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 34372321280 (1059061760 ||| 2^31) q11Shape16T611 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (34372321280 ||| 2^31) 1059061760 q11Shape16T638)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T611OK,q11Shape16T638OK⟩

private def q11Shape16T608 : Tree 11 := .split 35 q11Shape16T609 q11Shape16T610
private theorem q11Shape16T608OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 1059061760 q11Shape16T608=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 (1059061760 ||| 2^35) q11Shape16T609 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12582912 ||| 2^35) 1059061760 q11Shape16T610)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T609OK,q11Shape16T610OK⟩

private def q11Shape16T640 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape16T640OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46137344 2099249152 q11Shape16T640=true := by decide

private def q11Shape16T641 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape16T641OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1119879168 1025507328 q11Shape16T641=true := by decide

private def q11Shape16T639 : Tree 11 := .split 30 q11Shape16T640 q11Shape16T641
private theorem q11Shape16T639OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46137344 1025507328 q11Shape16T639=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46137344 (1025507328 ||| 2^30) q11Shape16T640 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (46137344 ||| 2^30) 1025507328 q11Shape16T641)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T640OK,q11Shape16T641OK⟩

private def q11Shape16T607 : Tree 11 := .split 25 q11Shape16T608 q11Shape16T639
private theorem q11Shape16T607OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 1025507328 q11Shape16T607=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 (1025507328 ||| 2^25) q11Shape16T608 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12582912 ||| 2^25) 1025507328 q11Shape16T639)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T608OK,q11Shape16T639OK⟩

private def q11Shape16T644 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,8,10})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape16T644OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 29360128 2116026368 q11Shape16T644=true := by decide

private def q11Shape16T645 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape16T645OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1103101952 1042284544 q11Shape16T645=true := by decide

private def q11Shape16T643 : Tree 11 := .split 30 q11Shape16T644 q11Shape16T645
private theorem q11Shape16T643OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 29360128 1042284544 q11Shape16T643=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 29360128 (1042284544 ||| 2^30) q11Shape16T644 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (29360128 ||| 2^30) 1042284544 q11Shape16T645)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T644OK,q11Shape16T645OK⟩

private def q11Shape16T647 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape16T647OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62914560 2082471936 q11Shape16T647=true := by decide

private def q11Shape16T648 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape16T648OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1136656384 1008730112 q11Shape16T648=true := by decide

private def q11Shape16T646 : Tree 11 := .split 30 q11Shape16T647 q11Shape16T648
private theorem q11Shape16T646OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62914560 1008730112 q11Shape16T646=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 62914560 (1008730112 ||| 2^30) q11Shape16T647 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (62914560 ||| 2^30) 1008730112 q11Shape16T648)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T647OK,q11Shape16T648OK⟩

private def q11Shape16T642 : Tree 11 := .split 25 q11Shape16T643 q11Shape16T646
private theorem q11Shape16T642OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 29360128 1008730112 q11Shape16T642=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 29360128 (1008730112 ||| 2^25) q11Shape16T643 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (29360128 ||| 2^25) 1008730112 q11Shape16T646)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T643OK,q11Shape16T646OK⟩

private def q11Shape16T606 : Tree 11 := .split 24 q11Shape16T607 q11Shape16T642
private theorem q11Shape16T606OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 1008730112 q11Shape16T606=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 (1008730112 ||| 2^24) q11Shape16T607 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (12582912 ||| 2^24) 1008730112 q11Shape16T642)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T607OK,q11Shape16T642OK⟩

def q11Shape16P22 : Tree 11 := q11Shape16T606
theorem q11Shape16P22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 12582912 1008730112 q11Shape16P22=true := q11Shape16T606OK

private def q11Shape16T650 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T650OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 541065216 471859200 q11Shape16T650=true := by decide

def q11Shape16P23 : Tree 11 := q11Shape16T650
theorem q11Shape16P23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 541065216 471859200 q11Shape16P23=true := q11Shape16T650OK

private def q11Shape16T652 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T652OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 272629760 203423744 q11Shape16T652=true := by decide

def q11Shape16P24 : Tree 11 := q11Shape16T652
theorem q11Shape16P24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 272629760 203423744 q11Shape16P24=true := q11Shape16T652OK

private def q11Shape16T654 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T654OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 138412032 69206016 q11Shape16T654=true := by decide

def q11Shape16P25 : Tree 11 := q11Shape16T654
theorem q11Shape16P25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 138412032 69206016 q11Shape16P25=true := q11Shape16T654OK

private def q11Shape16T656 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T656OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 71303168 2097152 q11Shape16T656=true := by decide

def q11Shape16P26 : Tree 11 := q11Shape16T656
theorem q11Shape16P26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 71303168 2097152 q11Shape16P26=true := q11Shape16T656OK

end Graffiti384b.EffectiveSearch.Q11
