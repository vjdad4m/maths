import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T668 : Tree 11 := (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10})))
private theorem q11Shape16T668OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 2143289344 q11Shape16T668=true := by decide

private def q11Shape16T670 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,5,6,7})) (.split 2 (.split 9 (.split 15 (.tip (.small 0)) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T670OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1075838976 3217031168 q11Shape16T670=true := by decide

private def q11Shape16T671 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T671OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3223322624 1069547520 q11Shape16T671=true := by decide

private def q11Shape16T669 : Tree 11 := .split 31 q11Shape16T670 q11Shape16T671
private theorem q11Shape16T669OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1075838976 1069547520 q11Shape16T669=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1075838976 (1069547520 ||| 2^31) q11Shape16T670 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1075838976 ||| 2^31) 1069547520 q11Shape16T671)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T670OK,q11Shape16T671OK⟩

private def q11Shape16T667 : Tree 11 := .split 30 q11Shape16T668 q11Shape16T669
private theorem q11Shape16T667OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 1069547520 q11Shape16T667=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (1069547520 ||| 2^30) q11Shape16T668 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^30) 1069547520 q11Shape16T669)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T668OK,q11Shape16T669OK⟩

private def q11Shape16T672 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape16T672OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 538968064 532676608 q11Shape16T672=true := by decide

private def q11Shape16T666 : Tree 11 := .split 29 q11Shape16T667 q11Shape16T672
private theorem q11Shape16T666OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 532676608 q11Shape16T666=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (532676608 ||| 2^29) q11Shape16T667 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^29) 532676608 q11Shape16T672)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T667OK,q11Shape16T672OK⟩

private def q11Shape16T673 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape16T673OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 270532608 264241152 q11Shape16T673=true := by decide

private def q11Shape16T665 : Tree 11 := .split 28 q11Shape16T666 q11Shape16T673
private theorem q11Shape16T665OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 264241152 q11Shape16T665=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (264241152 ||| 2^28) q11Shape16T666 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^28) 264241152 q11Shape16T673)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T666OK,q11Shape16T673OK⟩

private def q11Shape16T674 : Tree 11 := (.split 30 (.split 33 (.split 31 (.tip (.cover {2,3,4,5,6,10})) (.split 28 (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,7,8,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape16T674OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 136314880 130023424 q11Shape16T674=true := by decide

private def q11Shape16T664 : Tree 11 := .split 27 q11Shape16T665 q11Shape16T674
private theorem q11Shape16T664OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 130023424 q11Shape16T664=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (130023424 ||| 2^27) q11Shape16T665 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^27) 130023424 q11Shape16T674)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T665OK,q11Shape16T674OK⟩

private def q11Shape16T675 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape16T675OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 69206016 62914560 q11Shape16T675=true := by decide

private def q11Shape16T663 : Tree 11 := .split 26 q11Shape16T664 q11Shape16T675
private theorem q11Shape16T663OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 62914560 q11Shape16T663=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (62914560 ||| 2^26) q11Shape16T664 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^26) 62914560 q11Shape16T675)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T664OK,q11Shape16T675OK⟩

private def q11Shape16T676 : Tree 11 := (.split 26 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.split 31 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,1,5,8,9,10})))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape16T676OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35651584 29360128 q11Shape16T676=true := by decide

private def q11Shape16T662 : Tree 11 := .split 25 q11Shape16T663 q11Shape16T676
private theorem q11Shape16T662OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 29360128 q11Shape16T662=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (29360128 ||| 2^25) q11Shape16T663 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^25) 29360128 q11Shape16T676)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T663OK,q11Shape16T676OK⟩

private def q11Shape16T678 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape16T678OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 18874368 79691776 q11Shape16T678=true := by decide

private def q11Shape16T679 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T679OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 85983232 12582912 q11Shape16T679=true := by decide

private def q11Shape16T677 : Tree 11 := .split 26 q11Shape16T678 q11Shape16T679
private theorem q11Shape16T677OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 18874368 12582912 q11Shape16T677=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 18874368 (12582912 ||| 2^26) q11Shape16T678 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (18874368 ||| 2^26) 12582912 q11Shape16T679)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T678OK,q11Shape16T679OK⟩

private def q11Shape16T661 : Tree 11 := .split 24 q11Shape16T662 q11Shape16T677
private theorem q11Shape16T661OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 12582912 q11Shape16T661=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (12582912 ||| 2^24) q11Shape16T662 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^24) 12582912 q11Shape16T677)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T662OK,q11Shape16T677OK⟩

private def q11Shape16T683 : Tree 11 := (.split 29 (.split 30 (.split 33 (.split 31 (.tip (.cover {2,3,4,5,6,10})) (.split 24 (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape16T683OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10485760 473956352 q11Shape16T683=true := by decide

private def q11Shape16T684 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T684OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 278921216 205520896 q11Shape16T684=true := by decide

private def q11Shape16T682 : Tree 11 := .split 28 q11Shape16T683 q11Shape16T684
private theorem q11Shape16T682OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10485760 205520896 q11Shape16T682=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10485760 (205520896 ||| 2^28) q11Shape16T683 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (10485760 ||| 2^28) 205520896 q11Shape16T684)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T683OK,q11Shape16T684OK⟩

private def q11Shape16T685 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T685OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 144703488 71303168 q11Shape16T685=true := by decide

private def q11Shape16T681 : Tree 11 := .split 27 q11Shape16T682 q11Shape16T685
private theorem q11Shape16T681OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10485760 71303168 q11Shape16T681=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10485760 (71303168 ||| 2^27) q11Shape16T682 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (10485760 ||| 2^27) 71303168 q11Shape16T685)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T682OK,q11Shape16T685OK⟩

private def q11Shape16T686 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T686OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 77594624 4194304 q11Shape16T686=true := by decide

private def q11Shape16T680 : Tree 11 := .split 26 q11Shape16T681 q11Shape16T686
private theorem q11Shape16T680OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10485760 4194304 q11Shape16T680=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10485760 (4194304 ||| 2^26) q11Shape16T681 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (10485760 ||| 2^26) 4194304 q11Shape16T686)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T681OK,q11Shape16T686OK⟩

private def q11Shape16T660 : Tree 11 := .split 23 q11Shape16T661 q11Shape16T680
private theorem q11Shape16T660OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 4194304 q11Shape16T660=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (4194304 ||| 2^23) q11Shape16T661 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^23) 4194304 q11Shape16T680)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T661OK,q11Shape16T680OK⟩

private def q11Shape16T689 : Tree 11 := (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape16T689OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6291456 201326592 q11Shape16T689=true := by decide

private def q11Shape16T690 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T690OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 140509184 67108864 q11Shape16T690=true := by decide

private def q11Shape16T688 : Tree 11 := .split 27 q11Shape16T689 q11Shape16T690
private theorem q11Shape16T688OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6291456 67108864 q11Shape16T688=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6291456 (67108864 ||| 2^27) q11Shape16T689 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (6291456 ||| 2^27) 67108864 q11Shape16T690)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T689OK,q11Shape16T690OK⟩

private def q11Shape16T691 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape16T691OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 73400320 0 q11Shape16T691=true := by decide

private def q11Shape16T687 : Tree 11 := .split 26 q11Shape16T688 q11Shape16T691
private theorem q11Shape16T687OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6291456 0 q11Shape16T687=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6291456 (0 ||| 2^26) q11Shape16T688 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (6291456 ||| 2^26) 0 q11Shape16T691)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T688OK,q11Shape16T691OK⟩

private def q11Shape16T659 : Tree 11 := .split 22 q11Shape16T660 q11Shape16T687
private theorem q11Shape16T659OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 0 q11Shape16T659=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 (0 ||| 2^22) q11Shape16T660 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2097152 ||| 2^22) 0 q11Shape16T687)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T660OK,q11Shape16T687OK⟩

def q11Shape16P27 : Tree 11 := q11Shape16T659
theorem q11Shape16P27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2097152 0 q11Shape16P27=true := q11Shape16T659OK

end Graffiti384b.EffectiveSearch.Q11
