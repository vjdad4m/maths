import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T91 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape16T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 62274928640 q11Shape16T91=true := by decide

private def q11Shape16T94 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 40802189312 27915190788 q11Shape16T94=true := by decide

private def q11Shape16T95 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 40802189824 27915190276 q11Shape16T95=true := by decide

private def q11Shape16T93 : Tree 11 := .split 9 q11Shape16T94 q11Shape16T95
private theorem q11Shape16T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 40802189312 27915190276 q11Shape16T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 40802189312 (27915190276 ||| 2^9) q11Shape16T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (40802189312 ||| 2^9) 27915190276 q11Shape16T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T94OK,q11Shape16T95OK⟩

private def q11Shape16T96 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 40802189316 27915190272 q11Shape16T96=true := by decide

private def q11Shape16T92 : Tree 11 := .split 2 q11Shape16T93 q11Shape16T96
private theorem q11Shape16T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 40802189312 27915190272 q11Shape16T92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 40802189312 (27915190272 ||| 2^2) q11Shape16T93 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (40802189312 ||| 2^2) 27915190272 q11Shape16T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T93OK,q11Shape16T96OK⟩

private def q11Shape16T90 : Tree 11 := .split 35 q11Shape16T91 q11Shape16T92
private theorem q11Shape16T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 27915190272 q11Shape16T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 (27915190272 ||| 2^35) q11Shape16T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (6442450944 ||| 2^35) 27915190272 q11Shape16T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T91OK,q11Shape16T92OK⟩

private def q11Shape16T100 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320128 45095059972 q11Shape16T100=true := by decide

private def q11Shape16T101 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320640 45095059460 q11Shape16T101=true := by decide

private def q11Shape16T99 : Tree 11 := .split 9 q11Shape16T100 q11Shape16T101
private theorem q11Shape16T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320128 45095059460 q11Shape16T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320128 (45095059460 ||| 2^9) q11Shape16T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (23622320128 ||| 2^9) 45095059460 q11Shape16T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T100OK,q11Shape16T101OK⟩

private def q11Shape16T102 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320132 45095059456 q11Shape16T102=true := by decide

private def q11Shape16T98 : Tree 11 := .split 2 q11Shape16T99 q11Shape16T102
private theorem q11Shape16T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320128 45095059456 q11Shape16T98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320128 (45095059456 ||| 2^2) q11Shape16T99 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (23622320128 ||| 2^2) 45095059456 q11Shape16T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T99OK,q11Shape16T102OK⟩

private def q11Shape16T105 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 57982058496 10735321604 q11Shape16T105=true := by decide

private def q11Shape16T106 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 57982059008 10735321092 q11Shape16T106=true := by decide

private def q11Shape16T104 : Tree 11 := .split 9 q11Shape16T105 q11Shape16T106
private theorem q11Shape16T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 57982058496 10735321092 q11Shape16T104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 57982058496 (10735321092 ||| 2^9) q11Shape16T105 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (57982058496 ||| 2^9) 10735321092 q11Shape16T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T105OK,q11Shape16T106OK⟩

private def q11Shape16T107 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 57982058500 10735321088 q11Shape16T107=true := by decide

private def q11Shape16T103 : Tree 11 := .split 2 q11Shape16T104 q11Shape16T107
private theorem q11Shape16T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 57982058496 10735321088 q11Shape16T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 57982058496 (10735321088 ||| 2^2) q11Shape16T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (57982058496 ||| 2^2) 10735321088 q11Shape16T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T104OK,q11Shape16T107OK⟩

private def q11Shape16T97 : Tree 11 := .split 35 q11Shape16T98 q11Shape16T103
private theorem q11Shape16T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320128 10735321088 q11Shape16T97=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 23622320128 (10735321088 ||| 2^35) q11Shape16T98 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (23622320128 ||| 2^35) 10735321088 q11Shape16T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T98OK,q11Shape16T103OK⟩

private def q11Shape16T89 : Tree 11 := .split 34 q11Shape16T90 q11Shape16T97
private theorem q11Shape16T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 10735321088 q11Shape16T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 (10735321088 ||| 2^34) q11Shape16T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (6442450944 ||| 2^34) 10735321088 q11Shape16T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T90OK,q11Shape16T97OK⟩

private def q11Shape16T112 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 53684994564 q11Shape16T112=true := by decide

private def q11Shape16T113 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032386048 53684994052 q11Shape16T113=true := by decide

private def q11Shape16T111 : Tree 11 := .split 9 q11Shape16T112 q11Shape16T113
private theorem q11Shape16T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 53684994052 q11Shape16T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 (53684994052 ||| 2^9) q11Shape16T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (15032385536 ||| 2^9) 53684994052 q11Shape16T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T112OK,q11Shape16T113OK⟩

private def q11Shape16T114 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385540 53684994048 q11Shape16T114=true := by decide

private def q11Shape16T110 : Tree 11 := .split 2 q11Shape16T111 q11Shape16T114
private theorem q11Shape16T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 53684994048 q11Shape16T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 (53684994048 ||| 2^2) q11Shape16T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (15032385536 ||| 2^2) 53684994048 q11Shape16T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T111OK,q11Shape16T114OK⟩

private def q11Shape16T117 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 49392123904 19325256196 q11Shape16T117=true := by decide

private def q11Shape16T118 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 49392124416 19325255684 q11Shape16T118=true := by decide

private def q11Shape16T116 : Tree 11 := .split 9 q11Shape16T117 q11Shape16T118
private theorem q11Shape16T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 49392123904 19325255684 q11Shape16T116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 49392123904 (19325255684 ||| 2^9) q11Shape16T117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (49392123904 ||| 2^9) 19325255684 q11Shape16T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T117OK,q11Shape16T118OK⟩

private def q11Shape16T119 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 49392123908 19325255680 q11Shape16T119=true := by decide

private def q11Shape16T115 : Tree 11 := .split 2 q11Shape16T116 q11Shape16T119
private theorem q11Shape16T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 49392123904 19325255680 q11Shape16T115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 49392123904 (19325255680 ||| 2^2) q11Shape16T116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (49392123904 ||| 2^2) 19325255680 q11Shape16T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T116OK,q11Shape16T119OK⟩

private def q11Shape16T109 : Tree 11 := .split 35 q11Shape16T110 q11Shape16T115
private theorem q11Shape16T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 19325255680 q11Shape16T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 (19325255680 ||| 2^35) q11Shape16T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (15032385536 ||| 2^35) 19325255680 q11Shape16T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T110OK,q11Shape16T115OK⟩

private def q11Shape16T120 : Tree 11 := (.tip (.cover {0,1,5,6,7,8}))
private theorem q11Shape16T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 32212254720 2145386496 q11Shape16T120=true := by decide

private def q11Shape16T108 : Tree 11 := .split 34 q11Shape16T109 q11Shape16T120
private theorem q11Shape16T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 2145386496 q11Shape16T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 15032385536 (2145386496 ||| 2^34) q11Shape16T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (15032385536 ||| 2^34) 2145386496 q11Shape16T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T109OK,q11Shape16T120OK⟩

private def q11Shape16T88 : Tree 11 := .split 33 q11Shape16T89 q11Shape16T108
private theorem q11Shape16T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 2145386496 q11Shape16T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 (2145386496 ||| 2^33) q11Shape16T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (6442450944 ||| 2^33) 2145386496 q11Shape16T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T89OK,q11Shape16T108OK⟩

def q11Shape16P2 : Tree 11 := q11Shape16T88
theorem q11Shape16P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6442450944 2145386496 q11Shape16P2=true := q11Shape16T88OK

end Graffiti384b.EffectiveSearch.Q11
