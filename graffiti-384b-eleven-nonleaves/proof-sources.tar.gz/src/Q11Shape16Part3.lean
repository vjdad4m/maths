import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T124 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape16T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 41873833984 q11Shape16T124=true := by decide

private def q11Shape16T129 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 17 (.split 19 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {0,4,6,7,8,10}))) (.tip (.cover {0,4,6,8,9,10})))))))
private theorem q11Shape16T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 33283899908 q11Shape16T129=true := by decide

private def q11Shape16T130 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 11 (.split 19 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,6,7,8,10}))) (.tip (.cover {2,4,5,6,8,10}))) (.tip (.cover {0,3,6,8,9,10})))))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480704 33283899396 q11Shape16T130=true := by decide

private def q11Shape16T128 : Tree 11 := .split 9 q11Shape16T129 q11Shape16T130
private theorem q11Shape16T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 33283899396 q11Shape16T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 (33283899396 ||| 2^9) q11Shape16T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480192 ||| 2^9) 33283899396 q11Shape16T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T129OK,q11Shape16T130OK⟩

private def q11Shape16T134 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480196 33283932673 q11Shape16T134=true := by decide

private def q11Shape16T136 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480197 33283932674 q11Shape16T136=true := by decide

private def q11Shape16T138 : Tree 11 := (.tip (.small 0))
private theorem q11Shape16T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480199 33283932928 q11Shape16T138=true := by decide

private def q11Shape16T141 : Tree 11 := (.split 3 (.tip (.small 1)) (.split 17 (.split 19 (.tip (.cover {2,3,5,6,8,10})) (.split 11 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,8,10})))) (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {3,4,5,6,8,10})))))
private theorem q11Shape16T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480455 33283999232 q11Shape16T141=true := by decide

private def q11Shape16T142 : Tree 11 := (.split 3 (.split 17 (.split 19 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {1,4,5,7,8,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {2,3,4,5,7,9})))
private theorem q11Shape16T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433545991 33283933696 q11Shape16T142=true := by decide

private def q11Shape16T140 : Tree 11 := .split 16 q11Shape16T141 q11Shape16T142
private theorem q11Shape16T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480455 33283933696 q11Shape16T140=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480455 (33283933696 ||| 2^16) q11Shape16T141 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480455 ||| 2^16) 33283933696 q11Shape16T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T141OK,q11Shape16T142OK⟩

private def q11Shape16T143 : Tree 11 := (.split 16 (.split 3 (.split 17 (.split 19 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {4,5,6,7,8,10}))) (.tip (.cover {4,5,6,8,9,10}))) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9})))
private theorem q11Shape16T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433481479 33283932672 q11Shape16T143=true := by decide

private def q11Shape16T139 : Tree 11 := .split 10 q11Shape16T140 q11Shape16T143
private theorem q11Shape16T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480455 33283932672 q11Shape16T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480455 (33283932672 ||| 2^10) q11Shape16T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480455 ||| 2^10) 33283932672 q11Shape16T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T140OK,q11Shape16T143OK⟩

private def q11Shape16T137 : Tree 11 := .split 8 q11Shape16T138 q11Shape16T139
private theorem q11Shape16T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480199 33283932672 q11Shape16T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480199 (33283932672 ||| 2^8) q11Shape16T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480199 ||| 2^8) 33283932672 q11Shape16T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T138OK,q11Shape16T139OK⟩

private def q11Shape16T135 : Tree 11 := .split 1 q11Shape16T136 q11Shape16T137
private theorem q11Shape16T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480197 33283932672 q11Shape16T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480197 (33283932672 ||| 2^1) q11Shape16T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480197 ||| 2^1) 33283932672 q11Shape16T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T136OK,q11Shape16T137OK⟩

private def q11Shape16T133 : Tree 11 := .split 0 q11Shape16T134 q11Shape16T135
private theorem q11Shape16T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480196 33283932672 q11Shape16T133=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480196 (33283932672 ||| 2^0) q11Shape16T134 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480196 ||| 2^0) 33283932672 q11Shape16T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T134OK,q11Shape16T135OK⟩

private def q11Shape16T144 : Tree 11 := (.tip (.cover {2,3,4,6,7,9}))
private theorem q11Shape16T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433512964 33283899904 q11Shape16T144=true := by decide

private def q11Shape16T132 : Tree 11 := .split 15 q11Shape16T133 q11Shape16T144
private theorem q11Shape16T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480196 33283899904 q11Shape16T132=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480196 (33283899904 ||| 2^15) q11Shape16T133 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480196 ||| 2^15) 33283899904 q11Shape16T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T133OK,q11Shape16T144OK⟩

private def q11Shape16T145 : Tree 11 := (.tip (.cover {2,3,4,6,7,9}))
private theorem q11Shape16T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480708 33283899392 q11Shape16T145=true := by decide

private def q11Shape16T131 : Tree 11 := .split 9 q11Shape16T132 q11Shape16T145
private theorem q11Shape16T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480196 33283899392 q11Shape16T131=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480196 (33283899392 ||| 2^9) q11Shape16T132 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480196 ||| 2^9) 33283899392 q11Shape16T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T132OK,q11Shape16T145OK⟩

private def q11Shape16T127 : Tree 11 := .split 2 q11Shape16T128 q11Shape16T131
private theorem q11Shape16T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 33283899392 q11Shape16T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 (33283899392 ||| 2^2) q11Shape16T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480192 ||| 2^2) 33283899392 q11Shape16T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T128OK,q11Shape16T131OK⟩

private def q11Shape16T148 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52613349376 16104030724 q11Shape16T148=true := by decide

private def q11Shape16T149 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52613349888 16104030212 q11Shape16T149=true := by decide

private def q11Shape16T147 : Tree 11 := .split 9 q11Shape16T148 q11Shape16T149
private theorem q11Shape16T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52613349376 16104030212 q11Shape16T147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52613349376 (16104030212 ||| 2^9) q11Shape16T148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (52613349376 ||| 2^9) 16104030212 q11Shape16T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T148OK,q11Shape16T149OK⟩

private def q11Shape16T150 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52613349380 16104030208 q11Shape16T150=true := by decide

private def q11Shape16T146 : Tree 11 := .split 2 q11Shape16T147 q11Shape16T150
private theorem q11Shape16T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52613349376 16104030208 q11Shape16T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 52613349376 (16104030208 ||| 2^2) q11Shape16T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (52613349376 ||| 2^2) 16104030208 q11Shape16T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T147OK,q11Shape16T150OK⟩

private def q11Shape16T126 : Tree 11 := .split 34 q11Shape16T127 q11Shape16T146
private theorem q11Shape16T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 16104030208 q11Shape16T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 (16104030208 ||| 2^34) q11Shape16T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480192 ||| 2^34) 16104030208 q11Shape16T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T127OK,q11Shape16T146OK⟩

private def q11Shape16T154 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414784 24693965316 q11Shape16T154=true := by decide

private def q11Shape16T155 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023415296 24693964804 q11Shape16T155=true := by decide

private def q11Shape16T153 : Tree 11 := .split 9 q11Shape16T154 q11Shape16T155
private theorem q11Shape16T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414784 24693964804 q11Shape16T153=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414784 (24693964804 ||| 2^9) q11Shape16T154 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (44023414784 ||| 2^9) 24693964804 q11Shape16T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T154OK,q11Shape16T155OK⟩

private def q11Shape16T156 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414788 24693964800 q11Shape16T156=true := by decide

private def q11Shape16T152 : Tree 11 := .split 2 q11Shape16T153 q11Shape16T156
private theorem q11Shape16T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414784 24693964800 q11Shape16T152=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414784 (24693964800 ||| 2^2) q11Shape16T153 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (44023414784 ||| 2^2) 24693964800 q11Shape16T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T153OK,q11Shape16T156OK⟩

private def q11Shape16T159 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 61203283968 7514096132 q11Shape16T159=true := by decide

private def q11Shape16T160 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,9})))
private theorem q11Shape16T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 61203284480 7514095620 q11Shape16T160=true := by decide

private def q11Shape16T158 : Tree 11 := .split 9 q11Shape16T159 q11Shape16T160
private theorem q11Shape16T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 61203283968 7514095620 q11Shape16T158=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 61203283968 (7514095620 ||| 2^9) q11Shape16T159 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (61203283968 ||| 2^9) 7514095620 q11Shape16T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T159OK,q11Shape16T160OK⟩

private def q11Shape16T161 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,8,9}))) (.tip (.cover {2,3,4,6,8,9})))
private theorem q11Shape16T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 61203283972 7514095616 q11Shape16T161=true := by decide

private def q11Shape16T157 : Tree 11 := .split 2 q11Shape16T158 q11Shape16T161
private theorem q11Shape16T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 61203283968 7514095616 q11Shape16T157=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 61203283968 (7514095616 ||| 2^2) q11Shape16T158 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (61203283968 ||| 2^2) 7514095616 q11Shape16T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T158OK,q11Shape16T161OK⟩

private def q11Shape16T151 : Tree 11 := .split 34 q11Shape16T152 q11Shape16T157
private theorem q11Shape16T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414784 7514095616 q11Shape16T151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 44023414784 (7514095616 ||| 2^34) q11Shape16T152 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (44023414784 ||| 2^34) 7514095616 q11Shape16T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T152OK,q11Shape16T157OK⟩

private def q11Shape16T125 : Tree 11 := .split 33 q11Shape16T126 q11Shape16T151
private theorem q11Shape16T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 7514095616 q11Shape16T125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 35433480192 (7514095616 ||| 2^33) q11Shape16T126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (35433480192 ||| 2^33) 7514095616 q11Shape16T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T126OK,q11Shape16T151OK⟩

private def q11Shape16T123 : Tree 11 := .split 35 q11Shape16T124 q11Shape16T125
private theorem q11Shape16T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 7514095616 q11Shape16T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 (7514095616 ||| 2^35) q11Shape16T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1073741824 ||| 2^35) 7514095616 q11Shape16T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T124OK,q11Shape16T125OK⟩

def q11Shape16P3 : Tree 11 := q11Shape16T123
theorem q11Shape16P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1073741824 7514095616 q11Shape16P3=true := q11Shape16T123OK

end Graffiti384b.EffectiveSearch.Q11
