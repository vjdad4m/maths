import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T165 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape16T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 63348670464 q11Shape16T165=true := by decide

private def q11Shape16T168 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 39728447488 28988932612 q11Shape16T168=true := by decide

private def q11Shape16T169 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 39728448000 28988932100 q11Shape16T169=true := by decide

private def q11Shape16T167 : Tree 11 := .split 9 q11Shape16T168 q11Shape16T169
private theorem q11Shape16T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 39728447488 28988932100 q11Shape16T167=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 39728447488 (28988932100 ||| 2^9) q11Shape16T168 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (39728447488 ||| 2^9) 28988932100 q11Shape16T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T168OK,q11Shape16T169OK⟩

private def q11Shape16T170 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 39728447492 28988932096 q11Shape16T170=true := by decide

private def q11Shape16T166 : Tree 11 := .split 2 q11Shape16T167 q11Shape16T170
private theorem q11Shape16T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 39728447488 28988932096 q11Shape16T166=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 39728447488 (28988932096 ||| 2^2) q11Shape16T167 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (39728447488 ||| 2^2) 28988932096 q11Shape16T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T167OK,q11Shape16T170OK⟩

private def q11Shape16T164 : Tree 11 := .split 35 q11Shape16T165 q11Shape16T166
private theorem q11Shape16T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 28988932096 q11Shape16T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 (28988932096 ||| 2^35) q11Shape16T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (5368709120 ||| 2^35) 28988932096 q11Shape16T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T165OK,q11Shape16T166OK⟩

private def q11Shape16T174 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578304 46168801796 q11Shape16T174=true := by decide

private def q11Shape16T175 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578816 46168801284 q11Shape16T175=true := by decide

private def q11Shape16T173 : Tree 11 := .split 9 q11Shape16T174 q11Shape16T175
private theorem q11Shape16T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578304 46168801284 q11Shape16T173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578304 (46168801284 ||| 2^9) q11Shape16T174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (22548578304 ||| 2^9) 46168801284 q11Shape16T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T174OK,q11Shape16T175OK⟩

private def q11Shape16T176 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578308 46168801280 q11Shape16T176=true := by decide

private def q11Shape16T172 : Tree 11 := .split 2 q11Shape16T173 q11Shape16T176
private theorem q11Shape16T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578304 46168801280 q11Shape16T172=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578304 (46168801280 ||| 2^2) q11Shape16T173 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (22548578304 ||| 2^2) 46168801280 q11Shape16T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T173OK,q11Shape16T176OK⟩

private def q11Shape16T179 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 56908316672 11809063428 q11Shape16T179=true := by decide

private def q11Shape16T180 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 56908317184 11809062916 q11Shape16T180=true := by decide

private def q11Shape16T178 : Tree 11 := .split 9 q11Shape16T179 q11Shape16T180
private theorem q11Shape16T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 56908316672 11809062916 q11Shape16T178=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 56908316672 (11809062916 ||| 2^9) q11Shape16T179 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (56908316672 ||| 2^9) 11809062916 q11Shape16T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T179OK,q11Shape16T180OK⟩

private def q11Shape16T181 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape16T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 56908316676 11809062912 q11Shape16T181=true := by decide

private def q11Shape16T177 : Tree 11 := .split 2 q11Shape16T178 q11Shape16T181
private theorem q11Shape16T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 56908316672 11809062912 q11Shape16T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 56908316672 (11809062912 ||| 2^2) q11Shape16T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (56908316672 ||| 2^2) 11809062912 q11Shape16T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T178OK,q11Shape16T181OK⟩

private def q11Shape16T171 : Tree 11 := .split 35 q11Shape16T172 q11Shape16T177
private theorem q11Shape16T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578304 11809062912 q11Shape16T171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 22548578304 (11809062912 ||| 2^35) q11Shape16T172 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (22548578304 ||| 2^35) 11809062912 q11Shape16T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T172OK,q11Shape16T177OK⟩

private def q11Shape16T163 : Tree 11 := .split 34 q11Shape16T164 q11Shape16T171
private theorem q11Shape16T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 11809062912 q11Shape16T163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 (11809062912 ||| 2^34) q11Shape16T164 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (5368709120 ||| 2^34) 11809062912 q11Shape16T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T164OK,q11Shape16T171OK⟩

private def q11Shape16T186 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,9,10}))))))
private theorem q11Shape16T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 54758736388 q11Shape16T186=true := by decide

private def q11Shape16T187 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,9,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958644224 54758735876 q11Shape16T187=true := by decide

private def q11Shape16T185 : Tree 11 := .split 9 q11Shape16T186 q11Shape16T187
private theorem q11Shape16T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 54758735876 q11Shape16T185=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 (54758735876 ||| 2^9) q11Shape16T186 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13958643712 ||| 2^9) 54758735876 q11Shape16T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T186OK,q11Shape16T187OK⟩

private def q11Shape16T188 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,9,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643716 54758735872 q11Shape16T188=true := by decide

private def q11Shape16T184 : Tree 11 := .split 2 q11Shape16T185 q11Shape16T188
private theorem q11Shape16T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 54758735872 q11Shape16T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 (54758735872 ||| 2^2) q11Shape16T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13958643712 ||| 2^2) 54758735872 q11Shape16T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T185OK,q11Shape16T188OK⟩

private def q11Shape16T191 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 31138512896 37578867204 q11Shape16T191=true := by decide

private def q11Shape16T192 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 31138513408 37578866692 q11Shape16T192=true := by decide

private def q11Shape16T190 : Tree 11 := .split 9 q11Shape16T191 q11Shape16T192
private theorem q11Shape16T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 31138512896 37578866692 q11Shape16T190=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 31138512896 (37578866692 ||| 2^9) q11Shape16T191 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (31138512896 ||| 2^9) 37578866692 q11Shape16T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T191OK,q11Shape16T192OK⟩

private def q11Shape16T193 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 31138512900 37578866688 q11Shape16T193=true := by decide

private def q11Shape16T189 : Tree 11 := .split 2 q11Shape16T190 q11Shape16T193
private theorem q11Shape16T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 31138512896 37578866688 q11Shape16T189=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 31138512896 (37578866688 ||| 2^2) q11Shape16T190 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (31138512896 ||| 2^2) 37578866688 q11Shape16T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T190OK,q11Shape16T193OK⟩

private def q11Shape16T183 : Tree 11 := .split 34 q11Shape16T184 q11Shape16T189
private theorem q11Shape16T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 37578866688 q11Shape16T183=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 (37578866688 ||| 2^34) q11Shape16T184 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13958643712 ||| 2^34) 37578866688 q11Shape16T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T184OK,q11Shape16T189OK⟩

private def q11Shape16T194 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape16T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 48318382080 3219128320 q11Shape16T194=true := by decide

private def q11Shape16T182 : Tree 11 := .split 35 q11Shape16T183 q11Shape16T194
private theorem q11Shape16T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 3219128320 q11Shape16T182=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13958643712 (3219128320 ||| 2^35) q11Shape16T183 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13958643712 ||| 2^35) 3219128320 q11Shape16T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T183OK,q11Shape16T194OK⟩

private def q11Shape16T162 : Tree 11 := .split 33 q11Shape16T163 q11Shape16T182
private theorem q11Shape16T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 3219128320 q11Shape16T162=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 (3219128320 ||| 2^33) q11Shape16T163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (5368709120 ||| 2^33) 3219128320 q11Shape16T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T163OK,q11Shape16T182OK⟩

def q11Shape16P4 : Tree 11 := q11Shape16T162
theorem q11Shape16P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5368709120 3219128320 q11Shape16P4=true := q11Shape16T162OK

end Graffiti384b.EffectiveSearch.Q11
