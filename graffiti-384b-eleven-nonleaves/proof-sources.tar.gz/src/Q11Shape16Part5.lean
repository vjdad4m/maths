import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T199 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape16T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 65496154112 q11Shape16T199=true := by decide

private def q11Shape16T202 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37580963840 31136416260 q11Shape16T202=true := by decide

private def q11Shape16T203 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37580964352 31136415748 q11Shape16T203=true := by decide

private def q11Shape16T201 : Tree 11 := .split 9 q11Shape16T202 q11Shape16T203
private theorem q11Shape16T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37580963840 31136415748 q11Shape16T201=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37580963840 (31136415748 ||| 2^9) q11Shape16T202 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (37580963840 ||| 2^9) 31136415748 q11Shape16T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T202OK,q11Shape16T203OK⟩

private def q11Shape16T204 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37580963844 31136415744 q11Shape16T204=true := by decide

private def q11Shape16T200 : Tree 11 := .split 2 q11Shape16T201 q11Shape16T204
private theorem q11Shape16T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37580963840 31136415744 q11Shape16T200=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 37580963840 (31136415744 ||| 2^2) q11Shape16T201 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (37580963840 ||| 2^2) 31136415744 q11Shape16T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T201OK,q11Shape16T204OK⟩

private def q11Shape16T198 : Tree 11 := .split 35 q11Shape16T199 q11Shape16T200
private theorem q11Shape16T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 31136415744 q11Shape16T198=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 (31136415744 ||| 2^35) q11Shape16T199 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (3221225472 ||| 2^35) 31136415744 q11Shape16T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T199OK,q11Shape16T200OK⟩

private def q11Shape16T208 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,9,10}))))))
private theorem q11Shape16T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094656 48316285444 q11Shape16T208=true := by decide

private def q11Shape16T209 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,9,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401095168 48316284932 q11Shape16T209=true := by decide

private def q11Shape16T207 : Tree 11 := .split 9 q11Shape16T208 q11Shape16T209
private theorem q11Shape16T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094656 48316284932 q11Shape16T207=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094656 (48316284932 ||| 2^9) q11Shape16T208 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (20401094656 ||| 2^9) 48316284932 q11Shape16T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T208OK,q11Shape16T209OK⟩

private def q11Shape16T210 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,9,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094660 48316284928 q11Shape16T210=true := by decide

private def q11Shape16T206 : Tree 11 := .split 2 q11Shape16T207 q11Shape16T210
private theorem q11Shape16T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094656 48316284928 q11Shape16T206=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094656 (48316284928 ||| 2^2) q11Shape16T207 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (20401094656 ||| 2^2) 48316284928 q11Shape16T210)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T207OK,q11Shape16T210OK⟩

private def q11Shape16T211 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape16T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 54760833024 13956546560 q11Shape16T211=true := by decide

private def q11Shape16T205 : Tree 11 := .split 35 q11Shape16T206 q11Shape16T211
private theorem q11Shape16T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094656 13956546560 q11Shape16T205=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 20401094656 (13956546560 ||| 2^35) q11Shape16T206 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (20401094656 ||| 2^35) 13956546560 q11Shape16T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T206OK,q11Shape16T211OK⟩

private def q11Shape16T197 : Tree 11 := .split 34 q11Shape16T198 q11Shape16T205
private theorem q11Shape16T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 13956546560 q11Shape16T197=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 (13956546560 ||| 2^34) q11Shape16T198 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (3221225472 ||| 2^34) 13956546560 q11Shape16T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T198OK,q11Shape16T205OK⟩

private def q11Shape16T216 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 56906220036 q11Shape16T216=true := by decide

private def q11Shape16T217 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160576 56906219524 q11Shape16T217=true := by decide

private def q11Shape16T215 : Tree 11 := .split 9 q11Shape16T216 q11Shape16T217
private theorem q11Shape16T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 56906219524 q11Shape16T215=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 (56906219524 ||| 2^9) q11Shape16T216 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (11811160064 ||| 2^9) 56906219524 q11Shape16T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T216OK,q11Shape16T217OK⟩

private def q11Shape16T218 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160068 56906219520 q11Shape16T218=true := by decide

private def q11Shape16T214 : Tree 11 := .split 2 q11Shape16T215 q11Shape16T218
private theorem q11Shape16T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 56906219520 q11Shape16T214=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 (56906219520 ||| 2^2) q11Shape16T215 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (11811160064 ||| 2^2) 56906219520 q11Shape16T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T215OK,q11Shape16T218OK⟩

private def q11Shape16T221 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46170898432 22546481668 q11Shape16T221=true := by decide

private def q11Shape16T222 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46170898944 22546481156 q11Shape16T222=true := by decide

private def q11Shape16T220 : Tree 11 := .split 9 q11Shape16T221 q11Shape16T222
private theorem q11Shape16T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46170898432 22546481156 q11Shape16T220=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46170898432 (22546481156 ||| 2^9) q11Shape16T221 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (46170898432 ||| 2^9) 22546481156 q11Shape16T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T221OK,q11Shape16T222OK⟩

private def q11Shape16T223 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46170898436 22546481152 q11Shape16T223=true := by decide

private def q11Shape16T219 : Tree 11 := .split 2 q11Shape16T220 q11Shape16T223
private theorem q11Shape16T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46170898432 22546481152 q11Shape16T219=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 46170898432 (22546481152 ||| 2^2) q11Shape16T220 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (46170898432 ||| 2^2) 22546481152 q11Shape16T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T220OK,q11Shape16T223OK⟩

private def q11Shape16T213 : Tree 11 := .split 35 q11Shape16T214 q11Shape16T219
private theorem q11Shape16T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 22546481152 q11Shape16T213=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 (22546481152 ||| 2^35) q11Shape16T214 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (11811160064 ||| 2^35) 22546481152 q11Shape16T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T214OK,q11Shape16T219OK⟩

private def q11Shape16T227 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029248 39726350852 q11Shape16T227=true := by decide

private def q11Shape16T228 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029760 39726350340 q11Shape16T228=true := by decide

private def q11Shape16T226 : Tree 11 := .split 9 q11Shape16T227 q11Shape16T228
private theorem q11Shape16T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029248 39726350340 q11Shape16T226=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029248 (39726350340 ||| 2^9) q11Shape16T227 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (28991029248 ||| 2^9) 39726350340 q11Shape16T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T227OK,q11Shape16T228OK⟩

private def q11Shape16T229 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029252 39726350336 q11Shape16T229=true := by decide

private def q11Shape16T225 : Tree 11 := .split 2 q11Shape16T226 q11Shape16T229
private theorem q11Shape16T225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029248 39726350336 q11Shape16T225=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029248 (39726350336 ||| 2^2) q11Shape16T226 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (28991029248 ||| 2^2) 39726350336 q11Shape16T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T226OK,q11Shape16T229OK⟩

private def q11Shape16T230 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape16T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 63350767616 5366611968 q11Shape16T230=true := by decide

private def q11Shape16T224 : Tree 11 := .split 35 q11Shape16T225 q11Shape16T230
private theorem q11Shape16T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029248 5366611968 q11Shape16T224=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 28991029248 (5366611968 ||| 2^35) q11Shape16T225 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (28991029248 ||| 2^35) 5366611968 q11Shape16T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T225OK,q11Shape16T230OK⟩

private def q11Shape16T212 : Tree 11 := .split 34 q11Shape16T213 q11Shape16T224
private theorem q11Shape16T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 5366611968 q11Shape16T212=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11811160064 (5366611968 ||| 2^34) q11Shape16T213 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (11811160064 ||| 2^34) 5366611968 q11Shape16T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T213OK,q11Shape16T224OK⟩

private def q11Shape16T196 : Tree 11 := .split 33 q11Shape16T197 q11Shape16T212
private theorem q11Shape16T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 5366611968 q11Shape16T196=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 (5366611968 ||| 2^33) q11Shape16T197 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (3221225472 ||| 2^33) 5366611968 q11Shape16T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T197OK,q11Shape16T212OK⟩

def q11Shape16P5 : Tree 11 := q11Shape16T196
theorem q11Shape16P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3221225472 5366611968 q11Shape16P5=true := q11Shape16T196OK

end Graffiti384b.EffectiveSearch.Q11
