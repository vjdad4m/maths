import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T234 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape16T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 61201186816 q11Shape16T234=true := by decide

private def q11Shape16T237 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41875931136 26841448964 q11Shape16T237=true := by decide

private def q11Shape16T238 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41875931648 26841448452 q11Shape16T238=true := by decide

private def q11Shape16T236 : Tree 11 := .split 9 q11Shape16T237 q11Shape16T238
private theorem q11Shape16T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41875931136 26841448452 q11Shape16T236=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41875931136 (26841448452 ||| 2^9) q11Shape16T237 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (41875931136 ||| 2^9) 26841448452 q11Shape16T238)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T237OK,q11Shape16T238OK⟩

private def q11Shape16T239 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41875931140 26841448448 q11Shape16T239=true := by decide

private def q11Shape16T235 : Tree 11 := .split 2 q11Shape16T236 q11Shape16T239
private theorem q11Shape16T235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41875931136 26841448448 q11Shape16T235=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 41875931136 (26841448448 ||| 2^2) q11Shape16T236 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (41875931136 ||| 2^2) 26841448448 q11Shape16T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T236OK,q11Shape16T239OK⟩

private def q11Shape16T233 : Tree 11 := .split 35 q11Shape16T234 q11Shape16T235
private theorem q11Shape16T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 26841448448 q11Shape16T233=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 (26841448448 ||| 2^35) q11Shape16T234 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (7516192768 ||| 2^35) 26841448448 q11Shape16T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T234OK,q11Shape16T235OK⟩

private def q11Shape16T243 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061952 44021318148 q11Shape16T243=true := by decide

private def q11Shape16T244 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696062464 44021317636 q11Shape16T244=true := by decide

private def q11Shape16T242 : Tree 11 := .split 9 q11Shape16T243 q11Shape16T244
private theorem q11Shape16T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061952 44021317636 q11Shape16T242=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061952 (44021317636 ||| 2^9) q11Shape16T243 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (24696061952 ||| 2^9) 44021317636 q11Shape16T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T243OK,q11Shape16T244OK⟩

private def q11Shape16T245 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061956 44021317632 q11Shape16T245=true := by decide

private def q11Shape16T241 : Tree 11 := .split 2 q11Shape16T242 q11Shape16T245
private theorem q11Shape16T241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061952 44021317632 q11Shape16T241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061952 (44021317632 ||| 2^2) q11Shape16T242 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (24696061952 ||| 2^2) 44021317632 q11Shape16T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T242OK,q11Shape16T245OK⟩

private def q11Shape16T246 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape16T246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 59055800320 9661579264 q11Shape16T246=true := by decide

private def q11Shape16T240 : Tree 11 := .split 35 q11Shape16T241 q11Shape16T246
private theorem q11Shape16T240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061952 9661579264 q11Shape16T240=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 24696061952 (9661579264 ||| 2^35) q11Shape16T241 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (24696061952 ||| 2^35) 9661579264 q11Shape16T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T241OK,q11Shape16T246OK⟩

private def q11Shape16T232 : Tree 11 := .split 34 q11Shape16T233 q11Shape16T240
private theorem q11Shape16T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 9661579264 q11Shape16T232=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 (9661579264 ||| 2^34) q11Shape16T233 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (7516192768 ||| 2^34) 9661579264 q11Shape16T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T233OK,q11Shape16T240OK⟩

private def q11Shape16T251 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T251OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 52611252740 q11Shape16T251=true := by decide

private def q11Shape16T252 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T252OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127872 52611252228 q11Shape16T252=true := by decide

private def q11Shape16T250 : Tree 11 := .split 9 q11Shape16T251 q11Shape16T252
private theorem q11Shape16T250OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 52611252228 q11Shape16T250=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 (52611252228 ||| 2^9) q11Shape16T251 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16106127360 ||| 2^9) 52611252228 q11Shape16T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T251OK,q11Shape16T252OK⟩

private def q11Shape16T253 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T253OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127364 52611252224 q11Shape16T253=true := by decide

private def q11Shape16T249 : Tree 11 := .split 2 q11Shape16T250 q11Shape16T253
private theorem q11Shape16T249OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 52611252224 q11Shape16T249=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 (52611252224 ||| 2^2) q11Shape16T250 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16106127360 ||| 2^2) 52611252224 q11Shape16T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T250OK,q11Shape16T253OK⟩

private def q11Shape16T254 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape16T254OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 50465865728 18251513856 q11Shape16T254=true := by decide

private def q11Shape16T248 : Tree 11 := .split 35 q11Shape16T249 q11Shape16T254
private theorem q11Shape16T248OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 18251513856 q11Shape16T248=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 (18251513856 ||| 2^35) q11Shape16T249 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16106127360 ||| 2^35) 18251513856 q11Shape16T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T249OK,q11Shape16T254OK⟩

private def q11Shape16T255 : Tree 11 := (.tip (.cover {0,1,5,6,7,8}))
private theorem q11Shape16T255OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 33285996544 1071644672 q11Shape16T255=true := by decide

private def q11Shape16T247 : Tree 11 := .split 34 q11Shape16T248 q11Shape16T255
private theorem q11Shape16T247OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 1071644672 q11Shape16T247=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 16106127360 (1071644672 ||| 2^34) q11Shape16T248 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (16106127360 ||| 2^34) 1071644672 q11Shape16T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T248OK,q11Shape16T255OK⟩

private def q11Shape16T231 : Tree 11 := .split 33 q11Shape16T232 q11Shape16T247
private theorem q11Shape16T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 1071644672 q11Shape16T231=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 (1071644672 ||| 2^33) q11Shape16T232 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (7516192768 ||| 2^33) 1071644672 q11Shape16T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T232OK,q11Shape16T247OK⟩

def q11Shape16P6 : Tree 11 := q11Shape16T231
theorem q11Shape16P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7516192768 1071644672 q11Shape16P6=true := q11Shape16T231OK

private def q11Shape16T261 : Tree 11 := (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.split 32 (.tip (.cover {2,3,4,5,6,9})) (.split 35 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape16T261OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 536870912 3755999232 q11Shape16T261=true := by decide

private def q11Shape16T262 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.split 35 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,10}))) (.tip (.cover {2,3,4,5,7,10}))) (.tip (.cover {2,3,4,5,7,10}))) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T262OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2684354560 1608515584 q11Shape16T262=true := by decide

private def q11Shape16T260 : Tree 11 := .split 31 q11Shape16T261 q11Shape16T262
private theorem q11Shape16T260OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 536870912 1608515584 q11Shape16T260=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 536870912 (1608515584 ||| 2^31) q11Shape16T261 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (536870912 ||| 2^31) 1608515584 q11Shape16T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T261OK,q11Shape16T262OK⟩

private def q11Shape16T264 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,5,6,7})) (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,10}))) (.tip (.cover {2,3,4,5,7,10}))) (.tip (.cover {2,3,4,5,7,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T264OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1610612736 2682257408 q11Shape16T264=true := by decide

private def q11Shape16T265 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T265OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3758096384 534773760 q11Shape16T265=true := by decide

private def q11Shape16T263 : Tree 11 := .split 31 q11Shape16T264 q11Shape16T265
private theorem q11Shape16T263OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1610612736 534773760 q11Shape16T263=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1610612736 (534773760 ||| 2^31) q11Shape16T264 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1610612736 ||| 2^31) 534773760 q11Shape16T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T264OK,q11Shape16T265OK⟩

private def q11Shape16T259 : Tree 11 := .split 30 q11Shape16T260 q11Shape16T263
private theorem q11Shape16T259OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 536870912 534773760 q11Shape16T259=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 536870912 (534773760 ||| 2^30) q11Shape16T260 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (536870912 ||| 2^30) 534773760 q11Shape16T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T260OK,q11Shape16T263OK⟩

def q11Shape16P7 : Tree 11 := q11Shape16T259
theorem q11Shape16P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 536870912 534773760 q11Shape16P7=true := q11Shape16T259OK

end Graffiti384b.EffectiveSearch.Q11
