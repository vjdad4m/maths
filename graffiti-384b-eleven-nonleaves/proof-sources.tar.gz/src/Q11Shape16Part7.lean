import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T270 : Tree 11 := (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.split 32 (.tip (.cover {2,3,4,5,6,9})) (.split 35 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {0,1,5,7,8,9})))) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape16T270OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 4024434688 q11Shape16T270=true := by decide

private def q11Shape16T271 : Tree 11 := (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.split 33 (.split 35 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T271OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2415919104 1876951040 q11Shape16T271=true := by decide

private def q11Shape16T269 : Tree 11 := .split 31 q11Shape16T270 q11Shape16T271
private theorem q11Shape16T269OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 1876951040 q11Shape16T269=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 (1876951040 ||| 2^31) q11Shape16T270 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (268435456 ||| 2^31) 1876951040 q11Shape16T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T270OK,q11Shape16T271OK⟩

private def q11Shape16T273 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.cover {2,3,4,5,6,7})) (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T273OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1342177280 2950692864 q11Shape16T273=true := by decide

private def q11Shape16T274 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T274OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3489660928 803209216 q11Shape16T274=true := by decide

private def q11Shape16T272 : Tree 11 := .split 31 q11Shape16T273 q11Shape16T274
private theorem q11Shape16T272OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1342177280 803209216 q11Shape16T272=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1342177280 (803209216 ||| 2^31) q11Shape16T273 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1342177280 ||| 2^31) 803209216 q11Shape16T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T273OK,q11Shape16T274OK⟩

private def q11Shape16T268 : Tree 11 := .split 30 q11Shape16T269 q11Shape16T272
private theorem q11Shape16T268OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 803209216 q11Shape16T268=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 (803209216 ||| 2^30) q11Shape16T269 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (268435456 ||| 2^30) 803209216 q11Shape16T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T269OK,q11Shape16T272OK⟩

private def q11Shape16T276 : Tree 11 := (.tip (.cover {2,3,4,5,9,10}))
private theorem q11Shape16T276OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 805306368 1340080128 q11Shape16T276=true := by decide

private def q11Shape16T282 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape16T282OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 66838331392 q11Shape16T282=true := by decide

private def q11Shape16T285 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T285OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36238786560 32478593540 q11Shape16T285=true := by decide

private def q11Shape16T286 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T286OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36238787072 32478593028 q11Shape16T286=true := by decide

private def q11Shape16T284 : Tree 11 := .split 9 q11Shape16T285 q11Shape16T286
private theorem q11Shape16T284OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36238786560 32478593028 q11Shape16T284=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36238786560 (32478593028 ||| 2^9) q11Shape16T285 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (36238786560 ||| 2^9) 32478593028 q11Shape16T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T285OK,q11Shape16T286OK⟩

private def q11Shape16T287 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape16T287OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36238786564 32478593024 q11Shape16T287=true := by decide

private def q11Shape16T283 : Tree 11 := .split 2 q11Shape16T284 q11Shape16T287
private theorem q11Shape16T283OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36238786560 32478593024 q11Shape16T283=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 36238786560 (32478593024 ||| 2^2) q11Shape16T284 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (36238786560 ||| 2^2) 32478593024 q11Shape16T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T284OK,q11Shape16T287OK⟩

private def q11Shape16T281 : Tree 11 := .split 35 q11Shape16T282 q11Shape16T283
private theorem q11Shape16T281OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 32478593024 q11Shape16T281=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 (32478593024 ||| 2^35) q11Shape16T282 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1879048192 ||| 2^35) 32478593024 q11Shape16T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T282OK,q11Shape16T283OK⟩

private def q11Shape16T288 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape16T288OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19058917376 15298723840 q11Shape16T288=true := by decide

private def q11Shape16T280 : Tree 11 := .split 34 q11Shape16T281 q11Shape16T288
private theorem q11Shape16T280OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 15298723840 q11Shape16T280=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 (15298723840 ||| 2^34) q11Shape16T281 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1879048192 ||| 2^34) 15298723840 q11Shape16T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T281OK,q11Shape16T288OK⟩

private def q11Shape16T289 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape16T289OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10468982784 6708789248 q11Shape16T289=true := by decide

private def q11Shape16T279 : Tree 11 := .split 33 q11Shape16T280 q11Shape16T289
private theorem q11Shape16T279OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 6708789248 q11Shape16T279=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 (6708789248 ||| 2^33) q11Shape16T280 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1879048192 ||| 2^33) 6708789248 q11Shape16T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T280OK,q11Shape16T289OK⟩

private def q11Shape16T290 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T290OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6174015488 2413821952 q11Shape16T290=true := by decide

private def q11Shape16T278 : Tree 11 := .split 32 q11Shape16T279 q11Shape16T290
private theorem q11Shape16T278OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 2413821952 q11Shape16T278=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 (2413821952 ||| 2^32) q11Shape16T279 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1879048192 ||| 2^32) 2413821952 q11Shape16T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T279OK,q11Shape16T290OK⟩

private def q11Shape16T291 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T291OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4026531840 266338304 q11Shape16T291=true := by decide

private def q11Shape16T277 : Tree 11 := .split 31 q11Shape16T278 q11Shape16T291
private theorem q11Shape16T277OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 266338304 q11Shape16T277=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1879048192 (266338304 ||| 2^31) q11Shape16T278 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1879048192 ||| 2^31) 266338304 q11Shape16T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T278OK,q11Shape16T291OK⟩

private def q11Shape16T275 : Tree 11 := .split 30 q11Shape16T276 q11Shape16T277
private theorem q11Shape16T275OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 805306368 266338304 q11Shape16T275=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 805306368 (266338304 ||| 2^30) q11Shape16T276 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (805306368 ||| 2^30) 266338304 q11Shape16T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T276OK,q11Shape16T277OK⟩

private def q11Shape16T267 : Tree 11 := .split 29 q11Shape16T268 q11Shape16T275
private theorem q11Shape16T267OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 266338304 q11Shape16T267=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 (266338304 ||| 2^29) q11Shape16T268 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (268435456 ||| 2^29) 266338304 q11Shape16T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T268OK,q11Shape16T275OK⟩

def q11Shape16P8 : Tree 11 := q11Shape16T267
theorem q11Shape16P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 268435456 266338304 q11Shape16P8=true := q11Shape16T267OK

end Graffiti384b.EffectiveSearch.Q11
