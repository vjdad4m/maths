import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T297 : Tree 11 := (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 35 (.split 32 (.tip (.cover {2,3,4,5,6,8})) (.split 34 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {0,1,5,7,8,9})))) (.tip (.cover {0,1,5,7,8,10}))))
private theorem q11Shape16T297OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 4158652416 q11Shape16T297=true := by decide

private def q11Shape16T298 : Tree 11 := (.split 32 (.split 33 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.split 35 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {0,1,5,6,7,10})))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T298OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2281701376 2011168768 q11Shape16T298=true := by decide

private def q11Shape16T296 : Tree 11 := .split 31 q11Shape16T297 q11Shape16T298
private theorem q11Shape16T296OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 2011168768 q11Shape16T296=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 (2011168768 ||| 2^31) q11Shape16T297 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (134217728 ||| 2^31) 2011168768 q11Shape16T298)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T297OK,q11Shape16T298OK⟩

private def q11Shape16T300 : Tree 11 := (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.split 33 (.split 34 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T300OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1207959552 3084910592 q11Shape16T300=true := by decide

private def q11Shape16T301 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T301OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3355443200 937426944 q11Shape16T301=true := by decide

private def q11Shape16T299 : Tree 11 := .split 31 q11Shape16T300 q11Shape16T301
private theorem q11Shape16T299OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1207959552 937426944 q11Shape16T299=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1207959552 (937426944 ||| 2^31) q11Shape16T300 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1207959552 ||| 2^31) 937426944 q11Shape16T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T300OK,q11Shape16T301OK⟩

private def q11Shape16T295 : Tree 11 := .split 30 q11Shape16T296 q11Shape16T299
private theorem q11Shape16T295OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 937426944 q11Shape16T295=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 (937426944 ||| 2^30) q11Shape16T296 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (134217728 ||| 2^30) 937426944 q11Shape16T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T296OK,q11Shape16T299OK⟩

private def q11Shape16T303 : Tree 11 := (.tip (.cover {2,3,4,5,8,10}))
private theorem q11Shape16T303OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 671088640 2548039680 q11Shape16T303=true := by decide

private def q11Shape16T308 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape16T308OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 31539068928 q11Shape16T308=true := by decide

private def q11Shape16T312 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T312OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441472 48718938628 q11Shape16T312=true := by decide

private def q11Shape16T313 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T313OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441984 48718938116 q11Shape16T313=true := by decide

private def q11Shape16T311 : Tree 11 := .split 9 q11Shape16T312 q11Shape16T313
private theorem q11Shape16T311OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441472 48718938116 q11Shape16T311=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441472 (48718938116 ||| 2^9) q11Shape16T312 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19998441472 ||| 2^9) 48718938116 q11Shape16T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T312OK,q11Shape16T313OK⟩

private def q11Shape16T314 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T314OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441476 48718938112 q11Shape16T314=true := by decide

private def q11Shape16T310 : Tree 11 := .split 2 q11Shape16T311 q11Shape16T314
private theorem q11Shape16T310OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441472 48718938112 q11Shape16T310=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441472 (48718938112 ||| 2^2) q11Shape16T311 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19998441472 ||| 2^2) 48718938112 q11Shape16T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T311OK,q11Shape16T314OK⟩

private def q11Shape16T315 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape16T315OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 54358179840 14359199744 q11Shape16T315=true := by decide

private def q11Shape16T309 : Tree 11 := .split 35 q11Shape16T310 q11Shape16T315
private theorem q11Shape16T309OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441472 14359199744 q11Shape16T309=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19998441472 (14359199744 ||| 2^35) q11Shape16T310 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19998441472 ||| 2^35) 14359199744 q11Shape16T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T310OK,q11Shape16T315OK⟩

private def q11Shape16T307 : Tree 11 := .split 34 q11Shape16T308 q11Shape16T309
private theorem q11Shape16T307OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 14359199744 q11Shape16T307=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 (14359199744 ||| 2^34) q11Shape16T308 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2818572288 ||| 2^34) 14359199744 q11Shape16T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T308OK,q11Shape16T309OK⟩

private def q11Shape16T316 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape16T316OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11408506880 5769265152 q11Shape16T316=true := by decide

private def q11Shape16T306 : Tree 11 := .split 33 q11Shape16T307 q11Shape16T316
private theorem q11Shape16T306OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 5769265152 q11Shape16T306=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 (5769265152 ||| 2^33) q11Shape16T307 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2818572288 ||| 2^33) 5769265152 q11Shape16T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T307OK,q11Shape16T316OK⟩

private def q11Shape16T317 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T317OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 7113539584 1474297856 q11Shape16T317=true := by decide

private def q11Shape16T305 : Tree 11 := .split 32 q11Shape16T306 q11Shape16T317
private theorem q11Shape16T305OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 1474297856 q11Shape16T305=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 (1474297856 ||| 2^32) q11Shape16T306 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2818572288 ||| 2^32) 1474297856 q11Shape16T317)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T306OK,q11Shape16T317OK⟩

private def q11Shape16T318 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T318OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 3892314112 400556032 q11Shape16T318=true := by decide

private def q11Shape16T304 : Tree 11 := .split 30 q11Shape16T305 q11Shape16T318
private theorem q11Shape16T304OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 400556032 q11Shape16T304=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2818572288 (400556032 ||| 2^30) q11Shape16T305 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (2818572288 ||| 2^30) 400556032 q11Shape16T318)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T305OK,q11Shape16T318OK⟩

private def q11Shape16T302 : Tree 11 := .split 31 q11Shape16T303 q11Shape16T304
private theorem q11Shape16T302OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 671088640 400556032 q11Shape16T302=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 671088640 (400556032 ||| 2^31) q11Shape16T303 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (671088640 ||| 2^31) 400556032 q11Shape16T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T303OK,q11Shape16T304OK⟩

private def q11Shape16T294 : Tree 11 := .split 29 q11Shape16T295 q11Shape16T302
private theorem q11Shape16T294OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 400556032 q11Shape16T294=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 (400556032 ||| 2^29) q11Shape16T295 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (134217728 ||| 2^29) 400556032 q11Shape16T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T295OK,q11Shape16T302OK⟩

private def q11Shape16T321 : Tree 11 := (.tip (.cover {2,3,4,5,8,9}))
private theorem q11Shape16T321OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 402653184 4963958784 q11Shape16T321=true := by decide

private def q11Shape16T325 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape16T325OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4697620480 12480151552 q11Shape16T325=true := by decide

private def q11Shape16T330 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T330OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 55429825028 q11Shape16T330=true := by decide

private def q11Shape16T331 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T331OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555584 55429824516 q11Shape16T331=true := by decide

private def q11Shape16T329 : Tree 11 := .split 9 q11Shape16T330 q11Shape16T331
private theorem q11Shape16T329OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 55429824516 q11Shape16T329=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 (55429824516 ||| 2^9) q11Shape16T330 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13287555072 ||| 2^9) 55429824516 q11Shape16T331)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T330OK,q11Shape16T331OK⟩

private def q11Shape16T332 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T332OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555076 55429824512 q11Shape16T332=true := by decide

private def q11Shape16T328 : Tree 11 := .split 2 q11Shape16T329 q11Shape16T332
private theorem q11Shape16T328OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 55429824512 q11Shape16T328=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 (55429824512 ||| 2^2) q11Shape16T329 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13287555072 ||| 2^2) 55429824512 q11Shape16T332)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T329OK,q11Shape16T332OK⟩

private def q11Shape16T333 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape16T333OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47647293440 21070086144 q11Shape16T333=true := by decide

private def q11Shape16T327 : Tree 11 := .split 35 q11Shape16T328 q11Shape16T333
private theorem q11Shape16T327OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 21070086144 q11Shape16T327=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 (21070086144 ||| 2^35) q11Shape16T328 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13287555072 ||| 2^35) 21070086144 q11Shape16T333)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T328OK,q11Shape16T333OK⟩

private def q11Shape16T334 : Tree 11 := (.tip (.cover {0,1,5,6,7,8}))
private theorem q11Shape16T334OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 30467424256 3890216960 q11Shape16T334=true := by decide

private def q11Shape16T326 : Tree 11 := .split 34 q11Shape16T327 q11Shape16T334
private theorem q11Shape16T326OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 3890216960 q11Shape16T326=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13287555072 (3890216960 ||| 2^34) q11Shape16T327 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13287555072 ||| 2^34) 3890216960 q11Shape16T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T327OK,q11Shape16T334OK⟩

private def q11Shape16T324 : Tree 11 := .split 33 q11Shape16T325 q11Shape16T326
private theorem q11Shape16T324OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4697620480 3890216960 q11Shape16T324=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4697620480 (3890216960 ||| 2^33) q11Shape16T325 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4697620480 ||| 2^33) 3890216960 q11Shape16T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T325OK,q11Shape16T326OK⟩

private def q11Shape16T335 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T335OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 6845104128 1742733312 q11Shape16T335=true := by decide

private def q11Shape16T323 : Tree 11 := .split 31 q11Shape16T324 q11Shape16T335
private theorem q11Shape16T323OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4697620480 1742733312 q11Shape16T323=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4697620480 (1742733312 ||| 2^31) q11Shape16T324 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4697620480 ||| 2^31) 1742733312 q11Shape16T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T324OK,q11Shape16T335OK⟩

private def q11Shape16T336 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape16T336OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 5771362304 668991488 q11Shape16T336=true := by decide

private def q11Shape16T322 : Tree 11 := .split 30 q11Shape16T323 q11Shape16T336
private theorem q11Shape16T322OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4697620480 668991488 q11Shape16T322=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 4697620480 (668991488 ||| 2^30) q11Shape16T323 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (4697620480 ||| 2^30) 668991488 q11Shape16T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T323OK,q11Shape16T336OK⟩

private def q11Shape16T320 : Tree 11 := .split 32 q11Shape16T321 q11Shape16T322
private theorem q11Shape16T320OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 402653184 668991488 q11Shape16T320=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 402653184 (668991488 ||| 2^32) q11Shape16T321 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (402653184 ||| 2^32) 668991488 q11Shape16T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T321OK,q11Shape16T322OK⟩

private def q11Shape16T338 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape16T338OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 939524096 1205862400 q11Shape16T338=true := by decide

private def q11Shape16T339 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape16T339OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2013265920 132120576 q11Shape16T339=true := by decide

private def q11Shape16T337 : Tree 11 := .split 30 q11Shape16T338 q11Shape16T339
private theorem q11Shape16T337OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 939524096 132120576 q11Shape16T337=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 939524096 (132120576 ||| 2^30) q11Shape16T338 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (939524096 ||| 2^30) 132120576 q11Shape16T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T338OK,q11Shape16T339OK⟩

private def q11Shape16T319 : Tree 11 := .split 29 q11Shape16T320 q11Shape16T337
private theorem q11Shape16T319OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 402653184 132120576 q11Shape16T319=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 402653184 (132120576 ||| 2^29) q11Shape16T320 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (402653184 ||| 2^29) 132120576 q11Shape16T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T320OK,q11Shape16T337OK⟩

private def q11Shape16T293 : Tree 11 := .split 28 q11Shape16T294 q11Shape16T319
private theorem q11Shape16T293OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 132120576 q11Shape16T293=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 (132120576 ||| 2^28) q11Shape16T294 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (134217728 ||| 2^28) 132120576 q11Shape16T319)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T294OK,q11Shape16T319OK⟩

def q11Shape16P9 : Tree 11 := q11Shape16T293
theorem q11Shape16P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 134217728 132120576 q11Shape16P9=true := q11Shape16T293OK

end Graffiti384b.EffectiveSearch.Q11
