import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape16T345 : Tree 11 := (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.split 32 (.tip (.cover {2,3,4,5,6,9})) (.split 35 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {0,1,5,6,8,10})))) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape16T345OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 4225761280 q11Shape16T345=true := by decide

private def q11Shape16T346 : Tree 11 := (.split 33 (.split 35 (.split 34 (.tip (.cover {2,3,4,5,6,7})) (.split 32 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {2,3,4,5,7,8}))) (.tip (.cover {0,1,5,7,8,9})))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,10})))
private theorem q11Shape16T346OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 2214592512 2078277632 q11Shape16T346=true := by decide

private def q11Shape16T344 : Tree 11 := .split 31 q11Shape16T345 q11Shape16T346
private theorem q11Shape16T344OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 2078277632 q11Shape16T344=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 (2078277632 ||| 2^31) q11Shape16T345 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (67108864 ||| 2^31) 2078277632 q11Shape16T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T345OK,q11Shape16T346OK⟩

private def q11Shape16T348 : Tree 11 := (.split 34 (.split 35 (.tip (.cover {2,3,4,5,6,7})) (.split 31 (.split 32 (.split 10 (.split 16 (.split 3 (.tip (.small 1)) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape16T348OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1140850688 9594470400 q11Shape16T348=true := by decide

private def q11Shape16T349 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape16T349OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9730785280 1004535808 q11Shape16T349=true := by decide

private def q11Shape16T347 : Tree 11 := .split 33 q11Shape16T348 q11Shape16T349
private theorem q11Shape16T347OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1140850688 1004535808 q11Shape16T347=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1140850688 (1004535808 ||| 2^33) q11Shape16T348 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (1140850688 ||| 2^33) 1004535808 q11Shape16T349)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T348OK,q11Shape16T349OK⟩

private def q11Shape16T343 : Tree 11 := .split 30 q11Shape16T344 q11Shape16T347
private theorem q11Shape16T343OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 1004535808 q11Shape16T343=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 (1004535808 ||| 2^30) q11Shape16T344 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (67108864 ||| 2^30) 1004535808 q11Shape16T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T344OK,q11Shape16T347OK⟩

private def q11Shape16T351 : Tree 11 := (.tip (.cover {2,3,4,5,7,10}))
private theorem q11Shape16T351OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 603979776 9057599488 q11Shape16T351=true := by decide

private def q11Shape16T356 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape16T356OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 25163726848 q11Shape16T356=true := by decide

private def q11Shape16T360 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,9}))))))
private theorem q11Shape16T360OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881664 55228498436 q11Shape16T360=true := by decide

private def q11Shape16T361 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T361OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488882176 55228497924 q11Shape16T361=true := by decide

private def q11Shape16T359 : Tree 11 := .split 9 q11Shape16T360 q11Shape16T361
private theorem q11Shape16T359OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881664 55228497924 q11Shape16T359=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881664 (55228497924 ||| 2^9) q11Shape16T360 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13488881664 ||| 2^9) 55228497924 q11Shape16T361)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T360OK,q11Shape16T361OK⟩

private def q11Shape16T362 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,9})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T362OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881668 55228497920 q11Shape16T362=true := by decide

private def q11Shape16T358 : Tree 11 := .split 2 q11Shape16T359 q11Shape16T362
private theorem q11Shape16T358OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881664 55228497920 q11Shape16T358=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881664 (55228497920 ||| 2^2) q11Shape16T359 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13488881664 ||| 2^2) 55228497920 q11Shape16T362)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T359OK,q11Shape16T362OK⟩

private def q11Shape16T363 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape16T363OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 47848620032 20868759552 q11Shape16T363=true := by decide

private def q11Shape16T357 : Tree 11 := .split 35 q11Shape16T358 q11Shape16T363
private theorem q11Shape16T357OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881664 20868759552 q11Shape16T357=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 13488881664 (20868759552 ||| 2^35) q11Shape16T358 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (13488881664 ||| 2^35) 20868759552 q11Shape16T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T358OK,q11Shape16T363OK⟩

private def q11Shape16T355 : Tree 11 := .split 32 q11Shape16T356 q11Shape16T357
private theorem q11Shape16T355OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 20868759552 q11Shape16T355=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 (20868759552 ||| 2^32) q11Shape16T356 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (9193914368 ||| 2^32) 20868759552 q11Shape16T357)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T356OK,q11Shape16T357OK⟩

private def q11Shape16T364 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape16T364OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 26373783552 3688890368 q11Shape16T364=true := by decide

private def q11Shape16T354 : Tree 11 := .split 34 q11Shape16T355 q11Shape16T364
private theorem q11Shape16T354OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 3688890368 q11Shape16T354=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 (3688890368 ||| 2^34) q11Shape16T355 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (9193914368 ||| 2^34) 3688890368 q11Shape16T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T355OK,q11Shape16T364OK⟩

private def q11Shape16T365 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape16T365OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 11341398016 1541406720 q11Shape16T365=true := by decide

private def q11Shape16T353 : Tree 11 := .split 31 q11Shape16T354 q11Shape16T365
private theorem q11Shape16T353OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 1541406720 q11Shape16T353=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 (1541406720 ||| 2^31) q11Shape16T354 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (9193914368 ||| 2^31) 1541406720 q11Shape16T365)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T354OK,q11Shape16T365OK⟩

private def q11Shape16T366 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape16T366OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 10267656192 467664896 q11Shape16T366=true := by decide

private def q11Shape16T352 : Tree 11 := .split 30 q11Shape16T353 q11Shape16T366
private theorem q11Shape16T352OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 467664896 q11Shape16T352=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 9193914368 (467664896 ||| 2^30) q11Shape16T353 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (9193914368 ||| 2^30) 467664896 q11Shape16T366)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T353OK,q11Shape16T366OK⟩

private def q11Shape16T350 : Tree 11 := .split 33 q11Shape16T351 q11Shape16T352
private theorem q11Shape16T350OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 603979776 467664896 q11Shape16T350=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 603979776 (467664896 ||| 2^33) q11Shape16T351 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (603979776 ||| 2^33) 467664896 q11Shape16T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T351OK,q11Shape16T352OK⟩

private def q11Shape16T342 : Tree 11 := .split 29 q11Shape16T343 q11Shape16T350
private theorem q11Shape16T342OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 467664896 q11Shape16T342=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 (467664896 ||| 2^29) q11Shape16T343 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (67108864 ||| 2^29) 467664896 q11Shape16T350)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T343OK,q11Shape16T350OK⟩

private def q11Shape16T369 : Tree 11 := (.tip (.cover {2,3,4,5,7,9}))
private theorem q11Shape16T369OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 335544320 17915969536 q11Shape16T369=true := by decide

private def q11Shape16T374 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape16T374OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 16842227712 q11Shape16T374=true := by decide

private def q11Shape16T378 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,6,7,8,10}))))))
private theorem q11Shape16T378OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897152 49054482948 q11Shape16T378=true := by decide

private def q11Shape16T379 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T379OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897664 49054482436 q11Shape16T379=true := by decide

private def q11Shape16T377 : Tree 11 := .split 9 q11Shape16T378 q11Shape16T379
private theorem q11Shape16T377OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897152 49054482436 q11Shape16T377=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897152 (49054482436 ||| 2^9) q11Shape16T378 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19662897152 ||| 2^9) 49054482436 q11Shape16T379)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T378OK,q11Shape16T379OK⟩

private def q11Shape16T380 : Tree 11 := (.split 9 (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,6,7,8,10})))) (.tip (.cover {2,3,4,6,7,8}))) (.tip (.cover {2,3,4,6,7,8})))
private theorem q11Shape16T380OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897156 49054482432 q11Shape16T380=true := by decide

private def q11Shape16T376 : Tree 11 := .split 2 q11Shape16T377 q11Shape16T380
private theorem q11Shape16T376OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897152 49054482432 q11Shape16T376=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897152 (49054482432 ||| 2^2) q11Shape16T377 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19662897152 ||| 2^2) 49054482432 q11Shape16T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T377OK,q11Shape16T380OK⟩

private def q11Shape16T381 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape16T381OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 54022635520 14694744064 q11Shape16T381=true := by decide

private def q11Shape16T375 : Tree 11 := .split 35 q11Shape16T376 q11Shape16T381
private theorem q11Shape16T375OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897152 14694744064 q11Shape16T375=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 19662897152 (14694744064 ||| 2^35) q11Shape16T376 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (19662897152 ||| 2^35) 14694744064 q11Shape16T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T376OK,q11Shape16T381OK⟩

private def q11Shape16T373 : Tree 11 := .split 31 q11Shape16T374 q11Shape16T375
private theorem q11Shape16T373OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 14694744064 q11Shape16T373=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 (14694744064 ||| 2^31) q11Shape16T374 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17515413504 ||| 2^31) 14694744064 q11Shape16T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T374OK,q11Shape16T375OK⟩

private def q11Shape16T382 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape16T382OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 26105348096 6104809472 q11Shape16T382=true := by decide

private def q11Shape16T372 : Tree 11 := .split 33 q11Shape16T373 q11Shape16T382
private theorem q11Shape16T372OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 6104809472 q11Shape16T372=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 (6104809472 ||| 2^33) q11Shape16T373 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17515413504 ||| 2^33) 6104809472 q11Shape16T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T373OK,q11Shape16T382OK⟩

private def q11Shape16T383 : Tree 11 := (.tip (.cover {0,1,5,7,8,9}))
private theorem q11Shape16T383OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 21810380800 1809842176 q11Shape16T383=true := by decide

private def q11Shape16T371 : Tree 11 := .split 32 q11Shape16T372 q11Shape16T383
private theorem q11Shape16T371OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 1809842176 q11Shape16T371=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 (1809842176 ||| 2^32) q11Shape16T372 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17515413504 ||| 2^32) 1809842176 q11Shape16T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T372OK,q11Shape16T383OK⟩

private def q11Shape16T384 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape16T384OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 18589155328 736100352 q11Shape16T384=true := by decide

private def q11Shape16T370 : Tree 11 := .split 30 q11Shape16T371 q11Shape16T384
private theorem q11Shape16T370OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 736100352 q11Shape16T370=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 17515413504 (736100352 ||| 2^30) q11Shape16T371 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (17515413504 ||| 2^30) 736100352 q11Shape16T384)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T371OK,q11Shape16T384OK⟩

private def q11Shape16T368 : Tree 11 := .split 34 q11Shape16T369 q11Shape16T370
private theorem q11Shape16T368OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 335544320 736100352 q11Shape16T368=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 335544320 (736100352 ||| 2^34) q11Shape16T369 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (335544320 ||| 2^34) 736100352 q11Shape16T370)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T369OK,q11Shape16T370OK⟩

private def q11Shape16T386 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8})))) (.split 32 (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape16T386OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 872415232 1272971264 q11Shape16T386=true := by decide

private def q11Shape16T387 : Tree 11 := (.split 31 (.split 32 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape16T387OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 1946157056 199229440 q11Shape16T387=true := by decide

private def q11Shape16T385 : Tree 11 := .split 30 q11Shape16T386 q11Shape16T387
private theorem q11Shape16T385OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 872415232 199229440 q11Shape16T385=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 872415232 (199229440 ||| 2^30) q11Shape16T386 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (872415232 ||| 2^30) 199229440 q11Shape16T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T386OK,q11Shape16T387OK⟩

private def q11Shape16T367 : Tree 11 := .split 29 q11Shape16T368 q11Shape16T385
private theorem q11Shape16T367OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 335544320 199229440 q11Shape16T367=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 335544320 (199229440 ||| 2^29) q11Shape16T368 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (335544320 ||| 2^29) 199229440 q11Shape16T385)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T368OK,q11Shape16T385OK⟩

private def q11Shape16T341 : Tree 11 := .split 28 q11Shape16T342 q11Shape16T367
private theorem q11Shape16T341OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 199229440 q11Shape16T341=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 (199229440 ||| 2^28) q11Shape16T342 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) (67108864 ||| 2^28) 199229440 q11Shape16T367)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape16T342OK,q11Shape16T367OK⟩

def q11Shape16P10 : Tree 11 := q11Shape16T341
theorem q11Shape16P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 16)) 67108864 199229440 q11Shape16P10=true := q11Shape16T341OK

end Graffiti384b.EffectiveSearch.Q11
