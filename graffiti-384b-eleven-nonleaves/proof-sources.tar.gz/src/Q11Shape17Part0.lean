import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape17T2 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.split 28 (.tip (.cover {2,3,4,5,8,10})) (.split 29 (.split 32 (.tip (.cover {2,3,4,5,8,9})) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,7,8,9,10})))) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape17T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 0 201326592 q11Shape17T2=true := by decide

private def q11Shape17T3 : Tree 11 := (.split 28 (.split 29 (.split 30 (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.split 32 (.tip (.cover {2,3,4,5,8,9})) (.tip (.cover {0,1,6,8,9,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape17T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 134217728 67108864 q11Shape17T3=true := by decide

private def q11Shape17T1 : Tree 11 := .split 27 q11Shape17T2 q11Shape17T3
private theorem q11Shape17T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 0 67108864 q11Shape17T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 0 (67108864 ||| 2^27) q11Shape17T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) (0 ||| 2^27) 67108864 q11Shape17T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape17T2OK,q11Shape17T3OK⟩

private def q11Shape17T5 : Tree 11 := (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape17T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 67108864 134217728 q11Shape17T5=true := by decide

private def q11Shape17T6 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape17T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 201326592 0 q11Shape17T6=true := by decide

private def q11Shape17T4 : Tree 11 := .split 27 q11Shape17T5 q11Shape17T6
private theorem q11Shape17T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 67108864 0 q11Shape17T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 67108864 (0 ||| 2^27) q11Shape17T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) (67108864 ||| 2^27) 0 q11Shape17T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape17T5OK,q11Shape17T6OK⟩

private def q11Shape17T0 : Tree 11 := .split 26 q11Shape17T1 q11Shape17T4
private theorem q11Shape17T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 0 0 q11Shape17T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 0 (0 ||| 2^26) q11Shape17T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) (0 ||| 2^26) 0 q11Shape17T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape17T1OK,q11Shape17T4OK⟩

def q11Shape17P0 : Tree 11 := q11Shape17T0
theorem q11Shape17P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,5,5,4⟩) 0 0 q11Shape17P0=true := q11Shape17T0OK

end Graffiti384b.EffectiveSearch.Q11
