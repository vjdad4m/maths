import Q11Shape19Part0
import Q11Shape19Part1

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape19M56 : Tree 11 := .split 8 q11Shape19P0 q11Shape19P1
private theorem q11Shape19M56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 0 q11Shape19M56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 (0 ||| 2^8) q11Shape19P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (0 ||| 2^8) 0 q11Shape19P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19P0OK,q11Shape19P1OK⟩

theorem q11Shape19_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 19) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 19) b) (adj 11 (forms 19) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) adj_mono b H q11Shape19M56 q11Shape19M56OK

#print axioms q11Shape19_cover

end Graffiti384b.EffectiveSearch.Q11
