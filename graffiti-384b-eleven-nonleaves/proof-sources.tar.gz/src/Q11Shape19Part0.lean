import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape19T3 : Tree 11 := (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10}))))))
private theorem q11Shape19T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 34560 q11Shape19T3=true := by decide

private def q11Shape19T5 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))))
private theorem q11Shape19T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 32768 67328 q11Shape19T5=true := by decide

private def q11Shape19T6 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))))
private theorem q11Shape19T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 98304 1792 q11Shape19T6=true := by decide

private def q11Shape19T4 : Tree 11 := .split 16 q11Shape19T5 q11Shape19T6
private theorem q11Shape19T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 32768 1792 q11Shape19T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 32768 (1792 ||| 2^16) q11Shape19T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (32768 ||| 2^16) 1792 q11Shape19T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T5OK,q11Shape19T6OK⟩

private def q11Shape19T2 : Tree 11 := .split 15 q11Shape19T3 q11Shape19T4
private theorem q11Shape19T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 1792 q11Shape19T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 (1792 ||| 2^15) q11Shape19T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (0 ||| 2^15) 1792 q11Shape19T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T3OK,q11Shape19T4OK⟩

private def q11Shape19T9 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,10})))))
private theorem q11Shape19T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1024 99072 q11Shape19T9=true := by decide

private def q11Shape19T10 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10}))))
private theorem q11Shape19T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 66560 33536 q11Shape19T10=true := by decide

private def q11Shape19T8 : Tree 11 := .split 16 q11Shape19T9 q11Shape19T10
private theorem q11Shape19T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1024 33536 q11Shape19T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1024 (33536 ||| 2^16) q11Shape19T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (1024 ||| 2^16) 33536 q11Shape19T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T9OK,q11Shape19T10OK⟩

private def q11Shape19T12 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))))
private theorem q11Shape19T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33792 66304 q11Shape19T12=true := by decide

private def q11Shape19T13 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10}))))
private theorem q11Shape19T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 99328 768 q11Shape19T13=true := by decide

private def q11Shape19T11 : Tree 11 := .split 16 q11Shape19T12 q11Shape19T13
private theorem q11Shape19T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33792 768 q11Shape19T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33792 (768 ||| 2^16) q11Shape19T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (33792 ||| 2^16) 768 q11Shape19T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T12OK,q11Shape19T13OK⟩

private def q11Shape19T7 : Tree 11 := .split 15 q11Shape19T8 q11Shape19T11
private theorem q11Shape19T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1024 768 q11Shape19T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1024 (768 ||| 2^15) q11Shape19T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (1024 ||| 2^15) 768 q11Shape19T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T8OK,q11Shape19T11OK⟩

private def q11Shape19T1 : Tree 11 := .split 10 q11Shape19T2 q11Shape19T7
private theorem q11Shape19T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 768 q11Shape19T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 (768 ||| 2^10) q11Shape19T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (0 ||| 2^10) 768 q11Shape19T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T2OK,q11Shape19T7OK⟩

private def q11Shape19T17 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10})))))
private theorem q11Shape19T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 512 99584 q11Shape19T17=true := by decide

private def q11Shape19T18 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))))
private theorem q11Shape19T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 66048 34048 q11Shape19T18=true := by decide

private def q11Shape19T16 : Tree 11 := .split 16 q11Shape19T17 q11Shape19T18
private theorem q11Shape19T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 512 34048 q11Shape19T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 512 (34048 ||| 2^16) q11Shape19T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (512 ||| 2^16) 34048 q11Shape19T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T17OK,q11Shape19T18OK⟩

private def q11Shape19T20 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,5,6,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape19T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33280 66816 q11Shape19T20=true := by decide

private def q11Shape19T21 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape19T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 98816 1280 q11Shape19T21=true := by decide

private def q11Shape19T19 : Tree 11 := .split 16 q11Shape19T20 q11Shape19T21
private theorem q11Shape19T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33280 1280 q11Shape19T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33280 (1280 ||| 2^16) q11Shape19T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (33280 ||| 2^16) 1280 q11Shape19T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T20OK,q11Shape19T21OK⟩

private def q11Shape19T15 : Tree 11 := .split 15 q11Shape19T16 q11Shape19T19
private theorem q11Shape19T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 512 1280 q11Shape19T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 512 (1280 ||| 2^15) q11Shape19T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (512 ||| 2^15) 1280 q11Shape19T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T16OK,q11Shape19T19OK⟩

private def q11Shape19T24 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))))
private theorem q11Shape19T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1536 98560 q11Shape19T24=true := by decide

private def q11Shape19T25 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10}))))
private theorem q11Shape19T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 67072 33024 q11Shape19T25=true := by decide

private def q11Shape19T23 : Tree 11 := .split 16 q11Shape19T24 q11Shape19T25
private theorem q11Shape19T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1536 33024 q11Shape19T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1536 (33024 ||| 2^16) q11Shape19T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (1536 ||| 2^16) 33024 q11Shape19T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T24OK,q11Shape19T25OK⟩

private def q11Shape19T27 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape19T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 34304 65792 q11Shape19T27=true := by decide

private def q11Shape19T28 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {2,3,4,8,9,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape19T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 99840 256 q11Shape19T28=true := by decide

private def q11Shape19T26 : Tree 11 := .split 16 q11Shape19T27 q11Shape19T28
private theorem q11Shape19T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 34304 256 q11Shape19T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 34304 (256 ||| 2^16) q11Shape19T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (34304 ||| 2^16) 256 q11Shape19T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T27OK,q11Shape19T28OK⟩

private def q11Shape19T22 : Tree 11 := .split 15 q11Shape19T23 q11Shape19T26
private theorem q11Shape19T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1536 256 q11Shape19T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1536 (256 ||| 2^15) q11Shape19T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (1536 ||| 2^15) 256 q11Shape19T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T23OK,q11Shape19T26OK⟩

private def q11Shape19T14 : Tree 11 := .split 10 q11Shape19T15 q11Shape19T22
private theorem q11Shape19T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 512 256 q11Shape19T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 512 (256 ||| 2^10) q11Shape19T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (512 ||| 2^10) 256 q11Shape19T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T15OK,q11Shape19T22OK⟩

private def q11Shape19T0 : Tree 11 := .split 9 q11Shape19T1 q11Shape19T14
private theorem q11Shape19T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 256 q11Shape19T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 (256 ||| 2^9) q11Shape19T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (0 ||| 2^9) 256 q11Shape19T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T1OK,q11Shape19T14OK⟩

def q11Shape19P0 : Tree 11 := q11Shape19T0
theorem q11Shape19P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 0 256 q11Shape19P0=true := q11Shape19T0OK

end Graffiti384b.EffectiveSearch.Q11
