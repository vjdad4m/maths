import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape19T33 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))))
private theorem q11Shape19T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 99840 q11Shape19T33=true := by decide

private def q11Shape19T34 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))))
private theorem q11Shape19T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 65792 34304 q11Shape19T34=true := by decide

private def q11Shape19T32 : Tree 11 := .split 16 q11Shape19T33 q11Shape19T34
private theorem q11Shape19T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 34304 q11Shape19T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 (34304 ||| 2^16) q11Shape19T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (256 ||| 2^16) 34304 q11Shape19T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T33OK,q11Shape19T34OK⟩

private def q11Shape19T36 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,4,6,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))))
private theorem q11Shape19T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33024 67072 q11Shape19T36=true := by decide

private def q11Shape19T37 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10}))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape19T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 98560 1536 q11Shape19T37=true := by decide

private def q11Shape19T35 : Tree 11 := .split 16 q11Shape19T36 q11Shape19T37
private theorem q11Shape19T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33024 1536 q11Shape19T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33024 (1536 ||| 2^16) q11Shape19T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (33024 ||| 2^16) 1536 q11Shape19T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T36OK,q11Shape19T37OK⟩

private def q11Shape19T31 : Tree 11 := .split 15 q11Shape19T32 q11Shape19T35
private theorem q11Shape19T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 1536 q11Shape19T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 (1536 ||| 2^15) q11Shape19T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (256 ||| 2^15) 1536 q11Shape19T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T32OK,q11Shape19T35OK⟩

private def q11Shape19T40 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))))
private theorem q11Shape19T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1280 98816 q11Shape19T40=true := by decide

private def q11Shape19T41 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,6,7,9,10}))))
private theorem q11Shape19T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 66816 33280 q11Shape19T41=true := by decide

private def q11Shape19T39 : Tree 11 := .split 16 q11Shape19T40 q11Shape19T41
private theorem q11Shape19T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1280 33280 q11Shape19T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1280 (33280 ||| 2^16) q11Shape19T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (1280 ||| 2^16) 33280 q11Shape19T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T40OK,q11Shape19T41OK⟩

private def q11Shape19T43 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {2,3,5,8,9,10})))))
private theorem q11Shape19T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 34048 66048 q11Shape19T43=true := by decide

private def q11Shape19T44 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10}))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape19T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 99584 512 q11Shape19T44=true := by decide

private def q11Shape19T42 : Tree 11 := .split 16 q11Shape19T43 q11Shape19T44
private theorem q11Shape19T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 34048 512 q11Shape19T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 34048 (512 ||| 2^16) q11Shape19T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (34048 ||| 2^16) 512 q11Shape19T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T43OK,q11Shape19T44OK⟩

private def q11Shape19T38 : Tree 11 := .split 15 q11Shape19T39 q11Shape19T42
private theorem q11Shape19T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1280 512 q11Shape19T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1280 (512 ||| 2^15) q11Shape19T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (1280 ||| 2^15) 512 q11Shape19T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T39OK,q11Shape19T42OK⟩

private def q11Shape19T30 : Tree 11 := .split 10 q11Shape19T31 q11Shape19T38
private theorem q11Shape19T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 512 q11Shape19T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 (512 ||| 2^10) q11Shape19T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (256 ||| 2^10) 512 q11Shape19T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T31OK,q11Shape19T38OK⟩

private def q11Shape19T48 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))))
private theorem q11Shape19T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 768 99328 q11Shape19T48=true := by decide

private def q11Shape19T49 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {2,3,6,8,9,10})))))
private theorem q11Shape19T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 66304 33792 q11Shape19T49=true := by decide

private def q11Shape19T47 : Tree 11 := .split 16 q11Shape19T48 q11Shape19T49
private theorem q11Shape19T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 768 33792 q11Shape19T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 768 (33792 ||| 2^16) q11Shape19T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (768 ||| 2^16) 33792 q11Shape19T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T48OK,q11Shape19T49OK⟩

private def q11Shape19T51 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.split 31 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10})))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape19T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33536 66560 q11Shape19T51=true := by decide

private def q11Shape19T52 : Tree 11 := (.split 21 (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10}))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape19T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 99072 1024 q11Shape19T52=true := by decide

private def q11Shape19T50 : Tree 11 := .split 16 q11Shape19T51 q11Shape19T52
private theorem q11Shape19T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33536 1024 q11Shape19T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 33536 (1024 ||| 2^16) q11Shape19T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (33536 ||| 2^16) 1024 q11Shape19T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T51OK,q11Shape19T52OK⟩

private def q11Shape19T46 : Tree 11 := .split 15 q11Shape19T47 q11Shape19T50
private theorem q11Shape19T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 768 1024 q11Shape19T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 768 (1024 ||| 2^15) q11Shape19T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (768 ||| 2^15) 1024 q11Shape19T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T47OK,q11Shape19T50OK⟩

private def q11Shape19T54 : Tree 11 := (.split 16 (.split 21 (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10}))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10})))) (.split 21 (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10}))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10})))))
private theorem q11Shape19T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1792 32768 q11Shape19T54=true := by decide

private def q11Shape19T55 : Tree 11 := (.split 16 (.split 21 (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10}))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10})))) (.split 21 (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10}))) (.split 30 (.tip (.small 1)) (.tip (.cover {0,1,3,7,9,10})))))
private theorem q11Shape19T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 34560 0 q11Shape19T55=true := by decide

private def q11Shape19T53 : Tree 11 := .split 15 q11Shape19T54 q11Shape19T55
private theorem q11Shape19T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1792 0 q11Shape19T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 1792 (0 ||| 2^15) q11Shape19T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (1792 ||| 2^15) 0 q11Shape19T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T54OK,q11Shape19T55OK⟩

private def q11Shape19T45 : Tree 11 := .split 10 q11Shape19T46 q11Shape19T53
private theorem q11Shape19T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 768 0 q11Shape19T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 768 (0 ||| 2^10) q11Shape19T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (768 ||| 2^10) 0 q11Shape19T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T46OK,q11Shape19T53OK⟩

private def q11Shape19T29 : Tree 11 := .split 9 q11Shape19T30 q11Shape19T45
private theorem q11Shape19T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 0 q11Shape19T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 (0 ||| 2^9) q11Shape19T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) (256 ||| 2^9) 0 q11Shape19T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape19T30OK,q11Shape19T45OK⟩

def q11Shape19P1 : Tree 11 := q11Shape19T29
theorem q11Shape19P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,1⟩) 256 0 q11Shape19P1=true := q11Shape19T29OK

end Graffiti384b.EffectiveSearch.Q11
