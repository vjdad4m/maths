import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape1T3 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10}))))))
private theorem q11Shape1T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 11813355520 q11Shape1T3=true := by decide

private def q11Shape1T4 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10}))))))
private theorem q11Shape1T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589934592 3223420928 q11Shape1T4=true := by decide

private def q11Shape1T2 : Tree 11 := .split 33 q11Shape1T3 q11Shape1T4
private theorem q11Shape1T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 3223420928 q11Shape1T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 (3223420928 ||| 2^33) q11Shape1T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (0 ||| 2^33) 3223420928 q11Shape1T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T3OK,q11Shape1T4OK⟩

private def q11Shape1T6 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10}))))))
private theorem q11Shape1T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147483648 9665871872 q11Shape1T6=true := by decide

private def q11Shape1T7 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,9,10})))))
private theorem q11Shape1T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 10737418240 1075937280 q11Shape1T7=true := by decide

private def q11Shape1T5 : Tree 11 := .split 33 q11Shape1T6 q11Shape1T7
private theorem q11Shape1T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147483648 1075937280 q11Shape1T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147483648 (1075937280 ||| 2^33) q11Shape1T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147483648 ||| 2^33) 1075937280 q11Shape1T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T6OK,q11Shape1T7OK⟩

private def q11Shape1T1 : Tree 11 := .split 31 q11Shape1T2 q11Shape1T5
private theorem q11Shape1T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 1075937280 q11Shape1T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 (1075937280 ||| 2^31) q11Shape1T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (0 ||| 2^31) 1075937280 q11Shape1T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T2OK,q11Shape1T5OK⟩

private def q11Shape1T10 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10}))))))
private theorem q11Shape1T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073741824 10739613696 q11Shape1T10=true := by decide

private def q11Shape1T11 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,8,10})))))
private theorem q11Shape1T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 9663676416 2149679104 q11Shape1T11=true := by decide

private def q11Shape1T9 : Tree 11 := .split 33 q11Shape1T10 q11Shape1T11
private theorem q11Shape1T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073741824 2149679104 q11Shape1T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073741824 (2149679104 ||| 2^33) q11Shape1T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073741824 ||| 2^33) 2149679104 q11Shape1T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T10OK,q11Shape1T11OK⟩

private def q11Shape1T12 : Tree 11 := (.split 33 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,7,10}))))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,1,2,6,7,10}))))))
private theorem q11Shape1T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 3221225472 2195456 q11Shape1T12=true := by decide

private def q11Shape1T8 : Tree 11 := .split 31 q11Shape1T9 q11Shape1T12
private theorem q11Shape1T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073741824 2195456 q11Shape1T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073741824 (2195456 ||| 2^31) q11Shape1T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073741824 ||| 2^31) 2195456 q11Shape1T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T9OK,q11Shape1T12OK⟩

private def q11Shape1T0 : Tree 11 := .split 30 q11Shape1T1 q11Shape1T8
private theorem q11Shape1T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 2195456 q11Shape1T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 (2195456 ||| 2^30) q11Shape1T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (0 ||| 2^30) 2195456 q11Shape1T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T1OK,q11Shape1T8OK⟩

def q11Shape1P0 : Tree 11 := q11Shape1T0
theorem q11Shape1P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 0 2195456 q11Shape1P0=true := q11Shape1T0OK

end Graffiti384b.EffectiveSearch.Q11
