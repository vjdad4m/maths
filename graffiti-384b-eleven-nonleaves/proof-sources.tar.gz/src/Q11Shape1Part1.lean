import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape1T17 : Tree 11 := (.tip (.small 1))
private theorem q11Shape1T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 11811258369 q11Shape1T17=true := by decide

private def q11Shape1T19 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))))
private theorem q11Shape1T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097153 11811258370 q11Shape1T19=true := by decide

private def q11Shape1T21 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))))
private theorem q11Shape1T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097155 11811258372 q11Shape1T21=true := by decide

private def q11Shape1T22 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape1T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097159 11811258368 q11Shape1T22=true := by decide

private def q11Shape1T20 : Tree 11 := .split 2 q11Shape1T21 q11Shape1T22
private theorem q11Shape1T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097155 11811258368 q11Shape1T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097155 (11811258368 ||| 2^2) q11Shape1T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2097155 ||| 2^2) 11811258368 q11Shape1T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T21OK,q11Shape1T22OK⟩

private def q11Shape1T18 : Tree 11 := .split 1 q11Shape1T19 q11Shape1T20
private theorem q11Shape1T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097153 11811258368 q11Shape1T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097153 (11811258368 ||| 2^1) q11Shape1T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2097153 ||| 2^1) 11811258368 q11Shape1T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T19OK,q11Shape1T20OK⟩

private def q11Shape1T16 : Tree 11 := .split 0 q11Shape1T17 q11Shape1T18
private theorem q11Shape1T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 11811258368 q11Shape1T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 (11811258368 ||| 2^0) q11Shape1T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2097152 ||| 2^0) 11811258368 q11Shape1T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T17OK,q11Shape1T18OK⟩

private def q11Shape1T24 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10})))))
private theorem q11Shape1T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031744 3221323777 q11Shape1T24=true := by decide

private def q11Shape1T26 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10})))))))
private theorem q11Shape1T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031745 3221323778 q11Shape1T26=true := by decide

private def q11Shape1T28 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape1T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031747 3221323780 q11Shape1T28=true := by decide

private def q11Shape1T29 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))) (.tip (.cover {0,1,2,7,8,10})))
private theorem q11Shape1T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031751 3221323776 q11Shape1T29=true := by decide

private def q11Shape1T27 : Tree 11 := .split 2 q11Shape1T28 q11Shape1T29
private theorem q11Shape1T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031747 3221323776 q11Shape1T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031747 (3221323776 ||| 2^2) q11Shape1T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8592031747 ||| 2^2) 3221323776 q11Shape1T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T28OK,q11Shape1T29OK⟩

private def q11Shape1T25 : Tree 11 := .split 1 q11Shape1T26 q11Shape1T27
private theorem q11Shape1T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031745 3221323776 q11Shape1T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031745 (3221323776 ||| 2^1) q11Shape1T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8592031745 ||| 2^1) 3221323776 q11Shape1T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T26OK,q11Shape1T27OK⟩

private def q11Shape1T23 : Tree 11 := .split 0 q11Shape1T24 q11Shape1T25
private theorem q11Shape1T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031744 3221323776 q11Shape1T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592031744 (3221323776 ||| 2^0) q11Shape1T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8592031744 ||| 2^0) 3221323776 q11Shape1T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T24OK,q11Shape1T25OK⟩

private def q11Shape1T15 : Tree 11 := .split 33 q11Shape1T16 q11Shape1T23
private theorem q11Shape1T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 3221323776 q11Shape1T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 (3221323776 ||| 2^33) q11Shape1T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2097152 ||| 2^33) 3221323776 q11Shape1T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T16OK,q11Shape1T23OK⟩

private def q11Shape1T32 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10})))))
private theorem q11Shape1T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580800 9663774721 q11Shape1T32=true := by decide

private def q11Shape1T34 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10})))))))
private theorem q11Shape1T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580801 9663774722 q11Shape1T34=true := by decide

private def q11Shape1T36 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape1T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580803 9663774724 q11Shape1T36=true := by decide

private def q11Shape1T37 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))) (.tip (.cover {0,1,2,7,8,10})))
private theorem q11Shape1T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580807 9663774720 q11Shape1T37=true := by decide

private def q11Shape1T35 : Tree 11 := .split 2 q11Shape1T36 q11Shape1T37
private theorem q11Shape1T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580803 9663774720 q11Shape1T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580803 (9663774720 ||| 2^2) q11Shape1T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2149580803 ||| 2^2) 9663774720 q11Shape1T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T36OK,q11Shape1T37OK⟩

private def q11Shape1T33 : Tree 11 := .split 1 q11Shape1T34 q11Shape1T35
private theorem q11Shape1T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580801 9663774720 q11Shape1T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580801 (9663774720 ||| 2^1) q11Shape1T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2149580801 ||| 2^1) 9663774720 q11Shape1T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T34OK,q11Shape1T35OK⟩

private def q11Shape1T31 : Tree 11 := .split 0 q11Shape1T32 q11Shape1T33
private theorem q11Shape1T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580800 9663774720 q11Shape1T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580800 (9663774720 ||| 2^0) q11Shape1T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2149580800 ||| 2^0) 9663774720 q11Shape1T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T32OK,q11Shape1T33OK⟩

private def q11Shape1T38 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape1T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 10739515392 1073840128 q11Shape1T38=true := by decide

private def q11Shape1T30 : Tree 11 := .split 33 q11Shape1T31 q11Shape1T38
private theorem q11Shape1T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580800 1073840128 q11Shape1T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149580800 (1073840128 ||| 2^33) q11Shape1T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2149580800 ||| 2^33) 1073840128 q11Shape1T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T31OK,q11Shape1T38OK⟩

private def q11Shape1T14 : Tree 11 := .split 31 q11Shape1T15 q11Shape1T30
private theorem q11Shape1T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 1073840128 q11Shape1T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 (1073840128 ||| 2^31) q11Shape1T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2097152 ||| 2^31) 1073840128 q11Shape1T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T15OK,q11Shape1T30OK⟩

private def q11Shape1T42 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10})))))
private theorem q11Shape1T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838976 10737516545 q11Shape1T42=true := by decide

private def q11Shape1T44 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10})))))))
private theorem q11Shape1T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838977 10737516546 q11Shape1T44=true := by decide

private def q11Shape1T46 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))))
private theorem q11Shape1T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838979 10737516548 q11Shape1T46=true := by decide

private def q11Shape1T47 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape1T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838983 10737516544 q11Shape1T47=true := by decide

private def q11Shape1T45 : Tree 11 := .split 2 q11Shape1T46 q11Shape1T47
private theorem q11Shape1T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838979 10737516544 q11Shape1T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838979 (10737516544 ||| 2^2) q11Shape1T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1075838979 ||| 2^2) 10737516544 q11Shape1T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T46OK,q11Shape1T47OK⟩

private def q11Shape1T43 : Tree 11 := .split 1 q11Shape1T44 q11Shape1T45
private theorem q11Shape1T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838977 10737516544 q11Shape1T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838977 (10737516544 ||| 2^1) q11Shape1T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1075838977 ||| 2^1) 10737516544 q11Shape1T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T44OK,q11Shape1T45OK⟩

private def q11Shape1T41 : Tree 11 := .split 0 q11Shape1T42 q11Shape1T43
private theorem q11Shape1T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838976 10737516544 q11Shape1T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838976 (10737516544 ||| 2^0) q11Shape1T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1075838976 ||| 2^0) 10737516544 q11Shape1T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T42OK,q11Shape1T43OK⟩

private def q11Shape1T48 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape1T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 9665773568 2147581952 q11Shape1T48=true := by decide

private def q11Shape1T40 : Tree 11 := .split 33 q11Shape1T41 q11Shape1T48
private theorem q11Shape1T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838976 2147581952 q11Shape1T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838976 (2147581952 ||| 2^33) q11Shape1T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1075838976 ||| 2^33) 2147581952 q11Shape1T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T41OK,q11Shape1T48OK⟩

private def q11Shape1T49 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape1T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 3223322624 98304 q11Shape1T49=true := by decide

private def q11Shape1T39 : Tree 11 := .split 31 q11Shape1T40 q11Shape1T49
private theorem q11Shape1T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838976 98304 q11Shape1T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075838976 (98304 ||| 2^31) q11Shape1T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1075838976 ||| 2^31) 98304 q11Shape1T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T40OK,q11Shape1T49OK⟩

private def q11Shape1T13 : Tree 11 := .split 30 q11Shape1T14 q11Shape1T39
private theorem q11Shape1T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 98304 q11Shape1T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 (98304 ||| 2^30) q11Shape1T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2097152 ||| 2^30) 98304 q11Shape1T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T14OK,q11Shape1T39OK⟩

def q11Shape1P1 : Tree 11 := q11Shape1T13
theorem q11Shape1P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2097152 98304 q11Shape1P1=true := q11Shape1T13OK

end Graffiti384b.EffectiveSearch.Q11
