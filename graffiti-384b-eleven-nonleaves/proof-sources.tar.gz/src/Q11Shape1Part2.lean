import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape1T55 : Tree 11 := (.tip (.small 1))
private theorem q11Shape1T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 11813289985 q11Shape1T55=true := by decide

private def q11Shape1T57 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))))
private theorem q11Shape1T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65537 11813289986 q11Shape1T57=true := by decide

private def q11Shape1T59 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))))
private theorem q11Shape1T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65539 11813289988 q11Shape1T59=true := by decide

private def q11Shape1T60 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape1T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65543 11813289984 q11Shape1T60=true := by decide

private def q11Shape1T58 : Tree 11 := .split 2 q11Shape1T59 q11Shape1T60
private theorem q11Shape1T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65539 11813289984 q11Shape1T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65539 (11813289984 ||| 2^2) q11Shape1T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (65539 ||| 2^2) 11813289984 q11Shape1T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T59OK,q11Shape1T60OK⟩

private def q11Shape1T56 : Tree 11 := .split 1 q11Shape1T57 q11Shape1T58
private theorem q11Shape1T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65537 11813289984 q11Shape1T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65537 (11813289984 ||| 2^1) q11Shape1T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (65537 ||| 2^1) 11813289984 q11Shape1T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T57OK,q11Shape1T58OK⟩

private def q11Shape1T54 : Tree 11 := .split 0 q11Shape1T55 q11Shape1T56
private theorem q11Shape1T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 11813289984 q11Shape1T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 (11813289984 ||| 2^0) q11Shape1T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (65536 ||| 2^0) 11813289984 q11Shape1T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T55OK,q11Shape1T56OK⟩

private def q11Shape1T62 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10})))))
private theorem q11Shape1T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000128 3223355393 q11Shape1T62=true := by decide

private def q11Shape1T64 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10})))))))
private theorem q11Shape1T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000129 3223355394 q11Shape1T64=true := by decide

private def q11Shape1T66 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape1T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000131 3223355396 q11Shape1T66=true := by decide

private def q11Shape1T67 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))) (.tip (.cover {0,1,2,7,8,10})))
private theorem q11Shape1T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000135 3223355392 q11Shape1T67=true := by decide

private def q11Shape1T65 : Tree 11 := .split 2 q11Shape1T66 q11Shape1T67
private theorem q11Shape1T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000131 3223355392 q11Shape1T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000131 (3223355392 ||| 2^2) q11Shape1T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8590000131 ||| 2^2) 3223355392 q11Shape1T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T66OK,q11Shape1T67OK⟩

private def q11Shape1T63 : Tree 11 := .split 1 q11Shape1T64 q11Shape1T65
private theorem q11Shape1T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000129 3223355392 q11Shape1T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000129 (3223355392 ||| 2^1) q11Shape1T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8590000129 ||| 2^1) 3223355392 q11Shape1T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T64OK,q11Shape1T65OK⟩

private def q11Shape1T61 : Tree 11 := .split 0 q11Shape1T62 q11Shape1T63
private theorem q11Shape1T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000128 3223355392 q11Shape1T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590000128 (3223355392 ||| 2^0) q11Shape1T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8590000128 ||| 2^0) 3223355392 q11Shape1T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T62OK,q11Shape1T63OK⟩

private def q11Shape1T53 : Tree 11 := .split 33 q11Shape1T54 q11Shape1T61
private theorem q11Shape1T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 3223355392 q11Shape1T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 (3223355392 ||| 2^33) q11Shape1T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (65536 ||| 2^33) 3223355392 q11Shape1T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T54OK,q11Shape1T61OK⟩

private def q11Shape1T70 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10})))))
private theorem q11Shape1T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549184 9665806337 q11Shape1T70=true := by decide

private def q11Shape1T72 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10})))))))
private theorem q11Shape1T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549185 9665806338 q11Shape1T72=true := by decide

private def q11Shape1T74 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape1T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549187 9665806340 q11Shape1T74=true := by decide

private def q11Shape1T75 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))) (.tip (.cover {0,1,2,7,8,10})))
private theorem q11Shape1T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549191 9665806336 q11Shape1T75=true := by decide

private def q11Shape1T73 : Tree 11 := .split 2 q11Shape1T74 q11Shape1T75
private theorem q11Shape1T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549187 9665806336 q11Shape1T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549187 (9665806336 ||| 2^2) q11Shape1T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147549187 ||| 2^2) 9665806336 q11Shape1T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T74OK,q11Shape1T75OK⟩

private def q11Shape1T71 : Tree 11 := .split 1 q11Shape1T72 q11Shape1T73
private theorem q11Shape1T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549185 9665806336 q11Shape1T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549185 (9665806336 ||| 2^1) q11Shape1T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147549185 ||| 2^1) 9665806336 q11Shape1T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T72OK,q11Shape1T73OK⟩

private def q11Shape1T69 : Tree 11 := .split 0 q11Shape1T70 q11Shape1T71
private theorem q11Shape1T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549184 9665806336 q11Shape1T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549184 (9665806336 ||| 2^0) q11Shape1T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147549184 ||| 2^0) 9665806336 q11Shape1T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T70OK,q11Shape1T71OK⟩

private def q11Shape1T76 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape1T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 10737483776 1075871744 q11Shape1T76=true := by decide

private def q11Shape1T68 : Tree 11 := .split 33 q11Shape1T69 q11Shape1T76
private theorem q11Shape1T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549184 1075871744 q11Shape1T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147549184 (1075871744 ||| 2^33) q11Shape1T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147549184 ||| 2^33) 1075871744 q11Shape1T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T69OK,q11Shape1T76OK⟩

private def q11Shape1T52 : Tree 11 := .split 31 q11Shape1T53 q11Shape1T68
private theorem q11Shape1T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 1075871744 q11Shape1T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 (1075871744 ||| 2^31) q11Shape1T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (65536 ||| 2^31) 1075871744 q11Shape1T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T53OK,q11Shape1T68OK⟩

private def q11Shape1T80 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10})))))
private theorem q11Shape1T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807360 10739548161 q11Shape1T80=true := by decide

private def q11Shape1T82 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10})))))))
private theorem q11Shape1T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807361 10739548162 q11Shape1T82=true := by decide

private def q11Shape1T84 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))))
private theorem q11Shape1T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807363 10739548164 q11Shape1T84=true := by decide

private def q11Shape1T85 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape1T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807367 10739548160 q11Shape1T85=true := by decide

private def q11Shape1T83 : Tree 11 := .split 2 q11Shape1T84 q11Shape1T85
private theorem q11Shape1T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807363 10739548160 q11Shape1T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807363 (10739548160 ||| 2^2) q11Shape1T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073807363 ||| 2^2) 10739548160 q11Shape1T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T84OK,q11Shape1T85OK⟩

private def q11Shape1T81 : Tree 11 := .split 1 q11Shape1T82 q11Shape1T83
private theorem q11Shape1T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807361 10739548160 q11Shape1T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807361 (10739548160 ||| 2^1) q11Shape1T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073807361 ||| 2^1) 10739548160 q11Shape1T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T82OK,q11Shape1T83OK⟩

private def q11Shape1T79 : Tree 11 := .split 0 q11Shape1T80 q11Shape1T81
private theorem q11Shape1T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807360 10739548160 q11Shape1T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807360 (10739548160 ||| 2^0) q11Shape1T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073807360 ||| 2^0) 10739548160 q11Shape1T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T80OK,q11Shape1T81OK⟩

private def q11Shape1T86 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape1T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 9663741952 2149613568 q11Shape1T86=true := by decide

private def q11Shape1T78 : Tree 11 := .split 33 q11Shape1T79 q11Shape1T86
private theorem q11Shape1T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807360 2149613568 q11Shape1T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807360 (2149613568 ||| 2^33) q11Shape1T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073807360 ||| 2^33) 2149613568 q11Shape1T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T79OK,q11Shape1T86OK⟩

private def q11Shape1T87 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape1T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 3221291008 2129920 q11Shape1T87=true := by decide

private def q11Shape1T77 : Tree 11 := .split 31 q11Shape1T78 q11Shape1T87
private theorem q11Shape1T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807360 2129920 q11Shape1T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073807360 (2129920 ||| 2^31) q11Shape1T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073807360 ||| 2^31) 2129920 q11Shape1T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T78OK,q11Shape1T87OK⟩

private def q11Shape1T51 : Tree 11 := .split 30 q11Shape1T52 q11Shape1T77
private theorem q11Shape1T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 2129920 q11Shape1T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 (2129920 ||| 2^30) q11Shape1T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (65536 ||| 2^30) 2129920 q11Shape1T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T52OK,q11Shape1T77OK⟩

def q11Shape1P2 : Tree 11 := q11Shape1T51
theorem q11Shape1P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 65536 2129920 q11Shape1P2=true := q11Shape1T51OK

end Graffiti384b.EffectiveSearch.Q11
