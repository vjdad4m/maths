import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape1T92 : Tree 11 := (.tip (.small 1))
private theorem q11Shape1T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 11811192833 q11Shape1T92=true := by decide

private def q11Shape1T95 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10})))))
private theorem q11Shape1T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162689 11811192838 q11Shape1T95=true := by decide

private def q11Shape1T97 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))
private theorem q11Shape1T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162693 11811192842 q11Shape1T97=true := by decide

private def q11Shape1T98 : Tree 11 := (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))))
private theorem q11Shape1T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162701 11811192834 q11Shape1T98=true := by decide

private def q11Shape1T96 : Tree 11 := .split 3 q11Shape1T97 q11Shape1T98
private theorem q11Shape1T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162693 11811192834 q11Shape1T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162693 (11811192834 ||| 2^3) q11Shape1T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162693 ||| 2^3) 11811192834 q11Shape1T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T97OK,q11Shape1T98OK⟩

private def q11Shape1T94 : Tree 11 := .split 2 q11Shape1T95 q11Shape1T96
private theorem q11Shape1T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162689 11811192834 q11Shape1T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162689 (11811192834 ||| 2^2) q11Shape1T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162689 ||| 2^2) 11811192834 q11Shape1T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T95OK,q11Shape1T96OK⟩

private def q11Shape1T101 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))
private theorem q11Shape1T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162691 11811192844 q11Shape1T101=true := by decide

private def q11Shape1T102 : Tree 11 := (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))))
private theorem q11Shape1T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162699 11811192836 q11Shape1T102=true := by decide

private def q11Shape1T100 : Tree 11 := .split 3 q11Shape1T101 q11Shape1T102
private theorem q11Shape1T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162691 11811192836 q11Shape1T100=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162691 (11811192836 ||| 2^3) q11Shape1T101 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162691 ||| 2^3) 11811192836 q11Shape1T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T101OK,q11Shape1T102OK⟩

private def q11Shape1T103 : Tree 11 := (.split 3 (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10})))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape1T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162695 11811192832 q11Shape1T103=true := by decide

private def q11Shape1T99 : Tree 11 := .split 2 q11Shape1T100 q11Shape1T103
private theorem q11Shape1T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162691 11811192832 q11Shape1T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162691 (11811192832 ||| 2^2) q11Shape1T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162691 ||| 2^2) 11811192832 q11Shape1T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T100OK,q11Shape1T103OK⟩

private def q11Shape1T93 : Tree 11 := .split 1 q11Shape1T94 q11Shape1T99
private theorem q11Shape1T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162689 11811192832 q11Shape1T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162689 (11811192832 ||| 2^1) q11Shape1T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162689 ||| 2^1) 11811192832 q11Shape1T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T94OK,q11Shape1T99OK⟩

private def q11Shape1T91 : Tree 11 := .split 0 q11Shape1T92 q11Shape1T93
private theorem q11Shape1T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 11811192832 q11Shape1T91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 (11811192832 ||| 2^0) q11Shape1T92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162688 ||| 2^0) 11811192832 q11Shape1T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T92OK,q11Shape1T93OK⟩

private def q11Shape1T104 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape1T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592097280 3221258240 q11Shape1T104=true := by decide

private def q11Shape1T90 : Tree 11 := .split 33 q11Shape1T91 q11Shape1T104
private theorem q11Shape1T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 3221258240 q11Shape1T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 (3221258240 ||| 2^33) q11Shape1T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162688 ||| 2^33) 3221258240 q11Shape1T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T91OK,q11Shape1T104OK⟩

private def q11Shape1T105 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape1T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149646336 1073774592 q11Shape1T105=true := by decide

private def q11Shape1T89 : Tree 11 := .split 31 q11Shape1T90 q11Shape1T105
private theorem q11Shape1T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 1073774592 q11Shape1T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 (1073774592 ||| 2^31) q11Shape1T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162688 ||| 2^31) 1073774592 q11Shape1T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T90OK,q11Shape1T105OK⟩

private def q11Shape1T106 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape1T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075904512 32768 q11Shape1T106=true := by decide

private def q11Shape1T88 : Tree 11 := .split 30 q11Shape1T89 q11Shape1T106
private theorem q11Shape1T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 32768 q11Shape1T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 (32768 ||| 2^30) q11Shape1T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2162688 ||| 2^30) 32768 q11Shape1T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T89OK,q11Shape1T106OK⟩

def q11Shape1P3 : Tree 11 := q11Shape1T88
theorem q11Shape1P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2162688 32768 q11Shape1P3=true := q11Shape1T88OK

end Graffiti384b.EffectiveSearch.Q11
