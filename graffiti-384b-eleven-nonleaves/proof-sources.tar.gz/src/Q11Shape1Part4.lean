import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape1T113 : Tree 11 := (.tip (.small 1))
private theorem q11Shape1T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 11813322753 q11Shape1T113=true := by decide

private def q11Shape1T115 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))))
private theorem q11Shape1T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32769 11813322754 q11Shape1T115=true := by decide

private def q11Shape1T117 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))))
private theorem q11Shape1T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32771 11813322756 q11Shape1T117=true := by decide

private def q11Shape1T118 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape1T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32775 11813322752 q11Shape1T118=true := by decide

private def q11Shape1T116 : Tree 11 := .split 2 q11Shape1T117 q11Shape1T118
private theorem q11Shape1T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32771 11813322752 q11Shape1T116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32771 (11813322752 ||| 2^2) q11Shape1T117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32771 ||| 2^2) 11813322752 q11Shape1T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T117OK,q11Shape1T118OK⟩

private def q11Shape1T114 : Tree 11 := .split 1 q11Shape1T115 q11Shape1T116
private theorem q11Shape1T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32769 11813322752 q11Shape1T114=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32769 (11813322752 ||| 2^1) q11Shape1T115 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32769 ||| 2^1) 11813322752 q11Shape1T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T115OK,q11Shape1T116OK⟩

private def q11Shape1T112 : Tree 11 := .split 0 q11Shape1T113 q11Shape1T114
private theorem q11Shape1T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 11813322752 q11Shape1T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 (11813322752 ||| 2^0) q11Shape1T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32768 ||| 2^0) 11813322752 q11Shape1T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T113OK,q11Shape1T114OK⟩

private def q11Shape1T120 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10})))))
private theorem q11Shape1T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967360 3223388161 q11Shape1T120=true := by decide

private def q11Shape1T122 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10})))))))
private theorem q11Shape1T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967361 3223388162 q11Shape1T122=true := by decide

private def q11Shape1T124 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape1T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967363 3223388164 q11Shape1T124=true := by decide

private def q11Shape1T125 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.tip (.cover {0,1,2,7,8,10})))
private theorem q11Shape1T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967367 3223388160 q11Shape1T125=true := by decide

private def q11Shape1T123 : Tree 11 := .split 2 q11Shape1T124 q11Shape1T125
private theorem q11Shape1T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967363 3223388160 q11Shape1T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967363 (3223388160 ||| 2^2) q11Shape1T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8589967363 ||| 2^2) 3223388160 q11Shape1T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T124OK,q11Shape1T125OK⟩

private def q11Shape1T121 : Tree 11 := .split 1 q11Shape1T122 q11Shape1T123
private theorem q11Shape1T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967361 3223388160 q11Shape1T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967361 (3223388160 ||| 2^1) q11Shape1T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8589967361 ||| 2^1) 3223388160 q11Shape1T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T122OK,q11Shape1T123OK⟩

private def q11Shape1T119 : Tree 11 := .split 0 q11Shape1T120 q11Shape1T121
private theorem q11Shape1T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967360 3223388160 q11Shape1T119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8589967360 (3223388160 ||| 2^0) q11Shape1T120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (8589967360 ||| 2^0) 3223388160 q11Shape1T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T120OK,q11Shape1T121OK⟩

private def q11Shape1T111 : Tree 11 := .split 33 q11Shape1T112 q11Shape1T119
private theorem q11Shape1T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 3223388160 q11Shape1T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 (3223388160 ||| 2^33) q11Shape1T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32768 ||| 2^33) 3223388160 q11Shape1T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T112OK,q11Shape1T119OK⟩

private def q11Shape1T128 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,8,10})))))
private theorem q11Shape1T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516416 9665839105 q11Shape1T128=true := by decide

private def q11Shape1T130 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10})))))))
private theorem q11Shape1T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516417 9665839106 q11Shape1T130=true := by decide

private def q11Shape1T132 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape1T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516419 9665839108 q11Shape1T132=true := by decide

private def q11Shape1T133 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.tip (.cover {0,1,2,7,8,10})))
private theorem q11Shape1T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516423 9665839104 q11Shape1T133=true := by decide

private def q11Shape1T131 : Tree 11 := .split 2 q11Shape1T132 q11Shape1T133
private theorem q11Shape1T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516419 9665839104 q11Shape1T131=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516419 (9665839104 ||| 2^2) q11Shape1T132 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147516419 ||| 2^2) 9665839104 q11Shape1T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T132OK,q11Shape1T133OK⟩

private def q11Shape1T129 : Tree 11 := .split 1 q11Shape1T130 q11Shape1T131
private theorem q11Shape1T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516417 9665839104 q11Shape1T129=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516417 (9665839104 ||| 2^1) q11Shape1T130 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147516417 ||| 2^1) 9665839104 q11Shape1T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T130OK,q11Shape1T131OK⟩

private def q11Shape1T127 : Tree 11 := .split 0 q11Shape1T128 q11Shape1T129
private theorem q11Shape1T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516416 9665839104 q11Shape1T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516416 (9665839104 ||| 2^0) q11Shape1T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147516416 ||| 2^0) 9665839104 q11Shape1T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T128OK,q11Shape1T129OK⟩

private def q11Shape1T134 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape1T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 10737451008 1075904512 q11Shape1T134=true := by decide

private def q11Shape1T126 : Tree 11 := .split 33 q11Shape1T127 q11Shape1T134
private theorem q11Shape1T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516416 1075904512 q11Shape1T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147516416 (1075904512 ||| 2^33) q11Shape1T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2147516416 ||| 2^33) 1075904512 q11Shape1T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T127OK,q11Shape1T134OK⟩

private def q11Shape1T110 : Tree 11 := .split 31 q11Shape1T111 q11Shape1T126
private theorem q11Shape1T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 1075904512 q11Shape1T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 (1075904512 ||| 2^31) q11Shape1T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32768 ||| 2^31) 1075904512 q11Shape1T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T111OK,q11Shape1T126OK⟩

private def q11Shape1T138 : Tree 11 := (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10})))))
private theorem q11Shape1T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774592 10739580929 q11Shape1T138=true := by decide

private def q11Shape1T140 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10})))))))
private theorem q11Shape1T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774593 10739580930 q11Shape1T140=true := by decide

private def q11Shape1T142 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))))
private theorem q11Shape1T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774595 10739580932 q11Shape1T142=true := by decide

private def q11Shape1T143 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape1T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774599 10739580928 q11Shape1T143=true := by decide

private def q11Shape1T141 : Tree 11 := .split 2 q11Shape1T142 q11Shape1T143
private theorem q11Shape1T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774595 10739580928 q11Shape1T141=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774595 (10739580928 ||| 2^2) q11Shape1T142 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073774595 ||| 2^2) 10739580928 q11Shape1T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T142OK,q11Shape1T143OK⟩

private def q11Shape1T139 : Tree 11 := .split 1 q11Shape1T140 q11Shape1T141
private theorem q11Shape1T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774593 10739580928 q11Shape1T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774593 (10739580928 ||| 2^1) q11Shape1T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073774593 ||| 2^1) 10739580928 q11Shape1T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T140OK,q11Shape1T141OK⟩

private def q11Shape1T137 : Tree 11 := .split 0 q11Shape1T138 q11Shape1T139
private theorem q11Shape1T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774592 10739580928 q11Shape1T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774592 (10739580928 ||| 2^0) q11Shape1T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073774592 ||| 2^0) 10739580928 q11Shape1T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T138OK,q11Shape1T139OK⟩

private def q11Shape1T144 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape1T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 9663709184 2149646336 q11Shape1T144=true := by decide

private def q11Shape1T136 : Tree 11 := .split 33 q11Shape1T137 q11Shape1T144
private theorem q11Shape1T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774592 2149646336 q11Shape1T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774592 (2149646336 ||| 2^33) q11Shape1T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073774592 ||| 2^33) 2149646336 q11Shape1T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T137OK,q11Shape1T144OK⟩

private def q11Shape1T145 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape1T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 3221258240 2162688 q11Shape1T145=true := by decide

private def q11Shape1T135 : Tree 11 := .split 31 q11Shape1T136 q11Shape1T145
private theorem q11Shape1T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774592 2162688 q11Shape1T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073774592 (2162688 ||| 2^31) q11Shape1T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (1073774592 ||| 2^31) 2162688 q11Shape1T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T136OK,q11Shape1T145OK⟩

private def q11Shape1T109 : Tree 11 := .split 30 q11Shape1T110 q11Shape1T135
private theorem q11Shape1T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 2162688 q11Shape1T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 (2162688 ||| 2^30) q11Shape1T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (32768 ||| 2^30) 2162688 q11Shape1T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T110OK,q11Shape1T135OK⟩

def q11Shape1P4 : Tree 11 := q11Shape1T109
theorem q11Shape1P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 32768 2162688 q11Shape1P4=true := q11Shape1T109OK

end Graffiti384b.EffectiveSearch.Q11
