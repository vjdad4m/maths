import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape1T150 : Tree 11 := (.tip (.small 1))
private theorem q11Shape1T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 11811225601 q11Shape1T150=true := by decide

private def q11Shape1T153 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))))
private theorem q11Shape1T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129921 11811225606 q11Shape1T153=true := by decide

private def q11Shape1T154 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))) (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape1T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129925 11811225602 q11Shape1T154=true := by decide

private def q11Shape1T152 : Tree 11 := .split 2 q11Shape1T153 q11Shape1T154
private theorem q11Shape1T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129921 11811225602 q11Shape1T152=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129921 (11811225602 ||| 2^2) q11Shape1T153 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129921 ||| 2^2) 11811225602 q11Shape1T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T153OK,q11Shape1T154OK⟩

private def q11Shape1T157 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))
private theorem q11Shape1T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129923 11811225612 q11Shape1T157=true := by decide

private def q11Shape1T158 : Tree 11 := (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10}))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))))
private theorem q11Shape1T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129931 11811225604 q11Shape1T158=true := by decide

private def q11Shape1T156 : Tree 11 := .split 3 q11Shape1T157 q11Shape1T158
private theorem q11Shape1T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129923 11811225604 q11Shape1T156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129923 (11811225604 ||| 2^3) q11Shape1T157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129923 ||| 2^3) 11811225604 q11Shape1T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T157OK,q11Shape1T158OK⟩

private def q11Shape1T159 : Tree 11 := (.split 3 (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape1T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129927 11811225600 q11Shape1T159=true := by decide

private def q11Shape1T155 : Tree 11 := .split 2 q11Shape1T156 q11Shape1T159
private theorem q11Shape1T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129923 11811225600 q11Shape1T155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129923 (11811225600 ||| 2^2) q11Shape1T156 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129923 ||| 2^2) 11811225600 q11Shape1T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T156OK,q11Shape1T159OK⟩

private def q11Shape1T151 : Tree 11 := .split 1 q11Shape1T152 q11Shape1T155
private theorem q11Shape1T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129921 11811225600 q11Shape1T151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129921 (11811225600 ||| 2^1) q11Shape1T152 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129921 ||| 2^1) 11811225600 q11Shape1T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T152OK,q11Shape1T155OK⟩

private def q11Shape1T149 : Tree 11 := .split 0 q11Shape1T150 q11Shape1T151
private theorem q11Shape1T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 11811225600 q11Shape1T149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 (11811225600 ||| 2^0) q11Shape1T150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129920 ||| 2^0) 11811225600 q11Shape1T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T150OK,q11Shape1T151OK⟩

private def q11Shape1T160 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape1T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592064512 3221291008 q11Shape1T160=true := by decide

private def q11Shape1T148 : Tree 11 := .split 33 q11Shape1T149 q11Shape1T160
private theorem q11Shape1T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 3221291008 q11Shape1T148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 (3221291008 ||| 2^33) q11Shape1T149 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129920 ||| 2^33) 3221291008 q11Shape1T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T149OK,q11Shape1T160OK⟩

private def q11Shape1T161 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape1T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149613568 1073807360 q11Shape1T161=true := by decide

private def q11Shape1T147 : Tree 11 := .split 31 q11Shape1T148 q11Shape1T161
private theorem q11Shape1T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 1073807360 q11Shape1T147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 (1073807360 ||| 2^31) q11Shape1T148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129920 ||| 2^31) 1073807360 q11Shape1T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T148OK,q11Shape1T161OK⟩

private def q11Shape1T162 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape1T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075871744 65536 q11Shape1T162=true := by decide

private def q11Shape1T146 : Tree 11 := .split 30 q11Shape1T147 q11Shape1T162
private theorem q11Shape1T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 65536 q11Shape1T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 (65536 ||| 2^30) q11Shape1T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2129920 ||| 2^30) 65536 q11Shape1T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T147OK,q11Shape1T162OK⟩

def q11Shape1P5 : Tree 11 := q11Shape1T146
theorem q11Shape1P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2129920 65536 q11Shape1P5=true := q11Shape1T146OK

private def q11Shape1T169 : Tree 11 := (.tip (.small 1))
private theorem q11Shape1T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 11813257217 q11Shape1T169=true := by decide

private def q11Shape1T172 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))))
private theorem q11Shape1T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98305 11813257222 q11Shape1T172=true := by decide

private def q11Shape1T173 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))) (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {5,6,7,8,9,10})))) (.tip (.cover {2,4,7,8,9,10}))))
private theorem q11Shape1T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98309 11813257218 q11Shape1T173=true := by decide

private def q11Shape1T171 : Tree 11 := .split 2 q11Shape1T172 q11Shape1T173
private theorem q11Shape1T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98305 11813257218 q11Shape1T171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98305 (11813257218 ||| 2^2) q11Shape1T172 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98305 ||| 2^2) 11813257218 q11Shape1T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T172OK,q11Shape1T173OK⟩

private def q11Shape1T175 : Tree 11 := (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))))
private theorem q11Shape1T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98307 11813257220 q11Shape1T175=true := by decide

private def q11Shape1T176 : Tree 11 := (.split 3 (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape1T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98311 11813257216 q11Shape1T176=true := by decide

private def q11Shape1T174 : Tree 11 := .split 2 q11Shape1T175 q11Shape1T176
private theorem q11Shape1T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98307 11813257216 q11Shape1T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98307 (11813257216 ||| 2^2) q11Shape1T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98307 ||| 2^2) 11813257216 q11Shape1T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T175OK,q11Shape1T176OK⟩

private def q11Shape1T170 : Tree 11 := .split 1 q11Shape1T171 q11Shape1T174
private theorem q11Shape1T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98305 11813257216 q11Shape1T170=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98305 (11813257216 ||| 2^1) q11Shape1T171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98305 ||| 2^1) 11813257216 q11Shape1T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T171OK,q11Shape1T174OK⟩

private def q11Shape1T168 : Tree 11 := .split 0 q11Shape1T169 q11Shape1T170
private theorem q11Shape1T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 11813257216 q11Shape1T168=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 (11813257216 ||| 2^0) q11Shape1T169 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98304 ||| 2^0) 11813257216 q11Shape1T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T169OK,q11Shape1T170OK⟩

private def q11Shape1T177 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape1T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8590032896 3223322624 q11Shape1T177=true := by decide

private def q11Shape1T167 : Tree 11 := .split 33 q11Shape1T168 q11Shape1T177
private theorem q11Shape1T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 3223322624 q11Shape1T167=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 (3223322624 ||| 2^33) q11Shape1T168 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98304 ||| 2^33) 3223322624 q11Shape1T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T168OK,q11Shape1T177OK⟩

private def q11Shape1T178 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape1T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2147581952 1075838976 q11Shape1T178=true := by decide

private def q11Shape1T166 : Tree 11 := .split 31 q11Shape1T167 q11Shape1T178
private theorem q11Shape1T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 1075838976 q11Shape1T166=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 (1075838976 ||| 2^31) q11Shape1T167 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98304 ||| 2^31) 1075838976 q11Shape1T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T167OK,q11Shape1T178OK⟩

private def q11Shape1T179 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape1T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1073840128 2097152 q11Shape1T179=true := by decide

private def q11Shape1T165 : Tree 11 := .split 30 q11Shape1T166 q11Shape1T179
private theorem q11Shape1T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 2097152 q11Shape1T165=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 (2097152 ||| 2^30) q11Shape1T166 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98304 ||| 2^30) 2097152 q11Shape1T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T166OK,q11Shape1T179OK⟩

private def q11Shape1T184 : Tree 11 := (.tip (.small 1))
private theorem q11Shape1T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 11811160065 q11Shape1T184=true := by decide

private def q11Shape1T188 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))
private theorem q11Shape1T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195457 11811160078 q11Shape1T188=true := by decide

private def q11Shape1T189 : Tree 11 := (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))))
private theorem q11Shape1T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195465 11811160070 q11Shape1T189=true := by decide

private def q11Shape1T187 : Tree 11 := .split 3 q11Shape1T188 q11Shape1T189
private theorem q11Shape1T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195457 11811160070 q11Shape1T187=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195457 (11811160070 ||| 2^3) q11Shape1T188 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195457 ||| 2^3) 11811160070 q11Shape1T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T188OK,q11Shape1T189OK⟩

private def q11Shape1T191 : Tree 11 := (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))))
private theorem q11Shape1T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195461 11811160074 q11Shape1T191=true := by decide

private def q11Shape1T192 : Tree 11 := (.split 8 (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {2,4,7,8,9,10})))
private theorem q11Shape1T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195469 11811160066 q11Shape1T192=true := by decide

private def q11Shape1T190 : Tree 11 := .split 3 q11Shape1T191 q11Shape1T192
private theorem q11Shape1T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195461 11811160066 q11Shape1T190=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195461 (11811160066 ||| 2^3) q11Shape1T191 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195461 ||| 2^3) 11811160066 q11Shape1T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T191OK,q11Shape1T192OK⟩

private def q11Shape1T186 : Tree 11 := .split 2 q11Shape1T187 q11Shape1T190
private theorem q11Shape1T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195457 11811160066 q11Shape1T186=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195457 (11811160066 ||| 2^2) q11Shape1T187 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195457 ||| 2^2) 11811160066 q11Shape1T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T187OK,q11Shape1T190OK⟩

private def q11Shape1T194 : Tree 11 := (.split 3 (.split 8 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.split 8 (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))))
private theorem q11Shape1T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195459 11811160068 q11Shape1T194=true := by decide

private def q11Shape1T195 : Tree 11 := (.split 3 (.split 8 (.split 9 (.split 10 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape1T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195463 11811160064 q11Shape1T195=true := by decide

private def q11Shape1T193 : Tree 11 := .split 2 q11Shape1T194 q11Shape1T195
private theorem q11Shape1T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195459 11811160064 q11Shape1T193=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195459 (11811160064 ||| 2^2) q11Shape1T194 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195459 ||| 2^2) 11811160064 q11Shape1T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T194OK,q11Shape1T195OK⟩

private def q11Shape1T185 : Tree 11 := .split 1 q11Shape1T186 q11Shape1T193
private theorem q11Shape1T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195457 11811160064 q11Shape1T185=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195457 (11811160064 ||| 2^1) q11Shape1T186 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195457 ||| 2^1) 11811160064 q11Shape1T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T186OK,q11Shape1T193OK⟩

private def q11Shape1T183 : Tree 11 := .split 0 q11Shape1T184 q11Shape1T185
private theorem q11Shape1T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 11811160064 q11Shape1T183=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 (11811160064 ||| 2^0) q11Shape1T184 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195456 ||| 2^0) 11811160064 q11Shape1T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T184OK,q11Shape1T185OK⟩

private def q11Shape1T196 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape1T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 8592130048 3221225472 q11Shape1T196=true := by decide

private def q11Shape1T182 : Tree 11 := .split 33 q11Shape1T183 q11Shape1T196
private theorem q11Shape1T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 3221225472 q11Shape1T182=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 (3221225472 ||| 2^33) q11Shape1T183 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195456 ||| 2^33) 3221225472 q11Shape1T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T183OK,q11Shape1T196OK⟩

private def q11Shape1T197 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape1T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2149679104 1073741824 q11Shape1T197=true := by decide

private def q11Shape1T181 : Tree 11 := .split 31 q11Shape1T182 q11Shape1T197
private theorem q11Shape1T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 1073741824 q11Shape1T181=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 (1073741824 ||| 2^31) q11Shape1T182 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195456 ||| 2^31) 1073741824 q11Shape1T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T182OK,q11Shape1T197OK⟩

private def q11Shape1T198 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape1T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 1075937280 0 q11Shape1T198=true := by decide

private def q11Shape1T180 : Tree 11 := .split 30 q11Shape1T181 q11Shape1T198
private theorem q11Shape1T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 0 q11Shape1T180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 2195456 (0 ||| 2^30) q11Shape1T181 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (2195456 ||| 2^30) 0 q11Shape1T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T181OK,q11Shape1T198OK⟩

private def q11Shape1T164 : Tree 11 := .split 21 q11Shape1T165 q11Shape1T180
private theorem q11Shape1T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 0 q11Shape1T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 (0 ||| 2^21) q11Shape1T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) (98304 ||| 2^21) 0 q11Shape1T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape1T165OK,q11Shape1T180OK⟩

def q11Shape1P6 : Tree 11 := q11Shape1T164
theorem q11Shape1P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,2⟩) 98304 0 q11Shape1P6=true := q11Shape1T164OK

end Graffiti384b.EffectiveSearch.Q11
