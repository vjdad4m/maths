import Q11Shape2Part0
import Q11Shape2Part1
import Q11Shape2Part2
import Q11Shape2Part3
import Q11Shape2Part4

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape2M44 : Tree 11 := .split 30 q11Shape2P0 q11Shape2P1
private theorem q11Shape2M44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 2097152 q11Shape2M44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 (2097152 ||| 2^30) q11Shape2P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (0 ||| 2^30) 2097152 q11Shape2P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2P0OK,q11Shape2P1OK⟩
private def q11Shape2M116 : Tree 11 := .split 1 q11Shape2P3 q11Shape2P4
private theorem q11Shape2M116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 1073741824 q11Shape2M116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 (1073741824 ||| 2^1) q11Shape2P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097153 ||| 2^1) 1073741824 q11Shape2P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2P3OK,q11Shape2P4OK⟩
private def q11Shape2M117 : Tree 11 := .split 0 q11Shape2P2 q11Shape2M116
private theorem q11Shape2M117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 1073741824 q11Shape2M117=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 (1073741824 ||| 2^0) q11Shape2P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097152 ||| 2^0) 1073741824 q11Shape2M116)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2P2OK,q11Shape2M116OK⟩
private def q11Shape2M119 : Tree 11 := .split 30 q11Shape2M117 q11Shape2P5
private theorem q11Shape2M119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 0 q11Shape2M119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 (0 ||| 2^30) q11Shape2M117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097152 ||| 2^30) 0 q11Shape2P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2M117OK,q11Shape2P5OK⟩
private def q11Shape2M120 : Tree 11 := .split 21 q11Shape2M44 q11Shape2M119
private theorem q11Shape2M120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 0 q11Shape2M120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 (0 ||| 2^21) q11Shape2M44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (0 ||| 2^21) 0 q11Shape2M119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2M44OK,q11Shape2M119OK⟩

theorem q11Shape2_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 2) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 2) b) (adj 11 (forms 2) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) adj_mono b H q11Shape2M120 q11Shape2M120OK

#print axioms q11Shape2_cover

end Graffiti384b.EffectiveSearch.Q11
