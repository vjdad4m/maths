import Q11Shape20Part0
import Q11Shape20Part1
import Q11Shape20Part2
import Q11Shape20Part3

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape20M68 : Tree 11 := .split 21 q11Shape20P0 q11Shape20P1
private theorem q11Shape20M68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 98304 q11Shape20M68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 (98304 ||| 2^21) q11Shape20P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (0 ||| 2^21) 98304 q11Shape20P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20P0OK,q11Shape20P1OK⟩
private def q11Shape20M88 : Tree 11 := .split 16 q11Shape20M68 q11Shape20P2
private theorem q11Shape20M88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 32768 q11Shape20M88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 (32768 ||| 2^16) q11Shape20M68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (0 ||| 2^16) 32768 q11Shape20P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20M68OK,q11Shape20P2OK⟩
private def q11Shape20M112 : Tree 11 := .split 15 q11Shape20M88 q11Shape20P3
private theorem q11Shape20M112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 0 q11Shape20M112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 (0 ||| 2^15) q11Shape20M88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (0 ||| 2^15) 0 q11Shape20P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20M88OK,q11Shape20P3OK⟩

theorem q11Shape20_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 20) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 20) b) (adj 11 (forms 20) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) adj_mono b H q11Shape20M112 q11Shape20M112OK

#print axioms q11Shape20_cover

end Graffiti384b.EffectiveSearch.Q11
