import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape20T2 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 1075937281 q11Shape20T2=true := by decide

private def q11Shape20T4 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1 1075937296 q11Shape20T4=true := by decide

private def q11Shape20T6 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 17 1075937312 q11Shape20T6=true := by decide

private def q11Shape20T8 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 49 1075939328 q11Shape20T8=true := by decide

private def q11Shape20T10 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097 1075941376 q11Shape20T10=true := by decide

private def q11Shape20T12 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,2,3,5,9,10})))) (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,2,3,6,9,10}))) (.tip (.cover {0,1,2,4,9,10}))))
private theorem q11Shape20T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 6193 1075937282 q11Shape20T12=true := by decide

private def q11Shape20T13 : Tree 11 := (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape20T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 6195 1075937280 q11Shape20T13=true := by decide

private def q11Shape20T11 : Tree 11 := .split 1 q11Shape20T12 q11Shape20T13
private theorem q11Shape20T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 6193 1075937280 q11Shape20T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 6193 (1075937280 ||| 2^1) q11Shape20T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (6193 ||| 2^1) 1075937280 q11Shape20T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T12OK,q11Shape20T13OK⟩

private def q11Shape20T9 : Tree 11 := .split 12 q11Shape20T10 q11Shape20T11
private theorem q11Shape20T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097 1075937280 q11Shape20T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097 (1075937280 ||| 2^12) q11Shape20T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (2097 ||| 2^12) 1075937280 q11Shape20T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T10OK,q11Shape20T11OK⟩

private def q11Shape20T7 : Tree 11 := .split 11 q11Shape20T8 q11Shape20T9
private theorem q11Shape20T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 49 1075937280 q11Shape20T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 49 (1075937280 ||| 2^11) q11Shape20T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (49 ||| 2^11) 1075937280 q11Shape20T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T8OK,q11Shape20T9OK⟩

private def q11Shape20T5 : Tree 11 := .split 5 q11Shape20T6 q11Shape20T7
private theorem q11Shape20T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 17 1075937280 q11Shape20T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 17 (1075937280 ||| 2^5) q11Shape20T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (17 ||| 2^5) 1075937280 q11Shape20T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T6OK,q11Shape20T7OK⟩

private def q11Shape20T3 : Tree 11 := .split 4 q11Shape20T4 q11Shape20T5
private theorem q11Shape20T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1 1075937280 q11Shape20T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1 (1075937280 ||| 2^4) q11Shape20T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1 ||| 2^4) 1075937280 q11Shape20T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T4OK,q11Shape20T5OK⟩

private def q11Shape20T1 : Tree 11 := .split 0 q11Shape20T2 q11Shape20T3
private theorem q11Shape20T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 1075937280 q11Shape20T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 (1075937280 ||| 2^0) q11Shape20T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (0 ||| 2^0) 1075937280 q11Shape20T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T2OK,q11Shape20T3OK⟩

private def q11Shape20T16 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741824 2195473 q11Shape20T16=true := by decide

private def q11Shape20T18 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741840 2195489 q11Shape20T18=true := by decide

private def q11Shape20T19 : Tree 11 := (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,4,9,10})))) (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10}))))))
private theorem q11Shape20T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741872 2195457 q11Shape20T19=true := by decide

private def q11Shape20T17 : Tree 11 := .split 5 q11Shape20T18 q11Shape20T19
private theorem q11Shape20T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741840 2195457 q11Shape20T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741840 (2195457 ||| 2^5) q11Shape20T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741840 ||| 2^5) 2195457 q11Shape20T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T18OK,q11Shape20T19OK⟩

private def q11Shape20T15 : Tree 11 := .split 4 q11Shape20T16 q11Shape20T17
private theorem q11Shape20T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741824 2195457 q11Shape20T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741824 (2195457 ||| 2^4) q11Shape20T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741824 ||| 2^4) 2195457 q11Shape20T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T16OK,q11Shape20T17OK⟩

private def q11Shape20T22 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741825 2195504 q11Shape20T22=true := by decide

private def q11Shape20T24 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741857 2197520 q11Shape20T24=true := by decide

private def q11Shape20T26 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743905 2199568 q11Shape20T26=true := by decide

private def q11Shape20T28 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10}))))) (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10})))) (.tip (.cover {0,2,4,7,9,10}))))
private theorem q11Shape20T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748001 2195474 q11Shape20T28=true := by decide

private def q11Shape20T29 : Tree 11 := (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {0,2,5,7,9,10}))) (.tip (.cover {0,2,6,7,9,10})))
private theorem q11Shape20T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748003 2195472 q11Shape20T29=true := by decide

private def q11Shape20T27 : Tree 11 := .split 1 q11Shape20T28 q11Shape20T29
private theorem q11Shape20T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748001 2195472 q11Shape20T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748001 (2195472 ||| 2^1) q11Shape20T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073748001 ||| 2^1) 2195472 q11Shape20T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T28OK,q11Shape20T29OK⟩

private def q11Shape20T25 : Tree 11 := .split 12 q11Shape20T26 q11Shape20T27
private theorem q11Shape20T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743905 2195472 q11Shape20T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743905 (2195472 ||| 2^12) q11Shape20T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073743905 ||| 2^12) 2195472 q11Shape20T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T26OK,q11Shape20T27OK⟩

private def q11Shape20T23 : Tree 11 := .split 11 q11Shape20T24 q11Shape20T25
private theorem q11Shape20T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741857 2195472 q11Shape20T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741857 (2195472 ||| 2^11) q11Shape20T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741857 ||| 2^11) 2195472 q11Shape20T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T24OK,q11Shape20T25OK⟩

private def q11Shape20T21 : Tree 11 := .split 5 q11Shape20T22 q11Shape20T23
private theorem q11Shape20T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741825 2195472 q11Shape20T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741825 (2195472 ||| 2^5) q11Shape20T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741825 ||| 2^5) 2195472 q11Shape20T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T22OK,q11Shape20T23OK⟩

private def q11Shape20T32 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741841 2197536 q11Shape20T32=true := by decide

private def q11Shape20T34 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743889 2199584 q11Shape20T34=true := by decide

private def q11Shape20T36 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10}))))) (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,1,3,6,9,10})))) (.tip (.cover {0,2,4,8,9,10}))))
private theorem q11Shape20T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073747985 2195490 q11Shape20T36=true := by decide

private def q11Shape20T37 : Tree 11 := (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {0,2,5,8,9,10}))) (.tip (.cover {0,2,6,8,9,10})))
private theorem q11Shape20T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073747987 2195488 q11Shape20T37=true := by decide

private def q11Shape20T35 : Tree 11 := .split 1 q11Shape20T36 q11Shape20T37
private theorem q11Shape20T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073747985 2195488 q11Shape20T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073747985 (2195488 ||| 2^1) q11Shape20T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073747985 ||| 2^1) 2195488 q11Shape20T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T36OK,q11Shape20T37OK⟩

private def q11Shape20T33 : Tree 11 := .split 12 q11Shape20T34 q11Shape20T35
private theorem q11Shape20T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743889 2195488 q11Shape20T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743889 (2195488 ||| 2^12) q11Shape20T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073743889 ||| 2^12) 2195488 q11Shape20T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T34OK,q11Shape20T35OK⟩

private def q11Shape20T31 : Tree 11 := .split 11 q11Shape20T32 q11Shape20T33
private theorem q11Shape20T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741841 2195488 q11Shape20T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741841 (2195488 ||| 2^11) q11Shape20T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741841 ||| 2^11) 2195488 q11Shape20T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T32OK,q11Shape20T33OK⟩

private def q11Shape20T40 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741873 2201600 q11Shape20T40=true := by decide

private def q11Shape20T42 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,2,3,7,9,10}))))) (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,6,7,9,10})))) (.tip (.cover {0,1,2,4,9,10}))))
private theorem q11Shape20T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073745969 2197506 q11Shape20T42=true := by decide

private def q11Shape20T43 : Tree 11 := (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape20T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073745971 2197504 q11Shape20T43=true := by decide

private def q11Shape20T41 : Tree 11 := .split 1 q11Shape20T42 q11Shape20T43
private theorem q11Shape20T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073745969 2197504 q11Shape20T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073745969 (2197504 ||| 2^1) q11Shape20T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073745969 ||| 2^1) 2197504 q11Shape20T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T42OK,q11Shape20T43OK⟩

private def q11Shape20T39 : Tree 11 := .split 12 q11Shape20T40 q11Shape20T41
private theorem q11Shape20T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741873 2197504 q11Shape20T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741873 (2197504 ||| 2^12) q11Shape20T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741873 ||| 2^12) 2197504 q11Shape20T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T40OK,q11Shape20T41OK⟩

private def q11Shape20T46 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,2,3,7,9,10}))))) (.split 3 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover {0,3,6,8,9,10})))) (.tip (.cover {0,1,2,4,9,10}))))
private theorem q11Shape20T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743921 2199554 q11Shape20T46=true := by decide

private def q11Shape20T47 : Tree 11 := (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape20T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743923 2199552 q11Shape20T47=true := by decide

private def q11Shape20T45 : Tree 11 := .split 1 q11Shape20T46 q11Shape20T47
private theorem q11Shape20T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743921 2199552 q11Shape20T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743921 (2199552 ||| 2^1) q11Shape20T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073743921 ||| 2^1) 2199552 q11Shape20T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T46OK,q11Shape20T47OK⟩

private def q11Shape20T49 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,2,3,5,9,10})))) (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,2,3,6,9,10}))) (.tip (.cover {0,1,2,4,9,10}))))
private theorem q11Shape20T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748017 2195458 q11Shape20T49=true := by decide

private def q11Shape20T50 : Tree 11 := (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape20T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748019 2195456 q11Shape20T50=true := by decide

private def q11Shape20T48 : Tree 11 := .split 1 q11Shape20T49 q11Shape20T50
private theorem q11Shape20T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748017 2195456 q11Shape20T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073748017 (2195456 ||| 2^1) q11Shape20T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073748017 ||| 2^1) 2195456 q11Shape20T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T49OK,q11Shape20T50OK⟩

private def q11Shape20T44 : Tree 11 := .split 12 q11Shape20T45 q11Shape20T48
private theorem q11Shape20T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743921 2195456 q11Shape20T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073743921 (2195456 ||| 2^12) q11Shape20T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073743921 ||| 2^12) 2195456 q11Shape20T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T45OK,q11Shape20T48OK⟩

private def q11Shape20T38 : Tree 11 := .split 11 q11Shape20T39 q11Shape20T44
private theorem q11Shape20T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741873 2195456 q11Shape20T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741873 (2195456 ||| 2^11) q11Shape20T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741873 ||| 2^11) 2195456 q11Shape20T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T39OK,q11Shape20T44OK⟩

private def q11Shape20T30 : Tree 11 := .split 5 q11Shape20T31 q11Shape20T38
private theorem q11Shape20T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741841 2195456 q11Shape20T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741841 (2195456 ||| 2^5) q11Shape20T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741841 ||| 2^5) 2195456 q11Shape20T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T31OK,q11Shape20T38OK⟩

private def q11Shape20T20 : Tree 11 := .split 4 q11Shape20T21 q11Shape20T30
private theorem q11Shape20T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741825 2195456 q11Shape20T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741825 (2195456 ||| 2^4) q11Shape20T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741825 ||| 2^4) 2195456 q11Shape20T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T21OK,q11Shape20T30OK⟩

private def q11Shape20T14 : Tree 11 := .split 0 q11Shape20T15 q11Shape20T20
private theorem q11Shape20T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741824 2195456 q11Shape20T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073741824 (2195456 ||| 2^0) q11Shape20T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073741824 ||| 2^0) 2195456 q11Shape20T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T15OK,q11Shape20T20OK⟩

private def q11Shape20T0 : Tree 11 := .split 30 q11Shape20T1 q11Shape20T14
private theorem q11Shape20T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 2195456 q11Shape20T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 (2195456 ||| 2^30) q11Shape20T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (0 ||| 2^30) 2195456 q11Shape20T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T1OK,q11Shape20T14OK⟩

def q11Shape20P0 : Tree 11 := q11Shape20T0
theorem q11Shape20P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 0 2195456 q11Shape20P0=true := q11Shape20T0OK

end Graffiti384b.EffectiveSearch.Q11
