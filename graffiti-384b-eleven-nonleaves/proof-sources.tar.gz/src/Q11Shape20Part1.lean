import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape20T53 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097152 1073840129 q11Shape20T53=true := by decide

private def q11Shape20T55 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097153 1073840144 q11Shape20T55=true := by decide

private def q11Shape20T56 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,2,5,9,10}))))))
private theorem q11Shape20T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097169 1073840128 q11Shape20T56=true := by decide

private def q11Shape20T54 : Tree 11 := .split 4 q11Shape20T55 q11Shape20T56
private theorem q11Shape20T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097153 1073840128 q11Shape20T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097153 (1073840128 ||| 2^4) q11Shape20T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (2097153 ||| 2^4) 1073840128 q11Shape20T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T55OK,q11Shape20T56OK⟩

private def q11Shape20T52 : Tree 11 := .split 0 q11Shape20T53 q11Shape20T54
private theorem q11Shape20T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097152 1073840128 q11Shape20T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097152 (1073840128 ||| 2^0) q11Shape20T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (2097152 ||| 2^0) 1073840128 q11Shape20T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T53OK,q11Shape20T54OK⟩

private def q11Shape20T58 : Tree 11 := (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,2,5,9,10})))))))
private theorem q11Shape20T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838976 98305 q11Shape20T58=true := by decide

private def q11Shape20T60 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,4,5,7,9,10}))) (.tip (.cover {2,4,6,7,9,10}))) (.tip (.cover {0,2,5,7,9,10}))))))
private theorem q11Shape20T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838977 98320 q11Shape20T60=true := by decide

private def q11Shape20T62 : Tree 11 := (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,2,5,8,9,10})))))
private theorem q11Shape20T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838993 98336 q11Shape20T62=true := by decide

private def q11Shape20T64 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,5,7,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,1,2,5,9,10}))))
private theorem q11Shape20T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075839025 100352 q11Shape20T64=true := by decide

private def q11Shape20T66 : Tree 11 := (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {2,4,5,7,9,10}))) (.tip (.cover {2,4,6,7,9,10}))) (.tip (.cover {0,1,2,5,9,10})))
private theorem q11Shape20T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075841073 102400 q11Shape20T66=true := by decide

private def q11Shape20T67 : Tree 11 := (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,2,5,9,10})))
private theorem q11Shape20T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075845169 98304 q11Shape20T67=true := by decide

private def q11Shape20T65 : Tree 11 := .split 12 q11Shape20T66 q11Shape20T67
private theorem q11Shape20T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075841073 98304 q11Shape20T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075841073 (98304 ||| 2^12) q11Shape20T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1075841073 ||| 2^12) 98304 q11Shape20T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T66OK,q11Shape20T67OK⟩

private def q11Shape20T63 : Tree 11 := .split 11 q11Shape20T64 q11Shape20T65
private theorem q11Shape20T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075839025 98304 q11Shape20T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075839025 (98304 ||| 2^11) q11Shape20T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1075839025 ||| 2^11) 98304 q11Shape20T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T64OK,q11Shape20T65OK⟩

private def q11Shape20T61 : Tree 11 := .split 5 q11Shape20T62 q11Shape20T63
private theorem q11Shape20T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838993 98304 q11Shape20T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838993 (98304 ||| 2^5) q11Shape20T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1075838993 ||| 2^5) 98304 q11Shape20T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T62OK,q11Shape20T63OK⟩

private def q11Shape20T59 : Tree 11 := .split 4 q11Shape20T60 q11Shape20T61
private theorem q11Shape20T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838977 98304 q11Shape20T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838977 (98304 ||| 2^4) q11Shape20T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1075838977 ||| 2^4) 98304 q11Shape20T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T60OK,q11Shape20T61OK⟩

private def q11Shape20T57 : Tree 11 := .split 0 q11Shape20T58 q11Shape20T59
private theorem q11Shape20T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838976 98304 q11Shape20T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1075838976 (98304 ||| 2^0) q11Shape20T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1075838976 ||| 2^0) 98304 q11Shape20T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T58OK,q11Shape20T59OK⟩

private def q11Shape20T51 : Tree 11 := .split 30 q11Shape20T52 q11Shape20T57
private theorem q11Shape20T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097152 98304 q11Shape20T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097152 (98304 ||| 2^30) q11Shape20T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (2097152 ||| 2^30) 98304 q11Shape20T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T52OK,q11Shape20T57OK⟩

def q11Shape20P1 : Tree 11 := q11Shape20T51
theorem q11Shape20P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2097152 98304 q11Shape20P1=true := q11Shape20T51OK

end Graffiti384b.EffectiveSearch.Q11
