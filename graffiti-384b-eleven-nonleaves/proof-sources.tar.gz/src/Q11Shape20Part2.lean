import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape20T72 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 1075871745 q11Shape20T72=true := by decide

private def q11Shape20T74 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65537 1075871760 q11Shape20T74=true := by decide

private def q11Shape20T75 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,3,5,6,9,10}))))))
private theorem q11Shape20T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65553 1075871744 q11Shape20T75=true := by decide

private def q11Shape20T73 : Tree 11 := .split 4 q11Shape20T74 q11Shape20T75
private theorem q11Shape20T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65537 1075871744 q11Shape20T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65537 (1075871744 ||| 2^4) q11Shape20T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (65537 ||| 2^4) 1075871744 q11Shape20T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T74OK,q11Shape20T75OK⟩

private def q11Shape20T71 : Tree 11 := .split 0 q11Shape20T72 q11Shape20T73
private theorem q11Shape20T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 1075871744 q11Shape20T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 (1075871744 ||| 2^0) q11Shape20T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (65536 ||| 2^0) 1075871744 q11Shape20T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T72OK,q11Shape20T73OK⟩

private def q11Shape20T77 : Tree 11 := (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,3,5,6,9,10})))))))
private theorem q11Shape20T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807360 2129921 q11Shape20T77=true := by decide

private def q11Shape20T79 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,8,9,10}))) (.tip (.cover {2,4,5,7,9,10}))) (.tip (.cover {0,2,4,7,9,10}))) (.tip (.cover {2,5,6,7,9,10}))))))
private theorem q11Shape20T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807361 2129936 q11Shape20T79=true := by decide

private def q11Shape20T81 : Tree 11 := (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,5,6,8,9,10})))))
private theorem q11Shape20T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807377 2129952 q11Shape20T81=true := by decide

private def q11Shape20T83 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,5,6,8,9,10}))))
private theorem q11Shape20T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807409 2131968 q11Shape20T83=true := by decide

private def q11Shape20T85 : Tree 11 := (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,8,9,10}))) (.tip (.cover {2,4,5,7,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,5,6,7,9,10})))
private theorem q11Shape20T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073809457 2134016 q11Shape20T85=true := by decide

private def q11Shape20T86 : Tree 11 := (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,3,5,6,9,10})))
private theorem q11Shape20T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073813553 2129920 q11Shape20T86=true := by decide

private def q11Shape20T84 : Tree 11 := .split 12 q11Shape20T85 q11Shape20T86
private theorem q11Shape20T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073809457 2129920 q11Shape20T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073809457 (2129920 ||| 2^12) q11Shape20T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073809457 ||| 2^12) 2129920 q11Shape20T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T85OK,q11Shape20T86OK⟩

private def q11Shape20T82 : Tree 11 := .split 11 q11Shape20T83 q11Shape20T84
private theorem q11Shape20T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807409 2129920 q11Shape20T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807409 (2129920 ||| 2^11) q11Shape20T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073807409 ||| 2^11) 2129920 q11Shape20T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T83OK,q11Shape20T84OK⟩

private def q11Shape20T80 : Tree 11 := .split 5 q11Shape20T81 q11Shape20T82
private theorem q11Shape20T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807377 2129920 q11Shape20T80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807377 (2129920 ||| 2^5) q11Shape20T81 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073807377 ||| 2^5) 2129920 q11Shape20T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T81OK,q11Shape20T82OK⟩

private def q11Shape20T78 : Tree 11 := .split 4 q11Shape20T79 q11Shape20T80
private theorem q11Shape20T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807361 2129920 q11Shape20T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807361 (2129920 ||| 2^4) q11Shape20T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073807361 ||| 2^4) 2129920 q11Shape20T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T79OK,q11Shape20T80OK⟩

private def q11Shape20T76 : Tree 11 := .split 0 q11Shape20T77 q11Shape20T78
private theorem q11Shape20T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807360 2129920 q11Shape20T76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073807360 (2129920 ||| 2^0) q11Shape20T77 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073807360 ||| 2^0) 2129920 q11Shape20T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T77OK,q11Shape20T78OK⟩

private def q11Shape20T70 : Tree 11 := .split 30 q11Shape20T71 q11Shape20T76
private theorem q11Shape20T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 2129920 q11Shape20T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 (2129920 ||| 2^30) q11Shape20T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (65536 ||| 2^30) 2129920 q11Shape20T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T71OK,q11Shape20T76OK⟩

private def q11Shape20T87 : Tree 11 := (.split 30 (.split 0 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,6,9,10}))))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape20T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2162688 32768 q11Shape20T87=true := by decide

private def q11Shape20T69 : Tree 11 := .split 21 q11Shape20T70 q11Shape20T87
private theorem q11Shape20T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 32768 q11Shape20T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 (32768 ||| 2^21) q11Shape20T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (65536 ||| 2^21) 32768 q11Shape20T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T70OK,q11Shape20T87OK⟩

def q11Shape20P2 : Tree 11 := q11Shape20T69
theorem q11Shape20P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 65536 32768 q11Shape20P2=true := q11Shape20T69OK

end Graffiti384b.EffectiveSearch.Q11
