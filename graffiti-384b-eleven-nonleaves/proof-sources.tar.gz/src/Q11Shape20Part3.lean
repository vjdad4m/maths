import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape20T93 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 1075904513 q11Shape20T93=true := by decide

private def q11Shape20T95 : Tree 11 := (.tip (.small 1))
private theorem q11Shape20T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32769 1075904528 q11Shape20T95=true := by decide

private def q11Shape20T96 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,5,6,9,10}))))))
private theorem q11Shape20T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32785 1075904512 q11Shape20T96=true := by decide

private def q11Shape20T94 : Tree 11 := .split 4 q11Shape20T95 q11Shape20T96
private theorem q11Shape20T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32769 1075904512 q11Shape20T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32769 (1075904512 ||| 2^4) q11Shape20T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (32769 ||| 2^4) 1075904512 q11Shape20T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T95OK,q11Shape20T96OK⟩

private def q11Shape20T92 : Tree 11 := .split 0 q11Shape20T93 q11Shape20T94
private theorem q11Shape20T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 1075904512 q11Shape20T92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 (1075904512 ||| 2^0) q11Shape20T93 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (32768 ||| 2^0) 1075904512 q11Shape20T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T93OK,q11Shape20T94OK⟩

private def q11Shape20T98 : Tree 11 := (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,5,6,9,10})))))))
private theorem q11Shape20T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774592 2162689 q11Shape20T98=true := by decide

private def q11Shape20T100 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,8,9,10}))) (.tip (.cover {0,2,4,7,9,10}))) (.tip (.cover {2,4,6,7,9,10}))) (.tip (.cover {2,5,6,7,9,10}))))))
private theorem q11Shape20T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774593 2162704 q11Shape20T100=true := by decide

private def q11Shape20T102 : Tree 11 := (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,5,6,8,9,10})))))
private theorem q11Shape20T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774609 2162720 q11Shape20T102=true := by decide

private def q11Shape20T104 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,5,6,8,9,10}))))
private theorem q11Shape20T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774641 2164736 q11Shape20T104=true := by decide

private def q11Shape20T106 : Tree 11 := (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {3,5,6,8,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,4,6,7,9,10}))) (.tip (.cover {2,5,6,7,9,10})))
private theorem q11Shape20T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073776689 2166784 q11Shape20T106=true := by decide

private def q11Shape20T107 : Tree 11 := (.split 1 (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover {2,3,5,6,9,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,5,6,9,10})))
private theorem q11Shape20T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073780785 2162688 q11Shape20T107=true := by decide

private def q11Shape20T105 : Tree 11 := .split 12 q11Shape20T106 q11Shape20T107
private theorem q11Shape20T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073776689 2162688 q11Shape20T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073776689 (2162688 ||| 2^12) q11Shape20T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073776689 ||| 2^12) 2162688 q11Shape20T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T106OK,q11Shape20T107OK⟩

private def q11Shape20T103 : Tree 11 := .split 11 q11Shape20T104 q11Shape20T105
private theorem q11Shape20T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774641 2162688 q11Shape20T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774641 (2162688 ||| 2^11) q11Shape20T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073774641 ||| 2^11) 2162688 q11Shape20T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T104OK,q11Shape20T105OK⟩

private def q11Shape20T101 : Tree 11 := .split 5 q11Shape20T102 q11Shape20T103
private theorem q11Shape20T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774609 2162688 q11Shape20T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774609 (2162688 ||| 2^5) q11Shape20T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073774609 ||| 2^5) 2162688 q11Shape20T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T102OK,q11Shape20T103OK⟩

private def q11Shape20T99 : Tree 11 := .split 4 q11Shape20T100 q11Shape20T101
private theorem q11Shape20T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774593 2162688 q11Shape20T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774593 (2162688 ||| 2^4) q11Shape20T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073774593 ||| 2^4) 2162688 q11Shape20T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T100OK,q11Shape20T101OK⟩

private def q11Shape20T97 : Tree 11 := .split 0 q11Shape20T98 q11Shape20T99
private theorem q11Shape20T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774592 2162688 q11Shape20T97=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 1073774592 (2162688 ||| 2^0) q11Shape20T98 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (1073774592 ||| 2^0) 2162688 q11Shape20T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T98OK,q11Shape20T99OK⟩

private def q11Shape20T91 : Tree 11 := .split 30 q11Shape20T92 q11Shape20T97
private theorem q11Shape20T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 2162688 q11Shape20T91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 (2162688 ||| 2^30) q11Shape20T92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (32768 ||| 2^30) 2162688 q11Shape20T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T92OK,q11Shape20T97OK⟩

private def q11Shape20T108 : Tree 11 := (.split 30 (.split 0 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,5,9,10}))))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape20T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2129920 65536 q11Shape20T108=true := by decide

private def q11Shape20T90 : Tree 11 := .split 21 q11Shape20T91 q11Shape20T108
private theorem q11Shape20T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 65536 q11Shape20T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 (65536 ||| 2^21) q11Shape20T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (32768 ||| 2^21) 65536 q11Shape20T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T91OK,q11Shape20T108OK⟩

private def q11Shape20T110 : Tree 11 := (.split 30 (.split 0 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10}))))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape20T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 98304 2097152 q11Shape20T110=true := by decide

private def q11Shape20T111 : Tree 11 := (.split 30 (.split 0 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,1,2,4,9,10}))))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape20T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 2195456 0 q11Shape20T111=true := by decide

private def q11Shape20T109 : Tree 11 := .split 21 q11Shape20T110 q11Shape20T111
private theorem q11Shape20T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 98304 0 q11Shape20T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 98304 (0 ||| 2^21) q11Shape20T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (98304 ||| 2^21) 0 q11Shape20T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T110OK,q11Shape20T111OK⟩

private def q11Shape20T89 : Tree 11 := .split 16 q11Shape20T90 q11Shape20T109
private theorem q11Shape20T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 0 q11Shape20T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 (0 ||| 2^16) q11Shape20T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) (32768 ||| 2^16) 0 q11Shape20T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape20T90OK,q11Shape20T109OK⟩

def q11Shape20P3 : Tree 11 := q11Shape20T89
theorem q11Shape20P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,2⟩) 32768 0 q11Shape20P3=true := q11Shape20T89OK

end Graffiti384b.EffectiveSearch.Q11
