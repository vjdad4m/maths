import Q11Shape21Part0
import Q11Shape21Part1
import Q11Shape21Part2
import Q11Shape21Part3
import Q11Shape21Part4
import Q11Shape21Part5
import Q11Shape21Part6
import Q11Shape21Part7
import Q11Shape21Part8

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21M559 : Tree 11 := .split 17 q11Shape21P3 q11Shape21P4
private theorem q11Shape21M559OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 2099200 q11Shape21M559=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 (2099200 ||| 2^17) q11Shape21P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (259 ||| 2^17) 2099200 q11Shape21P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21P3OK,q11Shape21P4OK⟩
private def q11Shape21M777 : Tree 11 := .split 11 q11Shape21M559 q11Shape21P5
private theorem q11Shape21M777OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 2097152 q11Shape21M777=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 (2097152 ||| 2^11) q11Shape21M559 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (259 ||| 2^11) 2097152 q11Shape21P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21M559OK,q11Shape21P5OK⟩
private def q11Shape21M778 : Tree 11 := .split 8 q11Shape21P2 q11Shape21M777
private theorem q11Shape21M778OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 2097152 q11Shape21M778=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 (2097152 ||| 2^8) q11Shape21P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3 ||| 2^8) 2097152 q11Shape21M777)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21P2OK,q11Shape21M777OK⟩
private def q11Shape21M779 : Tree 11 := .split 1 q11Shape21P1 q11Shape21M778
private theorem q11Shape21M779OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 2097152 q11Shape21M779=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 (2097152 ||| 2^1) q11Shape21P1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1 ||| 2^1) 2097152 q11Shape21M778)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21P1OK,q11Shape21M778OK⟩
private def q11Shape21M780 : Tree 11 := .split 0 q11Shape21P0 q11Shape21M779
private theorem q11Shape21M780OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 2097152 q11Shape21M780=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 (2097152 ||| 2^0) q11Shape21P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (0 ||| 2^0) 2097152 q11Shape21M779)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21P0OK,q11Shape21M779OK⟩
private def q11Shape21M1188 : Tree 11 := .split 1 q11Shape21P7 q11Shape21P8
private theorem q11Shape21M1188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097153 0 q11Shape21M1188=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097153 (0 ||| 2^1) q11Shape21P7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097153 ||| 2^1) 0 q11Shape21P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21P7OK,q11Shape21P8OK⟩
private def q11Shape21M1189 : Tree 11 := .split 0 q11Shape21P6 q11Shape21M1188
private theorem q11Shape21M1189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097152 0 q11Shape21M1189=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097152 (0 ||| 2^0) q11Shape21P6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097152 ||| 2^0) 0 q11Shape21M1188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21P6OK,q11Shape21M1188OK⟩
private def q11Shape21M1190 : Tree 11 := .split 21 q11Shape21M780 q11Shape21M1189
private theorem q11Shape21M1190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 0 q11Shape21M1190=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 (0 ||| 2^21) q11Shape21M780 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (0 ||| 2^21) 0 q11Shape21M1189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21M780OK,q11Shape21M1189OK⟩

theorem q11Shape21_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 21) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 21) b) (adj 11 (forms 21) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 21)) adj_mono b H q11Shape21M1190 q11Shape21M1190OK

#print axioms q11Shape21_cover

end Graffiti384b.EffectiveSearch.Q11
