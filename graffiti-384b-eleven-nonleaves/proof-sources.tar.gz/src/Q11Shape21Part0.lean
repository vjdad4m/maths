import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T2 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 2097411 q11Shape21T2=true := by decide

private def q11Shape21T4 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 256 2099203 q11Shape21T4=true := by decide

private def q11Shape21T6 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2304 2228227 q11Shape21T6=true := by decide

private def q11Shape21T8 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133376 2097171 q11Shape21T8=true := by decide

private def q11Shape21T10 : Tree 11 := (.split 3 (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,1,4,8,9,10}))))) (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.split 9 (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,5,8,9,10})))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape21T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133392 2097159 q11Shape21T10=true := by decide

private def q11Shape21T11 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133396 2097155 q11Shape21T11=true := by decide

private def q11Shape21T9 : Tree 11 := .split 2 q11Shape21T10 q11Shape21T11
private theorem q11Shape21T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133392 2097155 q11Shape21T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133392 (2097155 ||| 2^2) q11Shape21T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133392 ||| 2^2) 2097155 q11Shape21T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T10OK,q11Shape21T11OK⟩

private def q11Shape21T7 : Tree 11 := .split 4 q11Shape21T8 q11Shape21T9
private theorem q11Shape21T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133376 2097155 q11Shape21T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133376 (2097155 ||| 2^4) q11Shape21T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133376 ||| 2^4) 2097155 q11Shape21T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T8OK,q11Shape21T9OK⟩

private def q11Shape21T5 : Tree 11 := .split 17 q11Shape21T6 q11Shape21T7
private theorem q11Shape21T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2304 2097155 q11Shape21T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2304 (2097155 ||| 2^17) q11Shape21T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2304 ||| 2^17) 2097155 q11Shape21T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T6OK,q11Shape21T7OK⟩

private def q11Shape21T3 : Tree 11 := .split 11 q11Shape21T4 q11Shape21T5
private theorem q11Shape21T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 256 2097155 q11Shape21T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 256 (2097155 ||| 2^11) q11Shape21T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (256 ||| 2^11) 2097155 q11Shape21T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T4OK,q11Shape21T5OK⟩

private def q11Shape21T1 : Tree 11 := .split 8 q11Shape21T2 q11Shape21T3
private theorem q11Shape21T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 2097155 q11Shape21T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 (2097155 ||| 2^8) q11Shape21T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (0 ||| 2^8) 2097155 q11Shape21T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T2OK,q11Shape21T3OK⟩

private def q11Shape21T14 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2 2099457 q11Shape21T14=true := by decide

private def q11Shape21T16 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2050 2228481 q11Shape21T16=true := by decide

private def q11Shape21T18 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133122 2097425 q11Shape21T18=true := by decide

private def q11Shape21T20 : Tree 11 := (.split 3 (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.split 9 (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,5,8,9,10})))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape21T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133138 2097413 q11Shape21T20=true := by decide

private def q11Shape21T21 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133142 2097409 q11Shape21T21=true := by decide

private def q11Shape21T19 : Tree 11 := .split 2 q11Shape21T20 q11Shape21T21
private theorem q11Shape21T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133138 2097409 q11Shape21T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133138 (2097409 ||| 2^2) q11Shape21T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133138 ||| 2^2) 2097409 q11Shape21T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T20OK,q11Shape21T21OK⟩

private def q11Shape21T17 : Tree 11 := .split 4 q11Shape21T18 q11Shape21T19
private theorem q11Shape21T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133122 2097409 q11Shape21T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133122 (2097409 ||| 2^4) q11Shape21T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133122 ||| 2^4) 2097409 q11Shape21T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T18OK,q11Shape21T19OK⟩

private def q11Shape21T15 : Tree 11 := .split 17 q11Shape21T16 q11Shape21T17
private theorem q11Shape21T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2050 2097409 q11Shape21T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2050 (2097409 ||| 2^17) q11Shape21T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2050 ||| 2^17) 2097409 q11Shape21T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T16OK,q11Shape21T17OK⟩

private def q11Shape21T13 : Tree 11 := .split 11 q11Shape21T14 q11Shape21T15
private theorem q11Shape21T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2 2097409 q11Shape21T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2 (2097409 ||| 2^11) q11Shape21T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2 ||| 2^11) 2097409 q11Shape21T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T14OK,q11Shape21T15OK⟩

private def q11Shape21T24 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 258 2230273 q11Shape21T24=true := by decide

private def q11Shape21T26 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131330 2099217 q11Shape21T26=true := by decide

private def q11Shape21T30 : Tree 11 := (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))))
private theorem q11Shape21T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131346 2099725 q11Shape21T30=true := by decide

private def q11Shape21T31 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,4,5,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131858 2099213 q11Shape21T31=true := by decide

private def q11Shape21T29 : Tree 11 := .split 9 q11Shape21T30 q11Shape21T31
private theorem q11Shape21T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131346 2099213 q11Shape21T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131346 (2099213 ||| 2^9) q11Shape21T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131346 ||| 2^9) 2099213 q11Shape21T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T30OK,q11Shape21T31OK⟩

private def q11Shape21T32 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape21T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131354 2099205 q11Shape21T32=true := by decide

private def q11Shape21T28 : Tree 11 := .split 3 q11Shape21T29 q11Shape21T32
private theorem q11Shape21T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131346 2099205 q11Shape21T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131346 (2099205 ||| 2^3) q11Shape21T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131346 ||| 2^3) 2099205 q11Shape21T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T29OK,q11Shape21T32OK⟩

private def q11Shape21T35 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))))
private theorem q11Shape21T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131350 2099721 q11Shape21T35=true := by decide

private def q11Shape21T36 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131862 2099209 q11Shape21T36=true := by decide

private def q11Shape21T34 : Tree 11 := .split 9 q11Shape21T35 q11Shape21T36
private theorem q11Shape21T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131350 2099209 q11Shape21T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131350 (2099209 ||| 2^9) q11Shape21T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131350 ||| 2^9) 2099209 q11Shape21T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T35OK,q11Shape21T36OK⟩

private def q11Shape21T37 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131358 2099201 q11Shape21T37=true := by decide

private def q11Shape21T33 : Tree 11 := .split 3 q11Shape21T34 q11Shape21T37
private theorem q11Shape21T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131350 2099201 q11Shape21T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131350 (2099201 ||| 2^3) q11Shape21T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131350 ||| 2^3) 2099201 q11Shape21T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T34OK,q11Shape21T37OK⟩

private def q11Shape21T27 : Tree 11 := .split 2 q11Shape21T28 q11Shape21T33
private theorem q11Shape21T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131346 2099201 q11Shape21T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131346 (2099201 ||| 2^2) q11Shape21T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131346 ||| 2^2) 2099201 q11Shape21T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T28OK,q11Shape21T33OK⟩

private def q11Shape21T25 : Tree 11 := .split 4 q11Shape21T26 q11Shape21T27
private theorem q11Shape21T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131330 2099201 q11Shape21T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131330 (2099201 ||| 2^4) q11Shape21T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131330 ||| 2^4) 2099201 q11Shape21T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T26OK,q11Shape21T27OK⟩

private def q11Shape21T23 : Tree 11 := .split 17 q11Shape21T24 q11Shape21T25
private theorem q11Shape21T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 258 2099201 q11Shape21T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 258 (2099201 ||| 2^17) q11Shape21T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (258 ||| 2^17) 2099201 q11Shape21T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T24OK,q11Shape21T25OK⟩

private def q11Shape21T40 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2306 2228241 q11Shape21T40=true := by decide

private def q11Shape21T44 : Tree 11 := (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape21T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2322 2228749 q11Shape21T44=true := by decide

private def q11Shape21T45 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2834 2228237 q11Shape21T45=true := by decide

private def q11Shape21T43 : Tree 11 := .split 9 q11Shape21T44 q11Shape21T45
private theorem q11Shape21T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2322 2228237 q11Shape21T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2322 (2228237 ||| 2^9) q11Shape21T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2322 ||| 2^9) 2228237 q11Shape21T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T44OK,q11Shape21T45OK⟩

private def q11Shape21T46 : Tree 11 := (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape21T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2330 2228229 q11Shape21T46=true := by decide

private def q11Shape21T42 : Tree 11 := .split 3 q11Shape21T43 q11Shape21T46
private theorem q11Shape21T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2322 2228229 q11Shape21T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2322 (2228229 ||| 2^3) q11Shape21T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2322 ||| 2^3) 2228229 q11Shape21T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T43OK,q11Shape21T46OK⟩

private def q11Shape21T47 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2326 2228225 q11Shape21T47=true := by decide

private def q11Shape21T41 : Tree 11 := .split 2 q11Shape21T42 q11Shape21T47
private theorem q11Shape21T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2322 2228225 q11Shape21T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2322 (2228225 ||| 2^2) q11Shape21T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2322 ||| 2^2) 2228225 q11Shape21T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T42OK,q11Shape21T47OK⟩

private def q11Shape21T39 : Tree 11 := .split 4 q11Shape21T40 q11Shape21T41
private theorem q11Shape21T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2306 2228225 q11Shape21T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2306 (2228225 ||| 2^4) q11Shape21T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2306 ||| 2^4) 2228225 q11Shape21T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T40OK,q11Shape21T41OK⟩

private def q11Shape21T51 : Tree 11 := (.split 9 (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))))
private theorem q11Shape21T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133378 2097181 q11Shape21T51=true := by decide

private def q11Shape21T53 : Tree 11 := (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape21T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133386 2097685 q11Shape21T53=true := by decide

private def q11Shape21T54 : Tree 11 := (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133898 2097173 q11Shape21T54=true := by decide

private def q11Shape21T52 : Tree 11 := .split 9 q11Shape21T53 q11Shape21T54
private theorem q11Shape21T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133386 2097173 q11Shape21T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133386 (2097173 ||| 2^9) q11Shape21T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133386 ||| 2^9) 2097173 q11Shape21T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T53OK,q11Shape21T54OK⟩

private def q11Shape21T50 : Tree 11 := .split 3 q11Shape21T51 q11Shape21T52
private theorem q11Shape21T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133378 2097173 q11Shape21T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133378 (2097173 ||| 2^3) q11Shape21T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133378 ||| 2^3) 2097173 q11Shape21T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T51OK,q11Shape21T52OK⟩

private def q11Shape21T58 : Tree 11 := (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,4,5,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133382 2098713 q11Shape21T58=true := by decide

private def q11Shape21T59 : Tree 11 := (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,3,4,8,9,10})))
private theorem q11Shape21T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134406 2097689 q11Shape21T59=true := by decide

private def q11Shape21T57 : Tree 11 := .split 10 q11Shape21T58 q11Shape21T59
private theorem q11Shape21T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133382 2097689 q11Shape21T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133382 (2097689 ||| 2^10) q11Shape21T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133382 ||| 2^10) 2097689 q11Shape21T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T58OK,q11Shape21T59OK⟩

private def q11Shape21T60 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133894 2097177 q11Shape21T60=true := by decide

private def q11Shape21T56 : Tree 11 := .split 9 q11Shape21T57 q11Shape21T60
private theorem q11Shape21T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133382 2097177 q11Shape21T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133382 (2097177 ||| 2^9) q11Shape21T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133382 ||| 2^9) 2097177 q11Shape21T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T57OK,q11Shape21T60OK⟩

private def q11Shape21T61 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133390 2097169 q11Shape21T61=true := by decide

private def q11Shape21T55 : Tree 11 := .split 3 q11Shape21T56 q11Shape21T61
private theorem q11Shape21T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133382 2097169 q11Shape21T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133382 (2097169 ||| 2^3) q11Shape21T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133382 ||| 2^3) 2097169 q11Shape21T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T56OK,q11Shape21T61OK⟩

private def q11Shape21T49 : Tree 11 := .split 2 q11Shape21T50 q11Shape21T55
private theorem q11Shape21T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133378 2097169 q11Shape21T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133378 (2097169 ||| 2^2) q11Shape21T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133378 ||| 2^2) 2097169 q11Shape21T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T50OK,q11Shape21T55OK⟩

private def q11Shape21T62 : Tree 11 := (.split 2 (.split 3 (.split 9 (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))) (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))))
private theorem q11Shape21T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133394 2097153 q11Shape21T62=true := by decide

private def q11Shape21T48 : Tree 11 := .split 4 q11Shape21T49 q11Shape21T62
private theorem q11Shape21T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133378 2097153 q11Shape21T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133378 (2097153 ||| 2^4) q11Shape21T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133378 ||| 2^4) 2097153 q11Shape21T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T49OK,q11Shape21T62OK⟩

private def q11Shape21T38 : Tree 11 := .split 17 q11Shape21T39 q11Shape21T48
private theorem q11Shape21T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2306 2097153 q11Shape21T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2306 (2097153 ||| 2^17) q11Shape21T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2306 ||| 2^17) 2097153 q11Shape21T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T39OK,q11Shape21T48OK⟩

private def q11Shape21T22 : Tree 11 := .split 11 q11Shape21T23 q11Shape21T38
private theorem q11Shape21T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 258 2097153 q11Shape21T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 258 (2097153 ||| 2^11) q11Shape21T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (258 ||| 2^11) 2097153 q11Shape21T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T23OK,q11Shape21T38OK⟩

private def q11Shape21T12 : Tree 11 := .split 8 q11Shape21T13 q11Shape21T22
private theorem q11Shape21T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2 2097153 q11Shape21T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2 (2097153 ||| 2^8) q11Shape21T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2 ||| 2^8) 2097153 q11Shape21T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T13OK,q11Shape21T22OK⟩

private def q11Shape21T0 : Tree 11 := .split 1 q11Shape21T1 q11Shape21T12
private theorem q11Shape21T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 2097153 q11Shape21T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 (2097153 ||| 2^1) q11Shape21T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (0 ||| 2^1) 2097153 q11Shape21T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1OK,q11Shape21T12OK⟩

def q11Shape21P0 : Tree 11 := q11Shape21T0
theorem q11Shape21P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 0 2097153 q11Shape21P0=true := q11Shape21T0OK

end Graffiti384b.EffectiveSearch.Q11
