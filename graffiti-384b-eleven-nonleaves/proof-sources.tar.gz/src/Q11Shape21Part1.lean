import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T65 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 2099458 q11Shape21T65=true := by decide

private def q11Shape21T67 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2049 2228482 q11Shape21T67=true := by decide

private def q11Shape21T69 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133121 2097426 q11Shape21T69=true := by decide

private def q11Shape21T71 : Tree 11 := (.split 3 (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.split 9 (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))))
private theorem q11Shape21T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133137 2097414 q11Shape21T71=true := by decide

private def q11Shape21T72 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {2,4,6,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133141 2097410 q11Shape21T72=true := by decide

private def q11Shape21T70 : Tree 11 := .split 2 q11Shape21T71 q11Shape21T72
private theorem q11Shape21T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133137 2097410 q11Shape21T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133137 (2097410 ||| 2^2) q11Shape21T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133137 ||| 2^2) 2097410 q11Shape21T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T71OK,q11Shape21T72OK⟩

private def q11Shape21T68 : Tree 11 := .split 4 q11Shape21T69 q11Shape21T70
private theorem q11Shape21T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133121 2097410 q11Shape21T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133121 (2097410 ||| 2^4) q11Shape21T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133121 ||| 2^4) 2097410 q11Shape21T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T69OK,q11Shape21T70OK⟩

private def q11Shape21T66 : Tree 11 := .split 17 q11Shape21T67 q11Shape21T68
private theorem q11Shape21T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2049 2097410 q11Shape21T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2049 (2097410 ||| 2^17) q11Shape21T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2049 ||| 2^17) 2097410 q11Shape21T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T67OK,q11Shape21T68OK⟩

private def q11Shape21T64 : Tree 11 := .split 11 q11Shape21T65 q11Shape21T66
private theorem q11Shape21T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 2097410 q11Shape21T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 (2097410 ||| 2^11) q11Shape21T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1 ||| 2^11) 2097410 q11Shape21T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T65OK,q11Shape21T66OK⟩

private def q11Shape21T75 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 257 2230274 q11Shape21T75=true := by decide

private def q11Shape21T77 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131329 2099218 q11Shape21T77=true := by decide

private def q11Shape21T81 : Tree 11 := (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))))
private theorem q11Shape21T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131345 2099726 q11Shape21T81=true := by decide

private def q11Shape21T82 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131857 2099214 q11Shape21T82=true := by decide

private def q11Shape21T80 : Tree 11 := .split 9 q11Shape21T81 q11Shape21T82
private theorem q11Shape21T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131345 2099214 q11Shape21T80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131345 (2099214 ||| 2^9) q11Shape21T81 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131345 ||| 2^9) 2099214 q11Shape21T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T81OK,q11Shape21T82OK⟩

private def q11Shape21T83 : Tree 11 := (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape21T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131353 2099206 q11Shape21T83=true := by decide

private def q11Shape21T79 : Tree 11 := .split 3 q11Shape21T80 q11Shape21T83
private theorem q11Shape21T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131345 2099206 q11Shape21T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131345 (2099206 ||| 2^3) q11Shape21T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131345 ||| 2^3) 2099206 q11Shape21T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T80OK,q11Shape21T83OK⟩

private def q11Shape21T86 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))))
private theorem q11Shape21T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131349 2099722 q11Shape21T86=true := by decide

private def q11Shape21T87 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131861 2099210 q11Shape21T87=true := by decide

private def q11Shape21T85 : Tree 11 := .split 9 q11Shape21T86 q11Shape21T87
private theorem q11Shape21T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131349 2099210 q11Shape21T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131349 (2099210 ||| 2^9) q11Shape21T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131349 ||| 2^9) 2099210 q11Shape21T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T86OK,q11Shape21T87OK⟩

private def q11Shape21T88 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131357 2099202 q11Shape21T88=true := by decide

private def q11Shape21T84 : Tree 11 := .split 3 q11Shape21T85 q11Shape21T88
private theorem q11Shape21T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131349 2099202 q11Shape21T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131349 (2099202 ||| 2^3) q11Shape21T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131349 ||| 2^3) 2099202 q11Shape21T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T85OK,q11Shape21T88OK⟩

private def q11Shape21T78 : Tree 11 := .split 2 q11Shape21T79 q11Shape21T84
private theorem q11Shape21T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131345 2099202 q11Shape21T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131345 (2099202 ||| 2^2) q11Shape21T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131345 ||| 2^2) 2099202 q11Shape21T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T79OK,q11Shape21T84OK⟩

private def q11Shape21T76 : Tree 11 := .split 4 q11Shape21T77 q11Shape21T78
private theorem q11Shape21T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131329 2099202 q11Shape21T76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131329 (2099202 ||| 2^4) q11Shape21T77 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131329 ||| 2^4) 2099202 q11Shape21T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T77OK,q11Shape21T78OK⟩

private def q11Shape21T74 : Tree 11 := .split 17 q11Shape21T75 q11Shape21T76
private theorem q11Shape21T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 257 2099202 q11Shape21T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 257 (2099202 ||| 2^17) q11Shape21T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (257 ||| 2^17) 2099202 q11Shape21T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T75OK,q11Shape21T76OK⟩

private def q11Shape21T91 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2305 2228242 q11Shape21T91=true := by decide

private def q11Shape21T95 : Tree 11 := (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape21T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2321 2228750 q11Shape21T95=true := by decide

private def q11Shape21T96 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,3,6,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2833 2228238 q11Shape21T96=true := by decide

private def q11Shape21T94 : Tree 11 := .split 9 q11Shape21T95 q11Shape21T96
private theorem q11Shape21T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2321 2228238 q11Shape21T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2321 (2228238 ||| 2^9) q11Shape21T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2321 ||| 2^9) 2228238 q11Shape21T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T95OK,q11Shape21T96OK⟩

private def q11Shape21T97 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {2,3,5,8,9,10})))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape21T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2329 2228230 q11Shape21T97=true := by decide

private def q11Shape21T93 : Tree 11 := .split 3 q11Shape21T94 q11Shape21T97
private theorem q11Shape21T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2321 2228230 q11Shape21T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2321 (2228230 ||| 2^3) q11Shape21T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2321 ||| 2^3) 2228230 q11Shape21T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T94OK,q11Shape21T97OK⟩

private def q11Shape21T98 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.split 10 (.split 15 (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2325 2228226 q11Shape21T98=true := by decide

private def q11Shape21T92 : Tree 11 := .split 2 q11Shape21T93 q11Shape21T98
private theorem q11Shape21T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2321 2228226 q11Shape21T92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2321 (2228226 ||| 2^2) q11Shape21T93 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2321 ||| 2^2) 2228226 q11Shape21T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T93OK,q11Shape21T98OK⟩

private def q11Shape21T90 : Tree 11 := .split 4 q11Shape21T91 q11Shape21T92
private theorem q11Shape21T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2305 2228226 q11Shape21T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2305 (2228226 ||| 2^4) q11Shape21T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2305 ||| 2^4) 2228226 q11Shape21T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T91OK,q11Shape21T92OK⟩

private def q11Shape21T102 : Tree 11 := (.split 9 (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10}))) (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,1,3,8,9,10}))))
private theorem q11Shape21T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133377 2097182 q11Shape21T102=true := by decide

private def q11Shape21T104 : Tree 11 := (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape21T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133385 2097686 q11Shape21T104=true := by decide

private def q11Shape21T105 : Tree 11 := (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,3,6,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133897 2097174 q11Shape21T105=true := by decide

private def q11Shape21T103 : Tree 11 := .split 9 q11Shape21T104 q11Shape21T105
private theorem q11Shape21T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133385 2097174 q11Shape21T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133385 (2097174 ||| 2^9) q11Shape21T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133385 ||| 2^9) 2097174 q11Shape21T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T104OK,q11Shape21T105OK⟩

private def q11Shape21T101 : Tree 11 := .split 3 q11Shape21T102 q11Shape21T103
private theorem q11Shape21T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133377 2097174 q11Shape21T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133377 (2097174 ||| 2^3) q11Shape21T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133377 ||| 2^3) 2097174 q11Shape21T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T102OK,q11Shape21T103OK⟩

private def q11Shape21T109 : Tree 11 := (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10})))) (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,1,4,8,9,10}))))
private theorem q11Shape21T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133381 2098714 q11Shape21T109=true := by decide

private def q11Shape21T110 : Tree 11 := (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,3,4,8,9,10})))
private theorem q11Shape21T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134405 2097690 q11Shape21T110=true := by decide

private def q11Shape21T108 : Tree 11 := .split 10 q11Shape21T109 q11Shape21T110
private theorem q11Shape21T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133381 2097690 q11Shape21T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133381 (2097690 ||| 2^10) q11Shape21T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133381 ||| 2^10) 2097690 q11Shape21T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T109OK,q11Shape21T110OK⟩

private def q11Shape21T111 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133893 2097178 q11Shape21T111=true := by decide

private def q11Shape21T107 : Tree 11 := .split 9 q11Shape21T108 q11Shape21T111
private theorem q11Shape21T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133381 2097178 q11Shape21T107=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133381 (2097178 ||| 2^9) q11Shape21T108 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133381 ||| 2^9) 2097178 q11Shape21T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T108OK,q11Shape21T111OK⟩

private def q11Shape21T112 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133389 2097170 q11Shape21T112=true := by decide

private def q11Shape21T106 : Tree 11 := .split 3 q11Shape21T107 q11Shape21T112
private theorem q11Shape21T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133381 2097170 q11Shape21T106=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133381 (2097170 ||| 2^3) q11Shape21T107 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133381 ||| 2^3) 2097170 q11Shape21T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T107OK,q11Shape21T112OK⟩

private def q11Shape21T100 : Tree 11 := .split 2 q11Shape21T101 q11Shape21T106
private theorem q11Shape21T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133377 2097170 q11Shape21T100=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133377 (2097170 ||| 2^2) q11Shape21T101 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133377 ||| 2^2) 2097170 q11Shape21T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T101OK,q11Shape21T106OK⟩

private def q11Shape21T114 : Tree 11 := (.split 3 (.split 9 (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,5,8,9,10})))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape21T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133393 2097158 q11Shape21T114=true := by decide

private def q11Shape21T115 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133397 2097154 q11Shape21T115=true := by decide

private def q11Shape21T113 : Tree 11 := .split 2 q11Shape21T114 q11Shape21T115
private theorem q11Shape21T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133393 2097154 q11Shape21T113=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133393 (2097154 ||| 2^2) q11Shape21T114 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133393 ||| 2^2) 2097154 q11Shape21T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T114OK,q11Shape21T115OK⟩

private def q11Shape21T99 : Tree 11 := .split 4 q11Shape21T100 q11Shape21T113
private theorem q11Shape21T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133377 2097154 q11Shape21T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133377 (2097154 ||| 2^4) q11Shape21T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133377 ||| 2^4) 2097154 q11Shape21T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T100OK,q11Shape21T113OK⟩

private def q11Shape21T89 : Tree 11 := .split 17 q11Shape21T90 q11Shape21T99
private theorem q11Shape21T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2305 2097154 q11Shape21T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2305 (2097154 ||| 2^17) q11Shape21T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2305 ||| 2^17) 2097154 q11Shape21T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T90OK,q11Shape21T99OK⟩

private def q11Shape21T73 : Tree 11 := .split 11 q11Shape21T74 q11Shape21T89
private theorem q11Shape21T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 257 2097154 q11Shape21T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 257 (2097154 ||| 2^11) q11Shape21T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (257 ||| 2^11) 2097154 q11Shape21T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T74OK,q11Shape21T89OK⟩

private def q11Shape21T63 : Tree 11 := .split 8 q11Shape21T64 q11Shape21T73
private theorem q11Shape21T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 2097154 q11Shape21T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 (2097154 ||| 2^8) q11Shape21T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1 ||| 2^8) 2097154 q11Shape21T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T64OK,q11Shape21T73OK⟩

def q11Shape21P1 : Tree 11 := q11Shape21T63
theorem q11Shape21P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1 2097154 q11Shape21P1=true := q11Shape21T63OK

end Graffiti384b.EffectiveSearch.Q11
