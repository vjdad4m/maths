import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T118 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 2230528 q11Shape21T118=true := by decide

private def q11Shape21T120 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131075 2099472 q11Shape21T120=true := by decide

private def q11Shape21T124 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))))
private theorem q11Shape21T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131091 2099980 q11Shape21T124=true := by decide

private def q11Shape21T125 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))) (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131603 2099468 q11Shape21T125=true := by decide

private def q11Shape21T123 : Tree 11 := .split 9 q11Shape21T124 q11Shape21T125
private theorem q11Shape21T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131091 2099468 q11Shape21T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131091 (2099468 ||| 2^9) q11Shape21T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131091 ||| 2^9) 2099468 q11Shape21T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T124OK,q11Shape21T125OK⟩

private def q11Shape21T126 : Tree 11 := (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,2,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape21T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131099 2099460 q11Shape21T126=true := by decide

private def q11Shape21T122 : Tree 11 := .split 3 q11Shape21T123 q11Shape21T126
private theorem q11Shape21T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131091 2099460 q11Shape21T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131091 (2099460 ||| 2^3) q11Shape21T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131091 ||| 2^3) 2099460 q11Shape21T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T123OK,q11Shape21T126OK⟩

private def q11Shape21T129 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,2,6,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))))
private theorem q11Shape21T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131095 2099976 q11Shape21T129=true := by decide

private def q11Shape21T130 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131607 2099464 q11Shape21T130=true := by decide

private def q11Shape21T128 : Tree 11 := .split 9 q11Shape21T129 q11Shape21T130
private theorem q11Shape21T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131095 2099464 q11Shape21T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131095 (2099464 ||| 2^9) q11Shape21T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131095 ||| 2^9) 2099464 q11Shape21T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T129OK,q11Shape21T130OK⟩

private def q11Shape21T131 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131103 2099456 q11Shape21T131=true := by decide

private def q11Shape21T127 : Tree 11 := .split 3 q11Shape21T128 q11Shape21T131
private theorem q11Shape21T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131095 2099456 q11Shape21T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131095 (2099456 ||| 2^3) q11Shape21T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131095 ||| 2^3) 2099456 q11Shape21T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T128OK,q11Shape21T131OK⟩

private def q11Shape21T121 : Tree 11 := .split 2 q11Shape21T122 q11Shape21T127
private theorem q11Shape21T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131091 2099456 q11Shape21T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131091 (2099456 ||| 2^2) q11Shape21T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131091 ||| 2^2) 2099456 q11Shape21T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T122OK,q11Shape21T127OK⟩

private def q11Shape21T119 : Tree 11 := .split 4 q11Shape21T120 q11Shape21T121
private theorem q11Shape21T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131075 2099456 q11Shape21T119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131075 (2099456 ||| 2^4) q11Shape21T120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131075 ||| 2^4) 2099456 q11Shape21T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T120OK,q11Shape21T121OK⟩

private def q11Shape21T117 : Tree 11 := .split 17 q11Shape21T118 q11Shape21T119
private theorem q11Shape21T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 2099456 q11Shape21T117=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 (2099456 ||| 2^17) q11Shape21T118 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3 ||| 2^17) 2099456 q11Shape21T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T118OK,q11Shape21T119OK⟩

private def q11Shape21T134 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2051 2228496 q11Shape21T134=true := by decide

private def q11Shape21T138 : Tree 11 := (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape21T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2067 2229004 q11Shape21T138=true := by decide

private def q11Shape21T139 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2579 2228492 q11Shape21T139=true := by decide

private def q11Shape21T137 : Tree 11 := .split 9 q11Shape21T138 q11Shape21T139
private theorem q11Shape21T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2067 2228492 q11Shape21T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2067 (2228492 ||| 2^9) q11Shape21T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2067 ||| 2^9) 2228492 q11Shape21T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T138OK,q11Shape21T139OK⟩

private def q11Shape21T140 : Tree 11 := (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,2,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,5,8,9,10})))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape21T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2075 2228484 q11Shape21T140=true := by decide

private def q11Shape21T136 : Tree 11 := .split 3 q11Shape21T137 q11Shape21T140
private theorem q11Shape21T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2067 2228484 q11Shape21T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2067 (2228484 ||| 2^3) q11Shape21T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2067 ||| 2^3) 2228484 q11Shape21T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T137OK,q11Shape21T140OK⟩

private def q11Shape21T141 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,2,6,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2071 2228480 q11Shape21T141=true := by decide

private def q11Shape21T135 : Tree 11 := .split 2 q11Shape21T136 q11Shape21T141
private theorem q11Shape21T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2067 2228480 q11Shape21T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2067 (2228480 ||| 2^2) q11Shape21T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2067 ||| 2^2) 2228480 q11Shape21T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T136OK,q11Shape21T141OK⟩

private def q11Shape21T133 : Tree 11 := .split 4 q11Shape21T134 q11Shape21T135
private theorem q11Shape21T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2051 2228480 q11Shape21T133=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2051 (2228480 ||| 2^4) q11Shape21T134 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2051 ||| 2^4) 2228480 q11Shape21T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T134OK,q11Shape21T135OK⟩

private def q11Shape21T145 : Tree 11 := (.split 9 (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))))
private theorem q11Shape21T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133123 2097436 q11Shape21T145=true := by decide

private def q11Shape21T147 : Tree 11 := (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape21T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133131 2097940 q11Shape21T147=true := by decide

private def q11Shape21T148 : Tree 11 := (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133643 2097428 q11Shape21T148=true := by decide

private def q11Shape21T146 : Tree 11 := .split 9 q11Shape21T147 q11Shape21T148
private theorem q11Shape21T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133131 2097428 q11Shape21T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133131 (2097428 ||| 2^9) q11Shape21T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133131 ||| 2^9) 2097428 q11Shape21T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T147OK,q11Shape21T148OK⟩

private def q11Shape21T144 : Tree 11 := .split 3 q11Shape21T145 q11Shape21T146
private theorem q11Shape21T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133123 2097428 q11Shape21T144=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133123 (2097428 ||| 2^3) q11Shape21T145 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133123 ||| 2^3) 2097428 q11Shape21T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T145OK,q11Shape21T146OK⟩

private def q11Shape21T152 : Tree 11 := (.split 15 (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133127 2098968 q11Shape21T152=true := by decide

private def q11Shape21T153 : Tree 11 := (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,3,4,8,9,10})))
private theorem q11Shape21T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134151 2097944 q11Shape21T153=true := by decide

private def q11Shape21T151 : Tree 11 := .split 10 q11Shape21T152 q11Shape21T153
private theorem q11Shape21T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133127 2097944 q11Shape21T151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133127 (2097944 ||| 2^10) q11Shape21T152 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133127 ||| 2^10) 2097944 q11Shape21T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T152OK,q11Shape21T153OK⟩

private def q11Shape21T154 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133639 2097432 q11Shape21T154=true := by decide

private def q11Shape21T150 : Tree 11 := .split 9 q11Shape21T151 q11Shape21T154
private theorem q11Shape21T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133127 2097432 q11Shape21T150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133127 (2097432 ||| 2^9) q11Shape21T151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133127 ||| 2^9) 2097432 q11Shape21T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T151OK,q11Shape21T154OK⟩

private def q11Shape21T155 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133135 2097424 q11Shape21T155=true := by decide

private def q11Shape21T149 : Tree 11 := .split 3 q11Shape21T150 q11Shape21T155
private theorem q11Shape21T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133127 2097424 q11Shape21T149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133127 (2097424 ||| 2^3) q11Shape21T150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133127 ||| 2^3) 2097424 q11Shape21T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T150OK,q11Shape21T155OK⟩

private def q11Shape21T143 : Tree 11 := .split 2 q11Shape21T144 q11Shape21T149
private theorem q11Shape21T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133123 2097424 q11Shape21T143=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133123 (2097424 ||| 2^2) q11Shape21T144 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133123 ||| 2^2) 2097424 q11Shape21T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T144OK,q11Shape21T149OK⟩

private def q11Shape21T157 : Tree 11 := (.split 3 (.split 9 (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,5,8,9,10})))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape21T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133139 2097412 q11Shape21T157=true := by decide

private def q11Shape21T158 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133143 2097408 q11Shape21T158=true := by decide

private def q11Shape21T156 : Tree 11 := .split 2 q11Shape21T157 q11Shape21T158
private theorem q11Shape21T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133139 2097408 q11Shape21T156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133139 (2097408 ||| 2^2) q11Shape21T157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133139 ||| 2^2) 2097408 q11Shape21T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T157OK,q11Shape21T158OK⟩

private def q11Shape21T142 : Tree 11 := .split 4 q11Shape21T143 q11Shape21T156
private theorem q11Shape21T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133123 2097408 q11Shape21T142=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133123 (2097408 ||| 2^4) q11Shape21T143 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133123 ||| 2^4) 2097408 q11Shape21T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T143OK,q11Shape21T156OK⟩

private def q11Shape21T132 : Tree 11 := .split 17 q11Shape21T133 q11Shape21T142
private theorem q11Shape21T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2051 2097408 q11Shape21T132=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2051 (2097408 ||| 2^17) q11Shape21T133 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2051 ||| 2^17) 2097408 q11Shape21T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T133OK,q11Shape21T142OK⟩

private def q11Shape21T116 : Tree 11 := .split 11 q11Shape21T117 q11Shape21T132
private theorem q11Shape21T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 2097408 q11Shape21T116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 (2097408 ||| 2^11) q11Shape21T117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3 ||| 2^11) 2097408 q11Shape21T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T117OK,q11Shape21T132OK⟩

def q11Shape21P2 : Tree 11 := q11Shape21T116
theorem q11Shape21P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3 2097408 q11Shape21P2=true := q11Shape21T116OK

end Graffiti384b.EffectiveSearch.Q11
