import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T160 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 2230288 q11Shape21T160=true := by decide

private def q11Shape21T165 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 2231820 q11Shape21T165=true := by decide

private def q11Shape21T167 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1299 2263564 q11Shape21T167=true := by decide

private def q11Shape21T182 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {0,3,4,7,8,9}))))))
private theorem q11Shape21T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 8588048908 q11Shape21T182=true := by decide

private def q11Shape21T183 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))))) (.tip (.cover {0,3,4,7,8,10})))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,3,4,7,8,9}))) (.tip (.cover {0,3,4,7,8,10})))))
private theorem q11Shape21T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 42259 8588040716 q11Shape21T183=true := by decide

private def q11Shape21T181 : Tree 11 := .split 13 q11Shape21T182 q11Shape21T183
private theorem q11Shape21T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 8588040716 q11Shape21T181=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (8588040716 ||| 2^13) q11Shape21T182 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^13) 8588040716 q11Shape21T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T182OK,q11Shape21T183OK⟩

private def q11Shape21T185 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.tip (.cover {0,3,4,7,9,10}))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,3,4,7,8,9})))) (.tip (.cover {0,3,4,7,9,10}))))
private theorem q11Shape21T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 38163 8588044812 q11Shape21T185=true := by decide

private def q11Shape21T186 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10}))))) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,7,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {0,3,4,7,8,9}))) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,7,9,10}))))
private theorem q11Shape21T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 46355 8588036620 q11Shape21T186=true := by decide

private def q11Shape21T184 : Tree 11 := .split 13 q11Shape21T185 q11Shape21T186
private theorem q11Shape21T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 38163 8588036620 q11Shape21T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 38163 (8588036620 ||| 2^13) q11Shape21T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (38163 ||| 2^13) 8588036620 q11Shape21T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T185OK,q11Shape21T186OK⟩

private def q11Shape21T180 : Tree 11 := .split 12 q11Shape21T181 q11Shape21T184
private theorem q11Shape21T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 8588036620 q11Shape21T180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (8588036620 ||| 2^12) q11Shape21T181 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^12) 8588036620 q11Shape21T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T181OK,q11Shape21T184OK⟩

private def q11Shape21T187 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295001363 4293069324 q11Shape21T187=true := by decide

private def q11Shape21T179 : Tree 11 := .split 32 q11Shape21T180 q11Shape21T187
private theorem q11Shape21T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 4293069324 q11Shape21T179=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (4293069324 ||| 2^32) q11Shape21T180 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^32) 4293069324 q11Shape21T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T180OK,q11Shape21T187OK⟩

private def q11Shape21T188 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147517715 2145585676 q11Shape21T188=true := by decide

private def q11Shape21T178 : Tree 11 := .split 31 q11Shape21T179 q11Shape21T188
private theorem q11Shape21T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 2145585676 q11Shape21T178=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (2145585676 ||| 2^31) q11Shape21T179 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^31) 2145585676 q11Shape21T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T179OK,q11Shape21T188OK⟩

private def q11Shape21T189 : Tree 11 := (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,3,4,8,9,10})))
private theorem q11Shape21T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073775891 1071843852 q11Shape21T189=true := by decide

private def q11Shape21T177 : Tree 11 := .split 30 q11Shape21T178 q11Shape21T189
private theorem q11Shape21T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 1071843852 q11Shape21T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (1071843852 ||| 2^30) q11Shape21T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^30) 1071843852 q11Shape21T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T178OK,q11Shape21T189OK⟩

private def q11Shape21T190 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536904979 534972940 q11Shape21T190=true := by decide

private def q11Shape21T176 : Tree 11 := .split 29 q11Shape21T177 q11Shape21T190
private theorem q11Shape21T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 534972940 q11Shape21T176=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (534972940 ||| 2^29) q11Shape21T177 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^29) 534972940 q11Shape21T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T177OK,q11Shape21T190OK⟩

private def q11Shape21T191 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268469523 266537484 q11Shape21T191=true := by decide

private def q11Shape21T175 : Tree 11 := .split 28 q11Shape21T176 q11Shape21T191
private theorem q11Shape21T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 266537484 q11Shape21T175=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (266537484 ||| 2^28) q11Shape21T176 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^28) 266537484 q11Shape21T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T176OK,q11Shape21T191OK⟩

private def q11Shape21T192 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134251795 132319756 q11Shape21T192=true := by decide

private def q11Shape21T174 : Tree 11 := .split 27 q11Shape21T175 q11Shape21T192
private theorem q11Shape21T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 132319756 q11Shape21T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (132319756 ||| 2^27) q11Shape21T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^27) 132319756 q11Shape21T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T175OK,q11Shape21T192OK⟩

private def q11Shape21T193 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33588499 98765324 q11Shape21T193=true := by decide

private def q11Shape21T173 : Tree 11 := .split 25 q11Shape21T174 q11Shape21T193
private theorem q11Shape21T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 98765324 q11Shape21T173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (98765324 ||| 2^25) q11Shape21T174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^25) 98765324 q11Shape21T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T174OK,q11Shape21T193OK⟩

private def q11Shape21T194 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16811283 81988108 q11Shape21T194=true := by decide

private def q11Shape21T172 : Tree 11 := .split 24 q11Shape21T173 q11Shape21T194
private theorem q11Shape21T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 81988108 q11Shape21T172=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (81988108 ||| 2^24) q11Shape21T173 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^24) 81988108 q11Shape21T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T173OK,q11Shape21T194OK⟩

private def q11Shape21T195 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8422675 73599500 q11Shape21T195=true := by decide

private def q11Shape21T171 : Tree 11 := .split 23 q11Shape21T172 q11Shape21T195
private theorem q11Shape21T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 73599500 q11Shape21T171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (73599500 ||| 2^23) q11Shape21T172 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^23) 73599500 q11Shape21T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T172OK,q11Shape21T195OK⟩

private def q11Shape21T196 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4228371 69405196 q11Shape21T196=true := by decide

private def q11Shape21T170 : Tree 11 := .split 22 q11Shape21T171 q11Shape21T196
private theorem q11Shape21T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 69405196 q11Shape21T170=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (69405196 ||| 2^22) q11Shape21T171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^22) 69405196 q11Shape21T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T171OK,q11Shape21T196OK⟩

private def q11Shape21T197 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67142931 2296332 q11Shape21T197=true := by decide

private def q11Shape21T169 : Tree 11 := .split 26 q11Shape21T170 q11Shape21T197
private theorem q11Shape21T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 2296332 q11Shape21T169=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (2296332 ||| 2^26) q11Shape21T170 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^26) 2296332 q11Shape21T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T170OK,q11Shape21T197OK⟩

private def q11Shape21T198 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 99603 2230796 q11Shape21T198=true := by decide

private def q11Shape21T168 : Tree 11 := .split 16 q11Shape21T169 q11Shape21T198
private theorem q11Shape21T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 2230796 q11Shape21T168=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34067 (2230796 ||| 2^16) q11Shape21T169 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (34067 ||| 2^16) 2230796 q11Shape21T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T169OK,q11Shape21T198OK⟩

private def q11Shape21T166 : Tree 11 := .split 15 q11Shape21T167 q11Shape21T168
private theorem q11Shape21T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1299 2230796 q11Shape21T166=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1299 (2230796 ||| 2^15) q11Shape21T167 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1299 ||| 2^15) 2230796 q11Shape21T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T167OK,q11Shape21T168OK⟩

private def q11Shape21T164 : Tree 11 := .split 10 q11Shape21T165 q11Shape21T166
private theorem q11Shape21T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 2230796 q11Shape21T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 (2230796 ||| 2^10) q11Shape21T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (275 ||| 2^10) 2230796 q11Shape21T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T165OK,q11Shape21T166OK⟩

private def q11Shape21T202 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 787 2329612 q11Shape21T202=true := by decide

private def q11Shape21T216 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {0,3,4,7,8,9}))))))
private theorem q11Shape21T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 8588016652 q11Shape21T216=true := by decide

private def q11Shape21T217 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))))) (.tip (.cover {0,3,4,7,8,10})))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,3,4,7,8,9}))) (.tip (.cover {0,3,4,7,8,10})))))
private theorem q11Shape21T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 74515 8588008460 q11Shape21T217=true := by decide

private def q11Shape21T215 : Tree 11 := .split 13 q11Shape21T216 q11Shape21T217
private theorem q11Shape21T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 8588008460 q11Shape21T215=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (8588008460 ||| 2^13) q11Shape21T216 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^13) 8588008460 q11Shape21T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T216OK,q11Shape21T217OK⟩

private def q11Shape21T219 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.tip (.cover {0,3,4,7,9,10}))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,3,4,7,8,9})))) (.tip (.cover {0,3,4,7,9,10}))))
private theorem q11Shape21T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 70419 8588012556 q11Shape21T219=true := by decide

private def q11Shape21T220 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10}))))) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,7,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {0,3,4,7,8,9}))) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,7,9,10}))))
private theorem q11Shape21T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 78611 8588004364 q11Shape21T220=true := by decide

private def q11Shape21T218 : Tree 11 := .split 13 q11Shape21T219 q11Shape21T220
private theorem q11Shape21T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 70419 8588004364 q11Shape21T218=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 70419 (8588004364 ||| 2^13) q11Shape21T219 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (70419 ||| 2^13) 8588004364 q11Shape21T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T219OK,q11Shape21T220OK⟩

private def q11Shape21T214 : Tree 11 := .split 12 q11Shape21T215 q11Shape21T218
private theorem q11Shape21T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 8588004364 q11Shape21T214=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (8588004364 ||| 2^12) q11Shape21T215 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^12) 8588004364 q11Shape21T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T215OK,q11Shape21T218OK⟩

private def q11Shape21T221 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295033619 4293037068 q11Shape21T221=true := by decide

private def q11Shape21T213 : Tree 11 := .split 32 q11Shape21T214 q11Shape21T221
private theorem q11Shape21T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 4293037068 q11Shape21T213=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (4293037068 ||| 2^32) q11Shape21T214 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^32) 4293037068 q11Shape21T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T214OK,q11Shape21T221OK⟩

private def q11Shape21T222 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147549971 2145553420 q11Shape21T222=true := by decide

private def q11Shape21T212 : Tree 11 := .split 31 q11Shape21T213 q11Shape21T222
private theorem q11Shape21T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 2145553420 q11Shape21T212=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (2145553420 ||| 2^31) q11Shape21T213 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^31) 2145553420 q11Shape21T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T213OK,q11Shape21T222OK⟩

private def q11Shape21T223 : Tree 11 := (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,3,4,8,9,10})))
private theorem q11Shape21T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073808147 1071811596 q11Shape21T223=true := by decide

private def q11Shape21T211 : Tree 11 := .split 30 q11Shape21T212 q11Shape21T223
private theorem q11Shape21T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 1071811596 q11Shape21T211=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (1071811596 ||| 2^30) q11Shape21T212 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^30) 1071811596 q11Shape21T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T212OK,q11Shape21T223OK⟩

private def q11Shape21T224 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536937235 534940684 q11Shape21T224=true := by decide

private def q11Shape21T210 : Tree 11 := .split 29 q11Shape21T211 q11Shape21T224
private theorem q11Shape21T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 534940684 q11Shape21T210=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (534940684 ||| 2^29) q11Shape21T211 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^29) 534940684 q11Shape21T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T211OK,q11Shape21T224OK⟩

private def q11Shape21T225 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268501779 266505228 q11Shape21T225=true := by decide

private def q11Shape21T209 : Tree 11 := .split 28 q11Shape21T210 q11Shape21T225
private theorem q11Shape21T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 266505228 q11Shape21T209=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (266505228 ||| 2^28) q11Shape21T210 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^28) 266505228 q11Shape21T225)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T210OK,q11Shape21T225OK⟩

private def q11Shape21T226 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134284051 132287500 q11Shape21T226=true := by decide

private def q11Shape21T208 : Tree 11 := .split 27 q11Shape21T209 q11Shape21T226
private theorem q11Shape21T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 132287500 q11Shape21T208=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (132287500 ||| 2^27) q11Shape21T209 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^27) 132287500 q11Shape21T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T209OK,q11Shape21T226OK⟩

private def q11Shape21T227 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33620755 98733068 q11Shape21T227=true := by decide

private def q11Shape21T207 : Tree 11 := .split 25 q11Shape21T208 q11Shape21T227
private theorem q11Shape21T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 98733068 q11Shape21T207=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (98733068 ||| 2^25) q11Shape21T208 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^25) 98733068 q11Shape21T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T208OK,q11Shape21T227OK⟩

private def q11Shape21T228 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16843539 81955852 q11Shape21T228=true := by decide

private def q11Shape21T206 : Tree 11 := .split 24 q11Shape21T207 q11Shape21T228
private theorem q11Shape21T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 81955852 q11Shape21T206=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (81955852 ||| 2^24) q11Shape21T207 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^24) 81955852 q11Shape21T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T207OK,q11Shape21T228OK⟩

private def q11Shape21T229 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8454931 73567244 q11Shape21T229=true := by decide

private def q11Shape21T205 : Tree 11 := .split 23 q11Shape21T206 q11Shape21T229
private theorem q11Shape21T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 73567244 q11Shape21T205=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (73567244 ||| 2^23) q11Shape21T206 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^23) 73567244 q11Shape21T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T206OK,q11Shape21T229OK⟩

private def q11Shape21T230 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4260627 69372940 q11Shape21T230=true := by decide

private def q11Shape21T204 : Tree 11 := .split 22 q11Shape21T205 q11Shape21T230
private theorem q11Shape21T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 69372940 q11Shape21T204=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (69372940 ||| 2^22) q11Shape21T205 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^22) 69372940 q11Shape21T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T205OK,q11Shape21T230OK⟩

private def q11Shape21T231 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67175187 2264076 q11Shape21T231=true := by decide

private def q11Shape21T203 : Tree 11 := .split 26 q11Shape21T204 q11Shape21T231
private theorem q11Shape21T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 2264076 q11Shape21T203=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66323 (2264076 ||| 2^26) q11Shape21T204 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (66323 ||| 2^26) 2264076 q11Shape21T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T204OK,q11Shape21T231OK⟩

private def q11Shape21T201 : Tree 11 := .split 16 q11Shape21T202 q11Shape21T203
private theorem q11Shape21T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 787 2264076 q11Shape21T201=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 787 (2264076 ||| 2^16) q11Shape21T202 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (787 ||| 2^16) 2264076 q11Shape21T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T202OK,q11Shape21T203OK⟩

private def q11Shape21T232 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33555 2231308 q11Shape21T232=true := by decide

private def q11Shape21T200 : Tree 11 := .split 15 q11Shape21T201 q11Shape21T232
private theorem q11Shape21T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 787 2231308 q11Shape21T200=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 787 (2231308 ||| 2^15) q11Shape21T201 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (787 ||| 2^15) 2231308 q11Shape21T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T201OK,q11Shape21T232OK⟩

private def q11Shape21T233 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1811 2230284 q11Shape21T233=true := by decide

private def q11Shape21T199 : Tree 11 := .split 10 q11Shape21T200 q11Shape21T233
private theorem q11Shape21T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 787 2230284 q11Shape21T199=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 787 (2230284 ||| 2^10) q11Shape21T200 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (787 ||| 2^10) 2230284 q11Shape21T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T200OK,q11Shape21T233OK⟩

private def q11Shape21T163 : Tree 11 := .split 9 q11Shape21T164 q11Shape21T199
private theorem q11Shape21T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 2230284 q11Shape21T163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 (2230284 ||| 2^9) q11Shape21T164 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (275 ||| 2^9) 2230284 q11Shape21T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T164OK,q11Shape21T199OK⟩

private def q11Shape21T237 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 283 2264580 q11Shape21T237=true := by decide

private def q11Shape21T248 : Tree 11 := (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10})))
private theorem q11Shape21T248OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 2145586692 q11Shape21T248=true := by decide

private def q11Shape21T249 : Tree 11 := (.tip (.cover {0,2,4,8,9,10}))
private theorem q11Shape21T249OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073774875 1071844868 q11Shape21T249=true := by decide

private def q11Shape21T247 : Tree 11 := .split 30 q11Shape21T248 q11Shape21T249
private theorem q11Shape21T247OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 1071844868 q11Shape21T247=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (1071844868 ||| 2^30) q11Shape21T248 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^30) 1071844868 q11Shape21T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T248OK,q11Shape21T249OK⟩

private def q11Shape21T250 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T250OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536903963 534973956 q11Shape21T250=true := by decide

private def q11Shape21T246 : Tree 11 := .split 29 q11Shape21T247 q11Shape21T250
private theorem q11Shape21T246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 534973956 q11Shape21T246=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (534973956 ||| 2^29) q11Shape21T247 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^29) 534973956 q11Shape21T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T247OK,q11Shape21T250OK⟩

private def q11Shape21T251 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T251OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268468507 266538500 q11Shape21T251=true := by decide

private def q11Shape21T245 : Tree 11 := .split 28 q11Shape21T246 q11Shape21T251
private theorem q11Shape21T245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 266538500 q11Shape21T245=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (266538500 ||| 2^28) q11Shape21T246 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^28) 266538500 q11Shape21T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T246OK,q11Shape21T251OK⟩

private def q11Shape21T252 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T252OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134250779 132320772 q11Shape21T252=true := by decide

private def q11Shape21T244 : Tree 11 := .split 27 q11Shape21T245 q11Shape21T252
private theorem q11Shape21T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 132320772 q11Shape21T244=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (132320772 ||| 2^27) q11Shape21T245 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^27) 132320772 q11Shape21T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T245OK,q11Shape21T252OK⟩

private def q11Shape21T253 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T253OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33587483 98766340 q11Shape21T253=true := by decide

private def q11Shape21T243 : Tree 11 := .split 25 q11Shape21T244 q11Shape21T253
private theorem q11Shape21T243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 98766340 q11Shape21T243=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (98766340 ||| 2^25) q11Shape21T244 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^25) 98766340 q11Shape21T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T244OK,q11Shape21T253OK⟩

private def q11Shape21T254 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T254OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16810267 81989124 q11Shape21T254=true := by decide

private def q11Shape21T242 : Tree 11 := .split 24 q11Shape21T243 q11Shape21T254
private theorem q11Shape21T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 81989124 q11Shape21T242=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (81989124 ||| 2^24) q11Shape21T243 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^24) 81989124 q11Shape21T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T243OK,q11Shape21T254OK⟩

private def q11Shape21T255 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T255OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8421659 73600516 q11Shape21T255=true := by decide

private def q11Shape21T241 : Tree 11 := .split 23 q11Shape21T242 q11Shape21T255
private theorem q11Shape21T241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 73600516 q11Shape21T241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (73600516 ||| 2^23) q11Shape21T242 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^23) 73600516 q11Shape21T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T242OK,q11Shape21T255OK⟩

private def q11Shape21T256 : Tree 11 := (.tip (.cover {0,2,5,8,9,10}))
private theorem q11Shape21T256OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4227355 69406212 q11Shape21T256=true := by decide

private def q11Shape21T240 : Tree 11 := .split 22 q11Shape21T241 q11Shape21T256
private theorem q11Shape21T240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 69406212 q11Shape21T240=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (69406212 ||| 2^22) q11Shape21T241 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^22) 69406212 q11Shape21T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T241OK,q11Shape21T256OK⟩

private def q11Shape21T257 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T257OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67141915 2297348 q11Shape21T257=true := by decide

private def q11Shape21T239 : Tree 11 := .split 26 q11Shape21T240 q11Shape21T257
private theorem q11Shape21T239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 2297348 q11Shape21T239=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (2297348 ||| 2^26) q11Shape21T240 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^26) 2297348 q11Shape21T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T240OK,q11Shape21T257OK⟩

private def q11Shape21T258 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T258OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 98587 2231812 q11Shape21T258=true := by decide

private def q11Shape21T238 : Tree 11 := .split 16 q11Shape21T239 q11Shape21T258
private theorem q11Shape21T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 2231812 q11Shape21T238=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33051 (2231812 ||| 2^16) q11Shape21T239 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (33051 ||| 2^16) 2231812 q11Shape21T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T239OK,q11Shape21T258OK⟩

private def q11Shape21T236 : Tree 11 := .split 15 q11Shape21T237 q11Shape21T238
private theorem q11Shape21T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 283 2231812 q11Shape21T236=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 283 (2231812 ||| 2^15) q11Shape21T237 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (283 ||| 2^15) 2231812 q11Shape21T238)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T237OK,q11Shape21T238OK⟩

private def q11Shape21T259 : Tree 11 := (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {0,3,4,7,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))))
private theorem q11Shape21T259OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1307 2230788 q11Shape21T259=true := by decide

private def q11Shape21T235 : Tree 11 := .split 10 q11Shape21T236 q11Shape21T259
private theorem q11Shape21T235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 283 2230788 q11Shape21T235=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 283 (2230788 ||| 2^10) q11Shape21T236 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (283 ||| 2^10) 2230788 q11Shape21T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T236OK,q11Shape21T259OK⟩

private def q11Shape21T276 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.split 20 (.tip (.cover {0,1,2,5,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))))))
private theorem q11Shape21T276OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 8588082180 q11Shape21T276=true := by decide

private def q11Shape21T277 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {0,1,2,5,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T277OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8987 8588073988 q11Shape21T277=true := by decide

private def q11Shape21T275 : Tree 11 := .split 13 q11Shape21T276 q11Shape21T277
private theorem q11Shape21T275OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 8588073988 q11Shape21T275=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (8588073988 ||| 2^13) q11Shape21T276 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^13) 8588073988 q11Shape21T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T276OK,q11Shape21T277OK⟩

private def q11Shape21T278 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.split 20 (.tip (.cover {0,1,2,5,8,9})) (.split 5 (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,3,9,10})))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,9})))))) (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10})))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape21T278OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4891 8588069892 q11Shape21T278=true := by decide

private def q11Shape21T274 : Tree 11 := .split 12 q11Shape21T275 q11Shape21T278
private theorem q11Shape21T274OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 8588069892 q11Shape21T274=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (8588069892 ||| 2^12) q11Shape21T275 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^12) 8588069892 q11Shape21T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T275OK,q11Shape21T278OK⟩

private def q11Shape21T279 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T279OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4294968091 4293102596 q11Shape21T279=true := by decide

private def q11Shape21T273 : Tree 11 := .split 32 q11Shape21T274 q11Shape21T279
private theorem q11Shape21T273OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 4293102596 q11Shape21T273=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (4293102596 ||| 2^32) q11Shape21T274 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^32) 4293102596 q11Shape21T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T274OK,q11Shape21T279OK⟩

private def q11Shape21T280 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T280OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147484443 2145618948 q11Shape21T280=true := by decide

private def q11Shape21T272 : Tree 11 := .split 31 q11Shape21T273 q11Shape21T280
private theorem q11Shape21T272OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 2145618948 q11Shape21T272=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (2145618948 ||| 2^31) q11Shape21T273 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^31) 2145618948 q11Shape21T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T273OK,q11Shape21T280OK⟩

private def q11Shape21T281 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape21T281OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073742619 1071877124 q11Shape21T281=true := by decide

private def q11Shape21T271 : Tree 11 := .split 30 q11Shape21T272 q11Shape21T281
private theorem q11Shape21T271OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 1071877124 q11Shape21T271=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (1071877124 ||| 2^30) q11Shape21T272 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^30) 1071877124 q11Shape21T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T272OK,q11Shape21T281OK⟩

private def q11Shape21T282 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T282OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536871707 535006212 q11Shape21T282=true := by decide

private def q11Shape21T270 : Tree 11 := .split 29 q11Shape21T271 q11Shape21T282
private theorem q11Shape21T270OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 535006212 q11Shape21T270=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (535006212 ||| 2^29) q11Shape21T271 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^29) 535006212 q11Shape21T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T271OK,q11Shape21T282OK⟩

private def q11Shape21T283 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T283OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268436251 266570756 q11Shape21T283=true := by decide

private def q11Shape21T269 : Tree 11 := .split 28 q11Shape21T270 q11Shape21T283
private theorem q11Shape21T269OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 266570756 q11Shape21T269=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (266570756 ||| 2^28) q11Shape21T270 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^28) 266570756 q11Shape21T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T270OK,q11Shape21T283OK⟩

private def q11Shape21T284 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T284OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134218523 132353028 q11Shape21T284=true := by decide

private def q11Shape21T268 : Tree 11 := .split 27 q11Shape21T269 q11Shape21T284
private theorem q11Shape21T268OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 132353028 q11Shape21T268=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (132353028 ||| 2^27) q11Shape21T269 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^27) 132353028 q11Shape21T284)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T269OK,q11Shape21T284OK⟩

private def q11Shape21T285 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T285OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33555227 98798596 q11Shape21T285=true := by decide

private def q11Shape21T267 : Tree 11 := .split 25 q11Shape21T268 q11Shape21T285
private theorem q11Shape21T267OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 98798596 q11Shape21T267=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (98798596 ||| 2^25) q11Shape21T268 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^25) 98798596 q11Shape21T285)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T268OK,q11Shape21T285OK⟩

private def q11Shape21T286 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T286OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16778011 82021380 q11Shape21T286=true := by decide

private def q11Shape21T266 : Tree 11 := .split 24 q11Shape21T267 q11Shape21T286
private theorem q11Shape21T266OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 82021380 q11Shape21T266=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (82021380 ||| 2^24) q11Shape21T267 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^24) 82021380 q11Shape21T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T267OK,q11Shape21T286OK⟩

private def q11Shape21T287 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T287OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8389403 73632772 q11Shape21T287=true := by decide

private def q11Shape21T265 : Tree 11 := .split 23 q11Shape21T266 q11Shape21T287
private theorem q11Shape21T265OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 73632772 q11Shape21T265=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (73632772 ||| 2^23) q11Shape21T266 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^23) 73632772 q11Shape21T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T266OK,q11Shape21T287OK⟩

private def q11Shape21T288 : Tree 11 := (.tip (.cover {0,2,5,8,9,10}))
private theorem q11Shape21T288OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4195099 69438468 q11Shape21T288=true := by decide

private def q11Shape21T264 : Tree 11 := .split 22 q11Shape21T265 q11Shape21T288
private theorem q11Shape21T264OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 69438468 q11Shape21T264=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (69438468 ||| 2^22) q11Shape21T265 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^22) 69438468 q11Shape21T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T265OK,q11Shape21T288OK⟩

private def q11Shape21T289 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T289OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67109659 2329604 q11Shape21T289=true := by decide

private def q11Shape21T263 : Tree 11 := .split 26 q11Shape21T264 q11Shape21T289
private theorem q11Shape21T263OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 2329604 q11Shape21T263=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (2329604 ||| 2^26) q11Shape21T264 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^26) 2329604 q11Shape21T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T264OK,q11Shape21T289OK⟩

private def q11Shape21T290 : Tree 11 := (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,7,9,10})) (.split 13 (.tip (.cover {2,4,5,7,8,10})) (.split 14 (.tip (.cover {2,4,5,7,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,3,4,7,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))
private theorem q11Shape21T290OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66331 2264068 q11Shape21T290=true := by decide

private def q11Shape21T262 : Tree 11 := .split 16 q11Shape21T263 q11Shape21T290
private theorem q11Shape21T262OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 2264068 q11Shape21T262=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (2264068 ||| 2^16) q11Shape21T263 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^16) 2264068 q11Shape21T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T263OK,q11Shape21T290OK⟩

private def q11Shape21T291 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {3,4,6,7,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,7,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,2,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T291OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33563 2231300 q11Shape21T291=true := by decide

private def q11Shape21T261 : Tree 11 := .split 15 q11Shape21T262 q11Shape21T291
private theorem q11Shape21T261OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 2231300 q11Shape21T261=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (2231300 ||| 2^15) q11Shape21T262 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^15) 2231300 q11Shape21T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T262OK,q11Shape21T291OK⟩

private def q11Shape21T292 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T292OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1819 2230276 q11Shape21T292=true := by decide

private def q11Shape21T260 : Tree 11 := .split 10 q11Shape21T261 q11Shape21T292
private theorem q11Shape21T260OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 2230276 q11Shape21T260=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 795 (2230276 ||| 2^10) q11Shape21T261 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (795 ||| 2^10) 2230276 q11Shape21T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T261OK,q11Shape21T292OK⟩

private def q11Shape21T234 : Tree 11 := .split 9 q11Shape21T235 q11Shape21T260
private theorem q11Shape21T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 283 2230276 q11Shape21T234=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 283 (2230276 ||| 2^9) q11Shape21T235 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (283 ||| 2^9) 2230276 q11Shape21T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T235OK,q11Shape21T260OK⟩

private def q11Shape21T162 : Tree 11 := .split 3 q11Shape21T163 q11Shape21T234
private theorem q11Shape21T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 2230276 q11Shape21T162=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 (2230276 ||| 2^3) q11Shape21T163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (275 ||| 2^3) 2230276 q11Shape21T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T163OK,q11Shape21T234OK⟩

private def q11Shape21T298 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T298OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 2330120 q11Shape21T298=true := by decide

private def q11Shape21T308 : Tree 11 := (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10})))
private theorem q11Shape21T308OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 2145553928 q11Shape21T308=true := by decide

private def q11Shape21T309 : Tree 11 := (.tip (.cover {0,2,4,8,9,10}))
private theorem q11Shape21T309OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073807639 1071812104 q11Shape21T309=true := by decide

private def q11Shape21T307 : Tree 11 := .split 30 q11Shape21T308 q11Shape21T309
private theorem q11Shape21T307OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 1071812104 q11Shape21T307=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (1071812104 ||| 2^30) q11Shape21T308 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^30) 1071812104 q11Shape21T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T308OK,q11Shape21T309OK⟩

private def q11Shape21T310 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T310OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536936727 534941192 q11Shape21T310=true := by decide

private def q11Shape21T306 : Tree 11 := .split 29 q11Shape21T307 q11Shape21T310
private theorem q11Shape21T306OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 534941192 q11Shape21T306=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (534941192 ||| 2^29) q11Shape21T307 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^29) 534941192 q11Shape21T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T307OK,q11Shape21T310OK⟩

private def q11Shape21T311 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T311OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268501271 266505736 q11Shape21T311=true := by decide

private def q11Shape21T305 : Tree 11 := .split 28 q11Shape21T306 q11Shape21T311
private theorem q11Shape21T305OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 266505736 q11Shape21T305=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (266505736 ||| 2^28) q11Shape21T306 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^28) 266505736 q11Shape21T311)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T306OK,q11Shape21T311OK⟩

private def q11Shape21T312 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T312OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134283543 132288008 q11Shape21T312=true := by decide

private def q11Shape21T304 : Tree 11 := .split 27 q11Shape21T305 q11Shape21T312
private theorem q11Shape21T304OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 132288008 q11Shape21T304=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (132288008 ||| 2^27) q11Shape21T305 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^27) 132288008 q11Shape21T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T305OK,q11Shape21T312OK⟩

private def q11Shape21T313 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T313OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33620247 98733576 q11Shape21T313=true := by decide

private def q11Shape21T303 : Tree 11 := .split 25 q11Shape21T304 q11Shape21T313
private theorem q11Shape21T303OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 98733576 q11Shape21T303=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (98733576 ||| 2^25) q11Shape21T304 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^25) 98733576 q11Shape21T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T304OK,q11Shape21T313OK⟩

private def q11Shape21T314 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T314OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16843031 81956360 q11Shape21T314=true := by decide

private def q11Shape21T302 : Tree 11 := .split 24 q11Shape21T303 q11Shape21T314
private theorem q11Shape21T302OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 81956360 q11Shape21T302=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (81956360 ||| 2^24) q11Shape21T303 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^24) 81956360 q11Shape21T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T303OK,q11Shape21T314OK⟩

private def q11Shape21T315 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T315OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8454423 73567752 q11Shape21T315=true := by decide

private def q11Shape21T301 : Tree 11 := .split 23 q11Shape21T302 q11Shape21T315
private theorem q11Shape21T301OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 73567752 q11Shape21T301=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (73567752 ||| 2^23) q11Shape21T302 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^23) 73567752 q11Shape21T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T302OK,q11Shape21T315OK⟩

private def q11Shape21T316 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T316OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4260119 69373448 q11Shape21T316=true := by decide

private def q11Shape21T300 : Tree 11 := .split 22 q11Shape21T301 q11Shape21T316
private theorem q11Shape21T300OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 69373448 q11Shape21T300=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (69373448 ||| 2^22) q11Shape21T301 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^22) 69373448 q11Shape21T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T301OK,q11Shape21T316OK⟩

private def q11Shape21T317 : Tree 11 := (.tip (.cover {0,2,6,8,9,10}))
private theorem q11Shape21T317OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67174679 2264584 q11Shape21T317=true := by decide

private def q11Shape21T299 : Tree 11 := .split 26 q11Shape21T300 q11Shape21T317
private theorem q11Shape21T299OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 2264584 q11Shape21T299=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 65815 (2264584 ||| 2^26) q11Shape21T300 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (65815 ||| 2^26) 2264584 q11Shape21T317)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T300OK,q11Shape21T317OK⟩

private def q11Shape21T297 : Tree 11 := .split 16 q11Shape21T298 q11Shape21T299
private theorem q11Shape21T297OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 2264584 q11Shape21T297=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 (2264584 ||| 2^16) q11Shape21T298 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (279 ||| 2^16) 2264584 q11Shape21T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T298OK,q11Shape21T299OK⟩

private def q11Shape21T318 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T318OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33047 2231816 q11Shape21T318=true := by decide

private def q11Shape21T296 : Tree 11 := .split 15 q11Shape21T297 q11Shape21T318
private theorem q11Shape21T296OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 2231816 q11Shape21T296=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 (2231816 ||| 2^15) q11Shape21T297 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (279 ||| 2^15) 2231816 q11Shape21T318)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T297OK,q11Shape21T318OK⟩

private def q11Shape21T334 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,6,9,10})) (.split 19 (.tip (.cover {0,1,2,6,8,10})) (.split 20 (.tip (.cover {0,1,2,6,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {0,1,2,6,9,10})) (.split 19 (.tip (.cover {0,1,2,6,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))))))
private theorem q11Shape21T334OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 8588081672 q11Shape21T334=true := by decide

private def q11Shape21T335 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,6,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {0,1,2,6,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.split 18 (.tip (.cover {0,1,2,6,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T335OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 9495 8588073480 q11Shape21T335=true := by decide

private def q11Shape21T333 : Tree 11 := .split 13 q11Shape21T334 q11Shape21T335
private theorem q11Shape21T333OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 8588073480 q11Shape21T333=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (8588073480 ||| 2^13) q11Shape21T334 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^13) 8588073480 q11Shape21T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T334OK,q11Shape21T335OK⟩

private def q11Shape21T336 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,6,8,10})) (.split 20 (.tip (.cover {0,1,2,6,8,9})) (.split 5 (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,3,9,10})))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,6,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,9})))))) (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10})))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape21T336OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 5399 8588069384 q11Shape21T336=true := by decide

private def q11Shape21T332 : Tree 11 := .split 12 q11Shape21T333 q11Shape21T336
private theorem q11Shape21T332OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 8588069384 q11Shape21T332=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (8588069384 ||| 2^12) q11Shape21T333 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^12) 8588069384 q11Shape21T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T333OK,q11Shape21T336OK⟩

private def q11Shape21T337 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T337OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4294968599 4293102088 q11Shape21T337=true := by decide

private def q11Shape21T331 : Tree 11 := .split 32 q11Shape21T332 q11Shape21T337
private theorem q11Shape21T331OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 4293102088 q11Shape21T331=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (4293102088 ||| 2^32) q11Shape21T332 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^32) 4293102088 q11Shape21T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T332OK,q11Shape21T337OK⟩

private def q11Shape21T338 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T338OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147484951 2145618440 q11Shape21T338=true := by decide

private def q11Shape21T330 : Tree 11 := .split 31 q11Shape21T331 q11Shape21T338
private theorem q11Shape21T330OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 2145618440 q11Shape21T330=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (2145618440 ||| 2^31) q11Shape21T331 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^31) 2145618440 q11Shape21T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T331OK,q11Shape21T338OK⟩

private def q11Shape21T339 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape21T339OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073743127 1071876616 q11Shape21T339=true := by decide

private def q11Shape21T329 : Tree 11 := .split 30 q11Shape21T330 q11Shape21T339
private theorem q11Shape21T329OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 1071876616 q11Shape21T329=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (1071876616 ||| 2^30) q11Shape21T330 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^30) 1071876616 q11Shape21T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T330OK,q11Shape21T339OK⟩

private def q11Shape21T340 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T340OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536872215 535005704 q11Shape21T340=true := by decide

private def q11Shape21T328 : Tree 11 := .split 29 q11Shape21T329 q11Shape21T340
private theorem q11Shape21T328OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 535005704 q11Shape21T328=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (535005704 ||| 2^29) q11Shape21T329 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^29) 535005704 q11Shape21T340)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T329OK,q11Shape21T340OK⟩

private def q11Shape21T341 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T341OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268436759 266570248 q11Shape21T341=true := by decide

private def q11Shape21T327 : Tree 11 := .split 28 q11Shape21T328 q11Shape21T341
private theorem q11Shape21T327OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 266570248 q11Shape21T327=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (266570248 ||| 2^28) q11Shape21T328 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^28) 266570248 q11Shape21T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T328OK,q11Shape21T341OK⟩

private def q11Shape21T342 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T342OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134219031 132352520 q11Shape21T342=true := by decide

private def q11Shape21T326 : Tree 11 := .split 27 q11Shape21T327 q11Shape21T342
private theorem q11Shape21T326OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 132352520 q11Shape21T326=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (132352520 ||| 2^27) q11Shape21T327 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^27) 132352520 q11Shape21T342)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T327OK,q11Shape21T342OK⟩

private def q11Shape21T343 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T343OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33555735 98798088 q11Shape21T343=true := by decide

private def q11Shape21T325 : Tree 11 := .split 25 q11Shape21T326 q11Shape21T343
private theorem q11Shape21T325OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 98798088 q11Shape21T325=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (98798088 ||| 2^25) q11Shape21T326 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^25) 98798088 q11Shape21T343)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T326OK,q11Shape21T343OK⟩

private def q11Shape21T344 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T344OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16778519 82020872 q11Shape21T344=true := by decide

private def q11Shape21T324 : Tree 11 := .split 24 q11Shape21T325 q11Shape21T344
private theorem q11Shape21T324OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 82020872 q11Shape21T324=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (82020872 ||| 2^24) q11Shape21T325 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^24) 82020872 q11Shape21T344)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T325OK,q11Shape21T344OK⟩

private def q11Shape21T345 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T345OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8389911 73632264 q11Shape21T345=true := by decide

private def q11Shape21T323 : Tree 11 := .split 23 q11Shape21T324 q11Shape21T345
private theorem q11Shape21T323OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 73632264 q11Shape21T323=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (73632264 ||| 2^23) q11Shape21T324 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^23) 73632264 q11Shape21T345)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T324OK,q11Shape21T345OK⟩

private def q11Shape21T346 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T346OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4195607 69437960 q11Shape21T346=true := by decide

private def q11Shape21T322 : Tree 11 := .split 22 q11Shape21T323 q11Shape21T346
private theorem q11Shape21T322OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 69437960 q11Shape21T322=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (69437960 ||| 2^22) q11Shape21T323 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^22) 69437960 q11Shape21T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T323OK,q11Shape21T346OK⟩

private def q11Shape21T347 : Tree 11 := (.tip (.cover {0,2,6,8,9,10}))
private theorem q11Shape21T347OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67110167 2329096 q11Shape21T347=true := by decide

private def q11Shape21T321 : Tree 11 := .split 26 q11Shape21T322 q11Shape21T347
private theorem q11Shape21T321OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 2329096 q11Shape21T321=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (2329096 ||| 2^26) q11Shape21T322 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^26) 2329096 q11Shape21T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T322OK,q11Shape21T347OK⟩

private def q11Shape21T348 : Tree 11 := (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {3,4,5,7,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,2,6,8,9,10})))
private theorem q11Shape21T348OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 66839 2263560 q11Shape21T348=true := by decide

private def q11Shape21T320 : Tree 11 := .split 16 q11Shape21T321 q11Shape21T348
private theorem q11Shape21T320OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 2263560 q11Shape21T320=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (2263560 ||| 2^16) q11Shape21T321 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^16) 2263560 q11Shape21T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T321OK,q11Shape21T348OK⟩

private def q11Shape21T349 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,6,7,9,10})) (.split 13 (.tip (.cover {2,4,6,7,8,10})) (.split 14 (.tip (.cover {2,4,6,7,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,3,4,7,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T349OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 34071 2230792 q11Shape21T349=true := by decide

private def q11Shape21T319 : Tree 11 := .split 15 q11Shape21T320 q11Shape21T349
private theorem q11Shape21T319OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 2230792 q11Shape21T319=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1303 (2230792 ||| 2^15) q11Shape21T320 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (1303 ||| 2^15) 2230792 q11Shape21T349)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T320OK,q11Shape21T349OK⟩

private def q11Shape21T295 : Tree 11 := .split 10 q11Shape21T296 q11Shape21T319
private theorem q11Shape21T295OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 2230792 q11Shape21T295=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 (2230792 ||| 2^10) q11Shape21T296 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (279 ||| 2^10) 2230792 q11Shape21T319)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T296OK,q11Shape21T319OK⟩

private def q11Shape21T351 : Tree 11 := (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {0,3,4,7,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {2,3,6,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T351OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 791 2231304 q11Shape21T351=true := by decide

private def q11Shape21T352 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T352OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1815 2230280 q11Shape21T352=true := by decide

private def q11Shape21T350 : Tree 11 := .split 10 q11Shape21T351 q11Shape21T352
private theorem q11Shape21T350OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 791 2230280 q11Shape21T350=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 791 (2230280 ||| 2^10) q11Shape21T351 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (791 ||| 2^10) 2230280 q11Shape21T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T351OK,q11Shape21T352OK⟩

private def q11Shape21T294 : Tree 11 := .split 9 q11Shape21T295 q11Shape21T350
private theorem q11Shape21T294OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 2230280 q11Shape21T294=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 (2230280 ||| 2^9) q11Shape21T295 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (279 ||| 2^9) 2230280 q11Shape21T350)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T295OK,q11Shape21T350OK⟩

private def q11Shape21T353 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T353OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 287 2230272 q11Shape21T353=true := by decide

private def q11Shape21T293 : Tree 11 := .split 3 q11Shape21T294 q11Shape21T353
private theorem q11Shape21T293OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 2230272 q11Shape21T293=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 279 (2230272 ||| 2^3) q11Shape21T294 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (279 ||| 2^3) 2230272 q11Shape21T353)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T294OK,q11Shape21T353OK⟩

private def q11Shape21T161 : Tree 11 := .split 2 q11Shape21T162 q11Shape21T293
private theorem q11Shape21T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 2230272 q11Shape21T161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 275 (2230272 ||| 2^2) q11Shape21T162 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (275 ||| 2^2) 2230272 q11Shape21T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T162OK,q11Shape21T293OK⟩

private def q11Shape21T159 : Tree 11 := .split 4 q11Shape21T160 q11Shape21T161
private theorem q11Shape21T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 2230272 q11Shape21T159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 (2230272 ||| 2^4) q11Shape21T160 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (259 ||| 2^4) 2230272 q11Shape21T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T160OK,q11Shape21T161OK⟩

def q11Shape21P3 : Tree 11 := q11Shape21T159
theorem q11Shape21P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 259 2230272 q11Shape21P3=true := q11Shape21T159OK

end Graffiti384b.EffectiveSearch.Q11
