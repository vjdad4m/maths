import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T359 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T359OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 2100764 q11Shape21T359=true := by decide

private def q11Shape21T361 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T361OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132355 2132508 q11Shape21T361=true := by decide

private def q11Shape21T376 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,6,9,10})) (.split 6 (.tip (.cover {0,1,4,6,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,4,6,9,10})) (.split 6 (.tip (.cover {0,1,4,6,8,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))))))
private theorem q11Shape21T376OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 8587917852 q11Shape21T376=true := by decide

private def q11Shape21T377 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,6,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))))) (.tip (.cover {0,1,3,4,8,10})))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,4,6,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10})))))
private theorem q11Shape21T377OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 173315 8587909660 q11Shape21T377=true := by decide

private def q11Shape21T375 : Tree 11 := .split 13 q11Shape21T376 q11Shape21T377
private theorem q11Shape21T375OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 8587909660 q11Shape21T375=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (8587909660 ||| 2^13) q11Shape21T376 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^13) 8587909660 q11Shape21T377)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T376OK,q11Shape21T377OK⟩

private def q11Shape21T379 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,4,6,8,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,4,6,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9})))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T379OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 169219 8587913756 q11Shape21T379=true := by decide

private def q11Shape21T380 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10}))))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T380OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 177411 8587905564 q11Shape21T380=true := by decide

private def q11Shape21T378 : Tree 11 := .split 13 q11Shape21T379 q11Shape21T380
private theorem q11Shape21T378OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 169219 8587905564 q11Shape21T378=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 169219 (8587905564 ||| 2^13) q11Shape21T379 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (169219 ||| 2^13) 8587905564 q11Shape21T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T379OK,q11Shape21T380OK⟩

private def q11Shape21T374 : Tree 11 := .split 12 q11Shape21T375 q11Shape21T378
private theorem q11Shape21T374OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 8587905564 q11Shape21T374=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (8587905564 ||| 2^12) q11Shape21T375 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^12) 8587905564 q11Shape21T378)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T375OK,q11Shape21T378OK⟩

private def q11Shape21T381 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T381OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295132419 4292938268 q11Shape21T381=true := by decide

private def q11Shape21T373 : Tree 11 := .split 32 q11Shape21T374 q11Shape21T381
private theorem q11Shape21T373OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 4292938268 q11Shape21T373=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (4292938268 ||| 2^32) q11Shape21T374 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^32) 4292938268 q11Shape21T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T374OK,q11Shape21T381OK⟩

private def q11Shape21T382 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T382OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147648771 2145454620 q11Shape21T382=true := by decide

private def q11Shape21T372 : Tree 11 := .split 31 q11Shape21T373 q11Shape21T382
private theorem q11Shape21T372OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 2145454620 q11Shape21T372=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (2145454620 ||| 2^31) q11Shape21T373 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^31) 2145454620 q11Shape21T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T373OK,q11Shape21T382OK⟩

private def q11Shape21T383 : Tree 11 := (.tip (.cover {0,3,4,8,9,10}))
private theorem q11Shape21T383OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073906947 1071712796 q11Shape21T383=true := by decide

private def q11Shape21T371 : Tree 11 := .split 30 q11Shape21T372 q11Shape21T383
private theorem q11Shape21T371OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 1071712796 q11Shape21T371=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (1071712796 ||| 2^30) q11Shape21T372 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^30) 1071712796 q11Shape21T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T372OK,q11Shape21T383OK⟩

private def q11Shape21T384 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T384OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 537036035 534841884 q11Shape21T384=true := by decide

private def q11Shape21T370 : Tree 11 := .split 29 q11Shape21T371 q11Shape21T384
private theorem q11Shape21T370OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 534841884 q11Shape21T370=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (534841884 ||| 2^29) q11Shape21T371 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^29) 534841884 q11Shape21T384)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T371OK,q11Shape21T384OK⟩

private def q11Shape21T385 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T385OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268600579 266406428 q11Shape21T385=true := by decide

private def q11Shape21T369 : Tree 11 := .split 28 q11Shape21T370 q11Shape21T385
private theorem q11Shape21T369OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 266406428 q11Shape21T369=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (266406428 ||| 2^28) q11Shape21T370 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^28) 266406428 q11Shape21T385)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T370OK,q11Shape21T385OK⟩

private def q11Shape21T386 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T386OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134382851 132188700 q11Shape21T386=true := by decide

private def q11Shape21T368 : Tree 11 := .split 27 q11Shape21T369 q11Shape21T386
private theorem q11Shape21T368OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 132188700 q11Shape21T368=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (132188700 ||| 2^27) q11Shape21T369 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^27) 132188700 q11Shape21T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T369OK,q11Shape21T386OK⟩

private def q11Shape21T387 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T387OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33719555 98634268 q11Shape21T387=true := by decide

private def q11Shape21T367 : Tree 11 := .split 25 q11Shape21T368 q11Shape21T387
private theorem q11Shape21T367OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 98634268 q11Shape21T367=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (98634268 ||| 2^25) q11Shape21T368 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^25) 98634268 q11Shape21T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T368OK,q11Shape21T387OK⟩

private def q11Shape21T388 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T388OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16942339 81857052 q11Shape21T388=true := by decide

private def q11Shape21T366 : Tree 11 := .split 24 q11Shape21T367 q11Shape21T388
private theorem q11Shape21T366OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 81857052 q11Shape21T366=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (81857052 ||| 2^24) q11Shape21T367 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^24) 81857052 q11Shape21T388)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T367OK,q11Shape21T388OK⟩

private def q11Shape21T389 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T389OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8553731 73468444 q11Shape21T389=true := by decide

private def q11Shape21T365 : Tree 11 := .split 23 q11Shape21T366 q11Shape21T389
private theorem q11Shape21T365OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 73468444 q11Shape21T365=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (73468444 ||| 2^23) q11Shape21T366 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^23) 73468444 q11Shape21T389)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T366OK,q11Shape21T389OK⟩

private def q11Shape21T390 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T390OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4359427 69274140 q11Shape21T390=true := by decide

private def q11Shape21T364 : Tree 11 := .split 22 q11Shape21T365 q11Shape21T390
private theorem q11Shape21T364OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 69274140 q11Shape21T364=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (69274140 ||| 2^22) q11Shape21T365 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^22) 69274140 q11Shape21T390)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T365OK,q11Shape21T390OK⟩

private def q11Shape21T391 : Tree 11 := (.tip (.cover {0,4,6,8,9,10}))
private theorem q11Shape21T391OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67273987 2165276 q11Shape21T391=true := by decide

private def q11Shape21T363 : Tree 11 := .split 26 q11Shape21T364 q11Shape21T391
private theorem q11Shape21T363OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 2165276 q11Shape21T363=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (2165276 ||| 2^26) q11Shape21T364 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^26) 2165276 q11Shape21T391)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T364OK,q11Shape21T391OK⟩

private def q11Shape21T392 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T392OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 230659 2099740 q11Shape21T392=true := by decide

private def q11Shape21T362 : Tree 11 := .split 16 q11Shape21T363 q11Shape21T392
private theorem q11Shape21T362OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 2099740 q11Shape21T362=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165123 (2099740 ||| 2^16) q11Shape21T363 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (165123 ||| 2^16) 2099740 q11Shape21T392)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T363OK,q11Shape21T392OK⟩

private def q11Shape21T360 : Tree 11 := .split 15 q11Shape21T361 q11Shape21T362
private theorem q11Shape21T360OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132355 2099740 q11Shape21T360=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132355 (2099740 ||| 2^15) q11Shape21T361 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132355 ||| 2^15) 2099740 q11Shape21T362)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T361OK,q11Shape21T362OK⟩

private def q11Shape21T358 : Tree 11 := .split 10 q11Shape21T359 q11Shape21T360
private theorem q11Shape21T358OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 2099740 q11Shape21T358=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 (2099740 ||| 2^10) q11Shape21T359 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131331 ||| 2^10) 2099740 q11Shape21T360)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T359OK,q11Shape21T360OK⟩

private def q11Shape21T396 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T396OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131843 2198556 q11Shape21T396=true := by decide

private def q11Shape21T410 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.split 6 (.tip (.cover {0,1,4,5,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.split 6 (.tip (.cover {0,1,4,5,8,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))))))
private theorem q11Shape21T410OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 8587885596 q11Shape21T410=true := by decide

private def q11Shape21T411 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))))) (.tip (.cover {0,1,3,4,8,10})))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10})))))
private theorem q11Shape21T411OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 205571 8587877404 q11Shape21T411=true := by decide

private def q11Shape21T409 : Tree 11 := .split 13 q11Shape21T410 q11Shape21T411
private theorem q11Shape21T409OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 8587877404 q11Shape21T409=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (8587877404 ||| 2^13) q11Shape21T410 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^13) 8587877404 q11Shape21T411)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T410OK,q11Shape21T411OK⟩

private def q11Shape21T413 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,4,5,8,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,4,5,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9})))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T413OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 201475 8587881500 q11Shape21T413=true := by decide

private def q11Shape21T414 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10}))))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T414OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 209667 8587873308 q11Shape21T414=true := by decide

private def q11Shape21T412 : Tree 11 := .split 13 q11Shape21T413 q11Shape21T414
private theorem q11Shape21T412OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 201475 8587873308 q11Shape21T412=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 201475 (8587873308 ||| 2^13) q11Shape21T413 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (201475 ||| 2^13) 8587873308 q11Shape21T414)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T413OK,q11Shape21T414OK⟩

private def q11Shape21T408 : Tree 11 := .split 12 q11Shape21T409 q11Shape21T412
private theorem q11Shape21T408OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 8587873308 q11Shape21T408=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (8587873308 ||| 2^12) q11Shape21T409 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^12) 8587873308 q11Shape21T412)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T409OK,q11Shape21T412OK⟩

private def q11Shape21T415 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T415OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295164675 4292906012 q11Shape21T415=true := by decide

private def q11Shape21T407 : Tree 11 := .split 32 q11Shape21T408 q11Shape21T415
private theorem q11Shape21T407OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 4292906012 q11Shape21T407=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (4292906012 ||| 2^32) q11Shape21T408 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^32) 4292906012 q11Shape21T415)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T408OK,q11Shape21T415OK⟩

private def q11Shape21T416 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T416OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147681027 2145422364 q11Shape21T416=true := by decide

private def q11Shape21T406 : Tree 11 := .split 31 q11Shape21T407 q11Shape21T416
private theorem q11Shape21T406OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 2145422364 q11Shape21T406=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (2145422364 ||| 2^31) q11Shape21T407 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^31) 2145422364 q11Shape21T416)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T407OK,q11Shape21T416OK⟩

private def q11Shape21T417 : Tree 11 := (.tip (.cover {0,3,4,8,9,10}))
private theorem q11Shape21T417OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073939203 1071680540 q11Shape21T417=true := by decide

private def q11Shape21T405 : Tree 11 := .split 30 q11Shape21T406 q11Shape21T417
private theorem q11Shape21T405OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 1071680540 q11Shape21T405=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (1071680540 ||| 2^30) q11Shape21T406 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^30) 1071680540 q11Shape21T417)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T406OK,q11Shape21T417OK⟩

private def q11Shape21T418 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T418OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 537068291 534809628 q11Shape21T418=true := by decide

private def q11Shape21T404 : Tree 11 := .split 29 q11Shape21T405 q11Shape21T418
private theorem q11Shape21T404OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 534809628 q11Shape21T404=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (534809628 ||| 2^29) q11Shape21T405 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^29) 534809628 q11Shape21T418)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T405OK,q11Shape21T418OK⟩

private def q11Shape21T419 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T419OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268632835 266374172 q11Shape21T419=true := by decide

private def q11Shape21T403 : Tree 11 := .split 28 q11Shape21T404 q11Shape21T419
private theorem q11Shape21T403OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 266374172 q11Shape21T403=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (266374172 ||| 2^28) q11Shape21T404 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^28) 266374172 q11Shape21T419)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T404OK,q11Shape21T419OK⟩

private def q11Shape21T420 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T420OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134415107 132156444 q11Shape21T420=true := by decide

private def q11Shape21T402 : Tree 11 := .split 27 q11Shape21T403 q11Shape21T420
private theorem q11Shape21T402OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 132156444 q11Shape21T402=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (132156444 ||| 2^27) q11Shape21T403 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^27) 132156444 q11Shape21T420)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T403OK,q11Shape21T420OK⟩

private def q11Shape21T421 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T421OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33751811 98602012 q11Shape21T421=true := by decide

private def q11Shape21T401 : Tree 11 := .split 25 q11Shape21T402 q11Shape21T421
private theorem q11Shape21T401OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 98602012 q11Shape21T401=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (98602012 ||| 2^25) q11Shape21T402 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^25) 98602012 q11Shape21T421)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T402OK,q11Shape21T421OK⟩

private def q11Shape21T422 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T422OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16974595 81824796 q11Shape21T422=true := by decide

private def q11Shape21T400 : Tree 11 := .split 24 q11Shape21T401 q11Shape21T422
private theorem q11Shape21T400OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 81824796 q11Shape21T400=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (81824796 ||| 2^24) q11Shape21T401 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^24) 81824796 q11Shape21T422)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T401OK,q11Shape21T422OK⟩

private def q11Shape21T423 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T423OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8585987 73436188 q11Shape21T423=true := by decide

private def q11Shape21T399 : Tree 11 := .split 23 q11Shape21T400 q11Shape21T423
private theorem q11Shape21T399OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 73436188 q11Shape21T399=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (73436188 ||| 2^23) q11Shape21T400 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^23) 73436188 q11Shape21T423)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T400OK,q11Shape21T423OK⟩

private def q11Shape21T424 : Tree 11 := (.tip (.cover {0,4,5,8,9,10}))
private theorem q11Shape21T424OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4391683 69241884 q11Shape21T424=true := by decide

private def q11Shape21T398 : Tree 11 := .split 22 q11Shape21T399 q11Shape21T424
private theorem q11Shape21T398OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 69241884 q11Shape21T398=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (69241884 ||| 2^22) q11Shape21T399 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^22) 69241884 q11Shape21T424)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T399OK,q11Shape21T424OK⟩

private def q11Shape21T425 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T425OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67306243 2133020 q11Shape21T425=true := by decide

private def q11Shape21T397 : Tree 11 := .split 26 q11Shape21T398 q11Shape21T425
private theorem q11Shape21T397OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 2133020 q11Shape21T397=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197379 (2133020 ||| 2^26) q11Shape21T398 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (197379 ||| 2^26) 2133020 q11Shape21T425)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T398OK,q11Shape21T425OK⟩

private def q11Shape21T395 : Tree 11 := .split 16 q11Shape21T396 q11Shape21T397
private theorem q11Shape21T395OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131843 2133020 q11Shape21T395=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131843 (2133020 ||| 2^16) q11Shape21T396 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131843 ||| 2^16) 2133020 q11Shape21T397)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T396OK,q11Shape21T397OK⟩

private def q11Shape21T426 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T426OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164611 2100252 q11Shape21T426=true := by decide

private def q11Shape21T394 : Tree 11 := .split 15 q11Shape21T395 q11Shape21T426
private theorem q11Shape21T394OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131843 2100252 q11Shape21T394=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131843 (2100252 ||| 2^15) q11Shape21T395 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131843 ||| 2^15) 2100252 q11Shape21T426)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T395OK,q11Shape21T426OK⟩

private def q11Shape21T427 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T427OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132867 2099228 q11Shape21T427=true := by decide

private def q11Shape21T393 : Tree 11 := .split 10 q11Shape21T394 q11Shape21T427
private theorem q11Shape21T393OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131843 2099228 q11Shape21T393=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131843 (2099228 ||| 2^10) q11Shape21T394 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131843 ||| 2^10) 2099228 q11Shape21T427)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T394OK,q11Shape21T427OK⟩

private def q11Shape21T357 : Tree 11 := .split 9 q11Shape21T358 q11Shape21T393
private theorem q11Shape21T357OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 2099228 q11Shape21T357=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 (2099228 ||| 2^9) q11Shape21T358 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131331 ||| 2^9) 2099228 q11Shape21T393)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T358OK,q11Shape21T393OK⟩

private def q11Shape21T431 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T431OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131339 2133524 q11Shape21T431=true := by decide

private def q11Shape21T442 : Tree 11 := (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10})))
private theorem q11Shape21T442OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 2145455636 q11Shape21T442=true := by decide

private def q11Shape21T443 : Tree 11 := (.tip (.cover {0,2,4,8,9,10}))
private theorem q11Shape21T443OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073905931 1071713812 q11Shape21T443=true := by decide

private def q11Shape21T441 : Tree 11 := .split 30 q11Shape21T442 q11Shape21T443
private theorem q11Shape21T441OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 1071713812 q11Shape21T441=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (1071713812 ||| 2^30) q11Shape21T442 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^30) 1071713812 q11Shape21T443)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T442OK,q11Shape21T443OK⟩

private def q11Shape21T444 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T444OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 537035019 534842900 q11Shape21T444=true := by decide

private def q11Shape21T440 : Tree 11 := .split 29 q11Shape21T441 q11Shape21T444
private theorem q11Shape21T440OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 534842900 q11Shape21T440=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (534842900 ||| 2^29) q11Shape21T441 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^29) 534842900 q11Shape21T444)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T441OK,q11Shape21T444OK⟩

private def q11Shape21T445 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T445OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268599563 266407444 q11Shape21T445=true := by decide

private def q11Shape21T439 : Tree 11 := .split 28 q11Shape21T440 q11Shape21T445
private theorem q11Shape21T439OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 266407444 q11Shape21T439=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (266407444 ||| 2^28) q11Shape21T440 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^28) 266407444 q11Shape21T445)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T440OK,q11Shape21T445OK⟩

private def q11Shape21T446 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T446OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134381835 132189716 q11Shape21T446=true := by decide

private def q11Shape21T438 : Tree 11 := .split 27 q11Shape21T439 q11Shape21T446
private theorem q11Shape21T438OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 132189716 q11Shape21T438=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (132189716 ||| 2^27) q11Shape21T439 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^27) 132189716 q11Shape21T446)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T439OK,q11Shape21T446OK⟩

private def q11Shape21T447 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T447OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33718539 98635284 q11Shape21T447=true := by decide

private def q11Shape21T437 : Tree 11 := .split 25 q11Shape21T438 q11Shape21T447
private theorem q11Shape21T437OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 98635284 q11Shape21T437=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (98635284 ||| 2^25) q11Shape21T438 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^25) 98635284 q11Shape21T447)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T438OK,q11Shape21T447OK⟩

private def q11Shape21T448 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T448OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16941323 81858068 q11Shape21T448=true := by decide

private def q11Shape21T436 : Tree 11 := .split 24 q11Shape21T437 q11Shape21T448
private theorem q11Shape21T436OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 81858068 q11Shape21T436=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (81858068 ||| 2^24) q11Shape21T437 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^24) 81858068 q11Shape21T448)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T437OK,q11Shape21T448OK⟩

private def q11Shape21T449 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T449OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8552715 73469460 q11Shape21T449=true := by decide

private def q11Shape21T435 : Tree 11 := .split 23 q11Shape21T436 q11Shape21T449
private theorem q11Shape21T435OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 73469460 q11Shape21T435=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (73469460 ||| 2^23) q11Shape21T436 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^23) 73469460 q11Shape21T449)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T436OK,q11Shape21T449OK⟩

private def q11Shape21T450 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T450OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4358411 69275156 q11Shape21T450=true := by decide

private def q11Shape21T434 : Tree 11 := .split 22 q11Shape21T435 q11Shape21T450
private theorem q11Shape21T434OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 69275156 q11Shape21T434=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (69275156 ||| 2^22) q11Shape21T435 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^22) 69275156 q11Shape21T450)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T435OK,q11Shape21T450OK⟩

private def q11Shape21T451 : Tree 11 := (.tip (.cover {0,4,6,8,9,10}))
private theorem q11Shape21T451OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67272971 2166292 q11Shape21T451=true := by decide

private def q11Shape21T433 : Tree 11 := .split 26 q11Shape21T434 q11Shape21T451
private theorem q11Shape21T433OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 2166292 q11Shape21T433=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (2166292 ||| 2^26) q11Shape21T434 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^26) 2166292 q11Shape21T451)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T434OK,q11Shape21T451OK⟩

private def q11Shape21T452 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T452OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 229643 2100756 q11Shape21T452=true := by decide

private def q11Shape21T432 : Tree 11 := .split 16 q11Shape21T433 q11Shape21T452
private theorem q11Shape21T432OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 2100756 q11Shape21T432=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164107 (2100756 ||| 2^16) q11Shape21T433 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (164107 ||| 2^16) 2100756 q11Shape21T452)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T433OK,q11Shape21T452OK⟩

private def q11Shape21T430 : Tree 11 := .split 15 q11Shape21T431 q11Shape21T432
private theorem q11Shape21T430OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131339 2100756 q11Shape21T430=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131339 (2100756 ||| 2^15) q11Shape21T431 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131339 ||| 2^15) 2100756 q11Shape21T432)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T431OK,q11Shape21T432OK⟩

private def q11Shape21T453 : Tree 11 := (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))))
private theorem q11Shape21T453OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132363 2099732 q11Shape21T453=true := by decide

private def q11Shape21T429 : Tree 11 := .split 10 q11Shape21T430 q11Shape21T453
private theorem q11Shape21T429OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131339 2099732 q11Shape21T429=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131339 (2099732 ||| 2^10) q11Shape21T430 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131339 ||| 2^10) 2099732 q11Shape21T453)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T430OK,q11Shape21T453OK⟩

private def q11Shape21T470 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))))))
private theorem q11Shape21T470OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 8587951124 q11Shape21T470=true := by decide

private def q11Shape21T471 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T471OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 140043 8587942932 q11Shape21T471=true := by decide

private def q11Shape21T469 : Tree 11 := .split 13 q11Shape21T470 q11Shape21T471
private theorem q11Shape21T469OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 8587942932 q11Shape21T469=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (8587942932 ||| 2^13) q11Shape21T470 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^13) 8587942932 q11Shape21T471)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T470OK,q11Shape21T471OK⟩

private def q11Shape21T472 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,3,7,9,10})))))) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {3,4,5,6,7,9})))))) (.split 14 (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.tip (.cover {3,4,5,6,7,10})))) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape21T472OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 135947 8587938836 q11Shape21T472=true := by decide

private def q11Shape21T468 : Tree 11 := .split 12 q11Shape21T469 q11Shape21T472
private theorem q11Shape21T468OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 8587938836 q11Shape21T468=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (8587938836 ||| 2^12) q11Shape21T469 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^12) 8587938836 q11Shape21T472)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T469OK,q11Shape21T472OK⟩

private def q11Shape21T473 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T473OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295099147 4292971540 q11Shape21T473=true := by decide

private def q11Shape21T467 : Tree 11 := .split 32 q11Shape21T468 q11Shape21T473
private theorem q11Shape21T467OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 4292971540 q11Shape21T467=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (4292971540 ||| 2^32) q11Shape21T468 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^32) 4292971540 q11Shape21T473)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T468OK,q11Shape21T473OK⟩

private def q11Shape21T474 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T474OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147615499 2145487892 q11Shape21T474=true := by decide

private def q11Shape21T466 : Tree 11 := .split 31 q11Shape21T467 q11Shape21T474
private theorem q11Shape21T466OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 2145487892 q11Shape21T466=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (2145487892 ||| 2^31) q11Shape21T467 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^31) 2145487892 q11Shape21T474)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T467OK,q11Shape21T474OK⟩

private def q11Shape21T475 : Tree 11 := (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape21T475OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073873675 1071746068 q11Shape21T475=true := by decide

private def q11Shape21T465 : Tree 11 := .split 30 q11Shape21T466 q11Shape21T475
private theorem q11Shape21T465OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 1071746068 q11Shape21T465=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (1071746068 ||| 2^30) q11Shape21T466 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^30) 1071746068 q11Shape21T475)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T466OK,q11Shape21T475OK⟩

private def q11Shape21T476 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T476OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 537002763 534875156 q11Shape21T476=true := by decide

private def q11Shape21T464 : Tree 11 := .split 29 q11Shape21T465 q11Shape21T476
private theorem q11Shape21T464OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 534875156 q11Shape21T464=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (534875156 ||| 2^29) q11Shape21T465 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^29) 534875156 q11Shape21T476)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T465OK,q11Shape21T476OK⟩

private def q11Shape21T477 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T477OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268567307 266439700 q11Shape21T477=true := by decide

private def q11Shape21T463 : Tree 11 := .split 28 q11Shape21T464 q11Shape21T477
private theorem q11Shape21T463OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 266439700 q11Shape21T463=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (266439700 ||| 2^28) q11Shape21T464 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^28) 266439700 q11Shape21T477)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T464OK,q11Shape21T477OK⟩

private def q11Shape21T478 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T478OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134349579 132221972 q11Shape21T478=true := by decide

private def q11Shape21T462 : Tree 11 := .split 27 q11Shape21T463 q11Shape21T478
private theorem q11Shape21T462OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 132221972 q11Shape21T462=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (132221972 ||| 2^27) q11Shape21T463 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^27) 132221972 q11Shape21T478)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T463OK,q11Shape21T478OK⟩

private def q11Shape21T479 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T479OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33686283 98667540 q11Shape21T479=true := by decide

private def q11Shape21T461 : Tree 11 := .split 25 q11Shape21T462 q11Shape21T479
private theorem q11Shape21T461OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 98667540 q11Shape21T461=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (98667540 ||| 2^25) q11Shape21T462 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^25) 98667540 q11Shape21T479)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T462OK,q11Shape21T479OK⟩

private def q11Shape21T480 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T480OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16909067 81890324 q11Shape21T480=true := by decide

private def q11Shape21T460 : Tree 11 := .split 24 q11Shape21T461 q11Shape21T480
private theorem q11Shape21T460OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 81890324 q11Shape21T460=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (81890324 ||| 2^24) q11Shape21T461 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^24) 81890324 q11Shape21T480)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T461OK,q11Shape21T480OK⟩

private def q11Shape21T481 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T481OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8520459 73501716 q11Shape21T481=true := by decide

private def q11Shape21T459 : Tree 11 := .split 23 q11Shape21T460 q11Shape21T481
private theorem q11Shape21T459OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 73501716 q11Shape21T459=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (73501716 ||| 2^23) q11Shape21T460 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^23) 73501716 q11Shape21T481)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T460OK,q11Shape21T481OK⟩

private def q11Shape21T482 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T482OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4326155 69307412 q11Shape21T482=true := by decide

private def q11Shape21T458 : Tree 11 := .split 22 q11Shape21T459 q11Shape21T482
private theorem q11Shape21T458OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 69307412 q11Shape21T458=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (69307412 ||| 2^22) q11Shape21T459 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^22) 69307412 q11Shape21T482)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T459OK,q11Shape21T482OK⟩

private def q11Shape21T483 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T483OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67240715 2198548 q11Shape21T483=true := by decide

private def q11Shape21T457 : Tree 11 := .split 26 q11Shape21T458 q11Shape21T483
private theorem q11Shape21T457OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 2198548 q11Shape21T457=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (2198548 ||| 2^26) q11Shape21T458 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^26) 2198548 q11Shape21T483)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T458OK,q11Shape21T483OK⟩

private def q11Shape21T484 : Tree 11 := (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,7,9,10})) (.split 13 (.tip (.cover {2,4,5,7,8,10})) (.split 14 (.tip (.cover {2,4,5,7,8,9})) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10})))
private theorem q11Shape21T484OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197387 2133012 q11Shape21T484=true := by decide

private def q11Shape21T456 : Tree 11 := .split 16 q11Shape21T457 q11Shape21T484
private theorem q11Shape21T456OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 2133012 q11Shape21T456=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (2133012 ||| 2^16) q11Shape21T457 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^16) 2133012 q11Shape21T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T457OK,q11Shape21T484OK⟩

private def q11Shape21T485 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.tip (.cover {3,4,6,7,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape21T485OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164619 2100244 q11Shape21T485=true := by decide

private def q11Shape21T455 : Tree 11 := .split 15 q11Shape21T456 q11Shape21T485
private theorem q11Shape21T455OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 2100244 q11Shape21T455=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (2100244 ||| 2^15) q11Shape21T456 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^15) 2100244 q11Shape21T485)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T456OK,q11Shape21T485OK⟩

private def q11Shape21T486 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T486OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132875 2099220 q11Shape21T486=true := by decide

private def q11Shape21T454 : Tree 11 := .split 10 q11Shape21T455 q11Shape21T486
private theorem q11Shape21T454OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 2099220 q11Shape21T454=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131851 (2099220 ||| 2^10) q11Shape21T455 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131851 ||| 2^10) 2099220 q11Shape21T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T455OK,q11Shape21T486OK⟩

private def q11Shape21T428 : Tree 11 := .split 9 q11Shape21T429 q11Shape21T454
private theorem q11Shape21T428OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131339 2099220 q11Shape21T428=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131339 (2099220 ||| 2^9) q11Shape21T429 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131339 ||| 2^9) 2099220 q11Shape21T454)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T429OK,q11Shape21T454OK⟩

private def q11Shape21T356 : Tree 11 := .split 3 q11Shape21T357 q11Shape21T428
private theorem q11Shape21T356OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 2099220 q11Shape21T356=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 (2099220 ||| 2^3) q11Shape21T357 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131331 ||| 2^3) 2099220 q11Shape21T428)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T357OK,q11Shape21T428OK⟩

private def q11Shape21T492 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T492OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 2199064 q11Shape21T492=true := by decide

private def q11Shape21T502 : Tree 11 := (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,4,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10})))
private theorem q11Shape21T502OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 2145422872 q11Shape21T502=true := by decide

private def q11Shape21T503 : Tree 11 := (.tip (.cover {0,2,4,8,9,10}))
private theorem q11Shape21T503OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073938695 1071681048 q11Shape21T503=true := by decide

private def q11Shape21T501 : Tree 11 := .split 30 q11Shape21T502 q11Shape21T503
private theorem q11Shape21T501OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 1071681048 q11Shape21T501=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (1071681048 ||| 2^30) q11Shape21T502 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^30) 1071681048 q11Shape21T503)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T502OK,q11Shape21T503OK⟩

private def q11Shape21T504 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T504OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 537067783 534810136 q11Shape21T504=true := by decide

private def q11Shape21T500 : Tree 11 := .split 29 q11Shape21T501 q11Shape21T504
private theorem q11Shape21T500OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 534810136 q11Shape21T500=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (534810136 ||| 2^29) q11Shape21T501 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^29) 534810136 q11Shape21T504)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T501OK,q11Shape21T504OK⟩

private def q11Shape21T505 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T505OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268632327 266374680 q11Shape21T505=true := by decide

private def q11Shape21T499 : Tree 11 := .split 28 q11Shape21T500 q11Shape21T505
private theorem q11Shape21T499OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 266374680 q11Shape21T499=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (266374680 ||| 2^28) q11Shape21T500 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^28) 266374680 q11Shape21T505)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T500OK,q11Shape21T505OK⟩

private def q11Shape21T506 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T506OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134414599 132156952 q11Shape21T506=true := by decide

private def q11Shape21T498 : Tree 11 := .split 27 q11Shape21T499 q11Shape21T506
private theorem q11Shape21T498OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 132156952 q11Shape21T498=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (132156952 ||| 2^27) q11Shape21T499 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^27) 132156952 q11Shape21T506)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T499OK,q11Shape21T506OK⟩

private def q11Shape21T507 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T507OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33751303 98602520 q11Shape21T507=true := by decide

private def q11Shape21T497 : Tree 11 := .split 25 q11Shape21T498 q11Shape21T507
private theorem q11Shape21T497OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 98602520 q11Shape21T497=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (98602520 ||| 2^25) q11Shape21T498 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^25) 98602520 q11Shape21T507)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T498OK,q11Shape21T507OK⟩

private def q11Shape21T508 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T508OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16974087 81825304 q11Shape21T508=true := by decide

private def q11Shape21T496 : Tree 11 := .split 24 q11Shape21T497 q11Shape21T508
private theorem q11Shape21T496OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 81825304 q11Shape21T496=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (81825304 ||| 2^24) q11Shape21T497 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^24) 81825304 q11Shape21T508)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T497OK,q11Shape21T508OK⟩

private def q11Shape21T509 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape21T509OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8585479 73436696 q11Shape21T509=true := by decide

private def q11Shape21T495 : Tree 11 := .split 23 q11Shape21T496 q11Shape21T509
private theorem q11Shape21T495OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 73436696 q11Shape21T495=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (73436696 ||| 2^23) q11Shape21T496 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^23) 73436696 q11Shape21T509)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T496OK,q11Shape21T509OK⟩

private def q11Shape21T510 : Tree 11 := (.tip (.cover {0,4,5,8,9,10}))
private theorem q11Shape21T510OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4391175 69242392 q11Shape21T510=true := by decide

private def q11Shape21T494 : Tree 11 := .split 22 q11Shape21T495 q11Shape21T510
private theorem q11Shape21T494OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 69242392 q11Shape21T494=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (69242392 ||| 2^22) q11Shape21T495 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^22) 69242392 q11Shape21T510)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T495OK,q11Shape21T510OK⟩

private def q11Shape21T511 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T511OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67305735 2133528 q11Shape21T511=true := by decide

private def q11Shape21T493 : Tree 11 := .split 26 q11Shape21T494 q11Shape21T511
private theorem q11Shape21T493OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 2133528 q11Shape21T493=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 196871 (2133528 ||| 2^26) q11Shape21T494 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (196871 ||| 2^26) 2133528 q11Shape21T511)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T494OK,q11Shape21T511OK⟩

private def q11Shape21T491 : Tree 11 := .split 16 q11Shape21T492 q11Shape21T493
private theorem q11Shape21T491OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 2133528 q11Shape21T491=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 (2133528 ||| 2^16) q11Shape21T492 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131335 ||| 2^16) 2133528 q11Shape21T493)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T492OK,q11Shape21T493OK⟩

private def q11Shape21T512 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T512OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 164103 2100760 q11Shape21T512=true := by decide

private def q11Shape21T490 : Tree 11 := .split 15 q11Shape21T491 q11Shape21T512
private theorem q11Shape21T490OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 2100760 q11Shape21T490=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 (2100760 ||| 2^15) q11Shape21T491 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131335 ||| 2^15) 2100760 q11Shape21T512)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T491OK,q11Shape21T512OK⟩

private def q11Shape21T528 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))))))
private theorem q11Shape21T528OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 8587950616 q11Shape21T528=true := by decide

private def q11Shape21T529 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T529OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 140551 8587942424 q11Shape21T529=true := by decide

private def q11Shape21T527 : Tree 11 := .split 13 q11Shape21T528 q11Shape21T529
private theorem q11Shape21T527OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 8587942424 q11Shape21T527=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (8587942424 ||| 2^13) q11Shape21T528 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^13) 8587942424 q11Shape21T529)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T528OK,q11Shape21T529OK⟩

private def q11Shape21T530 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,3,7,9,10})))))) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {3,4,5,6,7,9})))))) (.split 14 (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.tip (.cover {3,4,5,6,7,10})))) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.split 19 (.tip (.cover {0,2,3,7,8,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape21T530OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136455 8587938328 q11Shape21T530=true := by decide

private def q11Shape21T526 : Tree 11 := .split 12 q11Shape21T527 q11Shape21T530
private theorem q11Shape21T526OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 8587938328 q11Shape21T526=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (8587938328 ||| 2^12) q11Shape21T527 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^12) 8587938328 q11Shape21T530)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T527OK,q11Shape21T530OK⟩

private def q11Shape21T531 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T531OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295099655 4292971032 q11Shape21T531=true := by decide

private def q11Shape21T525 : Tree 11 := .split 32 q11Shape21T526 q11Shape21T531
private theorem q11Shape21T525OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 4292971032 q11Shape21T525=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (4292971032 ||| 2^32) q11Shape21T526 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^32) 4292971032 q11Shape21T531)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T526OK,q11Shape21T531OK⟩

private def q11Shape21T532 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T532OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147616007 2145487384 q11Shape21T532=true := by decide

private def q11Shape21T524 : Tree 11 := .split 31 q11Shape21T525 q11Shape21T532
private theorem q11Shape21T524OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 2145487384 q11Shape21T524=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (2145487384 ||| 2^31) q11Shape21T525 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^31) 2145487384 q11Shape21T532)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T525OK,q11Shape21T532OK⟩

private def q11Shape21T533 : Tree 11 := (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape21T533OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073874183 1071745560 q11Shape21T533=true := by decide

private def q11Shape21T523 : Tree 11 := .split 30 q11Shape21T524 q11Shape21T533
private theorem q11Shape21T523OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 1071745560 q11Shape21T523=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (1071745560 ||| 2^30) q11Shape21T524 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^30) 1071745560 q11Shape21T533)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T524OK,q11Shape21T533OK⟩

private def q11Shape21T534 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T534OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 537003271 534874648 q11Shape21T534=true := by decide

private def q11Shape21T522 : Tree 11 := .split 29 q11Shape21T523 q11Shape21T534
private theorem q11Shape21T522OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 534874648 q11Shape21T522=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (534874648 ||| 2^29) q11Shape21T523 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^29) 534874648 q11Shape21T534)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T523OK,q11Shape21T534OK⟩

private def q11Shape21T535 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T535OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268567815 266439192 q11Shape21T535=true := by decide

private def q11Shape21T521 : Tree 11 := .split 28 q11Shape21T522 q11Shape21T535
private theorem q11Shape21T521OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 266439192 q11Shape21T521=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (266439192 ||| 2^28) q11Shape21T522 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^28) 266439192 q11Shape21T535)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T522OK,q11Shape21T535OK⟩

private def q11Shape21T536 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T536OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134350087 132221464 q11Shape21T536=true := by decide

private def q11Shape21T520 : Tree 11 := .split 27 q11Shape21T521 q11Shape21T536
private theorem q11Shape21T520OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 132221464 q11Shape21T520=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (132221464 ||| 2^27) q11Shape21T521 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^27) 132221464 q11Shape21T536)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T521OK,q11Shape21T536OK⟩

private def q11Shape21T537 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T537OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33686791 98667032 q11Shape21T537=true := by decide

private def q11Shape21T519 : Tree 11 := .split 25 q11Shape21T520 q11Shape21T537
private theorem q11Shape21T519OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 98667032 q11Shape21T519=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (98667032 ||| 2^25) q11Shape21T520 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^25) 98667032 q11Shape21T537)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T520OK,q11Shape21T537OK⟩

private def q11Shape21T538 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T538OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16909575 81889816 q11Shape21T538=true := by decide

private def q11Shape21T518 : Tree 11 := .split 24 q11Shape21T519 q11Shape21T538
private theorem q11Shape21T518OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 81889816 q11Shape21T518=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (81889816 ||| 2^24) q11Shape21T519 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^24) 81889816 q11Shape21T538)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T519OK,q11Shape21T538OK⟩

private def q11Shape21T539 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T539OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8520967 73501208 q11Shape21T539=true := by decide

private def q11Shape21T517 : Tree 11 := .split 23 q11Shape21T518 q11Shape21T539
private theorem q11Shape21T517OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 73501208 q11Shape21T517=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (73501208 ||| 2^23) q11Shape21T518 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^23) 73501208 q11Shape21T539)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T518OK,q11Shape21T539OK⟩

private def q11Shape21T540 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T540OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4326663 69306904 q11Shape21T540=true := by decide

private def q11Shape21T516 : Tree 11 := .split 22 q11Shape21T517 q11Shape21T540
private theorem q11Shape21T516OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 69306904 q11Shape21T516=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (69306904 ||| 2^22) q11Shape21T517 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^22) 69306904 q11Shape21T540)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T517OK,q11Shape21T540OK⟩

private def q11Shape21T541 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T541OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67241223 2198040 q11Shape21T541=true := by decide

private def q11Shape21T515 : Tree 11 := .split 26 q11Shape21T516 q11Shape21T541
private theorem q11Shape21T515OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 2198040 q11Shape21T515=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (2198040 ||| 2^26) q11Shape21T516 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^26) 2198040 q11Shape21T541)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T516OK,q11Shape21T541OK⟩

private def q11Shape21T542 : Tree 11 := (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.tip (.cover {3,4,5,7,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10})))
private theorem q11Shape21T542OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 197895 2132504 q11Shape21T542=true := by decide

private def q11Shape21T514 : Tree 11 := .split 16 q11Shape21T515 q11Shape21T542
private theorem q11Shape21T514OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 2132504 q11Shape21T514=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (2132504 ||| 2^16) q11Shape21T515 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^16) 2132504 q11Shape21T542)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T515OK,q11Shape21T542OK⟩

private def q11Shape21T543 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,6,7,9,10})) (.split 13 (.tip (.cover {2,4,6,7,8,10})) (.split 14 (.tip (.cover {2,4,6,7,8,9})) (.split 18 (.tip (.cover {0,2,3,7,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape21T543OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 165127 2099736 q11Shape21T543=true := by decide

private def q11Shape21T513 : Tree 11 := .split 15 q11Shape21T514 q11Shape21T543
private theorem q11Shape21T513OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 2099736 q11Shape21T513=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132359 (2099736 ||| 2^15) q11Shape21T514 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (132359 ||| 2^15) 2099736 q11Shape21T543)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T514OK,q11Shape21T543OK⟩

private def q11Shape21T489 : Tree 11 := .split 10 q11Shape21T490 q11Shape21T513
private theorem q11Shape21T489OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 2099736 q11Shape21T489=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 (2099736 ||| 2^10) q11Shape21T490 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131335 ||| 2^10) 2099736 q11Shape21T513)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T490OK,q11Shape21T513OK⟩

private def q11Shape21T545 : Tree 11 := (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 14 (.tip (.cover {0,1,2,4,8,9})) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,7,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,4,5,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T545OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131847 2100248 q11Shape21T545=true := by decide

private def q11Shape21T546 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T546OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 132871 2099224 q11Shape21T546=true := by decide

private def q11Shape21T544 : Tree 11 := .split 10 q11Shape21T545 q11Shape21T546
private theorem q11Shape21T544OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131847 2099224 q11Shape21T544=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131847 (2099224 ||| 2^10) q11Shape21T545 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131847 ||| 2^10) 2099224 q11Shape21T546)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T545OK,q11Shape21T546OK⟩

private def q11Shape21T488 : Tree 11 := .split 9 q11Shape21T489 q11Shape21T544
private theorem q11Shape21T488OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 2099224 q11Shape21T488=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 (2099224 ||| 2^9) q11Shape21T489 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131335 ||| 2^9) 2099224 q11Shape21T544)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T489OK,q11Shape21T544OK⟩

private def q11Shape21T547 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T547OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131343 2099216 q11Shape21T547=true := by decide

private def q11Shape21T487 : Tree 11 := .split 3 q11Shape21T488 q11Shape21T547
private theorem q11Shape21T487OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 2099216 q11Shape21T487=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131335 (2099216 ||| 2^3) q11Shape21T488 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131335 ||| 2^3) 2099216 q11Shape21T547)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T488OK,q11Shape21T547OK⟩

private def q11Shape21T355 : Tree 11 := .split 2 q11Shape21T356 q11Shape21T487
private theorem q11Shape21T355OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 2099216 q11Shape21T355=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 (2099216 ||| 2^2) q11Shape21T356 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131331 ||| 2^2) 2099216 q11Shape21T487)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T356OK,q11Shape21T487OK⟩

private def q11Shape21T551 : Tree 11 := (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))))
private theorem q11Shape21T551OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131347 2099724 q11Shape21T551=true := by decide

private def q11Shape21T552 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T552OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131859 2099212 q11Shape21T552=true := by decide

private def q11Shape21T550 : Tree 11 := .split 9 q11Shape21T551 q11Shape21T552
private theorem q11Shape21T550OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131347 2099212 q11Shape21T550=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131347 (2099212 ||| 2^9) q11Shape21T551 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131347 ||| 2^9) 2099212 q11Shape21T552)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T551OK,q11Shape21T552OK⟩

private def q11Shape21T553 : Tree 11 := (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape21T553OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131355 2099204 q11Shape21T553=true := by decide

private def q11Shape21T549 : Tree 11 := .split 3 q11Shape21T550 q11Shape21T553
private theorem q11Shape21T549OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131347 2099204 q11Shape21T549=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131347 (2099204 ||| 2^3) q11Shape21T550 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131347 ||| 2^3) 2099204 q11Shape21T553)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T550OK,q11Shape21T553OK⟩

private def q11Shape21T556 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))))
private theorem q11Shape21T556OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131351 2099720 q11Shape21T556=true := by decide

private def q11Shape21T557 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape21T557OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131863 2099208 q11Shape21T557=true := by decide

private def q11Shape21T555 : Tree 11 := .split 9 q11Shape21T556 q11Shape21T557
private theorem q11Shape21T555OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131351 2099208 q11Shape21T555=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131351 (2099208 ||| 2^9) q11Shape21T556 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131351 ||| 2^9) 2099208 q11Shape21T557)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T556OK,q11Shape21T557OK⟩

private def q11Shape21T558 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape21T558OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131359 2099200 q11Shape21T558=true := by decide

private def q11Shape21T554 : Tree 11 := .split 3 q11Shape21T555 q11Shape21T558
private theorem q11Shape21T554OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131351 2099200 q11Shape21T554=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131351 (2099200 ||| 2^3) q11Shape21T555 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131351 ||| 2^3) 2099200 q11Shape21T558)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T555OK,q11Shape21T558OK⟩

private def q11Shape21T548 : Tree 11 := .split 2 q11Shape21T549 q11Shape21T554
private theorem q11Shape21T548OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131347 2099200 q11Shape21T548=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131347 (2099200 ||| 2^2) q11Shape21T549 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131347 ||| 2^2) 2099200 q11Shape21T554)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T549OK,q11Shape21T554OK⟩

private def q11Shape21T354 : Tree 11 := .split 4 q11Shape21T355 q11Shape21T548
private theorem q11Shape21T354OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 2099200 q11Shape21T354=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 (2099200 ||| 2^4) q11Shape21T355 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (131331 ||| 2^4) 2099200 q11Shape21T548)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T355OK,q11Shape21T548OK⟩

def q11Shape21P4 : Tree 11 := q11Shape21T354
theorem q11Shape21P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 131331 2099200 q11Shape21P4=true := q11Shape21T354OK

end Graffiti384b.EffectiveSearch.Q11
