import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T566 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T566OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2229788 q11Shape21T566=true := by decide

private def q11Shape21T568 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T568OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3331 2261532 q11Shape21T568=true := by decide

private def q11Shape21T583 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))))))
private theorem q11Shape21T583OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 8588046876 q11Shape21T583=true := by decide

private def q11Shape21T584 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,3,5,8,10})) (.tip (.cover {0,2,3,4,7,10}))))) (.tip (.cover {0,1,3,4,8,10})))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,3,5,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10})))))
private theorem q11Shape21T584OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 44291 8588038684 q11Shape21T584=true := by decide

private def q11Shape21T582 : Tree 11 := .split 13 q11Shape21T583 q11Shape21T584
private theorem q11Shape21T582OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 8588038684 q11Shape21T582=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (8588038684 ||| 2^13) q11Shape21T583 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^13) 8588038684 q11Shape21T584)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T583OK,q11Shape21T584OK⟩

private def q11Shape21T586 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9})))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T586OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 40195 8588042780 q11Shape21T586=true := by decide

private def q11Shape21T587 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.split 6 (.tip (.cover {0,1,3,5,8,10})) (.tip (.cover {2,3,5,6,7,10}))))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.split 6 (.tip (.cover {0,1,3,5,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T587OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 48387 8588034588 q11Shape21T587=true := by decide

private def q11Shape21T585 : Tree 11 := .split 13 q11Shape21T586 q11Shape21T587
private theorem q11Shape21T585OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 40195 8588034588 q11Shape21T585=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 40195 (8588034588 ||| 2^13) q11Shape21T586 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (40195 ||| 2^13) 8588034588 q11Shape21T587)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T586OK,q11Shape21T587OK⟩

private def q11Shape21T581 : Tree 11 := .split 12 q11Shape21T582 q11Shape21T585
private theorem q11Shape21T581OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 8588034588 q11Shape21T581=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (8588034588 ||| 2^12) q11Shape21T582 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^12) 8588034588 q11Shape21T585)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T582OK,q11Shape21T585OK⟩

private def q11Shape21T588 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T588OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295003395 4293067292 q11Shape21T588=true := by decide

private def q11Shape21T580 : Tree 11 := .split 32 q11Shape21T581 q11Shape21T588
private theorem q11Shape21T580OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 4293067292 q11Shape21T580=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (4293067292 ||| 2^32) q11Shape21T581 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^32) 4293067292 q11Shape21T588)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T581OK,q11Shape21T588OK⟩

private def q11Shape21T589 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T589OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147519747 2145583644 q11Shape21T589=true := by decide

private def q11Shape21T579 : Tree 11 := .split 31 q11Shape21T580 q11Shape21T589
private theorem q11Shape21T579OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 2145583644 q11Shape21T579=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (2145583644 ||| 2^31) q11Shape21T580 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^31) 2145583644 q11Shape21T589)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T580OK,q11Shape21T589OK⟩

private def q11Shape21T590 : Tree 11 := (.tip (.cover {0,3,4,8,9,10}))
private theorem q11Shape21T590OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073777923 1071841820 q11Shape21T590=true := by decide

private def q11Shape21T578 : Tree 11 := .split 30 q11Shape21T579 q11Shape21T590
private theorem q11Shape21T578OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 1071841820 q11Shape21T578=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (1071841820 ||| 2^30) q11Shape21T579 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^30) 1071841820 q11Shape21T590)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T579OK,q11Shape21T590OK⟩

private def q11Shape21T591 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T591OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536907011 534970908 q11Shape21T591=true := by decide

private def q11Shape21T577 : Tree 11 := .split 29 q11Shape21T578 q11Shape21T591
private theorem q11Shape21T577OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 534970908 q11Shape21T577=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (534970908 ||| 2^29) q11Shape21T578 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^29) 534970908 q11Shape21T591)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T578OK,q11Shape21T591OK⟩

private def q11Shape21T592 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T592OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268471555 266535452 q11Shape21T592=true := by decide

private def q11Shape21T576 : Tree 11 := .split 28 q11Shape21T577 q11Shape21T592
private theorem q11Shape21T576OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 266535452 q11Shape21T576=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (266535452 ||| 2^28) q11Shape21T577 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^28) 266535452 q11Shape21T592)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T577OK,q11Shape21T592OK⟩

private def q11Shape21T593 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T593OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134253827 132317724 q11Shape21T593=true := by decide

private def q11Shape21T575 : Tree 11 := .split 27 q11Shape21T576 q11Shape21T593
private theorem q11Shape21T575OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 132317724 q11Shape21T575=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (132317724 ||| 2^27) q11Shape21T576 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^27) 132317724 q11Shape21T593)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T576OK,q11Shape21T593OK⟩

private def q11Shape21T594 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T594OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33590531 98763292 q11Shape21T594=true := by decide

private def q11Shape21T574 : Tree 11 := .split 25 q11Shape21T575 q11Shape21T594
private theorem q11Shape21T574OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 98763292 q11Shape21T574=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (98763292 ||| 2^25) q11Shape21T575 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^25) 98763292 q11Shape21T594)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T575OK,q11Shape21T594OK⟩

private def q11Shape21T595 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T595OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16813315 81986076 q11Shape21T595=true := by decide

private def q11Shape21T573 : Tree 11 := .split 24 q11Shape21T574 q11Shape21T595
private theorem q11Shape21T573OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 81986076 q11Shape21T573=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (81986076 ||| 2^24) q11Shape21T574 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^24) 81986076 q11Shape21T595)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T574OK,q11Shape21T595OK⟩

private def q11Shape21T596 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T596OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8424707 73597468 q11Shape21T596=true := by decide

private def q11Shape21T572 : Tree 11 := .split 23 q11Shape21T573 q11Shape21T596
private theorem q11Shape21T572OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 73597468 q11Shape21T572=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (73597468 ||| 2^23) q11Shape21T573 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^23) 73597468 q11Shape21T596)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T573OK,q11Shape21T596OK⟩

private def q11Shape21T597 : Tree 11 := (.tip (.cover {0,3,5,8,9,10}))
private theorem q11Shape21T597OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4230403 69403164 q11Shape21T597=true := by decide

private def q11Shape21T571 : Tree 11 := .split 22 q11Shape21T572 q11Shape21T597
private theorem q11Shape21T571OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 69403164 q11Shape21T571=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (69403164 ||| 2^22) q11Shape21T572 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^22) 69403164 q11Shape21T597)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T572OK,q11Shape21T597OK⟩

private def q11Shape21T598 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T598OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67144963 2294300 q11Shape21T598=true := by decide

private def q11Shape21T570 : Tree 11 := .split 26 q11Shape21T571 q11Shape21T598
private theorem q11Shape21T570OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 2294300 q11Shape21T570=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (2294300 ||| 2^26) q11Shape21T571 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^26) 2294300 q11Shape21T598)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T571OK,q11Shape21T598OK⟩

private def q11Shape21T599 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T599OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 101635 2228764 q11Shape21T599=true := by decide

private def q11Shape21T569 : Tree 11 := .split 16 q11Shape21T570 q11Shape21T599
private theorem q11Shape21T569OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 2228764 q11Shape21T569=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36099 (2228764 ||| 2^16) q11Shape21T570 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (36099 ||| 2^16) 2228764 q11Shape21T599)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T570OK,q11Shape21T599OK⟩

private def q11Shape21T567 : Tree 11 := .split 15 q11Shape21T568 q11Shape21T569
private theorem q11Shape21T567OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3331 2228764 q11Shape21T567=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3331 (2228764 ||| 2^15) q11Shape21T568 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3331 ||| 2^15) 2228764 q11Shape21T569)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T568OK,q11Shape21T569OK⟩

private def q11Shape21T565 : Tree 11 := .split 10 q11Shape21T566 q11Shape21T567
private theorem q11Shape21T565OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2228764 q11Shape21T565=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 (2228764 ||| 2^10) q11Shape21T566 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2307 ||| 2^10) 2228764 q11Shape21T567)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T566OK,q11Shape21T567OK⟩

private def q11Shape21T603 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T603OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2819 2327580 q11Shape21T603=true := by decide

private def q11Shape21T617 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))))))
private theorem q11Shape21T617OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 8588014620 q11Shape21T617=true := by decide

private def q11Shape21T618 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,3,6,8,10})) (.tip (.cover {0,2,3,4,7,10}))))) (.tip (.cover {0,1,3,4,8,10})))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.split 6 (.tip (.cover {0,1,3,6,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10})))))
private theorem q11Shape21T618OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 76547 8588006428 q11Shape21T618=true := by decide

private def q11Shape21T616 : Tree 11 := .split 13 q11Shape21T617 q11Shape21T618
private theorem q11Shape21T616OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 8588006428 q11Shape21T616=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (8588006428 ||| 2^13) q11Shape21T617 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^13) 8588006428 q11Shape21T618)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T617OK,q11Shape21T618OK⟩

private def q11Shape21T620 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,6,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,6,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,1,3,4,8,9})))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T620OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 72451 8588010524 q11Shape21T620=true := by decide

private def q11Shape21T621 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,6,9,10})) (.split 6 (.tip (.cover {0,1,3,6,8,10})) (.tip (.cover {2,3,5,6,7,10}))))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,6,9,10})) (.split 6 (.tip (.cover {0,1,3,6,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))))
private theorem q11Shape21T621OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 80643 8588002332 q11Shape21T621=true := by decide

private def q11Shape21T619 : Tree 11 := .split 13 q11Shape21T620 q11Shape21T621
private theorem q11Shape21T619OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 72451 8588002332 q11Shape21T619=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 72451 (8588002332 ||| 2^13) q11Shape21T620 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (72451 ||| 2^13) 8588002332 q11Shape21T621)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T620OK,q11Shape21T621OK⟩

private def q11Shape21T615 : Tree 11 := .split 12 q11Shape21T616 q11Shape21T619
private theorem q11Shape21T615OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 8588002332 q11Shape21T615=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (8588002332 ||| 2^12) q11Shape21T616 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^12) 8588002332 q11Shape21T619)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T616OK,q11Shape21T619OK⟩

private def q11Shape21T622 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T622OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4295035651 4293035036 q11Shape21T622=true := by decide

private def q11Shape21T614 : Tree 11 := .split 32 q11Shape21T615 q11Shape21T622
private theorem q11Shape21T614OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 4293035036 q11Shape21T614=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (4293035036 ||| 2^32) q11Shape21T615 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^32) 4293035036 q11Shape21T622)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T615OK,q11Shape21T622OK⟩

private def q11Shape21T623 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T623OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147552003 2145551388 q11Shape21T623=true := by decide

private def q11Shape21T613 : Tree 11 := .split 31 q11Shape21T614 q11Shape21T623
private theorem q11Shape21T613OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 2145551388 q11Shape21T613=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (2145551388 ||| 2^31) q11Shape21T614 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^31) 2145551388 q11Shape21T623)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T614OK,q11Shape21T623OK⟩

private def q11Shape21T624 : Tree 11 := (.tip (.cover {0,3,4,8,9,10}))
private theorem q11Shape21T624OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073810179 1071809564 q11Shape21T624=true := by decide

private def q11Shape21T612 : Tree 11 := .split 30 q11Shape21T613 q11Shape21T624
private theorem q11Shape21T612OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 1071809564 q11Shape21T612=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (1071809564 ||| 2^30) q11Shape21T613 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^30) 1071809564 q11Shape21T624)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T613OK,q11Shape21T624OK⟩

private def q11Shape21T625 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T625OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536939267 534938652 q11Shape21T625=true := by decide

private def q11Shape21T611 : Tree 11 := .split 29 q11Shape21T612 q11Shape21T625
private theorem q11Shape21T611OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 534938652 q11Shape21T611=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (534938652 ||| 2^29) q11Shape21T612 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^29) 534938652 q11Shape21T625)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T612OK,q11Shape21T625OK⟩

private def q11Shape21T626 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T626OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268503811 266503196 q11Shape21T626=true := by decide

private def q11Shape21T610 : Tree 11 := .split 28 q11Shape21T611 q11Shape21T626
private theorem q11Shape21T610OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 266503196 q11Shape21T610=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (266503196 ||| 2^28) q11Shape21T611 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^28) 266503196 q11Shape21T626)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T611OK,q11Shape21T626OK⟩

private def q11Shape21T627 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T627OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134286083 132285468 q11Shape21T627=true := by decide

private def q11Shape21T609 : Tree 11 := .split 27 q11Shape21T610 q11Shape21T627
private theorem q11Shape21T609OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 132285468 q11Shape21T609=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (132285468 ||| 2^27) q11Shape21T610 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^27) 132285468 q11Shape21T627)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T610OK,q11Shape21T627OK⟩

private def q11Shape21T628 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T628OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33622787 98731036 q11Shape21T628=true := by decide

private def q11Shape21T608 : Tree 11 := .split 25 q11Shape21T609 q11Shape21T628
private theorem q11Shape21T608OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 98731036 q11Shape21T608=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (98731036 ||| 2^25) q11Shape21T609 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^25) 98731036 q11Shape21T628)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T609OK,q11Shape21T628OK⟩

private def q11Shape21T629 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T629OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16845571 81953820 q11Shape21T629=true := by decide

private def q11Shape21T607 : Tree 11 := .split 24 q11Shape21T608 q11Shape21T629
private theorem q11Shape21T607OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 81953820 q11Shape21T607=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (81953820 ||| 2^24) q11Shape21T608 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^24) 81953820 q11Shape21T629)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T608OK,q11Shape21T629OK⟩

private def q11Shape21T630 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T630OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8456963 73565212 q11Shape21T630=true := by decide

private def q11Shape21T606 : Tree 11 := .split 23 q11Shape21T607 q11Shape21T630
private theorem q11Shape21T606OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 73565212 q11Shape21T606=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (73565212 ||| 2^23) q11Shape21T607 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^23) 73565212 q11Shape21T630)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T607OK,q11Shape21T630OK⟩

private def q11Shape21T631 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T631OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4262659 69370908 q11Shape21T631=true := by decide

private def q11Shape21T605 : Tree 11 := .split 22 q11Shape21T606 q11Shape21T631
private theorem q11Shape21T605OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 69370908 q11Shape21T605=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (69370908 ||| 2^22) q11Shape21T606 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^22) 69370908 q11Shape21T631)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T606OK,q11Shape21T631OK⟩

private def q11Shape21T632 : Tree 11 := (.tip (.cover {0,3,6,8,9,10}))
private theorem q11Shape21T632OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67177219 2262044 q11Shape21T632=true := by decide

private def q11Shape21T604 : Tree 11 := .split 26 q11Shape21T605 q11Shape21T632
private theorem q11Shape21T604OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 2262044 q11Shape21T604=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68355 (2262044 ||| 2^26) q11Shape21T605 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (68355 ||| 2^26) 2262044 q11Shape21T632)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T605OK,q11Shape21T632OK⟩

private def q11Shape21T602 : Tree 11 := .split 16 q11Shape21T603 q11Shape21T604
private theorem q11Shape21T602OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2819 2262044 q11Shape21T602=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2819 (2262044 ||| 2^16) q11Shape21T603 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2819 ||| 2^16) 2262044 q11Shape21T604)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T603OK,q11Shape21T604OK⟩

private def q11Shape21T633 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T633OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35587 2229276 q11Shape21T633=true := by decide

private def q11Shape21T601 : Tree 11 := .split 15 q11Shape21T602 q11Shape21T633
private theorem q11Shape21T601OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2819 2229276 q11Shape21T601=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2819 (2229276 ||| 2^15) q11Shape21T602 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2819 ||| 2^15) 2229276 q11Shape21T633)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T602OK,q11Shape21T633OK⟩

private def q11Shape21T634 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T634OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3843 2228252 q11Shape21T634=true := by decide

private def q11Shape21T600 : Tree 11 := .split 10 q11Shape21T601 q11Shape21T634
private theorem q11Shape21T600OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2819 2228252 q11Shape21T600=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2819 (2228252 ||| 2^10) q11Shape21T601 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2819 ||| 2^10) 2228252 q11Shape21T634)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T601OK,q11Shape21T634OK⟩

private def q11Shape21T564 : Tree 11 := .split 9 q11Shape21T565 q11Shape21T600
private theorem q11Shape21T564OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2228252 q11Shape21T564=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 (2228252 ||| 2^9) q11Shape21T565 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2307 ||| 2^9) 2228252 q11Shape21T600)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T565OK,q11Shape21T600OK⟩

private def q11Shape21T638 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T638OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2315 2262548 q11Shape21T638=true := by decide

private def q11Shape21T649 : Tree 11 := (.split 31 (.split 32 (.split 12 (.tip (.cover {0,2,4,7,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.split 14 (.tip (.cover {0,2,4,7,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,4,7,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10})))
private theorem q11Shape21T649OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 2145584660 q11Shape21T649=true := by decide

private def q11Shape21T650 : Tree 11 := (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,2,4,8,9,10})))
private theorem q11Shape21T650OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073776907 1071842836 q11Shape21T650=true := by decide

private def q11Shape21T648 : Tree 11 := .split 30 q11Shape21T649 q11Shape21T650
private theorem q11Shape21T648OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 1071842836 q11Shape21T648=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (1071842836 ||| 2^30) q11Shape21T649 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^30) 1071842836 q11Shape21T650)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T649OK,q11Shape21T650OK⟩

private def q11Shape21T651 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T651OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536905995 534971924 q11Shape21T651=true := by decide

private def q11Shape21T647 : Tree 11 := .split 29 q11Shape21T648 q11Shape21T651
private theorem q11Shape21T647OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 534971924 q11Shape21T647=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (534971924 ||| 2^29) q11Shape21T648 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^29) 534971924 q11Shape21T651)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T648OK,q11Shape21T651OK⟩

private def q11Shape21T652 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T652OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268470539 266536468 q11Shape21T652=true := by decide

private def q11Shape21T646 : Tree 11 := .split 28 q11Shape21T647 q11Shape21T652
private theorem q11Shape21T646OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 266536468 q11Shape21T646=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (266536468 ||| 2^28) q11Shape21T647 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^28) 266536468 q11Shape21T652)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T647OK,q11Shape21T652OK⟩

private def q11Shape21T653 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T653OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134252811 132318740 q11Shape21T653=true := by decide

private def q11Shape21T645 : Tree 11 := .split 27 q11Shape21T646 q11Shape21T653
private theorem q11Shape21T645OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 132318740 q11Shape21T645=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (132318740 ||| 2^27) q11Shape21T646 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^27) 132318740 q11Shape21T653)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T646OK,q11Shape21T653OK⟩

private def q11Shape21T654 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T654OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33589515 98764308 q11Shape21T654=true := by decide

private def q11Shape21T644 : Tree 11 := .split 25 q11Shape21T645 q11Shape21T654
private theorem q11Shape21T644OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 98764308 q11Shape21T644=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (98764308 ||| 2^25) q11Shape21T645 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^25) 98764308 q11Shape21T654)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T645OK,q11Shape21T654OK⟩

private def q11Shape21T655 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T655OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16812299 81987092 q11Shape21T655=true := by decide

private def q11Shape21T643 : Tree 11 := .split 24 q11Shape21T644 q11Shape21T655
private theorem q11Shape21T643OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 81987092 q11Shape21T643=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (81987092 ||| 2^24) q11Shape21T644 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^24) 81987092 q11Shape21T655)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T644OK,q11Shape21T655OK⟩

private def q11Shape21T656 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T656OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8423691 73598484 q11Shape21T656=true := by decide

private def q11Shape21T642 : Tree 11 := .split 23 q11Shape21T643 q11Shape21T656
private theorem q11Shape21T642OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 73598484 q11Shape21T642=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (73598484 ||| 2^23) q11Shape21T643 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^23) 73598484 q11Shape21T656)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T643OK,q11Shape21T656OK⟩

private def q11Shape21T657 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T657OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4229387 69404180 q11Shape21T657=true := by decide

private def q11Shape21T641 : Tree 11 := .split 22 q11Shape21T642 q11Shape21T657
private theorem q11Shape21T641OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 69404180 q11Shape21T641=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (69404180 ||| 2^22) q11Shape21T642 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^22) 69404180 q11Shape21T657)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T642OK,q11Shape21T657OK⟩

private def q11Shape21T658 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T658OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67143947 2295316 q11Shape21T658=true := by decide

private def q11Shape21T640 : Tree 11 := .split 26 q11Shape21T641 q11Shape21T658
private theorem q11Shape21T640OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 2295316 q11Shape21T640=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (2295316 ||| 2^26) q11Shape21T641 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^26) 2295316 q11Shape21T658)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T641OK,q11Shape21T658OK⟩

private def q11Shape21T659 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T659OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 100619 2229780 q11Shape21T659=true := by decide

private def q11Shape21T639 : Tree 11 := .split 16 q11Shape21T640 q11Shape21T659
private theorem q11Shape21T639OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 2229780 q11Shape21T639=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35083 (2229780 ||| 2^16) q11Shape21T640 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (35083 ||| 2^16) 2229780 q11Shape21T659)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T640OK,q11Shape21T659OK⟩

private def q11Shape21T637 : Tree 11 := .split 15 q11Shape21T638 q11Shape21T639
private theorem q11Shape21T637OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2315 2229780 q11Shape21T637=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2315 (2229780 ||| 2^15) q11Shape21T638 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2315 ||| 2^15) 2229780 q11Shape21T639)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T638OK,q11Shape21T639OK⟩

private def q11Shape21T660 : Tree 11 := (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,2,4,7,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.split 14 (.tip (.cover {0,2,4,7,8,9})) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))))
private theorem q11Shape21T660OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3339 2228756 q11Shape21T660=true := by decide

private def q11Shape21T636 : Tree 11 := .split 10 q11Shape21T637 q11Shape21T660
private theorem q11Shape21T636OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2315 2228756 q11Shape21T636=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2315 (2228756 ||| 2^10) q11Shape21T637 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2315 ||| 2^10) 2228756 q11Shape21T660)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T637OK,q11Shape21T660OK⟩

private def q11Shape21T677 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))))))
private theorem q11Shape21T677OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 8588080148 q11Shape21T677=true := by decide

private def q11Shape21T678 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T678OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 11019 8588071956 q11Shape21T678=true := by decide

private def q11Shape21T676 : Tree 11 := .split 13 q11Shape21T677 q11Shape21T678
private theorem q11Shape21T676OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 8588071956 q11Shape21T676=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (8588071956 ||| 2^13) q11Shape21T677 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^13) 8588071956 q11Shape21T678)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T677OK,q11Shape21T678OK⟩

private def q11Shape21T679 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,3,9,10})))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,9})))))) (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10})))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape21T679OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6923 8588067860 q11Shape21T679=true := by decide

private def q11Shape21T675 : Tree 11 := .split 12 q11Shape21T676 q11Shape21T679
private theorem q11Shape21T675OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 8588067860 q11Shape21T675=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (8588067860 ||| 2^12) q11Shape21T676 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^12) 8588067860 q11Shape21T679)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T676OK,q11Shape21T679OK⟩

private def q11Shape21T680 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T680OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4294970123 4293100564 q11Shape21T680=true := by decide

private def q11Shape21T674 : Tree 11 := .split 32 q11Shape21T675 q11Shape21T680
private theorem q11Shape21T674OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 4293100564 q11Shape21T674=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (4293100564 ||| 2^32) q11Shape21T675 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^32) 4293100564 q11Shape21T680)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T675OK,q11Shape21T680OK⟩

private def q11Shape21T681 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T681OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147486475 2145616916 q11Shape21T681=true := by decide

private def q11Shape21T673 : Tree 11 := .split 31 q11Shape21T674 q11Shape21T681
private theorem q11Shape21T673OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 2145616916 q11Shape21T673=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (2145616916 ||| 2^31) q11Shape21T674 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^31) 2145616916 q11Shape21T681)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T674OK,q11Shape21T681OK⟩

private def q11Shape21T682 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape21T682OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073744651 1071875092 q11Shape21T682=true := by decide

private def q11Shape21T672 : Tree 11 := .split 30 q11Shape21T673 q11Shape21T682
private theorem q11Shape21T672OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 1071875092 q11Shape21T672=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (1071875092 ||| 2^30) q11Shape21T673 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^30) 1071875092 q11Shape21T682)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T673OK,q11Shape21T682OK⟩

private def q11Shape21T683 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T683OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536873739 535004180 q11Shape21T683=true := by decide

private def q11Shape21T671 : Tree 11 := .split 29 q11Shape21T672 q11Shape21T683
private theorem q11Shape21T671OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 535004180 q11Shape21T671=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (535004180 ||| 2^29) q11Shape21T672 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^29) 535004180 q11Shape21T683)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T672OK,q11Shape21T683OK⟩

private def q11Shape21T684 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T684OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268438283 266568724 q11Shape21T684=true := by decide

private def q11Shape21T670 : Tree 11 := .split 28 q11Shape21T671 q11Shape21T684
private theorem q11Shape21T670OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 266568724 q11Shape21T670=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (266568724 ||| 2^28) q11Shape21T671 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^28) 266568724 q11Shape21T684)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T671OK,q11Shape21T684OK⟩

private def q11Shape21T685 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T685OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134220555 132350996 q11Shape21T685=true := by decide

private def q11Shape21T669 : Tree 11 := .split 27 q11Shape21T670 q11Shape21T685
private theorem q11Shape21T669OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 132350996 q11Shape21T669=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (132350996 ||| 2^27) q11Shape21T670 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^27) 132350996 q11Shape21T685)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T670OK,q11Shape21T685OK⟩

private def q11Shape21T686 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T686OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33557259 98796564 q11Shape21T686=true := by decide

private def q11Shape21T668 : Tree 11 := .split 25 q11Shape21T669 q11Shape21T686
private theorem q11Shape21T668OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 98796564 q11Shape21T668=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (98796564 ||| 2^25) q11Shape21T669 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^25) 98796564 q11Shape21T686)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T669OK,q11Shape21T686OK⟩

private def q11Shape21T687 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T687OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16780043 82019348 q11Shape21T687=true := by decide

private def q11Shape21T667 : Tree 11 := .split 24 q11Shape21T668 q11Shape21T687
private theorem q11Shape21T667OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 82019348 q11Shape21T667=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (82019348 ||| 2^24) q11Shape21T668 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^24) 82019348 q11Shape21T687)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T668OK,q11Shape21T687OK⟩

private def q11Shape21T688 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T688OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8391435 73630740 q11Shape21T688=true := by decide

private def q11Shape21T666 : Tree 11 := .split 23 q11Shape21T667 q11Shape21T688
private theorem q11Shape21T666OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 73630740 q11Shape21T666=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (73630740 ||| 2^23) q11Shape21T667 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^23) 73630740 q11Shape21T688)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T667OK,q11Shape21T688OK⟩

private def q11Shape21T689 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T689OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4197131 69436436 q11Shape21T689=true := by decide

private def q11Shape21T665 : Tree 11 := .split 22 q11Shape21T666 q11Shape21T689
private theorem q11Shape21T665OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 69436436 q11Shape21T665=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (69436436 ||| 2^22) q11Shape21T666 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^22) 69436436 q11Shape21T689)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T666OK,q11Shape21T689OK⟩

private def q11Shape21T690 : Tree 11 := (.tip (.cover {0,3,6,8,9,10}))
private theorem q11Shape21T690OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67111691 2327572 q11Shape21T690=true := by decide

private def q11Shape21T664 : Tree 11 := .split 26 q11Shape21T665 q11Shape21T690
private theorem q11Shape21T664OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 2327572 q11Shape21T664=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (2327572 ||| 2^26) q11Shape21T665 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^26) 2327572 q11Shape21T690)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T665OK,q11Shape21T690OK⟩

private def q11Shape21T691 : Tree 11 := (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,7,9,10})) (.split 13 (.tip (.cover {2,4,5,7,8,10})) (.split 14 (.tip (.cover {2,4,5,7,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,3,6,8,9,10})))
private theorem q11Shape21T691OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68363 2262036 q11Shape21T691=true := by decide

private def q11Shape21T663 : Tree 11 := .split 16 q11Shape21T664 q11Shape21T691
private theorem q11Shape21T663OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 2262036 q11Shape21T663=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (2262036 ||| 2^16) q11Shape21T664 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^16) 2262036 q11Shape21T691)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T664OK,q11Shape21T691OK⟩

private def q11Shape21T692 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,2,4,7,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.split 14 (.tip (.cover {0,2,4,7,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {3,4,6,7,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T692OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35595 2229268 q11Shape21T692=true := by decide

private def q11Shape21T662 : Tree 11 := .split 15 q11Shape21T663 q11Shape21T692
private theorem q11Shape21T662OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 2229268 q11Shape21T662=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (2229268 ||| 2^15) q11Shape21T663 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^15) 2229268 q11Shape21T692)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T663OK,q11Shape21T692OK⟩

private def q11Shape21T693 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T693OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3851 2228244 q11Shape21T693=true := by decide

private def q11Shape21T661 : Tree 11 := .split 10 q11Shape21T662 q11Shape21T693
private theorem q11Shape21T661OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 2228244 q11Shape21T661=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2827 (2228244 ||| 2^10) q11Shape21T662 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2827 ||| 2^10) 2228244 q11Shape21T693)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T662OK,q11Shape21T693OK⟩

private def q11Shape21T635 : Tree 11 := .split 9 q11Shape21T636 q11Shape21T661
private theorem q11Shape21T635OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2315 2228244 q11Shape21T635=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2315 (2228244 ||| 2^9) q11Shape21T636 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2315 ||| 2^9) 2228244 q11Shape21T661)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T636OK,q11Shape21T661OK⟩

private def q11Shape21T563 : Tree 11 := .split 3 q11Shape21T564 q11Shape21T635
private theorem q11Shape21T563OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2228244 q11Shape21T563=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 (2228244 ||| 2^3) q11Shape21T564 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2307 ||| 2^3) 2228244 q11Shape21T635)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T564OK,q11Shape21T635OK⟩

private def q11Shape21T699 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T699OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 2328088 q11Shape21T699=true := by decide

private def q11Shape21T709 : Tree 11 := (.split 31 (.split 32 (.split 12 (.tip (.cover {0,2,4,7,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.split 14 (.tip (.cover {0,2,4,7,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))) (.split 20 (.split 5 (.tip (.cover {3,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.split 6 (.tip (.cover {3,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,4,7,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10})))
private theorem q11Shape21T709OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 2145551896 q11Shape21T709=true := by decide

private def q11Shape21T710 : Tree 11 := (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,2,4,8,9,10})))
private theorem q11Shape21T710OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073809671 1071810072 q11Shape21T710=true := by decide

private def q11Shape21T708 : Tree 11 := .split 30 q11Shape21T709 q11Shape21T710
private theorem q11Shape21T708OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 1071810072 q11Shape21T708=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (1071810072 ||| 2^30) q11Shape21T709 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^30) 1071810072 q11Shape21T710)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T709OK,q11Shape21T710OK⟩

private def q11Shape21T711 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T711OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536938759 534939160 q11Shape21T711=true := by decide

private def q11Shape21T707 : Tree 11 := .split 29 q11Shape21T708 q11Shape21T711
private theorem q11Shape21T707OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 534939160 q11Shape21T707=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (534939160 ||| 2^29) q11Shape21T708 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^29) 534939160 q11Shape21T711)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T708OK,q11Shape21T711OK⟩

private def q11Shape21T712 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T712OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268503303 266503704 q11Shape21T712=true := by decide

private def q11Shape21T706 : Tree 11 := .split 28 q11Shape21T707 q11Shape21T712
private theorem q11Shape21T706OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 266503704 q11Shape21T706=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (266503704 ||| 2^28) q11Shape21T707 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^28) 266503704 q11Shape21T712)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T707OK,q11Shape21T712OK⟩

private def q11Shape21T713 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T713OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134285575 132285976 q11Shape21T713=true := by decide

private def q11Shape21T705 : Tree 11 := .split 27 q11Shape21T706 q11Shape21T713
private theorem q11Shape21T705OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 132285976 q11Shape21T705=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (132285976 ||| 2^27) q11Shape21T706 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^27) 132285976 q11Shape21T713)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T706OK,q11Shape21T713OK⟩

private def q11Shape21T714 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T714OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33622279 98731544 q11Shape21T714=true := by decide

private def q11Shape21T704 : Tree 11 := .split 25 q11Shape21T705 q11Shape21T714
private theorem q11Shape21T704OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 98731544 q11Shape21T704=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (98731544 ||| 2^25) q11Shape21T705 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^25) 98731544 q11Shape21T714)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T705OK,q11Shape21T714OK⟩

private def q11Shape21T715 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T715OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16845063 81954328 q11Shape21T715=true := by decide

private def q11Shape21T703 : Tree 11 := .split 24 q11Shape21T704 q11Shape21T715
private theorem q11Shape21T703OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 81954328 q11Shape21T703=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (81954328 ||| 2^24) q11Shape21T704 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^24) 81954328 q11Shape21T715)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T704OK,q11Shape21T715OK⟩

private def q11Shape21T716 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T716OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8456455 73565720 q11Shape21T716=true := by decide

private def q11Shape21T702 : Tree 11 := .split 23 q11Shape21T703 q11Shape21T716
private theorem q11Shape21T702OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 73565720 q11Shape21T702=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (73565720 ||| 2^23) q11Shape21T703 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^23) 73565720 q11Shape21T716)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T703OK,q11Shape21T716OK⟩

private def q11Shape21T717 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T717OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4262151 69371416 q11Shape21T717=true := by decide

private def q11Shape21T701 : Tree 11 := .split 22 q11Shape21T702 q11Shape21T717
private theorem q11Shape21T701OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 69371416 q11Shape21T701=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (69371416 ||| 2^22) q11Shape21T702 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^22) 69371416 q11Shape21T717)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T702OK,q11Shape21T717OK⟩

private def q11Shape21T718 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T718OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67176711 2262552 q11Shape21T718=true := by decide

private def q11Shape21T700 : Tree 11 := .split 26 q11Shape21T701 q11Shape21T718
private theorem q11Shape21T700OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 2262552 q11Shape21T700=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67847 (2262552 ||| 2^26) q11Shape21T701 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (67847 ||| 2^26) 2262552 q11Shape21T718)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T701OK,q11Shape21T718OK⟩

private def q11Shape21T698 : Tree 11 := .split 16 q11Shape21T699 q11Shape21T700
private theorem q11Shape21T698OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 2262552 q11Shape21T698=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 (2262552 ||| 2^16) q11Shape21T699 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2311 ||| 2^16) 2262552 q11Shape21T700)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T699OK,q11Shape21T700OK⟩

private def q11Shape21T719 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T719OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35079 2229784 q11Shape21T719=true := by decide

private def q11Shape21T697 : Tree 11 := .split 15 q11Shape21T698 q11Shape21T719
private theorem q11Shape21T697OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 2229784 q11Shape21T697=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 (2229784 ||| 2^15) q11Shape21T698 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2311 ||| 2^15) 2229784 q11Shape21T719)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T698OK,q11Shape21T719OK⟩

private def q11Shape21T735 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,9})))))))
private theorem q11Shape21T735OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 8588079640 q11Shape21T735=true := by decide

private def q11Shape21T736 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {4,5,6,7,9,10})) (.tip (.cover {0,2,3,4,7,10})))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T736OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 11527 8588071448 q11Shape21T736=true := by decide

private def q11Shape21T734 : Tree 11 := .split 13 q11Shape21T735 q11Shape21T736
private theorem q11Shape21T734OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 8588071448 q11Shape21T734=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (8588071448 ||| 2^13) q11Shape21T735 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^13) 8588071448 q11Shape21T736)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T735OK,q11Shape21T736OK⟩

private def q11Shape21T737 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.split 6 (.tip (.cover {4,5,6,7,8,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,1,2,3,9,10})))))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {3,4,5,6,7,9})))))) (.split 14 (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10})))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,7,10}))))))
private theorem q11Shape21T737OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 7431 8588067352 q11Shape21T737=true := by decide

private def q11Shape21T733 : Tree 11 := .split 12 q11Shape21T734 q11Shape21T737
private theorem q11Shape21T733OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 8588067352 q11Shape21T733=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (8588067352 ||| 2^12) q11Shape21T734 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^12) 8588067352 q11Shape21T737)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T734OK,q11Shape21T737OK⟩

private def q11Shape21T738 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape21T738OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4294970631 4293100056 q11Shape21T738=true := by decide

private def q11Shape21T732 : Tree 11 := .split 32 q11Shape21T733 q11Shape21T738
private theorem q11Shape21T732OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 4293100056 q11Shape21T732=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (4293100056 ||| 2^32) q11Shape21T733 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^32) 4293100056 q11Shape21T738)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T733OK,q11Shape21T738OK⟩

private def q11Shape21T739 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape21T739OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2147486983 2145616408 q11Shape21T739=true := by decide

private def q11Shape21T731 : Tree 11 := .split 31 q11Shape21T732 q11Shape21T739
private theorem q11Shape21T731OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 2145616408 q11Shape21T731=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (2145616408 ||| 2^31) q11Shape21T732 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^31) 2145616408 q11Shape21T739)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T732OK,q11Shape21T739OK⟩

private def q11Shape21T740 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape21T740OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1073745159 1071874584 q11Shape21T740=true := by decide

private def q11Shape21T730 : Tree 11 := .split 30 q11Shape21T731 q11Shape21T740
private theorem q11Shape21T730OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 1071874584 q11Shape21T730=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (1071874584 ||| 2^30) q11Shape21T731 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^30) 1071874584 q11Shape21T740)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T731OK,q11Shape21T740OK⟩

private def q11Shape21T741 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T741OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 536874247 535003672 q11Shape21T741=true := by decide

private def q11Shape21T729 : Tree 11 := .split 29 q11Shape21T730 q11Shape21T741
private theorem q11Shape21T729OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 535003672 q11Shape21T729=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (535003672 ||| 2^29) q11Shape21T730 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^29) 535003672 q11Shape21T741)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T730OK,q11Shape21T741OK⟩

private def q11Shape21T742 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T742OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 268438791 266568216 q11Shape21T742=true := by decide

private def q11Shape21T728 : Tree 11 := .split 28 q11Shape21T729 q11Shape21T742
private theorem q11Shape21T728OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 266568216 q11Shape21T728=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (266568216 ||| 2^28) q11Shape21T729 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^28) 266568216 q11Shape21T742)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T729OK,q11Shape21T742OK⟩

private def q11Shape21T743 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T743OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134221063 132350488 q11Shape21T743=true := by decide

private def q11Shape21T727 : Tree 11 := .split 27 q11Shape21T728 q11Shape21T743
private theorem q11Shape21T727OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 132350488 q11Shape21T727=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (132350488 ||| 2^27) q11Shape21T728 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^27) 132350488 q11Shape21T743)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T728OK,q11Shape21T743OK⟩

private def q11Shape21T744 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T744OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 33557767 98796056 q11Shape21T744=true := by decide

private def q11Shape21T726 : Tree 11 := .split 25 q11Shape21T727 q11Shape21T744
private theorem q11Shape21T726OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 98796056 q11Shape21T726=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (98796056 ||| 2^25) q11Shape21T727 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^25) 98796056 q11Shape21T744)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T727OK,q11Shape21T744OK⟩

private def q11Shape21T745 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T745OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 16780551 82018840 q11Shape21T745=true := by decide

private def q11Shape21T725 : Tree 11 := .split 24 q11Shape21T726 q11Shape21T745
private theorem q11Shape21T725OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 82018840 q11Shape21T725=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (82018840 ||| 2^24) q11Shape21T726 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^24) 82018840 q11Shape21T745)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T726OK,q11Shape21T745OK⟩

private def q11Shape21T746 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T746OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 8391943 73630232 q11Shape21T746=true := by decide

private def q11Shape21T724 : Tree 11 := .split 23 q11Shape21T725 q11Shape21T746
private theorem q11Shape21T724OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 73630232 q11Shape21T724=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (73630232 ||| 2^23) q11Shape21T725 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^23) 73630232 q11Shape21T746)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T725OK,q11Shape21T746OK⟩

private def q11Shape21T747 : Tree 11 := (.tip (.cover {0,3,5,8,9,10}))
private theorem q11Shape21T747OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4197639 69435928 q11Shape21T747=true := by decide

private def q11Shape21T723 : Tree 11 := .split 22 q11Shape21T724 q11Shape21T747
private theorem q11Shape21T723OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 69435928 q11Shape21T723=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (69435928 ||| 2^22) q11Shape21T724 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^22) 69435928 q11Shape21T747)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T724OK,q11Shape21T747OK⟩

private def q11Shape21T748 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T748OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 67112199 2327064 q11Shape21T748=true := by decide

private def q11Shape21T722 : Tree 11 := .split 26 q11Shape21T723 q11Shape21T748
private theorem q11Shape21T722OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 2327064 q11Shape21T722=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (2327064 ||| 2^26) q11Shape21T723 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^26) 2327064 q11Shape21T748)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T723OK,q11Shape21T748OK⟩

private def q11Shape21T749 : Tree 11 := (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,2,4,7,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.split 14 (.tip (.cover {0,2,4,7,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {3,4,5,7,9,10})))))) (.tip (.cover {2,3,4,5,8,10}))) (.tip (.cover {2,3,4,5,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))
private theorem q11Shape21T749OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 68871 2261528 q11Shape21T749=true := by decide

private def q11Shape21T721 : Tree 11 := .split 16 q11Shape21T722 q11Shape21T749
private theorem q11Shape21T721OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 2261528 q11Shape21T721=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (2261528 ||| 2^16) q11Shape21T722 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^16) 2261528 q11Shape21T749)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T722OK,q11Shape21T749OK⟩

private def q11Shape21T750 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,6,7,9,10})) (.split 13 (.tip (.cover {2,4,6,7,8,10})) (.split 14 (.tip (.cover {2,4,6,7,8,9})) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,7,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T750OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 36103 2228760 q11Shape21T750=true := by decide

private def q11Shape21T720 : Tree 11 := .split 15 q11Shape21T721 q11Shape21T750
private theorem q11Shape21T720OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 2228760 q11Shape21T720=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3335 (2228760 ||| 2^15) q11Shape21T721 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (3335 ||| 2^15) 2228760 q11Shape21T750)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T721OK,q11Shape21T750OK⟩

private def q11Shape21T696 : Tree 11 := .split 10 q11Shape21T697 q11Shape21T720
private theorem q11Shape21T696OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 2228760 q11Shape21T696=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 (2228760 ||| 2^10) q11Shape21T697 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2311 ||| 2^10) 2228760 q11Shape21T720)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T697OK,q11Shape21T720OK⟩

private def q11Shape21T752 : Tree 11 := (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {0,2,4,7,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.split 14 (.tip (.cover {0,2,4,7,8,9})) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {0,1,3,4,9,10})))))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,3,6,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T752OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2823 2229272 q11Shape21T752=true := by decide

private def q11Shape21T753 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape21T753OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 3847 2228248 q11Shape21T753=true := by decide

private def q11Shape21T751 : Tree 11 := .split 10 q11Shape21T752 q11Shape21T753
private theorem q11Shape21T751OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2823 2228248 q11Shape21T751=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2823 (2228248 ||| 2^10) q11Shape21T752 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2823 ||| 2^10) 2228248 q11Shape21T753)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T752OK,q11Shape21T753OK⟩

private def q11Shape21T695 : Tree 11 := .split 9 q11Shape21T696 q11Shape21T751
private theorem q11Shape21T695OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 2228248 q11Shape21T695=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 (2228248 ||| 2^9) q11Shape21T696 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2311 ||| 2^9) 2228248 q11Shape21T751)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T696OK,q11Shape21T751OK⟩

private def q11Shape21T754 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T754OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2319 2228240 q11Shape21T754=true := by decide

private def q11Shape21T694 : Tree 11 := .split 3 q11Shape21T695 q11Shape21T754
private theorem q11Shape21T694OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 2228240 q11Shape21T694=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2311 (2228240 ||| 2^3) q11Shape21T695 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2311 ||| 2^3) 2228240 q11Shape21T754)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T695OK,q11Shape21T754OK⟩

private def q11Shape21T562 : Tree 11 := .split 2 q11Shape21T563 q11Shape21T694
private theorem q11Shape21T562OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2228240 q11Shape21T562=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 (2228240 ||| 2^2) q11Shape21T563 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2307 ||| 2^2) 2228240 q11Shape21T694)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T563OK,q11Shape21T694OK⟩

private def q11Shape21T758 : Tree 11 := (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape21T758OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2323 2228748 q11Shape21T758=true := by decide

private def q11Shape21T759 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T759OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2835 2228236 q11Shape21T759=true := by decide

private def q11Shape21T757 : Tree 11 := .split 9 q11Shape21T758 q11Shape21T759
private theorem q11Shape21T757OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2323 2228236 q11Shape21T757=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2323 (2228236 ||| 2^9) q11Shape21T758 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2323 ||| 2^9) 2228236 q11Shape21T759)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T758OK,q11Shape21T759OK⟩

private def q11Shape21T760 : Tree 11 := (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape21T760OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2331 2228228 q11Shape21T760=true := by decide

private def q11Shape21T756 : Tree 11 := .split 3 q11Shape21T757 q11Shape21T760
private theorem q11Shape21T756OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2323 2228228 q11Shape21T756=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2323 (2228228 ||| 2^3) q11Shape21T757 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2323 ||| 2^3) 2228228 q11Shape21T760)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T757OK,q11Shape21T760OK⟩

private def q11Shape21T761 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T761OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2327 2228224 q11Shape21T761=true := by decide

private def q11Shape21T755 : Tree 11 := .split 2 q11Shape21T756 q11Shape21T761
private theorem q11Shape21T755OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2323 2228224 q11Shape21T755=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2323 (2228224 ||| 2^2) q11Shape21T756 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2323 ||| 2^2) 2228224 q11Shape21T761)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T756OK,q11Shape21T761OK⟩

private def q11Shape21T561 : Tree 11 := .split 4 q11Shape21T562 q11Shape21T755
private theorem q11Shape21T561OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2228224 q11Shape21T561=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 (2228224 ||| 2^4) q11Shape21T562 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2307 ||| 2^4) 2228224 q11Shape21T755)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T562OK,q11Shape21T755OK⟩

private def q11Shape21T765 : Tree 11 := (.split 9 (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))))
private theorem q11Shape21T765OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133379 2097180 q11Shape21T765=true := by decide

private def q11Shape21T767 : Tree 11 := (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape21T767OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133387 2097684 q11Shape21T767=true := by decide

private def q11Shape21T768 : Tree 11 := (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T768OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133899 2097172 q11Shape21T768=true := by decide

private def q11Shape21T766 : Tree 11 := .split 9 q11Shape21T767 q11Shape21T768
private theorem q11Shape21T766OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133387 2097172 q11Shape21T766=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133387 (2097172 ||| 2^9) q11Shape21T767 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133387 ||| 2^9) 2097172 q11Shape21T768)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T767OK,q11Shape21T768OK⟩

private def q11Shape21T764 : Tree 11 := .split 3 q11Shape21T765 q11Shape21T766
private theorem q11Shape21T764OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133379 2097172 q11Shape21T764=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133379 (2097172 ||| 2^3) q11Shape21T765 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133379 ||| 2^3) 2097172 q11Shape21T766)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T765OK,q11Shape21T766OK⟩

private def q11Shape21T772 : Tree 11 := (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T772OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133383 2098712 q11Shape21T772=true := by decide

private def q11Shape21T773 : Tree 11 := (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {0,3,4,8,9,10})))
private theorem q11Shape21T773OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 134407 2097688 q11Shape21T773=true := by decide

private def q11Shape21T771 : Tree 11 := .split 10 q11Shape21T772 q11Shape21T773
private theorem q11Shape21T771OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133383 2097688 q11Shape21T771=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133383 (2097688 ||| 2^10) q11Shape21T772 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133383 ||| 2^10) 2097688 q11Shape21T773)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T772OK,q11Shape21T773OK⟩

private def q11Shape21T774 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T774OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133895 2097176 q11Shape21T774=true := by decide

private def q11Shape21T770 : Tree 11 := .split 9 q11Shape21T771 q11Shape21T774
private theorem q11Shape21T770OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133383 2097176 q11Shape21T770=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133383 (2097176 ||| 2^9) q11Shape21T771 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133383 ||| 2^9) 2097176 q11Shape21T774)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T771OK,q11Shape21T774OK⟩

private def q11Shape21T775 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T775OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133391 2097168 q11Shape21T775=true := by decide

private def q11Shape21T769 : Tree 11 := .split 3 q11Shape21T770 q11Shape21T775
private theorem q11Shape21T769OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133383 2097168 q11Shape21T769=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133383 (2097168 ||| 2^3) q11Shape21T770 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133383 ||| 2^3) 2097168 q11Shape21T775)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T770OK,q11Shape21T775OK⟩

private def q11Shape21T763 : Tree 11 := .split 2 q11Shape21T764 q11Shape21T769
private theorem q11Shape21T763OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133379 2097168 q11Shape21T763=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133379 (2097168 ||| 2^2) q11Shape21T764 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133379 ||| 2^2) 2097168 q11Shape21T769)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T764OK,q11Shape21T769OK⟩

private def q11Shape21T776 : Tree 11 := (.split 2 (.split 3 (.split 9 (.split 10 (.tip (.cover {0,4,7,8,9,10})) (.split 15 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10})))) (.split 10 (.split 15 (.split 16 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))) (.split 9 (.split 10 (.split 15 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))) (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.cover {0,2,7,8,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))))
private theorem q11Shape21T776OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133395 2097152 q11Shape21T776=true := by decide

private def q11Shape21T762 : Tree 11 := .split 4 q11Shape21T763 q11Shape21T776
private theorem q11Shape21T762OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133379 2097152 q11Shape21T762=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 133379 (2097152 ||| 2^4) q11Shape21T763 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (133379 ||| 2^4) 2097152 q11Shape21T776)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T763OK,q11Shape21T776OK⟩

private def q11Shape21T560 : Tree 11 := .split 17 q11Shape21T561 q11Shape21T762
private theorem q11Shape21T560OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2097152 q11Shape21T560=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 (2097152 ||| 2^17) q11Shape21T561 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2307 ||| 2^17) 2097152 q11Shape21T762)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T561OK,q11Shape21T762OK⟩

def q11Shape21P5 : Tree 11 := q11Shape21T560
theorem q11Shape21P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2307 2097152 q11Shape21P5=true := q11Shape21T560OK

end Graffiti384b.EffectiveSearch.Q11
