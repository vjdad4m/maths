import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T782 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10}))))))
private theorem q11Shape21T782OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097152 3 q11Shape21T782=true := by decide

private def q11Shape21T784 : Tree 11 := (.split 11 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape21T784OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097154 257 q11Shape21T784=true := by decide

private def q11Shape21T787 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T787OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097410 133121 q11Shape21T787=true := by decide

private def q11Shape21T789 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T789OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228482 2065 q11Shape21T789=true := by decide

private def q11Shape21T792 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))
private theorem q11Shape21T792OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228498 2061 q11Shape21T792=true := by decide

private def q11Shape21T793 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {2,4,5,8,9,10})))
private theorem q11Shape21T793OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228506 2053 q11Shape21T793=true := by decide

private def q11Shape21T791 : Tree 11 := .split 3 q11Shape21T792 q11Shape21T793
private theorem q11Shape21T791OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228498 2053 q11Shape21T791=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228498 (2053 ||| 2^3) q11Shape21T792 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228498 ||| 2^3) 2053 q11Shape21T793)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T792OK,q11Shape21T793OK⟩

private def q11Shape21T794 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T794OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228502 2049 q11Shape21T794=true := by decide

private def q11Shape21T790 : Tree 11 := .split 2 q11Shape21T791 q11Shape21T794
private theorem q11Shape21T790OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228498 2049 q11Shape21T790=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228498 (2049 ||| 2^2) q11Shape21T791 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228498 ||| 2^2) 2049 q11Shape21T794)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T791OK,q11Shape21T794OK⟩

private def q11Shape21T788 : Tree 11 := .split 4 q11Shape21T789 q11Shape21T790
private theorem q11Shape21T788OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228482 2049 q11Shape21T788=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228482 (2049 ||| 2^4) q11Shape21T789 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228482 ||| 2^4) 2049 q11Shape21T790)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T789OK,q11Shape21T790OK⟩

private def q11Shape21T786 : Tree 11 := .split 17 q11Shape21T787 q11Shape21T788
private theorem q11Shape21T786OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097410 2049 q11Shape21T786=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097410 (2049 ||| 2^17) q11Shape21T787 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097410 ||| 2^17) 2049 q11Shape21T788)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T787OK,q11Shape21T788OK⟩

private def q11Shape21T796 : Tree 11 := (.split 4 (.tip (.small 1)) (.split 2 (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))))
private theorem q11Shape21T796OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099458 131073 q11Shape21T796=true := by decide

private def q11Shape21T801 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape21T801OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 541 q11Shape21T801=true := by decide

private def q11Shape21T802 : Tree 11 := (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T802OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2231042 29 q11Shape21T802=true := by decide

private def q11Shape21T800 : Tree 11 := .split 9 q11Shape21T801 q11Shape21T802
private theorem q11Shape21T800OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 29 q11Shape21T800=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 (29 ||| 2^9) q11Shape21T801 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230530 ||| 2^9) 29 q11Shape21T802)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T801OK,q11Shape21T802OK⟩

private def q11Shape21T803 : Tree 11 := (.tip (.cover {0,6,7,8,9,10}))
private theorem q11Shape21T803OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230538 21 q11Shape21T803=true := by decide

private def q11Shape21T799 : Tree 11 := .split 3 q11Shape21T800 q11Shape21T803
private theorem q11Shape21T799OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 21 q11Shape21T799=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 (21 ||| 2^3) q11Shape21T800 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230530 ||| 2^3) 21 q11Shape21T803)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T800OK,q11Shape21T803OK⟩

private def q11Shape21T804 : Tree 11 := (.tip (.cover {0,5,7,8,9,10}))
private theorem q11Shape21T804OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230534 17 q11Shape21T804=true := by decide

private def q11Shape21T798 : Tree 11 := .split 2 q11Shape21T799 q11Shape21T804
private theorem q11Shape21T798OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 17 q11Shape21T798=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 (17 ||| 2^2) q11Shape21T799 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230530 ||| 2^2) 17 q11Shape21T804)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T799OK,q11Shape21T804OK⟩

private def q11Shape21T805 : Tree 11 := (.tip (.cover {0,5,7,8,9,10}))
private theorem q11Shape21T805OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230546 1 q11Shape21T805=true := by decide

private def q11Shape21T797 : Tree 11 := .split 4 q11Shape21T798 q11Shape21T805
private theorem q11Shape21T797OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 1 q11Shape21T797=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230530 (1 ||| 2^4) q11Shape21T798 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230530 ||| 2^4) 1 q11Shape21T805)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T798OK,q11Shape21T805OK⟩

private def q11Shape21T795 : Tree 11 := .split 17 q11Shape21T796 q11Shape21T797
private theorem q11Shape21T795OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099458 1 q11Shape21T795=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099458 (1 ||| 2^17) q11Shape21T796 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099458 ||| 2^17) 1 q11Shape21T797)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T796OK,q11Shape21T797OK⟩

private def q11Shape21T785 : Tree 11 := .split 11 q11Shape21T786 q11Shape21T795
private theorem q11Shape21T785OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097410 1 q11Shape21T785=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097410 (1 ||| 2^11) q11Shape21T786 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097410 ||| 2^11) 1 q11Shape21T795)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T786OK,q11Shape21T795OK⟩

private def q11Shape21T783 : Tree 11 := .split 8 q11Shape21T784 q11Shape21T785
private theorem q11Shape21T783OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097154 1 q11Shape21T783=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097154 (1 ||| 2^8) q11Shape21T784 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097154 ||| 2^8) 1 q11Shape21T785)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T784OK,q11Shape21T785OK⟩

private def q11Shape21T781 : Tree 11 := .split 1 q11Shape21T782 q11Shape21T783
private theorem q11Shape21T781OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097152 1 q11Shape21T781=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097152 (1 ||| 2^1) q11Shape21T782 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097152 ||| 2^1) 1 q11Shape21T783)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T782OK,q11Shape21T783OK⟩

def q11Shape21P6 : Tree 11 := q11Shape21T781
theorem q11Shape21P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097152 1 q11Shape21P6=true := q11Shape21T781OK

end Graffiti384b.EffectiveSearch.Q11
