import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T807 : Tree 11 := (.split 11 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape21T807OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097153 258 q11Shape21T807=true := by decide

private def q11Shape21T809 : Tree 11 := (.split 17 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 2 (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,6,8,9,10})))))
private theorem q11Shape21T809OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097409 2050 q11Shape21T809=true := by decide

private def q11Shape21T812 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T812OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099457 131090 q11Shape21T812=true := by decide

private def q11Shape21T815 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,6,8,9,10})))
private theorem q11Shape21T815OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099473 131086 q11Shape21T815=true := by decide

private def q11Shape21T816 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape21T816OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099481 131078 q11Shape21T816=true := by decide

private def q11Shape21T814 : Tree 11 := .split 3 q11Shape21T815 q11Shape21T816
private theorem q11Shape21T814OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099473 131078 q11Shape21T814=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099473 (131078 ||| 2^3) q11Shape21T815 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099473 ||| 2^3) 131078 q11Shape21T816)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T815OK,q11Shape21T816OK⟩

private def q11Shape21T817 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape21T817OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099477 131074 q11Shape21T817=true := by decide

private def q11Shape21T813 : Tree 11 := .split 2 q11Shape21T814 q11Shape21T817
private theorem q11Shape21T813OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099473 131074 q11Shape21T813=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099473 (131074 ||| 2^2) q11Shape21T814 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099473 ||| 2^2) 131074 q11Shape21T817)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T814OK,q11Shape21T817OK⟩

private def q11Shape21T811 : Tree 11 := .split 4 q11Shape21T812 q11Shape21T813
private theorem q11Shape21T811OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099457 131074 q11Shape21T811=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099457 (131074 ||| 2^4) q11Shape21T812 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099457 ||| 2^4) 131074 q11Shape21T813)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T812OK,q11Shape21T813OK⟩

private def q11Shape21T824 : Tree 11 := (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape21T824OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 34334 q11Shape21T824=true := by decide

private def q11Shape21T825 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape21T825OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2263297 1566 q11Shape21T825=true := by decide

private def q11Shape21T823 : Tree 11 := .split 15 q11Shape21T824 q11Shape21T825
private theorem q11Shape21T823OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 1566 q11Shape21T823=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 (1566 ||| 2^15) q11Shape21T824 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230529 ||| 2^15) 1566 q11Shape21T825)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T824OK,q11Shape21T825OK⟩

private def q11Shape21T826 : Tree 11 := (.tip (.cover {1,3,5,8,9,10}))
private theorem q11Shape21T826OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2231553 542 q11Shape21T826=true := by decide

private def q11Shape21T822 : Tree 11 := .split 10 q11Shape21T823 q11Shape21T826
private theorem q11Shape21T822OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 542 q11Shape21T822=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 (542 ||| 2^10) q11Shape21T823 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230529 ||| 2^10) 542 q11Shape21T826)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T823OK,q11Shape21T826OK⟩

private def q11Shape21T827 : Tree 11 := (.tip (.cover {1,3,6,8,9,10}))
private theorem q11Shape21T827OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2231041 30 q11Shape21T827=true := by decide

private def q11Shape21T821 : Tree 11 := .split 9 q11Shape21T822 q11Shape21T827
private theorem q11Shape21T821OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 30 q11Shape21T821=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 (30 ||| 2^9) q11Shape21T822 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230529 ||| 2^9) 30 q11Shape21T827)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T822OK,q11Shape21T827OK⟩

private def q11Shape21T828 : Tree 11 := (.tip (.cover {0,6,7,8,9,10}))
private theorem q11Shape21T828OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230537 22 q11Shape21T828=true := by decide

private def q11Shape21T820 : Tree 11 := .split 3 q11Shape21T821 q11Shape21T828
private theorem q11Shape21T820OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 22 q11Shape21T820=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 (22 ||| 2^3) q11Shape21T821 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230529 ||| 2^3) 22 q11Shape21T828)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T821OK,q11Shape21T828OK⟩

private def q11Shape21T829 : Tree 11 := (.tip (.cover {0,5,7,8,9,10}))
private theorem q11Shape21T829OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230533 18 q11Shape21T829=true := by decide

private def q11Shape21T819 : Tree 11 := .split 2 q11Shape21T820 q11Shape21T829
private theorem q11Shape21T819OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 18 q11Shape21T819=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 (18 ||| 2^2) q11Shape21T820 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230529 ||| 2^2) 18 q11Shape21T829)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T820OK,q11Shape21T829OK⟩

private def q11Shape21T830 : Tree 11 := (.tip (.cover {0,5,7,8,9,10}))
private theorem q11Shape21T830OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230545 2 q11Shape21T830=true := by decide

private def q11Shape21T818 : Tree 11 := .split 4 q11Shape21T819 q11Shape21T830
private theorem q11Shape21T818OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 2 q11Shape21T818=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230529 (2 ||| 2^4) q11Shape21T819 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230529 ||| 2^4) 2 q11Shape21T830)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T819OK,q11Shape21T830OK⟩

private def q11Shape21T810 : Tree 11 := .split 17 q11Shape21T811 q11Shape21T818
private theorem q11Shape21T810OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099457 2 q11Shape21T810=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099457 (2 ||| 2^17) q11Shape21T811 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099457 ||| 2^17) 2 q11Shape21T818)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T811OK,q11Shape21T818OK⟩

private def q11Shape21T808 : Tree 11 := .split 11 q11Shape21T809 q11Shape21T810
private theorem q11Shape21T808OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097409 2 q11Shape21T808=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097409 (2 ||| 2^11) q11Shape21T809 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097409 ||| 2^11) 2 q11Shape21T810)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T809OK,q11Shape21T810OK⟩

private def q11Shape21T806 : Tree 11 := .split 8 q11Shape21T807 q11Shape21T808
private theorem q11Shape21T806OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097153 2 q11Shape21T806=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097153 (2 ||| 2^8) q11Shape21T807 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097153 ||| 2^8) 2 q11Shape21T808)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T807OK,q11Shape21T808OK⟩

def q11Shape21P7 : Tree 11 := q11Shape21T806
theorem q11Shape21P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097153 2 q11Shape21P7=true := q11Shape21T806OK

end Graffiti384b.EffectiveSearch.Q11
