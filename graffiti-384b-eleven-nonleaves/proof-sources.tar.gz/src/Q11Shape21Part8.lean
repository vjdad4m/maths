import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape21T834 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T834OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 133376 q11Shape21T834=true := by decide

private def q11Shape21T836 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T836OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228227 2320 q11Shape21T836=true := by decide

private def q11Shape21T842 : Tree 11 := (.split 16 (.tip (.small 0)) (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape21T842OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 36620 q11Shape21T842=true := by decide

private def q11Shape21T843 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape21T843OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2261011 3852 q11Shape21T843=true := by decide

private def q11Shape21T841 : Tree 11 := .split 15 q11Shape21T842 q11Shape21T843
private theorem q11Shape21T841OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 3852 q11Shape21T841=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 (3852 ||| 2^15) q11Shape21T842 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228243 ||| 2^15) 3852 q11Shape21T843)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T842OK,q11Shape21T843OK⟩

private def q11Shape21T844 : Tree 11 := (.tip (.cover {0,6,7,8,9,10}))
private theorem q11Shape21T844OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229267 2828 q11Shape21T844=true := by decide

private def q11Shape21T840 : Tree 11 := .split 10 q11Shape21T841 q11Shape21T844
private theorem q11Shape21T840OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 2828 q11Shape21T840=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 (2828 ||| 2^10) q11Shape21T841 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228243 ||| 2^10) 2828 q11Shape21T844)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T841OK,q11Shape21T844OK⟩

private def q11Shape21T845 : Tree 11 := (.tip (.cover {0,5,7,8,9,10}))
private theorem q11Shape21T845OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228755 2316 q11Shape21T845=true := by decide

private def q11Shape21T839 : Tree 11 := .split 9 q11Shape21T840 q11Shape21T845
private theorem q11Shape21T839OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 2316 q11Shape21T839=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 (2316 ||| 2^9) q11Shape21T840 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228243 ||| 2^9) 2316 q11Shape21T845)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T840OK,q11Shape21T845OK⟩

private def q11Shape21T846 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T846OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228251 2308 q11Shape21T846=true := by decide

private def q11Shape21T838 : Tree 11 := .split 3 q11Shape21T839 q11Shape21T846
private theorem q11Shape21T838OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 2308 q11Shape21T838=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 (2308 ||| 2^3) q11Shape21T839 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228243 ||| 2^3) 2308 q11Shape21T846)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T839OK,q11Shape21T846OK⟩

private def q11Shape21T847 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T847OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228247 2304 q11Shape21T847=true := by decide

private def q11Shape21T837 : Tree 11 := .split 2 q11Shape21T838 q11Shape21T847
private theorem q11Shape21T837OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 2304 q11Shape21T837=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228243 (2304 ||| 2^2) q11Shape21T838 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228243 ||| 2^2) 2304 q11Shape21T847)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T838OK,q11Shape21T847OK⟩

private def q11Shape21T835 : Tree 11 := .split 4 q11Shape21T836 q11Shape21T837
private theorem q11Shape21T835OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228227 2304 q11Shape21T835=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228227 (2304 ||| 2^4) q11Shape21T836 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228227 ||| 2^4) 2304 q11Shape21T837)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T836OK,q11Shape21T837OK⟩

private def q11Shape21T833 : Tree 11 := .split 17 q11Shape21T834 q11Shape21T835
private theorem q11Shape21T833OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 2304 q11Shape21T833=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 (2304 ||| 2^17) q11Shape21T834 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097155 ||| 2^17) 2304 q11Shape21T835)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T834OK,q11Shape21T835OK⟩

private def q11Shape21T850 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T850OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099203 131344 q11Shape21T850=true := by decide

private def q11Shape21T854 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {2,3,5,8,9,10}))))
private theorem q11Shape21T854OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099219 131852 q11Shape21T854=true := by decide

private def q11Shape21T855 : Tree 11 := (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape21T855OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099731 131340 q11Shape21T855=true := by decide

private def q11Shape21T853 : Tree 11 := .split 9 q11Shape21T854 q11Shape21T855
private theorem q11Shape21T853OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099219 131340 q11Shape21T853=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099219 (131340 ||| 2^9) q11Shape21T854 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099219 ||| 2^9) 131340 q11Shape21T855)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T854OK,q11Shape21T855OK⟩

private def q11Shape21T856 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T856OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099227 131332 q11Shape21T856=true := by decide

private def q11Shape21T852 : Tree 11 := .split 3 q11Shape21T853 q11Shape21T856
private theorem q11Shape21T852OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099219 131332 q11Shape21T852=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099219 (131332 ||| 2^3) q11Shape21T853 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099219 ||| 2^3) 131332 q11Shape21T856)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T853OK,q11Shape21T856OK⟩

private def q11Shape21T857 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T857OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099223 131328 q11Shape21T857=true := by decide

private def q11Shape21T851 : Tree 11 := .split 2 q11Shape21T852 q11Shape21T857
private theorem q11Shape21T851OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099219 131328 q11Shape21T851=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099219 (131328 ||| 2^2) q11Shape21T852 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099219 ||| 2^2) 131328 q11Shape21T857)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T852OK,q11Shape21T857OK⟩

private def q11Shape21T849 : Tree 11 := .split 4 q11Shape21T850 q11Shape21T851
private theorem q11Shape21T849OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099203 131328 q11Shape21T849=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099203 (131328 ||| 2^4) q11Shape21T850 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099203 ||| 2^4) 131328 q11Shape21T851)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T850OK,q11Shape21T851OK⟩

private def q11Shape21T858 : Tree 11 := (.split 4 (.split 2 (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {3,4,5,8,9,10}))) (.tip (.cover {3,4,6,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))
private theorem q11Shape21T858OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230275 256 q11Shape21T858=true := by decide

private def q11Shape21T848 : Tree 11 := .split 17 q11Shape21T849 q11Shape21T858
private theorem q11Shape21T848OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099203 256 q11Shape21T848=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099203 (256 ||| 2^17) q11Shape21T849 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099203 ||| 2^17) 256 q11Shape21T858)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T849OK,q11Shape21T858OK⟩

private def q11Shape21T832 : Tree 11 := .split 11 q11Shape21T833 q11Shape21T848
private theorem q11Shape21T832OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 256 q11Shape21T832=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 (256 ||| 2^11) q11Shape21T833 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097155 ||| 2^11) 256 q11Shape21T848)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T833OK,q11Shape21T848OK⟩

private def q11Shape21T862 : Tree 11 := (.tip (.small 1))
private theorem q11Shape21T862OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097411 133136 q11Shape21T862=true := by decide

private def q11Shape21T881 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.split 20 (.tip (.cover {0,1,2,5,8,9})) (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.split 6 (.tip (.cover {0,4,5,7,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape21T881OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 8585977356 q11Shape21T881=true := by decide

private def q11Shape21T882 : Tree 11 := (.split 13 (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))) (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,2,5,8,9})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.split 6 (.tip (.cover {0,3,5,7,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape21T882OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2101523 8585973260 q11Shape21T882=true := by decide

private def q11Shape21T880 : Tree 11 := .split 12 q11Shape21T881 q11Shape21T882
private theorem q11Shape21T880OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 8585973260 q11Shape21T880=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (8585973260 ||| 2^12) q11Shape21T881 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^12) 8585973260 q11Shape21T882)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T881OK,q11Shape21T882OK⟩

private def q11Shape21T883 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T883OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4297064723 4291005964 q11Shape21T883=true := by decide

private def q11Shape21T879 : Tree 11 := .split 32 q11Shape21T880 q11Shape21T883
private theorem q11Shape21T879OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 4291005964 q11Shape21T879=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (4291005964 ||| 2^32) q11Shape21T880 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^32) 4291005964 q11Shape21T883)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T880OK,q11Shape21T883OK⟩

private def q11Shape21T884 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T884OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2149581075 2143522316 q11Shape21T884=true := by decide

private def q11Shape21T878 : Tree 11 := .split 31 q11Shape21T879 q11Shape21T884
private theorem q11Shape21T878OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 2143522316 q11Shape21T878=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (2143522316 ||| 2^31) q11Shape21T879 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^31) 2143522316 q11Shape21T884)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T879OK,q11Shape21T884OK⟩

private def q11Shape21T885 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T885OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075839251 1069780492 q11Shape21T885=true := by decide

private def q11Shape21T877 : Tree 11 := .split 30 q11Shape21T878 q11Shape21T885
private theorem q11Shape21T877OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 1069780492 q11Shape21T877=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (1069780492 ||| 2^30) q11Shape21T878 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^30) 1069780492 q11Shape21T885)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T878OK,q11Shape21T885OK⟩

private def q11Shape21T886 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T886OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 538968339 532909580 q11Shape21T886=true := by decide

private def q11Shape21T876 : Tree 11 := .split 29 q11Shape21T877 q11Shape21T886
private theorem q11Shape21T876OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 532909580 q11Shape21T876=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (532909580 ||| 2^29) q11Shape21T877 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^29) 532909580 q11Shape21T886)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T877OK,q11Shape21T886OK⟩

private def q11Shape21T887 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T887OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270532883 264474124 q11Shape21T887=true := by decide

private def q11Shape21T875 : Tree 11 := .split 28 q11Shape21T876 q11Shape21T887
private theorem q11Shape21T875OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 264474124 q11Shape21T875=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (264474124 ||| 2^28) q11Shape21T876 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^28) 264474124 q11Shape21T887)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T876OK,q11Shape21T887OK⟩

private def q11Shape21T888 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T888OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136315155 130256396 q11Shape21T888=true := by decide

private def q11Shape21T874 : Tree 11 := .split 27 q11Shape21T875 q11Shape21T888
private theorem q11Shape21T874OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 130256396 q11Shape21T874=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (130256396 ||| 2^27) q11Shape21T875 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^27) 130256396 q11Shape21T888)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T875OK,q11Shape21T888OK⟩

private def q11Shape21T889 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T889OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35651859 96701964 q11Shape21T889=true := by decide

private def q11Shape21T873 : Tree 11 := .split 25 q11Shape21T874 q11Shape21T889
private theorem q11Shape21T873OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 96701964 q11Shape21T873=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (96701964 ||| 2^25) q11Shape21T874 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^25) 96701964 q11Shape21T889)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T874OK,q11Shape21T889OK⟩

private def q11Shape21T890 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T890OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 18874643 79924748 q11Shape21T890=true := by decide

private def q11Shape21T872 : Tree 11 := .split 24 q11Shape21T873 q11Shape21T890
private theorem q11Shape21T872OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 79924748 q11Shape21T872=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (79924748 ||| 2^24) q11Shape21T873 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^24) 79924748 q11Shape21T890)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T873OK,q11Shape21T890OK⟩

private def q11Shape21T891 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T891OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10486035 71536140 q11Shape21T891=true := by decide

private def q11Shape21T871 : Tree 11 := .split 23 q11Shape21T872 q11Shape21T891
private theorem q11Shape21T871OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 71536140 q11Shape21T871=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (71536140 ||| 2^23) q11Shape21T872 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^23) 71536140 q11Shape21T891)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T872OK,q11Shape21T891OK⟩

private def q11Shape21T892 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T892OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6291731 67341836 q11Shape21T892=true := by decide

private def q11Shape21T870 : Tree 11 := .split 22 q11Shape21T871 q11Shape21T892
private theorem q11Shape21T870OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 67341836 q11Shape21T870=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (67341836 ||| 2^22) q11Shape21T871 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^22) 67341836 q11Shape21T892)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T871OK,q11Shape21T892OK⟩

private def q11Shape21T893 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T893OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69206291 232972 q11Shape21T893=true := by decide

private def q11Shape21T869 : Tree 11 := .split 26 q11Shape21T870 q11Shape21T893
private theorem q11Shape21T869OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 232972 q11Shape21T869=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (232972 ||| 2^26) q11Shape21T870 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^26) 232972 q11Shape21T893)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T870OK,q11Shape21T893OK⟩

private def q11Shape21T894 : Tree 11 := (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,7,9,10})) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {1,2,5,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape21T894OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2162963 167436 q11Shape21T894=true := by decide

private def q11Shape21T868 : Tree 11 := .split 16 q11Shape21T869 q11Shape21T894
private theorem q11Shape21T868OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 167436 q11Shape21T868=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (167436 ||| 2^16) q11Shape21T869 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^16) 167436 q11Shape21T894)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T869OK,q11Shape21T894OK⟩

private def q11Shape21T895 : Tree 11 := (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,6,7,9,10})) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {1,2,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape21T895OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2130195 134668 q11Shape21T895=true := by decide

private def q11Shape21T867 : Tree 11 := .split 15 q11Shape21T868 q11Shape21T895
private theorem q11Shape21T867OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 134668 q11Shape21T867=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (134668 ||| 2^15) q11Shape21T868 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^15) 134668 q11Shape21T895)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T868OK,q11Shape21T895OK⟩

private def q11Shape21T907 : Tree 11 := (.split 31 (.split 32 (.split 12 (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,5,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,5,7,8,9,10})))) (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,5,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,5,7,8,9,10}))))) (.split 13 (.split 14 (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10}))) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10})))) (.split 14 (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10}))) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10})))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape21T907OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 2143521292 q11Shape21T907=true := by decide

private def q11Shape21T908 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T908OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075840275 1069779468 q11Shape21T908=true := by decide

private def q11Shape21T906 : Tree 11 := .split 30 q11Shape21T907 q11Shape21T908
private theorem q11Shape21T906OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 1069779468 q11Shape21T906=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (1069779468 ||| 2^30) q11Shape21T907 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^30) 1069779468 q11Shape21T908)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T907OK,q11Shape21T908OK⟩

private def q11Shape21T909 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T909OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 538969363 532908556 q11Shape21T909=true := by decide

private def q11Shape21T905 : Tree 11 := .split 29 q11Shape21T906 q11Shape21T909
private theorem q11Shape21T905OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 532908556 q11Shape21T905=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (532908556 ||| 2^29) q11Shape21T906 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^29) 532908556 q11Shape21T909)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T906OK,q11Shape21T909OK⟩

private def q11Shape21T910 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T910OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270533907 264473100 q11Shape21T910=true := by decide

private def q11Shape21T904 : Tree 11 := .split 28 q11Shape21T905 q11Shape21T910
private theorem q11Shape21T904OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 264473100 q11Shape21T904=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (264473100 ||| 2^28) q11Shape21T905 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^28) 264473100 q11Shape21T910)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T905OK,q11Shape21T910OK⟩

private def q11Shape21T911 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T911OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136316179 130255372 q11Shape21T911=true := by decide

private def q11Shape21T903 : Tree 11 := .split 27 q11Shape21T904 q11Shape21T911
private theorem q11Shape21T903OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 130255372 q11Shape21T903=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (130255372 ||| 2^27) q11Shape21T904 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^27) 130255372 q11Shape21T911)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T904OK,q11Shape21T911OK⟩

private def q11Shape21T912 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T912OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35652883 96700940 q11Shape21T912=true := by decide

private def q11Shape21T902 : Tree 11 := .split 25 q11Shape21T903 q11Shape21T912
private theorem q11Shape21T902OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 96700940 q11Shape21T902=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (96700940 ||| 2^25) q11Shape21T903 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^25) 96700940 q11Shape21T912)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T903OK,q11Shape21T912OK⟩

private def q11Shape21T913 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T913OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 18875667 79923724 q11Shape21T913=true := by decide

private def q11Shape21T901 : Tree 11 := .split 24 q11Shape21T902 q11Shape21T913
private theorem q11Shape21T901OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 79923724 q11Shape21T901=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (79923724 ||| 2^24) q11Shape21T902 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^24) 79923724 q11Shape21T913)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T902OK,q11Shape21T913OK⟩

private def q11Shape21T914 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T914OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10487059 71535116 q11Shape21T914=true := by decide

private def q11Shape21T900 : Tree 11 := .split 23 q11Shape21T901 q11Shape21T914
private theorem q11Shape21T900OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 71535116 q11Shape21T900=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (71535116 ||| 2^23) q11Shape21T901 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^23) 71535116 q11Shape21T914)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T901OK,q11Shape21T914OK⟩

private def q11Shape21T915 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T915OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6292755 67340812 q11Shape21T915=true := by decide

private def q11Shape21T899 : Tree 11 := .split 22 q11Shape21T900 q11Shape21T915
private theorem q11Shape21T899OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 67340812 q11Shape21T899=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (67340812 ||| 2^22) q11Shape21T900 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^22) 67340812 q11Shape21T915)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T900OK,q11Shape21T915OK⟩

private def q11Shape21T916 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T916OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69207315 231948 q11Shape21T916=true := by decide

private def q11Shape21T898 : Tree 11 := .split 26 q11Shape21T899 q11Shape21T916
private theorem q11Shape21T898OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 231948 q11Shape21T898=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (231948 ||| 2^26) q11Shape21T899 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^26) 231948 q11Shape21T916)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T899OK,q11Shape21T916OK⟩

private def q11Shape21T917 : Tree 11 := (.tip (.cover {0,6,7,8,9,10}))
private theorem q11Shape21T917OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2163987 166412 q11Shape21T917=true := by decide

private def q11Shape21T897 : Tree 11 := .split 16 q11Shape21T898 q11Shape21T917
private theorem q11Shape21T897OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 166412 q11Shape21T897=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (166412 ||| 2^16) q11Shape21T898 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^16) 166412 q11Shape21T917)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T898OK,q11Shape21T917OK⟩

private def q11Shape21T918 : Tree 11 := (.tip (.cover {3,5,7,8,9,10}))
private theorem q11Shape21T918OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2131219 133644 q11Shape21T918=true := by decide

private def q11Shape21T896 : Tree 11 := .split 15 q11Shape21T897 q11Shape21T918
private theorem q11Shape21T896OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 133644 q11Shape21T896=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098451 (133644 ||| 2^15) q11Shape21T897 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2098451 ||| 2^15) 133644 q11Shape21T918)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T897OK,q11Shape21T918OK⟩

private def q11Shape21T866 : Tree 11 := .split 10 q11Shape21T867 q11Shape21T896
private theorem q11Shape21T866OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 133644 q11Shape21T866=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (133644 ||| 2^10) q11Shape21T867 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^10) 133644 q11Shape21T896)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T867OK,q11Shape21T896OK⟩

private def q11Shape21T931 : Tree 11 := (.split 31 (.split 32 (.split 12 (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,6,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,6,7,8,9,10})))) (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,6,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,6,7,8,9,10}))))) (.split 13 (.split 14 (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10})))) (.split 14 (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10})))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape21T931OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 2143521804 q11Shape21T931=true := by decide

private def q11Shape21T932 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T932OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075839763 1069779980 q11Shape21T932=true := by decide

private def q11Shape21T930 : Tree 11 := .split 30 q11Shape21T931 q11Shape21T932
private theorem q11Shape21T930OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 1069779980 q11Shape21T930=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (1069779980 ||| 2^30) q11Shape21T931 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^30) 1069779980 q11Shape21T932)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T931OK,q11Shape21T932OK⟩

private def q11Shape21T933 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T933OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 538968851 532909068 q11Shape21T933=true := by decide

private def q11Shape21T929 : Tree 11 := .split 29 q11Shape21T930 q11Shape21T933
private theorem q11Shape21T929OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 532909068 q11Shape21T929=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (532909068 ||| 2^29) q11Shape21T930 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^29) 532909068 q11Shape21T933)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T930OK,q11Shape21T933OK⟩

private def q11Shape21T934 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T934OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270533395 264473612 q11Shape21T934=true := by decide

private def q11Shape21T928 : Tree 11 := .split 28 q11Shape21T929 q11Shape21T934
private theorem q11Shape21T928OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 264473612 q11Shape21T928=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (264473612 ||| 2^28) q11Shape21T929 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^28) 264473612 q11Shape21T934)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T929OK,q11Shape21T934OK⟩

private def q11Shape21T935 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T935OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136315667 130255884 q11Shape21T935=true := by decide

private def q11Shape21T927 : Tree 11 := .split 27 q11Shape21T928 q11Shape21T935
private theorem q11Shape21T927OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 130255884 q11Shape21T927=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (130255884 ||| 2^27) q11Shape21T928 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^27) 130255884 q11Shape21T935)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T928OK,q11Shape21T935OK⟩

private def q11Shape21T936 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T936OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35652371 96701452 q11Shape21T936=true := by decide

private def q11Shape21T926 : Tree 11 := .split 25 q11Shape21T927 q11Shape21T936
private theorem q11Shape21T926OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 96701452 q11Shape21T926=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (96701452 ||| 2^25) q11Shape21T927 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^25) 96701452 q11Shape21T936)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T927OK,q11Shape21T936OK⟩

private def q11Shape21T937 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T937OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 18875155 79924236 q11Shape21T937=true := by decide

private def q11Shape21T925 : Tree 11 := .split 24 q11Shape21T926 q11Shape21T937
private theorem q11Shape21T925OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 79924236 q11Shape21T925=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (79924236 ||| 2^24) q11Shape21T926 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^24) 79924236 q11Shape21T937)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T926OK,q11Shape21T937OK⟩

private def q11Shape21T938 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T938OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10486547 71535628 q11Shape21T938=true := by decide

private def q11Shape21T924 : Tree 11 := .split 23 q11Shape21T925 q11Shape21T938
private theorem q11Shape21T924OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 71535628 q11Shape21T924=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (71535628 ||| 2^23) q11Shape21T925 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^23) 71535628 q11Shape21T938)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T925OK,q11Shape21T938OK⟩

private def q11Shape21T939 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T939OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6292243 67341324 q11Shape21T939=true := by decide

private def q11Shape21T923 : Tree 11 := .split 22 q11Shape21T924 q11Shape21T939
private theorem q11Shape21T923OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 67341324 q11Shape21T923=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (67341324 ||| 2^22) q11Shape21T924 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^22) 67341324 q11Shape21T939)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T924OK,q11Shape21T939OK⟩

private def q11Shape21T940 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T940OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69206803 232460 q11Shape21T940=true := by decide

private def q11Shape21T922 : Tree 11 := .split 26 q11Shape21T923 q11Shape21T940
private theorem q11Shape21T922OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 232460 q11Shape21T922=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (232460 ||| 2^26) q11Shape21T923 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^26) 232460 q11Shape21T940)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T923OK,q11Shape21T940OK⟩

private def q11Shape21T941 : Tree 11 := (.tip (.cover {3,6,7,8,9,10}))
private theorem q11Shape21T941OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2163475 166924 q11Shape21T941=true := by decide

private def q11Shape21T921 : Tree 11 := .split 16 q11Shape21T922 q11Shape21T941
private theorem q11Shape21T921OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 166924 q11Shape21T921=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (166924 ||| 2^16) q11Shape21T922 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^16) 166924 q11Shape21T941)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T922OK,q11Shape21T941OK⟩

private def q11Shape21T942 : Tree 11 := (.tip (.cover {0,5,7,8,9,10}))
private theorem q11Shape21T942OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2130707 134156 q11Shape21T942=true := by decide

private def q11Shape21T920 : Tree 11 := .split 15 q11Shape21T921 q11Shape21T942
private theorem q11Shape21T920OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 134156 q11Shape21T920=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (134156 ||| 2^15) q11Shape21T921 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^15) 134156 q11Shape21T942)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T921OK,q11Shape21T942OK⟩

private def q11Shape21T943 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T943OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2098963 133132 q11Shape21T943=true := by decide

private def q11Shape21T919 : Tree 11 := .split 10 q11Shape21T920 q11Shape21T943
private theorem q11Shape21T919OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 133132 q11Shape21T919=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097939 (133132 ||| 2^10) q11Shape21T920 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097939 ||| 2^10) 133132 q11Shape21T943)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T920OK,q11Shape21T943OK⟩

private def q11Shape21T865 : Tree 11 := .split 9 q11Shape21T866 q11Shape21T919
private theorem q11Shape21T865OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 133132 q11Shape21T865=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (133132 ||| 2^9) q11Shape21T866 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^9) 133132 q11Shape21T919)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T866OK,q11Shape21T919OK⟩

private def q11Shape21T944 : Tree 11 := (.tip (.cover {1,2,5,8,9,10}))
private theorem q11Shape21T944OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097435 133124 q11Shape21T944=true := by decide

private def q11Shape21T864 : Tree 11 := .split 3 q11Shape21T865 q11Shape21T944
private theorem q11Shape21T864OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 133124 q11Shape21T864=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (133124 ||| 2^3) q11Shape21T865 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^3) 133124 q11Shape21T944)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T865OK,q11Shape21T944OK⟩

private def q11Shape21T945 : Tree 11 := (.tip (.cover {1,2,6,8,9,10}))
private theorem q11Shape21T945OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097431 133120 q11Shape21T945=true := by decide

private def q11Shape21T863 : Tree 11 := .split 2 q11Shape21T864 q11Shape21T945
private theorem q11Shape21T863OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 133120 q11Shape21T863=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097427 (133120 ||| 2^2) q11Shape21T864 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097427 ||| 2^2) 133120 q11Shape21T945)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T864OK,q11Shape21T945OK⟩

private def q11Shape21T861 : Tree 11 := .split 4 q11Shape21T862 q11Shape21T863
private theorem q11Shape21T861OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097411 133120 q11Shape21T861=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097411 (133120 ||| 2^4) q11Shape21T862 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097411 ||| 2^4) 133120 q11Shape21T863)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T862OK,q11Shape21T863OK⟩

private def q11Shape21T966 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.split 20 (.tip (.cover {0,2,5,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.split 6 (.tip (.cover {0,1,4,5,8,10})) (.tip (.cover {2,4,5,6,7,10}))))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))))))
private theorem q11Shape21T966OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 8585854492 q11Shape21T966=true := by decide

private def q11Shape21T967 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.drop {1,4,6,7} (fun x => if x = 1 then some 0 else if x = 4 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none))) (.tip (.cover {0,5,7,8,9,10}))) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T967OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2236675 8585846300 q11Shape21T967=true := by decide

private def q11Shape21T965 : Tree 11 := .split 13 q11Shape21T966 q11Shape21T967
private theorem q11Shape21T965OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 8585846300 q11Shape21T965=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (8585846300 ||| 2^13) q11Shape21T966 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^13) 8585846300 q11Shape21T967)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T966OK,q11Shape21T967OK⟩

private def q11Shape21T969 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.tip (.drop {1,3,6,7} (fun x => if x = 1 then some 0 else if x = 3 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none)))))) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.drop {1,3,6,7} (fun x => if x = 1 then some 0 else if x = 3 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none))) (.tip (.cover {0,5,7,8,9,10})))))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10}))))) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.split 6 (.tip (.cover {0,1,4,5,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,9}))))))
private theorem q11Shape21T969OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2232579 8585850396 q11Shape21T969=true := by decide

private def q11Shape21T971 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.drop {1,4,6,7} (fun x => if x = 1 then some 0 else if x = 4 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none))) (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10}))))) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.split 6 (.tip (.cover {0,3,5,7,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))) (.tip (.cover {3,4,5,6,7,10}))))
private theorem q11Shape21T971OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2240771 8585858588 q11Shape21T971=true := by decide

private def q11Shape21T972 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.drop {1,4,6,7} (fun x => if x = 1 then some 0 else if x = 4 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none))) (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.split 5 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.split 6 (.tip (.cover {0,3,5,7,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))
private theorem q11Shape21T972OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2257155 8585842204 q11Shape21T972=true := by decide

private def q11Shape21T970 : Tree 11 := .split 14 q11Shape21T971 q11Shape21T972
private theorem q11Shape21T970OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2240771 8585842204 q11Shape21T970=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2240771 (8585842204 ||| 2^14) q11Shape21T971 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2240771 ||| 2^14) 8585842204 q11Shape21T972)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T971OK,q11Shape21T972OK⟩

private def q11Shape21T968 : Tree 11 := .split 13 q11Shape21T969 q11Shape21T970
private theorem q11Shape21T968OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2232579 8585842204 q11Shape21T968=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2232579 (8585842204 ||| 2^13) q11Shape21T969 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2232579 ||| 2^13) 8585842204 q11Shape21T970)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T969OK,q11Shape21T970OK⟩

private def q11Shape21T964 : Tree 11 := .split 12 q11Shape21T965 q11Shape21T968
private theorem q11Shape21T964OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 8585842204 q11Shape21T964=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (8585842204 ||| 2^12) q11Shape21T965 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^12) 8585842204 q11Shape21T968)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T965OK,q11Shape21T968OK⟩

private def q11Shape21T973 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T973OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4297195779 4290874908 q11Shape21T973=true := by decide

private def q11Shape21T963 : Tree 11 := .split 32 q11Shape21T964 q11Shape21T973
private theorem q11Shape21T963OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 4290874908 q11Shape21T963=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (4290874908 ||| 2^32) q11Shape21T964 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^32) 4290874908 q11Shape21T973)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T964OK,q11Shape21T973OK⟩

private def q11Shape21T974 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T974OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2149712131 2143391260 q11Shape21T974=true := by decide

private def q11Shape21T962 : Tree 11 := .split 31 q11Shape21T963 q11Shape21T974
private theorem q11Shape21T962OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 2143391260 q11Shape21T962=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (2143391260 ||| 2^31) q11Shape21T963 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^31) 2143391260 q11Shape21T974)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T963OK,q11Shape21T974OK⟩

private def q11Shape21T975 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T975OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075970307 1069649436 q11Shape21T975=true := by decide

private def q11Shape21T961 : Tree 11 := .split 30 q11Shape21T962 q11Shape21T975
private theorem q11Shape21T961OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 1069649436 q11Shape21T961=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (1069649436 ||| 2^30) q11Shape21T962 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^30) 1069649436 q11Shape21T975)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T962OK,q11Shape21T975OK⟩

private def q11Shape21T976 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T976OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 539099395 532778524 q11Shape21T976=true := by decide

private def q11Shape21T960 : Tree 11 := .split 29 q11Shape21T961 q11Shape21T976
private theorem q11Shape21T960OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 532778524 q11Shape21T960=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (532778524 ||| 2^29) q11Shape21T961 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^29) 532778524 q11Shape21T976)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T961OK,q11Shape21T976OK⟩

private def q11Shape21T977 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T977OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270663939 264343068 q11Shape21T977=true := by decide

private def q11Shape21T959 : Tree 11 := .split 28 q11Shape21T960 q11Shape21T977
private theorem q11Shape21T959OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 264343068 q11Shape21T959=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (264343068 ||| 2^28) q11Shape21T960 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^28) 264343068 q11Shape21T977)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T960OK,q11Shape21T977OK⟩

private def q11Shape21T978 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T978OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136446211 130125340 q11Shape21T978=true := by decide

private def q11Shape21T958 : Tree 11 := .split 27 q11Shape21T959 q11Shape21T978
private theorem q11Shape21T958OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 130125340 q11Shape21T958=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (130125340 ||| 2^27) q11Shape21T959 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^27) 130125340 q11Shape21T978)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T959OK,q11Shape21T978OK⟩

private def q11Shape21T979 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T979OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35782915 96570908 q11Shape21T979=true := by decide

private def q11Shape21T957 : Tree 11 := .split 25 q11Shape21T958 q11Shape21T979
private theorem q11Shape21T957OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 96570908 q11Shape21T957=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (96570908 ||| 2^25) q11Shape21T958 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^25) 96570908 q11Shape21T979)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T958OK,q11Shape21T979OK⟩

private def q11Shape21T980 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T980OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 19005699 79793692 q11Shape21T980=true := by decide

private def q11Shape21T956 : Tree 11 := .split 24 q11Shape21T957 q11Shape21T980
private theorem q11Shape21T956OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 79793692 q11Shape21T956=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (79793692 ||| 2^24) q11Shape21T957 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^24) 79793692 q11Shape21T980)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T957OK,q11Shape21T980OK⟩

private def q11Shape21T981 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T981OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10617091 71405084 q11Shape21T981=true := by decide

private def q11Shape21T955 : Tree 11 := .split 23 q11Shape21T956 q11Shape21T981
private theorem q11Shape21T955OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 71405084 q11Shape21T955=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (71405084 ||| 2^23) q11Shape21T956 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^23) 71405084 q11Shape21T981)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T956OK,q11Shape21T981OK⟩

private def q11Shape21T982 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T982OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6422787 67210780 q11Shape21T982=true := by decide

private def q11Shape21T954 : Tree 11 := .split 22 q11Shape21T955 q11Shape21T982
private theorem q11Shape21T954OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 67210780 q11Shape21T954=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (67210780 ||| 2^22) q11Shape21T955 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^22) 67210780 q11Shape21T982)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T955OK,q11Shape21T982OK⟩

private def q11Shape21T983 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T983OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69337347 101916 q11Shape21T983=true := by decide

private def q11Shape21T953 : Tree 11 := .split 26 q11Shape21T954 q11Shape21T983
private theorem q11Shape21T953OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 101916 q11Shape21T953=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (101916 ||| 2^26) q11Shape21T954 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^26) 101916 q11Shape21T983)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T954OK,q11Shape21T983OK⟩

private def q11Shape21T984 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T984OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2294019 36380 q11Shape21T984=true := by decide

private def q11Shape21T952 : Tree 11 := .split 16 q11Shape21T953 q11Shape21T984
private theorem q11Shape21T952OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 36380 q11Shape21T952=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (36380 ||| 2^16) q11Shape21T953 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^16) 36380 q11Shape21T984)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T953OK,q11Shape21T984OK⟩

private def q11Shape21T985 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T985OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2261251 3612 q11Shape21T985=true := by decide

private def q11Shape21T951 : Tree 11 := .split 15 q11Shape21T952 q11Shape21T985
private theorem q11Shape21T951OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 3612 q11Shape21T951=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (3612 ||| 2^15) q11Shape21T952 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^15) 3612 q11Shape21T985)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T952OK,q11Shape21T985OK⟩

private def q11Shape21T1000 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.split 19 (.tip (.cover {2,3,5,7,8,10})) (.split 20 (.tip (.cover {2,3,5,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {3,5,7,8,9,10})))))) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.split 19 (.tip (.cover {2,3,5,7,8,10})) (.split 20 (.tip (.cover {2,3,5,7,8,9})) (.tip (.cover {3,4,5,7,8,9})))))) (.split 14 (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.split 19 (.tip (.cover {2,3,5,7,8,10})) (.tip (.cover {3,4,5,7,8,10})))) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.split 19 (.tip (.cover {2,3,5,7,8,10})) (.tip (.cover {3,4,5,7,8,10}))))))
private theorem q11Shape21T1000OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 8585845276 q11Shape21T1000=true := by decide

private def q11Shape21T1001 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10}))) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10})))) (.split 14 (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10}))) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {3,4,5,7,9,10})))))
private theorem q11Shape21T1001OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2233603 8585841180 q11Shape21T1001=true := by decide

private def q11Shape21T999 : Tree 11 := .split 12 q11Shape21T1000 q11Shape21T1001
private theorem q11Shape21T999OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 8585841180 q11Shape21T999=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (8585841180 ||| 2^12) q11Shape21T1000 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^12) 8585841180 q11Shape21T1001)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1000OK,q11Shape21T1001OK⟩

private def q11Shape21T1002 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1002OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4297196803 4290873884 q11Shape21T1002=true := by decide

private def q11Shape21T998 : Tree 11 := .split 32 q11Shape21T999 q11Shape21T1002
private theorem q11Shape21T998OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 4290873884 q11Shape21T998=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (4290873884 ||| 2^32) q11Shape21T999 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^32) 4290873884 q11Shape21T1002)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T999OK,q11Shape21T1002OK⟩

private def q11Shape21T1003 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1003OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2149713155 2143390236 q11Shape21T1003=true := by decide

private def q11Shape21T997 : Tree 11 := .split 31 q11Shape21T998 q11Shape21T1003
private theorem q11Shape21T997OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 2143390236 q11Shape21T997=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (2143390236 ||| 2^31) q11Shape21T998 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^31) 2143390236 q11Shape21T1003)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T998OK,q11Shape21T1003OK⟩

private def q11Shape21T1004 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1004OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075971331 1069648412 q11Shape21T1004=true := by decide

private def q11Shape21T996 : Tree 11 := .split 30 q11Shape21T997 q11Shape21T1004
private theorem q11Shape21T996OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 1069648412 q11Shape21T996=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (1069648412 ||| 2^30) q11Shape21T997 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^30) 1069648412 q11Shape21T1004)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T997OK,q11Shape21T1004OK⟩

private def q11Shape21T1005 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T1005OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 539100419 532777500 q11Shape21T1005=true := by decide

private def q11Shape21T995 : Tree 11 := .split 29 q11Shape21T996 q11Shape21T1005
private theorem q11Shape21T995OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 532777500 q11Shape21T995=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (532777500 ||| 2^29) q11Shape21T996 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^29) 532777500 q11Shape21T1005)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T996OK,q11Shape21T1005OK⟩

private def q11Shape21T1006 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T1006OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270664963 264342044 q11Shape21T1006=true := by decide

private def q11Shape21T994 : Tree 11 := .split 28 q11Shape21T995 q11Shape21T1006
private theorem q11Shape21T994OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 264342044 q11Shape21T994=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (264342044 ||| 2^28) q11Shape21T995 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^28) 264342044 q11Shape21T1006)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T995OK,q11Shape21T1006OK⟩

private def q11Shape21T1007 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T1007OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136447235 130124316 q11Shape21T1007=true := by decide

private def q11Shape21T993 : Tree 11 := .split 27 q11Shape21T994 q11Shape21T1007
private theorem q11Shape21T993OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 130124316 q11Shape21T993=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (130124316 ||| 2^27) q11Shape21T994 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^27) 130124316 q11Shape21T1007)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T994OK,q11Shape21T1007OK⟩

private def q11Shape21T1008 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T1008OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35783939 96569884 q11Shape21T1008=true := by decide

private def q11Shape21T992 : Tree 11 := .split 25 q11Shape21T993 q11Shape21T1008
private theorem q11Shape21T992OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 96569884 q11Shape21T992=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (96569884 ||| 2^25) q11Shape21T993 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^25) 96569884 q11Shape21T1008)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T993OK,q11Shape21T1008OK⟩

private def q11Shape21T1009 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T1009OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 19006723 79792668 q11Shape21T1009=true := by decide

private def q11Shape21T991 : Tree 11 := .split 24 q11Shape21T992 q11Shape21T1009
private theorem q11Shape21T991OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 79792668 q11Shape21T991=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (79792668 ||| 2^24) q11Shape21T992 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^24) 79792668 q11Shape21T1009)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T992OK,q11Shape21T1009OK⟩

private def q11Shape21T1010 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T1010OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10618115 71404060 q11Shape21T1010=true := by decide

private def q11Shape21T990 : Tree 11 := .split 23 q11Shape21T991 q11Shape21T1010
private theorem q11Shape21T990OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 71404060 q11Shape21T990=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (71404060 ||| 2^23) q11Shape21T991 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^23) 71404060 q11Shape21T1010)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T991OK,q11Shape21T1010OK⟩

private def q11Shape21T1011 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1011OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6423811 67209756 q11Shape21T1011=true := by decide

private def q11Shape21T989 : Tree 11 := .split 22 q11Shape21T990 q11Shape21T1011
private theorem q11Shape21T989OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 67209756 q11Shape21T989=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (67209756 ||| 2^22) q11Shape21T990 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^22) 67209756 q11Shape21T1011)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T990OK,q11Shape21T1011OK⟩

private def q11Shape21T1012 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T1012OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69338371 100892 q11Shape21T1012=true := by decide

private def q11Shape21T988 : Tree 11 := .split 26 q11Shape21T989 q11Shape21T1012
private theorem q11Shape21T988OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 100892 q11Shape21T988=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (100892 ||| 2^26) q11Shape21T989 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^26) 100892 q11Shape21T1012)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T989OK,q11Shape21T1012OK⟩

private def q11Shape21T1013 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T1013OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2295043 35356 q11Shape21T1013=true := by decide

private def q11Shape21T987 : Tree 11 := .split 16 q11Shape21T988 q11Shape21T1013
private theorem q11Shape21T987OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 35356 q11Shape21T987=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (35356 ||| 2^16) q11Shape21T988 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^16) 35356 q11Shape21T1013)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T988OK,q11Shape21T1013OK⟩

private def q11Shape21T1014 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T1014OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2262275 2588 q11Shape21T1014=true := by decide

private def q11Shape21T986 : Tree 11 := .split 15 q11Shape21T987 q11Shape21T1014
private theorem q11Shape21T986OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 2588 q11Shape21T986=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2229507 (2588 ||| 2^15) q11Shape21T987 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2229507 ||| 2^15) 2588 q11Shape21T1014)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T987OK,q11Shape21T1014OK⟩

private def q11Shape21T950 : Tree 11 := .split 10 q11Shape21T951 q11Shape21T986
private theorem q11Shape21T950OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 2588 q11Shape21T950=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (2588 ||| 2^10) q11Shape21T951 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^10) 2588 q11Shape21T986)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T951OK,q11Shape21T986OK⟩

private def q11Shape21T1030 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.split 19 (.tip (.cover {2,3,6,7,8,10})) (.split 20 (.tip (.cover {2,3,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {3,6,7,8,9,10})))))) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.split 19 (.tip (.cover {2,3,6,7,8,10})) (.split 20 (.tip (.cover {2,3,6,7,8,9})) (.tip (.cover {3,4,6,7,8,9})))))) (.split 14 (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.split 19 (.tip (.cover {2,3,6,7,8,10})) (.tip (.cover {3,4,6,7,8,10})))) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.split 19 (.tip (.cover {2,3,6,7,8,10})) (.tip (.cover {3,4,6,7,8,10}))))))
private theorem q11Shape21T1030OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 8585845788 q11Shape21T1030=true := by decide

private def q11Shape21T1031 : Tree 11 := (.split 13 (.split 14 (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10})))) (.split 14 (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {3,4,6,7,9,10})))))
private theorem q11Shape21T1031OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2233091 8585841692 q11Shape21T1031=true := by decide

private def q11Shape21T1029 : Tree 11 := .split 12 q11Shape21T1030 q11Shape21T1031
private theorem q11Shape21T1029OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 8585841692 q11Shape21T1029=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (8585841692 ||| 2^12) q11Shape21T1030 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^12) 8585841692 q11Shape21T1031)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1030OK,q11Shape21T1031OK⟩

private def q11Shape21T1032 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1032OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4297196291 4290874396 q11Shape21T1032=true := by decide

private def q11Shape21T1028 : Tree 11 := .split 32 q11Shape21T1029 q11Shape21T1032
private theorem q11Shape21T1028OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 4290874396 q11Shape21T1028=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (4290874396 ||| 2^32) q11Shape21T1029 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^32) 4290874396 q11Shape21T1032)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1029OK,q11Shape21T1032OK⟩

private def q11Shape21T1033 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1033OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2149712643 2143390748 q11Shape21T1033=true := by decide

private def q11Shape21T1027 : Tree 11 := .split 31 q11Shape21T1028 q11Shape21T1033
private theorem q11Shape21T1027OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 2143390748 q11Shape21T1027=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (2143390748 ||| 2^31) q11Shape21T1028 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^31) 2143390748 q11Shape21T1033)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1028OK,q11Shape21T1033OK⟩

private def q11Shape21T1034 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1034OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075970819 1069648924 q11Shape21T1034=true := by decide

private def q11Shape21T1026 : Tree 11 := .split 30 q11Shape21T1027 q11Shape21T1034
private theorem q11Shape21T1026OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 1069648924 q11Shape21T1026=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (1069648924 ||| 2^30) q11Shape21T1027 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^30) 1069648924 q11Shape21T1034)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1027OK,q11Shape21T1034OK⟩

private def q11Shape21T1035 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T1035OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 539099907 532778012 q11Shape21T1035=true := by decide

private def q11Shape21T1025 : Tree 11 := .split 29 q11Shape21T1026 q11Shape21T1035
private theorem q11Shape21T1025OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 532778012 q11Shape21T1025=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (532778012 ||| 2^29) q11Shape21T1026 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^29) 532778012 q11Shape21T1035)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1026OK,q11Shape21T1035OK⟩

private def q11Shape21T1036 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T1036OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270664451 264342556 q11Shape21T1036=true := by decide

private def q11Shape21T1024 : Tree 11 := .split 28 q11Shape21T1025 q11Shape21T1036
private theorem q11Shape21T1024OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 264342556 q11Shape21T1024=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (264342556 ||| 2^28) q11Shape21T1025 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^28) 264342556 q11Shape21T1036)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1025OK,q11Shape21T1036OK⟩

private def q11Shape21T1037 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T1037OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136446723 130124828 q11Shape21T1037=true := by decide

private def q11Shape21T1023 : Tree 11 := .split 27 q11Shape21T1024 q11Shape21T1037
private theorem q11Shape21T1023OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 130124828 q11Shape21T1023=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (130124828 ||| 2^27) q11Shape21T1024 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^27) 130124828 q11Shape21T1037)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1024OK,q11Shape21T1037OK⟩

private def q11Shape21T1038 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T1038OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35783427 96570396 q11Shape21T1038=true := by decide

private def q11Shape21T1022 : Tree 11 := .split 25 q11Shape21T1023 q11Shape21T1038
private theorem q11Shape21T1022OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 96570396 q11Shape21T1022=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (96570396 ||| 2^25) q11Shape21T1023 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^25) 96570396 q11Shape21T1038)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1023OK,q11Shape21T1038OK⟩

private def q11Shape21T1039 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T1039OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 19006211 79793180 q11Shape21T1039=true := by decide

private def q11Shape21T1021 : Tree 11 := .split 24 q11Shape21T1022 q11Shape21T1039
private theorem q11Shape21T1021OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 79793180 q11Shape21T1021=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (79793180 ||| 2^24) q11Shape21T1022 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^24) 79793180 q11Shape21T1039)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1022OK,q11Shape21T1039OK⟩

private def q11Shape21T1040 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T1040OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10617603 71404572 q11Shape21T1040=true := by decide

private def q11Shape21T1020 : Tree 11 := .split 23 q11Shape21T1021 q11Shape21T1040
private theorem q11Shape21T1020OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 71404572 q11Shape21T1020=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (71404572 ||| 2^23) q11Shape21T1021 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^23) 71404572 q11Shape21T1040)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1021OK,q11Shape21T1040OK⟩

private def q11Shape21T1041 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1041OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6423299 67210268 q11Shape21T1041=true := by decide

private def q11Shape21T1019 : Tree 11 := .split 22 q11Shape21T1020 q11Shape21T1041
private theorem q11Shape21T1019OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 67210268 q11Shape21T1019=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (67210268 ||| 2^22) q11Shape21T1020 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^22) 67210268 q11Shape21T1041)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1020OK,q11Shape21T1041OK⟩

private def q11Shape21T1042 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T1042OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69337859 101404 q11Shape21T1042=true := by decide

private def q11Shape21T1018 : Tree 11 := .split 26 q11Shape21T1019 q11Shape21T1042
private theorem q11Shape21T1018OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 101404 q11Shape21T1018=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (101404 ||| 2^26) q11Shape21T1019 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^26) 101404 q11Shape21T1042)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1019OK,q11Shape21T1042OK⟩

private def q11Shape21T1043 : Tree 11 := (.tip (.cover {1,4,5,8,9,10}))
private theorem q11Shape21T1043OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2294531 35868 q11Shape21T1043=true := by decide

private def q11Shape21T1017 : Tree 11 := .split 16 q11Shape21T1018 q11Shape21T1043
private theorem q11Shape21T1017OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 35868 q11Shape21T1017=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (35868 ||| 2^16) q11Shape21T1018 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^16) 35868 q11Shape21T1043)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1018OK,q11Shape21T1043OK⟩

private def q11Shape21T1044 : Tree 11 := (.tip (.cover {1,4,6,8,9,10}))
private theorem q11Shape21T1044OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2261763 3100 q11Shape21T1044=true := by decide

private def q11Shape21T1016 : Tree 11 := .split 15 q11Shape21T1017 q11Shape21T1044
private theorem q11Shape21T1016OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 3100 q11Shape21T1016=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (3100 ||| 2^15) q11Shape21T1017 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^15) 3100 q11Shape21T1044)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1017OK,q11Shape21T1044OK⟩

private def q11Shape21T1045 : Tree 11 := (.tip (.cover {0,3,7,8,9,10}))
private theorem q11Shape21T1045OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230019 2076 q11Shape21T1045=true := by decide

private def q11Shape21T1015 : Tree 11 := .split 10 q11Shape21T1016 q11Shape21T1045
private theorem q11Shape21T1015OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 2076 q11Shape21T1015=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228995 (2076 ||| 2^10) q11Shape21T1016 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228995 ||| 2^10) 2076 q11Shape21T1045)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1016OK,q11Shape21T1045OK⟩

private def q11Shape21T949 : Tree 11 := .split 9 q11Shape21T950 q11Shape21T1015
private theorem q11Shape21T949OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 2076 q11Shape21T949=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (2076 ||| 2^9) q11Shape21T950 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^9) 2076 q11Shape21T1015)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T950OK,q11Shape21T1015OK⟩

private def q11Shape21T1046 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,7,9,10})) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10})))
private theorem q11Shape21T1046OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228491 2068 q11Shape21T1046=true := by decide

private def q11Shape21T948 : Tree 11 := .split 3 q11Shape21T949 q11Shape21T1046
private theorem q11Shape21T948OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 2068 q11Shape21T948=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (2068 ||| 2^3) q11Shape21T949 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^3) 2068 q11Shape21T1046)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T949OK,q11Shape21T1046OK⟩

private def q11Shape21T1047 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,6,7,9,10})) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {1,4,5,8,9,10}))) (.tip (.cover {1,4,6,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape21T1047OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228487 2064 q11Shape21T1047=true := by decide

private def q11Shape21T947 : Tree 11 := .split 2 q11Shape21T948 q11Shape21T1047
private theorem q11Shape21T947OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 2064 q11Shape21T947=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (2064 ||| 2^2) q11Shape21T948 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^2) 2064 q11Shape21T1047)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T948OK,q11Shape21T1047OK⟩

private def q11Shape21T1049 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {2,4,5,8,9,10}))) (.tip (.cover {2,4,6,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {2,4,5,8,9,10})))
private theorem q11Shape21T1049OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228499 2052 q11Shape21T1049=true := by decide

private def q11Shape21T1050 : Tree 11 := (.tip (.cover {2,4,6,8,9,10}))
private theorem q11Shape21T1050OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228503 2048 q11Shape21T1050=true := by decide

private def q11Shape21T1048 : Tree 11 := .split 2 q11Shape21T1049 q11Shape21T1050
private theorem q11Shape21T1048OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228499 2048 q11Shape21T1048=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228499 (2048 ||| 2^2) q11Shape21T1049 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228499 ||| 2^2) 2048 q11Shape21T1050)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1049OK,q11Shape21T1050OK⟩

private def q11Shape21T946 : Tree 11 := .split 4 q11Shape21T947 q11Shape21T1048
private theorem q11Shape21T946OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 2048 q11Shape21T946=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2228483 (2048 ||| 2^4) q11Shape21T947 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2228483 ||| 2^4) 2048 q11Shape21T1048)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T947OK,q11Shape21T1048OK⟩

private def q11Shape21T860 : Tree 11 := .split 17 q11Shape21T861 q11Shape21T946
private theorem q11Shape21T860OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097411 2048 q11Shape21T860=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097411 (2048 ||| 2^17) q11Shape21T861 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097411 ||| 2^17) 2048 q11Shape21T946)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T861OK,q11Shape21T946OK⟩

private def q11Shape21T1072 : Tree 11 := (.split 14 (.tip (.drop {1,3,6,7} (fun x => if x = 1 then some 0 else if x = 3 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none))) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10})))))))
private theorem q11Shape21T1072OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 8585983516 q11Shape21T1072=true := by decide

private def q11Shape21T1073 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10})))))) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.tip (.drop {1,4,6,7} (fun x => if x = 1 then some 0 else if x = 4 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none)))) (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.split 5 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,8}))))))
private theorem q11Shape21T1073OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2107651 8585975324 q11Shape21T1073=true := by decide

private def q11Shape21T1071 : Tree 11 := .split 13 q11Shape21T1072 q11Shape21T1073
private theorem q11Shape21T1071OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 8585975324 q11Shape21T1071=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (8585975324 ||| 2^13) q11Shape21T1072 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^13) 8585975324 q11Shape21T1073)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1072OK,q11Shape21T1073OK⟩

private def q11Shape21T1076 : Tree 11 := (.split 18 (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.drop {1,3,6,7} (fun x => if x = 1 then some 0 else if x = 3 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none))) (.tip (.cover {0,5,7,8,9,10}))))) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.split 6 (.tip (.cover {0,4,5,7,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))))))
private theorem q11Shape21T1076OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2103555 8585995804 q11Shape21T1076=true := by decide

private def q11Shape21T1077 : Tree 11 := (.split 18 (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))))) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.split 6 (.tip (.cover {0,4,5,7,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,9})))))
private theorem q11Shape21T1077OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2119939 8585979420 q11Shape21T1077=true := by decide

private def q11Shape21T1075 : Tree 11 := .split 14 q11Shape21T1076 q11Shape21T1077
private theorem q11Shape21T1075OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2103555 8585979420 q11Shape21T1075=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2103555 (8585979420 ||| 2^14) q11Shape21T1076 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2103555 ||| 2^14) 8585979420 q11Shape21T1077)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1076OK,q11Shape21T1077OK⟩

private def q11Shape21T1079 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {0,2,5,7,8,9})) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))))) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.split 6 (.tip (.cover {0,1,3,5,8,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))) (.tip (.cover {3,4,5,6,7,10}))))
private theorem q11Shape21T1079OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2111747 8585987612 q11Shape21T1079=true := by decide

private def q11Shape21T1080 : Tree 11 := (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.split 6 (.tip (.cover {0,1,3,5,8,10})) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,8})))) (.split 19 (.split 20 (.split 5 (.tip (.drop {1,4,6,7} (fun x => if x = 1 then some 0 else if x = 4 then some 0 else if x = 6 then some 5 else if x = 7 then some 5 else none))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,7,9}))) (.tip (.cover {3,4,5,6,7,10}))))
private theorem q11Shape21T1080OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2128131 8585971228 q11Shape21T1080=true := by decide

private def q11Shape21T1078 : Tree 11 := .split 14 q11Shape21T1079 q11Shape21T1080
private theorem q11Shape21T1078OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2111747 8585971228 q11Shape21T1078=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2111747 (8585971228 ||| 2^14) q11Shape21T1079 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2111747 ||| 2^14) 8585971228 q11Shape21T1080)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1079OK,q11Shape21T1080OK⟩

private def q11Shape21T1074 : Tree 11 := .split 13 q11Shape21T1075 q11Shape21T1078
private theorem q11Shape21T1074OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2103555 8585971228 q11Shape21T1074=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2103555 (8585971228 ||| 2^13) q11Shape21T1075 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2103555 ||| 2^13) 8585971228 q11Shape21T1078)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1075OK,q11Shape21T1078OK⟩

private def q11Shape21T1070 : Tree 11 := .split 12 q11Shape21T1071 q11Shape21T1074
private theorem q11Shape21T1070OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 8585971228 q11Shape21T1070=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (8585971228 ||| 2^12) q11Shape21T1071 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^12) 8585971228 q11Shape21T1074)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1071OK,q11Shape21T1074OK⟩

private def q11Shape21T1081 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1081OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4297066755 4291003932 q11Shape21T1081=true := by decide

private def q11Shape21T1069 : Tree 11 := .split 32 q11Shape21T1070 q11Shape21T1081
private theorem q11Shape21T1069OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 4291003932 q11Shape21T1069=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (4291003932 ||| 2^32) q11Shape21T1070 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^32) 4291003932 q11Shape21T1081)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1070OK,q11Shape21T1081OK⟩

private def q11Shape21T1082 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1082OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2149583107 2143520284 q11Shape21T1082=true := by decide

private def q11Shape21T1068 : Tree 11 := .split 31 q11Shape21T1069 q11Shape21T1082
private theorem q11Shape21T1068OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 2143520284 q11Shape21T1068=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (2143520284 ||| 2^31) q11Shape21T1069 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^31) 2143520284 q11Shape21T1082)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1069OK,q11Shape21T1082OK⟩

private def q11Shape21T1083 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1083OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075841283 1069778460 q11Shape21T1083=true := by decide

private def q11Shape21T1067 : Tree 11 := .split 30 q11Shape21T1068 q11Shape21T1083
private theorem q11Shape21T1067OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 1069778460 q11Shape21T1067=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (1069778460 ||| 2^30) q11Shape21T1068 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^30) 1069778460 q11Shape21T1083)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1068OK,q11Shape21T1083OK⟩

private def q11Shape21T1084 : Tree 11 := (.tip (.cover {1,3,5,8,9,10}))
private theorem q11Shape21T1084OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 538970371 532907548 q11Shape21T1084=true := by decide

private def q11Shape21T1066 : Tree 11 := .split 29 q11Shape21T1067 q11Shape21T1084
private theorem q11Shape21T1066OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 532907548 q11Shape21T1066=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (532907548 ||| 2^29) q11Shape21T1067 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^29) 532907548 q11Shape21T1084)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1067OK,q11Shape21T1084OK⟩

private def q11Shape21T1085 : Tree 11 := (.tip (.cover {1,3,5,8,9,10}))
private theorem q11Shape21T1085OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270534915 264472092 q11Shape21T1085=true := by decide

private def q11Shape21T1065 : Tree 11 := .split 28 q11Shape21T1066 q11Shape21T1085
private theorem q11Shape21T1065OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 264472092 q11Shape21T1065=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (264472092 ||| 2^28) q11Shape21T1066 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^28) 264472092 q11Shape21T1085)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1066OK,q11Shape21T1085OK⟩

private def q11Shape21T1086 : Tree 11 := (.tip (.cover {1,3,5,8,9,10}))
private theorem q11Shape21T1086OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136317187 130254364 q11Shape21T1086=true := by decide

private def q11Shape21T1064 : Tree 11 := .split 27 q11Shape21T1065 q11Shape21T1086
private theorem q11Shape21T1064OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 130254364 q11Shape21T1064=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (130254364 ||| 2^27) q11Shape21T1065 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^27) 130254364 q11Shape21T1086)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1065OK,q11Shape21T1086OK⟩

private def q11Shape21T1087 : Tree 11 := (.tip (.cover {1,3,6,8,9,10}))
private theorem q11Shape21T1087OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35653891 96699932 q11Shape21T1087=true := by decide

private def q11Shape21T1063 : Tree 11 := .split 25 q11Shape21T1064 q11Shape21T1087
private theorem q11Shape21T1063OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 96699932 q11Shape21T1063=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (96699932 ||| 2^25) q11Shape21T1064 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^25) 96699932 q11Shape21T1087)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1064OK,q11Shape21T1087OK⟩

private def q11Shape21T1088 : Tree 11 := (.tip (.cover {1,3,6,8,9,10}))
private theorem q11Shape21T1088OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 18876675 79922716 q11Shape21T1088=true := by decide

private def q11Shape21T1062 : Tree 11 := .split 24 q11Shape21T1063 q11Shape21T1088
private theorem q11Shape21T1062OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 79922716 q11Shape21T1062=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (79922716 ||| 2^24) q11Shape21T1063 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^24) 79922716 q11Shape21T1088)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1063OK,q11Shape21T1088OK⟩

private def q11Shape21T1089 : Tree 11 := (.tip (.cover {1,3,6,8,9,10}))
private theorem q11Shape21T1089OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10488067 71534108 q11Shape21T1089=true := by decide

private def q11Shape21T1061 : Tree 11 := .split 23 q11Shape21T1062 q11Shape21T1089
private theorem q11Shape21T1061OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 71534108 q11Shape21T1061=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (71534108 ||| 2^23) q11Shape21T1062 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^23) 71534108 q11Shape21T1089)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1062OK,q11Shape21T1089OK⟩

private def q11Shape21T1090 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1090OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6293763 67339804 q11Shape21T1090=true := by decide

private def q11Shape21T1060 : Tree 11 := .split 22 q11Shape21T1061 q11Shape21T1090
private theorem q11Shape21T1060OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 67339804 q11Shape21T1060=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (67339804 ||| 2^22) q11Shape21T1061 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^22) 67339804 q11Shape21T1090)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1061OK,q11Shape21T1090OK⟩

private def q11Shape21T1091 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T1091OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69208323 230940 q11Shape21T1091=true := by decide

private def q11Shape21T1059 : Tree 11 := .split 26 q11Shape21T1060 q11Shape21T1091
private theorem q11Shape21T1059OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 230940 q11Shape21T1059=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (230940 ||| 2^26) q11Shape21T1060 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^26) 230940 q11Shape21T1091)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1060OK,q11Shape21T1091OK⟩

private def q11Shape21T1093 : Tree 11 := (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,7,9,10})) (.split 13 (.tip (.cover {2,4,5,7,8,10})) (.split 14 (.tip (.cover {2,4,5,7,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {3,4,5,7,8,9}))) (.tip (.cover {3,4,5,7,8,10}))) (.tip (.cover {3,4,5,7,9,10})))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape21T1093OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2164995 67274268 q11Shape21T1093=true := by decide

private def q11Shape21T1094 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T1094OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69273859 165404 q11Shape21T1094=true := by decide

private def q11Shape21T1092 : Tree 11 := .split 26 q11Shape21T1093 q11Shape21T1094
private theorem q11Shape21T1092OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2164995 165404 q11Shape21T1092=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2164995 (165404 ||| 2^26) q11Shape21T1093 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2164995 ||| 2^26) 165404 q11Shape21T1094)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1093OK,q11Shape21T1094OK⟩

private def q11Shape21T1058 : Tree 11 := .split 16 q11Shape21T1059 q11Shape21T1092
private theorem q11Shape21T1058OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 165404 q11Shape21T1058=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (165404 ||| 2^16) q11Shape21T1059 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^16) 165404 q11Shape21T1092)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1059OK,q11Shape21T1092OK⟩

private def q11Shape21T1097 : Tree 11 := (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,6,7,9,10})) (.split 13 (.tip (.cover {2,4,6,7,8,10})) (.split 14 (.tip (.cover {2,4,6,7,8,9})) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {3,4,6,7,8,9}))) (.tip (.cover {3,4,6,7,8,10}))) (.tip (.cover {3,4,6,7,9,10})))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape21T1097OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2132227 67307036 q11Shape21T1097=true := by decide

private def q11Shape21T1098 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T1098OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69241091 198172 q11Shape21T1098=true := by decide

private def q11Shape21T1096 : Tree 11 := .split 26 q11Shape21T1097 q11Shape21T1098
private theorem q11Shape21T1096OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2132227 198172 q11Shape21T1096=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2132227 (198172 ||| 2^26) q11Shape21T1097 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2132227 ||| 2^26) 198172 q11Shape21T1098)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1097OK,q11Shape21T1098OK⟩

private def q11Shape21T1099 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape21T1099OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2197763 132636 q11Shape21T1099=true := by decide

private def q11Shape21T1095 : Tree 11 := .split 16 q11Shape21T1096 q11Shape21T1099
private theorem q11Shape21T1095OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2132227 132636 q11Shape21T1095=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2132227 (132636 ||| 2^16) q11Shape21T1096 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2132227 ||| 2^16) 132636 q11Shape21T1099)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1096OK,q11Shape21T1099OK⟩

private def q11Shape21T1057 : Tree 11 := .split 15 q11Shape21T1058 q11Shape21T1095
private theorem q11Shape21T1057OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 132636 q11Shape21T1057=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (132636 ||| 2^15) q11Shape21T1058 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^15) 132636 q11Shape21T1095)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1058OK,q11Shape21T1095OK⟩

private def q11Shape21T1100 : Tree 11 := (.tip (.cover {1,3,5,8,9,10}))
private theorem q11Shape21T1100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2100483 131612 q11Shape21T1100=true := by decide

private def q11Shape21T1056 : Tree 11 := .split 10 q11Shape21T1057 q11Shape21T1100
private theorem q11Shape21T1056OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 131612 q11Shape21T1056=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (131612 ||| 2^10) q11Shape21T1057 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^10) 131612 q11Shape21T1100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1057OK,q11Shape21T1100OK⟩

private def q11Shape21T1101 : Tree 11 := (.tip (.cover {1,3,6,8,9,10}))
private theorem q11Shape21T1101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099971 131100 q11Shape21T1101=true := by decide

private def q11Shape21T1055 : Tree 11 := .split 9 q11Shape21T1056 q11Shape21T1101
private theorem q11Shape21T1055OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 131100 q11Shape21T1055=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (131100 ||| 2^9) q11Shape21T1056 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^9) 131100 q11Shape21T1101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1056OK,q11Shape21T1101OK⟩

private def q11Shape21T1104 : Tree 11 := (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,5,7,9,10})) (.split 13 (.tip (.cover {2,4,5,7,8,10})) (.split 14 (.tip (.cover {2,4,5,7,8,9})) (.split 18 (.tip (.cover {2,3,5,7,9,10})) (.tip (.cover {2,5,7,8,9,10})))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {1,3,5,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10})))
private theorem q11Shape21T1104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099467 132628 q11Shape21T1104=true := by decide

private def q11Shape21T1105 : Tree 11 := (.tip (.cover {1,3,5,8,9,10}))
private theorem q11Shape21T1105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2100491 131604 q11Shape21T1105=true := by decide

private def q11Shape21T1103 : Tree 11 := .split 10 q11Shape21T1104 q11Shape21T1105
private theorem q11Shape21T1103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099467 131604 q11Shape21T1103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099467 (131604 ||| 2^10) q11Shape21T1104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099467 ||| 2^10) 131604 q11Shape21T1105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1104OK,q11Shape21T1105OK⟩

private def q11Shape21T1106 : Tree 11 := (.tip (.cover {1,3,6,8,9,10}))
private theorem q11Shape21T1106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099979 131092 q11Shape21T1106=true := by decide

private def q11Shape21T1102 : Tree 11 := .split 9 q11Shape21T1103 q11Shape21T1106
private theorem q11Shape21T1102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099467 131092 q11Shape21T1102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099467 (131092 ||| 2^9) q11Shape21T1103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099467 ||| 2^9) 131092 q11Shape21T1106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1103OK,q11Shape21T1106OK⟩

private def q11Shape21T1054 : Tree 11 := .split 3 q11Shape21T1055 q11Shape21T1102
private theorem q11Shape21T1054OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 131092 q11Shape21T1054=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (131092 ||| 2^3) q11Shape21T1055 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^3) 131092 q11Shape21T1102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1055OK,q11Shape21T1102OK⟩

private def q11Shape21T1110 : Tree 11 := (.split 15 (.split 16 (.split 26 (.split 22 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 12 (.tip (.cover {2,4,6,7,9,10})) (.split 13 (.tip (.cover {2,4,6,7,8,10})) (.split 14 (.tip (.cover {2,4,6,7,8,9})) (.split 18 (.tip (.cover {2,3,6,7,9,10})) (.tip (.cover {2,6,7,8,9,10})))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {1,3,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10})))
private theorem q11Shape21T1110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099463 132632 q11Shape21T1110=true := by decide

private def q11Shape21T1111 : Tree 11 := (.tip (.cover {1,3,5,8,9,10}))
private theorem q11Shape21T1111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2100487 131608 q11Shape21T1111=true := by decide

private def q11Shape21T1109 : Tree 11 := .split 10 q11Shape21T1110 q11Shape21T1111
private theorem q11Shape21T1109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099463 131608 q11Shape21T1109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099463 (131608 ||| 2^10) q11Shape21T1110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099463 ||| 2^10) 131608 q11Shape21T1111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1110OK,q11Shape21T1111OK⟩

private def q11Shape21T1112 : Tree 11 := (.tip (.cover {1,3,6,8,9,10}))
private theorem q11Shape21T1112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099975 131096 q11Shape21T1112=true := by decide

private def q11Shape21T1108 : Tree 11 := .split 9 q11Shape21T1109 q11Shape21T1112
private theorem q11Shape21T1108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099463 131096 q11Shape21T1108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099463 (131096 ||| 2^9) q11Shape21T1109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099463 ||| 2^9) 131096 q11Shape21T1112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1109OK,q11Shape21T1112OK⟩

private def q11Shape21T1113 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape21T1113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099471 131088 q11Shape21T1113=true := by decide

private def q11Shape21T1107 : Tree 11 := .split 3 q11Shape21T1108 q11Shape21T1113
private theorem q11Shape21T1107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099463 131088 q11Shape21T1107=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099463 (131088 ||| 2^3) q11Shape21T1108 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099463 ||| 2^3) 131088 q11Shape21T1113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1108OK,q11Shape21T1113OK⟩

private def q11Shape21T1053 : Tree 11 := .split 2 q11Shape21T1054 q11Shape21T1107
private theorem q11Shape21T1053OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 131088 q11Shape21T1053=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (131088 ||| 2^2) q11Shape21T1054 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^2) 131088 q11Shape21T1107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1054OK,q11Shape21T1107OK⟩

private def q11Shape21T1129 : Tree 11 := (.split 31 (.split 32 (.split 12 (.split 13 (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))))) (.split 13 (.split 14 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.split 14 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,5,7,8,9,10})))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape21T1129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 2143520268 q11Shape21T1129=true := by decide

private def q11Shape21T1130 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075841299 1069778444 q11Shape21T1130=true := by decide

private def q11Shape21T1128 : Tree 11 := .split 30 q11Shape21T1129 q11Shape21T1130
private theorem q11Shape21T1128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 1069778444 q11Shape21T1128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (1069778444 ||| 2^30) q11Shape21T1129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^30) 1069778444 q11Shape21T1130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1129OK,q11Shape21T1130OK⟩

private def q11Shape21T1131 : Tree 11 := (.tip (.cover {2,3,5,8,9,10}))
private theorem q11Shape21T1131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 538970387 532907532 q11Shape21T1131=true := by decide

private def q11Shape21T1127 : Tree 11 := .split 29 q11Shape21T1128 q11Shape21T1131
private theorem q11Shape21T1127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 532907532 q11Shape21T1127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (532907532 ||| 2^29) q11Shape21T1128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^29) 532907532 q11Shape21T1131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1128OK,q11Shape21T1131OK⟩

private def q11Shape21T1132 : Tree 11 := (.tip (.cover {2,3,5,8,9,10}))
private theorem q11Shape21T1132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270534931 264472076 q11Shape21T1132=true := by decide

private def q11Shape21T1126 : Tree 11 := .split 28 q11Shape21T1127 q11Shape21T1132
private theorem q11Shape21T1126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 264472076 q11Shape21T1126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (264472076 ||| 2^28) q11Shape21T1127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^28) 264472076 q11Shape21T1132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1127OK,q11Shape21T1132OK⟩

private def q11Shape21T1133 : Tree 11 := (.tip (.cover {2,3,5,8,9,10}))
private theorem q11Shape21T1133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136317203 130254348 q11Shape21T1133=true := by decide

private def q11Shape21T1125 : Tree 11 := .split 27 q11Shape21T1126 q11Shape21T1133
private theorem q11Shape21T1125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 130254348 q11Shape21T1125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (130254348 ||| 2^27) q11Shape21T1126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^27) 130254348 q11Shape21T1133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1126OK,q11Shape21T1133OK⟩

private def q11Shape21T1134 : Tree 11 := (.tip (.cover {2,3,6,8,9,10}))
private theorem q11Shape21T1134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35653907 96699916 q11Shape21T1134=true := by decide

private def q11Shape21T1124 : Tree 11 := .split 25 q11Shape21T1125 q11Shape21T1134
private theorem q11Shape21T1124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 96699916 q11Shape21T1124=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (96699916 ||| 2^25) q11Shape21T1125 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^25) 96699916 q11Shape21T1134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1125OK,q11Shape21T1134OK⟩

private def q11Shape21T1135 : Tree 11 := (.tip (.cover {2,3,6,8,9,10}))
private theorem q11Shape21T1135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 18876691 79922700 q11Shape21T1135=true := by decide

private def q11Shape21T1123 : Tree 11 := .split 24 q11Shape21T1124 q11Shape21T1135
private theorem q11Shape21T1123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 79922700 q11Shape21T1123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (79922700 ||| 2^24) q11Shape21T1124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^24) 79922700 q11Shape21T1135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1124OK,q11Shape21T1135OK⟩

private def q11Shape21T1136 : Tree 11 := (.tip (.cover {2,3,6,8,9,10}))
private theorem q11Shape21T1136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10488083 71534092 q11Shape21T1136=true := by decide

private def q11Shape21T1122 : Tree 11 := .split 23 q11Shape21T1123 q11Shape21T1136
private theorem q11Shape21T1122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 71534092 q11Shape21T1122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (71534092 ||| 2^23) q11Shape21T1123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^23) 71534092 q11Shape21T1136)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1123OK,q11Shape21T1136OK⟩

private def q11Shape21T1137 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6293779 67339788 q11Shape21T1137=true := by decide

private def q11Shape21T1121 : Tree 11 := .split 22 q11Shape21T1122 q11Shape21T1137
private theorem q11Shape21T1121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 67339788 q11Shape21T1121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (67339788 ||| 2^22) q11Shape21T1122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^22) 67339788 q11Shape21T1137)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1122OK,q11Shape21T1137OK⟩

private def q11Shape21T1138 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T1138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69208339 230924 q11Shape21T1138=true := by decide

private def q11Shape21T1120 : Tree 11 := .split 26 q11Shape21T1121 q11Shape21T1138
private theorem q11Shape21T1120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 230924 q11Shape21T1120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (230924 ||| 2^26) q11Shape21T1121 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^26) 230924 q11Shape21T1138)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1121OK,q11Shape21T1138OK⟩

private def q11Shape21T1139 : Tree 11 := (.tip (.cover {4,5,7,8,9,10}))
private theorem q11Shape21T1139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2165011 165388 q11Shape21T1139=true := by decide

private def q11Shape21T1119 : Tree 11 := .split 16 q11Shape21T1120 q11Shape21T1139
private theorem q11Shape21T1119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 165388 q11Shape21T1119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (165388 ||| 2^16) q11Shape21T1120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^16) 165388 q11Shape21T1139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1120OK,q11Shape21T1139OK⟩

private def q11Shape21T1140 : Tree 11 := (.tip (.cover {4,6,7,8,9,10}))
private theorem q11Shape21T1140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2132243 132620 q11Shape21T1140=true := by decide

private def q11Shape21T1118 : Tree 11 := .split 15 q11Shape21T1119 q11Shape21T1140
private theorem q11Shape21T1118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 132620 q11Shape21T1118=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (132620 ||| 2^15) q11Shape21T1119 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^15) 132620 q11Shape21T1140)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1119OK,q11Shape21T1140OK⟩

private def q11Shape21T1141 : Tree 11 := (.tip (.cover {2,3,5,8,9,10}))
private theorem q11Shape21T1141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2100499 131596 q11Shape21T1141=true := by decide

private def q11Shape21T1117 : Tree 11 := .split 10 q11Shape21T1118 q11Shape21T1141
private theorem q11Shape21T1117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 131596 q11Shape21T1117=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (131596 ||| 2^10) q11Shape21T1118 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^10) 131596 q11Shape21T1141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1118OK,q11Shape21T1141OK⟩

private def q11Shape21T1142 : Tree 11 := (.tip (.cover {2,3,6,8,9,10}))
private theorem q11Shape21T1142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099987 131084 q11Shape21T1142=true := by decide

private def q11Shape21T1116 : Tree 11 := .split 9 q11Shape21T1117 q11Shape21T1142
private theorem q11Shape21T1116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 131084 q11Shape21T1116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (131084 ||| 2^9) q11Shape21T1117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^9) 131084 q11Shape21T1142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1117OK,q11Shape21T1142OK⟩

private def q11Shape21T1143 : Tree 11 := (.tip (.cover {2,3,5,8,9,10}))
private theorem q11Shape21T1143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099483 131076 q11Shape21T1143=true := by decide

private def q11Shape21T1115 : Tree 11 := .split 3 q11Shape21T1116 q11Shape21T1143
private theorem q11Shape21T1115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 131076 q11Shape21T1115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (131076 ||| 2^3) q11Shape21T1116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^3) 131076 q11Shape21T1143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1116OK,q11Shape21T1143OK⟩

private def q11Shape21T1144 : Tree 11 := (.tip (.cover {2,3,6,8,9,10}))
private theorem q11Shape21T1144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099479 131072 q11Shape21T1144=true := by decide

private def q11Shape21T1114 : Tree 11 := .split 2 q11Shape21T1115 q11Shape21T1144
private theorem q11Shape21T1114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 131072 q11Shape21T1114=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099475 (131072 ||| 2^2) q11Shape21T1115 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099475 ||| 2^2) 131072 q11Shape21T1144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1115OK,q11Shape21T1144OK⟩

private def q11Shape21T1052 : Tree 11 := .split 4 q11Shape21T1053 q11Shape21T1114
private theorem q11Shape21T1052OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 131072 q11Shape21T1052=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (131072 ||| 2^4) q11Shape21T1053 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^4) 131072 q11Shape21T1114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1053OK,q11Shape21T1114OK⟩

private def q11Shape21T1165 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,8,9}))))))
private theorem q11Shape21T1165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 8585852444 q11Shape21T1165=true := by decide

private def q11Shape21T1166 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.tip (.cover {3,4,5,6,8,10})))) (.split 18 (.tip (.cover {2,5,6,7,9,10})) (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,8,9}))) (.tip (.cover {3,4,5,6,8,10})))))
private theorem q11Shape21T1166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2238723 8585844252 q11Shape21T1166=true := by decide

private def q11Shape21T1164 : Tree 11 := .split 13 q11Shape21T1165 q11Shape21T1166
private theorem q11Shape21T1164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 8585844252 q11Shape21T1164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (8585844252 ||| 2^13) q11Shape21T1165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^13) 8585844252 q11Shape21T1166)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1165OK,q11Shape21T1166OK⟩

private def q11Shape21T1168 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))))) (.tip (.cover {3,4,5,6,9,10}))) (.split 18 (.split 19 (.tip (.cover {2,5,6,7,8,10})) (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,8,9})))) (.tip (.cover {3,4,5,6,9,10}))))
private theorem q11Shape21T1168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2234627 8585848348 q11Shape21T1168=true := by decide

private def q11Shape21T1169 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {2,5,6,7,8,9})) (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.tip (.cover {3,4,5,6,8,10}))) (.tip (.cover {3,4,5,6,9,10}))) (.split 18 (.split 19 (.split 20 (.split 5 (.tip (.cover {0,1,3,5,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,5,6,8,9}))) (.tip (.cover {3,4,5,6,8,10}))) (.tip (.cover {3,4,5,6,9,10}))))
private theorem q11Shape21T1169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2242819 8585840156 q11Shape21T1169=true := by decide

private def q11Shape21T1167 : Tree 11 := .split 13 q11Shape21T1168 q11Shape21T1169
private theorem q11Shape21T1167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2234627 8585840156 q11Shape21T1167=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2234627 (8585840156 ||| 2^13) q11Shape21T1168 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2234627 ||| 2^13) 8585840156 q11Shape21T1169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1168OK,q11Shape21T1169OK⟩

private def q11Shape21T1163 : Tree 11 := .split 12 q11Shape21T1164 q11Shape21T1167
private theorem q11Shape21T1163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 8585840156 q11Shape21T1163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (8585840156 ||| 2^12) q11Shape21T1164 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^12) 8585840156 q11Shape21T1167)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1164OK,q11Shape21T1167OK⟩

private def q11Shape21T1170 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 4297197827 4290872860 q11Shape21T1170=true := by decide

private def q11Shape21T1162 : Tree 11 := .split 32 q11Shape21T1163 q11Shape21T1170
private theorem q11Shape21T1162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 4290872860 q11Shape21T1162=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (4290872860 ||| 2^32) q11Shape21T1163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^32) 4290872860 q11Shape21T1170)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1163OK,q11Shape21T1170OK⟩

private def q11Shape21T1171 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2149714179 2143389212 q11Shape21T1171=true := by decide

private def q11Shape21T1161 : Tree 11 := .split 31 q11Shape21T1162 q11Shape21T1171
private theorem q11Shape21T1161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 2143389212 q11Shape21T1161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (2143389212 ||| 2^31) q11Shape21T1162 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^31) 2143389212 q11Shape21T1171)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1162OK,q11Shape21T1171OK⟩

private def q11Shape21T1172 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 1075972355 1069647388 q11Shape21T1172=true := by decide

private def q11Shape21T1160 : Tree 11 := .split 30 q11Shape21T1161 q11Shape21T1172
private theorem q11Shape21T1160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 1069647388 q11Shape21T1160=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (1069647388 ||| 2^30) q11Shape21T1161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^30) 1069647388 q11Shape21T1172)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1161OK,q11Shape21T1172OK⟩

private def q11Shape21T1173 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T1173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 539101443 532776476 q11Shape21T1173=true := by decide

private def q11Shape21T1159 : Tree 11 := .split 29 q11Shape21T1160 q11Shape21T1173
private theorem q11Shape21T1159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 532776476 q11Shape21T1159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (532776476 ||| 2^29) q11Shape21T1160 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^29) 532776476 q11Shape21T1173)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1160OK,q11Shape21T1173OK⟩

private def q11Shape21T1174 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T1174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 270665987 264341020 q11Shape21T1174=true := by decide

private def q11Shape21T1158 : Tree 11 := .split 28 q11Shape21T1159 q11Shape21T1174
private theorem q11Shape21T1158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 264341020 q11Shape21T1158=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (264341020 ||| 2^28) q11Shape21T1159 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^28) 264341020 q11Shape21T1174)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1159OK,q11Shape21T1174OK⟩

private def q11Shape21T1175 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T1175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 136448259 130123292 q11Shape21T1175=true := by decide

private def q11Shape21T1157 : Tree 11 := .split 27 q11Shape21T1158 q11Shape21T1175
private theorem q11Shape21T1157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 130123292 q11Shape21T1157=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (130123292 ||| 2^27) q11Shape21T1158 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^27) 130123292 q11Shape21T1175)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1158OK,q11Shape21T1175OK⟩

private def q11Shape21T1176 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T1176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 35784963 96568860 q11Shape21T1176=true := by decide

private def q11Shape21T1156 : Tree 11 := .split 25 q11Shape21T1157 q11Shape21T1176
private theorem q11Shape21T1156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 96568860 q11Shape21T1156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (96568860 ||| 2^25) q11Shape21T1157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^25) 96568860 q11Shape21T1176)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1157OK,q11Shape21T1176OK⟩

private def q11Shape21T1177 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T1177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 19007747 79791644 q11Shape21T1177=true := by decide

private def q11Shape21T1155 : Tree 11 := .split 24 q11Shape21T1156 q11Shape21T1177
private theorem q11Shape21T1155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 79791644 q11Shape21T1155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (79791644 ||| 2^24) q11Shape21T1156 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^24) 79791644 q11Shape21T1177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1156OK,q11Shape21T1177OK⟩

private def q11Shape21T1178 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T1178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 10619139 71403036 q11Shape21T1178=true := by decide

private def q11Shape21T1154 : Tree 11 := .split 23 q11Shape21T1155 q11Shape21T1178
private theorem q11Shape21T1154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 71403036 q11Shape21T1154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (71403036 ||| 2^23) q11Shape21T1155 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^23) 71403036 q11Shape21T1178)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1155OK,q11Shape21T1178OK⟩

private def q11Shape21T1179 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape21T1179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 6424835 67208732 q11Shape21T1179=true := by decide

private def q11Shape21T1153 : Tree 11 := .split 22 q11Shape21T1154 q11Shape21T1179
private theorem q11Shape21T1153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 67208732 q11Shape21T1153=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (67208732 ||| 2^22) q11Shape21T1154 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^22) 67208732 q11Shape21T1179)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1154OK,q11Shape21T1179OK⟩

private def q11Shape21T1180 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape21T1180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 69339395 99868 q11Shape21T1180=true := by decide

private def q11Shape21T1152 : Tree 11 := .split 26 q11Shape21T1153 q11Shape21T1180
private theorem q11Shape21T1152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 99868 q11Shape21T1152=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (99868 ||| 2^26) q11Shape21T1153 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^26) 99868 q11Shape21T1180)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1153OK,q11Shape21T1180OK⟩

private def q11Shape21T1181 : Tree 11 := (.tip (.cover {3,4,5,8,9,10}))
private theorem q11Shape21T1181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2296067 34332 q11Shape21T1181=true := by decide

private def q11Shape21T1151 : Tree 11 := .split 16 q11Shape21T1152 q11Shape21T1181
private theorem q11Shape21T1151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 34332 q11Shape21T1151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (34332 ||| 2^16) q11Shape21T1152 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^16) 34332 q11Shape21T1181)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1152OK,q11Shape21T1181OK⟩

private def q11Shape21T1182 : Tree 11 := (.tip (.cover {3,4,6,8,9,10}))
private theorem q11Shape21T1182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2263299 1564 q11Shape21T1182=true := by decide

private def q11Shape21T1150 : Tree 11 := .split 15 q11Shape21T1151 q11Shape21T1182
private theorem q11Shape21T1150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 1564 q11Shape21T1150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (1564 ||| 2^15) q11Shape21T1151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^15) 1564 q11Shape21T1182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1151OK,q11Shape21T1182OK⟩

private def q11Shape21T1183 : Tree 11 := (.tip (.cover {3,4,5,8,9,10}))
private theorem q11Shape21T1183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2231555 540 q11Shape21T1183=true := by decide

private def q11Shape21T1149 : Tree 11 := .split 10 q11Shape21T1150 q11Shape21T1183
private theorem q11Shape21T1149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 540 q11Shape21T1149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (540 ||| 2^10) q11Shape21T1150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^10) 540 q11Shape21T1183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1150OK,q11Shape21T1183OK⟩

private def q11Shape21T1184 : Tree 11 := (.tip (.cover {3,4,6,8,9,10}))
private theorem q11Shape21T1184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2231043 28 q11Shape21T1184=true := by decide

private def q11Shape21T1148 : Tree 11 := .split 9 q11Shape21T1149 q11Shape21T1184
private theorem q11Shape21T1148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 28 q11Shape21T1148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (28 ||| 2^9) q11Shape21T1149 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^9) 28 q11Shape21T1184)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1149OK,q11Shape21T1184OK⟩

private def q11Shape21T1185 : Tree 11 := (.tip (.cover {2,5,7,8,9,10}))
private theorem q11Shape21T1185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230539 20 q11Shape21T1185=true := by decide

private def q11Shape21T1147 : Tree 11 := .split 3 q11Shape21T1148 q11Shape21T1185
private theorem q11Shape21T1147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 20 q11Shape21T1147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (20 ||| 2^3) q11Shape21T1148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^3) 20 q11Shape21T1185)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1148OK,q11Shape21T1185OK⟩

private def q11Shape21T1186 : Tree 11 := (.tip (.cover {2,6,7,8,9,10}))
private theorem q11Shape21T1186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230535 16 q11Shape21T1186=true := by decide

private def q11Shape21T1146 : Tree 11 := .split 2 q11Shape21T1147 q11Shape21T1186
private theorem q11Shape21T1146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 16 q11Shape21T1146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (16 ||| 2^2) q11Shape21T1147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^2) 16 q11Shape21T1186)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1147OK,q11Shape21T1186OK⟩

private def q11Shape21T1187 : Tree 11 := (.tip (.cover {0,5,7,8,9,10}))
private theorem q11Shape21T1187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230547 0 q11Shape21T1187=true := by decide

private def q11Shape21T1145 : Tree 11 := .split 4 q11Shape21T1146 q11Shape21T1187
private theorem q11Shape21T1145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 0 q11Shape21T1145=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2230531 (0 ||| 2^4) q11Shape21T1146 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2230531 ||| 2^4) 0 q11Shape21T1187)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1146OK,q11Shape21T1187OK⟩

private def q11Shape21T1051 : Tree 11 := .split 17 q11Shape21T1052 q11Shape21T1145
private theorem q11Shape21T1051OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 0 q11Shape21T1051=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2099459 (0 ||| 2^17) q11Shape21T1052 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2099459 ||| 2^17) 0 q11Shape21T1145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T1052OK,q11Shape21T1145OK⟩

private def q11Shape21T859 : Tree 11 := .split 11 q11Shape21T860 q11Shape21T1051
private theorem q11Shape21T859OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097411 0 q11Shape21T859=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097411 (0 ||| 2^11) q11Shape21T860 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097411 ||| 2^11) 0 q11Shape21T1051)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T860OK,q11Shape21T1051OK⟩

private def q11Shape21T831 : Tree 11 := .split 8 q11Shape21T832 q11Shape21T859
private theorem q11Shape21T831OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 0 q11Shape21T831=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 (0 ||| 2^8) q11Shape21T832 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) (2097155 ||| 2^8) 0 q11Shape21T859)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape21T832OK,q11Shape21T859OK⟩

def q11Shape21P8 : Tree 11 := q11Shape21T831
theorem q11Shape21P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 21)) 2097155 0 q11Shape21P8=true := q11Shape21T831OK

end Graffiti384b.EffectiveSearch.Q11
