import Q11Shape22Part0
import Q11Shape22Part1
import Q11Shape22Part2
import Q11Shape22Part3
import Q11Shape22Part4
import Q11Shape22Part5
import Q11Shape22Part6
import Q11Shape22Part7
import Q11Shape22Part8
import Q11Shape22Part9
import Q11Shape22Part10
import Q11Shape22Part11

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22M67 : Tree 11 := .split 30 q11Shape22P1 q11Shape22P2
private theorem q11Shape22M67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 1006699528 q11Shape22M67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 (1006699528 ||| 2^30) q11Shape22P1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2097152 ||| 2^30) 1006699528 q11Shape22P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22P1OK,q11Shape22P2OK⟩
private def q11Shape22M68 : Tree 11 := .split 21 q11Shape22P0 q11Shape22M67
private theorem q11Shape22M68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 1006699528 q11Shape22M68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (1006699528 ||| 2^21) q11Shape22P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^21) 1006699528 q11Shape22M67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22P0OK,q11Shape22M67OK⟩
private def q11Shape22M108 : Tree 11 := .split 34 q11Shape22P4 q11Shape22P5
private theorem q11Shape22M108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8590000128 4229956616 q11Shape22M108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8590000128 (4229956616 ||| 2^34) q11Shape22P4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8590000128 ||| 2^34) 4229956616 q11Shape22P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22P4OK,q11Shape22P5OK⟩
private def q11Shape22M109 : Tree 11 := .split 33 q11Shape22P3 q11Shape22M108
private theorem q11Shape22M109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 4229956616 q11Shape22M109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 (4229956616 ||| 2^33) q11Shape22P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (65536 ||| 2^33) 4229956616 q11Shape22M108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22P3OK,q11Shape22M108OK⟩
private def q11Shape22M148 : Tree 11 := .split 33 q11Shape22P6 q11Shape22P7
private theorem q11Shape22M148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 6377440264 q11Shape22M148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 (6377440264 ||| 2^33) q11Shape22P6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147549184 ||| 2^33) 6377440264 q11Shape22P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22P6OK,q11Shape22P7OK⟩
private def q11Shape22M150 : Tree 11 := .split 32 q11Shape22M148 q11Shape22P8
private theorem q11Shape22M150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 2082472968 q11Shape22M150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 (2082472968 ||| 2^32) q11Shape22M148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147549184 ||| 2^32) 2082472968 q11Shape22P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M148OK,q11Shape22P8OK⟩
private def q11Shape22M151 : Tree 11 := .split 31 q11Shape22M109 q11Shape22M150
private theorem q11Shape22M151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 2082472968 q11Shape22M151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 (2082472968 ||| 2^31) q11Shape22M109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (65536 ||| 2^31) 2082472968 q11Shape22M150)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M109OK,q11Shape22M150OK⟩
private def q11Shape22M190 : Tree 11 := .split 33 q11Shape22P9 q11Shape22P10
private theorem q11Shape22M190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 7451182088 q11Shape22M190=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 (7451182088 ||| 2^33) q11Shape22P9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073807360 ||| 2^33) 7451182088 q11Shape22P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22P9OK,q11Shape22P10OK⟩
private def q11Shape22M192 : Tree 11 := .split 32 q11Shape22M190 q11Shape22P11
private theorem q11Shape22M192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 3156214792 q11Shape22M192=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 (3156214792 ||| 2^32) q11Shape22M190 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073807360 ||| 2^32) 3156214792 q11Shape22P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M190OK,q11Shape22P11OK⟩
private def q11Shape22M194 : Tree 11 := .split 31 q11Shape22M192 q11Shape22P12
private theorem q11Shape22M194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 1008731144 q11Shape22M194=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 (1008731144 ||| 2^31) q11Shape22M192 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073807360 ||| 2^31) 1008731144 q11Shape22P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M192OK,q11Shape22P12OK⟩
private def q11Shape22M195 : Tree 11 := .split 30 q11Shape22M151 q11Shape22M194
private theorem q11Shape22M195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 1008731144 q11Shape22M195=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 (1008731144 ||| 2^30) q11Shape22M151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (65536 ||| 2^30) 1008731144 q11Shape22M194)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M151OK,q11Shape22M194OK⟩
private def q11Shape22M197 : Tree 11 := .split 21 q11Shape22M195 q11Shape22P13
private theorem q11Shape22M197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 1006633992 q11Shape22M197=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 (1006633992 ||| 2^21) q11Shape22M195 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (65536 ||| 2^21) 1006633992 q11Shape22P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M195OK,q11Shape22P13OK⟩
private def q11Shape22M198 : Tree 11 := .split 16 q11Shape22M68 q11Shape22M197
private theorem q11Shape22M198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 1006633992 q11Shape22M198=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (1006633992 ||| 2^16) q11Shape22M68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^16) 1006633992 q11Shape22M197)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M68OK,q11Shape22M197OK⟩
private def q11Shape22M264 : Tree 11 := .split 10 q11Shape22M198 q11Shape22P14
private theorem q11Shape22M264OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 1006632968 q11Shape22M264=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (1006632968 ||| 2^10) q11Shape22M198 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^10) 1006632968 q11Shape22P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M198OK,q11Shape22P14OK⟩
private def q11Shape22M363 : Tree 11 := .split 31 q11Shape22P15 q11Shape22P16
private theorem q11Shape22M363OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 2082538496 q11Shape22M363=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 (2082538496 ||| 2^31) q11Shape22P15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8 ||| 2^31) 2082538496 q11Shape22P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22P15OK,q11Shape22P16OK⟩
private def q11Shape22M415 : Tree 11 := .split 30 q11Shape22M363 q11Shape22P17
private theorem q11Shape22M415OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 1008796672 q11Shape22M415=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 (1008796672 ||| 2^30) q11Shape22M363 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8 ||| 2^30) 1008796672 q11Shape22P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M363OK,q11Shape22P17OK⟩
private def q11Shape22M417 : Tree 11 := .split 21 q11Shape22M415 q11Shape22P18
private theorem q11Shape22M417OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 1006699520 q11Shape22M417=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 (1006699520 ||| 2^21) q11Shape22M415 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8 ||| 2^21) 1006699520 q11Shape22P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M415OK,q11Shape22P18OK⟩
private def q11Shape22M419 : Tree 11 := .split 16 q11Shape22M417 q11Shape22P19
private theorem q11Shape22M419OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 1006633984 q11Shape22M419=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 (1006633984 ||| 2^16) q11Shape22M417 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8 ||| 2^16) 1006633984 q11Shape22P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M417OK,q11Shape22P19OK⟩
private def q11Shape22M421 : Tree 11 := .split 10 q11Shape22M419 q11Shape22P20
private theorem q11Shape22M421OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 1006632960 q11Shape22M421=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 (1006632960 ||| 2^10) q11Shape22M419 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8 ||| 2^10) 1006632960 q11Shape22P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M419OK,q11Shape22P20OK⟩
private def q11Shape22M422 : Tree 11 := .split 3 q11Shape22M264 q11Shape22M421
private theorem q11Shape22M422OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 1006632960 q11Shape22M422=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (1006632960 ||| 2^3) q11Shape22M264 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^3) 1006632960 q11Shape22M421)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M264OK,q11Shape22M421OK⟩
private def q11Shape22M424 : Tree 11 := .split 29 q11Shape22M422 q11Shape22P21
private theorem q11Shape22M424OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 469762048 q11Shape22M424=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (469762048 ||| 2^29) q11Shape22M422 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^29) 469762048 q11Shape22P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M422OK,q11Shape22P21OK⟩
private def q11Shape22M426 : Tree 11 := .split 28 q11Shape22M424 q11Shape22P22
private theorem q11Shape22M426OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 201326592 q11Shape22M426=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (201326592 ||| 2^28) q11Shape22M424 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^28) 201326592 q11Shape22P22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M424OK,q11Shape22P22OK⟩
private def q11Shape22M428 : Tree 11 := .split 27 q11Shape22M426 q11Shape22P23
private theorem q11Shape22M428OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 67108864 q11Shape22M428=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (67108864 ||| 2^27) q11Shape22M426 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^27) 67108864 q11Shape22P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M426OK,q11Shape22P23OK⟩
private def q11Shape22M430 : Tree 11 := .split 26 q11Shape22M428 q11Shape22P24
private theorem q11Shape22M430OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 0 q11Shape22M430=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 (0 ||| 2^26) q11Shape22M428 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (0 ||| 2^26) 0 q11Shape22P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22M428OK,q11Shape22P24OK⟩

theorem q11Shape22_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 22) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 22) b) (adj 11 (forms 22) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) adj_mono b H q11Shape22M430 q11Shape22M430OK

#print axioms q11Shape22_cover

end Graffiti384b.EffectiveSearch.Q11
