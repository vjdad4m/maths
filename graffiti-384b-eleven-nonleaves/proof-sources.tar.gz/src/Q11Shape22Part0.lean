import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T0 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape22T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 1008796680 q11Shape22T0=true := by decide

def q11Shape22P0 : Tree 11 := q11Shape22T0
theorem q11Shape22P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 0 1008796680 q11Shape22P0=true := q11Shape22T0OK

private def q11Shape22T3 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape22T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 12817859592 q11Shape22T3=true := by decide

private def q11Shape22T6 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8592031744 25702761480 q11Shape22T6=true := by decide

private def q11Shape22T11 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))))))
private theorem q11Shape22T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 55767532559 q11Shape22T11=true := by decide

private def q11Shape22T12 : Tree 11 := (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999044 55767532555 q11Shape22T12=true := by decide

private def q11Shape22T10 : Tree 11 := .split 2 q11Shape22T11 q11Shape22T12
private theorem q11Shape22T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 55767532555 q11Shape22T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 (55767532555 ||| 2^2) q11Shape22T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12886999040 ||| 2^2) 55767532555 q11Shape22T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T11OK,q11Shape22T12OK⟩

private def q11Shape22T13 : Tree 11 := (.split 2 (.split 22 (.split 23 (.split 9 (.split 15 (.tip (.small 1)) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape22T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999042 55767532553 q11Shape22T13=true := by decide

private def q11Shape22T9 : Tree 11 := .split 1 q11Shape22T10 q11Shape22T13
private theorem q11Shape22T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 55767532553 q11Shape22T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 (55767532553 ||| 2^1) q11Shape22T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12886999040 ||| 2^1) 55767532553 q11Shape22T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T10OK,q11Shape22T13OK⟩

private def q11Shape22T15 : Tree 11 := (.split 2 (.split 22 (.split 23 (.split 9 (.split 15 (.tip (.small 1)) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape22T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999041 55767532554 q11Shape22T15=true := by decide

private def q11Shape22T17 : Tree 11 := (.split 22 (.split 23 (.split 9 (.split 15 (.split 8 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,5,7,9,10}))) (.tip (.cover {0,3,5,8,9,10})))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999043 55767532556 q11Shape22T17=true := by decide

private def q11Shape22T18 : Tree 11 := (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999047 55767532552 q11Shape22T18=true := by decide

private def q11Shape22T16 : Tree 11 := .split 2 q11Shape22T17 q11Shape22T18
private theorem q11Shape22T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999043 55767532552 q11Shape22T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999043 (55767532552 ||| 2^2) q11Shape22T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12886999043 ||| 2^2) 55767532552 q11Shape22T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T17OK,q11Shape22T18OK⟩

private def q11Shape22T14 : Tree 11 := .split 1 q11Shape22T15 q11Shape22T16
private theorem q11Shape22T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999041 55767532552 q11Shape22T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999041 (55767532552 ||| 2^1) q11Shape22T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12886999041 ||| 2^1) 55767532552 q11Shape22T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T15OK,q11Shape22T16OK⟩

private def q11Shape22T8 : Tree 11 := .split 0 q11Shape22T9 q11Shape22T14
private theorem q11Shape22T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 55767532552 q11Shape22T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 (55767532552 ||| 2^0) q11Shape22T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12886999040 ||| 2^0) 55767532552 q11Shape22T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T9OK,q11Shape22T14OK⟩

private def q11Shape22T19 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 47246737408 21407794184 q11Shape22T19=true := by decide

private def q11Shape22T7 : Tree 11 := .split 35 q11Shape22T8 q11Shape22T19
private theorem q11Shape22T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 21407794184 q11Shape22T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12886999040 (21407794184 ||| 2^35) q11Shape22T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12886999040 ||| 2^35) 21407794184 q11Shape22T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T8OK,q11Shape22T19OK⟩

private def q11Shape22T5 : Tree 11 := .split 32 q11Shape22T6 q11Shape22T7
private theorem q11Shape22T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8592031744 21407794184 q11Shape22T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8592031744 (21407794184 ||| 2^32) q11Shape22T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8592031744 ||| 2^32) 21407794184 q11Shape22T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T6OK,q11Shape22T7OK⟩

private def q11Shape22T20 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 25771900928 4227925000 q11Shape22T20=true := by decide

private def q11Shape22T4 : Tree 11 := .split 34 q11Shape22T5 q11Shape22T20
private theorem q11Shape22T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8592031744 4227925000 q11Shape22T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8592031744 (4227925000 ||| 2^34) q11Shape22T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8592031744 ||| 2^34) 4227925000 q11Shape22T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T5OK,q11Shape22T20OK⟩

private def q11Shape22T2 : Tree 11 := .split 33 q11Shape22T3 q11Shape22T4
private theorem q11Shape22T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 4227925000 q11Shape22T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 (4227925000 ||| 2^33) q11Shape22T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2097152 ||| 2^33) 4227925000 q11Shape22T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T3OK,q11Shape22T4OK⟩

private def q11Shape22T24 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2149580800 32145212424 q11Shape22T24=true := by decide

private def q11Shape22T29 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))))))
private theorem q11Shape22T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 49325081615 q11Shape22T29=true := by decide

private def q11Shape22T30 : Tree 11 := (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449988 49325081611 q11Shape22T30=true := by decide

private def q11Shape22T28 : Tree 11 := .split 2 q11Shape22T29 q11Shape22T30
private theorem q11Shape22T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 49325081611 q11Shape22T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 (49325081611 ||| 2^2) q11Shape22T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19329449984 ||| 2^2) 49325081611 q11Shape22T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T29OK,q11Shape22T30OK⟩

private def q11Shape22T31 : Tree 11 := (.split 2 (.split 22 (.split 23 (.split 9 (.split 15 (.tip (.small 1)) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape22T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449986 49325081609 q11Shape22T31=true := by decide

private def q11Shape22T27 : Tree 11 := .split 1 q11Shape22T28 q11Shape22T31
private theorem q11Shape22T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 49325081609 q11Shape22T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 (49325081609 ||| 2^1) q11Shape22T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19329449984 ||| 2^1) 49325081609 q11Shape22T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T28OK,q11Shape22T31OK⟩

private def q11Shape22T33 : Tree 11 := (.split 2 (.split 22 (.split 23 (.split 9 (.split 15 (.tip (.small 1)) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape22T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449985 49325081610 q11Shape22T33=true := by decide

private def q11Shape22T35 : Tree 11 := (.split 22 (.split 23 (.split 9 (.split 15 (.split 8 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,5,7,9,10}))) (.tip (.cover {0,3,5,8,9,10})))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {2,3,4,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449987 49325081612 q11Shape22T35=true := by decide

private def q11Shape22T36 : Tree 11 := (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449991 49325081608 q11Shape22T36=true := by decide

private def q11Shape22T34 : Tree 11 := .split 2 q11Shape22T35 q11Shape22T36
private theorem q11Shape22T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449987 49325081608 q11Shape22T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449987 (49325081608 ||| 2^2) q11Shape22T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19329449987 ||| 2^2) 49325081608 q11Shape22T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T35OK,q11Shape22T36OK⟩

private def q11Shape22T32 : Tree 11 := .split 1 q11Shape22T33 q11Shape22T34
private theorem q11Shape22T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449985 49325081608 q11Shape22T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449985 (49325081608 ||| 2^1) q11Shape22T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19329449985 ||| 2^1) 49325081608 q11Shape22T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T33OK,q11Shape22T34OK⟩

private def q11Shape22T26 : Tree 11 := .split 0 q11Shape22T27 q11Shape22T32
private theorem q11Shape22T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 49325081608 q11Shape22T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 (49325081608 ||| 2^0) q11Shape22T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19329449984 ||| 2^0) 49325081608 q11Shape22T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T27OK,q11Shape22T32OK⟩

private def q11Shape22T37 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 53689188352 14965343240 q11Shape22T37=true := by decide

private def q11Shape22T25 : Tree 11 := .split 35 q11Shape22T26 q11Shape22T37
private theorem q11Shape22T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 14965343240 q11Shape22T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19329449984 (14965343240 ||| 2^35) q11Shape22T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19329449984 ||| 2^35) 14965343240 q11Shape22T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T26OK,q11Shape22T37OK⟩

private def q11Shape22T23 : Tree 11 := .split 34 q11Shape22T24 q11Shape22T25
private theorem q11Shape22T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2149580800 14965343240 q11Shape22T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2149580800 (14965343240 ||| 2^34) q11Shape22T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2149580800 ||| 2^34) 14965343240 q11Shape22T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T24OK,q11Shape22T25OK⟩

private def q11Shape22T38 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape22T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 10739515392 6375408648 q11Shape22T38=true := by decide

private def q11Shape22T22 : Tree 11 := .split 33 q11Shape22T23 q11Shape22T38
private theorem q11Shape22T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2149580800 6375408648 q11Shape22T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2149580800 (6375408648 ||| 2^33) q11Shape22T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2149580800 ||| 2^33) 6375408648 q11Shape22T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T23OK,q11Shape22T38OK⟩

private def q11Shape22T39 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 6444548096 2080441352 q11Shape22T39=true := by decide

private def q11Shape22T21 : Tree 11 := .split 32 q11Shape22T22 q11Shape22T39
private theorem q11Shape22T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2149580800 2080441352 q11Shape22T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2149580800 (2080441352 ||| 2^32) q11Shape22T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2149580800 ||| 2^32) 2080441352 q11Shape22T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T22OK,q11Shape22T39OK⟩

private def q11Shape22T1 : Tree 11 := .split 31 q11Shape22T2 q11Shape22T21
private theorem q11Shape22T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 2080441352 q11Shape22T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 (2080441352 ||| 2^31) q11Shape22T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2097152 ||| 2^31) 2080441352 q11Shape22T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T2OK,q11Shape22T21OK⟩

def q11Shape22P1 : Tree 11 := q11Shape22T1
theorem q11Shape22P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097152 2080441352 q11Shape22P1=true := q11Shape22T1OK

end Graffiti384b.EffectiveSearch.Q11
