import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T45 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape22T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 67578692616 q11Shape22T45=true := by decide

private def q11Shape22T49 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,8,9,10}))))))
private theorem q11Shape22T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577344 33218954255 q11Shape22T49=true := by decide

private def q11Shape22T50 : Tree 11 := (.split 22 (.split 13 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577348 33218954251 q11Shape22T50=true := by decide

private def q11Shape22T48 : Tree 11 := .split 2 q11Shape22T49 q11Shape22T50
private theorem q11Shape22T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577344 33218954251 q11Shape22T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577344 (33218954251 ||| 2^2) q11Shape22T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577344 ||| 2^2) 33218954251 q11Shape22T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T49OK,q11Shape22T50OK⟩

private def q11Shape22T52 : Tree 11 := (.split 22 (.split 23 (.split 24 (.split 9 (.split 15 (.tip (.small 1)) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577346 33218954253 q11Shape22T52=true := by decide

private def q11Shape22T53 : Tree 11 := (.split 22 (.split 13 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577350 33218954249 q11Shape22T53=true := by decide

private def q11Shape22T51 : Tree 11 := .split 2 q11Shape22T52 q11Shape22T53
private theorem q11Shape22T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577346 33218954249 q11Shape22T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577346 (33218954249 ||| 2^2) q11Shape22T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577346 ||| 2^2) 33218954249 q11Shape22T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T52OK,q11Shape22T53OK⟩

private def q11Shape22T47 : Tree 11 := .split 1 q11Shape22T48 q11Shape22T51
private theorem q11Shape22T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577344 33218954249 q11Shape22T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577344 (33218954249 ||| 2^1) q11Shape22T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577344 ||| 2^1) 33218954249 q11Shape22T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T48OK,q11Shape22T51OK⟩

private def q11Shape22T56 : Tree 11 := (.split 22 (.split 23 (.split 24 (.split 9 (.split 15 (.tip (.small 1)) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577345 33218954254 q11Shape22T56=true := by decide

private def q11Shape22T57 : Tree 11 := (.split 22 (.split 13 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577349 33218954250 q11Shape22T57=true := by decide

private def q11Shape22T55 : Tree 11 := .split 2 q11Shape22T56 q11Shape22T57
private theorem q11Shape22T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577345 33218954250 q11Shape22T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577345 (33218954250 ||| 2^2) q11Shape22T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577345 ||| 2^2) 33218954250 q11Shape22T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T56OK,q11Shape22T57OK⟩

private def q11Shape22T60 : Tree 11 := (.split 23 (.split 24 (.split 9 (.split 15 (.split 8 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,5,7,8,10}))) (.tip (.cover {0,3,5,8,9,10})))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape22T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577347 33223148556 q11Shape22T60=true := by decide

private def q11Shape22T61 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape22T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35439771651 33218954252 q11Shape22T61=true := by decide

private def q11Shape22T59 : Tree 11 := .split 22 q11Shape22T60 q11Shape22T61
private theorem q11Shape22T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577347 33218954252 q11Shape22T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577347 (33218954252 ||| 2^22) q11Shape22T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577347 ||| 2^22) 33218954252 q11Shape22T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T60OK,q11Shape22T61OK⟩

private def q11Shape22T62 : Tree 11 := (.split 22 (.split 13 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,6,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape22T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577351 33218954248 q11Shape22T62=true := by decide

private def q11Shape22T58 : Tree 11 := .split 2 q11Shape22T59 q11Shape22T62
private theorem q11Shape22T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577347 33218954248 q11Shape22T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577347 (33218954248 ||| 2^2) q11Shape22T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577347 ||| 2^2) 33218954248 q11Shape22T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T59OK,q11Shape22T62OK⟩

private def q11Shape22T54 : Tree 11 := .split 1 q11Shape22T55 q11Shape22T58
private theorem q11Shape22T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577345 33218954248 q11Shape22T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577345 (33218954248 ||| 2^1) q11Shape22T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577345 ||| 2^1) 33218954248 q11Shape22T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T55OK,q11Shape22T58OK⟩

private def q11Shape22T46 : Tree 11 := .split 0 q11Shape22T47 q11Shape22T54
private theorem q11Shape22T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577344 33218954248 q11Shape22T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35435577344 (33218954248 ||| 2^0) q11Shape22T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35435577344 ||| 2^0) 33218954248 q11Shape22T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T47OK,q11Shape22T54OK⟩

private def q11Shape22T44 : Tree 11 := .split 35 q11Shape22T45 q11Shape22T46
private theorem q11Shape22T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 33218954248 q11Shape22T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 (33218954248 ||| 2^35) q11Shape22T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1075838976 ||| 2^35) 33218954248 q11Shape22T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T45OK,q11Shape22T46OK⟩

private def q11Shape22T63 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 18255708160 16039085064 q11Shape22T63=true := by decide

private def q11Shape22T43 : Tree 11 := .split 34 q11Shape22T44 q11Shape22T63
private theorem q11Shape22T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 16039085064 q11Shape22T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 (16039085064 ||| 2^34) q11Shape22T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1075838976 ||| 2^34) 16039085064 q11Shape22T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T44OK,q11Shape22T63OK⟩

private def q11Shape22T64 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 9665773568 7449150472 q11Shape22T64=true := by decide

private def q11Shape22T42 : Tree 11 := .split 33 q11Shape22T43 q11Shape22T64
private theorem q11Shape22T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 7449150472 q11Shape22T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 (7449150472 ||| 2^33) q11Shape22T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1075838976 ||| 2^33) 7449150472 q11Shape22T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T43OK,q11Shape22T64OK⟩

private def q11Shape22T65 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 5370806272 3154183176 q11Shape22T65=true := by decide

private def q11Shape22T41 : Tree 11 := .split 32 q11Shape22T42 q11Shape22T65
private theorem q11Shape22T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 3154183176 q11Shape22T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 (3154183176 ||| 2^32) q11Shape22T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1075838976 ||| 2^32) 3154183176 q11Shape22T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T42OK,q11Shape22T65OK⟩

private def q11Shape22T66 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 3223322624 1006699528 q11Shape22T66=true := by decide

private def q11Shape22T40 : Tree 11 := .split 31 q11Shape22T41 q11Shape22T66
private theorem q11Shape22T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 1006699528 q11Shape22T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 (1006699528 ||| 2^31) q11Shape22T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1075838976 ||| 2^31) 1006699528 q11Shape22T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T41OK,q11Shape22T66OK⟩

def q11Shape22P2 : Tree 11 := q11Shape22T40
theorem q11Shape22P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1075838976 1006699528 q11Shape22P2=true := q11Shape22T40OK

private def q11Shape22T69 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape22T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 12819891208 q11Shape22T69=true := by decide

def q11Shape22P3 : Tree 11 := q11Shape22T69
theorem q11Shape22P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65536 12819891208 q11Shape22P3=true := q11Shape22T69OK

end Graffiti384b.EffectiveSearch.Q11
