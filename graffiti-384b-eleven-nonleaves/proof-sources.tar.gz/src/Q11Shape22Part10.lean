import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T369 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape22T369OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 67580789760 q11Shape22T369=true := by decide

private def q11Shape22T373 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,2,3,7,8,10}))) (.tip (.cover {0,2,3,8,9,10}))))))
private theorem q11Shape22T373OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480200 33221051399 q11Shape22T373=true := by decide

private def q11Shape22T374 : Tree 11 := (.split 8 (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,2,5,7,8,10}))) (.tip (.cover {0,2,5,8,9,10}))))) (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,2,3,7,8,10}))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape22T374OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480204 33221051395 q11Shape22T374=true := by decide

private def q11Shape22T372 : Tree 11 := .split 2 q11Shape22T373 q11Shape22T374
private theorem q11Shape22T372OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480200 33221051395 q11Shape22T372=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480200 (33221051395 ||| 2^2) q11Shape22T373 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480200 ||| 2^2) 33221051395 q11Shape22T374)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T373OK,q11Shape22T374OK⟩

private def q11Shape22T377 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {3,4,6,7,8,10}))) (.tip (.cover {3,4,6,8,9,10})))))
private theorem q11Shape22T377OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480202 33221051653 q11Shape22T377=true := by decide

private def q11Shape22T379 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.split 22 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {2,3,5,6,8,10})))) (.split 24 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {2,3,5,6,8,10})))))
private theorem q11Shape22T379OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480458 33221051909 q11Shape22T379=true := by decide

private def q11Shape22T380 : Tree 11 := (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,2,3,7,8,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape22T380OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480970 33221051397 q11Shape22T380=true := by decide

private def q11Shape22T378 : Tree 11 := .split 9 q11Shape22T379 q11Shape22T380
private theorem q11Shape22T378OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480458 33221051397 q11Shape22T378=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480458 (33221051397 ||| 2^9) q11Shape22T379 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480458 ||| 2^9) 33221051397 q11Shape22T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T379OK,q11Shape22T380OK⟩

private def q11Shape22T376 : Tree 11 := .split 8 q11Shape22T377 q11Shape22T378
private theorem q11Shape22T376OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480202 33221051397 q11Shape22T376=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480202 (33221051397 ||| 2^8) q11Shape22T377 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480202 ||| 2^8) 33221051397 q11Shape22T378)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T377OK,q11Shape22T378OK⟩

private def q11Shape22T385 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 14 (.split 22 (.split 24 (.tip (.cover {0,1,2,4,8,10})) (.split 17 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,8,10})))) (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {3,4,5,6,8,10})))) (.tip (.cover {0,2,3,7,8,9})))) (.tip (.cover {0,2,4,5,7,10})))
private theorem q11Shape22T385OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 33221065985 q11Shape22T385=true := by decide

private def q11Shape22T386 : Tree 11 := (.tip (.cover {0,2,4,5,7,10}))
private theorem q11Shape22T386OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480462 33221065729 q11Shape22T386=true := by decide

private def q11Shape22T384 : Tree 11 := .split 8 q11Shape22T385 q11Shape22T386
private theorem q11Shape22T384OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 33221065729 q11Shape22T384=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 (33221065729 ||| 2^8) q11Shape22T385 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480206 ||| 2^8) 33221065729 q11Shape22T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T385OK,q11Shape22T386OK⟩

private def q11Shape22T387 : Tree 11 := (.tip (.cover {0,2,3,7,8,10}))
private theorem q11Shape22T387OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433488398 33221057537 q11Shape22T387=true := by decide

private def q11Shape22T383 : Tree 11 := .split 13 q11Shape22T384 q11Shape22T387
private theorem q11Shape22T383OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 33221057537 q11Shape22T383=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 (33221057537 ||| 2^13) q11Shape22T384 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480206 ||| 2^13) 33221057537 q11Shape22T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T384OK,q11Shape22T387OK⟩

private def q11Shape22T388 : Tree 11 := (.tip (.cover {0,2,3,7,9,10}))
private theorem q11Shape22T388OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433484302 33221053441 q11Shape22T388=true := by decide

private def q11Shape22T382 : Tree 11 := .split 12 q11Shape22T383 q11Shape22T388
private theorem q11Shape22T382OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 33221053441 q11Shape22T382=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 (33221053441 ||| 2^12) q11Shape22T383 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480206 ||| 2^12) 33221053441 q11Shape22T388)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T383OK,q11Shape22T388OK⟩

private def q11Shape22T389 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape22T389OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433482254 33221051393 q11Shape22T389=true := by decide

private def q11Shape22T381 : Tree 11 := .split 11 q11Shape22T382 q11Shape22T389
private theorem q11Shape22T381OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 33221051393 q11Shape22T381=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480206 (33221051393 ||| 2^11) q11Shape22T382 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480206 ||| 2^11) 33221051393 q11Shape22T389)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T382OK,q11Shape22T389OK⟩

private def q11Shape22T375 : Tree 11 := .split 2 q11Shape22T376 q11Shape22T381
private theorem q11Shape22T375OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480202 33221051393 q11Shape22T375=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480202 (33221051393 ||| 2^2) q11Shape22T376 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480202 ||| 2^2) 33221051393 q11Shape22T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T376OK,q11Shape22T381OK⟩

private def q11Shape22T371 : Tree 11 := .split 1 q11Shape22T372 q11Shape22T375
private theorem q11Shape22T371OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480200 33221051393 q11Shape22T371=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480200 (33221051393 ||| 2^1) q11Shape22T372 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480200 ||| 2^1) 33221051393 q11Shape22T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T372OK,q11Shape22T375OK⟩

private def q11Shape22T393 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {3,4,6,7,8,10}))) (.tip (.cover {3,4,6,8,9,10})))))
private theorem q11Shape22T393OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480201 33221051654 q11Shape22T393=true := by decide

private def q11Shape22T394 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {3,5,6,7,8,10}))) (.tip (.cover {3,5,6,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,2,3,7,8,10}))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape22T394OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480457 33221051398 q11Shape22T394=true := by decide

private def q11Shape22T392 : Tree 11 := .split 8 q11Shape22T393 q11Shape22T394
private theorem q11Shape22T392OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480201 33221051398 q11Shape22T392=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480201 (33221051398 ||| 2^8) q11Shape22T393 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480201 ||| 2^8) 33221051398 q11Shape22T394)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T393OK,q11Shape22T394OK⟩

private def q11Shape22T397 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 22 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,2,5,7,8,10}))) (.tip (.cover {0,2,5,8,9,10}))))
private theorem q11Shape22T397OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480205 33221052162 q11Shape22T397=true := by decide

private def q11Shape22T398 : Tree 11 := (.split 15 (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.split 22 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {3,4,5,6,8,10})))) (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {3,4,5,6,8,10})))) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {3,4,6,7,8,10}))) (.tip (.cover {3,4,6,8,9,10}))))
private theorem q11Shape22T398OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480717 33221051650 q11Shape22T398=true := by decide

private def q11Shape22T396 : Tree 11 := .split 9 q11Shape22T397 q11Shape22T398
private theorem q11Shape22T396OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480205 33221051650 q11Shape22T396=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480205 (33221051650 ||| 2^9) q11Shape22T397 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480205 ||| 2^9) 33221051650 q11Shape22T398)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T397OK,q11Shape22T398OK⟩

private def q11Shape22T399 : Tree 11 := (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,2,3,7,8,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape22T399OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480461 33221051394 q11Shape22T399=true := by decide

private def q11Shape22T395 : Tree 11 := .split 8 q11Shape22T396 q11Shape22T399
private theorem q11Shape22T395OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480205 33221051394 q11Shape22T395=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480205 (33221051394 ||| 2^8) q11Shape22T396 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480205 ||| 2^8) 33221051394 q11Shape22T399)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T396OK,q11Shape22T399OK⟩

private def q11Shape22T391 : Tree 11 := .split 2 q11Shape22T392 q11Shape22T395
private theorem q11Shape22T391OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480201 33221051394 q11Shape22T391=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480201 (33221051394 ||| 2^2) q11Shape22T392 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480201 ||| 2^2) 33221051394 q11Shape22T395)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T392OK,q11Shape22T395OK⟩

private def q11Shape22T405 : Tree 11 := (.split 15 (.split 8 (.tip (.small 1)) (.split 25 (.split 11 (.split 13 (.tip (.cover {0,1,2,4,8,10})) (.split 17 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,8,10})))) (.split 19 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {3,4,5,6,8,10})))) (.tip (.cover {0,2,3,4,7,10})))) (.tip (.cover {0,2,3,4,7,10})))
private theorem q11Shape22T405OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 33250412036 q11Shape22T405=true := by decide

private def q11Shape22T406 : Tree 11 := (.tip (.cover {0,2,3,4,7,10}))
private theorem q11Shape22T406OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480715 33250411524 q11Shape22T406=true := by decide

private def q11Shape22T404 : Tree 11 := .split 9 q11Shape22T405 q11Shape22T406
private theorem q11Shape22T404OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 33250411524 q11Shape22T404=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 (33250411524 ||| 2^9) q11Shape22T405 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480203 ||| 2^9) 33250411524 q11Shape22T406)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T405OK,q11Shape22T406OK⟩

private def q11Shape22T407 : Tree 11 := (.tip (.cover {0,2,5,7,8,10}))
private theorem q11Shape22T407OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35450257419 33233634308 q11Shape22T407=true := by decide

private def q11Shape22T403 : Tree 11 := .split 24 q11Shape22T404 q11Shape22T407
private theorem q11Shape22T403OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 33233634308 q11Shape22T403=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 (33233634308 ||| 2^24) q11Shape22T404 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480203 ||| 2^24) 33233634308 q11Shape22T407)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T404OK,q11Shape22T407OK⟩

private def q11Shape22T408 : Tree 11 := (.tip (.cover {0,2,5,7,9,10}))
private theorem q11Shape22T408OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35441868811 33225245700 q11Shape22T408=true := by decide

private def q11Shape22T402 : Tree 11 := .split 23 q11Shape22T403 q11Shape22T408
private theorem q11Shape22T402OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 33225245700 q11Shape22T402=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 (33225245700 ||| 2^23) q11Shape22T403 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480203 ||| 2^23) 33225245700 q11Shape22T408)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T403OK,q11Shape22T408OK⟩

private def q11Shape22T409 : Tree 11 := (.tip (.cover {0,2,5,8,9,10}))
private theorem q11Shape22T409OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35437674507 33221051396 q11Shape22T409=true := by decide

private def q11Shape22T401 : Tree 11 := .split 22 q11Shape22T402 q11Shape22T409
private theorem q11Shape22T401OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 33221051396 q11Shape22T401=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 (33221051396 ||| 2^22) q11Shape22T402 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480203 ||| 2^22) 33221051396 q11Shape22T409)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T402OK,q11Shape22T409OK⟩

private def q11Shape22T410 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape22T410OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480207 33221051392 q11Shape22T410=true := by decide

private def q11Shape22T400 : Tree 11 := .split 2 q11Shape22T401 q11Shape22T410
private theorem q11Shape22T400OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 33221051392 q11Shape22T400=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480203 (33221051392 ||| 2^2) q11Shape22T401 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480203 ||| 2^2) 33221051392 q11Shape22T410)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T401OK,q11Shape22T410OK⟩

private def q11Shape22T390 : Tree 11 := .split 1 q11Shape22T391 q11Shape22T400
private theorem q11Shape22T390OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480201 33221051392 q11Shape22T390=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480201 (33221051392 ||| 2^1) q11Shape22T391 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480201 ||| 2^1) 33221051392 q11Shape22T400)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T391OK,q11Shape22T400OK⟩

private def q11Shape22T370 : Tree 11 := .split 0 q11Shape22T371 q11Shape22T390
private theorem q11Shape22T370OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480200 33221051392 q11Shape22T370=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433480200 (33221051392 ||| 2^0) q11Shape22T371 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433480200 ||| 2^0) 33221051392 q11Shape22T390)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T371OK,q11Shape22T390OK⟩

private def q11Shape22T368 : Tree 11 := .split 35 q11Shape22T369 q11Shape22T370
private theorem q11Shape22T368OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 33221051392 q11Shape22T368=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 (33221051392 ||| 2^35) q11Shape22T369 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073741832 ||| 2^35) 33221051392 q11Shape22T370)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T369OK,q11Shape22T370OK⟩

private def q11Shape22T411 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T411OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 18253611016 16041182208 q11Shape22T411=true := by decide

private def q11Shape22T367 : Tree 11 := .split 34 q11Shape22T368 q11Shape22T411
private theorem q11Shape22T367OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 16041182208 q11Shape22T367=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 (16041182208 ||| 2^34) q11Shape22T368 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073741832 ||| 2^34) 16041182208 q11Shape22T411)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T368OK,q11Shape22T411OK⟩

private def q11Shape22T412 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T412OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 9663676424 7451247616 q11Shape22T412=true := by decide

private def q11Shape22T366 : Tree 11 := .split 33 q11Shape22T367 q11Shape22T412
private theorem q11Shape22T366OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 7451247616 q11Shape22T366=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 (7451247616 ||| 2^33) q11Shape22T367 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073741832 ||| 2^33) 7451247616 q11Shape22T412)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T367OK,q11Shape22T412OK⟩

private def q11Shape22T413 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T413OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 5368709128 3156280320 q11Shape22T413=true := by decide

private def q11Shape22T365 : Tree 11 := .split 32 q11Shape22T366 q11Shape22T413
private theorem q11Shape22T365OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 3156280320 q11Shape22T365=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 (3156280320 ||| 2^32) q11Shape22T366 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073741832 ||| 2^32) 3156280320 q11Shape22T413)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T366OK,q11Shape22T413OK⟩

private def q11Shape22T414 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T414OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 3221225480 1008796672 q11Shape22T414=true := by decide

private def q11Shape22T364 : Tree 11 := .split 31 q11Shape22T365 q11Shape22T414
private theorem q11Shape22T364OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 1008796672 q11Shape22T364=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 (1008796672 ||| 2^31) q11Shape22T365 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073741832 ||| 2^31) 1008796672 q11Shape22T414)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T365OK,q11Shape22T414OK⟩

def q11Shape22P17 : Tree 11 := q11Shape22T364
theorem q11Shape22P17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073741832 1008796672 q11Shape22P17=true := q11Shape22T364OK

private def q11Shape22T416 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape22T416OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097160 1006699520 q11Shape22T416=true := by decide

def q11Shape22P18 : Tree 11 := q11Shape22T416
theorem q11Shape22P18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2097160 1006699520 q11Shape22P18=true := q11Shape22T416OK

private def q11Shape22T418 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape22T418OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65544 1006633984 q11Shape22T418=true := by decide

def q11Shape22P19 : Tree 11 := q11Shape22T418
theorem q11Shape22P19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 65544 1006633984 q11Shape22P19=true := q11Shape22T418OK

private def q11Shape22T420 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape22T420OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1032 1006632960 q11Shape22T420=true := by decide

def q11Shape22P20 : Tree 11 := q11Shape22T420
theorem q11Shape22P20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1032 1006632960 q11Shape22P20=true := q11Shape22T420OK

private def q11Shape22T423 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape22T423OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 536870912 469762048 q11Shape22T423=true := by decide

def q11Shape22P21 : Tree 11 := q11Shape22T423
theorem q11Shape22P21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 536870912 469762048 q11Shape22P21=true := q11Shape22T423OK

private def q11Shape22T425 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape22T425OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 268435456 201326592 q11Shape22T425=true := by decide

def q11Shape22P22 : Tree 11 := q11Shape22T425
theorem q11Shape22P22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 268435456 201326592 q11Shape22P22=true := q11Shape22T425OK

end Graffiti384b.EffectiveSearch.Q11
