import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T427 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape22T427OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 134217728 67108864 q11Shape22T427=true := by decide

def q11Shape22P23 : Tree 11 := q11Shape22T427
theorem q11Shape22P23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 134217728 67108864 q11Shape22P23=true := q11Shape22T427OK

private def q11Shape22T429 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape22T429OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 67108864 0 q11Shape22T429=true := by decide

def q11Shape22P24 : Tree 11 := q11Shape22T429
theorem q11Shape22P24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 67108864 0 q11Shape22P24=true := q11Shape22T429OK

end Graffiti384b.EffectiveSearch.Q11
