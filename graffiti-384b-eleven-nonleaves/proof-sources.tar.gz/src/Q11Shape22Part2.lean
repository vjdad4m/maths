import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T71 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8590000128 25704793096 q11Shape22T71=true := by decide

private def q11Shape22T76 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.split 22 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {2,3,5,6,9,10})))))))
private theorem q11Shape22T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 55769564175 q11Shape22T76=true := by decide

private def q11Shape22T77 : Tree 11 := (.split 8 (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10}))))) (.split 22 (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10}))))
private theorem q11Shape22T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967428 55769564171 q11Shape22T77=true := by decide

private def q11Shape22T75 : Tree 11 := .split 2 q11Shape22T76 q11Shape22T77
private theorem q11Shape22T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 55769564171 q11Shape22T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 (55769564171 ||| 2^2) q11Shape22T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967424 ||| 2^2) 55769564171 q11Shape22T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T76OK,q11Shape22T77OK⟩

private def q11Shape22T80 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))))
private theorem q11Shape22T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967426 55769564429 q11Shape22T80=true := by decide

private def q11Shape22T81 : Tree 11 := (.split 15 (.split 9 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967682 55769564173 q11Shape22T81=true := by decide

private def q11Shape22T79 : Tree 11 := .split 8 q11Shape22T80 q11Shape22T81
private theorem q11Shape22T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967426 55769564173 q11Shape22T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967426 (55769564173 ||| 2^8) q11Shape22T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967426 ||| 2^8) 55769564173 q11Shape22T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T80OK,q11Shape22T81OK⟩

private def q11Shape22T84 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.split 13 (.split 14 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,2,4,5,8,10}))) (.tip (.cover {0,2,4,5,9,10}))) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967430 55769564937 q11Shape22T84=true := by decide

private def q11Shape22T85 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape22T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967942 55769564425 q11Shape22T85=true := by decide

private def q11Shape22T83 : Tree 11 := .split 9 q11Shape22T84 q11Shape22T85
private theorem q11Shape22T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967430 55769564425 q11Shape22T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967430 (55769564425 ||| 2^9) q11Shape22T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967430 ||| 2^9) 55769564425 q11Shape22T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T84OK,q11Shape22T85OK⟩

private def q11Shape22T86 : Tree 11 := (.split 15 (.split 22 (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967686 55769564169 q11Shape22T86=true := by decide

private def q11Shape22T82 : Tree 11 := .split 8 q11Shape22T83 q11Shape22T86
private theorem q11Shape22T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967430 55769564169 q11Shape22T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967430 (55769564169 ||| 2^8) q11Shape22T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967430 ||| 2^8) 55769564169 q11Shape22T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T83OK,q11Shape22T86OK⟩

private def q11Shape22T78 : Tree 11 := .split 2 q11Shape22T79 q11Shape22T82
private theorem q11Shape22T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967426 55769564169 q11Shape22T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967426 (55769564169 ||| 2^2) q11Shape22T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967426 ||| 2^2) 55769564169 q11Shape22T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T79OK,q11Shape22T82OK⟩

private def q11Shape22T74 : Tree 11 := .split 1 q11Shape22T75 q11Shape22T78
private theorem q11Shape22T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 55769564169 q11Shape22T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 (55769564169 ||| 2^1) q11Shape22T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967424 ||| 2^1) 55769564169 q11Shape22T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T75OK,q11Shape22T78OK⟩

private def q11Shape22T90 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))))
private theorem q11Shape22T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967425 55769564430 q11Shape22T90=true := by decide

private def q11Shape22T91 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967681 55769564174 q11Shape22T91=true := by decide

private def q11Shape22T89 : Tree 11 := .split 8 q11Shape22T90 q11Shape22T91
private theorem q11Shape22T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967425 55769564174 q11Shape22T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967425 (55769564174 ||| 2^8) q11Shape22T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967425 ||| 2^8) 55769564174 q11Shape22T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T90OK,q11Shape22T91OK⟩

private def q11Shape22T93 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967429 55769564426 q11Shape22T93=true := by decide

private def q11Shape22T94 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10})))
private theorem q11Shape22T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967685 55769564170 q11Shape22T94=true := by decide

private def q11Shape22T92 : Tree 11 := .split 8 q11Shape22T93 q11Shape22T94
private theorem q11Shape22T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967429 55769564170 q11Shape22T92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967429 (55769564170 ||| 2^8) q11Shape22T93 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967429 ||| 2^8) 55769564170 q11Shape22T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T93OK,q11Shape22T94OK⟩

private def q11Shape22T88 : Tree 11 := .split 2 q11Shape22T89 q11Shape22T92
private theorem q11Shape22T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967425 55769564170 q11Shape22T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967425 (55769564170 ||| 2^2) q11Shape22T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967425 ||| 2^2) 55769564170 q11Shape22T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T89OK,q11Shape22T92OK⟩

private def q11Shape22T97 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967427 55769564428 q11Shape22T97=true := by decide

private def q11Shape22T99 : Tree 11 := (.split 22 (.split 23 (.split 9 (.split 24 (.split 25 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10}))) (.tip (.cover {0,2,3,4,9,10}))) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10})))
private theorem q11Shape22T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967683 55769596940 q11Shape22T99=true := by decide

private def q11Shape22T100 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape22T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12885000451 55769564172 q11Shape22T100=true := by decide

private def q11Shape22T98 : Tree 11 := .split 15 q11Shape22T99 q11Shape22T100
private theorem q11Shape22T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967683 55769564172 q11Shape22T98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967683 (55769564172 ||| 2^15) q11Shape22T99 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967683 ||| 2^15) 55769564172 q11Shape22T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T99OK,q11Shape22T100OK⟩

private def q11Shape22T96 : Tree 11 := .split 8 q11Shape22T97 q11Shape22T98
private theorem q11Shape22T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967427 55769564172 q11Shape22T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967427 (55769564172 ||| 2^8) q11Shape22T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967427 ||| 2^8) 55769564172 q11Shape22T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T97OK,q11Shape22T98OK⟩

private def q11Shape22T103 : Tree 11 := (.split 15 (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.split 22 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10}))))
private theorem q11Shape22T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967431 55769564936 q11Shape22T103=true := by decide

private def q11Shape22T104 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape22T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967943 55769564424 q11Shape22T104=true := by decide

private def q11Shape22T102 : Tree 11 := .split 9 q11Shape22T103 q11Shape22T104
private theorem q11Shape22T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967431 55769564424 q11Shape22T102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967431 (55769564424 ||| 2^9) q11Shape22T103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967431 ||| 2^9) 55769564424 q11Shape22T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T103OK,q11Shape22T104OK⟩

private def q11Shape22T105 : Tree 11 := (.split 15 (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967687 55769564168 q11Shape22T105=true := by decide

private def q11Shape22T101 : Tree 11 := .split 8 q11Shape22T102 q11Shape22T105
private theorem q11Shape22T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967431 55769564168 q11Shape22T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967431 (55769564168 ||| 2^8) q11Shape22T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967431 ||| 2^8) 55769564168 q11Shape22T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T102OK,q11Shape22T105OK⟩

private def q11Shape22T95 : Tree 11 := .split 2 q11Shape22T96 q11Shape22T101
private theorem q11Shape22T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967427 55769564168 q11Shape22T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967427 (55769564168 ||| 2^2) q11Shape22T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967427 ||| 2^2) 55769564168 q11Shape22T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T96OK,q11Shape22T101OK⟩

private def q11Shape22T87 : Tree 11 := .split 1 q11Shape22T88 q11Shape22T95
private theorem q11Shape22T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967425 55769564168 q11Shape22T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967425 (55769564168 ||| 2^1) q11Shape22T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967425 ||| 2^1) 55769564168 q11Shape22T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T88OK,q11Shape22T95OK⟩

private def q11Shape22T73 : Tree 11 := .split 0 q11Shape22T74 q11Shape22T87
private theorem q11Shape22T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 55769564168 q11Shape22T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 (55769564168 ||| 2^0) q11Shape22T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967424 ||| 2^0) 55769564168 q11Shape22T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T74OK,q11Shape22T87OK⟩

private def q11Shape22T106 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 47244705792 21409825800 q11Shape22T106=true := by decide

private def q11Shape22T72 : Tree 11 := .split 35 q11Shape22T73 q11Shape22T106
private theorem q11Shape22T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 21409825800 q11Shape22T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884967424 (21409825800 ||| 2^35) q11Shape22T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884967424 ||| 2^35) 21409825800 q11Shape22T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T73OK,q11Shape22T106OK⟩

private def q11Shape22T70 : Tree 11 := .split 32 q11Shape22T71 q11Shape22T72
private theorem q11Shape22T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8590000128 21409825800 q11Shape22T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8590000128 (21409825800 ||| 2^32) q11Shape22T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8590000128 ||| 2^32) 21409825800 q11Shape22T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T71OK,q11Shape22T72OK⟩

def q11Shape22P4 : Tree 11 := q11Shape22T70
theorem q11Shape22P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8590000128 21409825800 q11Shape22P4=true := q11Shape22T70OK

end Graffiti384b.EffectiveSearch.Q11
