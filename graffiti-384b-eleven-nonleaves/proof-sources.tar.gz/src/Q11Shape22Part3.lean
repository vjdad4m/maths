import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T107 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 25769869312 4229956616 q11Shape22T107=true := by decide

def q11Shape22P5 : Tree 11 := q11Shape22T107
theorem q11Shape22P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 25769869312 4229956616 q11Shape22P5=true := q11Shape22T107OK

end Graffiti384b.EffectiveSearch.Q11
