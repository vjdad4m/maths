import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T111 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 32147244040 q11Shape22T111=true := by decide

private def q11Shape22T116 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.split 22 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {2,3,5,6,9,10})))))))
private theorem q11Shape22T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 49327113231 q11Shape22T116=true := by decide

private def q11Shape22T117 : Tree 11 := (.split 8 (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10}))))) (.split 22 (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10}))))
private theorem q11Shape22T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418372 49327113227 q11Shape22T117=true := by decide

private def q11Shape22T115 : Tree 11 := .split 2 q11Shape22T116 q11Shape22T117
private theorem q11Shape22T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 49327113227 q11Shape22T115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 (49327113227 ||| 2^2) q11Shape22T116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418368 ||| 2^2) 49327113227 q11Shape22T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T116OK,q11Shape22T117OK⟩

private def q11Shape22T120 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))))
private theorem q11Shape22T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418370 49327113485 q11Shape22T120=true := by decide

private def q11Shape22T121 : Tree 11 := (.split 15 (.split 9 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418626 49327113229 q11Shape22T121=true := by decide

private def q11Shape22T119 : Tree 11 := .split 8 q11Shape22T120 q11Shape22T121
private theorem q11Shape22T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418370 49327113229 q11Shape22T119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418370 (49327113229 ||| 2^8) q11Shape22T120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418370 ||| 2^8) 49327113229 q11Shape22T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T120OK,q11Shape22T121OK⟩

private def q11Shape22T124 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.split 13 (.split 14 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,2,4,5,7,10}))) (.tip (.cover {0,2,4,5,9,10}))) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418374 49327113993 q11Shape22T124=true := by decide

private def q11Shape22T125 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape22T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418886 49327113481 q11Shape22T125=true := by decide

private def q11Shape22T123 : Tree 11 := .split 9 q11Shape22T124 q11Shape22T125
private theorem q11Shape22T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418374 49327113481 q11Shape22T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418374 (49327113481 ||| 2^9) q11Shape22T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418374 ||| 2^9) 49327113481 q11Shape22T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T124OK,q11Shape22T125OK⟩

private def q11Shape22T126 : Tree 11 := (.split 15 (.split 22 (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418630 49327113225 q11Shape22T126=true := by decide

private def q11Shape22T122 : Tree 11 := .split 8 q11Shape22T123 q11Shape22T126
private theorem q11Shape22T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418374 49327113225 q11Shape22T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418374 (49327113225 ||| 2^8) q11Shape22T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418374 ||| 2^8) 49327113225 q11Shape22T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T123OK,q11Shape22T126OK⟩

private def q11Shape22T118 : Tree 11 := .split 2 q11Shape22T119 q11Shape22T122
private theorem q11Shape22T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418370 49327113225 q11Shape22T118=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418370 (49327113225 ||| 2^2) q11Shape22T119 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418370 ||| 2^2) 49327113225 q11Shape22T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T119OK,q11Shape22T122OK⟩

private def q11Shape22T114 : Tree 11 := .split 1 q11Shape22T115 q11Shape22T118
private theorem q11Shape22T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 49327113225 q11Shape22T114=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 (49327113225 ||| 2^1) q11Shape22T115 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418368 ||| 2^1) 49327113225 q11Shape22T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T115OK,q11Shape22T118OK⟩

private def q11Shape22T130 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))))
private theorem q11Shape22T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418369 49327113486 q11Shape22T130=true := by decide

private def q11Shape22T131 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418625 49327113230 q11Shape22T131=true := by decide

private def q11Shape22T129 : Tree 11 := .split 8 q11Shape22T130 q11Shape22T131
private theorem q11Shape22T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418369 49327113230 q11Shape22T129=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418369 (49327113230 ||| 2^8) q11Shape22T130 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418369 ||| 2^8) 49327113230 q11Shape22T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T130OK,q11Shape22T131OK⟩

private def q11Shape22T133 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418373 49327113482 q11Shape22T133=true := by decide

private def q11Shape22T134 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10})))
private theorem q11Shape22T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418629 49327113226 q11Shape22T134=true := by decide

private def q11Shape22T132 : Tree 11 := .split 8 q11Shape22T133 q11Shape22T134
private theorem q11Shape22T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418373 49327113226 q11Shape22T132=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418373 (49327113226 ||| 2^8) q11Shape22T133 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418373 ||| 2^8) 49327113226 q11Shape22T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T133OK,q11Shape22T134OK⟩

private def q11Shape22T128 : Tree 11 := .split 2 q11Shape22T129 q11Shape22T132
private theorem q11Shape22T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418369 49327113226 q11Shape22T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418369 (49327113226 ||| 2^2) q11Shape22T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418369 ||| 2^2) 49327113226 q11Shape22T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T129OK,q11Shape22T132OK⟩

private def q11Shape22T137 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418371 49327113484 q11Shape22T137=true := by decide

private def q11Shape22T139 : Tree 11 := (.split 22 (.split 23 (.split 9 (.split 24 (.split 25 (.split 17 (.split 18 (.tip (.cover {2,3,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,3,4,9,10}))) (.tip (.cover {0,2,3,4,9,10}))) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10})))
private theorem q11Shape22T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418627 49327145996 q11Shape22T139=true := by decide

private def q11Shape22T140 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape22T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327451395 49327113228 q11Shape22T140=true := by decide

private def q11Shape22T138 : Tree 11 := .split 15 q11Shape22T139 q11Shape22T140
private theorem q11Shape22T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418627 49327113228 q11Shape22T138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418627 (49327113228 ||| 2^15) q11Shape22T139 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418627 ||| 2^15) 49327113228 q11Shape22T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T139OK,q11Shape22T140OK⟩

private def q11Shape22T136 : Tree 11 := .split 8 q11Shape22T137 q11Shape22T138
private theorem q11Shape22T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418371 49327113228 q11Shape22T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418371 (49327113228 ||| 2^8) q11Shape22T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418371 ||| 2^8) 49327113228 q11Shape22T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T137OK,q11Shape22T138OK⟩

private def q11Shape22T143 : Tree 11 := (.split 15 (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.split 22 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10}))))
private theorem q11Shape22T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418375 49327113992 q11Shape22T143=true := by decide

private def q11Shape22T144 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape22T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418887 49327113480 q11Shape22T144=true := by decide

private def q11Shape22T142 : Tree 11 := .split 9 q11Shape22T143 q11Shape22T144
private theorem q11Shape22T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418375 49327113480 q11Shape22T142=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418375 (49327113480 ||| 2^9) q11Shape22T143 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418375 ||| 2^9) 49327113480 q11Shape22T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T143OK,q11Shape22T144OK⟩

private def q11Shape22T145 : Tree 11 := (.split 15 (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418631 49327113224 q11Shape22T145=true := by decide

private def q11Shape22T141 : Tree 11 := .split 8 q11Shape22T142 q11Shape22T145
private theorem q11Shape22T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418375 49327113224 q11Shape22T141=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418375 (49327113224 ||| 2^8) q11Shape22T142 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418375 ||| 2^8) 49327113224 q11Shape22T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T142OK,q11Shape22T145OK⟩

private def q11Shape22T135 : Tree 11 := .split 2 q11Shape22T136 q11Shape22T141
private theorem q11Shape22T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418371 49327113224 q11Shape22T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418371 (49327113224 ||| 2^2) q11Shape22T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418371 ||| 2^2) 49327113224 q11Shape22T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T136OK,q11Shape22T141OK⟩

private def q11Shape22T127 : Tree 11 := .split 1 q11Shape22T128 q11Shape22T135
private theorem q11Shape22T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418369 49327113224 q11Shape22T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418369 (49327113224 ||| 2^1) q11Shape22T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418369 ||| 2^1) 49327113224 q11Shape22T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T128OK,q11Shape22T135OK⟩

private def q11Shape22T113 : Tree 11 := .split 0 q11Shape22T114 q11Shape22T127
private theorem q11Shape22T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 49327113224 q11Shape22T113=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 (49327113224 ||| 2^0) q11Shape22T114 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418368 ||| 2^0) 49327113224 q11Shape22T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T114OK,q11Shape22T127OK⟩

private def q11Shape22T146 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 53687156736 14967374856 q11Shape22T146=true := by decide

private def q11Shape22T112 : Tree 11 := .split 35 q11Shape22T113 q11Shape22T146
private theorem q11Shape22T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 14967374856 q11Shape22T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327418368 (14967374856 ||| 2^35) q11Shape22T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327418368 ||| 2^35) 14967374856 q11Shape22T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T113OK,q11Shape22T146OK⟩

private def q11Shape22T110 : Tree 11 := .split 34 q11Shape22T111 q11Shape22T112
private theorem q11Shape22T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 14967374856 q11Shape22T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 (14967374856 ||| 2^34) q11Shape22T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147549184 ||| 2^34) 14967374856 q11Shape22T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T111OK,q11Shape22T112OK⟩

def q11Shape22P6 : Tree 11 := q11Shape22T110
theorem q11Shape22P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147549184 14967374856 q11Shape22P6=true := q11Shape22T110OK

end Graffiti384b.EffectiveSearch.Q11
