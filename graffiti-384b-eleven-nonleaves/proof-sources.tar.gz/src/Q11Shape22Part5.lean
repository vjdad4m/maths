import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T147 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape22T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 10737483776 6377440264 q11Shape22T147=true := by decide

def q11Shape22P7 : Tree 11 := q11Shape22T147
theorem q11Shape22P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 10737483776 6377440264 q11Shape22P7=true := q11Shape22T147OK

private def q11Shape22T149 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 6442516480 2082472968 q11Shape22T149=true := by decide

def q11Shape22P8 : Tree 11 := q11Shape22T149
theorem q11Shape22P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 6442516480 2082472968 q11Shape22P8=true := q11Shape22T149OK

end Graffiti384b.EffectiveSearch.Q11
