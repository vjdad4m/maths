import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T154 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape22T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 67580724232 q11Shape22T154=true := by decide

private def q11Shape22T158 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.split 22 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {2,3,5,6,8,10})))) (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {2,3,5,6,8,10})))))))
private theorem q11Shape22T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545728 33220985871 q11Shape22T158=true := by decide

private def q11Shape22T159 : Tree 11 := (.split 8 (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,4,5,7,8,10}))) (.tip (.cover {0,4,5,8,9,10}))))) (.split 22 (.split 24 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,4,5,7,8,10}))) (.tip (.cover {0,4,5,8,9,10}))))
private theorem q11Shape22T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545732 33220985867 q11Shape22T159=true := by decide

private def q11Shape22T157 : Tree 11 := .split 2 q11Shape22T158 q11Shape22T159
private theorem q11Shape22T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545728 33220985867 q11Shape22T157=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545728 (33220985867 ||| 2^2) q11Shape22T158 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545728 ||| 2^2) 33220985867 q11Shape22T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T158OK,q11Shape22T159OK⟩

private def q11Shape22T162 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10})))))
private theorem q11Shape22T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545730 33220986125 q11Shape22T162=true := by decide

private def q11Shape22T163 : Tree 11 := (.split 15 (.split 9 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545986 33220985869 q11Shape22T163=true := by decide

private def q11Shape22T161 : Tree 11 := .split 8 q11Shape22T162 q11Shape22T163
private theorem q11Shape22T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545730 33220985869 q11Shape22T161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545730 (33220985869 ||| 2^8) q11Shape22T162 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545730 ||| 2^8) 33220985869 q11Shape22T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T162OK,q11Shape22T163OK⟩

private def q11Shape22T166 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.split 13 (.split 14 (.split 17 (.split 19 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,2,4,5,7,10}))) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545734 33220986633 q11Shape22T166=true := by decide

private def q11Shape22T167 : Tree 11 := (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape22T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433546246 33220986121 q11Shape22T167=true := by decide

private def q11Shape22T165 : Tree 11 := .split 9 q11Shape22T166 q11Shape22T167
private theorem q11Shape22T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545734 33220986121 q11Shape22T165=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545734 (33220986121 ||| 2^9) q11Shape22T166 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545734 ||| 2^9) 33220986121 q11Shape22T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T166OK,q11Shape22T167OK⟩

private def q11Shape22T168 : Tree 11 := (.split 15 (.split 22 (.split 24 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,4,5,7,8,10}))) (.tip (.cover {0,4,5,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545990 33220985865 q11Shape22T168=true := by decide

private def q11Shape22T164 : Tree 11 := .split 8 q11Shape22T165 q11Shape22T168
private theorem q11Shape22T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545734 33220985865 q11Shape22T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545734 (33220985865 ||| 2^8) q11Shape22T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545734 ||| 2^8) 33220985865 q11Shape22T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T165OK,q11Shape22T168OK⟩

private def q11Shape22T160 : Tree 11 := .split 2 q11Shape22T161 q11Shape22T164
private theorem q11Shape22T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545730 33220985865 q11Shape22T160=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545730 (33220985865 ||| 2^2) q11Shape22T161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545730 ||| 2^2) 33220985865 q11Shape22T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T161OK,q11Shape22T164OK⟩

private def q11Shape22T156 : Tree 11 := .split 1 q11Shape22T157 q11Shape22T160
private theorem q11Shape22T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545728 33220985865 q11Shape22T156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545728 (33220985865 ||| 2^1) q11Shape22T157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545728 ||| 2^1) 33220985865 q11Shape22T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T157OK,q11Shape22T160OK⟩

private def q11Shape22T172 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10})))))
private theorem q11Shape22T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545729 33220986126 q11Shape22T172=true := by decide

private def q11Shape22T173 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545985 33220985870 q11Shape22T173=true := by decide

private def q11Shape22T171 : Tree 11 := .split 8 q11Shape22T172 q11Shape22T173
private theorem q11Shape22T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545729 33220985870 q11Shape22T171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545729 (33220985870 ||| 2^8) q11Shape22T172 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545729 ||| 2^8) 33220985870 q11Shape22T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T172OK,q11Shape22T173OK⟩

private def q11Shape22T175 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {3,5,6,7,8,10}))) (.tip (.cover {3,5,6,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545733 33220986122 q11Shape22T175=true := by decide

private def q11Shape22T176 : Tree 11 := (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {3,5,6,7,8,10}))) (.tip (.cover {3,5,6,8,9,10})))
private theorem q11Shape22T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545989 33220985866 q11Shape22T176=true := by decide

private def q11Shape22T174 : Tree 11 := .split 8 q11Shape22T175 q11Shape22T176
private theorem q11Shape22T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545733 33220985866 q11Shape22T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545733 (33220985866 ||| 2^8) q11Shape22T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545733 ||| 2^8) 33220985866 q11Shape22T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T175OK,q11Shape22T176OK⟩

private def q11Shape22T170 : Tree 11 := .split 2 q11Shape22T171 q11Shape22T174
private theorem q11Shape22T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545729 33220985866 q11Shape22T170=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545729 (33220985866 ||| 2^2) q11Shape22T171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545729 ||| 2^2) 33220985866 q11Shape22T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T171OK,q11Shape22T174OK⟩

private def q11Shape22T179 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {0,3,4,7,8,10}))) (.tip (.cover {0,3,4,8,9,10}))))
private theorem q11Shape22T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545731 33220986124 q11Shape22T179=true := by decide

private def q11Shape22T181 : Tree 11 := (.split 22 (.split 23 (.split 24 (.split 9 (.split 25 (.split 17 (.split 19 (.tip (.cover {2,3,5,6,8,10})) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,4,5,7,8,10}))) (.tip (.cover {0,4,5,7,9,10}))) (.tip (.cover {0,4,5,8,9,10})))
private theorem q11Shape22T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545987 33221018636 q11Shape22T181=true := by decide

private def q11Shape22T182 : Tree 11 := (.tip (.cover {0,4,7,8,9,10}))
private theorem q11Shape22T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433578755 33220985868 q11Shape22T182=true := by decide

private def q11Shape22T180 : Tree 11 := .split 15 q11Shape22T181 q11Shape22T182
private theorem q11Shape22T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545987 33220985868 q11Shape22T180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545987 (33220985868 ||| 2^15) q11Shape22T181 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545987 ||| 2^15) 33220985868 q11Shape22T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T181OK,q11Shape22T182OK⟩

private def q11Shape22T178 : Tree 11 := .split 8 q11Shape22T179 q11Shape22T180
private theorem q11Shape22T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545731 33220985868 q11Shape22T178=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545731 (33220985868 ||| 2^8) q11Shape22T179 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545731 ||| 2^8) 33220985868 q11Shape22T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T179OK,q11Shape22T180OK⟩

private def q11Shape22T185 : Tree 11 := (.split 15 (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.split 22 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {2,3,5,6,8,10})))) (.split 24 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {2,3,5,6,8,10})))) (.split 11 (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {3,5,6,7,8,10}))) (.tip (.cover {3,5,6,8,9,10}))))
private theorem q11Shape22T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545735 33220986632 q11Shape22T185=true := by decide

private def q11Shape22T186 : Tree 11 := (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape22T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433546247 33220986120 q11Shape22T186=true := by decide

private def q11Shape22T184 : Tree 11 := .split 9 q11Shape22T185 q11Shape22T186
private theorem q11Shape22T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545735 33220986120 q11Shape22T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545735 (33220986120 ||| 2^9) q11Shape22T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545735 ||| 2^9) 33220986120 q11Shape22T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T185OK,q11Shape22T186OK⟩

private def q11Shape22T187 : Tree 11 := (.split 15 (.split 11 (.split 13 (.tip (.cover {2,4,5,6,8,10})) (.tip (.cover {3,5,6,7,8,10}))) (.tip (.cover {3,5,6,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))
private theorem q11Shape22T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545991 33220985864 q11Shape22T187=true := by decide

private def q11Shape22T183 : Tree 11 := .split 8 q11Shape22T184 q11Shape22T187
private theorem q11Shape22T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545735 33220985864 q11Shape22T183=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545735 (33220985864 ||| 2^8) q11Shape22T184 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545735 ||| 2^8) 33220985864 q11Shape22T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T184OK,q11Shape22T187OK⟩

private def q11Shape22T177 : Tree 11 := .split 2 q11Shape22T178 q11Shape22T183
private theorem q11Shape22T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545731 33220985864 q11Shape22T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545731 (33220985864 ||| 2^2) q11Shape22T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545731 ||| 2^2) 33220985864 q11Shape22T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T178OK,q11Shape22T183OK⟩

private def q11Shape22T169 : Tree 11 := .split 1 q11Shape22T170 q11Shape22T177
private theorem q11Shape22T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545729 33220985864 q11Shape22T169=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545729 (33220985864 ||| 2^1) q11Shape22T170 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545729 ||| 2^1) 33220985864 q11Shape22T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T170OK,q11Shape22T177OK⟩

private def q11Shape22T155 : Tree 11 := .split 0 q11Shape22T156 q11Shape22T169
private theorem q11Shape22T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545728 33220985864 q11Shape22T155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433545728 (33220985864 ||| 2^0) q11Shape22T156 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433545728 ||| 2^0) 33220985864 q11Shape22T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T156OK,q11Shape22T169OK⟩

private def q11Shape22T153 : Tree 11 := .split 35 q11Shape22T154 q11Shape22T155
private theorem q11Shape22T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 33220985864 q11Shape22T153=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 (33220985864 ||| 2^35) q11Shape22T154 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073807360 ||| 2^35) 33220985864 q11Shape22T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T154OK,q11Shape22T155OK⟩

private def q11Shape22T188 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 18253676544 16041116680 q11Shape22T188=true := by decide

private def q11Shape22T152 : Tree 11 := .split 34 q11Shape22T153 q11Shape22T188
private theorem q11Shape22T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 16041116680 q11Shape22T152=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 (16041116680 ||| 2^34) q11Shape22T153 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073807360 ||| 2^34) 16041116680 q11Shape22T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T153OK,q11Shape22T188OK⟩

def q11Shape22P9 : Tree 11 := q11Shape22T152
theorem q11Shape22P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073807360 16041116680 q11Shape22P9=true := q11Shape22T152OK

end Graffiti384b.EffectiveSearch.Q11
