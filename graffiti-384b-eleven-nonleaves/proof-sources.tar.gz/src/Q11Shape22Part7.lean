import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T189 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 9663741952 7451182088 q11Shape22T189=true := by decide

def q11Shape22P10 : Tree 11 := q11Shape22T189
theorem q11Shape22P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 9663741952 7451182088 q11Shape22P10=true := q11Shape22T189OK

private def q11Shape22T191 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 5368774656 3156214792 q11Shape22T191=true := by decide

def q11Shape22P11 : Tree 11 := q11Shape22T191
theorem q11Shape22P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 5368774656 3156214792 q11Shape22P11=true := q11Shape22T191OK

private def q11Shape22T193 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 3221291008 1008731144 q11Shape22T193=true := by decide

def q11Shape22P12 : Tree 11 := q11Shape22T193
theorem q11Shape22P12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 3221291008 1008731144 q11Shape22P12=true := q11Shape22T193OK

private def q11Shape22T196 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape22T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2162688 1006633992 q11Shape22T196=true := by decide

def q11Shape22P13 : Tree 11 := q11Shape22T196
theorem q11Shape22P13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2162688 1006633992 q11Shape22P13=true := q11Shape22T196OK

private def q11Shape22T204 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape22T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 12819955720 q11Shape22T204=true := by decide

private def q11Shape22T207 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589935616 25704857608 q11Shape22T207=true := by decide

private def q11Shape22T214 : Tree 11 := (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 13 (.split 14 (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,3,5,7,9,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape22T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 55769635593 q11Shape22T214=true := by decide

private def q11Shape22T215 : Tree 11 := (.tip (.cover {2,4,5,6,9,10}))
private theorem q11Shape22T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884903424 55769635081 q11Shape22T215=true := by decide

private def q11Shape22T213 : Tree 11 := .split 9 q11Shape22T214 q11Shape22T215
private theorem q11Shape22T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 55769635081 q11Shape22T213=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 (55769635081 ||| 2^9) q11Shape22T214 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884902912 ||| 2^9) 55769635081 q11Shape22T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T214OK,q11Shape22T215OK⟩

private def q11Shape22T216 : Tree 11 := (.tip (.cover {2,4,5,6,9,10}))
private theorem q11Shape22T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884903168 55769634825 q11Shape22T216=true := by decide

private def q11Shape22T212 : Tree 11 := .split 8 q11Shape22T213 q11Shape22T216
private theorem q11Shape22T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 55769634825 q11Shape22T212=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 (55769634825 ||| 2^8) q11Shape22T213 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884902912 ||| 2^8) 55769634825 q11Shape22T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T213OK,q11Shape22T216OK⟩

private def q11Shape22T217 : Tree 11 := (.tip (.cover {2,4,5,6,9,10}))
private theorem q11Shape22T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902913 55769634824 q11Shape22T217=true := by decide

private def q11Shape22T211 : Tree 11 := .split 0 q11Shape22T212 q11Shape22T217
private theorem q11Shape22T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 55769634824 q11Shape22T211=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 (55769634824 ||| 2^0) q11Shape22T212 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884902912 ||| 2^0) 55769634824 q11Shape22T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T212OK,q11Shape22T217OK⟩

private def q11Shape22T218 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape22T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884907008 55769630728 q11Shape22T218=true := by decide

private def q11Shape22T210 : Tree 11 := .split 12 q11Shape22T211 q11Shape22T218
private theorem q11Shape22T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 55769630728 q11Shape22T210=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 (55769630728 ||| 2^12) q11Shape22T211 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884902912 ||| 2^12) 55769630728 q11Shape22T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T211OK,q11Shape22T218OK⟩

private def q11Shape22T219 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape22T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884904960 55769628680 q11Shape22T219=true := by decide

private def q11Shape22T209 : Tree 11 := .split 11 q11Shape22T210 q11Shape22T219
private theorem q11Shape22T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 55769628680 q11Shape22T209=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 (55769628680 ||| 2^11) q11Shape22T210 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884902912 ||| 2^11) 55769628680 q11Shape22T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T210OK,q11Shape22T219OK⟩

private def q11Shape22T220 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 47244641280 21409890312 q11Shape22T220=true := by decide

private def q11Shape22T208 : Tree 11 := .split 35 q11Shape22T209 q11Shape22T220
private theorem q11Shape22T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 21409890312 q11Shape22T208=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902912 (21409890312 ||| 2^35) q11Shape22T209 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884902912 ||| 2^35) 21409890312 q11Shape22T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T209OK,q11Shape22T220OK⟩

private def q11Shape22T206 : Tree 11 := .split 32 q11Shape22T207 q11Shape22T208
private theorem q11Shape22T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589935616 21409890312 q11Shape22T206=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589935616 (21409890312 ||| 2^32) q11Shape22T207 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8589935616 ||| 2^32) 21409890312 q11Shape22T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T207OK,q11Shape22T208OK⟩

private def q11Shape22T221 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 25769804800 4230021128 q11Shape22T221=true := by decide

private def q11Shape22T205 : Tree 11 := .split 34 q11Shape22T206 q11Shape22T221
private theorem q11Shape22T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589935616 4230021128 q11Shape22T205=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589935616 (4230021128 ||| 2^34) q11Shape22T206 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8589935616 ||| 2^34) 4230021128 q11Shape22T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T206OK,q11Shape22T221OK⟩

private def q11Shape22T203 : Tree 11 := .split 33 q11Shape22T204 q11Shape22T205
private theorem q11Shape22T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 4230021128 q11Shape22T203=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 (4230021128 ||| 2^33) q11Shape22T204 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1024 ||| 2^33) 4230021128 q11Shape22T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T204OK,q11Shape22T205OK⟩

private def q11Shape22T225 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147484672 32147308552 q11Shape22T225=true := by decide

private def q11Shape22T232 : Tree 11 := (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 13 (.split 14 (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,3,5,7,9,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))))))
private theorem q11Shape22T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 49327184649 q11Shape22T232=true := by decide

private def q11Shape22T233 : Tree 11 := (.tip (.cover {2,4,5,6,9,10}))
private theorem q11Shape22T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327354368 49327184137 q11Shape22T233=true := by decide

private def q11Shape22T231 : Tree 11 := .split 9 q11Shape22T232 q11Shape22T233
private theorem q11Shape22T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 49327184137 q11Shape22T231=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 (49327184137 ||| 2^9) q11Shape22T232 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327353856 ||| 2^9) 49327184137 q11Shape22T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T232OK,q11Shape22T233OK⟩

private def q11Shape22T234 : Tree 11 := (.tip (.cover {2,4,5,6,9,10}))
private theorem q11Shape22T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327354112 49327183881 q11Shape22T234=true := by decide

private def q11Shape22T230 : Tree 11 := .split 8 q11Shape22T231 q11Shape22T234
private theorem q11Shape22T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 49327183881 q11Shape22T230=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 (49327183881 ||| 2^8) q11Shape22T231 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327353856 ||| 2^8) 49327183881 q11Shape22T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T231OK,q11Shape22T234OK⟩

private def q11Shape22T235 : Tree 11 := (.tip (.cover {2,4,5,6,9,10}))
private theorem q11Shape22T235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353857 49327183880 q11Shape22T235=true := by decide

private def q11Shape22T229 : Tree 11 := .split 0 q11Shape22T230 q11Shape22T235
private theorem q11Shape22T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 49327183880 q11Shape22T229=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 (49327183880 ||| 2^0) q11Shape22T230 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327353856 ||| 2^0) 49327183880 q11Shape22T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T230OK,q11Shape22T235OK⟩

private def q11Shape22T236 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape22T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327357952 49327179784 q11Shape22T236=true := by decide

private def q11Shape22T228 : Tree 11 := .split 12 q11Shape22T229 q11Shape22T236
private theorem q11Shape22T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 49327179784 q11Shape22T228=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 (49327179784 ||| 2^12) q11Shape22T229 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327353856 ||| 2^12) 49327179784 q11Shape22T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T229OK,q11Shape22T236OK⟩

private def q11Shape22T237 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape22T237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327355904 49327177736 q11Shape22T237=true := by decide

private def q11Shape22T227 : Tree 11 := .split 11 q11Shape22T228 q11Shape22T237
private theorem q11Shape22T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 49327177736 q11Shape22T227=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 (49327177736 ||| 2^11) q11Shape22T228 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327353856 ||| 2^11) 49327177736 q11Shape22T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T228OK,q11Shape22T237OK⟩

private def q11Shape22T238 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 53687092224 14967439368 q11Shape22T238=true := by decide

private def q11Shape22T226 : Tree 11 := .split 35 q11Shape22T227 q11Shape22T238
private theorem q11Shape22T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 14967439368 q11Shape22T226=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353856 (14967439368 ||| 2^35) q11Shape22T227 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327353856 ||| 2^35) 14967439368 q11Shape22T238)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T227OK,q11Shape22T238OK⟩

private def q11Shape22T224 : Tree 11 := .split 34 q11Shape22T225 q11Shape22T226
private theorem q11Shape22T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147484672 14967439368 q11Shape22T224=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147484672 (14967439368 ||| 2^34) q11Shape22T225 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147484672 ||| 2^34) 14967439368 q11Shape22T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T225OK,q11Shape22T226OK⟩

private def q11Shape22T239 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape22T239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 10737419264 6377504776 q11Shape22T239=true := by decide

private def q11Shape22T223 : Tree 11 := .split 33 q11Shape22T224 q11Shape22T239
private theorem q11Shape22T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147484672 6377504776 q11Shape22T223=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147484672 (6377504776 ||| 2^33) q11Shape22T224 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147484672 ||| 2^33) 6377504776 q11Shape22T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T224OK,q11Shape22T239OK⟩

private def q11Shape22T240 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 6442451968 2082537480 q11Shape22T240=true := by decide

private def q11Shape22T222 : Tree 11 := .split 32 q11Shape22T223 q11Shape22T240
private theorem q11Shape22T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147484672 2082537480 q11Shape22T222=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147484672 (2082537480 ||| 2^32) q11Shape22T223 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147484672 ||| 2^32) 2082537480 q11Shape22T240)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T223OK,q11Shape22T240OK⟩

private def q11Shape22T202 : Tree 11 := .split 31 q11Shape22T203 q11Shape22T222
private theorem q11Shape22T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 2082537480 q11Shape22T202=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 (2082537480 ||| 2^31) q11Shape22T203 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1024 ||| 2^31) 2082537480 q11Shape22T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T203OK,q11Shape22T222OK⟩

private def q11Shape22T246 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape22T246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 67580788744 q11Shape22T246=true := by decide

private def q11Shape22T252 : Tree 11 := (.split 9 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 14 (.split 22 (.split 24 (.tip (.cover {2,3,4,6,8,10})) (.tip (.cover {0,3,5,7,8,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {0,1,3,7,8,9})))))) (.tip (.cover {2,4,5,6,7,10})))
private theorem q11Shape22T252OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 33221064969 q11Shape22T252=true := by decide

private def q11Shape22T253 : Tree 11 := (.tip (.cover {2,4,5,6,7,10}))
private theorem q11Shape22T253OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481472 33221064713 q11Shape22T253=true := by decide

private def q11Shape22T251 : Tree 11 := .split 8 q11Shape22T252 q11Shape22T253
private theorem q11Shape22T251OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 33221064713 q11Shape22T251=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 (33221064713 ||| 2^8) q11Shape22T252 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433481216 ||| 2^8) 33221064713 q11Shape22T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T252OK,q11Shape22T253OK⟩

private def q11Shape22T254 : Tree 11 := (.tip (.cover {2,4,5,6,7,10}))
private theorem q11Shape22T254OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481217 33221064712 q11Shape22T254=true := by decide

private def q11Shape22T250 : Tree 11 := .split 0 q11Shape22T251 q11Shape22T254
private theorem q11Shape22T250OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 33221064712 q11Shape22T250=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 (33221064712 ||| 2^0) q11Shape22T251 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433481216 ||| 2^0) 33221064712 q11Shape22T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T251OK,q11Shape22T254OK⟩

private def q11Shape22T255 : Tree 11 := (.tip (.cover {0,1,3,7,8,10}))
private theorem q11Shape22T255OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433489408 33221056520 q11Shape22T255=true := by decide

private def q11Shape22T249 : Tree 11 := .split 13 q11Shape22T250 q11Shape22T255
private theorem q11Shape22T249OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 33221056520 q11Shape22T249=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 (33221056520 ||| 2^13) q11Shape22T250 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433481216 ||| 2^13) 33221056520 q11Shape22T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T250OK,q11Shape22T255OK⟩

private def q11Shape22T256 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape22T256OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433485312 33221052424 q11Shape22T256=true := by decide

private def q11Shape22T248 : Tree 11 := .split 12 q11Shape22T249 q11Shape22T256
private theorem q11Shape22T248OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 33221052424 q11Shape22T248=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 (33221052424 ||| 2^12) q11Shape22T249 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433481216 ||| 2^12) 33221052424 q11Shape22T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T249OK,q11Shape22T256OK⟩

private def q11Shape22T257 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape22T257OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433483264 33221050376 q11Shape22T257=true := by decide

private def q11Shape22T247 : Tree 11 := .split 11 q11Shape22T248 q11Shape22T257
private theorem q11Shape22T247OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 33221050376 q11Shape22T247=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 35433481216 (33221050376 ||| 2^11) q11Shape22T248 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (35433481216 ||| 2^11) 33221050376 q11Shape22T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T248OK,q11Shape22T257OK⟩

private def q11Shape22T245 : Tree 11 := .split 35 q11Shape22T246 q11Shape22T247
private theorem q11Shape22T245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 33221050376 q11Shape22T245=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 (33221050376 ||| 2^35) q11Shape22T246 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073742848 ||| 2^35) 33221050376 q11Shape22T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T246OK,q11Shape22T247OK⟩

private def q11Shape22T258 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T258OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 18253612032 16041181192 q11Shape22T258=true := by decide

private def q11Shape22T244 : Tree 11 := .split 34 q11Shape22T245 q11Shape22T258
private theorem q11Shape22T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 16041181192 q11Shape22T244=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 (16041181192 ||| 2^34) q11Shape22T245 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073742848 ||| 2^34) 16041181192 q11Shape22T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T245OK,q11Shape22T258OK⟩

private def q11Shape22T259 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T259OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 9663677440 7451246600 q11Shape22T259=true := by decide

private def q11Shape22T243 : Tree 11 := .split 33 q11Shape22T244 q11Shape22T259
private theorem q11Shape22T243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 7451246600 q11Shape22T243=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 (7451246600 ||| 2^33) q11Shape22T244 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073742848 ||| 2^33) 7451246600 q11Shape22T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T244OK,q11Shape22T259OK⟩

private def q11Shape22T260 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T260OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 5368710144 3156279304 q11Shape22T260=true := by decide

private def q11Shape22T242 : Tree 11 := .split 32 q11Shape22T243 q11Shape22T260
private theorem q11Shape22T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 3156279304 q11Shape22T242=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 (3156279304 ||| 2^32) q11Shape22T243 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073742848 ||| 2^32) 3156279304 q11Shape22T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T243OK,q11Shape22T260OK⟩

private def q11Shape22T261 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T261OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 3221226496 1008795656 q11Shape22T261=true := by decide

private def q11Shape22T241 : Tree 11 := .split 31 q11Shape22T242 q11Shape22T261
private theorem q11Shape22T241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 1008795656 q11Shape22T241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1073742848 (1008795656 ||| 2^31) q11Shape22T242 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1073742848 ||| 2^31) 1008795656 q11Shape22T261)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T242OK,q11Shape22T261OK⟩

private def q11Shape22T201 : Tree 11 := .split 30 q11Shape22T202 q11Shape22T241
private theorem q11Shape22T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 1008795656 q11Shape22T201=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 (1008795656 ||| 2^30) q11Shape22T202 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1024 ||| 2^30) 1008795656 q11Shape22T241)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T202OK,q11Shape22T241OK⟩

private def q11Shape22T262 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape22T262OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2098176 1006698504 q11Shape22T262=true := by decide

private def q11Shape22T200 : Tree 11 := .split 21 q11Shape22T201 q11Shape22T262
private theorem q11Shape22T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 1006698504 q11Shape22T200=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 (1006698504 ||| 2^21) q11Shape22T201 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1024 ||| 2^21) 1006698504 q11Shape22T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T201OK,q11Shape22T262OK⟩

private def q11Shape22T263 : Tree 11 := (.split 30 (.tip (.cover {2,3,4,5,9,10})) (.split 31 (.tip (.cover {2,3,4,5,8,10})) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape22T263OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 66560 1006632968 q11Shape22T263=true := by decide

private def q11Shape22T199 : Tree 11 := .split 16 q11Shape22T200 q11Shape22T263
private theorem q11Shape22T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 1006632968 q11Shape22T199=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 (1006632968 ||| 2^16) q11Shape22T200 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (1024 ||| 2^16) 1006632968 q11Shape22T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T200OK,q11Shape22T263OK⟩

def q11Shape22P14 : Tree 11 := q11Shape22T199
theorem q11Shape22P14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 1024 1006632968 q11Shape22P14=true := q11Shape22T199OK

end Graffiti384b.EffectiveSearch.Q11
