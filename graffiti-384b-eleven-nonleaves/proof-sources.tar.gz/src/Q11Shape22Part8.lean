import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T266 : Tree 11 := (.tip (.cover {2,3,4,5,6,10}))
private theorem q11Shape22T266OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 12819956736 q11Shape22T266=true := by decide

private def q11Shape22T269 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T269OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589934600 25704858624 q11Shape22T269=true := by decide

private def q11Shape22T274 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10}))))))
private theorem q11Shape22T274OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 55769629703 q11Shape22T274=true := by decide

private def q11Shape22T275 : Tree 11 := (.split 8 (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,2,5,7,9,10}))) (.tip (.cover {0,2,5,8,9,10}))))) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape22T275OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901900 55769629699 q11Shape22T275=true := by decide

private def q11Shape22T273 : Tree 11 := .split 2 q11Shape22T274 q11Shape22T275
private theorem q11Shape22T273OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 55769629699 q11Shape22T273=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 (55769629699 ||| 2^2) q11Shape22T274 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901896 ||| 2^2) 55769629699 q11Shape22T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T274OK,q11Shape22T275OK⟩

private def q11Shape22T278 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.tip (.cover {3,4,6,8,9,10})))))
private theorem q11Shape22T278OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901898 55769629957 q11Shape22T278=true := by decide

private def q11Shape22T280 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.split 22 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))))
private theorem q11Shape22T280OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902154 55769630213 q11Shape22T280=true := by decide

private def q11Shape22T281 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape22T281OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902666 55769629701 q11Shape22T281=true := by decide

private def q11Shape22T279 : Tree 11 := .split 9 q11Shape22T280 q11Shape22T281
private theorem q11Shape22T279OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902154 55769629701 q11Shape22T279=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902154 (55769629701 ||| 2^9) q11Shape22T280 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884902154 ||| 2^9) 55769629701 q11Shape22T281)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T280OK,q11Shape22T281OK⟩

private def q11Shape22T277 : Tree 11 := .split 8 q11Shape22T278 q11Shape22T279
private theorem q11Shape22T277OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901898 55769629701 q11Shape22T277=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901898 (55769629701 ||| 2^8) q11Shape22T278 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901898 ||| 2^8) 55769629701 q11Shape22T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T278OK,q11Shape22T279OK⟩

private def q11Shape22T286 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.split 14 (.split 22 (.split 23 (.tip (.cover {0,1,2,4,9,10})) (.split 17 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.tip (.cover {0,2,3,7,8,9}))) (.tip (.cover {0,2,3,7,8,10}))))
private theorem q11Shape22T286OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 55769636609 q11Shape22T286=true := by decide

private def q11Shape22T287 : Tree 11 := (.tip (.cover {0,2,4,5,9,10}))
private theorem q11Shape22T287OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902414 55769636097 q11Shape22T287=true := by decide

private def q11Shape22T285 : Tree 11 := .split 9 q11Shape22T286 q11Shape22T287
private theorem q11Shape22T285OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 55769636097 q11Shape22T285=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 (55769636097 ||| 2^9) q11Shape22T286 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901902 ||| 2^9) 55769636097 q11Shape22T287)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T286OK,q11Shape22T287OK⟩

private def q11Shape22T288 : Tree 11 := (.tip (.cover {0,2,4,5,9,10}))
private theorem q11Shape22T288OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902158 55769635841 q11Shape22T288=true := by decide

private def q11Shape22T284 : Tree 11 := .split 8 q11Shape22T285 q11Shape22T288
private theorem q11Shape22T284OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 55769635841 q11Shape22T284=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 (55769635841 ||| 2^8) q11Shape22T285 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901902 ||| 2^8) 55769635841 q11Shape22T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T285OK,q11Shape22T288OK⟩

private def q11Shape22T289 : Tree 11 := (.tip (.cover {0,2,3,7,9,10}))
private theorem q11Shape22T289OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884905998 55769631745 q11Shape22T289=true := by decide

private def q11Shape22T283 : Tree 11 := .split 12 q11Shape22T284 q11Shape22T289
private theorem q11Shape22T283OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 55769631745 q11Shape22T283=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 (55769631745 ||| 2^12) q11Shape22T284 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901902 ||| 2^12) 55769631745 q11Shape22T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T284OK,q11Shape22T289OK⟩

private def q11Shape22T290 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape22T290OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884903950 55769629697 q11Shape22T290=true := by decide

private def q11Shape22T282 : Tree 11 := .split 11 q11Shape22T283 q11Shape22T290
private theorem q11Shape22T282OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 55769629697 q11Shape22T282=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901902 (55769629697 ||| 2^11) q11Shape22T283 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901902 ||| 2^11) 55769629697 q11Shape22T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T283OK,q11Shape22T290OK⟩

private def q11Shape22T276 : Tree 11 := .split 2 q11Shape22T277 q11Shape22T282
private theorem q11Shape22T276OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901898 55769629697 q11Shape22T276=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901898 (55769629697 ||| 2^2) q11Shape22T277 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901898 ||| 2^2) 55769629697 q11Shape22T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T277OK,q11Shape22T282OK⟩

private def q11Shape22T272 : Tree 11 := .split 1 q11Shape22T273 q11Shape22T276
private theorem q11Shape22T272OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 55769629697 q11Shape22T272=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 (55769629697 ||| 2^1) q11Shape22T273 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901896 ||| 2^1) 55769629697 q11Shape22T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T273OK,q11Shape22T276OK⟩

private def q11Shape22T294 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.tip (.cover {3,4,6,8,9,10})))))
private theorem q11Shape22T294OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901897 55769629958 q11Shape22T294=true := by decide

private def q11Shape22T295 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape22T295OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902153 55769629702 q11Shape22T295=true := by decide

private def q11Shape22T293 : Tree 11 := .split 8 q11Shape22T294 q11Shape22T295
private theorem q11Shape22T293OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901897 55769629702 q11Shape22T293=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901897 (55769629702 ||| 2^8) q11Shape22T294 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901897 ||| 2^8) 55769629702 q11Shape22T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T294OK,q11Shape22T295OK⟩

private def q11Shape22T298 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,2,5,7,9,10}))) (.tip (.cover {0,2,5,8,9,10}))))
private theorem q11Shape22T298OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901901 55769630466 q11Shape22T298=true := by decide

private def q11Shape22T299 : Tree 11 := (.split 15 (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.split 22 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.tip (.cover {3,4,6,8,9,10}))))
private theorem q11Shape22T299OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902413 55769629954 q11Shape22T299=true := by decide

private def q11Shape22T297 : Tree 11 := .split 9 q11Shape22T298 q11Shape22T299
private theorem q11Shape22T297OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901901 55769629954 q11Shape22T297=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901901 (55769629954 ||| 2^9) q11Shape22T298 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901901 ||| 2^9) 55769629954 q11Shape22T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T298OK,q11Shape22T299OK⟩

private def q11Shape22T300 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape22T300OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902157 55769629698 q11Shape22T300=true := by decide

private def q11Shape22T296 : Tree 11 := .split 8 q11Shape22T297 q11Shape22T300
private theorem q11Shape22T296OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901901 55769629698 q11Shape22T296=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901901 (55769629698 ||| 2^8) q11Shape22T297 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901901 ||| 2^8) 55769629698 q11Shape22T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T297OK,q11Shape22T300OK⟩

private def q11Shape22T292 : Tree 11 := .split 2 q11Shape22T293 q11Shape22T296
private theorem q11Shape22T292OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901897 55769629698 q11Shape22T292=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901897 (55769629698 ||| 2^2) q11Shape22T293 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901897 ||| 2^2) 55769629698 q11Shape22T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T293OK,q11Shape22T296OK⟩

private def q11Shape22T306 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 24 (.split 25 (.split 11 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 17 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,4,9,10}))))
private theorem q11Shape22T306OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 55782245892 q11Shape22T306=true := by decide

private def q11Shape22T307 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape22T307OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884934667 55782213124 q11Shape22T307=true := by decide

private def q11Shape22T305 : Tree 11 := .split 15 q11Shape22T306 q11Shape22T307
private theorem q11Shape22T305OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 55782213124 q11Shape22T305=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 (55782213124 ||| 2^15) q11Shape22T306 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901899 ||| 2^15) 55782213124 q11Shape22T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T306OK,q11Shape22T307OK⟩

private def q11Shape22T308 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape22T308OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884902411 55782212612 q11Shape22T308=true := by decide

private def q11Shape22T304 : Tree 11 := .split 9 q11Shape22T305 q11Shape22T308
private theorem q11Shape22T304OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 55782212612 q11Shape22T304=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 (55782212612 ||| 2^9) q11Shape22T305 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901899 ||| 2^9) 55782212612 q11Shape22T308)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T305OK,q11Shape22T308OK⟩

private def q11Shape22T309 : Tree 11 := (.tip (.cover {0,2,5,7,9,10}))
private theorem q11Shape22T309OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12893290507 55773824004 q11Shape22T309=true := by decide

private def q11Shape22T303 : Tree 11 := .split 23 q11Shape22T304 q11Shape22T309
private theorem q11Shape22T303OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 55773824004 q11Shape22T303=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 (55773824004 ||| 2^23) q11Shape22T304 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901899 ||| 2^23) 55773824004 q11Shape22T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T304OK,q11Shape22T309OK⟩

private def q11Shape22T310 : Tree 11 := (.tip (.cover {0,2,5,8,9,10}))
private theorem q11Shape22T310OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12889096203 55769629700 q11Shape22T310=true := by decide

private def q11Shape22T302 : Tree 11 := .split 22 q11Shape22T303 q11Shape22T310
private theorem q11Shape22T302OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 55769629700 q11Shape22T302=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 (55769629700 ||| 2^22) q11Shape22T303 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901899 ||| 2^22) 55769629700 q11Shape22T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T303OK,q11Shape22T310OK⟩

private def q11Shape22T311 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape22T311OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901903 55769629696 q11Shape22T311=true := by decide

private def q11Shape22T301 : Tree 11 := .split 2 q11Shape22T302 q11Shape22T311
private theorem q11Shape22T301OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 55769629696 q11Shape22T301=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901899 (55769629696 ||| 2^2) q11Shape22T302 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901899 ||| 2^2) 55769629696 q11Shape22T311)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T302OK,q11Shape22T311OK⟩

private def q11Shape22T291 : Tree 11 := .split 1 q11Shape22T292 q11Shape22T301
private theorem q11Shape22T291OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901897 55769629696 q11Shape22T291=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901897 (55769629696 ||| 2^1) q11Shape22T292 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901897 ||| 2^1) 55769629696 q11Shape22T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T292OK,q11Shape22T301OK⟩

private def q11Shape22T271 : Tree 11 := .split 0 q11Shape22T272 q11Shape22T291
private theorem q11Shape22T271OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 55769629696 q11Shape22T271=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 (55769629696 ||| 2^0) q11Shape22T272 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901896 ||| 2^0) 55769629696 q11Shape22T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T272OK,q11Shape22T291OK⟩

private def q11Shape22T312 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T312OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 47244640264 21409891328 q11Shape22T312=true := by decide

private def q11Shape22T270 : Tree 11 := .split 35 q11Shape22T271 q11Shape22T312
private theorem q11Shape22T270OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 21409891328 q11Shape22T270=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 12884901896 (21409891328 ||| 2^35) q11Shape22T271 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (12884901896 ||| 2^35) 21409891328 q11Shape22T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T271OK,q11Shape22T312OK⟩

private def q11Shape22T268 : Tree 11 := .split 32 q11Shape22T269 q11Shape22T270
private theorem q11Shape22T268OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589934600 21409891328 q11Shape22T268=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589934600 (21409891328 ||| 2^32) q11Shape22T269 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8589934600 ||| 2^32) 21409891328 q11Shape22T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T269OK,q11Shape22T270OK⟩

private def q11Shape22T313 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape22T313OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 25769803784 4230022144 q11Shape22T313=true := by decide

private def q11Shape22T267 : Tree 11 := .split 34 q11Shape22T268 q11Shape22T313
private theorem q11Shape22T267OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589934600 4230022144 q11Shape22T267=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8589934600 (4230022144 ||| 2^34) q11Shape22T268 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8589934600 ||| 2^34) 4230022144 q11Shape22T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T268OK,q11Shape22T313OK⟩

private def q11Shape22T265 : Tree 11 := .split 33 q11Shape22T266 q11Shape22T267
private theorem q11Shape22T265OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 4230022144 q11Shape22T265=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 (4230022144 ||| 2^33) q11Shape22T266 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (8 ||| 2^33) 4230022144 q11Shape22T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T266OK,q11Shape22T267OK⟩

def q11Shape22P15 : Tree 11 := q11Shape22T265
theorem q11Shape22P15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 8 4230022144 q11Shape22P15=true := q11Shape22T265OK

end Graffiti384b.EffectiveSearch.Q11
