import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape22T317 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape22T317OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 32147309568 q11Shape22T317=true := by decide

private def q11Shape22T322 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10}))))))
private theorem q11Shape22T322OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 49327178759 q11Shape22T322=true := by decide

private def q11Shape22T323 : Tree 11 := (.split 8 (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,2,5,7,9,10}))) (.tip (.cover {0,2,5,8,9,10}))))) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape22T323OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352844 49327178755 q11Shape22T323=true := by decide

private def q11Shape22T321 : Tree 11 := .split 2 q11Shape22T322 q11Shape22T323
private theorem q11Shape22T321OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 49327178755 q11Shape22T321=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 (49327178755 ||| 2^2) q11Shape22T322 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352840 ||| 2^2) 49327178755 q11Shape22T323)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T322OK,q11Shape22T323OK⟩

private def q11Shape22T326 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.tip (.cover {3,4,6,8,9,10})))))
private theorem q11Shape22T326OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352842 49327179013 q11Shape22T326=true := by decide

private def q11Shape22T328 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {0,2,4,5,9,10})) (.split 22 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))) (.split 23 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {2,3,5,6,9,10})))))
private theorem q11Shape22T328OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353098 49327179269 q11Shape22T328=true := by decide

private def q11Shape22T329 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape22T329OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353610 49327178757 q11Shape22T329=true := by decide

private def q11Shape22T327 : Tree 11 := .split 9 q11Shape22T328 q11Shape22T329
private theorem q11Shape22T327OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353098 49327178757 q11Shape22T327=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353098 (49327178757 ||| 2^9) q11Shape22T328 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327353098 ||| 2^9) 49327178757 q11Shape22T329)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T328OK,q11Shape22T329OK⟩

private def q11Shape22T325 : Tree 11 := .split 8 q11Shape22T326 q11Shape22T327
private theorem q11Shape22T325OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352842 49327178757 q11Shape22T325=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352842 (49327178757 ||| 2^8) q11Shape22T326 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352842 ||| 2^8) 49327178757 q11Shape22T327)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T326OK,q11Shape22T327OK⟩

private def q11Shape22T334 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 13 (.split 14 (.split 22 (.split 23 (.tip (.cover {0,1,2,4,9,10})) (.split 17 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.tip (.cover {0,2,3,7,8,9}))) (.tip (.cover {0,2,3,7,8,10}))))
private theorem q11Shape22T334OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 49327185665 q11Shape22T334=true := by decide

private def q11Shape22T335 : Tree 11 := (.tip (.cover {0,2,4,5,9,10}))
private theorem q11Shape22T335OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353358 49327185153 q11Shape22T335=true := by decide

private def q11Shape22T333 : Tree 11 := .split 9 q11Shape22T334 q11Shape22T335
private theorem q11Shape22T333OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 49327185153 q11Shape22T333=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 (49327185153 ||| 2^9) q11Shape22T334 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352846 ||| 2^9) 49327185153 q11Shape22T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T334OK,q11Shape22T335OK⟩

private def q11Shape22T336 : Tree 11 := (.tip (.cover {0,2,4,5,9,10}))
private theorem q11Shape22T336OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353102 49327184897 q11Shape22T336=true := by decide

private def q11Shape22T332 : Tree 11 := .split 8 q11Shape22T333 q11Shape22T336
private theorem q11Shape22T332OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 49327184897 q11Shape22T332=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 (49327184897 ||| 2^8) q11Shape22T333 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352846 ||| 2^8) 49327184897 q11Shape22T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T333OK,q11Shape22T336OK⟩

private def q11Shape22T337 : Tree 11 := (.tip (.cover {0,2,3,7,9,10}))
private theorem q11Shape22T337OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327356942 49327180801 q11Shape22T337=true := by decide

private def q11Shape22T331 : Tree 11 := .split 12 q11Shape22T332 q11Shape22T337
private theorem q11Shape22T331OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 49327180801 q11Shape22T331=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 (49327180801 ||| 2^12) q11Shape22T332 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352846 ||| 2^12) 49327180801 q11Shape22T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T332OK,q11Shape22T337OK⟩

private def q11Shape22T338 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape22T338OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327354894 49327178753 q11Shape22T338=true := by decide

private def q11Shape22T330 : Tree 11 := .split 11 q11Shape22T331 q11Shape22T338
private theorem q11Shape22T330OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 49327178753 q11Shape22T330=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352846 (49327178753 ||| 2^11) q11Shape22T331 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352846 ||| 2^11) 49327178753 q11Shape22T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T331OK,q11Shape22T338OK⟩

private def q11Shape22T324 : Tree 11 := .split 2 q11Shape22T325 q11Shape22T330
private theorem q11Shape22T324OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352842 49327178753 q11Shape22T324=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352842 (49327178753 ||| 2^2) q11Shape22T325 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352842 ||| 2^2) 49327178753 q11Shape22T330)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T325OK,q11Shape22T330OK⟩

private def q11Shape22T320 : Tree 11 := .split 1 q11Shape22T321 q11Shape22T324
private theorem q11Shape22T320OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 49327178753 q11Shape22T320=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 (49327178753 ||| 2^1) q11Shape22T321 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352840 ||| 2^1) 49327178753 q11Shape22T324)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T321OK,q11Shape22T324OK⟩

private def q11Shape22T342 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.tip (.cover {3,4,6,8,9,10})))))
private theorem q11Shape22T342OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352841 49327179014 q11Shape22T342=true := by decide

private def q11Shape22T343 : Tree 11 := (.split 9 (.split 15 (.tip (.small 1)) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {3,5,6,8,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape22T343OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353097 49327178758 q11Shape22T343=true := by decide

private def q11Shape22T341 : Tree 11 := .split 8 q11Shape22T342 q11Shape22T343
private theorem q11Shape22T341OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352841 49327178758 q11Shape22T341=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352841 (49327178758 ||| 2^8) q11Shape22T342 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352841 ||| 2^8) 49327178758 q11Shape22T343)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T342OK,q11Shape22T343OK⟩

private def q11Shape22T346 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 22 (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {0,2,5,7,9,10}))) (.tip (.cover {0,2,5,8,9,10}))))
private theorem q11Shape22T346OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352845 49327179522 q11Shape22T346=true := by decide

private def q11Shape22T347 : Tree 11 := (.split 15 (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.split 22 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 23 (.tip (.cover {2,3,4,6,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {3,4,6,7,9,10}))) (.tip (.cover {3,4,6,8,9,10}))))
private theorem q11Shape22T347OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353357 49327179010 q11Shape22T347=true := by decide

private def q11Shape22T345 : Tree 11 := .split 9 q11Shape22T346 q11Shape22T347
private theorem q11Shape22T345OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352845 49327179010 q11Shape22T345=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352845 (49327179010 ||| 2^9) q11Shape22T346 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352845 ||| 2^9) 49327179010 q11Shape22T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T346OK,q11Shape22T347OK⟩

private def q11Shape22T348 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {2,4,5,6,9,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape22T348OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353101 49327178754 q11Shape22T348=true := by decide

private def q11Shape22T344 : Tree 11 := .split 8 q11Shape22T345 q11Shape22T348
private theorem q11Shape22T344OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352845 49327178754 q11Shape22T344=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352845 (49327178754 ||| 2^8) q11Shape22T345 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352845 ||| 2^8) 49327178754 q11Shape22T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T345OK,q11Shape22T348OK⟩

private def q11Shape22T340 : Tree 11 := .split 2 q11Shape22T341 q11Shape22T344
private theorem q11Shape22T340OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352841 49327178754 q11Shape22T340=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352841 (49327178754 ||| 2^2) q11Shape22T341 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352841 ||| 2^2) 49327178754 q11Shape22T344)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T341OK,q11Shape22T344OK⟩

private def q11Shape22T354 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 24 (.split 25 (.split 11 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.split 17 (.tip (.cover {0,1,2,8,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {3,4,5,6,9,10})))) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,3,4,9,10}))))
private theorem q11Shape22T354OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 49339794948 q11Shape22T354=true := by decide

private def q11Shape22T355 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape22T355OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327385611 49339762180 q11Shape22T355=true := by decide

private def q11Shape22T353 : Tree 11 := .split 15 q11Shape22T354 q11Shape22T355
private theorem q11Shape22T353OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 49339762180 q11Shape22T353=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 (49339762180 ||| 2^15) q11Shape22T354 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352843 ||| 2^15) 49339762180 q11Shape22T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T354OK,q11Shape22T355OK⟩

private def q11Shape22T356 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape22T356OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327353355 49339761668 q11Shape22T356=true := by decide

private def q11Shape22T352 : Tree 11 := .split 9 q11Shape22T353 q11Shape22T356
private theorem q11Shape22T352OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 49339761668 q11Shape22T352=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 (49339761668 ||| 2^9) q11Shape22T353 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352843 ||| 2^9) 49339761668 q11Shape22T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T353OK,q11Shape22T356OK⟩

private def q11Shape22T357 : Tree 11 := (.tip (.cover {0,2,5,7,9,10}))
private theorem q11Shape22T357OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19335741451 49331373060 q11Shape22T357=true := by decide

private def q11Shape22T351 : Tree 11 := .split 23 q11Shape22T352 q11Shape22T357
private theorem q11Shape22T351OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 49331373060 q11Shape22T351=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 (49331373060 ||| 2^23) q11Shape22T352 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352843 ||| 2^23) 49331373060 q11Shape22T357)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T352OK,q11Shape22T357OK⟩

private def q11Shape22T358 : Tree 11 := (.tip (.cover {0,2,5,8,9,10}))
private theorem q11Shape22T358OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19331547147 49327178756 q11Shape22T358=true := by decide

private def q11Shape22T350 : Tree 11 := .split 22 q11Shape22T351 q11Shape22T358
private theorem q11Shape22T350OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 49327178756 q11Shape22T350=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 (49327178756 ||| 2^22) q11Shape22T351 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352843 ||| 2^22) 49327178756 q11Shape22T358)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T351OK,q11Shape22T358OK⟩

private def q11Shape22T359 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape22T359OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352847 49327178752 q11Shape22T359=true := by decide

private def q11Shape22T349 : Tree 11 := .split 2 q11Shape22T350 q11Shape22T359
private theorem q11Shape22T349OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 49327178752 q11Shape22T349=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352843 (49327178752 ||| 2^2) q11Shape22T350 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352843 ||| 2^2) 49327178752 q11Shape22T359)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T350OK,q11Shape22T359OK⟩

private def q11Shape22T339 : Tree 11 := .split 1 q11Shape22T340 q11Shape22T349
private theorem q11Shape22T339OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352841 49327178752 q11Shape22T339=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352841 (49327178752 ||| 2^1) q11Shape22T340 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352841 ||| 2^1) 49327178752 q11Shape22T349)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T340OK,q11Shape22T349OK⟩

private def q11Shape22T319 : Tree 11 := .split 0 q11Shape22T320 q11Shape22T339
private theorem q11Shape22T319OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 49327178752 q11Shape22T319=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 (49327178752 ||| 2^0) q11Shape22T320 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352840 ||| 2^0) 49327178752 q11Shape22T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T320OK,q11Shape22T339OK⟩

private def q11Shape22T360 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape22T360OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 53687091208 14967440384 q11Shape22T360=true := by decide

private def q11Shape22T318 : Tree 11 := .split 35 q11Shape22T319 q11Shape22T360
private theorem q11Shape22T318OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 14967440384 q11Shape22T318=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 19327352840 (14967440384 ||| 2^35) q11Shape22T319 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (19327352840 ||| 2^35) 14967440384 q11Shape22T360)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T319OK,q11Shape22T360OK⟩

private def q11Shape22T316 : Tree 11 := .split 34 q11Shape22T317 q11Shape22T318
private theorem q11Shape22T316OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 14967440384 q11Shape22T316=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 (14967440384 ||| 2^34) q11Shape22T317 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147483656 ||| 2^34) 14967440384 q11Shape22T318)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T317OK,q11Shape22T318OK⟩

private def q11Shape22T361 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape22T361OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 10737418248 6377505792 q11Shape22T361=true := by decide

private def q11Shape22T315 : Tree 11 := .split 33 q11Shape22T316 q11Shape22T361
private theorem q11Shape22T315OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 6377505792 q11Shape22T315=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 (6377505792 ||| 2^33) q11Shape22T316 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147483656 ||| 2^33) 6377505792 q11Shape22T361)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T316OK,q11Shape22T361OK⟩

private def q11Shape22T362 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape22T362OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 6442450952 2082538496 q11Shape22T362=true := by decide

private def q11Shape22T314 : Tree 11 := .split 32 q11Shape22T315 q11Shape22T362
private theorem q11Shape22T314OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 2082538496 q11Shape22T314=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 (2082538496 ||| 2^32) q11Shape22T315 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) (2147483656 ||| 2^32) 2082538496 q11Shape22T362)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape22T315OK,q11Shape22T362OK⟩

def q11Shape22P16 : Tree 11 := q11Shape22T314
theorem q11Shape22P16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,5,4⟩) 2147483656 2082538496 q11Shape22P16=true := q11Shape22T314OK

end Graffiti384b.EffectiveSearch.Q11
