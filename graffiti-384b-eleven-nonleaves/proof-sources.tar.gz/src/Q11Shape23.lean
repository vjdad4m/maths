import Q11Shape23Part0
import Q11Shape23Part1
import Q11Shape23Part2
import Q11Shape23Part3
import Q11Shape23Part4
import Q11Shape23Part5
import Q11Shape23Part6
import Q11Shape23Part7
import Q11Shape23Part8
import Q11Shape23Part9

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23M38 : Tree 11 := .split 10 q11Shape23P0 q11Shape23P1
private theorem q11Shape23M38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 768 q11Shape23M38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 (768 ||| 2^10) q11Shape23P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (0 ||| 2^10) 768 q11Shape23P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23P0OK,q11Shape23P1OK⟩
private def q11Shape23M102 : Tree 11 := .split 15 q11Shape23P3 q11Shape23P4
private theorem q11Shape23M102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 256 q11Shape23M102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 (256 ||| 2^15) q11Shape23P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1536 ||| 2^15) 256 q11Shape23P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23P3OK,q11Shape23P4OK⟩
private def q11Shape23M103 : Tree 11 := .split 10 q11Shape23P2 q11Shape23M102
private theorem q11Shape23M103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 256 q11Shape23M103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 (256 ||| 2^10) q11Shape23P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (512 ||| 2^10) 256 q11Shape23M102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23P2OK,q11Shape23M102OK⟩
private def q11Shape23M104 : Tree 11 := .split 9 q11Shape23M38 q11Shape23M103
private theorem q11Shape23M104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 256 q11Shape23M104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 (256 ||| 2^9) q11Shape23M38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (0 ||| 2^9) 256 q11Shape23M103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23M38OK,q11Shape23M103OK⟩
private def q11Shape23M164 : Tree 11 := .split 15 q11Shape23P6 q11Shape23P7
private theorem q11Shape23M164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 512 q11Shape23M164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 (512 ||| 2^15) q11Shape23P6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1280 ||| 2^15) 512 q11Shape23P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23P6OK,q11Shape23P7OK⟩
private def q11Shape23M165 : Tree 11 := .split 10 q11Shape23P5 q11Shape23M164
private theorem q11Shape23M165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 512 q11Shape23M165=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 (512 ||| 2^10) q11Shape23P5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (256 ||| 2^10) 512 q11Shape23M164)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23P5OK,q11Shape23M164OK⟩
private def q11Shape23M202 : Tree 11 := .split 15 q11Shape23P8 q11Shape23P9
private theorem q11Shape23M202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 1024 q11Shape23M202=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 (1024 ||| 2^15) q11Shape23P8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (768 ||| 2^15) 1024 q11Shape23P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23P8OK,q11Shape23P9OK⟩
private def q11Shape23M204 : Tree 11 := .split 10 q11Shape23M202 q11Shape23P10
private theorem q11Shape23M204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 0 q11Shape23M204=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 (0 ||| 2^10) q11Shape23M202 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (768 ||| 2^10) 0 q11Shape23P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23M202OK,q11Shape23P10OK⟩
private def q11Shape23M205 : Tree 11 := .split 9 q11Shape23M165 q11Shape23M204
private theorem q11Shape23M205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 0 q11Shape23M205=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 (0 ||| 2^9) q11Shape23M165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (256 ||| 2^9) 0 q11Shape23M204)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23M165OK,q11Shape23M204OK⟩
private def q11Shape23M206 : Tree 11 := .split 8 q11Shape23M104 q11Shape23M205
private theorem q11Shape23M206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 0 q11Shape23M206=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 (0 ||| 2^8) q11Shape23M104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (0 ||| 2^8) 0 q11Shape23M205)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23M104OK,q11Shape23M205OK⟩

theorem q11Shape23_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 23) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 23) b) (adj 11 (forms 23) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) adj_mono b H q11Shape23M206 q11Shape23M206OK

#print axioms q11Shape23_cover

end Graffiti384b.EffectiveSearch.Q11
