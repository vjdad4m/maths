import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T1 : Tree 11 := (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10}))))))))
private theorem q11Shape23T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 34560 q11Shape23T1=true := by decide

private def q11Shape23T3 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))))
private theorem q11Shape23T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 32768 67328 q11Shape23T3=true := by decide

private def q11Shape23T5 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10}))))))
private theorem q11Shape23T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98304 2098944 q11Shape23T5=true := by decide

private def q11Shape23T9 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195456 7516194560 q11Shape23T9=true := by decide

private def q11Shape23T10 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297162752 3221227264 q11Shape23T10=true := by decide

private def q11Shape23T8 : Tree 11 := .split 32 q11Shape23T9 q11Shape23T10
private theorem q11Shape23T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195456 3221227264 q11Shape23T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195456 (3221227264 ||| 2^32) q11Shape23T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2195456 ||| 2^32) 3221227264 q11Shape23T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T9OK,q11Shape23T10OK⟩

private def q11Shape23T11 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149679104 1073743616 q11Shape23T11=true := by decide

private def q11Shape23T7 : Tree 11 := .split 31 q11Shape23T8 q11Shape23T11
private theorem q11Shape23T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195456 1073743616 q11Shape23T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195456 (1073743616 ||| 2^31) q11Shape23T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2195456 ||| 2^31) 1073743616 q11Shape23T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T8OK,q11Shape23T11OK⟩

private def q11Shape23T12 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075937280 1792 q11Shape23T12=true := by decide

private def q11Shape23T6 : Tree 11 := .split 30 q11Shape23T7 q11Shape23T12
private theorem q11Shape23T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195456 1792 q11Shape23T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195456 (1792 ||| 2^30) q11Shape23T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2195456 ||| 2^30) 1792 q11Shape23T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T7OK,q11Shape23T12OK⟩

private def q11Shape23T4 : Tree 11 := .split 21 q11Shape23T5 q11Shape23T6
private theorem q11Shape23T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98304 1792 q11Shape23T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98304 (1792 ||| 2^21) q11Shape23T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (98304 ||| 2^21) 1792 q11Shape23T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T5OK,q11Shape23T6OK⟩

private def q11Shape23T2 : Tree 11 := .split 16 q11Shape23T3 q11Shape23T4
private theorem q11Shape23T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 32768 1792 q11Shape23T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 32768 (1792 ||| 2^16) q11Shape23T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (32768 ||| 2^16) 1792 q11Shape23T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T3OK,q11Shape23T4OK⟩

private def q11Shape23T0 : Tree 11 := .split 15 q11Shape23T1 q11Shape23T2
private theorem q11Shape23T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 1792 q11Shape23T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 (1792 ||| 2^15) q11Shape23T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (0 ||| 2^15) 1792 q11Shape23T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T1OK,q11Shape23T2OK⟩

def q11Shape23P0 : Tree 11 := q11Shape23T0
theorem q11Shape23P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 0 1792 q11Shape23P0=true := q11Shape23T0OK

end Graffiti384b.EffectiveSearch.Q11
