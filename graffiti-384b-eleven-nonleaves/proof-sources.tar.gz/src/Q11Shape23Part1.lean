import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T15 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))))
private theorem q11Shape23T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1024 99072 q11Shape23T15=true := by decide

private def q11Shape23T17 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))
private theorem q11Shape23T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66560 2130688 q11Shape23T17=true := by decide

private def q11Shape23T18 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape23T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163712 33536 q11Shape23T18=true := by decide

private def q11Shape23T16 : Tree 11 := .split 21 q11Shape23T17 q11Shape23T18
private theorem q11Shape23T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66560 33536 q11Shape23T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66560 (33536 ||| 2^21) q11Shape23T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66560 ||| 2^21) 33536 q11Shape23T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T17OK,q11Shape23T18OK⟩

private def q11Shape23T14 : Tree 11 := .split 16 q11Shape23T15 q11Shape23T16
private theorem q11Shape23T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1024 33536 q11Shape23T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1024 (33536 ||| 2^16) q11Shape23T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1024 ||| 2^16) 33536 q11Shape23T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T15OK,q11Shape23T16OK⟩

private def q11Shape23T21 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10}))))))
private theorem q11Shape23T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33792 2163456 q11Shape23T21=true := by decide

private def q11Shape23T25 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130944 7516259072 q11Shape23T25=true := by decide

private def q11Shape23T26 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297098240 3221291776 q11Shape23T26=true := by decide

private def q11Shape23T24 : Tree 11 := .split 32 q11Shape23T25 q11Shape23T26
private theorem q11Shape23T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130944 3221291776 q11Shape23T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130944 (3221291776 ||| 2^32) q11Shape23T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2130944 ||| 2^32) 3221291776 q11Shape23T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T25OK,q11Shape23T26OK⟩

private def q11Shape23T27 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149614592 1073808128 q11Shape23T27=true := by decide

private def q11Shape23T23 : Tree 11 := .split 31 q11Shape23T24 q11Shape23T27
private theorem q11Shape23T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130944 1073808128 q11Shape23T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130944 (1073808128 ||| 2^31) q11Shape23T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2130944 ||| 2^31) 1073808128 q11Shape23T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T24OK,q11Shape23T27OK⟩

private def q11Shape23T28 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075872768 66304 q11Shape23T28=true := by decide

private def q11Shape23T22 : Tree 11 := .split 30 q11Shape23T23 q11Shape23T28
private theorem q11Shape23T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130944 66304 q11Shape23T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130944 (66304 ||| 2^30) q11Shape23T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2130944 ||| 2^30) 66304 q11Shape23T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T23OK,q11Shape23T28OK⟩

private def q11Shape23T20 : Tree 11 := .split 21 q11Shape23T21 q11Shape23T22
private theorem q11Shape23T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33792 66304 q11Shape23T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33792 (66304 ||| 2^21) q11Shape23T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33792 ||| 2^21) 66304 q11Shape23T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T21OK,q11Shape23T22OK⟩

private def q11Shape23T33 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 7518290688 q11Shape23T33=true := by decide

private def q11Shape23T34 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295066624 3223323392 q11Shape23T34=true := by decide

private def q11Shape23T32 : Tree 11 := .split 32 q11Shape23T33 q11Shape23T34
private theorem q11Shape23T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 3223323392 q11Shape23T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 (3223323392 ||| 2^32) q11Shape23T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99328 ||| 2^32) 3223323392 q11Shape23T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T33OK,q11Shape23T34OK⟩

private def q11Shape23T35 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147582976 1075839744 q11Shape23T35=true := by decide

private def q11Shape23T31 : Tree 11 := .split 31 q11Shape23T32 q11Shape23T35
private theorem q11Shape23T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 1075839744 q11Shape23T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 (1075839744 ||| 2^31) q11Shape23T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99328 ||| 2^31) 1075839744 q11Shape23T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T32OK,q11Shape23T35OK⟩

private def q11Shape23T36 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073841152 2097920 q11Shape23T36=true := by decide

private def q11Shape23T30 : Tree 11 := .split 30 q11Shape23T31 q11Shape23T36
private theorem q11Shape23T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 2097920 q11Shape23T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 (2097920 ||| 2^30) q11Shape23T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99328 ||| 2^30) 2097920 q11Shape23T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T31OK,q11Shape23T36OK⟩

private def q11Shape23T37 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape23T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2196480 768 q11Shape23T37=true := by decide

private def q11Shape23T29 : Tree 11 := .split 21 q11Shape23T30 q11Shape23T37
private theorem q11Shape23T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 768 q11Shape23T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99328 (768 ||| 2^21) q11Shape23T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99328 ||| 2^21) 768 q11Shape23T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T30OK,q11Shape23T37OK⟩

private def q11Shape23T19 : Tree 11 := .split 16 q11Shape23T20 q11Shape23T29
private theorem q11Shape23T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33792 768 q11Shape23T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33792 (768 ||| 2^16) q11Shape23T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33792 ||| 2^16) 768 q11Shape23T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T20OK,q11Shape23T29OK⟩

private def q11Shape23T13 : Tree 11 := .split 15 q11Shape23T14 q11Shape23T19
private theorem q11Shape23T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1024 768 q11Shape23T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1024 (768 ||| 2^15) q11Shape23T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1024 ||| 2^15) 768 q11Shape23T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T14OK,q11Shape23T19OK⟩

def q11Shape23P1 : Tree 11 := q11Shape23T13
theorem q11Shape23P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1024 768 q11Shape23P1=true := q11Shape23T13OK

end Graffiti384b.EffectiveSearch.Q11
