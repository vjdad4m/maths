import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T41 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))))
private theorem q11Shape23T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 99584 q11Shape23T41=true := by decide

private def q11Shape23T43 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10}))))))
private theorem q11Shape23T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66048 2131200 q11Shape23T43=true := by decide

private def q11Shape23T47 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163200 7516226816 q11Shape23T47=true := by decide

private def q11Shape23T48 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297130496 3221259520 q11Shape23T48=true := by decide

private def q11Shape23T46 : Tree 11 := .split 32 q11Shape23T47 q11Shape23T48
private theorem q11Shape23T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163200 3221259520 q11Shape23T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163200 (3221259520 ||| 2^32) q11Shape23T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2163200 ||| 2^32) 3221259520 q11Shape23T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T47OK,q11Shape23T48OK⟩

private def q11Shape23T49 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149646848 1073775872 q11Shape23T49=true := by decide

private def q11Shape23T45 : Tree 11 := .split 31 q11Shape23T46 q11Shape23T49
private theorem q11Shape23T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163200 1073775872 q11Shape23T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163200 (1073775872 ||| 2^31) q11Shape23T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2163200 ||| 2^31) 1073775872 q11Shape23T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T46OK,q11Shape23T49OK⟩

private def q11Shape23T50 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075905024 34048 q11Shape23T50=true := by decide

private def q11Shape23T44 : Tree 11 := .split 30 q11Shape23T45 q11Shape23T50
private theorem q11Shape23T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163200 34048 q11Shape23T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163200 (34048 ||| 2^30) q11Shape23T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2163200 ||| 2^30) 34048 q11Shape23T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T45OK,q11Shape23T50OK⟩

private def q11Shape23T42 : Tree 11 := .split 21 q11Shape23T43 q11Shape23T44
private theorem q11Shape23T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66048 34048 q11Shape23T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66048 (34048 ||| 2^21) q11Shape23T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66048 ||| 2^21) 34048 q11Shape23T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T43OK,q11Shape23T44OK⟩

private def q11Shape23T40 : Tree 11 := .split 16 q11Shape23T41 q11Shape23T42
private theorem q11Shape23T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 34048 q11Shape23T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 (34048 ||| 2^16) q11Shape23T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (512 ||| 2^16) 34048 q11Shape23T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T41OK,q11Shape23T42OK⟩

private def q11Shape23T53 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))
private theorem q11Shape23T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33280 2163968 q11Shape23T53=true := by decide

private def q11Shape23T54 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape23T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130432 66816 q11Shape23T54=true := by decide

private def q11Shape23T52 : Tree 11 := .split 21 q11Shape23T53 q11Shape23T54
private theorem q11Shape23T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33280 66816 q11Shape23T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33280 (66816 ||| 2^21) q11Shape23T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33280 ||| 2^21) 66816 q11Shape23T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T53OK,q11Shape23T54OK⟩

private def q11Shape23T59 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 7518291200 q11Shape23T59=true := by decide

private def q11Shape23T60 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295066112 3223323904 q11Shape23T60=true := by decide

private def q11Shape23T58 : Tree 11 := .split 32 q11Shape23T59 q11Shape23T60
private theorem q11Shape23T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 3223323904 q11Shape23T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 (3223323904 ||| 2^32) q11Shape23T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (98816 ||| 2^32) 3223323904 q11Shape23T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T59OK,q11Shape23T60OK⟩

private def q11Shape23T61 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147582464 1075840256 q11Shape23T61=true := by decide

private def q11Shape23T57 : Tree 11 := .split 31 q11Shape23T58 q11Shape23T61
private theorem q11Shape23T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 1075840256 q11Shape23T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 (1075840256 ||| 2^31) q11Shape23T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (98816 ||| 2^31) 1075840256 q11Shape23T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T58OK,q11Shape23T61OK⟩

private def q11Shape23T62 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073840640 2098432 q11Shape23T62=true := by decide

private def q11Shape23T56 : Tree 11 := .split 30 q11Shape23T57 q11Shape23T62
private theorem q11Shape23T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 2098432 q11Shape23T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 (2098432 ||| 2^30) q11Shape23T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (98816 ||| 2^30) 2098432 q11Shape23T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T57OK,q11Shape23T62OK⟩

private def q11Shape23T63 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape23T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2195968 1280 q11Shape23T63=true := by decide

private def q11Shape23T55 : Tree 11 := .split 21 q11Shape23T56 q11Shape23T63
private theorem q11Shape23T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 1280 q11Shape23T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98816 (1280 ||| 2^21) q11Shape23T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (98816 ||| 2^21) 1280 q11Shape23T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T56OK,q11Shape23T63OK⟩

private def q11Shape23T51 : Tree 11 := .split 16 q11Shape23T52 q11Shape23T55
private theorem q11Shape23T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33280 1280 q11Shape23T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33280 (1280 ||| 2^16) q11Shape23T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33280 ||| 2^16) 1280 q11Shape23T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T52OK,q11Shape23T55OK⟩

private def q11Shape23T39 : Tree 11 := .split 15 q11Shape23T40 q11Shape23T51
private theorem q11Shape23T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 1280 q11Shape23T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 (1280 ||| 2^15) q11Shape23T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (512 ||| 2^15) 1280 q11Shape23T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T40OK,q11Shape23T51OK⟩

def q11Shape23P2 : Tree 11 := q11Shape23T39
theorem q11Shape23P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 512 1280 q11Shape23P2=true := q11Shape23T39OK

end Graffiti384b.EffectiveSearch.Q11
