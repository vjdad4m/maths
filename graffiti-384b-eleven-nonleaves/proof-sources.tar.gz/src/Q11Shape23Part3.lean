import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T66 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10}))))))
private theorem q11Shape23T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 2195712 q11Shape23T66=true := by decide

private def q11Shape23T70 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098688 7516291328 q11Shape23T70=true := by decide

private def q11Shape23T71 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297065984 3221324032 q11Shape23T71=true := by decide

private def q11Shape23T69 : Tree 11 := .split 32 q11Shape23T70 q11Shape23T71
private theorem q11Shape23T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098688 3221324032 q11Shape23T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098688 (3221324032 ||| 2^32) q11Shape23T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2098688 ||| 2^32) 3221324032 q11Shape23T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T70OK,q11Shape23T71OK⟩

private def q11Shape23T72 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149582336 1073840384 q11Shape23T72=true := by decide

private def q11Shape23T68 : Tree 11 := .split 31 q11Shape23T69 q11Shape23T72
private theorem q11Shape23T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098688 1073840384 q11Shape23T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098688 (1073840384 ||| 2^31) q11Shape23T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2098688 ||| 2^31) 1073840384 q11Shape23T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T69OK,q11Shape23T72OK⟩

private def q11Shape23T73 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075840512 98560 q11Shape23T73=true := by decide

private def q11Shape23T67 : Tree 11 := .split 30 q11Shape23T68 q11Shape23T73
private theorem q11Shape23T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098688 98560 q11Shape23T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098688 (98560 ||| 2^30) q11Shape23T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2098688 ||| 2^30) 98560 q11Shape23T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T68OK,q11Shape23T73OK⟩

private def q11Shape23T65 : Tree 11 := .split 21 q11Shape23T66 q11Shape23T67
private theorem q11Shape23T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 98560 q11Shape23T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 (98560 ||| 2^21) q11Shape23T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1536 ||| 2^21) 98560 q11Shape23T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T66OK,q11Shape23T67OK⟩

private def q11Shape23T78 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 7518322944 q11Shape23T78=true := by decide

private def q11Shape23T79 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295034368 3223355648 q11Shape23T79=true := by decide

private def q11Shape23T77 : Tree 11 := .split 32 q11Shape23T78 q11Shape23T79
private theorem q11Shape23T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 3223355648 q11Shape23T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 (3223355648 ||| 2^32) q11Shape23T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (67072 ||| 2^32) 3223355648 q11Shape23T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T78OK,q11Shape23T79OK⟩

private def q11Shape23T80 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147550720 1075872000 q11Shape23T80=true := by decide

private def q11Shape23T76 : Tree 11 := .split 31 q11Shape23T77 q11Shape23T80
private theorem q11Shape23T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 1075872000 q11Shape23T76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 (1075872000 ||| 2^31) q11Shape23T77 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (67072 ||| 2^31) 1075872000 q11Shape23T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T77OK,q11Shape23T80OK⟩

private def q11Shape23T81 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073808896 2130176 q11Shape23T81=true := by decide

private def q11Shape23T75 : Tree 11 := .split 30 q11Shape23T76 q11Shape23T81
private theorem q11Shape23T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 2130176 q11Shape23T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 (2130176 ||| 2^30) q11Shape23T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (67072 ||| 2^30) 2130176 q11Shape23T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T76OK,q11Shape23T81OK⟩

private def q11Shape23T82 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape23T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2164224 33024 q11Shape23T82=true := by decide

private def q11Shape23T74 : Tree 11 := .split 21 q11Shape23T75 q11Shape23T82
private theorem q11Shape23T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 33024 q11Shape23T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 67072 (33024 ||| 2^21) q11Shape23T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (67072 ||| 2^21) 33024 q11Shape23T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T75OK,q11Shape23T82OK⟩

private def q11Shape23T64 : Tree 11 := .split 16 q11Shape23T65 q11Shape23T74
private theorem q11Shape23T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 33024 q11Shape23T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 (33024 ||| 2^16) q11Shape23T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1536 ||| 2^16) 33024 q11Shape23T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T65OK,q11Shape23T74OK⟩

def q11Shape23P3 : Tree 11 := q11Shape23T64
theorem q11Shape23P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1536 33024 q11Shape23P3=true := q11Shape23T64OK

end Graffiti384b.EffectiveSearch.Q11
