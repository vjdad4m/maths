import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T88 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 7518355712 q11Shape23T88=true := by decide

private def q11Shape23T89 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295001600 3223388416 q11Shape23T89=true := by decide

private def q11Shape23T87 : Tree 11 := .split 32 q11Shape23T88 q11Shape23T89
private theorem q11Shape23T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 3223388416 q11Shape23T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 (3223388416 ||| 2^32) q11Shape23T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34304 ||| 2^32) 3223388416 q11Shape23T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T88OK,q11Shape23T89OK⟩

private def q11Shape23T90 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147517952 1075904768 q11Shape23T90=true := by decide

private def q11Shape23T86 : Tree 11 := .split 31 q11Shape23T87 q11Shape23T90
private theorem q11Shape23T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 1075904768 q11Shape23T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 (1075904768 ||| 2^31) q11Shape23T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34304 ||| 2^31) 1075904768 q11Shape23T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T87OK,q11Shape23T90OK⟩

private def q11Shape23T91 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073776128 2162944 q11Shape23T91=true := by decide

private def q11Shape23T85 : Tree 11 := .split 30 q11Shape23T86 q11Shape23T91
private theorem q11Shape23T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 2162944 q11Shape23T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 (2162944 ||| 2^30) q11Shape23T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34304 ||| 2^30) 2162944 q11Shape23T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T86OK,q11Shape23T91OK⟩

private def q11Shape23T92 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape23T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131456 65792 q11Shape23T92=true := by decide

private def q11Shape23T84 : Tree 11 := .split 21 q11Shape23T85 q11Shape23T92
private theorem q11Shape23T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 65792 q11Shape23T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 (65792 ||| 2^21) q11Shape23T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34304 ||| 2^21) 65792 q11Shape23T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T85OK,q11Shape23T92OK⟩

private def q11Shape23T97 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,9})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,7,9,10}))))
private theorem q11Shape23T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 7518290176 q11Shape23T97=true := by decide

private def q11Shape23T98 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295067136 3223322880 q11Shape23T98=true := by decide

private def q11Shape23T96 : Tree 11 := .split 32 q11Shape23T97 q11Shape23T98
private theorem q11Shape23T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 3223322880 q11Shape23T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 (3223322880 ||| 2^32) q11Shape23T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99840 ||| 2^32) 3223322880 q11Shape23T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T97OK,q11Shape23T98OK⟩

private def q11Shape23T99 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,8,9,10})))
private theorem q11Shape23T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147583488 1075839232 q11Shape23T99=true := by decide

private def q11Shape23T95 : Tree 11 := .split 31 q11Shape23T96 q11Shape23T99
private theorem q11Shape23T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 1075839232 q11Shape23T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 (1075839232 ||| 2^31) q11Shape23T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99840 ||| 2^31) 1075839232 q11Shape23T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T96OK,q11Shape23T99OK⟩

private def q11Shape23T100 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {2,3,4,7,9,10}))) (.tip (.cover {2,3,4,7,9,10}))) (.tip (.cover {2,3,4,8,9,10}))) (.tip (.cover {2,3,4,8,9,10})))
private theorem q11Shape23T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073841664 2097408 q11Shape23T100=true := by decide

private def q11Shape23T94 : Tree 11 := .split 30 q11Shape23T95 q11Shape23T100
private theorem q11Shape23T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 2097408 q11Shape23T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 (2097408 ||| 2^30) q11Shape23T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99840 ||| 2^30) 2097408 q11Shape23T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T95OK,q11Shape23T100OK⟩

private def q11Shape23T101 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape23T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2196992 256 q11Shape23T101=true := by decide

private def q11Shape23T93 : Tree 11 := .split 21 q11Shape23T94 q11Shape23T101
private theorem q11Shape23T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 256 q11Shape23T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99840 (256 ||| 2^21) q11Shape23T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (99840 ||| 2^21) 256 q11Shape23T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T94OK,q11Shape23T101OK⟩

private def q11Shape23T83 : Tree 11 := .split 16 q11Shape23T84 q11Shape23T93
private theorem q11Shape23T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 256 q11Shape23T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 (256 ||| 2^16) q11Shape23T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34304 ||| 2^16) 256 q11Shape23T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T84OK,q11Shape23T93OK⟩

def q11Shape23P4 : Tree 11 := q11Shape23T83
theorem q11Shape23P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34304 256 q11Shape23P4=true := q11Shape23T83OK

end Graffiti384b.EffectiveSearch.Q11
