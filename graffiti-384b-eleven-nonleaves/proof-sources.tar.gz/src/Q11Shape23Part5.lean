import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T107 : Tree 11 := (.split 21 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))))
private theorem q11Shape23T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 99840 q11Shape23T107=true := by decide

private def q11Shape23T109 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))
private theorem q11Shape23T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 65792 2131456 q11Shape23T109=true := by decide

private def q11Shape23T113 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape23T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2162944 7516227072 q11Shape23T113=true := by decide

private def q11Shape23T114 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297130240 3221259776 q11Shape23T114=true := by decide

private def q11Shape23T112 : Tree 11 := .split 32 q11Shape23T113 q11Shape23T114
private theorem q11Shape23T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2162944 3221259776 q11Shape23T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2162944 (3221259776 ||| 2^32) q11Shape23T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2162944 ||| 2^32) 3221259776 q11Shape23T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T113OK,q11Shape23T114OK⟩

private def q11Shape23T115 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149646592 1073776128 q11Shape23T115=true := by decide

private def q11Shape23T111 : Tree 11 := .split 31 q11Shape23T112 q11Shape23T115
private theorem q11Shape23T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2162944 1073776128 q11Shape23T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2162944 (1073776128 ||| 2^31) q11Shape23T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2162944 ||| 2^31) 1073776128 q11Shape23T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T112OK,q11Shape23T115OK⟩

private def q11Shape23T116 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape23T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075904768 34304 q11Shape23T116=true := by decide

private def q11Shape23T110 : Tree 11 := .split 30 q11Shape23T111 q11Shape23T116
private theorem q11Shape23T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2162944 34304 q11Shape23T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2162944 (34304 ||| 2^30) q11Shape23T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2162944 ||| 2^30) 34304 q11Shape23T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T111OK,q11Shape23T116OK⟩

private def q11Shape23T108 : Tree 11 := .split 21 q11Shape23T109 q11Shape23T110
private theorem q11Shape23T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 65792 34304 q11Shape23T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 65792 (34304 ||| 2^21) q11Shape23T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (65792 ||| 2^21) 34304 q11Shape23T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T109OK,q11Shape23T110OK⟩

private def q11Shape23T106 : Tree 11 := .split 16 q11Shape23T107 q11Shape23T108
private theorem q11Shape23T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 34304 q11Shape23T106=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 (34304 ||| 2^16) q11Shape23T107 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (256 ||| 2^16) 34304 q11Shape23T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T107OK,q11Shape23T108OK⟩

private def q11Shape23T119 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))
private theorem q11Shape23T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33024 2164224 q11Shape23T119=true := by decide

private def q11Shape23T123 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape23T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130176 7516259840 q11Shape23T123=true := by decide

private def q11Shape23T124 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297097472 3221292544 q11Shape23T124=true := by decide

private def q11Shape23T122 : Tree 11 := .split 32 q11Shape23T123 q11Shape23T124
private theorem q11Shape23T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130176 3221292544 q11Shape23T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130176 (3221292544 ||| 2^32) q11Shape23T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2130176 ||| 2^32) 3221292544 q11Shape23T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T123OK,q11Shape23T124OK⟩

private def q11Shape23T125 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149613824 1073808896 q11Shape23T125=true := by decide

private def q11Shape23T121 : Tree 11 := .split 31 q11Shape23T122 q11Shape23T125
private theorem q11Shape23T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130176 1073808896 q11Shape23T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130176 (1073808896 ||| 2^31) q11Shape23T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2130176 ||| 2^31) 1073808896 q11Shape23T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T122OK,q11Shape23T125OK⟩

private def q11Shape23T126 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape23T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075872000 67072 q11Shape23T126=true := by decide

private def q11Shape23T120 : Tree 11 := .split 30 q11Shape23T121 q11Shape23T126
private theorem q11Shape23T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130176 67072 q11Shape23T120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130176 (67072 ||| 2^30) q11Shape23T121 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2130176 ||| 2^30) 67072 q11Shape23T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T121OK,q11Shape23T126OK⟩

private def q11Shape23T118 : Tree 11 := .split 21 q11Shape23T119 q11Shape23T120
private theorem q11Shape23T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33024 67072 q11Shape23T118=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33024 (67072 ||| 2^21) q11Shape23T119 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33024 ||| 2^21) 67072 q11Shape23T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T119OK,q11Shape23T120OK⟩

private def q11Shape23T127 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape23T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 98560 1536 q11Shape23T127=true := by decide

private def q11Shape23T117 : Tree 11 := .split 16 q11Shape23T118 q11Shape23T127
private theorem q11Shape23T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33024 1536 q11Shape23T117=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33024 (1536 ||| 2^16) q11Shape23T118 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33024 ||| 2^16) 1536 q11Shape23T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T118OK,q11Shape23T127OK⟩

private def q11Shape23T105 : Tree 11 := .split 15 q11Shape23T106 q11Shape23T117
private theorem q11Shape23T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 1536 q11Shape23T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 (1536 ||| 2^15) q11Shape23T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (256 ||| 2^15) 1536 q11Shape23T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T106OK,q11Shape23T117OK⟩

def q11Shape23P5 : Tree 11 := q11Shape23T105
theorem q11Shape23P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 256 1536 q11Shape23P5=true := q11Shape23T105OK

end Graffiti384b.EffectiveSearch.Q11
