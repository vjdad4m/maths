import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T130 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))
private theorem q11Shape23T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 2195968 q11Shape23T130=true := by decide

private def q11Shape23T134 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape23T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098432 7516291584 q11Shape23T134=true := by decide

private def q11Shape23T135 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297065728 3221324288 q11Shape23T135=true := by decide

private def q11Shape23T133 : Tree 11 := .split 32 q11Shape23T134 q11Shape23T135
private theorem q11Shape23T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098432 3221324288 q11Shape23T133=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098432 (3221324288 ||| 2^32) q11Shape23T134 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2098432 ||| 2^32) 3221324288 q11Shape23T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T134OK,q11Shape23T135OK⟩

private def q11Shape23T136 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149582080 1073840640 q11Shape23T136=true := by decide

private def q11Shape23T132 : Tree 11 := .split 31 q11Shape23T133 q11Shape23T136
private theorem q11Shape23T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098432 1073840640 q11Shape23T132=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098432 (1073840640 ||| 2^31) q11Shape23T133 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2098432 ||| 2^31) 1073840640 q11Shape23T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T133OK,q11Shape23T136OK⟩

private def q11Shape23T137 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape23T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075840256 98816 q11Shape23T137=true := by decide

private def q11Shape23T131 : Tree 11 := .split 30 q11Shape23T132 q11Shape23T137
private theorem q11Shape23T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098432 98816 q11Shape23T131=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2098432 (98816 ||| 2^30) q11Shape23T132 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2098432 ||| 2^30) 98816 q11Shape23T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T132OK,q11Shape23T137OK⟩

private def q11Shape23T129 : Tree 11 := .split 21 q11Shape23T130 q11Shape23T131
private theorem q11Shape23T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 98816 q11Shape23T129=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 (98816 ||| 2^21) q11Shape23T130 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1280 ||| 2^21) 98816 q11Shape23T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T130OK,q11Shape23T131OK⟩

private def q11Shape23T142 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape23T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 7518323200 q11Shape23T142=true := by decide

private def q11Shape23T143 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295034112 3223355904 q11Shape23T143=true := by decide

private def q11Shape23T141 : Tree 11 := .split 32 q11Shape23T142 q11Shape23T143
private theorem q11Shape23T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 3223355904 q11Shape23T141=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 (3223355904 ||| 2^32) q11Shape23T142 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66816 ||| 2^32) 3223355904 q11Shape23T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T142OK,q11Shape23T143OK⟩

private def q11Shape23T144 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147550464 1075872256 q11Shape23T144=true := by decide

private def q11Shape23T140 : Tree 11 := .split 31 q11Shape23T141 q11Shape23T144
private theorem q11Shape23T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 1075872256 q11Shape23T140=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 (1075872256 ||| 2^31) q11Shape23T141 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66816 ||| 2^31) 1075872256 q11Shape23T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T141OK,q11Shape23T144OK⟩

private def q11Shape23T145 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape23T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073808640 2130432 q11Shape23T145=true := by decide

private def q11Shape23T139 : Tree 11 := .split 30 q11Shape23T140 q11Shape23T145
private theorem q11Shape23T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 2130432 q11Shape23T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 (2130432 ||| 2^30) q11Shape23T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66816 ||| 2^30) 2130432 q11Shape23T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T140OK,q11Shape23T145OK⟩

private def q11Shape23T146 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape23T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163968 33280 q11Shape23T146=true := by decide

private def q11Shape23T138 : Tree 11 := .split 21 q11Shape23T139 q11Shape23T146
private theorem q11Shape23T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 33280 q11Shape23T138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66816 (33280 ||| 2^21) q11Shape23T139 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66816 ||| 2^21) 33280 q11Shape23T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T139OK,q11Shape23T146OK⟩

private def q11Shape23T128 : Tree 11 := .split 16 q11Shape23T129 q11Shape23T138
private theorem q11Shape23T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 33280 q11Shape23T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 (33280 ||| 2^16) q11Shape23T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (1280 ||| 2^16) 33280 q11Shape23T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T129OK,q11Shape23T138OK⟩

def q11Shape23P6 : Tree 11 := q11Shape23T128
theorem q11Shape23P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1280 33280 q11Shape23P6=true := q11Shape23T128OK

end Graffiti384b.EffectiveSearch.Q11
