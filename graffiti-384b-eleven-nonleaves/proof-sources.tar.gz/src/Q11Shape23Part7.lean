import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T152 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 7518355968 q11Shape23T152=true := by decide

private def q11Shape23T153 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295001344 3223388672 q11Shape23T153=true := by decide

private def q11Shape23T151 : Tree 11 := .split 32 q11Shape23T152 q11Shape23T153
private theorem q11Shape23T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 3223388672 q11Shape23T151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 (3223388672 ||| 2^32) q11Shape23T152 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34048 ||| 2^32) 3223388672 q11Shape23T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T152OK,q11Shape23T153OK⟩

private def q11Shape23T154 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147517696 1075905024 q11Shape23T154=true := by decide

private def q11Shape23T150 : Tree 11 := .split 31 q11Shape23T151 q11Shape23T154
private theorem q11Shape23T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 1075905024 q11Shape23T150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 (1075905024 ||| 2^31) q11Shape23T151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34048 ||| 2^31) 1075905024 q11Shape23T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T151OK,q11Shape23T154OK⟩

private def q11Shape23T155 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073775872 2163200 q11Shape23T155=true := by decide

private def q11Shape23T149 : Tree 11 := .split 30 q11Shape23T150 q11Shape23T155
private theorem q11Shape23T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 2163200 q11Shape23T149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 (2163200 ||| 2^30) q11Shape23T150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34048 ||| 2^30) 2163200 q11Shape23T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T150OK,q11Shape23T155OK⟩

private def q11Shape23T159 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,9})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,10}))) (.tip (.cover {2,3,5,7,9,10}))))
private theorem q11Shape23T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131200 7516258816 q11Shape23T159=true := by decide

private def q11Shape23T160 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,9}))) (.tip (.cover {2,3,5,7,8,9}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297098496 3221291520 q11Shape23T160=true := by decide

private def q11Shape23T158 : Tree 11 := .split 32 q11Shape23T159 q11Shape23T160
private theorem q11Shape23T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131200 3221291520 q11Shape23T158=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131200 (3221291520 ||| 2^32) q11Shape23T159 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2131200 ||| 2^32) 3221291520 q11Shape23T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T159OK,q11Shape23T160OK⟩

private def q11Shape23T161 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,5,7,8,10}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {2,3,5,7,8,10}))) (.tip (.cover {2,3,5,8,9,10})))
private theorem q11Shape23T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149614848 1073807872 q11Shape23T161=true := by decide

private def q11Shape23T157 : Tree 11 := .split 31 q11Shape23T158 q11Shape23T161
private theorem q11Shape23T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131200 1073807872 q11Shape23T157=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131200 (1073807872 ||| 2^31) q11Shape23T158 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2131200 ||| 2^31) 1073807872 q11Shape23T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T158OK,q11Shape23T161OK⟩

private def q11Shape23T162 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {2,3,5,7,9,10}))) (.tip (.cover {2,3,5,7,9,10}))) (.tip (.cover {2,3,5,8,9,10}))) (.tip (.cover {2,3,5,8,9,10})))
private theorem q11Shape23T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075873024 66048 q11Shape23T162=true := by decide

private def q11Shape23T156 : Tree 11 := .split 30 q11Shape23T157 q11Shape23T162
private theorem q11Shape23T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131200 66048 q11Shape23T156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2131200 (66048 ||| 2^30) q11Shape23T157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2131200 ||| 2^30) 66048 q11Shape23T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T157OK,q11Shape23T162OK⟩

private def q11Shape23T148 : Tree 11 := .split 21 q11Shape23T149 q11Shape23T156
private theorem q11Shape23T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 66048 q11Shape23T148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 (66048 ||| 2^21) q11Shape23T149 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34048 ||| 2^21) 66048 q11Shape23T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T149OK,q11Shape23T156OK⟩

private def q11Shape23T163 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape23T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99584 512 q11Shape23T163=true := by decide

private def q11Shape23T147 : Tree 11 := .split 16 q11Shape23T148 q11Shape23T163
private theorem q11Shape23T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 512 q11Shape23T147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 (512 ||| 2^16) q11Shape23T148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (34048 ||| 2^16) 512 q11Shape23T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T148OK,q11Shape23T163OK⟩

def q11Shape23P7 : Tree 11 := q11Shape23T147
theorem q11Shape23P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 34048 512 q11Shape23P7=true := q11Shape23T147OK

end Graffiti384b.EffectiveSearch.Q11
