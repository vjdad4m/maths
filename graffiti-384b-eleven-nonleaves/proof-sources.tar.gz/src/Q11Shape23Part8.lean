import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T168 : Tree 11 := (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))))
private theorem q11Shape23T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 2196480 q11Shape23T168=true := by decide

private def q11Shape23T172 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape23T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2097920 7516292096 q11Shape23T172=true := by decide

private def q11Shape23T173 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297065216 3221324800 q11Shape23T173=true := by decide

private def q11Shape23T171 : Tree 11 := .split 32 q11Shape23T172 q11Shape23T173
private theorem q11Shape23T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2097920 3221324800 q11Shape23T171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2097920 (3221324800 ||| 2^32) q11Shape23T172 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2097920 ||| 2^32) 3221324800 q11Shape23T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T172OK,q11Shape23T173OK⟩

private def q11Shape23T174 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,7,8}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape23T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149581568 1073841152 q11Shape23T174=true := by decide

private def q11Shape23T170 : Tree 11 := .split 31 q11Shape23T171 q11Shape23T174
private theorem q11Shape23T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2097920 1073841152 q11Shape23T170=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2097920 (1073841152 ||| 2^31) q11Shape23T171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2097920 ||| 2^31) 1073841152 q11Shape23T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T171OK,q11Shape23T174OK⟩

private def q11Shape23T175 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,7,9}))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape23T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075839744 99328 q11Shape23T175=true := by decide

private def q11Shape23T169 : Tree 11 := .split 30 q11Shape23T170 q11Shape23T175
private theorem q11Shape23T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2097920 99328 q11Shape23T169=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2097920 (99328 ||| 2^30) q11Shape23T170 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2097920 ||| 2^30) 99328 q11Shape23T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T170OK,q11Shape23T175OK⟩

private def q11Shape23T167 : Tree 11 := .split 21 q11Shape23T168 q11Shape23T169
private theorem q11Shape23T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 99328 q11Shape23T167=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 (99328 ||| 2^21) q11Shape23T168 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (768 ||| 2^21) 99328 q11Shape23T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T168OK,q11Shape23T169OK⟩

private def q11Shape23T180 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape23T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 7518323712 q11Shape23T180=true := by decide

private def q11Shape23T181 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295033600 3223356416 q11Shape23T181=true := by decide

private def q11Shape23T179 : Tree 11 := .split 32 q11Shape23T180 q11Shape23T181
private theorem q11Shape23T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 3223356416 q11Shape23T179=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 (3223356416 ||| 2^32) q11Shape23T180 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66304 ||| 2^32) 3223356416 q11Shape23T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T180OK,q11Shape23T181OK⟩

private def q11Shape23T182 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147549952 1075872768 q11Shape23T182=true := by decide

private def q11Shape23T178 : Tree 11 := .split 31 q11Shape23T179 q11Shape23T182
private theorem q11Shape23T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 1075872768 q11Shape23T178=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 (1075872768 ||| 2^31) q11Shape23T179 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66304 ||| 2^31) 1075872768 q11Shape23T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T179OK,q11Shape23T182OK⟩

private def q11Shape23T183 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {0,1,3,4,7,10})))
private theorem q11Shape23T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073808128 2130944 q11Shape23T183=true := by decide

private def q11Shape23T177 : Tree 11 := .split 30 q11Shape23T178 q11Shape23T183
private theorem q11Shape23T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 2130944 q11Shape23T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 (2130944 ||| 2^30) q11Shape23T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66304 ||| 2^30) 2130944 q11Shape23T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T178OK,q11Shape23T183OK⟩

private def q11Shape23T187 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,9})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {2,3,6,7,9,10}))))
private theorem q11Shape23T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163456 7516226560 q11Shape23T187=true := by decide

private def q11Shape23T188 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,9}))) (.tip (.cover {2,3,6,7,8,9}))) (.tip (.cover {0,1,3,4,7,8})))
private theorem q11Shape23T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4297130752 3221259264 q11Shape23T188=true := by decide

private def q11Shape23T186 : Tree 11 := .split 32 q11Shape23T187 q11Shape23T188
private theorem q11Shape23T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163456 3221259264 q11Shape23T186=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163456 (3221259264 ||| 2^32) q11Shape23T187 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2163456 ||| 2^32) 3221259264 q11Shape23T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T187OK,q11Shape23T188OK⟩

private def q11Shape23T189 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {2,3,6,7,8,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape23T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2149647104 1073775616 q11Shape23T189=true := by decide

private def q11Shape23T185 : Tree 11 := .split 31 q11Shape23T186 q11Shape23T189
private theorem q11Shape23T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163456 1073775616 q11Shape23T185=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163456 (1073775616 ||| 2^31) q11Shape23T186 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2163456 ||| 2^31) 1073775616 q11Shape23T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T186OK,q11Shape23T189OK⟩

private def q11Shape23T190 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,4,7,9}))) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {2,3,6,8,9,10}))) (.tip (.cover {2,3,6,8,9,10})))
private theorem q11Shape23T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1075905280 33792 q11Shape23T190=true := by decide

private def q11Shape23T184 : Tree 11 := .split 30 q11Shape23T185 q11Shape23T190
private theorem q11Shape23T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163456 33792 q11Shape23T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2163456 (33792 ||| 2^30) q11Shape23T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (2163456 ||| 2^30) 33792 q11Shape23T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T185OK,q11Shape23T190OK⟩

private def q11Shape23T176 : Tree 11 := .split 21 q11Shape23T177 q11Shape23T184
private theorem q11Shape23T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 33792 q11Shape23T176=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 66304 (33792 ||| 2^21) q11Shape23T177 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (66304 ||| 2^21) 33792 q11Shape23T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T177OK,q11Shape23T184OK⟩

private def q11Shape23T166 : Tree 11 := .split 16 q11Shape23T167 q11Shape23T176
private theorem q11Shape23T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 33792 q11Shape23T166=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 (33792 ||| 2^16) q11Shape23T167 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (768 ||| 2^16) 33792 q11Shape23T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T167OK,q11Shape23T176OK⟩

def q11Shape23P8 : Tree 11 := q11Shape23T166
theorem q11Shape23P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 768 33792 q11Shape23P8=true := q11Shape23T166OK

end Graffiti384b.EffectiveSearch.Q11
