import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape23T196 : Tree 11 := (.split 33 (.split 34 (.tip (.small 1)) (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,10})))) (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9}))) (.tip (.cover {0,1,3,6,7,8}))))
private theorem q11Shape23T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 7518356480 q11Shape23T196=true := by decide

private def q11Shape23T197 : Tree 11 := (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,1,3,6,7,8})))
private theorem q11Shape23T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 4295000832 3223389184 q11Shape23T197=true := by decide

private def q11Shape23T195 : Tree 11 := .split 32 q11Shape23T196 q11Shape23T197
private theorem q11Shape23T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 3223389184 q11Shape23T195=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 (3223389184 ||| 2^32) q11Shape23T196 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33536 ||| 2^32) 3223389184 q11Shape23T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T196OK,q11Shape23T197OK⟩

private def q11Shape23T198 : Tree 11 := (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,6,8,9}))) (.tip (.cover {0,1,3,6,7,8}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,1,3,6,7,8})))
private theorem q11Shape23T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2147517184 1075905536 q11Shape23T198=true := by decide

private def q11Shape23T194 : Tree 11 := .split 31 q11Shape23T195 q11Shape23T198
private theorem q11Shape23T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 1075905536 q11Shape23T194=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 (1075905536 ||| 2^31) q11Shape23T195 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33536 ||| 2^31) 1075905536 q11Shape23T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T195OK,q11Shape23T198OK⟩

private def q11Shape23T199 : Tree 11 := (.split 31 (.split 32 (.split 33 (.split 34 (.split 35 (.tip (.small 1)) (.tip (.cover {0,1,3,6,7,9}))) (.tip (.cover {0,1,3,6,8,9}))) (.tip (.cover {0,1,3,6,8,10}))) (.tip (.cover {0,1,3,6,7,9}))) (.tip (.cover {0,1,3,6,7,10})))
private theorem q11Shape23T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1073775360 2163712 q11Shape23T199=true := by decide

private def q11Shape23T193 : Tree 11 := .split 30 q11Shape23T194 q11Shape23T199
private theorem q11Shape23T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 2163712 q11Shape23T193=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 (2163712 ||| 2^30) q11Shape23T194 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33536 ||| 2^30) 2163712 q11Shape23T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T194OK,q11Shape23T199OK⟩

private def q11Shape23T200 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape23T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 2130688 66560 q11Shape23T200=true := by decide

private def q11Shape23T192 : Tree 11 := .split 21 q11Shape23T193 q11Shape23T200
private theorem q11Shape23T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 66560 q11Shape23T192=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 (66560 ||| 2^21) q11Shape23T193 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33536 ||| 2^21) 66560 q11Shape23T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T193OK,q11Shape23T200OK⟩

private def q11Shape23T201 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape23T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 99072 1024 q11Shape23T201=true := by decide

private def q11Shape23T191 : Tree 11 := .split 16 q11Shape23T192 q11Shape23T201
private theorem q11Shape23T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 1024 q11Shape23T191=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 (1024 ||| 2^16) q11Shape23T192 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) (33536 ||| 2^16) 1024 q11Shape23T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape23T192OK,q11Shape23T201OK⟩

def q11Shape23P9 : Tree 11 := q11Shape23T191
theorem q11Shape23P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 33536 1024 q11Shape23P9=true := q11Shape23T191OK

private def q11Shape23T203 : Tree 11 := (.split 30 (.split 31 (.split 32 (.split 33 (.split 34 (.tip (.small 1)) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape23T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1792 0 q11Shape23T203=true := by decide

def q11Shape23P10 : Tree 11 := q11Shape23T203
theorem q11Shape23P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,1⟩) 1792 0 q11Shape23P10=true := q11Shape23T203OK

end Graffiti384b.EffectiveSearch.Q11
