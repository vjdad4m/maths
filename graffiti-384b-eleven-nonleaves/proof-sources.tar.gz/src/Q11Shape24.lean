import Q11Shape24Part0
import Q11Shape24Part1
import Q11Shape24Part2
import Q11Shape24Part3
import Q11Shape24Part4
import Q11Shape24Part5
import Q11Shape24Part6
import Q11Shape24Part7
import Q11Shape24Part8
import Q11Shape24Part9
import Q11Shape24Part10
import Q11Shape24Part11
import Q11Shape24Part12
import Q11Shape24Part13
import Q11Shape24Part14

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24M70 : Tree 11 := .split 22 q11Shape24P0 q11Shape24P1
private theorem q11Shape24M70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11814273024 q11Shape24M70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (11814273024 ||| 2^22) q11Shape24P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^22) 11814273024 q11Shape24P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24P0OK,q11Shape24P1OK⟩
private def q11Shape24M122 : Tree 11 := .split 19 q11Shape24M70 q11Shape24P2
private theorem q11Shape24M122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11813748736 q11Shape24M122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (11813748736 ||| 2^19) q11Shape24M70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^19) 11813748736 q11Shape24P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M70OK,q11Shape24P2OK⟩
private def q11Shape24M188 : Tree 11 := .split 18 q11Shape24M122 q11Shape24P3
private theorem q11Shape24M188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11813486592 q11Shape24M188=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (11813486592 ||| 2^18) q11Shape24M122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^18) 11813486592 q11Shape24P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M122OK,q11Shape24P3OK⟩
private def q11Shape24M254 : Tree 11 := .split 17 q11Shape24M188 q11Shape24P4
private theorem q11Shape24M254OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11813355520 q11Shape24M254=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (11813355520 ||| 2^17) q11Shape24M188 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^17) 11813355520 q11Shape24P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M188OK,q11Shape24P4OK⟩
private def q11Shape24M280 : Tree 11 := .split 33 q11Shape24M254 q11Shape24P5
private theorem q11Shape24M280OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 3223420928 q11Shape24M280=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (3223420928 ||| 2^33) q11Shape24M254 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^33) 3223420928 q11Shape24P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M254OK,q11Shape24P5OK⟩
private def q11Shape24M310 : Tree 11 := .split 31 q11Shape24M280 q11Shape24P6
private theorem q11Shape24M310OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 1075937280 q11Shape24M310=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (1075937280 ||| 2^31) q11Shape24M280 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^31) 1075937280 q11Shape24P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M280OK,q11Shape24P6OK⟩
private def q11Shape24M344 : Tree 11 := .split 30 q11Shape24M310 q11Shape24P7
private theorem q11Shape24M344OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 2195456 q11Shape24M344=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (2195456 ||| 2^30) q11Shape24M310 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^30) 2195456 q11Shape24P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M310OK,q11Shape24P7OK⟩
private def q11Shape24M441 : Tree 11 := .split 31 q11Shape24P8 q11Shape24P9
private theorem q11Shape24M441OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 1073840128 q11Shape24M441=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (1073840128 ||| 2^31) q11Shape24P8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^31) 1073840128 q11Shape24P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24P8OK,q11Shape24P9OK⟩
private def q11Shape24M471 : Tree 11 := .split 30 q11Shape24M441 q11Shape24P10
private theorem q11Shape24M471OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 98304 q11Shape24M471=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (98304 ||| 2^30) q11Shape24M441 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^30) 98304 q11Shape24P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M441OK,q11Shape24P10OK⟩
private def q11Shape24M472 : Tree 11 := .split 21 q11Shape24M344 q11Shape24M471
private theorem q11Shape24M472OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 98304 q11Shape24M472=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (98304 ||| 2^21) q11Shape24M344 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^21) 98304 q11Shape24M471)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M344OK,q11Shape24M471OK⟩
private def q11Shape24M557 : Tree 11 := .split 31 q11Shape24P11 q11Shape24P12
private theorem q11Shape24M557OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 1075871744 q11Shape24M557=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (1075871744 ||| 2^31) q11Shape24P11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^31) 1075871744 q11Shape24P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24P11OK,q11Shape24P12OK⟩
private def q11Shape24M587 : Tree 11 := .split 30 q11Shape24M557 q11Shape24P13
private theorem q11Shape24M587OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 2129920 q11Shape24M587=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (2129920 ||| 2^30) q11Shape24M557 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^30) 2129920 q11Shape24P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M557OK,q11Shape24P13OK⟩
private def q11Shape24M589 : Tree 11 := .split 21 q11Shape24M587 q11Shape24P14
private theorem q11Shape24M589OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 32768 q11Shape24M589=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (32768 ||| 2^21) q11Shape24M587 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^21) 32768 q11Shape24P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M587OK,q11Shape24P14OK⟩
private def q11Shape24M590 : Tree 11 := .split 16 q11Shape24M472 q11Shape24M589
private theorem q11Shape24M590OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 32768 q11Shape24M590=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (32768 ||| 2^16) q11Shape24M472 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^16) 32768 q11Shape24M589)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M472OK,q11Shape24M589OK⟩
private def q11Shape24M651 : Tree 11 := .split 33 q11Shape24P15 q11Shape24P16
private theorem q11Shape24M651OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 3223388160 q11Shape24M651=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (3223388160 ||| 2^33) q11Shape24P15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^33) 3223388160 q11Shape24P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24P15OK,q11Shape24P16OK⟩
private def q11Shape24M677 : Tree 11 := .split 31 q11Shape24M651 q11Shape24P17
private theorem q11Shape24M677OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 1075904512 q11Shape24M677=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (1075904512 ||| 2^31) q11Shape24M651 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^31) 1075904512 q11Shape24P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M651OK,q11Shape24P17OK⟩
private def q11Shape24M707 : Tree 11 := .split 30 q11Shape24M677 q11Shape24P18
private theorem q11Shape24M707OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 2162688 q11Shape24M707=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (2162688 ||| 2^30) q11Shape24M677 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^30) 2162688 q11Shape24P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M677OK,q11Shape24P18OK⟩
private def q11Shape24M709 : Tree 11 := .split 21 q11Shape24M707 q11Shape24P19
private theorem q11Shape24M709OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 65536 q11Shape24M709=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (65536 ||| 2^21) q11Shape24M707 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^21) 65536 q11Shape24P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M707OK,q11Shape24P19OK⟩
private def q11Shape24M711 : Tree 11 := .split 16 q11Shape24M709 q11Shape24P20
private theorem q11Shape24M711OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 0 q11Shape24M711=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (0 ||| 2^16) q11Shape24M709 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^16) 0 q11Shape24P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M709OK,q11Shape24P20OK⟩
private def q11Shape24M712 : Tree 11 := .split 15 q11Shape24M590 q11Shape24M711
private theorem q11Shape24M712OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 0 q11Shape24M712=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (0 ||| 2^15) q11Shape24M590 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^15) 0 q11Shape24M711)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24M590OK,q11Shape24M711OK⟩

theorem q11Shape24_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 24) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 24) b) (adj 11 (forms 24) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 24)) adj_mono b H q11Shape24M712 q11Shape24M712OK

#print axioms q11Shape24_cover

end Graffiti384b.EffectiveSearch.Q11
