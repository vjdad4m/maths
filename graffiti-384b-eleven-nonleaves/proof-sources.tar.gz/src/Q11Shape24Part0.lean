import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T2 : Tree 11 := (.tip (.cover {0,1,2,3,6,10}))
private theorem q11Shape24T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11843633152 q11Shape24T2=true := by decide

private def q11Shape24T5 : Tree 11 := (.tip (.cover {0,1,2,3,9,10}))
private theorem q11Shape24T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16777216 12028182528 q11Shape24T5=true := by decide

private def q11Shape24T9 : Tree 11 := (.split 25 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,5,7,10})))) (.split 29 (.split 35 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape24T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 150994944 16458416128 q11Shape24T9=true := by decide

private def q11Shape24T10 : Tree 11 := (.split 25 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape24T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 419430400 16189980672 q11Shape24T10=true := by decide

private def q11Shape24T8 : Tree 11 := .split 28 q11Shape24T9 q11Shape24T10
private theorem q11Shape24T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 150994944 16189980672 q11Shape24T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 150994944 (16189980672 ||| 2^28) q11Shape24T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (150994944 ||| 2^28) 16189980672 q11Shape24T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T9OK,q11Shape24T10OK⟩

private def q11Shape24T11 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4445962240 11895013376 q11Shape24T11=true := by decide

private def q11Shape24T7 : Tree 11 := .split 32 q11Shape24T8 q11Shape24T11
private theorem q11Shape24T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 150994944 11895013376 q11Shape24T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 150994944 (11895013376 ||| 2^32) q11Shape24T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (150994944 ||| 2^32) 11895013376 q11Shape24T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T8OK,q11Shape24T11OK⟩

private def q11Shape24T12 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape24T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 152043520 11893964800 q11Shape24T12=true := by decide

private def q11Shape24T6 : Tree 11 := .split 20 q11Shape24T7 q11Shape24T12
private theorem q11Shape24T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 150994944 11893964800 q11Shape24T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 150994944 (11893964800 ||| 2^20) q11Shape24T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (150994944 ||| 2^20) 11893964800 q11Shape24T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T7OK,q11Shape24T12OK⟩

private def q11Shape24T4 : Tree 11 := .split 27 q11Shape24T5 q11Shape24T6
private theorem q11Shape24T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16777216 11893964800 q11Shape24T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16777216 (11893964800 ||| 2^27) q11Shape24T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (16777216 ||| 2^27) 11893964800 q11Shape24T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T5OK,q11Shape24T6OK⟩

private def q11Shape24T17 : Tree 11 := (.split 25 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,5,8,10})))) (.split 29 (.split 35 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape24T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 29410426880 q11Shape24T17=true := by decide

private def q11Shape24T18 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape24T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 352321536 29141991424 q11Shape24T18=true := by decide

private def q11Shape24T16 : Tree 11 := .split 28 q11Shape24T17 q11Shape24T18
private theorem q11Shape24T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 29141991424 q11Shape24T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 (29141991424 ||| 2^28) q11Shape24T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (83886080 ||| 2^28) 29141991424 q11Shape24T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T17OK,q11Shape24T18OK⟩

private def q11Shape24T19 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17263755264 11962122240 q11Shape24T19=true := by decide

private def q11Shape24T15 : Tree 11 := .split 34 q11Shape24T16 q11Shape24T19
private theorem q11Shape24T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 11962122240 q11Shape24T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 (11962122240 ||| 2^34) q11Shape24T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (83886080 ||| 2^34) 11962122240 q11Shape24T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T16OK,q11Shape24T19OK⟩

private def q11Shape24T20 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape24T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 84934656 11961073664 q11Shape24T20=true := by decide

private def q11Shape24T14 : Tree 11 := .split 20 q11Shape24T15 q11Shape24T20
private theorem q11Shape24T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 11961073664 q11Shape24T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 (11961073664 ||| 2^20) q11Shape24T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (83886080 ||| 2^20) 11961073664 q11Shape24T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T15OK,q11Shape24T20OK⟩

private def q11Shape24T21 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 218103808 11826855936 q11Shape24T21=true := by decide

private def q11Shape24T13 : Tree 11 := .split 27 q11Shape24T14 q11Shape24T21
private theorem q11Shape24T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 11826855936 q11Shape24T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83886080 (11826855936 ||| 2^27) q11Shape24T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (83886080 ||| 2^27) 11826855936 q11Shape24T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T14OK,q11Shape24T21OK⟩

private def q11Shape24T3 : Tree 11 := .split 26 q11Shape24T4 q11Shape24T13
private theorem q11Shape24T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16777216 11826855936 q11Shape24T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16777216 (11826855936 ||| 2^26) q11Shape24T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (16777216 ||| 2^26) 11826855936 q11Shape24T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T4OK,q11Shape24T13OK⟩

private def q11Shape24T1 : Tree 11 := .split 24 q11Shape24T2 q11Shape24T3
private theorem q11Shape24T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11826855936 q11Shape24T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (11826855936 ||| 2^24) q11Shape24T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^24) 11826855936 q11Shape24T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T2OK,q11Shape24T3OK⟩

private def q11Shape24T25 : Tree 11 := (.tip (.cover {0,1,2,3,8,10}))
private theorem q11Shape24T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8388608 12170788864 q11Shape24T25=true := by decide

private def q11Shape24T29 : Tree 11 := (.split 25 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,5,7,10})))) (.split 29 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape24T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276824064 16332587008 q11Shape24T29=true := by decide

private def q11Shape24T30 : Tree 11 := (.split 25 (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape24T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 411041792 16198369280 q11Shape24T30=true := by decide

private def q11Shape24T28 : Tree 11 := .split 27 q11Shape24T29 q11Shape24T30
private theorem q11Shape24T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276824064 16198369280 q11Shape24T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276824064 (16198369280 ||| 2^27) q11Shape24T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (276824064 ||| 2^27) 16198369280 q11Shape24T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T29OK,q11Shape24T30OK⟩

private def q11Shape24T31 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4571791360 11903401984 q11Shape24T31=true := by decide

private def q11Shape24T27 : Tree 11 := .split 32 q11Shape24T28 q11Shape24T31
private theorem q11Shape24T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276824064 11903401984 q11Shape24T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276824064 (11903401984 ||| 2^32) q11Shape24T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (276824064 ||| 2^32) 11903401984 q11Shape24T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T28OK,q11Shape24T31OK⟩

private def q11Shape24T32 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape24T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 277872640 11902353408 q11Shape24T32=true := by decide

private def q11Shape24T26 : Tree 11 := .split 20 q11Shape24T27 q11Shape24T32
private theorem q11Shape24T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276824064 11902353408 q11Shape24T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276824064 (11902353408 ||| 2^20) q11Shape24T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (276824064 ||| 2^20) 11902353408 q11Shape24T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T27OK,q11Shape24T32OK⟩

private def q11Shape24T24 : Tree 11 := .split 28 q11Shape24T25 q11Shape24T26
private theorem q11Shape24T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8388608 11902353408 q11Shape24T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8388608 (11902353408 ||| 2^28) q11Shape24T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8388608 ||| 2^28) 11902353408 q11Shape24T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T25OK,q11Shape24T26OK⟩

private def q11Shape24T37 : Tree 11 := (.split 25 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,5,9,10})))) (.split 29 (.split 34 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,5,6,9}))))
private theorem q11Shape24T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 46598684672 q11Shape24T37=true := by decide

private def q11Shape24T38 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 209715200 46464466944 q11Shape24T38=true := by decide

private def q11Shape24T36 : Tree 11 := .split 27 q11Shape24T37 q11Shape24T38
private theorem q11Shape24T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 46464466944 q11Shape24T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 (46464466944 ||| 2^27) q11Shape24T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (75497472 ||| 2^27) 46464466944 q11Shape24T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T37OK,q11Shape24T38OK⟩

private def q11Shape24T39 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 34435235840 12104728576 q11Shape24T39=true := by decide

private def q11Shape24T35 : Tree 11 := .split 35 q11Shape24T36 q11Shape24T39
private theorem q11Shape24T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 12104728576 q11Shape24T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 (12104728576 ||| 2^35) q11Shape24T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (75497472 ||| 2^35) 12104728576 q11Shape24T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T36OK,q11Shape24T39OK⟩

private def q11Shape24T40 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape24T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 76546048 12103680000 q11Shape24T40=true := by decide

private def q11Shape24T34 : Tree 11 := .split 20 q11Shape24T35 q11Shape24T40
private theorem q11Shape24T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 12103680000 q11Shape24T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 (12103680000 ||| 2^20) q11Shape24T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (75497472 ||| 2^20) 12103680000 q11Shape24T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T35OK,q11Shape24T40OK⟩

private def q11Shape24T41 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 343932928 11835244544 q11Shape24T41=true := by decide

private def q11Shape24T33 : Tree 11 := .split 28 q11Shape24T34 q11Shape24T41
private theorem q11Shape24T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 11835244544 q11Shape24T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75497472 (11835244544 ||| 2^28) q11Shape24T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (75497472 ||| 2^28) 11835244544 q11Shape24T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T34OK,q11Shape24T41OK⟩

private def q11Shape24T23 : Tree 11 := .split 26 q11Shape24T24 q11Shape24T33
private theorem q11Shape24T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8388608 11835244544 q11Shape24T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8388608 (11835244544 ||| 2^26) q11Shape24T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8388608 ||| 2^26) 11835244544 q11Shape24T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T24OK,q11Shape24T33OK⟩

private def q11Shape24T44 : Tree 11 := (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 3 (.split 27 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,2,3,9,10}))) (.split 35 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,7,10})))) (.tip (.cover {0,1,2,3,5,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25165824 12422447104 q11Shape24T44=true := by decide

private def q11Shape24T45 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 562036736 11885576192 q11Shape24T45=true := by decide

private def q11Shape24T43 : Tree 11 := .split 29 q11Shape24T44 q11Shape24T45
private theorem q11Shape24T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25165824 11885576192 q11Shape24T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25165824 (11885576192 ||| 2^29) q11Shape24T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (25165824 ||| 2^29) 11885576192 q11Shape24T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T44OK,q11Shape24T45OK⟩

private def q11Shape24T46 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 92274688 11818467328 q11Shape24T46=true := by decide

private def q11Shape24T42 : Tree 11 := .split 26 q11Shape24T43 q11Shape24T46
private theorem q11Shape24T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25165824 11818467328 q11Shape24T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25165824 (11818467328 ||| 2^26) q11Shape24T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (25165824 ||| 2^26) 11818467328 q11Shape24T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T43OK,q11Shape24T46OK⟩

private def q11Shape24T22 : Tree 11 := .split 24 q11Shape24T23 q11Shape24T42
private theorem q11Shape24T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8388608 11818467328 q11Shape24T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8388608 (11818467328 ||| 2^24) q11Shape24T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8388608 ||| 2^24) 11818467328 q11Shape24T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T23OK,q11Shape24T42OK⟩

private def q11Shape24T0 : Tree 11 := .split 23 q11Shape24T1 q11Shape24T22
private theorem q11Shape24T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11818467328 q11Shape24T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 (11818467328 ||| 2^23) q11Shape24T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (0 ||| 2^23) 11818467328 q11Shape24T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T1OK,q11Shape24T22OK⟩

def q11Shape24P0 : Tree 11 := q11Shape24T0
theorem q11Shape24P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 0 11818467328 q11Shape24P0=true := q11Shape24T0OK

end Graffiti384b.EffectiveSearch.Q11
