import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T52 : Tree 11 := (.tip (.cover {0,1,2,3,5,10}))
private theorem q11Shape24T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 12309200896 q11Shape24T52=true := by decide

private def q11Shape24T53 : Tree 11 := (.split 20 (.split 34 (.split 25 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 35 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,8,10})))) (.split 29 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 272629760 12040765440 q11Shape24T53=true := by decide

private def q11Shape24T51 : Tree 11 := .split 28 q11Shape24T52 q11Shape24T53
private theorem q11Shape24T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 12040765440 q11Shape24T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 (12040765440 ||| 2^28) q11Shape24T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4194304 ||| 2^28) 12040765440 q11Shape24T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T52OK,q11Shape24T53OK⟩

private def q11Shape24T55 : Tree 11 := (.split 20 (.split 35 (.split 25 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,9,10})))) (.split 29 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,5,6,9})))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 138412032 12174983168 q11Shape24T55=true := by decide

private def q11Shape24T56 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 406847488 11906547712 q11Shape24T56=true := by decide

private def q11Shape24T54 : Tree 11 := .split 28 q11Shape24T55 q11Shape24T56
private theorem q11Shape24T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 138412032 11906547712 q11Shape24T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 138412032 (11906547712 ||| 2^28) q11Shape24T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (138412032 ||| 2^28) 11906547712 q11Shape24T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T55OK,q11Shape24T56OK⟩

private def q11Shape24T50 : Tree 11 := .split 27 q11Shape24T51 q11Shape24T54
private theorem q11Shape24T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 11906547712 q11Shape24T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 (11906547712 ||| 2^27) q11Shape24T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4194304 ||| 2^27) 11906547712 q11Shape24T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T51OK,q11Shape24T54OK⟩

private def q11Shape24T57 : Tree 11 := (.split 25 (.split 20 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.split 35 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10})))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,2,3,6,10})))
private theorem q11Shape24T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 71303168 11839438848 q11Shape24T57=true := by decide

private def q11Shape24T49 : Tree 11 := .split 26 q11Shape24T50 q11Shape24T57
private theorem q11Shape24T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 11839438848 q11Shape24T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 (11839438848 ||| 2^26) q11Shape24T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4194304 ||| 2^26) 11839438848 q11Shape24T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T50OK,q11Shape24T57OK⟩

private def q11Shape24T60 : Tree 11 := (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.split 3 (.split 26 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,2,3,9,10}))) (.split 35 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,8,10})))) (.tip (.cover {0,1,2,3,5,10}))) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 20971520 12493750272 q11Shape24T60=true := by decide

private def q11Shape24T61 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 557842432 11956879360 q11Shape24T61=true := by decide

private def q11Shape24T59 : Tree 11 := .split 29 q11Shape24T60 q11Shape24T61
private theorem q11Shape24T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 20971520 11956879360 q11Shape24T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 20971520 (11956879360 ||| 2^29) q11Shape24T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (20971520 ||| 2^29) 11956879360 q11Shape24T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T60OK,q11Shape24T61OK⟩

private def q11Shape24T62 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 155189248 11822661632 q11Shape24T62=true := by decide

private def q11Shape24T58 : Tree 11 := .split 27 q11Shape24T59 q11Shape24T62
private theorem q11Shape24T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 20971520 11822661632 q11Shape24T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 20971520 (11822661632 ||| 2^27) q11Shape24T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (20971520 ||| 2^27) 11822661632 q11Shape24T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T59OK,q11Shape24T62OK⟩

private def q11Shape24T48 : Tree 11 := .split 24 q11Shape24T49 q11Shape24T58
private theorem q11Shape24T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 11822661632 q11Shape24T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 (11822661632 ||| 2^24) q11Shape24T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4194304 ||| 2^24) 11822661632 q11Shape24T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T49OK,q11Shape24T58OK⟩

private def q11Shape24T66 : Tree 11 := (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 35 (.split 3 (.split 26 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,2,3,8,10}))) (.split 34 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,9,10})))) (.tip (.cover {0,1,2,3,5,10}))) (.tip (.cover {0,1,4,5,6,9})))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12582912 12636356608 q11Shape24T66=true := by decide

private def q11Shape24T67 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 549453824 12099485696 q11Shape24T67=true := by decide

private def q11Shape24T65 : Tree 11 := .split 29 q11Shape24T66 q11Shape24T67
private theorem q11Shape24T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12582912 12099485696 q11Shape24T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12582912 (12099485696 ||| 2^29) q11Shape24T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (12582912 ||| 2^29) 12099485696 q11Shape24T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T66OK,q11Shape24T67OK⟩

private def q11Shape24T68 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 281018368 11831050240 q11Shape24T68=true := by decide

private def q11Shape24T64 : Tree 11 := .split 28 q11Shape24T65 q11Shape24T68
private theorem q11Shape24T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12582912 11831050240 q11Shape24T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12582912 (11831050240 ||| 2^28) q11Shape24T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (12582912 ||| 2^28) 11831050240 q11Shape24T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T65OK,q11Shape24T68OK⟩

private def q11Shape24T69 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 29360128 11814273024 q11Shape24T69=true := by decide

private def q11Shape24T63 : Tree 11 := .split 24 q11Shape24T64 q11Shape24T69
private theorem q11Shape24T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12582912 11814273024 q11Shape24T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12582912 (11814273024 ||| 2^24) q11Shape24T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (12582912 ||| 2^24) 11814273024 q11Shape24T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T64OK,q11Shape24T69OK⟩

private def q11Shape24T47 : Tree 11 := .split 23 q11Shape24T48 q11Shape24T63
private theorem q11Shape24T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 11814273024 q11Shape24T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 (11814273024 ||| 2^23) q11Shape24T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4194304 ||| 2^23) 11814273024 q11Shape24T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T48OK,q11Shape24T63OK⟩

def q11Shape24P1 : Tree 11 := q11Shape24T47
theorem q11Shape24P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4194304 11814273024 q11Shape24P1=true := q11Shape24T47OK

end Graffiti384b.EffectiveSearch.Q11
