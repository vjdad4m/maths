import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T481 : Tree 11 := (.tip (.cover {0,1,2,3,6,10}))
private theorem q11Shape24T481OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11844616192 q11Shape24T481=true := by decide

private def q11Shape24T483 : Tree 11 := (.split 27 (.split 29 (.split 32 (.split 34 (.split 28 (.split 25 (.tip (.cover {0,1,2,3,4,9})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,7,8,10})))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {1,2,3,4,5,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T483OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16842752 11894947840 q11Shape24T483=true := by decide

private def q11Shape24T484 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape24T484OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 83951616 11827838976 q11Shape24T484=true := by decide

private def q11Shape24T482 : Tree 11 := .split 26 q11Shape24T483 q11Shape24T484
private theorem q11Shape24T482OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16842752 11827838976 q11Shape24T482=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16842752 (11827838976 ||| 2^26) q11Shape24T483 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (16842752 ||| 2^26) 11827838976 q11Shape24T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T483OK,q11Shape24T484OK⟩

private def q11Shape24T480 : Tree 11 := .split 24 q11Shape24T481 q11Shape24T482
private theorem q11Shape24T480OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11827838976 q11Shape24T480=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (11827838976 ||| 2^24) q11Shape24T481 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^24) 11827838976 q11Shape24T482)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T481OK,q11Shape24T482OK⟩

private def q11Shape24T487 : Tree 11 := (.split 28 (.split 29 (.split 32 (.split 35 (.split 27 (.split 25 (.tip (.cover {0,1,2,3,4,8})) (.split 34 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,7,9,10})))) (.tip (.cover {1,2,3,4,5,8}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {1,2,3,4,5,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T487OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8454144 11903336448 q11Shape24T487=true := by decide

private def q11Shape24T488 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape24T488OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75563008 11836227584 q11Shape24T488=true := by decide

private def q11Shape24T486 : Tree 11 := .split 26 q11Shape24T487 q11Shape24T488
private theorem q11Shape24T486OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8454144 11836227584 q11Shape24T486=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8454144 (11836227584 ||| 2^26) q11Shape24T487 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8454144 ||| 2^26) 11836227584 q11Shape24T488)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T487OK,q11Shape24T488OK⟩

private def q11Shape24T489 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T489OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25231360 11819450368 q11Shape24T489=true := by decide

private def q11Shape24T485 : Tree 11 := .split 24 q11Shape24T486 q11Shape24T489
private theorem q11Shape24T485OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8454144 11819450368 q11Shape24T485=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8454144 (11819450368 ||| 2^24) q11Shape24T486 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8454144 ||| 2^24) 11819450368 q11Shape24T489)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T486OK,q11Shape24T489OK⟩

private def q11Shape24T479 : Tree 11 := .split 23 q11Shape24T480 q11Shape24T485
private theorem q11Shape24T479OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11819450368 q11Shape24T479=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (11819450368 ||| 2^23) q11Shape24T480 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^23) 11819450368 q11Shape24T485)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T480OK,q11Shape24T485OK⟩

private def q11Shape24T490 : Tree 11 := (.tip (.cover {1,2,3,5,6,10}))
private theorem q11Shape24T490OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1114112 11818401792 q11Shape24T490=true := by decide

private def q11Shape24T478 : Tree 11 := .split 20 q11Shape24T479 q11Shape24T490
private theorem q11Shape24T478OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11818401792 q11Shape24T478=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (11818401792 ||| 2^20) q11Shape24T479 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^20) 11818401792 q11Shape24T490)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T479OK,q11Shape24T490OK⟩

private def q11Shape24T495 : Tree 11 := (.split 29 (.split 20 (.split 34 (.split 35 (.split 26 (.split 25 (.tip (.cover {0,1,2,3,4,7})) (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {1,2,3,4,5,7}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {1,2,3,5,6,10}))) (.tip (.cover {1,2,3,4,5,10})))
private theorem q11Shape24T495OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 12242026496 q11Shape24T495=true := by decide

private def q11Shape24T496 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape24T496OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 272695296 11973591040 q11Shape24T496=true := by decide

private def q11Shape24T494 : Tree 11 := .split 28 q11Shape24T495 q11Shape24T496
private theorem q11Shape24T494OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 11973591040 q11Shape24T494=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 (11973591040 ||| 2^28) q11Shape24T495 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4259840 ||| 2^28) 11973591040 q11Shape24T496)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T495OK,q11Shape24T496OK⟩

private def q11Shape24T497 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape24T497OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 138477568 11839373312 q11Shape24T497=true := by decide

private def q11Shape24T493 : Tree 11 := .split 27 q11Shape24T494 q11Shape24T497
private theorem q11Shape24T493OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 11839373312 q11Shape24T493=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 (11839373312 ||| 2^27) q11Shape24T494 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4259840 ||| 2^27) 11839373312 q11Shape24T497)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T494OK,q11Shape24T497OK⟩

private def q11Shape24T498 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T498OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 21037056 11822596096 q11Shape24T498=true := by decide

private def q11Shape24T492 : Tree 11 := .split 24 q11Shape24T493 q11Shape24T498
private theorem q11Shape24T492OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 11822596096 q11Shape24T492=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 (11822596096 ||| 2^24) q11Shape24T493 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4259840 ||| 2^24) 11822596096 q11Shape24T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T493OK,q11Shape24T498OK⟩

private def q11Shape24T499 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T499OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12648448 11814207488 q11Shape24T499=true := by decide

private def q11Shape24T491 : Tree 11 := .split 23 q11Shape24T492 q11Shape24T499
private theorem q11Shape24T491OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 11814207488 q11Shape24T491=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4259840 (11814207488 ||| 2^23) q11Shape24T492 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4259840 ||| 2^23) 11814207488 q11Shape24T499)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T492OK,q11Shape24T499OK⟩

private def q11Shape24T477 : Tree 11 := .split 22 q11Shape24T478 q11Shape24T491
private theorem q11Shape24T477OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11814207488 q11Shape24T477=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (11814207488 ||| 2^22) q11Shape24T478 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^22) 11814207488 q11Shape24T491)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T478OK,q11Shape24T491OK⟩

private def q11Shape24T500 : Tree 11 := (.split 22 (.split 23 (.split 25 (.split 32 (.split 34 (.split 20 (.tip (.cover {1,2,3,5,6,9})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {1,2,3,5,6,10})))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T500OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 589824 11813683200 q11Shape24T500=true := by decide

private def q11Shape24T476 : Tree 11 := .split 19 q11Shape24T477 q11Shape24T500
private theorem q11Shape24T476OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11813683200 q11Shape24T476=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (11813683200 ||| 2^19) q11Shape24T477 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^19) 11813683200 q11Shape24T500)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T477OK,q11Shape24T500OK⟩

private def q11Shape24T502 : Tree 11 := (.split 22 (.split 24 (.split 25 (.split 32 (.split 35 (.split 20 (.tip (.cover {1,2,3,5,6,8})) (.split 34 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {1,2,3,5,6,10})))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape24T502OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 327680 11813945344 q11Shape24T502=true := by decide

private def q11Shape24T503 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T503OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 851968 11813421056 q11Shape24T503=true := by decide

private def q11Shape24T501 : Tree 11 := .split 19 q11Shape24T502 q11Shape24T503
private theorem q11Shape24T501OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 327680 11813421056 q11Shape24T501=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 327680 (11813421056 ||| 2^19) q11Shape24T502 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (327680 ||| 2^19) 11813421056 q11Shape24T503)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T502OK,q11Shape24T503OK⟩

private def q11Shape24T475 : Tree 11 := .split 18 q11Shape24T476 q11Shape24T501
private theorem q11Shape24T475OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11813421056 q11Shape24T475=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (11813421056 ||| 2^18) q11Shape24T476 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^18) 11813421056 q11Shape24T501)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T476OK,q11Shape24T501OK⟩

private def q11Shape24T506 : Tree 11 := (.split 23 (.split 24 (.split 25 (.split 34 (.split 35 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {1,2,3,5,6,10})))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape24T506OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 196608 11814076416 q11Shape24T506=true := by decide

private def q11Shape24T507 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T507OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 720896 11813552128 q11Shape24T507=true := by decide

private def q11Shape24T505 : Tree 11 := .split 19 q11Shape24T506 q11Shape24T507
private theorem q11Shape24T505OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 196608 11813552128 q11Shape24T505=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 196608 (11813552128 ||| 2^19) q11Shape24T506 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (196608 ||| 2^19) 11813552128 q11Shape24T507)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T506OK,q11Shape24T507OK⟩

private def q11Shape24T508 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T508OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 458752 11813289984 q11Shape24T508=true := by decide

private def q11Shape24T504 : Tree 11 := .split 18 q11Shape24T505 q11Shape24T508
private theorem q11Shape24T504OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 196608 11813289984 q11Shape24T504=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 196608 (11813289984 ||| 2^18) q11Shape24T505 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (196608 ||| 2^18) 11813289984 q11Shape24T508)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T505OK,q11Shape24T508OK⟩

private def q11Shape24T474 : Tree 11 := .split 17 q11Shape24T475 q11Shape24T504
private theorem q11Shape24T474OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 11813289984 q11Shape24T474=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (11813289984 ||| 2^17) q11Shape24T475 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^17) 11813289984 q11Shape24T504)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T475OK,q11Shape24T504OK⟩

private def q11Shape24T520 : Tree 11 := (.split 29 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,4,5,7,10})))) (.split 20 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,7,8,10}))))
private theorem q11Shape24T520OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 8051916800 q11Shape24T520=true := by decide

private def q11Shape24T521 : Tree 11 := (.split 20 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape24T521OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8858435584 7783481344 q11Shape24T521=true := by decide

private def q11Shape24T519 : Tree 11 := .split 28 q11Shape24T520 q11Shape24T521
private theorem q11Shape24T519OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 7783481344 q11Shape24T519=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (7783481344 ||| 2^28) q11Shape24T520 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^28) 7783481344 q11Shape24T521)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T520OK,q11Shape24T521OK⟩

private def q11Shape24T522 : Tree 11 := (.split 28 (.split 20 (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T522OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8724217856 7649263616 q11Shape24T522=true := by decide

private def q11Shape24T518 : Tree 11 := .split 27 q11Shape24T519 q11Shape24T522
private theorem q11Shape24T518OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 7649263616 q11Shape24T518=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (7649263616 ||| 2^27) q11Shape24T519 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^27) 7649263616 q11Shape24T522)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T519OK,q11Shape24T522OK⟩

private def q11Shape24T523 : Tree 11 := (.split 28 (.split 29 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape24T523OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590524416 7648739328 q11Shape24T523=true := by decide

private def q11Shape24T517 : Tree 11 := .split 19 q11Shape24T518 q11Shape24T523
private theorem q11Shape24T517OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 7648739328 q11Shape24T517=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (7648739328 ||| 2^19) q11Shape24T518 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^19) 7648739328 q11Shape24T523)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T518OK,q11Shape24T523OK⟩

private def q11Shape24T524 : Tree 11 := (.split 19 (.split 27 (.split 29 (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape24T524OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590262272 7648477184 q11Shape24T524=true := by decide

private def q11Shape24T516 : Tree 11 := .split 18 q11Shape24T517 q11Shape24T524
private theorem q11Shape24T516OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 7648477184 q11Shape24T516=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (7648477184 ||| 2^18) q11Shape24T517 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^18) 7648477184 q11Shape24T524)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T517OK,q11Shape24T524OK⟩

private def q11Shape24T525 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T525OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12884967424 3353509888 q11Shape24T525=true := by decide

private def q11Shape24T515 : Tree 11 := .split 32 q11Shape24T516 q11Shape24T525
private theorem q11Shape24T515OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 3353509888 q11Shape24T515=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (3353509888 ||| 2^32) q11Shape24T516 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^32) 3353509888 q11Shape24T525)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T516OK,q11Shape24T525OK⟩

private def q11Shape24T526 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T526OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8623554560 3319955456 q11Shape24T526=true := by decide

private def q11Shape24T514 : Tree 11 := .split 25 q11Shape24T515 q11Shape24T526
private theorem q11Shape24T514OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 3319955456 q11Shape24T514=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (3319955456 ||| 2^25) q11Shape24T515 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^25) 3319955456 q11Shape24T526)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T515OK,q11Shape24T526OK⟩

private def q11Shape24T527 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape24T527OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8657108992 3252846592 q11Shape24T527=true := by decide

private def q11Shape24T513 : Tree 11 := .split 26 q11Shape24T514 q11Shape24T527
private theorem q11Shape24T513OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 3252846592 q11Shape24T513=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (3252846592 ||| 2^26) q11Shape24T514 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^26) 3252846592 q11Shape24T527)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T514OK,q11Shape24T527OK⟩

private def q11Shape24T528 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T528OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8606777344 3236069376 q11Shape24T528=true := by decide

private def q11Shape24T512 : Tree 11 := .split 24 q11Shape24T513 q11Shape24T528
private theorem q11Shape24T512OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 3236069376 q11Shape24T512=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (3236069376 ||| 2^24) q11Shape24T513 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^24) 3236069376 q11Shape24T528)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T513OK,q11Shape24T528OK⟩

private def q11Shape24T529 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T529OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8598388736 3227680768 q11Shape24T529=true := by decide

private def q11Shape24T511 : Tree 11 := .split 23 q11Shape24T512 q11Shape24T529
private theorem q11Shape24T511OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 3227680768 q11Shape24T511=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (3227680768 ||| 2^23) q11Shape24T512 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^23) 3227680768 q11Shape24T529)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T512OK,q11Shape24T529OK⟩

private def q11Shape24T530 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T530OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8594194432 3223486464 q11Shape24T530=true := by decide

private def q11Shape24T510 : Tree 11 := .split 22 q11Shape24T511 q11Shape24T530
private theorem q11Shape24T510OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 3223486464 q11Shape24T510=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (3223486464 ||| 2^22) q11Shape24T511 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^22) 3223486464 q11Shape24T530)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T511OK,q11Shape24T530OK⟩

private def q11Shape24T531 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T531OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590131200 3223355392 q11Shape24T531=true := by decide

private def q11Shape24T509 : Tree 11 := .split 17 q11Shape24T510 q11Shape24T531
private theorem q11Shape24T509OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 3223355392 q11Shape24T509=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590000128 (3223355392 ||| 2^17) q11Shape24T510 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590000128 ||| 2^17) 3223355392 q11Shape24T531)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T510OK,q11Shape24T531OK⟩

private def q11Shape24T473 : Tree 11 := .split 33 q11Shape24T474 q11Shape24T509
private theorem q11Shape24T473OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 3223355392 q11Shape24T473=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 (3223355392 ||| 2^33) q11Shape24T474 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (65536 ||| 2^33) 3223355392 q11Shape24T509)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T474OK,q11Shape24T509OK⟩

def q11Shape24P11 : Tree 11 := q11Shape24T473
theorem q11Shape24P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 65536 3223355392 q11Shape24P11=true := q11Shape24T473OK

end Graffiti384b.EffectiveSearch.Q11
