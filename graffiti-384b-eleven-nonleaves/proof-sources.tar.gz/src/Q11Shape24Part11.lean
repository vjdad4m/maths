import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T544 : Tree 11 := (.split 29 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,5,8,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,7,8,10}))))
private theorem q11Shape24T544OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 27379269632 q11Shape24T544=true := by decide

private def q11Shape24T545 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape24T545OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2415984640 27110834176 q11Shape24T545=true := by decide

private def q11Shape24T543 : Tree 11 := .split 28 q11Shape24T544 q11Shape24T545
private theorem q11Shape24T543OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 27110834176 q11Shape24T543=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (27110834176 ||| 2^28) q11Shape24T544 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^28) 27110834176 q11Shape24T545)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T544OK,q11Shape24T545OK⟩

private def q11Shape24T546 : Tree 11 := (.split 28 (.split 20 (.split 35 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T546OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2214658048 27043725312 q11Shape24T546=true := by decide

private def q11Shape24T542 : Tree 11 := .split 26 q11Shape24T543 q11Shape24T546
private theorem q11Shape24T542OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 27043725312 q11Shape24T542=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (27043725312 ||| 2^26) q11Shape24T543 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^26) 27043725312 q11Shape24T546)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T543OK,q11Shape24T546OK⟩

private def q11Shape24T547 : Tree 11 := (.split 28 (.split 29 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape24T547OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2148073472 27043201024 q11Shape24T547=true := by decide

private def q11Shape24T541 : Tree 11 := .split 19 q11Shape24T542 q11Shape24T547
private theorem q11Shape24T541OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 27043201024 q11Shape24T541=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (27043201024 ||| 2^19) q11Shape24T542 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^19) 27043201024 q11Shape24T547)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T542OK,q11Shape24T547OK⟩

private def q11Shape24T548 : Tree 11 := (.split 19 (.split 26 (.split 29 (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T548OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147680256 27043069952 q11Shape24T548=true := by decide

private def q11Shape24T540 : Tree 11 := .split 17 q11Shape24T541 q11Shape24T548
private theorem q11Shape24T540OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 27043069952 q11Shape24T540=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (27043069952 ||| 2^17) q11Shape24T541 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^17) 27043069952 q11Shape24T548)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T541OK,q11Shape24T548OK⟩

private def q11Shape24T549 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T549OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 19327418368 9863200768 q11Shape24T549=true := by decide

private def q11Shape24T539 : Tree 11 := .split 34 q11Shape24T540 q11Shape24T549
private theorem q11Shape24T539OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 9863200768 q11Shape24T539=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (9863200768 ||| 2^34) q11Shape24T540 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^34) 9863200768 q11Shape24T549)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T540OK,q11Shape24T549OK⟩

private def q11Shape24T550 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T550OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2181103616 9829646336 q11Shape24T550=true := by decide

private def q11Shape24T538 : Tree 11 := .split 25 q11Shape24T539 q11Shape24T550
private theorem q11Shape24T538OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 9829646336 q11Shape24T538=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (9829646336 ||| 2^25) q11Shape24T539 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^25) 9829646336 q11Shape24T550)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T539OK,q11Shape24T550OK⟩

private def q11Shape24T551 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape24T551OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2281766912 9695428608 q11Shape24T551=true := by decide

private def q11Shape24T537 : Tree 11 := .split 27 q11Shape24T538 q11Shape24T551
private theorem q11Shape24T537OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 9695428608 q11Shape24T537=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (9695428608 ||| 2^27) q11Shape24T538 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^27) 9695428608 q11Shape24T551)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T538OK,q11Shape24T551OK⟩

private def q11Shape24T552 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape24T552OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2164326400 9678651392 q11Shape24T552=true := by decide

private def q11Shape24T536 : Tree 11 := .split 24 q11Shape24T537 q11Shape24T552
private theorem q11Shape24T536OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 9678651392 q11Shape24T536=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (9678651392 ||| 2^24) q11Shape24T537 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^24) 9678651392 q11Shape24T552)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T537OK,q11Shape24T552OK⟩

private def q11Shape24T553 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T553OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2155937792 9670262784 q11Shape24T553=true := by decide

private def q11Shape24T535 : Tree 11 := .split 23 q11Shape24T536 q11Shape24T553
private theorem q11Shape24T535OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 9670262784 q11Shape24T535=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (9670262784 ||| 2^23) q11Shape24T536 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^23) 9670262784 q11Shape24T553)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T536OK,q11Shape24T553OK⟩

private def q11Shape24T554 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T554OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2151743488 9666068480 q11Shape24T554=true := by decide

private def q11Shape24T534 : Tree 11 := .split 22 q11Shape24T535 q11Shape24T554
private theorem q11Shape24T534OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 9666068480 q11Shape24T534=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (9666068480 ||| 2^22) q11Shape24T535 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^22) 9666068480 q11Shape24T554)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T535OK,q11Shape24T554OK⟩

private def q11Shape24T555 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T555OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147811328 9665806336 q11Shape24T555=true := by decide

private def q11Shape24T533 : Tree 11 := .split 18 q11Shape24T534 q11Shape24T555
private theorem q11Shape24T533OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 9665806336 q11Shape24T533=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (9665806336 ||| 2^18) q11Shape24T534 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^18) 9665806336 q11Shape24T555)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T534OK,q11Shape24T555OK⟩

private def q11Shape24T556 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T556OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 10737483776 1075871744 q11Shape24T556=true := by decide

private def q11Shape24T532 : Tree 11 := .split 33 q11Shape24T533 q11Shape24T556
private theorem q11Shape24T532OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 1075871744 q11Shape24T532=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 (1075871744 ||| 2^33) q11Shape24T533 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147549184 ||| 2^33) 1075871744 q11Shape24T556)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T533OK,q11Shape24T556OK⟩

def q11Shape24P12 : Tree 11 := q11Shape24T532
theorem q11Shape24P12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147549184 1075871744 q11Shape24P12=true := q11Shape24T532OK

private def q11Shape24T571 : Tree 11 := (.split 29 (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.split 34 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,5,9,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape24T571OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 45632880640 q11Shape24T571=true := by decide

private def q11Shape24T572 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape24T572OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1208025088 45498662912 q11Shape24T572=true := by decide

private def q11Shape24T570 : Tree 11 := .split 27 q11Shape24T571 q11Shape24T572
private theorem q11Shape24T570OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 45498662912 q11Shape24T570=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (45498662912 ||| 2^27) q11Shape24T571 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^27) 45498662912 q11Shape24T572)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T571OK,q11Shape24T572OK⟩

private def q11Shape24T573 : Tree 11 := (.split 27 (.split 20 (.split 34 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T573OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1140916224 45431554048 q11Shape24T573=true := by decide

private def q11Shape24T569 : Tree 11 := .split 26 q11Shape24T570 q11Shape24T573
private theorem q11Shape24T569OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 45431554048 q11Shape24T569=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (45431554048 ||| 2^26) q11Shape24T570 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^26) 45431554048 q11Shape24T573)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T570OK,q11Shape24T573OK⟩

private def q11Shape24T574 : Tree 11 := (.split 27 (.split 29 (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape24T574OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074069504 45431291904 q11Shape24T574=true := by decide

private def q11Shape24T568 : Tree 11 := .split 18 q11Shape24T569 q11Shape24T574
private theorem q11Shape24T568OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 45431291904 q11Shape24T568=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (45431291904 ||| 2^18) q11Shape24T569 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^18) 45431291904 q11Shape24T574)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T569OK,q11Shape24T574OK⟩

private def q11Shape24T575 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T575OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 35433545728 11071553536 q11Shape24T575=true := by decide

private def q11Shape24T567 : Tree 11 := .split 35 q11Shape24T568 q11Shape24T575
private theorem q11Shape24T567OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 11071553536 q11Shape24T567=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (11071553536 ||| 2^35) q11Shape24T568 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^35) 11071553536 q11Shape24T575)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T568OK,q11Shape24T575OK⟩

private def q11Shape24T577 : Tree 11 := (.split 26 (.split 29 (.split 32 (.tip (.cover {0,2,3,4,8,9})) (.split 27 (.split 20 (.split 34 (.split 35 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape24T577OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073938432 11071684608 q11Shape24T577=true := by decide

private def q11Shape24T578 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T578OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074200576 11071422464 q11Shape24T578=true := by decide

private def q11Shape24T576 : Tree 11 := .split 18 q11Shape24T577 q11Shape24T578
private theorem q11Shape24T576OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073938432 11071422464 q11Shape24T576=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073938432 (11071422464 ||| 2^18) q11Shape24T577 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073938432 ||| 2^18) 11071422464 q11Shape24T578)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T577OK,q11Shape24T578OK⟩

private def q11Shape24T566 : Tree 11 := .split 17 q11Shape24T567 q11Shape24T576
private theorem q11Shape24T566OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 11071422464 q11Shape24T566=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (11071422464 ||| 2^17) q11Shape24T567 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^17) 11071422464 q11Shape24T576)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T567OK,q11Shape24T576OK⟩

private def q11Shape24T579 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T579OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1107361792 11037868032 q11Shape24T579=true := by decide

private def q11Shape24T565 : Tree 11 := .split 25 q11Shape24T566 q11Shape24T579
private theorem q11Shape24T565OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 11037868032 q11Shape24T565=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (11037868032 ||| 2^25) q11Shape24T566 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^25) 11037868032 q11Shape24T579)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T566OK,q11Shape24T579OK⟩

private def q11Shape24T580 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape24T580OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1342242816 10769432576 q11Shape24T580=true := by decide

private def q11Shape24T564 : Tree 11 := .split 28 q11Shape24T565 q11Shape24T580
private theorem q11Shape24T564OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 10769432576 q11Shape24T564=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (10769432576 ||| 2^28) q11Shape24T565 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^28) 10769432576 q11Shape24T580)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T565OK,q11Shape24T580OK⟩

private def q11Shape24T581 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T581OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1090584576 10752655360 q11Shape24T581=true := by decide

private def q11Shape24T563 : Tree 11 := .split 24 q11Shape24T564 q11Shape24T581
private theorem q11Shape24T563OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 10752655360 q11Shape24T563=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (10752655360 ||| 2^24) q11Shape24T564 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^24) 10752655360 q11Shape24T581)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T564OK,q11Shape24T581OK⟩

private def q11Shape24T582 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape24T582OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1082195968 10744266752 q11Shape24T582=true := by decide

private def q11Shape24T562 : Tree 11 := .split 23 q11Shape24T563 q11Shape24T582
private theorem q11Shape24T562OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 10744266752 q11Shape24T562=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (10744266752 ||| 2^23) q11Shape24T563 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^23) 10744266752 q11Shape24T582)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T563OK,q11Shape24T582OK⟩

private def q11Shape24T583 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T583OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1078001664 10740072448 q11Shape24T583=true := by decide

private def q11Shape24T561 : Tree 11 := .split 22 q11Shape24T562 q11Shape24T583
private theorem q11Shape24T561OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 10740072448 q11Shape24T561=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (10740072448 ||| 2^22) q11Shape24T562 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^22) 10740072448 q11Shape24T583)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T562OK,q11Shape24T583OK⟩

private def q11Shape24T584 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T584OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074331648 10739548160 q11Shape24T584=true := by decide

private def q11Shape24T560 : Tree 11 := .split 19 q11Shape24T561 q11Shape24T584
private theorem q11Shape24T560OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 10739548160 q11Shape24T560=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (10739548160 ||| 2^19) q11Shape24T561 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^19) 10739548160 q11Shape24T584)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T561OK,q11Shape24T584OK⟩

private def q11Shape24T585 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T585OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 9663741952 2149613568 q11Shape24T585=true := by decide

private def q11Shape24T559 : Tree 11 := .split 33 q11Shape24T560 q11Shape24T585
private theorem q11Shape24T559OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 2149613568 q11Shape24T559=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (2149613568 ||| 2^33) q11Shape24T560 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^33) 2149613568 q11Shape24T585)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T560OK,q11Shape24T585OK⟩

private def q11Shape24T586 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T586OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 3221291008 2129920 q11Shape24T586=true := by decide

private def q11Shape24T558 : Tree 11 := .split 31 q11Shape24T559 q11Shape24T586
private theorem q11Shape24T558OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 2129920 q11Shape24T558=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 (2129920 ||| 2^31) q11Shape24T559 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073807360 ||| 2^31) 2129920 q11Shape24T586)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T559OK,q11Shape24T586OK⟩

def q11Shape24P13 : Tree 11 := q11Shape24T558
theorem q11Shape24P13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073807360 2129920 q11Shape24P13=true := q11Shape24T558OK

private def q11Shape24T588 : Tree 11 := (.split 30 (.split 31 (.split 33 (.split 26 (.split 27 (.split 28 (.tip (.cover {1,2,3,4,5,10})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape24T588OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2162688 32768 q11Shape24T588=true := by decide

def q11Shape24P14 : Tree 11 := q11Shape24T588
theorem q11Shape24P14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2162688 32768 q11Shape24P14=true := q11Shape24T588OK

end Graffiti384b.EffectiveSearch.Q11
