import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T602 : Tree 11 := (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover {1,2,3,4,6,10}))) (.tip (.cover {1,2,3,5,6,10})))
private theorem q11Shape24T602OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11945312262 q11Shape24T602=true := by decide

private def q11Shape24T603 : Tree 11 := (.split 27 (.split 28 (.split 34 (.split 35 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T603OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67141632 11878203398 q11Shape24T603=true := by decide

private def q11Shape24T601 : Tree 11 := .split 26 q11Shape24T602 q11Shape24T603
private theorem q11Shape24T601OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11878203398 q11Shape24T601=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11878203398 ||| 2^26) q11Shape24T602 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^26) 11878203398 q11Shape24T603)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T602OK,q11Shape24T603OK⟩

private def q11Shape24T604 : Tree 11 := (.tip (.cover {1,2,3,4,6,10}))
private theorem q11Shape24T604OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32772 11878203394 q11Shape24T604=true := by decide

private def q11Shape24T600 : Tree 11 := .split 2 q11Shape24T601 q11Shape24T604
private theorem q11Shape24T600OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11878203394 q11Shape24T600=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11878203394 ||| 2^2) q11Shape24T601 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^2) 11878203394 q11Shape24T604)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T601OK,q11Shape24T604OK⟩

private def q11Shape24T605 : Tree 11 := (.tip (.cover {1,2,3,5,6,10}))
private theorem q11Shape24T605OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32770 11878203392 q11Shape24T605=true := by decide

private def q11Shape24T599 : Tree 11 := .split 1 q11Shape24T600 q11Shape24T605
private theorem q11Shape24T599OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11878203392 q11Shape24T599=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11878203392 ||| 2^1) q11Shape24T600 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^1) 11878203392 q11Shape24T605)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T600OK,q11Shape24T605OK⟩

private def q11Shape24T606 : Tree 11 := (.tip (.cover {1,2,3,4,6,10}))
private theorem q11Shape24T606OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 33587200 11844648960 q11Shape24T606=true := by decide

private def q11Shape24T598 : Tree 11 := .split 25 q11Shape24T599 q11Shape24T606
private theorem q11Shape24T598OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11844648960 q11Shape24T598=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11844648960 ||| 2^25) q11Shape24T599 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^25) 11844648960 q11Shape24T606)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T599OK,q11Shape24T606OK⟩

private def q11Shape24T607 : Tree 11 := (.split 26 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,5,10})) (.split 25 (.split 29 (.split 32 (.split 34 (.tip (.cover {1,2,3,4,6,9})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {1,2,3,4,6,10})))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T607OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16809984 11827871744 q11Shape24T607=true := by decide

private def q11Shape24T597 : Tree 11 := .split 24 q11Shape24T598 q11Shape24T607
private theorem q11Shape24T597OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11827871744 q11Shape24T597=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11827871744 ||| 2^24) q11Shape24T598 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^24) 11827871744 q11Shape24T607)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T598OK,q11Shape24T607OK⟩

private def q11Shape24T609 : Tree 11 := (.split 26 (.split 28 (.split 27 (.tip (.cover {0,1,2,3,5,10})) (.split 25 (.split 29 (.split 32 (.split 35 (.tip (.cover {1,2,3,4,6,8})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {1,2,3,4,6,10})))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T609OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8421376 11836260352 q11Shape24T609=true := by decide

private def q11Shape24T610 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape24T610OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25198592 11819483136 q11Shape24T610=true := by decide

private def q11Shape24T608 : Tree 11 := .split 24 q11Shape24T609 q11Shape24T610
private theorem q11Shape24T608OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8421376 11819483136 q11Shape24T608=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8421376 (11819483136 ||| 2^24) q11Shape24T609 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8421376 ||| 2^24) 11819483136 q11Shape24T610)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T609OK,q11Shape24T610OK⟩

private def q11Shape24T596 : Tree 11 := .split 23 q11Shape24T597 q11Shape24T608
private theorem q11Shape24T596OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11819483136 q11Shape24T596=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11819483136 ||| 2^23) q11Shape24T597 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^23) 11819483136 q11Shape24T608)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T597OK,q11Shape24T608OK⟩

private def q11Shape24T611 : Tree 11 := (.tip (.cover {1,2,3,5,6,10}))
private theorem q11Shape24T611OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1081344 11818434560 q11Shape24T611=true := by decide

private def q11Shape24T595 : Tree 11 := .split 20 q11Shape24T596 q11Shape24T611
private theorem q11Shape24T595OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11818434560 q11Shape24T595=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11818434560 ||| 2^20) q11Shape24T596 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^20) 11818434560 q11Shape24T611)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T596OK,q11Shape24T611OK⟩

private def q11Shape24T615 : Tree 11 := (.split 28 (.split 26 (.tip (.cover {0,1,2,3,5,10})) (.split 25 (.split 29 (.split 20 (.split 34 (.split 35 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {1,2,3,4,6,10})))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T615OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4227072 11973623808 q11Shape24T615=true := by decide

private def q11Shape24T616 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape24T616OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 138444800 11839406080 q11Shape24T616=true := by decide

private def q11Shape24T614 : Tree 11 := .split 27 q11Shape24T615 q11Shape24T616
private theorem q11Shape24T614OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4227072 11839406080 q11Shape24T614=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4227072 (11839406080 ||| 2^27) q11Shape24T615 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4227072 ||| 2^27) 11839406080 q11Shape24T616)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T615OK,q11Shape24T616OK⟩

private def q11Shape24T617 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape24T617OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 21004288 11822628864 q11Shape24T617=true := by decide

private def q11Shape24T613 : Tree 11 := .split 24 q11Shape24T614 q11Shape24T617
private theorem q11Shape24T613OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4227072 11822628864 q11Shape24T613=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4227072 (11822628864 ||| 2^24) q11Shape24T614 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4227072 ||| 2^24) 11822628864 q11Shape24T617)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T614OK,q11Shape24T617OK⟩

private def q11Shape24T618 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape24T618OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12615680 11814240256 q11Shape24T618=true := by decide

private def q11Shape24T612 : Tree 11 := .split 23 q11Shape24T613 q11Shape24T618
private theorem q11Shape24T612OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4227072 11814240256 q11Shape24T612=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4227072 (11814240256 ||| 2^23) q11Shape24T613 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4227072 ||| 2^23) 11814240256 q11Shape24T618)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T613OK,q11Shape24T618OK⟩

private def q11Shape24T594 : Tree 11 := .split 22 q11Shape24T595 q11Shape24T612
private theorem q11Shape24T594OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11814240256 q11Shape24T594=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11814240256 ||| 2^22) q11Shape24T595 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^22) 11814240256 q11Shape24T612)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T595OK,q11Shape24T612OK⟩

private def q11Shape24T619 : Tree 11 := (.split 26 (.split 27 (.split 29 (.split 32 (.split 34 (.split 20 (.tip (.cover {1,2,3,5,6,9})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {1,2,3,5,6,10})))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape24T619OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 557056 11813715968 q11Shape24T619=true := by decide

private def q11Shape24T593 : Tree 11 := .split 19 q11Shape24T594 q11Shape24T619
private theorem q11Shape24T593OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11813715968 q11Shape24T593=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11813715968 ||| 2^19) q11Shape24T594 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^19) 11813715968 q11Shape24T619)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T594OK,q11Shape24T619OK⟩

private def q11Shape24T621 : Tree 11 := (.split 26 (.split 28 (.split 29 (.split 32 (.split 35 (.split 20 (.tip (.cover {1,2,3,5,6,8})) (.split 34 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {1,2,3,5,6,10})))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T621OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 294912 11813978112 q11Shape24T621=true := by decide

private def q11Shape24T622 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T622OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 819200 11813453824 q11Shape24T622=true := by decide

private def q11Shape24T620 : Tree 11 := .split 19 q11Shape24T621 q11Shape24T622
private theorem q11Shape24T620OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 294912 11813453824 q11Shape24T620=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 294912 (11813453824 ||| 2^19) q11Shape24T621 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (294912 ||| 2^19) 11813453824 q11Shape24T622)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T621OK,q11Shape24T622OK⟩

private def q11Shape24T592 : Tree 11 := .split 18 q11Shape24T593 q11Shape24T620
private theorem q11Shape24T592OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11813453824 q11Shape24T592=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11813453824 ||| 2^18) q11Shape24T593 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^18) 11813453824 q11Shape24T620)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T593OK,q11Shape24T620OK⟩

private def q11Shape24T625 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 34 (.split 35 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {1,2,3,5,6,10})))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T625OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 163840 11814109184 q11Shape24T625=true := by decide

private def q11Shape24T626 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T626OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 688128 11813584896 q11Shape24T626=true := by decide

private def q11Shape24T624 : Tree 11 := .split 19 q11Shape24T625 q11Shape24T626
private theorem q11Shape24T624OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 163840 11813584896 q11Shape24T624=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 163840 (11813584896 ||| 2^19) q11Shape24T625 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (163840 ||| 2^19) 11813584896 q11Shape24T626)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T625OK,q11Shape24T626OK⟩

private def q11Shape24T627 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T627OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 425984 11813322752 q11Shape24T627=true := by decide

private def q11Shape24T623 : Tree 11 := .split 18 q11Shape24T624 q11Shape24T627
private theorem q11Shape24T623OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 163840 11813322752 q11Shape24T623=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 163840 (11813322752 ||| 2^18) q11Shape24T624 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (163840 ||| 2^18) 11813322752 q11Shape24T627)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T624OK,q11Shape24T627OK⟩

private def q11Shape24T591 : Tree 11 := .split 17 q11Shape24T592 q11Shape24T623
private theorem q11Shape24T591OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11813322752 q11Shape24T591=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 (11813322752 ||| 2^17) q11Shape24T592 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (32768 ||| 2^17) 11813322752 q11Shape24T623)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T592OK,q11Shape24T623OK⟩

def q11Shape24P15 : Tree 11 := q11Shape24T591
theorem q11Shape24P15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 32768 11813322752 q11Shape24P15=true := q11Shape24T591OK

end Graffiti384b.EffectiveSearch.Q11
