import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T639 : Tree 11 := (.split 25 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,4,6,7,10})))) (.split 20 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,7,8,10}))))
private theorem q11Shape24T639OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 8555266048 q11Shape24T639=true := by decide

private def q11Shape24T640 : Tree 11 := (.split 20 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape24T640OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8606744576 8538488832 q11Shape24T640=true := by decide

private def q11Shape24T638 : Tree 11 := .split 24 q11Shape24T639 q11Shape24T640
private theorem q11Shape24T638OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 8538488832 q11Shape24T638=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (8538488832 ||| 2^24) q11Shape24T639 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^24) 8538488832 q11Shape24T640)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T639OK,q11Shape24T640OK⟩

private def q11Shape24T641 : Tree 11 := (.split 24 (.split 20 (.split 35 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T641OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8598355968 8530100224 q11Shape24T641=true := by decide

private def q11Shape24T637 : Tree 11 := .split 23 q11Shape24T638 q11Shape24T641
private theorem q11Shape24T637OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 8530100224 q11Shape24T637=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (8530100224 ||| 2^23) q11Shape24T638 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^23) 8530100224 q11Shape24T641)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T638OK,q11Shape24T641OK⟩

private def q11Shape24T642 : Tree 11 := (.split 24 (.split 25 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape24T642OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590491648 8529575936 q11Shape24T642=true := by decide

private def q11Shape24T636 : Tree 11 := .split 19 q11Shape24T637 q11Shape24T642
private theorem q11Shape24T636OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 8529575936 q11Shape24T636=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (8529575936 ||| 2^19) q11Shape24T637 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^19) 8529575936 q11Shape24T642)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T637OK,q11Shape24T642OK⟩

private def q11Shape24T643 : Tree 11 := (.split 19 (.split 23 (.split 25 (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape24T643OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590229504 8529313792 q11Shape24T643=true := by decide

private def q11Shape24T635 : Tree 11 := .split 18 q11Shape24T636 q11Shape24T643
private theorem q11Shape24T635OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 8529313792 q11Shape24T635=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (8529313792 ||| 2^18) q11Shape24T636 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^18) 8529313792 q11Shape24T643)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T636OK,q11Shape24T643OK⟩

private def q11Shape24T644 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T644OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12884934656 4234346496 q11Shape24T644=true := by decide

private def q11Shape24T634 : Tree 11 := .split 32 q11Shape24T635 q11Shape24T644
private theorem q11Shape24T634OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 4234346496 q11Shape24T634=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (4234346496 ||| 2^32) q11Shape24T635 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^32) 4234346496 q11Shape24T644)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T635OK,q11Shape24T644OK⟩

private def q11Shape24T645 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T645OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 9126838272 3697475584 q11Shape24T645=true := by decide

private def q11Shape24T633 : Tree 11 := .split 29 q11Shape24T634 q11Shape24T645
private theorem q11Shape24T633OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 3697475584 q11Shape24T633=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (3697475584 ||| 2^29) q11Shape24T634 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^29) 3697475584 q11Shape24T645)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T634OK,q11Shape24T645OK⟩

private def q11Shape24T646 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T646OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8858402816 3429040128 q11Shape24T646=true := by decide

private def q11Shape24T632 : Tree 11 := .split 28 q11Shape24T633 q11Shape24T646
private theorem q11Shape24T632OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 3429040128 q11Shape24T632=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (3429040128 ||| 2^28) q11Shape24T633 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^28) 3429040128 q11Shape24T646)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T633OK,q11Shape24T646OK⟩

private def q11Shape24T647 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T647OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8724185088 3294822400 q11Shape24T647=true := by decide

private def q11Shape24T631 : Tree 11 := .split 27 q11Shape24T632 q11Shape24T647
private theorem q11Shape24T631OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 3294822400 q11Shape24T631=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (3294822400 ||| 2^27) q11Shape24T632 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^27) 3294822400 q11Shape24T647)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T632OK,q11Shape24T647OK⟩

private def q11Shape24T648 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T648OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8657076224 3227713536 q11Shape24T648=true := by decide

private def q11Shape24T630 : Tree 11 := .split 26 q11Shape24T631 q11Shape24T648
private theorem q11Shape24T630OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 3227713536 q11Shape24T630=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (3227713536 ||| 2^26) q11Shape24T631 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^26) 3227713536 q11Shape24T648)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T631OK,q11Shape24T648OK⟩

private def q11Shape24T649 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape24T649OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8594161664 3223519232 q11Shape24T649=true := by decide

private def q11Shape24T629 : Tree 11 := .split 22 q11Shape24T630 q11Shape24T649
private theorem q11Shape24T629OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 3223519232 q11Shape24T629=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (3223519232 ||| 2^22) q11Shape24T630 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^22) 3223519232 q11Shape24T649)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T630OK,q11Shape24T649OK⟩

private def q11Shape24T650 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T650OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590098432 3223388160 q11Shape24T650=true := by decide

private def q11Shape24T628 : Tree 11 := .split 17 q11Shape24T629 q11Shape24T650
private theorem q11Shape24T628OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 3223388160 q11Shape24T628=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 (3223388160 ||| 2^17) q11Shape24T629 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589967360 ||| 2^17) 3223388160 q11Shape24T650)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T629OK,q11Shape24T650OK⟩

def q11Shape24P16 : Tree 11 := q11Shape24T628
theorem q11Shape24P16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589967360 3223388160 q11Shape24P16=true := q11Shape24T628OK

private def q11Shape24T664 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,6,8,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,7,8,10}))))
private theorem q11Shape24T664OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 27882618880 q11Shape24T664=true := by decide

private def q11Shape24T665 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape24T665OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2164293632 27865841664 q11Shape24T665=true := by decide

private def q11Shape24T663 : Tree 11 := .split 24 q11Shape24T664 q11Shape24T665
private theorem q11Shape24T663OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 27865841664 q11Shape24T663=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (27865841664 ||| 2^24) q11Shape24T664 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^24) 27865841664 q11Shape24T665)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T664OK,q11Shape24T665OK⟩

private def q11Shape24T666 : Tree 11 := (.split 24 (.split 20 (.split 35 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T666OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2151710720 27861647360 q11Shape24T666=true := by decide

private def q11Shape24T662 : Tree 11 := .split 22 q11Shape24T663 q11Shape24T666
private theorem q11Shape24T662OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 27861647360 q11Shape24T662=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (27861647360 ||| 2^22) q11Shape24T663 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^22) 27861647360 q11Shape24T666)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T663OK,q11Shape24T666OK⟩

private def q11Shape24T667 : Tree 11 := (.split 24 (.split 25 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape24T667OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2148040704 27861123072 q11Shape24T667=true := by decide

private def q11Shape24T661 : Tree 11 := .split 19 q11Shape24T662 q11Shape24T667
private theorem q11Shape24T661OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 27861123072 q11Shape24T661=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (27861123072 ||| 2^19) q11Shape24T662 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^19) 27861123072 q11Shape24T667)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T662OK,q11Shape24T667OK⟩

private def q11Shape24T668 : Tree 11 := (.split 19 (.split 22 (.split 25 (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape24T668OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147647488 27860992000 q11Shape24T668=true := by decide

private def q11Shape24T660 : Tree 11 := .split 17 q11Shape24T661 q11Shape24T668
private theorem q11Shape24T660OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 27860992000 q11Shape24T660=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (27860992000 ||| 2^17) q11Shape24T661 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^17) 27860992000 q11Shape24T668)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T661OK,q11Shape24T668OK⟩

private def q11Shape24T669 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T669OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 19327385600 10681122816 q11Shape24T669=true := by decide

private def q11Shape24T659 : Tree 11 := .split 34 q11Shape24T660 q11Shape24T669
private theorem q11Shape24T659OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 10681122816 q11Shape24T659=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (10681122816 ||| 2^34) q11Shape24T660 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^34) 10681122816 q11Shape24T669)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T660OK,q11Shape24T669OK⟩

private def q11Shape24T670 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T670OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2684387328 10144251904 q11Shape24T670=true := by decide

private def q11Shape24T658 : Tree 11 := .split 29 q11Shape24T659 q11Shape24T670
private theorem q11Shape24T658OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 10144251904 q11Shape24T658=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (10144251904 ||| 2^29) q11Shape24T659 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^29) 10144251904 q11Shape24T670)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T659OK,q11Shape24T670OK⟩

private def q11Shape24T671 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape24T671OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2415951872 9875816448 q11Shape24T671=true := by decide

private def q11Shape24T657 : Tree 11 := .split 28 q11Shape24T658 q11Shape24T671
private theorem q11Shape24T657OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 9875816448 q11Shape24T657=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (9875816448 ||| 2^28) q11Shape24T658 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^28) 9875816448 q11Shape24T671)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T658OK,q11Shape24T671OK⟩

private def q11Shape24T672 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T672OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2281734144 9741598720 q11Shape24T672=true := by decide

private def q11Shape24T656 : Tree 11 := .split 27 q11Shape24T657 q11Shape24T672
private theorem q11Shape24T656OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 9741598720 q11Shape24T656=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (9741598720 ||| 2^27) q11Shape24T657 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^27) 9741598720 q11Shape24T672)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T657OK,q11Shape24T672OK⟩

private def q11Shape24T673 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T673OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2214625280 9674489856 q11Shape24T673=true := by decide

private def q11Shape24T655 : Tree 11 := .split 26 q11Shape24T656 q11Shape24T673
private theorem q11Shape24T655OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 9674489856 q11Shape24T655=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (9674489856 ||| 2^26) q11Shape24T656 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^26) 9674489856 q11Shape24T673)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T656OK,q11Shape24T673OK⟩

private def q11Shape24T674 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape24T674OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2155905024 9666101248 q11Shape24T674=true := by decide

private def q11Shape24T654 : Tree 11 := .split 23 q11Shape24T655 q11Shape24T674
private theorem q11Shape24T654OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 9666101248 q11Shape24T654=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (9666101248 ||| 2^23) q11Shape24T655 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^23) 9666101248 q11Shape24T674)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T655OK,q11Shape24T674OK⟩

private def q11Shape24T675 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T675OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147778560 9665839104 q11Shape24T675=true := by decide

private def q11Shape24T653 : Tree 11 := .split 18 q11Shape24T654 q11Shape24T675
private theorem q11Shape24T653OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 9665839104 q11Shape24T653=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (9665839104 ||| 2^18) q11Shape24T654 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^18) 9665839104 q11Shape24T675)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T654OK,q11Shape24T675OK⟩

private def q11Shape24T676 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T676OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 10737451008 1075904512 q11Shape24T676=true := by decide

private def q11Shape24T652 : Tree 11 := .split 33 q11Shape24T653 q11Shape24T676
private theorem q11Shape24T652OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 1075904512 q11Shape24T652=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 (1075904512 ||| 2^33) q11Shape24T653 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147516416 ||| 2^33) 1075904512 q11Shape24T676)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T653OK,q11Shape24T676OK⟩

def q11Shape24P17 : Tree 11 := q11Shape24T652
theorem q11Shape24P17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147516416 1075904512 q11Shape24P17=true := q11Shape24T652OK

private def q11Shape24T691 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.split 34 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,6,9,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,7,9,10}))))
private theorem q11Shape24T691OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 46136229888 q11Shape24T691=true := by decide

private def q11Shape24T692 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape24T692OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1082163200 46127841280 q11Shape24T692=true := by decide

private def q11Shape24T690 : Tree 11 := .split 23 q11Shape24T691 q11Shape24T692
private theorem q11Shape24T690OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 46127841280 q11Shape24T690=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (46127841280 ||| 2^23) q11Shape24T691 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^23) 46127841280 q11Shape24T692)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T691OK,q11Shape24T692OK⟩

private def q11Shape24T693 : Tree 11 := (.split 23 (.split 20 (.split 34 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T693OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1077968896 46123646976 q11Shape24T693=true := by decide

private def q11Shape24T689 : Tree 11 := .split 22 q11Shape24T690 q11Shape24T693
private theorem q11Shape24T689OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 46123646976 q11Shape24T689=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (46123646976 ||| 2^22) q11Shape24T690 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^22) 46123646976 q11Shape24T693)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T690OK,q11Shape24T693OK⟩

private def q11Shape24T694 : Tree 11 := (.split 23 (.split 25 (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape24T694OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074036736 46123384832 q11Shape24T694=true := by decide

private def q11Shape24T688 : Tree 11 := .split 18 q11Shape24T689 q11Shape24T694
private theorem q11Shape24T688OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 46123384832 q11Shape24T688=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (46123384832 ||| 2^18) q11Shape24T689 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^18) 46123384832 q11Shape24T694)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T689OK,q11Shape24T694OK⟩

private def q11Shape24T695 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T695OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 35433512960 11763646464 q11Shape24T695=true := by decide

private def q11Shape24T687 : Tree 11 := .split 35 q11Shape24T688 q11Shape24T695
private theorem q11Shape24T687OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 11763646464 q11Shape24T687=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (11763646464 ||| 2^35) q11Shape24T688 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^35) 11763646464 q11Shape24T695)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T688OK,q11Shape24T695OK⟩

private def q11Shape24T697 : Tree 11 := (.split 22 (.split 25 (.split 32 (.tip (.cover {0,2,3,4,8,9})) (.split 23 (.split 20 (.split 34 (.split 35 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape24T697OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073905664 11763777536 q11Shape24T697=true := by decide

private def q11Shape24T698 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T698OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074167808 11763515392 q11Shape24T698=true := by decide

private def q11Shape24T696 : Tree 11 := .split 18 q11Shape24T697 q11Shape24T698
private theorem q11Shape24T696OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073905664 11763515392 q11Shape24T696=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073905664 (11763515392 ||| 2^18) q11Shape24T697 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073905664 ||| 2^18) 11763515392 q11Shape24T698)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T697OK,q11Shape24T698OK⟩

private def q11Shape24T686 : Tree 11 := .split 17 q11Shape24T687 q11Shape24T696
private theorem q11Shape24T686OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 11763515392 q11Shape24T686=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (11763515392 ||| 2^17) q11Shape24T687 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^17) 11763515392 q11Shape24T696)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T687OK,q11Shape24T696OK⟩

private def q11Shape24T699 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T699OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1610645504 11226644480 q11Shape24T699=true := by decide

private def q11Shape24T685 : Tree 11 := .split 29 q11Shape24T686 q11Shape24T699
private theorem q11Shape24T685OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 11226644480 q11Shape24T685=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (11226644480 ||| 2^29) q11Shape24T686 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^29) 11226644480 q11Shape24T699)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T686OK,q11Shape24T699OK⟩

private def q11Shape24T700 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T700OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1342210048 10958209024 q11Shape24T700=true := by decide

private def q11Shape24T684 : Tree 11 := .split 28 q11Shape24T685 q11Shape24T700
private theorem q11Shape24T684OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 10958209024 q11Shape24T684=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (10958209024 ||| 2^28) q11Shape24T685 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^28) 10958209024 q11Shape24T700)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T685OK,q11Shape24T700OK⟩

private def q11Shape24T701 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape24T701OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1207992320 10823991296 q11Shape24T701=true := by decide

private def q11Shape24T683 : Tree 11 := .split 27 q11Shape24T684 q11Shape24T701
private theorem q11Shape24T683OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 10823991296 q11Shape24T683=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (10823991296 ||| 2^27) q11Shape24T684 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^27) 10823991296 q11Shape24T701)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T684OK,q11Shape24T701OK⟩

private def q11Shape24T702 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T702OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1140883456 10756882432 q11Shape24T702=true := by decide

private def q11Shape24T682 : Tree 11 := .split 26 q11Shape24T683 q11Shape24T702
private theorem q11Shape24T682OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 10756882432 q11Shape24T682=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (10756882432 ||| 2^26) q11Shape24T683 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^26) 10756882432 q11Shape24T702)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T683OK,q11Shape24T702OK⟩

private def q11Shape24T703 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape24T703OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1090551808 10740105216 q11Shape24T703=true := by decide

private def q11Shape24T681 : Tree 11 := .split 24 q11Shape24T682 q11Shape24T703
private theorem q11Shape24T681OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 10740105216 q11Shape24T681=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (10740105216 ||| 2^24) q11Shape24T682 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^24) 10740105216 q11Shape24T703)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T682OK,q11Shape24T703OK⟩

private def q11Shape24T704 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T704OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074298880 10739580928 q11Shape24T704=true := by decide

private def q11Shape24T680 : Tree 11 := .split 19 q11Shape24T681 q11Shape24T704
private theorem q11Shape24T680OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 10739580928 q11Shape24T680=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (10739580928 ||| 2^19) q11Shape24T681 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^19) 10739580928 q11Shape24T704)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T681OK,q11Shape24T704OK⟩

private def q11Shape24T705 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T705OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 9663709184 2149646336 q11Shape24T705=true := by decide

private def q11Shape24T679 : Tree 11 := .split 33 q11Shape24T680 q11Shape24T705
private theorem q11Shape24T679OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 2149646336 q11Shape24T679=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (2149646336 ||| 2^33) q11Shape24T680 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^33) 2149646336 q11Shape24T705)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T680OK,q11Shape24T705OK⟩

private def q11Shape24T706 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T706OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 3221258240 2162688 q11Shape24T706=true := by decide

private def q11Shape24T678 : Tree 11 := .split 31 q11Shape24T679 q11Shape24T706
private theorem q11Shape24T678OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 2162688 q11Shape24T678=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 (2162688 ||| 2^31) q11Shape24T679 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073774592 ||| 2^31) 2162688 q11Shape24T706)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T679OK,q11Shape24T706OK⟩

def q11Shape24P18 : Tree 11 := q11Shape24T678
theorem q11Shape24P18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073774592 2162688 q11Shape24P18=true := q11Shape24T678OK

end Graffiti384b.EffectiveSearch.Q11
