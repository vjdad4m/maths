import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T708 : Tree 11 := (.split 30 (.split 31 (.split 33 (.split 22 (.split 23 (.split 24 (.tip (.cover {1,2,3,4,6,10})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape24T708OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2129920 65536 q11Shape24T708=true := by decide

def q11Shape24P19 : Tree 11 := q11Shape24T708
theorem q11Shape24P19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2129920 65536 q11Shape24P19=true := q11Shape24T708OK

private def q11Shape24T710 : Tree 11 := (.split 30 (.split 31 (.split 33 (.split 17 (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape24T710OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 98304 0 q11Shape24T710=true := by decide

def q11Shape24P20 : Tree 11 := q11Shape24T710
theorem q11Shape24P20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 98304 0 q11Shape24P20=true := q11Shape24T710OK

end Graffiti384b.EffectiveSearch.Q11
