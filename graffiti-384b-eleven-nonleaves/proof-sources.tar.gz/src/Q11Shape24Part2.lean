import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T76 : Tree 11 := (.tip (.cover {0,1,2,3,9,10}))
private theorem q11Shape24T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 12044435456 q11Shape24T76=true := by decide

private def q11Shape24T80 : Tree 11 := (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,7,10})))) (.split 20 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape24T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134742016 16507174912 q11Shape24T80=true := by decide

private def q11Shape24T81 : Tree 11 := (.split 20 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 403177472 16238739456 q11Shape24T81=true := by decide

private def q11Shape24T79 : Tree 11 := .split 28 q11Shape24T80 q11Shape24T81
private theorem q11Shape24T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134742016 16238739456 q11Shape24T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134742016 (16238739456 ||| 2^28) q11Shape24T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (134742016 ||| 2^28) 16238739456 q11Shape24T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T80OK,q11Shape24T81OK⟩

private def q11Shape24T82 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4429709312 11943772160 q11Shape24T82=true := by decide

private def q11Shape24T78 : Tree 11 := .split 32 q11Shape24T79 q11Shape24T82
private theorem q11Shape24T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134742016 11943772160 q11Shape24T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134742016 (11943772160 ||| 2^32) q11Shape24T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (134742016 ||| 2^32) 11943772160 q11Shape24T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T79OK,q11Shape24T82OK⟩

private def q11Shape24T83 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 168296448 11910217728 q11Shape24T83=true := by decide

private def q11Shape24T77 : Tree 11 := .split 25 q11Shape24T78 q11Shape24T83
private theorem q11Shape24T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134742016 11910217728 q11Shape24T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134742016 (11910217728 ||| 2^25) q11Shape24T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (134742016 ||| 2^25) 11910217728 q11Shape24T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T78OK,q11Shape24T83OK⟩

private def q11Shape24T75 : Tree 11 := .split 27 q11Shape24T76 q11Shape24T77
private theorem q11Shape24T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 11910217728 q11Shape24T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 (11910217728 ||| 2^27) q11Shape24T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (524288 ||| 2^27) 11910217728 q11Shape24T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T76OK,q11Shape24T77OK⟩

private def q11Shape24T88 : Tree 11 := (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,8,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape24T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 29459185664 q11Shape24T88=true := by decide

private def q11Shape24T89 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 336068608 29190750208 q11Shape24T89=true := by decide

private def q11Shape24T87 : Tree 11 := .split 28 q11Shape24T88 q11Shape24T89
private theorem q11Shape24T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 29190750208 q11Shape24T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 (29190750208 ||| 2^28) q11Shape24T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67633152 ||| 2^28) 29190750208 q11Shape24T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T88OK,q11Shape24T89OK⟩

private def q11Shape24T90 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17247502336 12010881024 q11Shape24T90=true := by decide

private def q11Shape24T86 : Tree 11 := .split 34 q11Shape24T87 q11Shape24T90
private theorem q11Shape24T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 12010881024 q11Shape24T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 (12010881024 ||| 2^34) q11Shape24T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67633152 ||| 2^34) 12010881024 q11Shape24T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T87OK,q11Shape24T90OK⟩

private def q11Shape24T91 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 101187584 11977326592 q11Shape24T91=true := by decide

private def q11Shape24T85 : Tree 11 := .split 25 q11Shape24T86 q11Shape24T91
private theorem q11Shape24T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 11977326592 q11Shape24T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 (11977326592 ||| 2^25) q11Shape24T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67633152 ||| 2^25) 11977326592 q11Shape24T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T86OK,q11Shape24T91OK⟩

private def q11Shape24T92 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 201850880 11843108864 q11Shape24T92=true := by decide

private def q11Shape24T84 : Tree 11 := .split 27 q11Shape24T85 q11Shape24T92
private theorem q11Shape24T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 11843108864 q11Shape24T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67633152 (11843108864 ||| 2^27) q11Shape24T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67633152 ||| 2^27) 11843108864 q11Shape24T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T85OK,q11Shape24T92OK⟩

private def q11Shape24T74 : Tree 11 := .split 26 q11Shape24T75 q11Shape24T84
private theorem q11Shape24T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 11843108864 q11Shape24T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 (11843108864 ||| 2^26) q11Shape24T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (524288 ||| 2^26) 11843108864 q11Shape24T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T75OK,q11Shape24T84OK⟩

private def q11Shape24T93 : Tree 11 := (.split 26 (.split 27 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape24T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17301504 11826331648 q11Shape24T93=true := by decide

private def q11Shape24T73 : Tree 11 := .split 24 q11Shape24T74 q11Shape24T93
private theorem q11Shape24T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 11826331648 q11Shape24T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 (11826331648 ||| 2^24) q11Shape24T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (524288 ||| 2^24) 11826331648 q11Shape24T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T74OK,q11Shape24T93OK⟩

private def q11Shape24T100 : Tree 11 := (.split 25 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,7,10})))) (.split 20 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape24T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 17136320512 q11Shape24T100=true := by decide

private def q11Shape24T101 : Tree 11 := (.split 20 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25690112 17119543296 q11Shape24T101=true := by decide

private def q11Shape24T99 : Tree 11 := .split 24 q11Shape24T100 q11Shape24T101
private theorem q11Shape24T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 17119543296 q11Shape24T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 (17119543296 ||| 2^24) q11Shape24T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8912896 ||| 2^24) 17119543296 q11Shape24T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T100OK,q11Shape24T101OK⟩

private def q11Shape24T102 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4303880192 12824576000 q11Shape24T102=true := by decide

private def q11Shape24T98 : Tree 11 := .split 32 q11Shape24T99 q11Shape24T102
private theorem q11Shape24T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 12824576000 q11Shape24T98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 (12824576000 ||| 2^32) q11Shape24T99 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8912896 ||| 2^32) 12824576000 q11Shape24T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T99OK,q11Shape24T102OK⟩

private def q11Shape24T103 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 545783808 12287705088 q11Shape24T103=true := by decide

private def q11Shape24T97 : Tree 11 := .split 29 q11Shape24T98 q11Shape24T103
private theorem q11Shape24T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 12287705088 q11Shape24T97=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 (12287705088 ||| 2^29) q11Shape24T98 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8912896 ||| 2^29) 12287705088 q11Shape24T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T98OK,q11Shape24T103OK⟩

private def q11Shape24T104 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape24T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 277348352 12019269632 q11Shape24T104=true := by decide

private def q11Shape24T96 : Tree 11 := .split 28 q11Shape24T97 q11Shape24T104
private theorem q11Shape24T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 12019269632 q11Shape24T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 (12019269632 ||| 2^28) q11Shape24T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8912896 ||| 2^28) 12019269632 q11Shape24T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T97OK,q11Shape24T104OK⟩

private def q11Shape24T105 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 143130624 11885051904 q11Shape24T105=true := by decide

private def q11Shape24T95 : Tree 11 := .split 27 q11Shape24T96 q11Shape24T105
private theorem q11Shape24T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 11885051904 q11Shape24T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 (11885051904 ||| 2^27) q11Shape24T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8912896 ||| 2^27) 11885051904 q11Shape24T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T96OK,q11Shape24T105OK⟩

private def q11Shape24T106 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 76021760 11817943040 q11Shape24T106=true := by decide

private def q11Shape24T94 : Tree 11 := .split 26 q11Shape24T95 q11Shape24T106
private theorem q11Shape24T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 11817943040 q11Shape24T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8912896 (11817943040 ||| 2^26) q11Shape24T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8912896 ||| 2^26) 11817943040 q11Shape24T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T95OK,q11Shape24T106OK⟩

private def q11Shape24T72 : Tree 11 := .split 23 q11Shape24T73 q11Shape24T94
private theorem q11Shape24T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 11817943040 q11Shape24T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 (11817943040 ||| 2^23) q11Shape24T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (524288 ||| 2^23) 11817943040 q11Shape24T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T73OK,q11Shape24T94OK⟩

private def q11Shape24T114 : Tree 11 := (.split 25 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,8,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape24T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 30025416704 q11Shape24T114=true := by decide

private def q11Shape24T115 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 21495808 30008639488 q11Shape24T115=true := by decide

private def q11Shape24T113 : Tree 11 := .split 24 q11Shape24T114 q11Shape24T115
private theorem q11Shape24T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 30008639488 q11Shape24T113=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 (30008639488 ||| 2^24) q11Shape24T114 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4718592 ||| 2^24) 30008639488 q11Shape24T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T114OK,q11Shape24T115OK⟩

private def q11Shape24T116 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17184587776 12828770304 q11Shape24T116=true := by decide

private def q11Shape24T112 : Tree 11 := .split 34 q11Shape24T113 q11Shape24T116
private theorem q11Shape24T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 12828770304 q11Shape24T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 (12828770304 ||| 2^34) q11Shape24T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4718592 ||| 2^34) 12828770304 q11Shape24T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T113OK,q11Shape24T116OK⟩

private def q11Shape24T117 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 541589504 12291899392 q11Shape24T117=true := by decide

private def q11Shape24T111 : Tree 11 := .split 29 q11Shape24T112 q11Shape24T117
private theorem q11Shape24T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 12291899392 q11Shape24T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 (12291899392 ||| 2^29) q11Shape24T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4718592 ||| 2^29) 12291899392 q11Shape24T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T112OK,q11Shape24T117OK⟩

private def q11Shape24T118 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape24T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 273154048 12023463936 q11Shape24T118=true := by decide

private def q11Shape24T110 : Tree 11 := .split 28 q11Shape24T111 q11Shape24T118
private theorem q11Shape24T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 12023463936 q11Shape24T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 (12023463936 ||| 2^28) q11Shape24T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4718592 ||| 2^28) 12023463936 q11Shape24T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T111OK,q11Shape24T118OK⟩

private def q11Shape24T119 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 138936320 11889246208 q11Shape24T119=true := by decide

private def q11Shape24T109 : Tree 11 := .split 27 q11Shape24T110 q11Shape24T119
private theorem q11Shape24T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 11889246208 q11Shape24T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 (11889246208 ||| 2^27) q11Shape24T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4718592 ||| 2^27) 11889246208 q11Shape24T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T110OK,q11Shape24T119OK⟩

private def q11Shape24T120 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 71827456 11822137344 q11Shape24T120=true := by decide

private def q11Shape24T108 : Tree 11 := .split 26 q11Shape24T109 q11Shape24T120
private theorem q11Shape24T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 11822137344 q11Shape24T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 (11822137344 ||| 2^26) q11Shape24T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4718592 ||| 2^26) 11822137344 q11Shape24T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T109OK,q11Shape24T120OK⟩

private def q11Shape24T121 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 13107200 11813748736 q11Shape24T121=true := by decide

private def q11Shape24T107 : Tree 11 := .split 23 q11Shape24T108 q11Shape24T121
private theorem q11Shape24T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 11813748736 q11Shape24T107=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4718592 (11813748736 ||| 2^23) q11Shape24T108 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4718592 ||| 2^23) 11813748736 q11Shape24T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T108OK,q11Shape24T121OK⟩

private def q11Shape24T71 : Tree 11 := .split 22 q11Shape24T72 q11Shape24T107
private theorem q11Shape24T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 11813748736 q11Shape24T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 (11813748736 ||| 2^22) q11Shape24T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (524288 ||| 2^22) 11813748736 q11Shape24T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T72OK,q11Shape24T107OK⟩

def q11Shape24P2 : Tree 11 := q11Shape24T71
theorem q11Shape24P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 524288 11813748736 q11Shape24P2=true := q11Shape24T71OK

end Graffiti384b.EffectiveSearch.Q11
