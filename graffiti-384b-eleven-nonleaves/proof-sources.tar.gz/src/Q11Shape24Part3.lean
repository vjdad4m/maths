import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T129 : Tree 11 := (.tip (.cover {0,1,2,3,8,10}))
private theorem q11Shape24T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 12178915328 q11Shape24T129=true := by decide

private def q11Shape24T133 : Tree 11 := (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,7,10})))) (.split 20 (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape24T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268697600 16373219328 q11Shape24T133=true := by decide

private def q11Shape24T134 : Tree 11 := (.split 20 (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 402915328 16239001600 q11Shape24T134=true := by decide

private def q11Shape24T132 : Tree 11 := .split 27 q11Shape24T133 q11Shape24T134
private theorem q11Shape24T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268697600 16239001600 q11Shape24T132=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268697600 (16239001600 ||| 2^27) q11Shape24T133 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (268697600 ||| 2^27) 16239001600 q11Shape24T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T133OK,q11Shape24T134OK⟩

private def q11Shape24T135 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4563664896 11944034304 q11Shape24T135=true := by decide

private def q11Shape24T131 : Tree 11 := .split 32 q11Shape24T132 q11Shape24T135
private theorem q11Shape24T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268697600 11944034304 q11Shape24T131=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268697600 (11944034304 ||| 2^32) q11Shape24T132 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (268697600 ||| 2^32) 11944034304 q11Shape24T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T132OK,q11Shape24T135OK⟩

private def q11Shape24T136 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 302252032 11910479872 q11Shape24T136=true := by decide

private def q11Shape24T130 : Tree 11 := .split 25 q11Shape24T131 q11Shape24T136
private theorem q11Shape24T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268697600 11910479872 q11Shape24T130=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268697600 (11910479872 ||| 2^25) q11Shape24T131 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (268697600 ||| 2^25) 11910479872 q11Shape24T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T131OK,q11Shape24T136OK⟩

private def q11Shape24T128 : Tree 11 := .split 28 q11Shape24T129 q11Shape24T130
private theorem q11Shape24T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 11910479872 q11Shape24T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 (11910479872 ||| 2^28) q11Shape24T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (262144 ||| 2^28) 11910479872 q11Shape24T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T129OK,q11Shape24T130OK⟩

private def q11Shape24T141 : Tree 11 := (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,9,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,6,9}))))
private theorem q11Shape24T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 46639316992 q11Shape24T141=true := by decide

private def q11Shape24T142 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 201588736 46505099264 q11Shape24T142=true := by decide

private def q11Shape24T140 : Tree 11 := .split 27 q11Shape24T141 q11Shape24T142
private theorem q11Shape24T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 46505099264 q11Shape24T140=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 (46505099264 ||| 2^27) q11Shape24T141 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67371008 ||| 2^27) 46505099264 q11Shape24T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T141OK,q11Shape24T142OK⟩

private def q11Shape24T143 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 34427109376 12145360896 q11Shape24T143=true := by decide

private def q11Shape24T139 : Tree 11 := .split 35 q11Shape24T140 q11Shape24T143
private theorem q11Shape24T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 12145360896 q11Shape24T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 (12145360896 ||| 2^35) q11Shape24T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67371008 ||| 2^35) 12145360896 q11Shape24T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T140OK,q11Shape24T143OK⟩

private def q11Shape24T144 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 100925440 12111806464 q11Shape24T144=true := by decide

private def q11Shape24T138 : Tree 11 := .split 25 q11Shape24T139 q11Shape24T144
private theorem q11Shape24T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 12111806464 q11Shape24T138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 (12111806464 ||| 2^25) q11Shape24T139 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67371008 ||| 2^25) 12111806464 q11Shape24T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T139OK,q11Shape24T144OK⟩

private def q11Shape24T145 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 335806464 11843371008 q11Shape24T145=true := by decide

private def q11Shape24T137 : Tree 11 := .split 28 q11Shape24T138 q11Shape24T145
private theorem q11Shape24T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 11843371008 q11Shape24T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67371008 (11843371008 ||| 2^28) q11Shape24T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (67371008 ||| 2^28) 11843371008 q11Shape24T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T138OK,q11Shape24T145OK⟩

private def q11Shape24T127 : Tree 11 := .split 26 q11Shape24T128 q11Shape24T137
private theorem q11Shape24T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 11843371008 q11Shape24T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 (11843371008 ||| 2^26) q11Shape24T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (262144 ||| 2^26) 11843371008 q11Shape24T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T128OK,q11Shape24T137OK⟩

private def q11Shape24T149 : Tree 11 := (.split 29 (.split 32 (.split 25 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,7,10})))) (.split 20 (.split 35 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape24T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17039360 12296355840 q11Shape24T149=true := by decide

private def q11Shape24T150 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 285474816 12027920384 q11Shape24T150=true := by decide

private def q11Shape24T148 : Tree 11 := .split 28 q11Shape24T149 q11Shape24T150
private theorem q11Shape24T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17039360 12027920384 q11Shape24T148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17039360 (12027920384 ||| 2^28) q11Shape24T149 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (17039360 ||| 2^28) 12027920384 q11Shape24T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T149OK,q11Shape24T150OK⟩

private def q11Shape24T151 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape24T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 151257088 11893702656 q11Shape24T151=true := by decide

private def q11Shape24T147 : Tree 11 := .split 27 q11Shape24T148 q11Shape24T151
private theorem q11Shape24T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17039360 11893702656 q11Shape24T147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17039360 (11893702656 ||| 2^27) q11Shape24T148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (17039360 ||| 2^27) 11893702656 q11Shape24T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T148OK,q11Shape24T151OK⟩

private def q11Shape24T152 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 84148224 11826593792 q11Shape24T152=true := by decide

private def q11Shape24T146 : Tree 11 := .split 26 q11Shape24T147 q11Shape24T152
private theorem q11Shape24T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17039360 11826593792 q11Shape24T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17039360 (11826593792 ||| 2^26) q11Shape24T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (17039360 ||| 2^26) 11826593792 q11Shape24T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T147OK,q11Shape24T152OK⟩

private def q11Shape24T126 : Tree 11 := .split 24 q11Shape24T127 q11Shape24T146
private theorem q11Shape24T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 11826593792 q11Shape24T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 (11826593792 ||| 2^24) q11Shape24T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (262144 ||| 2^24) 11826593792 q11Shape24T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T127OK,q11Shape24T146OK⟩

private def q11Shape24T155 : Tree 11 := (.split 28 (.split 24 (.tip (.cover {0,1,2,3,8,10})) (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 35 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,7,10})))) (.tip (.cover {0,1,6,7,8,10})))
private theorem q11Shape24T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8650752 12019531776 q11Shape24T155=true := by decide

private def q11Shape24T156 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape24T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 142868480 11885314048 q11Shape24T156=true := by decide

private def q11Shape24T154 : Tree 11 := .split 27 q11Shape24T155 q11Shape24T156
private theorem q11Shape24T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8650752 11885314048 q11Shape24T154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8650752 (11885314048 ||| 2^27) q11Shape24T155 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8650752 ||| 2^27) 11885314048 q11Shape24T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T155OK,q11Shape24T156OK⟩

private def q11Shape24T157 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape24T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75759616 11818205184 q11Shape24T157=true := by decide

private def q11Shape24T153 : Tree 11 := .split 26 q11Shape24T154 q11Shape24T157
private theorem q11Shape24T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8650752 11818205184 q11Shape24T153=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8650752 (11818205184 ||| 2^26) q11Shape24T154 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8650752 ||| 2^26) 11818205184 q11Shape24T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T154OK,q11Shape24T157OK⟩

private def q11Shape24T125 : Tree 11 := .split 23 q11Shape24T126 q11Shape24T153
private theorem q11Shape24T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 11818205184 q11Shape24T125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 (11818205184 ||| 2^23) q11Shape24T126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (262144 ||| 2^23) 11818205184 q11Shape24T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T126OK,q11Shape24T153OK⟩

private def q11Shape24T165 : Tree 11 := (.split 25 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,9,10})))) (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,5,6,9}))))
private theorem q11Shape24T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 47205548032 q11Shape24T165=true := by decide

private def q11Shape24T166 : Tree 11 := (.split 20 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12845056 47197159424 q11Shape24T166=true := by decide

private def q11Shape24T164 : Tree 11 := .split 23 q11Shape24T165 q11Shape24T166
private theorem q11Shape24T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 47197159424 q11Shape24T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 (47197159424 ||| 2^23) q11Shape24T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4456448 ||| 2^23) 47197159424 q11Shape24T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T165OK,q11Shape24T166OK⟩

private def q11Shape24T167 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 34364194816 12837421056 q11Shape24T167=true := by decide

private def q11Shape24T163 : Tree 11 := .split 35 q11Shape24T164 q11Shape24T167
private theorem q11Shape24T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 12837421056 q11Shape24T163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 (12837421056 ||| 2^35) q11Shape24T164 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4456448 ||| 2^35) 12837421056 q11Shape24T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T164OK,q11Shape24T167OK⟩

private def q11Shape24T168 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 541327360 12300550144 q11Shape24T168=true := by decide

private def q11Shape24T162 : Tree 11 := .split 29 q11Shape24T163 q11Shape24T168
private theorem q11Shape24T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 12300550144 q11Shape24T162=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 (12300550144 ||| 2^29) q11Shape24T163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4456448 ||| 2^29) 12300550144 q11Shape24T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T163OK,q11Shape24T168OK⟩

private def q11Shape24T169 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 272891904 12032114688 q11Shape24T169=true := by decide

private def q11Shape24T161 : Tree 11 := .split 28 q11Shape24T162 q11Shape24T169
private theorem q11Shape24T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 12032114688 q11Shape24T161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 (12032114688 ||| 2^28) q11Shape24T162 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4456448 ||| 2^28) 12032114688 q11Shape24T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T162OK,q11Shape24T169OK⟩

private def q11Shape24T170 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape24T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 138674176 11897896960 q11Shape24T170=true := by decide

private def q11Shape24T160 : Tree 11 := .split 27 q11Shape24T161 q11Shape24T170
private theorem q11Shape24T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 11897896960 q11Shape24T160=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 (11897896960 ||| 2^27) q11Shape24T161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4456448 ||| 2^27) 11897896960 q11Shape24T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T161OK,q11Shape24T170OK⟩

private def q11Shape24T171 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape24T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 71565312 11830788096 q11Shape24T171=true := by decide

private def q11Shape24T159 : Tree 11 := .split 26 q11Shape24T160 q11Shape24T171
private theorem q11Shape24T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 11830788096 q11Shape24T159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 (11830788096 ||| 2^26) q11Shape24T160 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4456448 ||| 2^26) 11830788096 q11Shape24T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T160OK,q11Shape24T171OK⟩

private def q11Shape24T172 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 21233664 11814010880 q11Shape24T172=true := by decide

private def q11Shape24T158 : Tree 11 := .split 24 q11Shape24T159 q11Shape24T172
private theorem q11Shape24T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 11814010880 q11Shape24T158=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4456448 (11814010880 ||| 2^24) q11Shape24T159 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4456448 ||| 2^24) 11814010880 q11Shape24T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T159OK,q11Shape24T172OK⟩

private def q11Shape24T124 : Tree 11 := .split 22 q11Shape24T125 q11Shape24T158
private theorem q11Shape24T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 11814010880 q11Shape24T124=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 (11814010880 ||| 2^22) q11Shape24T125 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (262144 ||| 2^22) 11814010880 q11Shape24T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T125OK,q11Shape24T158OK⟩

private def q11Shape24T178 : Tree 11 := (.tip (.cover {0,2,3,7,8,9}))
private theorem q11Shape24T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 12456263680 q11Shape24T178=true := by decide

private def q11Shape24T181 : Tree 11 := (.split 24 (.split 3 (.split 27 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,2,3,9,10}))) (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,7,10})))) (.tip (.cover {0,1,2,3,4,10}))) (.split 27 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,10}))))
private theorem q11Shape24T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1835008 16758571008 q11Shape24T181=true := by decide

private def q11Shape24T182 : Tree 11 := (.split 24 (.split 27 (.split 28 (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 10223616 16750182400 q11Shape24T182=true := by decide

private def q11Shape24T180 : Tree 11 := .split 23 q11Shape24T181 q11Shape24T182
private theorem q11Shape24T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1835008 16750182400 q11Shape24T180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1835008 (16750182400 ||| 2^23) q11Shape24T181 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1835008 ||| 2^23) 16750182400 q11Shape24T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T181OK,q11Shape24T182OK⟩

private def q11Shape24T183 : Tree 11 := (.tip (.cover {0,1,4,5,6,7}))
private theorem q11Shape24T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4296802304 12455215104 q11Shape24T183=true := by decide

private def q11Shape24T179 : Tree 11 := .split 32 q11Shape24T180 q11Shape24T183
private theorem q11Shape24T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1835008 12455215104 q11Shape24T179=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1835008 (12455215104 ||| 2^32) q11Shape24T180 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1835008 ||| 2^32) 12455215104 q11Shape24T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T180OK,q11Shape24T183OK⟩

private def q11Shape24T177 : Tree 11 := .split 20 q11Shape24T178 q11Shape24T179
private theorem q11Shape24T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 12455215104 q11Shape24T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 (12455215104 ||| 2^20) q11Shape24T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (786432 ||| 2^20) 12455215104 q11Shape24T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T178OK,q11Shape24T179OK⟩

private def q11Shape24T184 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 537657344 11918344192 q11Shape24T184=true := by decide

private def q11Shape24T176 : Tree 11 := .split 29 q11Shape24T177 q11Shape24T184
private theorem q11Shape24T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 11918344192 q11Shape24T176=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 (11918344192 ||| 2^29) q11Shape24T177 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (786432 ||| 2^29) 11918344192 q11Shape24T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T177OK,q11Shape24T184OK⟩

private def q11Shape24T185 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 34340864 11884789760 q11Shape24T185=true := by decide

private def q11Shape24T175 : Tree 11 := .split 25 q11Shape24T176 q11Shape24T185
private theorem q11Shape24T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 11884789760 q11Shape24T175=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 (11884789760 ||| 2^25) q11Shape24T176 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (786432 ||| 2^25) 11884789760 q11Shape24T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T176OK,q11Shape24T185OK⟩

private def q11Shape24T186 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67895296 11817680896 q11Shape24T186=true := by decide

private def q11Shape24T174 : Tree 11 := .split 26 q11Shape24T175 q11Shape24T186
private theorem q11Shape24T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 11817680896 q11Shape24T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 (11817680896 ||| 2^26) q11Shape24T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (786432 ||| 2^26) 11817680896 q11Shape24T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T175OK,q11Shape24T186OK⟩

private def q11Shape24T187 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4980736 11813486592 q11Shape24T187=true := by decide

private def q11Shape24T173 : Tree 11 := .split 22 q11Shape24T174 q11Shape24T187
private theorem q11Shape24T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 11813486592 q11Shape24T173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 786432 (11813486592 ||| 2^22) q11Shape24T174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (786432 ||| 2^22) 11813486592 q11Shape24T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T174OK,q11Shape24T187OK⟩

private def q11Shape24T123 : Tree 11 := .split 19 q11Shape24T124 q11Shape24T173
private theorem q11Shape24T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 11813486592 q11Shape24T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 (11813486592 ||| 2^19) q11Shape24T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (262144 ||| 2^19) 11813486592 q11Shape24T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T124OK,q11Shape24T173OK⟩

def q11Shape24P3 : Tree 11 := q11Shape24T123
theorem q11Shape24P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 262144 11813486592 q11Shape24P3=true := q11Shape24T123OK

end Graffiti384b.EffectiveSearch.Q11
