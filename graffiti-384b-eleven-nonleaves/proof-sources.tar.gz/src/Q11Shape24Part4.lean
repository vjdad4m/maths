import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T197 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape24T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 12313264128 q11Shape24T197=true := by decide

private def q11Shape24T198 : Tree 11 := (.split 25 (.split 34 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,8,10})))) (.split 20 (.split 35 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape24T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268566528 12044828672 q11Shape24T198=true := by decide

private def q11Shape24T196 : Tree 11 := .split 28 q11Shape24T197 q11Shape24T198
private theorem q11Shape24T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 12044828672 q11Shape24T196=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (12044828672 ||| 2^28) q11Shape24T197 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^28) 12044828672 q11Shape24T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T197OK,q11Shape24T198OK⟩

private def q11Shape24T200 : Tree 11 := (.split 25 (.split 35 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,9,10})))) (.split 20 (.split 34 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,6,9})))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134348800 12179046400 q11Shape24T200=true := by decide

private def q11Shape24T201 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 402784256 11910610944 q11Shape24T201=true := by decide

private def q11Shape24T199 : Tree 11 := .split 28 q11Shape24T200 q11Shape24T201
private theorem q11Shape24T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134348800 11910610944 q11Shape24T199=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134348800 (11910610944 ||| 2^28) q11Shape24T200 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (134348800 ||| 2^28) 11910610944 q11Shape24T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T200OK,q11Shape24T201OK⟩

private def q11Shape24T195 : Tree 11 := .split 27 q11Shape24T196 q11Shape24T199
private theorem q11Shape24T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11910610944 q11Shape24T195=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (11910610944 ||| 2^27) q11Shape24T196 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^27) 11910610944 q11Shape24T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T196OK,q11Shape24T199OK⟩

private def q11Shape24T202 : Tree 11 := (.split 25 (.split 20 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.split 35 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10})))) (.tip (.cover {0,1,2,3,6,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape24T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 67239936 11843502080 q11Shape24T202=true := by decide

private def q11Shape24T194 : Tree 11 := .split 26 q11Shape24T195 q11Shape24T202
private theorem q11Shape24T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11843502080 q11Shape24T194=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (11843502080 ||| 2^26) q11Shape24T195 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^26) 11843502080 q11Shape24T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T195OK,q11Shape24T202OK⟩

private def q11Shape24T206 : Tree 11 := (.split 29 (.split 34 (.split 25 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,8,10})))) (.split 20 (.split 35 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16908288 12296486912 q11Shape24T206=true := by decide

private def q11Shape24T207 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape24T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 285343744 12028051456 q11Shape24T207=true := by decide

private def q11Shape24T205 : Tree 11 := .split 28 q11Shape24T206 q11Shape24T207
private theorem q11Shape24T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16908288 12028051456 q11Shape24T205=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16908288 (12028051456 ||| 2^28) q11Shape24T206 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (16908288 ||| 2^28) 12028051456 q11Shape24T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T206OK,q11Shape24T207OK⟩

private def q11Shape24T208 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 151126016 11893833728 q11Shape24T208=true := by decide

private def q11Shape24T204 : Tree 11 := .split 27 q11Shape24T205 q11Shape24T208
private theorem q11Shape24T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16908288 11893833728 q11Shape24T204=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16908288 (11893833728 ||| 2^27) q11Shape24T205 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (16908288 ||| 2^27) 11893833728 q11Shape24T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T205OK,q11Shape24T208OK⟩

private def q11Shape24T209 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape24T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 84017152 11826724864 q11Shape24T209=true := by decide

private def q11Shape24T203 : Tree 11 := .split 26 q11Shape24T204 q11Shape24T209
private theorem q11Shape24T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16908288 11826724864 q11Shape24T203=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 16908288 (11826724864 ||| 2^26) q11Shape24T204 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (16908288 ||| 2^26) 11826724864 q11Shape24T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T204OK,q11Shape24T209OK⟩

private def q11Shape24T193 : Tree 11 := .split 24 q11Shape24T194 q11Shape24T203
private theorem q11Shape24T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11826724864 q11Shape24T193=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (11826724864 ||| 2^24) q11Shape24T194 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^24) 11826724864 q11Shape24T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T194OK,q11Shape24T203OK⟩

private def q11Shape24T214 : Tree 11 := (.split 29 (.split 35 (.split 25 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,9,10})))) (.split 20 (.split 34 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,5,6,9})))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape24T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 12304875520 q11Shape24T214=true := by decide

private def q11Shape24T215 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 276955136 12036440064 q11Shape24T215=true := by decide

private def q11Shape24T213 : Tree 11 := .split 28 q11Shape24T214 q11Shape24T215
private theorem q11Shape24T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 12036440064 q11Shape24T213=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 (12036440064 ||| 2^28) q11Shape24T214 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8519680 ||| 2^28) 12036440064 q11Shape24T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T214OK,q11Shape24T215OK⟩

private def q11Shape24T216 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape24T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 142737408 11902222336 q11Shape24T216=true := by decide

private def q11Shape24T212 : Tree 11 := .split 27 q11Shape24T213 q11Shape24T216
private theorem q11Shape24T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 11902222336 q11Shape24T212=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 (11902222336 ||| 2^27) q11Shape24T213 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8519680 ||| 2^27) 11902222336 q11Shape24T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T213OK,q11Shape24T216OK⟩

private def q11Shape24T217 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape24T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 75628544 11835113472 q11Shape24T217=true := by decide

private def q11Shape24T211 : Tree 11 := .split 26 q11Shape24T212 q11Shape24T217
private theorem q11Shape24T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 11835113472 q11Shape24T211=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 (11835113472 ||| 2^26) q11Shape24T212 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8519680 ||| 2^26) 11835113472 q11Shape24T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T212OK,q11Shape24T217OK⟩

private def q11Shape24T218 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 25296896 11818336256 q11Shape24T218=true := by decide

private def q11Shape24T210 : Tree 11 := .split 24 q11Shape24T211 q11Shape24T218
private theorem q11Shape24T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 11818336256 q11Shape24T210=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8519680 (11818336256 ||| 2^24) q11Shape24T211 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8519680 ||| 2^24) 11818336256 q11Shape24T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T211OK,q11Shape24T218OK⟩

private def q11Shape24T192 : Tree 11 := .split 23 q11Shape24T193 q11Shape24T210
private theorem q11Shape24T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11818336256 q11Shape24T192=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (11818336256 ||| 2^23) q11Shape24T193 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^23) 11818336256 q11Shape24T210)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T193OK,q11Shape24T210OK⟩

private def q11Shape24T220 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.split 35 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))) (.tip (.cover {0,1,2,3,5,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10})))
private theorem q11Shape24T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4325376 11881250816 q11Shape24T220=true := by decide

private def q11Shape24T221 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape24T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 71434240 11814141952 q11Shape24T221=true := by decide

private def q11Shape24T219 : Tree 11 := .split 26 q11Shape24T220 q11Shape24T221
private theorem q11Shape24T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4325376 11814141952 q11Shape24T219=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 4325376 (11814141952 ||| 2^26) q11Shape24T220 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (4325376 ||| 2^26) 11814141952 q11Shape24T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T220OK,q11Shape24T221OK⟩

private def q11Shape24T191 : Tree 11 := .split 22 q11Shape24T192 q11Shape24T219
private theorem q11Shape24T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11814141952 q11Shape24T191=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (11814141952 ||| 2^22) q11Shape24T192 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^22) 11814141952 q11Shape24T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T192OK,q11Shape24T219OK⟩

private def q11Shape24T227 : Tree 11 := (.tip (.cover {0,2,3,7,8,9}))
private theorem q11Shape24T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 12527697920 q11Shape24T227=true := by decide

private def q11Shape24T230 : Tree 11 := (.split 24 (.split 3 (.split 26 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,2,3,9,10}))) (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,8,10})))) (.tip (.cover {0,1,2,3,4,10}))) (.split 26 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,10}))))
private theorem q11Shape24T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1703936 29710712832 q11Shape24T230=true := by decide

private def q11Shape24T231 : Tree 11 := (.split 24 (.split 26 (.split 28 (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 5898240 29706518528 q11Shape24T231=true := by decide

private def q11Shape24T229 : Tree 11 := .split 22 q11Shape24T230 q11Shape24T231
private theorem q11Shape24T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1703936 29706518528 q11Shape24T229=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1703936 (29706518528 ||| 2^22) q11Shape24T230 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1703936 ||| 2^22) 29706518528 q11Shape24T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T230OK,q11Shape24T231OK⟩

private def q11Shape24T232 : Tree 11 := (.tip (.cover {0,1,4,5,6,8}))
private theorem q11Shape24T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17181573120 12526649344 q11Shape24T232=true := by decide

private def q11Shape24T228 : Tree 11 := .split 34 q11Shape24T229 q11Shape24T232
private theorem q11Shape24T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1703936 12526649344 q11Shape24T228=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1703936 (12526649344 ||| 2^34) q11Shape24T229 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1703936 ||| 2^34) 12526649344 q11Shape24T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T229OK,q11Shape24T232OK⟩

private def q11Shape24T226 : Tree 11 := .split 20 q11Shape24T227 q11Shape24T228
private theorem q11Shape24T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 12526649344 q11Shape24T226=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 (12526649344 ||| 2^20) q11Shape24T227 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (655360 ||| 2^20) 12526649344 q11Shape24T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T227OK,q11Shape24T228OK⟩

private def q11Shape24T233 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 537526272 11989778432 q11Shape24T233=true := by decide

private def q11Shape24T225 : Tree 11 := .split 29 q11Shape24T226 q11Shape24T233
private theorem q11Shape24T225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 11989778432 q11Shape24T225=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 (11989778432 ||| 2^29) q11Shape24T226 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (655360 ||| 2^29) 11989778432 q11Shape24T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T226OK,q11Shape24T233OK⟩

private def q11Shape24T234 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 34209792 11956224000 q11Shape24T234=true := by decide

private def q11Shape24T224 : Tree 11 := .split 25 q11Shape24T225 q11Shape24T234
private theorem q11Shape24T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 11956224000 q11Shape24T224=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 (11956224000 ||| 2^25) q11Shape24T225 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (655360 ||| 2^25) 11956224000 q11Shape24T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T225OK,q11Shape24T234OK⟩

private def q11Shape24T235 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 134873088 11822006272 q11Shape24T235=true := by decide

private def q11Shape24T223 : Tree 11 := .split 27 q11Shape24T224 q11Shape24T235
private theorem q11Shape24T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 11822006272 q11Shape24T223=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 (11822006272 ||| 2^27) q11Shape24T224 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (655360 ||| 2^27) 11822006272 q11Shape24T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T224OK,q11Shape24T235OK⟩

private def q11Shape24T236 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 9043968 11813617664 q11Shape24T236=true := by decide

private def q11Shape24T222 : Tree 11 := .split 23 q11Shape24T223 q11Shape24T236
private theorem q11Shape24T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 11813617664 q11Shape24T222=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 655360 (11813617664 ||| 2^23) q11Shape24T223 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (655360 ||| 2^23) 11813617664 q11Shape24T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T223OK,q11Shape24T236OK⟩

private def q11Shape24T190 : Tree 11 := .split 19 q11Shape24T191 q11Shape24T222
private theorem q11Shape24T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11813617664 q11Shape24T190=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (11813617664 ||| 2^19) q11Shape24T191 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^19) 11813617664 q11Shape24T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T191OK,q11Shape24T222OK⟩

private def q11Shape24T243 : Tree 11 := (.tip (.cover {0,2,3,7,8,9}))
private theorem q11Shape24T243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 12670566400 q11Shape24T243=true := by decide

private def q11Shape24T246 : Tree 11 := (.split 23 (.split 3 (.split 26 (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,2,3,8,10}))) (.split 34 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,2,3,4,10}))) (.split 26 (.split 32 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,9,10}))))
private theorem q11Shape24T246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1441792 47033450496 q11Shape24T246=true := by decide

private def q11Shape24T247 : Tree 11 := (.split 23 (.split 26 (.split 27 (.split 34 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T247OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 5636096 47029256192 q11Shape24T247=true := by decide

private def q11Shape24T245 : Tree 11 := .split 22 q11Shape24T246 q11Shape24T247
private theorem q11Shape24T245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1441792 47029256192 q11Shape24T245=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1441792 (47029256192 ||| 2^22) q11Shape24T246 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1441792 ||| 2^22) 47029256192 q11Shape24T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T246OK,q11Shape24T247OK⟩

private def q11Shape24T248 : Tree 11 := (.tip (.cover {0,1,4,5,6,9}))
private theorem q11Shape24T248OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 34361180160 12669517824 q11Shape24T248=true := by decide

private def q11Shape24T244 : Tree 11 := .split 35 q11Shape24T245 q11Shape24T248
private theorem q11Shape24T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1441792 12669517824 q11Shape24T244=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1441792 (12669517824 ||| 2^35) q11Shape24T245 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1441792 ||| 2^35) 12669517824 q11Shape24T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T245OK,q11Shape24T248OK⟩

private def q11Shape24T242 : Tree 11 := .split 20 q11Shape24T243 q11Shape24T244
private theorem q11Shape24T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 12669517824 q11Shape24T242=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 (12669517824 ||| 2^20) q11Shape24T243 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (393216 ||| 2^20) 12669517824 q11Shape24T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T243OK,q11Shape24T244OK⟩

private def q11Shape24T249 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T249OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 537264128 12132646912 q11Shape24T249=true := by decide

private def q11Shape24T241 : Tree 11 := .split 29 q11Shape24T242 q11Shape24T249
private theorem q11Shape24T241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 12132646912 q11Shape24T241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 (12132646912 ||| 2^29) q11Shape24T242 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (393216 ||| 2^29) 12132646912 q11Shape24T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T242OK,q11Shape24T249OK⟩

private def q11Shape24T250 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T250OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 33947648 12099092480 q11Shape24T250=true := by decide

private def q11Shape24T240 : Tree 11 := .split 25 q11Shape24T241 q11Shape24T250
private theorem q11Shape24T240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 12099092480 q11Shape24T240=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 (12099092480 ||| 2^25) q11Shape24T241 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (393216 ||| 2^25) 12099092480 q11Shape24T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T241OK,q11Shape24T250OK⟩

private def q11Shape24T251 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T251OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 268828672 11830657024 q11Shape24T251=true := by decide

private def q11Shape24T239 : Tree 11 := .split 28 q11Shape24T240 q11Shape24T251
private theorem q11Shape24T239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 11830657024 q11Shape24T239=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 (11830657024 ||| 2^28) q11Shape24T240 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (393216 ||| 2^28) 11830657024 q11Shape24T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T240OK,q11Shape24T251OK⟩

private def q11Shape24T252 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T252OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 17170432 11813879808 q11Shape24T252=true := by decide

private def q11Shape24T238 : Tree 11 := .split 24 q11Shape24T239 q11Shape24T252
private theorem q11Shape24T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 11813879808 q11Shape24T238=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 (11813879808 ||| 2^24) q11Shape24T239 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (393216 ||| 2^24) 11813879808 q11Shape24T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T239OK,q11Shape24T252OK⟩

private def q11Shape24T253 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape24T253OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 917504 11813355520 q11Shape24T253=true := by decide

private def q11Shape24T237 : Tree 11 := .split 19 q11Shape24T238 q11Shape24T253
private theorem q11Shape24T237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 11813355520 q11Shape24T237=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 393216 (11813355520 ||| 2^19) q11Shape24T238 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (393216 ||| 2^19) 11813355520 q11Shape24T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T238OK,q11Shape24T253OK⟩

private def q11Shape24T189 : Tree 11 := .split 18 q11Shape24T190 q11Shape24T237
private theorem q11Shape24T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11813355520 q11Shape24T189=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 (11813355520 ||| 2^18) q11Shape24T190 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (131072 ||| 2^18) 11813355520 q11Shape24T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T190OK,q11Shape24T237OK⟩

def q11Shape24P4 : Tree 11 := q11Shape24T189
theorem q11Shape24P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 131072 11813355520 q11Shape24P4=true := q11Shape24T189OK

end Graffiti384b.EffectiveSearch.Q11
