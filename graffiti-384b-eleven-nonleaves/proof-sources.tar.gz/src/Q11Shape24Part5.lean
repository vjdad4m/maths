import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T261 : Tree 11 := (.split 26 (.split 27 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,1,2,3,8,10}))) (.split 25 (.split 20 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,8,10})))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,4,6,8,10}))))
private theorem q11Shape24T261OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3253698560 q11Shape24T261=true := by decide

private def q11Shape24T262 : Tree 11 := (.split 26 (.split 27 (.tip (.cover {0,1,2,3,9,10})) (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T262OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8606711808 3236921344 q11Shape24T262=true := by decide

private def q11Shape24T260 : Tree 11 := .split 24 q11Shape24T261 q11Shape24T262
private theorem q11Shape24T260OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3236921344 q11Shape24T260=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 (3236921344 ||| 2^24) q11Shape24T261 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589934592 ||| 2^24) 3236921344 q11Shape24T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T261OK,q11Shape24T262OK⟩

private def q11Shape24T263 : Tree 11 := (.split 26 (.split 27 (.split 24 (.split 28 (.tip (.cover {0,1,2,3,8,10})) (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))) (.tip (.cover {0,1,2,3,9,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape24T263OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8598323200 3228532736 q11Shape24T263=true := by decide

private def q11Shape24T259 : Tree 11 := .split 23 q11Shape24T260 q11Shape24T263
private theorem q11Shape24T259OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3228532736 q11Shape24T259=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 (3228532736 ||| 2^23) q11Shape24T260 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589934592 ||| 2^23) 3228532736 q11Shape24T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T260OK,q11Shape24T263OK⟩

private def q11Shape24T265 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,8,10})))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T265OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8594128896 3291447296 q11Shape24T265=true := by decide

private def q11Shape24T266 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape24T266OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8661237760 3224338432 q11Shape24T266=true := by decide

private def q11Shape24T264 : Tree 11 := .split 26 q11Shape24T265 q11Shape24T266
private theorem q11Shape24T264OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8594128896 3224338432 q11Shape24T264=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8594128896 (3224338432 ||| 2^26) q11Shape24T265 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8594128896 ||| 2^26) 3224338432 q11Shape24T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T265OK,q11Shape24T266OK⟩

private def q11Shape24T258 : Tree 11 := .split 22 q11Shape24T259 q11Shape24T264
private theorem q11Shape24T258OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3224338432 q11Shape24T258=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 (3224338432 ||| 2^22) q11Shape24T259 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589934592 ||| 2^22) 3224338432 q11Shape24T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T259OK,q11Shape24T264OK⟩

private def q11Shape24T267 : Tree 11 := (.split 22 (.split 24 (.split 26 (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {0,1,2,3,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T267OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590458880 3223814144 q11Shape24T267=true := by decide

private def q11Shape24T257 : Tree 11 := .split 19 q11Shape24T258 q11Shape24T267
private theorem q11Shape24T257OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3223814144 q11Shape24T257=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 (3223814144 ||| 2^19) q11Shape24T258 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589934592 ||| 2^19) 3223814144 q11Shape24T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T258OK,q11Shape24T267OK⟩

private def q11Shape24T269 : Tree 11 := (.split 23 (.split 26 (.split 27 (.split 19 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {0,1,2,3,9,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,2,3,9,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,6,7,8,10})))
private theorem q11Shape24T269OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590196736 3227746304 q11Shape24T269=true := by decide

private def q11Shape24T270 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape24T270OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8594391040 3223552000 q11Shape24T270=true := by decide

private def q11Shape24T268 : Tree 11 := .split 22 q11Shape24T269 q11Shape24T270
private theorem q11Shape24T268OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590196736 3223552000 q11Shape24T268=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590196736 (3223552000 ||| 2^22) q11Shape24T269 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590196736 ||| 2^22) 3223552000 q11Shape24T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T269OK,q11Shape24T270OK⟩

private def q11Shape24T256 : Tree 11 := .split 18 q11Shape24T257 q11Shape24T268
private theorem q11Shape24T256OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3223552000 q11Shape24T256=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 (3223552000 ||| 2^18) q11Shape24T257 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589934592 ||| 2^18) 3223552000 q11Shape24T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T257OK,q11Shape24T268OK⟩

private def q11Shape24T275 : Tree 11 := (.split 27 (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,8,10})))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T275OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 3319889920 q11Shape24T275=true := by decide

private def q11Shape24T276 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape24T276OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8657174528 3252781056 q11Shape24T276=true := by decide

private def q11Shape24T274 : Tree 11 := .split 26 q11Shape24T275 q11Shape24T276
private theorem q11Shape24T274OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 3252781056 q11Shape24T274=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 (3252781056 ||| 2^26) q11Shape24T275 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590065664 ||| 2^26) 3252781056 q11Shape24T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T275OK,q11Shape24T276OK⟩

private def q11Shape24T277 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T277OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8606842880 3236003840 q11Shape24T277=true := by decide

private def q11Shape24T273 : Tree 11 := .split 24 q11Shape24T274 q11Shape24T277
private theorem q11Shape24T273OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 3236003840 q11Shape24T273=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 (3236003840 ||| 2^24) q11Shape24T274 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590065664 ||| 2^24) 3236003840 q11Shape24T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T274OK,q11Shape24T277OK⟩

private def q11Shape24T278 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T278OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8598454272 3227615232 q11Shape24T278=true := by decide

private def q11Shape24T272 : Tree 11 := .split 23 q11Shape24T273 q11Shape24T278
private theorem q11Shape24T272OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 3227615232 q11Shape24T272=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 (3227615232 ||| 2^23) q11Shape24T273 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590065664 ||| 2^23) 3227615232 q11Shape24T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T273OK,q11Shape24T278OK⟩

private def q11Shape24T279 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape24T279OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8594259968 3223420928 q11Shape24T279=true := by decide

private def q11Shape24T271 : Tree 11 := .split 22 q11Shape24T272 q11Shape24T279
private theorem q11Shape24T271OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 3223420928 q11Shape24T271=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8590065664 (3223420928 ||| 2^22) q11Shape24T272 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8590065664 ||| 2^22) 3223420928 q11Shape24T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T272OK,q11Shape24T279OK⟩

private def q11Shape24T255 : Tree 11 := .split 17 q11Shape24T256 q11Shape24T271
private theorem q11Shape24T255OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3223420928 q11Shape24T255=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 (3223420928 ||| 2^17) q11Shape24T256 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8589934592 ||| 2^17) 3223420928 q11Shape24T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T256OK,q11Shape24T271OK⟩

def q11Shape24P5 : Tree 11 := q11Shape24T255
theorem q11Shape24P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8589934592 3223420928 q11Shape24P5=true := q11Shape24T255OK

end Graffiti384b.EffectiveSearch.Q11
