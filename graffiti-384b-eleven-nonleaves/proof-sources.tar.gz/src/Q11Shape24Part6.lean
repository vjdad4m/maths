import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T289 : Tree 11 := (.split 27 (.tip (.cover {0,1,2,3,9,10})) (.split 25 (.split 20 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,6,7,10}))))
private theorem q11Shape24T289OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9763258368 q11Shape24T289=true := by decide

private def q11Shape24T290 : Tree 11 := (.split 27 (.tip (.cover {0,1,2,3,7,10})) (.split 28 (.split 25 (.split 20 (.split 32 (.tip (.cover {0,2,3,6,8,9})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,10}))))
private theorem q11Shape24T290OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2214592512 9696149504 q11Shape24T290=true := by decide

private def q11Shape24T288 : Tree 11 := .split 26 q11Shape24T289 q11Shape24T290
private theorem q11Shape24T288OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9696149504 q11Shape24T288=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (9696149504 ||| 2^26) q11Shape24T289 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^26) 9696149504 q11Shape24T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T289OK,q11Shape24T290OK⟩

private def q11Shape24T291 : Tree 11 := (.split 27 (.split 26 (.tip (.cover {0,1,2,3,9,10})) (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T291OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2164260864 9679372288 q11Shape24T291=true := by decide

private def q11Shape24T287 : Tree 11 := .split 24 q11Shape24T288 q11Shape24T291
private theorem q11Shape24T287OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9679372288 q11Shape24T287=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (9679372288 ||| 2^24) q11Shape24T288 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^24) 9679372288 q11Shape24T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T288OK,q11Shape24T291OK⟩

private def q11Shape24T293 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,7,8,10})))
private theorem q11Shape24T293OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2155872256 9738092544 q11Shape24T293=true := by decide

private def q11Shape24T294 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T294OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2222981120 9670983680 q11Shape24T294=true := by decide

private def q11Shape24T292 : Tree 11 := .split 26 q11Shape24T293 q11Shape24T294
private theorem q11Shape24T292OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2155872256 9670983680 q11Shape24T292=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2155872256 (9670983680 ||| 2^26) q11Shape24T293 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2155872256 ||| 2^26) 9670983680 q11Shape24T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T293OK,q11Shape24T294OK⟩

private def q11Shape24T286 : Tree 11 := .split 23 q11Shape24T287 q11Shape24T292
private theorem q11Shape24T286OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9670983680 q11Shape24T286=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (9670983680 ||| 2^23) q11Shape24T287 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^23) 9670983680 q11Shape24T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T287OK,q11Shape24T292OK⟩

private def q11Shape24T295 : Tree 11 := (.split 26 (.split 27 (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,2,3,5,8,9})) (.tip (.cover {0,2,3,8,9,10})))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,7,8,10})))
private theorem q11Shape24T295OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2151677952 9666789376 q11Shape24T295=true := by decide

private def q11Shape24T285 : Tree 11 := .split 22 q11Shape24T286 q11Shape24T295
private theorem q11Shape24T285OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9666789376 q11Shape24T285=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (9666789376 ||| 2^22) q11Shape24T286 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^22) 9666789376 q11Shape24T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T286OK,q11Shape24T295OK⟩

private def q11Shape24T296 : Tree 11 := (.split 23 (.split 24 (.split 27 (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.tip (.cover {0,1,2,3,7,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T296OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2148007936 9666265088 q11Shape24T296=true := by decide

private def q11Shape24T284 : Tree 11 := .split 19 q11Shape24T285 q11Shape24T296
private theorem q11Shape24T284OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9666265088 q11Shape24T284=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (9666265088 ||| 2^19) q11Shape24T285 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^19) 9666265088 q11Shape24T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T285OK,q11Shape24T296OK⟩

private def q11Shape24T301 : Tree 11 := (.split 27 (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 34 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,5,7,8,10})))
private theorem q11Shape24T301OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 9762471936 q11Shape24T301=true := by decide

private def q11Shape24T302 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T302OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2214854656 9695363072 q11Shape24T302=true := by decide

private def q11Shape24T300 : Tree 11 := .split 26 q11Shape24T301 q11Shape24T302
private theorem q11Shape24T300OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 9695363072 q11Shape24T300=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 (9695363072 ||| 2^26) q11Shape24T301 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147745792 ||| 2^26) 9695363072 q11Shape24T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T301OK,q11Shape24T302OK⟩

private def q11Shape24T303 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T303OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2164523008 9678585856 q11Shape24T303=true := by decide

private def q11Shape24T299 : Tree 11 := .split 24 q11Shape24T300 q11Shape24T303
private theorem q11Shape24T299OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 9678585856 q11Shape24T299=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 (9678585856 ||| 2^24) q11Shape24T300 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147745792 ||| 2^24) 9678585856 q11Shape24T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T300OK,q11Shape24T303OK⟩

private def q11Shape24T304 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape24T304OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2156134400 9670197248 q11Shape24T304=true := by decide

private def q11Shape24T298 : Tree 11 := .split 23 q11Shape24T299 q11Shape24T304
private theorem q11Shape24T298OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 9670197248 q11Shape24T298=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 (9670197248 ||| 2^23) q11Shape24T299 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147745792 ||| 2^23) 9670197248 q11Shape24T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T299OK,q11Shape24T304OK⟩

private def q11Shape24T305 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T305OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2151940096 9666002944 q11Shape24T305=true := by decide

private def q11Shape24T297 : Tree 11 := .split 22 q11Shape24T298 q11Shape24T305
private theorem q11Shape24T297OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 9666002944 q11Shape24T297=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147745792 (9666002944 ||| 2^22) q11Shape24T298 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147745792 ||| 2^22) 9666002944 q11Shape24T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T298OK,q11Shape24T305OK⟩

private def q11Shape24T283 : Tree 11 := .split 18 q11Shape24T284 q11Shape24T297
private theorem q11Shape24T283OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9666002944 q11Shape24T283=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (9666002944 ||| 2^18) q11Shape24T284 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^18) 9666002944 q11Shape24T297)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T284OK,q11Shape24T297OK⟩

private def q11Shape24T307 : Tree 11 := (.split 23 (.split 26 (.split 27 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,2,3,8,9,10})))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T307OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147614720 9670066176 q11Shape24T307=true := by decide

private def q11Shape24T308 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape24T308OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2151809024 9665871872 q11Shape24T308=true := by decide

private def q11Shape24T306 : Tree 11 := .split 22 q11Shape24T307 q11Shape24T308
private theorem q11Shape24T306OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147614720 9665871872 q11Shape24T306=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147614720 (9665871872 ||| 2^22) q11Shape24T307 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147614720 ||| 2^22) 9665871872 q11Shape24T308)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T307OK,q11Shape24T308OK⟩

private def q11Shape24T282 : Tree 11 := .split 17 q11Shape24T283 q11Shape24T306
private theorem q11Shape24T282OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 9665871872 q11Shape24T282=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (9665871872 ||| 2^17) q11Shape24T283 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^17) 9665871872 q11Shape24T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T283OK,q11Shape24T306OK⟩

private def q11Shape24T309 : Tree 11 := (.split 19 (.split 24 (.split 28 (.tip (.cover {0,2,3,7,8,10})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape24T309OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 10737418240 1075937280 q11Shape24T309=true := by decide

private def q11Shape24T281 : Tree 11 := .split 33 q11Shape24T282 q11Shape24T309
private theorem q11Shape24T281OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 1075937280 q11Shape24T281=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 (1075937280 ||| 2^33) q11Shape24T282 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2147483648 ||| 2^33) 1075937280 q11Shape24T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T282OK,q11Shape24T309OK⟩

def q11Shape24P6 : Tree 11 := q11Shape24T281
theorem q11Shape24P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2147483648 1075937280 q11Shape24P6=true := q11Shape24T281OK

end Graffiti384b.EffectiveSearch.Q11
