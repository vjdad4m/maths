import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T320 : Tree 11 := (.split 28 (.tip (.cover {0,1,2,3,8,10})) (.split 25 (.split 20 (.split 29 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,6,7,10}))))
private theorem q11Shape24T320OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10837000192 q11Shape24T320=true := by decide

private def q11Shape24T321 : Tree 11 := (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.split 25 (.split 20 (.split 32 (.tip (.cover {0,2,3,6,8,9})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,6,7,10})))) (.tip (.cover {0,1,2,3,6,10})))
private theorem q11Shape24T321OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1140850688 10769891328 q11Shape24T321=true := by decide

private def q11Shape24T319 : Tree 11 := .split 26 q11Shape24T320 q11Shape24T321
private theorem q11Shape24T319OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10769891328 q11Shape24T319=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (10769891328 ||| 2^26) q11Shape24T320 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^26) 10769891328 q11Shape24T321)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T320OK,q11Shape24T321OK⟩

private def q11Shape24T323 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 35 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T323OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1090519040 10820222976 q11Shape24T323=true := by decide

private def q11Shape24T324 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T324OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1157627904 10753114112 q11Shape24T324=true := by decide

private def q11Shape24T322 : Tree 11 := .split 26 q11Shape24T323 q11Shape24T324
private theorem q11Shape24T322OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1090519040 10753114112 q11Shape24T322=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1090519040 (10753114112 ||| 2^26) q11Shape24T323 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1090519040 ||| 2^26) 10753114112 q11Shape24T324)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T323OK,q11Shape24T324OK⟩

private def q11Shape24T318 : Tree 11 := .split 24 q11Shape24T319 q11Shape24T322
private theorem q11Shape24T318OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10753114112 q11Shape24T318=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (10753114112 ||| 2^24) q11Shape24T319 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^24) 10753114112 q11Shape24T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T319OK,q11Shape24T322OK⟩

private def q11Shape24T325 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,2,3,5,7,9})) (.tip (.cover {0,2,3,7,9,10})))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape24T325OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1082130432 10744725504 q11Shape24T325=true := by decide

private def q11Shape24T317 : Tree 11 := .split 23 q11Shape24T318 q11Shape24T325
private theorem q11Shape24T317OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10744725504 q11Shape24T317=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (10744725504 ||| 2^23) q11Shape24T318 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^23) 10744725504 q11Shape24T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T318OK,q11Shape24T325OK⟩

private def q11Shape24T326 : Tree 11 := (.split 26 (.split 28 (.split 29 (.split 20 (.split 25 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,2,3,5,8,9})) (.tip (.cover {0,2,3,8,9,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape24T326OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1077936128 10740531200 q11Shape24T326=true := by decide

private def q11Shape24T316 : Tree 11 := .split 22 q11Shape24T317 q11Shape24T326
private theorem q11Shape24T316OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10740531200 q11Shape24T316=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (10740531200 ||| 2^22) q11Shape24T317 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^22) 10740531200 q11Shape24T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T317OK,q11Shape24T326OK⟩

private def q11Shape24T331 : Tree 11 := (.split 27 (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.split 35 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T331OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 10836475904 q11Shape24T331=true := by decide

private def q11Shape24T332 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T332OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1141374976 10769367040 q11Shape24T332=true := by decide

private def q11Shape24T330 : Tree 11 := .split 26 q11Shape24T331 q11Shape24T332
private theorem q11Shape24T330OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 10769367040 q11Shape24T330=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 (10769367040 ||| 2^26) q11Shape24T331 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1074266112 ||| 2^26) 10769367040 q11Shape24T332)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T331OK,q11Shape24T332OK⟩

private def q11Shape24T333 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape24T333OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1091043328 10752589824 q11Shape24T333=true := by decide

private def q11Shape24T329 : Tree 11 := .split 24 q11Shape24T330 q11Shape24T333
private theorem q11Shape24T329OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 10752589824 q11Shape24T329=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 (10752589824 ||| 2^24) q11Shape24T330 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1074266112 ||| 2^24) 10752589824 q11Shape24T333)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T330OK,q11Shape24T333OK⟩

private def q11Shape24T334 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T334OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1082654720 10744201216 q11Shape24T334=true := by decide

private def q11Shape24T328 : Tree 11 := .split 23 q11Shape24T329 q11Shape24T334
private theorem q11Shape24T328OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 10744201216 q11Shape24T328=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 (10744201216 ||| 2^23) q11Shape24T329 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1074266112 ||| 2^23) 10744201216 q11Shape24T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T329OK,q11Shape24T334OK⟩

private def q11Shape24T335 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T335OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1078460416 10740006912 q11Shape24T335=true := by decide

private def q11Shape24T327 : Tree 11 := .split 22 q11Shape24T328 q11Shape24T335
private theorem q11Shape24T327OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 10740006912 q11Shape24T327=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074266112 (10740006912 ||| 2^22) q11Shape24T328 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1074266112 ||| 2^22) 10740006912 q11Shape24T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T328OK,q11Shape24T335OK⟩

private def q11Shape24T315 : Tree 11 := .split 19 q11Shape24T316 q11Shape24T327
private theorem q11Shape24T315OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10740006912 q11Shape24T315=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (10740006912 ||| 2^19) q11Shape24T316 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^19) 10740006912 q11Shape24T327)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T316OK,q11Shape24T327OK⟩

private def q11Shape24T337 : Tree 11 := (.split 24 (.split 27 (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 34 (.tip (.cover {0,2,3,4,7,9})) (.tip (.cover {0,2,3,7,9,10})))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T337OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074003968 10748133376 q11Shape24T337=true := by decide

private def q11Shape24T338 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape24T338OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1082392576 10739744768 q11Shape24T338=true := by decide

private def q11Shape24T336 : Tree 11 := .split 23 q11Shape24T337 q11Shape24T338
private theorem q11Shape24T336OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074003968 10739744768 q11Shape24T336=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1074003968 (10739744768 ||| 2^23) q11Shape24T337 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1074003968 ||| 2^23) 10739744768 q11Shape24T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T337OK,q11Shape24T338OK⟩

private def q11Shape24T314 : Tree 11 := .split 18 q11Shape24T315 q11Shape24T336
private theorem q11Shape24T314OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10739744768 q11Shape24T314=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (10739744768 ||| 2^18) q11Shape24T315 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^18) 10739744768 q11Shape24T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T315OK,q11Shape24T336OK⟩

private def q11Shape24T340 : Tree 11 := (.split 24 (.split 26 (.split 28 (.split 25 (.split 29 (.split 20 (.tip (.cover {0,2,3,7,8,9})) (.split 32 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,2,3,8,9,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T340OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073872896 10743808000 q11Shape24T340=true := by decide

private def q11Shape24T341 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape24T341OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1078067200 10739613696 q11Shape24T341=true := by decide

private def q11Shape24T339 : Tree 11 := .split 22 q11Shape24T340 q11Shape24T341
private theorem q11Shape24T339OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073872896 10739613696 q11Shape24T339=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073872896 (10739613696 ||| 2^22) q11Shape24T340 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073872896 ||| 2^22) 10739613696 q11Shape24T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T340OK,q11Shape24T341OK⟩

private def q11Shape24T313 : Tree 11 := .split 17 q11Shape24T314 q11Shape24T339
private theorem q11Shape24T313OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 10739613696 q11Shape24T313=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (10739613696 ||| 2^17) q11Shape24T314 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^17) 10739613696 q11Shape24T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T314OK,q11Shape24T339OK⟩

private def q11Shape24T342 : Tree 11 := (.split 18 (.split 23 (.split 27 (.tip (.cover {0,2,3,7,9,10})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape24T342OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 9663676416 2149679104 q11Shape24T342=true := by decide

private def q11Shape24T312 : Tree 11 := .split 33 q11Shape24T313 q11Shape24T342
private theorem q11Shape24T312OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 2149679104 q11Shape24T312=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (2149679104 ||| 2^33) q11Shape24T313 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^33) 2149679104 q11Shape24T342)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T313OK,q11Shape24T342OK⟩

private def q11Shape24T343 : Tree 11 := (.split 17 (.split 22 (.split 26 (.tip (.cover {0,2,3,8,9,10})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape24T343OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 3221225472 2195456 q11Shape24T343=true := by decide

private def q11Shape24T311 : Tree 11 := .split 31 q11Shape24T312 q11Shape24T343
private theorem q11Shape24T311OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 2195456 q11Shape24T311=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 (2195456 ||| 2^31) q11Shape24T312 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1073741824 ||| 2^31) 2195456 q11Shape24T343)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T312OK,q11Shape24T343OK⟩

def q11Shape24P7 : Tree 11 := q11Shape24T311
theorem q11Shape24P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1073741824 2195456 q11Shape24P7=true := q11Shape24T311OK

end Graffiti384b.EffectiveSearch.Q11
