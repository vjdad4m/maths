import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T351 : Tree 11 := (.split 24 (.tip (.cover {0,1,2,3,6,10})) (.split 28 (.split 20 (.split 32 (.split 34 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,2,3,6,10}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,2,3,6,10}))))
private theorem q11Shape24T351OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 11824758784 q11Shape24T351=true := by decide

private def q11Shape24T352 : Tree 11 := (.split 24 (.split 27 (.split 20 (.split 32 (.split 34 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,2,3,6,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,2,3,6,10}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape24T352OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 10485760 11816370176 q11Shape24T352=true := by decide

private def q11Shape24T350 : Tree 11 := .split 23 q11Shape24T351 q11Shape24T352
private theorem q11Shape24T350OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 11816370176 q11Shape24T350=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (11816370176 ||| 2^23) q11Shape24T351 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^23) 11816370176 q11Shape24T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T351OK,q11Shape24T352OK⟩

private def q11Shape24T353 : Tree 11 := (.split 23 (.split 24 (.split 26 (.split 20 (.split 32 (.split 34 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,2,3,6,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,2,3,6,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape24T353OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 6291456 11812175872 q11Shape24T353=true := by decide

private def q11Shape24T349 : Tree 11 := .split 22 q11Shape24T350 q11Shape24T353
private theorem q11Shape24T349OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 11812175872 q11Shape24T349=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (11812175872 ||| 2^22) q11Shape24T350 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^22) 11812175872 q11Shape24T353)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T350OK,q11Shape24T353OK⟩

private def q11Shape24T359 : Tree 11 := (.split 29 (.split 32 (.split 34 (.split 24 (.split 28 (.split 20 (.tip (.cover {0,1,2,3,5,9})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {1,2,3,4,6,9}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {1,2,3,4,5,10})))
private theorem q11Shape24T359OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 12059115520 q11Shape24T359=true := by decide

private def q11Shape24T360 : Tree 11 := (.tip (.cover {1,2,3,4,6,10}))
private theorem q11Shape24T360OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 36175872 12025561088 q11Shape24T360=true := by decide

private def q11Shape24T358 : Tree 11 := .split 25 q11Shape24T359 q11Shape24T360
private theorem q11Shape24T358OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 12025561088 q11Shape24T358=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 (12025561088 ||| 2^25) q11Shape24T359 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2621440 ||| 2^25) 12025561088 q11Shape24T360)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T359OK,q11Shape24T360OK⟩

private def q11Shape24T361 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T361OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 136839168 11891343360 q11Shape24T361=true := by decide

private def q11Shape24T357 : Tree 11 := .split 27 q11Shape24T358 q11Shape24T361
private theorem q11Shape24T357OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 11891343360 q11Shape24T357=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 (11891343360 ||| 2^27) q11Shape24T358 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2621440 ||| 2^27) 11891343360 q11Shape24T361)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T358OK,q11Shape24T361OK⟩

private def q11Shape24T362 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T362OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 69730304 11824234496 q11Shape24T362=true := by decide

private def q11Shape24T356 : Tree 11 := .split 26 q11Shape24T357 q11Shape24T362
private theorem q11Shape24T356OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 11824234496 q11Shape24T356=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 (11824234496 ||| 2^26) q11Shape24T357 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2621440 ||| 2^26) 11824234496 q11Shape24T362)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T357OK,q11Shape24T362OK⟩

private def q11Shape24T363 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T363OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 11010048 11815845888 q11Shape24T363=true := by decide

private def q11Shape24T355 : Tree 11 := .split 23 q11Shape24T356 q11Shape24T363
private theorem q11Shape24T355OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 11815845888 q11Shape24T355=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 (11815845888 ||| 2^23) q11Shape24T356 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2621440 ||| 2^23) 11815845888 q11Shape24T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T356OK,q11Shape24T363OK⟩

private def q11Shape24T364 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T364OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 6815744 11811651584 q11Shape24T364=true := by decide

private def q11Shape24T354 : Tree 11 := .split 22 q11Shape24T355 q11Shape24T364
private theorem q11Shape24T354OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 11811651584 q11Shape24T354=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2621440 (11811651584 ||| 2^22) q11Shape24T355 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2621440 ||| 2^22) 11811651584 q11Shape24T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T355OK,q11Shape24T364OK⟩

private def q11Shape24T348 : Tree 11 := .split 19 q11Shape24T349 q11Shape24T354
private theorem q11Shape24T348OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 11811651584 q11Shape24T348=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (11811651584 ||| 2^19) q11Shape24T349 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^19) 11811651584 q11Shape24T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T349OK,q11Shape24T354OK⟩

private def q11Shape24T371 : Tree 11 := (.split 29 (.split 32 (.split 35 (.split 23 (.split 27 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.split 34 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {1,2,3,4,5,8}))) (.tip (.cover {1,2,3,4,6,8}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {1,2,3,4,5,10})))
private theorem q11Shape24T371OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 12201984000 q11Shape24T371=true := by decide

private def q11Shape24T372 : Tree 11 := (.tip (.cover {1,2,3,4,6,10}))
private theorem q11Shape24T372OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 35913728 12168429568 q11Shape24T372=true := by decide

private def q11Shape24T370 : Tree 11 := .split 25 q11Shape24T371 q11Shape24T372
private theorem q11Shape24T370OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 12168429568 q11Shape24T370=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 (12168429568 ||| 2^25) q11Shape24T371 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2359296 ||| 2^25) 12168429568 q11Shape24T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T371OK,q11Shape24T372OK⟩

private def q11Shape24T373 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T373OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 270794752 11899994112 q11Shape24T373=true := by decide

private def q11Shape24T369 : Tree 11 := .split 28 q11Shape24T370 q11Shape24T373
private theorem q11Shape24T369OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 11899994112 q11Shape24T369=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 (11899994112 ||| 2^28) q11Shape24T370 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2359296 ||| 2^28) 11899994112 q11Shape24T373)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T370OK,q11Shape24T373OK⟩

private def q11Shape24T374 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T374OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 69468160 11832885248 q11Shape24T374=true := by decide

private def q11Shape24T368 : Tree 11 := .split 26 q11Shape24T369 q11Shape24T374
private theorem q11Shape24T368OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 11832885248 q11Shape24T368=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 (11832885248 ||| 2^26) q11Shape24T369 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2359296 ||| 2^26) 11832885248 q11Shape24T374)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T369OK,q11Shape24T374OK⟩

private def q11Shape24T375 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T375OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 19136512 11816108032 q11Shape24T375=true := by decide

private def q11Shape24T367 : Tree 11 := .split 24 q11Shape24T368 q11Shape24T375
private theorem q11Shape24T367OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 11816108032 q11Shape24T367=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 (11816108032 ||| 2^24) q11Shape24T368 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2359296 ||| 2^24) 11816108032 q11Shape24T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T368OK,q11Shape24T375OK⟩

private def q11Shape24T376 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T376OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 6553600 11811913728 q11Shape24T376=true := by decide

private def q11Shape24T366 : Tree 11 := .split 22 q11Shape24T367 q11Shape24T376
private theorem q11Shape24T366OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 11811913728 q11Shape24T366=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 (11811913728 ||| 2^22) q11Shape24T367 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2359296 ||| 2^22) 11811913728 q11Shape24T376)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T367OK,q11Shape24T376OK⟩

private def q11Shape24T377 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T377OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2883584 11811389440 q11Shape24T377=true := by decide

private def q11Shape24T365 : Tree 11 := .split 19 q11Shape24T366 q11Shape24T377
private theorem q11Shape24T365OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 11811389440 q11Shape24T365=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2359296 (11811389440 ||| 2^19) q11Shape24T366 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2359296 ||| 2^19) 11811389440 q11Shape24T377)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T366OK,q11Shape24T377OK⟩

private def q11Shape24T347 : Tree 11 := .split 18 q11Shape24T348 q11Shape24T365
private theorem q11Shape24T347OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 11811389440 q11Shape24T347=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (11811389440 ||| 2^18) q11Shape24T348 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^18) 11811389440 q11Shape24T365)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T348OK,q11Shape24T365OK⟩

private def q11Shape24T385 : Tree 11 := (.split 29 (.split 34 (.split 35 (.split 22 (.split 26 (.split 20 (.tip (.cover {0,1,2,3,5,7})) (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,8,9,10})))) (.tip (.cover {1,2,3,4,5,7}))) (.tip (.cover {1,2,3,4,6,7}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {1,2,3,4,5,10})))
private theorem q11Shape24T385OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 12273418240 q11Shape24T385=true := by decide

private def q11Shape24T386 : Tree 11 := (.tip (.cover {1,2,3,4,6,10}))
private theorem q11Shape24T386OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 35782656 12239863808 q11Shape24T386=true := by decide

private def q11Shape24T384 : Tree 11 := .split 25 q11Shape24T385 q11Shape24T386
private theorem q11Shape24T384OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 12239863808 q11Shape24T384=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 (12239863808 ||| 2^25) q11Shape24T385 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2228224 ||| 2^25) 12239863808 q11Shape24T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T385OK,q11Shape24T386OK⟩

private def q11Shape24T387 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T387OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 270663680 11971428352 q11Shape24T387=true := by decide

private def q11Shape24T383 : Tree 11 := .split 28 q11Shape24T384 q11Shape24T387
private theorem q11Shape24T383OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 11971428352 q11Shape24T383=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 (11971428352 ||| 2^28) q11Shape24T384 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2228224 ||| 2^28) 11971428352 q11Shape24T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T384OK,q11Shape24T387OK⟩

private def q11Shape24T388 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape24T388OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 136445952 11837210624 q11Shape24T388=true := by decide

private def q11Shape24T382 : Tree 11 := .split 27 q11Shape24T383 q11Shape24T388
private theorem q11Shape24T382OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 11837210624 q11Shape24T382=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 (11837210624 ||| 2^27) q11Shape24T383 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2228224 ||| 2^27) 11837210624 q11Shape24T388)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T383OK,q11Shape24T388OK⟩

private def q11Shape24T389 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T389OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 19005440 11820433408 q11Shape24T389=true := by decide

private def q11Shape24T381 : Tree 11 := .split 24 q11Shape24T382 q11Shape24T389
private theorem q11Shape24T381OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 11820433408 q11Shape24T381=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 (11820433408 ||| 2^24) q11Shape24T382 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2228224 ||| 2^24) 11820433408 q11Shape24T389)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T382OK,q11Shape24T389OK⟩

private def q11Shape24T390 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T390OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 10616832 11812044800 q11Shape24T390=true := by decide

private def q11Shape24T380 : Tree 11 := .split 23 q11Shape24T381 q11Shape24T390
private theorem q11Shape24T380OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 11812044800 q11Shape24T380=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 (11812044800 ||| 2^23) q11Shape24T381 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2228224 ||| 2^23) 11812044800 q11Shape24T390)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T381OK,q11Shape24T390OK⟩

private def q11Shape24T391 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T391OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2752512 11811520512 q11Shape24T391=true := by decide

private def q11Shape24T379 : Tree 11 := .split 19 q11Shape24T380 q11Shape24T391
private theorem q11Shape24T379OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 11811520512 q11Shape24T379=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 (11811520512 ||| 2^19) q11Shape24T380 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2228224 ||| 2^19) 11811520512 q11Shape24T391)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T380OK,q11Shape24T391OK⟩

private def q11Shape24T392 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T392OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2490368 11811258368 q11Shape24T392=true := by decide

private def q11Shape24T378 : Tree 11 := .split 18 q11Shape24T379 q11Shape24T392
private theorem q11Shape24T378OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 11811258368 q11Shape24T378=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2228224 (11811258368 ||| 2^18) q11Shape24T379 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2228224 ||| 2^18) 11811258368 q11Shape24T392)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T379OK,q11Shape24T392OK⟩

private def q11Shape24T346 : Tree 11 := .split 17 q11Shape24T347 q11Shape24T378
private theorem q11Shape24T346OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 11811258368 q11Shape24T346=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (11811258368 ||| 2^17) q11Shape24T347 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^17) 11811258368 q11Shape24T378)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T347OK,q11Shape24T378OK⟩

private def q11Shape24T404 : Tree 11 := (.split 25 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,5,7,10})))) (.split 29 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,7,8,10}))))
private theorem q11Shape24T404OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 8017379328 q11Shape24T404=true := by decide

private def q11Shape24T405 : Tree 11 := (.split 25 (.split 34 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape24T405OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8860467200 7748943872 q11Shape24T405=true := by decide

private def q11Shape24T403 : Tree 11 := .split 28 q11Shape24T404 q11Shape24T405
private theorem q11Shape24T403OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 7748943872 q11Shape24T403=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (7748943872 ||| 2^28) q11Shape24T404 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^28) 7748943872 q11Shape24T405)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T404OK,q11Shape24T405OK⟩

private def q11Shape24T406 : Tree 11 := (.split 28 (.split 25 (.split 35 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape24T406OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8726249472 7614726144 q11Shape24T406=true := by decide

private def q11Shape24T402 : Tree 11 := .split 27 q11Shape24T403 q11Shape24T406
private theorem q11Shape24T402OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 7614726144 q11Shape24T402=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (7614726144 ||| 2^27) q11Shape24T403 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^27) 7614726144 q11Shape24T406)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T403OK,q11Shape24T406OK⟩

private def q11Shape24T407 : Tree 11 := (.split 28 (.split 29 (.split 34 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape24T407OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8608808960 7597948928 q11Shape24T407=true := by decide

private def q11Shape24T401 : Tree 11 := .split 24 q11Shape24T402 q11Shape24T407
private theorem q11Shape24T401OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 7597948928 q11Shape24T401=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (7597948928 ||| 2^24) q11Shape24T402 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^24) 7597948928 q11Shape24T407)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T402OK,q11Shape24T407OK⟩

private def q11Shape24T408 : Tree 11 := (.split 24 (.split 27 (.split 29 (.split 35 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape24T408OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8600420352 7589560320 q11Shape24T408=true := by decide

private def q11Shape24T400 : Tree 11 := .split 23 q11Shape24T401 q11Shape24T408
private theorem q11Shape24T400OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 7589560320 q11Shape24T400=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (7589560320 ||| 2^23) q11Shape24T401 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^23) 7589560320 q11Shape24T408)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T401OK,q11Shape24T408OK⟩

private def q11Shape24T409 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T409OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 12886999040 3294593024 q11Shape24T409=true := by decide

private def q11Shape24T399 : Tree 11 := .split 32 q11Shape24T400 q11Shape24T409
private theorem q11Shape24T399OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 3294593024 q11Shape24T399=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (3294593024 ||| 2^32) q11Shape24T400 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^32) 3294593024 q11Shape24T409)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T400OK,q11Shape24T409OK⟩

private def q11Shape24T410 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape24T410OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8593080320 3293544448 q11Shape24T410=true := by decide

private def q11Shape24T398 : Tree 11 := .split 20 q11Shape24T399 q11Shape24T410
private theorem q11Shape24T398OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 3293544448 q11Shape24T398=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (3293544448 ||| 2^20) q11Shape24T399 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^20) 3293544448 q11Shape24T410)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T399OK,q11Shape24T410OK⟩

private def q11Shape24T411 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape24T411OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8659140608 3226435584 q11Shape24T411=true := by decide

private def q11Shape24T397 : Tree 11 := .split 26 q11Shape24T398 q11Shape24T411
private theorem q11Shape24T397OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 3226435584 q11Shape24T397=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (3226435584 ||| 2^26) q11Shape24T398 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^26) 3226435584 q11Shape24T411)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T398OK,q11Shape24T411OK⟩

private def q11Shape24T412 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T412OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8596226048 3222241280 q11Shape24T412=true := by decide

private def q11Shape24T396 : Tree 11 := .split 22 q11Shape24T397 q11Shape24T412
private theorem q11Shape24T396OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 3222241280 q11Shape24T396=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (3222241280 ||| 2^22) q11Shape24T397 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^22) 3222241280 q11Shape24T412)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T397OK,q11Shape24T412OK⟩

private def q11Shape24T413 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape24T413OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592556032 3221716992 q11Shape24T413=true := by decide

private def q11Shape24T395 : Tree 11 := .split 19 q11Shape24T396 q11Shape24T413
private theorem q11Shape24T395OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 3221716992 q11Shape24T395=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (3221716992 ||| 2^19) q11Shape24T396 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^19) 3221716992 q11Shape24T413)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T396OK,q11Shape24T413OK⟩

private def q11Shape24T414 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape24T414OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592293888 3221454848 q11Shape24T414=true := by decide

private def q11Shape24T394 : Tree 11 := .split 18 q11Shape24T395 q11Shape24T414
private theorem q11Shape24T394OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 3221454848 q11Shape24T394=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (3221454848 ||| 2^18) q11Shape24T395 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^18) 3221454848 q11Shape24T414)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T395OK,q11Shape24T414OK⟩

private def q11Shape24T415 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T415OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592162816 3221323776 q11Shape24T415=true := by decide

private def q11Shape24T393 : Tree 11 := .split 17 q11Shape24T394 q11Shape24T415
private theorem q11Shape24T393OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 3221323776 q11Shape24T393=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 8592031744 (3221323776 ||| 2^17) q11Shape24T394 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (8592031744 ||| 2^17) 3221323776 q11Shape24T415)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T394OK,q11Shape24T415OK⟩

private def q11Shape24T345 : Tree 11 := .split 33 q11Shape24T346 q11Shape24T393
private theorem q11Shape24T345OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 3221323776 q11Shape24T345=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 (3221323776 ||| 2^33) q11Shape24T346 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2097152 ||| 2^33) 3221323776 q11Shape24T393)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T346OK,q11Shape24T393OK⟩

def q11Shape24P8 : Tree 11 := q11Shape24T345
theorem q11Shape24P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2097152 3221323776 q11Shape24P8=true := q11Shape24T345OK

end Graffiti384b.EffectiveSearch.Q11
