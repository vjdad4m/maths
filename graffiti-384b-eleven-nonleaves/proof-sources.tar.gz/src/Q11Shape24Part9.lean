import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape24T428 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.split 35 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,8,10})))) (.split 29 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,7,8,10}))))
private theorem q11Shape24T428OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 27344732160 q11Shape24T428=true := by decide

private def q11Shape24T429 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape24T429OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2418016256 27076296704 q11Shape24T429=true := by decide

private def q11Shape24T427 : Tree 11 := .split 28 q11Shape24T428 q11Shape24T429
private theorem q11Shape24T427OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 27076296704 q11Shape24T427=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (27076296704 ||| 2^28) q11Shape24T428 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^28) 27076296704 q11Shape24T429)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T428OK,q11Shape24T429OK⟩

private def q11Shape24T430 : Tree 11 := (.split 28 (.split 25 (.split 35 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape24T430OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2216689664 27009187840 q11Shape24T430=true := by decide

private def q11Shape24T426 : Tree 11 := .split 26 q11Shape24T427 q11Shape24T430
private theorem q11Shape24T426OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 27009187840 q11Shape24T426=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (27009187840 ||| 2^26) q11Shape24T427 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^26) 27009187840 q11Shape24T430)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T427OK,q11Shape24T430OK⟩

private def q11Shape24T431 : Tree 11 := (.split 28 (.split 29 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape24T431OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2166358016 26992410624 q11Shape24T431=true := by decide

private def q11Shape24T425 : Tree 11 := .split 24 q11Shape24T426 q11Shape24T431
private theorem q11Shape24T425OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 26992410624 q11Shape24T425=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (26992410624 ||| 2^24) q11Shape24T426 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^24) 26992410624 q11Shape24T431)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T426OK,q11Shape24T431OK⟩

private def q11Shape24T432 : Tree 11 := (.split 24 (.split 26 (.split 29 (.split 35 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape24T432OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2153775104 26988216320 q11Shape24T432=true := by decide

private def q11Shape24T424 : Tree 11 := .split 22 q11Shape24T425 q11Shape24T432
private theorem q11Shape24T424OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 26988216320 q11Shape24T424=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (26988216320 ||| 2^22) q11Shape24T425 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^22) 26988216320 q11Shape24T432)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T425OK,q11Shape24T432OK⟩

private def q11Shape24T433 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T433OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 19329449984 9808347136 q11Shape24T433=true := by decide

private def q11Shape24T423 : Tree 11 := .split 34 q11Shape24T424 q11Shape24T433
private theorem q11Shape24T423OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 9808347136 q11Shape24T423=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (9808347136 ||| 2^34) q11Shape24T424 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^34) 9808347136 q11Shape24T433)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T424OK,q11Shape24T433OK⟩

private def q11Shape24T434 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape24T434OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2150629376 9807298560 q11Shape24T434=true := by decide

private def q11Shape24T422 : Tree 11 := .split 20 q11Shape24T423 q11Shape24T434
private theorem q11Shape24T422OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 9807298560 q11Shape24T422=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (9807298560 ||| 2^20) q11Shape24T423 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^20) 9807298560 q11Shape24T434)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T423OK,q11Shape24T434OK⟩

private def q11Shape24T435 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T435OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2283798528 9673080832 q11Shape24T435=true := by decide

private def q11Shape24T421 : Tree 11 := .split 27 q11Shape24T422 q11Shape24T435
private theorem q11Shape24T421OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 9673080832 q11Shape24T421=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (9673080832 ||| 2^27) q11Shape24T422 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^27) 9673080832 q11Shape24T435)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T422OK,q11Shape24T435OK⟩

private def q11Shape24T436 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T436OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2157969408 9664692224 q11Shape24T436=true := by decide

private def q11Shape24T420 : Tree 11 := .split 23 q11Shape24T421 q11Shape24T436
private theorem q11Shape24T420OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 9664692224 q11Shape24T420=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (9664692224 ||| 2^23) q11Shape24T421 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^23) 9664692224 q11Shape24T436)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T421OK,q11Shape24T436OK⟩

private def q11Shape24T437 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape24T437OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2150105088 9664167936 q11Shape24T437=true := by decide

private def q11Shape24T419 : Tree 11 := .split 19 q11Shape24T420 q11Shape24T437
private theorem q11Shape24T419OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 9664167936 q11Shape24T419=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (9664167936 ||| 2^19) q11Shape24T420 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^19) 9664167936 q11Shape24T437)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T420OK,q11Shape24T437OK⟩

private def q11Shape24T438 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T438OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149842944 9663905792 q11Shape24T438=true := by decide

private def q11Shape24T418 : Tree 11 := .split 18 q11Shape24T419 q11Shape24T438
private theorem q11Shape24T418OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 9663905792 q11Shape24T418=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (9663905792 ||| 2^18) q11Shape24T419 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^18) 9663905792 q11Shape24T438)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T419OK,q11Shape24T438OK⟩

private def q11Shape24T439 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape24T439OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149711872 9663774720 q11Shape24T439=true := by decide

private def q11Shape24T417 : Tree 11 := .split 17 q11Shape24T418 q11Shape24T439
private theorem q11Shape24T417OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 9663774720 q11Shape24T417=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (9663774720 ||| 2^17) q11Shape24T418 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^17) 9663774720 q11Shape24T439)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T418OK,q11Shape24T439OK⟩

private def q11Shape24T440 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T440OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 10739515392 1073840128 q11Shape24T440=true := by decide

private def q11Shape24T416 : Tree 11 := .split 33 q11Shape24T417 q11Shape24T440
private theorem q11Shape24T416OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 1073840128 q11Shape24T416=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 (1073840128 ||| 2^33) q11Shape24T417 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (2149580800 ||| 2^33) 1073840128 q11Shape24T440)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T417OK,q11Shape24T440OK⟩

def q11Shape24P9 : Tree 11 := q11Shape24T416
theorem q11Shape24P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 2149580800 1073840128 q11Shape24P9=true := q11Shape24T416OK

private def q11Shape24T455 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.split 34 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,9,10})))) (.split 29 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape24T455OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 45598343168 q11Shape24T455=true := by decide

private def q11Shape24T456 : Tree 11 := (.split 25 (.split 32 (.tip (.cover {0,1,2,3,6,8})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape24T456OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1210056704 45464125440 q11Shape24T456=true := by decide

private def q11Shape24T454 : Tree 11 := .split 27 q11Shape24T455 q11Shape24T456
private theorem q11Shape24T454OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 45464125440 q11Shape24T454=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (45464125440 ||| 2^27) q11Shape24T455 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^27) 45464125440 q11Shape24T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T455OK,q11Shape24T456OK⟩

private def q11Shape24T457 : Tree 11 := (.split 27 (.split 25 (.split 34 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape24T457OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1142947840 45397016576 q11Shape24T457=true := by decide

private def q11Shape24T453 : Tree 11 := .split 26 q11Shape24T454 q11Shape24T457
private theorem q11Shape24T453OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 45397016576 q11Shape24T453=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (45397016576 ||| 2^26) q11Shape24T454 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^26) 45397016576 q11Shape24T457)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T454OK,q11Shape24T457OK⟩

private def q11Shape24T458 : Tree 11 := (.split 27 (.split 29 (.split 32 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape24T458OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1084227584 45388627968 q11Shape24T458=true := by decide

private def q11Shape24T452 : Tree 11 := .split 23 q11Shape24T453 q11Shape24T458
private theorem q11Shape24T452OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 45388627968 q11Shape24T452=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (45388627968 ||| 2^23) q11Shape24T453 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^23) 45388627968 q11Shape24T458)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T453OK,q11Shape24T458OK⟩

private def q11Shape24T459 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T459OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 35435577344 11028889600 q11Shape24T459=true := by decide

private def q11Shape24T451 : Tree 11 := .split 35 q11Shape24T452 q11Shape24T459
private theorem q11Shape24T451OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 11028889600 q11Shape24T451=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (11028889600 ||| 2^35) q11Shape24T452 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^35) 11028889600 q11Shape24T459)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T452OK,q11Shape24T459OK⟩

private def q11Shape24T461 : Tree 11 := (.split 26 (.split 29 (.split 32 (.tip (.cover {0,2,3,5,8,9})) (.split 27 (.split 25 (.split 34 (.split 35 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,6,9,10})))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape24T461OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1080033280 11033083904 q11Shape24T461=true := by decide

private def q11Shape24T462 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape24T462OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1088421888 11024695296 q11Shape24T462=true := by decide

private def q11Shape24T460 : Tree 11 := .split 23 q11Shape24T461 q11Shape24T462
private theorem q11Shape24T460OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1080033280 11024695296 q11Shape24T460=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1080033280 (11024695296 ||| 2^23) q11Shape24T461 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1080033280 ||| 2^23) 11024695296 q11Shape24T462)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T461OK,q11Shape24T462OK⟩

private def q11Shape24T450 : Tree 11 := .split 22 q11Shape24T451 q11Shape24T460
private theorem q11Shape24T450OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 11024695296 q11Shape24T450=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (11024695296 ||| 2^22) q11Shape24T451 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^22) 11024695296 q11Shape24T460)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T451OK,q11Shape24T460OK⟩

private def q11Shape24T463 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape24T463OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1076887552 11023646720 q11Shape24T463=true := by decide

private def q11Shape24T449 : Tree 11 := .split 20 q11Shape24T450 q11Shape24T463
private theorem q11Shape24T449OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 11023646720 q11Shape24T449=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (11023646720 ||| 2^20) q11Shape24T450 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^20) 11023646720 q11Shape24T463)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T450OK,q11Shape24T463OK⟩

private def q11Shape24T464 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape24T464OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1344274432 10755211264 q11Shape24T464=true := by decide

private def q11Shape24T448 : Tree 11 := .split 28 q11Shape24T449 q11Shape24T464
private theorem q11Shape24T448OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 10755211264 q11Shape24T448=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (10755211264 ||| 2^28) q11Shape24T449 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^28) 10755211264 q11Shape24T464)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T449OK,q11Shape24T464OK⟩

private def q11Shape24T465 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T465OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1092616192 10738434048 q11Shape24T465=true := by decide

private def q11Shape24T447 : Tree 11 := .split 24 q11Shape24T448 q11Shape24T465
private theorem q11Shape24T447OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 10738434048 q11Shape24T447=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (10738434048 ||| 2^24) q11Shape24T448 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^24) 10738434048 q11Shape24T465)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T448OK,q11Shape24T465OK⟩

private def q11Shape24T466 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T466OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1076363264 10737909760 q11Shape24T466=true := by decide

private def q11Shape24T446 : Tree 11 := .split 19 q11Shape24T447 q11Shape24T466
private theorem q11Shape24T446OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 10737909760 q11Shape24T446=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (10737909760 ||| 2^19) q11Shape24T447 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^19) 10737909760 q11Shape24T466)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T447OK,q11Shape24T466OK⟩

private def q11Shape24T467 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape24T467OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1076101120 10737647616 q11Shape24T467=true := by decide

private def q11Shape24T445 : Tree 11 := .split 18 q11Shape24T446 q11Shape24T467
private theorem q11Shape24T445OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 10737647616 q11Shape24T445=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (10737647616 ||| 2^18) q11Shape24T446 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^18) 10737647616 q11Shape24T467)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T446OK,q11Shape24T467OK⟩

private def q11Shape24T468 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape24T468OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075970048 10737516544 q11Shape24T468=true := by decide

private def q11Shape24T444 : Tree 11 := .split 17 q11Shape24T445 q11Shape24T468
private theorem q11Shape24T444OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 10737516544 q11Shape24T444=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (10737516544 ||| 2^17) q11Shape24T445 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^17) 10737516544 q11Shape24T468)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T445OK,q11Shape24T468OK⟩

private def q11Shape24T469 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape24T469OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 9665773568 2147581952 q11Shape24T469=true := by decide

private def q11Shape24T443 : Tree 11 := .split 33 q11Shape24T444 q11Shape24T469
private theorem q11Shape24T443OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 2147581952 q11Shape24T443=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (2147581952 ||| 2^33) q11Shape24T444 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^33) 2147581952 q11Shape24T469)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T444OK,q11Shape24T469OK⟩

private def q11Shape24T470 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape24T470OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 3223322624 98304 q11Shape24T470=true := by decide

private def q11Shape24T442 : Tree 11 := .split 31 q11Shape24T443 q11Shape24T470
private theorem q11Shape24T442OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 98304 q11Shape24T442=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 (98304 ||| 2^31) q11Shape24T443 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) (1075838976 ||| 2^31) 98304 q11Shape24T470)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape24T443OK,q11Shape24T470OK⟩

def q11Shape24P10 : Tree 11 := q11Shape24T442
theorem q11Shape24P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 24)) 1075838976 98304 q11Shape24P10=true := q11Shape24T442OK

end Graffiti384b.EffectiveSearch.Q11
