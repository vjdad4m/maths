import Q11Shape25Part0
import Q11Shape25Part1
import Q11Shape25Part2
import Q11Shape25Part3
import Q11Shape25Part4
import Q11Shape25Part5
import Q11Shape25Part6
import Q11Shape25Part7
import Q11Shape25Part8
import Q11Shape25Part9
import Q11Shape25Part10
import Q11Shape25Part11
import Q11Shape25Part12

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25M68 : Tree 11 := .split 24 q11Shape25P0 q11Shape25P1
private theorem q11Shape25M68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1289748480 q11Shape25M68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1289748480 ||| 2^24) q11Shape25P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^24) 1289748480 q11Shape25P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25P0OK,q11Shape25P1OK⟩
private def q11Shape25M135 : Tree 11 := .split 33 q11Shape25P2 q11Shape25P3
private theorem q11Shape25M135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 8453619712 q11Shape25M135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (8453619712 ||| 2^33) q11Shape25P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^33) 8453619712 q11Shape25P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25P2OK,q11Shape25P3OK⟩
private def q11Shape25M145 : Tree 11 := .split 29 q11Shape25M135 q11Shape25P4
private theorem q11Shape25M145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 7916748800 q11Shape25M145=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (7916748800 ||| 2^29) q11Shape25M135 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^29) 7916748800 q11Shape25P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M135OK,q11Shape25P4OK⟩
private def q11Shape25M161 : Tree 11 := .split 28 q11Shape25M145 q11Shape25P5
private theorem q11Shape25M161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 7648313344 q11Shape25M161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (7648313344 ||| 2^28) q11Shape25M145 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^28) 7648313344 q11Shape25P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M145OK,q11Shape25P5OK⟩
private def q11Shape25M163 : Tree 11 := .split 32 q11Shape25M161 q11Shape25P6
private theorem q11Shape25M163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 3353346048 q11Shape25M163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (3353346048 ||| 2^32) q11Shape25M161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^32) 3353346048 q11Shape25P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M161OK,q11Shape25P6OK⟩
private def q11Shape25M165 : Tree 11 := .split 31 q11Shape25M163 q11Shape25P7
private theorem q11Shape25M165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 1205862400 q11Shape25M165=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (1205862400 ||| 2^31) q11Shape25M163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^31) 1205862400 q11Shape25P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M163OK,q11Shape25P7OK⟩
private def q11Shape25M167 : Tree 11 := .split 25 q11Shape25M165 q11Shape25P8
private theorem q11Shape25M167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 1172307968 q11Shape25M167=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (1172307968 ||| 2^25) q11Shape25M165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^25) 1172307968 q11Shape25P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M165OK,q11Shape25P8OK⟩
private def q11Shape25M169 : Tree 11 := .split 24 q11Shape25M167 q11Shape25P9
private theorem q11Shape25M169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 1155530752 q11Shape25M169=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (1155530752 ||| 2^24) q11Shape25M167 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^24) 1155530752 q11Shape25P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M167OK,q11Shape25P9OK⟩
private def q11Shape25M170 : Tree 11 := .split 27 q11Shape25M68 q11Shape25M169
private theorem q11Shape25M170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1155530752 q11Shape25M170=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1155530752 ||| 2^27) q11Shape25M68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^27) 1155530752 q11Shape25M169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M68OK,q11Shape25M169OK⟩
private def q11Shape25M237 : Tree 11 := .split 31 q11Shape25P10 q11Shape25P11
private theorem q11Shape25M237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 27848081408 q11Shape25M237=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (27848081408 ||| 2^31) q11Shape25P10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^31) 27848081408 q11Shape25P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25P10OK,q11Shape25P11OK⟩
private def q11Shape25M249 : Tree 11 := .split 29 q11Shape25M237 q11Shape25P12
private theorem q11Shape25M249OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 27311210496 q11Shape25M249=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (27311210496 ||| 2^29) q11Shape25M237 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^29) 27311210496 q11Shape25P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M237OK,q11Shape25P12OK⟩
private def q11Shape25M267 : Tree 11 := .split 28 q11Shape25M249 q11Shape25P13
private theorem q11Shape25M267OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 27042775040 q11Shape25M267=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (27042775040 ||| 2^28) q11Shape25M249 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^28) 27042775040 q11Shape25P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M249OK,q11Shape25P13OK⟩
private def q11Shape25M269 : Tree 11 := .split 34 q11Shape25M267 q11Shape25P14
private theorem q11Shape25M269OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 9862905856 q11Shape25M269=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (9862905856 ||| 2^34) q11Shape25M267 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^34) 9862905856 q11Shape25P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M267OK,q11Shape25P14OK⟩
private def q11Shape25M271 : Tree 11 := .split 33 q11Shape25M269 q11Shape25P15
private theorem q11Shape25M271OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 1272971264 q11Shape25M271=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (1272971264 ||| 2^33) q11Shape25M269 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^33) 1272971264 q11Shape25P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M269OK,q11Shape25P15OK⟩
private def q11Shape25M273 : Tree 11 := .split 25 q11Shape25M271 q11Shape25P16
private theorem q11Shape25M273OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 1239416832 q11Shape25M273=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (1239416832 ||| 2^25) q11Shape25M271 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^25) 1239416832 q11Shape25P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M271OK,q11Shape25P16OK⟩
private def q11Shape25M275 : Tree 11 := .split 24 q11Shape25M273 q11Shape25P17
private theorem q11Shape25M275OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 1222639616 q11Shape25M275=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (1222639616 ||| 2^24) q11Shape25M273 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^24) 1222639616 q11Shape25P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M273OK,q11Shape25P17OK⟩
private def q11Shape25M277 : Tree 11 := .split 27 q11Shape25M275 q11Shape25P18
private theorem q11Shape25M277OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 1088421888 q11Shape25M277=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (1088421888 ||| 2^27) q11Shape25M275 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^27) 1088421888 q11Shape25P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M275OK,q11Shape25P18OK⟩
private def q11Shape25M278 : Tree 11 := .split 26 q11Shape25M170 q11Shape25M277
private theorem q11Shape25M278OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1088421888 q11Shape25M278=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1088421888 ||| 2^26) q11Shape25M170 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^26) 1088421888 q11Shape25M277)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M170OK,q11Shape25M277OK⟩
private def q11Shape25M347 : Tree 11 := .split 33 q11Shape25P19 q11Shape25P20
private theorem q11Shape25M347OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 8579448832 q11Shape25M347=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (8579448832 ||| 2^33) q11Shape25P19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^33) 8579448832 q11Shape25P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25P19OK,q11Shape25P20OK⟩
private def q11Shape25M357 : Tree 11 := .split 25 q11Shape25M347 q11Shape25P21
private theorem q11Shape25M357OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 8545894400 q11Shape25M357=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (8545894400 ||| 2^25) q11Shape25M347 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^25) 8545894400 q11Shape25P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M347OK,q11Shape25P21OK⟩
private def q11Shape25M379 : Tree 11 := .split 24 q11Shape25M357 q11Shape25P22
private theorem q11Shape25M379OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 8529117184 q11Shape25M379=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (8529117184 ||| 2^24) q11Shape25M357 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^24) 8529117184 q11Shape25P22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M357OK,q11Shape25P22OK⟩
private def q11Shape25M381 : Tree 11 := .split 32 q11Shape25M379 q11Shape25P23
private theorem q11Shape25M381OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 4234149888 q11Shape25M381=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (4234149888 ||| 2^32) q11Shape25M379 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^32) 4234149888 q11Shape25P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M379OK,q11Shape25P23OK⟩
private def q11Shape25M383 : Tree 11 := .split 31 q11Shape25M381 q11Shape25P24
private theorem q11Shape25M383OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 2086666240 q11Shape25M383=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (2086666240 ||| 2^31) q11Shape25M381 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^31) 2086666240 q11Shape25P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M381OK,q11Shape25P24OK⟩
private def q11Shape25M385 : Tree 11 := .split 29 q11Shape25M383 q11Shape25P25
private theorem q11Shape25M385OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 1549795328 q11Shape25M385=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (1549795328 ||| 2^29) q11Shape25M383 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^29) 1549795328 q11Shape25P25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M383OK,q11Shape25P25OK⟩
private def q11Shape25M387 : Tree 11 := .split 28 q11Shape25M385 q11Shape25P26
private theorem q11Shape25M387OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 1281359872 q11Shape25M387=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (1281359872 ||| 2^28) q11Shape25M385 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^28) 1281359872 q11Shape25P26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M385OK,q11Shape25P26OK⟩
private def q11Shape25M389 : Tree 11 := .split 27 q11Shape25M387 q11Shape25P27
private theorem q11Shape25M389OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 1147142144 q11Shape25M389=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (1147142144 ||| 2^27) q11Shape25M387 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^27) 1147142144 q11Shape25P27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M387OK,q11Shape25P27OK⟩
private def q11Shape25M391 : Tree 11 := .split 26 q11Shape25M389 q11Shape25P28
private theorem q11Shape25M391OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 1080033280 q11Shape25M391=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (1080033280 ||| 2^26) q11Shape25M389 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^26) 1080033280 q11Shape25P28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M389OK,q11Shape25P28OK⟩
private def q11Shape25M392 : Tree 11 := .split 23 q11Shape25M278 q11Shape25M391
private theorem q11Shape25M392OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1080033280 q11Shape25M392=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1080033280 ||| 2^23) q11Shape25M278 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^23) 1080033280 q11Shape25M391)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M278OK,q11Shape25M391OK⟩
private def q11Shape25M463 : Tree 11 := .split 31 q11Shape25P29 q11Shape25P30
private theorem q11Shape25M463OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 27910995968 q11Shape25M463=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (27910995968 ||| 2^31) q11Shape25P29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^31) 27910995968 q11Shape25P30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25P29OK,q11Shape25P30OK⟩
private def q11Shape25M475 : Tree 11 := .split 25 q11Shape25M463 q11Shape25P31
private theorem q11Shape25M475OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 27877441536 q11Shape25M475=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (27877441536 ||| 2^25) q11Shape25M463 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^25) 27877441536 q11Shape25P31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M463OK,q11Shape25P31OK⟩
private def q11Shape25M499 : Tree 11 := .split 24 q11Shape25M475 q11Shape25P32
private theorem q11Shape25M499OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 27860664320 q11Shape25M499=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (27860664320 ||| 2^24) q11Shape25M475 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^24) 27860664320 q11Shape25P32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M475OK,q11Shape25P32OK⟩
private def q11Shape25M501 : Tree 11 := .split 34 q11Shape25M499 q11Shape25P33
private theorem q11Shape25M501OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 10680795136 q11Shape25M501=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (10680795136 ||| 2^34) q11Shape25M499 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^34) 10680795136 q11Shape25P33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M499OK,q11Shape25P33OK⟩
private def q11Shape25M503 : Tree 11 := .split 33 q11Shape25M501 q11Shape25P34
private theorem q11Shape25M503OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 2090860544 q11Shape25M503=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (2090860544 ||| 2^33) q11Shape25M501 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^33) 2090860544 q11Shape25P34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M501OK,q11Shape25P34OK⟩
private def q11Shape25M505 : Tree 11 := .split 29 q11Shape25M503 q11Shape25P35
private theorem q11Shape25M505OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 1553989632 q11Shape25M505=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (1553989632 ||| 2^29) q11Shape25M503 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^29) 1553989632 q11Shape25P35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M503OK,q11Shape25P35OK⟩
private def q11Shape25M507 : Tree 11 := .split 28 q11Shape25M505 q11Shape25P36
private theorem q11Shape25M507OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 1285554176 q11Shape25M507=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (1285554176 ||| 2^28) q11Shape25M505 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^28) 1285554176 q11Shape25P36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M505OK,q11Shape25P36OK⟩
private def q11Shape25M509 : Tree 11 := .split 27 q11Shape25M507 q11Shape25P37
private theorem q11Shape25M509OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 1151336448 q11Shape25M509=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (1151336448 ||| 2^27) q11Shape25M507 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^27) 1151336448 q11Shape25P37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M507OK,q11Shape25P37OK⟩
private def q11Shape25M511 : Tree 11 := .split 26 q11Shape25M509 q11Shape25P38
private theorem q11Shape25M511OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 1084227584 q11Shape25M511=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (1084227584 ||| 2^26) q11Shape25M509 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^26) 1084227584 q11Shape25P38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M509OK,q11Shape25P38OK⟩
private def q11Shape25M513 : Tree 11 := .split 23 q11Shape25M511 q11Shape25P39
private theorem q11Shape25M513OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 1075838976 q11Shape25M513=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (1075838976 ||| 2^23) q11Shape25M511 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^23) 1075838976 q11Shape25P39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M511OK,q11Shape25P39OK⟩
private def q11Shape25M514 : Tree 11 := .split 22 q11Shape25M392 q11Shape25M513
private theorem q11Shape25M514OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1075838976 q11Shape25M514=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1075838976 ||| 2^22) q11Shape25M392 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^22) 1075838976 q11Shape25M513)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M392OK,q11Shape25M513OK⟩
private def q11Shape25M568 : Tree 11 := .split 30 q11Shape25M514 q11Shape25P40
private theorem q11Shape25M568OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 2097152 q11Shape25M568=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (2097152 ||| 2^30) q11Shape25M514 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^30) 2097152 q11Shape25P40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M514OK,q11Shape25P40OK⟩
private def q11Shape25M620 : Tree 11 := .split 21 q11Shape25M568 q11Shape25P41
private theorem q11Shape25M620OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 0 q11Shape25M620=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (0 ||| 2^21) q11Shape25M568 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^21) 0 q11Shape25P41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25M568OK,q11Shape25P41OK⟩

theorem q11Shape25_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 25) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 25) b) (adj 11 (forms 25) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) adj_mono b H q11Shape25M620 q11Shape25M620OK

#print axioms q11Shape25_cover

end Graffiti384b.EffectiveSearch.Q11
