import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T5 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 12882804736 q11Shape25T5=true := by decide

private def q11Shape25T8 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8589934592 25767706624 q11Shape25T8=true := by decide

private def q11Shape25T10 : Tree 11 := (.split 3 (.split 11 (.split 4 (.tip (.cover {0,1,3,4,9,10})) (.tip (.cover {0,3,4,7,9,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.split 9 (.split 11 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,2,4,7,9,10}))) (.split 17 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,7,9,10})))))
private theorem q11Shape25T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803776 8587837444 q11Shape25T10=true := by decide

private def q11Shape25T13 : Tree 11 := (.split 4 (.split 15 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.split 10 (.split 11 (.tip (.cover {0,1,4,5,8,9})) (.tip (.cover {0,2,4,7,8,9}))) (.split 11 (.tip (.cover {1,4,5,6,8,9})) (.tip (.cover {0,1,3,5,8,9}))))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape25T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803780 8587837960 q11Shape25T13=true := by decide

private def q11Shape25T14 : Tree 11 := (.split 10 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape25T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769804292 8587837448 q11Shape25T14=true := by decide

private def q11Shape25T12 : Tree 11 := .split 9 q11Shape25T13 q11Shape25T14
private theorem q11Shape25T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803780 8587837448 q11Shape25T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803780 (8587837448 ||| 2^9) q11Shape25T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25769803780 ||| 2^9) 8587837448 q11Shape25T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T13OK,q11Shape25T14OK⟩

private def q11Shape25T15 : Tree 11 := (.tip (.cover {0,1,2,7,9,10}))
private theorem q11Shape25T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803788 8587837440 q11Shape25T15=true := by decide

private def q11Shape25T11 : Tree 11 := .split 3 q11Shape25T12 q11Shape25T15
private theorem q11Shape25T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803780 8587837440 q11Shape25T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803780 (8587837440 ||| 2^3) q11Shape25T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25769803780 ||| 2^3) 8587837440 q11Shape25T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T12OK,q11Shape25T15OK⟩

private def q11Shape25T9 : Tree 11 := .split 2 q11Shape25T10 q11Shape25T11
private theorem q11Shape25T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803776 8587837440 q11Shape25T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25769803776 (8587837440 ||| 2^2) q11Shape25T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25769803776 ||| 2^2) 8587837440 q11Shape25T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T10OK,q11Shape25T11OK⟩

private def q11Shape25T7 : Tree 11 := .split 34 q11Shape25T8 q11Shape25T9
private theorem q11Shape25T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8589934592 8587837440 q11Shape25T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8589934592 (8587837440 ||| 2^34) q11Shape25T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8589934592 ||| 2^34) 8587837440 q11Shape25T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T8OK,q11Shape25T9OK⟩

private def q11Shape25T16 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 12884901888 4292870144 q11Shape25T16=true := by decide

private def q11Shape25T6 : Tree 11 := .split 32 q11Shape25T7 q11Shape25T16
private theorem q11Shape25T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8589934592 4292870144 q11Shape25T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8589934592 (4292870144 ||| 2^32) q11Shape25T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8589934592 ||| 2^32) 4292870144 q11Shape25T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T7OK,q11Shape25T16OK⟩

private def q11Shape25T4 : Tree 11 := .split 33 q11Shape25T5 q11Shape25T6
private theorem q11Shape25T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 4292870144 q11Shape25T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (4292870144 ||| 2^33) q11Shape25T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^33) 4292870144 q11Shape25T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T5OK,q11Shape25T6OK⟩

private def q11Shape25T20 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2147483648 32210157568 q11Shape25T20=true := by decide

private def q11Shape25T22 : Tree 11 := (.split 3 (.split 12 (.split 18 (.split 5 (.tip (.cover {0,1,5,6,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.split 9 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,8,9,10})))))
private theorem q11Shape25T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6442450944 27915190276 q11Shape25T22=true := by decide

private def q11Shape25T23 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,8,9,10})))) (.split 10 (.tip (.cover {0,4,5,8,9,10})) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape25T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6442450948 27915190272 q11Shape25T23=true := by decide

private def q11Shape25T21 : Tree 11 := .split 2 q11Shape25T22 q11Shape25T23
private theorem q11Shape25T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6442450944 27915190272 q11Shape25T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6442450944 (27915190272 ||| 2^2) q11Shape25T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6442450944 ||| 2^2) 27915190272 q11Shape25T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T22OK,q11Shape25T23OK⟩

private def q11Shape25T19 : Tree 11 := .split 32 q11Shape25T20 q11Shape25T21
private theorem q11Shape25T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2147483648 27915190272 q11Shape25T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2147483648 (27915190272 ||| 2^32) q11Shape25T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2147483648 ||| 2^32) 27915190272 q11Shape25T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T20OK,q11Shape25T21OK⟩

private def q11Shape25T24 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 19327352832 10735321088 q11Shape25T24=true := by decide

private def q11Shape25T18 : Tree 11 := .split 34 q11Shape25T19 q11Shape25T24
private theorem q11Shape25T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2147483648 10735321088 q11Shape25T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2147483648 (10735321088 ||| 2^34) q11Shape25T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2147483648 ||| 2^34) 10735321088 q11Shape25T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T19OK,q11Shape25T24OK⟩

private def q11Shape25T25 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 10737418240 2145386496 q11Shape25T25=true := by decide

private def q11Shape25T17 : Tree 11 := .split 33 q11Shape25T18 q11Shape25T25
private theorem q11Shape25T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2147483648 2145386496 q11Shape25T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2147483648 (2145386496 ||| 2^33) q11Shape25T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2147483648 ||| 2^33) 2145386496 q11Shape25T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T18OK,q11Shape25T25OK⟩

private def q11Shape25T3 : Tree 11 := .split 31 q11Shape25T4 q11Shape25T17
private theorem q11Shape25T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 2145386496 q11Shape25T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (2145386496 ||| 2^31) q11Shape25T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^31) 2145386496 q11Shape25T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T4OK,q11Shape25T17OK⟩

private def q11Shape25T26 : Tree 11 := (.split 31 (.split 33 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape25T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 536870912 1608515584 q11Shape25T26=true := by decide

private def q11Shape25T2 : Tree 11 := .split 29 q11Shape25T3 q11Shape25T26
private theorem q11Shape25T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1608515584 q11Shape25T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1608515584 ||| 2^29) q11Shape25T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^29) 1608515584 q11Shape25T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T3OK,q11Shape25T26OK⟩

private def q11Shape25T32 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 34089205760 q11Shape25T32=true := by decide

private def q11Shape25T35 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,7,8,9,10})) (.split 17 (.split 18 (.tip (.cover {1,2,3,5,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.split 11 (.split 12 (.tip (.cover {1,2,4,5,9,10})) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,3,4,6,9}))))
private theorem q11Shape25T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 805306368 33552334860 q11Shape25T35=true := by decide

private def q11Shape25T36 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,7,8,9,10})) (.split 17 (.split 18 (.tip (.cover {1,2,3,5,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.split 11 (.split 12 (.tip (.cover {1,2,4,5,9,10})) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,3,4,6,9}))))
private theorem q11Shape25T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 805306376 33552334852 q11Shape25T36=true := by decide

private def q11Shape25T34 : Tree 11 := .split 3 q11Shape25T35 q11Shape25T36
private theorem q11Shape25T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 805306368 33552334852 q11Shape25T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 805306368 (33552334852 ||| 2^3) q11Shape25T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (805306368 ||| 2^3) 33552334852 q11Shape25T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T35OK,q11Shape25T36OK⟩

private def q11Shape25T37 : Tree 11 := (.split 9 (.split 15 (.split 4 (.split 5 (.tip (.cover {1,3,4,5,9,10})) (.tip (.cover {0,1,2,7,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,2,3,4,6,9}))) (.tip (.cover {1,2,3,4,6,9})))
private theorem q11Shape25T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 805306372 33552334848 q11Shape25T37=true := by decide

private def q11Shape25T33 : Tree 11 := .split 2 q11Shape25T34 q11Shape25T37
private theorem q11Shape25T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 805306368 33552334848 q11Shape25T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 805306368 (33552334848 ||| 2^2) q11Shape25T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (805306368 ||| 2^2) 33552334848 q11Shape25T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T34OK,q11Shape25T37OK⟩

private def q11Shape25T31 : Tree 11 := .split 29 q11Shape25T32 q11Shape25T33
private theorem q11Shape25T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 33552334848 q11Shape25T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 (33552334848 ||| 2^29) q11Shape25T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (268435456 ||| 2^29) 33552334848 q11Shape25T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T32OK,q11Shape25T33OK⟩

private def q11Shape25T38 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17448304640 16372465664 q11Shape25T38=true := by decide

private def q11Shape25T30 : Tree 11 := .split 34 q11Shape25T31 q11Shape25T38
private theorem q11Shape25T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 16372465664 q11Shape25T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 (16372465664 ||| 2^34) q11Shape25T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (268435456 ||| 2^34) 16372465664 q11Shape25T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T31OK,q11Shape25T38OK⟩

private def q11Shape25T39 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8858370048 7782531072 q11Shape25T39=true := by decide

private def q11Shape25T29 : Tree 11 := .split 33 q11Shape25T30 q11Shape25T39
private theorem q11Shape25T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 7782531072 q11Shape25T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 (7782531072 ||| 2^33) q11Shape25T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (268435456 ||| 2^33) 7782531072 q11Shape25T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T30OK,q11Shape25T39OK⟩

private def q11Shape25T40 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4563402752 3487563776 q11Shape25T40=true := by decide

private def q11Shape25T28 : Tree 11 := .split 32 q11Shape25T29 q11Shape25T40
private theorem q11Shape25T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 3487563776 q11Shape25T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 (3487563776 ||| 2^32) q11Shape25T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (268435456 ||| 2^32) 3487563776 q11Shape25T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T29OK,q11Shape25T40OK⟩

private def q11Shape25T41 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2415919104 1340080128 q11Shape25T41=true := by decide

private def q11Shape25T27 : Tree 11 := .split 31 q11Shape25T28 q11Shape25T41
private theorem q11Shape25T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 1340080128 q11Shape25T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 268435456 (1340080128 ||| 2^31) q11Shape25T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (268435456 ||| 2^31) 1340080128 q11Shape25T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T28OK,q11Shape25T41OK⟩

private def q11Shape25T1 : Tree 11 := .split 28 q11Shape25T2 q11Shape25T27
private theorem q11Shape25T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1340080128 q11Shape25T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1340080128 ||| 2^28) q11Shape25T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^28) 1340080128 q11Shape25T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T2OK,q11Shape25T27OK⟩

private def q11Shape25T42 : Tree 11 := (.split 28 (.split 29 (.split 31 (.split 33 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape25T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 33554432 1306525696 q11Shape25T42=true := by decide

private def q11Shape25T0 : Tree 11 := .split 25 q11Shape25T1 q11Shape25T42
private theorem q11Shape25T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1306525696 q11Shape25T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 (1306525696 ||| 2^25) q11Shape25T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (0 ||| 2^25) 1306525696 q11Shape25T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T1OK,q11Shape25T42OK⟩

def q11Shape25P0 : Tree 11 := q11Shape25T0
theorem q11Shape25P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 0 1306525696 q11Shape25P0=true := q11Shape25T0OK

end Graffiti384b.EffectiveSearch.Q11
