import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T50 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 34340864000 q11Shape25T50=true := by decide

private def q11Shape25T54 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,7,8,9,10})) (.split 17 (.split 18 (.tip (.cover {1,2,3,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 16 (.split 11 (.split 12 (.tip (.cover {1,2,4,6,9,10})) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331648 34307310092 q11Shape25T54=true := by decide

private def q11Shape25T55 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,7,8,9,10})) (.split 17 (.split 18 (.tip (.cover {1,2,3,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 16 (.split 11 (.split 12 (.tip (.cover {1,2,4,6,9,10})) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50332160 34307309580 q11Shape25T55=true := by decide

private def q11Shape25T53 : Tree 11 := .split 9 q11Shape25T54 q11Shape25T55
private theorem q11Shape25T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331648 34307309580 q11Shape25T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331648 (34307309580 ||| 2^9) q11Shape25T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (50331648 ||| 2^9) 34307309580 q11Shape25T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T54OK,q11Shape25T55OK⟩

private def q11Shape25T56 : Tree 11 := (.split 10 (.split 16 (.split 4 (.split 5 (.tip (.cover {1,3,4,6,9,10})) (.tip (.cover {0,1,2,7,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {1,2,3,4,5,9})))
private theorem q11Shape25T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331656 34307309572 q11Shape25T56=true := by decide

private def q11Shape25T52 : Tree 11 := .split 3 q11Shape25T53 q11Shape25T56
private theorem q11Shape25T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331648 34307309572 q11Shape25T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331648 (34307309572 ||| 2^3) q11Shape25T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (50331648 ||| 2^3) 34307309572 q11Shape25T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T53OK,q11Shape25T56OK⟩

private def q11Shape25T59 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,7,8,9,10})) (.split 17 (.split 18 (.tip (.cover {1,2,3,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 16 (.split 11 (.split 12 (.tip (.cover {1,2,4,6,9,10})) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331652 34307310088 q11Shape25T59=true := by decide

private def q11Shape25T60 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,7,8,9,10})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,4,5,7,8,9})))) (.split 16 (.split 11 (.split 12 (.tip (.cover {1,2,4,6,9,10})) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50332164 34307309576 q11Shape25T60=true := by decide

private def q11Shape25T58 : Tree 11 := .split 9 q11Shape25T59 q11Shape25T60
private theorem q11Shape25T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331652 34307309576 q11Shape25T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331652 (34307309576 ||| 2^9) q11Shape25T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (50331652 ||| 2^9) 34307309576 q11Shape25T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T59OK,q11Shape25T60OK⟩

private def q11Shape25T61 : Tree 11 := (.split 10 (.split 16 (.split 4 (.split 5 (.tip (.cover {1,3,4,6,9,10})) (.tip (.cover {0,1,2,7,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {1,2,3,4,5,9})))
private theorem q11Shape25T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331660 34307309568 q11Shape25T61=true := by decide

private def q11Shape25T57 : Tree 11 := .split 3 q11Shape25T58 q11Shape25T61
private theorem q11Shape25T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331652 34307309568 q11Shape25T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331652 (34307309568 ||| 2^3) q11Shape25T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (50331652 ||| 2^3) 34307309568 q11Shape25T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T58OK,q11Shape25T61OK⟩

private def q11Shape25T51 : Tree 11 := .split 2 q11Shape25T52 q11Shape25T57
private theorem q11Shape25T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331648 34307309568 q11Shape25T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 50331648 (34307309568 ||| 2^2) q11Shape25T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (50331648 ||| 2^2) 34307309568 q11Shape25T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T52OK,q11Shape25T57OK⟩

private def q11Shape25T49 : Tree 11 := .split 25 q11Shape25T50 q11Shape25T51
private theorem q11Shape25T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 34307309568 q11Shape25T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 (34307309568 ||| 2^25) q11Shape25T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (16777216 ||| 2^25) 34307309568 q11Shape25T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T50OK,q11Shape25T51OK⟩

private def q11Shape25T62 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17196646400 17127440384 q11Shape25T62=true := by decide

private def q11Shape25T48 : Tree 11 := .split 34 q11Shape25T49 q11Shape25T62
private theorem q11Shape25T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 17127440384 q11Shape25T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 (17127440384 ||| 2^34) q11Shape25T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (16777216 ||| 2^34) 17127440384 q11Shape25T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T49OK,q11Shape25T62OK⟩

private def q11Shape25T63 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8606711808 8537505792 q11Shape25T63=true := by decide

private def q11Shape25T47 : Tree 11 := .split 33 q11Shape25T48 q11Shape25T63
private theorem q11Shape25T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 8537505792 q11Shape25T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 (8537505792 ||| 2^33) q11Shape25T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (16777216 ||| 2^33) 8537505792 q11Shape25T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T48OK,q11Shape25T63OK⟩

private def q11Shape25T64 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4311744512 4242538496 q11Shape25T64=true := by decide

private def q11Shape25T46 : Tree 11 := .split 32 q11Shape25T47 q11Shape25T64
private theorem q11Shape25T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 4242538496 q11Shape25T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 (4242538496 ||| 2^32) q11Shape25T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (16777216 ||| 2^32) 4242538496 q11Shape25T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T47OK,q11Shape25T64OK⟩

private def q11Shape25T65 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2164260864 2095054848 q11Shape25T65=true := by decide

private def q11Shape25T45 : Tree 11 := .split 31 q11Shape25T46 q11Shape25T65
private theorem q11Shape25T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 2095054848 q11Shape25T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 (2095054848 ||| 2^31) q11Shape25T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (16777216 ||| 2^31) 2095054848 q11Shape25T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T46OK,q11Shape25T65OK⟩

private def q11Shape25T66 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape25T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 553648128 1558183936 q11Shape25T66=true := by decide

private def q11Shape25T44 : Tree 11 := .split 29 q11Shape25T45 q11Shape25T66
private theorem q11Shape25T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 1558183936 q11Shape25T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 (1558183936 ||| 2^29) q11Shape25T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (16777216 ||| 2^29) 1558183936 q11Shape25T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T45OK,q11Shape25T66OK⟩

private def q11Shape25T67 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape25T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 285212672 1289748480 q11Shape25T67=true := by decide

private def q11Shape25T43 : Tree 11 := .split 28 q11Shape25T44 q11Shape25T67
private theorem q11Shape25T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 1289748480 q11Shape25T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 (1289748480 ||| 2^28) q11Shape25T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (16777216 ||| 2^28) 1289748480 q11Shape25T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T44OK,q11Shape25T67OK⟩

def q11Shape25P1 : Tree 11 := q11Shape25T43
theorem q11Shape25P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16777216 1289748480 q11Shape25P1=true := q11Shape25T43OK

end Graffiti384b.EffectiveSearch.Q11
