import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T453 : Tree 11 := (.split 15 (.split 3 (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10})))) (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {2,3,4,5,8,9})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T453OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 32205963780 q11Shape25T453=true := by decide

private def q11Shape25T454 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T454OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151678464 32205963268 q11Shape25T454=true := by decide

private def q11Shape25T452 : Tree 11 := .split 9 q11Shape25T453 q11Shape25T454
private theorem q11Shape25T452OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 32205963268 q11Shape25T452=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 (32205963268 ||| 2^9) q11Shape25T453 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2151677952 ||| 2^9) 32205963268 q11Shape25T454)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T453OK,q11Shape25T454OK⟩

private def q11Shape25T455 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T455OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677956 32205963264 q11Shape25T455=true := by decide

private def q11Shape25T451 : Tree 11 := .split 2 q11Shape25T452 q11Shape25T455
private theorem q11Shape25T451OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 32205963264 q11Shape25T451=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 (32205963264 ||| 2^2) q11Shape25T452 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2151677952 ||| 2^2) 32205963264 q11Shape25T455)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T452OK,q11Shape25T455OK⟩

private def q11Shape25T459 : Tree 11 := (.split 10 (.split 15 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,4,8,9,10}))) (.split 12 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,3,5,9,10}))))
private theorem q11Shape25T459OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645248 27910996492 q11Shape25T459=true := by decide

private def q11Shape25T460 : Tree 11 := (.split 10 (.split 5 (.tip (.cover {0,1,3,4,9,10})) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape25T460OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645760 27910995980 q11Shape25T460=true := by decide

private def q11Shape25T458 : Tree 11 := .split 9 q11Shape25T459 q11Shape25T460
private theorem q11Shape25T458OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645248 27910995980 q11Shape25T458=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645248 (27910995980 ||| 2^9) q11Shape25T459 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6446645248 ||| 2^9) 27910995980 q11Shape25T460)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T459OK,q11Shape25T460OK⟩

private def q11Shape25T461 : Tree 11 := (.split 9 (.split 10 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.split 15 (.split 35 (.tip (.cover {2,3,4,5,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {2,3,4,7,8,9})))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape25T461OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645256 27910995972 q11Shape25T461=true := by decide

private def q11Shape25T457 : Tree 11 := .split 3 q11Shape25T458 q11Shape25T461
private theorem q11Shape25T457OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645248 27910995972 q11Shape25T457=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645248 (27910995972 ||| 2^3) q11Shape25T458 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6446645248 ||| 2^3) 27910995972 q11Shape25T461)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T458OK,q11Shape25T461OK⟩

private def q11Shape25T462 : Tree 11 := (.split 3 (.split 9 (.split 10 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,8,9,10})))) (.split 10 (.tip (.cover {0,4,5,8,9,10})) (.tip (.cover {0,1,3,8,9,10})))) (.tip (.cover {0,1,2,8,9,10})))
private theorem q11Shape25T462OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645252 27910995968 q11Shape25T462=true := by decide

private def q11Shape25T456 : Tree 11 := .split 2 q11Shape25T457 q11Shape25T462
private theorem q11Shape25T456OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645248 27910995968 q11Shape25T456=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6446645248 (27910995968 ||| 2^2) q11Shape25T457 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6446645248 ||| 2^2) 27910995968 q11Shape25T462)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T457OK,q11Shape25T462OK⟩

private def q11Shape25T450 : Tree 11 := .split 32 q11Shape25T451 q11Shape25T456
private theorem q11Shape25T450OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 27910995968 q11Shape25T450=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 (27910995968 ||| 2^32) q11Shape25T451 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2151677952 ||| 2^32) 27910995968 q11Shape25T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T451OK,q11Shape25T456OK⟩

def q11Shape25P30 : Tree 11 := q11Shape25T450
theorem q11Shape25P30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2151677952 27910995968 q11Shape25P30=true := q11Shape25T450OK

private def q11Shape25T469 : Tree 11 := (.split 4 (.split 3 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T469OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 34320025604 q11Shape25T469=true := by decide

private def q11Shape25T470 : Tree 11 := (.split 4 (.split 3 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9})))) (.tip (.cover {1,2,3,4,6,10})))
private theorem q11Shape25T470OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748740 34320025600 q11Shape25T470=true := by decide

private def q11Shape25T468 : Tree 11 := .split 2 q11Shape25T469 q11Shape25T470
private theorem q11Shape25T468OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 34320025600 q11Shape25T468=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 (34320025600 ||| 2^2) q11Shape25T469 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (37748736 ||| 2^2) 34320025600 q11Shape25T470)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T469OK,q11Shape25T470OK⟩

private def q11Shape25T471 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T471OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37879808 34319894528 q11Shape25T471=true := by decide

private def q11Shape25T467 : Tree 11 := .split 17 q11Shape25T468 q11Shape25T471
private theorem q11Shape25T467OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 34319894528 q11Shape25T467=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 (34319894528 ||| 2^17) q11Shape25T468 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (37748736 ||| 2^17) 34319894528 q11Shape25T471)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T468OK,q11Shape25T471OK⟩

private def q11Shape25T472 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T472OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37750784 34319892480 q11Shape25T472=true := by decide

private def q11Shape25T466 : Tree 11 := .split 11 q11Shape25T467 q11Shape25T472
private theorem q11Shape25T466OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 34319892480 q11Shape25T466=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 (34319892480 ||| 2^11) q11Shape25T467 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (37748736 ||| 2^11) 34319892480 q11Shape25T472)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T467OK,q11Shape25T472OK⟩

private def q11Shape25T473 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T473OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4332716032 30024925184 q11Shape25T473=true := by decide

private def q11Shape25T465 : Tree 11 := .split 32 q11Shape25T466 q11Shape25T473
private theorem q11Shape25T465OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 30024925184 q11Shape25T465=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 (30024925184 ||| 2^32) q11Shape25T466 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (37748736 ||| 2^32) 30024925184 q11Shape25T473)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T466OK,q11Shape25T473OK⟩

private def q11Shape25T474 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T474OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2185232384 27877441536 q11Shape25T474=true := by decide

private def q11Shape25T464 : Tree 11 := .split 31 q11Shape25T465 q11Shape25T474
private theorem q11Shape25T464OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 27877441536 q11Shape25T464=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 (27877441536 ||| 2^31) q11Shape25T465 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (37748736 ||| 2^31) 27877441536 q11Shape25T474)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T465OK,q11Shape25T474OK⟩

def q11Shape25P31 : Tree 11 := q11Shape25T464
theorem q11Shape25P31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 37748736 27877441536 q11Shape25P31=true := q11Shape25T464OK

private def q11Shape25T482 : Tree 11 := (.split 4 (.split 3 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,10}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,10})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T482OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 34336802820 q11Shape25T482=true := by decide

private def q11Shape25T483 : Tree 11 := (.split 4 (.split 3 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,10}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,10})))) (.tip (.cover {1,2,3,4,6,9})))
private theorem q11Shape25T483OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971524 34336802816 q11Shape25T483=true := by decide

private def q11Shape25T481 : Tree 11 := .split 2 q11Shape25T482 q11Shape25T483
private theorem q11Shape25T481OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 34336802816 q11Shape25T481=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 (34336802816 ||| 2^2) q11Shape25T482 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (20971520 ||| 2^2) 34336802816 q11Shape25T483)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T482OK,q11Shape25T483OK⟩

private def q11Shape25T484 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T484OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 21102592 34336671744 q11Shape25T484=true := by decide

private def q11Shape25T480 : Tree 11 := .split 17 q11Shape25T481 q11Shape25T484
private theorem q11Shape25T480OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 34336671744 q11Shape25T480=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 (34336671744 ||| 2^17) q11Shape25T481 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (20971520 ||| 2^17) 34336671744 q11Shape25T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T481OK,q11Shape25T484OK⟩

private def q11Shape25T485 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T485OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20973568 34336669696 q11Shape25T485=true := by decide

private def q11Shape25T479 : Tree 11 := .split 11 q11Shape25T480 q11Shape25T485
private theorem q11Shape25T479OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 34336669696 q11Shape25T479=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 (34336669696 ||| 2^11) q11Shape25T480 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (20971520 ||| 2^11) 34336669696 q11Shape25T485)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T480OK,q11Shape25T485OK⟩

private def q11Shape25T489 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,5,8,9,10})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9})))) (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T489OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525952 34303115788 q11Shape25T489=true := by decide

private def q11Shape25T490 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,5,8,9,10})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9})))) (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T490OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54526464 34303115276 q11Shape25T490=true := by decide

private def q11Shape25T488 : Tree 11 := .split 9 q11Shape25T489 q11Shape25T490
private theorem q11Shape25T488OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525952 34303115276 q11Shape25T488=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525952 (34303115276 ||| 2^9) q11Shape25T489 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (54525952 ||| 2^9) 34303115276 q11Shape25T490)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T489OK,q11Shape25T490OK⟩

private def q11Shape25T491 : Tree 11 := (.split 10 (.split 16 (.split 4 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {1,2,3,4,5,9})))
private theorem q11Shape25T491OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525960 34303115268 q11Shape25T491=true := by decide

private def q11Shape25T487 : Tree 11 := .split 3 q11Shape25T488 q11Shape25T491
private theorem q11Shape25T487OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525952 34303115268 q11Shape25T487=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525952 (34303115268 ||| 2^3) q11Shape25T488 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (54525952 ||| 2^3) 34303115268 q11Shape25T491)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T488OK,q11Shape25T491OK⟩

private def q11Shape25T494 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,5,8,9,10})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9})))) (.split 15 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {1,5,6,8,9,10}))))
private theorem q11Shape25T494OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525956 34303115784 q11Shape25T494=true := by decide

private def q11Shape25T495 : Tree 11 := (.split 15 (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {1,5,6,8,9,10}))) (.tip (.cover {1,5,6,8,9,10})))
private theorem q11Shape25T495OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54526468 34303115272 q11Shape25T495=true := by decide

private def q11Shape25T493 : Tree 11 := .split 9 q11Shape25T494 q11Shape25T495
private theorem q11Shape25T493OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525956 34303115272 q11Shape25T493=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525956 (34303115272 ||| 2^9) q11Shape25T494 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (54525956 ||| 2^9) 34303115272 q11Shape25T495)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T494OK,q11Shape25T495OK⟩

private def q11Shape25T496 : Tree 11 := (.split 10 (.split 16 (.split 4 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {1,2,3,4,5,9})))
private theorem q11Shape25T496OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525964 34303115264 q11Shape25T496=true := by decide

private def q11Shape25T492 : Tree 11 := .split 3 q11Shape25T493 q11Shape25T496
private theorem q11Shape25T492OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525956 34303115264 q11Shape25T492=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525956 (34303115264 ||| 2^3) q11Shape25T493 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (54525956 ||| 2^3) 34303115264 q11Shape25T496)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T493OK,q11Shape25T496OK⟩

private def q11Shape25T486 : Tree 11 := .split 2 q11Shape25T487 q11Shape25T492
private theorem q11Shape25T486OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525952 34303115264 q11Shape25T486=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 54525952 (34303115264 ||| 2^2) q11Shape25T487 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (54525952 ||| 2^2) 34303115264 q11Shape25T492)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T487OK,q11Shape25T492OK⟩

private def q11Shape25T478 : Tree 11 := .split 25 q11Shape25T479 q11Shape25T486
private theorem q11Shape25T478OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 34303115264 q11Shape25T478=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 (34303115264 ||| 2^25) q11Shape25T479 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (20971520 ||| 2^25) 34303115264 q11Shape25T486)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T479OK,q11Shape25T486OK⟩

private def q11Shape25T497 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T497OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4315938816 30008147968 q11Shape25T497=true := by decide

private def q11Shape25T477 : Tree 11 := .split 32 q11Shape25T478 q11Shape25T497
private theorem q11Shape25T477OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 30008147968 q11Shape25T477=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 (30008147968 ||| 2^32) q11Shape25T478 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (20971520 ||| 2^32) 30008147968 q11Shape25T497)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T478OK,q11Shape25T497OK⟩

private def q11Shape25T498 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T498OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2168455168 27860664320 q11Shape25T498=true := by decide

private def q11Shape25T476 : Tree 11 := .split 31 q11Shape25T477 q11Shape25T498
private theorem q11Shape25T476OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 27860664320 q11Shape25T476=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 (27860664320 ||| 2^31) q11Shape25T477 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (20971520 ||| 2^31) 27860664320 q11Shape25T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T477OK,q11Shape25T498OK⟩

def q11Shape25P32 : Tree 11 := q11Shape25T476
theorem q11Shape25P32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 20971520 27860664320 q11Shape25P32=true := q11Shape25T476OK

private def q11Shape25T500 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T500OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17184063488 10680795136 q11Shape25T500=true := by decide

def q11Shape25P33 : Tree 11 := q11Shape25T500
theorem q11Shape25P33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17184063488 10680795136 q11Shape25P33=true := q11Shape25T500OK

private def q11Shape25T502 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T502OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8594128896 2090860544 q11Shape25T502=true := by decide

def q11Shape25P34 : Tree 11 := q11Shape25T502
theorem q11Shape25P34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8594128896 2090860544 q11Shape25P34=true := q11Shape25T502OK

end Graffiti384b.EffectiveSearch.Q11
