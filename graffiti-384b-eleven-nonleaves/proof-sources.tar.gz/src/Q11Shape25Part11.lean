import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T504 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T504OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 541065216 1553989632 q11Shape25T504=true := by decide

def q11Shape25P35 : Tree 11 := q11Shape25T504
theorem q11Shape25P35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 541065216 1553989632 q11Shape25P35=true := q11Shape25T504OK

private def q11Shape25T506 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T506OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 272629760 1285554176 q11Shape25T506=true := by decide

def q11Shape25P36 : Tree 11 := q11Shape25T506
theorem q11Shape25P36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 272629760 1285554176 q11Shape25P36=true := q11Shape25T506OK

private def q11Shape25T508 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T508OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 138412032 1151336448 q11Shape25T508=true := by decide

def q11Shape25P37 : Tree 11 := q11Shape25T508
theorem q11Shape25P37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 138412032 1151336448 q11Shape25P37=true := q11Shape25T508OK

private def q11Shape25T510 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape25T510OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 71303168 1084227584 q11Shape25T510=true := by decide

def q11Shape25P38 : Tree 11 := q11Shape25T510
theorem q11Shape25P38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 71303168 1084227584 q11Shape25P38=true := q11Shape25T510OK

private def q11Shape25T512 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T512OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 12582912 1075838976 q11Shape25T512=true := by decide

def q11Shape25P39 : Tree 11 := q11Shape25T512
theorem q11Shape25P39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 12582912 1075838976 q11Shape25P39=true := q11Shape25T512OK

private def q11Shape25T532 : Tree 11 := (.split 5 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.split 13 (.split 19 (.tip (.cover {1,2,5,6,7,10})) (.tip (.cover {1,4,5,6,7,10}))) (.tip (.cover {1,3,5,6,7,10}))))))) (.tip (.cover {0,2,3,4,7,9})))
private theorem q11Shape25T532OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 33284298768 q11Shape25T532=true := by decide

private def q11Shape25T533 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape25T533OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741840 33284298752 q11Shape25T533=true := by decide

private def q11Shape25T531 : Tree 11 := .split 4 q11Shape25T532 q11Shape25T533
private theorem q11Shape25T531OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 33284298752 q11Shape25T531=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (33284298752 ||| 2^4) q11Shape25T532 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^4) 33284298752 q11Shape25T533)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T532OK,q11Shape25T533OK⟩

private def q11Shape25T534 : Tree 11 := (.tip (.cover {0,2,3,4,7,9}))
private theorem q11Shape25T534OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1074003968 33284036608 q11Shape25T534=true := by decide

private def q11Shape25T530 : Tree 11 := .split 18 q11Shape25T531 q11Shape25T534
private theorem q11Shape25T530OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 33284036608 q11Shape25T530=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (33284036608 ||| 2^18) q11Shape25T531 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^18) 33284036608 q11Shape25T534)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T531OK,q11Shape25T534OK⟩

private def q11Shape25T535 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape25T535OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073872896 33283905536 q11Shape25T535=true := by decide

private def q11Shape25T529 : Tree 11 := .split 17 q11Shape25T530 q11Shape25T535
private theorem q11Shape25T529OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 33283905536 q11Shape25T529=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (33283905536 ||| 2^17) q11Shape25T530 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^17) 33283905536 q11Shape25T535)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T530OK,q11Shape25T535OK⟩

private def q11Shape25T536 : Tree 11 := (.tip (.cover {0,2,3,4,7,9}))
private theorem q11Shape25T536OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073745920 33283901440 q11Shape25T536=true := by decide

private def q11Shape25T528 : Tree 11 := .split 12 q11Shape25T529 q11Shape25T536
private theorem q11Shape25T528OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 33283901440 q11Shape25T528=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (33283901440 ||| 2^12) q11Shape25T529 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^12) 33283901440 q11Shape25T536)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T529OK,q11Shape25T536OK⟩

private def q11Shape25T537 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape25T537OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073743872 33283899392 q11Shape25T537=true := by decide

private def q11Shape25T527 : Tree 11 := .split 11 q11Shape25T528 q11Shape25T537
private theorem q11Shape25T527OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 33283899392 q11Shape25T527=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (33283899392 ||| 2^11) q11Shape25T528 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^11) 33283899392 q11Shape25T537)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T528OK,q11Shape25T537OK⟩

private def q11Shape25T538 : Tree 11 := (.tip (.cover {0,2,3,4,7,10}))
private theorem q11Shape25T538OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 18253611008 16104030208 q11Shape25T538=true := by decide

private def q11Shape25T526 : Tree 11 := .split 34 q11Shape25T527 q11Shape25T538
private theorem q11Shape25T526OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 16104030208 q11Shape25T526=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (16104030208 ||| 2^34) q11Shape25T527 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^34) 16104030208 q11Shape25T538)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T527OK,q11Shape25T538OK⟩

private def q11Shape25T540 : Tree 11 := (.tip (.cover {0,2,3,4,7,9}))
private theorem q11Shape25T540OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 9663676416 24693964800 q11Shape25T540=true := by decide

private def q11Shape25T544 : Tree 11 := (.split 4 (.split 3 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,6,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,6,8,9})))) (.tip (.cover {0,2,3,4,8,9})))
private theorem q11Shape25T544OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545600 7514228740 q11Shape25T544=true := by decide

private def q11Shape25T545 : Tree 11 := (.split 3 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,2,6,9,10}))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape25T545OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545604 7514228736 q11Shape25T545=true := by decide

private def q11Shape25T543 : Tree 11 := .split 2 q11Shape25T544 q11Shape25T545
private theorem q11Shape25T543OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545600 7514228736 q11Shape25T543=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545600 (7514228736 ||| 2^2) q11Shape25T544 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (26843545600 ||| 2^2) 7514228736 q11Shape25T545)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T544OK,q11Shape25T545OK⟩

private def q11Shape25T546 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape25T546OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843676672 7514097664 q11Shape25T546=true := by decide

private def q11Shape25T542 : Tree 11 := .split 17 q11Shape25T543 q11Shape25T546
private theorem q11Shape25T542OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545600 7514097664 q11Shape25T542=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545600 (7514097664 ||| 2^17) q11Shape25T543 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (26843545600 ||| 2^17) 7514097664 q11Shape25T546)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T543OK,q11Shape25T546OK⟩

private def q11Shape25T547 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape25T547OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843547648 7514095616 q11Shape25T547=true := by decide

private def q11Shape25T541 : Tree 11 := .split 11 q11Shape25T542 q11Shape25T547
private theorem q11Shape25T541OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545600 7514095616 q11Shape25T541=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 26843545600 (7514095616 ||| 2^11) q11Shape25T542 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (26843545600 ||| 2^11) 7514095616 q11Shape25T547)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T542OK,q11Shape25T547OK⟩

private def q11Shape25T539 : Tree 11 := .split 34 q11Shape25T540 q11Shape25T541
private theorem q11Shape25T539OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 9663676416 7514095616 q11Shape25T539=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 9663676416 (7514095616 ||| 2^34) q11Shape25T540 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (9663676416 ||| 2^34) 7514095616 q11Shape25T541)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T540OK,q11Shape25T541OK⟩

private def q11Shape25T525 : Tree 11 := .split 33 q11Shape25T526 q11Shape25T539
private theorem q11Shape25T525OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 7514095616 q11Shape25T525=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (7514095616 ||| 2^33) q11Shape25T526 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^33) 7514095616 q11Shape25T539)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T526OK,q11Shape25T539OK⟩

private def q11Shape25T548 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape25T548OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 5368709120 3219128320 q11Shape25T548=true := by decide

private def q11Shape25T524 : Tree 11 := .split 32 q11Shape25T525 q11Shape25T548
private theorem q11Shape25T524OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 3219128320 q11Shape25T524=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (3219128320 ||| 2^32) q11Shape25T525 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^32) 3219128320 q11Shape25T548)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T525OK,q11Shape25T548OK⟩

private def q11Shape25T550 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape25T550OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 3221225472 5366611968 q11Shape25T550=true := by decide

private def q11Shape25T555 : Tree 11 := (.split 18 (.split 3 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,2,3,4,7,9}))) (.split 5 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,2,5,9,10})))) (.tip (.cover {0,2,3,4,7,9})))
private theorem q11Shape25T555OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 26841452548 q11Shape25T555=true := by decide

private def q11Shape25T556 : Tree 11 := (.split 3 (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,2,6,9,10}))) (.tip (.cover {0,2,3,4,7,9}))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape25T556OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192772 26841452544 q11Shape25T556=true := by decide

private def q11Shape25T554 : Tree 11 := .split 2 q11Shape25T555 q11Shape25T556
private theorem q11Shape25T554OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 26841452544 q11Shape25T554=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 (26841452544 ||| 2^2) q11Shape25T555 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (7516192768 ||| 2^2) 26841452544 q11Shape25T556)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T555OK,q11Shape25T556OK⟩

private def q11Shape25T557 : Tree 11 := (.tip (.cover {0,2,3,4,7,9}))
private theorem q11Shape25T557OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516196864 26841448448 q11Shape25T557=true := by decide

private def q11Shape25T553 : Tree 11 := .split 12 q11Shape25T554 q11Shape25T557
private theorem q11Shape25T553OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 26841448448 q11Shape25T553=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 (26841448448 ||| 2^12) q11Shape25T554 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (7516192768 ||| 2^12) 26841448448 q11Shape25T557)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T554OK,q11Shape25T557OK⟩

private def q11Shape25T558 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T558OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 24696061952 9661579264 q11Shape25T558=true := by decide

private def q11Shape25T552 : Tree 11 := .split 34 q11Shape25T553 q11Shape25T558
private theorem q11Shape25T552OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 9661579264 q11Shape25T552=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 (9661579264 ||| 2^34) q11Shape25T553 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (7516192768 ||| 2^34) 9661579264 q11Shape25T558)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T553OK,q11Shape25T558OK⟩

private def q11Shape25T559 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T559OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 16106127360 1071644672 q11Shape25T559=true := by decide

private def q11Shape25T551 : Tree 11 := .split 33 q11Shape25T552 q11Shape25T559
private theorem q11Shape25T551OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 1071644672 q11Shape25T551=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 7516192768 (1071644672 ||| 2^33) q11Shape25T552 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (7516192768 ||| 2^33) 1071644672 q11Shape25T559)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T552OK,q11Shape25T559OK⟩

private def q11Shape25T549 : Tree 11 := .split 32 q11Shape25T550 q11Shape25T551
private theorem q11Shape25T549OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 3221225472 1071644672 q11Shape25T549=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 3221225472 (1071644672 ||| 2^32) q11Shape25T550 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (3221225472 ||| 2^32) 1071644672 q11Shape25T551)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T550OK,q11Shape25T551OK⟩

private def q11Shape25T523 : Tree 11 := .split 31 q11Shape25T524 q11Shape25T549
private theorem q11Shape25T523OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 1071644672 q11Shape25T523=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (1071644672 ||| 2^31) q11Shape25T524 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^31) 1071644672 q11Shape25T549)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T524OK,q11Shape25T549OK⟩

private def q11Shape25T560 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T560OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1610612736 534773760 q11Shape25T560=true := by decide

private def q11Shape25T522 : Tree 11 := .split 29 q11Shape25T523 q11Shape25T560
private theorem q11Shape25T522OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 534773760 q11Shape25T522=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (534773760 ||| 2^29) q11Shape25T523 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^29) 534773760 q11Shape25T560)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T523OK,q11Shape25T560OK⟩

private def q11Shape25T561 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T561OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1342177280 266338304 q11Shape25T561=true := by decide

private def q11Shape25T521 : Tree 11 := .split 28 q11Shape25T522 q11Shape25T561
private theorem q11Shape25T521OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 266338304 q11Shape25T521=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (266338304 ||| 2^28) q11Shape25T522 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^28) 266338304 q11Shape25T561)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T522OK,q11Shape25T561OK⟩

private def q11Shape25T562 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T562OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1107296256 232783872 q11Shape25T562=true := by decide

private def q11Shape25T520 : Tree 11 := .split 25 q11Shape25T521 q11Shape25T562
private theorem q11Shape25T520OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 232783872 q11Shape25T520=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (232783872 ||| 2^25) q11Shape25T521 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^25) 232783872 q11Shape25T562)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T521OK,q11Shape25T562OK⟩

private def q11Shape25T563 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T563OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1090519040 216006656 q11Shape25T563=true := by decide

private def q11Shape25T519 : Tree 11 := .split 24 q11Shape25T520 q11Shape25T563
private theorem q11Shape25T519OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 216006656 q11Shape25T519=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (216006656 ||| 2^24) q11Shape25T520 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^24) 216006656 q11Shape25T563)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T520OK,q11Shape25T563OK⟩

private def q11Shape25T564 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T564OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1207959552 81788928 q11Shape25T564=true := by decide

private def q11Shape25T518 : Tree 11 := .split 27 q11Shape25T519 q11Shape25T564
private theorem q11Shape25T518OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 81788928 q11Shape25T518=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (81788928 ||| 2^27) q11Shape25T519 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^27) 81788928 q11Shape25T564)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T519OK,q11Shape25T564OK⟩

private def q11Shape25T565 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T565OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1140850688 14680064 q11Shape25T565=true := by decide

private def q11Shape25T517 : Tree 11 := .split 26 q11Shape25T518 q11Shape25T565
private theorem q11Shape25T517OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 14680064 q11Shape25T517=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (14680064 ||| 2^26) q11Shape25T518 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^26) 14680064 q11Shape25T565)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T518OK,q11Shape25T565OK⟩

private def q11Shape25T566 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T566OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1082130432 6291456 q11Shape25T566=true := by decide

private def q11Shape25T516 : Tree 11 := .split 23 q11Shape25T517 q11Shape25T566
private theorem q11Shape25T516OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 6291456 q11Shape25T516=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (6291456 ||| 2^23) q11Shape25T517 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^23) 6291456 q11Shape25T566)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T517OK,q11Shape25T566OK⟩

private def q11Shape25T567 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T567OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1077936128 2097152 q11Shape25T567=true := by decide

private def q11Shape25T515 : Tree 11 := .split 22 q11Shape25T516 q11Shape25T567
private theorem q11Shape25T515OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 2097152 q11Shape25T515=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 (2097152 ||| 2^22) q11Shape25T516 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (1073741824 ||| 2^22) 2097152 q11Shape25T567)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T516OK,q11Shape25T567OK⟩

def q11Shape25P40 : Tree 11 := q11Shape25T515
theorem q11Shape25P40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1073741824 2097152 q11Shape25P40=true := q11Shape25T515OK

end Graffiti384b.EffectiveSearch.Q11
