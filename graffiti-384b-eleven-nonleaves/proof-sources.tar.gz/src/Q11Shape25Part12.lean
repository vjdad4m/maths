import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T587 : Tree 11 := (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.split 13 (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.tip (.cover {0,4,5,7,8,10}))) (.tip (.cover {0,3,5,7,8,10}))))))) (.tip (.cover {1,2,3,4,5,9})))
private theorem q11Shape25T587OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 34355578380 q11Shape25T587=true := by decide

private def q11Shape25T588 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T588OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2098176 34355577356 q11Shape25T588=true := by decide

private def q11Shape25T586 : Tree 11 := .split 10 q11Shape25T587 q11Shape25T588
private theorem q11Shape25T586OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 34355577356 q11Shape25T586=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (34355577356 ||| 2^10) q11Shape25T587 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^10) 34355577356 q11Shape25T588)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T587OK,q11Shape25T588OK⟩

private def q11Shape25T589 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T589OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097160 34355577348 q11Shape25T589=true := by decide

private def q11Shape25T585 : Tree 11 := .split 3 q11Shape25T586 q11Shape25T589
private theorem q11Shape25T585OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 34355577348 q11Shape25T585=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (34355577348 ||| 2^3) q11Shape25T586 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^3) 34355577348 q11Shape25T589)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T586OK,q11Shape25T589OK⟩

private def q11Shape25T590 : Tree 11 := (.tip (.cover {1,2,3,4,5,10}))
private theorem q11Shape25T590OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 538968064 33818706436 q11Shape25T590=true := by decide

private def q11Shape25T584 : Tree 11 := .split 29 q11Shape25T585 q11Shape25T590
private theorem q11Shape25T584OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 33818706436 q11Shape25T584=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (33818706436 ||| 2^29) q11Shape25T585 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^29) 33818706436 q11Shape25T590)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T585OK,q11Shape25T590OK⟩

private def q11Shape25T592 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T592OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 270532608 34087141892 q11Shape25T592=true := by decide

private def q11Shape25T593 : Tree 11 := (.split 3 (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,6,7,8,9}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,6,7,8,9})))) (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,6,7,8,9}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,6,7,8,9})))))
private theorem q11Shape25T593OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 807403520 33550270980 q11Shape25T593=true := by decide

private def q11Shape25T591 : Tree 11 := .split 29 q11Shape25T592 q11Shape25T593
private theorem q11Shape25T591OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 270532608 33550270980 q11Shape25T591=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 270532608 (33550270980 ||| 2^29) q11Shape25T592 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (270532608 ||| 2^29) 33550270980 q11Shape25T593)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T592OK,q11Shape25T593OK⟩

private def q11Shape25T583 : Tree 11 := .split 28 q11Shape25T584 q11Shape25T591
private theorem q11Shape25T583OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 33550270980 q11Shape25T583=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (33550270980 ||| 2^28) q11Shape25T584 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^28) 33550270980 q11Shape25T591)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T584OK,q11Shape25T591OK⟩

private def q11Shape25T594 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T594OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2129920 33550238212 q11Shape25T594=true := by decide

private def q11Shape25T582 : Tree 11 := .split 15 q11Shape25T583 q11Shape25T594
private theorem q11Shape25T582OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 33550238212 q11Shape25T582=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (33550238212 ||| 2^15) q11Shape25T583 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^15) 33550238212 q11Shape25T594)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T583OK,q11Shape25T594OK⟩

private def q11Shape25T595 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T595OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097664 33550237700 q11Shape25T595=true := by decide

private def q11Shape25T581 : Tree 11 := .split 9 q11Shape25T582 q11Shape25T595
private theorem q11Shape25T581OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 33550237700 q11Shape25T581=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (33550237700 ||| 2^9) q11Shape25T582 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^9) 33550237700 q11Shape25T595)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T582OK,q11Shape25T595OK⟩

private def q11Shape25T596 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T596OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097156 33550237696 q11Shape25T596=true := by decide

private def q11Shape25T580 : Tree 11 := .split 2 q11Shape25T581 q11Shape25T596
private theorem q11Shape25T580OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 33550237696 q11Shape25T580=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (33550237696 ||| 2^2) q11Shape25T581 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^2) 33550237696 q11Shape25T596)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T581OK,q11Shape25T596OK⟩

private def q11Shape25T597 : Tree 11 := (.tip (.cover {1,2,3,4,6,10}))
private theorem q11Shape25T597OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 35651584 33516683264 q11Shape25T597=true := by decide

private def q11Shape25T579 : Tree 11 := .split 25 q11Shape25T580 q11Shape25T597
private theorem q11Shape25T579OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 33516683264 q11Shape25T579=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (33516683264 ||| 2^25) q11Shape25T580 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^25) 33516683264 q11Shape25T597)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T580OK,q11Shape25T597OK⟩

private def q11Shape25T599 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T599OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 18874368 33533460480 q11Shape25T599=true := by decide

private def q11Shape25T605 : Tree 11 := (.split 2 (.split 9 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,8,9}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,8,9})))) (.split 9 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,8,9}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,8,9})))))
private theorem q11Shape25T605OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 34305278984 q11Shape25T605=true := by decide

private def q11Shape25T606 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T606OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52494336 34305213448 q11Shape25T606=true := by decide

private def q11Shape25T604 : Tree 11 := .split 16 q11Shape25T605 q11Shape25T606
private theorem q11Shape25T604OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 34305213448 q11Shape25T604=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 (34305213448 ||| 2^16) q11Shape25T605 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (52428800 ||| 2^16) 34305213448 q11Shape25T606)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T605OK,q11Shape25T606OK⟩

private def q11Shape25T607 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T607OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52429824 34305212424 q11Shape25T607=true := by decide

private def q11Shape25T603 : Tree 11 := .split 10 q11Shape25T604 q11Shape25T607
private theorem q11Shape25T603OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 34305212424 q11Shape25T603=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 (34305212424 ||| 2^10) q11Shape25T604 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (52428800 ||| 2^10) 34305212424 q11Shape25T607)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T604OK,q11Shape25T607OK⟩

private def q11Shape25T608 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T608OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428808 34305212416 q11Shape25T608=true := by decide

private def q11Shape25T602 : Tree 11 := .split 3 q11Shape25T603 q11Shape25T608
private theorem q11Shape25T602OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 34305212416 q11Shape25T602=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 (34305212416 ||| 2^3) q11Shape25T603 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (52428800 ||| 2^3) 34305212416 q11Shape25T608)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T603OK,q11Shape25T608OK⟩

private def q11Shape25T609 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape25T609OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 589299712 33768341504 q11Shape25T609=true := by decide

private def q11Shape25T601 : Tree 11 := .split 29 q11Shape25T602 q11Shape25T609
private theorem q11Shape25T601OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 33768341504 q11Shape25T601=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 (33768341504 ||| 2^29) q11Shape25T602 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (52428800 ||| 2^29) 33768341504 q11Shape25T609)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T602OK,q11Shape25T609OK⟩

private def q11Shape25T610 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape25T610OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 320864256 33499906048 q11Shape25T610=true := by decide

private def q11Shape25T600 : Tree 11 := .split 28 q11Shape25T601 q11Shape25T610
private theorem q11Shape25T600OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 33499906048 q11Shape25T600=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 52428800 (33499906048 ||| 2^28) q11Shape25T601 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (52428800 ||| 2^28) 33499906048 q11Shape25T610)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T601OK,q11Shape25T610OK⟩

private def q11Shape25T598 : Tree 11 := .split 25 q11Shape25T599 q11Shape25T600
private theorem q11Shape25T598OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 18874368 33499906048 q11Shape25T598=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 18874368 (33499906048 ||| 2^25) q11Shape25T599 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (18874368 ||| 2^25) 33499906048 q11Shape25T600)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T599OK,q11Shape25T600OK⟩

private def q11Shape25T578 : Tree 11 := .split 24 q11Shape25T579 q11Shape25T598
private theorem q11Shape25T578OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 33499906048 q11Shape25T578=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (33499906048 ||| 2^24) q11Shape25T579 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^24) 33499906048 q11Shape25T598)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T579OK,q11Shape25T598OK⟩

private def q11Shape25T611 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T611OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17181966336 16320036864 q11Shape25T611=true := by decide

private def q11Shape25T577 : Tree 11 := .split 34 q11Shape25T578 q11Shape25T611
private theorem q11Shape25T577OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 16320036864 q11Shape25T577=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (16320036864 ||| 2^34) q11Shape25T578 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^34) 16320036864 q11Shape25T611)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T578OK,q11Shape25T611OK⟩

private def q11Shape25T612 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T612OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8592031744 7730102272 q11Shape25T612=true := by decide

private def q11Shape25T576 : Tree 11 := .split 33 q11Shape25T577 q11Shape25T612
private theorem q11Shape25T576OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 7730102272 q11Shape25T576=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (7730102272 ||| 2^33) q11Shape25T577 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^33) 7730102272 q11Shape25T612)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T577OK,q11Shape25T612OK⟩

private def q11Shape25T613 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T613OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4297064448 3435134976 q11Shape25T613=true := by decide

private def q11Shape25T575 : Tree 11 := .split 32 q11Shape25T576 q11Shape25T613
private theorem q11Shape25T575OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 3435134976 q11Shape25T575=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (3435134976 ||| 2^32) q11Shape25T576 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^32) 3435134976 q11Shape25T613)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T576OK,q11Shape25T613OK⟩

private def q11Shape25T614 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T614OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2149580800 1287651328 q11Shape25T614=true := by decide

private def q11Shape25T574 : Tree 11 := .split 31 q11Shape25T575 q11Shape25T614
private theorem q11Shape25T574OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 1287651328 q11Shape25T574=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (1287651328 ||| 2^31) q11Shape25T575 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^31) 1287651328 q11Shape25T614)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T575OK,q11Shape25T614OK⟩

private def q11Shape25T615 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T615OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 136314880 1153433600 q11Shape25T615=true := by decide

private def q11Shape25T573 : Tree 11 := .split 27 q11Shape25T574 q11Shape25T615
private theorem q11Shape25T573OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 1153433600 q11Shape25T573=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (1153433600 ||| 2^27) q11Shape25T574 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^27) 1153433600 q11Shape25T615)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T574OK,q11Shape25T615OK⟩

private def q11Shape25T616 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T616OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 69206016 1086324736 q11Shape25T616=true := by decide

private def q11Shape25T572 : Tree 11 := .split 26 q11Shape25T573 q11Shape25T616
private theorem q11Shape25T572OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 1086324736 q11Shape25T572=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (1086324736 ||| 2^26) q11Shape25T573 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^26) 1086324736 q11Shape25T616)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T573OK,q11Shape25T616OK⟩

private def q11Shape25T617 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T617OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 10485760 1077936128 q11Shape25T617=true := by decide

private def q11Shape25T571 : Tree 11 := .split 23 q11Shape25T572 q11Shape25T617
private theorem q11Shape25T571OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 1077936128 q11Shape25T571=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (1077936128 ||| 2^23) q11Shape25T572 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^23) 1077936128 q11Shape25T617)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T572OK,q11Shape25T617OK⟩

private def q11Shape25T618 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T618OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6291456 1073741824 q11Shape25T618=true := by decide

private def q11Shape25T570 : Tree 11 := .split 22 q11Shape25T571 q11Shape25T618
private theorem q11Shape25T570OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 1073741824 q11Shape25T570=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (1073741824 ||| 2^22) q11Shape25T571 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^22) 1073741824 q11Shape25T618)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T571OK,q11Shape25T618OK⟩

private def q11Shape25T619 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T619OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 1075838976 0 q11Shape25T619=true := by decide

private def q11Shape25T569 : Tree 11 := .split 30 q11Shape25T570 q11Shape25T619
private theorem q11Shape25T569OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 0 q11Shape25T569=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 (0 ||| 2^30) q11Shape25T570 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2097152 ||| 2^30) 0 q11Shape25T619)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T570OK,q11Shape25T619OK⟩

def q11Shape25P41 : Tree 11 := q11Shape25T569
theorem q11Shape25P41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2097152 0 q11Shape25P41=true := q11Shape25T569OK

end Graffiti384b.EffectiveSearch.Q11
