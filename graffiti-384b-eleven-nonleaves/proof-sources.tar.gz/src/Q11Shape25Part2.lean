import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T74 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 34223456780 q11Shape25T74=true := by decide

private def q11Shape25T77 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134250496 68583293452 q11Shape25T77=true := by decide

private def q11Shape25T79 : Tree 11 := (.split 16 (.split 0 (.tip (.small 0)) (.split 11 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {1,3,5,6,9,10})))) (.split 12 (.split 18 (.split 5 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493988864 34223556108 q11Shape25T79=true := by decide

private def q11Shape25T80 : Tree 11 := (.split 11 (.tip (.cover {1,2,5,6,9,10})) (.split 12 (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10}))) (.tip (.cover {0,1,3,5,9,10}))))
private theorem q11Shape25T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493989888 34223555084 q11Shape25T80=true := by decide

private def q11Shape25T78 : Tree 11 := .split 10 q11Shape25T79 q11Shape25T80
private theorem q11Shape25T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493988864 34223555084 q11Shape25T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493988864 (34223555084 ||| 2^10) q11Shape25T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34493988864 ||| 2^10) 34223555084 q11Shape25T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T79OK,q11Shape25T80OK⟩

private def q11Shape25T76 : Tree 11 := .split 35 q11Shape25T77 q11Shape25T78
private theorem q11Shape25T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134250496 34223555084 q11Shape25T76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134250496 (34223555084 ||| 2^35) q11Shape25T77 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134250496 ||| 2^35) 34223555084 q11Shape25T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T77OK,q11Shape25T78OK⟩

private def q11Shape25T81 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape25T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134381568 34223424012 q11Shape25T81=true := by decide

private def q11Shape25T75 : Tree 11 := .split 17 q11Shape25T76 q11Shape25T81
private theorem q11Shape25T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134250496 34223424012 q11Shape25T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134250496 (34223424012 ||| 2^17) q11Shape25T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134250496 ||| 2^17) 34223424012 q11Shape25T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T76OK,q11Shape25T81OK⟩

private def q11Shape25T73 : Tree 11 := .split 15 q11Shape25T74 q11Shape25T75
private theorem q11Shape25T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 34223424012 q11Shape25T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (34223424012 ||| 2^15) q11Shape25T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^15) 34223424012 q11Shape25T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T74OK,q11Shape25T75OK⟩

private def q11Shape25T85 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218240 68583196684 q11Shape25T85=true := by decide

private def q11Shape25T87 : Tree 11 := (.split 16 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,6,7,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956608 34223459340 q11Shape25T87=true := by decide

private def q11Shape25T88 : Tree 11 := (.split 12 (.split 18 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,6,7,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape25T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493957632 34223458316 q11Shape25T88=true := by decide

private def q11Shape25T86 : Tree 11 := .split 10 q11Shape25T87 q11Shape25T88
private theorem q11Shape25T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956608 34223458316 q11Shape25T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956608 (34223458316 ||| 2^10) q11Shape25T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34493956608 ||| 2^10) 34223458316 q11Shape25T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T87OK,q11Shape25T88OK⟩

private def q11Shape25T84 : Tree 11 := .split 35 q11Shape25T85 q11Shape25T86
private theorem q11Shape25T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218240 34223458316 q11Shape25T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218240 (34223458316 ||| 2^35) q11Shape25T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134218240 ||| 2^35) 34223458316 q11Shape25T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T85OK,q11Shape25T86OK⟩

private def q11Shape25T89 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape25T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134220288 34223456268 q11Shape25T89=true := by decide

private def q11Shape25T83 : Tree 11 := .split 11 q11Shape25T84 q11Shape25T89
private theorem q11Shape25T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218240 34223456268 q11Shape25T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218240 (34223456268 ||| 2^11) q11Shape25T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134218240 ||| 2^11) 34223456268 q11Shape25T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T84OK,q11Shape25T89OK⟩

private def q11Shape25T90 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134251008 34223423500 q11Shape25T90=true := by decide

private def q11Shape25T82 : Tree 11 := .split 15 q11Shape25T83 q11Shape25T90
private theorem q11Shape25T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218240 34223423500 q11Shape25T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218240 (34223423500 ||| 2^15) q11Shape25T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134218240 ||| 2^15) 34223423500 q11Shape25T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T83OK,q11Shape25T90OK⟩

private def q11Shape25T72 : Tree 11 := .split 9 q11Shape25T73 q11Shape25T82
private theorem q11Shape25T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 34223423500 q11Shape25T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (34223423500 ||| 2^9) q11Shape25T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^9) 34223423500 q11Shape25T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T73OK,q11Shape25T82OK⟩

private def q11Shape25T95 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape25T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 68583428132 q11Shape25T95=true := by decide

private def q11Shape25T97 : Tree 11 := (.split 15 (.tip (.cover {0,1,6,7,9,10})) (.split 10 (.split 11 (.split 13 (.tip (.cover {0,1,2,4,6,10})) (.tip (.cover {1,3,5,6,7,10}))) (.tip (.cover {1,3,5,6,9,10}))) (.tip (.cover {1,5,6,7,9,10}))))
private theorem q11Shape25T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956104 34223690276 q11Shape25T97=true := by decide

private def q11Shape25T98 : Tree 11 := (.split 15 (.split 16 (.split 11 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,6,7,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956616 34223689764 q11Shape25T98=true := by decide

private def q11Shape25T96 : Tree 11 := .split 9 q11Shape25T97 q11Shape25T98
private theorem q11Shape25T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956104 34223689764 q11Shape25T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956104 (34223689764 ||| 2^9) q11Shape25T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34493956104 ||| 2^9) 34223689764 q11Shape25T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T97OK,q11Shape25T98OK⟩

private def q11Shape25T94 : Tree 11 := .split 35 q11Shape25T95 q11Shape25T96
private theorem q11Shape25T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 34223689764 q11Shape25T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 (34223689764 ||| 2^35) q11Shape25T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217736 ||| 2^35) 34223689764 q11Shape25T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T95OK,q11Shape25T96OK⟩

private def q11Shape25T99 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217768 34223689732 q11Shape25T99=true := by decide

private def q11Shape25T93 : Tree 11 := .split 5 q11Shape25T94 q11Shape25T99
private theorem q11Shape25T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 34223689732 q11Shape25T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 (34223689732 ||| 2^5) q11Shape25T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217736 ||| 2^5) 34223689732 q11Shape25T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T94OK,q11Shape25T99OK⟩

private def q11Shape25T100 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134479880 34223427588 q11Shape25T100=true := by decide

private def q11Shape25T92 : Tree 11 := .split 18 q11Shape25T93 q11Shape25T100
private theorem q11Shape25T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 34223427588 q11Shape25T92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 (34223427588 ||| 2^18) q11Shape25T93 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217736 ||| 2^18) 34223427588 q11Shape25T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T93OK,q11Shape25T100OK⟩

private def q11Shape25T101 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134221832 34223423492 q11Shape25T101=true := by decide

private def q11Shape25T91 : Tree 11 := .split 12 q11Shape25T92 q11Shape25T101
private theorem q11Shape25T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 34223423492 q11Shape25T91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217736 (34223423492 ||| 2^12) q11Shape25T92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217736 ||| 2^12) 34223423492 q11Shape25T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T92OK,q11Shape25T101OK⟩

private def q11Shape25T71 : Tree 11 := .split 3 q11Shape25T72 q11Shape25T91
private theorem q11Shape25T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 34223423492 q11Shape25T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (34223423492 ||| 2^3) q11Shape25T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^3) 34223423492 q11Shape25T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T72OK,q11Shape25T91OK⟩

private def q11Shape25T107 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 68583195160 q11Shape25T107=true := by decide

private def q11Shape25T109 : Tree 11 := (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {0,1,2,4,6,10})) (.tip (.cover {1,3,4,5,6,10}))) (.tip (.cover {1,3,5,6,9,10}))))
private theorem q11Shape25T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956100 34223457816 q11Shape25T109=true := by decide

private def q11Shape25T110 : Tree 11 := (.split 16 (.split 11 (.tip (.cover {1,4,5,6,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10})))) (.tip (.cover {1,5,6,7,9,10})))
private theorem q11Shape25T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493957124 34223456792 q11Shape25T110=true := by decide

private def q11Shape25T108 : Tree 11 := .split 10 q11Shape25T109 q11Shape25T110
private theorem q11Shape25T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956100 34223456792 q11Shape25T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34493956100 (34223456792 ||| 2^10) q11Shape25T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34493956100 ||| 2^10) 34223456792 q11Shape25T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T109OK,q11Shape25T110OK⟩

private def q11Shape25T106 : Tree 11 := .split 35 q11Shape25T107 q11Shape25T108
private theorem q11Shape25T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 34223456792 q11Shape25T106=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 (34223456792 ||| 2^35) q11Shape25T107 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217732 ||| 2^35) 34223456792 q11Shape25T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T107OK,q11Shape25T108OK⟩

private def q11Shape25T111 : Tree 11 := (.split 12 (.split 18 (.split 5 (.split 35 (.tip (.cover {2,3,4,5,7,8})) (.split 13 (.split 11 (.tip (.cover {0,1,2,4,6,10})) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {1,3,4,5,6,10})))) (.tip (.cover {0,1,2,7,9,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217740 34223456784 q11Shape25T111=true := by decide

private def q11Shape25T105 : Tree 11 := .split 3 q11Shape25T106 q11Shape25T111
private theorem q11Shape25T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 34223456784 q11Shape25T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 (34223456784 ||| 2^3) q11Shape25T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217732 ||| 2^3) 34223456784 q11Shape25T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T106OK,q11Shape25T111OK⟩

private def q11Shape25T112 : Tree 11 := (.tip (.cover {0,1,2,6,9,10}))
private theorem q11Shape25T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217748 34223456768 q11Shape25T112=true := by decide

private def q11Shape25T104 : Tree 11 := .split 4 q11Shape25T105 q11Shape25T112
private theorem q11Shape25T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 34223456768 q11Shape25T104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 (34223456768 ||| 2^4) q11Shape25T105 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217732 ||| 2^4) 34223456768 q11Shape25T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T105OK,q11Shape25T112OK⟩

private def q11Shape25T113 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134250500 34223424000 q11Shape25T113=true := by decide

private def q11Shape25T103 : Tree 11 := .split 15 q11Shape25T104 q11Shape25T113
private theorem q11Shape25T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 34223424000 q11Shape25T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 (34223424000 ||| 2^15) q11Shape25T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217732 ||| 2^15) 34223424000 q11Shape25T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T104OK,q11Shape25T113OK⟩

private def q11Shape25T114 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134218244 34223423488 q11Shape25T114=true := by decide

private def q11Shape25T102 : Tree 11 := .split 9 q11Shape25T103 q11Shape25T114
private theorem q11Shape25T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 34223423488 q11Shape25T102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217732 (34223423488 ||| 2^9) q11Shape25T103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217732 ||| 2^9) 34223423488 q11Shape25T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T103OK,q11Shape25T114OK⟩

private def q11Shape25T70 : Tree 11 := .split 2 q11Shape25T71 q11Shape25T102
private theorem q11Shape25T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 34223423488 q11Shape25T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (34223423488 ||| 2^2) q11Shape25T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^2) 34223423488 q11Shape25T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T71OK,q11Shape25T102OK⟩

private def q11Shape25T117 : Tree 11 := (.split 16 (.split 2 (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9})))) (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,10})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17314086912 17043555336 q11Shape25T117=true := by decide

private def q11Shape25T118 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17314087936 17043554312 q11Shape25T118=true := by decide

private def q11Shape25T116 : Tree 11 := .split 10 q11Shape25T117 q11Shape25T118
private theorem q11Shape25T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17314086912 17043554312 q11Shape25T116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17314086912 (17043554312 ||| 2^10) q11Shape25T117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (17314086912 ||| 2^10) 17043554312 q11Shape25T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T117OK,q11Shape25T118OK⟩

private def q11Shape25T119 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17314086920 17043554304 q11Shape25T119=true := by decide

private def q11Shape25T115 : Tree 11 := .split 3 q11Shape25T116 q11Shape25T119
private theorem q11Shape25T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17314086912 17043554304 q11Shape25T115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17314086912 (17043554304 ||| 2^3) q11Shape25T116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (17314086912 ||| 2^3) 17043554304 q11Shape25T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T116OK,q11Shape25T119OK⟩

private def q11Shape25T69 : Tree 11 := .split 34 q11Shape25T70 q11Shape25T115
private theorem q11Shape25T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 17043554304 q11Shape25T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 (17043554304 ||| 2^34) q11Shape25T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (134217728 ||| 2^34) 17043554304 q11Shape25T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T70OK,q11Shape25T115OK⟩

def q11Shape25P2 : Tree 11 := q11Shape25T69
theorem q11Shape25P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 134217728 17043554304 q11Shape25P2=true := q11Shape25T69OK

end Graffiti384b.EffectiveSearch.Q11
