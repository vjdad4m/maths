import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T123 : Tree 11 := (.split 16 (.split 2 (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10})))) (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,6,7,9})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 25633489928 q11Shape25T123=true := by decide

private def q11Shape25T124 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724153344 25633488904 q11Shape25T124=true := by decide

private def q11Shape25T122 : Tree 11 := .split 10 q11Shape25T123 q11Shape25T124
private theorem q11Shape25T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 25633488904 q11Shape25T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 (25633488904 ||| 2^10) q11Shape25T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8724152320 ||| 2^10) 25633488904 q11Shape25T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T123OK,q11Shape25T124OK⟩

private def q11Shape25T125 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152328 25633488896 q11Shape25T125=true := by decide

private def q11Shape25T121 : Tree 11 := .split 3 q11Shape25T122 q11Shape25T125
private theorem q11Shape25T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 25633488896 q11Shape25T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 (25633488896 ||| 2^3) q11Shape25T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8724152320 ||| 2^3) 25633488896 q11Shape25T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T122OK,q11Shape25T125OK⟩

private def q11Shape25T128 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,6,7,9,10})) (.split 16 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,4,7,9,10})))) (.split 10 (.split 11 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,1,3,7,9,10}))))
private theorem q11Shape25T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021504 8453619724 q11Shape25T128=true := by decide

private def q11Shape25T129 : Tree 11 := (.split 9 (.split 11 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,2,4,7,9,10}))) (.split 17 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,7,9,10}))))
private theorem q11Shape25T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021512 8453619716 q11Shape25T129=true := by decide

private def q11Shape25T127 : Tree 11 := .split 3 q11Shape25T128 q11Shape25T129
private theorem q11Shape25T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021504 8453619716 q11Shape25T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021504 (8453619716 ||| 2^3) q11Shape25T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25904021504 ||| 2^3) 8453619716 q11Shape25T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T128OK,q11Shape25T129OK⟩

private def q11Shape25T132 : Tree 11 := (.split 4 (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.split 11 (.tip (.cover {1,4,5,6,9,10})) (.tip (.cover {0,1,3,5,9,10})))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape25T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021508 8453620232 q11Shape25T132=true := by decide

private def q11Shape25T133 : Tree 11 := (.split 10 (.split 15 (.split 35 (.tip (.cover {2,3,4,6,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,1,3,7,9,10})))
private theorem q11Shape25T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904022020 8453619720 q11Shape25T133=true := by decide

private def q11Shape25T131 : Tree 11 := .split 9 q11Shape25T132 q11Shape25T133
private theorem q11Shape25T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021508 8453619720 q11Shape25T131=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021508 (8453619720 ||| 2^9) q11Shape25T132 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25904021508 ||| 2^9) 8453619720 q11Shape25T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T132OK,q11Shape25T133OK⟩

private def q11Shape25T134 : Tree 11 := (.tip (.cover {0,1,2,7,9,10}))
private theorem q11Shape25T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021516 8453619712 q11Shape25T134=true := by decide

private def q11Shape25T130 : Tree 11 := .split 3 q11Shape25T131 q11Shape25T134
private theorem q11Shape25T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021508 8453619712 q11Shape25T130=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021508 (8453619712 ||| 2^3) q11Shape25T131 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25904021508 ||| 2^3) 8453619712 q11Shape25T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T131OK,q11Shape25T134OK⟩

private def q11Shape25T126 : Tree 11 := .split 2 q11Shape25T127 q11Shape25T130
private theorem q11Shape25T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021504 8453619712 q11Shape25T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25904021504 (8453619712 ||| 2^2) q11Shape25T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25904021504 ||| 2^2) 8453619712 q11Shape25T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T127OK,q11Shape25T130OK⟩

private def q11Shape25T120 : Tree 11 := .split 34 q11Shape25T121 q11Shape25T126
private theorem q11Shape25T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 8453619712 q11Shape25T120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 (8453619712 ||| 2^34) q11Shape25T121 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8724152320 ||| 2^34) 8453619712 q11Shape25T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T121OK,q11Shape25T126OK⟩

def q11Shape25P3 : Tree 11 := q11Shape25T120
theorem q11Shape25P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8724152320 8453619712 q11Shape25P3=true := q11Shape25T120OK

private def q11Shape25T140 : Tree 11 := (.split 18 (.split 3 (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,2,3,4,10}))) (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,2,3,4,5,10})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 33686556676 q11Shape25T140=true := by decide

private def q11Shape25T141 : Tree 11 := (.split 9 (.split 15 (.split 18 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,2,3,4,10}))) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,7,8,10})))
private theorem q11Shape25T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088644 33686556672 q11Shape25T141=true := by decide

private def q11Shape25T139 : Tree 11 := .split 2 q11Shape25T140 q11Shape25T141
private theorem q11Shape25T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 33686556672 q11Shape25T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 (33686556672 ||| 2^2) q11Shape25T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (671088640 ||| 2^2) 33686556672 q11Shape25T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T140OK,q11Shape25T141OK⟩

private def q11Shape25T142 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671092736 33686552576 q11Shape25T142=true := by decide

private def q11Shape25T138 : Tree 11 := .split 12 q11Shape25T139 q11Shape25T142
private theorem q11Shape25T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 33686552576 q11Shape25T138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 (33686552576 ||| 2^12) q11Shape25T139 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (671088640 ||| 2^12) 33686552576 q11Shape25T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T139OK,q11Shape25T142OK⟩

private def q11Shape25T143 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17850957824 16506683392 q11Shape25T143=true := by decide

private def q11Shape25T137 : Tree 11 := .split 34 q11Shape25T138 q11Shape25T143
private theorem q11Shape25T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 16506683392 q11Shape25T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 (16506683392 ||| 2^34) q11Shape25T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (671088640 ||| 2^34) 16506683392 q11Shape25T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T138OK,q11Shape25T143OK⟩

private def q11Shape25T144 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 9261023232 7916748800 q11Shape25T144=true := by decide

private def q11Shape25T136 : Tree 11 := .split 33 q11Shape25T137 q11Shape25T144
private theorem q11Shape25T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 7916748800 q11Shape25T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 (7916748800 ||| 2^33) q11Shape25T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (671088640 ||| 2^33) 7916748800 q11Shape25T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T137OK,q11Shape25T144OK⟩

def q11Shape25P4 : Tree 11 := q11Shape25T136
theorem q11Shape25P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 671088640 7916748800 q11Shape25P4=true := q11Shape25T136OK

private def q11Shape25T151 : Tree 11 := (.split 18 (.split 3 (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {1,2,3,4,5,9})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 33954992132 q11Shape25T151=true := by decide

private def q11Shape25T152 : Tree 11 := (.split 9 (.split 15 (.split 18 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653188 33954992128 q11Shape25T152=true := by decide

private def q11Shape25T150 : Tree 11 := .split 2 q11Shape25T151 q11Shape25T152
private theorem q11Shape25T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 33954992128 q11Shape25T150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 (33954992128 ||| 2^2) q11Shape25T151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (402653184 ||| 2^2) 33954992128 q11Shape25T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T151OK,q11Shape25T152OK⟩

private def q11Shape25T153 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402657280 33954988032 q11Shape25T153=true := by decide

private def q11Shape25T149 : Tree 11 := .split 12 q11Shape25T150 q11Shape25T153
private theorem q11Shape25T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 33954988032 q11Shape25T149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 (33954988032 ||| 2^12) q11Shape25T150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (402653184 ||| 2^12) 33954988032 q11Shape25T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T150OK,q11Shape25T153OK⟩

private def q11Shape25T156 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,6,7,9,10})) (.split 17 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,4,6,9,10})))) (.split 15 (.split 11 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {1,2,3,4,6,9}))))
private theorem q11Shape25T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 939524096 33418117132 q11Shape25T156=true := by decide

private def q11Shape25T157 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,6,7,9,10})) (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,5,6,7,9,10})))) (.split 15 (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,2,3,4,6,9}))))
private theorem q11Shape25T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 939524104 33418117124 q11Shape25T157=true := by decide

private def q11Shape25T155 : Tree 11 := .split 3 q11Shape25T156 q11Shape25T157
private theorem q11Shape25T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 939524096 33418117124 q11Shape25T155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 939524096 (33418117124 ||| 2^3) q11Shape25T156 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (939524096 ||| 2^3) 33418117124 q11Shape25T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T156OK,q11Shape25T157OK⟩

private def q11Shape25T158 : Tree 11 := (.split 9 (.split 15 (.split 4 (.split 12 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,3,4,5,9,10}))) (.tip (.cover {0,1,2,6,9,10}))) (.tip (.cover {1,2,3,4,6,9}))) (.tip (.cover {1,2,3,4,6,9})))
private theorem q11Shape25T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 939524100 33418117120 q11Shape25T158=true := by decide

private def q11Shape25T154 : Tree 11 := .split 2 q11Shape25T155 q11Shape25T158
private theorem q11Shape25T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 939524096 33418117120 q11Shape25T154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 939524096 (33418117120 ||| 2^2) q11Shape25T155 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (939524096 ||| 2^2) 33418117120 q11Shape25T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T155OK,q11Shape25T158OK⟩

private def q11Shape25T148 : Tree 11 := .split 29 q11Shape25T149 q11Shape25T154
private theorem q11Shape25T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 33418117120 q11Shape25T148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 (33418117120 ||| 2^29) q11Shape25T149 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (402653184 ||| 2^29) 33418117120 q11Shape25T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T149OK,q11Shape25T154OK⟩

private def q11Shape25T159 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17582522368 16238247936 q11Shape25T159=true := by decide

private def q11Shape25T147 : Tree 11 := .split 34 q11Shape25T148 q11Shape25T159
private theorem q11Shape25T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 16238247936 q11Shape25T147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 (16238247936 ||| 2^34) q11Shape25T148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (402653184 ||| 2^34) 16238247936 q11Shape25T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T148OK,q11Shape25T159OK⟩

private def q11Shape25T160 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8992587776 7648313344 q11Shape25T160=true := by decide

private def q11Shape25T146 : Tree 11 := .split 33 q11Shape25T147 q11Shape25T160
private theorem q11Shape25T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 7648313344 q11Shape25T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 (7648313344 ||| 2^33) q11Shape25T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (402653184 ||| 2^33) 7648313344 q11Shape25T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T147OK,q11Shape25T160OK⟩

def q11Shape25P5 : Tree 11 := q11Shape25T146
theorem q11Shape25P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 402653184 7648313344 q11Shape25P5=true := q11Shape25T146OK

private def q11Shape25T162 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4429185024 3353346048 q11Shape25T162=true := by decide

def q11Shape25P6 : Tree 11 := q11Shape25T162
theorem q11Shape25P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4429185024 3353346048 q11Shape25P6=true := q11Shape25T162OK

private def q11Shape25T164 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2281701376 1205862400 q11Shape25T164=true := by decide

def q11Shape25P7 : Tree 11 := q11Shape25T164
theorem q11Shape25P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2281701376 1205862400 q11Shape25P7=true := q11Shape25T164OK

private def q11Shape25T166 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 167772160 1172307968 q11Shape25T166=true := by decide

def q11Shape25P8 : Tree 11 := q11Shape25T166
theorem q11Shape25P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 167772160 1172307968 q11Shape25P8=true := q11Shape25T166OK

private def q11Shape25T168 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 150994944 1155530752 q11Shape25T168=true := by decide

def q11Shape25P9 : Tree 11 := q11Shape25T168
theorem q11Shape25P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 150994944 1155530752 q11Shape25P9=true := q11Shape25T168OK

end Graffiti384b.EffectiveSearch.Q11
