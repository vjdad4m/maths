import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T176 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 34290565644 q11Shape25T176=true := by decide

private def q11Shape25T179 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67141632 68650533388 q11Shape25T179=true := by decide

private def q11Shape25T181 : Tree 11 := (.split 16 (.split 0 (.tip (.small 0)) (.split 12 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {1,3,5,6,9,10})))) (.split 11 (.split 17 (.split 4 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426880000 34290796044 q11Shape25T181=true := by decide

private def q11Shape25T182 : Tree 11 := (.split 11 (.split 12 (.tip (.cover {1,2,5,6,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426881024 34290795020 q11Shape25T182=true := by decide

private def q11Shape25T180 : Tree 11 := .split 10 q11Shape25T181 q11Shape25T182
private theorem q11Shape25T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426880000 34290795020 q11Shape25T180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426880000 (34290795020 ||| 2^10) q11Shape25T181 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34426880000 ||| 2^10) 34290795020 q11Shape25T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T181OK,q11Shape25T182OK⟩

private def q11Shape25T178 : Tree 11 := .split 35 q11Shape25T179 q11Shape25T180
private theorem q11Shape25T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67141632 34290795020 q11Shape25T178=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67141632 (34290795020 ||| 2^35) q11Shape25T179 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67141632 ||| 2^35) 34290795020 q11Shape25T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T179OK,q11Shape25T180OK⟩

private def q11Shape25T183 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape25T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67403776 34290532876 q11Shape25T183=true := by decide

private def q11Shape25T177 : Tree 11 := .split 18 q11Shape25T178 q11Shape25T183
private theorem q11Shape25T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67141632 34290532876 q11Shape25T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67141632 (34290532876 ||| 2^18) q11Shape25T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67141632 ||| 2^18) 34290532876 q11Shape25T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T178OK,q11Shape25T183OK⟩

private def q11Shape25T175 : Tree 11 := .split 15 q11Shape25T176 q11Shape25T177
private theorem q11Shape25T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 34290532876 q11Shape25T175=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (34290532876 ||| 2^15) q11Shape25T176 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^15) 34290532876 q11Shape25T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T176OK,q11Shape25T177OK⟩

private def q11Shape25T187 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109376 68650307596 q11Shape25T187=true := by decide

private def q11Shape25T189 : Tree 11 := (.split 16 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,6,8,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847744 34290570252 q11Shape25T189=true := by decide

private def q11Shape25T190 : Tree 11 := (.split 11 (.split 17 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,6,8,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape25T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426848768 34290569228 q11Shape25T190=true := by decide

private def q11Shape25T188 : Tree 11 := .split 10 q11Shape25T189 q11Shape25T190
private theorem q11Shape25T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847744 34290569228 q11Shape25T188=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847744 (34290569228 ||| 2^10) q11Shape25T189 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34426847744 ||| 2^10) 34290569228 q11Shape25T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T189OK,q11Shape25T190OK⟩

private def q11Shape25T186 : Tree 11 := .split 35 q11Shape25T187 q11Shape25T188
private theorem q11Shape25T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109376 34290569228 q11Shape25T186=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109376 (34290569228 ||| 2^35) q11Shape25T187 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67109376 ||| 2^35) 34290569228 q11Shape25T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T187OK,q11Shape25T188OK⟩

private def q11Shape25T191 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape25T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67113472 34290565132 q11Shape25T191=true := by decide

private def q11Shape25T185 : Tree 11 := .split 12 q11Shape25T186 q11Shape25T191
private theorem q11Shape25T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109376 34290565132 q11Shape25T185=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109376 (34290565132 ||| 2^12) q11Shape25T186 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67109376 ||| 2^12) 34290565132 q11Shape25T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T186OK,q11Shape25T191OK⟩

private def q11Shape25T192 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67142144 34290532364 q11Shape25T192=true := by decide

private def q11Shape25T184 : Tree 11 := .split 15 q11Shape25T185 q11Shape25T192
private theorem q11Shape25T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109376 34290532364 q11Shape25T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109376 (34290532364 ||| 2^15) q11Shape25T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67109376 ||| 2^15) 34290532364 q11Shape25T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T185OK,q11Shape25T192OK⟩

private def q11Shape25T174 : Tree 11 := .split 9 q11Shape25T175 q11Shape25T184
private theorem q11Shape25T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 34290532364 q11Shape25T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (34290532364 ||| 2^9) q11Shape25T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^9) 34290532364 q11Shape25T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T175OK,q11Shape25T184OK⟩

private def q11Shape25T197 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape25T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 68650403860 q11Shape25T197=true := by decide

private def q11Shape25T199 : Tree 11 := (.split 15 (.tip (.cover {0,1,6,8,9,10})) (.split 10 (.split 12 (.split 13 (.tip (.cover {0,1,2,4,6,10})) (.tip (.cover {1,3,5,6,8,10}))) (.tip (.cover {1,3,5,6,9,10}))) (.tip (.cover {1,5,6,8,9,10}))))
private theorem q11Shape25T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847240 34290666004 q11Shape25T199=true := by decide

private def q11Shape25T200 : Tree 11 := (.split 15 (.split 16 (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,6,8,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {1,5,6,8,9,10}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847752 34290665492 q11Shape25T200=true := by decide

private def q11Shape25T198 : Tree 11 := .split 9 q11Shape25T199 q11Shape25T200
private theorem q11Shape25T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847240 34290665492 q11Shape25T198=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847240 (34290665492 ||| 2^9) q11Shape25T199 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34426847240 ||| 2^9) 34290665492 q11Shape25T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T199OK,q11Shape25T200OK⟩

private def q11Shape25T196 : Tree 11 := .split 35 q11Shape25T197 q11Shape25T198
private theorem q11Shape25T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 34290665492 q11Shape25T196=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 (34290665492 ||| 2^35) q11Shape25T197 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108872 ||| 2^35) 34290665492 q11Shape25T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T197OK,q11Shape25T198OK⟩

private def q11Shape25T201 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108888 34290665476 q11Shape25T201=true := by decide

private def q11Shape25T195 : Tree 11 := .split 4 q11Shape25T196 q11Shape25T201
private theorem q11Shape25T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 34290665476 q11Shape25T195=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 (34290665476 ||| 2^4) q11Shape25T196 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108872 ||| 2^4) 34290665476 q11Shape25T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T196OK,q11Shape25T201OK⟩

private def q11Shape25T202 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67239944 34290534404 q11Shape25T202=true := by decide

private def q11Shape25T194 : Tree 11 := .split 17 q11Shape25T195 q11Shape25T202
private theorem q11Shape25T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 34290534404 q11Shape25T194=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 (34290534404 ||| 2^17) q11Shape25T195 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108872 ||| 2^17) 34290534404 q11Shape25T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T195OK,q11Shape25T202OK⟩

private def q11Shape25T203 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67110920 34290532356 q11Shape25T203=true := by decide

private def q11Shape25T193 : Tree 11 := .split 11 q11Shape25T194 q11Shape25T203
private theorem q11Shape25T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 34290532356 q11Shape25T193=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108872 (34290532356 ||| 2^11) q11Shape25T194 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108872 ||| 2^11) 34290532356 q11Shape25T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T194OK,q11Shape25T203OK⟩

private def q11Shape25T173 : Tree 11 := .split 3 q11Shape25T174 q11Shape25T193
private theorem q11Shape25T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 34290532356 q11Shape25T173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (34290532356 ||| 2^3) q11Shape25T174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^3) 34290532356 q11Shape25T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T174OK,q11Shape25T193OK⟩

private def q11Shape25T209 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 68650304040 q11Shape25T209=true := by decide

private def q11Shape25T211 : Tree 11 := (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))) (.split 11 (.split 12 (.split 13 (.tip (.cover {0,1,2,4,6,10})) (.tip (.cover {1,3,4,5,6,10}))) (.tip (.cover {1,3,5,6,9,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847236 34290566696 q11Shape25T211=true := by decide

private def q11Shape25T212 : Tree 11 := (.split 16 (.split 11 (.split 12 (.tip (.cover {1,4,5,6,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10})))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {1,5,6,8,9,10})))
private theorem q11Shape25T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426848260 34290565672 q11Shape25T212=true := by decide

private def q11Shape25T210 : Tree 11 := .split 10 q11Shape25T211 q11Shape25T212
private theorem q11Shape25T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847236 34290565672 q11Shape25T210=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34426847236 (34290565672 ||| 2^10) q11Shape25T211 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34426847236 ||| 2^10) 34290565672 q11Shape25T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T211OK,q11Shape25T212OK⟩

private def q11Shape25T208 : Tree 11 := .split 35 q11Shape25T209 q11Shape25T210
private theorem q11Shape25T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 34290565672 q11Shape25T208=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 (34290565672 ||| 2^35) q11Shape25T209 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108868 ||| 2^35) 34290565672 q11Shape25T210)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T209OK,q11Shape25T210OK⟩

private def q11Shape25T213 : Tree 11 := (.tip (.cover {0,1,2,6,9,10}))
private theorem q11Shape25T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108900 34290565640 q11Shape25T213=true := by decide

private def q11Shape25T207 : Tree 11 := .split 5 q11Shape25T208 q11Shape25T213
private theorem q11Shape25T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 34290565640 q11Shape25T207=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 (34290565640 ||| 2^5) q11Shape25T208 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108868 ||| 2^5) 34290565640 q11Shape25T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T208OK,q11Shape25T213OK⟩

private def q11Shape25T214 : Tree 11 := (.split 11 (.split 17 (.split 4 (.split 5 (.split 35 (.tip (.cover {2,3,4,5,7,8})) (.split 13 (.split 12 (.tip (.cover {0,1,2,4,6,10})) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {1,3,4,5,6,10})))) (.tip (.cover {0,1,2,6,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108876 34290565632 q11Shape25T214=true := by decide

private def q11Shape25T206 : Tree 11 := .split 3 q11Shape25T207 q11Shape25T214
private theorem q11Shape25T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 34290565632 q11Shape25T206=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 (34290565632 ||| 2^3) q11Shape25T207 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108868 ||| 2^3) 34290565632 q11Shape25T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T207OK,q11Shape25T214OK⟩

private def q11Shape25T215 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67141636 34290532864 q11Shape25T215=true := by decide

private def q11Shape25T205 : Tree 11 := .split 15 q11Shape25T206 q11Shape25T215
private theorem q11Shape25T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 34290532864 q11Shape25T205=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 (34290532864 ||| 2^15) q11Shape25T206 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108868 ||| 2^15) 34290532864 q11Shape25T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T206OK,q11Shape25T215OK⟩

private def q11Shape25T216 : Tree 11 := (.tip (.cover {1,2,3,4,6,9}))
private theorem q11Shape25T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67109380 34290532352 q11Shape25T216=true := by decide

private def q11Shape25T204 : Tree 11 := .split 9 q11Shape25T205 q11Shape25T216
private theorem q11Shape25T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 34290532352 q11Shape25T204=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108868 (34290532352 ||| 2^9) q11Shape25T205 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108868 ||| 2^9) 34290532352 q11Shape25T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T205OK,q11Shape25T216OK⟩

private def q11Shape25T172 : Tree 11 := .split 2 q11Shape25T173 q11Shape25T204
private theorem q11Shape25T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 34290532352 q11Shape25T172=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (34290532352 ||| 2^2) q11Shape25T173 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^2) 34290532352 q11Shape25T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T173OK,q11Shape25T204OK⟩

private def q11Shape25T219 : Tree 11 := (.split 16 (.split 2 (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9})))) (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {2,3,4,6,8,10})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4362076160 29995566088 q11Shape25T219=true := by decide

private def q11Shape25T220 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4362077184 29995565064 q11Shape25T220=true := by decide

private def q11Shape25T218 : Tree 11 := .split 10 q11Shape25T219 q11Shape25T220
private theorem q11Shape25T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4362076160 29995565064 q11Shape25T218=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4362076160 (29995565064 ||| 2^10) q11Shape25T219 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4362076160 ||| 2^10) 29995565064 q11Shape25T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T219OK,q11Shape25T220OK⟩

private def q11Shape25T221 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4362076168 29995565056 q11Shape25T221=true := by decide

private def q11Shape25T217 : Tree 11 := .split 3 q11Shape25T218 q11Shape25T221
private theorem q11Shape25T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4362076160 29995565056 q11Shape25T217=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4362076160 (29995565056 ||| 2^3) q11Shape25T218 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4362076160 ||| 2^3) 29995565056 q11Shape25T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T218OK,q11Shape25T221OK⟩

private def q11Shape25T171 : Tree 11 := .split 32 q11Shape25T172 q11Shape25T217
private theorem q11Shape25T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 29995565056 q11Shape25T171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 (29995565056 ||| 2^32) q11Shape25T172 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (67108864 ||| 2^32) 29995565056 q11Shape25T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T172OK,q11Shape25T217OK⟩

def q11Shape25P10 : Tree 11 := q11Shape25T171
theorem q11Shape25P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 67108864 29995565056 q11Shape25P10=true := q11Shape25T171OK

end Graffiti384b.EffectiveSearch.Q11
