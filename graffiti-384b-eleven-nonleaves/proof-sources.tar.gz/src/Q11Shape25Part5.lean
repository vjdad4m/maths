import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T225 : Tree 11 := (.split 16 (.split 2 (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10})))) (.split 9 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,6,8,9})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 32143049736 q11Shape25T225=true := by decide

private def q11Shape25T226 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214593536 32143048712 q11Shape25T226=true := by decide

private def q11Shape25T224 : Tree 11 := .split 10 q11Shape25T225 q11Shape25T226
private theorem q11Shape25T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 32143048712 q11Shape25T224=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 (32143048712 ||| 2^10) q11Shape25T225 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2214592512 ||| 2^10) 32143048712 q11Shape25T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T225OK,q11Shape25T226OK⟩

private def q11Shape25T227 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592520 32143048704 q11Shape25T227=true := by decide

private def q11Shape25T223 : Tree 11 := .split 3 q11Shape25T224 q11Shape25T227
private theorem q11Shape25T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 32143048704 q11Shape25T223=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 (32143048704 ||| 2^3) q11Shape25T224 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2214592512 ||| 2^3) 32143048704 q11Shape25T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T224OK,q11Shape25T227OK⟩

private def q11Shape25T230 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,6,8,9,10})) (.split 16 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 10 (.split 12 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,1,3,8,9,10}))))
private theorem q11Shape25T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559808 27848081420 q11Shape25T230=true := by decide

private def q11Shape25T231 : Tree 11 := (.split 9 (.split 12 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,2,4,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape25T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559816 27848081412 q11Shape25T231=true := by decide

private def q11Shape25T229 : Tree 11 := .split 3 q11Shape25T230 q11Shape25T231
private theorem q11Shape25T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559808 27848081412 q11Shape25T229=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559808 (27848081412 ||| 2^3) q11Shape25T230 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6509559808 ||| 2^3) 27848081412 q11Shape25T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T230OK,q11Shape25T231OK⟩

private def q11Shape25T234 : Tree 11 := (.split 10 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,2,6,9,10}))) (.split 18 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,8,9,10}))))
private theorem q11Shape25T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559812 27848081928 q11Shape25T234=true := by decide

private def q11Shape25T235 : Tree 11 := (.split 10 (.split 15 (.split 35 (.tip (.cover {2,3,4,6,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,3,8,9,10})))
private theorem q11Shape25T235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509560324 27848081416 q11Shape25T235=true := by decide

private def q11Shape25T233 : Tree 11 := .split 9 q11Shape25T234 q11Shape25T235
private theorem q11Shape25T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559812 27848081416 q11Shape25T233=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559812 (27848081416 ||| 2^9) q11Shape25T234 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6509559812 ||| 2^9) 27848081416 q11Shape25T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T234OK,q11Shape25T235OK⟩

private def q11Shape25T236 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape25T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559820 27848081408 q11Shape25T236=true := by decide

private def q11Shape25T232 : Tree 11 := .split 3 q11Shape25T233 q11Shape25T236
private theorem q11Shape25T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559812 27848081408 q11Shape25T232=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559812 (27848081408 ||| 2^3) q11Shape25T233 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6509559812 ||| 2^3) 27848081408 q11Shape25T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T233OK,q11Shape25T236OK⟩

private def q11Shape25T228 : Tree 11 := .split 2 q11Shape25T229 q11Shape25T232
private theorem q11Shape25T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559808 27848081408 q11Shape25T228=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 6509559808 (27848081408 ||| 2^2) q11Shape25T229 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (6509559808 ||| 2^2) 27848081408 q11Shape25T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T229OK,q11Shape25T232OK⟩

private def q11Shape25T222 : Tree 11 := .split 32 q11Shape25T223 q11Shape25T228
private theorem q11Shape25T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 27848081408 q11Shape25T222=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 (27848081408 ||| 2^32) q11Shape25T223 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (2214592512 ||| 2^32) 27848081408 q11Shape25T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T223OK,q11Shape25T228OK⟩

def q11Shape25P11 : Tree 11 := q11Shape25T222
theorem q11Shape25P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2214592512 27848081408 q11Shape25P11=true := q11Shape25T222OK

private def q11Shape25T243 : Tree 11 := (.split 4 (.split 3 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 33753794564 q11Shape25T243=true := by decide

private def q11Shape25T244 : Tree 11 := (.split 9 (.split 15 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {2,3,4,7,8,10}))) (.tip (.cover {2,3,4,7,8,10})))
private theorem q11Shape25T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979780 33753794560 q11Shape25T244=true := by decide

private def q11Shape25T242 : Tree 11 := .split 2 q11Shape25T243 q11Shape25T244
private theorem q11Shape25T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 33753794560 q11Shape25T242=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 (33753794560 ||| 2^2) q11Shape25T243 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (603979776 ||| 2^2) 33753794560 q11Shape25T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T243OK,q11Shape25T244OK⟩

private def q11Shape25T245 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 604110848 33753663488 q11Shape25T245=true := by decide

private def q11Shape25T241 : Tree 11 := .split 17 q11Shape25T242 q11Shape25T245
private theorem q11Shape25T241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 33753663488 q11Shape25T241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 (33753663488 ||| 2^17) q11Shape25T242 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (603979776 ||| 2^17) 33753663488 q11Shape25T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T242OK,q11Shape25T245OK⟩

private def q11Shape25T246 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603981824 33753661440 q11Shape25T246=true := by decide

private def q11Shape25T240 : Tree 11 := .split 11 q11Shape25T241 q11Shape25T246
private theorem q11Shape25T240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 33753661440 q11Shape25T240=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 (33753661440 ||| 2^11) q11Shape25T241 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (603979776 ||| 2^11) 33753661440 q11Shape25T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T241OK,q11Shape25T246OK⟩

private def q11Shape25T247 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T247OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4898947072 29458694144 q11Shape25T247=true := by decide

private def q11Shape25T239 : Tree 11 := .split 32 q11Shape25T240 q11Shape25T247
private theorem q11Shape25T239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 29458694144 q11Shape25T239=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 (29458694144 ||| 2^32) q11Shape25T240 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (603979776 ||| 2^32) 29458694144 q11Shape25T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T240OK,q11Shape25T247OK⟩

private def q11Shape25T248 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T248OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2751463424 27311210496 q11Shape25T248=true := by decide

private def q11Shape25T238 : Tree 11 := .split 31 q11Shape25T239 q11Shape25T248
private theorem q11Shape25T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 27311210496 q11Shape25T238=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 (27311210496 ||| 2^31) q11Shape25T239 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (603979776 ||| 2^31) 27311210496 q11Shape25T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T239OK,q11Shape25T248OK⟩

def q11Shape25P12 : Tree 11 := q11Shape25T238
theorem q11Shape25P12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 603979776 27311210496 q11Shape25P12=true := q11Shape25T238OK

private def q11Shape25T256 : Tree 11 := (.split 4 (.split 3 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,10}))) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,10})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T256OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 34022230020 q11Shape25T256=true := by decide

private def q11Shape25T257 : Tree 11 := (.split 9 (.split 15 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T257OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544324 34022230016 q11Shape25T257=true := by decide

private def q11Shape25T255 : Tree 11 := .split 2 q11Shape25T256 q11Shape25T257
private theorem q11Shape25T255OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 34022230016 q11Shape25T255=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 (34022230016 ||| 2^2) q11Shape25T256 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (335544320 ||| 2^2) 34022230016 q11Shape25T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T256OK,q11Shape25T257OK⟩

private def q11Shape25T258 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T258OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335675392 34022098944 q11Shape25T258=true := by decide

private def q11Shape25T254 : Tree 11 := .split 17 q11Shape25T255 q11Shape25T258
private theorem q11Shape25T254OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 34022098944 q11Shape25T254=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 (34022098944 ||| 2^17) q11Shape25T255 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (335544320 ||| 2^17) 34022098944 q11Shape25T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T255OK,q11Shape25T258OK⟩

private def q11Shape25T259 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T259OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335546368 34022096896 q11Shape25T259=true := by decide

private def q11Shape25T253 : Tree 11 := .split 11 q11Shape25T254 q11Shape25T259
private theorem q11Shape25T253OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 34022096896 q11Shape25T253=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 (34022096896 ||| 2^11) q11Shape25T254 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (335544320 ||| 2^11) 34022096896 q11Shape25T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T254OK,q11Shape25T259OK⟩

private def q11Shape25T262 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,6,8,9,10})) (.split 17 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,8,9,10})))) (.split 15 (.split 11 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,3,8,9,10}))) (.tip (.cover {1,2,3,4,6,9}))))
private theorem q11Shape25T262OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 872415232 33485225996 q11Shape25T262=true := by decide

private def q11Shape25T263 : Tree 11 := (.split 9 (.split 15 (.tip (.cover {0,1,6,8,9,10})) (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {1,5,6,8,9,10})))) (.split 15 (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {1,5,6,8,9,10}))) (.tip (.cover {1,2,3,4,6,9}))))
private theorem q11Shape25T263OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 872415240 33485225988 q11Shape25T263=true := by decide

private def q11Shape25T261 : Tree 11 := .split 3 q11Shape25T262 q11Shape25T263
private theorem q11Shape25T261OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 872415232 33485225988 q11Shape25T261=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 872415232 (33485225988 ||| 2^3) q11Shape25T262 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (872415232 ||| 2^3) 33485225988 q11Shape25T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T262OK,q11Shape25T263OK⟩

private def q11Shape25T264 : Tree 11 := (.split 9 (.split 15 (.split 4 (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,2,6,9,10}))) (.tip (.cover {0,1,2,8,9,10}))) (.tip (.cover {1,2,3,4,6,9}))) (.tip (.cover {1,2,3,4,6,9})))
private theorem q11Shape25T264OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 872415236 33485225984 q11Shape25T264=true := by decide

private def q11Shape25T260 : Tree 11 := .split 2 q11Shape25T261 q11Shape25T264
private theorem q11Shape25T260OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 872415232 33485225984 q11Shape25T260=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 872415232 (33485225984 ||| 2^2) q11Shape25T261 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (872415232 ||| 2^2) 33485225984 q11Shape25T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T261OK,q11Shape25T264OK⟩

private def q11Shape25T252 : Tree 11 := .split 29 q11Shape25T253 q11Shape25T260
private theorem q11Shape25T252OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 33485225984 q11Shape25T252=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 (33485225984 ||| 2^29) q11Shape25T253 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (335544320 ||| 2^29) 33485225984 q11Shape25T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T253OK,q11Shape25T260OK⟩

private def q11Shape25T265 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T265OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4630511616 29190258688 q11Shape25T265=true := by decide

private def q11Shape25T251 : Tree 11 := .split 32 q11Shape25T252 q11Shape25T265
private theorem q11Shape25T251OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 29190258688 q11Shape25T251=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 (29190258688 ||| 2^32) q11Shape25T252 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (335544320 ||| 2^32) 29190258688 q11Shape25T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T252OK,q11Shape25T265OK⟩

private def q11Shape25T266 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T266OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2483027968 27042775040 q11Shape25T266=true := by decide

private def q11Shape25T250 : Tree 11 := .split 31 q11Shape25T251 q11Shape25T266
private theorem q11Shape25T250OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 27042775040 q11Shape25T250=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 (27042775040 ||| 2^31) q11Shape25T251 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (335544320 ||| 2^31) 27042775040 q11Shape25T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T251OK,q11Shape25T266OK⟩

def q11Shape25P13 : Tree 11 := q11Shape25T250
theorem q11Shape25P13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 335544320 27042775040 q11Shape25P13=true := q11Shape25T250OK

private def q11Shape25T268 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T268OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17246978048 9862905856 q11Shape25T268=true := by decide

def q11Shape25P14 : Tree 11 := q11Shape25T268
theorem q11Shape25P14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17246978048 9862905856 q11Shape25P14=true := q11Shape25T268OK

private def q11Shape25T270 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T270OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8657043456 1272971264 q11Shape25T270=true := by decide

def q11Shape25P15 : Tree 11 := q11Shape25T270
theorem q11Shape25P15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8657043456 1272971264 q11Shape25P15=true := q11Shape25T270OK

private def q11Shape25T272 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T272OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 100663296 1239416832 q11Shape25T272=true := by decide

def q11Shape25P16 : Tree 11 := q11Shape25T272
theorem q11Shape25P16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 100663296 1239416832 q11Shape25P16=true := q11Shape25T272OK

private def q11Shape25T274 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape25T274OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 83886080 1222639616 q11Shape25T274=true := by decide

def q11Shape25P17 : Tree 11 := q11Shape25T274
theorem q11Shape25P17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 83886080 1222639616 q11Shape25P17=true := q11Shape25T274OK

private def q11Shape25T276 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T276OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 201326592 1088421888 q11Shape25T276=true := by decide

def q11Shape25P18 : Tree 11 := q11Shape25T276
theorem q11Shape25P18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 201326592 1088421888 q11Shape25P18=true := q11Shape25T276OK

end Graffiti384b.EffectiveSearch.Q11
