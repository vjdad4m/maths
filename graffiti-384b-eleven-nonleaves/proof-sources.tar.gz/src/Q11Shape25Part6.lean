import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T285 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T285OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 34349319692 q11Shape25T285=true := by decide

private def q11Shape25T288 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T288OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8454144 68709123596 q11Shape25T288=true := by decide

private def q11Shape25T289 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 11 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {1,3,5,6,9,10})))) (.split 12 (.split 18 (.split 5 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T289OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368192512 34349385228 q11Shape25T289=true := by decide

private def q11Shape25T287 : Tree 11 := .split 35 q11Shape25T288 q11Shape25T289
private theorem q11Shape25T287OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8454144 34349385228 q11Shape25T287=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8454144 (34349385228 ||| 2^35) q11Shape25T288 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8454144 ||| 2^35) 34349385228 q11Shape25T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T288OK,q11Shape25T289OK⟩

private def q11Shape25T290 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape25T290OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8585216 34349254156 q11Shape25T290=true := by decide

private def q11Shape25T286 : Tree 11 := .split 17 q11Shape25T287 q11Shape25T290
private theorem q11Shape25T286OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8454144 34349254156 q11Shape25T286=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8454144 (34349254156 ||| 2^17) q11Shape25T287 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8454144 ||| 2^17) 34349254156 q11Shape25T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T287OK,q11Shape25T290OK⟩

private def q11Shape25T284 : Tree 11 := .split 16 q11Shape25T285 q11Shape25T286
private theorem q11Shape25T284OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 34349254156 q11Shape25T284=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (34349254156 ||| 2^16) q11Shape25T285 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^16) 34349254156 q11Shape25T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T285OK,q11Shape25T286OK⟩

private def q11Shape25T292 : Tree 11 := (.split 11 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,7,10}))) (.tip (.cover {0,1,2,3,4,9}))))) (.tip (.cover {0,1,3,5,9,10})))
private theorem q11Shape25T292OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389632 34349318668 q11Shape25T292=true := by decide

private def q11Shape25T293 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T293OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8455168 34349253132 q11Shape25T293=true := by decide

private def q11Shape25T291 : Tree 11 := .split 16 q11Shape25T292 q11Shape25T293
private theorem q11Shape25T291OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389632 34349253132 q11Shape25T291=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389632 (34349253132 ||| 2^16) q11Shape25T292 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8389632 ||| 2^16) 34349253132 q11Shape25T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T292OK,q11Shape25T293OK⟩

private def q11Shape25T283 : Tree 11 := .split 10 q11Shape25T284 q11Shape25T291
private theorem q11Shape25T283OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 34349253132 q11Shape25T283=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (34349253132 ||| 2^10) q11Shape25T284 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^10) 34349253132 q11Shape25T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T284OK,q11Shape25T291OK⟩

private def q11Shape25T298 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape25T298OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 68709257260 q11Shape25T298=true := by decide

private def q11Shape25T300 : Tree 11 := (.split 16 (.tip (.cover {0,1,5,7,9,10})) (.split 17 (.split 11 (.tip (.cover {1,2,5,6,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10})))) (.tip (.cover {0,1,4,5,9,10}))))
private theorem q11Shape25T300OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368127488 34349519916 q11Shape25T300=true := by decide

private def q11Shape25T301 : Tree 11 := (.split 16 (.split 11 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,7,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T301OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368128512 34349518892 q11Shape25T301=true := by decide

private def q11Shape25T299 : Tree 11 := .split 10 q11Shape25T300 q11Shape25T301
private theorem q11Shape25T299OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368127488 34349518892 q11Shape25T299=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368127488 (34349518892 ||| 2^10) q11Shape25T300 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34368127488 ||| 2^10) 34349518892 q11Shape25T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T300OK,q11Shape25T301OK⟩

private def q11Shape25T297 : Tree 11 := .split 35 q11Shape25T298 q11Shape25T299
private theorem q11Shape25T297OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 34349518892 q11Shape25T297=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 (34349518892 ||| 2^35) q11Shape25T298 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8389120 ||| 2^35) 34349518892 q11Shape25T299)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T298OK,q11Shape25T299OK⟩

private def q11Shape25T302 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T302OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389152 34349518860 q11Shape25T302=true := by decide

private def q11Shape25T296 : Tree 11 := .split 5 q11Shape25T297 q11Shape25T302
private theorem q11Shape25T296OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 34349518860 q11Shape25T296=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 (34349518860 ||| 2^5) q11Shape25T297 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8389120 ||| 2^5) 34349518860 q11Shape25T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T297OK,q11Shape25T302OK⟩

private def q11Shape25T303 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T303OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8651264 34349256716 q11Shape25T303=true := by decide

private def q11Shape25T295 : Tree 11 := .split 18 q11Shape25T296 q11Shape25T303
private theorem q11Shape25T295OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 34349256716 q11Shape25T295=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 (34349256716 ||| 2^18) q11Shape25T296 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8389120 ||| 2^18) 34349256716 q11Shape25T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T296OK,q11Shape25T303OK⟩

private def q11Shape25T304 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T304OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8393216 34349252620 q11Shape25T304=true := by decide

private def q11Shape25T294 : Tree 11 := .split 12 q11Shape25T295 q11Shape25T304
private theorem q11Shape25T294OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 34349252620 q11Shape25T294=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389120 (34349252620 ||| 2^12) q11Shape25T295 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8389120 ||| 2^12) 34349252620 q11Shape25T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T295OK,q11Shape25T304OK⟩

private def q11Shape25T282 : Tree 11 := .split 9 q11Shape25T283 q11Shape25T294
private theorem q11Shape25T282OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 34349252620 q11Shape25T282=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (34349252620 ||| 2^9) q11Shape25T283 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^9) 34349252620 q11Shape25T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T283OK,q11Shape25T294OK⟩

private def q11Shape25T309 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T309OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 68709057556 q11Shape25T309=true := by decide

private def q11Shape25T311 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,3,4,5,6,10}))) (.tip (.cover {1,3,5,6,9,10}))))
private theorem q11Shape25T311OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126984 34349319700 q11Shape25T311=true := by decide

private def q11Shape25T312 : Tree 11 := (.split 15 (.split 11 (.tip (.cover {1,4,5,6,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10})))) (.tip (.cover {1,5,6,7,9,10})))
private theorem q11Shape25T312OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368127496 34349319188 q11Shape25T312=true := by decide

private def q11Shape25T310 : Tree 11 := .split 9 q11Shape25T311 q11Shape25T312
private theorem q11Shape25T310OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126984 34349319188 q11Shape25T310=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126984 (34349319188 ||| 2^9) q11Shape25T311 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34368126984 ||| 2^9) 34349319188 q11Shape25T312)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T311OK,q11Shape25T312OK⟩

private def q11Shape25T308 : Tree 11 := .split 35 q11Shape25T309 q11Shape25T310
private theorem q11Shape25T308OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 34349319188 q11Shape25T308=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 (34349319188 ||| 2^35) q11Shape25T309 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388616 ||| 2^35) 34349319188 q11Shape25T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T309OK,q11Shape25T310OK⟩

private def q11Shape25T313 : Tree 11 := (.tip (.cover {0,1,2,5,9,10}))
private theorem q11Shape25T313OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388632 34349319172 q11Shape25T313=true := by decide

private def q11Shape25T307 : Tree 11 := .split 4 q11Shape25T308 q11Shape25T313
private theorem q11Shape25T307OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 34349319172 q11Shape25T307=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 (34349319172 ||| 2^4) q11Shape25T308 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388616 ||| 2^4) 34349319172 q11Shape25T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T308OK,q11Shape25T313OK⟩

private def q11Shape25T314 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T314OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8454152 34349253636 q11Shape25T314=true := by decide

private def q11Shape25T306 : Tree 11 := .split 16 q11Shape25T307 q11Shape25T314
private theorem q11Shape25T306OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 34349253636 q11Shape25T306=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 (34349253636 ||| 2^16) q11Shape25T307 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388616 ||| 2^16) 34349253636 q11Shape25T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T307OK,q11Shape25T314OK⟩

private def q11Shape25T315 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T315OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8389640 34349252612 q11Shape25T315=true := by decide

private def q11Shape25T305 : Tree 11 := .split 10 q11Shape25T306 q11Shape25T315
private theorem q11Shape25T305OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 34349252612 q11Shape25T305=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388616 (34349252612 ||| 2^10) q11Shape25T306 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388616 ||| 2^10) 34349252612 q11Shape25T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T306OK,q11Shape25T315OK⟩

private def q11Shape25T281 : Tree 11 := .split 3 q11Shape25T282 q11Shape25T305
private theorem q11Shape25T281OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 34349252612 q11Shape25T281=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (34349252612 ||| 2^3) q11Shape25T282 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^3) 34349252612 q11Shape25T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T282OK,q11Shape25T305OK⟩

private def q11Shape25T321 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape25T321OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 68709257256 q11Shape25T321=true := by decide

private def q11Shape25T324 : Tree 11 := (.split 16 (.tip (.cover {0,1,5,7,9,10})) (.split 11 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,3,5,6,7,10}))) (.tip (.cover {1,3,5,6,9,10}))))
private theorem q11Shape25T324OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126980 34349520424 q11Shape25T324=true := by decide

private def q11Shape25T325 : Tree 11 := (.split 15 (.split 16 (.split 11 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,7,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {1,5,6,7,9,10})))
private theorem q11Shape25T325OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368128004 34349519400 q11Shape25T325=true := by decide

private def q11Shape25T323 : Tree 11 := .split 10 q11Shape25T324 q11Shape25T325
private theorem q11Shape25T323OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126980 34349519400 q11Shape25T323=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126980 (34349519400 ||| 2^10) q11Shape25T324 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34368126980 ||| 2^10) 34349519400 q11Shape25T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T324OK,q11Shape25T325OK⟩

private def q11Shape25T326 : Tree 11 := (.split 15 (.split 16 (.split 10 (.tip (.cover {0,1,5,7,9,10})) (.split 11 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,7,10}))) (.tip (.cover {0,1,3,5,9,10})))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,5,6,7,9,10})))
private theorem q11Shape25T326OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368127492 34349518888 q11Shape25T326=true := by decide

private def q11Shape25T322 : Tree 11 := .split 9 q11Shape25T323 q11Shape25T326
private theorem q11Shape25T322OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126980 34349518888 q11Shape25T322=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34368126980 (34349518888 ||| 2^9) q11Shape25T323 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34368126980 ||| 2^9) 34349518888 q11Shape25T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T323OK,q11Shape25T326OK⟩

private def q11Shape25T320 : Tree 11 := .split 35 q11Shape25T321 q11Shape25T322
private theorem q11Shape25T320OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 34349518888 q11Shape25T320=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 (34349518888 ||| 2^35) q11Shape25T321 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388612 ||| 2^35) 34349518888 q11Shape25T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T321OK,q11Shape25T322OK⟩

private def q11Shape25T327 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T327OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388644 34349518856 q11Shape25T327=true := by decide

private def q11Shape25T319 : Tree 11 := .split 5 q11Shape25T320 q11Shape25T327
private theorem q11Shape25T319OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 34349518856 q11Shape25T319=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 (34349518856 ||| 2^5) q11Shape25T320 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388612 ||| 2^5) 34349518856 q11Shape25T327)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T320OK,q11Shape25T327OK⟩

private def q11Shape25T328 : Tree 11 := (.split 10 (.split 16 (.split 4 (.split 5 (.split 35 (.tip (.cover {2,3,4,6,7,8})) (.split 13 (.split 11 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {1,3,4,5,6,10})))) (.tip (.cover {0,1,2,7,9,10}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T328OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388620 34349518848 q11Shape25T328=true := by decide

private def q11Shape25T318 : Tree 11 := .split 3 q11Shape25T319 q11Shape25T328
private theorem q11Shape25T318OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 34349518848 q11Shape25T318=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 (34349518848 ||| 2^3) q11Shape25T319 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388612 ||| 2^3) 34349518848 q11Shape25T328)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T319OK,q11Shape25T328OK⟩

private def q11Shape25T329 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T329OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8650756 34349256704 q11Shape25T329=true := by decide

private def q11Shape25T317 : Tree 11 := .split 18 q11Shape25T318 q11Shape25T329
private theorem q11Shape25T317OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 34349256704 q11Shape25T317=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 (34349256704 ||| 2^18) q11Shape25T318 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388612 ||| 2^18) 34349256704 q11Shape25T329)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T318OK,q11Shape25T329OK⟩

private def q11Shape25T330 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T330OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8392708 34349252608 q11Shape25T330=true := by decide

private def q11Shape25T316 : Tree 11 := .split 12 q11Shape25T317 q11Shape25T330
private theorem q11Shape25T316OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 34349252608 q11Shape25T316=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388612 (34349252608 ||| 2^12) q11Shape25T317 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388612 ||| 2^12) 34349252608 q11Shape25T330)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T317OK,q11Shape25T330OK⟩

private def q11Shape25T280 : Tree 11 := .split 2 q11Shape25T281 q11Shape25T316
private theorem q11Shape25T280OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 34349252608 q11Shape25T280=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (34349252608 ||| 2^2) q11Shape25T281 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^2) 34349252608 q11Shape25T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T281OK,q11Shape25T316OK⟩

private def q11Shape25T333 : Tree 11 := (.split 15 (.split 3 (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9})))) (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {2,3,4,5,7,10})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T333OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17188257792 17169383940 q11Shape25T333=true := by decide

private def q11Shape25T334 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T334OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17188258304 17169383428 q11Shape25T334=true := by decide

private def q11Shape25T332 : Tree 11 := .split 9 q11Shape25T333 q11Shape25T334
private theorem q11Shape25T332OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17188257792 17169383428 q11Shape25T332=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17188257792 (17169383428 ||| 2^9) q11Shape25T333 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (17188257792 ||| 2^9) 17169383428 q11Shape25T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T333OK,q11Shape25T334OK⟩

private def q11Shape25T335 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T335OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17188257796 17169383424 q11Shape25T335=true := by decide

private def q11Shape25T331 : Tree 11 := .split 2 q11Shape25T332 q11Shape25T335
private theorem q11Shape25T331OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17188257792 17169383424 q11Shape25T331=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17188257792 (17169383424 ||| 2^2) q11Shape25T332 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (17188257792 ||| 2^2) 17169383424 q11Shape25T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T332OK,q11Shape25T335OK⟩

private def q11Shape25T279 : Tree 11 := .split 34 q11Shape25T280 q11Shape25T331
private theorem q11Shape25T279OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 17169383424 q11Shape25T279=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 (17169383424 ||| 2^34) q11Shape25T280 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8388608 ||| 2^34) 17169383424 q11Shape25T331)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T280OK,q11Shape25T331OK⟩

def q11Shape25P19 : Tree 11 := q11Shape25T279
theorem q11Shape25P19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8388608 17169383424 q11Shape25P19=true := q11Shape25T279OK

end Graffiti384b.EffectiveSearch.Q11
