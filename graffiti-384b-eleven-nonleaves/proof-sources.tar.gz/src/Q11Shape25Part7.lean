import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T339 : Tree 11 := (.split 15 (.split 3 (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10})))) (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {2,3,4,5,7,9})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T339OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 25759318532 q11Shape25T339=true := by decide

private def q11Shape25T340 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T340OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323712 25759318020 q11Shape25T340=true := by decide

private def q11Shape25T338 : Tree 11 := .split 9 q11Shape25T339 q11Shape25T340
private theorem q11Shape25T338OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 25759318020 q11Shape25T338=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 (25759318020 ||| 2^9) q11Shape25T339 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8598323200 ||| 2^9) 25759318020 q11Shape25T340)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T339OK,q11Shape25T340OK⟩

private def q11Shape25T341 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T341OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323204 25759318016 q11Shape25T341=true := by decide

private def q11Shape25T337 : Tree 11 := .split 2 q11Shape25T338 q11Shape25T341
private theorem q11Shape25T337OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 25759318016 q11Shape25T337=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 (25759318016 ||| 2^2) q11Shape25T338 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8598323200 ||| 2^2) 25759318016 q11Shape25T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T338OK,q11Shape25T341OK⟩

private def q11Shape25T344 : Tree 11 := (.split 9 (.split 10 (.split 15 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.split 11 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,3,5,9,10})))) (.split 4 (.tip (.cover {0,1,3,4,9,10})) (.tip (.cover {0,3,4,7,9,10}))))
private theorem q11Shape25T344OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25778192384 8579448844 q11Shape25T344=true := by decide

private def q11Shape25T345 : Tree 11 := (.split 9 (.split 4 (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.split 11 (.tip (.cover {1,4,5,6,9,10})) (.tip (.cover {0,1,3,5,9,10})))) (.tip (.cover {0,1,2,5,9,10}))) (.split 17 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,3,7,9,10}))))
private theorem q11Shape25T345OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25778192392 8579448836 q11Shape25T345=true := by decide

private def q11Shape25T343 : Tree 11 := .split 3 q11Shape25T344 q11Shape25T345
private theorem q11Shape25T343OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25778192384 8579448836 q11Shape25T343=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25778192384 (8579448836 ||| 2^3) q11Shape25T344 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25778192384 ||| 2^3) 8579448836 q11Shape25T345)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T344OK,q11Shape25T345OK⟩

private def q11Shape25T346 : Tree 11 := (.split 3 (.split 9 (.split 4 (.split 15 (.split 35 (.tip (.cover {2,3,4,6,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,2,6,9,10}))) (.split 10 (.tip (.cover {0,4,5,7,9,10})) (.tip (.cover {0,1,3,7,9,10})))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape25T346OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25778192388 8579448832 q11Shape25T346=true := by decide

private def q11Shape25T342 : Tree 11 := .split 2 q11Shape25T343 q11Shape25T346
private theorem q11Shape25T342OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25778192384 8579448832 q11Shape25T342=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25778192384 (8579448832 ||| 2^2) q11Shape25T343 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25778192384 ||| 2^2) 8579448832 q11Shape25T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T343OK,q11Shape25T346OK⟩

private def q11Shape25T336 : Tree 11 := .split 34 q11Shape25T337 q11Shape25T342
private theorem q11Shape25T336OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 8579448832 q11Shape25T336=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 (8579448832 ||| 2^34) q11Shape25T337 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (8598323200 ||| 2^34) 8579448832 q11Shape25T342)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T337OK,q11Shape25T342OK⟩

def q11Shape25P20 : Tree 11 := q11Shape25T336
theorem q11Shape25P20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8598323200 8579448832 q11Shape25P20=true := q11Shape25T336OK

private def q11Shape25T352 : Tree 11 := (.split 18 (.split 3 (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,2,3,4,10}))) (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {2,3,4,7,8,10})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T352OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 34315702276 q11Shape25T352=true := by decide

private def q11Shape25T353 : Tree 11 := (.split 18 (.split 3 (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,2,3,4,6,10}))) (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {2,3,4,7,8,10})))) (.tip (.cover {1,2,3,4,6,10})))
private theorem q11Shape25T353OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943044 34315702272 q11Shape25T353=true := by decide

private def q11Shape25T351 : Tree 11 := .split 2 q11Shape25T352 q11Shape25T353
private theorem q11Shape25T351OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 34315702272 q11Shape25T351=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 (34315702272 ||| 2^2) q11Shape25T352 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (41943040 ||| 2^2) 34315702272 q11Shape25T353)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T352OK,q11Shape25T353OK⟩

private def q11Shape25T354 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T354OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41947136 34315698176 q11Shape25T354=true := by decide

private def q11Shape25T350 : Tree 11 := .split 12 q11Shape25T351 q11Shape25T354
private theorem q11Shape25T350OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 34315698176 q11Shape25T350=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 (34315698176 ||| 2^12) q11Shape25T351 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (41943040 ||| 2^12) 34315698176 q11Shape25T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T351OK,q11Shape25T354OK⟩

private def q11Shape25T355 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T355OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17221812224 17135828992 q11Shape25T355=true := by decide

private def q11Shape25T349 : Tree 11 := .split 34 q11Shape25T350 q11Shape25T355
private theorem q11Shape25T349OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 17135828992 q11Shape25T349=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 (17135828992 ||| 2^34) q11Shape25T350 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (41943040 ||| 2^34) 17135828992 q11Shape25T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T350OK,q11Shape25T355OK⟩

private def q11Shape25T356 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T356OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8631877632 8545894400 q11Shape25T356=true := by decide

private def q11Shape25T348 : Tree 11 := .split 33 q11Shape25T349 q11Shape25T356
private theorem q11Shape25T348OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 8545894400 q11Shape25T348=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 (8545894400 ||| 2^33) q11Shape25T349 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (41943040 ||| 2^33) 8545894400 q11Shape25T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T349OK,q11Shape25T356OK⟩

def q11Shape25P21 : Tree 11 := q11Shape25T348
theorem q11Shape25P21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 41943040 8545894400 q11Shape25P21=true := q11Shape25T348OK

end Graffiti384b.EffectiveSearch.Q11
