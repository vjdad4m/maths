import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T363 : Tree 11 := (.split 18 (.split 3 (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {2,3,4,7,8,9})))) (.tip (.cover {0,1,2,3,4,9})))
private theorem q11Shape25T363OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 34332479492 q11Shape25T363=true := by decide

private def q11Shape25T364 : Tree 11 := (.split 18 (.split 3 (.split 5 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {1,2,3,4,6,9}))) (.split 10 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {2,3,4,7,8,9})))) (.tip (.cover {1,2,3,4,6,9})))
private theorem q11Shape25T364OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165828 34332479488 q11Shape25T364=true := by decide

private def q11Shape25T362 : Tree 11 := .split 2 q11Shape25T363 q11Shape25T364
private theorem q11Shape25T362OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 34332479488 q11Shape25T362=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 (34332479488 ||| 2^2) q11Shape25T363 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25165824 ||| 2^2) 34332479488 q11Shape25T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T363OK,q11Shape25T364OK⟩

private def q11Shape25T365 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T365OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25169920 34332475392 q11Shape25T365=true := by decide

private def q11Shape25T361 : Tree 11 := .split 12 q11Shape25T362 q11Shape25T365
private theorem q11Shape25T361OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 34332475392 q11Shape25T361=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 (34332475392 ||| 2^12) q11Shape25T362 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25165824 ||| 2^12) 34332475392 q11Shape25T365)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T362OK,q11Shape25T365OK⟩

private def q11Shape25T369 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,5,7,9,10})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9})))) (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T369OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720256 34298921484 q11Shape25T369=true := by decide

private def q11Shape25T370 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,5,7,9,10})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9})))) (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,2,3,4,5,9}))))
private theorem q11Shape25T370OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720768 34298920972 q11Shape25T370=true := by decide

private def q11Shape25T368 : Tree 11 := .split 9 q11Shape25T369 q11Shape25T370
private theorem q11Shape25T368OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720256 34298920972 q11Shape25T368=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720256 (34298920972 ||| 2^9) q11Shape25T369 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (58720256 ||| 2^9) 34298920972 q11Shape25T370)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T369OK,q11Shape25T370OK⟩

private def q11Shape25T371 : Tree 11 := (.split 10 (.split 16 (.split 4 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {1,2,3,4,5,9})))
private theorem q11Shape25T371OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720264 34298920964 q11Shape25T371=true := by decide

private def q11Shape25T367 : Tree 11 := .split 3 q11Shape25T368 q11Shape25T371
private theorem q11Shape25T367OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720256 34298920964 q11Shape25T367=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720256 (34298920964 ||| 2^3) q11Shape25T368 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (58720256 ||| 2^3) 34298920964 q11Shape25T371)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T368OK,q11Shape25T371OK⟩

private def q11Shape25T374 : Tree 11 := (.split 10 (.split 16 (.tip (.cover {0,1,5,7,9,10})) (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9})))) (.split 15 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,5,6,7,9,10}))))
private theorem q11Shape25T374OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720260 34298921480 q11Shape25T374=true := by decide

private def q11Shape25T375 : Tree 11 := (.split 15 (.split 16 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,5,6,7,9,10})))
private theorem q11Shape25T375OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720772 34298920968 q11Shape25T375=true := by decide

private def q11Shape25T373 : Tree 11 := .split 9 q11Shape25T374 q11Shape25T375
private theorem q11Shape25T373OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720260 34298920968 q11Shape25T373=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720260 (34298920968 ||| 2^9) q11Shape25T374 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (58720260 ||| 2^9) 34298920968 q11Shape25T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T374OK,q11Shape25T375OK⟩

private def q11Shape25T376 : Tree 11 := (.split 10 (.split 16 (.split 4 (.split 35 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {1,2,3,4,5,9}))) (.tip (.cover {1,2,3,4,5,9})))
private theorem q11Shape25T376OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720268 34298920960 q11Shape25T376=true := by decide

private def q11Shape25T372 : Tree 11 := .split 3 q11Shape25T373 q11Shape25T376
private theorem q11Shape25T372OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720260 34298920960 q11Shape25T372=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720260 (34298920960 ||| 2^3) q11Shape25T373 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (58720260 ||| 2^3) 34298920960 q11Shape25T376)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T373OK,q11Shape25T376OK⟩

private def q11Shape25T366 : Tree 11 := .split 2 q11Shape25T367 q11Shape25T372
private theorem q11Shape25T366OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720256 34298920960 q11Shape25T366=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 58720256 (34298920960 ||| 2^2) q11Shape25T367 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (58720256 ||| 2^2) 34298920960 q11Shape25T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T367OK,q11Shape25T372OK⟩

private def q11Shape25T360 : Tree 11 := .split 25 q11Shape25T361 q11Shape25T366
private theorem q11Shape25T360OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 34298920960 q11Shape25T360=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 (34298920960 ||| 2^25) q11Shape25T361 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25165824 ||| 2^25) 34298920960 q11Shape25T366)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T361OK,q11Shape25T366OK⟩

private def q11Shape25T377 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T377OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 17205035008 17119051776 q11Shape25T377=true := by decide

private def q11Shape25T359 : Tree 11 := .split 34 q11Shape25T360 q11Shape25T377
private theorem q11Shape25T359OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 17119051776 q11Shape25T359=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 (17119051776 ||| 2^34) q11Shape25T360 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25165824 ||| 2^34) 17119051776 q11Shape25T377)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T360OK,q11Shape25T377OK⟩

private def q11Shape25T378 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape25T378OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 8615100416 8529117184 q11Shape25T378=true := by decide

private def q11Shape25T358 : Tree 11 := .split 33 q11Shape25T359 q11Shape25T378
private theorem q11Shape25T358OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 8529117184 q11Shape25T358=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 (8529117184 ||| 2^33) q11Shape25T359 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (25165824 ||| 2^33) 8529117184 q11Shape25T378)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T359OK,q11Shape25T378OK⟩

def q11Shape25P22 : Tree 11 := q11Shape25T358
theorem q11Shape25P22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 25165824 8529117184 q11Shape25P22=true := q11Shape25T358OK

private def q11Shape25T380 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T380OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4303355904 4234149888 q11Shape25T380=true := by decide

def q11Shape25P23 : Tree 11 := q11Shape25T380
theorem q11Shape25P23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4303355904 4234149888 q11Shape25P23=true := q11Shape25T380OK

private def q11Shape25T382 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T382OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2155872256 2086666240 q11Shape25T382=true := by decide

def q11Shape25P24 : Tree 11 := q11Shape25T382
theorem q11Shape25P24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 2155872256 2086666240 q11Shape25P24=true := q11Shape25T382OK

private def q11Shape25T384 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T384OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 545259520 1549795328 q11Shape25T384=true := by decide

def q11Shape25P25 : Tree 11 := q11Shape25T384
theorem q11Shape25P25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 545259520 1549795328 q11Shape25P25=true := q11Shape25T384OK

private def q11Shape25T386 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape25T386OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 276824064 1281359872 q11Shape25T386=true := by decide

def q11Shape25P26 : Tree 11 := q11Shape25T386
theorem q11Shape25P26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 276824064 1281359872 q11Shape25P26=true := q11Shape25T386OK

private def q11Shape25T388 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape25T388OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 142606336 1147142144 q11Shape25T388=true := by decide

def q11Shape25P27 : Tree 11 := q11Shape25T388
theorem q11Shape25P27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 142606336 1147142144 q11Shape25P27=true := q11Shape25T388OK

private def q11Shape25T390 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape25T390OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 75497472 1080033280 q11Shape25T390=true := by decide

def q11Shape25P28 : Tree 11 := q11Shape25T390
theorem q11Shape25P28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 75497472 1080033280 q11Shape25P28=true := q11Shape25T390OK

end Graffiti384b.EffectiveSearch.Q11
