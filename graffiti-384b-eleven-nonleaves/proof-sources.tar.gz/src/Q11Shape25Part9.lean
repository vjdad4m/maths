import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape25T399 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape25T399OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 34353513996 q11Shape25T399=true := by decide

private def q11Shape25T402 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T402OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4259840 68713448972 q11Shape25T402=true := by decide

private def q11Shape25T403 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 12 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {1,3,5,6,9,10})))) (.split 11 (.split 17 (.split 4 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T403OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363998208 34353710604 q11Shape25T403=true := by decide

private def q11Shape25T401 : Tree 11 := .split 35 q11Shape25T402 q11Shape25T403
private theorem q11Shape25T401OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4259840 34353710604 q11Shape25T401=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4259840 (34353710604 ||| 2^35) q11Shape25T402 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4259840 ||| 2^35) 34353710604 q11Shape25T403)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T402OK,q11Shape25T403OK⟩

private def q11Shape25T404 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape25T404OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4521984 34353448460 q11Shape25T404=true := by decide

private def q11Shape25T400 : Tree 11 := .split 18 q11Shape25T401 q11Shape25T404
private theorem q11Shape25T400OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4259840 34353448460 q11Shape25T400=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4259840 (34353448460 ||| 2^18) q11Shape25T401 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4259840 ||| 2^18) 34353448460 q11Shape25T404)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T401OK,q11Shape25T404OK⟩

private def q11Shape25T398 : Tree 11 := .split 16 q11Shape25T399 q11Shape25T400
private theorem q11Shape25T398OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 34353448460 q11Shape25T398=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (34353448460 ||| 2^16) q11Shape25T399 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^16) 34353448460 q11Shape25T400)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T399OK,q11Shape25T400OK⟩

private def q11Shape25T406 : Tree 11 := (.split 12 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.split 15 (.split 0 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))) (.split 11 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,2,3,4,9}))))) (.tip (.cover {0,1,3,5,9,10})))
private theorem q11Shape25T406OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4195328 34353512972 q11Shape25T406=true := by decide

private def q11Shape25T407 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T407OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4260864 34353447436 q11Shape25T407=true := by decide

private def q11Shape25T405 : Tree 11 := .split 16 q11Shape25T406 q11Shape25T407
private theorem q11Shape25T405OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4195328 34353447436 q11Shape25T405=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4195328 (34353447436 ||| 2^16) q11Shape25T406 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4195328 ||| 2^16) 34353447436 q11Shape25T407)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T406OK,q11Shape25T407OK⟩

private def q11Shape25T397 : Tree 11 := .split 10 q11Shape25T398 q11Shape25T405
private theorem q11Shape25T397OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 34353447436 q11Shape25T397=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (34353447436 ||| 2^10) q11Shape25T398 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^10) 34353447436 q11Shape25T405)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T398OK,q11Shape25T405OK⟩

private def q11Shape25T412 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape25T412OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 68713318428 q11Shape25T412=true := by decide

private def q11Shape25T414 : Tree 11 := (.split 16 (.tip (.cover {0,1,5,8,9,10})) (.split 18 (.split 12 (.tip (.cover {1,2,5,6,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10})))) (.tip (.cover {0,1,4,5,9,10}))))
private theorem q11Shape25T414OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363933184 34353581084 q11Shape25T414=true := by decide

private def q11Shape25T415 : Tree 11 := (.split 16 (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T415OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363934208 34353580060 q11Shape25T415=true := by decide

private def q11Shape25T413 : Tree 11 := .split 10 q11Shape25T414 q11Shape25T415
private theorem q11Shape25T413OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363933184 34353580060 q11Shape25T413=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363933184 (34353580060 ||| 2^10) q11Shape25T414 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34363933184 ||| 2^10) 34353580060 q11Shape25T415)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T414OK,q11Shape25T415OK⟩

private def q11Shape25T411 : Tree 11 := .split 35 q11Shape25T412 q11Shape25T413
private theorem q11Shape25T411OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 34353580060 q11Shape25T411=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 (34353580060 ||| 2^35) q11Shape25T412 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194816 ||| 2^35) 34353580060 q11Shape25T413)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T412OK,q11Shape25T413OK⟩

private def q11Shape25T416 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T416OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194832 34353580044 q11Shape25T416=true := by decide

private def q11Shape25T410 : Tree 11 := .split 4 q11Shape25T411 q11Shape25T416
private theorem q11Shape25T410OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 34353580044 q11Shape25T410=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 (34353580044 ||| 2^4) q11Shape25T411 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194816 ||| 2^4) 34353580044 q11Shape25T416)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T411OK,q11Shape25T416OK⟩

private def q11Shape25T417 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T417OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4325888 34353448972 q11Shape25T417=true := by decide

private def q11Shape25T409 : Tree 11 := .split 17 q11Shape25T410 q11Shape25T417
private theorem q11Shape25T409OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 34353448972 q11Shape25T409=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 (34353448972 ||| 2^17) q11Shape25T410 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194816 ||| 2^17) 34353448972 q11Shape25T417)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T410OK,q11Shape25T417OK⟩

private def q11Shape25T418 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T418OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4196864 34353446924 q11Shape25T418=true := by decide

private def q11Shape25T408 : Tree 11 := .split 11 q11Shape25T409 q11Shape25T418
private theorem q11Shape25T408OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 34353446924 q11Shape25T408=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194816 (34353446924 ||| 2^11) q11Shape25T409 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194816 ||| 2^11) 34353446924 q11Shape25T418)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T409OK,q11Shape25T418OK⟩

private def q11Shape25T396 : Tree 11 := .split 9 q11Shape25T397 q11Shape25T408
private theorem q11Shape25T396OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 34353446924 q11Shape25T396=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (34353446924 ||| 2^9) q11Shape25T397 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^9) 34353446924 q11Shape25T408)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T397OK,q11Shape25T408OK⟩

private def q11Shape25T423 : Tree 11 := (.tip (.cover {0,2,3,4,7,8}))
private theorem q11Shape25T423OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 68713251876 q11Shape25T423=true := by decide

private def q11Shape25T425 : Tree 11 := (.split 15 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10})))) (.split 11 (.split 12 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,3,4,5,6,10}))) (.tip (.cover {1,3,5,6,9,10}))) (.tip (.cover {0,1,2,3,4,9}))))
private theorem q11Shape25T425OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932680 34353514020 q11Shape25T425=true := by decide

private def q11Shape25T426 : Tree 11 := (.split 15 (.split 11 (.split 12 (.tip (.cover {1,4,5,6,9,10})) (.split 13 (.tip (.cover {0,2,4,7,8,10})) (.tip (.cover {0,1,3,5,6,10})))) (.tip (.cover {0,1,2,3,4,9}))) (.tip (.cover {1,5,6,8,9,10})))
private theorem q11Shape25T426OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363933192 34353513508 q11Shape25T426=true := by decide

private def q11Shape25T424 : Tree 11 := .split 9 q11Shape25T425 q11Shape25T426
private theorem q11Shape25T424OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932680 34353513508 q11Shape25T424=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932680 (34353513508 ||| 2^9) q11Shape25T425 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34363932680 ||| 2^9) 34353513508 q11Shape25T426)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T425OK,q11Shape25T426OK⟩

private def q11Shape25T422 : Tree 11 := .split 35 q11Shape25T423 q11Shape25T424
private theorem q11Shape25T422OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 34353513508 q11Shape25T422=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 (34353513508 ||| 2^35) q11Shape25T423 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194312 ||| 2^35) 34353513508 q11Shape25T424)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T423OK,q11Shape25T424OK⟩

private def q11Shape25T427 : Tree 11 := (.tip (.cover {0,1,2,5,9,10}))
private theorem q11Shape25T427OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194344 34353513476 q11Shape25T427=true := by decide

private def q11Shape25T421 : Tree 11 := .split 5 q11Shape25T422 q11Shape25T427
private theorem q11Shape25T421OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 34353513476 q11Shape25T421=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 (34353513476 ||| 2^5) q11Shape25T422 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194312 ||| 2^5) 34353513476 q11Shape25T427)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T422OK,q11Shape25T427OK⟩

private def q11Shape25T428 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T428OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4259848 34353447940 q11Shape25T428=true := by decide

private def q11Shape25T420 : Tree 11 := .split 16 q11Shape25T421 q11Shape25T428
private theorem q11Shape25T420OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 34353447940 q11Shape25T420=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 (34353447940 ||| 2^16) q11Shape25T421 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194312 ||| 2^16) 34353447940 q11Shape25T428)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T421OK,q11Shape25T428OK⟩

private def q11Shape25T429 : Tree 11 := (.tip (.cover {1,2,3,4,5,9}))
private theorem q11Shape25T429OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4195336 34353446916 q11Shape25T429=true := by decide

private def q11Shape25T419 : Tree 11 := .split 10 q11Shape25T420 q11Shape25T429
private theorem q11Shape25T419OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 34353446916 q11Shape25T419=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194312 (34353446916 ||| 2^10) q11Shape25T420 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194312 ||| 2^10) 34353446916 q11Shape25T429)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T420OK,q11Shape25T429OK⟩

private def q11Shape25T395 : Tree 11 := .split 3 q11Shape25T396 q11Shape25T419
private theorem q11Shape25T395OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 34353446916 q11Shape25T395=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (34353446916 ||| 2^3) q11Shape25T396 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^3) 34353446916 q11Shape25T419)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T396OK,q11Shape25T419OK⟩

private def q11Shape25T435 : Tree 11 := (.tip (.cover {2,3,4,6,7,8}))
private theorem q11Shape25T435OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 68713318424 q11Shape25T435=true := by decide

private def q11Shape25T438 : Tree 11 := (.split 16 (.tip (.cover {0,1,5,8,9,10})) (.split 12 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,3,5,6,8,10}))) (.tip (.cover {1,3,5,6,9,10}))))
private theorem q11Shape25T438OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932676 34353581592 q11Shape25T438=true := by decide

private def q11Shape25T439 : Tree 11 := (.split 15 (.split 16 (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {1,5,6,8,9,10})))
private theorem q11Shape25T439OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363933700 34353580568 q11Shape25T439=true := by decide

private def q11Shape25T437 : Tree 11 := .split 10 q11Shape25T438 q11Shape25T439
private theorem q11Shape25T437OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932676 34353580568 q11Shape25T437=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932676 (34353580568 ||| 2^10) q11Shape25T438 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34363932676 ||| 2^10) 34353580568 q11Shape25T439)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T438OK,q11Shape25T439OK⟩

private def q11Shape25T440 : Tree 11 := (.split 15 (.split 16 (.split 10 (.tip (.cover {0,1,5,8,9,10})) (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,3,5,9,10})))) (.tip (.cover {1,5,6,8,9,10}))) (.tip (.cover {1,5,6,8,9,10})))
private theorem q11Shape25T440OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363933188 34353580056 q11Shape25T440=true := by decide

private def q11Shape25T436 : Tree 11 := .split 9 q11Shape25T437 q11Shape25T440
private theorem q11Shape25T436OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932676 34353580056 q11Shape25T436=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 34363932676 (34353580056 ||| 2^9) q11Shape25T437 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (34363932676 ||| 2^9) 34353580056 q11Shape25T440)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T437OK,q11Shape25T440OK⟩

private def q11Shape25T434 : Tree 11 := .split 35 q11Shape25T435 q11Shape25T436
private theorem q11Shape25T434OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 34353580056 q11Shape25T434=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 (34353580056 ||| 2^35) q11Shape25T435 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194308 ||| 2^35) 34353580056 q11Shape25T436)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T435OK,q11Shape25T436OK⟩

private def q11Shape25T441 : Tree 11 := (.split 10 (.split 16 (.split 5 (.split 35 (.tip (.cover {2,3,4,6,7,8})) (.split 13 (.split 12 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {1,3,4,5,6,10})))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {2,3,4,7,8,9}))) (.tip (.cover {2,3,4,7,8,9})))
private theorem q11Shape25T441OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194316 34353580048 q11Shape25T441=true := by decide

private def q11Shape25T433 : Tree 11 := .split 3 q11Shape25T434 q11Shape25T441
private theorem q11Shape25T433OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 34353580048 q11Shape25T433=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 (34353580048 ||| 2^3) q11Shape25T434 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194308 ||| 2^3) 34353580048 q11Shape25T441)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T434OK,q11Shape25T441OK⟩

private def q11Shape25T442 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T442OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194324 34353580032 q11Shape25T442=true := by decide

private def q11Shape25T432 : Tree 11 := .split 4 q11Shape25T433 q11Shape25T442
private theorem q11Shape25T432OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 34353580032 q11Shape25T432=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 (34353580032 ||| 2^4) q11Shape25T433 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194308 ||| 2^4) 34353580032 q11Shape25T442)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T433OK,q11Shape25T442OK⟩

private def q11Shape25T443 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T443OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4325380 34353448960 q11Shape25T443=true := by decide

private def q11Shape25T431 : Tree 11 := .split 17 q11Shape25T432 q11Shape25T443
private theorem q11Shape25T431OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 34353448960 q11Shape25T431=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 (34353448960 ||| 2^17) q11Shape25T432 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194308 ||| 2^17) 34353448960 q11Shape25T443)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T432OK,q11Shape25T443OK⟩

private def q11Shape25T444 : Tree 11 := (.tip (.cover {0,1,2,3,4,9}))
private theorem q11Shape25T444OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4196356 34353446912 q11Shape25T444=true := by decide

private def q11Shape25T430 : Tree 11 := .split 11 q11Shape25T431 q11Shape25T444
private theorem q11Shape25T430OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 34353446912 q11Shape25T430=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194308 (34353446912 ||| 2^11) q11Shape25T431 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194308 ||| 2^11) 34353446912 q11Shape25T444)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T431OK,q11Shape25T444OK⟩

private def q11Shape25T394 : Tree 11 := .split 2 q11Shape25T395 q11Shape25T430
private theorem q11Shape25T394OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 34353446912 q11Shape25T394=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (34353446912 ||| 2^2) q11Shape25T395 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^2) 34353446912 q11Shape25T430)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T395OK,q11Shape25T430OK⟩

private def q11Shape25T447 : Tree 11 := (.split 15 (.split 3 (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9})))) (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {2,3,4,5,8,10})))) (.tip (.cover {0,1,2,3,4,10})))
private theorem q11Shape25T447OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4299161600 30058480132 q11Shape25T447=true := by decide

private def q11Shape25T448 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T448OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4299162112 30058479620 q11Shape25T448=true := by decide

private def q11Shape25T446 : Tree 11 := .split 9 q11Shape25T447 q11Shape25T448
private theorem q11Shape25T446OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4299161600 30058479620 q11Shape25T446=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4299161600 (30058479620 ||| 2^9) q11Shape25T447 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4299161600 ||| 2^9) 30058479620 q11Shape25T448)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T447OK,q11Shape25T448OK⟩

private def q11Shape25T449 : Tree 11 := (.tip (.cover {0,1,2,3,4,10}))
private theorem q11Shape25T449OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4299161604 30058479616 q11Shape25T449=true := by decide

private def q11Shape25T445 : Tree 11 := .split 2 q11Shape25T446 q11Shape25T449
private theorem q11Shape25T445OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4299161600 30058479616 q11Shape25T445=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4299161600 (30058479616 ||| 2^2) q11Shape25T446 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4299161600 ||| 2^2) 30058479616 q11Shape25T449)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T446OK,q11Shape25T449OK⟩

private def q11Shape25T393 : Tree 11 := .split 32 q11Shape25T394 q11Shape25T445
private theorem q11Shape25T393OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 30058479616 q11Shape25T393=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 (30058479616 ||| 2^32) q11Shape25T394 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) (4194304 ||| 2^32) 30058479616 q11Shape25T445)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape25T394OK,q11Shape25T445OK⟩

def q11Shape25P29 : Tree 11 := q11Shape25T393
theorem q11Shape25P29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,6,6,3⟩) 4194304 30058479616 q11Shape25P29=true := q11Shape25T393OK

end Graffiti384b.EffectiveSearch.Q11
