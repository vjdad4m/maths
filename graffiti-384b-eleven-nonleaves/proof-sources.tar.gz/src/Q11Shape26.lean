import Q11Shape26Part0
import Q11Shape26Part1
import Q11Shape26Part2
import Q11Shape26Part3
import Q11Shape26Part4
import Q11Shape26Part5
import Q11Shape26Part6
import Q11Shape26Part7

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26M79 : Tree 11 := .split 10 q11Shape26P1 q11Shape26P2
private theorem q11Shape26M79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 34292629512 q11Shape26M79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 (34292629512 ||| 2^10) q11Shape26P1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738368 ||| 2^10) 34292629512 q11Shape26P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26P1OK,q11Shape26P2OK⟩
private def q11Shape26M115 : Tree 11 := .split 3 q11Shape26M79 q11Shape26P3
private theorem q11Shape26M115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 34292629504 q11Shape26M115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 (34292629504 ||| 2^3) q11Shape26M79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738368 ||| 2^3) 34292629504 q11Shape26P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M79OK,q11Shape26P3OK⟩
private def q11Shape26M116 : Tree 11 := .split 35 q11Shape26P0 q11Shape26M115
private theorem q11Shape26M116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 34292629504 q11Shape26M116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (34292629504 ||| 2^35) q11Shape26P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^35) 34292629504 q11Shape26M115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26P0OK,q11Shape26M115OK⟩
private def q11Shape26M171 : Tree 11 := .split 16 q11Shape26P4 q11Shape26P5
private theorem q11Shape26M171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 51472499720 q11Shape26M171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 (51472499720 ||| 2^16) q11Shape26P4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869184 ||| 2^16) 51472499720 q11Shape26P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26P4OK,q11Shape26P5OK⟩
private def q11Shape26M199 : Tree 11 := .split 10 q11Shape26M171 q11Shape26P6
private theorem q11Shape26M199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 51472498696 q11Shape26M199=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 (51472498696 ||| 2^10) q11Shape26M171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869184 ||| 2^10) 51472498696 q11Shape26P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M171OK,q11Shape26P6OK⟩
private def q11Shape26M237 : Tree 11 := .split 3 q11Shape26M199 q11Shape26P7
private theorem q11Shape26M237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 51472498688 q11Shape26M237=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 (51472498688 ||| 2^3) q11Shape26M199 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869184 ||| 2^3) 51472498688 q11Shape26P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M199OK,q11Shape26P7OK⟩
private def q11Shape26M239 : Tree 11 := .split 35 q11Shape26M237 q11Shape26P8
private theorem q11Shape26M239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 17112760320 q11Shape26M239=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 (17112760320 ||| 2^35) q11Shape26M237 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869184 ||| 2^35) 17112760320 q11Shape26P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M237OK,q11Shape26P8OK⟩
private def q11Shape26M240 : Tree 11 := .split 34 q11Shape26M116 q11Shape26M239
private theorem q11Shape26M240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 17112760320 q11Shape26M240=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (17112760320 ||| 2^34) q11Shape26M116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^34) 17112760320 q11Shape26M239)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M116OK,q11Shape26M239OK⟩
private def q11Shape26M307 : Tree 11 := .split 16 q11Shape26P9 q11Shape26P10
private theorem q11Shape26M307OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 60062434312 q11Shape26M307=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 (60062434312 ||| 2^16) q11Shape26P9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934592 ||| 2^16) 60062434312 q11Shape26P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26P9OK,q11Shape26P10OK⟩
private def q11Shape26M343 : Tree 11 := .split 10 q11Shape26M307 q11Shape26P11
private theorem q11Shape26M343OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 60062433288 q11Shape26M343=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 (60062433288 ||| 2^10) q11Shape26M307 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934592 ||| 2^10) 60062433288 q11Shape26P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M307OK,q11Shape26P11OK⟩
private def q11Shape26M387 : Tree 11 := .split 3 q11Shape26M343 q11Shape26P12
private theorem q11Shape26M387OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 60062433280 q11Shape26M387=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 (60062433280 ||| 2^3) q11Shape26M343 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934592 ||| 2^3) 60062433280 q11Shape26P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M343OK,q11Shape26P12OK⟩
private def q11Shape26M389 : Tree 11 := .split 35 q11Shape26M387 q11Shape26P13
private theorem q11Shape26M389OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 25702694912 q11Shape26M389=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 (25702694912 ||| 2^35) q11Shape26M387 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934592 ||| 2^35) 25702694912 q11Shape26P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M387OK,q11Shape26P13OK⟩
private def q11Shape26M391 : Tree 11 := .split 34 q11Shape26M389 q11Shape26P14
private theorem q11Shape26M391OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 8522825728 q11Shape26M391=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 (8522825728 ||| 2^34) q11Shape26M389 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934592 ||| 2^34) 8522825728 q11Shape26P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M389OK,q11Shape26P14OK⟩
private def q11Shape26M392 : Tree 11 := .split 33 q11Shape26M240 q11Shape26M391
private theorem q11Shape26M392OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 8522825728 q11Shape26M392=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (8522825728 ||| 2^33) q11Shape26M240 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^33) 8522825728 q11Shape26M391)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M240OK,q11Shape26M391OK⟩
private def q11Shape26M394 : Tree 11 := .split 32 q11Shape26M392 q11Shape26P15
private theorem q11Shape26M394OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 4227858432 q11Shape26M394=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (4227858432 ||| 2^32) q11Shape26M392 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^32) 4227858432 q11Shape26P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M392OK,q11Shape26P15OK⟩
private def q11Shape26M396 : Tree 11 := .split 31 q11Shape26M394 q11Shape26P16
private theorem q11Shape26M396OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 2080374784 q11Shape26M396=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (2080374784 ||| 2^31) q11Shape26M394 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^31) 2080374784 q11Shape26P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M394OK,q11Shape26P16OK⟩
private def q11Shape26M398 : Tree 11 := .split 30 q11Shape26M396 q11Shape26P17
private theorem q11Shape26M398OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 1006632960 q11Shape26M398=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (1006632960 ||| 2^30) q11Shape26M396 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^30) 1006632960 q11Shape26P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M396OK,q11Shape26P17OK⟩
private def q11Shape26M400 : Tree 11 := .split 29 q11Shape26M398 q11Shape26P18
private theorem q11Shape26M400OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 469762048 q11Shape26M400=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (469762048 ||| 2^29) q11Shape26M398 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^29) 469762048 q11Shape26P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M398OK,q11Shape26P18OK⟩
private def q11Shape26M402 : Tree 11 := .split 28 q11Shape26M400 q11Shape26P19
private theorem q11Shape26M402OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 201326592 q11Shape26M402=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (201326592 ||| 2^28) q11Shape26M400 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^28) 201326592 q11Shape26P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M400OK,q11Shape26P19OK⟩
private def q11Shape26M404 : Tree 11 := .split 27 q11Shape26M402 q11Shape26P20
private theorem q11Shape26M404OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 67108864 q11Shape26M404=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (67108864 ||| 2^27) q11Shape26M402 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^27) 67108864 q11Shape26P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M402OK,q11Shape26P20OK⟩
private def q11Shape26M406 : Tree 11 := .split 26 q11Shape26M404 q11Shape26P21
private theorem q11Shape26M406OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 0 q11Shape26M406=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 (0 ||| 2^26) q11Shape26M404 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (0 ||| 2^26) 0 q11Shape26P21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26M404OK,q11Shape26P21OK⟩

theorem q11Shape26_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 26) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 26) b) (adj 11 (forms 26) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 26)) adj_mono b H q11Shape26M406 q11Shape26M406OK

#print axioms q11Shape26_cover

end Graffiti384b.EffectiveSearch.Q11
