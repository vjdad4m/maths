import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T0 : Tree 11 := (.tip (.cover {2,3,4,5,6,7}))
private theorem q11Shape26T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 68652367872 q11Shape26T0=true := by decide

def q11Shape26P0 : Tree 11 := q11Shape26T0
theorem q11Shape26P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 0 68652367872 q11Shape26P0=true := q11Shape26T0OK

private def q11Shape26T3 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape26T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 34294793224 q11Shape26T3=true := by decide

private def q11Shape26T8 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 34297023512 q11Shape26T8=true := by decide

private def q11Shape26T10 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,3,5,7,8,9})))))
private theorem q11Shape26T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835536 34297027592 q11Shape26T10=true := by decide

private def q11Shape26T12 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,4,5,7,8,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,3,4,5,7,9}))))
private theorem q11Shape26T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361839632 34297031688 q11Shape26T12=true := by decide

private def q11Shape26T13 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,3,4,5,7,10}))) (.split 18 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,3,4,5,7,9}))))
private theorem q11Shape26T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361847824 34297023496 q11Shape26T13=true := by decide

private def q11Shape26T11 : Tree 11 := .split 13 q11Shape26T12 q11Shape26T13
private theorem q11Shape26T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361839632 34297023496 q11Shape26T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361839632 (34297023496 ||| 2^13) q11Shape26T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361839632 ||| 2^13) 34297023496 q11Shape26T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T12OK,q11Shape26T13OK⟩

private def q11Shape26T9 : Tree 11 := .split 12 q11Shape26T10 q11Shape26T11
private theorem q11Shape26T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835536 34297023496 q11Shape26T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835536 (34297023496 ||| 2^12) q11Shape26T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361835536 ||| 2^12) 34297023496 q11Shape26T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T10OK,q11Shape26T11OK⟩

private def q11Shape26T7 : Tree 11 := .split 4 q11Shape26T8 q11Shape26T9
private theorem q11Shape26T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 34297023496 q11Shape26T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 (34297023496 ||| 2^4) q11Shape26T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361835520 ||| 2^4) 34297023496 q11Shape26T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T8OK,q11Shape26T9OK⟩

private def q11Shape26T16 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,2,3,5,7,9})) (.split 19 (.split 20 (.split 23 (.tip (.cover {1,2,3,4,6,9})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))))))
private theorem q11Shape26T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361966592 34296896536 q11Shape26T16=true := by decide

private def q11Shape26T18 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,4,6,8,10}))) (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.tip (.cover {0,1,4,6,8,10})))) (.split 18 (.tip (.cover {0,2,3,5,7,9})) (.tip (.cover {0,1,3,4,6,9}))))
private theorem q11Shape26T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361970688 34296900632 q11Shape26T18=true := by decide

private def q11Shape26T19 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,3,4,6,10}))) (.split 18 (.tip (.cover {0,2,3,5,7,9})) (.tip (.cover {0,1,3,4,6,9}))))
private theorem q11Shape26T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361978880 34296892440 q11Shape26T19=true := by decide

private def q11Shape26T17 : Tree 11 := .split 13 q11Shape26T18 q11Shape26T19
private theorem q11Shape26T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361970688 34296892440 q11Shape26T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361970688 (34296892440 ||| 2^13) q11Shape26T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361970688 ||| 2^13) 34296892440 q11Shape26T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T18OK,q11Shape26T19OK⟩

private def q11Shape26T15 : Tree 11 := .split 12 q11Shape26T16 q11Shape26T17
private theorem q11Shape26T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361966592 34296892440 q11Shape26T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361966592 (34296892440 ||| 2^12) q11Shape26T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361966592 ||| 2^12) 34296892440 q11Shape26T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T16OK,q11Shape26T17OK⟩

private def q11Shape26T20 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361966608 34296892424 q11Shape26T20=true := by decide

private def q11Shape26T14 : Tree 11 := .split 4 q11Shape26T15 q11Shape26T20
private theorem q11Shape26T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361966592 34296892424 q11Shape26T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361966592 (34296892424 ||| 2^4) q11Shape26T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361966592 ||| 2^4) 34296892424 q11Shape26T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T15OK,q11Shape26T20OK⟩

private def q11Shape26T6 : Tree 11 := .split 17 q11Shape26T7 q11Shape26T14
private theorem q11Shape26T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 34296892424 q11Shape26T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 (34296892424 ||| 2^17) q11Shape26T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361835520 ||| 2^17) 34296892424 q11Shape26T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T7OK,q11Shape26T14OK⟩

private def q11Shape26T24 : Tree 11 := (.split 13 (.tip (.cover {0,2,4,5,7,10})) (.tip (.cover {0,1,3,6,8,10})))
private theorem q11Shape26T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837568 34297025560 q11Shape26T24=true := by decide

private def q11Shape26T25 : Tree 11 := (.split 13 (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.split 20 (.tip (.cover {0,1,2,3,5,9})) (.split 23 (.tip (.cover {1,2,3,4,6,9})) (.tip (.cover {0,1,3,5,9,10}))))) (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.tip (.cover {0,1,3,4,6,10})))) (.tip (.cover {0,1,3,6,8,9}))) (.tip (.cover {0,1,3,6,8,10})))
private theorem q11Shape26T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361841664 34297021464 q11Shape26T25=true := by decide

private def q11Shape26T23 : Tree 11 := .split 12 q11Shape26T24 q11Shape26T25
private theorem q11Shape26T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837568 34297021464 q11Shape26T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837568 (34297021464 ||| 2^12) q11Shape26T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361837568 ||| 2^12) 34297021464 q11Shape26T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T24OK,q11Shape26T25OK⟩

private def q11Shape26T26 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837584 34297021448 q11Shape26T26=true := by decide

private def q11Shape26T22 : Tree 11 := .split 4 q11Shape26T23 q11Shape26T26
private theorem q11Shape26T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837568 34297021448 q11Shape26T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837568 (34297021448 ||| 2^4) q11Shape26T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361837568 ||| 2^4) 34297021448 q11Shape26T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T23OK,q11Shape26T26OK⟩

private def q11Shape26T27 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361968640 34296890376 q11Shape26T27=true := by decide

private def q11Shape26T21 : Tree 11 := .split 17 q11Shape26T22 q11Shape26T27
private theorem q11Shape26T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837568 34296890376 q11Shape26T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361837568 (34296890376 ||| 2^17) q11Shape26T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361837568 ||| 2^17) 34296890376 q11Shape26T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T22OK,q11Shape26T27OK⟩

private def q11Shape26T5 : Tree 11 := .split 11 q11Shape26T6 q11Shape26T21
private theorem q11Shape26T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 34296890376 q11Shape26T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 (34296890376 ||| 2^11) q11Shape26T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361835520 ||| 2^11) 34296890376 q11Shape26T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T6OK,q11Shape26T21OK⟩

private def q11Shape26T28 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape26T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34366029824 34292696072 q11Shape26T28=true := by decide

private def q11Shape26T4 : Tree 11 := .split 22 q11Shape26T5 q11Shape26T28
private theorem q11Shape26T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 34292696072 q11Shape26T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835520 (34292696072 ||| 2^22) q11Shape26T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34361835520 ||| 2^22) 34292696072 q11Shape26T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T5OK,q11Shape26T28OK⟩

private def q11Shape26T2 : Tree 11 := .split 21 q11Shape26T3 q11Shape26T4
private theorem q11Shape26T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 34292696072 q11Shape26T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 (34292696072 ||| 2^21) q11Shape26T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738368 ||| 2^21) 34292696072 q11Shape26T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T3OK,q11Shape26T4OK⟩

private def q11Shape26T34 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 34299055128 q11Shape26T34=true := by decide

private def q11Shape26T36 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {1,2,3,5,6,9})) (.split 19 (.split 20 (.split 23 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,3,4,5,7,9}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))))))
private theorem q11Shape26T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803920 34299059208 q11Shape26T36=true := by decide

private def q11Shape26T38 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,7,8,10}))) (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.tip (.cover {0,1,4,7,8,10})))) (.split 18 (.tip (.cover {1,2,3,5,6,9})) (.tip (.cover {0,1,3,4,7,9}))))
private theorem q11Shape26T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359808016 34299063304 q11Shape26T38=true := by decide

private def q11Shape26T39 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,3,4,7,10}))) (.split 18 (.tip (.cover {1,2,3,5,6,9})) (.tip (.cover {0,1,3,4,7,9}))))
private theorem q11Shape26T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359816208 34299055112 q11Shape26T39=true := by decide

private def q11Shape26T37 : Tree 11 := .split 13 q11Shape26T38 q11Shape26T39
private theorem q11Shape26T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359808016 34299055112 q11Shape26T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359808016 (34299055112 ||| 2^13) q11Shape26T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359808016 ||| 2^13) 34299055112 q11Shape26T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T38OK,q11Shape26T39OK⟩

private def q11Shape26T35 : Tree 11 := .split 12 q11Shape26T36 q11Shape26T37
private theorem q11Shape26T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803920 34299055112 q11Shape26T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803920 (34299055112 ||| 2^12) q11Shape26T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359803920 ||| 2^12) 34299055112 q11Shape26T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T36OK,q11Shape26T37OK⟩

private def q11Shape26T33 : Tree 11 := .split 4 q11Shape26T34 q11Shape26T35
private theorem q11Shape26T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 34299055112 q11Shape26T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 (34299055112 ||| 2^4) q11Shape26T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359803904 ||| 2^4) 34299055112 q11Shape26T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T34OK,q11Shape26T35OK⟩

private def q11Shape26T40 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359934976 34298924040 q11Shape26T40=true := by decide

private def q11Shape26T32 : Tree 11 := .split 17 q11Shape26T33 q11Shape26T40
private theorem q11Shape26T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 34298924040 q11Shape26T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 (34298924040 ||| 2^17) q11Shape26T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359803904 ||| 2^17) 34298924040 q11Shape26T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T33OK,q11Shape26T40OK⟩

private def q11Shape26T42 : Tree 11 := (.split 4 (.split 12 (.split 13 (.tip (.cover {0,2,4,5,7,10})) (.tip (.cover {0,1,3,6,8,10}))) (.split 13 (.split 14 (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,6,8,9}))) (.tip (.cover {0,1,3,6,8,10})))) (.tip (.cover {2,3,4,5,6,9})))
private theorem q11Shape26T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359805952 34299053064 q11Shape26T42=true := by decide

private def q11Shape26T43 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359937024 34298921992 q11Shape26T43=true := by decide

private def q11Shape26T41 : Tree 11 := .split 17 q11Shape26T42 q11Shape26T43
private theorem q11Shape26T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359805952 34298921992 q11Shape26T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359805952 (34298921992 ||| 2^17) q11Shape26T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359805952 ||| 2^17) 34298921992 q11Shape26T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T42OK,q11Shape26T43OK⟩

private def q11Shape26T31 : Tree 11 := .split 11 q11Shape26T32 q11Shape26T41
private theorem q11Shape26T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 34298921992 q11Shape26T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 (34298921992 ||| 2^11) q11Shape26T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359803904 ||| 2^11) 34298921992 q11Shape26T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T32OK,q11Shape26T41OK⟩

private def q11Shape26T48 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {1,2,3,5,6,9})) (.split 19 (.split 20 (.split 23 (.tip (.cover {0,2,3,4,7,9})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))))))
private theorem q11Shape26T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 34294864920 q11Shape26T48=true := by decide

private def q11Shape26T50 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,4,7,8,10}))) (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.tip (.cover {0,1,4,7,8,10})))) (.split 18 (.tip (.cover {1,2,3,5,6,9})) (.tip (.cover {0,1,3,4,7,9}))))
private theorem q11Shape26T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364002304 34294869016 q11Shape26T50=true := by decide

private def q11Shape26T51 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,3,4,7,10}))) (.split 18 (.tip (.cover {1,2,3,5,6,9})) (.tip (.cover {0,1,3,4,7,9}))))
private theorem q11Shape26T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364010496 34294860824 q11Shape26T51=true := by decide

private def q11Shape26T49 : Tree 11 := .split 13 q11Shape26T50 q11Shape26T51
private theorem q11Shape26T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364002304 34294860824 q11Shape26T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364002304 (34294860824 ||| 2^13) q11Shape26T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34364002304 ||| 2^13) 34294860824 q11Shape26T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T50OK,q11Shape26T51OK⟩

private def q11Shape26T47 : Tree 11 := .split 12 q11Shape26T48 q11Shape26T49
private theorem q11Shape26T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 34294860824 q11Shape26T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 (34294860824 ||| 2^12) q11Shape26T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363998208 ||| 2^12) 34294860824 q11Shape26T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T48OK,q11Shape26T49OK⟩

private def q11Shape26T52 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998224 34294860808 q11Shape26T52=true := by decide

private def q11Shape26T46 : Tree 11 := .split 4 q11Shape26T47 q11Shape26T52
private theorem q11Shape26T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 34294860808 q11Shape26T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 (34294860808 ||| 2^4) q11Shape26T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363998208 ||| 2^4) 34294860808 q11Shape26T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T47OK,q11Shape26T52OK⟩

private def q11Shape26T53 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364129280 34294729736 q11Shape26T53=true := by decide

private def q11Shape26T45 : Tree 11 := .split 17 q11Shape26T46 q11Shape26T53
private theorem q11Shape26T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 34294729736 q11Shape26T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 (34294729736 ||| 2^17) q11Shape26T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363998208 ||| 2^17) 34294729736 q11Shape26T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T46OK,q11Shape26T53OK⟩

private def q11Shape26T54 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364000256 34294727688 q11Shape26T54=true := by decide

private def q11Shape26T44 : Tree 11 := .split 11 q11Shape26T45 q11Shape26T54
private theorem q11Shape26T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 34294727688 q11Shape26T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363998208 (34294727688 ||| 2^11) q11Shape26T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363998208 ||| 2^11) 34294727688 q11Shape26T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T45OK,q11Shape26T54OK⟩

private def q11Shape26T30 : Tree 11 := .split 22 q11Shape26T31 q11Shape26T44
private theorem q11Shape26T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 34294727688 q11Shape26T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 (34294727688 ||| 2^22) q11Shape26T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359803904 ||| 2^22) 34294727688 q11Shape26T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T31OK,q11Shape26T44OK⟩

private def q11Shape26T55 : Tree 11 := (.tip (.cover {2,3,4,5,7,9}))
private theorem q11Shape26T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361901056 34292630536 q11Shape26T55=true := by decide

private def q11Shape26T29 : Tree 11 := .split 21 q11Shape26T30 q11Shape26T55
private theorem q11Shape26T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 34292630536 q11Shape26T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803904 (34292630536 ||| 2^21) q11Shape26T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359803904 ||| 2^21) 34292630536 q11Shape26T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T30OK,q11Shape26T55OK⟩

private def q11Shape26T1 : Tree 11 := .split 16 q11Shape26T2 q11Shape26T29
private theorem q11Shape26T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 34292630536 q11Shape26T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 (34292630536 ||| 2^16) q11Shape26T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738368 ||| 2^16) 34292630536 q11Shape26T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T2OK,q11Shape26T29OK⟩

def q11Shape26P1 : Tree 11 := q11Shape26T1
theorem q11Shape26P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738368 34292630536 q11Shape26P1=true := q11Shape26T1OK

end Graffiti384b.EffectiveSearch.Q11
