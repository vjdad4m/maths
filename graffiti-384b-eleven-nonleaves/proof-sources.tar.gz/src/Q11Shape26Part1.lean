import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T62 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34299119640 q11Shape26T62=true := by decide

private def q11Shape26T64 : Tree 11 := (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,7,8,10})))
private theorem q11Shape26T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739408 34299123720 q11Shape26T64=true := by decide

private def q11Shape26T65 : Tree 11 := (.split 13 (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.split 20 (.tip (.cover {0,1,2,3,5,9})) (.split 23 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,3,4,5,7,9}))))) (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.tip (.cover {0,1,3,4,7,10})))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10})))
private theorem q11Shape26T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359743504 34299119624 q11Shape26T65=true := by decide

private def q11Shape26T63 : Tree 11 := .split 12 q11Shape26T64 q11Shape26T65
private theorem q11Shape26T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739408 34299119624 q11Shape26T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739408 (34299119624 ||| 2^12) q11Shape26T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359739408 ||| 2^12) 34299119624 q11Shape26T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T64OK,q11Shape26T65OK⟩

private def q11Shape26T61 : Tree 11 := .split 4 q11Shape26T62 q11Shape26T63
private theorem q11Shape26T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34299119624 q11Shape26T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 (34299119624 ||| 2^4) q11Shape26T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359739392 ||| 2^4) 34299119624 q11Shape26T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T62OK,q11Shape26T63OK⟩

private def q11Shape26T66 : Tree 11 := (.split 4 (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,7,8,10}))) (.split 13 (.split 14 (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,3,4,9,10}))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10})))) (.tip (.cover {2,3,4,5,6,9})))
private theorem q11Shape26T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359870464 34298988552 q11Shape26T66=true := by decide

private def q11Shape26T60 : Tree 11 := .split 17 q11Shape26T61 q11Shape26T66
private theorem q11Shape26T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34298988552 q11Shape26T60=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 (34298988552 ||| 2^17) q11Shape26T61 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359739392 ||| 2^17) 34298988552 q11Shape26T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T61OK,q11Shape26T66OK⟩

private def q11Shape26T67 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape26T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359741440 34298986504 q11Shape26T67=true := by decide

private def q11Shape26T59 : Tree 11 := .split 11 q11Shape26T60 q11Shape26T67
private theorem q11Shape26T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34298986504 q11Shape26T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 (34298986504 ||| 2^11) q11Shape26T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359739392 ||| 2^11) 34298986504 q11Shape26T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T60OK,q11Shape26T67OK⟩

private def q11Shape26T72 : Tree 11 := (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.tip (.cover {0,1,3,7,8,10})))
private theorem q11Shape26T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 34294929432 q11Shape26T72=true := by decide

private def q11Shape26T73 : Tree 11 := (.split 13 (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.split 20 (.tip (.cover {0,1,2,3,5,9})) (.split 23 (.tip (.cover {0,2,3,4,7,9})) (.tip (.cover {0,1,3,5,9,10}))))) (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.tip (.cover {0,1,3,4,7,10})))) (.tip (.cover {0,1,3,7,8,9}))) (.tip (.cover {0,1,3,7,8,10})))
private theorem q11Shape26T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363937792 34294925336 q11Shape26T73=true := by decide

private def q11Shape26T71 : Tree 11 := .split 12 q11Shape26T72 q11Shape26T73
private theorem q11Shape26T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 34294925336 q11Shape26T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 (34294925336 ||| 2^12) q11Shape26T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363933696 ||| 2^12) 34294925336 q11Shape26T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T72OK,q11Shape26T73OK⟩

private def q11Shape26T74 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933712 34294925320 q11Shape26T74=true := by decide

private def q11Shape26T70 : Tree 11 := .split 4 q11Shape26T71 q11Shape26T74
private theorem q11Shape26T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 34294925320 q11Shape26T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 (34294925320 ||| 2^4) q11Shape26T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363933696 ||| 2^4) 34294925320 q11Shape26T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T71OK,q11Shape26T74OK⟩

private def q11Shape26T75 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364064768 34294794248 q11Shape26T75=true := by decide

private def q11Shape26T69 : Tree 11 := .split 17 q11Shape26T70 q11Shape26T75
private theorem q11Shape26T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 34294794248 q11Shape26T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 (34294794248 ||| 2^17) q11Shape26T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363933696 ||| 2^17) 34294794248 q11Shape26T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T70OK,q11Shape26T75OK⟩

private def q11Shape26T76 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape26T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363935744 34294792200 q11Shape26T76=true := by decide

private def q11Shape26T68 : Tree 11 := .split 11 q11Shape26T69 q11Shape26T76
private theorem q11Shape26T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 34294792200 q11Shape26T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363933696 (34294792200 ||| 2^11) q11Shape26T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363933696 ||| 2^11) 34294792200 q11Shape26T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T69OK,q11Shape26T76OK⟩

private def q11Shape26T58 : Tree 11 := .split 22 q11Shape26T59 q11Shape26T68
private theorem q11Shape26T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34294792200 q11Shape26T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 (34294792200 ||| 2^22) q11Shape26T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359739392 ||| 2^22) 34294792200 q11Shape26T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T59OK,q11Shape26T68OK⟩

private def q11Shape26T77 : Tree 11 := (.tip (.cover {2,3,4,5,7,9}))
private theorem q11Shape26T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361836544 34292695048 q11Shape26T77=true := by decide

private def q11Shape26T57 : Tree 11 := .split 21 q11Shape26T58 q11Shape26T77
private theorem q11Shape26T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34292695048 q11Shape26T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 (34292695048 ||| 2^21) q11Shape26T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359739392 ||| 2^21) 34292695048 q11Shape26T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T58OK,q11Shape26T77OK⟩

private def q11Shape26T78 : Tree 11 := (.tip (.cover {2,3,4,5,7,9}))
private theorem q11Shape26T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359804928 34292629512 q11Shape26T78=true := by decide

private def q11Shape26T56 : Tree 11 := .split 16 q11Shape26T57 q11Shape26T78
private theorem q11Shape26T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34292629512 q11Shape26T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 (34292629512 ||| 2^16) q11Shape26T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359739392 ||| 2^16) 34292629512 q11Shape26T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T57OK,q11Shape26T78OK⟩

def q11Shape26P2 : Tree 11 := q11Shape26T56
theorem q11Shape26P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739392 34292629512 q11Shape26P2=true := q11Shape26T56OK

private def q11Shape26T86 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34299120640 q11Shape26T86=true := by decide

private def q11Shape26T89 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,2,3,5,7,9})) (.split 19 (.split 20 (.split 23 (.tip (.cover {0,1,2,4,9,10})) (.tip (.cover {0,2,3,7,8,9}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))))))
private theorem q11Shape26T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359869448 34298993680 q11Shape26T89=true := by decide

private def q11Shape26T91 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,4,6,8,10}))) (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.tip (.cover {0,1,4,6,8,10})))) (.split 18 (.tip (.cover {0,2,3,5,7,9})) (.tip (.cover {0,1,3,4,6,9}))))
private theorem q11Shape26T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359873544 34298997776 q11Shape26T91=true := by decide

private def q11Shape26T92 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,3,4,6,10}))) (.split 18 (.tip (.cover {0,2,3,5,7,9})) (.tip (.cover {0,1,3,4,6,9}))))
private theorem q11Shape26T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359881736 34298989584 q11Shape26T92=true := by decide

private def q11Shape26T90 : Tree 11 := .split 13 q11Shape26T91 q11Shape26T92
private theorem q11Shape26T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359873544 34298989584 q11Shape26T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359873544 (34298989584 ||| 2^13) q11Shape26T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359873544 ||| 2^13) 34298989584 q11Shape26T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T91OK,q11Shape26T92OK⟩

private def q11Shape26T88 : Tree 11 := .split 12 q11Shape26T89 q11Shape26T90
private theorem q11Shape26T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359869448 34298989584 q11Shape26T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359869448 (34298989584 ||| 2^12) q11Shape26T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359869448 ||| 2^12) 34298989584 q11Shape26T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T89OK,q11Shape26T90OK⟩

private def q11Shape26T93 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359869464 34298989568 q11Shape26T93=true := by decide

private def q11Shape26T87 : Tree 11 := .split 4 q11Shape26T88 q11Shape26T93
private theorem q11Shape26T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359869448 34298989568 q11Shape26T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359869448 (34298989568 ||| 2^4) q11Shape26T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359869448 ||| 2^4) 34298989568 q11Shape26T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T88OK,q11Shape26T93OK⟩

private def q11Shape26T85 : Tree 11 := .split 17 q11Shape26T86 q11Shape26T87
private theorem q11Shape26T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34298989568 q11Shape26T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 (34298989568 ||| 2^17) q11Shape26T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738376 ||| 2^17) 34298989568 q11Shape26T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T86OK,q11Shape26T87OK⟩

private def q11Shape26T97 : Tree 11 := (.split 13 (.tip (.cover {0,2,4,5,7,10})) (.tip (.cover {0,1,3,6,8,10})))
private theorem q11Shape26T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740424 34299122704 q11Shape26T97=true := by decide

private def q11Shape26T98 : Tree 11 := (.split 13 (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.split 20 (.tip (.cover {0,1,2,3,5,9})) (.split 23 (.tip (.cover {0,1,2,3,9,10})) (.tip (.cover {0,2,4,7,8,9}))))) (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.tip (.cover {0,1,3,4,6,10})))) (.tip (.cover {0,1,3,6,8,9}))) (.tip (.cover {0,1,3,6,8,10})))
private theorem q11Shape26T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359744520 34299118608 q11Shape26T98=true := by decide

private def q11Shape26T96 : Tree 11 := .split 12 q11Shape26T97 q11Shape26T98
private theorem q11Shape26T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740424 34299118608 q11Shape26T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740424 (34299118608 ||| 2^12) q11Shape26T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359740424 ||| 2^12) 34299118608 q11Shape26T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T97OK,q11Shape26T98OK⟩

private def q11Shape26T99 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740440 34299118592 q11Shape26T99=true := by decide

private def q11Shape26T95 : Tree 11 := .split 4 q11Shape26T96 q11Shape26T99
private theorem q11Shape26T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740424 34299118592 q11Shape26T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740424 (34299118592 ||| 2^4) q11Shape26T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359740424 ||| 2^4) 34299118592 q11Shape26T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T96OK,q11Shape26T99OK⟩

private def q11Shape26T100 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359871496 34298987520 q11Shape26T100=true := by decide

private def q11Shape26T94 : Tree 11 := .split 17 q11Shape26T95 q11Shape26T100
private theorem q11Shape26T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740424 34298987520 q11Shape26T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359740424 (34298987520 ||| 2^17) q11Shape26T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359740424 ||| 2^17) 34298987520 q11Shape26T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T95OK,q11Shape26T100OK⟩

private def q11Shape26T84 : Tree 11 := .split 11 q11Shape26T85 q11Shape26T94
private theorem q11Shape26T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34298987520 q11Shape26T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 (34298987520 ||| 2^11) q11Shape26T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738376 ||| 2^11) 34298987520 q11Shape26T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T85OK,q11Shape26T94OK⟩

private def q11Shape26T105 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,2,3,7,8,9})))))
private theorem q11Shape26T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 34294930448 q11Shape26T105=true := by decide

private def q11Shape26T107 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.split 18 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,2,3,4,7,9}))))
private theorem q11Shape26T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363936776 34294934544 q11Shape26T107=true := by decide

private def q11Shape26T108 : Tree 11 := (.split 14 (.split 18 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,2,3,4,7,10}))) (.split 18 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,2,3,4,7,9}))))
private theorem q11Shape26T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363944968 34294926352 q11Shape26T108=true := by decide

private def q11Shape26T106 : Tree 11 := .split 13 q11Shape26T107 q11Shape26T108
private theorem q11Shape26T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363936776 34294926352 q11Shape26T106=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363936776 (34294926352 ||| 2^13) q11Shape26T107 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363936776 ||| 2^13) 34294926352 q11Shape26T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T107OK,q11Shape26T108OK⟩

private def q11Shape26T104 : Tree 11 := .split 12 q11Shape26T105 q11Shape26T106
private theorem q11Shape26T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 34294926352 q11Shape26T104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 (34294926352 ||| 2^12) q11Shape26T105 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363932680 ||| 2^12) 34294926352 q11Shape26T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T105OK,q11Shape26T106OK⟩

private def q11Shape26T109 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932696 34294926336 q11Shape26T109=true := by decide

private def q11Shape26T103 : Tree 11 := .split 4 q11Shape26T104 q11Shape26T109
private theorem q11Shape26T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 34294926336 q11Shape26T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 (34294926336 ||| 2^4) q11Shape26T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363932680 ||| 2^4) 34294926336 q11Shape26T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T104OK,q11Shape26T109OK⟩

private def q11Shape26T110 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34364063752 34294795264 q11Shape26T110=true := by decide

private def q11Shape26T102 : Tree 11 := .split 17 q11Shape26T103 q11Shape26T110
private theorem q11Shape26T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 34294795264 q11Shape26T102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 (34294795264 ||| 2^17) q11Shape26T103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363932680 ||| 2^17) 34294795264 q11Shape26T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T103OK,q11Shape26T110OK⟩

private def q11Shape26T111 : Tree 11 := (.tip (.cover {2,3,4,5,6,9}))
private theorem q11Shape26T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363934728 34294793216 q11Shape26T111=true := by decide

private def q11Shape26T101 : Tree 11 := .split 11 q11Shape26T102 q11Shape26T111
private theorem q11Shape26T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 34294793216 q11Shape26T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34363932680 (34294793216 ||| 2^11) q11Shape26T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34363932680 ||| 2^11) 34294793216 q11Shape26T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T102OK,q11Shape26T111OK⟩

private def q11Shape26T83 : Tree 11 := .split 22 q11Shape26T84 q11Shape26T101
private theorem q11Shape26T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34294793216 q11Shape26T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 (34294793216 ||| 2^22) q11Shape26T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738376 ||| 2^22) 34294793216 q11Shape26T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T84OK,q11Shape26T101OK⟩

private def q11Shape26T112 : Tree 11 := (.tip (.cover {2,3,4,5,7,9}))
private theorem q11Shape26T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34361835528 34292696064 q11Shape26T112=true := by decide

private def q11Shape26T82 : Tree 11 := .split 21 q11Shape26T83 q11Shape26T112
private theorem q11Shape26T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34292696064 q11Shape26T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 (34292696064 ||| 2^21) q11Shape26T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738376 ||| 2^21) 34292696064 q11Shape26T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T83OK,q11Shape26T112OK⟩

private def q11Shape26T113 : Tree 11 := (.tip (.cover {2,3,4,5,7,9}))
private theorem q11Shape26T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359803912 34292630528 q11Shape26T113=true := by decide

private def q11Shape26T81 : Tree 11 := .split 16 q11Shape26T82 q11Shape26T113
private theorem q11Shape26T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34292630528 q11Shape26T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 (34292630528 ||| 2^16) q11Shape26T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738376 ||| 2^16) 34292630528 q11Shape26T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T82OK,q11Shape26T113OK⟩

private def q11Shape26T114 : Tree 11 := (.tip (.cover {2,3,4,5,7,9}))
private theorem q11Shape26T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359739400 34292629504 q11Shape26T114=true := by decide

private def q11Shape26T80 : Tree 11 := .split 10 q11Shape26T81 q11Shape26T114
private theorem q11Shape26T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34292629504 q11Shape26T80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 (34292629504 ||| 2^10) q11Shape26T81 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (34359738376 ||| 2^10) 34292629504 q11Shape26T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T81OK,q11Shape26T114OK⟩

def q11Shape26P3 : Tree 11 := q11Shape26T80
theorem q11Shape26P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 34359738376 34292629504 q11Shape26P3=true := q11Shape26T80OK

end Graffiti384b.EffectiveSearch.Q11
