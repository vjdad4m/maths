import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T118 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape26T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 51474662408 q11Shape26T118=true := by decide

private def q11Shape26T123 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 51476892696 q11Shape26T123=true := by decide

private def q11Shape26T125 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,4,5,7,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,3,5,7,8,9})))))
private theorem q11Shape26T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966352 51476896776 q11Shape26T125=true := by decide

private def q11Shape26T127 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,3,5,7,8,9}))) (.tip (.cover {0,1,2,4,5,10}))))
private theorem q11Shape26T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181970448 51476900872 q11Shape26T127=true := by decide

private def q11Shape26T128 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,3,4,5,7,10}))) (.tip (.cover {0,4,5,7,9,10}))) (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,3,4,5,7,8}))) (.tip (.cover {0,3,5,7,8,9}))))
private theorem q11Shape26T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181978640 51476892680 q11Shape26T128=true := by decide

private def q11Shape26T126 : Tree 11 := .split 13 q11Shape26T127 q11Shape26T128
private theorem q11Shape26T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181970448 51476892680 q11Shape26T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181970448 (51476892680 ||| 2^13) q11Shape26T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181970448 ||| 2^13) 51476892680 q11Shape26T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T127OK,q11Shape26T128OK⟩

private def q11Shape26T124 : Tree 11 := .split 12 q11Shape26T125 q11Shape26T126
private theorem q11Shape26T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966352 51476892680 q11Shape26T124=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966352 (51476892680 ||| 2^12) q11Shape26T125 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181966352 ||| 2^12) 51476892680 q11Shape26T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T125OK,q11Shape26T126OK⟩

private def q11Shape26T122 : Tree 11 := .split 4 q11Shape26T123 q11Shape26T124
private theorem q11Shape26T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 51476892680 q11Shape26T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 (51476892680 ||| 2^4) q11Shape26T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181966336 ||| 2^4) 51476892680 q11Shape26T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T123OK,q11Shape26T124OK⟩

private def q11Shape26T131 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10}))) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10})))))
private theorem q11Shape26T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182097408 51476765720 q11Shape26T131=true := by decide

private def q11Shape26T133 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,8})) (.split 20 (.split 23 (.split 24 (.tip (.cover {1,2,3,4,6,8})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,4,6,8,9})))) (.tip (.cover {0,1,4,6,9,10}))))
private theorem q11Shape26T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182101504 51476769816 q11Shape26T133=true := by decide

private def q11Shape26T134 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,3,4,6,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,8})) (.tip (.cover {0,1,3,4,6,8}))) (.tip (.cover {0,1,4,6,9,10}))))
private theorem q11Shape26T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182109696 51476761624 q11Shape26T134=true := by decide

private def q11Shape26T132 : Tree 11 := .split 13 q11Shape26T133 q11Shape26T134
private theorem q11Shape26T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182101504 51476761624 q11Shape26T132=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182101504 (51476761624 ||| 2^13) q11Shape26T133 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17182101504 ||| 2^13) 51476761624 q11Shape26T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T133OK,q11Shape26T134OK⟩

private def q11Shape26T130 : Tree 11 := .split 12 q11Shape26T131 q11Shape26T132
private theorem q11Shape26T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182097408 51476761624 q11Shape26T130=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182097408 (51476761624 ||| 2^12) q11Shape26T131 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17182097408 ||| 2^12) 51476761624 q11Shape26T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T131OK,q11Shape26T132OK⟩

private def q11Shape26T135 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182097424 51476761608 q11Shape26T135=true := by decide

private def q11Shape26T129 : Tree 11 := .split 4 q11Shape26T130 q11Shape26T135
private theorem q11Shape26T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182097408 51476761608 q11Shape26T129=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182097408 (51476761608 ||| 2^4) q11Shape26T130 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17182097408 ||| 2^4) 51476761608 q11Shape26T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T130OK,q11Shape26T135OK⟩

private def q11Shape26T121 : Tree 11 := .split 17 q11Shape26T122 q11Shape26T129
private theorem q11Shape26T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 51476761608 q11Shape26T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 (51476761608 ||| 2^17) q11Shape26T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181966336 ||| 2^17) 51476761608 q11Shape26T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T122OK,q11Shape26T129OK⟩

private def q11Shape26T140 : Tree 11 := (.tip (.cover {0,2,4,5,7,10}))
private theorem q11Shape26T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 51476902936 q11Shape26T140=true := by decide

private def q11Shape26T141 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,2,5,7,9,10}))) (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.split 23 (.split 24 (.tip (.cover {1,2,3,4,6,8})) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {0,1,3,4,6,10})))) (.tip (.cover {0,1,3,6,8,9})))
private theorem q11Shape26T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181976576 51476894744 q11Shape26T141=true := by decide

private def q11Shape26T139 : Tree 11 := .split 13 q11Shape26T140 q11Shape26T141
private theorem q11Shape26T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 51476894744 q11Shape26T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 (51476894744 ||| 2^13) q11Shape26T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181968384 ||| 2^13) 51476894744 q11Shape26T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T140OK,q11Shape26T141OK⟩

private def q11Shape26T142 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape26T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181972480 51476890648 q11Shape26T142=true := by decide

private def q11Shape26T138 : Tree 11 := .split 12 q11Shape26T139 q11Shape26T142
private theorem q11Shape26T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 51476890648 q11Shape26T138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 (51476890648 ||| 2^12) q11Shape26T139 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181968384 ||| 2^12) 51476890648 q11Shape26T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T139OK,q11Shape26T142OK⟩

private def q11Shape26T143 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968400 51476890632 q11Shape26T143=true := by decide

private def q11Shape26T137 : Tree 11 := .split 4 q11Shape26T138 q11Shape26T143
private theorem q11Shape26T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 51476890632 q11Shape26T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 (51476890632 ||| 2^4) q11Shape26T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181968384 ||| 2^4) 51476890632 q11Shape26T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T138OK,q11Shape26T143OK⟩

private def q11Shape26T144 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182099456 51476759560 q11Shape26T144=true := by decide

private def q11Shape26T136 : Tree 11 := .split 17 q11Shape26T137 q11Shape26T144
private theorem q11Shape26T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 51476759560 q11Shape26T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181968384 (51476759560 ||| 2^17) q11Shape26T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181968384 ||| 2^17) 51476759560 q11Shape26T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T137OK,q11Shape26T144OK⟩

private def q11Shape26T120 : Tree 11 := .split 11 q11Shape26T121 q11Shape26T136
private theorem q11Shape26T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 51476759560 q11Shape26T120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 (51476759560 ||| 2^11) q11Shape26T121 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181966336 ||| 2^11) 51476759560 q11Shape26T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T121OK,q11Shape26T136OK⟩

private def q11Shape26T145 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape26T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17186160640 51472565256 q11Shape26T145=true := by decide

private def q11Shape26T119 : Tree 11 := .split 22 q11Shape26T120 q11Shape26T145
private theorem q11Shape26T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 51472565256 q11Shape26T119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966336 (51472565256 ||| 2^22) q11Shape26T120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17181966336 ||| 2^22) 51472565256 q11Shape26T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T120OK,q11Shape26T145OK⟩

private def q11Shape26T117 : Tree 11 := .split 21 q11Shape26T118 q11Shape26T119
private theorem q11Shape26T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 51472565256 q11Shape26T117=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 (51472565256 ||| 2^21) q11Shape26T118 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869184 ||| 2^21) 51472565256 q11Shape26T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T118OK,q11Shape26T119OK⟩

def q11Shape26P4 : Tree 11 := q11Shape26T117
theorem q11Shape26P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869184 51472565256 q11Shape26P4=true := q11Shape26T117OK

end Graffiti384b.EffectiveSearch.Q11
