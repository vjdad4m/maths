import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T151 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 51478924312 q11Shape26T151=true := by decide

private def q11Shape26T153 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10})))))
private theorem q11Shape26T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934736 51478928392 q11Shape26T153=true := by decide

private def q11Shape26T155 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,8})) (.split 20 (.split 23 (.split 24 (.tip (.cover {0,1,2,4,8,10})) (.tip (.cover {0,3,4,5,7,8}))) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,4,7,8,9})))) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape26T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179938832 51478932488 q11Shape26T155=true := by decide

private def q11Shape26T156 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,3,4,7,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,8})) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape26T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179947024 51478924296 q11Shape26T156=true := by decide

private def q11Shape26T154 : Tree 11 := .split 13 q11Shape26T155 q11Shape26T156
private theorem q11Shape26T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179938832 51478924296 q11Shape26T154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179938832 (51478924296 ||| 2^13) q11Shape26T155 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179938832 ||| 2^13) 51478924296 q11Shape26T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T155OK,q11Shape26T156OK⟩

private def q11Shape26T152 : Tree 11 := .split 12 q11Shape26T153 q11Shape26T154
private theorem q11Shape26T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934736 51478924296 q11Shape26T152=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934736 (51478924296 ||| 2^12) q11Shape26T153 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179934736 ||| 2^12) 51478924296 q11Shape26T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T153OK,q11Shape26T154OK⟩

private def q11Shape26T150 : Tree 11 := .split 4 q11Shape26T151 q11Shape26T152
private theorem q11Shape26T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 51478924296 q11Shape26T150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 (51478924296 ||| 2^4) q11Shape26T151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179934720 ||| 2^4) 51478924296 q11Shape26T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T151OK,q11Shape26T152OK⟩

private def q11Shape26T157 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180065792 51478793224 q11Shape26T157=true := by decide

private def q11Shape26T149 : Tree 11 := .split 17 q11Shape26T150 q11Shape26T157
private theorem q11Shape26T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 51478793224 q11Shape26T149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 (51478793224 ||| 2^17) q11Shape26T150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179934720 ||| 2^17) 51478793224 q11Shape26T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T150OK,q11Shape26T157OK⟩

private def q11Shape26T158 : Tree 11 := (.split 17 (.split 4 (.split 12 (.split 13 (.tip (.cover {0,2,4,5,7,10})) (.split 14 (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,3,6,8,9})))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {2,3,4,5,6,8}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape26T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179936768 51478791176 q11Shape26T158=true := by decide

private def q11Shape26T148 : Tree 11 := .split 11 q11Shape26T149 q11Shape26T158
private theorem q11Shape26T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 51478791176 q11Shape26T148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 (51478791176 ||| 2^11) q11Shape26T149 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179934720 ||| 2^11) 51478791176 q11Shape26T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T149OK,q11Shape26T158OK⟩

private def q11Shape26T163 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10}))) (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10})))))
private theorem q11Shape26T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 51474734104 q11Shape26T163=true := by decide

private def q11Shape26T165 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,8})) (.split 20 (.split 23 (.split 24 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,4,7,8,9})))) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape26T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184133120 51474738200 q11Shape26T165=true := by decide

private def q11Shape26T166 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,10})) (.tip (.cover {0,1,3,4,7,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.split 18 (.split 19 (.tip (.cover {1,2,3,5,6,8})) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape26T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184141312 51474730008 q11Shape26T166=true := by decide

private def q11Shape26T164 : Tree 11 := .split 13 q11Shape26T165 q11Shape26T166
private theorem q11Shape26T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184133120 51474730008 q11Shape26T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184133120 (51474730008 ||| 2^13) q11Shape26T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184133120 ||| 2^13) 51474730008 q11Shape26T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T165OK,q11Shape26T166OK⟩

private def q11Shape26T162 : Tree 11 := .split 12 q11Shape26T163 q11Shape26T164
private theorem q11Shape26T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 51474730008 q11Shape26T162=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 (51474730008 ||| 2^12) q11Shape26T163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184129024 ||| 2^12) 51474730008 q11Shape26T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T163OK,q11Shape26T164OK⟩

private def q11Shape26T167 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129040 51474729992 q11Shape26T167=true := by decide

private def q11Shape26T161 : Tree 11 := .split 4 q11Shape26T162 q11Shape26T167
private theorem q11Shape26T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 51474729992 q11Shape26T161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 (51474729992 ||| 2^4) q11Shape26T162 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184129024 ||| 2^4) 51474729992 q11Shape26T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T162OK,q11Shape26T167OK⟩

private def q11Shape26T168 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184260096 51474598920 q11Shape26T168=true := by decide

private def q11Shape26T160 : Tree 11 := .split 17 q11Shape26T161 q11Shape26T168
private theorem q11Shape26T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 51474598920 q11Shape26T160=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 (51474598920 ||| 2^17) q11Shape26T161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184129024 ||| 2^17) 51474598920 q11Shape26T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T161OK,q11Shape26T168OK⟩

private def q11Shape26T169 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184131072 51474596872 q11Shape26T169=true := by decide

private def q11Shape26T159 : Tree 11 := .split 11 q11Shape26T160 q11Shape26T169
private theorem q11Shape26T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 51474596872 q11Shape26T159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184129024 (51474596872 ||| 2^11) q11Shape26T160 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184129024 ||| 2^11) 51474596872 q11Shape26T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T160OK,q11Shape26T169OK⟩

private def q11Shape26T147 : Tree 11 := .split 22 q11Shape26T148 q11Shape26T159
private theorem q11Shape26T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 51474596872 q11Shape26T147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 (51474596872 ||| 2^22) q11Shape26T148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179934720 ||| 2^22) 51474596872 q11Shape26T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T148OK,q11Shape26T159OK⟩

private def q11Shape26T170 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17182031872 51472499720 q11Shape26T170=true := by decide

private def q11Shape26T146 : Tree 11 := .split 21 q11Shape26T147 q11Shape26T170
private theorem q11Shape26T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 51472499720 q11Shape26T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 (51472499720 ||| 2^21) q11Shape26T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179934720 ||| 2^21) 51472499720 q11Shape26T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T147OK,q11Shape26T170OK⟩

def q11Shape26P5 : Tree 11 := q11Shape26T146
theorem q11Shape26P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934720 51472499720 q11Shape26P5=true := q11Shape26T146OK

private def q11Shape26T178 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51478988824 q11Shape26T178=true := by decide

private def q11Shape26T181 : Tree 11 := (.tip (.cover {1,2,4,5,6,10}))
private theorem q11Shape26T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870224 51479001096 q11Shape26T181=true := by decide

private def q11Shape26T182 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {1,2,5,6,9,10}))) (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.split 23 (.split 24 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {0,3,4,5,7,8}))) (.tip (.cover {0,1,2,3,5,10})))) (.tip (.cover {0,1,3,4,7,10})))) (.tip (.cover {0,1,3,7,8,9})))
private theorem q11Shape26T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179878416 51478992904 q11Shape26T182=true := by decide

private def q11Shape26T180 : Tree 11 := .split 13 q11Shape26T181 q11Shape26T182
private theorem q11Shape26T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870224 51478992904 q11Shape26T180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870224 (51478992904 ||| 2^13) q11Shape26T181 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870224 ||| 2^13) 51478992904 q11Shape26T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T181OK,q11Shape26T182OK⟩

private def q11Shape26T183 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape26T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179874320 51478988808 q11Shape26T183=true := by decide

private def q11Shape26T179 : Tree 11 := .split 12 q11Shape26T180 q11Shape26T183
private theorem q11Shape26T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870224 51478988808 q11Shape26T179=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870224 (51478988808 ||| 2^12) q11Shape26T180 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870224 ||| 2^12) 51478988808 q11Shape26T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T180OK,q11Shape26T183OK⟩

private def q11Shape26T177 : Tree 11 := .split 4 q11Shape26T178 q11Shape26T179
private theorem q11Shape26T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51478988808 q11Shape26T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 (51478988808 ||| 2^4) q11Shape26T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870208 ||| 2^4) 51478988808 q11Shape26T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T178OK,q11Shape26T179OK⟩

private def q11Shape26T184 : Tree 11 := (.split 4 (.split 12 (.split 13 (.tip (.cover {1,2,4,5,6,10})) (.split 14 (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,3,4,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,3,7,8,9})))) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {2,3,4,5,6,8})))
private theorem q11Shape26T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180001280 51478857736 q11Shape26T184=true := by decide

private def q11Shape26T176 : Tree 11 := .split 17 q11Shape26T177 q11Shape26T184
private theorem q11Shape26T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51478857736 q11Shape26T176=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 (51478857736 ||| 2^17) q11Shape26T177 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870208 ||| 2^17) 51478857736 q11Shape26T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T177OK,q11Shape26T184OK⟩

private def q11Shape26T185 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape26T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179872256 51478855688 q11Shape26T185=true := by decide

private def q11Shape26T175 : Tree 11 := .split 11 q11Shape26T176 q11Shape26T185
private theorem q11Shape26T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51478855688 q11Shape26T175=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 (51478855688 ||| 2^11) q11Shape26T176 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870208 ||| 2^11) 51478855688 q11Shape26T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T176OK,q11Shape26T185OK⟩

private def q11Shape26T191 : Tree 11 := (.tip (.cover {1,2,4,5,6,10}))
private theorem q11Shape26T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 51474806808 q11Shape26T191=true := by decide

private def q11Shape26T192 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {1,2,5,6,9,10}))) (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.split 23 (.split 24 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,3,5,8,10}))) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,3,4,7,10})))) (.tip (.cover {0,1,3,7,8,9})))
private theorem q11Shape26T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184072704 51474798616 q11Shape26T192=true := by decide

private def q11Shape26T190 : Tree 11 := .split 13 q11Shape26T191 q11Shape26T192
private theorem q11Shape26T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 51474798616 q11Shape26T190=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 (51474798616 ||| 2^13) q11Shape26T191 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184064512 ||| 2^13) 51474798616 q11Shape26T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T191OK,q11Shape26T192OK⟩

private def q11Shape26T193 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape26T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184068608 51474794520 q11Shape26T193=true := by decide

private def q11Shape26T189 : Tree 11 := .split 12 q11Shape26T190 q11Shape26T193
private theorem q11Shape26T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 51474794520 q11Shape26T189=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 (51474794520 ||| 2^12) q11Shape26T190 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184064512 ||| 2^12) 51474794520 q11Shape26T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T190OK,q11Shape26T193OK⟩

private def q11Shape26T194 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064528 51474794504 q11Shape26T194=true := by decide

private def q11Shape26T188 : Tree 11 := .split 4 q11Shape26T189 q11Shape26T194
private theorem q11Shape26T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 51474794504 q11Shape26T188=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 (51474794504 ||| 2^4) q11Shape26T189 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184064512 ||| 2^4) 51474794504 q11Shape26T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T189OK,q11Shape26T194OK⟩

private def q11Shape26T195 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184195584 51474663432 q11Shape26T195=true := by decide

private def q11Shape26T187 : Tree 11 := .split 17 q11Shape26T188 q11Shape26T195
private theorem q11Shape26T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 51474663432 q11Shape26T187=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 (51474663432 ||| 2^17) q11Shape26T188 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184064512 ||| 2^17) 51474663432 q11Shape26T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T188OK,q11Shape26T195OK⟩

private def q11Shape26T196 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape26T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184066560 51474661384 q11Shape26T196=true := by decide

private def q11Shape26T186 : Tree 11 := .split 11 q11Shape26T187 q11Shape26T196
private theorem q11Shape26T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 51474661384 q11Shape26T186=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184064512 (51474661384 ||| 2^11) q11Shape26T187 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184064512 ||| 2^11) 51474661384 q11Shape26T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T187OK,q11Shape26T196OK⟩

private def q11Shape26T174 : Tree 11 := .split 22 q11Shape26T175 q11Shape26T186
private theorem q11Shape26T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51474661384 q11Shape26T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 (51474661384 ||| 2^22) q11Shape26T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870208 ||| 2^22) 51474661384 q11Shape26T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T175OK,q11Shape26T186OK⟩

private def q11Shape26T197 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181967360 51472564232 q11Shape26T197=true := by decide

private def q11Shape26T173 : Tree 11 := .split 21 q11Shape26T174 q11Shape26T197
private theorem q11Shape26T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51472564232 q11Shape26T173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 (51472564232 ||| 2^21) q11Shape26T174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870208 ||| 2^21) 51472564232 q11Shape26T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T174OK,q11Shape26T197OK⟩

private def q11Shape26T198 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179935744 51472498696 q11Shape26T198=true := by decide

private def q11Shape26T172 : Tree 11 := .split 16 q11Shape26T173 q11Shape26T198
private theorem q11Shape26T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51472498696 q11Shape26T172=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 (51472498696 ||| 2^16) q11Shape26T173 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179870208 ||| 2^16) 51472498696 q11Shape26T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T173OK,q11Shape26T198OK⟩

def q11Shape26P6 : Tree 11 := q11Shape26T172
theorem q11Shape26P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870208 51472498696 q11Shape26P6=true := q11Shape26T172OK

end Graffiti384b.EffectiveSearch.Q11
