import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T206 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51478989824 q11Shape26T206=true := by decide

private def q11Shape26T209 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10}))) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10})))))
private theorem q11Shape26T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180000264 51478862864 q11Shape26T209=true := by decide

private def q11Shape26T211 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,8})) (.split 20 (.split 23 (.split 24 (.tip (.cover {0,1,2,4,8,10})) (.tip (.cover {0,2,3,7,8,9}))) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,4,6,8,9})))) (.tip (.cover {0,1,4,6,9,10}))))
private theorem q11Shape26T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180004360 51478866960 q11Shape26T211=true := by decide

private def q11Shape26T212 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,10})) (.tip (.cover {0,1,3,4,6,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.split 18 (.split 19 (.tip (.cover {0,2,3,5,7,8})) (.tip (.cover {0,1,3,4,6,8}))) (.tip (.cover {0,1,4,6,9,10}))))
private theorem q11Shape26T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180012552 51478858768 q11Shape26T212=true := by decide

private def q11Shape26T210 : Tree 11 := .split 13 q11Shape26T211 q11Shape26T212
private theorem q11Shape26T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180004360 51478858768 q11Shape26T210=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180004360 (51478858768 ||| 2^13) q11Shape26T211 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17180004360 ||| 2^13) 51478858768 q11Shape26T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T211OK,q11Shape26T212OK⟩

private def q11Shape26T208 : Tree 11 := .split 12 q11Shape26T209 q11Shape26T210
private theorem q11Shape26T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180000264 51478858768 q11Shape26T208=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180000264 (51478858768 ||| 2^12) q11Shape26T209 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17180000264 ||| 2^12) 51478858768 q11Shape26T210)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T209OK,q11Shape26T210OK⟩

private def q11Shape26T213 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180000280 51478858752 q11Shape26T213=true := by decide

private def q11Shape26T207 : Tree 11 := .split 4 q11Shape26T208 q11Shape26T213
private theorem q11Shape26T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180000264 51478858752 q11Shape26T207=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180000264 (51478858752 ||| 2^4) q11Shape26T208 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17180000264 ||| 2^4) 51478858752 q11Shape26T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T208OK,q11Shape26T213OK⟩

private def q11Shape26T205 : Tree 11 := .split 17 q11Shape26T206 q11Shape26T207
private theorem q11Shape26T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51478858752 q11Shape26T205=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 (51478858752 ||| 2^17) q11Shape26T206 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869192 ||| 2^17) 51478858752 q11Shape26T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T206OK,q11Shape26T207OK⟩

private def q11Shape26T218 : Tree 11 := (.tip (.cover {0,2,4,5,7,10}))
private theorem q11Shape26T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 51479000080 q11Shape26T218=true := by decide

private def q11Shape26T219 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,2,5,7,9,10}))) (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.split 23 (.split 24 (.tip (.cover {0,1,2,3,8,10})) (.tip (.cover {0,2,4,7,8,9}))) (.tip (.cover {0,1,2,3,5,10})))) (.tip (.cover {0,1,3,4,6,10})))) (.tip (.cover {0,1,3,6,8,9})))
private theorem q11Shape26T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179879432 51478991888 q11Shape26T219=true := by decide

private def q11Shape26T217 : Tree 11 := .split 13 q11Shape26T218 q11Shape26T219
private theorem q11Shape26T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 51478991888 q11Shape26T217=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 (51478991888 ||| 2^13) q11Shape26T218 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179871240 ||| 2^13) 51478991888 q11Shape26T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T218OK,q11Shape26T219OK⟩

private def q11Shape26T220 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape26T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179875336 51478987792 q11Shape26T220=true := by decide

private def q11Shape26T216 : Tree 11 := .split 12 q11Shape26T217 q11Shape26T220
private theorem q11Shape26T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 51478987792 q11Shape26T216=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 (51478987792 ||| 2^12) q11Shape26T217 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179871240 ||| 2^12) 51478987792 q11Shape26T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T217OK,q11Shape26T220OK⟩

private def q11Shape26T221 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871256 51478987776 q11Shape26T221=true := by decide

private def q11Shape26T215 : Tree 11 := .split 4 q11Shape26T216 q11Shape26T221
private theorem q11Shape26T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 51478987776 q11Shape26T215=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 (51478987776 ||| 2^4) q11Shape26T216 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179871240 ||| 2^4) 51478987776 q11Shape26T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T216OK,q11Shape26T221OK⟩

private def q11Shape26T222 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17180002312 51478856704 q11Shape26T222=true := by decide

private def q11Shape26T214 : Tree 11 := .split 17 q11Shape26T215 q11Shape26T222
private theorem q11Shape26T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 51478856704 q11Shape26T214=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179871240 (51478856704 ||| 2^17) q11Shape26T215 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179871240 ||| 2^17) 51478856704 q11Shape26T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T215OK,q11Shape26T222OK⟩

private def q11Shape26T204 : Tree 11 := .split 11 q11Shape26T205 q11Shape26T214
private theorem q11Shape26T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51478856704 q11Shape26T204=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 (51478856704 ||| 2^11) q11Shape26T205 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869192 ||| 2^11) 51478856704 q11Shape26T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T205OK,q11Shape26T214OK⟩

private def q11Shape26T227 : Tree 11 := (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.split 14 (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,2,4,7,9,10}))) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,2,3,7,8,9})))))
private theorem q11Shape26T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 51474799632 q11Shape26T227=true := by decide

private def q11Shape26T229 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,2,3,7,8,9}))) (.tip (.cover {0,1,2,4,5,10}))))
private theorem q11Shape26T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184067592 51474803728 q11Shape26T229=true := by decide

private def q11Shape26T230 : Tree 11 := (.split 14 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,2,3,4,7,10}))) (.tip (.cover {0,2,4,7,9,10}))) (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,2,3,4,7,8}))) (.tip (.cover {0,2,3,7,8,9}))))
private theorem q11Shape26T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184075784 51474795536 q11Shape26T230=true := by decide

private def q11Shape26T228 : Tree 11 := .split 13 q11Shape26T229 q11Shape26T230
private theorem q11Shape26T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184067592 51474795536 q11Shape26T228=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184067592 (51474795536 ||| 2^13) q11Shape26T229 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184067592 ||| 2^13) 51474795536 q11Shape26T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T229OK,q11Shape26T230OK⟩

private def q11Shape26T226 : Tree 11 := .split 12 q11Shape26T227 q11Shape26T228
private theorem q11Shape26T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 51474795536 q11Shape26T226=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 (51474795536 ||| 2^12) q11Shape26T227 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184063496 ||| 2^12) 51474795536 q11Shape26T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T227OK,q11Shape26T228OK⟩

private def q11Shape26T231 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063512 51474795520 q11Shape26T231=true := by decide

private def q11Shape26T225 : Tree 11 := .split 4 q11Shape26T226 q11Shape26T231
private theorem q11Shape26T225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 51474795520 q11Shape26T225=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 (51474795520 ||| 2^4) q11Shape26T226 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184063496 ||| 2^4) 51474795520 q11Shape26T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T226OK,q11Shape26T231OK⟩

private def q11Shape26T232 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184194568 51474664448 q11Shape26T232=true := by decide

private def q11Shape26T224 : Tree 11 := .split 17 q11Shape26T225 q11Shape26T232
private theorem q11Shape26T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 51474664448 q11Shape26T224=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 (51474664448 ||| 2^17) q11Shape26T225 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184063496 ||| 2^17) 51474664448 q11Shape26T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T225OK,q11Shape26T232OK⟩

private def q11Shape26T233 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184065544 51474662400 q11Shape26T233=true := by decide

private def q11Shape26T223 : Tree 11 := .split 11 q11Shape26T224 q11Shape26T233
private theorem q11Shape26T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 51474662400 q11Shape26T223=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17184063496 (51474662400 ||| 2^11) q11Shape26T224 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17184063496 ||| 2^11) 51474662400 q11Shape26T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T224OK,q11Shape26T233OK⟩

private def q11Shape26T203 : Tree 11 := .split 22 q11Shape26T204 q11Shape26T223
private theorem q11Shape26T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51474662400 q11Shape26T203=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 (51474662400 ||| 2^22) q11Shape26T204 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869192 ||| 2^22) 51474662400 q11Shape26T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T204OK,q11Shape26T223OK⟩

private def q11Shape26T234 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17181966344 51472565248 q11Shape26T234=true := by decide

private def q11Shape26T202 : Tree 11 := .split 21 q11Shape26T203 q11Shape26T234
private theorem q11Shape26T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51472565248 q11Shape26T202=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 (51472565248 ||| 2^21) q11Shape26T203 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869192 ||| 2^21) 51472565248 q11Shape26T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T203OK,q11Shape26T234OK⟩

private def q11Shape26T235 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179934728 51472499712 q11Shape26T235=true := by decide

private def q11Shape26T201 : Tree 11 := .split 16 q11Shape26T202 q11Shape26T235
private theorem q11Shape26T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51472499712 q11Shape26T201=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 (51472499712 ||| 2^16) q11Shape26T202 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869192 ||| 2^16) 51472499712 q11Shape26T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T202OK,q11Shape26T235OK⟩

private def q11Shape26T236 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179870216 51472498688 q11Shape26T236=true := by decide

private def q11Shape26T200 : Tree 11 := .split 10 q11Shape26T201 q11Shape26T236
private theorem q11Shape26T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51472498688 q11Shape26T200=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 (51472498688 ||| 2^10) q11Shape26T201 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (17179869192 ||| 2^10) 51472498688 q11Shape26T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T201OK,q11Shape26T236OK⟩

def q11Shape26P7 : Tree 11 := q11Shape26T200
theorem q11Shape26P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 17179869192 51472498688 q11Shape26P7=true := q11Shape26T200OK

private def q11Shape26T238 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape26T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 51539607552 17112760320 q11Shape26T238=true := by decide

def q11Shape26P8 : Tree 11 := q11Shape26T238
theorem q11Shape26P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 51539607552 17112760320 q11Shape26P8=true := q11Shape26T238OK

end Graffiti384b.EffectiveSearch.Q11
