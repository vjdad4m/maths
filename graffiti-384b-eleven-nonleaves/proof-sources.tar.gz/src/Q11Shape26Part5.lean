import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T242 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape26T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 60064597000 q11Shape26T242=true := by decide

private def q11Shape26T247 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T247OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 60066827288 q11Shape26T247=true := by decide

private def q11Shape26T249 : Tree 11 := (.split 13 (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,4,5,7,9,10})))) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,3,5,7,8,10})))))
private theorem q11Shape26T249OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031760 60066831368 q11Shape26T249=true := by decide

private def q11Shape26T251 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,3,5,7,9,10}))) (.tip (.cover {0,4,5,7,9,10}))))
private theorem q11Shape26T251OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592035856 60066835464 q11Shape26T251=true := by decide

private def q11Shape26T252 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,2,5,8,9})) (.tip (.cover {0,3,5,7,8,10}))) (.tip (.cover {0,1,2,4,5,8}))) (.tip (.cover {0,1,2,4,5,9}))) (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,3,4,5,7,8}))) (.tip (.cover {0,3,5,7,9,10}))) (.tip (.cover {0,3,5,7,8,10}))))
private theorem q11Shape26T252OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592044048 60066827272 q11Shape26T252=true := by decide

private def q11Shape26T250 : Tree 11 := .split 13 q11Shape26T251 q11Shape26T252
private theorem q11Shape26T250OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592035856 60066827272 q11Shape26T250=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592035856 (60066827272 ||| 2^13) q11Shape26T251 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592035856 ||| 2^13) 60066827272 q11Shape26T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T251OK,q11Shape26T252OK⟩

private def q11Shape26T248 : Tree 11 := .split 12 q11Shape26T249 q11Shape26T250
private theorem q11Shape26T248OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031760 60066827272 q11Shape26T248=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031760 (60066827272 ||| 2^12) q11Shape26T249 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592031760 ||| 2^12) 60066827272 q11Shape26T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T249OK,q11Shape26T250OK⟩

private def q11Shape26T246 : Tree 11 := .split 4 q11Shape26T247 q11Shape26T248
private theorem q11Shape26T246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 60066827272 q11Shape26T246=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 (60066827272 ||| 2^4) q11Shape26T247 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592031744 ||| 2^4) 60066827272 q11Shape26T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T247OK,q11Shape26T248OK⟩

private def q11Shape26T255 : Tree 11 := (.split 13 (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10})))) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10})))))
private theorem q11Shape26T255OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592162816 60066700312 q11Shape26T255=true := by decide

private def q11Shape26T257 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))))
private theorem q11Shape26T257OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592166912 60066704408 q11Shape26T257=true := by decide

private def q11Shape26T259 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {0,2,3,5,7,8})) (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,8})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape26T259OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592175104 60066712600 q11Shape26T259=true := by decide

private def q11Shape26T260 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {0,2,3,5,7,8})) (.tip (.cover {0,1,3,4,6,8}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape26T260OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592191488 60066696216 q11Shape26T260=true := by decide

private def q11Shape26T258 : Tree 11 := .split 14 q11Shape26T259 q11Shape26T260
private theorem q11Shape26T258OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592175104 60066696216 q11Shape26T258=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592175104 (60066696216 ||| 2^14) q11Shape26T259 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592175104 ||| 2^14) 60066696216 q11Shape26T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T259OK,q11Shape26T260OK⟩

private def q11Shape26T256 : Tree 11 := .split 13 q11Shape26T257 q11Shape26T258
private theorem q11Shape26T256OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592166912 60066696216 q11Shape26T256=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592166912 (60066696216 ||| 2^13) q11Shape26T257 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592166912 ||| 2^13) 60066696216 q11Shape26T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T257OK,q11Shape26T258OK⟩

private def q11Shape26T254 : Tree 11 := .split 12 q11Shape26T255 q11Shape26T256
private theorem q11Shape26T254OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592162816 60066696216 q11Shape26T254=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592162816 (60066696216 ||| 2^12) q11Shape26T255 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592162816 ||| 2^12) 60066696216 q11Shape26T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T255OK,q11Shape26T256OK⟩

private def q11Shape26T261 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T261OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592162832 60066696200 q11Shape26T261=true := by decide

private def q11Shape26T253 : Tree 11 := .split 4 q11Shape26T254 q11Shape26T261
private theorem q11Shape26T253OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592162816 60066696200 q11Shape26T253=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592162816 (60066696200 ||| 2^4) q11Shape26T254 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592162816 ||| 2^4) 60066696200 q11Shape26T261)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T254OK,q11Shape26T261OK⟩

private def q11Shape26T245 : Tree 11 := .split 17 q11Shape26T246 q11Shape26T253
private theorem q11Shape26T245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 60066696200 q11Shape26T245=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 (60066696200 ||| 2^17) q11Shape26T246 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592031744 ||| 2^17) 60066696200 q11Shape26T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T246OK,q11Shape26T253OK⟩

private def q11Shape26T267 : Tree 11 := (.tip (.cover {0,2,4,5,7,8}))
private theorem q11Shape26T267OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 60066853912 q11Shape26T267=true := by decide

private def q11Shape26T269 : Tree 11 := (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,2,5,7,8,10}))) (.tip (.cover {0,2,5,7,9,10})))
private theorem q11Shape26T269OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592050176 60067099672 q11Shape26T269=true := by decide

private def q11Shape26T270 : Tree 11 := (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,8})) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,3,4,6,8}))))
private theorem q11Shape26T270OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592312320 60066837528 q11Shape26T270=true := by decide

private def q11Shape26T268 : Tree 11 := .split 18 q11Shape26T269 q11Shape26T270
private theorem q11Shape26T268OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592050176 60066837528 q11Shape26T268=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592050176 (60066837528 ||| 2^18) q11Shape26T269 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592050176 ||| 2^18) 60066837528 q11Shape26T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T269OK,q11Shape26T270OK⟩

private def q11Shape26T266 : Tree 11 := .split 14 q11Shape26T267 q11Shape26T268
private theorem q11Shape26T266OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 60066837528 q11Shape26T266=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 (60066837528 ||| 2^14) q11Shape26T267 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592033792 ||| 2^14) 60066837528 q11Shape26T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T267OK,q11Shape26T268OK⟩

private def q11Shape26T271 : Tree 11 := (.tip (.cover {0,1,3,6,8,10}))
private theorem q11Shape26T271OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592041984 60066829336 q11Shape26T271=true := by decide

private def q11Shape26T265 : Tree 11 := .split 13 q11Shape26T266 q11Shape26T271
private theorem q11Shape26T265OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 60066829336 q11Shape26T265=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 (60066829336 ||| 2^13) q11Shape26T266 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592033792 ||| 2^13) 60066829336 q11Shape26T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T266OK,q11Shape26T271OK⟩

private def q11Shape26T272 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape26T272OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592037888 60066825240 q11Shape26T272=true := by decide

private def q11Shape26T264 : Tree 11 := .split 12 q11Shape26T265 q11Shape26T272
private theorem q11Shape26T264OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 60066825240 q11Shape26T264=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 (60066825240 ||| 2^12) q11Shape26T265 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592033792 ||| 2^12) 60066825240 q11Shape26T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T265OK,q11Shape26T272OK⟩

private def q11Shape26T273 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T273OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033808 60066825224 q11Shape26T273=true := by decide

private def q11Shape26T263 : Tree 11 := .split 4 q11Shape26T264 q11Shape26T273
private theorem q11Shape26T263OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 60066825224 q11Shape26T263=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 (60066825224 ||| 2^4) q11Shape26T264 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592033792 ||| 2^4) 60066825224 q11Shape26T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T264OK,q11Shape26T273OK⟩

private def q11Shape26T274 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T274OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592164864 60066694152 q11Shape26T274=true := by decide

private def q11Shape26T262 : Tree 11 := .split 17 q11Shape26T263 q11Shape26T274
private theorem q11Shape26T262OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 60066694152 q11Shape26T262=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592033792 (60066694152 ||| 2^17) q11Shape26T263 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592033792 ||| 2^17) 60066694152 q11Shape26T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T263OK,q11Shape26T274OK⟩

private def q11Shape26T244 : Tree 11 := .split 11 q11Shape26T245 q11Shape26T262
private theorem q11Shape26T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 60066694152 q11Shape26T244=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 (60066694152 ||| 2^11) q11Shape26T245 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592031744 ||| 2^11) 60066694152 q11Shape26T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T245OK,q11Shape26T262OK⟩

private def q11Shape26T275 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape26T275OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8596226048 60062499848 q11Shape26T275=true := by decide

private def q11Shape26T243 : Tree 11 := .split 22 q11Shape26T244 q11Shape26T275
private theorem q11Shape26T243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 60062499848 q11Shape26T243=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031744 (60062499848 ||| 2^22) q11Shape26T244 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8592031744 ||| 2^22) 60062499848 q11Shape26T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T244OK,q11Shape26T275OK⟩

private def q11Shape26T241 : Tree 11 := .split 21 q11Shape26T242 q11Shape26T243
private theorem q11Shape26T241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 60062499848 q11Shape26T241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 (60062499848 ||| 2^21) q11Shape26T242 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934592 ||| 2^21) 60062499848 q11Shape26T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T242OK,q11Shape26T243OK⟩

def q11Shape26P9 : Tree 11 := q11Shape26T241
theorem q11Shape26P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934592 60062499848 q11Shape26P9=true := q11Shape26T241OK

end Graffiti384b.EffectiveSearch.Q11
