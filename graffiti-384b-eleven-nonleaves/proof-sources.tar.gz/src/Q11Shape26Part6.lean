import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T281 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T281OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 60068858904 q11Shape26T281=true := by decide

private def q11Shape26T283 : Tree 11 := (.split 13 (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10})))) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10})))))
private theorem q11Shape26T283OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000144 60068862984 q11Shape26T283=true := by decide

private def q11Shape26T285 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape26T285OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590004240 60068867080 q11Shape26T285=true := by decide

private def q11Shape26T287 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,8})) (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,4,8,9})) (.tip (.cover {0,3,4,5,7,8}))) (.tip (.cover {0,1,2,4,5,8}))) (.tip (.cover {0,1,2,4,5,9})))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape26T287OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590012432 60068875272 q11Shape26T287=true := by decide

private def q11Shape26T288 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,8})) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape26T288OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590028816 60068858888 q11Shape26T288=true := by decide

private def q11Shape26T286 : Tree 11 := .split 14 q11Shape26T287 q11Shape26T288
private theorem q11Shape26T286OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590012432 60068858888 q11Shape26T286=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590012432 (60068858888 ||| 2^14) q11Shape26T287 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590012432 ||| 2^14) 60068858888 q11Shape26T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T287OK,q11Shape26T288OK⟩

private def q11Shape26T284 : Tree 11 := .split 13 q11Shape26T285 q11Shape26T286
private theorem q11Shape26T284OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590004240 60068858888 q11Shape26T284=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590004240 (60068858888 ||| 2^13) q11Shape26T285 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590004240 ||| 2^13) 60068858888 q11Shape26T286)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T285OK,q11Shape26T286OK⟩

private def q11Shape26T282 : Tree 11 := .split 12 q11Shape26T283 q11Shape26T284
private theorem q11Shape26T282OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000144 60068858888 q11Shape26T282=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000144 (60068858888 ||| 2^12) q11Shape26T283 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590000144 ||| 2^12) 60068858888 q11Shape26T284)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T283OK,q11Shape26T284OK⟩

private def q11Shape26T280 : Tree 11 := .split 4 q11Shape26T281 q11Shape26T282
private theorem q11Shape26T280OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 60068858888 q11Shape26T280=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 (60068858888 ||| 2^4) q11Shape26T281 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590000128 ||| 2^4) 60068858888 q11Shape26T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T281OK,q11Shape26T282OK⟩

private def q11Shape26T289 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T289OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590131200 60068727816 q11Shape26T289=true := by decide

private def q11Shape26T279 : Tree 11 := .split 17 q11Shape26T280 q11Shape26T289
private theorem q11Shape26T279OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 60068727816 q11Shape26T279=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 (60068727816 ||| 2^17) q11Shape26T280 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590000128 ||| 2^17) 60068727816 q11Shape26T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T280OK,q11Shape26T289OK⟩

private def q11Shape26T291 : Tree 11 := (.split 4 (.split 12 (.split 13 (.split 14 (.tip (.cover {0,2,4,5,7,8})) (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,8})) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))) (.tip (.cover {0,1,3,6,8,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {2,3,4,5,6,8})))
private theorem q11Shape26T291OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590002176 60068856840 q11Shape26T291=true := by decide

private def q11Shape26T292 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T292OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590133248 60068725768 q11Shape26T292=true := by decide

private def q11Shape26T290 : Tree 11 := .split 17 q11Shape26T291 q11Shape26T292
private theorem q11Shape26T290OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590002176 60068725768 q11Shape26T290=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590002176 (60068725768 ||| 2^17) q11Shape26T291 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590002176 ||| 2^17) 60068725768 q11Shape26T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T291OK,q11Shape26T292OK⟩

private def q11Shape26T278 : Tree 11 := .split 11 q11Shape26T279 q11Shape26T290
private theorem q11Shape26T278OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 60068725768 q11Shape26T278=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 (60068725768 ||| 2^11) q11Shape26T279 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590000128 ||| 2^11) 60068725768 q11Shape26T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T279OK,q11Shape26T290OK⟩

private def q11Shape26T297 : Tree 11 := (.split 13 (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10})))) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {1,2,5,6,9,10})) (.tip (.cover {0,1,4,7,9,10})))))
private theorem q11Shape26T297OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 60064668696 q11Shape26T297=true := by decide

private def q11Shape26T299 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))))
private theorem q11Shape26T299OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594198528 60064672792 q11Shape26T299=true := by decide

private def q11Shape26T301 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,8})) (.split 23 (.split 24 (.split 25 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape26T301OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594206720 60064680984 q11Shape26T301=true := by decide

private def q11Shape26T302 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,8})) (.tip (.cover {0,1,3,4,7,8}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape26T302OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594223104 60064664600 q11Shape26T302=true := by decide

private def q11Shape26T300 : Tree 11 := .split 14 q11Shape26T301 q11Shape26T302
private theorem q11Shape26T300OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594206720 60064664600 q11Shape26T300=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594206720 (60064664600 ||| 2^14) q11Shape26T301 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594206720 ||| 2^14) 60064664600 q11Shape26T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T301OK,q11Shape26T302OK⟩

private def q11Shape26T298 : Tree 11 := .split 13 q11Shape26T299 q11Shape26T300
private theorem q11Shape26T298OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594198528 60064664600 q11Shape26T298=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594198528 (60064664600 ||| 2^13) q11Shape26T299 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594198528 ||| 2^13) 60064664600 q11Shape26T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T299OK,q11Shape26T300OK⟩

private def q11Shape26T296 : Tree 11 := .split 12 q11Shape26T297 q11Shape26T298
private theorem q11Shape26T296OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 60064664600 q11Shape26T296=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 (60064664600 ||| 2^12) q11Shape26T297 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594194432 ||| 2^12) 60064664600 q11Shape26T298)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T297OK,q11Shape26T298OK⟩

private def q11Shape26T303 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T303OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194448 60064664584 q11Shape26T303=true := by decide

private def q11Shape26T295 : Tree 11 := .split 4 q11Shape26T296 q11Shape26T303
private theorem q11Shape26T295OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 60064664584 q11Shape26T295=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 (60064664584 ||| 2^4) q11Shape26T296 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594194432 ||| 2^4) 60064664584 q11Shape26T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T296OK,q11Shape26T303OK⟩

private def q11Shape26T304 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape26T304OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594325504 60064533512 q11Shape26T304=true := by decide

private def q11Shape26T294 : Tree 11 := .split 17 q11Shape26T295 q11Shape26T304
private theorem q11Shape26T294OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 60064533512 q11Shape26T294=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 (60064533512 ||| 2^17) q11Shape26T295 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594194432 ||| 2^17) 60064533512 q11Shape26T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T295OK,q11Shape26T304OK⟩

private def q11Shape26T305 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T305OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594196480 60064531464 q11Shape26T305=true := by decide

private def q11Shape26T293 : Tree 11 := .split 11 q11Shape26T294 q11Shape26T305
private theorem q11Shape26T293OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 60064531464 q11Shape26T293=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594194432 (60064531464 ||| 2^11) q11Shape26T294 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594194432 ||| 2^11) 60064531464 q11Shape26T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T294OK,q11Shape26T305OK⟩

private def q11Shape26T277 : Tree 11 := .split 22 q11Shape26T278 q11Shape26T293
private theorem q11Shape26T277OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 60064531464 q11Shape26T277=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 (60064531464 ||| 2^22) q11Shape26T278 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590000128 ||| 2^22) 60064531464 q11Shape26T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T278OK,q11Shape26T293OK⟩

private def q11Shape26T306 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T306OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592097280 60062434312 q11Shape26T306=true := by decide

private def q11Shape26T276 : Tree 11 := .split 21 q11Shape26T277 q11Shape26T306
private theorem q11Shape26T276OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 60062434312 q11Shape26T276=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 (60062434312 ||| 2^21) q11Shape26T277 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590000128 ||| 2^21) 60062434312 q11Shape26T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T277OK,q11Shape26T306OK⟩

def q11Shape26P10 : Tree 11 := q11Shape26T276
theorem q11Shape26P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000128 60062434312 q11Shape26P10=true := q11Shape26T276OK

private def q11Shape26T314 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T314OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60068923416 q11Shape26T314=true := by decide

private def q11Shape26T318 : Tree 11 := (.tip (.cover {1,2,4,5,6,8}))
private theorem q11Shape26T318OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935632 60068952072 q11Shape26T318=true := by decide

private def q11Shape26T320 : Tree 11 := (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {1,2,5,6,8,10}))) (.tip (.cover {1,2,5,6,9,10})))
private theorem q11Shape26T320OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589952016 60069197832 q11Shape26T320=true := by decide

private def q11Shape26T321 : Tree 11 := (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {0,3,4,5,7,8}))) (.tip (.cover {0,1,2,3,5,8}))) (.tip (.cover {0,1,2,3,5,9}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape26T321OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590214160 60068935688 q11Shape26T321=true := by decide

private def q11Shape26T319 : Tree 11 := .split 18 q11Shape26T320 q11Shape26T321
private theorem q11Shape26T319OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589952016 60068935688 q11Shape26T319=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589952016 (60068935688 ||| 2^18) q11Shape26T320 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589952016 ||| 2^18) 60068935688 q11Shape26T321)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T320OK,q11Shape26T321OK⟩

private def q11Shape26T317 : Tree 11 := .split 14 q11Shape26T318 q11Shape26T319
private theorem q11Shape26T317OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935632 60068935688 q11Shape26T317=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935632 (60068935688 ||| 2^14) q11Shape26T318 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935632 ||| 2^14) 60068935688 q11Shape26T319)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T318OK,q11Shape26T319OK⟩

private def q11Shape26T322 : Tree 11 := (.tip (.cover {0,1,3,7,8,10}))
private theorem q11Shape26T322OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589943824 60068927496 q11Shape26T322=true := by decide

private def q11Shape26T316 : Tree 11 := .split 13 q11Shape26T317 q11Shape26T322
private theorem q11Shape26T316OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935632 60068927496 q11Shape26T316=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935632 (60068927496 ||| 2^13) q11Shape26T317 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935632 ||| 2^13) 60068927496 q11Shape26T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T317OK,q11Shape26T322OK⟩

private def q11Shape26T323 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape26T323OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589939728 60068923400 q11Shape26T323=true := by decide

private def q11Shape26T315 : Tree 11 := .split 12 q11Shape26T316 q11Shape26T323
private theorem q11Shape26T315OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935632 60068923400 q11Shape26T315=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935632 (60068923400 ||| 2^12) q11Shape26T316 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935632 ||| 2^12) 60068923400 q11Shape26T323)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T316OK,q11Shape26T323OK⟩

private def q11Shape26T313 : Tree 11 := .split 4 q11Shape26T314 q11Shape26T315
private theorem q11Shape26T313OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60068923400 q11Shape26T313=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 (60068923400 ||| 2^4) q11Shape26T314 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935616 ||| 2^4) 60068923400 q11Shape26T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T314OK,q11Shape26T315OK⟩

private def q11Shape26T324 : Tree 11 := (.split 4 (.split 12 (.split 13 (.split 14 (.tip (.cover {1,2,4,5,6,8})) (.split 18 (.split 19 (.split 20 (.tip (.cover {0,2,3,5,7,8})) (.tip (.cover {0,1,3,4,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))) (.tip (.cover {0,1,3,7,8,10}))) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {2,3,4,5,6,8})))
private theorem q11Shape26T324OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590066688 60068792328 q11Shape26T324=true := by decide

private def q11Shape26T312 : Tree 11 := .split 17 q11Shape26T313 q11Shape26T324
private theorem q11Shape26T312OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60068792328 q11Shape26T312=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 (60068792328 ||| 2^17) q11Shape26T313 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935616 ||| 2^17) 60068792328 q11Shape26T324)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T313OK,q11Shape26T324OK⟩

private def q11Shape26T325 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape26T325OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589937664 60068790280 q11Shape26T325=true := by decide

private def q11Shape26T311 : Tree 11 := .split 11 q11Shape26T312 q11Shape26T325
private theorem q11Shape26T311OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60068790280 q11Shape26T311=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 (60068790280 ||| 2^11) q11Shape26T312 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935616 ||| 2^11) 60068790280 q11Shape26T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T312OK,q11Shape26T325OK⟩

private def q11Shape26T332 : Tree 11 := (.tip (.cover {1,2,4,5,6,8}))
private theorem q11Shape26T332OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 60064757784 q11Shape26T332=true := by decide

private def q11Shape26T334 : Tree 11 := (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {1,2,5,6,8,10}))) (.tip (.cover {1,2,5,6,9,10})))
private theorem q11Shape26T334OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594146304 60065003544 q11Shape26T334=true := by decide

private def q11Shape26T335 : Tree 11 := (.split 19 (.tip (.cover {1,2,5,6,8,10})) (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,3,5,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,3,4,7,8}))))
private theorem q11Shape26T335OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594408448 60064741400 q11Shape26T335=true := by decide

private def q11Shape26T333 : Tree 11 := .split 18 q11Shape26T334 q11Shape26T335
private theorem q11Shape26T333OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594146304 60064741400 q11Shape26T333=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594146304 (60064741400 ||| 2^18) q11Shape26T334 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594146304 ||| 2^18) 60064741400 q11Shape26T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T334OK,q11Shape26T335OK⟩

private def q11Shape26T331 : Tree 11 := .split 14 q11Shape26T332 q11Shape26T333
private theorem q11Shape26T331OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 60064741400 q11Shape26T331=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 (60064741400 ||| 2^14) q11Shape26T332 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594129920 ||| 2^14) 60064741400 q11Shape26T333)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T332OK,q11Shape26T333OK⟩

private def q11Shape26T336 : Tree 11 := (.tip (.cover {0,1,3,7,8,10}))
private theorem q11Shape26T336OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594138112 60064733208 q11Shape26T336=true := by decide

private def q11Shape26T330 : Tree 11 := .split 13 q11Shape26T331 q11Shape26T336
private theorem q11Shape26T330OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 60064733208 q11Shape26T330=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 (60064733208 ||| 2^13) q11Shape26T331 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594129920 ||| 2^13) 60064733208 q11Shape26T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T331OK,q11Shape26T336OK⟩

private def q11Shape26T337 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape26T337OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594134016 60064729112 q11Shape26T337=true := by decide

private def q11Shape26T329 : Tree 11 := .split 12 q11Shape26T330 q11Shape26T337
private theorem q11Shape26T329OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 60064729112 q11Shape26T329=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 (60064729112 ||| 2^12) q11Shape26T330 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594129920 ||| 2^12) 60064729112 q11Shape26T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T330OK,q11Shape26T337OK⟩

private def q11Shape26T338 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T338OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129936 60064729096 q11Shape26T338=true := by decide

private def q11Shape26T328 : Tree 11 := .split 4 q11Shape26T329 q11Shape26T338
private theorem q11Shape26T328OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 60064729096 q11Shape26T328=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 (60064729096 ||| 2^4) q11Shape26T329 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594129920 ||| 2^4) 60064729096 q11Shape26T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T329OK,q11Shape26T338OK⟩

private def q11Shape26T339 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T339OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594260992 60064598024 q11Shape26T339=true := by decide

private def q11Shape26T327 : Tree 11 := .split 17 q11Shape26T328 q11Shape26T339
private theorem q11Shape26T327OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 60064598024 q11Shape26T327=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 (60064598024 ||| 2^17) q11Shape26T328 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594129920 ||| 2^17) 60064598024 q11Shape26T339)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T328OK,q11Shape26T339OK⟩

private def q11Shape26T340 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape26T340OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594131968 60064595976 q11Shape26T340=true := by decide

private def q11Shape26T326 : Tree 11 := .split 11 q11Shape26T327 q11Shape26T340
private theorem q11Shape26T326OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 60064595976 q11Shape26T326=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594129920 (60064595976 ||| 2^11) q11Shape26T327 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594129920 ||| 2^11) 60064595976 q11Shape26T340)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T327OK,q11Shape26T340OK⟩

private def q11Shape26T310 : Tree 11 := .split 22 q11Shape26T311 q11Shape26T326
private theorem q11Shape26T310OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60064595976 q11Shape26T310=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 (60064595976 ||| 2^22) q11Shape26T311 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935616 ||| 2^22) 60064595976 q11Shape26T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T311OK,q11Shape26T326OK⟩

private def q11Shape26T341 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T341OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592032768 60062498824 q11Shape26T341=true := by decide

private def q11Shape26T309 : Tree 11 := .split 21 q11Shape26T310 q11Shape26T341
private theorem q11Shape26T309OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60062498824 q11Shape26T309=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 (60062498824 ||| 2^21) q11Shape26T310 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935616 ||| 2^21) 60062498824 q11Shape26T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T310OK,q11Shape26T341OK⟩

private def q11Shape26T342 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T342OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590001152 60062433288 q11Shape26T342=true := by decide

private def q11Shape26T308 : Tree 11 := .split 16 q11Shape26T309 q11Shape26T342
private theorem q11Shape26T308OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60062433288 q11Shape26T308=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 (60062433288 ||| 2^16) q11Shape26T309 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589935616 ||| 2^16) 60062433288 q11Shape26T342)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T309OK,q11Shape26T342OK⟩

def q11Shape26P11 : Tree 11 := q11Shape26T308
theorem q11Shape26P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935616 60062433288 q11Shape26P11=true := q11Shape26T308OK

end Graffiti384b.EffectiveSearch.Q11
