import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape26T350 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T350OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60068924416 q11Shape26T350=true := by decide

private def q11Shape26T353 : Tree 11 := (.split 13 (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10})))) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,2,5,7,9,10})) (.tip (.cover {0,1,4,6,9,10})))))
private theorem q11Shape26T353OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590065672 60068797456 q11Shape26T353=true := by decide

private def q11Shape26T355 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))))
private theorem q11Shape26T355OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590069768 60068801552 q11Shape26T355=true := by decide

private def q11Shape26T357 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {0,2,3,5,7,8})) (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,4,8,9})) (.tip (.cover {0,2,3,7,8,10}))) (.tip (.cover {0,1,2,4,5,8}))) (.tip (.cover {0,1,2,4,5,9})))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape26T357OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590077960 60068809744 q11Shape26T357=true := by decide

private def q11Shape26T358 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {0,2,3,5,7,8})) (.tip (.cover {0,1,3,4,6,8}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape26T358OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590094344 60068793360 q11Shape26T358=true := by decide

private def q11Shape26T356 : Tree 11 := .split 14 q11Shape26T357 q11Shape26T358
private theorem q11Shape26T356OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590077960 60068793360 q11Shape26T356=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590077960 (60068793360 ||| 2^14) q11Shape26T357 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590077960 ||| 2^14) 60068793360 q11Shape26T358)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T357OK,q11Shape26T358OK⟩

private def q11Shape26T354 : Tree 11 := .split 13 q11Shape26T355 q11Shape26T356
private theorem q11Shape26T354OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590069768 60068793360 q11Shape26T354=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590069768 (60068793360 ||| 2^13) q11Shape26T355 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590069768 ||| 2^13) 60068793360 q11Shape26T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T355OK,q11Shape26T356OK⟩

private def q11Shape26T352 : Tree 11 := .split 12 q11Shape26T353 q11Shape26T354
private theorem q11Shape26T352OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590065672 60068793360 q11Shape26T352=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590065672 (60068793360 ||| 2^12) q11Shape26T353 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590065672 ||| 2^12) 60068793360 q11Shape26T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T353OK,q11Shape26T354OK⟩

private def q11Shape26T359 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T359OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590065688 60068793344 q11Shape26T359=true := by decide

private def q11Shape26T351 : Tree 11 := .split 4 q11Shape26T352 q11Shape26T359
private theorem q11Shape26T351OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590065672 60068793344 q11Shape26T351=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590065672 (60068793344 ||| 2^4) q11Shape26T352 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8590065672 ||| 2^4) 60068793344 q11Shape26T359)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T352OK,q11Shape26T359OK⟩

private def q11Shape26T349 : Tree 11 := .split 17 q11Shape26T350 q11Shape26T351
private theorem q11Shape26T349OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60068793344 q11Shape26T349=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 (60068793344 ||| 2^17) q11Shape26T350 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934600 ||| 2^17) 60068793344 q11Shape26T351)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T350OK,q11Shape26T351OK⟩

private def q11Shape26T365 : Tree 11 := (.tip (.cover {0,2,4,5,7,8}))
private theorem q11Shape26T365OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 60068951056 q11Shape26T365=true := by decide

private def q11Shape26T367 : Tree 11 := (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,2,5,7,8,10}))) (.tip (.cover {0,2,5,7,9,10})))
private theorem q11Shape26T367OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589953032 60069196816 q11Shape26T367=true := by decide

private def q11Shape26T368 : Tree 11 := (.split 19 (.tip (.cover {0,2,5,7,8,10})) (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,8,9})) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {0,1,2,3,5,8}))) (.tip (.cover {0,1,2,3,5,9}))) (.tip (.cover {0,1,3,4,6,8}))))
private theorem q11Shape26T368OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590215176 60068934672 q11Shape26T368=true := by decide

private def q11Shape26T366 : Tree 11 := .split 18 q11Shape26T367 q11Shape26T368
private theorem q11Shape26T366OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589953032 60068934672 q11Shape26T366=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589953032 (60068934672 ||| 2^18) q11Shape26T367 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589953032 ||| 2^18) 60068934672 q11Shape26T368)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T367OK,q11Shape26T368OK⟩

private def q11Shape26T364 : Tree 11 := .split 14 q11Shape26T365 q11Shape26T366
private theorem q11Shape26T364OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 60068934672 q11Shape26T364=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 (60068934672 ||| 2^14) q11Shape26T365 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589936648 ||| 2^14) 60068934672 q11Shape26T366)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T365OK,q11Shape26T366OK⟩

private def q11Shape26T369 : Tree 11 := (.tip (.cover {0,1,3,6,8,10}))
private theorem q11Shape26T369OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589944840 60068926480 q11Shape26T369=true := by decide

private def q11Shape26T363 : Tree 11 := .split 13 q11Shape26T364 q11Shape26T369
private theorem q11Shape26T363OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 60068926480 q11Shape26T363=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 (60068926480 ||| 2^13) q11Shape26T364 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589936648 ||| 2^13) 60068926480 q11Shape26T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T364OK,q11Shape26T369OK⟩

private def q11Shape26T370 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape26T370OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589940744 60068922384 q11Shape26T370=true := by decide

private def q11Shape26T362 : Tree 11 := .split 12 q11Shape26T363 q11Shape26T370
private theorem q11Shape26T362OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 60068922384 q11Shape26T362=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 (60068922384 ||| 2^12) q11Shape26T363 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589936648 ||| 2^12) 60068922384 q11Shape26T370)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T363OK,q11Shape26T370OK⟩

private def q11Shape26T371 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T371OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936664 60068922368 q11Shape26T371=true := by decide

private def q11Shape26T361 : Tree 11 := .split 4 q11Shape26T362 q11Shape26T371
private theorem q11Shape26T361OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 60068922368 q11Shape26T361=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 (60068922368 ||| 2^4) q11Shape26T362 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589936648 ||| 2^4) 60068922368 q11Shape26T371)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T362OK,q11Shape26T371OK⟩

private def q11Shape26T372 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T372OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590067720 60068791296 q11Shape26T372=true := by decide

private def q11Shape26T360 : Tree 11 := .split 17 q11Shape26T361 q11Shape26T372
private theorem q11Shape26T360OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 60068791296 q11Shape26T360=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589936648 (60068791296 ||| 2^17) q11Shape26T361 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589936648 ||| 2^17) 60068791296 q11Shape26T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T361OK,q11Shape26T372OK⟩

private def q11Shape26T348 : Tree 11 := .split 11 q11Shape26T349 q11Shape26T360
private theorem q11Shape26T348OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60068791296 q11Shape26T348=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 (60068791296 ||| 2^11) q11Shape26T349 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934600 ||| 2^11) 60068791296 q11Shape26T360)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T349OK,q11Shape26T360OK⟩

private def q11Shape26T377 : Tree 11 := (.split 13 (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,2,4,7,9,10})))) (.split 14 (.tip (.cover {0,1,2,4,5,9})) (.split 18 (.tip (.cover {0,1,2,5,9,10})) (.tip (.cover {0,2,3,7,8,10})))))
private theorem q11Shape26T377OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 60064734224 q11Shape26T377=true := by decide

private def q11Shape26T379 : Tree 11 := (.split 14 (.tip (.cover {0,1,2,4,5,8})) (.split 18 (.split 19 (.tip (.cover {0,1,2,5,8,10})) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,4,7,9,10}))))
private theorem q11Shape26T379OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594133000 60064738320 q11Shape26T379=true := by decide

private def q11Shape26T380 : Tree 11 := (.split 14 (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,2,5,8,9})) (.tip (.cover {0,2,3,7,8,10}))) (.tip (.cover {0,1,2,4,5,8}))) (.tip (.cover {0,1,2,4,5,9}))) (.split 18 (.split 19 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,2,3,4,7,8}))) (.tip (.cover {0,2,3,7,9,10}))) (.tip (.cover {0,2,3,7,8,10}))))
private theorem q11Shape26T380OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594141192 60064730128 q11Shape26T380=true := by decide

private def q11Shape26T378 : Tree 11 := .split 13 q11Shape26T379 q11Shape26T380
private theorem q11Shape26T378OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594133000 60064730128 q11Shape26T378=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594133000 (60064730128 ||| 2^13) q11Shape26T379 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594133000 ||| 2^13) 60064730128 q11Shape26T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T379OK,q11Shape26T380OK⟩

private def q11Shape26T376 : Tree 11 := .split 12 q11Shape26T377 q11Shape26T378
private theorem q11Shape26T376OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 60064730128 q11Shape26T376=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 (60064730128 ||| 2^12) q11Shape26T377 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594128904 ||| 2^12) 60064730128 q11Shape26T378)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T377OK,q11Shape26T378OK⟩

private def q11Shape26T381 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape26T381OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128920 60064730112 q11Shape26T381=true := by decide

private def q11Shape26T375 : Tree 11 := .split 4 q11Shape26T376 q11Shape26T381
private theorem q11Shape26T375OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 60064730112 q11Shape26T375=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 (60064730112 ||| 2^4) q11Shape26T376 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594128904 ||| 2^4) 60064730112 q11Shape26T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T376OK,q11Shape26T381OK⟩

private def q11Shape26T382 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T382OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594259976 60064599040 q11Shape26T382=true := by decide

private def q11Shape26T374 : Tree 11 := .split 17 q11Shape26T375 q11Shape26T382
private theorem q11Shape26T374OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 60064599040 q11Shape26T374=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 (60064599040 ||| 2^17) q11Shape26T375 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594128904 ||| 2^17) 60064599040 q11Shape26T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T375OK,q11Shape26T382OK⟩

private def q11Shape26T383 : Tree 11 := (.tip (.cover {2,3,4,5,6,8}))
private theorem q11Shape26T383OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594130952 60064596992 q11Shape26T383=true := by decide

private def q11Shape26T373 : Tree 11 := .split 11 q11Shape26T374 q11Shape26T383
private theorem q11Shape26T373OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 60064596992 q11Shape26T373=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8594128904 (60064596992 ||| 2^11) q11Shape26T374 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8594128904 ||| 2^11) 60064596992 q11Shape26T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T374OK,q11Shape26T383OK⟩

private def q11Shape26T347 : Tree 11 := .split 22 q11Shape26T348 q11Shape26T373
private theorem q11Shape26T347OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60064596992 q11Shape26T347=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 (60064596992 ||| 2^22) q11Shape26T348 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934600 ||| 2^22) 60064596992 q11Shape26T373)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T348OK,q11Shape26T373OK⟩

private def q11Shape26T384 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T384OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8592031752 60062499840 q11Shape26T384=true := by decide

private def q11Shape26T346 : Tree 11 := .split 21 q11Shape26T347 q11Shape26T384
private theorem q11Shape26T346OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60062499840 q11Shape26T346=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 (60062499840 ||| 2^21) q11Shape26T347 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934600 ||| 2^21) 60062499840 q11Shape26T384)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T347OK,q11Shape26T384OK⟩

private def q11Shape26T385 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T385OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8590000136 60062434304 q11Shape26T385=true := by decide

private def q11Shape26T345 : Tree 11 := .split 16 q11Shape26T346 q11Shape26T385
private theorem q11Shape26T345OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60062434304 q11Shape26T345=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 (60062434304 ||| 2^16) q11Shape26T346 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934600 ||| 2^16) 60062434304 q11Shape26T385)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T346OK,q11Shape26T385OK⟩

private def q11Shape26T386 : Tree 11 := (.tip (.cover {2,3,4,5,7,8}))
private theorem q11Shape26T386OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589935624 60062433280 q11Shape26T386=true := by decide

private def q11Shape26T344 : Tree 11 := .split 10 q11Shape26T345 q11Shape26T386
private theorem q11Shape26T344OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60062433280 q11Shape26T344=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 (60062433280 ||| 2^10) q11Shape26T345 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) (8589934600 ||| 2^10) 60062433280 q11Shape26T386)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape26T345OK,q11Shape26T386OK⟩

def q11Shape26P12 : Tree 11 := q11Shape26T344
theorem q11Shape26P12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 8589934600 60062433280 q11Shape26P12=true := q11Shape26T344OK

private def q11Shape26T388 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape26T388OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 42949672960 25702694912 q11Shape26T388=true := by decide

def q11Shape26P13 : Tree 11 := q11Shape26T388
theorem q11Shape26P13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 42949672960 25702694912 q11Shape26P13=true := q11Shape26T388OK

private def q11Shape26T390 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape26T390OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 25769803776 8522825728 q11Shape26T390=true := by decide

def q11Shape26P14 : Tree 11 := q11Shape26T390
theorem q11Shape26P14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 25769803776 8522825728 q11Shape26P14=true := q11Shape26T390OK

private def q11Shape26T393 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T393OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 4294967296 4227858432 q11Shape26T393=true := by decide

def q11Shape26P15 : Tree 11 := q11Shape26T393
theorem q11Shape26P15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 4294967296 4227858432 q11Shape26P15=true := q11Shape26T393OK

private def q11Shape26T395 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T395OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 2147483648 2080374784 q11Shape26T395=true := by decide

def q11Shape26P16 : Tree 11 := q11Shape26T395
theorem q11Shape26P16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 2147483648 2080374784 q11Shape26P16=true := q11Shape26T395OK

private def q11Shape26T397 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T397OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 1073741824 1006632960 q11Shape26T397=true := by decide

def q11Shape26P17 : Tree 11 := q11Shape26T397
theorem q11Shape26P17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 1073741824 1006632960 q11Shape26P17=true := q11Shape26T397OK

private def q11Shape26T399 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape26T399OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 536870912 469762048 q11Shape26T399=true := by decide

def q11Shape26P18 : Tree 11 := q11Shape26T399
theorem q11Shape26P18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 536870912 469762048 q11Shape26P18=true := q11Shape26T399OK

private def q11Shape26T401 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape26T401OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 268435456 201326592 q11Shape26T401=true := by decide

def q11Shape26P19 : Tree 11 := q11Shape26T401
theorem q11Shape26P19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 268435456 201326592 q11Shape26P19=true := q11Shape26T401OK

private def q11Shape26T403 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape26T403OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 134217728 67108864 q11Shape26T403=true := by decide

def q11Shape26P20 : Tree 11 := q11Shape26T403
theorem q11Shape26P20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 134217728 67108864 q11Shape26P20=true := q11Shape26T403OK

private def q11Shape26T405 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape26T405OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 67108864 0 q11Shape26T405=true := by decide

def q11Shape26P21 : Tree 11 := q11Shape26T405
theorem q11Shape26P21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 26)) 67108864 0 q11Shape26P21=true := q11Shape26T405OK

end Graffiti384b.EffectiveSearch.Q11
