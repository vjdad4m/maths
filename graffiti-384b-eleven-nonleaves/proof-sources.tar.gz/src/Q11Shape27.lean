import Q11Shape27Part0

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q11Shape27_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 27) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 27) b) (adj 11 (forms 27) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) adj_mono b H q11Shape27P0 q11Shape27P0OK

#print axioms q11Shape27_cover

end Graffiti384b.EffectiveSearch.Q11
