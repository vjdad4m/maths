import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape27T1 : Tree 11 := (.tip (.small 1))
private theorem q11Shape27T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 0 32 q11Shape27T1=true := by decide

private def q11Shape27T3 : Tree 11 := (.tip (.small 1))
private theorem q11Shape27T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 32 64 q11Shape27T3=true := by decide

private def q11Shape27T5 : Tree 11 := (.tip (.small 1))
private theorem q11Shape27T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 96 128 q11Shape27T5=true := by decide

private def q11Shape27T13 : Tree 11 := (.split 10 (.split 11 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 15 (.tip (.cover {0,6,7,8,9,10})) (.tip (.cover {0,1,2,3,4,6})))) (.split 11 (.split 15 (.tip (.cover {0,6,7,8,9,10})) (.tip (.cover {0,1,2,3,4,7}))) (.tip (.cover {1,2,4,5,6,7}))))
private theorem q11Shape27T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 799 q11Shape27T13=true := by decide

private def q11Shape27T14 : Tree 11 := (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,1,2,3,4,7}))) (.tip (.cover {1,2,3,4,6,7}))) (.tip (.cover {1,2,4,5,6,7}))) (.tip (.cover {1,2,4,5,6,7})))
private theorem q11Shape27T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 736 287 q11Shape27T14=true := by decide

private def q11Shape27T12 : Tree 11 := .split 9 q11Shape27T13 q11Shape27T14
private theorem q11Shape27T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 287 q11Shape27T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 (287 ||| 2^9) q11Shape27T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (224 ||| 2^9) 287 q11Shape27T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T13OK,q11Shape27T14OK⟩

private def q11Shape27T15 : Tree 11 := (.split 9 (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {1,2,3,5,6,7}))) (.tip (.cover {1,2,3,5,6,7}))) (.tip (.cover {1,2,4,5,6,7}))) (.tip (.cover {1,2,4,5,6,7}))) (.tip (.cover {1,2,4,5,6,7})))
private theorem q11Shape27T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 480 31 q11Shape27T15=true := by decide

private def q11Shape27T11 : Tree 11 := .split 8 q11Shape27T12 q11Shape27T15
private theorem q11Shape27T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 31 q11Shape27T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 (31 ||| 2^8) q11Shape27T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (224 ||| 2^8) 31 q11Shape27T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T12OK,q11Shape27T15OK⟩

private def q11Shape27T16 : Tree 11 := (.split 8 (.split 9 (.split 10 (.split 11 (.split 15 (.tip (.cover {0,6,7,8,9,10})) (.tip (.cover {0,1,2,3,4,6}))) (.tip (.cover {1,2,3,4,5,6}))) (.tip (.cover {0,1,2,3,4,5}))) (.tip (.cover {0,1,2,3,4,6}))) (.tip (.cover {0,1,2,3,5,6})))
private theorem q11Shape27T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 240 15 q11Shape27T16=true := by decide

private def q11Shape27T10 : Tree 11 := .split 4 q11Shape27T11 q11Shape27T16
private theorem q11Shape27T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 15 q11Shape27T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 (15 ||| 2^4) q11Shape27T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (224 ||| 2^4) 15 q11Shape27T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T11OK,q11Shape27T16OK⟩

private def q11Shape27T17 : Tree 11 := (.split 4 (.split 8 (.split 9 (.split 10 (.split 11 (.split 15 (.tip (.cover {0,6,7,8,9,10})) (.tip (.cover {0,1,2,3,4,7}))) (.tip (.cover {0,1,2,3,4,5}))) (.tip (.cover {1,2,3,4,5,7}))) (.tip (.cover {0,1,2,3,4,7}))) (.tip (.cover {0,1,2,3,5,7}))) (.tip (.cover {0,1,2,3,4,5})))
private theorem q11Shape27T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 232 7 q11Shape27T17=true := by decide

private def q11Shape27T9 : Tree 11 := .split 3 q11Shape27T10 q11Shape27T17
private theorem q11Shape27T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 7 q11Shape27T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 (7 ||| 2^3) q11Shape27T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (224 ||| 2^3) 7 q11Shape27T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T10OK,q11Shape27T17OK⟩

private def q11Shape27T19 : Tree 11 := (.split 4 (.split 8 (.split 9 (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,1,2,3,4,7}))) (.tip (.cover {1,2,3,4,6,7}))) (.tip (.cover {0,1,2,3,4,6}))) (.tip (.cover {0,1,2,3,4,7}))) (.tip (.cover {1,2,3,4,6,7}))) (.tip (.cover {0,1,2,3,6,7}))) (.tip (.cover {0,1,2,3,4,6})))
private theorem q11Shape27T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 228 11 q11Shape27T19=true := by decide

private def q11Shape27T20 : Tree 11 := (.tip (.cover {0,1,2,3,4,7}))
private theorem q11Shape27T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 236 3 q11Shape27T20=true := by decide

private def q11Shape27T18 : Tree 11 := .split 3 q11Shape27T19 q11Shape27T20
private theorem q11Shape27T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 228 3 q11Shape27T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 228 (3 ||| 2^3) q11Shape27T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (228 ||| 2^3) 3 q11Shape27T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T19OK,q11Shape27T20OK⟩

private def q11Shape27T8 : Tree 11 := .split 2 q11Shape27T9 q11Shape27T18
private theorem q11Shape27T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 3 q11Shape27T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 (3 ||| 2^2) q11Shape27T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (224 ||| 2^2) 3 q11Shape27T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T9OK,q11Shape27T18OK⟩

private def q11Shape27T23 : Tree 11 := (.split 4 (.split 8 (.split 9 (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {1,2,3,5,6,7}))) (.tip (.cover {0,1,2,3,5,6}))) (.tip (.cover {0,1,2,3,5,7}))) (.tip (.cover {0,1,2,3,6,7}))) (.tip (.cover {1,2,3,5,6,7}))) (.tip (.cover {0,1,2,3,5,6})))
private theorem q11Shape27T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 226 13 q11Shape27T23=true := by decide

private def q11Shape27T24 : Tree 11 := (.tip (.cover {0,1,2,3,5,7}))
private theorem q11Shape27T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 234 5 q11Shape27T24=true := by decide

private def q11Shape27T22 : Tree 11 := .split 3 q11Shape27T23 q11Shape27T24
private theorem q11Shape27T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 226 5 q11Shape27T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 226 (5 ||| 2^3) q11Shape27T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (226 ||| 2^3) 5 q11Shape27T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T23OK,q11Shape27T24OK⟩

private def q11Shape27T25 : Tree 11 := (.tip (.cover {0,1,2,3,6,7}))
private theorem q11Shape27T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 230 1 q11Shape27T25=true := by decide

private def q11Shape27T21 : Tree 11 := .split 2 q11Shape27T22 q11Shape27T25
private theorem q11Shape27T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 226 1 q11Shape27T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 226 (1 ||| 2^2) q11Shape27T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (226 ||| 2^2) 1 q11Shape27T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T22OK,q11Shape27T25OK⟩

private def q11Shape27T7 : Tree 11 := .split 1 q11Shape27T8 q11Shape27T21
private theorem q11Shape27T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 1 q11Shape27T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 (1 ||| 2^1) q11Shape27T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (224 ||| 2^1) 1 q11Shape27T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T8OK,q11Shape27T21OK⟩

private def q11Shape27T29 : Tree 11 := (.split 4 (.split 8 (.split 9 (.split 10 (.split 11 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,1,2,4,5,7}))) (.tip (.cover {0,1,2,4,6,7}))) (.tip (.cover {1,2,4,5,6,7}))) (.tip (.cover {1,2,4,5,6,7}))) (.tip (.cover {1,2,4,5,6,7}))) (.tip (.cover {1,2,4,5,6,7}))) (.tip (.cover {0,1,2,4,5,6})))
private theorem q11Shape27T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 225 14 q11Shape27T29=true := by decide

private def q11Shape27T30 : Tree 11 := (.tip (.cover {0,1,2,4,5,7}))
private theorem q11Shape27T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 233 6 q11Shape27T30=true := by decide

private def q11Shape27T28 : Tree 11 := .split 3 q11Shape27T29 q11Shape27T30
private theorem q11Shape27T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 225 6 q11Shape27T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 225 (6 ||| 2^3) q11Shape27T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (225 ||| 2^3) 6 q11Shape27T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T29OK,q11Shape27T30OK⟩

private def q11Shape27T31 : Tree 11 := (.tip (.cover {0,1,2,4,6,7}))
private theorem q11Shape27T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 229 2 q11Shape27T31=true := by decide

private def q11Shape27T27 : Tree 11 := .split 2 q11Shape27T28 q11Shape27T31
private theorem q11Shape27T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 225 2 q11Shape27T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 225 (2 ||| 2^2) q11Shape27T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (225 ||| 2^2) 2 q11Shape27T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T28OK,q11Shape27T31OK⟩

private def q11Shape27T32 : Tree 11 := (.tip (.cover {0,1,2,5,6,7}))
private theorem q11Shape27T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 227 0 q11Shape27T32=true := by decide

private def q11Shape27T26 : Tree 11 := .split 1 q11Shape27T27 q11Shape27T32
private theorem q11Shape27T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 225 0 q11Shape27T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 225 (0 ||| 2^1) q11Shape27T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (225 ||| 2^1) 0 q11Shape27T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T27OK,q11Shape27T32OK⟩

private def q11Shape27T6 : Tree 11 := .split 0 q11Shape27T7 q11Shape27T26
private theorem q11Shape27T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 0 q11Shape27T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 224 (0 ||| 2^0) q11Shape27T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (224 ||| 2^0) 0 q11Shape27T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T7OK,q11Shape27T26OK⟩

private def q11Shape27T4 : Tree 11 := .split 7 q11Shape27T5 q11Shape27T6
private theorem q11Shape27T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 96 0 q11Shape27T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 96 (0 ||| 2^7) q11Shape27T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (96 ||| 2^7) 0 q11Shape27T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T5OK,q11Shape27T6OK⟩

private def q11Shape27T2 : Tree 11 := .split 6 q11Shape27T3 q11Shape27T4
private theorem q11Shape27T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 32 0 q11Shape27T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 32 (0 ||| 2^6) q11Shape27T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (32 ||| 2^6) 0 q11Shape27T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T3OK,q11Shape27T4OK⟩

private def q11Shape27T0 : Tree 11 := .split 5 q11Shape27T1 q11Shape27T2
private theorem q11Shape27T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 0 0 q11Shape27T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 0 (0 ||| 2^5) q11Shape27T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) (0 ||| 2^5) 0 q11Shape27T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape27T1OK,q11Shape27T2OK⟩

def q11Shape27P0 : Tree 11 := q11Shape27T0
theorem q11Shape27P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,1⟩) 0 0 q11Shape27P0=true := q11Shape27T0OK

end Graffiti384b.EffectiveSearch.Q11
