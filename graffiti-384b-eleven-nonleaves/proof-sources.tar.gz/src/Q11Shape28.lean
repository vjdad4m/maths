import Q11Shape28Part0
import Q11Shape28Part1
import Q11Shape28Part2

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape28M46 : Tree 11 := .split 17 q11Shape28P0 q11Shape28P1
private theorem q11Shape28M46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 98304 q11Shape28M46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 (98304 ||| 2^17) q11Shape28P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (0 ||| 2^17) 98304 q11Shape28P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28P0OK,q11Shape28P1OK⟩
private def q11Shape28M64 : Tree 11 := .split 16 q11Shape28M46 q11Shape28P2
private theorem q11Shape28M64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 32768 q11Shape28M64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 (32768 ||| 2^16) q11Shape28M46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (0 ||| 2^16) 32768 q11Shape28P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28M46OK,q11Shape28P2OK⟩
private def q11Shape28M88 : Tree 11 := .split 15 q11Shape28M64 q11Shape28P3
private theorem q11Shape28M88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 0 q11Shape28M88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 (0 ||| 2^15) q11Shape28M64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (0 ||| 2^15) 0 q11Shape28P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28M64OK,q11Shape28P3OK⟩

theorem q11Shape28_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 28) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 28) b) (adj 11 (forms 28) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) adj_mono b H q11Shape28M88 q11Shape28M88OK

#print axioms q11Shape28_cover

end Graffiti384b.EffectiveSearch.Q11
