import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape28T3 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape28T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 73629696 q11Shape28T3=true := by decide

private def q11Shape28T5 : Tree 11 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10})) (.tip (.cover {0,1,2,4,6,10}))) (.tip (.cover {0,1,2,5,6,10}))))))))
private theorem q11Shape28T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 67108864 8596455424 q11Shape28T5=true := by decide

private def q11Shape28T7 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10})) (.tip (.cover {0,1,2,4,6,10}))) (.tip (.cover {0,1,2,5,6,10})))))))
private theorem q11Shape28T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8657043456 6520833 q11Shape28T7=true := by decide

private def q11Shape28T9 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10})) (.tip (.cover {0,2,4,6,8,10}))) (.tip (.cover {0,2,5,6,8,10}))))))
private theorem q11Shape28T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8657043457 6520864 q11Shape28T9=true := by decide

private def q11Shape28T10 : Tree 11 := (.split 1 (.split 2 (.tip (.cover {0,3,6,8,9,10})) (.tip (.cover {0,2,4,6,9,10}))) (.tip (.cover {0,2,5,6,9,10})))
private theorem q11Shape28T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8657043489 6520832 q11Shape28T10=true := by decide

private def q11Shape28T8 : Tree 11 := .split 5 q11Shape28T9 q11Shape28T10
private theorem q11Shape28T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8657043457 6520832 q11Shape28T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8657043457 (6520832 ||| 2^5) q11Shape28T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8657043457 ||| 2^5) 6520832 q11Shape28T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T9OK,q11Shape28T10OK⟩

private def q11Shape28T6 : Tree 11 := .split 0 q11Shape28T7 q11Shape28T8
private theorem q11Shape28T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8657043456 6520832 q11Shape28T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8657043456 (6520832 ||| 2^0) q11Shape28T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8657043456 ||| 2^0) 6520832 q11Shape28T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T7OK,q11Shape28T8OK⟩

private def q11Shape28T4 : Tree 11 := .split 33 q11Shape28T5 q11Shape28T6
private theorem q11Shape28T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 67108864 6520832 q11Shape28T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 67108864 (6520832 ||| 2^33) q11Shape28T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (67108864 ||| 2^33) 6520832 q11Shape28T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T5OK,q11Shape28T6OK⟩

private def q11Shape28T2 : Tree 11 := .split 26 q11Shape28T3 q11Shape28T4
private theorem q11Shape28T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 6520832 q11Shape28T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 (6520832 ||| 2^26) q11Shape28T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (0 ||| 2^26) 6520832 q11Shape28T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T3OK,q11Shape28T4OK⟩

private def q11Shape28T13 : Tree 11 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 3 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,5,6,10}))))))))
private theorem q11Shape28T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4194304 8659369984 q11Shape28T13=true := by decide

private def q11Shape28T15 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 3 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,5,6,10})))))))
private theorem q11Shape28T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8594128896 69435393 q11Shape28T15=true := by decide

private def q11Shape28T17 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 3 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,4,5,8,10}))) (.tip (.cover {0,2,5,6,8,10}))))))
private theorem q11Shape28T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8594128897 69435424 q11Shape28T17=true := by decide

private def q11Shape28T18 : Tree 11 := (.split 1 (.split 3 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,4,5,9,10}))) (.tip (.cover {0,2,5,6,9,10})))
private theorem q11Shape28T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8594128929 69435392 q11Shape28T18=true := by decide

private def q11Shape28T16 : Tree 11 := .split 5 q11Shape28T17 q11Shape28T18
private theorem q11Shape28T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8594128897 69435392 q11Shape28T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8594128897 (69435392 ||| 2^5) q11Shape28T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8594128897 ||| 2^5) 69435392 q11Shape28T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T17OK,q11Shape28T18OK⟩

private def q11Shape28T14 : Tree 11 := .split 0 q11Shape28T15 q11Shape28T16
private theorem q11Shape28T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8594128896 69435392 q11Shape28T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8594128896 (69435392 ||| 2^0) q11Shape28T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8594128896 ||| 2^0) 69435392 q11Shape28T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T15OK,q11Shape28T16OK⟩

private def q11Shape28T12 : Tree 11 := .split 33 q11Shape28T13 q11Shape28T14
private theorem q11Shape28T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4194304 69435392 q11Shape28T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4194304 (69435392 ||| 2^33) q11Shape28T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (4194304 ||| 2^33) 69435392 q11Shape28T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T13OK,q11Shape28T14OK⟩

private def q11Shape28T19 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,2,7,8,9,10})))) (.tip (.cover {0,1,4,7,8,10})))
private theorem q11Shape28T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 71303168 2326528 q11Shape28T19=true := by decide

private def q11Shape28T11 : Tree 11 := .split 26 q11Shape28T12 q11Shape28T19
private theorem q11Shape28T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4194304 2326528 q11Shape28T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4194304 (2326528 ||| 2^26) q11Shape28T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (4194304 ||| 2^26) 2326528 q11Shape28T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T12OK,q11Shape28T19OK⟩

private def q11Shape28T1 : Tree 11 := .split 22 q11Shape28T2 q11Shape28T11
private theorem q11Shape28T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 2326528 q11Shape28T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 (2326528 ||| 2^22) q11Shape28T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (0 ||| 2^22) 2326528 q11Shape28T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T2OK,q11Shape28T11OK⟩

private def q11Shape28T23 : Tree 11 := (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 4 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,5,7,10}))))))))
private theorem q11Shape28T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2097152 8661467136 q11Shape28T23=true := by decide

private def q11Shape28T25 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 4 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,5,7,10})))))))
private theorem q11Shape28T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8592031744 71532545 q11Shape28T25=true := by decide

private def q11Shape28T27 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 4 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,4,5,8,10}))) (.tip (.cover {0,2,5,7,8,10}))))))
private theorem q11Shape28T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8592031745 71532576 q11Shape28T27=true := by decide

private def q11Shape28T28 : Tree 11 := (.split 1 (.split 4 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,4,5,9,10}))) (.tip (.cover {0,2,5,7,9,10})))
private theorem q11Shape28T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8592031777 71532544 q11Shape28T28=true := by decide

private def q11Shape28T26 : Tree 11 := .split 5 q11Shape28T27 q11Shape28T28
private theorem q11Shape28T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8592031745 71532544 q11Shape28T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8592031745 (71532544 ||| 2^5) q11Shape28T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8592031745 ||| 2^5) 71532544 q11Shape28T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T27OK,q11Shape28T28OK⟩

private def q11Shape28T24 : Tree 11 := .split 0 q11Shape28T25 q11Shape28T26
private theorem q11Shape28T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8592031744 71532544 q11Shape28T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8592031744 (71532544 ||| 2^0) q11Shape28T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8592031744 ||| 2^0) 71532544 q11Shape28T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T25OK,q11Shape28T26OK⟩

private def q11Shape28T22 : Tree 11 := .split 33 q11Shape28T23 q11Shape28T24
private theorem q11Shape28T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2097152 71532544 q11Shape28T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2097152 (71532544 ||| 2^33) q11Shape28T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (2097152 ||| 2^33) 71532544 q11Shape28T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T23OK,q11Shape28T24OK⟩

private def q11Shape28T29 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,6,8,9,10})) (.tip (.cover {0,2,6,8,9,10})))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape28T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 69206016 4423680 q11Shape28T29=true := by decide

private def q11Shape28T21 : Tree 11 := .split 26 q11Shape28T22 q11Shape28T29
private theorem q11Shape28T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2097152 4423680 q11Shape28T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2097152 (4423680 ||| 2^26) q11Shape28T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (2097152 ||| 2^26) 4423680 q11Shape28T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T22OK,q11Shape28T29OK⟩

private def q11Shape28T30 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,5,8,9,10})))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape28T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 6291456 229376 q11Shape28T30=true := by decide

private def q11Shape28T20 : Tree 11 := .split 22 q11Shape28T21 q11Shape28T30
private theorem q11Shape28T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2097152 229376 q11Shape28T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2097152 (229376 ||| 2^22) q11Shape28T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (2097152 ||| 2^22) 229376 q11Shape28T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T21OK,q11Shape28T30OK⟩

private def q11Shape28T0 : Tree 11 := .split 21 q11Shape28T1 q11Shape28T20
private theorem q11Shape28T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 229376 q11Shape28T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 (229376 ||| 2^21) q11Shape28T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (0 ||| 2^21) 229376 q11Shape28T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T1OK,q11Shape28T20OK⟩

def q11Shape28P0 : Tree 11 := q11Shape28T0
theorem q11Shape28P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 0 229376 q11Shape28P0=true := q11Shape28T0OK

end Graffiti384b.EffectiveSearch.Q11
