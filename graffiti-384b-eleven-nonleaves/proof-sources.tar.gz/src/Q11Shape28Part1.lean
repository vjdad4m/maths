import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape28T36 : Tree 11 := (.tip (.small 1))
private theorem q11Shape28T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 8663433217 q11Shape28T36=true := by decide

private def q11Shape28T37 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,4,6,10}))) (.tip (.cover {2,3,5,6,7,10})))))))
private theorem q11Shape28T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131073 8663433216 q11Shape28T37=true := by decide

private def q11Shape28T35 : Tree 11 := .split 0 q11Shape28T36 q11Shape28T37
private theorem q11Shape28T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 8663433216 q11Shape28T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 (8663433216 ||| 2^0) q11Shape28T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (131072 ||| 2^0) 8663433216 q11Shape28T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T36OK,q11Shape28T37OK⟩

private def q11Shape28T39 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,4,6,10}))) (.tip (.cover {2,3,5,6,7,10})))))))
private theorem q11Shape28T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590065664 73498625 q11Shape28T39=true := by decide

private def q11Shape28T41 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,2,4,5,8,10}))) (.tip (.cover {0,2,4,6,8,10}))) (.tip (.cover {2,5,6,7,8,10}))))))
private theorem q11Shape28T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590065665 73498656 q11Shape28T41=true := by decide

private def q11Shape28T42 : Tree 11 := (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,2,4,5,9,10}))) (.tip (.cover {0,2,4,6,9,10})))
private theorem q11Shape28T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590065697 73498624 q11Shape28T42=true := by decide

private def q11Shape28T40 : Tree 11 := .split 5 q11Shape28T41 q11Shape28T42
private theorem q11Shape28T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590065665 73498624 q11Shape28T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590065665 (73498624 ||| 2^5) q11Shape28T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8590065665 ||| 2^5) 73498624 q11Shape28T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T41OK,q11Shape28T42OK⟩

private def q11Shape28T38 : Tree 11 := .split 0 q11Shape28T39 q11Shape28T40
private theorem q11Shape28T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590065664 73498624 q11Shape28T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590065664 (73498624 ||| 2^0) q11Shape28T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8590065664 ||| 2^0) 73498624 q11Shape28T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T39OK,q11Shape28T40OK⟩

private def q11Shape28T34 : Tree 11 := .split 33 q11Shape28T35 q11Shape28T38
private theorem q11Shape28T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 73498624 q11Shape28T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 (73498624 ||| 2^33) q11Shape28T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (131072 ||| 2^33) 73498624 q11Shape28T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T35OK,q11Shape28T38OK⟩

private def q11Shape28T43 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,2,7,8,9,10})))) (.tip (.cover {0,1,5,7,8,10})))
private theorem q11Shape28T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 67239936 6389760 q11Shape28T43=true := by decide

private def q11Shape28T33 : Tree 11 := .split 26 q11Shape28T34 q11Shape28T43
private theorem q11Shape28T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 6389760 q11Shape28T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 (6389760 ||| 2^26) q11Shape28T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (131072 ||| 2^26) 6389760 q11Shape28T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T34OK,q11Shape28T43OK⟩

private def q11Shape28T44 : Tree 11 := (.split 26 (.split 33 (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover {0,3,7,8,9,10})) (.tip (.cover {0,2,7,8,9,10})))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape28T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4325376 2195456 q11Shape28T44=true := by decide

private def q11Shape28T32 : Tree 11 := .split 22 q11Shape28T33 q11Shape28T44
private theorem q11Shape28T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 2195456 q11Shape28T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 (2195456 ||| 2^22) q11Shape28T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (131072 ||| 2^22) 2195456 q11Shape28T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T33OK,q11Shape28T44OK⟩

private def q11Shape28T45 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10}))))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape28T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2228224 98304 q11Shape28T45=true := by decide

private def q11Shape28T31 : Tree 11 := .split 21 q11Shape28T32 q11Shape28T45
private theorem q11Shape28T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 98304 q11Shape28T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 (98304 ||| 2^21) q11Shape28T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (131072 ||| 2^21) 98304 q11Shape28T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T32OK,q11Shape28T45OK⟩

def q11Shape28P1 : Tree 11 := q11Shape28T31
theorem q11Shape28P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 131072 98304 q11Shape28P1=true := q11Shape28T31OK

private def q11Shape28T53 : Tree 11 := (.tip (.small 1))
private theorem q11Shape28T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 8663498753 q11Shape28T53=true := by decide

private def q11Shape28T54 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,4,7,10}))) (.tip (.cover {2,3,5,6,7,10})))))))
private theorem q11Shape28T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65537 8663498752 q11Shape28T54=true := by decide

private def q11Shape28T52 : Tree 11 := .split 0 q11Shape28T53 q11Shape28T54
private theorem q11Shape28T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 8663498752 q11Shape28T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 (8663498752 ||| 2^0) q11Shape28T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (65536 ||| 2^0) 8663498752 q11Shape28T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T53OK,q11Shape28T54OK⟩

private def q11Shape28T56 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,4,5,10}))) (.tip (.cover {0,1,2,4,7,10}))) (.tip (.cover {2,3,5,6,7,10})))))))
private theorem q11Shape28T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590000128 73564161 q11Shape28T56=true := by decide

private def q11Shape28T58 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,2,4,5,8,10}))) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {2,5,6,7,8,10}))))))
private theorem q11Shape28T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590000129 73564192 q11Shape28T58=true := by decide

private def q11Shape28T59 : Tree 11 := (.split 2 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,2,4,5,9,10}))) (.tip (.cover {0,2,4,7,9,10})))
private theorem q11Shape28T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590000161 73564160 q11Shape28T59=true := by decide

private def q11Shape28T57 : Tree 11 := .split 5 q11Shape28T58 q11Shape28T59
private theorem q11Shape28T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590000129 73564160 q11Shape28T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590000129 (73564160 ||| 2^5) q11Shape28T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8590000129 ||| 2^5) 73564160 q11Shape28T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T58OK,q11Shape28T59OK⟩

private def q11Shape28T55 : Tree 11 := .split 0 q11Shape28T56 q11Shape28T57
private theorem q11Shape28T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590000128 73564160 q11Shape28T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8590000128 (73564160 ||| 2^0) q11Shape28T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8590000128 ||| 2^0) 73564160 q11Shape28T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T56OK,q11Shape28T57OK⟩

private def q11Shape28T51 : Tree 11 := .split 33 q11Shape28T52 q11Shape28T55
private theorem q11Shape28T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 73564160 q11Shape28T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 (73564160 ||| 2^33) q11Shape28T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (65536 ||| 2^33) 73564160 q11Shape28T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T52OK,q11Shape28T55OK⟩

private def q11Shape28T60 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover {0,3,6,8,9,10})) (.tip (.cover {0,2,6,8,9,10})))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape28T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 67174400 6455296 q11Shape28T60=true := by decide

private def q11Shape28T50 : Tree 11 := .split 26 q11Shape28T51 q11Shape28T60
private theorem q11Shape28T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 6455296 q11Shape28T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 (6455296 ||| 2^26) q11Shape28T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (65536 ||| 2^26) 6455296 q11Shape28T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T51OK,q11Shape28T60OK⟩

private def q11Shape28T61 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10}))))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape28T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4259840 2260992 q11Shape28T61=true := by decide

private def q11Shape28T49 : Tree 11 := .split 22 q11Shape28T50 q11Shape28T61
private theorem q11Shape28T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 2260992 q11Shape28T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 (2260992 ||| 2^22) q11Shape28T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (65536 ||| 2^22) 2260992 q11Shape28T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T50OK,q11Shape28T61OK⟩

private def q11Shape28T62 : Tree 11 := (.split 26 (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,6,7,10}))))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape28T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2162688 163840 q11Shape28T62=true := by decide

private def q11Shape28T48 : Tree 11 := .split 21 q11Shape28T49 q11Shape28T62
private theorem q11Shape28T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 163840 q11Shape28T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 (163840 ||| 2^21) q11Shape28T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (65536 ||| 2^21) 163840 q11Shape28T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T49OK,q11Shape28T62OK⟩

private def q11Shape28T63 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,10}))))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape28T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 196608 32768 q11Shape28T63=true := by decide

private def q11Shape28T47 : Tree 11 := .split 17 q11Shape28T48 q11Shape28T63
private theorem q11Shape28T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 32768 q11Shape28T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 (32768 ||| 2^17) q11Shape28T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (65536 ||| 2^17) 32768 q11Shape28T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T48OK,q11Shape28T63OK⟩

def q11Shape28P2 : Tree 11 := q11Shape28T47
theorem q11Shape28P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 65536 32768 q11Shape28P2=true := q11Shape28T47OK

end Graffiti384b.EffectiveSearch.Q11
