import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape28T72 : Tree 11 := (.tip (.small 1))
private theorem q11Shape28T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 8663531521 q11Shape28T72=true := by decide

private def q11Shape28T74 : Tree 11 := (.tip (.small 1))
private theorem q11Shape28T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32769 8663531552 q11Shape28T74=true := by decide

private def q11Shape28T75 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,4,6,10}))) (.tip (.cover {0,1,2,4,7,10}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,5,6,7,10}))))))
private theorem q11Shape28T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32801 8663531520 q11Shape28T75=true := by decide

private def q11Shape28T73 : Tree 11 := .split 5 q11Shape28T74 q11Shape28T75
private theorem q11Shape28T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32769 8663531520 q11Shape28T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32769 (8663531520 ||| 2^5) q11Shape28T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32769 ||| 2^5) 8663531520 q11Shape28T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T74OK,q11Shape28T75OK⟩

private def q11Shape28T71 : Tree 11 := .split 0 q11Shape28T72 q11Shape28T73
private theorem q11Shape28T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 8663531520 q11Shape28T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 (8663531520 ||| 2^0) q11Shape28T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32768 ||| 2^0) 8663531520 q11Shape28T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T72OK,q11Shape28T73OK⟩

private def q11Shape28T78 : Tree 11 := (.tip (.small 1))
private theorem q11Shape28T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967360 73596961 q11Shape28T78=true := by decide

private def q11Shape28T79 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,4,6,10}))) (.tip (.cover {0,1,2,4,7,10}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,5,6,7,10}))))))
private theorem q11Shape28T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967392 73596929 q11Shape28T79=true := by decide

private def q11Shape28T77 : Tree 11 := .split 5 q11Shape28T78 q11Shape28T79
private theorem q11Shape28T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967360 73596929 q11Shape28T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967360 (73596929 ||| 2^5) q11Shape28T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8589967360 ||| 2^5) 73596929 q11Shape28T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T78OK,q11Shape28T79OK⟩

private def q11Shape28T81 : Tree 11 := (.split 6 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 1 (.split 2 (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,2,4,6,8,10}))) (.tip (.cover {0,2,4,7,8,10}))) (.tip (.cover {2,4,6,7,8,10}))) (.tip (.cover {2,5,6,7,8,10}))))))
private theorem q11Shape28T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967361 73596960 q11Shape28T81=true := by decide

private def q11Shape28T82 : Tree 11 := (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,2,4,6,9,10}))) (.tip (.cover {0,2,4,7,9,10})))
private theorem q11Shape28T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967393 73596928 q11Shape28T82=true := by decide

private def q11Shape28T80 : Tree 11 := .split 5 q11Shape28T81 q11Shape28T82
private theorem q11Shape28T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967361 73596928 q11Shape28T80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967361 (73596928 ||| 2^5) q11Shape28T81 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8589967361 ||| 2^5) 73596928 q11Shape28T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T81OK,q11Shape28T82OK⟩

private def q11Shape28T76 : Tree 11 := .split 0 q11Shape28T77 q11Shape28T80
private theorem q11Shape28T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967360 73596928 q11Shape28T76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 8589967360 (73596928 ||| 2^0) q11Shape28T77 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (8589967360 ||| 2^0) 73596928 q11Shape28T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T77OK,q11Shape28T80OK⟩

private def q11Shape28T70 : Tree 11 := .split 33 q11Shape28T71 q11Shape28T76
private theorem q11Shape28T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 73596928 q11Shape28T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 (73596928 ||| 2^33) q11Shape28T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32768 ||| 2^33) 73596928 q11Shape28T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T71OK,q11Shape28T76OK⟩

private def q11Shape28T83 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10}))))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape28T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 67141632 6488064 q11Shape28T83=true := by decide

private def q11Shape28T69 : Tree 11 := .split 26 q11Shape28T70 q11Shape28T83
private theorem q11Shape28T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 6488064 q11Shape28T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 (6488064 ||| 2^26) q11Shape28T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32768 ||| 2^26) 6488064 q11Shape28T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T70OK,q11Shape28T83OK⟩

private def q11Shape28T84 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,10}))))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape28T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 4227072 2293760 q11Shape28T84=true := by decide

private def q11Shape28T68 : Tree 11 := .split 22 q11Shape28T69 q11Shape28T84
private theorem q11Shape28T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 2293760 q11Shape28T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 (2293760 ||| 2^22) q11Shape28T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32768 ||| 2^22) 2293760 q11Shape28T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T69OK,q11Shape28T84OK⟩

private def q11Shape28T85 : Tree 11 := (.split 22 (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,10}))))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape28T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 2129920 196608 q11Shape28T85=true := by decide

private def q11Shape28T67 : Tree 11 := .split 21 q11Shape28T68 q11Shape28T85
private theorem q11Shape28T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 196608 q11Shape28T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 (196608 ||| 2^21) q11Shape28T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32768 ||| 2^21) 196608 q11Shape28T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T68OK,q11Shape28T85OK⟩

private def q11Shape28T86 : Tree 11 := (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,10}))))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape28T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 163840 65536 q11Shape28T86=true := by decide

private def q11Shape28T66 : Tree 11 := .split 17 q11Shape28T67 q11Shape28T86
private theorem q11Shape28T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 65536 q11Shape28T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 (65536 ||| 2^17) q11Shape28T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32768 ||| 2^17) 65536 q11Shape28T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T67OK,q11Shape28T86OK⟩

private def q11Shape28T87 : Tree 11 := (.split 17 (.split 33 (.split 0 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,10}))))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape28T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 98304 0 q11Shape28T87=true := by decide

private def q11Shape28T65 : Tree 11 := .split 16 q11Shape28T66 q11Shape28T87
private theorem q11Shape28T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 0 q11Shape28T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 (0 ||| 2^16) q11Shape28T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) (32768 ||| 2^16) 0 q11Shape28T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape28T66OK,q11Shape28T87OK⟩

def q11Shape28P3 : Tree 11 := q11Shape28T65
theorem q11Shape28P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,2⟩) 32768 0 q11Shape28P3=true := q11Shape28T65OK

end Graffiti384b.EffectiveSearch.Q11
