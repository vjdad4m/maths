import Q11Shape29Part0
import Q11Shape29Part1
import Q11Shape29Part2
import Q11Shape29Part3
import Q11Shape29Part4
import Q11Shape29Part5
import Q11Shape29Part6
import Q11Shape29Part7

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29M82 : Tree 11 := .split 27 q11Shape29P0 q11Shape29P1
private theorem q11Shape29M82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 73400320 q11Shape29M82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (73400320 ||| 2^27) q11Shape29P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^27) 73400320 q11Shape29P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29P0OK,q11Shape29P1OK⟩
private def q11Shape29M151 : Tree 11 := .split 31 q11Shape29P2 q11Shape29P3
private theorem q11Shape29M151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 27042775040 q11Shape29M151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (27042775040 ||| 2^31) q11Shape29P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^31) 27042775040 q11Shape29P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29P2OK,q11Shape29P3OK⟩
private def q11Shape29M153 : Tree 11 := .split 34 q11Shape29M151 q11Shape29P4
private theorem q11Shape29M153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 9862905856 q11Shape29M153=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (9862905856 ||| 2^34) q11Shape29M151 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^34) 9862905856 q11Shape29P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M151OK,q11Shape29P4OK⟩
private def q11Shape29M155 : Tree 11 := .split 33 q11Shape29M153 q11Shape29P5
private theorem q11Shape29M155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 1272971264 q11Shape29M155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (1272971264 ||| 2^33) q11Shape29M153 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^33) 1272971264 q11Shape29P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M153OK,q11Shape29P5OK⟩
private def q11Shape29M157 : Tree 11 := .split 25 q11Shape29M155 q11Shape29P6
private theorem q11Shape29M157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 1239416832 q11Shape29M157=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (1239416832 ||| 2^25) q11Shape29M155 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^25) 1239416832 q11Shape29P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M155OK,q11Shape29P6OK⟩
private def q11Shape29M159 : Tree 11 := .split 24 q11Shape29M157 q11Shape29P7
private theorem q11Shape29M159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 1222639616 q11Shape29M159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (1222639616 ||| 2^24) q11Shape29M157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^24) 1222639616 q11Shape29P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M157OK,q11Shape29P7OK⟩
private def q11Shape29M161 : Tree 11 := .split 23 q11Shape29M159 q11Shape29P8
private theorem q11Shape29M161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 1214251008 q11Shape29M161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (1214251008 ||| 2^23) q11Shape29M159 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^23) 1214251008 q11Shape29P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M159OK,q11Shape29P8OK⟩
private def q11Shape29M163 : Tree 11 := .split 30 q11Shape29M161 q11Shape29P9
private theorem q11Shape29M163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 140509184 q11Shape29M163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (140509184 ||| 2^30) q11Shape29M161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^30) 140509184 q11Shape29P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M161OK,q11Shape29P9OK⟩
private def q11Shape29M165 : Tree 11 := .split 27 q11Shape29M163 q11Shape29P10
private theorem q11Shape29M165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 6291456 q11Shape29M165=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (6291456 ||| 2^27) q11Shape29M163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^27) 6291456 q11Shape29P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M163OK,q11Shape29P10OK⟩
private def q11Shape29M166 : Tree 11 := .split 26 q11Shape29M82 q11Shape29M165
private theorem q11Shape29M166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 6291456 q11Shape29M166=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (6291456 ||| 2^26) q11Shape29M82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^26) 6291456 q11Shape29M165)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M82OK,q11Shape29M165OK⟩
private def q11Shape29M235 : Tree 11 := .split 31 q11Shape29P11 q11Shape29P12
private theorem q11Shape29M235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 27860664320 q11Shape29M235=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (27860664320 ||| 2^31) q11Shape29P11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^31) 27860664320 q11Shape29P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29P11OK,q11Shape29P12OK⟩
private def q11Shape29M237 : Tree 11 := .split 34 q11Shape29M235 q11Shape29P13
private theorem q11Shape29M237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 10680795136 q11Shape29M237=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (10680795136 ||| 2^34) q11Shape29M235 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^34) 10680795136 q11Shape29P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M235OK,q11Shape29P13OK⟩
private def q11Shape29M239 : Tree 11 := .split 33 q11Shape29M237 q11Shape29P14
private theorem q11Shape29M239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 2090860544 q11Shape29M239=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (2090860544 ||| 2^33) q11Shape29M237 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^33) 2090860544 q11Shape29P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M237OK,q11Shape29P14OK⟩
private def q11Shape29M241 : Tree 11 := .split 29 q11Shape29M239 q11Shape29P15
private theorem q11Shape29M241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 1553989632 q11Shape29M241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (1553989632 ||| 2^29) q11Shape29M239 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^29) 1553989632 q11Shape29P15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M239OK,q11Shape29P15OK⟩
private def q11Shape29M243 : Tree 11 := .split 28 q11Shape29M241 q11Shape29P16
private theorem q11Shape29M243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 1285554176 q11Shape29M243=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (1285554176 ||| 2^28) q11Shape29M241 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^28) 1285554176 q11Shape29P16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M241OK,q11Shape29P16OK⟩
private def q11Shape29M245 : Tree 11 := .split 23 q11Shape29M243 q11Shape29P17
private theorem q11Shape29M245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 1277165568 q11Shape29M245=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (1277165568 ||| 2^23) q11Shape29M243 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^23) 1277165568 q11Shape29P17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M243OK,q11Shape29P17OK⟩
private def q11Shape29M247 : Tree 11 := .split 30 q11Shape29M245 q11Shape29P18
private theorem q11Shape29M247OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 203423744 q11Shape29M247=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (203423744 ||| 2^30) q11Shape29M245 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^30) 203423744 q11Shape29P18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M245OK,q11Shape29P18OK⟩
private def q11Shape29M249 : Tree 11 := .split 27 q11Shape29M247 q11Shape29P19
private theorem q11Shape29M249OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 69206016 q11Shape29M249=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (69206016 ||| 2^27) q11Shape29M247 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^27) 69206016 q11Shape29P19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M247OK,q11Shape29P19OK⟩
private def q11Shape29M251 : Tree 11 := .split 26 q11Shape29M249 q11Shape29P20
private theorem q11Shape29M251OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 2097152 q11Shape29M251=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (2097152 ||| 2^26) q11Shape29M249 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^26) 2097152 q11Shape29P20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M249OK,q11Shape29P20OK⟩
private def q11Shape29M252 : Tree 11 := .split 22 q11Shape29M166 q11Shape29M251
private theorem q11Shape29M252OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 2097152 q11Shape29M252=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (2097152 ||| 2^22) q11Shape29M166 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^22) 2097152 q11Shape29M251)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M166OK,q11Shape29M251OK⟩
private def q11Shape29M323 : Tree 11 := .split 24 q11Shape29P21 q11Shape29P22
private theorem q11Shape29M323OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 33499906048 q11Shape29M323=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (33499906048 ||| 2^24) q11Shape29P21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^24) 33499906048 q11Shape29P22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29P21OK,q11Shape29P22OK⟩
private def q11Shape29M325 : Tree 11 := .split 34 q11Shape29M323 q11Shape29P23
private theorem q11Shape29M325OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 16320036864 q11Shape29M325=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (16320036864 ||| 2^34) q11Shape29M323 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^34) 16320036864 q11Shape29P23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M323OK,q11Shape29P23OK⟩
private def q11Shape29M327 : Tree 11 := .split 33 q11Shape29M325 q11Shape29P24
private theorem q11Shape29M327OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 7730102272 q11Shape29M327=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (7730102272 ||| 2^33) q11Shape29M325 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^33) 7730102272 q11Shape29P24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M325OK,q11Shape29P24OK⟩
private def q11Shape29M329 : Tree 11 := .split 32 q11Shape29M327 q11Shape29P25
private theorem q11Shape29M329OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 3435134976 q11Shape29M329=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (3435134976 ||| 2^32) q11Shape29M327 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^32) 3435134976 q11Shape29P25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M327OK,q11Shape29P25OK⟩
private def q11Shape29M331 : Tree 11 := .split 31 q11Shape29M329 q11Shape29P26
private theorem q11Shape29M331OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 1287651328 q11Shape29M331=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (1287651328 ||| 2^31) q11Shape29M329 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^31) 1287651328 q11Shape29P26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M329OK,q11Shape29P26OK⟩
private def q11Shape29M333 : Tree 11 := .split 23 q11Shape29M331 q11Shape29P27
private theorem q11Shape29M333OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 1279262720 q11Shape29M333=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (1279262720 ||| 2^23) q11Shape29M331 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^23) 1279262720 q11Shape29P27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M331OK,q11Shape29P27OK⟩
private def q11Shape29M335 : Tree 11 := .split 30 q11Shape29M333 q11Shape29P28
private theorem q11Shape29M335OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 205520896 q11Shape29M335=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (205520896 ||| 2^30) q11Shape29M333 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^30) 205520896 q11Shape29P28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M333OK,q11Shape29P28OK⟩
private def q11Shape29M337 : Tree 11 := .split 27 q11Shape29M335 q11Shape29P29
private theorem q11Shape29M337OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 71303168 q11Shape29M337=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (71303168 ||| 2^27) q11Shape29M335 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^27) 71303168 q11Shape29P29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M335OK,q11Shape29P29OK⟩
private def q11Shape29M339 : Tree 11 := .split 26 q11Shape29M337 q11Shape29P30
private theorem q11Shape29M339OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 4194304 q11Shape29M339=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (4194304 ||| 2^26) q11Shape29M337 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^26) 4194304 q11Shape29P30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M337OK,q11Shape29P30OK⟩
private def q11Shape29M341 : Tree 11 := .split 22 q11Shape29M339 q11Shape29P31
private theorem q11Shape29M341OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 0 q11Shape29M341=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (0 ||| 2^22) q11Shape29M339 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^22) 0 q11Shape29P31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M339OK,q11Shape29P31OK⟩
private def q11Shape29M342 : Tree 11 := .split 21 q11Shape29M252 q11Shape29M341
private theorem q11Shape29M342OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 0 q11Shape29M342=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (0 ||| 2^21) q11Shape29M252 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^21) 0 q11Shape29M341)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29M252OK,q11Shape29M341OK⟩

theorem q11Shape29_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 29) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 29) b) (adj 11 (forms 29) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) adj_mono b H q11Shape29M342 q11Shape29M342OK

#print axioms q11Shape29_cover

end Graffiti384b.EffectiveSearch.Q11
