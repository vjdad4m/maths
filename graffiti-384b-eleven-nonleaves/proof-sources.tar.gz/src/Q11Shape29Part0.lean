import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T6 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 8017412096 q11Shape29T6=true := by decide

private def q11Shape29T9 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 268435456 8319401984 q11Shape29T9=true := by decide

private def q11Shape29T13 : Tree 11 := (.split 18 (.split 5 (.tip (.small 1)) (.split 2 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,7,9,10})))) (.split 5 (.split 15 (.split 17 (.tip (.cover {0,2,3,8,9,10})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,2,3,4,6,9}))))
private theorem q11Shape29T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805306368 33552338944 q11Shape29T13=true := by decide

private def q11Shape29T14 : Tree 11 := (.split 18 (.split 5 (.split 9 (.split 11 (.tip (.cover {0,2,4,8,9,10})) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,2,3,4,6,9}))) (.tip (.cover {0,2,3,4,6,9})))
private theorem q11Shape29T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805310464 33552334848 q11Shape29T14=true := by decide

private def q11Shape29T12 : Tree 11 := .split 12 q11Shape29T13 q11Shape29T14
private theorem q11Shape29T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805306368 33552334848 q11Shape29T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805306368 (33552334848 ||| 2^12) q11Shape29T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (805306368 ||| 2^12) 33552334848 q11Shape29T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T13OK,q11Shape29T14OK⟩

private def q11Shape29T15 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17985175552 16372465664 q11Shape29T15=true := by decide

private def q11Shape29T11 : Tree 11 := .split 34 q11Shape29T12 q11Shape29T15
private theorem q11Shape29T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805306368 16372465664 q11Shape29T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805306368 (16372465664 ||| 2^34) q11Shape29T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (805306368 ||| 2^34) 16372465664 q11Shape29T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T12OK,q11Shape29T15OK⟩

private def q11Shape29T16 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 9395240960 7782531072 q11Shape29T16=true := by decide

private def q11Shape29T10 : Tree 11 := .split 33 q11Shape29T11 q11Shape29T16
private theorem q11Shape29T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805306368 7782531072 q11Shape29T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 805306368 (7782531072 ||| 2^33) q11Shape29T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (805306368 ||| 2^33) 7782531072 q11Shape29T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T11OK,q11Shape29T16OK⟩

private def q11Shape29T8 : Tree 11 := .split 29 q11Shape29T9 q11Shape29T10
private theorem q11Shape29T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 268435456 7782531072 q11Shape29T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 268435456 (7782531072 ||| 2^29) q11Shape29T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (268435456 ||| 2^29) 7782531072 q11Shape29T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T9OK,q11Shape29T10OK⟩

private def q11Shape29T17 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 301989888 7748976640 q11Shape29T17=true := by decide

private def q11Shape29T7 : Tree 11 := .split 25 q11Shape29T8 q11Shape29T17
private theorem q11Shape29T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 268435456 7748976640 q11Shape29T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 268435456 (7748976640 ||| 2^25) q11Shape29T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (268435456 ||| 2^25) 7748976640 q11Shape29T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T8OK,q11Shape29T17OK⟩

private def q11Shape29T5 : Tree 11 := .split 28 q11Shape29T6 q11Shape29T7
private theorem q11Shape29T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 7748976640 q11Shape29T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (7748976640 ||| 2^28) q11Shape29T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^28) 7748976640 q11Shape29T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T6OK,q11Shape29T7OK⟩

private def q11Shape29T21 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 16777216 8571060224 q11Shape29T21=true := by decide

private def q11Shape29T25 : Tree 11 := (.split 18 (.split 5 (.tip (.small 1)) (.split 3 (.split 4 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,6,9,10}))) (.tip (.cover {0,1,2,7,9,10})))) (.split 5 (.split 16 (.split 17 (.tip (.cover {0,2,3,8,9,10})) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,2,3,4,5,9}))))
private theorem q11Shape29T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50331648 34307313664 q11Shape29T25=true := by decide

private def q11Shape29T26 : Tree 11 := (.split 18 (.split 5 (.split 10 (.split 11 (.tip (.cover {0,2,4,8,9,10})) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,2,3,4,5,9}))) (.tip (.cover {0,2,3,4,5,9})))
private theorem q11Shape29T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50335744 34307309568 q11Shape29T26=true := by decide

private def q11Shape29T24 : Tree 11 := .split 12 q11Shape29T25 q11Shape29T26
private theorem q11Shape29T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50331648 34307309568 q11Shape29T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50331648 (34307309568 ||| 2^12) q11Shape29T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (50331648 ||| 2^12) 34307309568 q11Shape29T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T25OK,q11Shape29T26OK⟩

private def q11Shape29T27 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17230200832 17127440384 q11Shape29T27=true := by decide

private def q11Shape29T23 : Tree 11 := .split 34 q11Shape29T24 q11Shape29T27
private theorem q11Shape29T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50331648 17127440384 q11Shape29T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50331648 (17127440384 ||| 2^34) q11Shape29T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (50331648 ||| 2^34) 17127440384 q11Shape29T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T24OK,q11Shape29T27OK⟩

private def q11Shape29T28 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8640266240 8537505792 q11Shape29T28=true := by decide

private def q11Shape29T22 : Tree 11 := .split 33 q11Shape29T23 q11Shape29T28
private theorem q11Shape29T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50331648 8537505792 q11Shape29T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 50331648 (8537505792 ||| 2^33) q11Shape29T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (50331648 ||| 2^33) 8537505792 q11Shape29T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T23OK,q11Shape29T28OK⟩

private def q11Shape29T20 : Tree 11 := .split 25 q11Shape29T21 q11Shape29T22
private theorem q11Shape29T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 16777216 8537505792 q11Shape29T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 16777216 (8537505792 ||| 2^25) q11Shape29T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (16777216 ||| 2^25) 8537505792 q11Shape29T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T21OK,q11Shape29T22OK⟩

private def q11Shape29T29 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 553648128 8000634880 q11Shape29T29=true := by decide

private def q11Shape29T19 : Tree 11 := .split 29 q11Shape29T20 q11Shape29T29
private theorem q11Shape29T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 16777216 8000634880 q11Shape29T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 16777216 (8000634880 ||| 2^29) q11Shape29T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (16777216 ||| 2^29) 8000634880 q11Shape29T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T20OK,q11Shape29T29OK⟩

private def q11Shape29T30 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 285212672 7732199424 q11Shape29T30=true := by decide

private def q11Shape29T18 : Tree 11 := .split 28 q11Shape29T19 q11Shape29T30
private theorem q11Shape29T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 16777216 7732199424 q11Shape29T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 16777216 (7732199424 ||| 2^28) q11Shape29T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (16777216 ||| 2^28) 7732199424 q11Shape29T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T19OK,q11Shape29T30OK⟩

private def q11Shape29T4 : Tree 11 := .split 24 q11Shape29T5 q11Shape29T18
private theorem q11Shape29T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 7732199424 q11Shape29T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (7732199424 ||| 2^24) q11Shape29T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^24) 7732199424 q11Shape29T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T5OK,q11Shape29T18OK⟩

private def q11Shape29T31 : Tree 11 := (.split 24 (.split 28 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape29T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4294967296 3437232128 q11Shape29T31=true := by decide

private def q11Shape29T3 : Tree 11 := .split 32 q11Shape29T4 q11Shape29T31
private theorem q11Shape29T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 3437232128 q11Shape29T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (3437232128 ||| 2^32) q11Shape29T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^32) 3437232128 q11Shape29T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T4OK,q11Shape29T31OK⟩

private def q11Shape29T37 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 6440353792 q11Shape29T37=true := by decide

private def q11Shape29T41 : Tree 11 := (.split 18 (.split 5 (.tip (.small 1)) (.split 2 (.split 3 (.tip (.cover {0,3,4,8,9,10})) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10})))) (.split 5 (.split 15 (.split 16 (.tip (.cover {0,2,3,8,9,10})) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,2,3,4,7,9}))))
private theorem q11Shape29T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442450944 27915194368 q11Shape29T41=true := by decide

private def q11Shape29T42 : Tree 11 := (.split 18 (.split 5 (.split 9 (.split 10 (.tip (.cover {0,2,4,8,9,10})) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,2,3,4,7,9}))) (.tip (.cover {0,2,3,4,7,9})))
private theorem q11Shape29T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442455040 27915190272 q11Shape29T42=true := by decide

private def q11Shape29T40 : Tree 11 := .split 12 q11Shape29T41 q11Shape29T42
private theorem q11Shape29T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442450944 27915190272 q11Shape29T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442450944 (27915190272 ||| 2^12) q11Shape29T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (6442450944 ||| 2^12) 27915190272 q11Shape29T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T41OK,q11Shape29T42OK⟩

private def q11Shape29T43 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 23622320128 10735321088 q11Shape29T43=true := by decide

private def q11Shape29T39 : Tree 11 := .split 34 q11Shape29T40 q11Shape29T43
private theorem q11Shape29T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442450944 10735321088 q11Shape29T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442450944 (10735321088 ||| 2^34) q11Shape29T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (6442450944 ||| 2^34) 10735321088 q11Shape29T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T40OK,q11Shape29T43OK⟩

private def q11Shape29T44 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 15032385536 2145386496 q11Shape29T44=true := by decide

private def q11Shape29T38 : Tree 11 := .split 33 q11Shape29T39 q11Shape29T44
private theorem q11Shape29T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442450944 2145386496 q11Shape29T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6442450944 (2145386496 ||| 2^33) q11Shape29T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (6442450944 ||| 2^33) 2145386496 q11Shape29T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T39OK,q11Shape29T44OK⟩

private def q11Shape29T36 : Tree 11 := .split 32 q11Shape29T37 q11Shape29T38
private theorem q11Shape29T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 2145386496 q11Shape29T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 (2145386496 ||| 2^32) q11Shape29T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2147483648 ||| 2^32) 2145386496 q11Shape29T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T37OK,q11Shape29T38OK⟩

private def q11Shape29T45 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2684354560 1608515584 q11Shape29T45=true := by decide

private def q11Shape29T35 : Tree 11 := .split 29 q11Shape29T36 q11Shape29T45
private theorem q11Shape29T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 1608515584 q11Shape29T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 (1608515584 ||| 2^29) q11Shape29T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2147483648 ||| 2^29) 1608515584 q11Shape29T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T36OK,q11Shape29T45OK⟩

private def q11Shape29T46 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2415919104 1340080128 q11Shape29T46=true := by decide

private def q11Shape29T34 : Tree 11 := .split 28 q11Shape29T35 q11Shape29T46
private theorem q11Shape29T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 1340080128 q11Shape29T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 (1340080128 ||| 2^28) q11Shape29T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2147483648 ||| 2^28) 1340080128 q11Shape29T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T35OK,q11Shape29T46OK⟩

private def q11Shape29T47 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2181038080 1306525696 q11Shape29T47=true := by decide

private def q11Shape29T33 : Tree 11 := .split 25 q11Shape29T34 q11Shape29T47
private theorem q11Shape29T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 1306525696 q11Shape29T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 (1306525696 ||| 2^25) q11Shape29T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2147483648 ||| 2^25) 1306525696 q11Shape29T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T34OK,q11Shape29T47OK⟩

private def q11Shape29T48 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2164260864 1289748480 q11Shape29T48=true := by decide

private def q11Shape29T32 : Tree 11 := .split 24 q11Shape29T33 q11Shape29T48
private theorem q11Shape29T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 1289748480 q11Shape29T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2147483648 (1289748480 ||| 2^24) q11Shape29T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2147483648 ||| 2^24) 1289748480 q11Shape29T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T33OK,q11Shape29T48OK⟩

private def q11Shape29T2 : Tree 11 := .split 31 q11Shape29T3 q11Shape29T32
private theorem q11Shape29T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 1289748480 q11Shape29T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (1289748480 ||| 2^31) q11Shape29T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^31) 1289748480 q11Shape29T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T3OK,q11Shape29T32OK⟩

private def q11Shape29T53 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 8009023488 q11Shape29T53=true := by decide

private def q11Shape29T54 : Tree 11 := (.split 29 (.split 25 (.tip (.cover {0,2,3,4,8,9})) (.split 33 (.split 34 (.split 12 (.split 18 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,3,4,5,9}))) (.tip (.cover {0,2,3,4,5,9}))) (.tip (.cover {0,2,3,4,5,9}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape29T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 25165824 7992246272 q11Shape29T54=true := by decide

private def q11Shape29T52 : Tree 11 := .split 24 q11Shape29T53 q11Shape29T54
private theorem q11Shape29T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 7992246272 q11Shape29T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 (7992246272 ||| 2^24) q11Shape29T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (8388608 ||| 2^24) 7992246272 q11Shape29T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T53OK,q11Shape29T54OK⟩

private def q11Shape29T55 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 276824064 7723810816 q11Shape29T55=true := by decide

private def q11Shape29T51 : Tree 11 := .split 28 q11Shape29T52 q11Shape29T55
private theorem q11Shape29T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 7723810816 q11Shape29T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 (7723810816 ||| 2^28) q11Shape29T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (8388608 ||| 2^28) 7723810816 q11Shape29T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T52OK,q11Shape29T55OK⟩

private def q11Shape29T56 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4303355904 3428843520 q11Shape29T56=true := by decide

private def q11Shape29T50 : Tree 11 := .split 32 q11Shape29T51 q11Shape29T56
private theorem q11Shape29T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 3428843520 q11Shape29T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 (3428843520 ||| 2^32) q11Shape29T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (8388608 ||| 2^32) 3428843520 q11Shape29T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T51OK,q11Shape29T56OK⟩

private def q11Shape29T57 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2155872256 1281359872 q11Shape29T57=true := by decide

private def q11Shape29T49 : Tree 11 := .split 31 q11Shape29T50 q11Shape29T57
private theorem q11Shape29T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 1281359872 q11Shape29T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8388608 (1281359872 ||| 2^31) q11Shape29T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (8388608 ||| 2^31) 1281359872 q11Shape29T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T50OK,q11Shape29T57OK⟩

private def q11Shape29T1 : Tree 11 := .split 23 q11Shape29T2 q11Shape29T49
private theorem q11Shape29T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 1281359872 q11Shape29T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (1281359872 ||| 2^23) q11Shape29T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^23) 1281359872 q11Shape29T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T2OK,q11Shape29T49OK⟩

private def q11Shape29T63 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 2682257408 q11Shape29T63=true := by decide

private def q11Shape29T64 : Tree 11 := (.split 29 (.split 32 (.tip (.cover {0,2,3,4,8,9})) (.split 33 (.split 34 (.split 12 (.split 18 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,3,4,7,9}))) (.tip (.cover {0,2,3,4,7,9}))) (.tip (.cover {0,2,3,4,7,9}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape29T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 3221225472 534773760 q11Shape29T64=true := by decide

private def q11Shape29T62 : Tree 11 := .split 31 q11Shape29T63 q11Shape29T64
private theorem q11Shape29T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 534773760 q11Shape29T62=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 (534773760 ||| 2^31) q11Shape29T63 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (1073741824 ||| 2^31) 534773760 q11Shape29T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T63OK,q11Shape29T64OK⟩

private def q11Shape29T65 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1342177280 266338304 q11Shape29T65=true := by decide

private def q11Shape29T61 : Tree 11 := .split 28 q11Shape29T62 q11Shape29T65
private theorem q11Shape29T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 266338304 q11Shape29T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 (266338304 ||| 2^28) q11Shape29T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (1073741824 ||| 2^28) 266338304 q11Shape29T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T62OK,q11Shape29T65OK⟩

private def q11Shape29T66 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1107296256 232783872 q11Shape29T66=true := by decide

private def q11Shape29T60 : Tree 11 := .split 25 q11Shape29T61 q11Shape29T66
private theorem q11Shape29T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 232783872 q11Shape29T60=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 (232783872 ||| 2^25) q11Shape29T61 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (1073741824 ||| 2^25) 232783872 q11Shape29T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T61OK,q11Shape29T66OK⟩

private def q11Shape29T67 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1090519040 216006656 q11Shape29T67=true := by decide

private def q11Shape29T59 : Tree 11 := .split 24 q11Shape29T60 q11Shape29T67
private theorem q11Shape29T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 216006656 q11Shape29T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 (216006656 ||| 2^24) q11Shape29T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (1073741824 ||| 2^24) 216006656 q11Shape29T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T60OK,q11Shape29T67OK⟩

private def q11Shape29T68 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1082130432 207618048 q11Shape29T68=true := by decide

private def q11Shape29T58 : Tree 11 := .split 23 q11Shape29T59 q11Shape29T68
private theorem q11Shape29T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 207618048 q11Shape29T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1073741824 (207618048 ||| 2^23) q11Shape29T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (1073741824 ||| 2^23) 207618048 q11Shape29T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T59OK,q11Shape29T68OK⟩

private def q11Shape29T0 : Tree 11 := .split 30 q11Shape29T1 q11Shape29T58
private theorem q11Shape29T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 207618048 q11Shape29T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 (207618048 ||| 2^30) q11Shape29T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (0 ||| 2^30) 207618048 q11Shape29T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T1OK,q11Shape29T58OK⟩

def q11Shape29P0 : Tree 11 := q11Shape29T0
theorem q11Shape29P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 0 207618048 q11Shape29P0=true := q11Shape29T0OK

end Graffiti384b.EffectiveSearch.Q11
