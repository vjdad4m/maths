import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T75 : Tree 11 := (.split 28 (.tip (.cover {0,2,3,4,8,10})) (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.split 33 (.split 34 (.split 12 (.split 18 (.split 5 (.tip (.small 1)) (.tip (.cover {0,2,3,4,6,9}))) (.tip (.cover {0,2,3,4,6,9}))) (.tip (.cover {0,2,3,4,6,9}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10})))))
private theorem q11Shape29T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 7648313344 q11Shape29T75=true := by decide

private def q11Shape29T76 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 167772160 7614758912 q11Shape29T76=true := by decide

private def q11Shape29T74 : Tree 11 := .split 25 q11Shape29T75 q11Shape29T76
private theorem q11Shape29T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 7614758912 q11Shape29T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 (7614758912 ||| 2^25) q11Shape29T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (134217728 ||| 2^25) 7614758912 q11Shape29T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T75OK,q11Shape29T76OK⟩

private def q11Shape29T77 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 150994944 7597981696 q11Shape29T77=true := by decide

private def q11Shape29T73 : Tree 11 := .split 24 q11Shape29T74 q11Shape29T77
private theorem q11Shape29T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 7597981696 q11Shape29T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 (7597981696 ||| 2^24) q11Shape29T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (134217728 ||| 2^24) 7597981696 q11Shape29T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T74OK,q11Shape29T77OK⟩

private def q11Shape29T78 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4429185024 3303014400 q11Shape29T78=true := by decide

private def q11Shape29T72 : Tree 11 := .split 32 q11Shape29T73 q11Shape29T78
private theorem q11Shape29T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 3303014400 q11Shape29T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 (3303014400 ||| 2^32) q11Shape29T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (134217728 ||| 2^32) 3303014400 q11Shape29T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T73OK,q11Shape29T78OK⟩

private def q11Shape29T79 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2281701376 1155530752 q11Shape29T79=true := by decide

private def q11Shape29T71 : Tree 11 := .split 31 q11Shape29T72 q11Shape29T79
private theorem q11Shape29T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 1155530752 q11Shape29T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 (1155530752 ||| 2^31) q11Shape29T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (134217728 ||| 2^31) 1155530752 q11Shape29T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T72OK,q11Shape29T79OK⟩

private def q11Shape29T80 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 142606336 1147142144 q11Shape29T80=true := by decide

private def q11Shape29T70 : Tree 11 := .split 23 q11Shape29T71 q11Shape29T80
private theorem q11Shape29T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 1147142144 q11Shape29T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 (1147142144 ||| 2^23) q11Shape29T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (134217728 ||| 2^23) 1147142144 q11Shape29T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T71OK,q11Shape29T80OK⟩

private def q11Shape29T81 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1207959552 73400320 q11Shape29T81=true := by decide

private def q11Shape29T69 : Tree 11 := .split 30 q11Shape29T70 q11Shape29T81
private theorem q11Shape29T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 73400320 q11Shape29T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 (73400320 ||| 2^30) q11Shape29T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (134217728 ||| 2^30) 73400320 q11Shape29T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T70OK,q11Shape29T81OK⟩

def q11Shape29P1 : Tree 11 := q11Shape29T69
theorem q11Shape29P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 134217728 73400320 q11Shape29P1=true := q11Shape29T69OK

end Graffiti384b.EffectiveSearch.Q11
