import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T89 : Tree 11 := (.tip (.small 1))
private theorem q11Shape29T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 34290798624 q11Shape29T89=true := by decide

private def q11Shape29T92 : Tree 11 := (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 9 (.tip (.cover {0,4,6,8,9,10})) (.tip (.cover {0,3,6,8,9,10})))))))
private theorem q11Shape29T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108896 34290798604 q11Shape29T92=true := by decide

private def q11Shape29T93 : Tree 11 := (.split 4 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover {1,2,5,7,9,10})))) (.tip (.cover {0,1,2,5,9,10})))
private theorem q11Shape29T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108904 34290798596 q11Shape29T93=true := by decide

private def q11Shape29T91 : Tree 11 := .split 3 q11Shape29T92 q11Shape29T93
private theorem q11Shape29T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108896 34290798596 q11Shape29T91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108896 (34290798596 ||| 2^3) q11Shape29T92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108896 ||| 2^3) 34290798596 q11Shape29T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T92OK,q11Shape29T93OK⟩

private def q11Shape29T94 : Tree 11 := (.tip (.cover {0,1,2,6,9,10}))
private theorem q11Shape29T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108900 34290798592 q11Shape29T94=true := by decide

private def q11Shape29T90 : Tree 11 := .split 2 q11Shape29T91 q11Shape29T94
private theorem q11Shape29T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108896 34290798592 q11Shape29T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108896 (34290798592 ||| 2^2) q11Shape29T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108896 ||| 2^2) 34290798592 q11Shape29T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T91OK,q11Shape29T94OK⟩

private def q11Shape29T88 : Tree 11 := .split 5 q11Shape29T89 q11Shape29T90
private theorem q11Shape29T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 34290798592 q11Shape29T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (34290798592 ||| 2^5) q11Shape29T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^5) 34290798592 q11Shape29T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T89OK,q11Shape29T90OK⟩

private def q11Shape29T95 : Tree 11 := (.split 5 (.split 15 (.split 2 (.split 3 (.split 0 (.tip (.small 1)) (.tip (.cover {0,3,6,8,9,10}))) (.tip (.cover {0,3,6,8,9,10}))) (.split 9 (.split 0 (.tip (.small 1)) (.tip (.cover {0,2,6,8,9,10}))) (.tip (.cover {0,5,6,8,9,10})))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,2,3,4,6,9})))
private theorem q11Shape29T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67371008 34290536448 q11Shape29T95=true := by decide

private def q11Shape29T87 : Tree 11 := .split 18 q11Shape29T88 q11Shape29T95
private theorem q11Shape29T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 34290536448 q11Shape29T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (34290536448 ||| 2^18) q11Shape29T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^18) 34290536448 q11Shape29T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T88OK,q11Shape29T95OK⟩

private def q11Shape29T99 : Tree 11 := (.split 2 (.split 3 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover {0,4,6,8,9,10})))) (.tip (.cover {0,4,6,8,9,10}))) (.split 15 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover {0,2,6,8,9,10})))) (.tip (.cover {0,5,6,8,9,10}))))
private theorem q11Shape29T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112960 34290795040 q11Shape29T99=true := by decide

private def q11Shape29T100 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape29T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67113472 34290794528 q11Shape29T100=true := by decide

private def q11Shape29T98 : Tree 11 := .split 9 q11Shape29T99 q11Shape29T100
private theorem q11Shape29T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112960 34290794528 q11Shape29T98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112960 (34290794528 ||| 2^9) q11Shape29T99 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67112960 ||| 2^9) 34290794528 q11Shape29T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T99OK,q11Shape29T100OK⟩

private def q11Shape29T101 : Tree 11 := (.tip (.cover {0,2,3,4,6,9}))
private theorem q11Shape29T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112992 34290794496 q11Shape29T101=true := by decide

private def q11Shape29T97 : Tree 11 := .split 5 q11Shape29T98 q11Shape29T101
private theorem q11Shape29T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112960 34290794496 q11Shape29T97=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112960 (34290794496 ||| 2^5) q11Shape29T98 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67112960 ||| 2^5) 34290794496 q11Shape29T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T98OK,q11Shape29T101OK⟩

private def q11Shape29T102 : Tree 11 := (.tip (.cover {0,2,3,4,6,9}))
private theorem q11Shape29T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67375104 34290532352 q11Shape29T102=true := by decide

private def q11Shape29T96 : Tree 11 := .split 18 q11Shape29T97 q11Shape29T102
private theorem q11Shape29T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112960 34290532352 q11Shape29T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67112960 (34290532352 ||| 2^18) q11Shape29T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67112960 ||| 2^18) 34290532352 q11Shape29T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T97OK,q11Shape29T102OK⟩

private def q11Shape29T86 : Tree 11 := .split 12 q11Shape29T87 q11Shape29T96
private theorem q11Shape29T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 34290532352 q11Shape29T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (34290532352 ||| 2^12) q11Shape29T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^12) 34290532352 q11Shape29T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T87OK,q11Shape29T96OK⟩

private def q11Shape29T106 : Tree 11 := (.split 18 (.split 5 (.tip (.small 1)) (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,9})))) (.split 5 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,10}))))
private theorem q11Shape29T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979776 33753667600 q11Shape29T106=true := by decide

private def q11Shape29T107 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {2,3,4,5,7,10}))) (.tip (.cover {2,3,4,5,7,10})))
private theorem q11Shape29T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603983872 33753663504 q11Shape29T107=true := by decide

private def q11Shape29T105 : Tree 11 := .split 12 q11Shape29T106 q11Shape29T107
private theorem q11Shape29T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979776 33753663504 q11Shape29T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979776 (33753663504 ||| 2^12) q11Shape29T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (603979776 ||| 2^12) 33753663504 q11Shape29T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T106OK,q11Shape29T107OK⟩

private def q11Shape29T108 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603981824 33753661456 q11Shape29T108=true := by decide

private def q11Shape29T104 : Tree 11 := .split 11 q11Shape29T105 q11Shape29T108
private theorem q11Shape29T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979776 33753661456 q11Shape29T104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979776 (33753661456 ||| 2^11) q11Shape29T105 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (603979776 ||| 2^11) 33753661456 q11Shape29T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T105OK,q11Shape29T108OK⟩

private def q11Shape29T109 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979792 33753661440 q11Shape29T109=true := by decide

private def q11Shape29T103 : Tree 11 := .split 4 q11Shape29T104 q11Shape29T109
private theorem q11Shape29T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979776 33753661440 q11Shape29T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 603979776 (33753661440 ||| 2^4) q11Shape29T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (603979776 ||| 2^4) 33753661440 q11Shape29T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T104OK,q11Shape29T109OK⟩

private def q11Shape29T85 : Tree 11 := .split 29 q11Shape29T86 q11Shape29T103
private theorem q11Shape29T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 33753661440 q11Shape29T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (33753661440 ||| 2^29) q11Shape29T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^29) 33753661440 q11Shape29T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T86OK,q11Shape29T103OK⟩

private def q11Shape29T114 : Tree 11 := (.split 18 (.split 5 (.tip (.small 1)) (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,10})))) (.split 5 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {2,3,4,5,7,9}))))
private theorem q11Shape29T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 34022103056 q11Shape29T114=true := by decide

private def q11Shape29T115 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {2,3,4,5,7,9}))) (.tip (.cover {2,3,4,5,7,9})))
private theorem q11Shape29T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335548416 34022098960 q11Shape29T115=true := by decide

private def q11Shape29T113 : Tree 11 := .split 12 q11Shape29T114 q11Shape29T115
private theorem q11Shape29T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 34022098960 q11Shape29T113=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 (34022098960 ||| 2^12) q11Shape29T114 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (335544320 ||| 2^12) 34022098960 q11Shape29T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T114OK,q11Shape29T115OK⟩

private def q11Shape29T116 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335546368 34022096912 q11Shape29T116=true := by decide

private def q11Shape29T112 : Tree 11 := .split 11 q11Shape29T113 q11Shape29T116
private theorem q11Shape29T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 34022096912 q11Shape29T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 (34022096912 ||| 2^11) q11Shape29T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (335544320 ||| 2^11) 34022096912 q11Shape29T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T113OK,q11Shape29T116OK⟩

private def q11Shape29T117 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544336 34022096896 q11Shape29T117=true := by decide

private def q11Shape29T111 : Tree 11 := .split 4 q11Shape29T112 q11Shape29T117
private theorem q11Shape29T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 34022096896 q11Shape29T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 (34022096896 ||| 2^4) q11Shape29T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (335544320 ||| 2^4) 34022096896 q11Shape29T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T112OK,q11Shape29T117OK⟩

private def q11Shape29T120 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 2 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10}))))
private theorem q11Shape29T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 872415232 33485492224 q11Shape29T120=true := by decide

private def q11Shape29T121 : Tree 11 := (.split 5 (.split 15 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,2,3,4,6,9})))
private theorem q11Shape29T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 872677376 33485230080 q11Shape29T121=true := by decide

private def q11Shape29T119 : Tree 11 := .split 18 q11Shape29T120 q11Shape29T121
private theorem q11Shape29T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 872415232 33485230080 q11Shape29T119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 872415232 (33485230080 ||| 2^18) q11Shape29T120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (872415232 ||| 2^18) 33485230080 q11Shape29T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T120OK,q11Shape29T121OK⟩

private def q11Shape29T122 : Tree 11 := (.split 18 (.split 5 (.split 9 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,2,3,4,6,9}))) (.tip (.cover {0,2,3,4,6,9})))
private theorem q11Shape29T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 872419328 33485225984 q11Shape29T122=true := by decide

private def q11Shape29T118 : Tree 11 := .split 12 q11Shape29T119 q11Shape29T122
private theorem q11Shape29T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 872415232 33485225984 q11Shape29T118=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 872415232 (33485225984 ||| 2^12) q11Shape29T119 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (872415232 ||| 2^12) 33485225984 q11Shape29T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T119OK,q11Shape29T122OK⟩

private def q11Shape29T110 : Tree 11 := .split 29 q11Shape29T111 q11Shape29T118
private theorem q11Shape29T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 33485225984 q11Shape29T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 335544320 (33485225984 ||| 2^29) q11Shape29T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (335544320 ||| 2^29) 33485225984 q11Shape29T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T111OK,q11Shape29T118OK⟩

private def q11Shape29T84 : Tree 11 := .split 28 q11Shape29T85 q11Shape29T110
private theorem q11Shape29T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 33485225984 q11Shape29T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (33485225984 ||| 2^28) q11Shape29T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^28) 33485225984 q11Shape29T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T85OK,q11Shape29T110OK⟩

private def q11Shape29T128 : Tree 11 := (.split 16 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9})))) (.tip (.cover {0,2,3,4,8,10})))
private theorem q11Shape29T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 29995570184 q11Shape29T128=true := by decide

private def q11Shape29T129 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {2,3,4,5,6,10}))) (.tip (.cover {2,3,4,5,6,10})))
private theorem q11Shape29T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362080256 29995566088 q11Shape29T129=true := by decide

private def q11Shape29T127 : Tree 11 := .split 12 q11Shape29T128 q11Shape29T129
private theorem q11Shape29T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 29995566088 q11Shape29T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 (29995566088 ||| 2^12) q11Shape29T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4362076160 ||| 2^12) 29995566088 q11Shape29T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T128OK,q11Shape29T129OK⟩

private def q11Shape29T130 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362077184 29995565064 q11Shape29T130=true := by decide

private def q11Shape29T126 : Tree 11 := .split 10 q11Shape29T127 q11Shape29T130
private theorem q11Shape29T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 29995565064 q11Shape29T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 (29995565064 ||| 2^10) q11Shape29T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4362076160 ||| 2^10) 29995565064 q11Shape29T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T127OK,q11Shape29T130OK⟩

private def q11Shape29T131 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076168 29995565056 q11Shape29T131=true := by decide

private def q11Shape29T125 : Tree 11 := .split 3 q11Shape29T126 q11Shape29T131
private theorem q11Shape29T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 29995565056 q11Shape29T125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 (29995565056 ||| 2^3) q11Shape29T126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4362076160 ||| 2^3) 29995565056 q11Shape29T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T126OK,q11Shape29T131OK⟩

private def q11Shape29T132 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4898947072 29458694144 q11Shape29T132=true := by decide

private def q11Shape29T124 : Tree 11 := .split 29 q11Shape29T125 q11Shape29T132
private theorem q11Shape29T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 29458694144 q11Shape29T124=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 (29458694144 ||| 2^29) q11Shape29T125 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4362076160 ||| 2^29) 29458694144 q11Shape29T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T125OK,q11Shape29T132OK⟩

private def q11Shape29T133 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4630511616 29190258688 q11Shape29T133=true := by decide

private def q11Shape29T123 : Tree 11 := .split 28 q11Shape29T124 q11Shape29T133
private theorem q11Shape29T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 29190258688 q11Shape29T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4362076160 (29190258688 ||| 2^28) q11Shape29T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4362076160 ||| 2^28) 29190258688 q11Shape29T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T124OK,q11Shape29T133OK⟩

private def q11Shape29T83 : Tree 11 := .split 32 q11Shape29T84 q11Shape29T123
private theorem q11Shape29T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 29190258688 q11Shape29T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 (29190258688 ||| 2^32) q11Shape29T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (67108864 ||| 2^32) 29190258688 q11Shape29T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T84OK,q11Shape29T123OK⟩

def q11Shape29P2 : Tree 11 := q11Shape29T83
theorem q11Shape29P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 67108864 29190258688 q11Shape29P2=true := q11Shape29T83OK

end Graffiti384b.EffectiveSearch.Q11
