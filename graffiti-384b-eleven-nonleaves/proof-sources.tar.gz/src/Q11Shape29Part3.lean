import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T140 : Tree 11 := (.split 16 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,2,3,4,8,9})))
private theorem q11Shape29T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 32143053832 q11Shape29T140=true := by decide

private def q11Shape29T141 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,5,6,9}))) (.tip (.cover {2,3,4,5,6,9})))
private theorem q11Shape29T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214596608 32143049736 q11Shape29T141=true := by decide

private def q11Shape29T139 : Tree 11 := .split 12 q11Shape29T140 q11Shape29T141
private theorem q11Shape29T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 32143049736 q11Shape29T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 (32143049736 ||| 2^12) q11Shape29T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2214592512 ||| 2^12) 32143049736 q11Shape29T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T140OK,q11Shape29T141OK⟩

private def q11Shape29T142 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214593536 32143048712 q11Shape29T142=true := by decide

private def q11Shape29T138 : Tree 11 := .split 10 q11Shape29T139 q11Shape29T142
private theorem q11Shape29T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 32143048712 q11Shape29T138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 (32143048712 ||| 2^10) q11Shape29T139 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2214592512 ||| 2^10) 32143048712 q11Shape29T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T139OK,q11Shape29T142OK⟩

private def q11Shape29T143 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592520 32143048704 q11Shape29T143=true := by decide

private def q11Shape29T137 : Tree 11 := .split 3 q11Shape29T138 q11Shape29T143
private theorem q11Shape29T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 32143048704 q11Shape29T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 (32143048704 ||| 2^3) q11Shape29T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2214592512 ||| 2^3) 32143048704 q11Shape29T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T138OK,q11Shape29T143OK⟩

private def q11Shape29T146 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 2 (.split 3 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10}))))
private theorem q11Shape29T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6509559808 27848347648 q11Shape29T146=true := by decide

private def q11Shape29T147 : Tree 11 := (.split 5 (.split 15 (.split 3 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,2,3,4,7,9})))
private theorem q11Shape29T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6509821952 27848085504 q11Shape29T147=true := by decide

private def q11Shape29T145 : Tree 11 := .split 18 q11Shape29T146 q11Shape29T147
private theorem q11Shape29T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6509559808 27848085504 q11Shape29T145=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6509559808 (27848085504 ||| 2^18) q11Shape29T146 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (6509559808 ||| 2^18) 27848085504 q11Shape29T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T146OK,q11Shape29T147OK⟩

private def q11Shape29T148 : Tree 11 := (.split 18 (.split 5 (.split 9 (.split 3 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,2,3,4,7,9}))) (.tip (.cover {0,2,3,4,7,9})))
private theorem q11Shape29T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6509563904 27848081408 q11Shape29T148=true := by decide

private def q11Shape29T144 : Tree 11 := .split 12 q11Shape29T145 q11Shape29T148
private theorem q11Shape29T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6509559808 27848081408 q11Shape29T144=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6509559808 (27848081408 ||| 2^12) q11Shape29T145 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (6509559808 ||| 2^12) 27848081408 q11Shape29T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T145OK,q11Shape29T148OK⟩

private def q11Shape29T136 : Tree 11 := .split 32 q11Shape29T137 q11Shape29T144
private theorem q11Shape29T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 27848081408 q11Shape29T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 (27848081408 ||| 2^32) q11Shape29T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2214592512 ||| 2^32) 27848081408 q11Shape29T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T137OK,q11Shape29T144OK⟩

private def q11Shape29T149 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2751463424 27311210496 q11Shape29T149=true := by decide

private def q11Shape29T135 : Tree 11 := .split 29 q11Shape29T136 q11Shape29T149
private theorem q11Shape29T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 27311210496 q11Shape29T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 (27311210496 ||| 2^29) q11Shape29T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2214592512 ||| 2^29) 27311210496 q11Shape29T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T136OK,q11Shape29T149OK⟩

private def q11Shape29T150 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2483027968 27042775040 q11Shape29T150=true := by decide

private def q11Shape29T134 : Tree 11 := .split 28 q11Shape29T135 q11Shape29T150
private theorem q11Shape29T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 27042775040 q11Shape29T134=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 (27042775040 ||| 2^28) q11Shape29T135 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2214592512 ||| 2^28) 27042775040 q11Shape29T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T135OK,q11Shape29T150OK⟩

def q11Shape29P3 : Tree 11 := q11Shape29T134
theorem q11Shape29P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2214592512 27042775040 q11Shape29P3=true := q11Shape29T134OK

private def q11Shape29T152 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17246978048 9862905856 q11Shape29T152=true := by decide

def q11Shape29P4 : Tree 11 := q11Shape29T152
theorem q11Shape29P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17246978048 9862905856 q11Shape29P4=true := q11Shape29T152OK

private def q11Shape29T154 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8657043456 1272971264 q11Shape29T154=true := by decide

def q11Shape29P5 : Tree 11 := q11Shape29T154
theorem q11Shape29P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8657043456 1272971264 q11Shape29P5=true := q11Shape29T154OK

private def q11Shape29T156 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 100663296 1239416832 q11Shape29T156=true := by decide

def q11Shape29P6 : Tree 11 := q11Shape29T156
theorem q11Shape29P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 100663296 1239416832 q11Shape29P6=true := q11Shape29T156OK

private def q11Shape29T158 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 83886080 1222639616 q11Shape29T158=true := by decide

def q11Shape29P7 : Tree 11 := q11Shape29T158
theorem q11Shape29P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 83886080 1222639616 q11Shape29P7=true := q11Shape29T158OK

private def q11Shape29T160 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 75497472 1214251008 q11Shape29T160=true := by decide

def q11Shape29P8 : Tree 11 := q11Shape29T160
theorem q11Shape29P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 75497472 1214251008 q11Shape29P8=true := q11Shape29T160OK

private def q11Shape29T162 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1140850688 140509184 q11Shape29T162=true := by decide

def q11Shape29P9 : Tree 11 := q11Shape29T162
theorem q11Shape29P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1140850688 140509184 q11Shape29P9=true := q11Shape29T162OK

private def q11Shape29T164 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 201326592 6291456 q11Shape29T164=true := by decide

def q11Shape29P10 : Tree 11 := q11Shape29T164
theorem q11Shape29P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 201326592 6291456 q11Shape29P10=true := q11Shape29T164OK

end Graffiti384b.EffectiveSearch.Q11
