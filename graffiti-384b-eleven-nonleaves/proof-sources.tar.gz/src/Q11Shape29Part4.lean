import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T173 : Tree 11 := (.tip (.small 1))
private theorem q11Shape29T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 34353713184 q11Shape29T173=true := by decide

private def q11Shape29T176 : Tree 11 := (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 10 (.tip (.cover {0,4,5,8,9,10})) (.tip (.cover {0,3,5,8,9,10})))))))
private theorem q11Shape29T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194336 34353713164 q11Shape29T176=true := by decide

private def q11Shape29T177 : Tree 11 := (.split 4 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape29T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194340 34353713160 q11Shape29T177=true := by decide

private def q11Shape29T175 : Tree 11 := .split 2 q11Shape29T176 q11Shape29T177
private theorem q11Shape29T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194336 34353713160 q11Shape29T175=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194336 (34353713160 ||| 2^2) q11Shape29T176 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194336 ||| 2^2) 34353713160 q11Shape29T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T176OK,q11Shape29T177OK⟩

private def q11Shape29T178 : Tree 11 := (.tip (.cover {0,1,2,5,9,10}))
private theorem q11Shape29T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194344 34353713152 q11Shape29T178=true := by decide

private def q11Shape29T174 : Tree 11 := .split 3 q11Shape29T175 q11Shape29T178
private theorem q11Shape29T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194336 34353713152 q11Shape29T174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194336 (34353713152 ||| 2^3) q11Shape29T175 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194336 ||| 2^3) 34353713152 q11Shape29T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T175OK,q11Shape29T178OK⟩

private def q11Shape29T172 : Tree 11 := .split 5 q11Shape29T173 q11Shape29T174
private theorem q11Shape29T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 34353713152 q11Shape29T172=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (34353713152 ||| 2^5) q11Shape29T173 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^5) 34353713152 q11Shape29T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T173OK,q11Shape29T174OK⟩

private def q11Shape29T180 : Tree 11 := (.split 16 (.split 2 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,5,8,9,10}))))) (.split 3 (.tip (.cover {0,3,5,8,9,10})) (.split 0 (.tip (.small 1)) (.tip (.cover {0,2,5,8,9,10}))))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape29T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4456448 34353451040 q11Shape29T180=true := by decide

private def q11Shape29T181 : Tree 11 := (.tip (.cover {0,2,3,4,5,9}))
private theorem q11Shape29T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4456480 34353451008 q11Shape29T181=true := by decide

private def q11Shape29T179 : Tree 11 := .split 5 q11Shape29T180 q11Shape29T181
private theorem q11Shape29T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4456448 34353451008 q11Shape29T179=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4456448 (34353451008 ||| 2^5) q11Shape29T180 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4456448 ||| 2^5) 34353451008 q11Shape29T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T180OK,q11Shape29T181OK⟩

private def q11Shape29T171 : Tree 11 := .split 18 q11Shape29T172 q11Shape29T179
private theorem q11Shape29T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 34353451008 q11Shape29T171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (34353451008 ||| 2^18) q11Shape29T172 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^18) 34353451008 q11Shape29T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T172OK,q11Shape29T179OK⟩

private def q11Shape29T186 : Tree 11 := (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 3 (.tip (.cover {0,4,5,8,9,10})) (.tip (.cover {0,2,5,8,9,10}))))))
private theorem q11Shape29T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 34353710116 q11Shape29T186=true := by decide

private def q11Shape29T187 : Tree 11 := (.split 3 (.tip (.cover {0,4,5,8,9,10})) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover {0,2,5,8,9,10})))))
private theorem q11Shape29T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198404 34353710112 q11Shape29T187=true := by decide

private def q11Shape29T185 : Tree 11 := .split 2 q11Shape29T186 q11Shape29T187
private theorem q11Shape29T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 34353710112 q11Shape29T185=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 (34353710112 ||| 2^2) q11Shape29T186 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4198400 ||| 2^2) 34353710112 q11Shape29T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T186OK,q11Shape29T187OK⟩

private def q11Shape29T188 : Tree 11 := (.tip (.cover {0,1,3,5,9,10}))
private theorem q11Shape29T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4199424 34353709088 q11Shape29T188=true := by decide

private def q11Shape29T184 : Tree 11 := .split 10 q11Shape29T185 q11Shape29T188
private theorem q11Shape29T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 34353709088 q11Shape29T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 (34353709088 ||| 2^10) q11Shape29T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4198400 ||| 2^10) 34353709088 q11Shape29T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T185OK,q11Shape29T188OK⟩

private def q11Shape29T189 : Tree 11 := (.tip (.cover {0,2,3,4,5,9}))
private theorem q11Shape29T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198432 34353709056 q11Shape29T189=true := by decide

private def q11Shape29T183 : Tree 11 := .split 5 q11Shape29T184 q11Shape29T189
private theorem q11Shape29T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 34353709056 q11Shape29T183=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 (34353709056 ||| 2^5) q11Shape29T184 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4198400 ||| 2^5) 34353709056 q11Shape29T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T184OK,q11Shape29T189OK⟩

private def q11Shape29T190 : Tree 11 := (.tip (.cover {0,2,3,4,5,9}))
private theorem q11Shape29T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4460544 34353446912 q11Shape29T190=true := by decide

private def q11Shape29T182 : Tree 11 := .split 18 q11Shape29T183 q11Shape29T190
private theorem q11Shape29T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 34353446912 q11Shape29T182=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4198400 (34353446912 ||| 2^18) q11Shape29T183 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4198400 ||| 2^18) 34353446912 q11Shape29T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T183OK,q11Shape29T190OK⟩

private def q11Shape29T170 : Tree 11 := .split 12 q11Shape29T171 q11Shape29T182
private theorem q11Shape29T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 34353446912 q11Shape29T170=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (34353446912 ||| 2^12) q11Shape29T171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^12) 34353446912 q11Shape29T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T171OK,q11Shape29T182OK⟩

private def q11Shape29T194 : Tree 11 := (.split 18 (.split 5 (.tip (.small 1)) (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,9})))) (.split 5 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {2,3,4,6,7,10}))))
private theorem q11Shape29T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748736 34319898640 q11Shape29T194=true := by decide

private def q11Shape29T195 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape29T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37752832 34319894544 q11Shape29T195=true := by decide

private def q11Shape29T193 : Tree 11 := .split 12 q11Shape29T194 q11Shape29T195
private theorem q11Shape29T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748736 34319894544 q11Shape29T193=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748736 (34319894544 ||| 2^12) q11Shape29T194 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (37748736 ||| 2^12) 34319894544 q11Shape29T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T194OK,q11Shape29T195OK⟩

private def q11Shape29T196 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37750784 34319892496 q11Shape29T196=true := by decide

private def q11Shape29T192 : Tree 11 := .split 11 q11Shape29T193 q11Shape29T196
private theorem q11Shape29T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748736 34319892496 q11Shape29T192=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748736 (34319892496 ||| 2^11) q11Shape29T193 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (37748736 ||| 2^11) 34319892496 q11Shape29T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T193OK,q11Shape29T196OK⟩

private def q11Shape29T197 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748752 34319892480 q11Shape29T197=true := by decide

private def q11Shape29T191 : Tree 11 := .split 4 q11Shape29T192 q11Shape29T197
private theorem q11Shape29T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748736 34319892480 q11Shape29T191=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 37748736 (34319892480 ||| 2^4) q11Shape29T192 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (37748736 ||| 2^4) 34319892480 q11Shape29T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T192OK,q11Shape29T197OK⟩

private def q11Shape29T169 : Tree 11 := .split 25 q11Shape29T170 q11Shape29T191
private theorem q11Shape29T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 34319892480 q11Shape29T169=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (34319892480 ||| 2^25) q11Shape29T170 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^25) 34319892480 q11Shape29T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T170OK,q11Shape29T191OK⟩

private def q11Shape29T202 : Tree 11 := (.split 18 (.split 5 (.tip (.small 1)) (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,10})))) (.split 5 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {2,3,4,6,7,9}))))
private theorem q11Shape29T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 34336675856 q11Shape29T202=true := by decide

private def q11Shape29T203 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape29T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20975616 34336671760 q11Shape29T203=true := by decide

private def q11Shape29T201 : Tree 11 := .split 12 q11Shape29T202 q11Shape29T203
private theorem q11Shape29T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 34336671760 q11Shape29T201=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 (34336671760 ||| 2^12) q11Shape29T202 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (20971520 ||| 2^12) 34336671760 q11Shape29T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T202OK,q11Shape29T203OK⟩

private def q11Shape29T204 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20973568 34336669712 q11Shape29T204=true := by decide

private def q11Shape29T200 : Tree 11 := .split 11 q11Shape29T201 q11Shape29T204
private theorem q11Shape29T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 34336669712 q11Shape29T200=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 (34336669712 ||| 2^11) q11Shape29T201 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (20971520 ||| 2^11) 34336669712 q11Shape29T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T201OK,q11Shape29T204OK⟩

private def q11Shape29T205 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971536 34336669696 q11Shape29T205=true := by decide

private def q11Shape29T199 : Tree 11 := .split 4 q11Shape29T200 q11Shape29T205
private theorem q11Shape29T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 34336669696 q11Shape29T199=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 (34336669696 ||| 2^4) q11Shape29T200 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (20971520 ||| 2^4) 34336669696 q11Shape29T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T200OK,q11Shape29T205OK⟩

private def q11Shape29T208 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 3 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,2,6,9,10}))) (.tip (.cover {0,1,2,5,9,10}))))
private theorem q11Shape29T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 54525952 34303381504 q11Shape29T208=true := by decide

private def q11Shape29T209 : Tree 11 := (.split 5 (.split 16 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,2,3,4,5,9})))
private theorem q11Shape29T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 54788096 34303119360 q11Shape29T209=true := by decide

private def q11Shape29T207 : Tree 11 := .split 18 q11Shape29T208 q11Shape29T209
private theorem q11Shape29T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 54525952 34303119360 q11Shape29T207=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 54525952 (34303119360 ||| 2^18) q11Shape29T208 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (54525952 ||| 2^18) 34303119360 q11Shape29T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T208OK,q11Shape29T209OK⟩

private def q11Shape29T210 : Tree 11 := (.split 18 (.split 5 (.split 10 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,2,4,8,9,10}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,2,3,4,5,9}))) (.tip (.cover {0,2,3,4,5,9})))
private theorem q11Shape29T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 54530048 34303115264 q11Shape29T210=true := by decide

private def q11Shape29T206 : Tree 11 := .split 12 q11Shape29T207 q11Shape29T210
private theorem q11Shape29T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 54525952 34303115264 q11Shape29T206=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 54525952 (34303115264 ||| 2^12) q11Shape29T207 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (54525952 ||| 2^12) 34303115264 q11Shape29T210)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T207OK,q11Shape29T210OK⟩

private def q11Shape29T198 : Tree 11 := .split 25 q11Shape29T199 q11Shape29T206
private theorem q11Shape29T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 34303115264 q11Shape29T198=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 20971520 (34303115264 ||| 2^25) q11Shape29T199 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (20971520 ||| 2^25) 34303115264 q11Shape29T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T199OK,q11Shape29T206OK⟩

private def q11Shape29T168 : Tree 11 := .split 24 q11Shape29T169 q11Shape29T198
private theorem q11Shape29T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 34303115264 q11Shape29T168=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (34303115264 ||| 2^24) q11Shape29T169 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^24) 34303115264 q11Shape29T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T169OK,q11Shape29T198OK⟩

private def q11Shape29T215 : Tree 11 := (.split 15 (.split 12 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9})))) (.split 18 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {2,3,4,5,6,10})))) (.tip (.cover {0,2,3,4,8,10})))
private theorem q11Shape29T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 30058480132 q11Shape29T215=true := by decide

private def q11Shape29T216 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299162112 30058479620 q11Shape29T216=true := by decide

private def q11Shape29T214 : Tree 11 := .split 9 q11Shape29T215 q11Shape29T216
private theorem q11Shape29T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 30058479620 q11Shape29T214=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 (30058479620 ||| 2^9) q11Shape29T215 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4299161600 ||| 2^9) 30058479620 q11Shape29T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T215OK,q11Shape29T216OK⟩

private def q11Shape29T217 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161604 30058479616 q11Shape29T217=true := by decide

private def q11Shape29T213 : Tree 11 := .split 2 q11Shape29T214 q11Shape29T217
private theorem q11Shape29T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 30058479616 q11Shape29T213=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 (30058479616 ||| 2^2) q11Shape29T214 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4299161600 ||| 2^2) 30058479616 q11Shape29T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T214OK,q11Shape29T217OK⟩

private def q11Shape29T218 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4332716032 30024925184 q11Shape29T218=true := by decide

private def q11Shape29T212 : Tree 11 := .split 25 q11Shape29T213 q11Shape29T218
private theorem q11Shape29T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 30024925184 q11Shape29T212=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 (30024925184 ||| 2^25) q11Shape29T213 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4299161600 ||| 2^25) 30024925184 q11Shape29T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T213OK,q11Shape29T218OK⟩

private def q11Shape29T219 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4315938816 30008147968 q11Shape29T219=true := by decide

private def q11Shape29T211 : Tree 11 := .split 24 q11Shape29T212 q11Shape29T219
private theorem q11Shape29T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 30008147968 q11Shape29T211=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4299161600 (30008147968 ||| 2^24) q11Shape29T212 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4299161600 ||| 2^24) 30008147968 q11Shape29T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T212OK,q11Shape29T219OK⟩

private def q11Shape29T167 : Tree 11 := .split 32 q11Shape29T168 q11Shape29T211
private theorem q11Shape29T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 30008147968 q11Shape29T167=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 (30008147968 ||| 2^32) q11Shape29T168 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (4194304 ||| 2^32) 30008147968 q11Shape29T211)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T168OK,q11Shape29T211OK⟩

def q11Shape29P11 : Tree 11 := q11Shape29T167
theorem q11Shape29P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4194304 30008147968 q11Shape29P11=true := q11Shape29T167OK

end Graffiti384b.EffectiveSearch.Q11
