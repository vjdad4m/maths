import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T225 : Tree 11 := (.split 15 (.split 12 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10})))) (.split 18 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {2,3,4,5,6,9})))) (.tip (.cover {0,2,3,4,8,9})))
private theorem q11Shape29T225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 32205963780 q11Shape29T225=true := by decide

private def q11Shape29T226 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151678464 32205963268 q11Shape29T226=true := by decide

private def q11Shape29T224 : Tree 11 := .split 9 q11Shape29T225 q11Shape29T226
private theorem q11Shape29T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 32205963268 q11Shape29T224=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 (32205963268 ||| 2^9) q11Shape29T225 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2151677952 ||| 2^9) 32205963268 q11Shape29T226)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T225OK,q11Shape29T226OK⟩

private def q11Shape29T227 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677956 32205963264 q11Shape29T227=true := by decide

private def q11Shape29T223 : Tree 11 := .split 2 q11Shape29T224 q11Shape29T227
private theorem q11Shape29T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 32205963264 q11Shape29T223=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 (32205963264 ||| 2^2) q11Shape29T224 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2151677952 ||| 2^2) 32205963264 q11Shape29T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T224OK,q11Shape29T227OK⟩

private def q11Shape29T230 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 2 (.split 3 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,6,9,10}))))
private theorem q11Shape29T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6446645248 27911262208 q11Shape29T230=true := by decide

private def q11Shape29T231 : Tree 11 := (.split 5 (.split 15 (.split 16 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,2,3,4,7,9})))
private theorem q11Shape29T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6446907392 27911000064 q11Shape29T231=true := by decide

private def q11Shape29T229 : Tree 11 := .split 18 q11Shape29T230 q11Shape29T231
private theorem q11Shape29T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6446645248 27911000064 q11Shape29T229=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6446645248 (27911000064 ||| 2^18) q11Shape29T230 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (6446645248 ||| 2^18) 27911000064 q11Shape29T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T230OK,q11Shape29T231OK⟩

private def q11Shape29T232 : Tree 11 := (.split 18 (.split 5 (.split 9 (.split 10 (.split 35 (.tip (.cover {0,2,3,4,7,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,6,9,10}))) (.tip (.cover {0,2,3,4,7,9}))) (.tip (.cover {0,2,3,4,7,9})))
private theorem q11Shape29T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6446649344 27910995968 q11Shape29T232=true := by decide

private def q11Shape29T228 : Tree 11 := .split 12 q11Shape29T229 q11Shape29T232
private theorem q11Shape29T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6446645248 27910995968 q11Shape29T228=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6446645248 (27910995968 ||| 2^12) q11Shape29T229 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (6446645248 ||| 2^12) 27910995968 q11Shape29T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T229OK,q11Shape29T232OK⟩

private def q11Shape29T222 : Tree 11 := .split 32 q11Shape29T223 q11Shape29T228
private theorem q11Shape29T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 27910995968 q11Shape29T222=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 (27910995968 ||| 2^32) q11Shape29T223 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2151677952 ||| 2^32) 27910995968 q11Shape29T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T223OK,q11Shape29T228OK⟩

private def q11Shape29T233 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2185232384 27877441536 q11Shape29T233=true := by decide

private def q11Shape29T221 : Tree 11 := .split 25 q11Shape29T222 q11Shape29T233
private theorem q11Shape29T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 27877441536 q11Shape29T221=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 (27877441536 ||| 2^25) q11Shape29T222 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2151677952 ||| 2^25) 27877441536 q11Shape29T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T222OK,q11Shape29T233OK⟩

private def q11Shape29T234 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2168455168 27860664320 q11Shape29T234=true := by decide

private def q11Shape29T220 : Tree 11 := .split 24 q11Shape29T221 q11Shape29T234
private theorem q11Shape29T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 27860664320 q11Shape29T220=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 (27860664320 ||| 2^24) q11Shape29T221 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2151677952 ||| 2^24) 27860664320 q11Shape29T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T221OK,q11Shape29T234OK⟩

def q11Shape29P12 : Tree 11 := q11Shape29T220
theorem q11Shape29P12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2151677952 27860664320 q11Shape29P12=true := q11Shape29T220OK

private def q11Shape29T236 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17184063488 10680795136 q11Shape29T236=true := by decide

def q11Shape29P13 : Tree 11 := q11Shape29T236
theorem q11Shape29P13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17184063488 10680795136 q11Shape29P13=true := q11Shape29T236OK

private def q11Shape29T238 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8594128896 2090860544 q11Shape29T238=true := by decide

def q11Shape29P14 : Tree 11 := q11Shape29T238
theorem q11Shape29P14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8594128896 2090860544 q11Shape29P14=true := q11Shape29T238OK

private def q11Shape29T240 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 541065216 1553989632 q11Shape29T240=true := by decide

def q11Shape29P15 : Tree 11 := q11Shape29T240
theorem q11Shape29P15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 541065216 1553989632 q11Shape29P15=true := q11Shape29T240OK

private def q11Shape29T242 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 272629760 1285554176 q11Shape29T242=true := by decide

def q11Shape29P16 : Tree 11 := q11Shape29T242
theorem q11Shape29P16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 272629760 1285554176 q11Shape29P16=true := q11Shape29T242OK

private def q11Shape29T244 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 12582912 1277165568 q11Shape29T244=true := by decide

def q11Shape29P17 : Tree 11 := q11Shape29T244
theorem q11Shape29P17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 12582912 1277165568 q11Shape29P17=true := q11Shape29T244OK

private def q11Shape29T246 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1077936128 203423744 q11Shape29T246=true := by decide

def q11Shape29P18 : Tree 11 := q11Shape29T246
theorem q11Shape29P18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1077936128 203423744 q11Shape29P18=true := q11Shape29T246OK

private def q11Shape29T248 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape29T248OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 138412032 69206016 q11Shape29T248=true := by decide

def q11Shape29P19 : Tree 11 := q11Shape29T248
theorem q11Shape29P19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 138412032 69206016 q11Shape29P19=true := q11Shape29T248OK

private def q11Shape29T250 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T250OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 71303168 2097152 q11Shape29T250=true := by decide

def q11Shape29P20 : Tree 11 := q11Shape29T250
theorem q11Shape29P20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 71303168 2097152 q11Shape29P20=true := q11Shape29T250OK

end Graffiti384b.EffectiveSearch.Q11
