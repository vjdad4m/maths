import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T259 : Tree 11 := (.tip (.small 1))
private theorem q11Shape29T259OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 34355810336 q11Shape29T259=true := by decide

private def q11Shape29T262 : Tree 11 := (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 11 (.tip (.cover {0,4,5,8,9,10})) (.tip (.cover {0,3,5,8,9,10})))))))
private theorem q11Shape29T262OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097184 34355810324 q11Shape29T262=true := by decide

private def q11Shape29T263 : Tree 11 := (.split 3 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape29T263OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097188 34355810320 q11Shape29T263=true := by decide

private def q11Shape29T261 : Tree 11 := .split 2 q11Shape29T262 q11Shape29T263
private theorem q11Shape29T261OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097184 34355810320 q11Shape29T261=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097184 (34355810320 ||| 2^2) q11Shape29T262 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097184 ||| 2^2) 34355810320 q11Shape29T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T262OK,q11Shape29T263OK⟩

private def q11Shape29T264 : Tree 11 := (.tip (.cover {0,1,2,5,9,10}))
private theorem q11Shape29T264OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097200 34355810304 q11Shape29T264=true := by decide

private def q11Shape29T260 : Tree 11 := .split 4 q11Shape29T261 q11Shape29T264
private theorem q11Shape29T260OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097184 34355810304 q11Shape29T260=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097184 (34355810304 ||| 2^4) q11Shape29T261 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097184 ||| 2^4) 34355810304 q11Shape29T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T261OK,q11Shape29T264OK⟩

private def q11Shape29T258 : Tree 11 := .split 5 q11Shape29T259 q11Shape29T260
private theorem q11Shape29T258OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 34355810304 q11Shape29T258=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (34355810304 ||| 2^5) q11Shape29T259 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^5) 34355810304 q11Shape29T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T259OK,q11Shape29T260OK⟩

private def q11Shape29T267 : Tree 11 := (.split 17 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.split 0 (.tip (.small 1)) (.split 4 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,5,8,9,10}))))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape29T267OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2359296 34355548196 q11Shape29T267=true := by decide

private def q11Shape29T268 : Tree 11 := (.split 3 (.split 9 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.cover {2,4,6,7,8,10})) (.tip (.cover {2,6,7,8,9,10})))))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,2,3,4,8,9})))
private theorem q11Shape29T268OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2359300 34355548192 q11Shape29T268=true := by decide

private def q11Shape29T266 : Tree 11 := .split 2 q11Shape29T267 q11Shape29T268
private theorem q11Shape29T266OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2359296 34355548192 q11Shape29T266=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2359296 (34355548192 ||| 2^2) q11Shape29T267 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2359296 ||| 2^2) 34355548192 q11Shape29T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T267OK,q11Shape29T268OK⟩

private def q11Shape29T269 : Tree 11 := (.tip (.cover {0,2,3,4,5,9}))
private theorem q11Shape29T269OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2359328 34355548160 q11Shape29T269=true := by decide

private def q11Shape29T265 : Tree 11 := .split 5 q11Shape29T266 q11Shape29T269
private theorem q11Shape29T265OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2359296 34355548160 q11Shape29T265=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2359296 (34355548160 ||| 2^5) q11Shape29T266 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2359296 ||| 2^5) 34355548160 q11Shape29T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T266OK,q11Shape29T269OK⟩

private def q11Shape29T257 : Tree 11 := .split 18 q11Shape29T258 q11Shape29T265
private theorem q11Shape29T257OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 34355548160 q11Shape29T257=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (34355548160 ||| 2^18) q11Shape29T258 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^18) 34355548160 q11Shape29T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T258OK,q11Shape29T265OK⟩

private def q11Shape29T274 : Tree 11 := (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 4 (.tip (.cover {0,4,5,8,9,10})) (.tip (.cover {0,2,5,8,9,10}))))))
private theorem q11Shape29T274OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 34355808292 q11Shape29T274=true := by decide

private def q11Shape29T275 : Tree 11 := (.split 3 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 4 (.tip (.cover {0,4,5,8,9,10})) (.tip (.cover {0,2,5,8,9,10}))))) (.tip (.cover {0,2,3,4,8,9})))
private theorem q11Shape29T275OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101252 34355808288 q11Shape29T275=true := by decide

private def q11Shape29T273 : Tree 11 := .split 2 q11Shape29T274 q11Shape29T275
private theorem q11Shape29T273OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 34355808288 q11Shape29T273=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 (34355808288 ||| 2^2) q11Shape29T274 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2101248 ||| 2^2) 34355808288 q11Shape29T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T274OK,q11Shape29T275OK⟩

private def q11Shape29T276 : Tree 11 := (.tip (.cover {0,1,3,5,9,10}))
private theorem q11Shape29T276OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2103296 34355806240 q11Shape29T276=true := by decide

private def q11Shape29T272 : Tree 11 := .split 11 q11Shape29T273 q11Shape29T276
private theorem q11Shape29T272OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 34355806240 q11Shape29T272=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 (34355806240 ||| 2^11) q11Shape29T273 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2101248 ||| 2^11) 34355806240 q11Shape29T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T273OK,q11Shape29T276OK⟩

private def q11Shape29T277 : Tree 11 := (.tip (.cover {0,2,3,4,5,9}))
private theorem q11Shape29T277OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101280 34355806208 q11Shape29T277=true := by decide

private def q11Shape29T271 : Tree 11 := .split 5 q11Shape29T272 q11Shape29T277
private theorem q11Shape29T271OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 34355806208 q11Shape29T271=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 (34355806208 ||| 2^5) q11Shape29T272 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2101248 ||| 2^5) 34355806208 q11Shape29T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T272OK,q11Shape29T277OK⟩

private def q11Shape29T278 : Tree 11 := (.tip (.cover {0,2,3,4,5,9}))
private theorem q11Shape29T278OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2363392 34355544064 q11Shape29T278=true := by decide

private def q11Shape29T270 : Tree 11 := .split 18 q11Shape29T271 q11Shape29T278
private theorem q11Shape29T270OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 34355544064 q11Shape29T270=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2101248 (34355544064 ||| 2^18) q11Shape29T271 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2101248 ||| 2^18) 34355544064 q11Shape29T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T271OK,q11Shape29T278OK⟩

private def q11Shape29T256 : Tree 11 := .split 12 q11Shape29T257 q11Shape29T270
private theorem q11Shape29T256OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 34355544064 q11Shape29T256=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (34355544064 ||| 2^12) q11Shape29T257 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^12) 34355544064 q11Shape29T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T257OK,q11Shape29T270OK⟩

private def q11Shape29T281 : Tree 11 := (.split 15 (.split 12 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,9})))) (.split 18 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {2,3,4,5,7,10})))) (.tip (.cover {0,2,3,4,8,10})))
private theorem q11Shape29T281OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 538968064 33818673668 q11Shape29T281=true := by decide

private def q11Shape29T282 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T282OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 538968576 33818673156 q11Shape29T282=true := by decide

private def q11Shape29T280 : Tree 11 := .split 9 q11Shape29T281 q11Shape29T282
private theorem q11Shape29T280OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 538968064 33818673156 q11Shape29T280=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 538968064 (33818673156 ||| 2^9) q11Shape29T281 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (538968064 ||| 2^9) 33818673156 q11Shape29T282)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T281OK,q11Shape29T282OK⟩

private def q11Shape29T283 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T283OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 538968068 33818673152 q11Shape29T283=true := by decide

private def q11Shape29T279 : Tree 11 := .split 2 q11Shape29T280 q11Shape29T283
private theorem q11Shape29T279OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 538968064 33818673152 q11Shape29T279=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 538968064 (33818673152 ||| 2^2) q11Shape29T280 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (538968064 ||| 2^2) 33818673152 q11Shape29T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T280OK,q11Shape29T283OK⟩

private def q11Shape29T255 : Tree 11 := .split 29 q11Shape29T256 q11Shape29T279
private theorem q11Shape29T255OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 33818673152 q11Shape29T255=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (33818673152 ||| 2^29) q11Shape29T256 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^29) 33818673152 q11Shape29T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T256OK,q11Shape29T279OK⟩

private def q11Shape29T287 : Tree 11 := (.split 15 (.split 12 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,10})))) (.split 18 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {2,3,4,5,7,9})))) (.tip (.cover {0,2,3,4,8,9})))
private theorem q11Shape29T287OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532608 34087109124 q11Shape29T287=true := by decide

private def q11Shape29T288 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T288OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270533120 34087108612 q11Shape29T288=true := by decide

private def q11Shape29T286 : Tree 11 := .split 9 q11Shape29T287 q11Shape29T288
private theorem q11Shape29T286OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532608 34087108612 q11Shape29T286=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532608 (34087108612 ||| 2^9) q11Shape29T287 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (270532608 ||| 2^9) 34087108612 q11Shape29T288)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T287OK,q11Shape29T288OK⟩

private def q11Shape29T289 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T289OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532612 34087108608 q11Shape29T289=true := by decide

private def q11Shape29T285 : Tree 11 := .split 2 q11Shape29T286 q11Shape29T289
private theorem q11Shape29T285OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532608 34087108608 q11Shape29T285=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532608 (34087108608 ||| 2^2) q11Shape29T286 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (270532608 ||| 2^2) 34087108608 q11Shape29T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T286OK,q11Shape29T289OK⟩

private def q11Shape29T292 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 2 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,7,9,10}))))
private theorem q11Shape29T292OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 807403520 33550503936 q11Shape29T292=true := by decide

private def q11Shape29T293 : Tree 11 := (.split 5 (.split 15 (.split 17 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,2,3,4,6,9})))
private theorem q11Shape29T293OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 807665664 33550241792 q11Shape29T293=true := by decide

private def q11Shape29T291 : Tree 11 := .split 18 q11Shape29T292 q11Shape29T293
private theorem q11Shape29T291OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 807403520 33550241792 q11Shape29T291=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 807403520 (33550241792 ||| 2^18) q11Shape29T292 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (807403520 ||| 2^18) 33550241792 q11Shape29T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T292OK,q11Shape29T293OK⟩

private def q11Shape29T294 : Tree 11 := (.split 18 (.split 5 (.split 9 (.split 11 (.split 35 (.tip (.cover {0,2,3,4,6,8})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,2,3,4,6,9}))) (.tip (.cover {0,2,3,4,6,9})))
private theorem q11Shape29T294OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 807407616 33550237696 q11Shape29T294=true := by decide

private def q11Shape29T290 : Tree 11 := .split 12 q11Shape29T291 q11Shape29T294
private theorem q11Shape29T290OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 807403520 33550237696 q11Shape29T290=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 807403520 (33550237696 ||| 2^12) q11Shape29T291 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (807403520 ||| 2^12) 33550237696 q11Shape29T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T291OK,q11Shape29T294OK⟩

private def q11Shape29T284 : Tree 11 := .split 29 q11Shape29T285 q11Shape29T290
private theorem q11Shape29T284OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532608 33550237696 q11Shape29T284=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 270532608 (33550237696 ||| 2^29) q11Shape29T285 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (270532608 ||| 2^29) 33550237696 q11Shape29T290)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T285OK,q11Shape29T290OK⟩

private def q11Shape29T254 : Tree 11 := .split 28 q11Shape29T255 q11Shape29T284
private theorem q11Shape29T254OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 33550237696 q11Shape29T254=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (33550237696 ||| 2^28) q11Shape29T255 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^28) 33550237696 q11Shape29T284)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T255OK,q11Shape29T284OK⟩

private def q11Shape29T300 : Tree 11 := (.split 16 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,9}))) (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,9})))) (.tip (.cover {0,2,3,4,8,10})))
private theorem q11Shape29T300OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 34321994760 q11Shape29T300=true := by decide

private def q11Shape29T301 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {2,3,4,6,7,10}))) (.tip (.cover {2,3,4,6,7,10})))
private theorem q11Shape29T301OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35655680 34321990664 q11Shape29T301=true := by decide

private def q11Shape29T299 : Tree 11 := .split 12 q11Shape29T300 q11Shape29T301
private theorem q11Shape29T299OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 34321990664 q11Shape29T299=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 (34321990664 ||| 2^12) q11Shape29T300 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (35651584 ||| 2^12) 34321990664 q11Shape29T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T300OK,q11Shape29T301OK⟩

private def q11Shape29T302 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T302OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35652608 34321989640 q11Shape29T302=true := by decide

private def q11Shape29T298 : Tree 11 := .split 10 q11Shape29T299 q11Shape29T302
private theorem q11Shape29T298OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 34321989640 q11Shape29T298=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 (34321989640 ||| 2^10) q11Shape29T299 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (35651584 ||| 2^10) 34321989640 q11Shape29T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T299OK,q11Shape29T302OK⟩

private def q11Shape29T303 : Tree 11 := (.tip (.cover {0,2,3,4,8,10}))
private theorem q11Shape29T303OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651592 34321989632 q11Shape29T303=true := by decide

private def q11Shape29T297 : Tree 11 := .split 3 q11Shape29T298 q11Shape29T303
private theorem q11Shape29T297OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 34321989632 q11Shape29T297=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 (34321989632 ||| 2^3) q11Shape29T298 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (35651584 ||| 2^3) 34321989632 q11Shape29T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T298OK,q11Shape29T303OK⟩

private def q11Shape29T304 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T304OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 572522496 33785118720 q11Shape29T304=true := by decide

private def q11Shape29T296 : Tree 11 := .split 29 q11Shape29T297 q11Shape29T304
private theorem q11Shape29T296OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 33785118720 q11Shape29T296=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 (33785118720 ||| 2^29) q11Shape29T297 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (35651584 ||| 2^29) 33785118720 q11Shape29T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T297OK,q11Shape29T304OK⟩

private def q11Shape29T305 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T305OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 304087040 33516683264 q11Shape29T305=true := by decide

private def q11Shape29T295 : Tree 11 := .split 28 q11Shape29T296 q11Shape29T305
private theorem q11Shape29T295OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 33516683264 q11Shape29T295=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 35651584 (33516683264 ||| 2^28) q11Shape29T296 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (35651584 ||| 2^28) 33516683264 q11Shape29T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T296OK,q11Shape29T305OK⟩

private def q11Shape29T253 : Tree 11 := .split 25 q11Shape29T254 q11Shape29T295
private theorem q11Shape29T253OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 33516683264 q11Shape29T253=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 (33516683264 ||| 2^25) q11Shape29T254 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (2097152 ||| 2^25) 33516683264 q11Shape29T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T254OK,q11Shape29T295OK⟩

def q11Shape29P21 : Tree 11 := q11Shape29T253
theorem q11Shape29P21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2097152 33516683264 q11Shape29P21=true := q11Shape29T253OK

end Graffiti384b.EffectiveSearch.Q11
