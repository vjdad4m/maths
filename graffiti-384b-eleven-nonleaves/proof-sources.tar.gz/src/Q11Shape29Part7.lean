import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape29T312 : Tree 11 := (.split 16 (.split 18 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,10}))) (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,10})))) (.tip (.cover {0,2,3,4,8,9})))
private theorem q11Shape29T312OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 34338771976 q11Shape29T312=true := by decide

private def q11Shape29T313 : Tree 11 := (.split 18 (.split 5 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {2,3,4,6,7,9}))) (.tip (.cover {2,3,4,6,7,9})))
private theorem q11Shape29T313OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18878464 34338767880 q11Shape29T313=true := by decide

private def q11Shape29T311 : Tree 11 := .split 12 q11Shape29T312 q11Shape29T313
private theorem q11Shape29T311OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 34338767880 q11Shape29T311=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 (34338767880 ||| 2^12) q11Shape29T312 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (18874368 ||| 2^12) 34338767880 q11Shape29T313)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T312OK,q11Shape29T313OK⟩

private def q11Shape29T314 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T314OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18875392 34338766856 q11Shape29T314=true := by decide

private def q11Shape29T310 : Tree 11 := .split 10 q11Shape29T311 q11Shape29T314
private theorem q11Shape29T310OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 34338766856 q11Shape29T310=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 (34338766856 ||| 2^10) q11Shape29T311 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (18874368 ||| 2^10) 34338766856 q11Shape29T314)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T311OK,q11Shape29T314OK⟩

private def q11Shape29T315 : Tree 11 := (.tip (.cover {0,2,3,4,8,9}))
private theorem q11Shape29T315OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874376 34338766848 q11Shape29T315=true := by decide

private def q11Shape29T309 : Tree 11 := .split 3 q11Shape29T310 q11Shape29T315
private theorem q11Shape29T309OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 34338766848 q11Shape29T309=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 (34338766848 ||| 2^3) q11Shape29T310 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (18874368 ||| 2^3) 34338766848 q11Shape29T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T310OK,q11Shape29T315OK⟩

private def q11Shape29T318 : Tree 11 := (.split 5 (.tip (.small 1)) (.split 3 (.split 4 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,2,5,9,10}))) (.tip (.cover {0,1,2,7,9,10}))))
private theorem q11Shape29T318OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 52428800 34305478656 q11Shape29T318=true := by decide

private def q11Shape29T319 : Tree 11 := (.split 5 (.split 16 (.split 17 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,2,3,4,5,9})))
private theorem q11Shape29T319OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 52690944 34305216512 q11Shape29T319=true := by decide

private def q11Shape29T317 : Tree 11 := .split 18 q11Shape29T318 q11Shape29T319
private theorem q11Shape29T317OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 52428800 34305216512 q11Shape29T317=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 52428800 (34305216512 ||| 2^18) q11Shape29T318 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (52428800 ||| 2^18) 34305216512 q11Shape29T319)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T318OK,q11Shape29T319OK⟩

private def q11Shape29T320 : Tree 11 := (.split 18 (.split 5 (.split 10 (.split 11 (.split 35 (.tip (.cover {0,2,3,4,5,8})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,3,5,9,10}))) (.tip (.cover {0,1,3,7,9,10}))) (.tip (.cover {0,2,3,4,5,9}))) (.tip (.cover {0,2,3,4,5,9})))
private theorem q11Shape29T320OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 52432896 34305212416 q11Shape29T320=true := by decide

private def q11Shape29T316 : Tree 11 := .split 12 q11Shape29T317 q11Shape29T320
private theorem q11Shape29T316OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 52428800 34305212416 q11Shape29T316=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 52428800 (34305212416 ||| 2^12) q11Shape29T317 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (52428800 ||| 2^12) 34305212416 q11Shape29T320)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T317OK,q11Shape29T320OK⟩

private def q11Shape29T308 : Tree 11 := .split 25 q11Shape29T309 q11Shape29T316
private theorem q11Shape29T308OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 34305212416 q11Shape29T308=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 (34305212416 ||| 2^25) q11Shape29T309 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (18874368 ||| 2^25) 34305212416 q11Shape29T316)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T309OK,q11Shape29T316OK⟩

private def q11Shape29T321 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T321OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 555745280 33768341504 q11Shape29T321=true := by decide

private def q11Shape29T307 : Tree 11 := .split 29 q11Shape29T308 q11Shape29T321
private theorem q11Shape29T307OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 33768341504 q11Shape29T307=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 (33768341504 ||| 2^29) q11Shape29T308 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (18874368 ||| 2^29) 33768341504 q11Shape29T321)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T308OK,q11Shape29T321OK⟩

private def q11Shape29T322 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape29T322OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 287309824 33499906048 q11Shape29T322=true := by decide

private def q11Shape29T306 : Tree 11 := .split 28 q11Shape29T307 q11Shape29T322
private theorem q11Shape29T306OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 33499906048 q11Shape29T306=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 (33499906048 ||| 2^28) q11Shape29T307 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) (18874368 ||| 2^28) 33499906048 q11Shape29T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape29T307OK,q11Shape29T322OK⟩

def q11Shape29P22 : Tree 11 := q11Shape29T306
theorem q11Shape29P22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 18874368 33499906048 q11Shape29P22=true := q11Shape29T306OK

private def q11Shape29T324 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T324OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17181966336 16320036864 q11Shape29T324=true := by decide

def q11Shape29P23 : Tree 11 := q11Shape29T324
theorem q11Shape29P23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 17181966336 16320036864 q11Shape29P23=true := q11Shape29T324OK

private def q11Shape29T326 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T326OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8592031744 7730102272 q11Shape29T326=true := by decide

def q11Shape29P24 : Tree 11 := q11Shape29T326
theorem q11Shape29P24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 8592031744 7730102272 q11Shape29P24=true := q11Shape29T326OK

private def q11Shape29T328 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T328OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4297064448 3435134976 q11Shape29T328=true := by decide

def q11Shape29P25 : Tree 11 := q11Shape29T328
theorem q11Shape29P25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 4297064448 3435134976 q11Shape29P25=true := q11Shape29T328OK

private def q11Shape29T330 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T330OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2149580800 1287651328 q11Shape29T330=true := by decide

def q11Shape29P26 : Tree 11 := q11Shape29T330
theorem q11Shape29P26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 2149580800 1287651328 q11Shape29P26=true := q11Shape29T330OK

private def q11Shape29T332 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T332OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 10485760 1279262720 q11Shape29T332=true := by decide

def q11Shape29P27 : Tree 11 := q11Shape29T332
theorem q11Shape29P27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 10485760 1279262720 q11Shape29P27=true := q11Shape29T332OK

private def q11Shape29T334 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape29T334OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1075838976 205520896 q11Shape29T334=true := by decide

def q11Shape29P28 : Tree 11 := q11Shape29T334
theorem q11Shape29P28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 1075838976 205520896 q11Shape29P28=true := q11Shape29T334OK

private def q11Shape29T336 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape29T336OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 136314880 71303168 q11Shape29T336=true := by decide

def q11Shape29P29 : Tree 11 := q11Shape29T336
theorem q11Shape29P29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 136314880 71303168 q11Shape29P29=true := q11Shape29T336OK

private def q11Shape29T338 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape29T338OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 69206016 4194304 q11Shape29T338=true := by decide

def q11Shape29P30 : Tree 11 := q11Shape29T338
theorem q11Shape29P30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 69206016 4194304 q11Shape29P30=true := q11Shape29T338OK

private def q11Shape29T340 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape29T340OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6291456 0 q11Shape29T340=true := by decide

def q11Shape29P31 : Tree 11 := q11Shape29T340
theorem q11Shape29P31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,3⟩) 6291456 0 q11Shape29P31=true := q11Shape29T340OK

end Graffiti384b.EffectiveSearch.Q11
