import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape2T2 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {5,6,7,8,9,10})))))))))
private theorem q11Shape2T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 1075838979 q11Shape2T2=true := by decide

private def q11Shape2T4 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {5,6,7,8,9,10}))))))))
private theorem q11Shape2T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2 1075839233 q11Shape2T4=true := by decide

private def q11Shape2T6 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))))))
private theorem q11Shape2T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 258 1075838981 q11Shape2T6=true := by decide

private def q11Shape2T8 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))))))
private theorem q11Shape2T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 262 1075838985 q11Shape2T8=true := by decide

private def q11Shape2T9 : Tree 11 := (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))))) (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.tip (.cover {2,3,7,8,9,10}))))
private theorem q11Shape2T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 270 1075838977 q11Shape2T9=true := by decide

private def q11Shape2T7 : Tree 11 := .split 3 q11Shape2T8 q11Shape2T9
private theorem q11Shape2T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 262 1075838977 q11Shape2T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 262 (1075838977 ||| 2^3) q11Shape2T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (262 ||| 2^3) 1075838977 q11Shape2T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T8OK,q11Shape2T9OK⟩

private def q11Shape2T5 : Tree 11 := .split 2 q11Shape2T6 q11Shape2T7
private theorem q11Shape2T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 258 1075838977 q11Shape2T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 258 (1075838977 ||| 2^2) q11Shape2T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (258 ||| 2^2) 1075838977 q11Shape2T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T6OK,q11Shape2T7OK⟩

private def q11Shape2T3 : Tree 11 := .split 8 q11Shape2T4 q11Shape2T5
private theorem q11Shape2T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2 1075838977 q11Shape2T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2 (1075838977 ||| 2^8) q11Shape2T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2 ||| 2^8) 1075838977 q11Shape2T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T4OK,q11Shape2T5OK⟩

private def q11Shape2T1 : Tree 11 := .split 1 q11Shape2T2 q11Shape2T3
private theorem q11Shape2T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 1075838977 q11Shape2T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 (1075838977 ||| 2^1) q11Shape2T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (0 ||| 2^1) 1075838977 q11Shape2T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T2OK,q11Shape2T3OK⟩

private def q11Shape2T12 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {5,6,7,8,9,10}))))))))
private theorem q11Shape2T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1 1075839234 q11Shape2T12=true := by decide

private def q11Shape2T14 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10})))))
private theorem q11Shape2T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 257 1075838982 q11Shape2T14=true := by decide

private def q11Shape2T16 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 261 1075838986 q11Shape2T16=true := by decide

private def q11Shape2T17 : Tree 11 := (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {2,4,7,8,9,10}))))) (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {2,4,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 269 1075838978 q11Shape2T17=true := by decide

private def q11Shape2T15 : Tree 11 := .split 3 q11Shape2T16 q11Shape2T17
private theorem q11Shape2T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 261 1075838978 q11Shape2T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 261 (1075838978 ||| 2^3) q11Shape2T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (261 ||| 2^3) 1075838978 q11Shape2T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T16OK,q11Shape2T17OK⟩

private def q11Shape2T13 : Tree 11 := .split 2 q11Shape2T14 q11Shape2T15
private theorem q11Shape2T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 257 1075838978 q11Shape2T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 257 (1075838978 ||| 2^2) q11Shape2T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (257 ||| 2^2) 1075838978 q11Shape2T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T14OK,q11Shape2T15OK⟩

private def q11Shape2T11 : Tree 11 := .split 8 q11Shape2T12 q11Shape2T13
private theorem q11Shape2T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1 1075838978 q11Shape2T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1 (1075838978 ||| 2^8) q11Shape2T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1 ||| 2^8) 1075838978 q11Shape2T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T12OK,q11Shape2T13OK⟩

private def q11Shape2T20 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10})))))))
private theorem q11Shape2T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 3 1075839236 q11Shape2T20=true := by decide

private def q11Shape2T21 : Tree 11 := (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10})))))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape2T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 7 1075839232 q11Shape2T21=true := by decide

private def q11Shape2T19 : Tree 11 := .split 2 q11Shape2T20 q11Shape2T21
private theorem q11Shape2T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 3 1075839232 q11Shape2T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 3 (1075839232 ||| 2^2) q11Shape2T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (3 ||| 2^2) 1075839232 q11Shape2T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T20OK,q11Shape2T21OK⟩

private def q11Shape2T24 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 259 1075838988 q11Shape2T24=true := by decide

private def q11Shape2T25 : Tree 11 := (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))))) (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 267 1075838980 q11Shape2T25=true := by decide

private def q11Shape2T23 : Tree 11 := .split 3 q11Shape2T24 q11Shape2T25
private theorem q11Shape2T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 259 1075838980 q11Shape2T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 259 (1075838980 ||| 2^3) q11Shape2T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (259 ||| 2^3) 1075838980 q11Shape2T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T24OK,q11Shape2T25OK⟩

private def q11Shape2T26 : Tree 11 := (.split 3 (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))))) (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape2T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 263 1075838976 q11Shape2T26=true := by decide

private def q11Shape2T22 : Tree 11 := .split 2 q11Shape2T23 q11Shape2T26
private theorem q11Shape2T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 259 1075838976 q11Shape2T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 259 (1075838976 ||| 2^2) q11Shape2T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (259 ||| 2^2) 1075838976 q11Shape2T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T23OK,q11Shape2T26OK⟩

private def q11Shape2T18 : Tree 11 := .split 8 q11Shape2T19 q11Shape2T22
private theorem q11Shape2T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 3 1075838976 q11Shape2T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 3 (1075838976 ||| 2^8) q11Shape2T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (3 ||| 2^8) 1075838976 q11Shape2T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T19OK,q11Shape2T22OK⟩

private def q11Shape2T10 : Tree 11 := .split 1 q11Shape2T11 q11Shape2T18
private theorem q11Shape2T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1 1075838976 q11Shape2T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1 (1075838976 ||| 2^1) q11Shape2T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1 ||| 2^1) 1075838976 q11Shape2T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T11OK,q11Shape2T18OK⟩

private def q11Shape2T0 : Tree 11 := .split 0 q11Shape2T1 q11Shape2T10
private theorem q11Shape2T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 1075838976 q11Shape2T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 (1075838976 ||| 2^0) q11Shape2T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (0 ||| 2^0) 1075838976 q11Shape2T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T1OK,q11Shape2T10OK⟩

def q11Shape2P0 : Tree 11 := q11Shape2T0
theorem q11Shape2P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 0 1075838976 q11Shape2P0=true := q11Shape2T0OK

end Graffiti384b.EffectiveSearch.Q11
