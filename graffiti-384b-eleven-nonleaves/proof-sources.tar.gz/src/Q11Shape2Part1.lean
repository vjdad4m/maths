import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape2T29 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10})))))
private theorem q11Shape2T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741824 2097155 q11Shape2T29=true := by decide

private def q11Shape2T31 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10}))))
private theorem q11Shape2T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741826 2097409 q11Shape2T31=true := by decide

private def q11Shape2T32 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))) (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10})))) (.tip (.cover {0,1,2,7,9,10}))))
private theorem q11Shape2T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742082 2097153 q11Shape2T32=true := by decide

private def q11Shape2T30 : Tree 11 := .split 8 q11Shape2T31 q11Shape2T32
private theorem q11Shape2T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741826 2097153 q11Shape2T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741826 (2097153 ||| 2^8) q11Shape2T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073741826 ||| 2^8) 2097153 q11Shape2T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T31OK,q11Shape2T32OK⟩

private def q11Shape2T28 : Tree 11 := .split 1 q11Shape2T29 q11Shape2T30
private theorem q11Shape2T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741824 2097153 q11Shape2T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741824 (2097153 ||| 2^1) q11Shape2T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073741824 ||| 2^1) 2097153 q11Shape2T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T29OK,q11Shape2T30OK⟩

private def q11Shape2T35 : Tree 11 := (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover {0,1,2,7,9,10}))))
private theorem q11Shape2T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741825 2097410 q11Shape2T35=true := by decide

private def q11Shape2T36 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))) (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10})))) (.tip (.cover {0,1,2,7,9,10}))))
private theorem q11Shape2T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742081 2097154 q11Shape2T36=true := by decide

private def q11Shape2T34 : Tree 11 := .split 8 q11Shape2T35 q11Shape2T36
private theorem q11Shape2T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741825 2097154 q11Shape2T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741825 (2097154 ||| 2^8) q11Shape2T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073741825 ||| 2^8) 2097154 q11Shape2T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T35OK,q11Shape2T36OK⟩

private def q11Shape2T38 : Tree 11 := (.split 2 (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))) (.split 3 (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10})))) (.tip (.cover {0,1,2,7,9,10}))))
private theorem q11Shape2T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741827 2097408 q11Shape2T38=true := by decide

private def q11Shape2T41 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,1,3,7,9,10}))))
private theorem q11Shape2T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742083 2097164 q11Shape2T41=true := by decide

private def q11Shape2T42 : Tree 11 := (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {1,5,6,7,9,10})))) (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {0,1,3,7,9,10}))))
private theorem q11Shape2T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742091 2097156 q11Shape2T42=true := by decide

private def q11Shape2T40 : Tree 11 := .split 3 q11Shape2T41 q11Shape2T42
private theorem q11Shape2T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742083 2097156 q11Shape2T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742083 (2097156 ||| 2^3) q11Shape2T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073742083 ||| 2^3) 2097156 q11Shape2T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T41OK,q11Shape2T42OK⟩

private def q11Shape2T43 : Tree 11 := (.split 3 (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {1,5,6,7,9,10})))) (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,1,3,7,9,10})))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape2T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742087 2097152 q11Shape2T43=true := by decide

private def q11Shape2T39 : Tree 11 := .split 2 q11Shape2T40 q11Shape2T43
private theorem q11Shape2T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742083 2097152 q11Shape2T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073742083 (2097152 ||| 2^2) q11Shape2T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073742083 ||| 2^2) 2097152 q11Shape2T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T40OK,q11Shape2T43OK⟩

private def q11Shape2T37 : Tree 11 := .split 8 q11Shape2T38 q11Shape2T39
private theorem q11Shape2T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741827 2097152 q11Shape2T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741827 (2097152 ||| 2^8) q11Shape2T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073741827 ||| 2^8) 2097152 q11Shape2T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T38OK,q11Shape2T39OK⟩

private def q11Shape2T33 : Tree 11 := .split 1 q11Shape2T34 q11Shape2T37
private theorem q11Shape2T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741825 2097152 q11Shape2T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741825 (2097152 ||| 2^1) q11Shape2T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073741825 ||| 2^1) 2097152 q11Shape2T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T34OK,q11Shape2T37OK⟩

private def q11Shape2T27 : Tree 11 := .split 0 q11Shape2T28 q11Shape2T33
private theorem q11Shape2T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741824 2097152 q11Shape2T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741824 (2097152 ||| 2^0) q11Shape2T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (1073741824 ||| 2^0) 2097152 q11Shape2T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T28OK,q11Shape2T33OK⟩

def q11Shape2P1 : Tree 11 := q11Shape2T27
theorem q11Shape2P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1073741824 2097152 q11Shape2P1=true := q11Shape2T27OK

end Graffiti384b.EffectiveSearch.Q11
