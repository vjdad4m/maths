import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape2T47 : Tree 11 := (.tip (.small 1))
private theorem q11Shape2T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 1073742083 q11Shape2T47=true := by decide

private def q11Shape2T49 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))))))
private theorem q11Shape2T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097408 1073741831 q11Shape2T49=true := by decide

private def q11Shape2T51 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape2T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097412 1073741835 q11Shape2T51=true := by decide

private def q11Shape2T53 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))))
private theorem q11Shape2T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097420 1073742339 q11Shape2T53=true := by decide

private def q11Shape2T54 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))))
private theorem q11Shape2T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097932 1073741827 q11Shape2T54=true := by decide

private def q11Shape2T52 : Tree 11 := .split 9 q11Shape2T53 q11Shape2T54
private theorem q11Shape2T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097420 1073741827 q11Shape2T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097420 (1073741827 ||| 2^9) q11Shape2T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097420 ||| 2^9) 1073741827 q11Shape2T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T53OK,q11Shape2T54OK⟩

private def q11Shape2T50 : Tree 11 := .split 3 q11Shape2T51 q11Shape2T52
private theorem q11Shape2T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097412 1073741827 q11Shape2T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097412 (1073741827 ||| 2^3) q11Shape2T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097412 ||| 2^3) 1073741827 q11Shape2T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T51OK,q11Shape2T52OK⟩

private def q11Shape2T48 : Tree 11 := .split 2 q11Shape2T49 q11Shape2T50
private theorem q11Shape2T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097408 1073741827 q11Shape2T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097408 (1073741827 ||| 2^2) q11Shape2T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097408 ||| 2^2) 1073741827 q11Shape2T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T49OK,q11Shape2T50OK⟩

private def q11Shape2T46 : Tree 11 := .split 8 q11Shape2T47 q11Shape2T48
private theorem q11Shape2T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 1073741827 q11Shape2T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 (1073741827 ||| 2^8) q11Shape2T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097152 ||| 2^8) 1073741827 q11Shape2T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T47OK,q11Shape2T48OK⟩

private def q11Shape2T57 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))))))
private theorem q11Shape2T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097154 1073742085 q11Shape2T57=true := by decide

private def q11Shape2T59 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape2T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097158 1073742089 q11Shape2T59=true := by decide

private def q11Shape2T61 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))))
private theorem q11Shape2T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097166 1073742593 q11Shape2T61=true := by decide

private def q11Shape2T62 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))))
private theorem q11Shape2T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097678 1073742081 q11Shape2T62=true := by decide

private def q11Shape2T60 : Tree 11 := .split 9 q11Shape2T61 q11Shape2T62
private theorem q11Shape2T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097166 1073742081 q11Shape2T60=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097166 (1073742081 ||| 2^9) q11Shape2T61 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097166 ||| 2^9) 1073742081 q11Shape2T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T61OK,q11Shape2T62OK⟩

private def q11Shape2T58 : Tree 11 := .split 3 q11Shape2T59 q11Shape2T60
private theorem q11Shape2T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097158 1073742081 q11Shape2T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097158 (1073742081 ||| 2^3) q11Shape2T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097158 ||| 2^3) 1073742081 q11Shape2T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T59OK,q11Shape2T60OK⟩

private def q11Shape2T56 : Tree 11 := .split 2 q11Shape2T57 q11Shape2T58
private theorem q11Shape2T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097154 1073742081 q11Shape2T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097154 (1073742081 ||| 2^2) q11Shape2T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097154 ||| 2^2) 1073742081 q11Shape2T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T57OK,q11Shape2T58OK⟩

private def q11Shape2T65 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))))))
private theorem q11Shape2T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097410 1073741837 q11Shape2T65=true := by decide

private def q11Shape2T67 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10}))))
private theorem q11Shape2T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097418 1073742341 q11Shape2T67=true := by decide

private def q11Shape2T68 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))))
private theorem q11Shape2T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097930 1073741829 q11Shape2T68=true := by decide

private def q11Shape2T66 : Tree 11 := .split 9 q11Shape2T67 q11Shape2T68
private theorem q11Shape2T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097418 1073741829 q11Shape2T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097418 (1073741829 ||| 2^9) q11Shape2T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097418 ||| 2^9) 1073741829 q11Shape2T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T67OK,q11Shape2T68OK⟩

private def q11Shape2T64 : Tree 11 := .split 3 q11Shape2T65 q11Shape2T66
private theorem q11Shape2T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097410 1073741829 q11Shape2T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097410 (1073741829 ||| 2^3) q11Shape2T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097410 ||| 2^3) 1073741829 q11Shape2T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T65OK,q11Shape2T66OK⟩

private def q11Shape2T71 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape2T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097414 1073742345 q11Shape2T71=true := by decide

private def q11Shape2T72 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))))
private theorem q11Shape2T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097926 1073741833 q11Shape2T72=true := by decide

private def q11Shape2T70 : Tree 11 := .split 9 q11Shape2T71 q11Shape2T72
private theorem q11Shape2T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097414 1073741833 q11Shape2T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097414 (1073741833 ||| 2^9) q11Shape2T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097414 ||| 2^9) 1073741833 q11Shape2T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T71OK,q11Shape2T72OK⟩

private def q11Shape2T74 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {4,6,7,8,9,10}))))
private theorem q11Shape2T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097422 1073742337 q11Shape2T74=true := by decide

private def q11Shape2T75 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {2,3,7,8,9,10})))
private theorem q11Shape2T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097934 1073741825 q11Shape2T75=true := by decide

private def q11Shape2T73 : Tree 11 := .split 9 q11Shape2T74 q11Shape2T75
private theorem q11Shape2T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097422 1073741825 q11Shape2T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097422 (1073741825 ||| 2^9) q11Shape2T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097422 ||| 2^9) 1073741825 q11Shape2T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T74OK,q11Shape2T75OK⟩

private def q11Shape2T69 : Tree 11 := .split 3 q11Shape2T70 q11Shape2T73
private theorem q11Shape2T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097414 1073741825 q11Shape2T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097414 (1073741825 ||| 2^3) q11Shape2T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097414 ||| 2^3) 1073741825 q11Shape2T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T70OK,q11Shape2T73OK⟩

private def q11Shape2T63 : Tree 11 := .split 2 q11Shape2T64 q11Shape2T69
private theorem q11Shape2T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097410 1073741825 q11Shape2T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097410 (1073741825 ||| 2^2) q11Shape2T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097410 ||| 2^2) 1073741825 q11Shape2T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T64OK,q11Shape2T69OK⟩

private def q11Shape2T55 : Tree 11 := .split 8 q11Shape2T56 q11Shape2T63
private theorem q11Shape2T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097154 1073741825 q11Shape2T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097154 (1073741825 ||| 2^8) q11Shape2T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097154 ||| 2^8) 1073741825 q11Shape2T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T56OK,q11Shape2T63OK⟩

private def q11Shape2T45 : Tree 11 := .split 1 q11Shape2T46 q11Shape2T55
private theorem q11Shape2T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 1073741825 q11Shape2T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 (1073741825 ||| 2^1) q11Shape2T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097152 ||| 2^1) 1073741825 q11Shape2T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T46OK,q11Shape2T55OK⟩

def q11Shape2P2 : Tree 11 := q11Shape2T45
theorem q11Shape2P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097152 1073741825 q11Shape2P2=true := q11Shape2T45OK

end Graffiti384b.EffectiveSearch.Q11
