import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape2T78 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))))))
private theorem q11Shape2T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 1073742086 q11Shape2T78=true := by decide

private def q11Shape2T80 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape2T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097157 1073742090 q11Shape2T80=true := by decide

private def q11Shape2T82 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))))
private theorem q11Shape2T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097165 1073742594 q11Shape2T82=true := by decide

private def q11Shape2T83 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))))
private theorem q11Shape2T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097677 1073742082 q11Shape2T83=true := by decide

private def q11Shape2T81 : Tree 11 := .split 9 q11Shape2T82 q11Shape2T83
private theorem q11Shape2T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097165 1073742082 q11Shape2T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097165 (1073742082 ||| 2^9) q11Shape2T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097165 ||| 2^9) 1073742082 q11Shape2T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T82OK,q11Shape2T83OK⟩

private def q11Shape2T79 : Tree 11 := .split 3 q11Shape2T80 q11Shape2T81
private theorem q11Shape2T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097157 1073742082 q11Shape2T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097157 (1073742082 ||| 2^3) q11Shape2T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097157 ||| 2^3) 1073742082 q11Shape2T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T80OK,q11Shape2T81OK⟩

private def q11Shape2T77 : Tree 11 := .split 2 q11Shape2T78 q11Shape2T79
private theorem q11Shape2T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 1073742082 q11Shape2T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 (1073742082 ||| 2^2) q11Shape2T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097153 ||| 2^2) 1073742082 q11Shape2T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T78OK,q11Shape2T79OK⟩

private def q11Shape2T86 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097409 1073741838 q11Shape2T86=true := by decide

private def q11Shape2T87 : Tree 11 := (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))))) (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097417 1073741830 q11Shape2T87=true := by decide

private def q11Shape2T85 : Tree 11 := .split 3 q11Shape2T86 q11Shape2T87
private theorem q11Shape2T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097409 1073741830 q11Shape2T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097409 (1073741830 ||| 2^3) q11Shape2T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097409 ||| 2^3) 1073741830 q11Shape2T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T86OK,q11Shape2T87OK⟩

private def q11Shape2T89 : Tree 11 := (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10})))) (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097413 1073741834 q11Shape2T89=true := by decide

private def q11Shape2T91 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {2,4,7,8,9,10})))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))))
private theorem q11Shape2T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097421 1073742338 q11Shape2T91=true := by decide

private def q11Shape2T92 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape2T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097933 1073741826 q11Shape2T92=true := by decide

private def q11Shape2T90 : Tree 11 := .split 9 q11Shape2T91 q11Shape2T92
private theorem q11Shape2T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097421 1073741826 q11Shape2T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097421 (1073741826 ||| 2^9) q11Shape2T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097421 ||| 2^9) 1073741826 q11Shape2T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T91OK,q11Shape2T92OK⟩

private def q11Shape2T88 : Tree 11 := .split 3 q11Shape2T89 q11Shape2T90
private theorem q11Shape2T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097413 1073741826 q11Shape2T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097413 (1073741826 ||| 2^3) q11Shape2T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097413 ||| 2^3) 1073741826 q11Shape2T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T89OK,q11Shape2T90OK⟩

private def q11Shape2T84 : Tree 11 := .split 2 q11Shape2T85 q11Shape2T88
private theorem q11Shape2T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097409 1073741826 q11Shape2T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097409 (1073741826 ||| 2^2) q11Shape2T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097409 ||| 2^2) 1073741826 q11Shape2T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T85OK,q11Shape2T88OK⟩

private def q11Shape2T76 : Tree 11 := .split 8 q11Shape2T77 q11Shape2T84
private theorem q11Shape2T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 1073741826 q11Shape2T76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 (1073741826 ||| 2^8) q11Shape2T77 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097153 ||| 2^8) 1073741826 q11Shape2T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T77OK,q11Shape2T84OK⟩

def q11Shape2P3 : Tree 11 := q11Shape2T76
theorem q11Shape2P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097153 1073741826 q11Shape2P3=true := q11Shape2T76OK

end Graffiti384b.EffectiveSearch.Q11
