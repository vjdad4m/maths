import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape2T96 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10}))))))
private theorem q11Shape2T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 1073742092 q11Shape2T96=true := by decide

private def q11Shape2T98 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10})))))
private theorem q11Shape2T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097163 1073742596 q11Shape2T98=true := by decide

private def q11Shape2T99 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10}))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {0,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))))
private theorem q11Shape2T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097675 1073742084 q11Shape2T99=true := by decide

private def q11Shape2T97 : Tree 11 := .split 9 q11Shape2T98 q11Shape2T99
private theorem q11Shape2T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097163 1073742084 q11Shape2T97=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097163 (1073742084 ||| 2^9) q11Shape2T98 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097163 ||| 2^9) 1073742084 q11Shape2T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T98OK,q11Shape2T99OK⟩

private def q11Shape2T95 : Tree 11 := .split 3 q11Shape2T96 q11Shape2T97
private theorem q11Shape2T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 1073742084 q11Shape2T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 (1073742084 ||| 2^3) q11Shape2T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097155 ||| 2^3) 1073742084 q11Shape2T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T96OK,q11Shape2T97OK⟩

private def q11Shape2T102 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10})))))
private theorem q11Shape2T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097159 1073742600 q11Shape2T102=true := by decide

private def q11Shape2T103 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))))
private theorem q11Shape2T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097671 1073742088 q11Shape2T103=true := by decide

private def q11Shape2T101 : Tree 11 := .split 9 q11Shape2T102 q11Shape2T103
private theorem q11Shape2T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097159 1073742088 q11Shape2T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097159 (1073742088 ||| 2^9) q11Shape2T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097159 ||| 2^9) 1073742088 q11Shape2T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T102OK,q11Shape2T103OK⟩

private def q11Shape2T104 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape2T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097167 1073742080 q11Shape2T104=true := by decide

private def q11Shape2T100 : Tree 11 := .split 3 q11Shape2T101 q11Shape2T104
private theorem q11Shape2T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097159 1073742080 q11Shape2T100=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097159 (1073742080 ||| 2^3) q11Shape2T101 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097159 ||| 2^3) 1073742080 q11Shape2T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T101OK,q11Shape2T104OK⟩

private def q11Shape2T94 : Tree 11 := .split 2 q11Shape2T95 q11Shape2T100
private theorem q11Shape2T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 1073742080 q11Shape2T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 (1073742080 ||| 2^2) q11Shape2T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097155 ||| 2^2) 1073742080 q11Shape2T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T95OK,q11Shape2T100OK⟩

private def q11Shape2T107 : Tree 11 := (.split 9 (.split 10 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))))) (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape2T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097411 1073741836 q11Shape2T107=true := by decide

private def q11Shape2T109 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.unordered {2,3,4,6} 0))) (.tip (.cover {4,6,7,8,9,10}))))
private theorem q11Shape2T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097419 1073742340 q11Shape2T109=true := by decide

private def q11Shape2T110 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10}))) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape2T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097931 1073741828 q11Shape2T110=true := by decide

private def q11Shape2T108 : Tree 11 := .split 9 q11Shape2T109 q11Shape2T110
private theorem q11Shape2T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097419 1073741828 q11Shape2T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097419 (1073741828 ||| 2^9) q11Shape2T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097419 ||| 2^9) 1073741828 q11Shape2T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T109OK,q11Shape2T110OK⟩

private def q11Shape2T106 : Tree 11 := .split 3 q11Shape2T107 q11Shape2T108
private theorem q11Shape2T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097411 1073741828 q11Shape2T106=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097411 (1073741828 ||| 2^3) q11Shape2T107 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097411 ||| 2^3) 1073741828 q11Shape2T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T107OK,q11Shape2T108OK⟩

private def q11Shape2T113 : Tree 11 := (.split 10 (.split 15 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10}))) (.tip (.cover {3,5,7,8,9,10}))))
private theorem q11Shape2T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097415 1073742344 q11Shape2T113=true := by decide

private def q11Shape2T114 : Tree 11 := (.split 10 (.split 15 (.split 16 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10}))) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape2T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097927 1073741832 q11Shape2T114=true := by decide

private def q11Shape2T112 : Tree 11 := .split 9 q11Shape2T113 q11Shape2T114
private theorem q11Shape2T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097415 1073741832 q11Shape2T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097415 (1073741832 ||| 2^9) q11Shape2T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097415 ||| 2^9) 1073741832 q11Shape2T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T113OK,q11Shape2T114OK⟩

private def q11Shape2T115 : Tree 11 := (.tip (.cover {0,2,7,8,9,10}))
private theorem q11Shape2T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097423 1073741824 q11Shape2T115=true := by decide

private def q11Shape2T111 : Tree 11 := .split 3 q11Shape2T112 q11Shape2T115
private theorem q11Shape2T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097415 1073741824 q11Shape2T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097415 (1073741824 ||| 2^3) q11Shape2T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097415 ||| 2^3) 1073741824 q11Shape2T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T112OK,q11Shape2T115OK⟩

private def q11Shape2T105 : Tree 11 := .split 2 q11Shape2T106 q11Shape2T111
private theorem q11Shape2T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097411 1073741824 q11Shape2T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097411 (1073741824 ||| 2^2) q11Shape2T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097411 ||| 2^2) 1073741824 q11Shape2T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T106OK,q11Shape2T111OK⟩

private def q11Shape2T93 : Tree 11 := .split 8 q11Shape2T94 q11Shape2T105
private theorem q11Shape2T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 1073741824 q11Shape2T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 (1073741824 ||| 2^8) q11Shape2T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) (2097155 ||| 2^8) 1073741824 q11Shape2T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape2T94OK,q11Shape2T105OK⟩

def q11Shape2P4 : Tree 11 := q11Shape2T93
theorem q11Shape2P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 2097155 1073741824 q11Shape2P4=true := q11Shape2T93OK

private def q11Shape2T118 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape2T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1075838976 0 q11Shape2T118=true := by decide

def q11Shape2P5 : Tree 11 := q11Shape2T118
theorem q11Shape2P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,3⟩) 1075838976 0 q11Shape2P5=true := q11Shape2T118OK

end Graffiti384b.EffectiveSearch.Q11
