import Q11Shape3Part0
import Q11Shape3Part1
import Q11Shape3Part2
import Q11Shape3Part3

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape3M36 : Tree 11 := .split 1 q11Shape3P0 q11Shape3P1
private theorem q11Shape3M36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 1 q11Shape3M36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 (1 ||| 2^1) q11Shape3P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (0 ||| 2^1) 1 q11Shape3P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3P0OK,q11Shape3P1OK⟩
private def q11Shape3M89 : Tree 11 := .split 1 q11Shape3P2 q11Shape3P3
private theorem q11Shape3M89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 0 q11Shape3M89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 (0 ||| 2^1) q11Shape3P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (1 ||| 2^1) 0 q11Shape3P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3P2OK,q11Shape3P3OK⟩
private def q11Shape3M90 : Tree 11 := .split 0 q11Shape3M36 q11Shape3M89
private theorem q11Shape3M90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 0 q11Shape3M90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 (0 ||| 2^0) q11Shape3M36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (0 ||| 2^0) 0 q11Shape3M89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3M36OK,q11Shape3M89OK⟩

theorem q11Shape3_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 3) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 3) b) (adj 11 (forms 3) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) adj_mono b H q11Shape3M90 q11Shape3M90OK

#print axioms q11Shape3_cover

end Graffiti384b.EffectiveSearch.Q11
