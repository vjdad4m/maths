import Q11Shape30Part0
import Q11Shape30Part1
import Q11Shape30Part2

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape30M46 : Tree 11 := .split 4 q11Shape30P0 q11Shape30P1
private theorem q11Shape30M46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 8522825736 q11Shape30M46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (8522825736 ||| 2^4) q11Shape30P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^4) 8522825736 q11Shape30P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30P0OK,q11Shape30P1OK⟩
private def q11Shape30M72 : Tree 11 := .split 3 q11Shape30M46 q11Shape30P2
private theorem q11Shape30M72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 8522825728 q11Shape30M72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (8522825728 ||| 2^3) q11Shape30M46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^3) 8522825728 q11Shape30P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M46OK,q11Shape30P2OK⟩
private def q11Shape30M74 : Tree 11 := .split 32 q11Shape30M72 q11Shape30P3
private theorem q11Shape30M74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 4227858432 q11Shape30M74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (4227858432 ||| 2^32) q11Shape30M72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^32) 4227858432 q11Shape30P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M72OK,q11Shape30P3OK⟩
private def q11Shape30M76 : Tree 11 := .split 31 q11Shape30M74 q11Shape30P4
private theorem q11Shape30M76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 2080374784 q11Shape30M76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (2080374784 ||| 2^31) q11Shape30M74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^31) 2080374784 q11Shape30P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M74OK,q11Shape30P4OK⟩
private def q11Shape30M78 : Tree 11 := .split 30 q11Shape30M76 q11Shape30P5
private theorem q11Shape30M78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 1006632960 q11Shape30M78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (1006632960 ||| 2^30) q11Shape30M76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^30) 1006632960 q11Shape30P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M76OK,q11Shape30P5OK⟩
private def q11Shape30M80 : Tree 11 := .split 29 q11Shape30M78 q11Shape30P6
private theorem q11Shape30M80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 469762048 q11Shape30M80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (469762048 ||| 2^29) q11Shape30M78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^29) 469762048 q11Shape30P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M78OK,q11Shape30P6OK⟩
private def q11Shape30M82 : Tree 11 := .split 28 q11Shape30M80 q11Shape30P7
private theorem q11Shape30M82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 201326592 q11Shape30M82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (201326592 ||| 2^28) q11Shape30M80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^28) 201326592 q11Shape30P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M80OK,q11Shape30P7OK⟩
private def q11Shape30M84 : Tree 11 := .split 27 q11Shape30M82 q11Shape30P8
private theorem q11Shape30M84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 67108864 q11Shape30M84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (67108864 ||| 2^27) q11Shape30M82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^27) 67108864 q11Shape30P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M82OK,q11Shape30P8OK⟩
private def q11Shape30M86 : Tree 11 := .split 26 q11Shape30M84 q11Shape30P9
private theorem q11Shape30M86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 0 q11Shape30M86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (0 ||| 2^26) q11Shape30M84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^26) 0 q11Shape30P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30M84OK,q11Shape30P9OK⟩

theorem q11Shape30_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 30) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 30) b) (adj 11 (forms 30) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) adj_mono b H q11Shape30M86 q11Shape30M86OK

#print axioms q11Shape30_cover

end Graffiti384b.EffectiveSearch.Q11
