import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape30T3 : Tree 11 := (.split 17 (.tip (.cover {0,1,5,8,9,10})) (.split 21 (.tip (.cover {0,1,7,8,9,10})) (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))))
private theorem q11Shape30T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 8522894360 q11Shape30T3=true := by decide

private def q11Shape30T4 : Tree 11 := (.split 17 (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10}))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape30T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 65536 8522828824 q11Shape30T4=true := by decide

private def q11Shape30T2 : Tree 11 := .split 16 q11Shape30T3 q11Shape30T4
private theorem q11Shape30T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 8522828824 q11Shape30T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (8522828824 ||| 2^16) q11Shape30T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^16) 8522828824 q11Shape30T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T3OK,q11Shape30T4OK⟩

private def q11Shape30T7 : Tree 11 := (.split 21 (.tip (.cover {0,1,7,8,9,10})) (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape30T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2048 8523023384 q11Shape30T7=true := by decide

private def q11Shape30T8 : Tree 11 := (.split 21 (.tip (.cover {0,1,7,8,9,10})) (.split 22 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape30T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 133120 8522892312 q11Shape30T8=true := by decide

private def q11Shape30T6 : Tree 11 := .split 17 q11Shape30T7 q11Shape30T8
private theorem q11Shape30T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2048 8522892312 q11Shape30T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2048 (8522892312 ||| 2^17) q11Shape30T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (2048 ||| 2^17) 8522892312 q11Shape30T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T7OK,q11Shape30T8OK⟩

private def q11Shape30T11 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))))
private theorem q11Shape30T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67584 8525055000 q11Shape30T11=true := by decide

private def q11Shape30T12 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2164736 8522957848 q11Shape30T12=true := by decide

private def q11Shape30T10 : Tree 11 := .split 21 q11Shape30T11 q11Shape30T12
private theorem q11Shape30T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67584 8522957848 q11Shape30T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67584 (8522957848 ||| 2^21) q11Shape30T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (67584 ||| 2^21) 8522957848 q11Shape30T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T11OK,q11Shape30T12OK⟩

private def q11Shape30T13 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape30T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 198656 8522826776 q11Shape30T13=true := by decide

private def q11Shape30T9 : Tree 11 := .split 17 q11Shape30T10 q11Shape30T13
private theorem q11Shape30T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67584 8522826776 q11Shape30T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67584 (8522826776 ||| 2^17) q11Shape30T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (67584 ||| 2^17) 8522826776 q11Shape30T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T10OK,q11Shape30T13OK⟩

private def q11Shape30T5 : Tree 11 := .split 16 q11Shape30T6 q11Shape30T9
private theorem q11Shape30T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2048 8522826776 q11Shape30T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2048 (8522826776 ||| 2^16) q11Shape30T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (2048 ||| 2^16) 8522826776 q11Shape30T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T6OK,q11Shape30T9OK⟩

private def q11Shape30T1 : Tree 11 := .split 11 q11Shape30T2 q11Shape30T5
private theorem q11Shape30T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 8522826776 q11Shape30T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (8522826776 ||| 2^11) q11Shape30T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^11) 8522826776 q11Shape30T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T2OK,q11Shape30T5OK⟩

private def q11Shape30T17 : Tree 11 := (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10}))))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1024 8523024408 q11Shape30T17=true := by decide

private def q11Shape30T19 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))))
private theorem q11Shape30T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 132096 8524990488 q11Shape30T19=true := by decide

private def q11Shape30T20 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2229248 8522893336 q11Shape30T20=true := by decide

private def q11Shape30T18 : Tree 11 := .split 21 q11Shape30T19 q11Shape30T20
private theorem q11Shape30T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 132096 8522893336 q11Shape30T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 132096 (8522893336 ||| 2^21) q11Shape30T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (132096 ||| 2^21) 8522893336 q11Shape30T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T19OK,q11Shape30T20OK⟩

private def q11Shape30T16 : Tree 11 := .split 17 q11Shape30T17 q11Shape30T18
private theorem q11Shape30T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1024 8522893336 q11Shape30T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1024 (8522893336 ||| 2^17) q11Shape30T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1024 ||| 2^17) 8522893336 q11Shape30T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T17OK,q11Shape30T18OK⟩

private def q11Shape30T21 : Tree 11 := (.split 17 (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10}))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape30T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 66560 8522827800 q11Shape30T21=true := by decide

private def q11Shape30T15 : Tree 11 := .split 16 q11Shape30T16 q11Shape30T21
private theorem q11Shape30T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1024 8522827800 q11Shape30T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1024 (8522827800 ||| 2^16) q11Shape30T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1024 ||| 2^16) 8522827800 q11Shape30T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T16OK,q11Shape30T21OK⟩

private def q11Shape30T22 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape30T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 3072 8522825752 q11Shape30T22=true := by decide

private def q11Shape30T14 : Tree 11 := .split 11 q11Shape30T15 q11Shape30T22
private theorem q11Shape30T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1024 8522825752 q11Shape30T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1024 (8522825752 ||| 2^11) q11Shape30T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1024 ||| 2^11) 8522825752 q11Shape30T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T15OK,q11Shape30T22OK⟩

private def q11Shape30T0 : Tree 11 := .split 10 q11Shape30T1 q11Shape30T14
private theorem q11Shape30T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 8522825752 q11Shape30T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 (8522825752 ||| 2^10) q11Shape30T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (0 ||| 2^10) 8522825752 q11Shape30T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T1OK,q11Shape30T14OK⟩

def q11Shape30P0 : Tree 11 := q11Shape30T0
theorem q11Shape30P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 0 8522825752 q11Shape30P0=true := q11Shape30T0OK

end Graffiti384b.EffectiveSearch.Q11
