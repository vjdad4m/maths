import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape30T27 : Tree 11 := (.split 21 (.tip (.cover {0,1,7,8,9,10})) (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape30T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 8523025416 q11Shape30T27=true := by decide

private def q11Shape30T28 : Tree 11 := (.split 21 (.tip (.cover {0,1,7,8,9,10})) (.split 22 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10}))))
private theorem q11Shape30T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 131088 8522894344 q11Shape30T28=true := by decide

private def q11Shape30T26 : Tree 11 := .split 17 q11Shape30T27 q11Shape30T28
private theorem q11Shape30T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 8522894344 q11Shape30T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 (8522894344 ||| 2^17) q11Shape30T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (16 ||| 2^17) 8522894344 q11Shape30T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T27OK,q11Shape30T28OK⟩

private def q11Shape30T31 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))))
private theorem q11Shape30T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 65552 8525057032 q11Shape30T31=true := by decide

private def q11Shape30T32 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2162704 8522959880 q11Shape30T32=true := by decide

private def q11Shape30T30 : Tree 11 := .split 21 q11Shape30T31 q11Shape30T32
private theorem q11Shape30T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 65552 8522959880 q11Shape30T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 65552 (8522959880 ||| 2^21) q11Shape30T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (65552 ||| 2^21) 8522959880 q11Shape30T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T31OK,q11Shape30T32OK⟩

private def q11Shape30T33 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape30T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 196624 8522828808 q11Shape30T33=true := by decide

private def q11Shape30T29 : Tree 11 := .split 17 q11Shape30T30 q11Shape30T33
private theorem q11Shape30T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 65552 8522828808 q11Shape30T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 65552 (8522828808 ||| 2^17) q11Shape30T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (65552 ||| 2^17) 8522828808 q11Shape30T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T30OK,q11Shape30T33OK⟩

private def q11Shape30T25 : Tree 11 := .split 16 q11Shape30T26 q11Shape30T29
private theorem q11Shape30T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 8522828808 q11Shape30T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 (8522828808 ||| 2^16) q11Shape30T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (16 ||| 2^16) 8522828808 q11Shape30T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T26OK,q11Shape30T29OK⟩

private def q11Shape30T35 : Tree 11 := (.split 17 (.split 21 (.tip (.cover {0,1,7,8,9,10})) (.split 22 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))) (.tip (.cover {0,5,7,8,9,10})))
private theorem q11Shape30T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2064 8522892296 q11Shape30T35=true := by decide

private def q11Shape30T36 : Tree 11 := (.split 17 (.split 21 (.split 22 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape30T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67600 8522826760 q11Shape30T36=true := by decide

private def q11Shape30T34 : Tree 11 := .split 16 q11Shape30T35 q11Shape30T36
private theorem q11Shape30T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2064 8522826760 q11Shape30T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2064 (8522826760 ||| 2^16) q11Shape30T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (2064 ||| 2^16) 8522826760 q11Shape30T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T35OK,q11Shape30T36OK⟩

private def q11Shape30T24 : Tree 11 := .split 11 q11Shape30T25 q11Shape30T34
private theorem q11Shape30T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 8522826760 q11Shape30T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 (8522826760 ||| 2^11) q11Shape30T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (16 ||| 2^11) 8522826760 q11Shape30T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T25OK,q11Shape30T34OK⟩

private def q11Shape30T41 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))))
private theorem q11Shape30T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 8525121544 q11Shape30T41=true := by decide

private def q11Shape30T42 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2098192 8523024392 q11Shape30T42=true := by decide

private def q11Shape30T40 : Tree 11 := .split 21 q11Shape30T41 q11Shape30T42
private theorem q11Shape30T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 8523024392 q11Shape30T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 (8523024392 ||| 2^21) q11Shape30T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1040 ||| 2^21) 8523024392 q11Shape30T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T41OK,q11Shape30T42OK⟩

private def q11Shape30T43 : Tree 11 := (.split 21 (.split 22 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {2,3,4,5,8,9})))
private theorem q11Shape30T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 132112 8522893320 q11Shape30T43=true := by decide

private def q11Shape30T39 : Tree 11 := .split 17 q11Shape30T40 q11Shape30T43
private theorem q11Shape30T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 8522893320 q11Shape30T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 (8522893320 ||| 2^17) q11Shape30T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1040 ||| 2^17) 8522893320 q11Shape30T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T40OK,q11Shape30T43OK⟩

private def q11Shape30T44 : Tree 11 := (.split 17 (.split 21 (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {0,2,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape30T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 66576 8522827784 q11Shape30T44=true := by decide

private def q11Shape30T38 : Tree 11 := .split 16 q11Shape30T39 q11Shape30T44
private theorem q11Shape30T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 8522827784 q11Shape30T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 (8522827784 ||| 2^16) q11Shape30T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1040 ||| 2^16) 8522827784 q11Shape30T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T39OK,q11Shape30T44OK⟩

private def q11Shape30T45 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape30T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 3088 8522825736 q11Shape30T45=true := by decide

private def q11Shape30T37 : Tree 11 := .split 11 q11Shape30T38 q11Shape30T45
private theorem q11Shape30T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 8522825736 q11Shape30T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1040 (8522825736 ||| 2^11) q11Shape30T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1040 ||| 2^11) 8522825736 q11Shape30T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T38OK,q11Shape30T45OK⟩

private def q11Shape30T23 : Tree 11 := .split 10 q11Shape30T24 q11Shape30T37
private theorem q11Shape30T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 8522825736 q11Shape30T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 (8522825736 ||| 2^10) q11Shape30T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (16 ||| 2^10) 8522825736 q11Shape30T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T24OK,q11Shape30T37OK⟩

def q11Shape30P1 : Tree 11 := q11Shape30T23
theorem q11Shape30P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 16 8522825736 q11Shape30P1=true := q11Shape30T23OK

end Graffiti384b.EffectiveSearch.Q11
