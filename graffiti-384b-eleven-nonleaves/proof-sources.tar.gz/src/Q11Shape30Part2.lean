import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape30T52 : Tree 11 := (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10}))))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 8523025424 q11Shape30T52=true := by decide

private def q11Shape30T54 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))))
private theorem q11Shape30T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 131080 8524991504 q11Shape30T54=true := by decide

private def q11Shape30T55 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2228232 8522894352 q11Shape30T55=true := by decide

private def q11Shape30T53 : Tree 11 := .split 21 q11Shape30T54 q11Shape30T55
private theorem q11Shape30T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 131080 8522894352 q11Shape30T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 131080 (8522894352 ||| 2^21) q11Shape30T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (131080 ||| 2^21) 8522894352 q11Shape30T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T54OK,q11Shape30T55OK⟩

private def q11Shape30T51 : Tree 11 := .split 17 q11Shape30T52 q11Shape30T53
private theorem q11Shape30T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 8522894352 q11Shape30T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 (8522894352 ||| 2^17) q11Shape30T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (8 ||| 2^17) 8522894352 q11Shape30T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T52OK,q11Shape30T53OK⟩

private def q11Shape30T56 : Tree 11 := (.split 17 (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10}))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape30T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 65544 8522828816 q11Shape30T56=true := by decide

private def q11Shape30T50 : Tree 11 := .split 16 q11Shape30T51 q11Shape30T56
private theorem q11Shape30T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 8522828816 q11Shape30T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 (8522828816 ||| 2^16) q11Shape30T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (8 ||| 2^16) 8522828816 q11Shape30T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T51OK,q11Shape30T56OK⟩

private def q11Shape30T60 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10})))) (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))))
private theorem q11Shape30T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2056 8525120528 q11Shape30T60=true := by decide

private def q11Shape30T61 : Tree 11 := (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2099208 8523023376 q11Shape30T61=true := by decide

private def q11Shape30T59 : Tree 11 := .split 21 q11Shape30T60 q11Shape30T61
private theorem q11Shape30T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2056 8523023376 q11Shape30T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2056 (8523023376 ||| 2^21) q11Shape30T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (2056 ||| 2^21) 8523023376 q11Shape30T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T60OK,q11Shape30T61OK⟩

private def q11Shape30T62 : Tree 11 := (.split 21 (.split 22 (.split 33 (.tip (.cover {2,3,4,5,6,10})) (.split 34 (.tip (.cover {2,3,4,5,6,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,2,7,8,9,10}))) (.tip (.cover {2,3,4,5,8,9})))
private theorem q11Shape30T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 133128 8522892304 q11Shape30T62=true := by decide

private def q11Shape30T58 : Tree 11 := .split 17 q11Shape30T59 q11Shape30T62
private theorem q11Shape30T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2056 8522892304 q11Shape30T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2056 (8522892304 ||| 2^17) q11Shape30T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (2056 ||| 2^17) 8522892304 q11Shape30T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T59OK,q11Shape30T62OK⟩

private def q11Shape30T63 : Tree 11 := (.split 17 (.split 21 (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {0,3,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape30T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67592 8522826768 q11Shape30T63=true := by decide

private def q11Shape30T57 : Tree 11 := .split 16 q11Shape30T58 q11Shape30T63
private theorem q11Shape30T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2056 8522826768 q11Shape30T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2056 (8522826768 ||| 2^16) q11Shape30T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (2056 ||| 2^16) 8522826768 q11Shape30T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T58OK,q11Shape30T63OK⟩

private def q11Shape30T49 : Tree 11 := .split 11 q11Shape30T50 q11Shape30T57
private theorem q11Shape30T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 8522826768 q11Shape30T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 (8522826768 ||| 2^11) q11Shape30T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (8 ||| 2^11) 8522826768 q11Shape30T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T50OK,q11Shape30T57OK⟩

private def q11Shape30T67 : Tree 11 := (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10}))))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape30T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1032 8523024400 q11Shape30T67=true := by decide

private def q11Shape30T68 : Tree 11 := (.split 21 (.split 22 (.split 33 (.tip (.cover {2,3,4,5,7,10})) (.split 34 (.tip (.cover {2,3,4,5,7,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {2,3,4,5,8,9}))) (.tip (.cover {0,4,6,8,9,10})))
private theorem q11Shape30T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 132104 8522893328 q11Shape30T68=true := by decide

private def q11Shape30T66 : Tree 11 := .split 17 q11Shape30T67 q11Shape30T68
private theorem q11Shape30T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1032 8522893328 q11Shape30T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1032 (8522893328 ||| 2^17) q11Shape30T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1032 ||| 2^17) 8522893328 q11Shape30T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T67OK,q11Shape30T68OK⟩

private def q11Shape30T69 : Tree 11 := (.split 17 (.tip (.cover {0,5,6,8,9,10})) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape30T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 66568 8522827792 q11Shape30T69=true := by decide

private def q11Shape30T65 : Tree 11 := .split 16 q11Shape30T66 q11Shape30T69
private theorem q11Shape30T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1032 8522827792 q11Shape30T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1032 (8522827792 ||| 2^16) q11Shape30T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1032 ||| 2^16) 8522827792 q11Shape30T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T66OK,q11Shape30T69OK⟩

private def q11Shape30T70 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape30T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 3080 8522825744 q11Shape30T70=true := by decide

private def q11Shape30T64 : Tree 11 := .split 11 q11Shape30T65 q11Shape30T70
private theorem q11Shape30T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1032 8522825744 q11Shape30T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1032 (8522825744 ||| 2^11) q11Shape30T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (1032 ||| 2^11) 8522825744 q11Shape30T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T65OK,q11Shape30T70OK⟩

private def q11Shape30T48 : Tree 11 := .split 10 q11Shape30T49 q11Shape30T64
private theorem q11Shape30T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 8522825744 q11Shape30T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 (8522825744 ||| 2^10) q11Shape30T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (8 ||| 2^10) 8522825744 q11Shape30T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T49OK,q11Shape30T64OK⟩

private def q11Shape30T71 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape30T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 24 8522825728 q11Shape30T71=true := by decide

private def q11Shape30T47 : Tree 11 := .split 4 q11Shape30T48 q11Shape30T71
private theorem q11Shape30T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 8522825728 q11Shape30T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 (8522825728 ||| 2^4) q11Shape30T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) (8 ||| 2^4) 8522825728 q11Shape30T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape30T48OK,q11Shape30T71OK⟩

def q11Shape30P2 : Tree 11 := q11Shape30T47
theorem q11Shape30P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 8 8522825728 q11Shape30P2=true := q11Shape30T47OK

private def q11Shape30T73 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape30T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 4294967296 4227858432 q11Shape30T73=true := by decide

def q11Shape30P3 : Tree 11 := q11Shape30T73
theorem q11Shape30P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 4294967296 4227858432 q11Shape30P3=true := q11Shape30T73OK

private def q11Shape30T75 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape30T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2147483648 2080374784 q11Shape30T75=true := by decide

def q11Shape30P4 : Tree 11 := q11Shape30T75
theorem q11Shape30P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 2147483648 2080374784 q11Shape30P4=true := q11Shape30T75OK

private def q11Shape30T77 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape30T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1073741824 1006632960 q11Shape30T77=true := by decide

def q11Shape30P5 : Tree 11 := q11Shape30T77
theorem q11Shape30P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 1073741824 1006632960 q11Shape30P5=true := q11Shape30T77OK

private def q11Shape30T79 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape30T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 536870912 469762048 q11Shape30T79=true := by decide

def q11Shape30P6 : Tree 11 := q11Shape30T79
theorem q11Shape30P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 536870912 469762048 q11Shape30P6=true := q11Shape30T79OK

private def q11Shape30T81 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape30T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 268435456 201326592 q11Shape30T81=true := by decide

def q11Shape30P7 : Tree 11 := q11Shape30T81
theorem q11Shape30P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 268435456 201326592 q11Shape30P7=true := q11Shape30T81OK

private def q11Shape30T83 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape30T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 134217728 67108864 q11Shape30T83=true := by decide

def q11Shape30P8 : Tree 11 := q11Shape30T83
theorem q11Shape30P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 134217728 67108864 q11Shape30P8=true := q11Shape30T83OK

private def q11Shape30T85 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape30T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67108864 0 q11Shape30T85=true := by decide

def q11Shape30P9 : Tree 11 := q11Shape30T85
theorem q11Shape30P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,5,4⟩) 67108864 0 q11Shape30P9=true := q11Shape30T85OK

end Graffiti384b.EffectiveSearch.Q11
