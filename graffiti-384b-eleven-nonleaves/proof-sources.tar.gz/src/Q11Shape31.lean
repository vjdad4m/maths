import Q11Shape31Part0
import Q11Shape31Part1
import Q11Shape31Part2
import Q11Shape31Part3
import Q11Shape31Part4
import Q11Shape31Part5
import Q11Shape31Part6
import Q11Shape31Part7

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31M44 : Tree 11 := .split 22 q11Shape31P0 q11Shape31P1
private theorem q11Shape31M44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 2326528 q11Shape31M44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 (2326528 ||| 2^22) q11Shape31P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (0 ||| 2^22) 2326528 q11Shape31P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31P0OK,q11Shape31P1OK⟩
private def q11Shape31M82 : Tree 11 := .split 21 q11Shape31M44 q11Shape31P2
private theorem q11Shape31M82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 229376 q11Shape31M82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 (229376 ||| 2^21) q11Shape31M44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (0 ||| 2^21) 229376 q11Shape31P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M44OK,q11Shape31P2OK⟩
private def q11Shape31M120 : Tree 11 := .split 17 q11Shape31M82 q11Shape31P3
private theorem q11Shape31M120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 98304 q11Shape31M120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 (98304 ||| 2^17) q11Shape31M82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (0 ||| 2^17) 98304 q11Shape31P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M82OK,q11Shape31P3OK⟩
private def q11Shape31M169 : Tree 11 := .split 22 q11Shape31P4 q11Shape31P5
private theorem q11Shape31M169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 2260992 q11Shape31M169=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (2260992 ||| 2^22) q11Shape31P4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^22) 2260992 q11Shape31P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31P4OK,q11Shape31P5OK⟩
private def q11Shape31M171 : Tree 11 := .split 21 q11Shape31M169 q11Shape31P6
private theorem q11Shape31M171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 163840 q11Shape31M171=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (163840 ||| 2^21) q11Shape31M169 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^21) 163840 q11Shape31P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M169OK,q11Shape31P6OK⟩
private def q11Shape31M173 : Tree 11 := .split 17 q11Shape31M171 q11Shape31P7
private theorem q11Shape31M173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 32768 q11Shape31M173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (32768 ||| 2^17) q11Shape31M171 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^17) 32768 q11Shape31P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M171OK,q11Shape31P7OK⟩
private def q11Shape31M174 : Tree 11 := .split 16 q11Shape31M120 q11Shape31M173
private theorem q11Shape31M174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 32768 q11Shape31M174=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 (32768 ||| 2^16) q11Shape31M120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (0 ||| 2^16) 32768 q11Shape31M173)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M120OK,q11Shape31M173OK⟩
private def q11Shape31M225 : Tree 11 := .split 33 q11Shape31P8 q11Shape31P9
private theorem q11Shape31M225OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 73596928 q11Shape31M225=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (73596928 ||| 2^33) q11Shape31P8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^33) 73596928 q11Shape31P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31P8OK,q11Shape31P9OK⟩
private def q11Shape31M237 : Tree 11 := .split 26 q11Shape31M225 q11Shape31P10
private theorem q11Shape31M237OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 6488064 q11Shape31M237=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (6488064 ||| 2^26) q11Shape31M225 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^26) 6488064 q11Shape31P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M225OK,q11Shape31P10OK⟩
private def q11Shape31M239 : Tree 11 := .split 22 q11Shape31M237 q11Shape31P11
private theorem q11Shape31M239OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 2293760 q11Shape31M239=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (2293760 ||| 2^22) q11Shape31M237 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^22) 2293760 q11Shape31P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M237OK,q11Shape31P11OK⟩
private def q11Shape31M241 : Tree 11 := .split 21 q11Shape31M239 q11Shape31P12
private theorem q11Shape31M241OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 196608 q11Shape31M241=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (196608 ||| 2^21) q11Shape31M239 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^21) 196608 q11Shape31P12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M239OK,q11Shape31P12OK⟩
private def q11Shape31M243 : Tree 11 := .split 17 q11Shape31M241 q11Shape31P13
private theorem q11Shape31M243OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 65536 q11Shape31M243=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (65536 ||| 2^17) q11Shape31M241 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^17) 65536 q11Shape31P13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M241OK,q11Shape31P13OK⟩
private def q11Shape31M245 : Tree 11 := .split 16 q11Shape31M243 q11Shape31P14
private theorem q11Shape31M245OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 0 q11Shape31M245=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (0 ||| 2^16) q11Shape31M243 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^16) 0 q11Shape31P14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M243OK,q11Shape31P14OK⟩
private def q11Shape31M246 : Tree 11 := .split 15 q11Shape31M174 q11Shape31M245
private theorem q11Shape31M246OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 0 q11Shape31M246=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 (0 ||| 2^15) q11Shape31M174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (0 ||| 2^15) 0 q11Shape31M245)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31M174OK,q11Shape31M245OK⟩

theorem q11Shape31_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 31) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 31) b) (adj 11 (forms 31) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) adj_mono b H q11Shape31M246 q11Shape31M246OK

#print axioms q11Shape31_cover

end Graffiti384b.EffectiveSearch.Q11
