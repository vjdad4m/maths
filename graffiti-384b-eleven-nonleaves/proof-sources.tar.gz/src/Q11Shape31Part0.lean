import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T1 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape31T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 73629696 q11Shape31T1=true := by decide

private def q11Shape31T9 : Tree 11 := (.split 24 (.split 25 (.tip (.cover {0,1,2,3,6,7})) (.split 27 (.split 28 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9})))) (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape31T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 60146286592 q11Shape31T9=true := by decide

private def q11Shape31T10 : Tree 11 := (.split 24 (.split 25 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 75497472 60137897984 q11Shape31T10=true := by decide

private def q11Shape31T8 : Tree 11 := .split 23 q11Shape31T9 q11Shape31T10
private theorem q11Shape31T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 60137897984 q11Shape31T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 (60137897984 ||| 2^23) q11Shape31T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67108864 ||| 2^23) 60137897984 q11Shape31T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T9OK,q11Shape31T10OK⟩

private def q11Shape31T11 : Tree 11 := (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 68157440 60136849408 q11Shape31T11=true := by decide

private def q11Shape31T7 : Tree 11 := .split 20 q11Shape31T8 q11Shape31T11
private theorem q11Shape31T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 60136849408 q11Shape31T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 (60136849408 ||| 2^20) q11Shape31T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67108864 ||| 2^20) 60136849408 q11Shape31T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T8OK,q11Shape31T11OK⟩

private def q11Shape31T12 : Tree 11 := (.split 20 (.split 23 (.split 24 (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape31T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67633152 60136325120 q11Shape31T12=true := by decide

private def q11Shape31T6 : Tree 11 := .split 19 q11Shape31T7 q11Shape31T12
private theorem q11Shape31T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 60136325120 q11Shape31T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 (60136325120 ||| 2^19) q11Shape31T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67108864 ||| 2^19) 60136325120 q11Shape31T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T7OK,q11Shape31T12OK⟩

private def q11Shape31T13 : Tree 11 := (.split 19 (.split 20 (.split 23 (.split 24 (.split 25 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67371008 60136062976 q11Shape31T13=true := by decide

private def q11Shape31T5 : Tree 11 := .split 18 q11Shape31T6 q11Shape31T13
private theorem q11Shape31T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 60136062976 q11Shape31T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 (60136062976 ||| 2^18) q11Shape31T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67108864 ||| 2^18) 60136062976 q11Shape31T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T6OK,q11Shape31T13OK⟩

private def q11Shape31T14 : Tree 11 := (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.split 27 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 34426847232 25776324608 q11Shape31T14=true := by decide

private def q11Shape31T4 : Tree 11 := .split 35 q11Shape31T5 q11Shape31T14
private theorem q11Shape31T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 25776324608 q11Shape31T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 (25776324608 ||| 2^35) q11Shape31T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67108864 ||| 2^35) 25776324608 q11Shape31T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T5OK,q11Shape31T14OK⟩

private def q11Shape31T15 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17246978048 8596455424 q11Shape31T15=true := by decide

private def q11Shape31T3 : Tree 11 := .split 34 q11Shape31T4 q11Shape31T15
private theorem q11Shape31T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 8596455424 q11Shape31T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 (8596455424 ||| 2^34) q11Shape31T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67108864 ||| 2^34) 8596455424 q11Shape31T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T4OK,q11Shape31T15OK⟩

private def q11Shape31T18 : Tree 11 := (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.split 25 (.split 29 (.tip (.cover {0,1,2,3,7,8})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape31T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657043456 51546128384 q11Shape31T18=true := by decide

private def q11Shape31T19 : Tree 11 := (.tip (.cover {0,1,4,5,6,9}))
private theorem q11Shape31T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 43016781824 17186390016 q11Shape31T19=true := by decide

private def q11Shape31T17 : Tree 11 := .split 35 q11Shape31T18 q11Shape31T19
private theorem q11Shape31T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657043456 17186390016 q11Shape31T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657043456 (17186390016 ||| 2^35) q11Shape31T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8657043456 ||| 2^35) 17186390016 q11Shape31T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T18OK,q11Shape31T19OK⟩

private def q11Shape31T20 : Tree 11 := (.tip (.cover {0,1,4,5,6,8}))
private theorem q11Shape31T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 25836912640 6520832 q11Shape31T20=true := by decide

private def q11Shape31T16 : Tree 11 := .split 34 q11Shape31T17 q11Shape31T20
private theorem q11Shape31T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657043456 6520832 q11Shape31T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657043456 (6520832 ||| 2^34) q11Shape31T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8657043456 ||| 2^34) 6520832 q11Shape31T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T17OK,q11Shape31T20OK⟩

private def q11Shape31T2 : Tree 11 := .split 33 q11Shape31T3 q11Shape31T16
private theorem q11Shape31T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 6520832 q11Shape31T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67108864 (6520832 ||| 2^33) q11Shape31T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67108864 ||| 2^33) 6520832 q11Shape31T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T3OK,q11Shape31T16OK⟩

private def q11Shape31T0 : Tree 11 := .split 26 q11Shape31T1 q11Shape31T2
private theorem q11Shape31T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 6520832 q11Shape31T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 (6520832 ||| 2^26) q11Shape31T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (0 ||| 2^26) 6520832 q11Shape31T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T1OK,q11Shape31T2OK⟩

def q11Shape31P0 : Tree 11 := q11Shape31T0
theorem q11Shape31P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 0 6520832 q11Shape31P0=true := q11Shape31T0OK

end Graffiti384b.EffectiveSearch.Q11
