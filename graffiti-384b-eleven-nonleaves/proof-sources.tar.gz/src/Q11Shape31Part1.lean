import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T29 : Tree 11 := (.split 24 (.split 25 (.tip (.cover {0,1,2,3,6,7})) (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9})))) (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,7,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape31T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 60209201152 q11Shape31T29=true := by decide

private def q11Shape31T30 : Tree 11 := (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,2,3,6,7}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 12582912 60200812544 q11Shape31T30=true := by decide

private def q11Shape31T28 : Tree 11 := .split 23 q11Shape31T29 q11Shape31T30
private theorem q11Shape31T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 60200812544 q11Shape31T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (60200812544 ||| 2^23) q11Shape31T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^23) 60200812544 q11Shape31T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T29OK,q11Shape31T30OK⟩

private def q11Shape31T31 : Tree 11 := (.split 23 (.split 24 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 5242880 60199763968 q11Shape31T31=true := by decide

private def q11Shape31T27 : Tree 11 := .split 20 q11Shape31T28 q11Shape31T31
private theorem q11Shape31T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 60199763968 q11Shape31T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (60199763968 ||| 2^20) q11Shape31T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^20) 60199763968 q11Shape31T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T28OK,q11Shape31T31OK⟩

private def q11Shape31T32 : Tree 11 := (.split 20 (.split 23 (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,7,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape31T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4718592 60199239680 q11Shape31T32=true := by decide

private def q11Shape31T26 : Tree 11 := .split 19 q11Shape31T27 q11Shape31T32
private theorem q11Shape31T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 60199239680 q11Shape31T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (60199239680 ||| 2^19) q11Shape31T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^19) 60199239680 q11Shape31T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T27OK,q11Shape31T32OK⟩

private def q11Shape31T33 : Tree 11 := (.split 19 (.split 20 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4456448 60198977536 q11Shape31T33=true := by decide

private def q11Shape31T25 : Tree 11 := .split 18 q11Shape31T26 q11Shape31T33
private theorem q11Shape31T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 60198977536 q11Shape31T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (60198977536 ||| 2^18) q11Shape31T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^18) 60198977536 q11Shape31T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T26OK,q11Shape31T33OK⟩

private def q11Shape31T34 : Tree 11 := (.split 18 (.split 19 (.split 20 (.split 23 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 34363932672 25839239168 q11Shape31T34=true := by decide

private def q11Shape31T24 : Tree 11 := .split 35 q11Shape31T25 q11Shape31T34
private theorem q11Shape31T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 25839239168 q11Shape31T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (25839239168 ||| 2^35) q11Shape31T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^35) 25839239168 q11Shape31T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T25OK,q11Shape31T34OK⟩

private def q11Shape31T35 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 24 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17184063488 8659369984 q11Shape31T35=true := by decide

private def q11Shape31T23 : Tree 11 := .split 34 q11Shape31T24 q11Shape31T35
private theorem q11Shape31T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 8659369984 q11Shape31T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (8659369984 ||| 2^34) q11Shape31T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^34) 8659369984 q11Shape31T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T24OK,q11Shape31T35OK⟩

private def q11Shape31T37 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,7,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8594128896 17249304576 q11Shape31T37=true := by decide

private def q11Shape31T38 : Tree 11 := (.tip (.cover {0,1,4,5,6,8}))
private theorem q11Shape31T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 25773998080 69435392 q11Shape31T38=true := by decide

private def q11Shape31T36 : Tree 11 := .split 34 q11Shape31T37 q11Shape31T38
private theorem q11Shape31T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8594128896 69435392 q11Shape31T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8594128896 (69435392 ||| 2^34) q11Shape31T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8594128896 ||| 2^34) 69435392 q11Shape31T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T37OK,q11Shape31T38OK⟩

private def q11Shape31T22 : Tree 11 := .split 33 q11Shape31T23 q11Shape31T36
private theorem q11Shape31T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 69435392 q11Shape31T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (69435392 ||| 2^33) q11Shape31T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^33) 69435392 q11Shape31T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T23OK,q11Shape31T36OK⟩

private def q11Shape31T41 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 30 (.split 31 (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,9})))
private theorem q11Shape31T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 71303168 25772130304 q11Shape31T41=true := by decide

private def q11Shape31T42 : Tree 11 := (.tip (.cover {0,1,4,7,8,9}))
private theorem q11Shape31T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17251172352 8592261120 q11Shape31T42=true := by decide

private def q11Shape31T40 : Tree 11 := .split 34 q11Shape31T41 q11Shape31T42
private theorem q11Shape31T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 71303168 8592261120 q11Shape31T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 71303168 (8592261120 ||| 2^34) q11Shape31T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (71303168 ||| 2^34) 8592261120 q11Shape31T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T41OK,q11Shape31T42OK⟩

private def q11Shape31T43 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape31T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8661237760 2326528 q11Shape31T43=true := by decide

private def q11Shape31T39 : Tree 11 := .split 33 q11Shape31T40 q11Shape31T43
private theorem q11Shape31T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 71303168 2326528 q11Shape31T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 71303168 (2326528 ||| 2^33) q11Shape31T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (71303168 ||| 2^33) 2326528 q11Shape31T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T40OK,q11Shape31T43OK⟩

private def q11Shape31T21 : Tree 11 := .split 26 q11Shape31T22 q11Shape31T39
private theorem q11Shape31T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 2326528 q11Shape31T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 (2326528 ||| 2^26) q11Shape31T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4194304 ||| 2^26) 2326528 q11Shape31T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T22OK,q11Shape31T39OK⟩

def q11Shape31P1 : Tree 11 := q11Shape31T21
theorem q11Shape31P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4194304 2326528 q11Shape31P1=true := q11Shape31T21OK

end Graffiti384b.EffectiveSearch.Q11
