import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T54 : Tree 11 := (.split 24 (.split 25 (.tip (.cover {0,1,2,3,6,7})) (.split 27 (.split 28 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))) (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,5,7,8}))))
private theorem q11Shape31T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 60211298304 q11Shape31T54=true := by decide

private def q11Shape31T55 : Tree 11 := (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape31T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 10485760 60202909696 q11Shape31T55=true := by decide

private def q11Shape31T53 : Tree 11 := .split 23 q11Shape31T54 q11Shape31T55
private theorem q11Shape31T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 60202909696 q11Shape31T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (60202909696 ||| 2^23) q11Shape31T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^23) 60202909696 q11Shape31T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T54OK,q11Shape31T55OK⟩

private def q11Shape31T56 : Tree 11 := (.split 23 (.split 24 (.split 27 (.split 28 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,9})))
private theorem q11Shape31T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 3145728 60201861120 q11Shape31T56=true := by decide

private def q11Shape31T52 : Tree 11 := .split 20 q11Shape31T53 q11Shape31T56
private theorem q11Shape31T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 60201861120 q11Shape31T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (60201861120 ||| 2^20) q11Shape31T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^20) 60201861120 q11Shape31T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T53OK,q11Shape31T56OK⟩

private def q11Shape31T57 : Tree 11 := (.split 20 (.split 23 (.split 25 (.split 27 (.split 29 (.split 30 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,5,7,8})))
private theorem q11Shape31T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2621440 60201336832 q11Shape31T57=true := by decide

private def q11Shape31T51 : Tree 11 := .split 19 q11Shape31T52 q11Shape31T57
private theorem q11Shape31T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 60201336832 q11Shape31T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (60201336832 ||| 2^19) q11Shape31T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^19) 60201336832 q11Shape31T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T52OK,q11Shape31T57OK⟩

private def q11Shape31T60 : Tree 11 := (.split 24 (.split 25 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape31T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2359296 60202647552 q11Shape31T60=true := by decide

private def q11Shape31T61 : Tree 11 := (.tip (.cover {0,1,4,5,7,9}))
private theorem q11Shape31T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 3407872 60201598976 q11Shape31T61=true := by decide

private def q11Shape31T59 : Tree 11 := .split 20 q11Shape31T60 q11Shape31T61
private theorem q11Shape31T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2359296 60201598976 q11Shape31T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2359296 (60201598976 ||| 2^20) q11Shape31T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2359296 ||| 2^20) 60201598976 q11Shape31T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T60OK,q11Shape31T61OK⟩

private def q11Shape31T62 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape31T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2883584 60201074688 q11Shape31T62=true := by decide

private def q11Shape31T58 : Tree 11 := .split 19 q11Shape31T59 q11Shape31T62
private theorem q11Shape31T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2359296 60201074688 q11Shape31T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2359296 (60201074688 ||| 2^19) q11Shape31T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2359296 ||| 2^19) 60201074688 q11Shape31T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T59OK,q11Shape31T62OK⟩

private def q11Shape31T50 : Tree 11 := .split 18 q11Shape31T51 q11Shape31T58
private theorem q11Shape31T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 60201074688 q11Shape31T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (60201074688 ||| 2^18) q11Shape31T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^18) 60201074688 q11Shape31T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T51OK,q11Shape31T58OK⟩

private def q11Shape31T63 : Tree 11 := (.split 18 (.split 19 (.split 20 (.split 23 (.split 27 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,9})))
private theorem q11Shape31T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 34361835520 25841336320 q11Shape31T63=true := by decide

private def q11Shape31T49 : Tree 11 := .split 35 q11Shape31T50 q11Shape31T63
private theorem q11Shape31T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 25841336320 q11Shape31T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (25841336320 ||| 2^35) q11Shape31T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^35) 25841336320 q11Shape31T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T50OK,q11Shape31T63OK⟩

private def q11Shape31T65 : Tree 11 := (.split 18 (.split 19 (.split 20 (.split 24 (.split 28 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,5,7,8,9})))
private theorem q11Shape31T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17181966336 43021205504 q11Shape31T65=true := by decide

private def q11Shape31T66 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape31T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 51541704704 8661467136 q11Shape31T66=true := by decide

private def q11Shape31T64 : Tree 11 := .split 35 q11Shape31T65 q11Shape31T66
private theorem q11Shape31T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17181966336 8661467136 q11Shape31T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17181966336 (8661467136 ||| 2^35) q11Shape31T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (17181966336 ||| 2^35) 8661467136 q11Shape31T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T65OK,q11Shape31T66OK⟩

private def q11Shape31T48 : Tree 11 := .split 34 q11Shape31T49 q11Shape31T64
private theorem q11Shape31T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 8661467136 q11Shape31T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (8661467136 ||| 2^34) q11Shape31T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^34) 8661467136 q11Shape31T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T49OK,q11Shape31T64OK⟩

private def q11Shape31T69 : Tree 11 := (.split 18 (.split 19 (.split 20 (.split 25 (.split 29 (.split 30 (.split 32 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,10})))
private theorem q11Shape31T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8592031744 51611140096 q11Shape31T69=true := by decide

private def q11Shape31T70 : Tree 11 := (.tip (.cover {0,1,4,5,7,9}))
private theorem q11Shape31T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 42951770112 17251401728 q11Shape31T70=true := by decide

private def q11Shape31T68 : Tree 11 := .split 35 q11Shape31T69 q11Shape31T70
private theorem q11Shape31T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8592031744 17251401728 q11Shape31T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8592031744 (17251401728 ||| 2^35) q11Shape31T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8592031744 ||| 2^35) 17251401728 q11Shape31T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T69OK,q11Shape31T70OK⟩

private def q11Shape31T71 : Tree 11 := (.tip (.cover {0,1,4,5,7,8}))
private theorem q11Shape31T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 25771900928 71532544 q11Shape31T71=true := by decide

private def q11Shape31T67 : Tree 11 := .split 34 q11Shape31T68 q11Shape31T71
private theorem q11Shape31T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8592031744 71532544 q11Shape31T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8592031744 (71532544 ||| 2^34) q11Shape31T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8592031744 ||| 2^34) 71532544 q11Shape31T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T68OK,q11Shape31T71OK⟩

private def q11Shape31T47 : Tree 11 := .split 33 q11Shape31T48 q11Shape31T67
private theorem q11Shape31T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 71532544 q11Shape31T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (71532544 ||| 2^33) q11Shape31T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^33) 71532544 q11Shape31T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T48OK,q11Shape31T67OK⟩

private def q11Shape31T74 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,5,7})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,9})))
private theorem q11Shape31T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 69206016 25774227456 q11Shape31T74=true := by decide

private def q11Shape31T75 : Tree 11 := (.tip (.cover {0,1,4,6,8,9}))
private theorem q11Shape31T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17249075200 8594358272 q11Shape31T75=true := by decide

private def q11Shape31T73 : Tree 11 := .split 34 q11Shape31T74 q11Shape31T75
private theorem q11Shape31T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 69206016 8594358272 q11Shape31T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 69206016 (8594358272 ||| 2^34) q11Shape31T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (69206016 ||| 2^34) 8594358272 q11Shape31T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T74OK,q11Shape31T75OK⟩

private def q11Shape31T76 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape31T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8659140608 4423680 q11Shape31T76=true := by decide

private def q11Shape31T72 : Tree 11 := .split 33 q11Shape31T73 q11Shape31T76
private theorem q11Shape31T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 69206016 4423680 q11Shape31T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 69206016 (4423680 ||| 2^33) q11Shape31T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (69206016 ||| 2^33) 4423680 q11Shape31T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T73OK,q11Shape31T76OK⟩

private def q11Shape31T46 : Tree 11 := .split 26 q11Shape31T47 q11Shape31T72
private theorem q11Shape31T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 4423680 q11Shape31T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (4423680 ||| 2^26) q11Shape31T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^26) 4423680 q11Shape31T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T47OK,q11Shape31T72OK⟩

private def q11Shape31T79 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9})))
private theorem q11Shape31T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 6291456 25770033152 q11Shape31T79=true := by decide

private def q11Shape31T80 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape31T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17186160640 8590163968 q11Shape31T80=true := by decide

private def q11Shape31T78 : Tree 11 := .split 34 q11Shape31T79 q11Shape31T80
private theorem q11Shape31T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 6291456 8590163968 q11Shape31T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 6291456 (8590163968 ||| 2^34) q11Shape31T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (6291456 ||| 2^34) 8590163968 q11Shape31T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T79OK,q11Shape31T80OK⟩

private def q11Shape31T81 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape31T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8596226048 229376 q11Shape31T81=true := by decide

private def q11Shape31T77 : Tree 11 := .split 33 q11Shape31T78 q11Shape31T81
private theorem q11Shape31T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 6291456 229376 q11Shape31T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 6291456 (229376 ||| 2^33) q11Shape31T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (6291456 ||| 2^33) 229376 q11Shape31T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T78OK,q11Shape31T81OK⟩

private def q11Shape31T45 : Tree 11 := .split 22 q11Shape31T46 q11Shape31T77
private theorem q11Shape31T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 229376 q11Shape31T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 (229376 ||| 2^22) q11Shape31T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2097152 ||| 2^22) 229376 q11Shape31T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T46OK,q11Shape31T77OK⟩

def q11Shape31P2 : Tree 11 := q11Shape31T45
theorem q11Shape31P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2097152 229376 q11Shape31P2=true := q11Shape31T45OK

end Graffiti384b.EffectiveSearch.Q11
