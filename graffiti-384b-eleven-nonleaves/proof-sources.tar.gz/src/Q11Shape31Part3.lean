import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T93 : Tree 11 := (.split 24 (.split 25 (.tip (.cover {0,1,2,3,6,7})) (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9})))) (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,7,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape31T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 60213264384 q11Shape31T93=true := by decide

private def q11Shape31T94 : Tree 11 := (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8519680 60204875776 q11Shape31T94=true := by decide

private def q11Shape31T92 : Tree 11 := .split 23 q11Shape31T93 q11Shape31T94
private theorem q11Shape31T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 60204875776 q11Shape31T92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (60204875776 ||| 2^23) q11Shape31T93 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^23) 60204875776 q11Shape31T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T93OK,q11Shape31T94OK⟩

private def q11Shape31T95 : Tree 11 := (.split 23 (.split 24 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1179648 60203827200 q11Shape31T95=true := by decide

private def q11Shape31T91 : Tree 11 := .split 20 q11Shape31T92 q11Shape31T95
private theorem q11Shape31T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 60203827200 q11Shape31T91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (60203827200 ||| 2^20) q11Shape31T92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^20) 60203827200 q11Shape31T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T92OK,q11Shape31T95OK⟩

private def q11Shape31T96 : Tree 11 := (.split 20 (.split 23 (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,7,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape31T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 655360 60203302912 q11Shape31T96=true := by decide

private def q11Shape31T90 : Tree 11 := .split 19 q11Shape31T91 q11Shape31T96
private theorem q11Shape31T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 60203302912 q11Shape31T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (60203302912 ||| 2^19) q11Shape31T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^19) 60203302912 q11Shape31T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T91OK,q11Shape31T96OK⟩

private def q11Shape31T97 : Tree 11 := (.split 19 (.split 20 (.split 24 (.split 25 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,7,8})) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 393216 60203040768 q11Shape31T97=true := by decide

private def q11Shape31T89 : Tree 11 := .split 18 q11Shape31T90 q11Shape31T97
private theorem q11Shape31T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 60203040768 q11Shape31T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (60203040768 ||| 2^18) q11Shape31T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^18) 60203040768 q11Shape31T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T90OK,q11Shape31T97OK⟩

private def q11Shape31T98 : Tree 11 := (.split 18 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 34359869440 25843302400 q11Shape31T98=true := by decide

private def q11Shape31T88 : Tree 11 := .split 35 q11Shape31T89 q11Shape31T98
private theorem q11Shape31T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 25843302400 q11Shape31T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (25843302400 ||| 2^35) q11Shape31T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^35) 25843302400 q11Shape31T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T89OK,q11Shape31T98OK⟩

private def q11Shape31T99 : Tree 11 := (.split 35 (.split 19 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,7,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape31T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17180000256 8663433216 q11Shape31T99=true := by decide

private def q11Shape31T87 : Tree 11 := .split 34 q11Shape31T88 q11Shape31T99
private theorem q11Shape31T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 8663433216 q11Shape31T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (8663433216 ||| 2^34) q11Shape31T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^34) 8663433216 q11Shape31T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T88OK,q11Shape31T99OK⟩

private def q11Shape31T101 : Tree 11 := (.split 35 (.split 20 (.split 23 (.split 24 (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,7,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape31T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590065664 17253367808 q11Shape31T101=true := by decide

private def q11Shape31T102 : Tree 11 := (.tip (.cover {0,1,4,5,6,8}))
private theorem q11Shape31T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 25769934848 73498624 q11Shape31T102=true := by decide

private def q11Shape31T100 : Tree 11 := .split 34 q11Shape31T101 q11Shape31T102
private theorem q11Shape31T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590065664 73498624 q11Shape31T100=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590065664 (73498624 ||| 2^34) q11Shape31T101 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8590065664 ||| 2^34) 73498624 q11Shape31T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T101OK,q11Shape31T102OK⟩

private def q11Shape31T86 : Tree 11 := .split 33 q11Shape31T87 q11Shape31T100
private theorem q11Shape31T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 73498624 q11Shape31T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (73498624 ||| 2^33) q11Shape31T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^33) 73498624 q11Shape31T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T87OK,q11Shape31T100OK⟩

private def q11Shape31T105 : Tree 11 := (.split 35 (.split 23 (.split 24 (.split 25 (.split 30 (.split 31 (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9})))
private theorem q11Shape31T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67239936 25776193536 q11Shape31T105=true := by decide

private def q11Shape31T106 : Tree 11 := (.tip (.cover {0,1,5,7,8,9}))
private theorem q11Shape31T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17247109120 8596324352 q11Shape31T106=true := by decide

private def q11Shape31T104 : Tree 11 := .split 34 q11Shape31T105 q11Shape31T106
private theorem q11Shape31T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67239936 8596324352 q11Shape31T104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67239936 (8596324352 ||| 2^34) q11Shape31T105 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67239936 ||| 2^34) 8596324352 q11Shape31T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T105OK,q11Shape31T106OK⟩

private def q11Shape31T107 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape31T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657174528 6389760 q11Shape31T107=true := by decide

private def q11Shape31T103 : Tree 11 := .split 33 q11Shape31T104 q11Shape31T107
private theorem q11Shape31T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67239936 6389760 q11Shape31T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67239936 (6389760 ||| 2^33) q11Shape31T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67239936 ||| 2^33) 6389760 q11Shape31T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T104OK,q11Shape31T107OK⟩

private def q11Shape31T85 : Tree 11 := .split 26 q11Shape31T86 q11Shape31T103
private theorem q11Shape31T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 6389760 q11Shape31T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (6389760 ||| 2^26) q11Shape31T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^26) 6389760 q11Shape31T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T86OK,q11Shape31T103OK⟩

private def q11Shape31T111 : Tree 11 := (.split 35 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,9})))
private theorem q11Shape31T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4325376 25839108096 q11Shape31T111=true := by decide

private def q11Shape31T112 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape31T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17184194560 8659238912 q11Shape31T112=true := by decide

private def q11Shape31T110 : Tree 11 := .split 34 q11Shape31T111 q11Shape31T112
private theorem q11Shape31T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4325376 8659238912 q11Shape31T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4325376 (8659238912 ||| 2^34) q11Shape31T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4325376 ||| 2^34) 8659238912 q11Shape31T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T111OK,q11Shape31T112OK⟩

private def q11Shape31T113 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape31T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8594259968 69304320 q11Shape31T113=true := by decide

private def q11Shape31T109 : Tree 11 := .split 33 q11Shape31T110 q11Shape31T113
private theorem q11Shape31T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4325376 69304320 q11Shape31T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4325376 (69304320 ||| 2^33) q11Shape31T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4325376 ||| 2^33) 69304320 q11Shape31T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T110OK,q11Shape31T113OK⟩

private def q11Shape31T114 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape31T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 71434240 2195456 q11Shape31T114=true := by decide

private def q11Shape31T108 : Tree 11 := .split 26 q11Shape31T109 q11Shape31T114
private theorem q11Shape31T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4325376 2195456 q11Shape31T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4325376 (2195456 ||| 2^26) q11Shape31T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4325376 ||| 2^26) 2195456 q11Shape31T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T109OK,q11Shape31T114OK⟩

private def q11Shape31T84 : Tree 11 := .split 22 q11Shape31T85 q11Shape31T108
private theorem q11Shape31T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 2195456 q11Shape31T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (2195456 ||| 2^22) q11Shape31T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^22) 2195456 q11Shape31T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T85OK,q11Shape31T108OK⟩

private def q11Shape31T117 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9})))
private theorem q11Shape31T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2228224 25769902080 q11Shape31T117=true := by decide

private def q11Shape31T118 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape31T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17182097408 8590032896 q11Shape31T118=true := by decide

private def q11Shape31T116 : Tree 11 := .split 34 q11Shape31T117 q11Shape31T118
private theorem q11Shape31T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2228224 8590032896 q11Shape31T116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2228224 (8590032896 ||| 2^34) q11Shape31T117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2228224 ||| 2^34) 8590032896 q11Shape31T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T117OK,q11Shape31T118OK⟩

private def q11Shape31T119 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape31T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8592162816 98304 q11Shape31T119=true := by decide

private def q11Shape31T115 : Tree 11 := .split 33 q11Shape31T116 q11Shape31T119
private theorem q11Shape31T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2228224 98304 q11Shape31T115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2228224 (98304 ||| 2^33) q11Shape31T116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (2228224 ||| 2^33) 98304 q11Shape31T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T116OK,q11Shape31T119OK⟩

private def q11Shape31T83 : Tree 11 := .split 21 q11Shape31T84 q11Shape31T115
private theorem q11Shape31T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 98304 q11Shape31T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 (98304 ||| 2^21) q11Shape31T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (131072 ||| 2^21) 98304 q11Shape31T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T84OK,q11Shape31T115OK⟩

def q11Shape31P3 : Tree 11 := q11Shape31T83
theorem q11Shape31P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 131072 98304 q11Shape31P3=true := q11Shape31T83OK

end Graffiti384b.EffectiveSearch.Q11
