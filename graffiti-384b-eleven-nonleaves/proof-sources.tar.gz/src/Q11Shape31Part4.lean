import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T130 : Tree 11 := (.split 25 (.tip (.cover {0,1,2,3,6,7})) (.split 27 (.split 28 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9}))))
private theorem q11Shape31T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 60230107136 q11Shape31T130=true := by decide

private def q11Shape31T131 : Tree 11 := (.split 25 (.split 27 (.split 29 (.split 30 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,7,8})))
private theorem q11Shape31T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 16842752 60213329920 q11Shape31T131=true := by decide

private def q11Shape31T129 : Tree 11 := .split 24 q11Shape31T130 q11Shape31T131
private theorem q11Shape31T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 60213329920 q11Shape31T129=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (60213329920 ||| 2^24) q11Shape31T130 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^24) 60213329920 q11Shape31T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T130OK,q11Shape31T131OK⟩

private def q11Shape31T132 : Tree 11 := (.split 24 (.split 25 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape31T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8454144 60204941312 q11Shape31T132=true := by decide

private def q11Shape31T128 : Tree 11 := .split 23 q11Shape31T129 q11Shape31T132
private theorem q11Shape31T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 60204941312 q11Shape31T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (60204941312 ||| 2^23) q11Shape31T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^23) 60204941312 q11Shape31T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T129OK,q11Shape31T132OK⟩

private def q11Shape31T134 : Tree 11 := (.split 24 (.split 27 (.split 28 (.split 25 (.tip (.cover {0,1,2,3,4,7})) (.split 29 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,7,8,9,10})))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,5,7,8})))
private theorem q11Shape31T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1114112 60212281344 q11Shape31T134=true := by decide

private def q11Shape31T135 : Tree 11 := (.tip (.cover {0,1,4,5,7,9}))
private theorem q11Shape31T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 9502720 60203892736 q11Shape31T135=true := by decide

private def q11Shape31T133 : Tree 11 := .split 23 q11Shape31T134 q11Shape31T135
private theorem q11Shape31T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1114112 60203892736 q11Shape31T133=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1114112 (60203892736 ||| 2^23) q11Shape31T134 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (1114112 ||| 2^23) 60203892736 q11Shape31T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T134OK,q11Shape31T135OK⟩

private def q11Shape31T127 : Tree 11 := .split 20 q11Shape31T128 q11Shape31T133
private theorem q11Shape31T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 60203892736 q11Shape31T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (60203892736 ||| 2^20) q11Shape31T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^20) 60203892736 q11Shape31T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T128OK,q11Shape31T133OK⟩

private def q11Shape31T138 : Tree 11 := (.split 25 (.split 27 (.split 28 (.split 29 (.split 24 (.tip (.cover {0,1,2,3,4,7})) (.split 30 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,10})))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,5,7,8})))
private theorem q11Shape31T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 589824 60212805632 q11Shape31T138=true := by decide

private def q11Shape31T139 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape31T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8978432 60204417024 q11Shape31T139=true := by decide

private def q11Shape31T137 : Tree 11 := .split 23 q11Shape31T138 q11Shape31T139
private theorem q11Shape31T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 589824 60204417024 q11Shape31T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 589824 (60204417024 ||| 2^23) q11Shape31T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (589824 ||| 2^23) 60204417024 q11Shape31T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T138OK,q11Shape31T139OK⟩

private def q11Shape31T140 : Tree 11 := (.tip (.cover {0,1,4,5,7,8}))
private theorem q11Shape31T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1638400 60203368448 q11Shape31T140=true := by decide

private def q11Shape31T136 : Tree 11 := .split 20 q11Shape31T137 q11Shape31T140
private theorem q11Shape31T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 589824 60203368448 q11Shape31T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 589824 (60203368448 ||| 2^20) q11Shape31T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (589824 ||| 2^20) 60203368448 q11Shape31T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T137OK,q11Shape31T140OK⟩

private def q11Shape31T126 : Tree 11 := .split 19 q11Shape31T127 q11Shape31T136
private theorem q11Shape31T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 60203368448 q11Shape31T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (60203368448 ||| 2^19) q11Shape31T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^19) 60203368448 q11Shape31T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T127OK,q11Shape31T136OK⟩

private def q11Shape31T145 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 23 (.tip (.cover {0,1,2,3,4,7})) (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape31T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 60255010816 q11Shape31T145=true := by decide

private def q11Shape31T146 : Tree 11 := (.tip (.cover {0,1,4,5,7,9}))
private theorem q11Shape31T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 33882112 60221456384 q11Shape31T146=true := by decide

private def q11Shape31T144 : Tree 11 := .split 25 q11Shape31T145 q11Shape31T146
private theorem q11Shape31T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 60221456384 q11Shape31T144=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 (60221456384 ||| 2^25) q11Shape31T145 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (327680 ||| 2^25) 60221456384 q11Shape31T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T145OK,q11Shape31T146OK⟩

private def q11Shape31T147 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape31T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17104896 60204679168 q11Shape31T147=true := by decide

private def q11Shape31T143 : Tree 11 := .split 24 q11Shape31T144 q11Shape31T147
private theorem q11Shape31T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 60204679168 q11Shape31T143=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 (60204679168 ||| 2^24) q11Shape31T144 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (327680 ||| 2^24) 60204679168 q11Shape31T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T144OK,q11Shape31T147OK⟩

private def q11Shape31T148 : Tree 11 := (.tip (.cover {0,1,4,5,7,9}))
private theorem q11Shape31T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1376256 60203630592 q11Shape31T148=true := by decide

private def q11Shape31T142 : Tree 11 := .split 20 q11Shape31T143 q11Shape31T148
private theorem q11Shape31T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 60203630592 q11Shape31T142=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 (60203630592 ||| 2^20) q11Shape31T143 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (327680 ||| 2^20) 60203630592 q11Shape31T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T143OK,q11Shape31T148OK⟩

private def q11Shape31T149 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape31T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 851968 60203106304 q11Shape31T149=true := by decide

private def q11Shape31T141 : Tree 11 := .split 19 q11Shape31T142 q11Shape31T149
private theorem q11Shape31T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 60203106304 q11Shape31T141=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 327680 (60203106304 ||| 2^19) q11Shape31T142 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (327680 ||| 2^19) 60203106304 q11Shape31T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T142OK,q11Shape31T149OK⟩

private def q11Shape31T125 : Tree 11 := .split 18 q11Shape31T126 q11Shape31T141
private theorem q11Shape31T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 60203106304 q11Shape31T125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (60203106304 ||| 2^18) q11Shape31T126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^18) 60203106304 q11Shape31T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T126OK,q11Shape31T141OK⟩

private def q11Shape31T150 : Tree 11 := (.split 18 (.split 23 (.split 24 (.split 25 (.split 27 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,9})))
private theorem q11Shape31T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 34359803904 25843367936 q11Shape31T150=true := by decide

private def q11Shape31T124 : Tree 11 := .split 35 q11Shape31T125 q11Shape31T150
private theorem q11Shape31T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 25843367936 q11Shape31T124=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (25843367936 ||| 2^35) q11Shape31T125 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^35) 25843367936 q11Shape31T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T125OK,q11Shape31T150OK⟩

private def q11Shape31T152 : Tree 11 := (.split 19 (.split 23 (.split 24 (.split 25 (.split 28 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,5,7,8})))
private theorem q11Shape31T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17179934720 43023237120 q11Shape31T152=true := by decide

private def q11Shape31T153 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape31T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 51539673088 8663498752 q11Shape31T153=true := by decide

private def q11Shape31T151 : Tree 11 := .split 35 q11Shape31T152 q11Shape31T153
private theorem q11Shape31T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17179934720 8663498752 q11Shape31T151=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17179934720 (8663498752 ||| 2^35) q11Shape31T152 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (17179934720 ||| 2^35) 8663498752 q11Shape31T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T152OK,q11Shape31T153OK⟩

private def q11Shape31T123 : Tree 11 := .split 34 q11Shape31T124 q11Shape31T151
private theorem q11Shape31T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 8663498752 q11Shape31T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (8663498752 ||| 2^34) q11Shape31T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^34) 8663498752 q11Shape31T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T124OK,q11Shape31T151OK⟩

private def q11Shape31T156 : Tree 11 := (.split 20 (.split 23 (.split 24 (.split 25 (.split 29 (.split 30 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,5,7,8})))
private theorem q11Shape31T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590000128 51613171712 q11Shape31T156=true := by decide

private def q11Shape31T157 : Tree 11 := (.tip (.cover {0,1,4,5,7,9}))
private theorem q11Shape31T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 42949738496 17253433344 q11Shape31T157=true := by decide

private def q11Shape31T155 : Tree 11 := .split 35 q11Shape31T156 q11Shape31T157
private theorem q11Shape31T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590000128 17253433344 q11Shape31T155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590000128 (17253433344 ||| 2^35) q11Shape31T156 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8590000128 ||| 2^35) 17253433344 q11Shape31T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T156OK,q11Shape31T157OK⟩

private def q11Shape31T158 : Tree 11 := (.tip (.cover {0,1,4,5,7,8}))
private theorem q11Shape31T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 25769869312 73564160 q11Shape31T158=true := by decide

private def q11Shape31T154 : Tree 11 := .split 34 q11Shape31T155 q11Shape31T158
private theorem q11Shape31T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590000128 73564160 q11Shape31T154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8590000128 (73564160 ||| 2^34) q11Shape31T155 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8590000128 ||| 2^34) 73564160 q11Shape31T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T155OK,q11Shape31T158OK⟩

private def q11Shape31T122 : Tree 11 := .split 33 q11Shape31T123 q11Shape31T154
private theorem q11Shape31T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 73564160 q11Shape31T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (73564160 ||| 2^33) q11Shape31T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^33) 73564160 q11Shape31T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T123OK,q11Shape31T154OK⟩

private def q11Shape31T161 : Tree 11 := (.split 35 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,5,7})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9})))
private theorem q11Shape31T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67174400 25776259072 q11Shape31T161=true := by decide

private def q11Shape31T162 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape31T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17247043584 8596389888 q11Shape31T162=true := by decide

private def q11Shape31T160 : Tree 11 := .split 34 q11Shape31T161 q11Shape31T162
private theorem q11Shape31T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67174400 8596389888 q11Shape31T160=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67174400 (8596389888 ||| 2^34) q11Shape31T161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67174400 ||| 2^34) 8596389888 q11Shape31T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T161OK,q11Shape31T162OK⟩

private def q11Shape31T163 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape31T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657108992 6455296 q11Shape31T163=true := by decide

private def q11Shape31T159 : Tree 11 := .split 33 q11Shape31T160 q11Shape31T163
private theorem q11Shape31T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67174400 6455296 q11Shape31T159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67174400 (6455296 ||| 2^33) q11Shape31T160 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67174400 ||| 2^33) 6455296 q11Shape31T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T160OK,q11Shape31T163OK⟩

private def q11Shape31T121 : Tree 11 := .split 26 q11Shape31T122 q11Shape31T159
private theorem q11Shape31T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 6455296 q11Shape31T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 (6455296 ||| 2^26) q11Shape31T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (65536 ||| 2^26) 6455296 q11Shape31T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T122OK,q11Shape31T159OK⟩

def q11Shape31P4 : Tree 11 := q11Shape31T121
theorem q11Shape31P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 65536 6455296 q11Shape31P4=true := q11Shape31T121OK

end Graffiti384b.EffectiveSearch.Q11
