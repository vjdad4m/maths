import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T166 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,6,7})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9})))
private theorem q11Shape31T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4259840 25772064768 q11Shape31T166=true := by decide

private def q11Shape31T167 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape31T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17184129024 8592195584 q11Shape31T167=true := by decide

private def q11Shape31T165 : Tree 11 := .split 34 q11Shape31T166 q11Shape31T167
private theorem q11Shape31T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4259840 8592195584 q11Shape31T165=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4259840 (8592195584 ||| 2^34) q11Shape31T166 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4259840 ||| 2^34) 8592195584 q11Shape31T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T166OK,q11Shape31T167OK⟩

private def q11Shape31T168 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape31T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8594194432 2260992 q11Shape31T168=true := by decide

private def q11Shape31T164 : Tree 11 := .split 33 q11Shape31T165 q11Shape31T168
private theorem q11Shape31T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4259840 2260992 q11Shape31T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4259840 (2260992 ||| 2^33) q11Shape31T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (4259840 ||| 2^33) 2260992 q11Shape31T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T165OK,q11Shape31T168OK⟩

def q11Shape31P5 : Tree 11 := q11Shape31T164
theorem q11Shape31P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4259840 2260992 q11Shape31P5=true := q11Shape31T164OK

private def q11Shape31T170 : Tree 11 := (.split 26 (.split 33 (.split 34 (.split 35 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,5,7})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape31T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2162688 163840 q11Shape31T170=true := by decide

def q11Shape31P6 : Tree 11 := q11Shape31T170
theorem q11Shape31P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2162688 163840 q11Shape31P6=true := q11Shape31T170OK

private def q11Shape31T172 : Tree 11 := (.split 33 (.split 34 (.split 35 (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape31T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 196608 32768 q11Shape31T172=true := by decide

def q11Shape31P7 : Tree 11 := q11Shape31T172
theorem q11Shape31P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 196608 32768 q11Shape31P7=true := q11Shape31T172OK

end Graffiti384b.EffectiveSearch.Q11
