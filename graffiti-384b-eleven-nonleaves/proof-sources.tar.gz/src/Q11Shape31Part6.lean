import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T188 : Tree 11 := (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9})))) (.split 29 (.split 30 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,7,8}))))
private theorem q11Shape31T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60397912838 q11Shape31T188=true := by decide

private def q11Shape31T189 : Tree 11 := (.tip (.cover {1,2,3,4,6,7}))
private theorem q11Shape31T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 33280 60397912326 q11Shape31T189=true := by decide

private def q11Shape31T187 : Tree 11 := .split 9 q11Shape31T188 q11Shape31T189
private theorem q11Shape31T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60397912326 q11Shape31T187=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60397912326 ||| 2^9) q11Shape31T188 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^9) 60397912326 q11Shape31T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T188OK,q11Shape31T189OK⟩

private def q11Shape31T190 : Tree 11 := (.tip (.cover {1,2,3,5,6,7}))
private theorem q11Shape31T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 33024 60397912070 q11Shape31T190=true := by decide

private def q11Shape31T186 : Tree 11 := .split 8 q11Shape31T187 q11Shape31T190
private theorem q11Shape31T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60397912070 q11Shape31T186=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60397912070 ||| 2^8) q11Shape31T187 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^8) 60397912070 q11Shape31T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T187OK,q11Shape31T190OK⟩

private def q11Shape31T191 : Tree 11 := (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape31T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 134250496 60263694342 q11Shape31T191=true := by decide

private def q11Shape31T185 : Tree 11 := .split 27 q11Shape31T186 q11Shape31T191
private theorem q11Shape31T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60263694342 q11Shape31T185=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60263694342 ||| 2^27) q11Shape31T186 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^27) 60263694342 q11Shape31T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T186OK,q11Shape31T191OK⟩

private def q11Shape31T192 : Tree 11 := (.tip (.cover {1,2,3,4,6,7}))
private theorem q11Shape31T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32772 60263694338 q11Shape31T192=true := by decide

private def q11Shape31T184 : Tree 11 := .split 2 q11Shape31T185 q11Shape31T192
private theorem q11Shape31T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60263694338 q11Shape31T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60263694338 ||| 2^2) q11Shape31T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^2) 60263694338 q11Shape31T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T185OK,q11Shape31T192OK⟩

private def q11Shape31T193 : Tree 11 := (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,5,7})) (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9})))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape31T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 33587200 60230139906 q11Shape31T193=true := by decide

private def q11Shape31T183 : Tree 11 := .split 25 q11Shape31T184 q11Shape31T193
private theorem q11Shape31T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60230139906 q11Shape31T183=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60230139906 ||| 2^25) q11Shape31T184 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^25) 60230139906 q11Shape31T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T184OK,q11Shape31T193OK⟩

private def q11Shape31T194 : Tree 11 := (.tip (.cover {1,2,3,5,6,7}))
private theorem q11Shape31T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32770 60230139904 q11Shape31T194=true := by decide

private def q11Shape31T182 : Tree 11 := .split 1 q11Shape31T183 q11Shape31T194
private theorem q11Shape31T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60230139904 q11Shape31T182=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60230139904 ||| 2^1) q11Shape31T183 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^1) 60230139904 q11Shape31T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T183OK,q11Shape31T194OK⟩

private def q11Shape31T195 : Tree 11 := (.split 25 (.split 27 (.split 29 (.split 28 (.tip (.cover {0,1,2,3,5,7})) (.split 30 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,10})))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape31T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 16809984 60213362688 q11Shape31T195=true := by decide

private def q11Shape31T181 : Tree 11 := .split 24 q11Shape31T182 q11Shape31T195
private theorem q11Shape31T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60213362688 q11Shape31T181=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60213362688 ||| 2^24) q11Shape31T182 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^24) 60213362688 q11Shape31T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T182OK,q11Shape31T195OK⟩

private def q11Shape31T197 : Tree 11 := (.split 25 (.split 28 (.split 29 (.split 27 (.tip (.cover {0,1,2,3,5,7})) (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape31T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8421376 60221751296 q11Shape31T197=true := by decide

private def q11Shape31T198 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape31T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 25198592 60204974080 q11Shape31T198=true := by decide

private def q11Shape31T196 : Tree 11 := .split 24 q11Shape31T197 q11Shape31T198
private theorem q11Shape31T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8421376 60204974080 q11Shape31T196=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8421376 (60204974080 ||| 2^24) q11Shape31T197 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8421376 ||| 2^24) 60204974080 q11Shape31T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T197OK,q11Shape31T198OK⟩

private def q11Shape31T180 : Tree 11 := .split 23 q11Shape31T181 q11Shape31T196
private theorem q11Shape31T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60204974080 q11Shape31T180=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60204974080 ||| 2^23) q11Shape31T181 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^23) 60204974080 q11Shape31T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T181OK,q11Shape31T196OK⟩

private def q11Shape31T200 : Tree 11 := (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9})))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape31T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1081344 60212314112 q11Shape31T200=true := by decide

private def q11Shape31T201 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape31T201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 9469952 60203925504 q11Shape31T201=true := by decide

private def q11Shape31T199 : Tree 11 := .split 23 q11Shape31T200 q11Shape31T201
private theorem q11Shape31T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1081344 60203925504 q11Shape31T199=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1081344 (60203925504 ||| 2^23) q11Shape31T200 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (1081344 ||| 2^23) 60203925504 q11Shape31T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T200OK,q11Shape31T201OK⟩

private def q11Shape31T179 : Tree 11 := .split 20 q11Shape31T180 q11Shape31T199
private theorem q11Shape31T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60203925504 q11Shape31T179=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60203925504 ||| 2^20) q11Shape31T180 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^20) 60203925504 q11Shape31T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T180OK,q11Shape31T199OK⟩

private def q11Shape31T204 : Tree 11 := (.split 24 (.split 25 (.split 27 (.split 29 (.split 28 (.tip (.cover {0,1,2,3,4,7})) (.split 30 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,10})))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape31T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 557056 60212838400 q11Shape31T204=true := by decide

private def q11Shape31T205 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape31T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8945664 60204449792 q11Shape31T205=true := by decide

private def q11Shape31T203 : Tree 11 := .split 23 q11Shape31T204 q11Shape31T205
private theorem q11Shape31T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 557056 60204449792 q11Shape31T203=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 557056 (60204449792 ||| 2^23) q11Shape31T204 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (557056 ||| 2^23) 60204449792 q11Shape31T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T204OK,q11Shape31T205OK⟩

private def q11Shape31T206 : Tree 11 := (.tip (.cover {0,1,4,6,7,8}))
private theorem q11Shape31T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1605632 60203401216 q11Shape31T206=true := by decide

private def q11Shape31T202 : Tree 11 := .split 20 q11Shape31T203 q11Shape31T206
private theorem q11Shape31T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 557056 60203401216 q11Shape31T202=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 557056 (60203401216 ||| 2^20) q11Shape31T203 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (557056 ||| 2^20) 60203401216 q11Shape31T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T203OK,q11Shape31T206OK⟩

private def q11Shape31T178 : Tree 11 := .split 19 q11Shape31T179 q11Shape31T202
private theorem q11Shape31T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60203401216 q11Shape31T178=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60203401216 ||| 2^19) q11Shape31T179 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^19) 60203401216 q11Shape31T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T179OK,q11Shape31T202OK⟩

private def q11Shape31T211 : Tree 11 := (.split 25 (.split 28 (.split 29 (.split 27 (.tip (.cover {0,1,2,3,4,7})) (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,8,9,10})))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape31T211OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 60229877760 q11Shape31T211=true := by decide

private def q11Shape31T212 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape31T212OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17072128 60213100544 q11Shape31T212=true := by decide

private def q11Shape31T210 : Tree 11 := .split 24 q11Shape31T211 q11Shape31T212
private theorem q11Shape31T210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 60213100544 q11Shape31T210=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 (60213100544 ||| 2^24) q11Shape31T211 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (294912 ||| 2^24) 60213100544 q11Shape31T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T211OK,q11Shape31T212OK⟩

private def q11Shape31T213 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape31T213OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8683520 60204711936 q11Shape31T213=true := by decide

private def q11Shape31T209 : Tree 11 := .split 23 q11Shape31T210 q11Shape31T213
private theorem q11Shape31T209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 60204711936 q11Shape31T209=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 (60204711936 ||| 2^23) q11Shape31T210 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (294912 ||| 2^23) 60204711936 q11Shape31T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T210OK,q11Shape31T213OK⟩

private def q11Shape31T214 : Tree 11 := (.tip (.cover {0,1,4,6,7,9}))
private theorem q11Shape31T214OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 1343488 60203663360 q11Shape31T214=true := by decide

private def q11Shape31T208 : Tree 11 := .split 20 q11Shape31T209 q11Shape31T214
private theorem q11Shape31T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 60203663360 q11Shape31T208=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 (60203663360 ||| 2^20) q11Shape31T209 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (294912 ||| 2^20) 60203663360 q11Shape31T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T209OK,q11Shape31T214OK⟩

private def q11Shape31T215 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape31T215OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 819200 60203139072 q11Shape31T215=true := by decide

private def q11Shape31T207 : Tree 11 := .split 19 q11Shape31T208 q11Shape31T215
private theorem q11Shape31T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 60203139072 q11Shape31T207=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 294912 (60203139072 ||| 2^19) q11Shape31T208 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (294912 ||| 2^19) 60203139072 q11Shape31T215)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T208OK,q11Shape31T215OK⟩

private def q11Shape31T177 : Tree 11 := .split 18 q11Shape31T178 q11Shape31T207
private theorem q11Shape31T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 60203139072 q11Shape31T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (60203139072 ||| 2^18) q11Shape31T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^18) 60203139072 q11Shape31T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T178OK,q11Shape31T207OK⟩

private def q11Shape31T216 : Tree 11 := (.split 18 (.split 23 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,4,6,7,9})))
private theorem q11Shape31T216OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 34359771136 25843400704 q11Shape31T216=true := by decide

private def q11Shape31T176 : Tree 11 := .split 35 q11Shape31T177 q11Shape31T216
private theorem q11Shape31T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 25843400704 q11Shape31T176=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (25843400704 ||| 2^35) q11Shape31T177 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^35) 25843400704 q11Shape31T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T177OK,q11Shape31T216OK⟩

private def q11Shape31T218 : Tree 11 := (.split 19 (.split 24 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,4,6,7,8})))
private theorem q11Shape31T218OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17179901952 43023269888 q11Shape31T218=true := by decide

private def q11Shape31T219 : Tree 11 := (.tip (.cover {0,1,4,6,7,10}))
private theorem q11Shape31T219OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 51539640320 8663531520 q11Shape31T219=true := by decide

private def q11Shape31T217 : Tree 11 := .split 35 q11Shape31T218 q11Shape31T219
private theorem q11Shape31T217OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17179901952 8663531520 q11Shape31T217=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17179901952 (8663531520 ||| 2^35) q11Shape31T218 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (17179901952 ||| 2^35) 8663531520 q11Shape31T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T218OK,q11Shape31T219OK⟩

private def q11Shape31T175 : Tree 11 := .split 34 q11Shape31T176 q11Shape31T217
private theorem q11Shape31T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 8663531520 q11Shape31T175=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 (8663531520 ||| 2^34) q11Shape31T176 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (32768 ||| 2^34) 8663531520 q11Shape31T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T176OK,q11Shape31T217OK⟩

def q11Shape31P8 : Tree 11 := q11Shape31T175
theorem q11Shape31P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 32768 8663531520 q11Shape31P8=true := q11Shape31T175OK

end Graffiti384b.EffectiveSearch.Q11
