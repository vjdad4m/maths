import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape31T222 : Tree 11 := (.split 20 (.split 25 (.split 27 (.split 28 (.split 29 (.split 30 (.split 32 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,4,6,7,8})))
private theorem q11Shape31T222OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8589967360 51613204480 q11Shape31T222=true := by decide

private def q11Shape31T223 : Tree 11 := (.tip (.cover {0,1,4,6,7,9}))
private theorem q11Shape31T223OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 42949705728 17253466112 q11Shape31T223=true := by decide

private def q11Shape31T221 : Tree 11 := .split 35 q11Shape31T222 q11Shape31T223
private theorem q11Shape31T221OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8589967360 17253466112 q11Shape31T221=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8589967360 (17253466112 ||| 2^35) q11Shape31T222 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8589967360 ||| 2^35) 17253466112 q11Shape31T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T222OK,q11Shape31T223OK⟩

private def q11Shape31T224 : Tree 11 := (.tip (.cover {0,1,4,6,7,8}))
private theorem q11Shape31T224OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 25769836544 73596928 q11Shape31T224=true := by decide

private def q11Shape31T220 : Tree 11 := .split 34 q11Shape31T221 q11Shape31T224
private theorem q11Shape31T220OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8589967360 73596928 q11Shape31T220=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8589967360 (73596928 ||| 2^34) q11Shape31T221 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (8589967360 ||| 2^34) 73596928 q11Shape31T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T221OK,q11Shape31T224OK⟩

def q11Shape31P9 : Tree 11 := q11Shape31T220
theorem q11Shape31P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8589967360 73596928 q11Shape31P9=true := q11Shape31T220OK

private def q11Shape31T231 : Tree 11 := (.split 20 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,4,6,8,9})))
private theorem q11Shape31T231OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 60136816640 q11Shape31T231=true := by decide

private def q11Shape31T232 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape31T232OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67665920 60136292352 q11Shape31T232=true := by decide

private def q11Shape31T230 : Tree 11 := .split 19 q11Shape31T231 q11Shape31T232
private theorem q11Shape31T230OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 60136292352 q11Shape31T230=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 (60136292352 ||| 2^19) q11Shape31T231 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67141632 ||| 2^19) 60136292352 q11Shape31T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T231OK,q11Shape31T232OK⟩

private def q11Shape31T233 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape31T233OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67403776 60136030208 q11Shape31T233=true := by decide

private def q11Shape31T229 : Tree 11 := .split 18 q11Shape31T230 q11Shape31T233
private theorem q11Shape31T229OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 60136030208 q11Shape31T229=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 (60136030208 ||| 2^18) q11Shape31T230 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67141632 ||| 2^18) 60136030208 q11Shape31T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T230OK,q11Shape31T233OK⟩

private def q11Shape31T234 : Tree 11 := (.tip (.cover {0,1,4,6,8,9}))
private theorem q11Shape31T234OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 34426880000 25776291840 q11Shape31T234=true := by decide

private def q11Shape31T228 : Tree 11 := .split 35 q11Shape31T229 q11Shape31T234
private theorem q11Shape31T228OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 25776291840 q11Shape31T228=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 (25776291840 ||| 2^35) q11Shape31T229 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67141632 ||| 2^35) 25776291840 q11Shape31T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T229OK,q11Shape31T234OK⟩

private def q11Shape31T235 : Tree 11 := (.tip (.cover {0,1,4,6,8,9}))
private theorem q11Shape31T235OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 17247010816 8596422656 q11Shape31T235=true := by decide

private def q11Shape31T227 : Tree 11 := .split 34 q11Shape31T228 q11Shape31T235
private theorem q11Shape31T227OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 8596422656 q11Shape31T227=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 (8596422656 ||| 2^34) q11Shape31T228 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67141632 ||| 2^34) 8596422656 q11Shape31T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T228OK,q11Shape31T235OK⟩

private def q11Shape31T236 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape31T236OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 8657076224 6488064 q11Shape31T236=true := by decide

private def q11Shape31T226 : Tree 11 := .split 33 q11Shape31T227 q11Shape31T236
private theorem q11Shape31T226OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 6488064 q11Shape31T226=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 (6488064 ||| 2^33) q11Shape31T227 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) (67141632 ||| 2^33) 6488064 q11Shape31T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape31T227OK,q11Shape31T236OK⟩

def q11Shape31P10 : Tree 11 := q11Shape31T226
theorem q11Shape31P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 67141632 6488064 q11Shape31P10=true := q11Shape31T226OK

private def q11Shape31T238 : Tree 11 := (.split 33 (.split 34 (.split 35 (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape31T238OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4227072 2293760 q11Shape31T238=true := by decide

def q11Shape31P11 : Tree 11 := q11Shape31T238
theorem q11Shape31P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 4227072 2293760 q11Shape31P11=true := q11Shape31T238OK

private def q11Shape31T240 : Tree 11 := (.split 22 (.split 33 (.split 34 (.split 35 (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape31T240OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2129920 196608 q11Shape31T240=true := by decide

def q11Shape31P12 : Tree 11 := q11Shape31T240
theorem q11Shape31P12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 2129920 196608 q11Shape31P12=true := q11Shape31T240OK

private def q11Shape31T242 : Tree 11 := (.split 33 (.split 34 (.split 35 (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape31T242OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 163840 65536 q11Shape31T242=true := by decide

def q11Shape31P13 : Tree 11 := q11Shape31T242
theorem q11Shape31P13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 163840 65536 q11Shape31P13=true := q11Shape31T242OK

private def q11Shape31T244 : Tree 11 := (.split 17 (.split 33 (.split 34 (.split 35 (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape31T244OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 98304 0 q11Shape31T244=true := by decide

def q11Shape31P14 : Tree 11 := q11Shape31T244
theorem q11Shape31P14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,2⟩) 98304 0 q11Shape31P14=true := q11Shape31T244OK

end Graffiti384b.EffectiveSearch.Q11
