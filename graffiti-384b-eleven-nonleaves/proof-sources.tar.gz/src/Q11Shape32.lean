import Q11Shape32Part0
import Q11Shape32Part1

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape32M78 : Tree 11 := .split 22 q11Shape32P0 q11Shape32P1
private theorem q11Shape32M78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 2097152 q11Shape32M78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (2097152 ||| 2^22) q11Shape32P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^22) 2097152 q11Shape32P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32P0OK,q11Shape32P1OK⟩
private def q11Shape32M102 : Tree 11 := .split 21 q11Shape32M78 q11Shape32P2
private theorem q11Shape32M102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 0 q11Shape32M102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (0 ||| 2^21) q11Shape32M78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^21) 0 q11Shape32P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32M78OK,q11Shape32P2OK⟩

theorem q11Shape32_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 32) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 32) b) (adj 11 (forms 32) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) adj_mono b H q11Shape32M102 q11Shape32M102OK

#print axioms q11Shape32_cover

end Graffiti384b.EffectiveSearch.Q11
