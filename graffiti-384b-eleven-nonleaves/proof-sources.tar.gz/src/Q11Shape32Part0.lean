import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape32T7 : Tree 11 := (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.split 32 (.split 25 (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,8})))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,8,10}))))
private theorem q11Shape32T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 12043943936 q11Shape32T7=true := by decide

private def q11Shape32T8 : Tree 11 := (.split 28 (.split 32 (.split 25 (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape32T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 134217728 11909726208 q11Shape32T8=true := by decide

private def q11Shape32T6 : Tree 11 := .split 27 q11Shape32T7 q11Shape32T8
private theorem q11Shape32T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 11909726208 q11Shape32T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (11909726208 ||| 2^27) q11Shape32T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^27) 11909726208 q11Shape32T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T7OK,q11Shape32T8OK⟩

private def q11Shape32T10 : Tree 11 := (.split 28 (.split 32 (.split 25 (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,1,5,7,8,10}))) (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8})))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape32T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 16777216 12027166720 q11Shape32T10=true := by decide

private def q11Shape32T11 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape32T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 150994944 11892948992 q11Shape32T11=true := by decide

private def q11Shape32T9 : Tree 11 := .split 27 q11Shape32T10 q11Shape32T11
private theorem q11Shape32T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 16777216 11892948992 q11Shape32T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 16777216 (11892948992 ||| 2^27) q11Shape32T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (16777216 ||| 2^27) 11892948992 q11Shape32T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T10OK,q11Shape32T11OK⟩

private def q11Shape32T5 : Tree 11 := .split 24 q11Shape32T6 q11Shape32T9
private theorem q11Shape32T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 11892948992 q11Shape32T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (11892948992 ||| 2^24) q11Shape32T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^24) 11892948992 q11Shape32T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T6OK,q11Shape32T9OK⟩

private def q11Shape32T14 : Tree 11 := (.split 28 (.split 32 (.split 25 (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,1,5,7,9,10}))) (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,9})))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape32T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8388608 12035555328 q11Shape32T14=true := by decide

private def q11Shape32T15 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape32T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 142606336 11901337600 q11Shape32T15=true := by decide

private def q11Shape32T13 : Tree 11 := .split 27 q11Shape32T14 q11Shape32T15
private theorem q11Shape32T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8388608 11901337600 q11Shape32T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8388608 (11901337600 ||| 2^27) q11Shape32T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (8388608 ||| 2^27) 11901337600 q11Shape32T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T14OK,q11Shape32T15OK⟩

private def q11Shape32T16 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape32T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 25165824 11884560384 q11Shape32T16=true := by decide

private def q11Shape32T12 : Tree 11 := .split 24 q11Shape32T13 q11Shape32T16
private theorem q11Shape32T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8388608 11884560384 q11Shape32T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8388608 (11884560384 ||| 2^24) q11Shape32T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (8388608 ||| 2^24) 11884560384 q11Shape32T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T13OK,q11Shape32T16OK⟩

private def q11Shape32T4 : Tree 11 := .split 23 q11Shape32T5 q11Shape32T12
private theorem q11Shape32T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 11884560384 q11Shape32T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (11884560384 ||| 2^23) q11Shape32T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^23) 11884560384 q11Shape32T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T5OK,q11Shape32T12OK⟩

private def q11Shape32T21 : Tree 11 := (.split 32 (.split 25 (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.split 25 (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape32T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 10164895744 q11Shape32T21=true := by decide

private def q11Shape32T22 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape32T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2415919104 9896460288 q11Shape32T22=true := by decide

private def q11Shape32T20 : Tree 11 := .split 28 q11Shape32T21 q11Shape32T22
private theorem q11Shape32T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 9896460288 q11Shape32T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 (9896460288 ||| 2^28) q11Shape32T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2147483648 ||| 2^28) 9896460288 q11Shape32T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T21OK,q11Shape32T22OK⟩

private def q11Shape32T23 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape32T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2281701376 9762242560 q11Shape32T23=true := by decide

private def q11Shape32T19 : Tree 11 := .split 27 q11Shape32T20 q11Shape32T23
private theorem q11Shape32T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 9762242560 q11Shape32T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 (9762242560 ||| 2^27) q11Shape32T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2147483648 ||| 2^27) 9762242560 q11Shape32T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T20OK,q11Shape32T23OK⟩

private def q11Shape32T24 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape32T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2164260864 9745465344 q11Shape32T24=true := by decide

private def q11Shape32T18 : Tree 11 := .split 24 q11Shape32T19 q11Shape32T24
private theorem q11Shape32T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 9745465344 q11Shape32T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 (9745465344 ||| 2^24) q11Shape32T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2147483648 ||| 2^24) 9745465344 q11Shape32T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T19OK,q11Shape32T24OK⟩

private def q11Shape32T25 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape32T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2155872256 9737076736 q11Shape32T25=true := by decide

private def q11Shape32T17 : Tree 11 := .split 23 q11Shape32T18 q11Shape32T25
private theorem q11Shape32T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 9737076736 q11Shape32T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2147483648 (9737076736 ||| 2^23) q11Shape32T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2147483648 ||| 2^23) 9737076736 q11Shape32T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T18OK,q11Shape32T25OK⟩

private def q11Shape32T3 : Tree 11 := .split 31 q11Shape32T4 q11Shape32T17
private theorem q11Shape32T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 9737076736 q11Shape32T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (9737076736 ||| 2^31) q11Shape32T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^31) 9737076736 q11Shape32T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T4OK,q11Shape32T17OK⟩

private def q11Shape32T31 : Tree 11 := (.split 32 (.split 25 (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.split 25 (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,9}))))
private theorem q11Shape32T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 11238637568 q11Shape32T31=true := by decide

private def q11Shape32T32 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape32T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1342177280 10970202112 q11Shape32T32=true := by decide

private def q11Shape32T30 : Tree 11 := .split 28 q11Shape32T31 q11Shape32T32
private theorem q11Shape32T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 10970202112 q11Shape32T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 (10970202112 ||| 2^28) q11Shape32T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (1073741824 ||| 2^28) 10970202112 q11Shape32T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T31OK,q11Shape32T32OK⟩

private def q11Shape32T33 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape32T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1207959552 10835984384 q11Shape32T33=true := by decide

private def q11Shape32T29 : Tree 11 := .split 27 q11Shape32T30 q11Shape32T33
private theorem q11Shape32T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 10835984384 q11Shape32T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 (10835984384 ||| 2^27) q11Shape32T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (1073741824 ||| 2^27) 10835984384 q11Shape32T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T30OK,q11Shape32T33OK⟩

private def q11Shape32T34 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape32T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1090519040 10819207168 q11Shape32T34=true := by decide

private def q11Shape32T28 : Tree 11 := .split 24 q11Shape32T29 q11Shape32T34
private theorem q11Shape32T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 10819207168 q11Shape32T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 (10819207168 ||| 2^24) q11Shape32T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (1073741824 ||| 2^24) 10819207168 q11Shape32T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T29OK,q11Shape32T34OK⟩

private def q11Shape32T35 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape32T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1082130432 10810818560 q11Shape32T35=true := by decide

private def q11Shape32T27 : Tree 11 := .split 23 q11Shape32T28 q11Shape32T35
private theorem q11Shape32T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 10810818560 q11Shape32T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 (10810818560 ||| 2^23) q11Shape32T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (1073741824 ||| 2^23) 10810818560 q11Shape32T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T28OK,q11Shape32T35OK⟩

private def q11Shape32T36 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape32T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 3221225472 8663334912 q11Shape32T36=true := by decide

private def q11Shape32T26 : Tree 11 := .split 31 q11Shape32T27 q11Shape32T36
private theorem q11Shape32T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 8663334912 q11Shape32T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1073741824 (8663334912 ||| 2^31) q11Shape32T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (1073741824 ||| 2^31) 8663334912 q11Shape32T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T27OK,q11Shape32T36OK⟩

private def q11Shape32T2 : Tree 11 := .split 30 q11Shape32T3 q11Shape32T26
private theorem q11Shape32T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 8663334912 q11Shape32T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (8663334912 ||| 2^30) q11Shape32T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^30) 8663334912 q11Shape32T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T3OK,q11Shape32T26OK⟩

private def q11Shape32T39 : Tree 11 := (.split 23 (.split 24 (.split 27 (.split 28 (.split 32 (.split 25 (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,10})))
private theorem q11Shape32T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8589934592 3294625792 q11Shape32T39=true := by decide

private def q11Shape32T40 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape32T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 10737418240 1147142144 q11Shape32T40=true := by decide

private def q11Shape32T38 : Tree 11 := .split 31 q11Shape32T39 q11Shape32T40
private theorem q11Shape32T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8589934592 1147142144 q11Shape32T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8589934592 (1147142144 ||| 2^31) q11Shape32T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (8589934592 ||| 2^31) 1147142144 q11Shape32T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T39OK,q11Shape32T40OK⟩

private def q11Shape32T41 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape32T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 9663676416 73400320 q11Shape32T41=true := by decide

private def q11Shape32T37 : Tree 11 := .split 30 q11Shape32T38 q11Shape32T41
private theorem q11Shape32T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8589934592 73400320 q11Shape32T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8589934592 (73400320 ||| 2^30) q11Shape32T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (8589934592 ||| 2^30) 73400320 q11Shape32T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T38OK,q11Shape32T41OK⟩

private def q11Shape32T1 : Tree 11 := .split 33 q11Shape32T2 q11Shape32T37
private theorem q11Shape32T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 73400320 q11Shape32T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (73400320 ||| 2^33) q11Shape32T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^33) 73400320 q11Shape32T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T2OK,q11Shape32T37OK⟩

private def q11Shape32T50 : Tree 11 := (.split 25 (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,9})))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape32T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 16540237824 q11Shape32T50=true := by decide

private def q11Shape32T51 : Tree 11 := (.split 25 (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,7,8,9})))
private theorem q11Shape32T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4362076160 12245270528 q11Shape32T51=true := by decide

private def q11Shape32T49 : Tree 11 := .split 32 q11Shape32T50 q11Shape32T51
private theorem q11Shape32T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 12245270528 q11Shape32T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (12245270528 ||| 2^32) q11Shape32T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^32) 12245270528 q11Shape32T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T50OK,q11Shape32T51OK⟩

private def q11Shape32T52 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape32T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 335544320 11976835072 q11Shape32T52=true := by decide

private def q11Shape32T48 : Tree 11 := .split 28 q11Shape32T49 q11Shape32T52
private theorem q11Shape32T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 11976835072 q11Shape32T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (11976835072 ||| 2^28) q11Shape32T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^28) 11976835072 q11Shape32T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T49OK,q11Shape32T52OK⟩

private def q11Shape32T53 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape32T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 201326592 11842617344 q11Shape32T53=true := by decide

private def q11Shape32T47 : Tree 11 := .split 27 q11Shape32T48 q11Shape32T53
private theorem q11Shape32T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 11842617344 q11Shape32T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (11842617344 ||| 2^27) q11Shape32T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^27) 11842617344 q11Shape32T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T48OK,q11Shape32T53OK⟩

private def q11Shape32T54 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape32T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 83886080 11825840128 q11Shape32T54=true := by decide

private def q11Shape32T46 : Tree 11 := .split 24 q11Shape32T47 q11Shape32T54
private theorem q11Shape32T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 11825840128 q11Shape32T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (11825840128 ||| 2^24) q11Shape32T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^24) 11825840128 q11Shape32T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T47OK,q11Shape32T54OK⟩

private def q11Shape32T55 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape32T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 75497472 11817451520 q11Shape32T55=true := by decide

private def q11Shape32T45 : Tree 11 := .split 23 q11Shape32T46 q11Shape32T55
private theorem q11Shape32T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 11817451520 q11Shape32T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (11817451520 ||| 2^23) q11Shape32T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^23) 11817451520 q11Shape32T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T46OK,q11Shape32T55OK⟩

private def q11Shape32T56 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape32T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2214592512 9669967872 q11Shape32T56=true := by decide

private def q11Shape32T44 : Tree 11 := .split 31 q11Shape32T45 q11Shape32T56
private theorem q11Shape32T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 9669967872 q11Shape32T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (9669967872 ||| 2^31) q11Shape32T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^31) 9669967872 q11Shape32T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T45OK,q11Shape32T56OK⟩

private def q11Shape32T57 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape32T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1140850688 8596226048 q11Shape32T57=true := by decide

private def q11Shape32T43 : Tree 11 := .split 30 q11Shape32T44 q11Shape32T57
private theorem q11Shape32T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 8596226048 q11Shape32T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (8596226048 ||| 2^30) q11Shape32T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^30) 8596226048 q11Shape32T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T44OK,q11Shape32T57OK⟩

private def q11Shape32T58 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape32T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8657043456 6291456 q11Shape32T58=true := by decide

private def q11Shape32T42 : Tree 11 := .split 33 q11Shape32T43 q11Shape32T58
private theorem q11Shape32T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 6291456 q11Shape32T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 67108864 (6291456 ||| 2^33) q11Shape32T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (67108864 ||| 2^33) 6291456 q11Shape32T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T43OK,q11Shape32T58OK⟩

private def q11Shape32T0 : Tree 11 := .split 26 q11Shape32T1 q11Shape32T42
private theorem q11Shape32T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 6291456 q11Shape32T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 (6291456 ||| 2^26) q11Shape32T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (0 ||| 2^26) 6291456 q11Shape32T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T1OK,q11Shape32T42OK⟩

def q11Shape32P0 : Tree 11 := q11Shape32T0
theorem q11Shape32P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 0 6291456 q11Shape32P0=true := q11Shape32T0OK

end Graffiti384b.EffectiveSearch.Q11
