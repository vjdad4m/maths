import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape32T68 : Tree 11 := (.split 25 (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,9}))))
private theorem q11Shape32T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 16603152384 q11Shape32T68=true := by decide

private def q11Shape32T69 : Tree 11 := (.split 25 (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape32T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4299161600 12308185088 q11Shape32T69=true := by decide

private def q11Shape32T67 : Tree 11 := .split 32 q11Shape32T68 q11Shape32T69
private theorem q11Shape32T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 12308185088 q11Shape32T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (12308185088 ||| 2^32) q11Shape32T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^32) 12308185088 q11Shape32T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T68OK,q11Shape32T69OK⟩

private def q11Shape32T70 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape32T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 272629760 12039749632 q11Shape32T70=true := by decide

private def q11Shape32T66 : Tree 11 := .split 28 q11Shape32T67 q11Shape32T70
private theorem q11Shape32T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 12039749632 q11Shape32T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (12039749632 ||| 2^28) q11Shape32T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^28) 12039749632 q11Shape32T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T67OK,q11Shape32T70OK⟩

private def q11Shape32T71 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape32T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 138412032 11905531904 q11Shape32T71=true := by decide

private def q11Shape32T65 : Tree 11 := .split 27 q11Shape32T66 q11Shape32T71
private theorem q11Shape32T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 11905531904 q11Shape32T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (11905531904 ||| 2^27) q11Shape32T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^27) 11905531904 q11Shape32T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T66OK,q11Shape32T71OK⟩

private def q11Shape32T72 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape32T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 20971520 11888754688 q11Shape32T72=true := by decide

private def q11Shape32T64 : Tree 11 := .split 24 q11Shape32T65 q11Shape32T72
private theorem q11Shape32T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 11888754688 q11Shape32T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (11888754688 ||| 2^24) q11Shape32T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^24) 11888754688 q11Shape32T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T65OK,q11Shape32T72OK⟩

private def q11Shape32T73 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape32T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 12582912 11880366080 q11Shape32T73=true := by decide

private def q11Shape32T63 : Tree 11 := .split 23 q11Shape32T64 q11Shape32T73
private theorem q11Shape32T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 11880366080 q11Shape32T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (11880366080 ||| 2^23) q11Shape32T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^23) 11880366080 q11Shape32T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T64OK,q11Shape32T73OK⟩

private def q11Shape32T74 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape32T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2151677952 9732882432 q11Shape32T74=true := by decide

private def q11Shape32T62 : Tree 11 := .split 31 q11Shape32T63 q11Shape32T74
private theorem q11Shape32T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 9732882432 q11Shape32T62=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (9732882432 ||| 2^31) q11Shape32T63 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^31) 9732882432 q11Shape32T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T63OK,q11Shape32T74OK⟩

private def q11Shape32T75 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape32T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1077936128 8659140608 q11Shape32T75=true := by decide

private def q11Shape32T61 : Tree 11 := .split 30 q11Shape32T62 q11Shape32T75
private theorem q11Shape32T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 8659140608 q11Shape32T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (8659140608 ||| 2^30) q11Shape32T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^30) 8659140608 q11Shape32T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T62OK,q11Shape32T75OK⟩

private def q11Shape32T76 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape32T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8594128896 69206016 q11Shape32T76=true := by decide

private def q11Shape32T60 : Tree 11 := .split 33 q11Shape32T61 q11Shape32T76
private theorem q11Shape32T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 69206016 q11Shape32T60=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (69206016 ||| 2^33) q11Shape32T61 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^33) 69206016 q11Shape32T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T61OK,q11Shape32T76OK⟩

private def q11Shape32T77 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape32T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 71303168 2097152 q11Shape32T77=true := by decide

private def q11Shape32T59 : Tree 11 := .split 26 q11Shape32T60 q11Shape32T77
private theorem q11Shape32T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 2097152 q11Shape32T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 (2097152 ||| 2^26) q11Shape32T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (4194304 ||| 2^26) 2097152 q11Shape32T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T60OK,q11Shape32T77OK⟩

def q11Shape32P1 : Tree 11 := q11Shape32T59
theorem q11Shape32P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4194304 2097152 q11Shape32P1=true := q11Shape32T59OK

private def q11Shape32T90 : Tree 11 := (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))))
private theorem q11Shape32T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 16638803968 q11Shape32T90=true := by decide

private def q11Shape32T91 : Tree 11 := (.split 29 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape32T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 35651584 16605249536 q11Shape32T91=true := by decide

private def q11Shape32T89 : Tree 11 := .split 25 q11Shape32T90 q11Shape32T91
private theorem q11Shape32T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 16605249536 q11Shape32T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (16605249536 ||| 2^25) q11Shape32T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^25) 16605249536 q11Shape32T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T90OK,q11Shape32T91OK⟩

private def q11Shape32T92 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape32T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 4297064448 12310282240 q11Shape32T92=true := by decide

private def q11Shape32T88 : Tree 11 := .split 32 q11Shape32T89 q11Shape32T92
private theorem q11Shape32T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 12310282240 q11Shape32T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (12310282240 ||| 2^32) q11Shape32T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^32) 12310282240 q11Shape32T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T89OK,q11Shape32T92OK⟩

private def q11Shape32T93 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape32T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 270532608 12041846784 q11Shape32T93=true := by decide

private def q11Shape32T87 : Tree 11 := .split 28 q11Shape32T88 q11Shape32T93
private theorem q11Shape32T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 12041846784 q11Shape32T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (12041846784 ||| 2^28) q11Shape32T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^28) 12041846784 q11Shape32T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T88OK,q11Shape32T93OK⟩

private def q11Shape32T94 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape32T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 136314880 11907629056 q11Shape32T94=true := by decide

private def q11Shape32T86 : Tree 11 := .split 27 q11Shape32T87 q11Shape32T94
private theorem q11Shape32T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 11907629056 q11Shape32T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (11907629056 ||| 2^27) q11Shape32T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^27) 11907629056 q11Shape32T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T87OK,q11Shape32T94OK⟩

private def q11Shape32T95 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape32T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 18874368 11890851840 q11Shape32T95=true := by decide

private def q11Shape32T85 : Tree 11 := .split 24 q11Shape32T86 q11Shape32T95
private theorem q11Shape32T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 11890851840 q11Shape32T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (11890851840 ||| 2^24) q11Shape32T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^24) 11890851840 q11Shape32T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T86OK,q11Shape32T95OK⟩

private def q11Shape32T96 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape32T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 10485760 11882463232 q11Shape32T96=true := by decide

private def q11Shape32T84 : Tree 11 := .split 23 q11Shape32T85 q11Shape32T96
private theorem q11Shape32T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 11882463232 q11Shape32T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (11882463232 ||| 2^23) q11Shape32T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^23) 11882463232 q11Shape32T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T85OK,q11Shape32T96OK⟩

private def q11Shape32T97 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape32T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2149580800 9734979584 q11Shape32T97=true := by decide

private def q11Shape32T83 : Tree 11 := .split 31 q11Shape32T84 q11Shape32T97
private theorem q11Shape32T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 9734979584 q11Shape32T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (9734979584 ||| 2^31) q11Shape32T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^31) 9734979584 q11Shape32T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T84OK,q11Shape32T97OK⟩

private def q11Shape32T98 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape32T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 1075838976 8661237760 q11Shape32T98=true := by decide

private def q11Shape32T82 : Tree 11 := .split 30 q11Shape32T83 q11Shape32T98
private theorem q11Shape32T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 8661237760 q11Shape32T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (8661237760 ||| 2^30) q11Shape32T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^30) 8661237760 q11Shape32T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T83OK,q11Shape32T98OK⟩

private def q11Shape32T99 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape32T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 8592031744 71303168 q11Shape32T99=true := by decide

private def q11Shape32T81 : Tree 11 := .split 33 q11Shape32T82 q11Shape32T99
private theorem q11Shape32T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 71303168 q11Shape32T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (71303168 ||| 2^33) q11Shape32T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^33) 71303168 q11Shape32T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T82OK,q11Shape32T99OK⟩

private def q11Shape32T100 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape32T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 69206016 4194304 q11Shape32T100=true := by decide

private def q11Shape32T80 : Tree 11 := .split 26 q11Shape32T81 q11Shape32T100
private theorem q11Shape32T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 4194304 q11Shape32T80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (4194304 ||| 2^26) q11Shape32T81 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^26) 4194304 q11Shape32T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T81OK,q11Shape32T100OK⟩

private def q11Shape32T101 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape32T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 6291456 0 q11Shape32T101=true := by decide

private def q11Shape32T79 : Tree 11 := .split 22 q11Shape32T80 q11Shape32T101
private theorem q11Shape32T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 0 q11Shape32T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 (0 ||| 2^22) q11Shape32T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) (2097152 ||| 2^22) 0 q11Shape32T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape32T80OK,q11Shape32T101OK⟩

def q11Shape32P2 : Tree 11 := q11Shape32T79
theorem q11Shape32P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,3⟩) 2097152 0 q11Shape32P2=true := q11Shape32T79OK

end Graffiti384b.EffectiveSearch.Q11
