import Q11Shape33Part0
import Q11Shape33Part1
import Q11Shape33Part2

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape33M98 : Tree 11 := .split 4 q11Shape33P0 q11Shape33P1
private theorem q11Shape33M98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34292629512 q11Shape33M98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (34292629512 ||| 2^4) q11Shape33P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^4) 34292629512 q11Shape33P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33P0OK,q11Shape33P1OK⟩
private def q11Shape33M136 : Tree 11 := .split 3 q11Shape33M98 q11Shape33P2
private theorem q11Shape33M136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34292629504 q11Shape33M136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (34292629504 ||| 2^3) q11Shape33M98 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^3) 34292629504 q11Shape33P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M98OK,q11Shape33P2OK⟩
private def q11Shape33M138 : Tree 11 := .split 34 q11Shape33M136 q11Shape33P3
private theorem q11Shape33M138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 17112760320 q11Shape33M138=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (17112760320 ||| 2^34) q11Shape33M136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^34) 17112760320 q11Shape33P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M136OK,q11Shape33P3OK⟩
private def q11Shape33M140 : Tree 11 := .split 33 q11Shape33M138 q11Shape33P4
private theorem q11Shape33M140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 8522825728 q11Shape33M140=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (8522825728 ||| 2^33) q11Shape33M138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^33) 8522825728 q11Shape33P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M138OK,q11Shape33P4OK⟩
private def q11Shape33M142 : Tree 11 := .split 32 q11Shape33M140 q11Shape33P5
private theorem q11Shape33M142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 4227858432 q11Shape33M142=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (4227858432 ||| 2^32) q11Shape33M140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^32) 4227858432 q11Shape33P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M140OK,q11Shape33P5OK⟩
private def q11Shape33M144 : Tree 11 := .split 31 q11Shape33M142 q11Shape33P6
private theorem q11Shape33M144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 2080374784 q11Shape33M144=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (2080374784 ||| 2^31) q11Shape33M142 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^31) 2080374784 q11Shape33P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M142OK,q11Shape33P6OK⟩
private def q11Shape33M146 : Tree 11 := .split 29 q11Shape33M144 q11Shape33P7
private theorem q11Shape33M146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 1543503872 q11Shape33M146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (1543503872 ||| 2^29) q11Shape33M144 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^29) 1543503872 q11Shape33P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M144OK,q11Shape33P7OK⟩
private def q11Shape33M148 : Tree 11 := .split 28 q11Shape33M146 q11Shape33P8
private theorem q11Shape33M148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 1275068416 q11Shape33M148=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (1275068416 ||| 2^28) q11Shape33M146 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^28) 1275068416 q11Shape33P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M146OK,q11Shape33P8OK⟩
private def q11Shape33M150 : Tree 11 := .split 30 q11Shape33M148 q11Shape33P9
private theorem q11Shape33M150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 201326592 q11Shape33M150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (201326592 ||| 2^30) q11Shape33M148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^30) 201326592 q11Shape33P9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M148OK,q11Shape33P9OK⟩
private def q11Shape33M152 : Tree 11 := .split 27 q11Shape33M150 q11Shape33P10
private theorem q11Shape33M152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 67108864 q11Shape33M152=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (67108864 ||| 2^27) q11Shape33M150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^27) 67108864 q11Shape33P10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M150OK,q11Shape33P10OK⟩
private def q11Shape33M154 : Tree 11 := .split 26 q11Shape33M152 q11Shape33P11
private theorem q11Shape33M154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 0 q11Shape33M154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (0 ||| 2^26) q11Shape33M152 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^26) 0 q11Shape33P11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33M152OK,q11Shape33P11OK⟩

theorem q11Shape33_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 33) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 33) b) (adj 11 (forms 33) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) adj_mono b H q11Shape33M154 q11Shape33M154OK

#print axioms q11Shape33_cover

end Graffiti384b.EffectiveSearch.Q11
