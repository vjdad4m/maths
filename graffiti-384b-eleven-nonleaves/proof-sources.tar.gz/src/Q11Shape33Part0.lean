import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape33T5 : Tree 11 := (.tip (.cover {0,2,3,4,5,8}))
private theorem q11Shape33T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 68661021720 q11Shape33T5=true := by decide

private def q11Shape33T7 : Tree 11 := (.split 17 (.tip (.cover {0,1,5,8,9,10})) (.split 21 (.tip (.cover {0,1,7,8,9,10})) (.split 22 (.split 12 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,2,3,6,7,10}))) (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,1,3,6,7,10})))) (.tip (.cover {0,1,5,8,9,10})))))
private theorem q11Shape33T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738368 34301348888 q11Shape33T7=true := by decide

private def q11Shape33T8 : Tree 11 := (.split 17 (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 12 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,2,3,6,7,10}))) (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,1,3,6,7,10}))))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape33T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803904 34301283352 q11Shape33T8=true := by decide

private def q11Shape33T6 : Tree 11 := .split 16 q11Shape33T7 q11Shape33T8
private theorem q11Shape33T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738368 34301283352 q11Shape33T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738368 (34301283352 ||| 2^16) q11Shape33T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359738368 ||| 2^16) 34301283352 q11Shape33T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T7OK,q11Shape33T8OK⟩

private def q11Shape33T4 : Tree 11 := .split 35 q11Shape33T5 q11Shape33T6
private theorem q11Shape33T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34301283352 q11Shape33T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (34301283352 ||| 2^35) q11Shape33T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^35) 34301283352 q11Shape33T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T5OK,q11Shape33T6OK⟩

private def q11Shape33T9 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape33T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 262144 34301021208 q11Shape33T9=true := by decide

private def q11Shape33T3 : Tree 11 := .split 18 q11Shape33T4 q11Shape33T9
private theorem q11Shape33T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34301021208 q11Shape33T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (34301021208 ||| 2^18) q11Shape33T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^18) 34301021208 q11Shape33T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T4OK,q11Shape33T9OK⟩

private def q11Shape33T10 : Tree 11 := (.tip (.cover {0,1,4,5,9,10}))
private theorem q11Shape33T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8388608 34292632600 q11Shape33T10=true := by decide

private def q11Shape33T2 : Tree 11 := .split 23 q11Shape33T3 q11Shape33T10
private theorem q11Shape33T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34292632600 q11Shape33T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (34292632600 ||| 2^23) q11Shape33T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^23) 34292632600 q11Shape33T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T3OK,q11Shape33T10OK⟩

private def q11Shape33T13 : Tree 11 := (.tip (.cover {0,2,3,4,5,8}))
private theorem q11Shape33T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2048 68652373016 q11Shape33T13=true := by decide

private def q11Shape33T16 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape33T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740416 34294797336 q11Shape33T16=true := by decide

private def q11Shape33T20 : Tree 11 := (.split 18 (.split 5 (.tip (.cover {0,1,6,7,9,10})) (.split 1 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,3,4,5,8,10}))) (.tip (.cover {1,2,6,7,9,10})))) (.split 5 (.split 0 (.split 19 (.tip (.cover {0,2,3,5,8,10})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {0,2,3,4,5,9}))))
private theorem q11Shape33T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837568 34305414168 q11Shape33T20=true := by decide

private def q11Shape33T21 : Tree 11 := (.split 18 (.tip (.cover {1,2,6,7,9,10})) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape33T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361968640 34305283096 q11Shape33T21=true := by decide

private def q11Shape33T19 : Tree 11 := .split 17 q11Shape33T20 q11Shape33T21
private theorem q11Shape33T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837568 34305283096 q11Shape33T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837568 (34305283096 ||| 2^17) q11Shape33T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34361837568 ||| 2^17) 34305283096 q11Shape33T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T20OK,q11Shape33T21OK⟩

private def q11Shape33T22 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape33T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34370226176 34296894488 q11Shape33T22=true := by decide

private def q11Shape33T18 : Tree 11 := .split 23 q11Shape33T19 q11Shape33T22
private theorem q11Shape33T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837568 34296894488 q11Shape33T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837568 (34296894488 ||| 2^23) q11Shape33T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34361837568 ||| 2^23) 34296894488 q11Shape33T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T19OK,q11Shape33T22OK⟩

private def q11Shape33T23 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape33T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34366031872 34292700184 q11Shape33T23=true := by decide

private def q11Shape33T17 : Tree 11 := .split 22 q11Shape33T18 q11Shape33T23
private theorem q11Shape33T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837568 34292700184 q11Shape33T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837568 (34292700184 ||| 2^22) q11Shape33T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34361837568 ||| 2^22) 34292700184 q11Shape33T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T18OK,q11Shape33T23OK⟩

private def q11Shape33T15 : Tree 11 := .split 21 q11Shape33T16 q11Shape33T17
private theorem q11Shape33T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740416 34292700184 q11Shape33T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740416 (34292700184 ||| 2^21) q11Shape33T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359740416 ||| 2^21) 34292700184 q11Shape33T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T16OK,q11Shape33T17OK⟩

private def q11Shape33T29 : Tree 11 := (.split 5 (.tip (.cover {0,1,6,7,9,10})) (.split 2 (.split 9 (.split 15 (.split 24 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,3,4,5,8,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {1,2,6,7,9,10}))))
private theorem q11Shape33T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 34307707928 q11Shape33T29=true := by decide

private def q11Shape33T30 : Tree 11 := (.split 5 (.split 0 (.split 1 (.split 2 (.split 24 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,2,3,4,5,9})))
private theorem q11Shape33T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34368194560 34299319320 q11Shape33T30=true := by decide

private def q11Shape33T28 : Tree 11 := .split 23 q11Shape33T29 q11Shape33T30
private theorem q11Shape33T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 34299319320 q11Shape33T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 (34299319320 ||| 2^23) q11Shape33T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359805952 ||| 2^23) 34299319320 q11Shape33T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T29OK,q11Shape33T30OK⟩

private def q11Shape33T31 : Tree 11 := (.split 23 (.tip (.cover {1,2,6,7,9,10})) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape33T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34364000256 34295125016 q11Shape33T31=true := by decide

private def q11Shape33T27 : Tree 11 := .split 22 q11Shape33T28 q11Shape33T31
private theorem q11Shape33T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 34295125016 q11Shape33T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 (34295125016 ||| 2^22) q11Shape33T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359805952 ||| 2^22) 34295125016 q11Shape33T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T28OK,q11Shape33T31OK⟩

private def q11Shape33T32 : Tree 11 := (.split 23 (.tip (.cover {1,2,6,7,9,10})) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape33T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361903104 34293027864 q11Shape33T32=true := by decide

private def q11Shape33T26 : Tree 11 := .split 21 q11Shape33T27 q11Shape33T32
private theorem q11Shape33T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 34293027864 q11Shape33T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 (34293027864 ||| 2^21) q11Shape33T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359805952 ||| 2^21) 34293027864 q11Shape33T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T27OK,q11Shape33T32OK⟩

private def q11Shape33T33 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape33T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34360068096 34292765720 q11Shape33T33=true := by decide

private def q11Shape33T25 : Tree 11 := .split 18 q11Shape33T26 q11Shape33T33
private theorem q11Shape33T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 34292765720 q11Shape33T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 (34292765720 ||| 2^18) q11Shape33T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359805952 ||| 2^18) 34292765720 q11Shape33T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T26OK,q11Shape33T33OK⟩

private def q11Shape33T34 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape33T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359937024 34292634648 q11Shape33T34=true := by decide

private def q11Shape33T24 : Tree 11 := .split 17 q11Shape33T25 q11Shape33T34
private theorem q11Shape33T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 34292634648 q11Shape33T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805952 (34292634648 ||| 2^17) q11Shape33T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359805952 ||| 2^17) 34292634648 q11Shape33T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T25OK,q11Shape33T34OK⟩

private def q11Shape33T14 : Tree 11 := .split 16 q11Shape33T15 q11Shape33T24
private theorem q11Shape33T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740416 34292634648 q11Shape33T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740416 (34292634648 ||| 2^16) q11Shape33T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359740416 ||| 2^16) 34292634648 q11Shape33T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T15OK,q11Shape33T24OK⟩

private def q11Shape33T12 : Tree 11 := .split 35 q11Shape33T13 q11Shape33T14
private theorem q11Shape33T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2048 34292634648 q11Shape33T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2048 (34292634648 ||| 2^35) q11Shape33T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (2048 ||| 2^35) 34292634648 q11Shape33T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T13OK,q11Shape33T14OK⟩

private def q11Shape33T35 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape33T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 6144 34292630552 q11Shape33T35=true := by decide

private def q11Shape33T11 : Tree 11 := .split 12 q11Shape33T12 q11Shape33T35
private theorem q11Shape33T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2048 34292630552 q11Shape33T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2048 (34292630552 ||| 2^12) q11Shape33T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (2048 ||| 2^12) 34292630552 q11Shape33T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T12OK,q11Shape33T35OK⟩

private def q11Shape33T1 : Tree 11 := .split 11 q11Shape33T2 q11Shape33T11
private theorem q11Shape33T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34292630552 q11Shape33T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (34292630552 ||| 2^11) q11Shape33T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^11) 34292630552 q11Shape33T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T2OK,q11Shape33T11OK⟩

private def q11Shape33T39 : Tree 11 := (.tip (.cover {0,2,3,4,5,8}))
private theorem q11Shape33T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1024 68652374040 q11Shape33T39=true := by decide

private def q11Shape33T44 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape33T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 34299123736 q11Shape33T44=true := by decide

private def q11Shape33T46 : Tree 11 := (.split 18 (.split 5 (.tip (.cover {0,1,6,7,9,10})) (.split 1 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,3,4,5,8,10}))) (.tip (.cover {1,2,6,7,9,10})))) (.split 5 (.split 0 (.split 19 (.tip (.cover {0,2,3,5,8,10})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,3,5,8,9,10}))) (.tip (.cover {0,2,3,4,5,9}))))
private theorem q11Shape33T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34363933696 34303318040 q11Shape33T46=true := by decide

private def q11Shape33T47 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape33T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34372322304 34294929432 q11Shape33T47=true := by decide

private def q11Shape33T45 : Tree 11 := .split 23 q11Shape33T46 q11Shape33T47
private theorem q11Shape33T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34363933696 34294929432 q11Shape33T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34363933696 (34294929432 ||| 2^23) q11Shape33T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34363933696 ||| 2^23) 34294929432 q11Shape33T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T46OK,q11Shape33T47OK⟩

private def q11Shape33T43 : Tree 11 := .split 22 q11Shape33T44 q11Shape33T45
private theorem q11Shape33T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 34294929432 q11Shape33T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 (34294929432 ||| 2^22) q11Shape33T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739392 ||| 2^22) 34294929432 q11Shape33T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T44OK,q11Shape33T45OK⟩

private def q11Shape33T48 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape33T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361836544 34292832280 q11Shape33T48=true := by decide

private def q11Shape33T42 : Tree 11 := .split 21 q11Shape33T43 q11Shape33T48
private theorem q11Shape33T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 34292832280 q11Shape33T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 (34292832280 ||| 2^21) q11Shape33T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739392 ||| 2^21) 34292832280 q11Shape33T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T43OK,q11Shape33T48OK⟩

private def q11Shape33T53 : Tree 11 := (.split 5 (.tip (.cover {0,1,6,7,9,10})) (.split 2 (.split 9 (.split 15 (.split 24 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,3,4,5,8,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {1,2,6,7,9,10}))))
private theorem q11Shape33T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 34307643416 q11Shape33T53=true := by decide

private def q11Shape33T54 : Tree 11 := (.split 5 (.split 0 (.split 1 (.split 2 (.split 24 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,3,4,8,9,10}))) (.tip (.cover {0,2,3,4,5,9})))
private theorem q11Shape33T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34368259072 34299254808 q11Shape33T54=true := by decide

private def q11Shape33T52 : Tree 11 := .split 23 q11Shape33T53 q11Shape33T54
private theorem q11Shape33T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 34299254808 q11Shape33T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 (34299254808 ||| 2^23) q11Shape33T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359870464 ||| 2^23) 34299254808 q11Shape33T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T53OK,q11Shape33T54OK⟩

private def q11Shape33T55 : Tree 11 := (.split 23 (.tip (.cover {1,2,6,7,9,10})) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape33T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34364064768 34295060504 q11Shape33T55=true := by decide

private def q11Shape33T51 : Tree 11 := .split 22 q11Shape33T52 q11Shape33T55
private theorem q11Shape33T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 34295060504 q11Shape33T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 (34295060504 ||| 2^22) q11Shape33T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359870464 ||| 2^22) 34295060504 q11Shape33T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T52OK,q11Shape33T55OK⟩

private def q11Shape33T56 : Tree 11 := (.split 23 (.tip (.cover {1,2,6,7,9,10})) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape33T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361967616 34292963352 q11Shape33T56=true := by decide

private def q11Shape33T50 : Tree 11 := .split 21 q11Shape33T51 q11Shape33T56
private theorem q11Shape33T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 34292963352 q11Shape33T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 (34292963352 ||| 2^21) q11Shape33T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359870464 ||| 2^21) 34292963352 q11Shape33T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T51OK,q11Shape33T56OK⟩

private def q11Shape33T57 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape33T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34360132608 34292701208 q11Shape33T57=true := by decide

private def q11Shape33T49 : Tree 11 := .split 18 q11Shape33T50 q11Shape33T57
private theorem q11Shape33T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 34292701208 q11Shape33T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870464 (34292701208 ||| 2^18) q11Shape33T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359870464 ||| 2^18) 34292701208 q11Shape33T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T50OK,q11Shape33T57OK⟩

private def q11Shape33T41 : Tree 11 := .split 17 q11Shape33T42 q11Shape33T49
private theorem q11Shape33T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 34292701208 q11Shape33T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 (34292701208 ||| 2^17) q11Shape33T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739392 ||| 2^17) 34292701208 q11Shape33T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T42OK,q11Shape33T49OK⟩

private def q11Shape33T58 : Tree 11 := (.split 17 (.split 5 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape33T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359804928 34292635672 q11Shape33T58=true := by decide

private def q11Shape33T40 : Tree 11 := .split 16 q11Shape33T41 q11Shape33T58
private theorem q11Shape33T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 34292635672 q11Shape33T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739392 (34292635672 ||| 2^16) q11Shape33T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739392 ||| 2^16) 34292635672 q11Shape33T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T41OK,q11Shape33T58OK⟩

private def q11Shape33T38 : Tree 11 := .split 35 q11Shape33T39 q11Shape33T40
private theorem q11Shape33T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1024 34292635672 q11Shape33T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1024 (34292635672 ||| 2^35) q11Shape33T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1024 ||| 2^35) 34292635672 q11Shape33T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T39OK,q11Shape33T40OK⟩

private def q11Shape33T59 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape33T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 5120 34292631576 q11Shape33T59=true := by decide

private def q11Shape33T37 : Tree 11 := .split 12 q11Shape33T38 q11Shape33T59
private theorem q11Shape33T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1024 34292631576 q11Shape33T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1024 (34292631576 ||| 2^12) q11Shape33T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1024 ||| 2^12) 34292631576 q11Shape33T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T38OK,q11Shape33T59OK⟩

private def q11Shape33T60 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape33T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 3072 34292629528 q11Shape33T60=true := by decide

private def q11Shape33T36 : Tree 11 := .split 11 q11Shape33T37 q11Shape33T60
private theorem q11Shape33T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1024 34292629528 q11Shape33T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1024 (34292629528 ||| 2^11) q11Shape33T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1024 ||| 2^11) 34292629528 q11Shape33T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T37OK,q11Shape33T60OK⟩

private def q11Shape33T0 : Tree 11 := .split 10 q11Shape33T1 q11Shape33T36
private theorem q11Shape33T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34292629528 q11Shape33T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 (34292629528 ||| 2^10) q11Shape33T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (0 ||| 2^10) 34292629528 q11Shape33T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T1OK,q11Shape33T36OK⟩

def q11Shape33P0 : Tree 11 := q11Shape33T0
theorem q11Shape33P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 0 34292629528 q11Shape33P0=true := q11Shape33T0OK

end Graffiti384b.EffectiveSearch.Q11
