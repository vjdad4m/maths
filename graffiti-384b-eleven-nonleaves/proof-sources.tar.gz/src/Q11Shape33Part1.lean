import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape33T65 : Tree 11 := (.tip (.cover {0,2,3,4,5,8}))
private theorem q11Shape33T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 68652370984 q11Shape33T65=true := by decide

private def q11Shape33T68 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape33T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738384 34294795304 q11Shape33T68=true := by decide

private def q11Shape33T69 : Tree 11 := (.split 22 (.split 23 (.split 17 (.split 12 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,3,4,6,7,10}))) (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,1,3,6,7,10})))) (.split 12 (.tip (.cover {0,1,4,6,9,10})) (.tip (.cover {0,5,7,8,9,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape33T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361835536 34292698152 q11Shape33T69=true := by decide

private def q11Shape33T67 : Tree 11 := .split 21 q11Shape33T68 q11Shape33T69
private theorem q11Shape33T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738384 34292698152 q11Shape33T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738384 (34292698152 ||| 2^21) q11Shape33T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359738384 ||| 2^21) 34292698152 q11Shape33T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T68OK,q11Shape33T69OK⟩

private def q11Shape33T73 : Tree 11 := (.split 22 (.split 23 (.split 12 (.tip (.cover {0,1,6,7,9,10})) (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,1,3,6,7,10})))) (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {0,2,3,4,8,10})))) (.split 23 (.tip (.cover {1,3,6,7,9,10})) (.tip (.cover {0,1,5,6,9,10}))))
private theorem q11Shape33T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803920 34295122984 q11Shape33T73=true := by decide

private def q11Shape33T74 : Tree 11 := (.split 23 (.tip (.cover {1,3,6,7,9,10})) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape33T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361901072 34293025832 q11Shape33T74=true := by decide

private def q11Shape33T72 : Tree 11 := .split 21 q11Shape33T73 q11Shape33T74
private theorem q11Shape33T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803920 34293025832 q11Shape33T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803920 (34293025832 ||| 2^21) q11Shape33T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359803920 ||| 2^21) 34293025832 q11Shape33T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T73OK,q11Shape33T74OK⟩

private def q11Shape33T75 : Tree 11 := (.tip (.cover {0,1,4,7,9,10}))
private theorem q11Shape33T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34360066064 34292763688 q11Shape33T75=true := by decide

private def q11Shape33T71 : Tree 11 := .split 18 q11Shape33T72 q11Shape33T75
private theorem q11Shape33T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803920 34292763688 q11Shape33T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803920 (34292763688 ||| 2^18) q11Shape33T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359803920 ||| 2^18) 34292763688 q11Shape33T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T72OK,q11Shape33T75OK⟩

private def q11Shape33T76 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape33T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359934992 34292632616 q11Shape33T76=true := by decide

private def q11Shape33T70 : Tree 11 := .split 17 q11Shape33T71 q11Shape33T76
private theorem q11Shape33T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803920 34292632616 q11Shape33T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803920 (34292632616 ||| 2^17) q11Shape33T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359803920 ||| 2^17) 34292632616 q11Shape33T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T71OK,q11Shape33T76OK⟩

private def q11Shape33T66 : Tree 11 := .split 16 q11Shape33T67 q11Shape33T70
private theorem q11Shape33T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738384 34292632616 q11Shape33T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738384 (34292632616 ||| 2^16) q11Shape33T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359738384 ||| 2^16) 34292632616 q11Shape33T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T67OK,q11Shape33T70OK⟩

private def q11Shape33T64 : Tree 11 := .split 35 q11Shape33T65 q11Shape33T66
private theorem q11Shape33T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 34292632616 q11Shape33T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 (34292632616 ||| 2^35) q11Shape33T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (16 ||| 2^35) 34292632616 q11Shape33T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T65OK,q11Shape33T66OK⟩

private def q11Shape33T77 : Tree 11 := (.tip (.cover {0,1,2,6,9,10}))
private theorem q11Shape33T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 48 34292632584 q11Shape33T77=true := by decide

private def q11Shape33T63 : Tree 11 := .split 5 q11Shape33T64 q11Shape33T77
private theorem q11Shape33T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 34292632584 q11Shape33T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 (34292632584 ||| 2^5) q11Shape33T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (16 ||| 2^5) 34292632584 q11Shape33T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T64OK,q11Shape33T77OK⟩

private def q11Shape33T79 : Tree 11 := (.split 5 (.split 17 (.split 22 (.split 35 (.tip (.cover {2,3,4,5,6,8})) (.split 16 (.split 18 (.tip (.cover {0,1,5,7,9,10})) (.tip (.cover {0,5,7,8,9,10}))) (.split 23 (.tip (.cover {0,1,4,7,9,10})) (.tip (.cover {0,4,7,8,9,10}))))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,2,6,9,10})))
private theorem q11Shape33T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2064 34292634632 q11Shape33T79=true := by decide

private def q11Shape33T80 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape33T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 6160 34292630536 q11Shape33T80=true := by decide

private def q11Shape33T78 : Tree 11 := .split 12 q11Shape33T79 q11Shape33T80
private theorem q11Shape33T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2064 34292630536 q11Shape33T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2064 (34292630536 ||| 2^12) q11Shape33T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (2064 ||| 2^12) 34292630536 q11Shape33T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T79OK,q11Shape33T80OK⟩

private def q11Shape33T62 : Tree 11 := .split 11 q11Shape33T63 q11Shape33T78
private theorem q11Shape33T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 34292630536 q11Shape33T62=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 (34292630536 ||| 2^11) q11Shape33T63 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (16 ||| 2^11) 34292630536 q11Shape33T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T63OK,q11Shape33T78OK⟩

private def q11Shape33T85 : Tree 11 := (.tip (.cover {0,2,3,4,5,8}))
private theorem q11Shape33T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 68652374056 q11Shape33T85=true := by decide

private def q11Shape33T90 : Tree 11 := (.split 23 (.split 18 (.tip (.cover {0,1,6,7,9,10})) (.split 2 (.split 19 (.tip (.cover {0,2,3,5,8,10})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,2,3,8,9,10})))) (.split 18 (.split 1 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,4,5,9}))))
private theorem q11Shape33T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 34299123752 q11Shape33T90=true := by decide

private def q11Shape33T91 : Tree 11 := (.split 23 (.tip (.cover {1,4,6,7,9,10})) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape33T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34363933712 34294929448 q11Shape33T91=true := by decide

private def q11Shape33T89 : Tree 11 := .split 22 q11Shape33T90 q11Shape33T91
private theorem q11Shape33T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 34294929448 q11Shape33T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 (34294929448 ||| 2^22) q11Shape33T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739408 ||| 2^22) 34294929448 q11Shape33T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T90OK,q11Shape33T91OK⟩

private def q11Shape33T92 : Tree 11 := (.split 23 (.tip (.cover {1,4,6,7,9,10})) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape33T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361836560 34292832296 q11Shape33T92=true := by decide

private def q11Shape33T88 : Tree 11 := .split 21 q11Shape33T89 q11Shape33T92
private theorem q11Shape33T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 34292832296 q11Shape33T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 (34292832296 ||| 2^21) q11Shape33T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739408 ||| 2^21) 34292832296 q11Shape33T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T89OK,q11Shape33T92OK⟩

private def q11Shape33T93 : Tree 11 := (.split 23 (.tip (.cover {0,1,4,6,9,10})) (.tip (.cover {0,3,7,8,9,10})))
private theorem q11Shape33T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359870480 34292701224 q11Shape33T93=true := by decide

private def q11Shape33T87 : Tree 11 := .split 17 q11Shape33T88 q11Shape33T93
private theorem q11Shape33T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 34292701224 q11Shape33T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 (34292701224 ||| 2^17) q11Shape33T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739408 ||| 2^17) 34292701224 q11Shape33T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T88OK,q11Shape33T93OK⟩

private def q11Shape33T94 : Tree 11 := (.split 23 (.tip (.cover {0,1,4,7,9,10})) (.tip (.cover {0,2,6,8,9,10})))
private theorem q11Shape33T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359804944 34292635688 q11Shape33T94=true := by decide

private def q11Shape33T86 : Tree 11 := .split 16 q11Shape33T87 q11Shape33T94
private theorem q11Shape33T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 34292635688 q11Shape33T86=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359739408 (34292635688 ||| 2^16) q11Shape33T87 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359739408 ||| 2^16) 34292635688 q11Shape33T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T87OK,q11Shape33T94OK⟩

private def q11Shape33T84 : Tree 11 := .split 35 q11Shape33T85 q11Shape33T86
private theorem q11Shape33T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 34292635688 q11Shape33T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 (34292635688 ||| 2^35) q11Shape33T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1040 ||| 2^35) 34292635688 q11Shape33T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T85OK,q11Shape33T86OK⟩

private def q11Shape33T95 : Tree 11 := (.tip (.cover {0,1,2,6,9,10}))
private theorem q11Shape33T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1072 34292635656 q11Shape33T95=true := by decide

private def q11Shape33T83 : Tree 11 := .split 5 q11Shape33T84 q11Shape33T95
private theorem q11Shape33T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 34292635656 q11Shape33T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 (34292635656 ||| 2^5) q11Shape33T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1040 ||| 2^5) 34292635656 q11Shape33T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T84OK,q11Shape33T95OK⟩

private def q11Shape33T96 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape33T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 5136 34292631560 q11Shape33T96=true := by decide

private def q11Shape33T82 : Tree 11 := .split 12 q11Shape33T83 q11Shape33T96
private theorem q11Shape33T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 34292631560 q11Shape33T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 (34292631560 ||| 2^12) q11Shape33T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1040 ||| 2^12) 34292631560 q11Shape33T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T83OK,q11Shape33T96OK⟩

private def q11Shape33T97 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape33T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 3088 34292629512 q11Shape33T97=true := by decide

private def q11Shape33T81 : Tree 11 := .split 11 q11Shape33T82 q11Shape33T97
private theorem q11Shape33T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 34292629512 q11Shape33T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1040 (34292629512 ||| 2^11) q11Shape33T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1040 ||| 2^11) 34292629512 q11Shape33T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T82OK,q11Shape33T97OK⟩

private def q11Shape33T61 : Tree 11 := .split 10 q11Shape33T62 q11Shape33T81
private theorem q11Shape33T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 34292629512 q11Shape33T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 (34292629512 ||| 2^10) q11Shape33T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (16 ||| 2^10) 34292629512 q11Shape33T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T62OK,q11Shape33T81OK⟩

def q11Shape33P1 : Tree 11 := q11Shape33T61
theorem q11Shape33P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 16 34292629512 q11Shape33P1=true := q11Shape33T61OK

end Graffiti384b.EffectiveSearch.Q11
