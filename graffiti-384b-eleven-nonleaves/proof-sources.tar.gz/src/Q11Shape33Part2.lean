import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape33T104 : Tree 11 := (.tip (.cover {0,2,3,4,5,8}))
private theorem q11Shape33T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 68652370992 q11Shape33T104=true := by decide

private def q11Shape33T107 : Tree 11 := (.split 21 (.split 22 (.tip (.cover {0,1,6,8,9,10})) (.split 23 (.split 12 (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {1,3,4,6,7,10}))) (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,1,3,6,7,10})))) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape33T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738376 34292829232 q11Shape33T107=true := by decide

private def q11Shape33T110 : Tree 11 := (.split 22 (.split 23 (.split 12 (.tip (.cover {0,1,6,7,9,10})) (.split 13 (.tip (.cover {0,2,4,5,8,10})) (.tip (.cover {0,1,3,6,7,10})))) (.split 13 (.tip (.cover {0,1,2,4,5,10})) (.tip (.cover {0,2,3,4,8,10})))) (.split 23 (.tip (.cover {1,3,6,7,9,10})) (.tip (.cover {0,1,5,6,9,10}))))
private theorem q11Shape33T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359869448 34295057456 q11Shape33T110=true := by decide

private def q11Shape33T111 : Tree 11 := (.split 23 (.tip (.cover {1,3,6,7,9,10})) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape33T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361966600 34292960304 q11Shape33T111=true := by decide

private def q11Shape33T109 : Tree 11 := .split 21 q11Shape33T110 q11Shape33T111
private theorem q11Shape33T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359869448 34292960304 q11Shape33T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359869448 (34292960304 ||| 2^21) q11Shape33T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359869448 ||| 2^21) 34292960304 q11Shape33T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T110OK,q11Shape33T111OK⟩

private def q11Shape33T112 : Tree 11 := (.tip (.cover {0,1,4,6,9,10}))
private theorem q11Shape33T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34360131592 34292698160 q11Shape33T112=true := by decide

private def q11Shape33T108 : Tree 11 := .split 18 q11Shape33T109 q11Shape33T112
private theorem q11Shape33T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359869448 34292698160 q11Shape33T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359869448 (34292698160 ||| 2^18) q11Shape33T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359869448 ||| 2^18) 34292698160 q11Shape33T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T109OK,q11Shape33T112OK⟩

private def q11Shape33T106 : Tree 11 := .split 17 q11Shape33T107 q11Shape33T108
private theorem q11Shape33T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738376 34292698160 q11Shape33T106=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738376 (34292698160 ||| 2^17) q11Shape33T107 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359738376 ||| 2^17) 34292698160 q11Shape33T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T107OK,q11Shape33T108OK⟩

private def q11Shape33T113 : Tree 11 := (.split 17 (.split 12 (.tip (.cover {0,1,4,5,9,10})) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape33T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359803912 34292632624 q11Shape33T113=true := by decide

private def q11Shape33T105 : Tree 11 := .split 16 q11Shape33T106 q11Shape33T113
private theorem q11Shape33T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738376 34292632624 q11Shape33T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359738376 (34292632624 ||| 2^16) q11Shape33T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359738376 ||| 2^16) 34292632624 q11Shape33T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T106OK,q11Shape33T113OK⟩

private def q11Shape33T103 : Tree 11 := .split 35 q11Shape33T104 q11Shape33T105
private theorem q11Shape33T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 34292632624 q11Shape33T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 (34292632624 ||| 2^35) q11Shape33T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (8 ||| 2^35) 34292632624 q11Shape33T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T104OK,q11Shape33T105OK⟩

private def q11Shape33T114 : Tree 11 := (.tip (.cover {0,1,2,7,9,10}))
private theorem q11Shape33T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 40 34292632592 q11Shape33T114=true := by decide

private def q11Shape33T102 : Tree 11 := .split 5 q11Shape33T103 q11Shape33T114
private theorem q11Shape33T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 34292632592 q11Shape33T102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 (34292632592 ||| 2^5) q11Shape33T103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (8 ||| 2^5) 34292632592 q11Shape33T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T103OK,q11Shape33T114OK⟩

private def q11Shape33T118 : Tree 11 := (.tip (.cover {0,2,3,4,5,8}))
private theorem q11Shape33T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2056 68652373040 q11Shape33T118=true := by decide

private def q11Shape33T123 : Tree 11 := (.split 23 (.split 18 (.tip (.cover {0,1,6,7,9,10})) (.split 2 (.split 19 (.tip (.cover {0,2,3,5,8,10})) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,2,3,8,9,10})))) (.split 18 (.split 1 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,2,3,4,8,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,4,5,9}))))
private theorem q11Shape33T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 34299122736 q11Shape33T123=true := by decide

private def q11Shape33T124 : Tree 11 := (.split 23 (.tip (.cover {1,4,6,7,9,10})) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape33T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34363934728 34294928432 q11Shape33T124=true := by decide

private def q11Shape33T122 : Tree 11 := .split 22 q11Shape33T123 q11Shape33T124
private theorem q11Shape33T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 34294928432 q11Shape33T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 (34294928432 ||| 2^22) q11Shape33T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359740424 ||| 2^22) 34294928432 q11Shape33T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T123OK,q11Shape33T124OK⟩

private def q11Shape33T125 : Tree 11 := (.split 23 (.tip (.cover {1,4,6,7,9,10})) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape33T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34361837576 34292831280 q11Shape33T125=true := by decide

private def q11Shape33T121 : Tree 11 := .split 21 q11Shape33T122 q11Shape33T125
private theorem q11Shape33T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 34292831280 q11Shape33T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 (34292831280 ||| 2^21) q11Shape33T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359740424 ||| 2^21) 34292831280 q11Shape33T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T122OK,q11Shape33T125OK⟩

private def q11Shape33T126 : Tree 11 := (.split 23 (.tip (.cover {0,1,4,6,9,10})) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape33T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359871496 34292700208 q11Shape33T126=true := by decide

private def q11Shape33T120 : Tree 11 := .split 17 q11Shape33T121 q11Shape33T126
private theorem q11Shape33T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 34292700208 q11Shape33T120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 (34292700208 ||| 2^17) q11Shape33T121 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359740424 ||| 2^17) 34292700208 q11Shape33T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T121OK,q11Shape33T126OK⟩

private def q11Shape33T127 : Tree 11 := (.split 23 (.tip (.cover {0,1,4,7,9,10})) (.tip (.cover {0,3,6,8,9,10})))
private theorem q11Shape33T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359805960 34292634672 q11Shape33T127=true := by decide

private def q11Shape33T119 : Tree 11 := .split 16 q11Shape33T120 q11Shape33T127
private theorem q11Shape33T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 34292634672 q11Shape33T119=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 34359740424 (34292634672 ||| 2^16) q11Shape33T120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (34359740424 ||| 2^16) 34292634672 q11Shape33T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T120OK,q11Shape33T127OK⟩

private def q11Shape33T117 : Tree 11 := .split 35 q11Shape33T118 q11Shape33T119
private theorem q11Shape33T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2056 34292634672 q11Shape33T117=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2056 (34292634672 ||| 2^35) q11Shape33T118 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (2056 ||| 2^35) 34292634672 q11Shape33T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T118OK,q11Shape33T119OK⟩

private def q11Shape33T128 : Tree 11 := (.tip (.cover {0,1,2,7,9,10}))
private theorem q11Shape33T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2088 34292634640 q11Shape33T128=true := by decide

private def q11Shape33T116 : Tree 11 := .split 5 q11Shape33T117 q11Shape33T128
private theorem q11Shape33T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2056 34292634640 q11Shape33T116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2056 (34292634640 ||| 2^5) q11Shape33T117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (2056 ||| 2^5) 34292634640 q11Shape33T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T117OK,q11Shape33T128OK⟩

private def q11Shape33T129 : Tree 11 := (.tip (.cover {0,1,3,6,9,10}))
private theorem q11Shape33T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 6152 34292630544 q11Shape33T129=true := by decide

private def q11Shape33T115 : Tree 11 := .split 12 q11Shape33T116 q11Shape33T129
private theorem q11Shape33T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2056 34292630544 q11Shape33T115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2056 (34292630544 ||| 2^12) q11Shape33T116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (2056 ||| 2^12) 34292630544 q11Shape33T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T116OK,q11Shape33T129OK⟩

private def q11Shape33T101 : Tree 11 := .split 11 q11Shape33T102 q11Shape33T115
private theorem q11Shape33T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 34292630544 q11Shape33T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 (34292630544 ||| 2^11) q11Shape33T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (8 ||| 2^11) 34292630544 q11Shape33T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T102OK,q11Shape33T115OK⟩

private def q11Shape33T132 : Tree 11 := (.split 5 (.split 16 (.split 21 (.split 35 (.tip (.cover {2,3,4,5,7,8})) (.split 17 (.split 18 (.tip (.cover {0,1,5,6,9,10})) (.tip (.cover {0,5,6,8,9,10}))) (.split 23 (.tip (.cover {0,1,4,6,9,10})) (.tip (.cover {0,4,6,8,9,10}))))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,2,7,9,10})))
private theorem q11Shape33T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1032 34292635664 q11Shape33T132=true := by decide

private def q11Shape33T133 : Tree 11 := (.tip (.cover {0,1,3,7,9,10}))
private theorem q11Shape33T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 5128 34292631568 q11Shape33T133=true := by decide

private def q11Shape33T131 : Tree 11 := .split 12 q11Shape33T132 q11Shape33T133
private theorem q11Shape33T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1032 34292631568 q11Shape33T131=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1032 (34292631568 ||| 2^12) q11Shape33T132 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1032 ||| 2^12) 34292631568 q11Shape33T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T132OK,q11Shape33T133OK⟩

private def q11Shape33T134 : Tree 11 := (.tip (.cover {0,1,3,8,9,10}))
private theorem q11Shape33T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 3080 34292629520 q11Shape33T134=true := by decide

private def q11Shape33T130 : Tree 11 := .split 11 q11Shape33T131 q11Shape33T134
private theorem q11Shape33T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1032 34292629520 q11Shape33T130=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1032 (34292629520 ||| 2^11) q11Shape33T131 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (1032 ||| 2^11) 34292629520 q11Shape33T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T131OK,q11Shape33T134OK⟩

private def q11Shape33T100 : Tree 11 := .split 10 q11Shape33T101 q11Shape33T130
private theorem q11Shape33T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 34292629520 q11Shape33T100=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 (34292629520 ||| 2^10) q11Shape33T101 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (8 ||| 2^10) 34292629520 q11Shape33T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T101OK,q11Shape33T130OK⟩

private def q11Shape33T135 : Tree 11 := (.tip (.cover {0,1,2,8,9,10}))
private theorem q11Shape33T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 24 34292629504 q11Shape33T135=true := by decide

private def q11Shape33T99 : Tree 11 := .split 4 q11Shape33T100 q11Shape33T135
private theorem q11Shape33T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 34292629504 q11Shape33T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 (34292629504 ||| 2^4) q11Shape33T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) (8 ||| 2^4) 34292629504 q11Shape33T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape33T100OK,q11Shape33T135OK⟩

def q11Shape33P2 : Tree 11 := q11Shape33T99
theorem q11Shape33P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8 34292629504 q11Shape33P2=true := q11Shape33T99OK

private def q11Shape33T137 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape33T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 17179869184 17112760320 q11Shape33T137=true := by decide

def q11Shape33P3 : Tree 11 := q11Shape33T137
theorem q11Shape33P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 17179869184 17112760320 q11Shape33P3=true := q11Shape33T137OK

private def q11Shape33T139 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape33T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8589934592 8522825728 q11Shape33T139=true := by decide

def q11Shape33P4 : Tree 11 := q11Shape33T139
theorem q11Shape33P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 8589934592 8522825728 q11Shape33P4=true := q11Shape33T139OK

private def q11Shape33T141 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape33T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 4294967296 4227858432 q11Shape33T141=true := by decide

def q11Shape33P5 : Tree 11 := q11Shape33T141
theorem q11Shape33P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 4294967296 4227858432 q11Shape33P5=true := q11Shape33T141OK

private def q11Shape33T143 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape33T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2147483648 2080374784 q11Shape33T143=true := by decide

def q11Shape33P6 : Tree 11 := q11Shape33T143
theorem q11Shape33P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 2147483648 2080374784 q11Shape33P6=true := q11Shape33T143OK

private def q11Shape33T145 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape33T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 536870912 1543503872 q11Shape33T145=true := by decide

def q11Shape33P7 : Tree 11 := q11Shape33T145
theorem q11Shape33P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 536870912 1543503872 q11Shape33P7=true := q11Shape33T145OK

private def q11Shape33T147 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape33T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 268435456 1275068416 q11Shape33T147=true := by decide

def q11Shape33P8 : Tree 11 := q11Shape33T147
theorem q11Shape33P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 268435456 1275068416 q11Shape33P8=true := q11Shape33T147OK

private def q11Shape33T149 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape33T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1073741824 201326592 q11Shape33T149=true := by decide

def q11Shape33P9 : Tree 11 := q11Shape33T149
theorem q11Shape33P9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 1073741824 201326592 q11Shape33P9=true := q11Shape33T149OK

private def q11Shape33T151 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape33T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 134217728 67108864 q11Shape33T151=true := by decide

def q11Shape33P10 : Tree 11 := q11Shape33T151
theorem q11Shape33P10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 134217728 67108864 q11Shape33P10=true := q11Shape33T151OK

private def q11Shape33T153 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape33T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 67108864 0 q11Shape33T153=true := by decide

def q11Shape33P11 : Tree 11 := q11Shape33T153
theorem q11Shape33P11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,6,4⟩) 67108864 0 q11Shape33P11=true := q11Shape33T153OK

end Graffiti384b.EffectiveSearch.Q11
