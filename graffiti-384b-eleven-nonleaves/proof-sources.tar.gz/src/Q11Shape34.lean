import Q11Shape34Part0
import Q11Shape34Part1

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape34M62 : Tree 11 := .split 21 q11Shape34P0 q11Shape34P1
private theorem q11Shape34M62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 0 q11Shape34M62=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (0 ||| 2^21) q11Shape34P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^21) 0 q11Shape34P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34P0OK,q11Shape34P1OK⟩

theorem q11Shape34_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 34) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 34) b) (adj 11 (forms 34) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) adj_mono b H q11Shape34M62 q11Shape34M62OK

#print axioms q11Shape34_cover

end Graffiti384b.EffectiveSearch.Q11
