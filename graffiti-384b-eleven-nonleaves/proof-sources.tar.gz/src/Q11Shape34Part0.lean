import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape34T10 : Tree 11 := (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9}))))
private theorem q11Shape34T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 67744301056 q11Shape34T10=true := by decide

private def q11Shape34T11 : Tree 11 := (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape34T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 16777216 67727523840 q11Shape34T11=true := by decide

private def q11Shape34T9 : Tree 11 := .split 24 q11Shape34T10 q11Shape34T11
private theorem q11Shape34T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 67727523840 q11Shape34T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (67727523840 ||| 2^24) q11Shape34T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^24) 67727523840 q11Shape34T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T10OK,q11Shape34T11OK⟩

private def q11Shape34T12 : Tree 11 := (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape34T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8388608 67719135232 q11Shape34T12=true := by decide

private def q11Shape34T8 : Tree 11 := .split 23 q11Shape34T9 q11Shape34T12
private theorem q11Shape34T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 67719135232 q11Shape34T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (67719135232 ||| 2^23) q11Shape34T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^23) 67719135232 q11Shape34T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T9OK,q11Shape34T12OK⟩

private def q11Shape34T13 : Tree 11 := (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape34T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4294967296 63424167936 q11Shape34T13=true := by decide

private def q11Shape34T7 : Tree 11 := .split 32 q11Shape34T8 q11Shape34T13
private theorem q11Shape34T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 63424167936 q11Shape34T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (63424167936 ||| 2^32) q11Shape34T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^32) 63424167936 q11Shape34T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T8OK,q11Shape34T13OK⟩

private def q11Shape34T14 : Tree 11 := (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape34T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2147483648 61276684288 q11Shape34T14=true := by decide

private def q11Shape34T6 : Tree 11 := .split 31 q11Shape34T7 q11Shape34T14
private theorem q11Shape34T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 61276684288 q11Shape34T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (61276684288 ||| 2^31) q11Shape34T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^31) 61276684288 q11Shape34T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T7OK,q11Shape34T14OK⟩

private def q11Shape34T16 : Tree 11 := (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape34T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 1073741824 62350426112 q11Shape34T16=true := by decide

private def q11Shape34T17 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape34T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 3221225472 60202942464 q11Shape34T17=true := by decide

private def q11Shape34T15 : Tree 11 := .split 31 q11Shape34T16 q11Shape34T17
private theorem q11Shape34T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 1073741824 60202942464 q11Shape34T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 1073741824 (60202942464 ||| 2^31) q11Shape34T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (1073741824 ||| 2^31) 60202942464 q11Shape34T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T16OK,q11Shape34T17OK⟩

private def q11Shape34T5 : Tree 11 := .split 30 q11Shape34T6 q11Shape34T15
private theorem q11Shape34T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 60202942464 q11Shape34T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (60202942464 ||| 2^30) q11Shape34T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^30) 60202942464 q11Shape34T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T6OK,q11Shape34T15OK⟩

private def q11Shape34T19 : Tree 11 := (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9})))
private theorem q11Shape34T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 34359738368 26916945920 q11Shape34T19=true := by decide

private def q11Shape34T20 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape34T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 35433480192 25843204096 q11Shape34T20=true := by decide

private def q11Shape34T18 : Tree 11 := .split 30 q11Shape34T19 q11Shape34T20
private theorem q11Shape34T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 34359738368 25843204096 q11Shape34T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 34359738368 (25843204096 ||| 2^30) q11Shape34T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (34359738368 ||| 2^30) 25843204096 q11Shape34T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T19OK,q11Shape34T20OK⟩

private def q11Shape34T4 : Tree 11 := .split 35 q11Shape34T5 q11Shape34T18
private theorem q11Shape34T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 25843204096 q11Shape34T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (25843204096 ||| 2^35) q11Shape34T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^35) 25843204096 q11Shape34T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T5OK,q11Shape34T18OK⟩

private def q11Shape34T23 : Tree 11 := (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape34T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17179869184 44096815104 q11Shape34T23=true := by decide

private def q11Shape34T24 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape34T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 18253611008 43023073280 q11Shape34T24=true := by decide

private def q11Shape34T22 : Tree 11 := .split 30 q11Shape34T23 q11Shape34T24
private theorem q11Shape34T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17179869184 43023073280 q11Shape34T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17179869184 (43023073280 ||| 2^30) q11Shape34T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (17179869184 ||| 2^30) 43023073280 q11Shape34T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T23OK,q11Shape34T24OK⟩

private def q11Shape34T25 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape34T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 51539607552 8663334912 q11Shape34T25=true := by decide

private def q11Shape34T21 : Tree 11 := .split 35 q11Shape34T22 q11Shape34T25
private theorem q11Shape34T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17179869184 8663334912 q11Shape34T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17179869184 (8663334912 ||| 2^35) q11Shape34T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (17179869184 ||| 2^35) 8663334912 q11Shape34T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T22OK,q11Shape34T25OK⟩

private def q11Shape34T3 : Tree 11 := .split 34 q11Shape34T4 q11Shape34T21
private theorem q11Shape34T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 8663334912 q11Shape34T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (8663334912 ||| 2^34) q11Shape34T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^34) 8663334912 q11Shape34T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T4OK,q11Shape34T21OK⟩

private def q11Shape34T30 : Tree 11 := (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,8})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape34T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 54834233344 q11Shape34T30=true := by decide

private def q11Shape34T31 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape34T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 10737418240 52686749696 q11Shape34T31=true := by decide

private def q11Shape34T29 : Tree 11 := .split 31 q11Shape34T30 q11Shape34T31
private theorem q11Shape34T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 52686749696 q11Shape34T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 (52686749696 ||| 2^31) q11Shape34T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (8589934592 ||| 2^31) 52686749696 q11Shape34T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T30OK,q11Shape34T31OK⟩

private def q11Shape34T32 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape34T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 9663676416 51613007872 q11Shape34T32=true := by decide

private def q11Shape34T28 : Tree 11 := .split 30 q11Shape34T29 q11Shape34T32
private theorem q11Shape34T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 51613007872 q11Shape34T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 (51613007872 ||| 2^30) q11Shape34T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (8589934592 ||| 2^30) 51613007872 q11Shape34T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T29OK,q11Shape34T32OK⟩

private def q11Shape34T33 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape34T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 42949672960 17253269504 q11Shape34T33=true := by decide

private def q11Shape34T27 : Tree 11 := .split 35 q11Shape34T28 q11Shape34T33
private theorem q11Shape34T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 17253269504 q11Shape34T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 (17253269504 ||| 2^35) q11Shape34T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (8589934592 ||| 2^35) 17253269504 q11Shape34T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T28OK,q11Shape34T33OK⟩

private def q11Shape34T34 : Tree 11 := (.tip (.cover {0,1,5,6,7,8}))
private theorem q11Shape34T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 25769803776 73400320 q11Shape34T34=true := by decide

private def q11Shape34T26 : Tree 11 := .split 34 q11Shape34T27 q11Shape34T34
private theorem q11Shape34T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 73400320 q11Shape34T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8589934592 (73400320 ||| 2^34) q11Shape34T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (8589934592 ||| 2^34) 73400320 q11Shape34T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T27OK,q11Shape34T34OK⟩

private def q11Shape34T2 : Tree 11 := .split 33 q11Shape34T3 q11Shape34T26
private theorem q11Shape34T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 73400320 q11Shape34T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (73400320 ||| 2^33) q11Shape34T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^33) 73400320 q11Shape34T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T3OK,q11Shape34T26OK⟩

private def q11Shape34T37 : Tree 11 := (.split 35 (.split 30 (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,8,9})))
private theorem q11Shape34T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 67108864 25776095232 q11Shape34T37=true := by decide

private def q11Shape34T38 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape34T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17246978048 8596226048 q11Shape34T38=true := by decide

private def q11Shape34T36 : Tree 11 := .split 34 q11Shape34T37 q11Shape34T38
private theorem q11Shape34T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 67108864 8596226048 q11Shape34T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 67108864 (8596226048 ||| 2^34) q11Shape34T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (67108864 ||| 2^34) 8596226048 q11Shape34T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T37OK,q11Shape34T38OK⟩

private def q11Shape34T39 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape34T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8657043456 6291456 q11Shape34T39=true := by decide

private def q11Shape34T35 : Tree 11 := .split 33 q11Shape34T36 q11Shape34T39
private theorem q11Shape34T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 67108864 6291456 q11Shape34T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 67108864 (6291456 ||| 2^33) q11Shape34T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (67108864 ||| 2^33) 6291456 q11Shape34T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T36OK,q11Shape34T39OK⟩

private def q11Shape34T1 : Tree 11 := .split 26 q11Shape34T2 q11Shape34T35
private theorem q11Shape34T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 6291456 q11Shape34T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (6291456 ||| 2^26) q11Shape34T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^26) 6291456 q11Shape34T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T2OK,q11Shape34T35OK⟩

private def q11Shape34T46 : Tree 11 := (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,6,7,8,9})))
private theorem q11Shape34T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 63419973632 q11Shape34T46=true := by decide

private def q11Shape34T47 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape34T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2151677952 61272489984 q11Shape34T47=true := by decide

private def q11Shape34T45 : Tree 11 := .split 31 q11Shape34T46 q11Shape34T47
private theorem q11Shape34T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 61272489984 q11Shape34T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 (61272489984 ||| 2^31) q11Shape34T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (4194304 ||| 2^31) 61272489984 q11Shape34T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T46OK,q11Shape34T47OK⟩

private def q11Shape34T48 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape34T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 1077936128 60198748160 q11Shape34T48=true := by decide

private def q11Shape34T44 : Tree 11 := .split 30 q11Shape34T45 q11Shape34T48
private theorem q11Shape34T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 60198748160 q11Shape34T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 (60198748160 ||| 2^30) q11Shape34T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (4194304 ||| 2^30) 60198748160 q11Shape34T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T45OK,q11Shape34T48OK⟩

private def q11Shape34T49 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape34T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 34363932672 25839009792 q11Shape34T49=true := by decide

private def q11Shape34T43 : Tree 11 := .split 35 q11Shape34T44 q11Shape34T49
private theorem q11Shape34T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 25839009792 q11Shape34T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 (25839009792 ||| 2^35) q11Shape34T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (4194304 ||| 2^35) 25839009792 q11Shape34T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T44OK,q11Shape34T49OK⟩

private def q11Shape34T50 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape34T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17184063488 8659140608 q11Shape34T50=true := by decide

private def q11Shape34T42 : Tree 11 := .split 34 q11Shape34T43 q11Shape34T50
private theorem q11Shape34T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 8659140608 q11Shape34T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 (8659140608 ||| 2^34) q11Shape34T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (4194304 ||| 2^34) 8659140608 q11Shape34T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T43OK,q11Shape34T50OK⟩

private def q11Shape34T51 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape34T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8594128896 69206016 q11Shape34T51=true := by decide

private def q11Shape34T41 : Tree 11 := .split 33 q11Shape34T42 q11Shape34T51
private theorem q11Shape34T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 69206016 q11Shape34T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 (69206016 ||| 2^33) q11Shape34T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (4194304 ||| 2^33) 69206016 q11Shape34T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T42OK,q11Shape34T51OK⟩

private def q11Shape34T52 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape34T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 71303168 2097152 q11Shape34T52=true := by decide

private def q11Shape34T40 : Tree 11 := .split 26 q11Shape34T41 q11Shape34T52
private theorem q11Shape34T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 2097152 q11Shape34T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 4194304 (2097152 ||| 2^26) q11Shape34T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (4194304 ||| 2^26) 2097152 q11Shape34T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T41OK,q11Shape34T52OK⟩

private def q11Shape34T0 : Tree 11 := .split 22 q11Shape34T1 q11Shape34T40
private theorem q11Shape34T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 2097152 q11Shape34T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 (2097152 ||| 2^22) q11Shape34T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (0 ||| 2^22) 2097152 q11Shape34T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T1OK,q11Shape34T40OK⟩

def q11Shape34P0 : Tree 11 := q11Shape34T0
theorem q11Shape34P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 0 2097152 q11Shape34P0=true := q11Shape34T0OK

end Graffiti384b.EffectiveSearch.Q11
