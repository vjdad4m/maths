import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape34T57 : Tree 11 := (.split 35 (.split 30 (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9})))
private theorem q11Shape34T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 25841106944 q11Shape34T57=true := by decide

private def q11Shape34T58 : Tree 11 := (.tip (.cover {0,1,5,7,8,9}))
private theorem q11Shape34T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 17181966336 8661237760 q11Shape34T58=true := by decide

private def q11Shape34T56 : Tree 11 := .split 34 q11Shape34T57 q11Shape34T58
private theorem q11Shape34T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 8661237760 q11Shape34T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 (8661237760 ||| 2^34) q11Shape34T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (2097152 ||| 2^34) 8661237760 q11Shape34T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T57OK,q11Shape34T58OK⟩

private def q11Shape34T59 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape34T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 8592031744 71303168 q11Shape34T59=true := by decide

private def q11Shape34T55 : Tree 11 := .split 33 q11Shape34T56 q11Shape34T59
private theorem q11Shape34T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 71303168 q11Shape34T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 (71303168 ||| 2^33) q11Shape34T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (2097152 ||| 2^33) 71303168 q11Shape34T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T56OK,q11Shape34T59OK⟩

private def q11Shape34T60 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape34T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 69206016 4194304 q11Shape34T60=true := by decide

private def q11Shape34T54 : Tree 11 := .split 26 q11Shape34T55 q11Shape34T60
private theorem q11Shape34T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 4194304 q11Shape34T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 (4194304 ||| 2^26) q11Shape34T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (2097152 ||| 2^26) 4194304 q11Shape34T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T55OK,q11Shape34T60OK⟩

private def q11Shape34T61 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape34T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 6291456 0 q11Shape34T61=true := by decide

private def q11Shape34T53 : Tree 11 := .split 22 q11Shape34T54 q11Shape34T61
private theorem q11Shape34T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 0 q11Shape34T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 (0 ||| 2^22) q11Shape34T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) (2097152 ||| 2^22) 0 q11Shape34T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape34T54OK,q11Shape34T61OK⟩

def q11Shape34P1 : Tree 11 := q11Shape34T53
theorem q11Shape34P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,3⟩) 2097152 0 q11Shape34P1=true := q11Shape34T53OK

end Graffiti384b.EffectiveSearch.Q11
