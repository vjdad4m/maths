import Q11Shape35Part0

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q11Shape35_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 35) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 35) b) (adj 11 (forms 35) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) adj_mono b H q11Shape35P0 q11Shape35P0OK

#print axioms q11Shape35_cover

end Graffiti384b.EffectiveSearch.Q11
