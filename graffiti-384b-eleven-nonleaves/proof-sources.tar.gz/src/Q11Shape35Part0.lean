import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape35T3 : Tree 11 := (.split 28 (.split 30 (.split 31 (.split 29 (.split 32 (.split 34 (.split 35 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,10})))
private theorem q11Shape35T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 8791261184 q11Shape35T3=true := by decide

private def q11Shape35T4 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape35T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 134217728 8657043456 q11Shape35T4=true := by decide

private def q11Shape35T2 : Tree 11 := .split 27 q11Shape35T3 q11Shape35T4
private theorem q11Shape35T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 8657043456 q11Shape35T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 (8657043456 ||| 2^27) q11Shape35T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) (0 ||| 2^27) 8657043456 q11Shape35T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape35T3OK,q11Shape35T4OK⟩

private def q11Shape35T5 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape35T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 8589934592 67108864 q11Shape35T5=true := by decide

private def q11Shape35T1 : Tree 11 := .split 33 q11Shape35T2 q11Shape35T5
private theorem q11Shape35T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 67108864 q11Shape35T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 (67108864 ||| 2^33) q11Shape35T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) (0 ||| 2^33) 67108864 q11Shape35T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape35T2OK,q11Shape35T5OK⟩

private def q11Shape35T6 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape35T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 67108864 0 q11Shape35T6=true := by decide

private def q11Shape35T0 : Tree 11 := .split 26 q11Shape35T1 q11Shape35T6
private theorem q11Shape35T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 0 q11Shape35T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 (0 ||| 2^26) q11Shape35T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) (0 ||| 2^26) 0 q11Shape35T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape35T1OK,q11Shape35T6OK⟩

def q11Shape35P0 : Tree 11 := q11Shape35T0
theorem q11Shape35P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,7,7,4⟩) 0 0 q11Shape35P0=true := q11Shape35T0OK

end Graffiti384b.EffectiveSearch.Q11
