import Q11Shape36Part0
import Q11Shape36Part1
import Q11Shape36Part2

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape36M38 : Tree 11 := .split 16 q11Shape36P0 q11Shape36P1
private theorem q11Shape36M38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 32768 q11Shape36M38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 (32768 ||| 2^16) q11Shape36P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (0 ||| 2^16) 32768 q11Shape36P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36P0OK,q11Shape36P1OK⟩
private def q11Shape36M56 : Tree 11 := .split 15 q11Shape36M38 q11Shape36P2
private theorem q11Shape36M56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 0 q11Shape36M56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 (0 ||| 2^15) q11Shape36M38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (0 ||| 2^15) 0 q11Shape36P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36M38OK,q11Shape36P2OK⟩

theorem q11Shape36_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 36) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 36) b) (adj 11 (forms 36) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) adj_mono b H q11Shape36M56 q11Shape36M56OK

#print axioms q11Shape36_cover

end Graffiti384b.EffectiveSearch.Q11
