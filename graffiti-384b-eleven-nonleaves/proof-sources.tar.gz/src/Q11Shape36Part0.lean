import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape36T4 : Tree 11 := (.split 26 (.tip (.cover {0,2,3,8,9,10})) (.split 23 (.split 27 (.tip (.cover {0,2,3,7,9,10})) (.tip (.cover {0,2,3,6,9,10}))) (.split 35 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,5,6,9,10})) (.tip (.cover {0,2,5,6,9,10})))) (.tip (.cover {0,1,4,5,6,9})))))
private theorem q11Shape36T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 6782976 q11Shape36T4=true := by decide

private def q11Shape36T6 : Tree 11 := (.split 27 (.tip (.cover {0,2,3,7,9,10})) (.split 35 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,5,6,9,10})) (.tip (.cover {0,2,5,6,9,10})))) (.tip (.cover {0,1,4,5,6,9}))))
private theorem q11Shape36T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 4194304 10977280 q11Shape36T6=true := by decide

private def q11Shape36T7 : Tree 11 := (.split 35 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,5,6,9,10})) (.tip (.cover {0,2,5,6,9,10})))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape36T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 12582912 2588672 q11Shape36T7=true := by decide

private def q11Shape36T5 : Tree 11 := .split 23 q11Shape36T6 q11Shape36T7
private theorem q11Shape36T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 4194304 2588672 q11Shape36T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 4194304 (2588672 ||| 2^23) q11Shape36T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (4194304 ||| 2^23) 2588672 q11Shape36T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T6OK,q11Shape36T7OK⟩

private def q11Shape36T3 : Tree 11 := .split 22 q11Shape36T4 q11Shape36T5
private theorem q11Shape36T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 2588672 q11Shape36T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 (2588672 ||| 2^22) q11Shape36T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (0 ||| 2^22) 2588672 q11Shape36T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T4OK,q11Shape36T5OK⟩

private def q11Shape36T10 : Tree 11 := (.split 30 (.tip (.cover {0,2,3,6,9,10})) (.split 35 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,2,5,7,9,10})))) (.tip (.cover {0,1,4,5,7,9}))))
private theorem q11Shape36T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2097152 13074432 q11Shape36T10=true := by decide

private def q11Shape36T11 : Tree 11 := (.split 35 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,5,7,9,10})) (.tip (.cover {0,2,5,7,9,10})))) (.tip (.cover {0,1,4,5,7,9})))
private theorem q11Shape36T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 10485760 4685824 q11Shape36T11=true := by decide

private def q11Shape36T9 : Tree 11 := .split 23 q11Shape36T10 q11Shape36T11
private theorem q11Shape36T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2097152 4685824 q11Shape36T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2097152 (4685824 ||| 2^23) q11Shape36T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (2097152 ||| 2^23) 4685824 q11Shape36T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T10OK,q11Shape36T11OK⟩

private def q11Shape36T12 : Tree 11 := (.split 23 (.split 35 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.cover {0,3,5,8,9,10})) (.tip (.cover {0,2,5,8,9,10})))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape36T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 6291456 491520 q11Shape36T12=true := by decide

private def q11Shape36T8 : Tree 11 := .split 22 q11Shape36T9 q11Shape36T12
private theorem q11Shape36T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2097152 491520 q11Shape36T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2097152 (491520 ||| 2^22) q11Shape36T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (2097152 ||| 2^22) 491520 q11Shape36T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T9OK,q11Shape36T12OK⟩

private def q11Shape36T2 : Tree 11 := .split 21 q11Shape36T3 q11Shape36T8
private theorem q11Shape36T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 491520 q11Shape36T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 (491520 ||| 2^21) q11Shape36T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (0 ||| 2^21) 491520 q11Shape36T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T3OK,q11Shape36T8OK⟩

private def q11Shape36T15 : Tree 11 := (.split 26 (.tip (.cover {0,2,3,8,9,10})) (.split 23 (.split 35 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover {0,3,4,6,9,10})) (.tip (.cover {0,2,4,6,9,10})))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,6,8,9,10}))))
private theorem q11Shape36T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 262144 6520832 q11Shape36T15=true := by decide

private def q11Shape36T16 : Tree 11 := (.split 26 (.split 27 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6}))))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,7,9,10})))
private theorem q11Shape36T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 4456448 2326528 q11Shape36T16=true := by decide

private def q11Shape36T14 : Tree 11 := .split 22 q11Shape36T15 q11Shape36T16
private theorem q11Shape36T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 262144 2326528 q11Shape36T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 262144 (2326528 ||| 2^22) q11Shape36T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (262144 ||| 2^22) 2326528 q11Shape36T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T15OK,q11Shape36T16OK⟩

private def q11Shape36T17 : Tree 11 := (.split 22 (.split 26 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7}))))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape36T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2359296 229376 q11Shape36T17=true := by decide

private def q11Shape36T13 : Tree 11 := .split 21 q11Shape36T14 q11Shape36T17
private theorem q11Shape36T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 262144 229376 q11Shape36T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 262144 (229376 ||| 2^21) q11Shape36T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (262144 ||| 2^21) 229376 q11Shape36T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T14OK,q11Shape36T17OK⟩

private def q11Shape36T1 : Tree 11 := .split 18 q11Shape36T2 q11Shape36T13
private theorem q11Shape36T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 229376 q11Shape36T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 (229376 ||| 2^18) q11Shape36T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (0 ||| 2^18) 229376 q11Shape36T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T2OK,q11Shape36T13OK⟩

private def q11Shape36T22 : Tree 11 := (.split 27 (.tip (.cover {0,2,3,7,9,10})) (.split 35 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover {0,3,4,6,9,10})) (.tip (.cover {0,2,4,6,9,10})))) (.tip (.cover {0,1,4,5,6,9}))))
private theorem q11Shape36T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 15040512 q11Shape36T22=true := by decide

private def q11Shape36T23 : Tree 11 := (.split 26 (.split 27 (.split 35 (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover {0,3,4,5,9,10})) (.tip (.cover {0,2,4,5,9,10})))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,5,7,9,10})))
private theorem q11Shape36T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 8519680 6651904 q11Shape36T23=true := by decide

private def q11Shape36T21 : Tree 11 := .split 23 q11Shape36T22 q11Shape36T23
private theorem q11Shape36T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 6651904 q11Shape36T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 (6651904 ||| 2^23) q11Shape36T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (131072 ||| 2^23) 6651904 q11Shape36T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T22OK,q11Shape36T23OK⟩

private def q11Shape36T24 : Tree 11 := (.split 26 (.split 27 (.split 23 (.tip (.cover {0,2,3,7,9,10})) (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover {0,3,4,5,9,10})) (.tip (.cover {0,2,4,5,9,10})))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape36T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 4325376 2457600 q11Shape36T24=true := by decide

private def q11Shape36T20 : Tree 11 := .split 22 q11Shape36T21 q11Shape36T24
private theorem q11Shape36T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 2457600 q11Shape36T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 (2457600 ||| 2^22) q11Shape36T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (131072 ||| 2^22) 2457600 q11Shape36T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T21OK,q11Shape36T24OK⟩

private def q11Shape36T25 : Tree 11 := (.split 23 (.split 27 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8}))))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape36T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2228224 360448 q11Shape36T25=true := by decide

private def q11Shape36T19 : Tree 11 := .split 21 q11Shape36T20 q11Shape36T25
private theorem q11Shape36T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 360448 q11Shape36T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 (360448 ||| 2^21) q11Shape36T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (131072 ||| 2^21) 360448 q11Shape36T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T20OK,q11Shape36T25OK⟩

private def q11Shape36T26 : Tree 11 := (.split 21 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,6}))))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape36T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 393216 98304 q11Shape36T26=true := by decide

private def q11Shape36T18 : Tree 11 := .split 18 q11Shape36T19 q11Shape36T26
private theorem q11Shape36T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 98304 q11Shape36T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 131072 (98304 ||| 2^18) q11Shape36T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (131072 ||| 2^18) 98304 q11Shape36T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T19OK,q11Shape36T26OK⟩

private def q11Shape36T0 : Tree 11 := .split 17 q11Shape36T1 q11Shape36T18
private theorem q11Shape36T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 98304 q11Shape36T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 (98304 ||| 2^17) q11Shape36T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (0 ||| 2^17) 98304 q11Shape36T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T1OK,q11Shape36T18OK⟩

def q11Shape36P0 : Tree 11 := q11Shape36T0
theorem q11Shape36P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 0 98304 q11Shape36P0=true := q11Shape36T0OK

end Graffiti384b.EffectiveSearch.Q11
