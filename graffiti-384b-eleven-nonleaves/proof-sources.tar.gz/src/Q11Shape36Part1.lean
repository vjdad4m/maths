import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape36T32 : Tree 11 := (.split 30 (.tip (.cover {0,2,3,6,9,10})) (.split 35 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.cover {0,3,4,7,9,10})) (.tip (.cover {0,2,4,7,9,10})))) (.tip (.cover {0,1,4,5,7,9}))))
private theorem q11Shape36T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 15106048 q11Shape36T32=true := by decide

private def q11Shape36T33 : Tree 11 := (.split 26 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7}))))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape36T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 8454144 6717440 q11Shape36T33=true := by decide

private def q11Shape36T31 : Tree 11 := .split 23 q11Shape36T32 q11Shape36T33
private theorem q11Shape36T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 6717440 q11Shape36T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 (6717440 ||| 2^23) q11Shape36T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (65536 ||| 2^23) 6717440 q11Shape36T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T32OK,q11Shape36T33OK⟩

private def q11Shape36T34 : Tree 11 := (.split 23 (.split 27 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8}))))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape36T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 4259840 2523136 q11Shape36T34=true := by decide

private def q11Shape36T30 : Tree 11 := .split 22 q11Shape36T31 q11Shape36T34
private theorem q11Shape36T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 2523136 q11Shape36T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 (2523136 ||| 2^22) q11Shape36T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (65536 ||| 2^22) 2523136 q11Shape36T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T31OK,q11Shape36T34OK⟩

private def q11Shape36T35 : Tree 11 := (.split 26 (.split 27 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,6,7,8}))))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape36T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2162688 425984 q11Shape36T35=true := by decide

private def q11Shape36T29 : Tree 11 := .split 21 q11Shape36T30 q11Shape36T35
private theorem q11Shape36T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 425984 q11Shape36T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 (425984 ||| 2^21) q11Shape36T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (65536 ||| 2^21) 425984 q11Shape36T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T30OK,q11Shape36T35OK⟩

private def q11Shape36T36 : Tree 11 := (.split 22 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,7}))))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape36T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 327680 163840 q11Shape36T36=true := by decide

private def q11Shape36T28 : Tree 11 := .split 18 q11Shape36T29 q11Shape36T36
private theorem q11Shape36T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 163840 q11Shape36T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 (163840 ||| 2^18) q11Shape36T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (65536 ||| 2^18) 163840 q11Shape36T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T29OK,q11Shape36T36OK⟩

private def q11Shape36T37 : Tree 11 := (.split 18 (.split 23 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,5,8}))))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape36T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 196608 32768 q11Shape36T37=true := by decide

private def q11Shape36T27 : Tree 11 := .split 17 q11Shape36T28 q11Shape36T37
private theorem q11Shape36T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 32768 q11Shape36T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 (32768 ||| 2^17) q11Shape36T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (65536 ||| 2^17) 32768 q11Shape36T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T28OK,q11Shape36T37OK⟩

def q11Shape36P1 : Tree 11 := q11Shape36T27
theorem q11Shape36P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 65536 32768 q11Shape36P1=true := q11Shape36T27OK

end Graffiti384b.EffectiveSearch.Q11
