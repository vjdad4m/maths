import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape36T47 : Tree 11 := (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.split 35 (.split 0 (.tip (.small 1)) (.split 3 (.tip (.cover {0,3,4,7,9,10})) (.tip (.cover {0,2,4,7,9,10})))) (.tip (.cover {0,1,4,6,7,9}))))
private theorem q11Shape36T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 216465408 q11Shape36T47=true := by decide

private def q11Shape36T48 : Tree 11 := (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 4 (.tip (.cover {0,3,4,6,9,10})) (.tip (.cover {0,2,4,6,9,10})))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape36T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 134250496 82247680 q11Shape36T48=true := by decide

private def q11Shape36T46 : Tree 11 := .split 27 q11Shape36T47 q11Shape36T48
private theorem q11Shape36T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 82247680 q11Shape36T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (82247680 ||| 2^27) q11Shape36T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^27) 82247680 q11Shape36T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T47OK,q11Shape36T48OK⟩

private def q11Shape36T49 : Tree 11 := (.split 27 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8}))))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape36T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 67141632 15138816 q11Shape36T49=true := by decide

private def q11Shape36T45 : Tree 11 := .split 26 q11Shape36T46 q11Shape36T49
private theorem q11Shape36T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 15138816 q11Shape36T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (15138816 ||| 2^26) q11Shape36T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^26) 15138816 q11Shape36T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T46OK,q11Shape36T49OK⟩

private def q11Shape36T50 : Tree 11 := (.split 26 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,7}))))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape36T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 8421376 6750208 q11Shape36T50=true := by decide

private def q11Shape36T44 : Tree 11 := .split 23 q11Shape36T45 q11Shape36T50
private theorem q11Shape36T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 6750208 q11Shape36T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (6750208 ||| 2^23) q11Shape36T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^23) 6750208 q11Shape36T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T45OK,q11Shape36T50OK⟩

private def q11Shape36T51 : Tree 11 := (.split 23 (.split 27 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,6,8}))))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape36T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 4227072 2555904 q11Shape36T51=true := by decide

private def q11Shape36T43 : Tree 11 := .split 22 q11Shape36T44 q11Shape36T51
private theorem q11Shape36T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 2555904 q11Shape36T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (2555904 ||| 2^22) q11Shape36T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^22) 2555904 q11Shape36T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T44OK,q11Shape36T51OK⟩

private def q11Shape36T52 : Tree 11 := (.split 22 (.split 23 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,5,7,8}))))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape36T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 2129920 458752 q11Shape36T52=true := by decide

private def q11Shape36T42 : Tree 11 := .split 21 q11Shape36T43 q11Shape36T52
private theorem q11Shape36T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 458752 q11Shape36T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (458752 ||| 2^21) q11Shape36T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^21) 458752 q11Shape36T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T43OK,q11Shape36T52OK⟩

private def q11Shape36T53 : Tree 11 := (.split 26 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,7}))))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape36T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 294912 196608 q11Shape36T53=true := by decide

private def q11Shape36T41 : Tree 11 := .split 18 q11Shape36T42 q11Shape36T53
private theorem q11Shape36T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 196608 q11Shape36T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (196608 ||| 2^18) q11Shape36T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^18) 196608 q11Shape36T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T42OK,q11Shape36T53OK⟩

private def q11Shape36T54 : Tree 11 := (.split 18 (.split 27 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,6,8}))))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape36T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 163840 65536 q11Shape36T54=true := by decide

private def q11Shape36T40 : Tree 11 := .split 17 q11Shape36T41 q11Shape36T54
private theorem q11Shape36T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 65536 q11Shape36T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (65536 ||| 2^17) q11Shape36T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^17) 65536 q11Shape36T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T41OK,q11Shape36T54OK⟩

private def q11Shape36T55 : Tree 11 := (.split 17 (.split 18 (.split 30 (.split 35 (.split 0 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover {0,1,2,4,7,8}))))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,8,9,10})))
private theorem q11Shape36T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 98304 0 q11Shape36T55=true := by decide

private def q11Shape36T39 : Tree 11 := .split 16 q11Shape36T40 q11Shape36T55
private theorem q11Shape36T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 0 q11Shape36T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 (0 ||| 2^16) q11Shape36T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) (32768 ||| 2^16) 0 q11Shape36T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape36T40OK,q11Shape36T55OK⟩

def q11Shape36P2 : Tree 11 := q11Shape36T39
theorem q11Shape36P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,2⟩) 32768 0 q11Shape36P2=true := q11Shape36T39OK

end Graffiti384b.EffectiveSearch.Q11
