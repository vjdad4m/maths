import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape37T6 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape37T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 1289748480 q11Shape37T6=true := by decide

private def q11Shape37T8 : Tree 11 := (.split 31 (.split 33 (.split 24 (.split 25 (.split 29 (.split 32 (.tip (.cover {0,2,3,4,8,9})) (.split 34 (.tip (.cover {0,2,3,4,7,9})) (.tip (.cover {0,1,5,6,9,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape37T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1073741824 484442112 q11Shape37T8=true := by decide

private def q11Shape37T9 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape37T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1342177280 216006656 q11Shape37T9=true := by decide

private def q11Shape37T7 : Tree 11 := .split 28 q11Shape37T8 q11Shape37T9
private theorem q11Shape37T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1073741824 216006656 q11Shape37T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1073741824 (216006656 ||| 2^28) q11Shape37T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (1073741824 ||| 2^28) 216006656 q11Shape37T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T8OK,q11Shape37T9OK⟩

private def q11Shape37T5 : Tree 11 := .split 30 q11Shape37T6 q11Shape37T7
private theorem q11Shape37T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 216006656 q11Shape37T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 (216006656 ||| 2^30) q11Shape37T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (0 ||| 2^30) 216006656 q11Shape37T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T6OK,q11Shape37T7OK⟩

private def q11Shape37T12 : Tree 11 := (.split 31 (.split 33 (.split 24 (.split 32 (.split 25 (.split 34 (.tip (.cover {0,2,3,4,6,9})) (.split 29 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,1,5,7,9,10})))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape37T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 134217728 1423966208 q11Shape37T12=true := by decide

private def q11Shape37T13 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape37T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 402653184 1155530752 q11Shape37T13=true := by decide

private def q11Shape37T11 : Tree 11 := .split 28 q11Shape37T12 q11Shape37T13
private theorem q11Shape37T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 134217728 1155530752 q11Shape37T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 134217728 (1155530752 ||| 2^28) q11Shape37T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (134217728 ||| 2^28) 1155530752 q11Shape37T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T12OK,q11Shape37T13OK⟩

private def q11Shape37T14 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape37T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1207959552 81788928 q11Shape37T14=true := by decide

private def q11Shape37T10 : Tree 11 := .split 30 q11Shape37T11 q11Shape37T14
private theorem q11Shape37T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 134217728 81788928 q11Shape37T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 134217728 (81788928 ||| 2^30) q11Shape37T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (134217728 ||| 2^30) 81788928 q11Shape37T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T11OK,q11Shape37T14OK⟩

private def q11Shape37T4 : Tree 11 := .split 27 q11Shape37T5 q11Shape37T10
private theorem q11Shape37T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 81788928 q11Shape37T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 (81788928 ||| 2^27) q11Shape37T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (0 ||| 2^27) 81788928 q11Shape37T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T5OK,q11Shape37T10OK⟩

private def q11Shape37T18 : Tree 11 := (.split 31 (.split 33 (.split 24 (.split 34 (.split 25 (.split 32 (.tip (.cover {0,2,3,4,6,9})) (.split 29 (.tip (.cover {0,2,3,4,7,9})) (.tip (.cover {0,1,5,8,9,10})))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,7,8,10})))
private theorem q11Shape37T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 67108864 1491075072 q11Shape37T18=true := by decide

private def q11Shape37T19 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape37T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 335544320 1222639616 q11Shape37T19=true := by decide

private def q11Shape37T17 : Tree 11 := .split 28 q11Shape37T18 q11Shape37T19
private theorem q11Shape37T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 67108864 1222639616 q11Shape37T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 67108864 (1222639616 ||| 2^28) q11Shape37T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (67108864 ||| 2^28) 1222639616 q11Shape37T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T18OK,q11Shape37T19OK⟩

private def q11Shape37T20 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape37T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1140850688 148897792 q11Shape37T20=true := by decide

private def q11Shape37T16 : Tree 11 := .split 30 q11Shape37T17 q11Shape37T20
private theorem q11Shape37T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 67108864 148897792 q11Shape37T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 67108864 (148897792 ||| 2^30) q11Shape37T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (67108864 ||| 2^30) 148897792 q11Shape37T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T17OK,q11Shape37T20OK⟩

private def q11Shape37T21 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape37T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 201326592 14680064 q11Shape37T21=true := by decide

private def q11Shape37T15 : Tree 11 := .split 27 q11Shape37T16 q11Shape37T21
private theorem q11Shape37T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 67108864 14680064 q11Shape37T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 67108864 (14680064 ||| 2^27) q11Shape37T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (67108864 ||| 2^27) 14680064 q11Shape37T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T16OK,q11Shape37T21OK⟩

private def q11Shape37T3 : Tree 11 := .split 26 q11Shape37T4 q11Shape37T15
private theorem q11Shape37T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 14680064 q11Shape37T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 (14680064 ||| 2^26) q11Shape37T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (0 ||| 2^26) 14680064 q11Shape37T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T4OK,q11Shape37T15OK⟩

private def q11Shape37T26 : Tree 11 := (.split 31 (.split 33 (.split 24 (.split 32 (.split 29 (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.split 25 (.tip (.cover {0,2,3,4,8,9})) (.tip (.cover {0,1,6,7,9,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape37T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 1549795328 q11Shape37T26=true := by decide

private def q11Shape37T27 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape37T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 276824064 1281359872 q11Shape37T27=true := by decide

private def q11Shape37T25 : Tree 11 := .split 28 q11Shape37T26 q11Shape37T27
private theorem q11Shape37T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 1281359872 q11Shape37T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 (1281359872 ||| 2^28) q11Shape37T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (8388608 ||| 2^28) 1281359872 q11Shape37T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T26OK,q11Shape37T27OK⟩

private def q11Shape37T28 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape37T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1082130432 207618048 q11Shape37T28=true := by decide

private def q11Shape37T24 : Tree 11 := .split 30 q11Shape37T25 q11Shape37T28
private theorem q11Shape37T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 207618048 q11Shape37T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 (207618048 ||| 2^30) q11Shape37T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (8388608 ||| 2^30) 207618048 q11Shape37T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T25OK,q11Shape37T28OK⟩

private def q11Shape37T29 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape37T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 142606336 73400320 q11Shape37T29=true := by decide

private def q11Shape37T23 : Tree 11 := .split 27 q11Shape37T24 q11Shape37T29
private theorem q11Shape37T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 73400320 q11Shape37T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 (73400320 ||| 2^27) q11Shape37T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (8388608 ||| 2^27) 73400320 q11Shape37T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T24OK,q11Shape37T29OK⟩

private def q11Shape37T30 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape37T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 75497472 6291456 q11Shape37T30=true := by decide

private def q11Shape37T22 : Tree 11 := .split 26 q11Shape37T23 q11Shape37T30
private theorem q11Shape37T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 6291456 q11Shape37T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 8388608 (6291456 ||| 2^26) q11Shape37T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (8388608 ||| 2^26) 6291456 q11Shape37T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T23OK,q11Shape37T30OK⟩

private def q11Shape37T2 : Tree 11 := .split 23 q11Shape37T3 q11Shape37T22
private theorem q11Shape37T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 6291456 q11Shape37T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 (6291456 ||| 2^23) q11Shape37T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (0 ||| 2^23) 6291456 q11Shape37T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T3OK,q11Shape37T22OK⟩

private def q11Shape37T36 : Tree 11 := (.split 31 (.split 33 (.split 24 (.split 34 (.split 29 (.split 32 (.tip (.cover {0,2,3,4,5,9})) (.split 25 (.tip (.cover {0,2,3,4,7,9})) (.tip (.cover {0,1,6,8,9,10})))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,6,7,8,10})))
private theorem q11Shape37T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 1553989632 q11Shape37T36=true := by decide

private def q11Shape37T37 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape37T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 272629760 1285554176 q11Shape37T37=true := by decide

private def q11Shape37T35 : Tree 11 := .split 28 q11Shape37T36 q11Shape37T37
private theorem q11Shape37T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 1285554176 q11Shape37T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 (1285554176 ||| 2^28) q11Shape37T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (4194304 ||| 2^28) 1285554176 q11Shape37T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T36OK,q11Shape37T37OK⟩

private def q11Shape37T38 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape37T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1077936128 211812352 q11Shape37T38=true := by decide

private def q11Shape37T34 : Tree 11 := .split 30 q11Shape37T35 q11Shape37T38
private theorem q11Shape37T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 211812352 q11Shape37T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 (211812352 ||| 2^30) q11Shape37T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (4194304 ||| 2^30) 211812352 q11Shape37T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T35OK,q11Shape37T38OK⟩

private def q11Shape37T39 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape37T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 138412032 77594624 q11Shape37T39=true := by decide

private def q11Shape37T33 : Tree 11 := .split 27 q11Shape37T34 q11Shape37T39
private theorem q11Shape37T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 77594624 q11Shape37T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 (77594624 ||| 2^27) q11Shape37T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (4194304 ||| 2^27) 77594624 q11Shape37T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T34OK,q11Shape37T39OK⟩

private def q11Shape37T40 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape37T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 71303168 10485760 q11Shape37T40=true := by decide

private def q11Shape37T32 : Tree 11 := .split 26 q11Shape37T33 q11Shape37T40
private theorem q11Shape37T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 10485760 q11Shape37T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 (10485760 ||| 2^26) q11Shape37T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (4194304 ||| 2^26) 10485760 q11Shape37T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T33OK,q11Shape37T40OK⟩

private def q11Shape37T41 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape37T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 12582912 2097152 q11Shape37T41=true := by decide

private def q11Shape37T31 : Tree 11 := .split 23 q11Shape37T32 q11Shape37T41
private theorem q11Shape37T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 2097152 q11Shape37T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 4194304 (2097152 ||| 2^23) q11Shape37T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (4194304 ||| 2^23) 2097152 q11Shape37T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T32OK,q11Shape37T41OK⟩

private def q11Shape37T1 : Tree 11 := .split 22 q11Shape37T2 q11Shape37T31
private theorem q11Shape37T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 2097152 q11Shape37T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 (2097152 ||| 2^22) q11Shape37T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (0 ||| 2^22) 2097152 q11Shape37T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T2OK,q11Shape37T31OK⟩

private def q11Shape37T48 : Tree 11 := (.split 31 (.split 33 (.split 24 (.split 32 (.split 34 (.split 25 (.tip (.cover {0,2,3,4,6,9})) (.split 29 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,7,8,9,10})))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,10})))
private theorem q11Shape37T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 1556086784 q11Shape37T48=true := by decide

private def q11Shape37T49 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape37T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 270532608 1287651328 q11Shape37T49=true := by decide

private def q11Shape37T47 : Tree 11 := .split 28 q11Shape37T48 q11Shape37T49
private theorem q11Shape37T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 1287651328 q11Shape37T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 (1287651328 ||| 2^28) q11Shape37T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (2097152 ||| 2^28) 1287651328 q11Shape37T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T48OK,q11Shape37T49OK⟩

private def q11Shape37T50 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape37T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 1075838976 213909504 q11Shape37T50=true := by decide

private def q11Shape37T46 : Tree 11 := .split 30 q11Shape37T47 q11Shape37T50
private theorem q11Shape37T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 213909504 q11Shape37T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 (213909504 ||| 2^30) q11Shape37T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (2097152 ||| 2^30) 213909504 q11Shape37T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T47OK,q11Shape37T50OK⟩

private def q11Shape37T51 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape37T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 136314880 79691776 q11Shape37T51=true := by decide

private def q11Shape37T45 : Tree 11 := .split 27 q11Shape37T46 q11Shape37T51
private theorem q11Shape37T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 79691776 q11Shape37T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 (79691776 ||| 2^27) q11Shape37T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (2097152 ||| 2^27) 79691776 q11Shape37T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T46OK,q11Shape37T51OK⟩

private def q11Shape37T52 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape37T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 69206016 12582912 q11Shape37T52=true := by decide

private def q11Shape37T44 : Tree 11 := .split 26 q11Shape37T45 q11Shape37T52
private theorem q11Shape37T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 12582912 q11Shape37T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 (12582912 ||| 2^26) q11Shape37T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (2097152 ||| 2^26) 12582912 q11Shape37T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T45OK,q11Shape37T52OK⟩

private def q11Shape37T53 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape37T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 10485760 4194304 q11Shape37T53=true := by decide

private def q11Shape37T43 : Tree 11 := .split 23 q11Shape37T44 q11Shape37T53
private theorem q11Shape37T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 4194304 q11Shape37T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 (4194304 ||| 2^23) q11Shape37T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (2097152 ||| 2^23) 4194304 q11Shape37T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T44OK,q11Shape37T53OK⟩

private def q11Shape37T54 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape37T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 6291456 0 q11Shape37T54=true := by decide

private def q11Shape37T42 : Tree 11 := .split 22 q11Shape37T43 q11Shape37T54
private theorem q11Shape37T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 0 q11Shape37T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 2097152 (0 ||| 2^22) q11Shape37T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (2097152 ||| 2^22) 0 q11Shape37T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T43OK,q11Shape37T54OK⟩

private def q11Shape37T0 : Tree 11 := .split 21 q11Shape37T1 q11Shape37T42
private theorem q11Shape37T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 0 q11Shape37T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 (0 ||| 2^21) q11Shape37T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) (0 ||| 2^21) 0 q11Shape37T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape37T1OK,q11Shape37T42OK⟩

def q11Shape37P0 : Tree 11 := q11Shape37T0
theorem q11Shape37P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,3⟩) 0 0 q11Shape37P0=true := q11Shape37T0OK

end Graffiti384b.EffectiveSearch.Q11
