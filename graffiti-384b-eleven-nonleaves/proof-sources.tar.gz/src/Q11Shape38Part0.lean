import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape38T0 : Tree 11 := (.split 26 (.split 27 (.split 30 (.split 28 (.split 29 (.split 31 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape38T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,4⟩) 0 0 q11Shape38T0=true := by decide

def q11Shape38P0 : Tree 11 := q11Shape38T0
theorem q11Shape38P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨true,8,5,4⟩) 0 0 q11Shape38P0=true := q11Shape38T0OK

end Graffiti384b.EffectiveSearch.Q11
