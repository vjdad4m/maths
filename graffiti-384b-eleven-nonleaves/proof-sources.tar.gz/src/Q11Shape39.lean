import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape39T5 : Tree 11 := (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.split 35 (.split 31 (.split 32 (.split 33 (.split 34 (.split 24 (.split 25 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,9}))))
private theorem q11Shape39T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 216006656 q11Shape39T5=true := by decide

private def q11Shape39T6 : Tree 11 := (.split 30 (.split 35 (.split 31 (.split 32 (.split 33 (.split 34 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape39T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 134217728 81788928 q11Shape39T6=true := by decide

private def q11Shape39T4 : Tree 11 := .split 27 q11Shape39T5 q11Shape39T6
private theorem q11Shape39T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 81788928 q11Shape39T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 (81788928 ||| 2^27) q11Shape39T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) (0 ||| 2^27) 81788928 q11Shape39T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape39T5OK,q11Shape39T6OK⟩

private def q11Shape39T7 : Tree 11 := (.split 27 (.split 30 (.split 35 (.split 31 (.split 32 (.split 33 (.split 34 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape39T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 67108864 14680064 q11Shape39T7=true := by decide

private def q11Shape39T3 : Tree 11 := .split 26 q11Shape39T4 q11Shape39T7
private theorem q11Shape39T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 14680064 q11Shape39T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 (14680064 ||| 2^26) q11Shape39T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) (0 ||| 2^26) 14680064 q11Shape39T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape39T4OK,q11Shape39T7OK⟩

private def q11Shape39T8 : Tree 11 := (.split 26 (.split 27 (.split 30 (.split 35 (.split 31 (.split 32 (.split 33 (.split 34 (.split 24 (.split 25 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape39T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 8388608 6291456 q11Shape39T8=true := by decide

private def q11Shape39T2 : Tree 11 := .split 23 q11Shape39T3 q11Shape39T8
private theorem q11Shape39T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 6291456 q11Shape39T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 (6291456 ||| 2^23) q11Shape39T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) (0 ||| 2^23) 6291456 q11Shape39T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape39T3OK,q11Shape39T8OK⟩

private def q11Shape39T9 : Tree 11 := (.split 23 (.split 26 (.split 27 (.split 30 (.split 35 (.split 31 (.split 32 (.split 33 (.split 34 (.split 24 (.split 25 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape39T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 4194304 2097152 q11Shape39T9=true := by decide

private def q11Shape39T1 : Tree 11 := .split 22 q11Shape39T2 q11Shape39T9
private theorem q11Shape39T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 2097152 q11Shape39T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 (2097152 ||| 2^22) q11Shape39T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) (0 ||| 2^22) 2097152 q11Shape39T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape39T2OK,q11Shape39T9OK⟩

private def q11Shape39T10 : Tree 11 := (.split 22 (.split 23 (.split 26 (.split 27 (.split 30 (.split 35 (.split 31 (.split 32 (.split 33 (.split 34 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape39T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 2097152 0 q11Shape39T10=true := by decide

private def q11Shape39T0 : Tree 11 := .split 21 q11Shape39T1 q11Shape39T10
private theorem q11Shape39T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 0 q11Shape39T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) 0 (0 ||| 2^21) q11Shape39T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 39)) (0 ||| 2^21) 0 q11Shape39T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape39T1OK,q11Shape39T10OK⟩


theorem q11Shape39_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 39) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 39) b) (adj 11 (forms 39) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 39)) adj_mono b H q11Shape39T0 q11Shape39T0OK

#print axioms q11Shape39_cover
end Graffiti384b.EffectiveSearch.Q11
