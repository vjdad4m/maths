import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape3T1 : Tree 11 := (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.unordered {3,4,5,6} 0)))))))))
private theorem q11Shape3T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 7 q11Shape3T1=true := by decide

private def q11Shape3T3 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {5,6,7,8,9,10})))))))
private theorem q11Shape3T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 4 259 q11Shape3T3=true := by decide

private def q11Shape3T5 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10}))))))))
private theorem q11Shape3T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 260 515 q11Shape3T5=true := by decide

private def q11Shape3T7 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))
private theorem q11Shape3T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 772 32771 q11Shape3T7=true := by decide

private def q11Shape3T9 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape3T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33540 11 q11Shape3T9=true := by decide

private def q11Shape3T10 : Tree 11 := (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {5,6,7,8,9,10}))))
private theorem q11Shape3T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33548 3 q11Shape3T10=true := by decide

private def q11Shape3T8 : Tree 11 := .split 3 q11Shape3T9 q11Shape3T10
private theorem q11Shape3T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33540 3 q11Shape3T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33540 (3 ||| 2^3) q11Shape3T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (33540 ||| 2^3) 3 q11Shape3T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T9OK,q11Shape3T10OK⟩

private def q11Shape3T6 : Tree 11 := .split 15 q11Shape3T7 q11Shape3T8
private theorem q11Shape3T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 772 3 q11Shape3T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 772 (3 ||| 2^15) q11Shape3T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (772 ||| 2^15) 3 q11Shape3T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T7OK,q11Shape3T8OK⟩

private def q11Shape3T4 : Tree 11 := .split 9 q11Shape3T5 q11Shape3T6
private theorem q11Shape3T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 260 3 q11Shape3T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 260 (3 ||| 2^9) q11Shape3T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (260 ||| 2^9) 3 q11Shape3T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T5OK,q11Shape3T6OK⟩

private def q11Shape3T2 : Tree 11 := .split 8 q11Shape3T3 q11Shape3T4
private theorem q11Shape3T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 4 3 q11Shape3T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 4 (3 ||| 2^8) q11Shape3T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (4 ||| 2^8) 3 q11Shape3T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T3OK,q11Shape3T4OK⟩

private def q11Shape3T0 : Tree 11 := .split 2 q11Shape3T1 q11Shape3T2
private theorem q11Shape3T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 3 q11Shape3T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 (3 ||| 2^2) q11Shape3T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (0 ||| 2^2) 3 q11Shape3T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T1OK,q11Shape3T2OK⟩

def q11Shape3P0 : Tree 11 := q11Shape3T0
theorem q11Shape3P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 0 3 q11Shape3P0=true := q11Shape3T0OK

end Graffiti384b.EffectiveSearch.Q11
