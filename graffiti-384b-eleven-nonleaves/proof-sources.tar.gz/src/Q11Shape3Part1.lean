import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape3T13 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))))
private theorem q11Shape3T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 2 261 q11Shape3T13=true := by decide

private def q11Shape3T15 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))))))
private theorem q11Shape3T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 258 517 q11Shape3T15=true := by decide

private def q11Shape3T17 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))
private theorem q11Shape3T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 770 32773 q11Shape3T17=true := by decide

private def q11Shape3T18 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 10 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape3T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33538 5 q11Shape3T18=true := by decide

private def q11Shape3T16 : Tree 11 := .split 15 q11Shape3T17 q11Shape3T18
private theorem q11Shape3T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 770 5 q11Shape3T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 770 (5 ||| 2^15) q11Shape3T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (770 ||| 2^15) 5 q11Shape3T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T17OK,q11Shape3T18OK⟩

private def q11Shape3T14 : Tree 11 := .split 9 q11Shape3T15 q11Shape3T16
private theorem q11Shape3T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 258 5 q11Shape3T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 258 (5 ||| 2^9) q11Shape3T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (258 ||| 2^9) 5 q11Shape3T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T15OK,q11Shape3T16OK⟩

private def q11Shape3T12 : Tree 11 := .split 8 q11Shape3T13 q11Shape3T14
private theorem q11Shape3T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 2 5 q11Shape3T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 2 (5 ||| 2^8) q11Shape3T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (2 ||| 2^8) 5 q11Shape3T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T13OK,q11Shape3T14OK⟩

private def q11Shape3T21 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.unordered {2,4,5,6} 0)))))))
private theorem q11Shape3T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 6 769 q11Shape3T21=true := by decide

private def q11Shape3T23 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))
private theorem q11Shape3T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 518 33025 q11Shape3T23=true := by decide

private def q11Shape3T25 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape3T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33286 265 q11Shape3T25=true := by decide

private def q11Shape3T26 : Tree 11 := (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {5,6,7,8,9,10}))))
private theorem q11Shape3T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33294 257 q11Shape3T26=true := by decide

private def q11Shape3T24 : Tree 11 := .split 3 q11Shape3T25 q11Shape3T26
private theorem q11Shape3T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33286 257 q11Shape3T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33286 (257 ||| 2^3) q11Shape3T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (33286 ||| 2^3) 257 q11Shape3T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T25OK,q11Shape3T26OK⟩

private def q11Shape3T22 : Tree 11 := .split 15 q11Shape3T23 q11Shape3T24
private theorem q11Shape3T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 518 257 q11Shape3T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 518 (257 ||| 2^15) q11Shape3T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (518 ||| 2^15) 257 q11Shape3T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T23OK,q11Shape3T24OK⟩

private def q11Shape3T20 : Tree 11 := .split 9 q11Shape3T21 q11Shape3T22
private theorem q11Shape3T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 6 257 q11Shape3T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 6 (257 ||| 2^9) q11Shape3T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (6 ||| 2^9) 257 q11Shape3T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T21OK,q11Shape3T22OK⟩

private def q11Shape3T29 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))
private theorem q11Shape3T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 262 33281 q11Shape3T29=true := by decide

private def q11Shape3T30 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 10 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape3T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33030 513 q11Shape3T30=true := by decide

private def q11Shape3T28 : Tree 11 := .split 15 q11Shape3T29 q11Shape3T30
private theorem q11Shape3T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 262 513 q11Shape3T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 262 (513 ||| 2^15) q11Shape3T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (262 ||| 2^15) 513 q11Shape3T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T29OK,q11Shape3T30OK⟩

private def q11Shape3T32 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10}))))) (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {2,3,7,8,9,10}))))
private theorem q11Shape3T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 774 32769 q11Shape3T32=true := by decide

private def q11Shape3T34 : Tree 11 := (.split 10 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))))
private theorem q11Shape3T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33542 9 q11Shape3T34=true := by decide

private def q11Shape3T35 : Tree 11 := (.split 10 (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {2,3,7,8,9,10})))
private theorem q11Shape3T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33550 1 q11Shape3T35=true := by decide

private def q11Shape3T33 : Tree 11 := .split 3 q11Shape3T34 q11Shape3T35
private theorem q11Shape3T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33542 1 q11Shape3T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33542 (1 ||| 2^3) q11Shape3T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (33542 ||| 2^3) 1 q11Shape3T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T34OK,q11Shape3T35OK⟩

private def q11Shape3T31 : Tree 11 := .split 15 q11Shape3T32 q11Shape3T33
private theorem q11Shape3T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 774 1 q11Shape3T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 774 (1 ||| 2^15) q11Shape3T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (774 ||| 2^15) 1 q11Shape3T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T32OK,q11Shape3T33OK⟩

private def q11Shape3T27 : Tree 11 := .split 9 q11Shape3T28 q11Shape3T31
private theorem q11Shape3T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 262 1 q11Shape3T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 262 (1 ||| 2^9) q11Shape3T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (262 ||| 2^9) 1 q11Shape3T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T28OK,q11Shape3T31OK⟩

private def q11Shape3T19 : Tree 11 := .split 8 q11Shape3T20 q11Shape3T27
private theorem q11Shape3T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 6 1 q11Shape3T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 6 (1 ||| 2^8) q11Shape3T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (6 ||| 2^8) 1 q11Shape3T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T20OK,q11Shape3T27OK⟩

private def q11Shape3T11 : Tree 11 := .split 2 q11Shape3T12 q11Shape3T19
private theorem q11Shape3T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 2 1 q11Shape3T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 2 (1 ||| 2^2) q11Shape3T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (2 ||| 2^2) 1 q11Shape3T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T12OK,q11Shape3T19OK⟩

def q11Shape3P1 : Tree 11 := q11Shape3T11
theorem q11Shape3P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 2 1 q11Shape3P1=true := q11Shape3T11OK

end Graffiti384b.EffectiveSearch.Q11
