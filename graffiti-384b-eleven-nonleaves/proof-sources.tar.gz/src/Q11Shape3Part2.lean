import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape3T39 : Tree 11 := (.split 9 (.tip (.small 0)) (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))))
private theorem q11Shape3T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 262 q11Shape3T39=true := by decide

private def q11Shape3T41 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10}))))))))
private theorem q11Shape3T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 257 518 q11Shape3T41=true := by decide

private def q11Shape3T43 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape3T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 769 32774 q11Shape3T43=true := by decide

private def q11Shape3T44 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))) (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape3T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33537 6 q11Shape3T44=true := by decide

private def q11Shape3T42 : Tree 11 := .split 15 q11Shape3T43 q11Shape3T44
private theorem q11Shape3T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 769 6 q11Shape3T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 769 (6 ||| 2^15) q11Shape3T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (769 ||| 2^15) 6 q11Shape3T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T43OK,q11Shape3T44OK⟩

private def q11Shape3T40 : Tree 11 := .split 9 q11Shape3T41 q11Shape3T42
private theorem q11Shape3T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 257 6 q11Shape3T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 257 (6 ||| 2^9) q11Shape3T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (257 ||| 2^9) 6 q11Shape3T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T41OK,q11Shape3T42OK⟩

private def q11Shape3T38 : Tree 11 := .split 8 q11Shape3T39 q11Shape3T40
private theorem q11Shape3T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 6 q11Shape3T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 (6 ||| 2^8) q11Shape3T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (1 ||| 2^8) 6 q11Shape3T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T39OK,q11Shape3T40OK⟩

private def q11Shape3T47 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10}))))))))
private theorem q11Shape3T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 5 770 q11Shape3T47=true := by decide

private def q11Shape3T49 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.unordered {2,3,5,6} 0))))))
private theorem q11Shape3T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 517 33026 q11Shape3T49=true := by decide

private def q11Shape3T51 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))))
private theorem q11Shape3T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33285 266 q11Shape3T51=true := by decide

private def q11Shape3T52 : Tree 11 := (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {5,6,7,8,9,10}))))
private theorem q11Shape3T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33293 258 q11Shape3T52=true := by decide

private def q11Shape3T50 : Tree 11 := .split 3 q11Shape3T51 q11Shape3T52
private theorem q11Shape3T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33285 258 q11Shape3T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33285 (258 ||| 2^3) q11Shape3T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (33285 ||| 2^3) 258 q11Shape3T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T51OK,q11Shape3T52OK⟩

private def q11Shape3T48 : Tree 11 := .split 15 q11Shape3T49 q11Shape3T50
private theorem q11Shape3T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 517 258 q11Shape3T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 517 (258 ||| 2^15) q11Shape3T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (517 ||| 2^15) 258 q11Shape3T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T49OK,q11Shape3T50OK⟩

private def q11Shape3T46 : Tree 11 := .split 9 q11Shape3T47 q11Shape3T48
private theorem q11Shape3T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 5 258 q11Shape3T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 5 (258 ||| 2^9) q11Shape3T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (5 ||| 2^9) 258 q11Shape3T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T47OK,q11Shape3T48OK⟩

private def q11Shape3T55 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))
private theorem q11Shape3T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 261 33282 q11Shape3T55=true := by decide

private def q11Shape3T57 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10})))))
private theorem q11Shape3T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33029 522 q11Shape3T57=true := by decide

private def q11Shape3T58 : Tree 11 := (.split 10 (.split 16 (.tip (.small 0)) (.tip (.cover {2,4,7,8,9,10}))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {2,4,7,8,9,10}))))
private theorem q11Shape3T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33037 514 q11Shape3T58=true := by decide

private def q11Shape3T56 : Tree 11 := .split 3 q11Shape3T57 q11Shape3T58
private theorem q11Shape3T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33029 514 q11Shape3T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33029 (514 ||| 2^3) q11Shape3T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (33029 ||| 2^3) 514 q11Shape3T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T57OK,q11Shape3T58OK⟩

private def q11Shape3T54 : Tree 11 := .split 15 q11Shape3T55 q11Shape3T56
private theorem q11Shape3T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 261 514 q11Shape3T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 261 (514 ||| 2^15) q11Shape3T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (261 ||| 2^15) 514 q11Shape3T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T55OK,q11Shape3T56OK⟩

private def q11Shape3T60 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))) (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape3T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 773 32770 q11Shape3T60=true := by decide

private def q11Shape3T61 : Tree 11 := (.split 3 (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))) (.split 10 (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {2,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape3T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33541 2 q11Shape3T61=true := by decide

private def q11Shape3T59 : Tree 11 := .split 15 q11Shape3T60 q11Shape3T61
private theorem q11Shape3T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 773 2 q11Shape3T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 773 (2 ||| 2^15) q11Shape3T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (773 ||| 2^15) 2 q11Shape3T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T60OK,q11Shape3T61OK⟩

private def q11Shape3T53 : Tree 11 := .split 9 q11Shape3T54 q11Shape3T59
private theorem q11Shape3T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 261 2 q11Shape3T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 261 (2 ||| 2^9) q11Shape3T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (261 ||| 2^9) 2 q11Shape3T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T54OK,q11Shape3T59OK⟩

private def q11Shape3T45 : Tree 11 := .split 8 q11Shape3T46 q11Shape3T53
private theorem q11Shape3T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 5 2 q11Shape3T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 5 (2 ||| 2^8) q11Shape3T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (5 ||| 2^8) 2 q11Shape3T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T46OK,q11Shape3T53OK⟩

private def q11Shape3T37 : Tree 11 := .split 2 q11Shape3T38 q11Shape3T45
private theorem q11Shape3T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 2 q11Shape3T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 (2 ||| 2^2) q11Shape3T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (1 ||| 2^2) 2 q11Shape3T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T38OK,q11Shape3T45OK⟩

def q11Shape3P2 : Tree 11 := q11Shape3T37
theorem q11Shape3P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 1 2 q11Shape3P2=true := q11Shape3T37OK

end Graffiti384b.EffectiveSearch.Q11
