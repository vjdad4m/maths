import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape3T65 : Tree 11 := (.split 15 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10}))))))))
private theorem q11Shape3T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 772 q11Shape3T65=true := by decide

private def q11Shape3T67 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.split 11 (.tip (.small 1)) (.tip (.cover {0,1,3,8,9,10})))))))
private theorem q11Shape3T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 515 33028 q11Shape3T67=true := by decide

private def q11Shape3T69 : Tree 11 := (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {3,4,7,8,9,10}))))
private theorem q11Shape3T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33283 268 q11Shape3T69=true := by decide

private def q11Shape3T70 : Tree 11 := (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10})))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {3,4,7,8,9,10}))))
private theorem q11Shape3T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33291 260 q11Shape3T70=true := by decide

private def q11Shape3T68 : Tree 11 := .split 3 q11Shape3T69 q11Shape3T70
private theorem q11Shape3T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33283 260 q11Shape3T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33283 (260 ||| 2^3) q11Shape3T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (33283 ||| 2^3) 260 q11Shape3T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T69OK,q11Shape3T70OK⟩

private def q11Shape3T66 : Tree 11 := .split 15 q11Shape3T67 q11Shape3T68
private theorem q11Shape3T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 515 260 q11Shape3T66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 515 (260 ||| 2^15) q11Shape3T67 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (515 ||| 2^15) 260 q11Shape3T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T67OK,q11Shape3T68OK⟩

private def q11Shape3T64 : Tree 11 := .split 9 q11Shape3T65 q11Shape3T66
private theorem q11Shape3T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 260 q11Shape3T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 (260 ||| 2^9) q11Shape3T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (3 ||| 2^9) 260 q11Shape3T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T65OK,q11Shape3T66OK⟩

private def q11Shape3T73 : Tree 11 := (.split 3 (.tip (.small 0)) (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.unordered {2,3,4,6} 0))))))
private theorem q11Shape3T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 259 33284 q11Shape3T73=true := by decide

private def q11Shape3T74 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10})))) (.split 10 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {4,6,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))))
private theorem q11Shape3T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33027 516 q11Shape3T74=true := by decide

private def q11Shape3T72 : Tree 11 := .split 15 q11Shape3T73 q11Shape3T74
private theorem q11Shape3T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 259 516 q11Shape3T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 259 (516 ||| 2^15) q11Shape3T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (259 ||| 2^15) 516 q11Shape3T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T73OK,q11Shape3T74OK⟩

private def q11Shape3T76 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.tip (.cover {0,3,7,8,9,10}))) (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {3,6,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape3T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 771 32772 q11Shape3T76=true := by decide

private def q11Shape3T77 : Tree 11 := (.split 3 (.split 10 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))) (.split 10 (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {2,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10}))) (.tip (.cover {0,3,7,8,9,10}))))
private theorem q11Shape3T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33539 4 q11Shape3T77=true := by decide

private def q11Shape3T75 : Tree 11 := .split 15 q11Shape3T76 q11Shape3T77
private theorem q11Shape3T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 771 4 q11Shape3T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 771 (4 ||| 2^15) q11Shape3T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (771 ||| 2^15) 4 q11Shape3T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T76OK,q11Shape3T77OK⟩

private def q11Shape3T71 : Tree 11 := .split 9 q11Shape3T72 q11Shape3T75
private theorem q11Shape3T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 259 4 q11Shape3T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 259 (4 ||| 2^9) q11Shape3T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (259 ||| 2^9) 4 q11Shape3T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T72OK,q11Shape3T75OK⟩

private def q11Shape3T63 : Tree 11 := .split 8 q11Shape3T64 q11Shape3T71
private theorem q11Shape3T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 4 q11Shape3T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 (4 ||| 2^8) q11Shape3T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (3 ||| 2^8) 4 q11Shape3T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T64OK,q11Shape3T71OK⟩

private def q11Shape3T80 : Tree 11 := (.split 15 (.split 3 (.tip (.small 0)) (.tip (.cover {0,2,7,8,9,10}))) (.split 3 (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10}))))) (.tip (.cover {0,2,7,8,9,10}))))
private theorem q11Shape3T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 7 768 q11Shape3T80=true := by decide

private def q11Shape3T82 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10}))))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape3T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 519 33024 q11Shape3T82=true := by decide

private def q11Shape3T83 : Tree 11 := (.split 3 (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10})))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {3,4,7,8,9,10})))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape3T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33287 256 q11Shape3T83=true := by decide

private def q11Shape3T81 : Tree 11 := .split 15 q11Shape3T82 q11Shape3T83
private theorem q11Shape3T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 519 256 q11Shape3T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 519 (256 ||| 2^15) q11Shape3T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (519 ||| 2^15) 256 q11Shape3T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T82OK,q11Shape3T83OK⟩

private def q11Shape3T79 : Tree 11 := .split 9 q11Shape3T80 q11Shape3T81
private theorem q11Shape3T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 7 256 q11Shape3T79=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 7 (256 ||| 2^9) q11Shape3T80 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (7 ||| 2^9) 256 q11Shape3T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T80OK,q11Shape3T81OK⟩

private def q11Shape3T86 : Tree 11 := (.split 3 (.split 10 (.tip (.small 0)) (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {2,6,7,8,9,10}))))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape3T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 263 33280 q11Shape3T86=true := by decide

private def q11Shape3T87 : Tree 11 := (.split 3 (.split 10 (.split 16 (.tip (.small 0)) (.tip (.cover {0,4,7,8,9,10}))) (.split 16 (.split 21 (.tip (.small 0)) (.tip (.cover {3,5,7,8,9,10}))) (.tip (.cover {0,4,7,8,9,10})))) (.tip (.cover {0,2,7,8,9,10})))
private theorem q11Shape3T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 33031 512 q11Shape3T87=true := by decide

private def q11Shape3T85 : Tree 11 := .split 15 q11Shape3T86 q11Shape3T87
private theorem q11Shape3T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 263 512 q11Shape3T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 263 (512 ||| 2^15) q11Shape3T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (263 ||| 2^15) 512 q11Shape3T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T86OK,q11Shape3T87OK⟩

private def q11Shape3T88 : Tree 11 := (.split 15 (.split 3 (.split 10 (.split 16 (.tip (.small 0)) (.split 21 (.tip (.small 0)) (.tip (.cover {4,5,7,8,9,10})))) (.tip (.cover {0,3,7,8,9,10}))) (.tip (.cover {0,2,7,8,9,10}))) (.split 3 (.tip (.unordered {2,3,4,5} 0)) (.tip (.cover {0,2,7,8,9,10}))))
private theorem q11Shape3T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 775 0 q11Shape3T88=true := by decide

private def q11Shape3T84 : Tree 11 := .split 9 q11Shape3T85 q11Shape3T88
private theorem q11Shape3T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 263 0 q11Shape3T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 263 (0 ||| 2^9) q11Shape3T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (263 ||| 2^9) 0 q11Shape3T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T85OK,q11Shape3T88OK⟩

private def q11Shape3T78 : Tree 11 := .split 8 q11Shape3T79 q11Shape3T84
private theorem q11Shape3T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 7 0 q11Shape3T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 7 (0 ||| 2^8) q11Shape3T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (7 ||| 2^8) 0 q11Shape3T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T79OK,q11Shape3T84OK⟩

private def q11Shape3T62 : Tree 11 := .split 2 q11Shape3T63 q11Shape3T78
private theorem q11Shape3T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 0 q11Shape3T62=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 (0 ||| 2^2) q11Shape3T63 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) (3 ||| 2^2) 0 q11Shape3T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape3T63OK,q11Shape3T78OK⟩

def q11Shape3P3 : Tree 11 := q11Shape3T62
theorem q11Shape3P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,5,5,4⟩) 3 0 q11Shape3P3=true := q11Shape3T62OK

end Graffiti384b.EffectiveSearch.Q11
