import Q11Shape4Part0
import Q11Shape4Part1
import Q11Shape4Part2
import Q11Shape4Part3
import Q11Shape4Part4
import Q11Shape4Part5
import Q11Shape4Part6
import Q11Shape4Part7

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4M42 : Tree 11 := .split 22 q11Shape4P0 q11Shape4P1
private theorem q11Shape4M42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 2326528 q11Shape4M42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 (2326528 ||| 2^22) q11Shape4P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (0 ||| 2^22) 2326528 q11Shape4P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4P0OK,q11Shape4P1OK⟩
private def q11Shape4M68 : Tree 11 := .split 21 q11Shape4M42 q11Shape4P2
private theorem q11Shape4M68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 229376 q11Shape4M68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 (229376 ||| 2^21) q11Shape4M42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (0 ||| 2^21) 229376 q11Shape4P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4M42OK,q11Shape4P2OK⟩
private def q11Shape4M108 : Tree 11 := .split 17 q11Shape4M68 q11Shape4P3
private theorem q11Shape4M108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 98304 q11Shape4M108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 (98304 ||| 2^17) q11Shape4M68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (0 ||| 2^17) 98304 q11Shape4P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4M68OK,q11Shape4P3OK⟩
private def q11Shape4M153 : Tree 11 := .split 17 q11Shape4P4 q11Shape4P5
private theorem q11Shape4M153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 32768 q11Shape4M153=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (32768 ||| 2^17) q11Shape4P4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^17) 32768 q11Shape4P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4P4OK,q11Shape4P5OK⟩
private def q11Shape4M154 : Tree 11 := .split 16 q11Shape4M108 q11Shape4M153
private theorem q11Shape4M154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 32768 q11Shape4M154=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 (32768 ||| 2^16) q11Shape4M108 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (0 ||| 2^16) 32768 q11Shape4M153)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4M108OK,q11Shape4M153OK⟩
private def q11Shape4M201 : Tree 11 := .split 17 q11Shape4P6 q11Shape4P7
private theorem q11Shape4M201OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 65536 q11Shape4M201=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (65536 ||| 2^17) q11Shape4P6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^17) 65536 q11Shape4P7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4P6OK,q11Shape4P7OK⟩
private def q11Shape4M209 : Tree 11 := .split 16 q11Shape4M201 q11Shape4P8
private theorem q11Shape4M209OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 0 q11Shape4M209=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (0 ||| 2^16) q11Shape4M201 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^16) 0 q11Shape4P8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4M201OK,q11Shape4P8OK⟩
private def q11Shape4M210 : Tree 11 := .split 15 q11Shape4M154 q11Shape4M209
private theorem q11Shape4M210OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 0 q11Shape4M210=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 (0 ||| 2^15) q11Shape4M154 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (0 ||| 2^15) 0 q11Shape4M209)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4M154OK,q11Shape4M209OK⟩

theorem q11Shape4_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 4) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 4) b) (adj 11 (forms 4) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) adj_mono b H q11Shape4M210 q11Shape4M210OK

#print axioms q11Shape4_cover

end Graffiti384b.EffectiveSearch.Q11
