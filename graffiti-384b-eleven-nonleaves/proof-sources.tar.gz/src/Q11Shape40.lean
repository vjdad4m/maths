import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape40T0 : Tree 11 := (.split 26 (.split 27 (.split 30 (.split 28 (.split 31 (.split 33 (.split 29 (.split 32 (.split 34 (.tip (.cover {0,2,3,4,5,9})) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape40T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 40)) 0 0 q11Shape40T0=true := by decide


theorem q11Shape40_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 40) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 40) b) (adj 11 (forms 40) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 40)) adj_mono b H q11Shape40T0 q11Shape40T0OK

#print axioms q11Shape40_cover
end Graffiti384b.EffectiveSearch.Q11
