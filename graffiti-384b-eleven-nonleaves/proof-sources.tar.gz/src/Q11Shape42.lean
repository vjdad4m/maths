import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape42T4 : Tree 11 := (.split 26 (.split 27 (.split 28 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,1,5,6,7,10})))) (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,1,5,6,7,10})))) (.split 28 (.split 30 (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,7,10})))) (.split 27 (.split 28 (.split 30 (.split 31 (.split 33 (.tip (.cover {0,2,3,4,6,10})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))))
private theorem q11Shape42T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 31457280 q11Shape42T4=true := by decide

private def q11Shape42T5 : Tree 11 := (.split 26 (.split 27 (.split 28 (.split 30 (.tip (.cover {0,2,3,4,9,10})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape42T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 16777216 14680064 q11Shape42T5=true := by decide

private def q11Shape42T3 : Tree 11 := .split 24 q11Shape42T4 q11Shape42T5
private theorem q11Shape42T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 14680064 q11Shape42T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 (14680064 ||| 2^24) q11Shape42T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) (0 ||| 2^24) 14680064 q11Shape42T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape42T4OK,q11Shape42T5OK⟩

private def q11Shape42T6 : Tree 11 := (.split 24 (.split 26 (.split 27 (.split 28 (.split 30 (.split 31 (.tip (.cover {0,2,3,4,8,10})) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape42T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 8388608 6291456 q11Shape42T6=true := by decide

private def q11Shape42T2 : Tree 11 := .split 23 q11Shape42T3 q11Shape42T6
private theorem q11Shape42T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 6291456 q11Shape42T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 (6291456 ||| 2^23) q11Shape42T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) (0 ||| 2^23) 6291456 q11Shape42T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape42T3OK,q11Shape42T6OK⟩

private def q11Shape42T7 : Tree 11 := (.split 23 (.split 24 (.split 26 (.split 27 (.split 28 (.split 30 (.split 31 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape42T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 4194304 2097152 q11Shape42T7=true := by decide

private def q11Shape42T1 : Tree 11 := .split 22 q11Shape42T2 q11Shape42T7
private theorem q11Shape42T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 2097152 q11Shape42T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 (2097152 ||| 2^22) q11Shape42T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) (0 ||| 2^22) 2097152 q11Shape42T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape42T2OK,q11Shape42T7OK⟩

private def q11Shape42T8 : Tree 11 := (.split 22 (.split 23 (.split 24 (.split 26 (.split 27 (.split 28 (.split 30 (.split 31 (.split 33 (.tip (.cover {0,2,3,4,5,10})) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,8,9,10})))
private theorem q11Shape42T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 2097152 0 q11Shape42T8=true := by decide

private def q11Shape42T0 : Tree 11 := .split 21 q11Shape42T1 q11Shape42T8
private theorem q11Shape42T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 0 q11Shape42T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) 0 (0 ||| 2^21) q11Shape42T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 (forms 42)) (0 ||| 2^21) 0 q11Shape42T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape42T1OK,q11Shape42T8OK⟩


theorem q11Shape42_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 42) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 42) b) (adj 11 (forms 42) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 (forms 42)) adj_mono b H q11Shape42T0 q11Shape42T0OK

#print axioms q11Shape42_cover
end Graffiti384b.EffectiveSearch.Q11
