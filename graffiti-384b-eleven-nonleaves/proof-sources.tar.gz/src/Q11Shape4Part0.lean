import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T1 : Tree 11 := (.tip (.cover {0,2,3,8,9,10}))
private theorem q11Shape4T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 73629696 q11Shape4T1=true := by decide

private def q11Shape4T9 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))))
private theorem q11Shape4T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 62149328896 q11Shape4T9=true := by decide

private def q11Shape4T10 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape4T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 1140850688 61075587072 q11Shape4T10=true := by decide

private def q11Shape4T8 : Tree 11 := .split 30 q11Shape4T9 q11Shape4T10
private theorem q11Shape4T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 61075587072 q11Shape4T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 (61075587072 ||| 2^30) q11Shape4T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67108864 ||| 2^30) 61075587072 q11Shape4T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T9OK,q11Shape4T10OK⟩

private def q11Shape4T11 : Tree 11 := (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6})))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10})))
private theorem q11Shape4T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 603979776 60538716160 q11Shape4T11=true := by decide

private def q11Shape4T7 : Tree 11 := .split 29 q11Shape4T8 q11Shape4T11
private theorem q11Shape4T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 60538716160 q11Shape4T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 (60538716160 ||| 2^29) q11Shape4T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67108864 ||| 2^29) 60538716160 q11Shape4T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T8OK,q11Shape4T11OK⟩

private def q11Shape4T12 : Tree 11 := (.split 29 (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape4T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 335544320 60270280704 q11Shape4T12=true := by decide

private def q11Shape4T6 : Tree 11 := .split 28 q11Shape4T7 q11Shape4T12
private theorem q11Shape4T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 60270280704 q11Shape4T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 (60270280704 ||| 2^28) q11Shape4T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67108864 ||| 2^28) 60270280704 q11Shape4T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T7OK,q11Shape4T12OK⟩

private def q11Shape4T13 : Tree 11 := (.split 28 (.split 29 (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,2,3,8,9,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape4T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 201326592 60136062976 q11Shape4T13=true := by decide

private def q11Shape4T5 : Tree 11 := .split 27 q11Shape4T6 q11Shape4T13
private theorem q11Shape4T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 60136062976 q11Shape4T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 (60136062976 ||| 2^27) q11Shape4T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67108864 ||| 2^27) 60136062976 q11Shape4T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T6OK,q11Shape4T13OK⟩

private def q11Shape4T14 : Tree 11 := (.split 27 (.split 30 (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.tip (.cover {0,1,2,3,6,10})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape4T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34426847232 25776324608 q11Shape4T14=true := by decide

private def q11Shape4T4 : Tree 11 := .split 35 q11Shape4T5 q11Shape4T14
private theorem q11Shape4T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 25776324608 q11Shape4T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 (25776324608 ||| 2^35) q11Shape4T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67108864 ||| 2^35) 25776324608 q11Shape4T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T5OK,q11Shape4T14OK⟩

private def q11Shape4T16 : Tree 11 := (.split 28 (.split 31 (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.tip (.cover {0,1,2,3,6,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape4T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17246978048 42956193792 q11Shape4T16=true := by decide

private def q11Shape4T17 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape4T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 51606716416 8596455424 q11Shape4T17=true := by decide

private def q11Shape4T15 : Tree 11 := .split 35 q11Shape4T16 q11Shape4T17
private theorem q11Shape4T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17246978048 8596455424 q11Shape4T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17246978048 (8596455424 ||| 2^35) q11Shape4T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (17246978048 ||| 2^35) 8596455424 q11Shape4T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T16OK,q11Shape4T17OK⟩

private def q11Shape4T3 : Tree 11 := .split 34 q11Shape4T4 q11Shape4T15
private theorem q11Shape4T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 8596455424 q11Shape4T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 (8596455424 ||| 2^34) q11Shape4T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67108864 ||| 2^34) 8596455424 q11Shape4T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T4OK,q11Shape4T15OK⟩

private def q11Shape4T20 : Tree 11 := (.split 29 (.split 32 (.split 18 (.split 19 (.split 20 (.split 23 (.split 25 (.tip (.cover {0,1,2,3,6,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape4T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8657043456 51546128384 q11Shape4T20=true := by decide

private def q11Shape4T21 : Tree 11 := (.tip (.cover {0,1,4,5,6,9}))
private theorem q11Shape4T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 43016781824 17186390016 q11Shape4T21=true := by decide

private def q11Shape4T19 : Tree 11 := .split 35 q11Shape4T20 q11Shape4T21
private theorem q11Shape4T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8657043456 17186390016 q11Shape4T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8657043456 (17186390016 ||| 2^35) q11Shape4T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8657043456 ||| 2^35) 17186390016 q11Shape4T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T20OK,q11Shape4T21OK⟩

private def q11Shape4T22 : Tree 11 := (.tip (.cover {0,1,4,5,6,8}))
private theorem q11Shape4T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 25836912640 6520832 q11Shape4T22=true := by decide

private def q11Shape4T18 : Tree 11 := .split 34 q11Shape4T19 q11Shape4T22
private theorem q11Shape4T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8657043456 6520832 q11Shape4T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8657043456 (6520832 ||| 2^34) q11Shape4T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8657043456 ||| 2^34) 6520832 q11Shape4T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T19OK,q11Shape4T22OK⟩

private def q11Shape4T2 : Tree 11 := .split 33 q11Shape4T3 q11Shape4T18
private theorem q11Shape4T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 6520832 q11Shape4T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67108864 (6520832 ||| 2^33) q11Shape4T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67108864 ||| 2^33) 6520832 q11Shape4T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T3OK,q11Shape4T18OK⟩

private def q11Shape4T0 : Tree 11 := .split 26 q11Shape4T1 q11Shape4T2
private theorem q11Shape4T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 6520832 q11Shape4T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 (6520832 ||| 2^26) q11Shape4T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (0 ||| 2^26) 6520832 q11Shape4T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T1OK,q11Shape4T2OK⟩

def q11Shape4P0 : Tree 11 := q11Shape4T0
theorem q11Shape4P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 0 6520832 q11Shape4P0=true := q11Shape4T0OK

end Graffiti384b.EffectiveSearch.Q11
