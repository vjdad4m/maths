import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T31 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,3,4,6,7}))))) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,2,3,8,9,10})))))
private theorem q11Shape4T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 62212243456 q11Shape4T31=true := by decide

private def q11Shape4T32 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,4,6,7,9})))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape4T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 1077936128 61138501632 q11Shape4T32=true := by decide

private def q11Shape4T30 : Tree 11 := .split 30 q11Shape4T31 q11Shape4T32
private theorem q11Shape4T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 61138501632 q11Shape4T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (61138501632 ||| 2^30) q11Shape4T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^30) 61138501632 q11Shape4T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T31OK,q11Shape4T32OK⟩

private def q11Shape4T33 : Tree 11 := (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6})))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9})))
private theorem q11Shape4T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 541065216 60601630720 q11Shape4T33=true := by decide

private def q11Shape4T29 : Tree 11 := .split 29 q11Shape4T30 q11Shape4T33
private theorem q11Shape4T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 60601630720 q11Shape4T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (60601630720 ||| 2^29) q11Shape4T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^29) 60601630720 q11Shape4T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T30OK,q11Shape4T33OK⟩

private def q11Shape4T34 : Tree 11 := (.split 29 (.split 30 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape4T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 272629760 60333195264 q11Shape4T34=true := by decide

private def q11Shape4T28 : Tree 11 := .split 28 q11Shape4T29 q11Shape4T34
private theorem q11Shape4T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 60333195264 q11Shape4T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (60333195264 ||| 2^28) q11Shape4T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^28) 60333195264 q11Shape4T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T29OK,q11Shape4T34OK⟩

private def q11Shape4T35 : Tree 11 := (.split 28 (.split 29 (.split 31 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape4T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 138412032 60198977536 q11Shape4T35=true := by decide

private def q11Shape4T27 : Tree 11 := .split 27 q11Shape4T28 q11Shape4T35
private theorem q11Shape4T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 60198977536 q11Shape4T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (60198977536 ||| 2^27) q11Shape4T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^27) 60198977536 q11Shape4T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T28OK,q11Shape4T35OK⟩

private def q11Shape4T36 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 30 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape4T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34363932672 25839239168 q11Shape4T36=true := by decide

private def q11Shape4T26 : Tree 11 := .split 35 q11Shape4T27 q11Shape4T36
private theorem q11Shape4T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 25839239168 q11Shape4T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (25839239168 ||| 2^35) q11Shape4T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^35) 25839239168 q11Shape4T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T27OK,q11Shape4T36OK⟩

private def q11Shape4T37 : Tree 11 := (.split 35 (.split 27 (.split 28 (.split 29 (.split 31 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape4T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17184063488 8659369984 q11Shape4T37=true := by decide

private def q11Shape4T25 : Tree 11 := .split 34 q11Shape4T26 q11Shape4T37
private theorem q11Shape4T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 8659369984 q11Shape4T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (8659369984 ||| 2^34) q11Shape4T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^34) 8659369984 q11Shape4T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T26OK,q11Shape4T37OK⟩

private def q11Shape4T39 : Tree 11 := (.split 35 (.split 27 (.split 28 (.split 29 (.split 32 (.split 18 (.split 20 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape4T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8594128896 17249304576 q11Shape4T39=true := by decide

private def q11Shape4T40 : Tree 11 := (.tip (.cover {0,1,4,5,6,8}))
private theorem q11Shape4T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 25773998080 69435392 q11Shape4T40=true := by decide

private def q11Shape4T38 : Tree 11 := .split 34 q11Shape4T39 q11Shape4T40
private theorem q11Shape4T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8594128896 69435392 q11Shape4T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8594128896 (69435392 ||| 2^34) q11Shape4T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8594128896 ||| 2^34) 69435392 q11Shape4T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T39OK,q11Shape4T40OK⟩

private def q11Shape4T24 : Tree 11 := .split 33 q11Shape4T25 q11Shape4T38
private theorem q11Shape4T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 69435392 q11Shape4T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (69435392 ||| 2^33) q11Shape4T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^33) 69435392 q11Shape4T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T25OK,q11Shape4T38OK⟩

private def q11Shape4T41 : Tree 11 := (.split 33 (.split 34 (.split 35 (.split 30 (.split 31 (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10})))
private theorem q11Shape4T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 71303168 2326528 q11Shape4T41=true := by decide

private def q11Shape4T23 : Tree 11 := .split 26 q11Shape4T24 q11Shape4T41
private theorem q11Shape4T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 2326528 q11Shape4T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 (2326528 ||| 2^26) q11Shape4T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4194304 ||| 2^26) 2326528 q11Shape4T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T24OK,q11Shape4T41OK⟩

def q11Shape4P1 : Tree 11 := q11Shape4T23
theorem q11Shape4P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4194304 2326528 q11Shape4P1=true := q11Shape4T23OK

end Graffiti384b.EffectiveSearch.Q11
