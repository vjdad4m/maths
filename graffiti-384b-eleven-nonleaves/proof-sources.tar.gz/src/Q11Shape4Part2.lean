import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T52 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,3,4,5,7}))))) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))))
private theorem q11Shape4T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 62214340608 q11Shape4T52=true := by decide

private def q11Shape4T53 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape4T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 1075838976 61140598784 q11Shape4T53=true := by decide

private def q11Shape4T51 : Tree 11 := .split 30 q11Shape4T52 q11Shape4T53
private theorem q11Shape4T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 61140598784 q11Shape4T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (61140598784 ||| 2^30) q11Shape4T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^30) 61140598784 q11Shape4T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T52OK,q11Shape4T53OK⟩

private def q11Shape4T54 : Tree 11 := (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7})))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9})))
private theorem q11Shape4T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 538968064 60603727872 q11Shape4T54=true := by decide

private def q11Shape4T50 : Tree 11 := .split 29 q11Shape4T51 q11Shape4T54
private theorem q11Shape4T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 60603727872 q11Shape4T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (60603727872 ||| 2^29) q11Shape4T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^29) 60603727872 q11Shape4T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T51OK,q11Shape4T54OK⟩

private def q11Shape4T55 : Tree 11 := (.split 29 (.split 30 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,7,8})))
private theorem q11Shape4T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 270532608 60335292416 q11Shape4T55=true := by decide

private def q11Shape4T49 : Tree 11 := .split 28 q11Shape4T50 q11Shape4T55
private theorem q11Shape4T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 60335292416 q11Shape4T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (60335292416 ||| 2^28) q11Shape4T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^28) 60335292416 q11Shape4T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T50OK,q11Shape4T55OK⟩

private def q11Shape4T56 : Tree 11 := (.split 28 (.split 29 (.split 31 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape4T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 136314880 60201074688 q11Shape4T56=true := by decide

private def q11Shape4T48 : Tree 11 := .split 27 q11Shape4T49 q11Shape4T56
private theorem q11Shape4T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 60201074688 q11Shape4T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (60201074688 ||| 2^27) q11Shape4T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^27) 60201074688 q11Shape4T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T49OK,q11Shape4T56OK⟩

private def q11Shape4T57 : Tree 11 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,6,7,9})))
private theorem q11Shape4T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34361835520 25841336320 q11Shape4T57=true := by decide

private def q11Shape4T47 : Tree 11 := .split 35 q11Shape4T48 q11Shape4T57
private theorem q11Shape4T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 25841336320 q11Shape4T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (25841336320 ||| 2^35) q11Shape4T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^35) 25841336320 q11Shape4T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T48OK,q11Shape4T57OK⟩

private def q11Shape4T58 : Tree 11 := (.split 35 (.split 28 (.split 30 (.split 31 (.split 32 (.split 18 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape4T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17181966336 8661467136 q11Shape4T58=true := by decide

private def q11Shape4T46 : Tree 11 := .split 34 q11Shape4T47 q11Shape4T58
private theorem q11Shape4T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 8661467136 q11Shape4T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (8661467136 ||| 2^34) q11Shape4T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^34) 8661467136 q11Shape4T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T47OK,q11Shape4T58OK⟩

private def q11Shape4T60 : Tree 11 := (.split 35 (.split 29 (.split 30 (.split 31 (.split 32 (.split 18 (.split 20 (.tip (.cover {0,1,2,3,5,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,5,7,9})))
private theorem q11Shape4T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8592031744 17251401728 q11Shape4T60=true := by decide

private def q11Shape4T61 : Tree 11 := (.tip (.cover {0,1,4,5,7,8}))
private theorem q11Shape4T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 25771900928 71532544 q11Shape4T61=true := by decide

private def q11Shape4T59 : Tree 11 := .split 34 q11Shape4T60 q11Shape4T61
private theorem q11Shape4T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8592031744 71532544 q11Shape4T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8592031744 (71532544 ||| 2^34) q11Shape4T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8592031744 ||| 2^34) 71532544 q11Shape4T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T60OK,q11Shape4T61OK⟩

private def q11Shape4T45 : Tree 11 := .split 33 q11Shape4T46 q11Shape4T59
private theorem q11Shape4T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 71532544 q11Shape4T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (71532544 ||| 2^33) q11Shape4T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^33) 71532544 q11Shape4T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T46OK,q11Shape4T59OK⟩

private def q11Shape4T62 : Tree 11 := (.split 33 (.split 34 (.split 35 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,5,7})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10})))
private theorem q11Shape4T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 69206016 4423680 q11Shape4T62=true := by decide

private def q11Shape4T44 : Tree 11 := .split 26 q11Shape4T45 q11Shape4T62
private theorem q11Shape4T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 4423680 q11Shape4T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (4423680 ||| 2^26) q11Shape4T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^26) 4423680 q11Shape4T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T45OK,q11Shape4T62OK⟩

private def q11Shape4T65 : Tree 11 := (.split 35 (.split 18 (.split 19 (.split 20 (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,9})))
private theorem q11Shape4T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 6291456 25770033152 q11Shape4T65=true := by decide

private def q11Shape4T66 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape4T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17186160640 8590163968 q11Shape4T66=true := by decide

private def q11Shape4T64 : Tree 11 := .split 34 q11Shape4T65 q11Shape4T66
private theorem q11Shape4T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 6291456 8590163968 q11Shape4T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 6291456 (8590163968 ||| 2^34) q11Shape4T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (6291456 ||| 2^34) 8590163968 q11Shape4T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T65OK,q11Shape4T66OK⟩

private def q11Shape4T67 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape4T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8596226048 229376 q11Shape4T67=true := by decide

private def q11Shape4T63 : Tree 11 := .split 33 q11Shape4T64 q11Shape4T67
private theorem q11Shape4T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 6291456 229376 q11Shape4T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 6291456 (229376 ||| 2^33) q11Shape4T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (6291456 ||| 2^33) 229376 q11Shape4T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T64OK,q11Shape4T67OK⟩

private def q11Shape4T43 : Tree 11 := .split 22 q11Shape4T44 q11Shape4T63
private theorem q11Shape4T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 229376 q11Shape4T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 (229376 ||| 2^22) q11Shape4T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2097152 ||| 2^22) 229376 q11Shape4T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T44OK,q11Shape4T63OK⟩

def q11Shape4P2 : Tree 11 := q11Shape4T43
theorem q11Shape4P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2097152 229376 q11Shape4P2=true := q11Shape4T43OK

end Graffiti384b.EffectiveSearch.Q11
