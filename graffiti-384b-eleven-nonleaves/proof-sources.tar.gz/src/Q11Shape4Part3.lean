import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T79 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,3,5,6,7}))))) (.split 12 (.tip (.small 1)) (.split 20 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,2,3,8,9,10})))))
private theorem q11Shape4T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 62216306688 q11Shape4T79=true := by decide

private def q11Shape4T80 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,7,9})))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape4T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 1073872896 61142564864 q11Shape4T80=true := by decide

private def q11Shape4T78 : Tree 11 := .split 30 q11Shape4T79 q11Shape4T80
private theorem q11Shape4T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 61142564864 q11Shape4T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (61142564864 ||| 2^30) q11Shape4T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^30) 61142564864 q11Shape4T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T79OK,q11Shape4T80OK⟩

private def q11Shape4T81 : Tree 11 := (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6})))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape4T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 537001984 60605693952 q11Shape4T81=true := by decide

private def q11Shape4T77 : Tree 11 := .split 29 q11Shape4T78 q11Shape4T81
private theorem q11Shape4T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 60605693952 q11Shape4T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (60605693952 ||| 2^29) q11Shape4T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^29) 60605693952 q11Shape4T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T78OK,q11Shape4T81OK⟩

private def q11Shape4T82 : Tree 11 := (.split 29 (.split 30 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,6,8})))
private theorem q11Shape4T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 268566528 60337258496 q11Shape4T82=true := by decide

private def q11Shape4T76 : Tree 11 := .split 28 q11Shape4T77 q11Shape4T82
private theorem q11Shape4T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 60337258496 q11Shape4T76=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (60337258496 ||| 2^28) q11Shape4T77 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^28) 60337258496 q11Shape4T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T77OK,q11Shape4T82OK⟩

private def q11Shape4T83 : Tree 11 := (.split 28 (.split 29 (.split 31 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,6}))))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,10})))
private theorem q11Shape4T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 134348800 60203040768 q11Shape4T83=true := by decide

private def q11Shape4T75 : Tree 11 := .split 27 q11Shape4T76 q11Shape4T83
private theorem q11Shape4T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 60203040768 q11Shape4T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (60203040768 ||| 2^27) q11Shape4T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^27) 60203040768 q11Shape4T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T76OK,q11Shape4T83OK⟩

private def q11Shape4T84 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 30 (.split 18 (.split 23 (.split 24 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,4,5,6,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,6,9})))
private theorem q11Shape4T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34359869440 25843302400 q11Shape4T84=true := by decide

private def q11Shape4T74 : Tree 11 := .split 35 q11Shape4T75 q11Shape4T84
private theorem q11Shape4T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 25843302400 q11Shape4T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (25843302400 ||| 2^35) q11Shape4T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^35) 25843302400 q11Shape4T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T75OK,q11Shape4T84OK⟩

private def q11Shape4T86 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 31 (.split 19 (.split 23 (.split 24 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,8,9})))
private theorem q11Shape4T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17180000256 43023171584 q11Shape4T86=true := by decide

private def q11Shape4T87 : Tree 11 := (.tip (.cover {0,1,4,5,6,10}))
private theorem q11Shape4T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 51539738624 8663433216 q11Shape4T87=true := by decide

private def q11Shape4T85 : Tree 11 := .split 35 q11Shape4T86 q11Shape4T87
private theorem q11Shape4T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17180000256 8663433216 q11Shape4T85=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17180000256 (8663433216 ||| 2^35) q11Shape4T86 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (17180000256 ||| 2^35) 8663433216 q11Shape4T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T86OK,q11Shape4T87OK⟩

private def q11Shape4T73 : Tree 11 := .split 34 q11Shape4T74 q11Shape4T85
private theorem q11Shape4T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 8663433216 q11Shape4T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (8663433216 ||| 2^34) q11Shape4T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^34) 8663433216 q11Shape4T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T74OK,q11Shape4T85OK⟩

private def q11Shape4T90 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 32 (.split 20 (.split 23 (.split 25 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,4,5,6,8}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,10})))
private theorem q11Shape4T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590065664 51613106176 q11Shape4T90=true := by decide

private def q11Shape4T91 : Tree 11 := (.tip (.cover {0,1,4,5,6,9}))
private theorem q11Shape4T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 42949804032 17253367808 q11Shape4T91=true := by decide

private def q11Shape4T89 : Tree 11 := .split 35 q11Shape4T90 q11Shape4T91
private theorem q11Shape4T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590065664 17253367808 q11Shape4T89=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590065664 (17253367808 ||| 2^35) q11Shape4T90 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8590065664 ||| 2^35) 17253367808 q11Shape4T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T90OK,q11Shape4T91OK⟩

private def q11Shape4T92 : Tree 11 := (.tip (.cover {0,1,4,5,6,8}))
private theorem q11Shape4T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 25769934848 73498624 q11Shape4T92=true := by decide

private def q11Shape4T88 : Tree 11 := .split 34 q11Shape4T89 q11Shape4T92
private theorem q11Shape4T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590065664 73498624 q11Shape4T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590065664 (73498624 ||| 2^34) q11Shape4T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8590065664 ||| 2^34) 73498624 q11Shape4T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T89OK,q11Shape4T92OK⟩

private def q11Shape4T72 : Tree 11 := .split 33 q11Shape4T73 q11Shape4T88
private theorem q11Shape4T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 73498624 q11Shape4T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (73498624 ||| 2^33) q11Shape4T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^33) 73498624 q11Shape4T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T73OK,q11Shape4T88OK⟩

private def q11Shape4T93 : Tree 11 := (.split 33 (.split 34 (.split 35 (.split 30 (.split 31 (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10})))
private theorem q11Shape4T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67239936 6389760 q11Shape4T93=true := by decide

private def q11Shape4T71 : Tree 11 := .split 26 q11Shape4T72 q11Shape4T93
private theorem q11Shape4T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 6389760 q11Shape4T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (6389760 ||| 2^26) q11Shape4T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^26) 6389760 q11Shape4T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T72OK,q11Shape4T93OK⟩

private def q11Shape4T97 : Tree 11 := (.split 35 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,9})))
private theorem q11Shape4T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4325376 25839108096 q11Shape4T97=true := by decide

private def q11Shape4T98 : Tree 11 := (.tip (.cover {0,1,6,7,8,9}))
private theorem q11Shape4T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17184194560 8659238912 q11Shape4T98=true := by decide

private def q11Shape4T96 : Tree 11 := .split 34 q11Shape4T97 q11Shape4T98
private theorem q11Shape4T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4325376 8659238912 q11Shape4T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4325376 (8659238912 ||| 2^34) q11Shape4T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4325376 ||| 2^34) 8659238912 q11Shape4T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T97OK,q11Shape4T98OK⟩

private def q11Shape4T99 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape4T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8594259968 69304320 q11Shape4T99=true := by decide

private def q11Shape4T95 : Tree 11 := .split 33 q11Shape4T96 q11Shape4T99
private theorem q11Shape4T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4325376 69304320 q11Shape4T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4325376 (69304320 ||| 2^33) q11Shape4T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4325376 ||| 2^33) 69304320 q11Shape4T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T96OK,q11Shape4T99OK⟩

private def q11Shape4T100 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape4T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 71434240 2195456 q11Shape4T100=true := by decide

private def q11Shape4T94 : Tree 11 := .split 26 q11Shape4T95 q11Shape4T100
private theorem q11Shape4T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4325376 2195456 q11Shape4T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4325376 (2195456 ||| 2^26) q11Shape4T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4325376 ||| 2^26) 2195456 q11Shape4T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T95OK,q11Shape4T100OK⟩

private def q11Shape4T70 : Tree 11 := .split 22 q11Shape4T71 q11Shape4T94
private theorem q11Shape4T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 2195456 q11Shape4T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (2195456 ||| 2^22) q11Shape4T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^22) 2195456 q11Shape4T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T71OK,q11Shape4T94OK⟩

private def q11Shape4T104 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 26 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {1,2,3,4,5,7}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape4T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2228224 60129640448 q11Shape4T104=true := by decide

private def q11Shape4T105 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape4T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34361966592 25769902080 q11Shape4T105=true := by decide

private def q11Shape4T103 : Tree 11 := .split 35 q11Shape4T104 q11Shape4T105
private theorem q11Shape4T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2228224 25769902080 q11Shape4T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2228224 (25769902080 ||| 2^35) q11Shape4T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2228224 ||| 2^35) 25769902080 q11Shape4T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T104OK,q11Shape4T105OK⟩

private def q11Shape4T106 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape4T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17182097408 8590032896 q11Shape4T106=true := by decide

private def q11Shape4T102 : Tree 11 := .split 34 q11Shape4T103 q11Shape4T106
private theorem q11Shape4T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2228224 8590032896 q11Shape4T102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2228224 (8590032896 ||| 2^34) q11Shape4T103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2228224 ||| 2^34) 8590032896 q11Shape4T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T103OK,q11Shape4T106OK⟩

private def q11Shape4T107 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape4T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8592162816 98304 q11Shape4T107=true := by decide

private def q11Shape4T101 : Tree 11 := .split 33 q11Shape4T102 q11Shape4T107
private theorem q11Shape4T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2228224 98304 q11Shape4T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2228224 (98304 ||| 2^33) q11Shape4T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2228224 ||| 2^33) 98304 q11Shape4T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T102OK,q11Shape4T107OK⟩

private def q11Shape4T69 : Tree 11 := .split 21 q11Shape4T70 q11Shape4T101
private theorem q11Shape4T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 98304 q11Shape4T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 (98304 ||| 2^21) q11Shape4T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (131072 ||| 2^21) 98304 q11Shape4T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T70OK,q11Shape4T101OK⟩

def q11Shape4P3 : Tree 11 := q11Shape4T69
theorem q11Shape4P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 131072 98304 q11Shape4P3=true := q11Shape4T69OK

end Graffiti384b.EffectiveSearch.Q11
