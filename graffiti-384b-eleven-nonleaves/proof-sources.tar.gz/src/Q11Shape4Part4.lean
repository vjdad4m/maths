import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T119 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,3,4,5,7}))))) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))))
private theorem q11Shape4T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 62216372224 q11Shape4T119=true := by decide

private def q11Shape4T120 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))) (.tip (.cover {0,1,4,5,7,10})))
private theorem q11Shape4T120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 1073807360 61142630400 q11Shape4T120=true := by decide

private def q11Shape4T118 : Tree 11 := .split 30 q11Shape4T119 q11Shape4T120
private theorem q11Shape4T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 61142630400 q11Shape4T118=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (61142630400 ||| 2^30) q11Shape4T119 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^30) 61142630400 q11Shape4T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T119OK,q11Shape4T120OK⟩

private def q11Shape4T121 : Tree 11 := (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7})))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape4T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 536936448 60605759488 q11Shape4T121=true := by decide

private def q11Shape4T117 : Tree 11 := .split 29 q11Shape4T118 q11Shape4T121
private theorem q11Shape4T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 60605759488 q11Shape4T117=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (60605759488 ||| 2^29) q11Shape4T118 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^29) 60605759488 q11Shape4T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T118OK,q11Shape4T121OK⟩

private def q11Shape4T122 : Tree 11 := (.split 29 (.split 30 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape4T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 268500992 60337324032 q11Shape4T122=true := by decide

private def q11Shape4T116 : Tree 11 := .split 28 q11Shape4T117 q11Shape4T122
private theorem q11Shape4T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 60337324032 q11Shape4T116=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (60337324032 ||| 2^28) q11Shape4T117 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^28) 60337324032 q11Shape4T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T117OK,q11Shape4T122OK⟩

private def q11Shape4T123 : Tree 11 := (.split 28 (.split 29 (.split 31 (.split 32 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,5,7}))))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape4T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 134283264 60203106304 q11Shape4T123=true := by decide

private def q11Shape4T115 : Tree 11 := .split 27 q11Shape4T116 q11Shape4T123
private theorem q11Shape4T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 60203106304 q11Shape4T115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (60203106304 ||| 2^27) q11Shape4T116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^27) 60203106304 q11Shape4T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T116OK,q11Shape4T123OK⟩

private def q11Shape4T124 : Tree 11 := (.split 27 (.split 30 (.split 31 (.split 32 (.split 18 (.split 23 (.split 24 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,7,9}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape4T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34359803904 25843367936 q11Shape4T124=true := by decide

private def q11Shape4T114 : Tree 11 := .split 35 q11Shape4T115 q11Shape4T124
private theorem q11Shape4T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 25843367936 q11Shape4T114=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (25843367936 ||| 2^35) q11Shape4T115 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^35) 25843367936 q11Shape4T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T115OK,q11Shape4T124OK⟩

private def q11Shape4T126 : Tree 11 := (.split 28 (.split 30 (.split 31 (.split 32 (.split 19 (.split 23 (.split 24 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape4T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17179934720 43023237120 q11Shape4T126=true := by decide

private def q11Shape4T127 : Tree 11 := (.tip (.cover {0,1,4,5,7,10}))
private theorem q11Shape4T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 51539673088 8663498752 q11Shape4T127=true := by decide

private def q11Shape4T125 : Tree 11 := .split 35 q11Shape4T126 q11Shape4T127
private theorem q11Shape4T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17179934720 8663498752 q11Shape4T125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17179934720 (8663498752 ||| 2^35) q11Shape4T126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (17179934720 ||| 2^35) 8663498752 q11Shape4T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T126OK,q11Shape4T127OK⟩

private def q11Shape4T113 : Tree 11 := .split 34 q11Shape4T114 q11Shape4T125
private theorem q11Shape4T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 8663498752 q11Shape4T113=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (8663498752 ||| 2^34) q11Shape4T114 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^34) 8663498752 q11Shape4T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T114OK,q11Shape4T125OK⟩

private def q11Shape4T130 : Tree 11 := (.split 29 (.split 30 (.split 31 (.split 32 (.split 20 (.split 23 (.split 25 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,7,8}))) (.tip (.cover {0,1,4,5,9,10}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape4T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590000128 51613171712 q11Shape4T130=true := by decide

private def q11Shape4T131 : Tree 11 := (.tip (.cover {0,1,4,5,7,9}))
private theorem q11Shape4T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 42949738496 17253433344 q11Shape4T131=true := by decide

private def q11Shape4T129 : Tree 11 := .split 35 q11Shape4T130 q11Shape4T131
private theorem q11Shape4T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590000128 17253433344 q11Shape4T129=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590000128 (17253433344 ||| 2^35) q11Shape4T130 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8590000128 ||| 2^35) 17253433344 q11Shape4T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T130OK,q11Shape4T131OK⟩

private def q11Shape4T132 : Tree 11 := (.tip (.cover {0,1,4,5,7,8}))
private theorem q11Shape4T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 25769869312 73564160 q11Shape4T132=true := by decide

private def q11Shape4T128 : Tree 11 := .split 34 q11Shape4T129 q11Shape4T132
private theorem q11Shape4T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590000128 73564160 q11Shape4T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590000128 (73564160 ||| 2^34) q11Shape4T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8590000128 ||| 2^34) 73564160 q11Shape4T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T129OK,q11Shape4T132OK⟩

private def q11Shape4T112 : Tree 11 := .split 33 q11Shape4T113 q11Shape4T128
private theorem q11Shape4T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 73564160 q11Shape4T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (73564160 ||| 2^33) q11Shape4T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^33) 73564160 q11Shape4T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T113OK,q11Shape4T128OK⟩

private def q11Shape4T133 : Tree 11 := (.split 33 (.split 34 (.split 35 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,5,7})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10})))
private theorem q11Shape4T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67174400 6455296 q11Shape4T133=true := by decide

private def q11Shape4T111 : Tree 11 := .split 26 q11Shape4T112 q11Shape4T133
private theorem q11Shape4T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 6455296 q11Shape4T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (6455296 ||| 2^26) q11Shape4T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^26) 6455296 q11Shape4T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T112OK,q11Shape4T133OK⟩

private def q11Shape4T137 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 26 (.split 30 (.split 31 (.split 32 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {1,2,3,4,5,7}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape4T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4259840 60131803136 q11Shape4T137=true := by decide

private def q11Shape4T138 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape4T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34363998208 25772064768 q11Shape4T138=true := by decide

private def q11Shape4T136 : Tree 11 := .split 35 q11Shape4T137 q11Shape4T138
private theorem q11Shape4T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4259840 25772064768 q11Shape4T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4259840 (25772064768 ||| 2^35) q11Shape4T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4259840 ||| 2^35) 25772064768 q11Shape4T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T137OK,q11Shape4T138OK⟩

private def q11Shape4T139 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape4T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17184129024 8592195584 q11Shape4T139=true := by decide

private def q11Shape4T135 : Tree 11 := .split 34 q11Shape4T136 q11Shape4T139
private theorem q11Shape4T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4259840 8592195584 q11Shape4T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4259840 (8592195584 ||| 2^34) q11Shape4T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4259840 ||| 2^34) 8592195584 q11Shape4T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T136OK,q11Shape4T139OK⟩

private def q11Shape4T140 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape4T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8594194432 2260992 q11Shape4T140=true := by decide

private def q11Shape4T134 : Tree 11 := .split 33 q11Shape4T135 q11Shape4T140
private theorem q11Shape4T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4259840 2260992 q11Shape4T134=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4259840 (2260992 ||| 2^33) q11Shape4T135 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4259840 ||| 2^33) 2260992 q11Shape4T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T135OK,q11Shape4T140OK⟩

private def q11Shape4T110 : Tree 11 := .split 22 q11Shape4T111 q11Shape4T134
private theorem q11Shape4T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 2260992 q11Shape4T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (2260992 ||| 2^22) q11Shape4T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^22) 2260992 q11Shape4T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T111OK,q11Shape4T134OK⟩

private def q11Shape4T141 : Tree 11 := (.split 26 (.split 33 (.split 34 (.split 35 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,5,7})) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape4T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2162688 163840 q11Shape4T141=true := by decide

private def q11Shape4T109 : Tree 11 := .split 21 q11Shape4T110 q11Shape4T141
private theorem q11Shape4T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 163840 q11Shape4T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 (163840 ||| 2^21) q11Shape4T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (65536 ||| 2^21) 163840 q11Shape4T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T110OK,q11Shape4T141OK⟩

def q11Shape4P4 : Tree 11 := q11Shape4T109
theorem q11Shape4P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 65536 163840 q11Shape4P4=true := q11Shape4T109OK

end Graffiti384b.EffectiveSearch.Q11
