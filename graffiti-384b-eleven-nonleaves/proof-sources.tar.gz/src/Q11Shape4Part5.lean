import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T147 : Tree 11 := (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,5,8,9}))) (.tip (.cover {0,1,4,5,8,10}))) (.tip (.cover {0,1,4,5,9,10})))
private theorem q11Shape4T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 60135866368 q11Shape4T147=true := by decide

private def q11Shape4T148 : Tree 11 := (.split 26 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.tip (.cover {1,2,3,4,5,6})) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,7,8,9,10})))
private theorem q11Shape4T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4390912 60131672064 q11Shape4T148=true := by decide

private def q11Shape4T146 : Tree 11 := .split 22 q11Shape4T147 q11Shape4T148
private theorem q11Shape4T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 60131672064 q11Shape4T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 (60131672064 ||| 2^22) q11Shape4T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (196608 ||| 2^22) 60131672064 q11Shape4T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T147OK,q11Shape4T148OK⟩

private def q11Shape4T149 : Tree 11 := (.split 26 (.split 27 (.split 28 (.split 29 (.tip (.cover {1,2,3,4,5,7})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,6,8,9,10})))
private theorem q11Shape4T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2293760 60129574912 q11Shape4T149=true := by decide

private def q11Shape4T145 : Tree 11 := .split 21 q11Shape4T146 q11Shape4T149
private theorem q11Shape4T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 60129574912 q11Shape4T145=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 (60129574912 ||| 2^21) q11Shape4T146 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (196608 ||| 2^21) 60129574912 q11Shape4T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T146OK,q11Shape4T149OK⟩

private def q11Shape4T150 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape4T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34359934976 25769836544 q11Shape4T150=true := by decide

private def q11Shape4T144 : Tree 11 := .split 35 q11Shape4T145 q11Shape4T150
private theorem q11Shape4T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 25769836544 q11Shape4T144=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 (25769836544 ||| 2^35) q11Shape4T145 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (196608 ||| 2^35) 25769836544 q11Shape4T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T145OK,q11Shape4T150OK⟩

private def q11Shape4T151 : Tree 11 := (.tip (.cover {0,1,4,5,8,9}))
private theorem q11Shape4T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17180065792 8589967360 q11Shape4T151=true := by decide

private def q11Shape4T143 : Tree 11 := .split 34 q11Shape4T144 q11Shape4T151
private theorem q11Shape4T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 8589967360 q11Shape4T143=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 (8589967360 ||| 2^34) q11Shape4T144 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (196608 ||| 2^34) 8589967360 q11Shape4T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T144OK,q11Shape4T151OK⟩

private def q11Shape4T152 : Tree 11 := (.tip (.cover {0,1,4,5,8,10}))
private theorem q11Shape4T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590131200 32768 q11Shape4T152=true := by decide

private def q11Shape4T142 : Tree 11 := .split 33 q11Shape4T143 q11Shape4T152
private theorem q11Shape4T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 32768 q11Shape4T142=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 (32768 ||| 2^33) q11Shape4T143 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (196608 ||| 2^33) 32768 q11Shape4T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T143OK,q11Shape4T152OK⟩

def q11Shape4P5 : Tree 11 := q11Shape4T142
theorem q11Shape4P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 196608 32768 q11Shape4P5=true := q11Shape4T142OK

end Graffiti384b.EffectiveSearch.Q11
