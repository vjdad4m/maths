import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T165 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,2,3,4,10})))) (.split 12 (.tip (.small 1)) (.split 20 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,7,8})))))
private theorem q11Shape4T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 62216404992 q11Shape4T165=true := by decide

private def q11Shape4T166 : Tree 11 := (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.cover {0,1,2,3,5,7})) (.tip (.cover {0,1,4,6,7,9}))))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape4T166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 1073774592 61142663168 q11Shape4T166=true := by decide

private def q11Shape4T164 : Tree 11 := .split 30 q11Shape4T165 q11Shape4T166
private theorem q11Shape4T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 61142663168 q11Shape4T164=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (61142663168 ||| 2^30) q11Shape4T165 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^30) 61142663168 q11Shape4T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T165OK,q11Shape4T166OK⟩

private def q11Shape4T167 : Tree 11 := (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,6,7,8})))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,9})))
private theorem q11Shape4T167OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 536903680 60605792256 q11Shape4T167=true := by decide

private def q11Shape4T163 : Tree 11 := .split 29 q11Shape4T164 q11Shape4T167
private theorem q11Shape4T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 60605792256 q11Shape4T163=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (60605792256 ||| 2^29) q11Shape4T164 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^29) 60605792256 q11Shape4T167)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T164OK,q11Shape4T167OK⟩

private def q11Shape4T168 : Tree 11 := (.split 29 (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7}))))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,6,7,8})))
private theorem q11Shape4T168OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 268468224 60337356800 q11Shape4T168=true := by decide

private def q11Shape4T162 : Tree 11 := .split 28 q11Shape4T163 q11Shape4T168
private theorem q11Shape4T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 60337356800 q11Shape4T162=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (60337356800 ||| 2^28) q11Shape4T163 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^28) 60337356800 q11Shape4T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T163OK,q11Shape4T168OK⟩

private def q11Shape4T169 : Tree 11 := (.split 28 (.split 29 (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,7}))))) (.tip (.cover {0,1,4,6,7,10}))) (.tip (.cover {0,1,4,8,9,10}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape4T169OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 134250496 60203139072 q11Shape4T169=true := by decide

private def q11Shape4T161 : Tree 11 := .split 27 q11Shape4T162 q11Shape4T169
private theorem q11Shape4T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 60203139072 q11Shape4T161=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (60203139072 ||| 2^27) q11Shape4T162 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^27) 60203139072 q11Shape4T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T162OK,q11Shape4T169OK⟩

private def q11Shape4T170 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 18 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,7,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,6,7,9})))
private theorem q11Shape4T170OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34359771136 25843400704 q11Shape4T170=true := by decide

private def q11Shape4T160 : Tree 11 := .split 35 q11Shape4T161 q11Shape4T170
private theorem q11Shape4T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 25843400704 q11Shape4T160=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (25843400704 ||| 2^35) q11Shape4T161 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^35) 25843400704 q11Shape4T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T161OK,q11Shape4T170OK⟩

private def q11Shape4T171 : Tree 11 := (.split 35 (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 19 (.tip (.cover {0,1,2,3,5,10})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,6,7,10})))
private theorem q11Shape4T171OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17179901952 8663531520 q11Shape4T171=true := by decide

private def q11Shape4T159 : Tree 11 := .split 34 q11Shape4T160 q11Shape4T171
private theorem q11Shape4T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 8663531520 q11Shape4T159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (8663531520 ||| 2^34) q11Shape4T160 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^34) 8663531520 q11Shape4T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T160OK,q11Shape4T171OK⟩

private def q11Shape4T174 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 32 (.split 20 (.tip (.cover {0,1,2,3,5,8})) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,7,8}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,10})))
private theorem q11Shape4T174OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8589967360 51613204480 q11Shape4T174=true := by decide

private def q11Shape4T175 : Tree 11 := (.tip (.cover {0,1,4,6,7,9}))
private theorem q11Shape4T175OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 42949705728 17253466112 q11Shape4T175=true := by decide

private def q11Shape4T173 : Tree 11 := .split 35 q11Shape4T174 q11Shape4T175
private theorem q11Shape4T173OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8589967360 17253466112 q11Shape4T173=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8589967360 (17253466112 ||| 2^35) q11Shape4T174 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8589967360 ||| 2^35) 17253466112 q11Shape4T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T174OK,q11Shape4T175OK⟩

private def q11Shape4T176 : Tree 11 := (.tip (.cover {0,1,4,6,7,8}))
private theorem q11Shape4T176OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 25769836544 73596928 q11Shape4T176=true := by decide

private def q11Shape4T172 : Tree 11 := .split 34 q11Shape4T173 q11Shape4T176
private theorem q11Shape4T172OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8589967360 73596928 q11Shape4T172=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8589967360 (73596928 ||| 2^34) q11Shape4T173 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (8589967360 ||| 2^34) 73596928 q11Shape4T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T173OK,q11Shape4T176OK⟩

private def q11Shape4T158 : Tree 11 := .split 33 q11Shape4T159 q11Shape4T172
private theorem q11Shape4T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 73596928 q11Shape4T158=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (73596928 ||| 2^33) q11Shape4T159 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^33) 73596928 q11Shape4T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T159OK,q11Shape4T172OK⟩

private def q11Shape4T180 : Tree 11 := (.split 27 (.split 28 (.split 29 (.split 30 (.split 31 (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,4,6,10})))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10})))
private theorem q11Shape4T180OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67141632 60136030208 q11Shape4T180=true := by decide

private def q11Shape4T181 : Tree 11 := (.tip (.cover {0,1,4,6,8,9}))
private theorem q11Shape4T181OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 34426880000 25776291840 q11Shape4T181=true := by decide

private def q11Shape4T179 : Tree 11 := .split 35 q11Shape4T180 q11Shape4T181
private theorem q11Shape4T179OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67141632 25776291840 q11Shape4T179=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67141632 (25776291840 ||| 2^35) q11Shape4T180 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67141632 ||| 2^35) 25776291840 q11Shape4T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T180OK,q11Shape4T181OK⟩

private def q11Shape4T182 : Tree 11 := (.tip (.cover {0,1,4,6,8,9}))
private theorem q11Shape4T182OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17247010816 8596422656 q11Shape4T182=true := by decide

private def q11Shape4T178 : Tree 11 := .split 34 q11Shape4T179 q11Shape4T182
private theorem q11Shape4T178OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67141632 8596422656 q11Shape4T178=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67141632 (8596422656 ||| 2^34) q11Shape4T179 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67141632 ||| 2^34) 8596422656 q11Shape4T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T179OK,q11Shape4T182OK⟩

private def q11Shape4T183 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape4T183OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8657076224 6488064 q11Shape4T183=true := by decide

private def q11Shape4T177 : Tree 11 := .split 33 q11Shape4T178 q11Shape4T183
private theorem q11Shape4T177OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67141632 6488064 q11Shape4T177=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 67141632 (6488064 ||| 2^33) q11Shape4T178 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (67141632 ||| 2^33) 6488064 q11Shape4T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T178OK,q11Shape4T183OK⟩

private def q11Shape4T157 : Tree 11 := .split 26 q11Shape4T158 q11Shape4T177
private theorem q11Shape4T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 6488064 q11Shape4T157=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (6488064 ||| 2^26) q11Shape4T158 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^26) 6488064 q11Shape4T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T158OK,q11Shape4T177OK⟩

private def q11Shape4T186 : Tree 11 := (.split 35 (.split 27 (.split 28 (.split 29 (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9})))
private theorem q11Shape4T186OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4227072 25772097536 q11Shape4T186=true := by decide

private def q11Shape4T187 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape4T187OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17184096256 8592228352 q11Shape4T187=true := by decide

private def q11Shape4T185 : Tree 11 := .split 34 q11Shape4T186 q11Shape4T187
private theorem q11Shape4T185OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4227072 8592228352 q11Shape4T185=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4227072 (8592228352 ||| 2^34) q11Shape4T186 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4227072 ||| 2^34) 8592228352 q11Shape4T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T186OK,q11Shape4T187OK⟩

private def q11Shape4T188 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape4T188OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8594161664 2293760 q11Shape4T188=true := by decide

private def q11Shape4T184 : Tree 11 := .split 33 q11Shape4T185 q11Shape4T188
private theorem q11Shape4T184OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4227072 2293760 q11Shape4T184=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 4227072 (2293760 ||| 2^33) q11Shape4T185 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (4227072 ||| 2^33) 2293760 q11Shape4T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T185OK,q11Shape4T188OK⟩

private def q11Shape4T156 : Tree 11 := .split 22 q11Shape4T157 q11Shape4T184
private theorem q11Shape4T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 2293760 q11Shape4T156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (2293760 ||| 2^22) q11Shape4T157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^22) 2293760 q11Shape4T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T157OK,q11Shape4T184OK⟩

private def q11Shape4T192 : Tree 11 := (.split 35 (.split 30 (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.tip (.cover {1,2,3,4,6,7})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9})))
private theorem q11Shape4T192OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2129920 25774194688 q11Shape4T192=true := by decide

private def q11Shape4T193 : Tree 11 := (.tip (.cover {0,1,5,7,8,9}))
private theorem q11Shape4T193OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17181999104 8594325504 q11Shape4T193=true := by decide

private def q11Shape4T191 : Tree 11 := .split 34 q11Shape4T192 q11Shape4T193
private theorem q11Shape4T191OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2129920 8594325504 q11Shape4T191=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2129920 (8594325504 ||| 2^34) q11Shape4T192 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2129920 ||| 2^34) 8594325504 q11Shape4T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T192OK,q11Shape4T193OK⟩

private def q11Shape4T194 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape4T194OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8592064512 4390912 q11Shape4T194=true := by decide

private def q11Shape4T190 : Tree 11 := .split 33 q11Shape4T191 q11Shape4T194
private theorem q11Shape4T190OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2129920 4390912 q11Shape4T190=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2129920 (4390912 ||| 2^33) q11Shape4T191 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2129920 ||| 2^33) 4390912 q11Shape4T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T191OK,q11Shape4T194OK⟩

private def q11Shape4T195 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape4T195OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 6324224 196608 q11Shape4T195=true := by decide

private def q11Shape4T189 : Tree 11 := .split 22 q11Shape4T190 q11Shape4T195
private theorem q11Shape4T189OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2129920 196608 q11Shape4T189=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 2129920 (196608 ||| 2^22) q11Shape4T190 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (2129920 ||| 2^22) 196608 q11Shape4T195)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T190OK,q11Shape4T195OK⟩

private def q11Shape4T155 : Tree 11 := .split 21 q11Shape4T156 q11Shape4T189
private theorem q11Shape4T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 196608 q11Shape4T155=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 (196608 ||| 2^21) q11Shape4T156 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (32768 ||| 2^21) 196608 q11Shape4T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T156OK,q11Shape4T189OK⟩

def q11Shape4P6 : Tree 11 := q11Shape4T155
theorem q11Shape4P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 32768 196608 q11Shape4P6=true := q11Shape4T155OK

end Graffiti384b.EffectiveSearch.Q11
