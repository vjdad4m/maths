import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape4T198 : Tree 11 := (.split 35 (.split 27 (.split 28 (.split 29 (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,9}))) (.tip (.cover {0,1,4,6,8,10}))) (.tip (.cover {0,1,4,6,9,10}))) (.tip (.cover {0,1,4,6,8,9})))
private theorem q11Shape4T198OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 163840 25769869312 q11Shape4T198=true := by decide

private def q11Shape4T199 : Tree 11 := (.tip (.cover {0,1,4,6,8,9}))
private theorem q11Shape4T199OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17180033024 8590000128 q11Shape4T199=true := by decide

private def q11Shape4T197 : Tree 11 := .split 34 q11Shape4T198 q11Shape4T199
private theorem q11Shape4T197OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 163840 8590000128 q11Shape4T197=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 163840 (8590000128 ||| 2^34) q11Shape4T198 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (163840 ||| 2^34) 8590000128 q11Shape4T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T198OK,q11Shape4T199OK⟩

private def q11Shape4T200 : Tree 11 := (.tip (.cover {0,1,4,6,8,10}))
private theorem q11Shape4T200OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590098432 65536 q11Shape4T200=true := by decide

private def q11Shape4T196 : Tree 11 := .split 33 q11Shape4T197 q11Shape4T200
private theorem q11Shape4T196OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 163840 65536 q11Shape4T196=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 163840 (65536 ||| 2^33) q11Shape4T197 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (163840 ||| 2^33) 65536 q11Shape4T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T197OK,q11Shape4T200OK⟩

def q11Shape4P7 : Tree 11 := q11Shape4T196
theorem q11Shape4P7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 163840 65536 q11Shape4P7=true := q11Shape4T196OK

private def q11Shape4T205 : Tree 11 := (.split 35 (.split 30 (.split 31 (.split 32 (.split 18 (.split 19 (.split 20 (.tip (.cover {1,2,3,5,6,7})) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,9}))) (.tip (.cover {0,1,4,7,8,10}))) (.tip (.cover {0,1,4,7,9,10}))) (.tip (.cover {0,1,4,7,8,9})))
private theorem q11Shape4T205OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 25769934848 q11Shape4T205=true := by decide

private def q11Shape4T206 : Tree 11 := (.tip (.cover {0,1,4,7,8,9}))
private theorem q11Shape4T206OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 17179967488 8590065664 q11Shape4T206=true := by decide

private def q11Shape4T204 : Tree 11 := .split 34 q11Shape4T205 q11Shape4T206
private theorem q11Shape4T204OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 8590065664 q11Shape4T204=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 (8590065664 ||| 2^34) q11Shape4T205 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (98304 ||| 2^34) 8590065664 q11Shape4T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T205OK,q11Shape4T206OK⟩

private def q11Shape4T207 : Tree 11 := (.tip (.cover {0,1,4,7,8,10}))
private theorem q11Shape4T207OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 8590032896 131072 q11Shape4T207=true := by decide

private def q11Shape4T203 : Tree 11 := .split 33 q11Shape4T204 q11Shape4T207
private theorem q11Shape4T203OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 131072 q11Shape4T203=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 (131072 ||| 2^33) q11Shape4T204 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (98304 ||| 2^33) 131072 q11Shape4T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T204OK,q11Shape4T207OK⟩

private def q11Shape4T208 : Tree 11 := (.tip (.cover {0,1,4,8,9,10}))
private theorem q11Shape4T208OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 229376 0 q11Shape4T208=true := by decide

private def q11Shape4T202 : Tree 11 := .split 17 q11Shape4T203 q11Shape4T208
private theorem q11Shape4T202OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 0 q11Shape4T202=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 (0 ||| 2^17) q11Shape4T203 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) (98304 ||| 2^17) 0 q11Shape4T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape4T203OK,q11Shape4T208OK⟩

def q11Shape4P8 : Tree 11 := q11Shape4T202
theorem q11Shape4P8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,2⟩) 98304 0 q11Shape4P8=true := q11Shape4T202OK

end Graffiti384b.EffectiveSearch.Q11
