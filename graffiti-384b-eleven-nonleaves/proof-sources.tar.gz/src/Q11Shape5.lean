import Q11Shape5Part0
import Q11Shape5Part1
import Q11Shape5Part2
import Q11Shape5Part3
import Q11Shape5Part4
import Q11Shape5Part5
import Q11Shape5Part6

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5M98 : Tree 11 := .split 1 q11Shape5P2 q11Shape5P3
private theorem q11Shape5M98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 73400320 q11Shape5M98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 (73400320 ||| 2^1) q11Shape5P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934593 ||| 2^1) 73400320 q11Shape5P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5P2OK,q11Shape5P3OK⟩
private def q11Shape5M99 : Tree 11 := .split 0 q11Shape5P1 q11Shape5M98
private theorem q11Shape5M99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 73400320 q11Shape5M99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 (73400320 ||| 2^0) q11Shape5P1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934592 ||| 2^0) 73400320 q11Shape5M98)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5P1OK,q11Shape5M98OK⟩
private def q11Shape5M100 : Tree 11 := .split 33 q11Shape5P0 q11Shape5M99
private theorem q11Shape5M100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 73400320 q11Shape5M100=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 (73400320 ||| 2^33) q11Shape5P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (0 ||| 2^33) 73400320 q11Shape5M99)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5P0OK,q11Shape5M99OK⟩
private def q11Shape5M120 : Tree 11 := .split 26 q11Shape5M100 q11Shape5P4
private theorem q11Shape5M120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 6291456 q11Shape5M120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 (6291456 ||| 2^26) q11Shape5M100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (0 ||| 2^26) 6291456 q11Shape5P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5M100OK,q11Shape5P4OK⟩
private def q11Shape5M142 : Tree 11 := .split 22 q11Shape5M120 q11Shape5P5
private theorem q11Shape5M142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 2097152 q11Shape5M142=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 (2097152 ||| 2^22) q11Shape5M120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (0 ||| 2^22) 2097152 q11Shape5P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5M120OK,q11Shape5P5OK⟩
private def q11Shape5M166 : Tree 11 := .split 21 q11Shape5M142 q11Shape5P6
private theorem q11Shape5M166OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 0 q11Shape5M166=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 (0 ||| 2^21) q11Shape5M142 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (0 ||| 2^21) 0 q11Shape5P6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5M142OK,q11Shape5P6OK⟩

theorem q11Shape5_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 5) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 5) b) (adj 11 (forms 5) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) adj_mono b H q11Shape5M166 q11Shape5M166OK

#print axioms q11Shape5_cover

end Graffiti384b.EffectiveSearch.Q11
