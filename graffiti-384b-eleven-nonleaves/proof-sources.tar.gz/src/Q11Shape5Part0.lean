import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5T2 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10})))))))))
private theorem q11Shape5T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 8663334915 q11Shape5T2=true := by decide

private def q11Shape5T4 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))))))))
private theorem q11Shape5T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2 8663335169 q11Shape5T4=true := by decide

private def q11Shape5T6 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10})))))
private theorem q11Shape5T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 258 8663339009 q11Shape5T6=true := by decide

private def q11Shape5T8 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4354 8663343105 q11Shape5T8=true := by decide

private def q11Shape5T9 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,3,5,6,7,10}))))) (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,3,5,6,7,10})))) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 12546 8663334913 q11Shape5T9=true := by decide

private def q11Shape5T7 : Tree 11 := .split 13 q11Shape5T8 q11Shape5T9
private theorem q11Shape5T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4354 8663334913 q11Shape5T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4354 (8663334913 ||| 2^13) q11Shape5T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4354 ||| 2^13) 8663334913 q11Shape5T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T8OK,q11Shape5T9OK⟩

private def q11Shape5T5 : Tree 11 := .split 12 q11Shape5T6 q11Shape5T7
private theorem q11Shape5T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 258 8663334913 q11Shape5T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 258 (8663334913 ||| 2^12) q11Shape5T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (258 ||| 2^12) 8663334913 q11Shape5T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T6OK,q11Shape5T7OK⟩

private def q11Shape5T3 : Tree 11 := .split 8 q11Shape5T4 q11Shape5T5
private theorem q11Shape5T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2 8663334913 q11Shape5T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2 (8663334913 ||| 2^8) q11Shape5T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2 ||| 2^8) 8663334913 q11Shape5T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T4OK,q11Shape5T5OK⟩

private def q11Shape5T1 : Tree 11 := .split 1 q11Shape5T2 q11Shape5T3
private theorem q11Shape5T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 8663334913 q11Shape5T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 (8663334913 ||| 2^1) q11Shape5T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (0 ||| 2^1) 8663334913 q11Shape5T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T2OK,q11Shape5T3OK⟩

private def q11Shape5T12 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))))))))
private theorem q11Shape5T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 1 8663335170 q11Shape5T12=true := by decide

private def q11Shape5T14 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,4,5,6,7,10})))))))
private theorem q11Shape5T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 257 8663339010 q11Shape5T14=true := by decide

private def q11Shape5T15 : Tree 11 := (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,4,5,6,7,10})))))) (.tip (.cover {1,3,5,6,7,10})))
private theorem q11Shape5T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4353 8663334914 q11Shape5T15=true := by decide

private def q11Shape5T13 : Tree 11 := .split 12 q11Shape5T14 q11Shape5T15
private theorem q11Shape5T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 257 8663334914 q11Shape5T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 257 (8663334914 ||| 2^12) q11Shape5T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (257 ||| 2^12) 8663334914 q11Shape5T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T14OK,q11Shape5T15OK⟩

private def q11Shape5T11 : Tree 11 := .split 8 q11Shape5T12 q11Shape5T13
private theorem q11Shape5T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 1 8663334914 q11Shape5T11=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 1 (8663334914 ||| 2^8) q11Shape5T12 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (1 ||| 2^8) 8663334914 q11Shape5T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T12OK,q11Shape5T13OK⟩

private def q11Shape5T18 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))))))
private theorem q11Shape5T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 3 8663339264 q11Shape5T18=true := by decide

private def q11Shape5T20 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10}))))))
private theorem q11Shape5T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4099 8663343360 q11Shape5T20=true := by decide

private def q11Shape5T21 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10}))))) (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))) (.tip (.cover {3,4,5,6,7,10}))))
private theorem q11Shape5T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 12291 8663335168 q11Shape5T21=true := by decide

private def q11Shape5T19 : Tree 11 := .split 13 q11Shape5T20 q11Shape5T21
private theorem q11Shape5T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4099 8663335168 q11Shape5T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4099 (8663335168 ||| 2^13) q11Shape5T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4099 ||| 2^13) 8663335168 q11Shape5T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T20OK,q11Shape5T21OK⟩

private def q11Shape5T17 : Tree 11 := .split 12 q11Shape5T18 q11Shape5T19
private theorem q11Shape5T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 3 8663335168 q11Shape5T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 3 (8663335168 ||| 2^12) q11Shape5T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (3 ||| 2^12) 8663335168 q11Shape5T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T18OK,q11Shape5T19OK⟩

private def q11Shape5T24 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 259 8663347200 q11Shape5T24=true := by decide

private def q11Shape5T25 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10}))))) (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8451 8663339008 q11Shape5T25=true := by decide

private def q11Shape5T23 : Tree 11 := .split 13 q11Shape5T24 q11Shape5T25
private theorem q11Shape5T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 259 8663339008 q11Shape5T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 259 (8663339008 ||| 2^13) q11Shape5T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (259 ||| 2^13) 8663339008 q11Shape5T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T24OK,q11Shape5T25OK⟩

private def q11Shape5T26 : Tree 11 := (.split 13 (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10}))))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10}))) (.tip (.cover {1,4,5,6,7,10})))) (.tip (.cover {1,3,5,6,7,10})))
private theorem q11Shape5T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4355 8663334912 q11Shape5T26=true := by decide

private def q11Shape5T22 : Tree 11 := .split 12 q11Shape5T23 q11Shape5T26
private theorem q11Shape5T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 259 8663334912 q11Shape5T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 259 (8663334912 ||| 2^12) q11Shape5T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (259 ||| 2^12) 8663334912 q11Shape5T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T23OK,q11Shape5T26OK⟩

private def q11Shape5T16 : Tree 11 := .split 8 q11Shape5T17 q11Shape5T22
private theorem q11Shape5T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 3 8663334912 q11Shape5T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 3 (8663334912 ||| 2^8) q11Shape5T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (3 ||| 2^8) 8663334912 q11Shape5T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T17OK,q11Shape5T22OK⟩

private def q11Shape5T10 : Tree 11 := .split 1 q11Shape5T11 q11Shape5T16
private theorem q11Shape5T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 1 8663334912 q11Shape5T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 1 (8663334912 ||| 2^1) q11Shape5T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (1 ||| 2^1) 8663334912 q11Shape5T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T11OK,q11Shape5T16OK⟩

private def q11Shape5T0 : Tree 11 := .split 0 q11Shape5T1 q11Shape5T10
private theorem q11Shape5T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 8663334912 q11Shape5T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 (8663334912 ||| 2^0) q11Shape5T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (0 ||| 2^0) 8663334912 q11Shape5T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T1OK,q11Shape5T10OK⟩

def q11Shape5P0 : Tree 11 := q11Shape5T0
theorem q11Shape5P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 0 8663334912 q11Shape5P0=true := q11Shape5T0OK

end Graffiti384b.EffectiveSearch.Q11
