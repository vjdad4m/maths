import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5T29 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))))))
private theorem q11Shape5T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 73400579 q11Shape5T29=true := by decide

private def q11Shape5T31 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))))
private theorem q11Shape5T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934848 73404419 q11Shape5T31=true := by decide

private def q11Shape5T33 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))))
private theorem q11Shape5T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938944 73408515 q11Shape5T33=true := by decide

private def q11Shape5T35 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))
private theorem q11Shape5T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947136 73662467 q11Shape5T35=true := by decide

private def q11Shape5T36 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,5,6,7,8,10}))))
private theorem q11Shape5T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590209280 73400323 q11Shape5T36=true := by decide

private def q11Shape5T34 : Tree 11 := .split 18 q11Shape5T35 q11Shape5T36
private theorem q11Shape5T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947136 73400323 q11Shape5T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947136 (73400323 ||| 2^18) q11Shape5T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589947136 ||| 2^18) 73400323 q11Shape5T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T35OK,q11Shape5T36OK⟩

private def q11Shape5T32 : Tree 11 := .split 13 q11Shape5T33 q11Shape5T34
private theorem q11Shape5T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938944 73400323 q11Shape5T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938944 (73400323 ||| 2^13) q11Shape5T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938944 ||| 2^13) 73400323 q11Shape5T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T33OK,q11Shape5T34OK⟩

private def q11Shape5T30 : Tree 11 := .split 12 q11Shape5T31 q11Shape5T32
private theorem q11Shape5T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934848 73400323 q11Shape5T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934848 (73400323 ||| 2^12) q11Shape5T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934848 ||| 2^12) 73400323 q11Shape5T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T31OK,q11Shape5T32OK⟩

private def q11Shape5T28 : Tree 11 := .split 8 q11Shape5T29 q11Shape5T30
private theorem q11Shape5T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 73400323 q11Shape5T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 (73400323 ||| 2^8) q11Shape5T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934592 ||| 2^8) 73400323 q11Shape5T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T29OK,q11Shape5T30OK⟩

private def q11Shape5T39 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))))
private theorem q11Shape5T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934594 73404673 q11Shape5T39=true := by decide

private def q11Shape5T41 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))))
private theorem q11Shape5T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938690 73408769 q11Shape5T41=true := by decide

private def q11Shape5T43 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))
private theorem q11Shape5T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946882 73662721 q11Shape5T43=true := by decide

private def q11Shape5T44 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,5,6,7,8,10}))))
private theorem q11Shape5T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590209026 73400577 q11Shape5T44=true := by decide

private def q11Shape5T42 : Tree 11 := .split 18 q11Shape5T43 q11Shape5T44
private theorem q11Shape5T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946882 73400577 q11Shape5T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946882 (73400577 ||| 2^18) q11Shape5T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589946882 ||| 2^18) 73400577 q11Shape5T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T43OK,q11Shape5T44OK⟩

private def q11Shape5T40 : Tree 11 := .split 13 q11Shape5T41 q11Shape5T42
private theorem q11Shape5T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938690 73400577 q11Shape5T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938690 (73400577 ||| 2^13) q11Shape5T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938690 ||| 2^13) 73400577 q11Shape5T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T41OK,q11Shape5T42OK⟩

private def q11Shape5T38 : Tree 11 := .split 12 q11Shape5T39 q11Shape5T40
private theorem q11Shape5T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934594 73400577 q11Shape5T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934594 (73400577 ||| 2^12) q11Shape5T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934594 ||| 2^12) 73400577 q11Shape5T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T39OK,q11Shape5T40OK⟩

private def q11Shape5T47 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934850 73412609 q11Shape5T47=true := by decide

private def q11Shape5T48 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))))) (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {4,5,6,7,9,10})))) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589943042 73404417 q11Shape5T48=true := by decide

private def q11Shape5T46 : Tree 11 := .split 13 q11Shape5T47 q11Shape5T48
private theorem q11Shape5T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934850 73404417 q11Shape5T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934850 (73404417 ||| 2^13) q11Shape5T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934850 ||| 2^13) 73404417 q11Shape5T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T47OK,q11Shape5T48OK⟩

private def q11Shape5T50 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {4,5,6,7,8,10})))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938946 73408513 q11Shape5T50=true := by decide

private def q11Shape5T52 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,3,5,6,7,10})))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {4,5,6,7,8,10}))))
private theorem q11Shape5T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947138 73662465 q11Shape5T52=true := by decide

private def q11Shape5T53 : Tree 11 := (.split 19 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {4,5,6,7,9,10}))) (.tip (.cover {1,5,6,7,8,10}))) (.tip (.cover {1,4,5,6,7,10})))
private theorem q11Shape5T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590209282 73400321 q11Shape5T53=true := by decide

private def q11Shape5T51 : Tree 11 := .split 18 q11Shape5T52 q11Shape5T53
private theorem q11Shape5T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947138 73400321 q11Shape5T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947138 (73400321 ||| 2^18) q11Shape5T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589947138 ||| 2^18) 73400321 q11Shape5T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T52OK,q11Shape5T53OK⟩

private def q11Shape5T49 : Tree 11 := .split 13 q11Shape5T50 q11Shape5T51
private theorem q11Shape5T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938946 73400321 q11Shape5T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938946 (73400321 ||| 2^13) q11Shape5T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938946 ||| 2^13) 73400321 q11Shape5T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T50OK,q11Shape5T51OK⟩

private def q11Shape5T45 : Tree 11 := .split 12 q11Shape5T46 q11Shape5T49
private theorem q11Shape5T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934850 73400321 q11Shape5T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934850 (73400321 ||| 2^12) q11Shape5T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934850 ||| 2^12) 73400321 q11Shape5T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T46OK,q11Shape5T49OK⟩

private def q11Shape5T37 : Tree 11 := .split 8 q11Shape5T38 q11Shape5T45
private theorem q11Shape5T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934594 73400321 q11Shape5T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934594 (73400321 ||| 2^8) q11Shape5T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934594 ||| 2^8) 73400321 q11Shape5T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T38OK,q11Shape5T45OK⟩

private def q11Shape5T27 : Tree 11 := .split 1 q11Shape5T28 q11Shape5T37
private theorem q11Shape5T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 73400321 q11Shape5T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 (73400321 ||| 2^1) q11Shape5T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934592 ||| 2^1) 73400321 q11Shape5T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T28OK,q11Shape5T37OK⟩

def q11Shape5P1 : Tree 11 := q11Shape5T27
theorem q11Shape5P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934592 73400321 q11Shape5P1=true := q11Shape5T27OK

end Graffiti384b.EffectiveSearch.Q11
