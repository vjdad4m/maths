import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5T56 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))))
private theorem q11Shape5T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 73404674 q11Shape5T56=true := by decide

private def q11Shape5T58 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10})))))
private theorem q11Shape5T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938689 73408770 q11Shape5T58=true := by decide

private def q11Shape5T60 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))
private theorem q11Shape5T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946881 73662722 q11Shape5T60=true := by decide

private def q11Shape5T61 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,5,6,7,8,10}))))
private theorem q11Shape5T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590209025 73400578 q11Shape5T61=true := by decide

private def q11Shape5T59 : Tree 11 := .split 18 q11Shape5T60 q11Shape5T61
private theorem q11Shape5T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946881 73400578 q11Shape5T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946881 (73400578 ||| 2^18) q11Shape5T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589946881 ||| 2^18) 73400578 q11Shape5T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T60OK,q11Shape5T61OK⟩

private def q11Shape5T57 : Tree 11 := .split 13 q11Shape5T58 q11Shape5T59
private theorem q11Shape5T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938689 73400578 q11Shape5T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938689 (73400578 ||| 2^13) q11Shape5T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938689 ||| 2^13) 73400578 q11Shape5T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T58OK,q11Shape5T59OK⟩

private def q11Shape5T55 : Tree 11 := .split 12 q11Shape5T56 q11Shape5T57
private theorem q11Shape5T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 73400578 q11Shape5T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 (73400578 ||| 2^12) q11Shape5T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934593 ||| 2^12) 73400578 q11Shape5T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T56OK,q11Shape5T57OK⟩

private def q11Shape5T64 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {2,4,5,6,7,10}))))))
private theorem q11Shape5T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934849 73412610 q11Shape5T64=true := by decide

private def q11Shape5T66 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))
private theorem q11Shape5T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589943041 73666562 q11Shape5T66=true := by decide

private def q11Shape5T67 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {3,5,6,7,8,10}))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {3,5,6,7,8,10}))))
private theorem q11Shape5T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590205185 73404418 q11Shape5T67=true := by decide

private def q11Shape5T65 : Tree 11 := .split 18 q11Shape5T66 q11Shape5T67
private theorem q11Shape5T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589943041 73404418 q11Shape5T65=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589943041 (73404418 ||| 2^18) q11Shape5T66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589943041 ||| 2^18) 73404418 q11Shape5T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T66OK,q11Shape5T67OK⟩

private def q11Shape5T63 : Tree 11 := .split 13 q11Shape5T64 q11Shape5T65
private theorem q11Shape5T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934849 73404418 q11Shape5T63=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934849 (73404418 ||| 2^13) q11Shape5T64 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934849 ||| 2^13) 73404418 q11Shape5T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T64OK,q11Shape5T65OK⟩

private def q11Shape5T70 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {3,5,6,7,9,10})))))
private theorem q11Shape5T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938945 73670658 q11Shape5T70=true := by decide

private def q11Shape5T71 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {1,5,6,7,8,10}))))
private theorem q11Shape5T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590201089 73408514 q11Shape5T71=true := by decide

private def q11Shape5T69 : Tree 11 := .split 18 q11Shape5T70 q11Shape5T71
private theorem q11Shape5T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938945 73408514 q11Shape5T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938945 (73408514 ||| 2^18) q11Shape5T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938945 ||| 2^18) 73408514 q11Shape5T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T70OK,q11Shape5T71OK⟩

private def q11Shape5T72 : Tree 11 := (.tip (.cover {1,3,5,6,7,10}))
private theorem q11Shape5T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947137 73400322 q11Shape5T72=true := by decide

private def q11Shape5T68 : Tree 11 := .split 13 q11Shape5T69 q11Shape5T72
private theorem q11Shape5T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938945 73400322 q11Shape5T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938945 (73400322 ||| 2^13) q11Shape5T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938945 ||| 2^13) 73400322 q11Shape5T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T69OK,q11Shape5T72OK⟩

private def q11Shape5T62 : Tree 11 := .split 12 q11Shape5T63 q11Shape5T68
private theorem q11Shape5T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934849 73400322 q11Shape5T62=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934849 (73400322 ||| 2^12) q11Shape5T63 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934849 ||| 2^12) 73400322 q11Shape5T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T63OK,q11Shape5T68OK⟩

private def q11Shape5T54 : Tree 11 := .split 8 q11Shape5T55 q11Shape5T62
private theorem q11Shape5T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 73400322 q11Shape5T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 (73400322 ||| 2^8) q11Shape5T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934593 ||| 2^8) 73400322 q11Shape5T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T55OK,q11Shape5T62OK⟩

def q11Shape5P2 : Tree 11 := q11Shape5T54
theorem q11Shape5P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934593 73400322 q11Shape5P2=true := q11Shape5T54OK

end Graffiti384b.EffectiveSearch.Q11
