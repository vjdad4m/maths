import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5T76 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10}))))))
private theorem q11Shape5T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 73412864 q11Shape5T76=true := by decide

private def q11Shape5T78 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10}))))
private theorem q11Shape5T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589942787 73666816 q11Shape5T78=true := by decide

private def q11Shape5T79 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {2,5,6,7,9,10}))))
private theorem q11Shape5T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590204931 73404672 q11Shape5T79=true := by decide

private def q11Shape5T77 : Tree 11 := .split 18 q11Shape5T78 q11Shape5T79
private theorem q11Shape5T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589942787 73404672 q11Shape5T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589942787 (73404672 ||| 2^18) q11Shape5T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589942787 ||| 2^18) 73404672 q11Shape5T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T78OK,q11Shape5T79OK⟩

private def q11Shape5T75 : Tree 11 := .split 13 q11Shape5T76 q11Shape5T77
private theorem q11Shape5T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 73404672 q11Shape5T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 (73404672 ||| 2^13) q11Shape5T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934595 ||| 2^13) 73404672 q11Shape5T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T76OK,q11Shape5T77OK⟩

private def q11Shape5T82 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))))
private theorem q11Shape5T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938691 73670912 q11Shape5T82=true := by decide

private def q11Shape5T83 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {1,5,6,7,8,10}))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10}))) (.tip (.cover {1,5,6,7,8,10}))))
private theorem q11Shape5T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590200835 73408768 q11Shape5T83=true := by decide

private def q11Shape5T81 : Tree 11 := .split 18 q11Shape5T82 q11Shape5T83
private theorem q11Shape5T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938691 73408768 q11Shape5T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938691 (73408768 ||| 2^18) q11Shape5T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938691 ||| 2^18) 73408768 q11Shape5T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T82OK,q11Shape5T83OK⟩

private def q11Shape5T85 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {2,5,6,7,9,10}))))
private theorem q11Shape5T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946883 73662720 q11Shape5T85=true := by decide

private def q11Shape5T86 : Tree 11 := (.split 19 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10}))) (.tip (.cover {1,5,6,7,8,10}))) (.tip (.cover {3,4,5,6,7,10})))
private theorem q11Shape5T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590209027 73400576 q11Shape5T86=true := by decide

private def q11Shape5T84 : Tree 11 := .split 18 q11Shape5T85 q11Shape5T86
private theorem q11Shape5T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946883 73400576 q11Shape5T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589946883 (73400576 ||| 2^18) q11Shape5T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589946883 ||| 2^18) 73400576 q11Shape5T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T85OK,q11Shape5T86OK⟩

private def q11Shape5T80 : Tree 11 := .split 13 q11Shape5T81 q11Shape5T84
private theorem q11Shape5T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938691 73400576 q11Shape5T80=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938691 (73400576 ||| 2^13) q11Shape5T81 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938691 ||| 2^13) 73400576 q11Shape5T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T81OK,q11Shape5T84OK⟩

private def q11Shape5T74 : Tree 11 := .split 12 q11Shape5T75 q11Shape5T80
private theorem q11Shape5T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 73400576 q11Shape5T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 (73400576 ||| 2^12) q11Shape5T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934595 ||| 2^12) 73400576 q11Shape5T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T75OK,q11Shape5T80OK⟩

private def q11Shape5T89 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10}))))) (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))) (.tip (.cover {1,4,5,6,7,10}))))
private theorem q11Shape5T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934851 73412608 q11Shape5T89=true := by decide

private def q11Shape5T91 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.unordered {2,3,4,9} 1))) (.tip (.cover {2,5,6,7,9,10}))))
private theorem q11Shape5T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589943043 73666560 q11Shape5T91=true := by decide

private def q11Shape5T92 : Tree 11 := (.split 19 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {4,5,6,7,9,10}))) (.tip (.cover {3,5,6,7,8,10}))) (.tip (.cover {1,4,5,6,7,10})))
private theorem q11Shape5T92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590205187 73404416 q11Shape5T92=true := by decide

private def q11Shape5T90 : Tree 11 := .split 18 q11Shape5T91 q11Shape5T92
private theorem q11Shape5T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589943043 73404416 q11Shape5T90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589943043 (73404416 ||| 2^18) q11Shape5T91 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589943043 ||| 2^18) 73404416 q11Shape5T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T91OK,q11Shape5T92OK⟩

private def q11Shape5T88 : Tree 11 := .split 13 q11Shape5T89 q11Shape5T90
private theorem q11Shape5T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934851 73404416 q11Shape5T88=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934851 (73404416 ||| 2^13) q11Shape5T89 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934851 ||| 2^13) 73404416 q11Shape5T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T89OK,q11Shape5T90OK⟩

private def q11Shape5T95 : Tree 11 := (.split 19 (.split 5 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {1,2,5,6,7,10})))) (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {4,5,6,7,8,10}))))
private theorem q11Shape5T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938947 73670656 q11Shape5T95=true := by decide

private def q11Shape5T96 : Tree 11 := (.split 19 (.split 5 (.split 6 (.tip (.small 1)) (.tip (.cover {2,5,6,7,8,10}))) (.tip (.cover {1,5,6,7,8,10}))) (.tip (.cover {1,4,5,6,7,10})))
private theorem q11Shape5T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8590201091 73408512 q11Shape5T96=true := by decide

private def q11Shape5T94 : Tree 11 := .split 18 q11Shape5T95 q11Shape5T96
private theorem q11Shape5T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938947 73408512 q11Shape5T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938947 (73408512 ||| 2^18) q11Shape5T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938947 ||| 2^18) 73408512 q11Shape5T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T95OK,q11Shape5T96OK⟩

private def q11Shape5T97 : Tree 11 := (.tip (.cover {1,3,5,6,7,10}))
private theorem q11Shape5T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589947139 73400320 q11Shape5T97=true := by decide

private def q11Shape5T93 : Tree 11 := .split 13 q11Shape5T94 q11Shape5T97
private theorem q11Shape5T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938947 73400320 q11Shape5T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589938947 (73400320 ||| 2^13) q11Shape5T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589938947 ||| 2^13) 73400320 q11Shape5T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T94OK,q11Shape5T97OK⟩

private def q11Shape5T87 : Tree 11 := .split 12 q11Shape5T88 q11Shape5T93
private theorem q11Shape5T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934851 73400320 q11Shape5T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934851 (73400320 ||| 2^12) q11Shape5T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934851 ||| 2^12) 73400320 q11Shape5T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T88OK,q11Shape5T93OK⟩

private def q11Shape5T73 : Tree 11 := .split 8 q11Shape5T74 q11Shape5T87
private theorem q11Shape5T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 73400320 q11Shape5T73=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 (73400320 ||| 2^8) q11Shape5T74 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (8589934595 ||| 2^8) 73400320 q11Shape5T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T74OK,q11Shape5T87OK⟩

def q11Shape5P3 : Tree 11 := q11Shape5T73
theorem q11Shape5P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8589934595 73400320 q11Shape5P3=true := q11Shape5T73OK

end Graffiti384b.EffectiveSearch.Q11
