import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5T104 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10})))))
private theorem q11Shape5T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 8596226051 q11Shape5T104=true := by decide

private def q11Shape5T106 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108866 8596226305 q11Shape5T106=true := by decide

private def q11Shape5T107 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67109122 8596226049 q11Shape5T107=true := by decide

private def q11Shape5T105 : Tree 11 := .split 8 q11Shape5T106 q11Shape5T107
private theorem q11Shape5T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108866 8596226049 q11Shape5T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108866 (8596226049 ||| 2^8) q11Shape5T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67108866 ||| 2^8) 8596226049 q11Shape5T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T106OK,q11Shape5T107OK⟩

private def q11Shape5T103 : Tree 11 := .split 1 q11Shape5T104 q11Shape5T105
private theorem q11Shape5T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 8596226049 q11Shape5T103=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 (8596226049 ||| 2^1) q11Shape5T104 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67108864 ||| 2^1) 8596226049 q11Shape5T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T104OK,q11Shape5T105OK⟩

private def q11Shape5T110 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108865 8596226306 q11Shape5T110=true := by decide

private def q11Shape5T111 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67109121 8596226050 q11Shape5T111=true := by decide

private def q11Shape5T109 : Tree 11 := .split 8 q11Shape5T110 q11Shape5T111
private theorem q11Shape5T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108865 8596226050 q11Shape5T109=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108865 (8596226050 ||| 2^8) q11Shape5T110 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67108865 ||| 2^8) 8596226050 q11Shape5T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T110OK,q11Shape5T111OK⟩

private def q11Shape5T113 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108867 8596226304 q11Shape5T113=true := by decide

private def q11Shape5T116 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))
private theorem q11Shape5T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67109123 8596238336 q11Shape5T116=true := by decide

private def q11Shape5T117 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,10}))))
private theorem q11Shape5T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67117315 8596230144 q11Shape5T117=true := by decide

private def q11Shape5T115 : Tree 11 := .split 13 q11Shape5T116 q11Shape5T117
private theorem q11Shape5T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67109123 8596230144 q11Shape5T115=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67109123 (8596230144 ||| 2^13) q11Shape5T116 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67109123 ||| 2^13) 8596230144 q11Shape5T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T116OK,q11Shape5T117OK⟩

private def q11Shape5T118 : Tree 11 := (.split 13 (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10})))
private theorem q11Shape5T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67113219 8596226048 q11Shape5T118=true := by decide

private def q11Shape5T114 : Tree 11 := .split 12 q11Shape5T115 q11Shape5T118
private theorem q11Shape5T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67109123 8596226048 q11Shape5T114=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67109123 (8596226048 ||| 2^12) q11Shape5T115 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67109123 ||| 2^12) 8596226048 q11Shape5T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T115OK,q11Shape5T118OK⟩

private def q11Shape5T112 : Tree 11 := .split 8 q11Shape5T113 q11Shape5T114
private theorem q11Shape5T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108867 8596226048 q11Shape5T112=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108867 (8596226048 ||| 2^8) q11Shape5T113 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67108867 ||| 2^8) 8596226048 q11Shape5T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T113OK,q11Shape5T114OK⟩

private def q11Shape5T108 : Tree 11 := .split 1 q11Shape5T109 q11Shape5T112
private theorem q11Shape5T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108865 8596226048 q11Shape5T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108865 (8596226048 ||| 2^1) q11Shape5T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67108865 ||| 2^1) 8596226048 q11Shape5T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T109OK,q11Shape5T112OK⟩

private def q11Shape5T102 : Tree 11 := .split 0 q11Shape5T103 q11Shape5T108
private theorem q11Shape5T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 8596226048 q11Shape5T102=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 (8596226048 ||| 2^0) q11Shape5T103 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67108864 ||| 2^0) 8596226048 q11Shape5T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T103OK,q11Shape5T108OK⟩

private def q11Shape5T119 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape5T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8657043456 6291456 q11Shape5T119=true := by decide

private def q11Shape5T101 : Tree 11 := .split 33 q11Shape5T102 q11Shape5T119
private theorem q11Shape5T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 6291456 q11Shape5T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 (6291456 ||| 2^33) q11Shape5T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (67108864 ||| 2^33) 6291456 q11Shape5T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T102OK,q11Shape5T119OK⟩

def q11Shape5P4 : Tree 11 := q11Shape5T101
theorem q11Shape5P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 67108864 6291456 q11Shape5P4=true := q11Shape5T101OK

end Graffiti384b.EffectiveSearch.Q11
