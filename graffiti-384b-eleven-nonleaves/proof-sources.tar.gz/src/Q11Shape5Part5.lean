import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5T125 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10})))))
private theorem q11Shape5T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 8659140611 q11Shape5T125=true := by decide

private def q11Shape5T127 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194306 8659140865 q11Shape5T127=true := by decide

private def q11Shape5T128 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194562 8659140609 q11Shape5T128=true := by decide

private def q11Shape5T126 : Tree 11 := .split 8 q11Shape5T127 q11Shape5T128
private theorem q11Shape5T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194306 8659140609 q11Shape5T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194306 (8659140609 ||| 2^8) q11Shape5T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194306 ||| 2^8) 8659140609 q11Shape5T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T127OK,q11Shape5T128OK⟩

private def q11Shape5T124 : Tree 11 := .split 1 q11Shape5T125 q11Shape5T126
private theorem q11Shape5T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 8659140609 q11Shape5T124=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 (8659140609 ||| 2^1) q11Shape5T125 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194304 ||| 2^1) 8659140609 q11Shape5T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T125OK,q11Shape5T126OK⟩

private def q11Shape5T131 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194305 8659140866 q11Shape5T131=true := by decide

private def q11Shape5T132 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194561 8659140610 q11Shape5T132=true := by decide

private def q11Shape5T130 : Tree 11 := .split 8 q11Shape5T131 q11Shape5T132
private theorem q11Shape5T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194305 8659140610 q11Shape5T130=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194305 (8659140610 ||| 2^8) q11Shape5T131 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194305 ||| 2^8) 8659140610 q11Shape5T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T131OK,q11Shape5T132OK⟩

private def q11Shape5T134 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10}))))
private theorem q11Shape5T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194307 8659140864 q11Shape5T134=true := by decide

private def q11Shape5T137 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,10}))))
private theorem q11Shape5T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194563 8659152896 q11Shape5T137=true := by decide

private def q11Shape5T138 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,10}))))
private theorem q11Shape5T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4202755 8659144704 q11Shape5T138=true := by decide

private def q11Shape5T136 : Tree 11 := .split 13 q11Shape5T137 q11Shape5T138
private theorem q11Shape5T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194563 8659144704 q11Shape5T136=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194563 (8659144704 ||| 2^13) q11Shape5T137 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194563 ||| 2^13) 8659144704 q11Shape5T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T137OK,q11Shape5T138OK⟩

private def q11Shape5T139 : Tree 11 := (.split 13 (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,10})))) (.tip (.cover {0,1,3,5,6,10})))
private theorem q11Shape5T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4198659 8659140608 q11Shape5T139=true := by decide

private def q11Shape5T135 : Tree 11 := .split 12 q11Shape5T136 q11Shape5T139
private theorem q11Shape5T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194563 8659140608 q11Shape5T135=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194563 (8659140608 ||| 2^12) q11Shape5T136 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194563 ||| 2^12) 8659140608 q11Shape5T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T136OK,q11Shape5T139OK⟩

private def q11Shape5T133 : Tree 11 := .split 8 q11Shape5T134 q11Shape5T135
private theorem q11Shape5T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194307 8659140608 q11Shape5T133=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194307 (8659140608 ||| 2^8) q11Shape5T134 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194307 ||| 2^8) 8659140608 q11Shape5T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T134OK,q11Shape5T135OK⟩

private def q11Shape5T129 : Tree 11 := .split 1 q11Shape5T130 q11Shape5T133
private theorem q11Shape5T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194305 8659140608 q11Shape5T129=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194305 (8659140608 ||| 2^1) q11Shape5T130 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194305 ||| 2^1) 8659140608 q11Shape5T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T130OK,q11Shape5T133OK⟩

private def q11Shape5T123 : Tree 11 := .split 0 q11Shape5T124 q11Shape5T129
private theorem q11Shape5T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 8659140608 q11Shape5T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 (8659140608 ||| 2^0) q11Shape5T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194304 ||| 2^0) 8659140608 q11Shape5T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T124OK,q11Shape5T129OK⟩

private def q11Shape5T140 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape5T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8594128896 69206016 q11Shape5T140=true := by decide

private def q11Shape5T122 : Tree 11 := .split 33 q11Shape5T123 q11Shape5T140
private theorem q11Shape5T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 69206016 q11Shape5T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 (69206016 ||| 2^33) q11Shape5T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194304 ||| 2^33) 69206016 q11Shape5T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T123OK,q11Shape5T140OK⟩

private def q11Shape5T141 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape5T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 71303168 2097152 q11Shape5T141=true := by decide

private def q11Shape5T121 : Tree 11 := .split 26 q11Shape5T122 q11Shape5T141
private theorem q11Shape5T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 2097152 q11Shape5T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 (2097152 ||| 2^26) q11Shape5T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (4194304 ||| 2^26) 2097152 q11Shape5T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T122OK,q11Shape5T141OK⟩

def q11Shape5P5 : Tree 11 := q11Shape5T121
theorem q11Shape5P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 4194304 2097152 q11Shape5P5=true := q11Shape5T121OK

end Graffiti384b.EffectiveSearch.Q11
