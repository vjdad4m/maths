import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape5T148 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10})))))
private theorem q11Shape5T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 8661237763 q11Shape5T148=true := by decide

private def q11Shape5T150 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10}))))
private theorem q11Shape5T150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097154 8661238017 q11Shape5T150=true := by decide

private def q11Shape5T151 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10})))) (.tip (.cover {0,1,3,5,7,10}))))
private theorem q11Shape5T151OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097410 8661237761 q11Shape5T151=true := by decide

private def q11Shape5T149 : Tree 11 := .split 8 q11Shape5T150 q11Shape5T151
private theorem q11Shape5T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097154 8661237761 q11Shape5T149=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097154 (8661237761 ||| 2^8) q11Shape5T150 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097154 ||| 2^8) 8661237761 q11Shape5T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T150OK,q11Shape5T151OK⟩

private def q11Shape5T147 : Tree 11 := .split 1 q11Shape5T148 q11Shape5T149
private theorem q11Shape5T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 8661237761 q11Shape5T147=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 (8661237761 ||| 2^1) q11Shape5T148 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097152 ||| 2^1) 8661237761 q11Shape5T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T148OK,q11Shape5T149OK⟩

private def q11Shape5T154 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,10}))))
private theorem q11Shape5T154OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097153 8661238018 q11Shape5T154=true := by decide

private def q11Shape5T155 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10})))) (.tip (.cover {0,1,3,5,7,10}))))
private theorem q11Shape5T155OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097409 8661237762 q11Shape5T155=true := by decide

private def q11Shape5T153 : Tree 11 := .split 8 q11Shape5T154 q11Shape5T155
private theorem q11Shape5T153OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097153 8661237762 q11Shape5T153=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097153 (8661237762 ||| 2^8) q11Shape5T154 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097153 ||| 2^8) 8661237762 q11Shape5T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T154OK,q11Shape5T155OK⟩

private def q11Shape5T157 : Tree 11 := (.split 12 (.split 13 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10}))))) (.split 13 (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10})))) (.tip (.cover {0,1,3,5,7,10}))))
private theorem q11Shape5T157OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097155 8661238016 q11Shape5T157=true := by decide

private def q11Shape5T160 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,10}))))
private theorem q11Shape5T160OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097411 8661250048 q11Shape5T160=true := by decide

private def q11Shape5T161 : Tree 11 := (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10})))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,10}))))
private theorem q11Shape5T161OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2105603 8661241856 q11Shape5T161=true := by decide

private def q11Shape5T159 : Tree 11 := .split 13 q11Shape5T160 q11Shape5T161
private theorem q11Shape5T159OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097411 8661241856 q11Shape5T159=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097411 (8661241856 ||| 2^13) q11Shape5T160 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097411 ||| 2^13) 8661241856 q11Shape5T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T160OK,q11Shape5T161OK⟩

private def q11Shape5T162 : Tree 11 := (.split 13 (.split 18 (.split 19 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10})))) (.split 19 (.split 5 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,10})))) (.tip (.cover {0,1,3,5,7,10})))
private theorem q11Shape5T162OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2101507 8661237760 q11Shape5T162=true := by decide

private def q11Shape5T158 : Tree 11 := .split 12 q11Shape5T159 q11Shape5T162
private theorem q11Shape5T158OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097411 8661237760 q11Shape5T158=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097411 (8661237760 ||| 2^12) q11Shape5T159 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097411 ||| 2^12) 8661237760 q11Shape5T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T159OK,q11Shape5T162OK⟩

private def q11Shape5T156 : Tree 11 := .split 8 q11Shape5T157 q11Shape5T158
private theorem q11Shape5T156OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097155 8661237760 q11Shape5T156=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097155 (8661237760 ||| 2^8) q11Shape5T157 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097155 ||| 2^8) 8661237760 q11Shape5T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T157OK,q11Shape5T158OK⟩

private def q11Shape5T152 : Tree 11 := .split 1 q11Shape5T153 q11Shape5T156
private theorem q11Shape5T152OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097153 8661237760 q11Shape5T152=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097153 (8661237760 ||| 2^1) q11Shape5T153 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097153 ||| 2^1) 8661237760 q11Shape5T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T153OK,q11Shape5T156OK⟩

private def q11Shape5T146 : Tree 11 := .split 0 q11Shape5T147 q11Shape5T152
private theorem q11Shape5T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 8661237760 q11Shape5T146=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 (8661237760 ||| 2^0) q11Shape5T147 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097152 ||| 2^0) 8661237760 q11Shape5T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T147OK,q11Shape5T152OK⟩

private def q11Shape5T163 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape5T163OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 8592031744 71303168 q11Shape5T163=true := by decide

private def q11Shape5T145 : Tree 11 := .split 33 q11Shape5T146 q11Shape5T163
private theorem q11Shape5T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 71303168 q11Shape5T145=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 (71303168 ||| 2^33) q11Shape5T146 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097152 ||| 2^33) 71303168 q11Shape5T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T146OK,q11Shape5T163OK⟩

private def q11Shape5T164 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape5T164OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 69206016 4194304 q11Shape5T164=true := by decide

private def q11Shape5T144 : Tree 11 := .split 26 q11Shape5T145 q11Shape5T164
private theorem q11Shape5T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 4194304 q11Shape5T144=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 (4194304 ||| 2^26) q11Shape5T145 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097152 ||| 2^26) 4194304 q11Shape5T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T145OK,q11Shape5T164OK⟩

private def q11Shape5T165 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape5T165OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 6291456 0 q11Shape5T165=true := by decide

private def q11Shape5T143 : Tree 11 := .split 22 q11Shape5T144 q11Shape5T165
private theorem q11Shape5T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 0 q11Shape5T143=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 (0 ||| 2^22) q11Shape5T144 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) (2097152 ||| 2^22) 0 q11Shape5T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape5T144OK,q11Shape5T165OK⟩

def q11Shape5P6 : Tree 11 := q11Shape5T143
theorem q11Shape5P6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,3⟩) 2097152 0 q11Shape5P6=true := q11Shape5T143OK

end Graffiti384b.EffectiveSearch.Q11
