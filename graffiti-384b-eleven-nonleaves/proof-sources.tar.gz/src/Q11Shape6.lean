import Q11Shape6Part0
import Q11Shape6Part1
import Q11Shape6Part2
import Q11Shape6Part3
import Q11Shape6Part4

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape6M32 : Tree 11 := .split 1 q11Shape6P0 q11Shape6P1
private theorem q11Shape6M32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 67108865 q11Shape6M32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 (67108865 ||| 2^1) q11Shape6P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (0 ||| 2^1) 67108865 q11Shape6P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6P0OK,q11Shape6P1OK⟩
private def q11Shape6M90 : Tree 11 := .split 2 q11Shape6P3 q11Shape6P4
private theorem q11Shape6M90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 67108864 q11Shape6M90=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 (67108864 ||| 2^2) q11Shape6P3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (3 ||| 2^2) 67108864 q11Shape6P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6P3OK,q11Shape6P4OK⟩
private def q11Shape6M91 : Tree 11 := .split 1 q11Shape6P2 q11Shape6M90
private theorem q11Shape6M91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 67108864 q11Shape6M91=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 (67108864 ||| 2^1) q11Shape6P2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (1 ||| 2^1) 67108864 q11Shape6M90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6P2OK,q11Shape6M90OK⟩
private def q11Shape6M92 : Tree 11 := .split 0 q11Shape6M32 q11Shape6M91
private theorem q11Shape6M92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 67108864 q11Shape6M92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 (67108864 ||| 2^0) q11Shape6M32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (0 ||| 2^0) 67108864 q11Shape6M91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6M32OK,q11Shape6M91OK⟩
private def q11Shape6M94 : Tree 11 := .split 26 q11Shape6M92 q11Shape6P5
private theorem q11Shape6M94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 0 q11Shape6M94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 (0 ||| 2^26) q11Shape6M92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (0 ||| 2^26) 0 q11Shape6P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6M92OK,q11Shape6P5OK⟩

theorem q11Shape6_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 6) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 6) b) (adj 11 (forms 6) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) adj_mono b H q11Shape6M94 q11Shape6M94OK

#print axioms q11Shape6_cover

end Graffiti384b.EffectiveSearch.Q11
