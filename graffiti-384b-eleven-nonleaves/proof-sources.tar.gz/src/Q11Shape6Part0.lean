import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape6T1 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.unordered {3,4,5,8} 1)))))))))
private theorem q11Shape6T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 67108871 q11Shape6T1=true := by decide

private def q11Shape6T3 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))))))
private theorem q11Shape6T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 4 67109123 q11Shape6T3=true := by decide

private def q11Shape6T5 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape6T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 260 67109379 q11Shape6T5=true := by decide

private def q11Shape6T7 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape6T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 772 67141635 q11Shape6T7=true := by decide

private def q11Shape6T8 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))) (.split 18 (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))) (.tip (.cover {1,5,6,7,9,10})))))
private theorem q11Shape6T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33540 67108867 q11Shape6T8=true := by decide

private def q11Shape6T6 : Tree 11 := .split 15 q11Shape6T7 q11Shape6T8
private theorem q11Shape6T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 772 67108867 q11Shape6T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 772 (67108867 ||| 2^15) q11Shape6T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (772 ||| 2^15) 67108867 q11Shape6T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T7OK,q11Shape6T8OK⟩

private def q11Shape6T4 : Tree 11 := .split 9 q11Shape6T5 q11Shape6T6
private theorem q11Shape6T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 260 67108867 q11Shape6T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 260 (67108867 ||| 2^9) q11Shape6T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (260 ||| 2^9) 67108867 q11Shape6T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T5OK,q11Shape6T6OK⟩

private def q11Shape6T2 : Tree 11 := .split 8 q11Shape6T3 q11Shape6T4
private theorem q11Shape6T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 4 67108867 q11Shape6T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 4 (67108867 ||| 2^8) q11Shape6T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (4 ||| 2^8) 67108867 q11Shape6T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T3OK,q11Shape6T4OK⟩

private def q11Shape6T0 : Tree 11 := .split 2 q11Shape6T1 q11Shape6T2
private theorem q11Shape6T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 67108867 q11Shape6T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 (67108867 ||| 2^2) q11Shape6T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (0 ||| 2^2) 67108867 q11Shape6T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T1OK,q11Shape6T2OK⟩

def q11Shape6P0 : Tree 11 := q11Shape6T0
theorem q11Shape6P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 0 67108867 q11Shape6P0=true := q11Shape6T0OK

end Graffiti384b.EffectiveSearch.Q11
