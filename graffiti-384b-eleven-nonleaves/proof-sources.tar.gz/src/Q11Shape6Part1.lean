import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape6T11 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))))
private theorem q11Shape6T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 2 67109125 q11Shape6T11=true := by decide

private def q11Shape6T13 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10})))))
private theorem q11Shape6T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 258 67109381 q11Shape6T13=true := by decide

private def q11Shape6T15 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape6T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 770 67141637 q11Shape6T15=true := by decide

private def q11Shape6T16 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10}))) (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10})))) (.tip (.cover {1,4,6,7,9,10}))))
private theorem q11Shape6T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33538 67108869 q11Shape6T16=true := by decide

private def q11Shape6T14 : Tree 11 := .split 15 q11Shape6T15 q11Shape6T16
private theorem q11Shape6T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 770 67108869 q11Shape6T14=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 770 (67108869 ||| 2^15) q11Shape6T15 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (770 ||| 2^15) 67108869 q11Shape6T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T15OK,q11Shape6T16OK⟩

private def q11Shape6T12 : Tree 11 := .split 9 q11Shape6T13 q11Shape6T14
private theorem q11Shape6T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 258 67108869 q11Shape6T12=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 258 (67108869 ||| 2^9) q11Shape6T13 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (258 ||| 2^9) 67108869 q11Shape6T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T13OK,q11Shape6T14OK⟩

private def q11Shape6T10 : Tree 11 := .split 8 q11Shape6T11 q11Shape6T12
private theorem q11Shape6T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 2 67108869 q11Shape6T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 2 (67108869 ||| 2^8) q11Shape6T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (2 ||| 2^8) 67108869 q11Shape6T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T11OK,q11Shape6T12OK⟩

private def q11Shape6T19 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.unordered {2,4,5,8} 1)))))))
private theorem q11Shape6T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 6 67109633 q11Shape6T19=true := by decide

private def q11Shape6T21 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape6T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 518 67141889 q11Shape6T21=true := by decide

private def q11Shape6T22 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))) (.split 18 (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))) (.tip (.cover {1,5,6,7,9,10})))))
private theorem q11Shape6T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33286 67109121 q11Shape6T22=true := by decide

private def q11Shape6T20 : Tree 11 := .split 15 q11Shape6T21 q11Shape6T22
private theorem q11Shape6T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 518 67109121 q11Shape6T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 518 (67109121 ||| 2^15) q11Shape6T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (518 ||| 2^15) 67109121 q11Shape6T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T21OK,q11Shape6T22OK⟩

private def q11Shape6T18 : Tree 11 := .split 9 q11Shape6T19 q11Shape6T20
private theorem q11Shape6T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 6 67109121 q11Shape6T18=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 6 (67109121 ||| 2^9) q11Shape6T19 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (6 ||| 2^9) 67109121 q11Shape6T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T19OK,q11Shape6T20OK⟩

private def q11Shape6T25 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape6T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 262 67142145 q11Shape6T25=true := by decide

private def q11Shape6T26 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10}))) (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10})))) (.tip (.cover {1,4,6,7,9,10}))))
private theorem q11Shape6T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33030 67109377 q11Shape6T26=true := by decide

private def q11Shape6T24 : Tree 11 := .split 15 q11Shape6T25 q11Shape6T26
private theorem q11Shape6T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 262 67109377 q11Shape6T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 262 (67109377 ||| 2^15) q11Shape6T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (262 ||| 2^15) 67109377 q11Shape6T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T25OK,q11Shape6T26OK⟩

private def q11Shape6T29 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.tip (.cover {4,5,6,7,9,10}))))
private theorem q11Shape6T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 774 67145729 q11Shape6T29=true := by decide

private def q11Shape6T30 : Tree 11 := (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {2,3,6,7,9,10})))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {4,5,6,7,9,10}))))
private theorem q11Shape6T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 4870 67141633 q11Shape6T30=true := by decide

private def q11Shape6T28 : Tree 11 := .split 12 q11Shape6T29 q11Shape6T30
private theorem q11Shape6T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 774 67141633 q11Shape6T28=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 774 (67141633 ||| 2^12) q11Shape6T29 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (774 ||| 2^12) 67141633 q11Shape6T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T29OK,q11Shape6T30OK⟩

private def q11Shape6T31 : Tree 11 := (.split 12 (.split 18 (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,4,6,7,9,10}))) (.split 18 (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {2,3,6,7,9,10}))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {1,4,6,7,9,10}))))
private theorem q11Shape6T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33542 67108865 q11Shape6T31=true := by decide

private def q11Shape6T27 : Tree 11 := .split 15 q11Shape6T28 q11Shape6T31
private theorem q11Shape6T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 774 67108865 q11Shape6T27=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 774 (67108865 ||| 2^15) q11Shape6T28 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (774 ||| 2^15) 67108865 q11Shape6T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T28OK,q11Shape6T31OK⟩

private def q11Shape6T23 : Tree 11 := .split 9 q11Shape6T24 q11Shape6T27
private theorem q11Shape6T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 262 67108865 q11Shape6T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 262 (67108865 ||| 2^9) q11Shape6T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (262 ||| 2^9) 67108865 q11Shape6T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T24OK,q11Shape6T27OK⟩

private def q11Shape6T17 : Tree 11 := .split 8 q11Shape6T18 q11Shape6T23
private theorem q11Shape6T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 6 67108865 q11Shape6T17=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 6 (67108865 ||| 2^8) q11Shape6T18 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (6 ||| 2^8) 67108865 q11Shape6T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T18OK,q11Shape6T23OK⟩

private def q11Shape6T9 : Tree 11 := .split 2 q11Shape6T10 q11Shape6T17
private theorem q11Shape6T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 2 67108865 q11Shape6T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 2 (67108865 ||| 2^2) q11Shape6T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (2 ||| 2^2) 67108865 q11Shape6T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T10OK,q11Shape6T17OK⟩

def q11Shape6P1 : Tree 11 := q11Shape6T9
theorem q11Shape6P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 2 67108865 q11Shape6P1=true := q11Shape6T9OK

end Graffiti384b.EffectiveSearch.Q11
