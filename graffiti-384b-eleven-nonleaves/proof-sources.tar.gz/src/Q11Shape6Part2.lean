import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape6T35 : Tree 11 := (.split 9 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))))
private theorem q11Shape6T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 67109126 q11Shape6T35=true := by decide

private def q11Shape6T37 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape6T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 257 67109382 q11Shape6T37=true := by decide

private def q11Shape6T38 : Tree 11 := (.split 15 (.split 12 (.tip (.small 1)) (.tip (.cover {1,3,6,7,9,10}))) (.split 12 (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10}))))) (.tip (.cover {1,3,6,7,9,10}))))
private theorem q11Shape6T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 769 67108870 q11Shape6T38=true := by decide

private def q11Shape6T36 : Tree 11 := .split 9 q11Shape6T37 q11Shape6T38
private theorem q11Shape6T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 257 67108870 q11Shape6T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 257 (67108870 ||| 2^9) q11Shape6T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (257 ||| 2^9) 67108870 q11Shape6T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T37OK,q11Shape6T38OK⟩

private def q11Shape6T34 : Tree 11 := .split 8 q11Shape6T35 q11Shape6T36
private theorem q11Shape6T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 67108870 q11Shape6T34=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 (67108870 ||| 2^8) q11Shape6T35 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (1 ||| 2^8) 67108870 q11Shape6T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T35OK,q11Shape6T36OK⟩

private def q11Shape6T41 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape6T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 5 67109634 q11Shape6T41=true := by decide

private def q11Shape6T43 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.unordered {2,3,5,8} 1))))))
private theorem q11Shape6T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 517 67141890 q11Shape6T43=true := by decide

private def q11Shape6T44 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10})))) (.split 18 (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {5,6,7,8,9,10}))) (.tip (.cover {1,5,6,7,9,10})))))
private theorem q11Shape6T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33285 67109122 q11Shape6T44=true := by decide

private def q11Shape6T42 : Tree 11 := .split 15 q11Shape6T43 q11Shape6T44
private theorem q11Shape6T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 517 67109122 q11Shape6T42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 517 (67109122 ||| 2^15) q11Shape6T43 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (517 ||| 2^15) 67109122 q11Shape6T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T43OK,q11Shape6T44OK⟩

private def q11Shape6T40 : Tree 11 := .split 9 q11Shape6T41 q11Shape6T42
private theorem q11Shape6T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 5 67109122 q11Shape6T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 5 (67109122 ||| 2^9) q11Shape6T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (5 ||| 2^9) 67109122 q11Shape6T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T41OK,q11Shape6T42OK⟩

private def q11Shape6T47 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape6T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 261 67142146 q11Shape6T47=true := by decide

private def q11Shape6T49 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {2,4,6,7,9,10})))))
private theorem q11Shape6T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33029 67113474 q11Shape6T49=true := by decide

private def q11Shape6T50 : Tree 11 := (.split 18 (.split 23 (.tip (.small 1)) (.tip (.cover {3,5,6,7,9,10}))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {2,4,6,7,9,10}))) (.tip (.cover {3,5,6,7,9,10}))))
private theorem q11Shape6T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 37125 67109378 q11Shape6T50=true := by decide

private def q11Shape6T48 : Tree 11 := .split 12 q11Shape6T49 q11Shape6T50
private theorem q11Shape6T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33029 67109378 q11Shape6T48=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33029 (67109378 ||| 2^12) q11Shape6T49 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (33029 ||| 2^12) 67109378 q11Shape6T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T49OK,q11Shape6T50OK⟩

private def q11Shape6T46 : Tree 11 := .split 15 q11Shape6T47 q11Shape6T48
private theorem q11Shape6T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 261 67109378 q11Shape6T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 261 (67109378 ||| 2^15) q11Shape6T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (261 ||| 2^15) 67109378 q11Shape6T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T47OK,q11Shape6T48OK⟩

private def q11Shape6T52 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10}))))) (.tip (.cover {1,3,6,7,9,10})))
private theorem q11Shape6T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 773 67141634 q11Shape6T52=true := by decide

private def q11Shape6T53 : Tree 11 := (.split 12 (.split 18 (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {2,4,6,7,9,10}))) (.tip (.cover {1,5,6,7,9,10})))) (.tip (.cover {1,3,6,7,9,10})))
private theorem q11Shape6T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33541 67108866 q11Shape6T53=true := by decide

private def q11Shape6T51 : Tree 11 := .split 15 q11Shape6T52 q11Shape6T53
private theorem q11Shape6T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 773 67108866 q11Shape6T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 773 (67108866 ||| 2^15) q11Shape6T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (773 ||| 2^15) 67108866 q11Shape6T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T52OK,q11Shape6T53OK⟩

private def q11Shape6T45 : Tree 11 := .split 9 q11Shape6T46 q11Shape6T51
private theorem q11Shape6T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 261 67108866 q11Shape6T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 261 (67108866 ||| 2^9) q11Shape6T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (261 ||| 2^9) 67108866 q11Shape6T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T46OK,q11Shape6T51OK⟩

private def q11Shape6T39 : Tree 11 := .split 8 q11Shape6T40 q11Shape6T45
private theorem q11Shape6T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 5 67108866 q11Shape6T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 5 (67108866 ||| 2^8) q11Shape6T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (5 ||| 2^8) 67108866 q11Shape6T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T40OK,q11Shape6T45OK⟩

private def q11Shape6T33 : Tree 11 := .split 2 q11Shape6T34 q11Shape6T39
private theorem q11Shape6T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 67108866 q11Shape6T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 (67108866 ||| 2^2) q11Shape6T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (1 ||| 2^2) 67108866 q11Shape6T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T34OK,q11Shape6T39OK⟩

def q11Shape6P2 : Tree 11 := q11Shape6T33
theorem q11Shape6P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 1 67108866 q11Shape6P2=true := q11Shape6T33OK

end Graffiti384b.EffectiveSearch.Q11
