import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape6T56 : Tree 11 := (.split 15 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10})))))))
private theorem q11Shape6T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 67109636 q11Shape6T56=true := by decide

private def q11Shape6T58 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,6,7,8,9,10}))))))
private theorem q11Shape6T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 515 67141892 q11Shape6T58=true := by decide

private def q11Shape6T59 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10}))))) (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10})))) (.tip (.cover {3,4,6,7,9,10}))))
private theorem q11Shape6T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33283 67109124 q11Shape6T59=true := by decide

private def q11Shape6T57 : Tree 11 := .split 15 q11Shape6T58 q11Shape6T59
private theorem q11Shape6T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 515 67109124 q11Shape6T57=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 515 (67109124 ||| 2^15) q11Shape6T58 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (515 ||| 2^15) 67109124 q11Shape6T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T58OK,q11Shape6T59OK⟩

private def q11Shape6T55 : Tree 11 := .split 9 q11Shape6T56 q11Shape6T57
private theorem q11Shape6T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 67109124 q11Shape6T55=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 (67109124 ||| 2^9) q11Shape6T56 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (3 ||| 2^9) 67109124 q11Shape6T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T56OK,q11Shape6T57OK⟩

private def q11Shape6T62 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.unordered {2,3,4,8} 1))))))
private theorem q11Shape6T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 259 67142148 q11Shape6T62=true := by decide

private def q11Shape6T63 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.tip (.cover {1,4,6,7,9,10}))) (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {4,6,7,8,9,10})))) (.tip (.cover {1,4,6,7,9,10}))))
private theorem q11Shape6T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33027 67109380 q11Shape6T63=true := by decide

private def q11Shape6T61 : Tree 11 := .split 15 q11Shape6T62 q11Shape6T63
private theorem q11Shape6T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 259 67109380 q11Shape6T61=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 259 (67109380 ||| 2^15) q11Shape6T62 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (259 ||| 2^15) 67109380 q11Shape6T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T62OK,q11Shape6T63OK⟩

private def q11Shape6T65 : Tree 11 := (.split 12 (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {3,6,7,8,9,10}))))) (.tip (.cover {1,3,6,7,9,10})))
private theorem q11Shape6T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 771 67141636 q11Shape6T65=true := by decide

private def q11Shape6T66 : Tree 11 := (.split 12 (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {2,5,6,7,9,10})))) (.tip (.cover {1,4,6,7,9,10}))) (.tip (.cover {1,3,6,7,9,10})))
private theorem q11Shape6T66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33539 67108868 q11Shape6T66=true := by decide

private def q11Shape6T64 : Tree 11 := .split 15 q11Shape6T65 q11Shape6T66
private theorem q11Shape6T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 771 67108868 q11Shape6T64=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 771 (67108868 ||| 2^15) q11Shape6T65 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (771 ||| 2^15) 67108868 q11Shape6T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T65OK,q11Shape6T66OK⟩

private def q11Shape6T60 : Tree 11 := .split 9 q11Shape6T61 q11Shape6T64
private theorem q11Shape6T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 259 67108868 q11Shape6T60=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 259 (67108868 ||| 2^9) q11Shape6T61 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (259 ||| 2^9) 67108868 q11Shape6T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T61OK,q11Shape6T64OK⟩

private def q11Shape6T54 : Tree 11 := .split 8 q11Shape6T55 q11Shape6T60
private theorem q11Shape6T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 67108868 q11Shape6T54=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 (67108868 ||| 2^8) q11Shape6T55 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (3 ||| 2^8) 67108868 q11Shape6T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T55OK,q11Shape6T60OK⟩

def q11Shape6P3 : Tree 11 := q11Shape6T54
theorem q11Shape6P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 3 67108868 q11Shape6P3=true := q11Shape6T54OK

end Graffiti384b.EffectiveSearch.Q11
