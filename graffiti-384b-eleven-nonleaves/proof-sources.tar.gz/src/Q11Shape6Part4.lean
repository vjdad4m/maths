import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape6T70 : Tree 11 := (.split 12 (.tip (.small 1)) (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.tip (.cover {2,6,7,8,9,10})))))
private theorem q11Shape6T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 67142400 q11Shape6T70=true := by decide

private def q11Shape6T72 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))))
private theorem q11Shape6T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 32775 67113728 q11Shape6T72=true := by decide

private def q11Shape6T73 : Tree 11 := (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10}))) (.tip (.cover {2,6,7,8,9,10}))))
private theorem q11Shape6T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 36871 67109632 q11Shape6T73=true := by decide

private def q11Shape6T71 : Tree 11 := .split 12 q11Shape6T72 q11Shape6T73
private theorem q11Shape6T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 32775 67109632 q11Shape6T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 32775 (67109632 ||| 2^12) q11Shape6T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (32775 ||| 2^12) 67109632 q11Shape6T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T72OK,q11Shape6T73OK⟩

private def q11Shape6T69 : Tree 11 := .split 15 q11Shape6T70 q11Shape6T71
private theorem q11Shape6T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 67109632 q11Shape6T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 (67109632 ||| 2^15) q11Shape6T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (7 ||| 2^15) 67109632 q11Shape6T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T70OK,q11Shape6T71OK⟩

private def q11Shape6T76 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))))
private theorem q11Shape6T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 519 67145984 q11Shape6T76=true := by decide

private def q11Shape6T77 : Tree 11 := (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10}))) (.tip (.cover {2,6,7,8,9,10}))))
private theorem q11Shape6T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 4615 67141888 q11Shape6T77=true := by decide

private def q11Shape6T75 : Tree 11 := .split 12 q11Shape6T76 q11Shape6T77
private theorem q11Shape6T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 519 67141888 q11Shape6T75=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 519 (67141888 ||| 2^12) q11Shape6T76 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (519 ||| 2^12) 67141888 q11Shape6T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T76OK,q11Shape6T77OK⟩

private def q11Shape6T79 : Tree 11 := (.split 18 (.split 23 (.tip (.small 1)) (.tip (.cover {1,5,6,7,9,10}))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10}))) (.tip (.cover {1,5,6,7,9,10}))))
private theorem q11Shape6T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33287 67113216 q11Shape6T79=true := by decide

private def q11Shape6T80 : Tree 11 := (.split 18 (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10}))) (.tip (.cover {1,5,6,7,9,10}))) (.tip (.cover {3,4,6,7,9,10})))
private theorem q11Shape6T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 37383 67109120 q11Shape6T80=true := by decide

private def q11Shape6T78 : Tree 11 := .split 12 q11Shape6T79 q11Shape6T80
private theorem q11Shape6T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33287 67109120 q11Shape6T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33287 (67109120 ||| 2^12) q11Shape6T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (33287 ||| 2^12) 67109120 q11Shape6T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T79OK,q11Shape6T80OK⟩

private def q11Shape6T74 : Tree 11 := .split 15 q11Shape6T75 q11Shape6T78
private theorem q11Shape6T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 519 67109120 q11Shape6T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 519 (67109120 ||| 2^15) q11Shape6T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (519 ||| 2^15) 67109120 q11Shape6T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T75OK,q11Shape6T78OK⟩

private def q11Shape6T68 : Tree 11 := .split 9 q11Shape6T69 q11Shape6T74
private theorem q11Shape6T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 67109120 q11Shape6T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 (67109120 ||| 2^9) q11Shape6T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (7 ||| 2^9) 67109120 q11Shape6T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T69OK,q11Shape6T74OK⟩

private def q11Shape6T84 : Tree 11 := (.split 18 (.tip (.small 1)) (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))))
private theorem q11Shape6T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 263 67146240 q11Shape6T84=true := by decide

private def q11Shape6T85 : Tree 11 := (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10}))) (.tip (.cover {2,6,7,8,9,10}))))
private theorem q11Shape6T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 4359 67142144 q11Shape6T85=true := by decide

private def q11Shape6T83 : Tree 11 := .split 12 q11Shape6T84 q11Shape6T85
private theorem q11Shape6T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 263 67142144 q11Shape6T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 263 (67142144 ||| 2^12) q11Shape6T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (263 ||| 2^12) 67142144 q11Shape6T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T84OK,q11Shape6T85OK⟩

private def q11Shape6T86 : Tree 11 := (.split 12 (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))) (.tip (.cover {1,4,6,7,9,10}))) (.split 18 (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10}))) (.tip (.cover {3,5,6,7,9,10}))) (.tip (.cover {1,4,6,7,9,10}))))
private theorem q11Shape6T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33031 67109376 q11Shape6T86=true := by decide

private def q11Shape6T82 : Tree 11 := .split 15 q11Shape6T83 q11Shape6T86
private theorem q11Shape6T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 263 67109376 q11Shape6T82=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 263 (67109376 ||| 2^15) q11Shape6T83 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (263 ||| 2^15) 67109376 q11Shape6T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T83OK,q11Shape6T86OK⟩

private def q11Shape6T88 : Tree 11 := (.split 12 (.split 18 (.split 23 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10})))) (.split 23 (.split 5 (.tip (.small 1)) (.tip (.cover {1,2,6,7,9,10}))) (.tip (.cover {4,5,6,7,9,10})))) (.tip (.cover {1,3,6,7,9,10})))
private theorem q11Shape6T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 775 67141632 q11Shape6T88=true := by decide

private def q11Shape6T89 : Tree 11 := (.split 12 (.tip (.unordered {2,3,4,5} 1)) (.tip (.cover {1,3,6,7,9,10})))
private theorem q11Shape6T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 33543 67108864 q11Shape6T89=true := by decide

private def q11Shape6T87 : Tree 11 := .split 15 q11Shape6T88 q11Shape6T89
private theorem q11Shape6T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 775 67108864 q11Shape6T87=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 775 (67108864 ||| 2^15) q11Shape6T88 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (775 ||| 2^15) 67108864 q11Shape6T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T88OK,q11Shape6T89OK⟩

private def q11Shape6T81 : Tree 11 := .split 9 q11Shape6T82 q11Shape6T87
private theorem q11Shape6T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 263 67108864 q11Shape6T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 263 (67108864 ||| 2^9) q11Shape6T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (263 ||| 2^9) 67108864 q11Shape6T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T82OK,q11Shape6T87OK⟩

private def q11Shape6T67 : Tree 11 := .split 8 q11Shape6T68 q11Shape6T81
private theorem q11Shape6T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 67108864 q11Shape6T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 (67108864 ||| 2^8) q11Shape6T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) (7 ||| 2^8) 67108864 q11Shape6T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape6T68OK,q11Shape6T81OK⟩

def q11Shape6P4 : Tree 11 := q11Shape6T67
theorem q11Shape6P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 7 67108864 q11Shape6P4=true := q11Shape6T67OK

private def q11Shape6T93 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape6T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 67108864 0 q11Shape6T93=true := by decide

def q11Shape6P5 : Tree 11 := q11Shape6T93
theorem q11Shape6P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,5,4⟩) 67108864 0 q11Shape6P5=true := q11Shape6T93OK

end Graffiti384b.EffectiveSearch.Q11
