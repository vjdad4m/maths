import Q11Shape7Part0
import Q11Shape7Part1

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape7M58 : Tree 11 := .split 21 q11Shape7P0 q11Shape7P1
private theorem q11Shape7M58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 0 q11Shape7M58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (0 ||| 2^21) q11Shape7P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^21) 0 q11Shape7P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7P0OK,q11Shape7P1OK⟩

theorem q11Shape7_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 7) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 7) b) (adj 11 (forms 7) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) adj_mono b H q11Shape7M58 q11Shape7M58OK

#print axioms q11Shape7_cover

end Graffiti384b.EffectiveSearch.Q11
