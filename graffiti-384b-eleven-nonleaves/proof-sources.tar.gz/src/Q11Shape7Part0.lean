import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape7T9 : Tree 11 := (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9})))) (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8}))))
private theorem q11Shape7T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 67727523840 q11Shape7T9=true := by decide

private def q11Shape7T10 : Tree 11 := (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,7,8,9,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10})))
private theorem q11Shape7T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8388608 67719135232 q11Shape7T10=true := by decide

private def q11Shape7T8 : Tree 11 := .split 23 q11Shape7T9 q11Shape7T10
private theorem q11Shape7T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 67719135232 q11Shape7T8=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (67719135232 ||| 2^23) q11Shape7T9 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^23) 67719135232 q11Shape7T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T9OK,q11Shape7T10OK⟩

private def q11Shape7T11 : Tree 11 := (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape7T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4294967296 63424167936 q11Shape7T11=true := by decide

private def q11Shape7T7 : Tree 11 := .split 32 q11Shape7T8 q11Shape7T11
private theorem q11Shape7T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 63424167936 q11Shape7T7=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (63424167936 ||| 2^32) q11Shape7T8 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^32) 63424167936 q11Shape7T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T8OK,q11Shape7T11OK⟩

private def q11Shape7T12 : Tree 11 := (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape7T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2147483648 61276684288 q11Shape7T12=true := by decide

private def q11Shape7T6 : Tree 11 := .split 31 q11Shape7T7 q11Shape7T12
private theorem q11Shape7T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 61276684288 q11Shape7T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (61276684288 ||| 2^31) q11Shape7T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^31) 61276684288 q11Shape7T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T7OK,q11Shape7T12OK⟩

private def q11Shape7T14 : Tree 11 := (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,7})) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,5,8,9,10}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,7,10}))) (.tip (.cover {0,1,6,8,9,10}))) (.tip (.cover {0,1,5,6,7,9})))
private theorem q11Shape7T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 1073741824 62350426112 q11Shape7T14=true := by decide

private def q11Shape7T15 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape7T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 3221225472 60202942464 q11Shape7T15=true := by decide

private def q11Shape7T13 : Tree 11 := .split 31 q11Shape7T14 q11Shape7T15
private theorem q11Shape7T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 1073741824 60202942464 q11Shape7T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 1073741824 (60202942464 ||| 2^31) q11Shape7T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (1073741824 ||| 2^31) 60202942464 q11Shape7T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T14OK,q11Shape7T15OK⟩

private def q11Shape7T5 : Tree 11 := .split 30 q11Shape7T6 q11Shape7T13
private theorem q11Shape7T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 60202942464 q11Shape7T5=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (60202942464 ||| 2^30) q11Shape7T6 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^30) 60202942464 q11Shape7T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T6OK,q11Shape7T13OK⟩

private def q11Shape7T17 : Tree 11 := (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,5,6,7,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,8,9})))
private theorem q11Shape7T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 34359738368 26916945920 q11Shape7T17=true := by decide

private def q11Shape7T18 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape7T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 35433480192 25843204096 q11Shape7T18=true := by decide

private def q11Shape7T16 : Tree 11 := .split 30 q11Shape7T17 q11Shape7T18
private theorem q11Shape7T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 34359738368 25843204096 q11Shape7T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 34359738368 (25843204096 ||| 2^30) q11Shape7T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (34359738368 ||| 2^30) 25843204096 q11Shape7T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T17OK,q11Shape7T18OK⟩

private def q11Shape7T4 : Tree 11 := .split 35 q11Shape7T5 q11Shape7T16
private theorem q11Shape7T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 25843204096 q11Shape7T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (25843204096 ||| 2^35) q11Shape7T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^35) 25843204096 q11Shape7T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T5OK,q11Shape7T16OK⟩

private def q11Shape7T21 : Tree 11 := (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.tip (.cover {0,1,2,3,4,10})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,7,8,9}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,7,8})))
private theorem q11Shape7T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17179869184 44096815104 q11Shape7T21=true := by decide

private def q11Shape7T22 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape7T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 18253611008 43023073280 q11Shape7T22=true := by decide

private def q11Shape7T20 : Tree 11 := .split 30 q11Shape7T21 q11Shape7T22
private theorem q11Shape7T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17179869184 43023073280 q11Shape7T20=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17179869184 (43023073280 ||| 2^30) q11Shape7T21 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (17179869184 ||| 2^30) 43023073280 q11Shape7T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T21OK,q11Shape7T22OK⟩

private def q11Shape7T23 : Tree 11 := (.tip (.cover {0,1,5,6,7,10}))
private theorem q11Shape7T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 51539607552 8663334912 q11Shape7T23=true := by decide

private def q11Shape7T19 : Tree 11 := .split 35 q11Shape7T20 q11Shape7T23
private theorem q11Shape7T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17179869184 8663334912 q11Shape7T19=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17179869184 (8663334912 ||| 2^35) q11Shape7T20 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (17179869184 ||| 2^35) 8663334912 q11Shape7T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T20OK,q11Shape7T23OK⟩

private def q11Shape7T3 : Tree 11 := .split 34 q11Shape7T4 q11Shape7T19
private theorem q11Shape7T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 8663334912 q11Shape7T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (8663334912 ||| 2^34) q11Shape7T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^34) 8663334912 q11Shape7T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T4OK,q11Shape7T19OK⟩

private def q11Shape7T27 : Tree 11 := (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 29 (.tip (.cover {0,1,2,3,4,9})) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,6,7,9,10}))) (.tip (.cover {0,1,6,7,8,10}))) (.tip (.cover {0,1,5,6,7,8}))) (.tip (.cover {0,1,5,6,9,10})))
private theorem q11Shape7T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8589934592 52686749696 q11Shape7T27=true := by decide

private def q11Shape7T28 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape7T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 9663676416 51613007872 q11Shape7T28=true := by decide

private def q11Shape7T26 : Tree 11 := .split 30 q11Shape7T27 q11Shape7T28
private theorem q11Shape7T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8589934592 51613007872 q11Shape7T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8589934592 (51613007872 ||| 2^30) q11Shape7T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (8589934592 ||| 2^30) 51613007872 q11Shape7T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T27OK,q11Shape7T28OK⟩

private def q11Shape7T29 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape7T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 42949672960 17253269504 q11Shape7T29=true := by decide

private def q11Shape7T25 : Tree 11 := .split 35 q11Shape7T26 q11Shape7T29
private theorem q11Shape7T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8589934592 17253269504 q11Shape7T25=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8589934592 (17253269504 ||| 2^35) q11Shape7T26 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (8589934592 ||| 2^35) 17253269504 q11Shape7T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T26OK,q11Shape7T29OK⟩

private def q11Shape7T30 : Tree 11 := (.tip (.cover {0,1,5,6,7,8}))
private theorem q11Shape7T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 25769803776 73400320 q11Shape7T30=true := by decide

private def q11Shape7T24 : Tree 11 := .split 34 q11Shape7T25 q11Shape7T30
private theorem q11Shape7T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8589934592 73400320 q11Shape7T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8589934592 (73400320 ||| 2^34) q11Shape7T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (8589934592 ||| 2^34) 73400320 q11Shape7T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T25OK,q11Shape7T30OK⟩

private def q11Shape7T2 : Tree 11 := .split 33 q11Shape7T3 q11Shape7T24
private theorem q11Shape7T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 73400320 q11Shape7T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (73400320 ||| 2^33) q11Shape7T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^33) 73400320 q11Shape7T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T3OK,q11Shape7T24OK⟩

private def q11Shape7T33 : Tree 11 := (.split 35 (.split 30 (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,6,8,9})))
private theorem q11Shape7T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 67108864 25776095232 q11Shape7T33=true := by decide

private def q11Shape7T34 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape7T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17246978048 8596226048 q11Shape7T34=true := by decide

private def q11Shape7T32 : Tree 11 := .split 34 q11Shape7T33 q11Shape7T34
private theorem q11Shape7T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 67108864 8596226048 q11Shape7T32=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 67108864 (8596226048 ||| 2^34) q11Shape7T33 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (67108864 ||| 2^34) 8596226048 q11Shape7T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T33OK,q11Shape7T34OK⟩

private def q11Shape7T35 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape7T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8657043456 6291456 q11Shape7T35=true := by decide

private def q11Shape7T31 : Tree 11 := .split 33 q11Shape7T32 q11Shape7T35
private theorem q11Shape7T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 67108864 6291456 q11Shape7T31=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 67108864 (6291456 ||| 2^33) q11Shape7T32 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (67108864 ||| 2^33) 6291456 q11Shape7T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T32OK,q11Shape7T35OK⟩

private def q11Shape7T1 : Tree 11 := .split 26 q11Shape7T2 q11Shape7T31
private theorem q11Shape7T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 6291456 q11Shape7T1=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (6291456 ||| 2^26) q11Shape7T2 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^26) 6291456 q11Shape7T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T2OK,q11Shape7T31OK⟩

private def q11Shape7T42 : Tree 11 := (.split 32 (.split 23 (.split 24 (.split 25 (.split 27 (.split 28 (.split 29 (.tip (.cover {0,1,2,3,4,5})) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,5,6,8,9}))) (.tip (.cover {0,1,5,6,8,10}))) (.tip (.cover {0,1,5,6,9,10}))) (.tip (.cover {0,1,6,7,8,9})))
private theorem q11Shape7T42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 63419973632 q11Shape7T42=true := by decide

private def q11Shape7T43 : Tree 11 := (.tip (.cover {0,1,6,7,8,10}))
private theorem q11Shape7T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2151677952 61272489984 q11Shape7T43=true := by decide

private def q11Shape7T41 : Tree 11 := .split 31 q11Shape7T42 q11Shape7T43
private theorem q11Shape7T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 61272489984 q11Shape7T41=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 (61272489984 ||| 2^31) q11Shape7T42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (4194304 ||| 2^31) 61272489984 q11Shape7T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T42OK,q11Shape7T43OK⟩

private def q11Shape7T44 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape7T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 1077936128 60198748160 q11Shape7T44=true := by decide

private def q11Shape7T40 : Tree 11 := .split 30 q11Shape7T41 q11Shape7T44
private theorem q11Shape7T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 60198748160 q11Shape7T40=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 (60198748160 ||| 2^30) q11Shape7T41 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (4194304 ||| 2^30) 60198748160 q11Shape7T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T41OK,q11Shape7T44OK⟩

private def q11Shape7T45 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape7T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 34363932672 25839009792 q11Shape7T45=true := by decide

private def q11Shape7T39 : Tree 11 := .split 35 q11Shape7T40 q11Shape7T45
private theorem q11Shape7T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 25839009792 q11Shape7T39=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 (25839009792 ||| 2^35) q11Shape7T40 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (4194304 ||| 2^35) 25839009792 q11Shape7T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T40OK,q11Shape7T45OK⟩

private def q11Shape7T46 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape7T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17184063488 8659140608 q11Shape7T46=true := by decide

private def q11Shape7T38 : Tree 11 := .split 34 q11Shape7T39 q11Shape7T46
private theorem q11Shape7T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 8659140608 q11Shape7T38=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 (8659140608 ||| 2^34) q11Shape7T39 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (4194304 ||| 2^34) 8659140608 q11Shape7T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T39OK,q11Shape7T46OK⟩

private def q11Shape7T47 : Tree 11 := (.tip (.cover {0,1,5,6,8,10}))
private theorem q11Shape7T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8594128896 69206016 q11Shape7T47=true := by decide

private def q11Shape7T37 : Tree 11 := .split 33 q11Shape7T38 q11Shape7T47
private theorem q11Shape7T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 69206016 q11Shape7T37=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 (69206016 ||| 2^33) q11Shape7T38 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (4194304 ||| 2^33) 69206016 q11Shape7T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T38OK,q11Shape7T47OK⟩

private def q11Shape7T48 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape7T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 71303168 2097152 q11Shape7T48=true := by decide

private def q11Shape7T36 : Tree 11 := .split 26 q11Shape7T37 q11Shape7T48
private theorem q11Shape7T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 2097152 q11Shape7T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 4194304 (2097152 ||| 2^26) q11Shape7T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (4194304 ||| 2^26) 2097152 q11Shape7T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T37OK,q11Shape7T48OK⟩

private def q11Shape7T0 : Tree 11 := .split 22 q11Shape7T1 q11Shape7T36
private theorem q11Shape7T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 2097152 q11Shape7T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 (2097152 ||| 2^22) q11Shape7T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (0 ||| 2^22) 2097152 q11Shape7T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T1OK,q11Shape7T36OK⟩

def q11Shape7P0 : Tree 11 := q11Shape7T0
theorem q11Shape7P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 0 2097152 q11Shape7P0=true := q11Shape7T0OK

end Graffiti384b.EffectiveSearch.Q11
