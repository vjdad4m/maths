import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape7T53 : Tree 11 := (.split 35 (.split 30 (.split 31 (.split 32 (.split 23 (.split 24 (.split 25 (.tip (.cover {0,1,2,3,4,6})) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9}))) (.tip (.cover {0,1,5,7,8,10}))) (.tip (.cover {0,1,5,7,9,10}))) (.tip (.cover {0,1,5,7,8,9})))
private theorem q11Shape7T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 25841106944 q11Shape7T53=true := by decide

private def q11Shape7T54 : Tree 11 := (.tip (.cover {0,1,5,7,8,9}))
private theorem q11Shape7T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 17181966336 8661237760 q11Shape7T54=true := by decide

private def q11Shape7T52 : Tree 11 := .split 34 q11Shape7T53 q11Shape7T54
private theorem q11Shape7T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 8661237760 q11Shape7T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 (8661237760 ||| 2^34) q11Shape7T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (2097152 ||| 2^34) 8661237760 q11Shape7T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T53OK,q11Shape7T54OK⟩

private def q11Shape7T55 : Tree 11 := (.tip (.cover {0,1,5,7,8,10}))
private theorem q11Shape7T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 8592031744 71303168 q11Shape7T55=true := by decide

private def q11Shape7T51 : Tree 11 := .split 33 q11Shape7T52 q11Shape7T55
private theorem q11Shape7T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 71303168 q11Shape7T51=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 (71303168 ||| 2^33) q11Shape7T52 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (2097152 ||| 2^33) 71303168 q11Shape7T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T52OK,q11Shape7T55OK⟩

private def q11Shape7T56 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape7T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 69206016 4194304 q11Shape7T56=true := by decide

private def q11Shape7T50 : Tree 11 := .split 26 q11Shape7T51 q11Shape7T56
private theorem q11Shape7T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 4194304 q11Shape7T50=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 (4194304 ||| 2^26) q11Shape7T51 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (2097152 ||| 2^26) 4194304 q11Shape7T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T51OK,q11Shape7T56OK⟩

private def q11Shape7T57 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape7T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 6291456 0 q11Shape7T57=true := by decide

private def q11Shape7T49 : Tree 11 := .split 22 q11Shape7T50 q11Shape7T57
private theorem q11Shape7T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 0 q11Shape7T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 (0 ||| 2^22) q11Shape7T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) (2097152 ||| 2^22) 0 q11Shape7T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape7T50OK,q11Shape7T57OK⟩

def q11Shape7P1 : Tree 11 := q11Shape7T49
theorem q11Shape7P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,3⟩) 2097152 0 q11Shape7P1=true := q11Shape7T49OK

end Graffiti384b.EffectiveSearch.Q11
