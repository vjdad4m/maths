import Q11Shape8Part0

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

theorem q11Shape8_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 8) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 8) b) (adj 11 (forms 8) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,6,6,4⟩) adj_mono b H q11Shape8P0 q11Shape8P0OK

#print axioms q11Shape8_cover

end Graffiti384b.EffectiveSearch.Q11
