import Q11Shape9Part0
import Q11Shape9Part1
import Q11Shape9Part2
import Q11Shape9Part3
import Q11Shape9Part4
import Q11Shape9Part5

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape9M42 : Tree 11 := .split 27 q11Shape9P0 q11Shape9P1
private theorem q11Shape9M42OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 81788928 q11Shape9M42=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 (81788928 ||| 2^27) q11Shape9P0 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (0 ||| 2^27) 81788928 q11Shape9P1)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9P0OK,q11Shape9P1OK⟩
private def q11Shape9M66 : Tree 11 := .split 26 q11Shape9M42 q11Shape9P2
private theorem q11Shape9M66OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 14680064 q11Shape9M66=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 (14680064 ||| 2^26) q11Shape9M42 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (0 ||| 2^26) 14680064 q11Shape9P2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9M42OK,q11Shape9P2OK⟩
private def q11Shape9M92 : Tree 11 := .split 23 q11Shape9M66 q11Shape9P3
private theorem q11Shape9M92OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 6291456 q11Shape9M92=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 (6291456 ||| 2^23) q11Shape9M66 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (0 ||| 2^23) 6291456 q11Shape9P3)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9M66OK,q11Shape9P3OK⟩
private def q11Shape9M120 : Tree 11 := .split 22 q11Shape9M92 q11Shape9P4
private theorem q11Shape9M120OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 2097152 q11Shape9M120=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 (2097152 ||| 2^22) q11Shape9M92 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (0 ||| 2^22) 2097152 q11Shape9P4)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9M92OK,q11Shape9P4OK⟩
private def q11Shape9M150 : Tree 11 := .split 21 q11Shape9M120 q11Shape9P5
private theorem q11Shape9M150OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 0 q11Shape9M150=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 (0 ||| 2^21) q11Shape9M120 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (0 ||| 2^21) 0 q11Shape9P5)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9M120OK,q11Shape9P5OK⟩

theorem q11Shape9_cover (b : Nat→Bool) (H : Ranked (adj 11 (forms 9) b) (root (n:=11) (by decide))) :
    ∃ D : Finset (Label 11),D.card≤6 ∧ Effective (adj 11 (forms 9) b) (adj 11 (forms 9) b) D :=
  checked_fast_tree (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) adj_mono b H q11Shape9M150 q11Shape9M150OK

#print axioms q11Shape9_cover

end Graffiti384b.EffectiveSearch.Q11
