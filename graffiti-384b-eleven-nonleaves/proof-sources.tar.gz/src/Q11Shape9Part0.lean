import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape9T1 : Tree 11 := (.tip (.cover {0,2,3,4,9,10}))
private theorem q11Shape9T1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 1289748480 q11Shape9T1=true := by decide

private def q11Shape9T5 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7})))))
private theorem q11Shape9T5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741824 34575745027 q11Shape9T5=true := by decide

private def q11Shape9T7 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T7OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741826 34575745281 q11Shape9T7=true := by decide

private def q11Shape9T8 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T8OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073742082 34575745025 q11Shape9T8=true := by decide

private def q11Shape9T6 : Tree 11 := .split 8 q11Shape9T7 q11Shape9T8
private theorem q11Shape9T6OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741826 34575745025 q11Shape9T6=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741826 (34575745025 ||| 2^8) q11Shape9T7 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073741826 ||| 2^8) 34575745025 q11Shape9T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T7OK,q11Shape9T8OK⟩

private def q11Shape9T4 : Tree 11 := .split 1 q11Shape9T5 q11Shape9T6
private theorem q11Shape9T4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741824 34575745025 q11Shape9T4=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741824 (34575745025 ||| 2^1) q11Shape9T5 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073741824 ||| 2^1) 34575745025 q11Shape9T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T5OK,q11Shape9T6OK⟩

private def q11Shape9T11 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T11OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741825 34575745282 q11Shape9T11=true := by decide

private def q11Shape9T12 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T12OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073742081 34575745026 q11Shape9T12=true := by decide

private def q11Shape9T10 : Tree 11 := .split 8 q11Shape9T11 q11Shape9T12
private theorem q11Shape9T10OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741825 34575745026 q11Shape9T10=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741825 (34575745026 ||| 2^8) q11Shape9T11 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073741825 ||| 2^8) 34575745026 q11Shape9T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T11OK,q11Shape9T12OK⟩

private def q11Shape9T14 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T14OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741827 34575745280 q11Shape9T14=true := by decide

private def q11Shape9T17 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape9T17OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073742083 34575769600 q11Shape9T17=true := by decide

private def q11Shape9T18 : Tree 11 := (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape9T18OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073758467 34575753216 q11Shape9T18=true := by decide

private def q11Shape9T16 : Tree 11 := .split 14 q11Shape9T17 q11Shape9T18
private theorem q11Shape9T16OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073742083 34575753216 q11Shape9T16=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073742083 (34575753216 ||| 2^14) q11Shape9T17 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073742083 ||| 2^14) 34575753216 q11Shape9T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T17OK,q11Shape9T18OK⟩

private def q11Shape9T19 : Tree 11 := (.split 14 (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7})))
private theorem q11Shape9T19OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073750275 34575745024 q11Shape9T19=true := by decide

private def q11Shape9T15 : Tree 11 := .split 13 q11Shape9T16 q11Shape9T19
private theorem q11Shape9T15OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073742083 34575745024 q11Shape9T15=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073742083 (34575745024 ||| 2^13) q11Shape9T16 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073742083 ||| 2^13) 34575745024 q11Shape9T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T16OK,q11Shape9T19OK⟩

private def q11Shape9T13 : Tree 11 := .split 8 q11Shape9T14 q11Shape9T15
private theorem q11Shape9T13OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741827 34575745024 q11Shape9T13=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741827 (34575745024 ||| 2^8) q11Shape9T14 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073741827 ||| 2^8) 34575745024 q11Shape9T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T14OK,q11Shape9T15OK⟩

private def q11Shape9T9 : Tree 11 := .split 1 q11Shape9T10 q11Shape9T13
private theorem q11Shape9T9OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741825 34575745024 q11Shape9T9=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741825 (34575745024 ||| 2^1) q11Shape9T10 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073741825 ||| 2^1) 34575745024 q11Shape9T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T10OK,q11Shape9T13OK⟩

private def q11Shape9T3 : Tree 11 := .split 0 q11Shape9T4 q11Shape9T9
private theorem q11Shape9T3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741824 34575745024 q11Shape9T3=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741824 (34575745024 ||| 2^0) q11Shape9T4 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073741824 ||| 2^0) 34575745024 q11Shape9T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T4OK,q11Shape9T9OK⟩

private def q11Shape9T20 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape9T20OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 35433480192 216006656 q11Shape9T20=true := by decide

private def q11Shape9T2 : Tree 11 := .split 35 q11Shape9T3 q11Shape9T20
private theorem q11Shape9T2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741824 216006656 q11Shape9T2=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1073741824 (216006656 ||| 2^35) q11Shape9T3 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (1073741824 ||| 2^35) 216006656 q11Shape9T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T3OK,q11Shape9T20OK⟩

private def q11Shape9T0 : Tree 11 := .split 30 q11Shape9T1 q11Shape9T2
private theorem q11Shape9T0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 216006656 q11Shape9T0=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 (216006656 ||| 2^30) q11Shape9T1 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (0 ||| 2^30) 216006656 q11Shape9T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T1OK,q11Shape9T2OK⟩

def q11Shape9P0 : Tree 11 := q11Shape9T0
theorem q11Shape9P0OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 0 216006656 q11Shape9P0=true := q11Shape9T0OK

end Graffiti384b.EffectiveSearch.Q11
