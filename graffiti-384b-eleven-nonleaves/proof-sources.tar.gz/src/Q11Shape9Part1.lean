import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape9T25 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7})))))
private theorem q11Shape9T25OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 35515269123 q11Shape9T25=true := by decide

private def q11Shape9T27 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T27OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217730 35515269377 q11Shape9T27=true := by decide

private def q11Shape9T28 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T28OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217986 35515269121 q11Shape9T28=true := by decide

private def q11Shape9T26 : Tree 11 := .split 8 q11Shape9T27 q11Shape9T28
private theorem q11Shape9T26OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217730 35515269121 q11Shape9T26=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217730 (35515269121 ||| 2^8) q11Shape9T27 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217730 ||| 2^8) 35515269121 q11Shape9T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T27OK,q11Shape9T28OK⟩

private def q11Shape9T24 : Tree 11 := .split 1 q11Shape9T25 q11Shape9T26
private theorem q11Shape9T24OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 35515269121 q11Shape9T24=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 (35515269121 ||| 2^1) q11Shape9T25 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217728 ||| 2^1) 35515269121 q11Shape9T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T25OK,q11Shape9T26OK⟩

private def q11Shape9T31 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T31OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217729 35515269378 q11Shape9T31=true := by decide

private def q11Shape9T32 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T32OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217985 35515269122 q11Shape9T32=true := by decide

private def q11Shape9T30 : Tree 11 := .split 8 q11Shape9T31 q11Shape9T32
private theorem q11Shape9T30OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217729 35515269122 q11Shape9T30=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217729 (35515269122 ||| 2^8) q11Shape9T31 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217729 ||| 2^8) 35515269122 q11Shape9T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T31OK,q11Shape9T32OK⟩

private def q11Shape9T34 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T34OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217731 35515269376 q11Shape9T34=true := by decide

private def q11Shape9T37 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape9T37OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217987 35515293696 q11Shape9T37=true := by decide

private def q11Shape9T38 : Tree 11 := (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape9T38OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134234371 35515277312 q11Shape9T38=true := by decide

private def q11Shape9T36 : Tree 11 := .split 14 q11Shape9T37 q11Shape9T38
private theorem q11Shape9T36OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217987 35515277312 q11Shape9T36=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217987 (35515277312 ||| 2^14) q11Shape9T37 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217987 ||| 2^14) 35515277312 q11Shape9T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T37OK,q11Shape9T38OK⟩

private def q11Shape9T39 : Tree 11 := (.split 14 (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7})))
private theorem q11Shape9T39OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134226179 35515269120 q11Shape9T39=true := by decide

private def q11Shape9T35 : Tree 11 := .split 13 q11Shape9T36 q11Shape9T39
private theorem q11Shape9T35OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217987 35515269120 q11Shape9T35=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217987 (35515269120 ||| 2^13) q11Shape9T36 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217987 ||| 2^13) 35515269120 q11Shape9T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T36OK,q11Shape9T39OK⟩

private def q11Shape9T33 : Tree 11 := .split 8 q11Shape9T34 q11Shape9T35
private theorem q11Shape9T33OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217731 35515269120 q11Shape9T33=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217731 (35515269120 ||| 2^8) q11Shape9T34 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217731 ||| 2^8) 35515269120 q11Shape9T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T34OK,q11Shape9T35OK⟩

private def q11Shape9T29 : Tree 11 := .split 1 q11Shape9T30 q11Shape9T33
private theorem q11Shape9T29OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217729 35515269120 q11Shape9T29=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217729 (35515269120 ||| 2^1) q11Shape9T30 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217729 ||| 2^1) 35515269120 q11Shape9T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T30OK,q11Shape9T33OK⟩

private def q11Shape9T23 : Tree 11 := .split 0 q11Shape9T24 q11Shape9T29
private theorem q11Shape9T23OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 35515269120 q11Shape9T23=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 (35515269120 ||| 2^0) q11Shape9T24 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217728 ||| 2^0) 35515269120 q11Shape9T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T24OK,q11Shape9T29OK⟩

private def q11Shape9T40 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape9T40OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 34493956096 1155530752 q11Shape9T40=true := by decide

private def q11Shape9T22 : Tree 11 := .split 35 q11Shape9T23 q11Shape9T40
private theorem q11Shape9T22OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 1155530752 q11Shape9T22=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 (1155530752 ||| 2^35) q11Shape9T23 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217728 ||| 2^35) 1155530752 q11Shape9T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T23OK,q11Shape9T40OK⟩

private def q11Shape9T41 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape9T41OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1207959552 81788928 q11Shape9T41=true := by decide

private def q11Shape9T21 : Tree 11 := .split 30 q11Shape9T22 q11Shape9T41
private theorem q11Shape9T21OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 81788928 q11Shape9T21=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 (81788928 ||| 2^30) q11Shape9T22 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (134217728 ||| 2^30) 81788928 q11Shape9T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T22OK,q11Shape9T41OK⟩

def q11Shape9P1 : Tree 11 := q11Shape9T21
theorem q11Shape9P1OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 134217728 81788928 q11Shape9P1=true := q11Shape9T21OK

end Graffiti384b.EffectiveSearch.Q11
