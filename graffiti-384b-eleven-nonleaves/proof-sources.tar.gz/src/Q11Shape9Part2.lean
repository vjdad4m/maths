import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape9T48 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8})))))
private theorem q11Shape9T48OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 35582377987 q11Shape9T48=true := by decide

private def q11Shape9T50 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T50OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108866 35582378241 q11Shape9T50=true := by decide

private def q11Shape9T51 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T51OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67109122 35582377985 q11Shape9T51=true := by decide

private def q11Shape9T49 : Tree 11 := .split 8 q11Shape9T50 q11Shape9T51
private theorem q11Shape9T49OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108866 35582377985 q11Shape9T49=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108866 (35582377985 ||| 2^8) q11Shape9T50 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108866 ||| 2^8) 35582377985 q11Shape9T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T50OK,q11Shape9T51OK⟩

private def q11Shape9T47 : Tree 11 := .split 1 q11Shape9T48 q11Shape9T49
private theorem q11Shape9T47OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 35582377985 q11Shape9T47=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 (35582377985 ||| 2^1) q11Shape9T48 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108864 ||| 2^1) 35582377985 q11Shape9T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T48OK,q11Shape9T49OK⟩

private def q11Shape9T54 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T54OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108865 35582378242 q11Shape9T54=true := by decide

private def q11Shape9T55 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T55OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67109121 35582377986 q11Shape9T55=true := by decide

private def q11Shape9T53 : Tree 11 := .split 8 q11Shape9T54 q11Shape9T55
private theorem q11Shape9T53OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108865 35582377986 q11Shape9T53=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108865 (35582377986 ||| 2^8) q11Shape9T54 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108865 ||| 2^8) 35582377986 q11Shape9T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T54OK,q11Shape9T55OK⟩

private def q11Shape9T57 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T57OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108867 35582378240 q11Shape9T57=true := by decide

private def q11Shape9T60 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape9T60OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67109123 35582402560 q11Shape9T60=true := by decide

private def q11Shape9T61 : Tree 11 := (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape9T61OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67125507 35582386176 q11Shape9T61=true := by decide

private def q11Shape9T59 : Tree 11 := .split 14 q11Shape9T60 q11Shape9T61
private theorem q11Shape9T59OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67109123 35582386176 q11Shape9T59=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67109123 (35582386176 ||| 2^14) q11Shape9T60 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67109123 ||| 2^14) 35582386176 q11Shape9T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T60OK,q11Shape9T61OK⟩

private def q11Shape9T62 : Tree 11 := (.split 14 (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8})))
private theorem q11Shape9T62OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67117315 35582377984 q11Shape9T62=true := by decide

private def q11Shape9T58 : Tree 11 := .split 13 q11Shape9T59 q11Shape9T62
private theorem q11Shape9T58OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67109123 35582377984 q11Shape9T58=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67109123 (35582377984 ||| 2^13) q11Shape9T59 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67109123 ||| 2^13) 35582377984 q11Shape9T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T59OK,q11Shape9T62OK⟩

private def q11Shape9T56 : Tree 11 := .split 8 q11Shape9T57 q11Shape9T58
private theorem q11Shape9T56OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108867 35582377984 q11Shape9T56=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108867 (35582377984 ||| 2^8) q11Shape9T57 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108867 ||| 2^8) 35582377984 q11Shape9T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T57OK,q11Shape9T58OK⟩

private def q11Shape9T52 : Tree 11 := .split 1 q11Shape9T53 q11Shape9T56
private theorem q11Shape9T52OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108865 35582377984 q11Shape9T52=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108865 (35582377984 ||| 2^1) q11Shape9T53 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108865 ||| 2^1) 35582377984 q11Shape9T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T53OK,q11Shape9T56OK⟩

private def q11Shape9T46 : Tree 11 := .split 0 q11Shape9T47 q11Shape9T52
private theorem q11Shape9T46OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 35582377984 q11Shape9T46=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 (35582377984 ||| 2^0) q11Shape9T47 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108864 ||| 2^0) 35582377984 q11Shape9T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T47OK,q11Shape9T52OK⟩

private def q11Shape9T63 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape9T63OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 34426847232 1222639616 q11Shape9T63=true := by decide

private def q11Shape9T45 : Tree 11 := .split 35 q11Shape9T46 q11Shape9T63
private theorem q11Shape9T45OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 1222639616 q11Shape9T45=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 (1222639616 ||| 2^35) q11Shape9T46 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108864 ||| 2^35) 1222639616 q11Shape9T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T46OK,q11Shape9T63OK⟩

private def q11Shape9T64 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape9T64OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1140850688 148897792 q11Shape9T64=true := by decide

private def q11Shape9T44 : Tree 11 := .split 30 q11Shape9T45 q11Shape9T64
private theorem q11Shape9T44OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 148897792 q11Shape9T44=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 (148897792 ||| 2^30) q11Shape9T45 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108864 ||| 2^30) 148897792 q11Shape9T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T45OK,q11Shape9T64OK⟩

private def q11Shape9T65 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape9T65OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 201326592 14680064 q11Shape9T65=true := by decide

private def q11Shape9T43 : Tree 11 := .split 27 q11Shape9T44 q11Shape9T65
private theorem q11Shape9T43OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 14680064 q11Shape9T43=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 (14680064 ||| 2^27) q11Shape9T44 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (67108864 ||| 2^27) 14680064 q11Shape9T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T44OK,q11Shape9T65OK⟩

def q11Shape9P2 : Tree 11 := q11Shape9T43
theorem q11Shape9P2OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 67108864 14680064 q11Shape9P2=true := q11Shape9T43OK

end Graffiti384b.EffectiveSearch.Q11
