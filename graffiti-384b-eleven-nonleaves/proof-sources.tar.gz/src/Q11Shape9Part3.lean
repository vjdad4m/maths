import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape9T73 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7})))))
private theorem q11Shape9T73OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 35641098243 q11Shape9T73=true := by decide

private def q11Shape9T75 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T75OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388610 35641098497 q11Shape9T75=true := by decide

private def q11Shape9T76 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T76OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388866 35641098241 q11Shape9T76=true := by decide

private def q11Shape9T74 : Tree 11 := .split 8 q11Shape9T75 q11Shape9T76
private theorem q11Shape9T74OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388610 35641098241 q11Shape9T74=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388610 (35641098241 ||| 2^8) q11Shape9T75 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388610 ||| 2^8) 35641098241 q11Shape9T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T75OK,q11Shape9T76OK⟩

private def q11Shape9T72 : Tree 11 := .split 1 q11Shape9T73 q11Shape9T74
private theorem q11Shape9T72OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 35641098241 q11Shape9T72=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 (35641098241 ||| 2^1) q11Shape9T73 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388608 ||| 2^1) 35641098241 q11Shape9T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T73OK,q11Shape9T74OK⟩

private def q11Shape9T79 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T79OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388609 35641098498 q11Shape9T79=true := by decide

private def q11Shape9T80 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T80OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388865 35641098242 q11Shape9T80=true := by decide

private def q11Shape9T78 : Tree 11 := .split 8 q11Shape9T79 q11Shape9T80
private theorem q11Shape9T78OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388609 35641098242 q11Shape9T78=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388609 (35641098242 ||| 2^8) q11Shape9T79 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388609 ||| 2^8) 35641098242 q11Shape9T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T79OK,q11Shape9T80OK⟩

private def q11Shape9T82 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7}))))
private theorem q11Shape9T82OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388611 35641098496 q11Shape9T82=true := by decide

private def q11Shape9T85 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape9T85OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388867 35641122816 q11Shape9T85=true := by decide

private def q11Shape9T86 : Tree 11 := (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,1,4,5,6,7}))))
private theorem q11Shape9T86OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8405251 35641106432 q11Shape9T86=true := by decide

private def q11Shape9T84 : Tree 11 := .split 14 q11Shape9T85 q11Shape9T86
private theorem q11Shape9T84OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388867 35641106432 q11Shape9T84=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388867 (35641106432 ||| 2^14) q11Shape9T85 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388867 ||| 2^14) 35641106432 q11Shape9T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T85OK,q11Shape9T86OK⟩

private def q11Shape9T87 : Tree 11 := (.split 14 (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,7,9,10}))) (.tip (.cover {0,1,4,5,6,7})))) (.tip (.cover {0,1,3,5,6,7})))
private theorem q11Shape9T87OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8397059 35641098240 q11Shape9T87=true := by decide

private def q11Shape9T83 : Tree 11 := .split 13 q11Shape9T84 q11Shape9T87
private theorem q11Shape9T83OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388867 35641098240 q11Shape9T83=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388867 (35641098240 ||| 2^13) q11Shape9T84 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388867 ||| 2^13) 35641098240 q11Shape9T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T84OK,q11Shape9T87OK⟩

private def q11Shape9T81 : Tree 11 := .split 8 q11Shape9T82 q11Shape9T83
private theorem q11Shape9T81OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388611 35641098240 q11Shape9T81=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388611 (35641098240 ||| 2^8) q11Shape9T82 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388611 ||| 2^8) 35641098240 q11Shape9T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T82OK,q11Shape9T83OK⟩

private def q11Shape9T77 : Tree 11 := .split 1 q11Shape9T78 q11Shape9T81
private theorem q11Shape9T77OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388609 35641098240 q11Shape9T77=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388609 (35641098240 ||| 2^1) q11Shape9T78 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388609 ||| 2^1) 35641098240 q11Shape9T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T78OK,q11Shape9T81OK⟩

private def q11Shape9T71 : Tree 11 := .split 0 q11Shape9T72 q11Shape9T77
private theorem q11Shape9T71OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 35641098240 q11Shape9T71=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 (35641098240 ||| 2^0) q11Shape9T72 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388608 ||| 2^0) 35641098240 q11Shape9T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T72OK,q11Shape9T77OK⟩

private def q11Shape9T88 : Tree 11 := (.tip (.cover {0,1,5,6,7,9}))
private theorem q11Shape9T88OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 34368126976 1281359872 q11Shape9T88=true := by decide

private def q11Shape9T70 : Tree 11 := .split 35 q11Shape9T71 q11Shape9T88
private theorem q11Shape9T70OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 1281359872 q11Shape9T70=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 (1281359872 ||| 2^35) q11Shape9T71 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388608 ||| 2^35) 1281359872 q11Shape9T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T71OK,q11Shape9T88OK⟩

private def q11Shape9T89 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape9T89OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1082130432 207618048 q11Shape9T89=true := by decide

private def q11Shape9T69 : Tree 11 := .split 30 q11Shape9T70 q11Shape9T89
private theorem q11Shape9T69OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 207618048 q11Shape9T69=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 (207618048 ||| 2^30) q11Shape9T70 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388608 ||| 2^30) 207618048 q11Shape9T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T70OK,q11Shape9T89OK⟩

private def q11Shape9T90 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape9T90OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 142606336 73400320 q11Shape9T90=true := by decide

private def q11Shape9T68 : Tree 11 := .split 27 q11Shape9T69 q11Shape9T90
private theorem q11Shape9T68OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 73400320 q11Shape9T68=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 (73400320 ||| 2^27) q11Shape9T69 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388608 ||| 2^27) 73400320 q11Shape9T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T69OK,q11Shape9T90OK⟩

private def q11Shape9T91 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape9T91OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 75497472 6291456 q11Shape9T91=true := by decide

private def q11Shape9T67 : Tree 11 := .split 26 q11Shape9T68 q11Shape9T91
private theorem q11Shape9T67OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 6291456 q11Shape9T67=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 (6291456 ||| 2^26) q11Shape9T68 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (8388608 ||| 2^26) 6291456 q11Shape9T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T68OK,q11Shape9T91OK⟩

def q11Shape9P3 : Tree 11 := q11Shape9T67
theorem q11Shape9P3OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 8388608 6291456 q11Shape9P3=true := q11Shape9T67OK

end Graffiti384b.EffectiveSearch.Q11
