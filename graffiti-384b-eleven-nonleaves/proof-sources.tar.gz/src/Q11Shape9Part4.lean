import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape9T100 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8})))))
private theorem q11Shape9T100OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 35645292547 q11Shape9T100=true := by decide

private def q11Shape9T102 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T102OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194306 35645292801 q11Shape9T102=true := by decide

private def q11Shape9T103 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T103OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194562 35645292545 q11Shape9T103=true := by decide

private def q11Shape9T101 : Tree 11 := .split 8 q11Shape9T102 q11Shape9T103
private theorem q11Shape9T101OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194306 35645292545 q11Shape9T101=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194306 (35645292545 ||| 2^8) q11Shape9T102 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194306 ||| 2^8) 35645292545 q11Shape9T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T102OK,q11Shape9T103OK⟩

private def q11Shape9T99 : Tree 11 := .split 1 q11Shape9T100 q11Shape9T101
private theorem q11Shape9T99OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 35645292545 q11Shape9T99=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 (35645292545 ||| 2^1) q11Shape9T100 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194304 ||| 2^1) 35645292545 q11Shape9T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T100OK,q11Shape9T101OK⟩

private def q11Shape9T106 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T106OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194305 35645292802 q11Shape9T106=true := by decide

private def q11Shape9T107 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T107OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194561 35645292546 q11Shape9T107=true := by decide

private def q11Shape9T105 : Tree 11 := .split 8 q11Shape9T106 q11Shape9T107
private theorem q11Shape9T105OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194305 35645292546 q11Shape9T105=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194305 (35645292546 ||| 2^8) q11Shape9T106 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194305 ||| 2^8) 35645292546 q11Shape9T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T106OK,q11Shape9T107OK⟩

private def q11Shape9T109 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8}))))
private theorem q11Shape9T109OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194307 35645292800 q11Shape9T109=true := by decide

private def q11Shape9T112 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape9T112OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194563 35645317120 q11Shape9T112=true := by decide

private def q11Shape9T113 : Tree 11 := (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8}))))
private theorem q11Shape9T113OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4210947 35645300736 q11Shape9T113=true := by decide

private def q11Shape9T111 : Tree 11 := .split 14 q11Shape9T112 q11Shape9T113
private theorem q11Shape9T111OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194563 35645300736 q11Shape9T111=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194563 (35645300736 ||| 2^14) q11Shape9T112 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194563 ||| 2^14) 35645300736 q11Shape9T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T112OK,q11Shape9T113OK⟩

private def q11Shape9T114 : Tree 11 := (.split 14 (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,6,8,9,10}))) (.tip (.cover {0,1,4,5,6,8})))) (.tip (.cover {0,1,3,5,6,8})))
private theorem q11Shape9T114OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4202755 35645292544 q11Shape9T114=true := by decide

private def q11Shape9T110 : Tree 11 := .split 13 q11Shape9T111 q11Shape9T114
private theorem q11Shape9T110OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194563 35645292544 q11Shape9T110=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194563 (35645292544 ||| 2^13) q11Shape9T111 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194563 ||| 2^13) 35645292544 q11Shape9T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T111OK,q11Shape9T114OK⟩

private def q11Shape9T108 : Tree 11 := .split 8 q11Shape9T109 q11Shape9T110
private theorem q11Shape9T108OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194307 35645292544 q11Shape9T108=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194307 (35645292544 ||| 2^8) q11Shape9T109 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194307 ||| 2^8) 35645292544 q11Shape9T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T109OK,q11Shape9T110OK⟩

private def q11Shape9T104 : Tree 11 := .split 1 q11Shape9T105 q11Shape9T108
private theorem q11Shape9T104OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194305 35645292544 q11Shape9T104=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194305 (35645292544 ||| 2^1) q11Shape9T105 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194305 ||| 2^1) 35645292544 q11Shape9T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T105OK,q11Shape9T108OK⟩

private def q11Shape9T98 : Tree 11 := .split 0 q11Shape9T99 q11Shape9T104
private theorem q11Shape9T98OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 35645292544 q11Shape9T98=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 (35645292544 ||| 2^0) q11Shape9T99 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194304 ||| 2^0) 35645292544 q11Shape9T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T99OK,q11Shape9T104OK⟩

private def q11Shape9T115 : Tree 11 := (.tip (.cover {0,1,5,6,8,9}))
private theorem q11Shape9T115OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 34363932672 1285554176 q11Shape9T115=true := by decide

private def q11Shape9T97 : Tree 11 := .split 35 q11Shape9T98 q11Shape9T115
private theorem q11Shape9T97OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 1285554176 q11Shape9T97=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 (1285554176 ||| 2^35) q11Shape9T98 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194304 ||| 2^35) 1285554176 q11Shape9T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T98OK,q11Shape9T115OK⟩

private def q11Shape9T116 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape9T116OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1077936128 211812352 q11Shape9T116=true := by decide

private def q11Shape9T96 : Tree 11 := .split 30 q11Shape9T97 q11Shape9T116
private theorem q11Shape9T96OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 211812352 q11Shape9T96=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 (211812352 ||| 2^30) q11Shape9T97 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194304 ||| 2^30) 211812352 q11Shape9T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T97OK,q11Shape9T116OK⟩

private def q11Shape9T117 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape9T117OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 138412032 77594624 q11Shape9T117=true := by decide

private def q11Shape9T95 : Tree 11 := .split 27 q11Shape9T96 q11Shape9T117
private theorem q11Shape9T95OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 77594624 q11Shape9T95=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 (77594624 ||| 2^27) q11Shape9T96 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194304 ||| 2^27) 77594624 q11Shape9T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T96OK,q11Shape9T117OK⟩

private def q11Shape9T118 : Tree 11 := (.tip (.cover {0,1,7,8,9,10}))
private theorem q11Shape9T118OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 71303168 10485760 q11Shape9T118=true := by decide

private def q11Shape9T94 : Tree 11 := .split 26 q11Shape9T95 q11Shape9T118
private theorem q11Shape9T94OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 10485760 q11Shape9T94=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 (10485760 ||| 2^26) q11Shape9T95 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194304 ||| 2^26) 10485760 q11Shape9T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T95OK,q11Shape9T118OK⟩

private def q11Shape9T119 : Tree 11 := (.tip (.cover {0,1,5,6,9,10}))
private theorem q11Shape9T119OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 12582912 2097152 q11Shape9T119=true := by decide

private def q11Shape9T93 : Tree 11 := .split 23 q11Shape9T94 q11Shape9T119
private theorem q11Shape9T93OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 2097152 q11Shape9T93=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 (2097152 ||| 2^23) q11Shape9T94 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (4194304 ||| 2^23) 2097152 q11Shape9T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T94OK,q11Shape9T119OK⟩

def q11Shape9P4 : Tree 11 := q11Shape9T93
theorem q11Shape9P4OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 4194304 2097152 q11Shape9P4=true := q11Shape9T93OK

end Graffiti384b.EffectiveSearch.Q11
