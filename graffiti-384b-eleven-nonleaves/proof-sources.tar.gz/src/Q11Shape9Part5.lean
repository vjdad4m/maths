import Q11GeometryBridge384b
import EffectiveSearchFast384b

namespace Graffiti384b.EffectiveSearch.Q11
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q11Shape9T129 : Tree 11 := (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8})))))
private theorem q11Shape9T129OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 35647389699 q11Shape9T129=true := by decide

private def q11Shape9T131 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape9T131OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097154 35647389953 q11Shape9T131=true := by decide

private def q11Shape9T132 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,8})))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape9T132OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097410 35647389697 q11Shape9T132=true := by decide

private def q11Shape9T130 : Tree 11 := .split 8 q11Shape9T131 q11Shape9T132
private theorem q11Shape9T130OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097154 35647389697 q11Shape9T130=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097154 (35647389697 ||| 2^8) q11Shape9T131 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097154 ||| 2^8) 35647389697 q11Shape9T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T131OK,q11Shape9T132OK⟩

private def q11Shape9T128 : Tree 11 := .split 1 q11Shape9T129 q11Shape9T130
private theorem q11Shape9T128OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 35647389697 q11Shape9T128=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (35647389697 ||| 2^1) q11Shape9T129 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^1) 35647389697 q11Shape9T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T129OK,q11Shape9T130OK⟩

private def q11Shape9T135 : Tree 11 := (.split 13 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape9T135OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097153 35647389954 q11Shape9T135=true := by decide

private def q11Shape9T136 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,8})))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape9T136OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097409 35647389698 q11Shape9T136=true := by decide

private def q11Shape9T134 : Tree 11 := .split 8 q11Shape9T135 q11Shape9T136
private theorem q11Shape9T134OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097153 35647389698 q11Shape9T134=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097153 (35647389698 ||| 2^8) q11Shape9T135 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097153 ||| 2^8) 35647389698 q11Shape9T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T135OK,q11Shape9T136OK⟩

private def q11Shape9T138 : Tree 11 := (.split 13 (.split 14 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,8}))))) (.split 14 (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,8})))) (.tip (.cover {0,1,3,5,7,8}))))
private theorem q11Shape9T138OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097155 35647389952 q11Shape9T138=true := by decide

private def q11Shape9T141 : Tree 11 := (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.tip (.cover {0,1,4,5,7,8}))))
private theorem q11Shape9T141OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097411 35647414272 q11Shape9T141=true := by decide

private def q11Shape9T142 : Tree 11 := (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,8}))))
private theorem q11Shape9T142OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2113795 35647397888 q11Shape9T142=true := by decide

private def q11Shape9T140 : Tree 11 := .split 14 q11Shape9T141 q11Shape9T142
private theorem q11Shape9T140OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097411 35647397888 q11Shape9T140=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097411 (35647397888 ||| 2^14) q11Shape9T141 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097411 ||| 2^14) 35647397888 q11Shape9T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T141OK,q11Shape9T142OK⟩

private def q11Shape9T143 : Tree 11 := (.split 14 (.split 19 (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10})))) (.split 20 (.split 6 (.tip (.small 1)) (.tip (.cover {0,5,7,8,9,10}))) (.tip (.cover {0,1,4,5,7,8})))) (.tip (.cover {0,1,3,5,7,8})))
private theorem q11Shape9T143OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2105603 35647389696 q11Shape9T143=true := by decide

private def q11Shape9T139 : Tree 11 := .split 13 q11Shape9T140 q11Shape9T143
private theorem q11Shape9T139OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097411 35647389696 q11Shape9T139=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097411 (35647389696 ||| 2^13) q11Shape9T140 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097411 ||| 2^13) 35647389696 q11Shape9T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T140OK,q11Shape9T143OK⟩

private def q11Shape9T137 : Tree 11 := .split 8 q11Shape9T138 q11Shape9T139
private theorem q11Shape9T137OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097155 35647389696 q11Shape9T137=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097155 (35647389696 ||| 2^8) q11Shape9T138 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097155 ||| 2^8) 35647389696 q11Shape9T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T138OK,q11Shape9T139OK⟩

private def q11Shape9T133 : Tree 11 := .split 1 q11Shape9T134 q11Shape9T137
private theorem q11Shape9T133OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097153 35647389696 q11Shape9T133=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097153 (35647389696 ||| 2^1) q11Shape9T134 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097153 ||| 2^1) 35647389696 q11Shape9T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T134OK,q11Shape9T137OK⟩

private def q11Shape9T127 : Tree 11 := .split 0 q11Shape9T128 q11Shape9T133
private theorem q11Shape9T127OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 35647389696 q11Shape9T127=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (35647389696 ||| 2^0) q11Shape9T128 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^0) 35647389696 q11Shape9T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T128OK,q11Shape9T133OK⟩

private def q11Shape9T144 : Tree 11 := (.tip (.cover {0,1,5,7,8,9}))
private theorem q11Shape9T144OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 34361835520 1287651328 q11Shape9T144=true := by decide

private def q11Shape9T126 : Tree 11 := .split 35 q11Shape9T127 q11Shape9T144
private theorem q11Shape9T126OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 1287651328 q11Shape9T126=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (1287651328 ||| 2^35) q11Shape9T127 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^35) 1287651328 q11Shape9T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T127OK,q11Shape9T144OK⟩

private def q11Shape9T145 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape9T145OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 1075838976 213909504 q11Shape9T145=true := by decide

private def q11Shape9T125 : Tree 11 := .split 30 q11Shape9T126 q11Shape9T145
private theorem q11Shape9T125OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 213909504 q11Shape9T125=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (213909504 ||| 2^30) q11Shape9T126 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^30) 213909504 q11Shape9T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T126OK,q11Shape9T145OK⟩

private def q11Shape9T146 : Tree 11 := (.tip (.cover {0,1,6,7,9,10}))
private theorem q11Shape9T146OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 136314880 79691776 q11Shape9T146=true := by decide

private def q11Shape9T124 : Tree 11 := .split 27 q11Shape9T125 q11Shape9T146
private theorem q11Shape9T124OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 79691776 q11Shape9T124=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (79691776 ||| 2^27) q11Shape9T125 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^27) 79691776 q11Shape9T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T125OK,q11Shape9T146OK⟩

private def q11Shape9T147 : Tree 11 := (.tip (.cover {0,1,6,8,9,10}))
private theorem q11Shape9T147OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 69206016 12582912 q11Shape9T147=true := by decide

private def q11Shape9T123 : Tree 11 := .split 26 q11Shape9T124 q11Shape9T147
private theorem q11Shape9T123OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 12582912 q11Shape9T123=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (12582912 ||| 2^26) q11Shape9T124 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^26) 12582912 q11Shape9T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T124OK,q11Shape9T147OK⟩

private def q11Shape9T148 : Tree 11 := (.tip (.cover {0,1,5,7,9,10}))
private theorem q11Shape9T148OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 10485760 4194304 q11Shape9T148=true := by decide

private def q11Shape9T122 : Tree 11 := .split 23 q11Shape9T123 q11Shape9T148
private theorem q11Shape9T122OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 4194304 q11Shape9T122=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (4194304 ||| 2^23) q11Shape9T123 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^23) 4194304 q11Shape9T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T123OK,q11Shape9T148OK⟩

private def q11Shape9T149 : Tree 11 := (.tip (.cover {0,1,5,8,9,10}))
private theorem q11Shape9T149OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 6291456 0 q11Shape9T149=true := by decide

private def q11Shape9T121 : Tree 11 := .split 22 q11Shape9T122 q11Shape9T149
private theorem q11Shape9T121OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 0 q11Shape9T121=true := by
  change (fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 (0 ||| 2^22) q11Shape9T122 &&
    fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) (2097152 ||| 2^22) 0 q11Shape9T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q11Shape9T122OK,q11Shape9T149OK⟩

def q11Shape9P5 : Tree 11 := q11Shape9T121
theorem q11Shape9P5OK : fastTreeOK (root (n:=11) (by decide)) (adj 11 ⟨false,7,5,3⟩) 2097152 0 q11Shape9P5=true := q11Shape9T121OK

end Graffiti384b.EffectiveSearch.Q11
