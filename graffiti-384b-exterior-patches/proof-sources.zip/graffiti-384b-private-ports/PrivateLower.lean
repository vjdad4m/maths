import ThinOutside
namespace Graffiti384b.Exterior
open Finset SimpleGraph
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A private triangle whose two exterior neighborhoods each see just one
local endpoint, even across one exterior edge, cannot use two exterior pins. -/
structure ThinTriangle (K : Finset V) (e a b x y : V) : Prop where
  ear : ∀i,G.Adj e i → i=a ∨ i=b
  anchor : ∀i,G.Adj a i → i=e ∨ i=b ∨ i=x ∨ i=y
  first : ∀i∈K,G.Adj x i → i=a ∨ i=y
  second : ∀i∈K,G.Adj y i → i=a ∨ i=x
  interface : ∀u∉K,∀k∈({x,y}:Finset V),G.Adj u k →
    (∀i∈K,G.Adj u i → i=k) ∧ (∀v∉K,G.Adj u v → ∀i∈K,G.Adj v i → i=k)

private theorem private_left {K P Q : Finset V} {e a b x y : V} (T : ThinTriangle G K e a b x y)
    (cut : Protected G P Q) (budget : ((P∪Q)\K).card≤2) (ear : e∈P) : False := by
  have flip : Protected G Q P := ⟨cut.1.symm,cut.2.2,cut.2.1⟩
  have rev : ((Q∪P)\K).card≤2 := by simpa only [union_comm Q P] using budget
  have confined (k : V) (km : k∈({x,y}:Finset V)) (i : V) (im : i∈P∪Q) (ki : G.Adj k i) : i∈K := by
    by_contra ext
    obtain ⟨own,next⟩ := T.interface i ext k km ki.symm
    exact (mem_union.mp im).elim (thin_outside G cut budget ext own next) (thin_outside G flip rev ext own next)
  have A := forces_pair G (x:=a) (y:=b) (cut.2.1 e ear) (fun i _ => T.ear i)
  have notA : (a:V)∉P := fun m => disjoint_left.mp cut.1 m A.1
  have pairX (i : V) (im : i∈P∪Q) (adj : G.Adj x i) : i=a ∨ i=y :=
    T.first i (confined x (mem_insert_self ..) i im adj) adj
  have pairY (i : V) (im : i∈P∪Q) (adj : G.Adj y i) : i=a ∨ i=x :=
    T.second i (confined y (mem_insert_of_mem (mem_singleton_self _)) i im adj) adj
  have noX (m : (x:V)∈P) : False := by
    have five := (forces_pair G (cut.2.1 x m) (fun i h => pairX i (mem_union_right _ h))).2
    exact notA (forces_pair G (cut.2.2 y five) (fun i h => pairY i (mem_union_left _ h))).1
  have noY (m : (y:V)∈P) : False := by
    have four := (forces_pair G (cut.2.1 y m) (fun i h => pairY i (mem_union_right _ h))).2
    exact notA (forces_pair G (cut.2.2 x four) (fun i h => pairX i (mem_union_left _ h))).1
  have few : P.filter (G.Adj a)⊆{e} := by
    intro i im
    obtain ⟨ip,edge⟩ := mem_filter.mp im
    rcases T.anchor i edge with rfl|rfl|rfl|rfl
    · exact mem_singleton_self _
    · exact (disjoint_left.mp cut.1 ip A.2).elim
    · exact (noX ip).elim
    · exact (noY ip).elim
  have lower := cut.2.2 a A.1
  change 2≤(P.filter (G.Adj a)).card at lower
  have upper := card_le_card few
  rw [card_singleton] at upper
  omega

theorem at_least_three {K P Q : Finset V} {e a b x y : V} (T : ThinTriangle G K e a b x y)
    (cut : Protected G P Q) (ear : e∈P∪Q) : 3≤((P∪Q)\K).card := by
  by_contra! small
  have cap : ((P∪Q)\K).card≤2 := by omega
  rcases mem_union.mp ear with l|r
  · exact private_left G T cut cap l
  · exact private_left G T (P:=Q) (Q:=P) ⟨cut.1.symm,cut.2.2,cut.2.1⟩ (by simpa only [union_comm Q P] using cap) r
end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.at_least_three
