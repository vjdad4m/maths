import ThreeSharp
import SixObstruction
import ForkPatch
import UnconditionalPorts
namespace Graffiti384b.Exterior.Three
open Finset SimpleGraph Four29 LowSample FiveChoice
namespace Earlier
abbrev graph := FiveChoice.Obstruction.graph
end Earlier

/-- The entire induced twelve-vertex patch agrees with the frozen example,
including every absent edge. Only its exterior has been changed. -/
theorem same_patch : localVertices=FiveChoice.Obstruction.localVertices ∧
    ∀i∈localVertices,∀j∈localVertices,graph.Adj i j ↔ Earlier.graph.Adj i j := by
  rw [localVertices,roots_eq,contacts_eq,FiveChoice.Obstruction.localVertices,
    FiveChoice.Obstruction.roots_eq,FiveChoice.Obstruction.contacts_eq]
  decide

/-- Every possible choice of extra points has the same four restricted
anchor scores in the two graphs, even if points outside the patch are chosen. -/
theorem carrier_iff (X : Finset V) : supports graph 27 28 X ↔ contacts⊆X := by
  have root : roots graph 27 28=roots Earlier.graph 27 28 := roots_eq.trans FiveChoice.Obstruction.roots_eq.symm
  have equal : ∀i∈roots graph 27 28,link graph i=link Earlier.graph i := by rw [roots_eq]; decide
  have fixed : base graph 27 28=base Earlier.graph 27 28 := by simp only [base,root]
  have eq (v : V) (vm : v∈roots graph 27 28) : score graph 27 28 X v=score Earlier.graph 27 28 X v := by
    simp only [score,equal v vm,fixed]
  have same : supports graph 27 28 X ↔ supports Earlier.graph 27 28 X := by
    unfold supports
    rw [←root]
    constructor
    · rintro ⟨small,v,vr,high⟩
      exact ⟨fun i ir => (eq i ir) ▸ small i ir,v,vr,(eq v vr) ▸ high⟩
    · rintro ⟨small,v,vr,high⟩
      exact ⟨fun i ir => (eq i ir).symm ▸ small i ir,v,vr,(eq v vr).symm ▸ high⟩
  exact same.trans (FiveChoice.Obstruction.carrier_iff X)

private def points : Fin 6 ↪ V :=
  ⟨![0,1,2,3,27,28],by decide⟩

theorem fork_example : gamma graph≤bound graph := by
  apply fork_patch graph diversity degrees.1 degrees.2.1 points (x:=4) (y:=5)
  · decide
  · decide
  · decide
  · decide
  all_goals first | rw [show points 4=(27:V) from rfl,show points 5=(28:V) from rfl,roots_eq]; decide
                  | rw [show points 4=(27:V) from rfl,show points 5=(28:V) from rfl,contacts_eq]; decide
                  | decide

theorem earlier_fork : gamma Earlier.graph≤bound Earlier.graph := by
  apply fork_patch Earlier.graph FiveChoice.Obstruction.diversity FiveChoice.Obstruction.degrees.1
    FiveChoice.Obstruction.degrees.2.1 points (x:=4) (y:=5)
  · decide
  · decide
  · decide
  · decide
  all_goals first | rw [show points 4=(27:V) from rfl,show points 5=(28:V) from rfl,FiveChoice.Obstruction.roots_eq]; decide
                  | rw [show points 4=(27:V) from rfl,show points 5=(28:V) from rfl,FiveChoice.Obstruction.contacts_eq]; decide
                  | decide
end Graffiti384b.Exterior.Three
#print axioms Graffiti384b.Exterior.Three.same_patch
#print axioms Graffiti384b.Exterior.Three.fork_example
#print axioms Graffiti384b.Exterior.Three.earlier_fork
#print axioms Graffiti384b.Exterior.Three.carrier_iff
