import PortFrames
namespace Graffiti384b.Exterior
open Finset SimpleGraph
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- If a side supplies two neighbors from a pair, both must be present. -/
theorem forces_pair {P : Finset V} {r x y : V} (two : 2≤nbr G r P)
    (only : ∀v∈P,G.Adj r v → v=x ∨ v=y) : x∈P ∧ y∈P := by
  have inc : P.filter (G.Adj r)⊆{x,y} := by
    intro v vm
    simpa only [mem_insert,mem_singleton] using only v (mem_filter.mp vm).1 (mem_filter.mp vm).2
  have eq := eq_of_subset_of_card_le inc ((card_le_two (a:=x) (b:=y)).trans two)
  exact ⟨(mem_filter.mp (eq.symm ▸ mem_insert_self x {y})).1,(mem_filter.mp (eq.symm ▸ mem_insert_of_mem (mem_singleton_self y))).1⟩

/-- With at most two exterior pins, an exterior edge needs opposite local
neighbors. A private endpoint for which both ends can only see the same
local vertex cannot be used. -/
theorem thin_outside {K P Q : Finset V} {u k : V} (cut : Protected G P Q)
    (budget : ((P∪Q)\K).card≤2) (outside : u∉K)
    (single : ∀i∈K,G.Adj u i → i=k)
    (next : ∀v∉K,G.Adj u v → ∀i∈K,G.Adj v i → i=k) : u∉P := by
  intro up
  obtain ⟨j,jm,l,lm,jl⟩ := one_lt_card.mp (cut.2.1 u up)
  have newv : ∃v∈Q,v∉K ∧ G.Adj u v := by
    by_cases jK : j∈K
    · have lK : l∉K := fun h => jl ((single j jK (mem_filter.mp jm).2).trans (single l h (mem_filter.mp lm).2).symm)
      exact ⟨l,(mem_filter.mp lm).1,lK,(mem_filter.mp lm).2⟩
    · exact ⟨j,(mem_filter.mp jm).1,jK,(mem_filter.mp jm).2⟩
  obtain ⟨v,vq,vout,uv⟩ := newv
  have ins : ({u,v}:Finset V)⊆(P∪Q)\K := insert_subset
    (mem_sdiff.mpr ⟨mem_union_left _ up,outside⟩) (singleton_subset_iff.mpr (mem_sdiff.mpr ⟨mem_union_right _ vq,vout⟩))
  have eq := (eq_of_subset_of_card_le ins (by rw [card_pair uv.ne]; exact budget)).symm
  have inPair (i : V) (m : i∈P∪Q) (o : i∉K) : i=u ∨ i=v := by
    have mem : i∈(P∪Q)\K := mem_sdiff.mpr ⟨m,o⟩
    simpa only [eq,mem_insert,mem_singleton] using mem
  have kq := (forces_pair G (x:=k) (y:=v) (cut.2.1 u up) (fun i iq ui => by
    by_cases h : i∈K
    · exact Or.inl (single i h ui)
    · exact Or.inr ((inPair i (mem_union_right _ iq) h).resolve_left ui.ne.symm))).1
  have kp := (forces_pair G (x:=k) (y:=u) (cut.2.2 v vq) (fun i ip vi => by
    by_cases h : i∈K
    · exact Or.inl (next v vout uv i h vi)
    · exact Or.inr ((inPair i (mem_union_left _ ip) h).resolve_right vi.ne.symm))).1
  exact disjoint_left.mp cut.1 kp kq
end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.thin_outside
