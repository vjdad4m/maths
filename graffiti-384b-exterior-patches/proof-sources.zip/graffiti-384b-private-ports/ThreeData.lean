import PrivatePorts
import FiveData
namespace Graffiti384b.Exterior.Three
open Finset SimpleGraph Four29 LowSample FiveChoice
abbrev V := Fin 29

/-- Row i of the symmetric adjacency matrix, with the least significant
bit representing vertex 0. Vertices 27 and 28 are the two ears. -/
private def rows : V → ℕ := ![134217778,134218701,268436418,268436162,7201,122897,16778126,125829710,117441094,109052366,8128528,267280,1968144,8355872,8323104,1646624,7790624,39677952,133921792,131527680,128971776,64316416,45048832,125567616,112984512,100533120,60556160,3,12]
private def adj (i j : V) : Prop := (rows i).testBit j.val=true
instance : DecidableRel adj := fun i j => inferInstanceAs (Decidable ((rows i).testBit j.val=true))
set_option maxRecDepth 65536
set_option maxHeartbeats 0
def graph : SimpleGraph V where
  Adj := adj
  symm := fun {i j} h => (show ∀a b:V,adj a b → adj b a by decide) i j h
  loopless := by exact (show ∀i:V,¬adj i i by decide)
instance : DecidableRel graph.Adj := inferInstanceAs (DecidableRel adj)

def localVertices : Finset V := roots graph 27 28 ∪ triangleContacts graph 27 28 ∪ {27,28}
def seed : Finset V := {0,2,3,11,16,19,25,27}

def scores : V → ℕ := ![2,13,9,6,3,5,14,19,12,20,10,4,8,22,18,7,23,25,52,38,44,27,28,29,26,36,24,1,0]

theorem score_table (v : V) : trianglesAt graph v=scores v := by
  rw [←Four29.FiveWitness.ordered_card graph]
  exact (show ∀i:V,(Four29.FiveWitness.ordered graph i).card=scores i by decide) v

private def parent : V → V := ![0,0,1,1,0,0,1,1,1,1,4,4,4,5,5,5,5,12,10,10,10,10,10,7,6,7,7,0,2]

theorem connected : graph.Connected := by
  have tree : ∀i:V,i=parent i ∨ graph.Adj i (parent i) := by decide
  have root : ∀i:V,parent (parent (parent i))=0 := by decide
  have step (v : V) : graph.Reachable v (parent v) :=
    (tree v).elim (fun eq => eq ▸ Reachable.refl _) (fun edge => edge.reachable)
  apply (connected_iff_exists_forall_reachable graph).mpr
  refine ⟨0,fun v => ?_⟩
  have path := (step v).trans ((step (parent v)).trans (step (parent (parent v))))
  rw [root v] at path
  exact path.symm

theorem diversity : (types graph).card=29 := by rw [types,funext score_table]; decide
theorem degrees : (nonleaves graph).card=29 ∧ (high graph).card=27 ∧ twos graph={27,28} ∧
    graph.neighborFinset 27={0,1} ∧ graph.neighborFinset 28={2,3} := by decide
theorem roots_eq : roots graph 27 28={0,1,2,3} := by rw [roots,degrees.2.2.2.1,degrees.2.2.2.2]; decide

def contacts : Finset V := {4,5,6,7,8,9}
theorem contacts_eq : triangleContacts graph 27 28=contacts := by unfold triangleContacts; rw [roots_eq]; decide
theorem exposures : (Donor.exposed graph (pool graph 27 28)).card=6 ∧ (twice graph (pool graph 27 28)).card≤6 := by decide

theorem fixed_partners :
    Repair.linkSupport graph 0\base graph 27 28={4,5} ∧
    Repair.linkSupport graph 1\base graph 27 28={6,7,8,9} := by decide

theorem feasible : gamma graph≤8 ∧ gamma graph≤bound graph := by
  have good : TwoDominates graph seed := by unfold TwoDominates; decide
  have le : gamma graph≤seed.card := Nat.sInf_le ⟨seed,good,rfl⟩
  have cnt : seed.card=8 := by decide
  rw [cnt] at le
  exact ⟨le,by rw [bound,diversity]; change _≤14; omega⟩
def leftBase : Finset V := {0,1,28}
def rightBase : Finset V := {27,2,3}
def arms : Finset V := {4,5}
def further : Finset V := pool graph 27 28\arms

theorem port_geometry : Ports graph leftBase rightBase arms further 0 := by
  constructor
  · constructor <;> decide
  all_goals decide

theorem loss : ∀p∈arms,trianglesAt graph p≤(kept (link graph p) (pool graph 27 28)).card+1 := by
  intro p pm; rw [score_table]; exact (show ∀i∈arms,scores i≤(kept (link graph i) (pool graph 27 28)).card+1 by decide) p pm

theorem private_solution : gamma graph≤bound graph := by
  apply private_branch graph diversity degrees.1 degrees.2.1 (e:=27) (f:=28) (a:=0) (x:=4) (y:=5)
    (by decide) (by decide) (by decide) leftBase rightBase (by decide) (by decide) (by decide) (by decide)
    (by rw [score_table]; decide) port_geometry (by decide) (by decide) loss
  rw [contacts_eq]; decide

theorem three_pins_exist :
    Protected graph ({0,1,28,10,13}:Finset V) {27,2,3,4,5,18} ∧
    ((({0,1,28,10,13}:Finset V) ∪ {27,2,3,4,5,18}) \ localVertices).card=3 := by
  rw [localVertices,roots_eq,contacts_eq]
  unfold Protected
  decide
end Graffiti384b.Exterior.Three
#print axioms Graffiti384b.Exterior.Three.connected
#print axioms Graffiti384b.Exterior.Three.score_table
#print axioms Graffiti384b.Exterior.Three.contacts_eq
#print axioms Graffiti384b.Exterior.Three.fixed_partners
#print axioms Graffiti384b.Exterior.Three.feasible
#print axioms Graffiti384b.Exterior.Three.private_solution
#print axioms Graffiti384b.Exterior.Three.three_pins_exist
