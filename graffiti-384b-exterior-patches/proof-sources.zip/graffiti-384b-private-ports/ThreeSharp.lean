import ThreeData
import PrivateLower
import PrivatePatch
namespace Graffiti384b.Exterior.Three
open Finset SimpleGraph Four29 LowSample

private theorem frame_eq : localVertices={0,1,2,3,4,5,6,7,8,9,27,28} := by
  rw [localVertices,roots_eq,contacts_eq]; decide

private theorem thin : ThinTriangle graph localVertices 27 0 1 4 5 := by
  rw [frame_eq]
  constructor <;> decide

theorem minimum_outside : IsLeast {n : ℕ | ∃P Q:Finset V,((P∪Q)\localVertices).card=n ∧
    Protected graph P Q ∧ twos graph⊆P∪Q} 3 := by
  constructor
  · refine ⟨{0,1,28,10,13},{27,2,3,4,5,18},three_pins_exist.2,three_pins_exist.1,?_⟩
    rw [degrees.2.2.1]; decide
  · rintro n ⟨P,Q,count,good,cover⟩
    rw [←count]
    exact at_least_three graph thin good (cover (degrees.2.2.1 ▸ mem_insert_self (27:V) {28}))

theorem local_shape_solution : gamma graph≤bound graph := by
  apply patch_solution graph diversity degrees.1 degrees.2.1 (e:=27) (f:=28) (a:=0) (x:=4) (y:=5)
    (by decide) (by decide) (by decide) leftBase rightBase (by decide) (by decide) (by decide)
    (by rw [roots_eq]; decide) (by rw [score_table]; decide) port_geometry (by decide) (by decide)
  · rw [roots_eq]; decide
  · rw [contacts_eq]; decide

theorem sharp_profile : graph.Connected ∧ (types graph).card=29 ∧ (nonleaves graph).card=29 ∧
    (high graph).card=27 ∧ (triangleContacts graph 27 28).card=6 ∧
    (Donor.exposed graph (pool graph 27 28)).card=6 ∧ gamma graph≤8 := by
  refine ⟨connected,diversity,degrees.1,degrees.2.1,?_,exposures.1,feasible.1⟩
  rw [contacts_eq]; decide
end Graffiti384b.Exterior.Three
#print axioms Graffiti384b.Exterior.Three.minimum_outside
#print axioms Graffiti384b.Exterior.Three.sharp_profile
#print axioms Graffiti384b.Exterior.Three.local_shape_solution
