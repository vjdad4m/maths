import ChoiceTight
namespace Graffiti384b.FiveChoice
open Finset SimpleGraph Four29
open private Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- At another anchor, charge the triangles using the tight anchor, either ear,
or any pool point forced by the tight anchor. -/
def charged (e f a v : V) (R : Finset V) :=
  (link G v).filter (fun p => ∃z∈p,z∈({a,e,f}:Finset V)∪R)

/-- Only two other fixed anchors can participate in the uncharged triangles. -/
theorem competition_bound {e f a v : V} (ar : a∈roots G e f) (vr : v∈roots G e f) (va : v≠a)
    (four : (roots G e f).card=4) (R X : Finset V) (inc : R⊆X) :
    score G e f X v≤(charged G e f a v R).card+(2+(X.card-R.card)).choose 2 := by
  classical
  let C := ((roots G e f).erase a).erase v
  let available := C∪(X\R)
  have vc : v∈(roots G e f).erase a := mem_erase.mpr ⟨va,vr⟩
  have cs : C.card=2 := by dsimp only [C]; rw [card_erase_of_mem vc,card_erase_of_mem ar,four]
  have bound : available.card≤2+(X.card-R.card) := by
    have cap := card_union_le C (X\R); simpa only [available,cs,card_sdiff inc] using cap
  have cover : kept (link G v) (base G e f∪X) ⊆ charged G e f a v R ∪ available.powersetCard 2 := by
    intro p pm
    obtain ⟨pl,sub⟩ := mem_filter.mp pm
    by_cases hit : ∃z∈p,z∈({a,e,f}:Finset V)∪R
    · exact mem_union_left _ (mem_filter.mpr ⟨pl,hit⟩)
    refine mem_union_right _ (mem_powersetCard.mpr ⟨?_,link_two G v p pl⟩)
    intro z zm
    have notin : z∉({a,e,f}:Finset V)∪R := fun m => hit ⟨z,zm,m⟩
    simp only [mem_union,mem_insert,mem_singleton,not_or] at notin
    have zv : z≠v := ((G.mem_neighborFinset ..).mp ((Repair.edge_info G pl).1 zm)).ne.symm
    rcases mem_union.mp (sub zm) with original|out
    · rcases mem_union.mp original with root|ear
      · exact mem_union_left _ (mem_erase.mpr ⟨zv,mem_erase.mpr ⟨notin.1.1,root⟩⟩)
      · simp only [mem_insert,mem_singleton] at ear
        exact (ear.elim notin.1.2.1 notin.1.2.2).elim
    · exact mem_union_right _ (mem_sdiff.mpr ⟨out,notin.2⟩)
  have size := (card_le_card cover).trans (card_union_le _ _)
  rw [card_powersetCard] at size
  exact size.trans (Nat.add_le_add_left (Nat.choose_le_choose 2 bound) _)

/-- For any number of contacts, two mandatory points at a two-triangle
anchor preclude the five-point test if the other anchors have at most two
charged triangles apiece. -/
theorem no_five_of_competition {e f a : V} (ar : a∈roots G e f) (four : (roots G e f).card=4)
    (tight : trianglesAt G a=2) (R : Finset V) (two : R.card=2)
    (force : R⊆Repair.linkSupport G a\base G e f)
    (low : ∀v∈roots G e f,v≠a → (charged G e f a v R).card≤2) :
    ∀X:Finset V,X.card≤5 → ¬supports G e f X := by
  intro X five wins
  have required := (full_score_iff G e f X a).mp
    (Nat.le_antisymm (score_le_global G ..) (tight ▸ wins.1 a ar))
  obtain ⟨v,vr,high⟩ := wins.2
  have va : v≠a := by
    intro eq; subst v; have cap := score_le_global G e f X a; omega
  have small := competition_bound G ar vr va four R X (force.trans required)
  have cap := Nat.choose_le_choose 2 (by omega : 2+(X.card-R.card)≤5)
  have price := low v vr va
  have ten : (5:ℕ).choose 2=10 := by decide
  omega
end Graffiti384b.FiveChoice
#print axioms Graffiti384b.FiveChoice.competition_bound
#print axioms Graffiti384b.FiveChoice.no_five_of_competition
