import ChoicePatch
namespace Graffiti384b.FiveChoice
open Finset SimpleGraph LowSample EarFrame33
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
/-- Add the second ear to an existing protected frame. Its two anchors may
already be pinned on the opposite side. -/
theorem attach_ear {P Q : Finset V} (frame : Frame G P Q) {f c d : V}
    (cd : c≠d) (fc : G.Adj f c) (fd : G.Adj f d)
    (fresh : f∉P∪Q) (cp : c∉P) (dp : d∉P)
    (touch : ∀w∈({c,d}:Finset V),∃x∈P,G.Adj w x) :
    Frame G (insert f P) (Q∪{c,d}) := by
  have fp : f∉P := fun m => fresh (mem_union_left _ m)
  have fq : f∉Q := fun m => fresh (mem_union_right _ m)
  have cQ : c∈Q∪({c,d}:Finset V) := mem_union_right _ (mem_insert_self ..)
  have dQ : d∈Q∪({c,d}:Finset V) := mem_union_right _ (mem_insert_of_mem (mem_singleton_self _))
  refine ⟨?_,?_,?_⟩
  · apply disjoint_left.mpr
    intro v vl vr
    rcases mem_insert.mp vl with rfl|vp
    · rcases mem_union.mp vr with x|x
      · exact fq x
      · rcases mem_insert.mp x with eq|singleton
        · exact fc.ne eq
        · exact fd.ne (mem_singleton.mp singleton)
    · rcases mem_union.mp vr with x|x
      · exact disjoint_left.mp frame.1 vp x
      · rcases mem_insert.mp x with rfl|singleton
        · exact cp vp
        · exact dp (mem_singleton.mp singleton ▸ vp)
  · intro v vm
    rcases mem_insert.mp vm with rfl|vp
    · exact PinnedColor34.two G cd fc fd cQ dQ
    · exact (frame.2.1 v vp).trans (Repair.nbr_mono G v subset_union_left)
  · intro v vm
    rcases mem_union.mp vm with vq|vw
    · exact (frame.2.2 v vq).trans (Repair.nbr_mono G v (subset_insert ..))
    · obtain ⟨x,xp,adj⟩ := touch v vw
      have near : G.Adj v f := (mem_insert.mp vw).elim
        (fun eq => eq ▸ fc.symm) (fun eq => mem_singleton.mp eq ▸ fd.symm)
      have fx : f≠x := by intro eq; subst x; exact fp xp
      exact PinnedColor34.two G fx near adj (mem_insert_self ..) (mem_insert_of_mem xp)

/-- A frame carrying one ear can use vertices anywhere in the graph.
Seeing the same shore from both other anchors suffices. -/
theorem frame_solution {P Q : Finset V} (frame : Frame G P Q) {e f c d : V}
    (quota : (types G).card≤(nonleaves G).card) (ears : ∀v∈twos G,v=e ∨ v=f)
    (first : e∈P∪Q) (cd : c≠d) (fc : G.Adj f c) (fd : G.Adj f d)
    (fresh : f∉P∪Q) (cp : c∉P) (dp : d∉P) (touch : ∀w∈({c,d}:Finset V),∃x∈P,G.Adj w x) :
    gamma G≤bound G := by
  have more := attach_ear G frame cd fc fd fresh cp dp touch
  apply PinnedColor34.complete G more.1 quota ?_ more.2.1 more.2.2
  intro v vn vl vr
  by_contra! small
  have low : v∈twos G := mem_sdiff.mpr ⟨vn,fun m => (not_le_of_gt small) (mem_filter.mp m).2⟩
  rcases ears v low with rfl|rfl
  · exact (mem_union.mp first).elim (fun m => vl (mem_insert_of_mem m)) (fun m => vr (mem_union_left _ m))
  · exact vl (mem_insert_self ..)
end Graffiti384b.FiveChoice
#print axioms Graffiti384b.FiveChoice.attach_ear
#print axioms Graffiti384b.FiveChoice.frame_solution
