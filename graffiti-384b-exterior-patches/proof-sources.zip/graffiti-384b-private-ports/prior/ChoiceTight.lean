import ChoicePatch
namespace Graffiti384b.FiveChoice
open Finset SimpleGraph Four29
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem score_le_global (e f : V) (X : Finset V) (v : V) : score G e f X v≤trianglesAt G v :=
  card_le_card (filter_subset ..)

theorem score_mono (e f : V) {X Y : Finset V} (inc : X⊆Y) (v : V) : score G e f X v≤score G e f Y v :=
  card_le_card (kept_mono (union_subset_union_right inc))

/-- An anchor attains its full score precisely when every triangle partner
outside the fixed four anchors and two ears is among the chosen points. -/
theorem full_score_iff (e f : V) (X : Finset V) (v : V) :
    score G e f X v=trianglesAt G v ↔ Repair.linkSupport G v\base G e f⊆X := by
  classical
  let F := link G v
  change (kept F (base G e f∪X)).card=F.card ↔ _
  constructor
  · intro eq
    have all : kept F (base G e f∪X)=F := eq_of_subset_of_card_le (filter_subset ..) eq.ge
    intro x xm
    obtain ⟨p,pe,px⟩ := mem_biUnion.mp (mem_sdiff.mp xm).1
    have stay : p∈kept F (base G e f∪X) := by rw [all]; exact pe
    exact (mem_union.mp ((mem_filter.mp stay).2 px)).resolve_left (mem_sdiff.mp xm).2
  · intro inc
    have all : kept F (base G e f∪X)=F := by
      apply filter_true_of_mem
      intro p pm x xm
      by_cases fixed : x∈base G e f
      · exact mem_union_left _ fixed
      · exact mem_union_right _ (inc (mem_sdiff.mpr ⟨mem_biUnion.mpr ⟨p,pm,xm⟩,fixed⟩))
    rw [all]

def supports (e f : V) (X : Finset V) :=
  (∀v∈roots G e f,2≤score G e f X v) ∧ ∃a∈roots G e f,13≤score G e f X a

/-- Partners of all anchors exactly at their quota must fit simultaneously.
The distinguished anchor may differ between admissible choices. -/
theorem compulsory (e f : V) (X : Finset V) (win : supports G e f X) :
    ∃a∈roots G e f,13≤trianglesAt G a ∧
    (∀v∈roots G e f,trianglesAt G v=(if v=a then 13 else 2) →
      Repair.linkSupport G v\base G e f⊆X) := by
  obtain ⟨a,ar,large⟩ := win.2
  refine ⟨a,ar,large.trans (score_le_global G ..),?_⟩
  intro v vm eq; apply (full_score_iff G ..).mp
  apply Nat.le_antisymm (score_le_global G ..)
  by_cases same : v=a
  · subst v; rw [if_pos rfl] at eq; simpa only [eq] using large
  · rw [eq,if_neg same]; exact win.1 v vm
end Graffiti384b.FiveChoice
#print axioms Graffiti384b.FiveChoice.full_score_iff
#print axioms Graffiti384b.FiveChoice.compulsory
