"""Replay simultaneous five-point selection and the exact six-contact obstruction."""
import argparse
from hashlib import sha256
import os
from pathlib import Path
import re
import subprocess
import tempfile

HERE=Path(__file__).resolve().parent
MATHLIB="c44e0c8ee63ca166450922a373c7409c5d26b00b"
ALLOWED={"propext","Classical.choice","Quot.sound"}
def digest(f):
    return sha256(f.read_bytes()).hexdigest()
def manifest(p):
    return {name:digest for digest,name in (line.split() for line in p.read_text().splitlines())}
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    modes=parser.add_mutually_exclusive_group()
    modes.add_argument("--cold",action="store_true",help="rebuild all project sources (default)")
    modes.add_argument("--checked",metavar="WORKSPACE",type=Path,help="reuse only the listed hash-verified predecessor objects")
    parser.add_argument("--resume-from",type=Path,metavar="STRICT_STAGE",help="reuse completed fresh modules with identical extracted sources, logs and independent object hashes")
    args=parser.parse_args()
    if args.resume_from and not args.checked:parser.error("--resume-from requires --checked")
    reference=manifest(HERE/"FRESH-OBJECTS.sha256") if args.resume_from else {}
    env=os.environ.copy()
    deps=HERE.parent/"graff384b-codex/.deps"
    lean=Path(env.get("CHOICE_LEAN_BIN",deps/"lean-4.19.0-linux/bin")).resolve()
    ml=Path(env.get("CHOICE_MATHLIB",deps/"mathlib4")).resolve()
    env["PATH"]=str(lean)+os.pathsep+env["PATH"]
    version=subprocess.check_output([lean/"lean","--version"],text=True).strip()
    assert "version 4.19.0," in version and "commit 6caaee842e94," in version
    assert subprocess.check_output(["git","-C",ml,"rev-parse","HEAD"],text=True).strip()==MATHLIB
    lib=subprocess.check_output([lean/"lake","env","printenv","LEAN_PATH"],env=env,cwd=ml,text=True).strip()
    stage=Path(tempfile.mkdtemp(prefix=".choice.",dir=HERE))
    build=stage/"build";build.mkdir()
    baseline=stage/"baseline";baseline.mkdir()
    env["LEAN_PATH"]=os.pathsep.join(map(str,[build,baseline]+[(ml/p).resolve() for p in lib.split(os.pathsep)]))
    print(version,"\nMathlib",MATHLIB,"\nReplay directory",stage,flush=True)
    fresh=manifest(HERE/"SOURCES.sha256"); old=manifest(HERE/"PREDECESSORS.sha256")
    sources={}; previous=set()
    for name,expected in (old|fresh).items():
        f=HERE/name; mod=f.stem; assert mod not in sources and digest(f)==expected,name
        assert not re.search(r"\b(?:sorry|admit|axiom|native_decide)\b",f.read_text()),name
        sources[mod]=f
        if name in old:previous.add(mod)
    assert len(fresh)==10 and len(previous)==351
    cached={}
    for line in (HERE/"CHECKED-OBJECTS.tsv").read_text().splitlines():
        mod,sha,rel=line.split("\t"); assert mod not in cached
        assert not Path(rel).is_absolute() and ".." not in Path(rel).parts
        cached[mod]=(sha,rel)
    assert set(cached)==previous
    if args.checked:
        for mod,(key,rel) in cached.items():
            source=(args.checked/rel).resolve()
            assert digest(source)==key,source
            (baseline/(mod+".olean")).symlink_to(source)
        print(f"Matched {len(cached)} predecessor source and object hashes.",flush=True)
    built=set();visited=set();reports=0
    def build_module(mod):
        nonlocal reports
        if mod in visited:return
        visited.add(mod); source=sources[mod]; body=source.read_text()
        for dep in re.findall(r"^import\s+(\S+)",body,re.M):
            if dep.split(".")[0] not in ("Mathlib","Lean","Std","Init","Batteries","Aesop"):build_module(dep)
        if mod in previous and args.checked:return
        if args.resume_from:
            oldstage=args.resume_from.resolve()
            oldsource=oldstage.parent/source.name
            oldlog=oldstage/(mod+".log")
            oldobj=oldstage/"build"/(mod+".olean")
            if oldlog.is_file() and oldobj.is_file() and oldsource.is_file() and digest(oldsource)==digest(source):
                assert digest(oldobj)==reference[mod+".olean"],mod
                prior=oldlog.read_text()
                assert not re.search(r"\b(?:error|warning):|sorryAx|Lean\.ofReduceBool",prior)
                output=re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]$",prior,re.M)
                named=re.findall(r"^#print axioms ([\w.]+)$",body,re.M)
                assert named and named==[name for name,_ in output] and all(set(ax.split(", "))<=ALLOWED for _,ax in output),mod
                (build/(mod+".olean")).symlink_to(oldobj)
                (stage/(mod+".log")).write_text(prior)
                print("Matched earlier strict extracted replay, identical source and object",mod,flush=True)
                print(prior,end="",flush=True)
                reports+=len(named);built.add(mod);return
        print("Checking",mod,flush=True)
        proc=subprocess.run([lean/"lean","-j1","-s","65536","-DElab.async=false","-DwarningAsError=true",
                             "-o",build/(mod+".olean"),source.name],env=env,cwd=source.parent,
                            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        (stage/(mod+".log")).write_text(proc.stdout);print(proc.stdout,end="",flush=True)
        proc.check_returncode()
        assert (build/(mod+".olean")).stat().st_size
        assert not re.search(r"\b(?:error|warning):|sorryAx|Lean\.ofReduceBool",proc.stdout)
        lines=re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]$",proc.stdout,re.M)
        assert all(set(axioms.split(", "))<=ALLOWED for _,axioms in lines)
        if mod not in previous:
            expected=re.findall(r"^#print axioms ([\w.]+)$",body,re.M)
            assert expected and expected==[name for name,_ in lines],mod
            reports+=len(lines)
        built.add(mod)
    for terminal in ["ChoiceShrink","ChoiceSimultaneous","SixObstruction"]:build_module(terminal)
    assert set(sources)==visited and built==(visited-previous if args.checked else visited)
    print(f"Verified {len(fresh)} new modules and {reports} standard-axiom reports.",flush=True)
    print("Verified simultaneous thinning, weighted selection, the competition obstruction, and the exact connected order-29 example.",flush=True)
if __name__=="__main__":
    main()
