"""Strict replay of the four-anchor extension, with the exact transitive source closure."""
import argparse
from hashlib import sha256
import os
from pathlib import Path
import re
import subprocess
import tempfile

HERE = Path(__file__).resolve().parent
MATHLIB = "c44e0c8ee63ca166450922a373c7409c5d26b00b"
SHARED_ANCHOR_LOG = "d749d4a9fd99f5d2258d934e130684881ece5e4d4d7084d3e5e0bb4ab674d5f6"
ALLOW = {"propext", "Classical.choice", "Quot.sound"}
TERMINALS = ("FourRankGap",)

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

def manifest(filename):
    return dict(line.split()[::-1] for line in (HERE / filename).read_text().splitlines())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--checked", type=Path, metavar="SHARED_ANCHOR_LOG", help="reuse the digest-verified objects from the frozen shared-anchor replay")
    group.add_argument("--cold", action="store_true", help="compile all sources recursively (default)")
    args = parser.parse_args()
    env = os.environ.copy()
    deps = HERE.parent / "graff384b-codex/.deps"
    lean = Path(env.get("CROSSFOUR_LEAN_BIN", deps / "lean-4.19.0-linux/bin")).resolve()
    math = Path(env.get("CROSSFOUR_MATHLIB", deps / "mathlib4")).resolve()
    env["PATH"] = str(lean) + os.pathsep + env["PATH"]
    version = subprocess.check_output([lean/"lean", "--version"], text=True).strip()
    assert "version 4.19.0," in version and "commit 6caaee842e94," in version
    assert subprocess.check_output(["git", "-C", math, "rev-parse", "HEAD"], text=True).strip() == MATHLIB
    print(version, "\nMathlib", MATHLIB, flush=True)
    paths = subprocess.check_output([lean/"lake", "env", "printenv", "LEAN_PATH"], text=True, cwd=math, env=env).strip()
    new = manifest("NEW-SOURCES.sha256")
    prior = manifest("PRIOR-SOURCES.sha256")
    sources = {}
    for name, expected in (new | prior).items():
        path = HERE/name
        assert path.stem not in sources and digest(path) == expected, name
        sources[path.stem] = path
    assert len(new) == 10 and len(prior) == 196
    past = set(Path(n).stem for n in prior)
    stage = Path(tempfile.mkdtemp(prefix=".four-replay.", dir=HERE))
    print("Replay directory", stage, flush=True)
    checked = set()
    search = [stage]
    if args.checked:
        assert digest(args.checked) == SHARED_ANCHOR_LOG
        pred = Path(re.search(r"^Replay directory (.+)$", args.checked.read_text(), re.M)[1])
        # Only the authenticated predecessors are put on LEAN_PATH.
        baseline = stage / "prior-objects"
        baseline.mkdir()
        old = manifest("PRIOR-OBJECTS.sha256")
        assert set(old) == {m+".olean" for m in past}
        for name, expected in old.items():
            candidates = [p/name for p in (pred, pred/"prior-objects") if (p/name).is_file()]
            assert len(candidates) == 1 and digest(candidates[0]) == expected, name
            (baseline/name).symlink_to(candidates[0])
        search.append(baseline)
        checked.update(past)
        print("Verified all 196 prior source hashes, the frozen shared-anchor replay, and 196 prior object hashes.", flush=True)
    search.extend((math/entry).resolve() for entry in paths.split(os.pathsep))
    env["LEAN_PATH"] = os.pathsep.join(map(str, search))
    visited = set()
    reports = 0
    def build(mod):
        nonlocal reports
        if mod in visited: return
        visited.add(mod)
        path = sources[mod]
        body = path.read_text()
        for dep in re.findall(r"^import\s+(\S+)", body, re.M):
            if dep.split(".")[0] not in ("Mathlib","Lean","Std","Init","Batteries","Aesop"):
                build(dep)
        if mod in checked: return
        print("Checking", mod, flush=True)
        command=[lean/"lean", "-j1", "-s", "65536", "-DElab.async=false", "-DwarningAsError=true", "-o", stage/(mod+".olean"), path.name]
        proc=subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=path.parent, env=env)
        (stage/(mod+".log")).write_text(proc.stdout)
        print(proc.stdout, end="", flush=True)
        proc.check_returncode()
        assert (stage/(mod+".olean")).stat().st_size > 0
        assert not re.search(r"\b(?:error|warning):|sorryAx|Lean\.ofReduceBool", proc.stdout)
        if mod not in past:
            assert not re.search(r"\b(?:sorry|admit|native_decide|axiom)\b",body)
            expected = re.findall(r"^#print axioms ([\w.]+)$", body, re.M)
            found = re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]$", proc.stdout, re.M)
            assert expected and [name for name,_ in found] == expected
            assert all(set(names.split(", ")) <= ALLOW for _, names in found)
            reports += len(found)
        checked.add(mod)
    for mod in TERMINALS: build(mod)
    assert checked == visited == set(sources) and reports == 20
    print("Verified ten new modules and twenty named standard-axiom reports.", flush=True)
    print("Verified the dense and sparse four-anchor bounds, the induced nine-label cut, the missing-rank test, and its numerical limitation.", flush=True)
if __name__ == "__main__":
    main()
