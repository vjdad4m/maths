import GrowingCuts
namespace Graffiti384b.Four29.FiveWitness
open Finset SimpleGraph LowSample
abbrev V := Fin 30

/-- Row i of the symmetric adjacency matrix, with the least significant
bit representing vertex 0. Vertices 27 and 28 are the two ears. -/
private def rows : V → ℕ := ![134217778,134218189,268435850,268435654,5007905,87469585,39156618,132607566,64349766,95624688,99564448,29001456,101910080,79332848,86835664,102312224,113563584,8666784,130762224,90500112,25213792,4746912,70059472,102182784,35409824,92639680,47052448,3,12,0]
private def adj (i j : V) : Prop := (rows i).testBit j.val=true
instance : DecidableRel adj := fun i j => inferInstanceAs (Decidable ((rows i).testBit j.val=true))
set_option maxRecDepth 65536
set_option maxHeartbeats 0
def graph : SimpleGraph V where
  Adj := adj
  symm := fun {i j} h => (show ∀a b:V,adj a b → adj b a by decide) i j h
  loopless := by exact (show ∀i:V,¬adj i i by decide)
instance : DecidableRel graph.Adj := inferInstanceAs (DecidableRel adj)

def localVertices : Finset V := roots graph 27 28 ∪ triangleContacts graph 27 28 ∪ {27,28}
def seed : Finset V := {0,3,4,6,8,10,13,15,16,21,23,24,27,28,29}

/- All unordered adjacent-neighbor pairs are represented once with their
smaller label first. This avoids materializing powersets during replay. -/
variable {A : Type*} [Fintype A] [LinearOrder A] [DecidableEq A] (H : SimpleGraph A) [DecidableRel H.Adj]

def ordered (v : A) : Finset (A×A) := univ.filter (fun p => p.1<p.2 ∧
  H.Adj v p.1 ∧ H.Adj v p.2 ∧ H.Adj p.1 p.2)

open private Repair.linkEdges Repair.edge_info from Repair384b
theorem ordered_card (v : A) : (ordered H v).card=trianglesAt H v := by
  let lift (p : A×A) : Finset A := {p.1,p.2}
  have spec (p : A×A) : p∈ordered H v ↔ p.1<p.2 ∧ H.Adj v p.1 ∧ H.Adj v p.2 ∧ H.Adj p.1 p.2 := by simp [ordered]
  change (ordered H v).card=(Repair.linkEdges H v).card
  apply card_bij (fun p _ => lift p)
  · intro p hm
    obtain ⟨lt,ax,bx,edge⟩ := (spec p).mp hm
    have sub : lift p⊆H.neighborFinset v := insert_subset ((H.mem_neighborFinset ..).mpr ax)
      (singleton_subset_iff.mpr ((H.mem_neighborFinset ..).mpr bx))
    refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub,card_pair lt.ne⟩,?_⟩
    intro x hx y hy xy
    simp only [lift,mem_insert,mem_singleton] at hx hy
    rcases hx with rfl|rfl <;> rcases hy with rfl|rfl <;> first | exact (xy rfl).elim | exact edge | exact edge.symm
  · rintro ⟨a,b⟩ ap ⟨c,d⟩ cp eq
    have lt := ((spec _).mp ap).1
    have lt' := ((spec _).mp cp).1
    have eq' : ({a,b}:Set A)={c,d} := by simpa [lift] using congrArg (fun s : Finset A => (s:Set A)) eq
    rcases Set.pair_eq_pair_iff.mp eq' with ⟨rfl,rfl⟩|⟨rfl,rfl⟩
    · rfl
    · exact (not_lt_of_ge lt.le lt').elim
  · intro edge em
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info H em
    obtain ⟨a,b,ne,rfl⟩ := card_eq_two.mp sz
    have am : a∈({a,b}:Finset A) := mem_insert_self ..
    have bm : b∈({a,b}:Finset A) := mem_insert_of_mem (mem_singleton_self _)
    have ax := (H.mem_neighborFinset ..).mp (sub am)
    have bx := (H.mem_neighborFinset ..).mp (sub bm)
    have ab := cl _ am _ bm ne
    rcases lt_or_gt_of_ne ne with lt|lt
    · exact ⟨(a,b),(spec _).mpr ⟨lt,ax,bx,ab⟩,rfl⟩
    · exact ⟨(b,a),(spec _).mpr ⟨lt,bx,ax,ab.symm⟩,pair_comm ..⟩
end Graffiti384b.Four29.FiveWitness
#print axioms Graffiti384b.Four29.FiveWitness.ordered_card
