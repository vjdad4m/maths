import FiveData
namespace Graffiti384b.Four29.FiveWitness
open Finset SimpleGraph LowSample
set_option maxRecDepth 65536
set_option maxHeartbeats 0

theorem degrees : (nonleaves graph).card=29 ∧ (high graph).card=27 ∧
    twos graph={27,28} ∧ graph.neighborFinset 27={0,1} ∧ graph.neighborFinset 28={2,3} := by decide

theorem roots_eq : roots graph 27 28={0,1,2,3} := by
  rw [roots,degrees.2.2.2.1,degrees.2.2.2.2]
  decide

theorem contacts : triangleContacts graph 27 28={4,5,6,7,8} := by
  unfold triangleContacts
  rw [roots_eq]
  decide

theorem exposure : (Donor.exposed graph (pool graph 27 28)).card=5 ∧
    (twice graph (pool graph 27 28)).card=3 := by decide

theorem local_eq : localVertices={0,1,2,3,4,5,6,7,8,27,28} := by
  rw [localVertices,roots_eq,contacts]
  decide

private def P : Finset V := {0,1,2,3,9}
private def Q : Finset V := {27,28,4,6,7}

/-- A single extra pin outside the local vertices suffices, and the two shores
already protect each other without any further extension. -/
theorem one_outside : ∃A B:Finset V, ((A∪B)\localVertices).card=1 ∧ Disjoint A B ∧
    twos graph⊆A∪B ∧ (∀v∈A,2≤nbr graph v B) ∧ (∀v∈B,2≤nbr graph v A) := by
  refine ⟨P,Q,?_⟩
  rw [local_eq,degrees.2.2.1]
  decide

/-- The automatic shore expansion covers the deficient anchor on round two. -/
theorem rounds : (∃v∈roots graph 27 28,nbr graph v (growPins graph 1 (roots graph 27 28,{27,28})).2=1) ∧
    (∀v∈roots graph 27 28,2≤nbr graph v (growPins graph 2 (roots graph 27 28,{27,28})).2) := by
  rw [roots_eq]; decide
private theorem local_neighbors :
    localVertices.filter (graph.Adj 27)={0,1} ∧ localVertices.filter (graph.Adj 0)={27,1,4,5} ∧
    localVertices.filter (graph.Adj 4)={0,5} ∧ localVertices.filter (graph.Adj 5)={0,4} := by rw [local_eq]; decide

private theorem both {v a b : V} {S : Finset V} (sub : S⊆localVertices) (two : 2≤nbr graph v S)
    (eq : localVertices.filter (graph.Adj v)={a,b}) : a∈S ∧ b∈S := by
  have inc := Finset.filter_subset_filter (graph.Adj v) sub
  rw [eq] at inc
  have bound : ({a,b}:Finset V).card≤(S.filter (graph.Adj v)).card :=
    Finset.card_le_two.trans two
  have equal := eq_of_subset_of_card_le inc bound
  exact ⟨(mem_filter.mp (equal.symm ▸ mem_insert_self a {b})).1,
    (mem_filter.mp (equal.symm ▸ mem_insert_of_mem (mem_singleton_self b))).1⟩

private theorem one_side (P Q : Finset V) (pd : P⊆localVertices) (qd : Q⊆localVertices)
    (dis : Disjoint P Q) (pq : ∀v∈P,2≤nbr graph v Q) (qp : ∀v∈Q,2≤nbr graph v P)
    (ear : 27∈P) : False := by
  obtain ⟨a,b⟩ := both qd (pq 27 ear) local_neighbors.1
  have np : (0:V)∉P := fun h => disjoint_left.mp dis h a
  have no4 (i : (4:V)∈P) : False := by
    have five := (both qd (pq 4 i) local_neighbors.2.2.1).2
    exact np (both pd (qp 5 five) local_neighbors.2.2.2).1
  have no5 (i : (5:V)∈P) : False := by
    have four := (both qd (pq 5 i) local_neighbors.2.2.2).2
    exact np (both pd (qp 4 four) local_neighbors.2.2.1).1
  have only : P.filter (graph.Adj 0)⊆{27} := by
    intro i im
    have hm := Finset.filter_subset_filter (graph.Adj 0) pd im
    rw [local_neighbors.2.1] at hm
    simp only [mem_insert,mem_singleton] at hm
    rcases hm with rfl|rfl|rfl|rfl
    · exact mem_singleton_self _
    · exact (disjoint_left.mp dis (mem_filter.mp im).1 b).elim
    · exact (no4 (mem_filter.mp im).1).elim
    · exact (no5 (mem_filter.mp im).1).elim
  have small := card_le_card only
  rw [card_singleton] at small
  exact (by have big := qp 0 a; change 2≤(P.filter (graph.Adj 0)).card at big; omega : False)

/-- No two disjoint pinned sets inside the ears, four anchors and five
triangle contacts can protect every pin and include even the first ear. -/
theorem no_local_cut (P Q : Finset V) (pd : P⊆localVertices) (qd : Q⊆localVertices)
    (dis : Disjoint P Q) (pq : ∀v∈P,2≤nbr graph v Q) (qp : ∀v∈Q,2≤nbr graph v P) :
    (27:V)∉P∪Q := by
  intro em
  exact (mem_union.mp em).elim (one_side P Q pd qd dis pq qp) (one_side Q P qd pd dis.symm qp pq)
end Graffiti384b.Four29.FiveWitness
#print axioms Graffiti384b.Four29.FiveWitness.contacts
#print axioms Graffiti384b.Four29.FiveWitness.rounds
#print axioms Graffiti384b.Four29.FiveWitness.no_local_cut
#print axioms Graffiti384b.Four29.FiveWitness.one_outside
