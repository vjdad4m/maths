import FiveData
namespace Graffiti384b.Four29.FiveWitness
open Finset SimpleGraph LowSample
set_option maxRecDepth 65536
set_option maxHeartbeats 0
def scores : V → ℕ := ![2,8,5,6,13,35,36,62,42,51,65,37,15,33,22,17,47,23,54,28,24,20,25,40,29,26,46,1,1,0]

/-- Evaluate the thirty ordered-pair counts, then pass back to the
catalogue's neighbor-pair definition. -/
theorem score_table (v : V) : trianglesAt graph v=scores v := by
  rw [←ordered_card graph]
  exact (show ∀i:V,(ordered graph i).card=scores i by decide) v

theorem diversity : (types graph).card=29 := by
  rw [types,funext score_table]
  decide
end Graffiti384b.Four29.FiveWitness
#print axioms Graffiti384b.Four29.FiveWitness.score_table
#print axioms Graffiti384b.Four29.FiveWitness.diversity
