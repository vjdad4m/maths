import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code2 : covered (0*8+2) := by unfold covered; rfl
theorem code3 : covered (0*8+3) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code2
#print axioms Graffiti384b.Four29.Ten.code3
