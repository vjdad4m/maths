import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code96 : covered (12*8+0) := by unfold covered; rfl
theorem code97 : covered (12*8+1) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code96
#print axioms Graffiti384b.Four29.Ten.code97
