import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code100 : covered (12*8+4) := by unfold covered; rfl
theorem code101 : covered (12*8+5) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code100
#print axioms Graffiti384b.Four29.Ten.code101
