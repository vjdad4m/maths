import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code110 : covered (13*8+6) := by unfold covered; rfl
theorem code111 : covered (13*8+7) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code110
#print axioms Graffiti384b.Four29.Ten.code111
