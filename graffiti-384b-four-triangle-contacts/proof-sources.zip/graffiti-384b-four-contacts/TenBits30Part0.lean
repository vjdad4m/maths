import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code240 : covered (30*8+0) := by unfold covered; rfl
theorem code241 : covered (30*8+1) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code240
#print axioms Graffiti384b.Four29.Ten.code241
