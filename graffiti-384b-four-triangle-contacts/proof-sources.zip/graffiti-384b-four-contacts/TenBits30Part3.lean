import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code246 : covered (30*8+6) := by unfold covered; rfl
theorem code247 : covered (30*8+7) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code246
#print axioms Graffiti384b.Four29.Ten.code247
