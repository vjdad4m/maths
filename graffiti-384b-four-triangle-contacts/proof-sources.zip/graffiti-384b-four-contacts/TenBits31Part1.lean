import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code250 : covered (31*8+2) := by unfold covered; rfl
theorem code251 : covered (31*8+3) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code250
#print axioms Graffiti384b.Four29.Ten.code251
