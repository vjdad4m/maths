import TenSignals
namespace Graffiti384b.Four29.Ten
set_option maxRecDepth 65536
set_option maxHeartbeats 0
set_option exponentiation.threshold 524288
theorem code30 : covered (3*8+6) := by unfold covered; rfl
theorem code31 : covered (3*8+7) := by unfold covered; rfl
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.code30
#print axioms Graffiti384b.Four29.Ten.code31
