import TenCanon
namespace Graffiti384b.Four29.Ten
open Finset SimpleGraph Words
open private canonIndex renameExtra from TenCanon

theorem assignment_bit (v : ℕ → Bool) {n i : ℕ} (hi : i<n) :
    (assignment v n).testBit i=v i := by
  induction n with
  | zero => omega
  | succ n ih =>
    have small := Nat.testBit_lt_two_pow (assignment_bound v n)
    by_cases same : i=n
    · subst i
      cases b : v n <;> simp [assignment,b,small,Nat.testBit_two_pow_add_eq]
    · have lt : i<n := by omega
      cases b : v n <;> simp [assignment,b,Nat.testBit_two_pow_add_gt lt,ih lt]

variable {V : Type*} (G : SimpleGraph V)
private theorem six_edges (f : Label ↪ V) :
    ∃g:Fin 64,∀i j:Label,extraPair i j=true → (fixed g.val i j=true ↔ G.Adj (f i) (f j)) := by
  classical
  let v := fun n : ℕ => decide (∃a b:Label, a<b ∧ extraPair a b=true ∧ fixedPos a b=n ∧ G.Adj (f a) (f b))
  let g : Fin 64 := ⟨assignment v 6,assignment_bound v 6⟩
  refine ⟨g,?_⟩
  have ordered (a b : Label) (ab : a<b) (ex : extraPair a b=true) :
      fixed g.val a b=true ↔ G.Adj (f a) (f b) := by
    have small : ∀i j:Label,extraPair i j=true → i<j → fixedPos i j<6 := by decide
    have unique : ∀i j k l:Label, extraPair i j=true → extraPair k l=true → i<j → k<l →
        fixedPos i j=fixedPos k l → i=k ∧ j=l := by decide
    simp only [fixed,bne_iff_ne.mpr ab.ne,Bool.true_and]
    rw [assignment_bit v (small _ _ ex ab)]
    change decide _=true ↔ _
    rw [decide_eq_true_eq]
    constructor
    · rintro ⟨i,j,ij,h,key,adj⟩; obtain ⟨rfl,rfl⟩ := unique i j a b h ex ij ab key; exact adj
    · exact fun h => ⟨a,b,ab,ex,rfl,h⟩
  intro i j ex
  rcases lt_trichotomy i j with lt|rfl|gt
  · exact ordered i j lt ex
  · simp [fixed]
  · have swap : ∀a b:Label,extraPair a b=extraPair b a := by decide
    have sym : fixed g.val i j = fixed g.val j i := by simp [fixed,fixedPos,min_comm,max_comm,bne_iff_ne.mpr gt.ne,bne_iff_ne.mpr gt.ne']
    rw [sym,ordered j i gt ((swap i j).symm ▸ ex)]; exact G.adj_comm _ _

/-- Relabel just the four extra vertices so their internal graph is in one of
the eleven four-vertex isomorphism classes. The range and all six marked
vertices are preserved. -/
theorem canonicalize (f : Label ↪ V)
    (shape : ∀i j:Label,8 ≤ i.val ∨ 8 ≤ j.val → (preset i j=true ↔ G.Adj (f i) (f j))) :
    ∃g∈canonical,∃l:Label ↪ V, (∀a:Label,a.val<4 ∨ 8 ≤ a.val → l a=f a) ∧
      Set.range f=Set.range l ∧
      (∀i j:Label,8 ≤ i.val ∨ 8 ≤ j.val → (preset i j=true ↔ G.Adj (l i) (l j))) ∧
      (∀i j:Label,extraPair i j=true → (fixed g i j=true ↔ G.Adj (l i) (l j))) := by
  obtain ⟨old,values⟩ := six_edges G f
  obtain ⟨ok,inj,fix,six,shapeEq⟩ := orbit old
  let perm : Label ↪ Label := ⟨renameExtra old,inj⟩
  let l := perm.trans f
  have unchanged (a : Label) (h : a.val<4 ∨ 8 ≤ a.val) : l a=f a := congrArg f (fix _ h)
  refine ⟨_,ok,l,unchanged,?_,?_,?_⟩
  · ext x
    constructor
    · rintro ⟨j,rfl⟩
      obtain ⟨i,hi⟩ := Finite.surjective_of_injective perm.injective j
      exact ⟨i,congrArg f hi⟩
    · rintro ⟨i,rfl⟩; exact ⟨perm i,rfl⟩
  · intro i j er
    rw [shapeEq _ _ er]
    apply shape
    rcases er with h|h
    · left; rw [fix _ (Or.inr h)]; exact h
    · right; rw [fix _ (Or.inr h)]; exact h
  · intro i j ex
    obtain ⟨ex',eq⟩ := six _ _ ex
    rw [eq]; exact values _ _ ex'
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.canonicalize
