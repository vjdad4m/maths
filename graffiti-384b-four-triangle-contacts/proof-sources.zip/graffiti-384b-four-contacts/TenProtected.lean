import TenSemantic
import TenTable

namespace Graffiti384b.Four29.Ten
open Finset SimpleGraph Words LowSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Restricted count of unordered triangles at a label in the induced
ten-vertex graph. This count can be checked on any chosen four extra vertices. -/
def localCount (f : Label ↪ V) (i : Label) := (pairs.filter (fun z =>
  decide (G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2)))).length

omit [Fintype V] [DecidableEq V] in
private theorem actual (f : Label ↪ V) (g p : ℕ)
    (edges : ∀i j:Label,(edge g i j).testBit p=true ↔ G.Adj (f i) (f j)) (i : Label) :
    number p (score g i)=localCount G f i := by
  rw [score,binary_at,triangles,List.filter_map,List.length_map,localCount]
  congr 1
  apply List.filter_congr
  intro z _
  apply Bool.eq_iff_iff.mpr
  simp only [Function.comp_apply,Nat.testBit_and,Bool.and_eq_true,edges,decide_eq_true_eq,and_assoc]
/-- A tested arrangement pins both ears and leaves every unpinned nonleaf
with degree at least three, so the pinned maximum-cut theorem applies. -/
theorem ten_canonical_induced (f : Label ↪ V) (g : ℕ) (can : g∈canonical) (quota : (types G).card≤(nonleaves G).card)
    (ears : ∀z∈twos G,z=f 8 ∨ z=f 9)
    (shape : ∀i j:Label, (8 ≤ i.val ∨ 8 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j)))
    (extra : ∀i j:Label,extraPair i j=true → (fixed g i j=true ↔ G.Adj (f i) (f j)))
    (positive : ∀i∈anchors,2≤localCount G f i)
    (distinctScores : ∀a∈anchors,∀b∈anchors,a≠b → localCount G f a≠localCount G f b) :
    gamma G≤bound G := by
  classical
  obtain ⟨k,ks,p,small,edges⟩ := represents G f g shape extra
  have pt : (ones 19).testBit p=true := by rw [ones,Nat.testBit_two_pow_sub_one,decide_eq_true_eq]; exact small
  have eq := actual G f (g*8+k) p edges
  have rt : (rich (g*8+k)).testBit p=true := by
    apply (all_at pt _).mpr
    intro w wm
    obtain ⟨i,im,rfl⟩ := List.mem_map.mp wm
    apply at_least_two
    rw [eq i]
    exact positive i im
  have dt : (distinct (g*8+k)).testBit p=true := by
    apply (all_at pt _).mpr
    intro w wm
    obtain ⟨⟨a,b⟩,ab,rfl⟩ := List.mem_map.mp wm
    obtain ⟨prod,lt⟩ := List.mem_filter.mp ab
    obtain ⟨am,bm⟩ := List.mem_product.mp prod
    apply differ_at
    rw [eq a,eq b]
    exact distinctScores a am b bm (ne_of_lt (of_decide_eq_true lt))
  have bit := congrArg (fun z : ℕ => z.testBit p) (table g can k ks)
  simp only [Nat.testBit_and,rt,dt,Bool.true_and] at bit
  obtain ⟨w,wm,yes⟩ := (any_at p _).mp bit
  obtain ⟨⟨P,Q⟩,placement,rfl⟩ := List.mem_map.mp wm
  obtain ⟨no,pd,qd,e7,e8⟩ := pattern_data _ placement
  have split := Bool.and_eq_true_iff.mp (show ((supported (g*8+k) P Q).testBit p && (supported (g*8+k) Q P).testBit p) = true by
    simpa only [works,Nat.testBit_and] using yes)
  let L := P.toFinset.map f
  let R := Q.toFinset.map f
  have either {z : Label} (m : z∈P ∨ z∈Q) : f z∈L ∨ f z∈R :=
    m.imp (fun h => mem_map.mpr ⟨z,List.mem_toFinset.mpr h,rfl⟩)
      (fun h => mem_map.mpr ⟨z,List.mem_toFinset.mpr h,rfl⟩)
  have lp := support_lift G f pt edges qd split.1
  have rq := support_lift G f pt edges pd split.2
  apply PinnedColor34.complete G (P:=L) (Q:=R) ?_ quota ?_ lp rq
  · apply disjoint_left.mpr
    intro z zl zr
    obtain ⟨i,im,rfl⟩ := mem_map.mp zl
    obtain ⟨j,jm,eq'⟩ := mem_map.mp zr
    exact no i (List.mem_toFinset.mp im) (f.injective eq' ▸ List.mem_toFinset.mp jm)
  · intro z zn zl zr
    by_contra! smallD
    have low : z∈twos G := mem_sdiff.mpr ⟨zn,fun h => (not_le_of_gt smallD) (mem_filter.mp h).2⟩
    rcases ears z low with rfl|rfl
    · exact (either e7).elim zl zr
    · exact (either e8).elim zl zr

/-- The chosen labels contain every triangle through the four anchors. The
canonical relabeling of the extras preserves the four global triangle scores. -/
theorem ten_labels (f : Label ↪ V) (quota : (types G).card≤(nonleaves G).card)
    (ears : ∀z∈twos G,z=f 8 ∨ z=f 9)
    (shape : ∀i j:Label, (8 ≤ i.val ∨ 8 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j)))
    (locality : ∀i∈anchors,∀z∈Repair.linkSupport G (f i),z∈Set.range f)
    (positive : ∀i∈anchors,2≤trianglesAt G (f i))
    (distinctScores : ∀a∈anchors,∀b∈anchors,a≠b → trianglesAt G (f a)≠trianglesAt G (f b)) :
    gamma G≤bound G := by
  obtain ⟨g,can,l,fix,rng,shape',extra⟩ := canonicalize G f shape
  obtain ⟨k,_,p,_,edges⟩ := represents G l g shape' extra
  have small : ∀i∈anchors,i.val<4 := by decide
  have agrees (i : Label) (ia : i∈anchors) : localCount G l i=trianglesAt G (f i) := by
    have eq := fix i (Or.inl (small _ ia))
    have holds (z : V) (zm : z∈Repair.linkSupport G (l i)) : z∈Set.range l := by
      rw [←rng]; apply locality i ia; rwa [eq] at zm
    exact (actual G l (g*8+k) p edges i).symm.trans ((counts G l (g*8+k) p edges i holds).trans (congrArg _ eq))
  refine ten_canonical_induced G l g can quota ?_ shape' extra ?_ ?_
  · intro z zm
    rw [fix 8 (Or.inr (by decide)),fix 9 (Or.inr (by decide))]
    exact ears z zm
  · intro i ia; rw [agrees i ia]; exact positive i ia
  · intro a am b bm ne; rw [agrees a am,agrees b bm]; exact distinctScores a am b bm ne
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.ten_canonical_induced
#print axioms Graffiti384b.Four29.Ten.ten_labels
