import TenOrbit
namespace Graffiti384b.Four29.Ten
open Finset SimpleGraph Words
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem order_pair : ∀z:Label×Label, z∈pairs ↔ z.1<z.2 := by decide
set_option maxHeartbeats 0 in
private theorem key_table : ∀a b x y:Label, a<b → x<y → b.val<8 → y.val<8 →
    extraPair a b=false → extraPair x y=false → position a b=position x y → a=x ∧ b=y := by decide

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem represents (f : Label ↪ V) (g : ℕ)
    (ear : ∀i j:Label, (8 ≤ i.val ∨ 8 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j)))
    (extra : ∀i j:Label,extraPair i j=true → (fixed g i j=true ↔ G.Adj (f i) (f j))) :
    ∃k<8,∃p<2^19,∀i j:Label,(edge (g*8+k) i j).testBit p=true ↔ G.Adj (f i) (f j) := by
  classical
  let v := fun n : ℕ => decide (∃a b:Label, a<b ∧ b.val<8 ∧ extraPair a b=false ∧ position a b=n ∧ G.Adj (f a) (f b))
  let p := assignment v 19
  let k := assignment (fun n => v (19+n)) 3
  let code := g*8+k
  have ks : k<8 := assignment_bound _ 3
  have rem : code%8=k := by dsimp only [code]; omega
  have quot : code/8=g := by dsimp only [code]; omega
  have top : (ones 19).testBit p=true := by
    rw [ones,Nat.testBit_two_pow_sub_one,decide_eq_true_eq]; exact assignment_bound v 19
  have constant (b : Bool) : (if b then ones 19 else 0).testBit p=true ↔ b=true := by
    cases b <;> simp [top]
  have value {n : ℕ} (small : n<22) : (variableEdge code n).testBit p=true ↔ v n=true := by
    unfold variableEdge
    split
    · rename_i lt; rw [column_at v lt]
    · rename_i ge; rw [constant,rem,assignment_bit _ (show n-19<3 by omega)]
      rw [show 19+(n-19)=n by omega]
  have young (i j : Label) (ij : i<j) (j8 : j.val<8) (ex : extraPair i j=false) : (variableEdge code (position i j)).testBit p=true ↔ G.Adj (f i) (f j) := by
    have tab : ∀a b:Label,a<b → b.val<8 → extraPair a b=false → position a b<22 := by decide
    rw [value (tab i j ij j8 ex)]
    change decide _=true ↔ _
    rw [decide_eq_true_eq]
    constructor
    · rintro ⟨a,b,ab,b8,ex',key,adj⟩
      obtain ⟨rfl,rfl⟩ := key_table a b i j ab ij b8 j8 ex' ex key
      exact adj
    · exact fun h => ⟨i,j,ij,j8,ex,rfl,h⟩
  refine ⟨k,ks,p,assignment_bound v 19,?_⟩
  change ∀i j:Label,(edge code i j).testBit p=true ↔ G.Adj (f i) (f j)
  intro i j
  unfold edge
  by_cases ij : i=j
  · subst j; simp
  rw [if_neg ij]
  split
  · rename_i small
    cases ex : extraPair i j with
    | true => simp only [Bool.true_eq,if_true,constant,quot]; exact extra _ _ ex
    | false =>
      simp only [Bool.false_eq_true,if_false]
      rcases lt_or_gt_of_ne ij with lt|gt
      · exact young i j lt small.2 ex
      · have eq : position i j=position j i := by simp [position,max_comm,min_comm]
        have sym : ∀a b:Label,extraPair a b=extraPair b a := by decide
        rw [eq,young j i gt small.1 ((sym i j).symm ▸ ex)]; exact G.adj_comm _ _
  · rename_i old
    exact (constant _).trans (ear _ _ (by omega))

theorem counts (f : Label ↪ V) (g p : ℕ)
    (edges : ∀a b:Label,(edge g a b).testBit p=true ↔ G.Adj (f a) (f b))
    (i : Label) (locality : ∀z∈Repair.linkSupport G (f i),z∈Set.range f) :
    number p (score g i)=trianglesAt G (f i) := by
  classical
  let tag (z : Label×Label) := edge g i z.1 &&& edge g i z.2 &&& edge g z.1 z.2
  let selected := pairs.filter (fun z => (tag z).testBit p)
  let P := selected.toFinset
  let liftPair (z : Label×Label) : Finset V := {f z.1,f z.2}
  have sm (z : Label×Label) : z∈P ↔ z.1<z.2 ∧ G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2) := by
    simp only [P,selected,List.mem_toFinset,List.mem_filter,order_pair,tag,Nat.testBit_and,Bool.and_eq_true,edges,and_assoc]
  have repr : P.image liftPair=Repair.linkEdges G (f i) := by
    ext s
    constructor
    · intro hm
      obtain ⟨⟨a,b⟩,ab,rfl⟩ := mem_image.mp hm
      obtain ⟨lt,ia,ib,adj⟩ := (sm _).mp ab
      have sub : liftPair (a,b)⊆G.neighborFinset (f i) := insert_subset ((G.mem_neighborFinset ..).mpr ia)
        (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr ib))
      refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub,card_pair (f.injective.ne lt.ne)⟩,?_⟩
      intro x xm y ym ne
      simp only [liftPair,mem_insert,mem_singleton] at xm ym
      rcases xm with rfl|rfl <;> rcases ym with rfl|rfl <;> first | exact (ne rfl).elim | exact adj | exact adj.symm
    · intro hm
      obtain ⟨sub,sz,cl⟩ := Repair.edge_info G hm
      obtain ⟨x,y,ne,rfl⟩ := card_eq_two.mp sz
      have xm : x∈({x,y}:Finset V) := mem_insert_self ..
      have ym : y∈({x,y}:Finset V) := mem_insert_of_mem (mem_singleton_self _)
      obtain ⟨a,rfl⟩ := locality x (mem_biUnion.mpr ⟨_,hm,xm⟩)
      obtain ⟨b,rfl⟩ := locality y (mem_biUnion.mpr ⟨_,hm,ym⟩)
      have ia := (G.mem_neighborFinset ..).mp (sub xm)
      have ib := (G.mem_neighborFinset ..).mp (sub ym)
      have adj := cl _ xm _ ym ne
      rcases lt_or_gt_of_ne (fun eq : a=b => ne (congrArg f eq)) with l|l
      · exact mem_image.mpr ⟨(a,b),(sm _).mpr ⟨l,ia,ib,adj⟩,rfl⟩
      · exact mem_image.mpr ⟨(b,a),(sm _).mpr ⟨l,ib,ia,adj.symm⟩,pair_comm ..⟩
  have inj : Set.InjOn liftPair (P : Set (Label×Label)) := by
    rintro ⟨a,b⟩ ap ⟨c,d⟩ cp eq
    have lt := ((sm _).mp ap).1
    have lt' := ((sm _).mp cp).1
    have eq' : ({f a,f b}:Set V)={f c,f d} := by simpa [liftPair] using congrArg (fun s : Finset V => (s:Set V)) eq
    rcases Set.pair_eq_pair_iff.mp eq' with ⟨ac,bd⟩|⟨ad,bc⟩
    · exact Prod.ext (f.injective ac) (f.injective bd)
    · have := f.injective ad
      have := f.injective bc
      change a<b at lt; change c<d at lt'
      subst c; subst d; exact (not_lt_of_ge lt.le lt').elim
  have ord : pairs.Nodup := by decide
  have count := congrArg Finset.card repr
  rw [card_image_of_injOn inj] at count
  have sz := List.toFinset_card_of_nodup (ord.filter _ : selected.Nodup)
  change number p (binary (pairs.map tag))=(Repair.linkEdges G (f i)).card
  rw [binary_at,List.filter_map,List.length_map]
  change selected.length=_
  exact sz.symm.trans count

omit [Fintype V] [DecidableEq V] in
/-- Translate a tested placement back to actual neighbor counts. Only
distinct pinned labels are counted. -/
theorem support_lift (f : Label ↪ V) {g p : ℕ} (pt : (ones 19).testBit p=true)
    (edges : ∀a b:Label,(edge g a b).testBit p=true ↔ G.Adj (f a) (f b))
    {P Q : List Label} (nodup : Q.Nodup) (ok : (supported g P Q).testBit p=true) :
    ∀v∈P.toFinset.map f,2≤nbr G v (Q.toFinset.map f) := by
  intro v vm; obtain ⟨i,ip,rfl⟩ := mem_map.mp vm
  have ys := (all_at pt _).mp ok _ (List.mem_map.mpr ⟨i,List.mem_toFinset.mp ip,rfl⟩)
  have two := (atTwo_at p _).mp ys
  rw [List.filter_map,List.length_map] at two
  let good := Q.filter (fun j => (edge g i j).testBit p)
  have sz := List.toFinset_card_of_nodup (nodup.filter _ : good.Nodup)
  have sub : good.toFinset.map f⊆(Q.toFinset.map f).filter (G.Adj (f i)) := by
    intro z zm
    obtain ⟨j,jm,rfl⟩ := mem_map.mp zm
    obtain ⟨jq,adj⟩ := List.mem_filter.mp (List.mem_toFinset.mp jm)
    exact mem_filter.mpr ⟨mem_map.mpr ⟨j,List.mem_toFinset.mpr jq,rfl⟩,(edges i j).mp adj⟩
  have le := card_le_card sub
  rw [card_map,sz] at le
  exact two.trans le
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.represents
#print axioms Graffiti384b.Four29.Ten.counts
#print axioms Graffiti384b.Four29.Ten.support_lift
