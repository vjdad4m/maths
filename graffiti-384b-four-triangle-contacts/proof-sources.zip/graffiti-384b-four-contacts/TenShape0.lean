import TenBits0Part0
import TenBits0Part1
import TenBits0Part2
import TenBits0Part3
namespace Graffiti384b.Four29.Ten
theorem shape0 (k : ℕ) (hk : k<8) : covered (0*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code0
  · exact code1
  · exact code2
  · exact code3
  · exact code4
  · exact code5
  · exact code6
  · exact code7
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape0
