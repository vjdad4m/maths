import TenBits1Part0
import TenBits1Part1
import TenBits1Part2
import TenBits1Part3
namespace Graffiti384b.Four29.Ten
theorem shape1 (k : ℕ) (hk : k<8) : covered (1*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code8
  · exact code9
  · exact code10
  · exact code11
  · exact code12
  · exact code13
  · exact code14
  · exact code15
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape1
