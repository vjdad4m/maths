import TenBits11Part0
import TenBits11Part1
import TenBits11Part2
import TenBits11Part3
namespace Graffiti384b.Four29.Ten
theorem shape11 (k : ℕ) (hk : k<8) : covered (11*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code88
  · exact code89
  · exact code90
  · exact code91
  · exact code92
  · exact code93
  · exact code94
  · exact code95
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape11
