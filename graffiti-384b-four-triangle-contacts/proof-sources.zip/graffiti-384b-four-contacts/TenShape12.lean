import TenBits12Part0
import TenBits12Part1
import TenBits12Part2
import TenBits12Part3
namespace Graffiti384b.Four29.Ten
theorem shape12 (k : ℕ) (hk : k<8) : covered (12*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code96
  · exact code97
  · exact code98
  · exact code99
  · exact code100
  · exact code101
  · exact code102
  · exact code103
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape12
