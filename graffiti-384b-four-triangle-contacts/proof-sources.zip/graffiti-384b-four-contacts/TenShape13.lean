import TenBits13Part0
import TenBits13Part1
import TenBits13Part2
import TenBits13Part3
namespace Graffiti384b.Four29.Ten
theorem shape13 (k : ℕ) (hk : k<8) : covered (13*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code104
  · exact code105
  · exact code106
  · exact code107
  · exact code108
  · exact code109
  · exact code110
  · exact code111
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape13
