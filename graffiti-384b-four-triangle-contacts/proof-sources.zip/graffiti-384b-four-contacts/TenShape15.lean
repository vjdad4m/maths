import TenBits15Part0
import TenBits15Part1
import TenBits15Part2
import TenBits15Part3
namespace Graffiti384b.Four29.Ten
theorem shape15 (k : ℕ) (hk : k<8) : covered (15*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code120
  · exact code121
  · exact code122
  · exact code123
  · exact code124
  · exact code125
  · exact code126
  · exact code127
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape15
