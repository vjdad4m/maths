import TenBits3Part0
import TenBits3Part1
import TenBits3Part2
import TenBits3Part3
namespace Graffiti384b.Four29.Ten
theorem shape3 (k : ℕ) (hk : k<8) : covered (3*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code24
  · exact code25
  · exact code26
  · exact code27
  · exact code28
  · exact code29
  · exact code30
  · exact code31
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape3
