import TenBits30Part0
import TenBits30Part1
import TenBits30Part2
import TenBits30Part3
namespace Graffiti384b.Four29.Ten
theorem shape30 (k : ℕ) (hk : k<8) : covered (30*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code240
  · exact code241
  · exact code242
  · exact code243
  · exact code244
  · exact code245
  · exact code246
  · exact code247
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape30
