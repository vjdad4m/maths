import TenBits31Part0
import TenBits31Part1
import TenBits31Part2
import TenBits31Part3
namespace Graffiti384b.Four29.Ten
theorem shape31 (k : ℕ) (hk : k<8) : covered (31*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code248
  · exact code249
  · exact code250
  · exact code251
  · exact code252
  · exact code253
  · exact code254
  · exact code255
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape31
