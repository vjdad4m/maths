import TenBits63Part0
import TenBits63Part1
import TenBits63Part2
import TenBits63Part3
namespace Graffiti384b.Four29.Ten
theorem shape63 (k : ℕ) (hk : k<8) : covered (63*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code504
  · exact code505
  · exact code506
  · exact code507
  · exact code508
  · exact code509
  · exact code510
  · exact code511
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape63
