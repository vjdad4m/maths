import TenBits7Part0
import TenBits7Part1
import TenBits7Part2
import TenBits7Part3
namespace Graffiti384b.Four29.Ten
theorem shape7 (k : ℕ) (hk : k<8) : covered (7*8+k) := by
  have cases : k=0 ∨ k=1 ∨ k=2 ∨ k=3 ∨ k=4 ∨ k=5 ∨ k=6 ∨ k=7 := by omega
  rcases cases with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact code56
  · exact code57
  · exact code58
  · exact code59
  · exact code60
  · exact code61
  · exact code62
  · exact code63
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.shape7
