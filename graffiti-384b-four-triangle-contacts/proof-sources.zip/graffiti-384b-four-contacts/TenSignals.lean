import TruthWords

namespace Graffiti384b.Four29.Ten
open Words
abbrev Label := Fin 10
abbrev Pattern := List Label × List Label

def labels := List.finRange 10
def pairs := (labels.product labels).filter (fun z => z.1<z.2)
def anchors : List Label := [0,1,2,3]
def anchorPairs := (anchors.product anchors).filter (fun z => z.1<z.2)

/-- The six anchor-anchor edges have the first six bit positions.
The sixteen anchor-extra incidences have positions 6 through 21. -/
def position (i j : Label) :=
  let a := min i.val j.val
  let b := max i.val j.val
  if b<4 then b.choose 2+a else 6+(b-4)*4+a
def extraPair (i j : Label) : Bool := decide (4 ≤ i.val ∧ i.val<8 ∧ 4 ≤ j.val ∧ j.val<8)
def fixedPos (i j : Label) := (max i.val j.val-4).choose 2+(min i.val j.val-4)
def fixed (g : ℕ) (i j : Label) := (i != j) && g.testBit (fixedPos i j)
def preset (i j : Label) : Bool :=
  decide ((i=8 ∧ j.val<2) ∨ (j=8 ∧ i.val<2) ∨
    (i=9 ∧ 2 ≤ j.val ∧ j.val<4) ∨ (j=9 ∧ 2 ≤ i.val ∧ i.val<4))
def variableEdge (g n : ℕ) : ℕ :=
  if n<19 then column 19 n else if (g%8).testBit (n-19) then ones 19 else 0

def edge (g : ℕ) (i j : Label) : ℕ :=
  if i=j then 0 else if i.val<8 ∧ j.val<8 then
    if extraPair i j then (if fixed (g/8) i j then ones 19 else 0)
    else variableEdge g (position i j)
  else if preset i j then ones 19 else 0

def triangles (g : ℕ) (i : Label) := pairs.map fun (a,b) => edge g i a &&& edge g i b &&& edge g a b
def score (g : ℕ) (i : Label) := binary (triangles g i)
def rich (g : ℕ) := all (ones 19) (anchors.map (fun i => any (score g i).tail))
def distinct (g : ℕ) := all (ones 19) (anchorPairs.map (fun (a,b) => differ (score g a) (score g b)))

/-- Both ears are pinned opposite their two anchors. A choice at each extra
label pins it left, pins it right, or leaves it free. -/
def patterns : List Pattern := ([([0,1,2,3],[8,9]),([0,1,9],[2,3,8])] : List Pattern).flatMap fun seed =>
  ([4,5,6,7] : List Label).foldl (fun ps i => ps.flatMap fun (l,r) => [(l,r),(i::l,r),(l,i::r)]) [seed]

def supported (g : ℕ) (P Q : List Label) := all (ones 19) (P.map (fun i => atTwo (Q.map (edge g i))))
def works (g : ℕ) (a : Pattern) := supported g a.1 a.2 &&& supported g a.2 a.1
def available (g : ℕ) := any (patterns.map (works g))

set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
theorem pattern_data : ∀a∈patterns,(∀i∈a.1,i∉a.2) ∧ a.1.Nodup ∧ a.2.Nodup ∧
    (8∈a.1 ∨ 8∈a.2) ∧ (9∈a.1 ∨ 9∈a.2) := by decide

/-- Success of the protected-cut test on every assignment in one slice. -/
@[irreducible] def covered (code : ℕ) : Prop :=
  rich code &&& distinct code &&& available code = rich code &&& distinct code

def canonical : List ℕ := [0, 1, 3, 7, 11, 12, 13, 15, 30, 31, 63]

end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.pattern_data
