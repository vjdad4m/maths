import TenShape0
import TenShape1
import TenShape3
import TenShape7
import TenShape11
import TenShape12
import TenShape13
import TenShape15
import TenShape30
import TenShape31
import TenShape63
namespace Graffiti384b.Four29.Ten
/-- Eleven unlabeled extra graphs, with each of the 22 remaining edge bits unrestricted. -/
theorem table (g : ℕ) (h : g∈canonical) (k : ℕ) (hk : k<8) : rich (g*8+k) &&& distinct (g*8+k) &&& available (g*8+k) = rich (g*8+k) &&& distinct (g*8+k) := by
  suffices s : covered (g*8+k) by simpa only [covered] using s
  simp only [canonical,List.mem_cons,List.not_mem_nil,or_false] at h
  rcases h with rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl|rfl
  · exact shape0 k hk
  · exact shape1 k hk
  · exact shape3 k hk
  · exact shape7 k hk
  · exact shape11 k hk
  · exact shape12 k hk
  · exact shape13 k hk
  · exact shape15 k hk
  · exact shape30 k hk
  · exact shape31 k hk
  · exact shape63 k hk
end Graffiti384b.Four29.Ten
#print axioms Graffiti384b.Four29.Ten.table
