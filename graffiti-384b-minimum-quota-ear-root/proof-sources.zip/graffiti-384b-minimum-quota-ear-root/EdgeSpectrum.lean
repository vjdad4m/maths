import EscapingPins
namespace Graffiti384b.EarRooted
open Finset SimpleGraph FiveChoice TriangleFrame SixFront
open private Repair.edge_info Repair.support_sub Repair.edge_fiber from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def Avoids (v b : V) : Prop := ∃p∈link G v,b∉p

theorem mem_pair {a b c : V} (ab : G.Adj a b) (ac : G.Adj a c) (bc : G.Adj b c) :
    ({b,c}:Finset V)∈link G a := by
  refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset ((G.mem_neighborFinset ..).mpr ab)
    (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr ac)),card_pair bc.ne⟩,?_⟩
  intro i hi j hj ne
  simp only [mem_insert,mem_singleton] at hi hj
  rcases hi with rfl|rfl <;> rcases hj with rfl|rfl <;> first | exact (ne rfl).elim | exact bc | exact bc.symm

/-- Count the triangles through a specified edge from either endpoint. -/
theorem fiber_count {v b : V} (vb : G.Adj v b) :
    ((link G v).filter (fun p => b∈p)).card=nbr G v (G.neighborFinset b) := by
  let S := (G.neighborFinset b).filter (G.Adj v)
  have eq : (link G v).filter (fun p => b∈p)=S.image (fun w => ({b,w}:Finset V)) := by
    ext p
    constructor
    · intro h
      obtain ⟨pm,bp⟩ := mem_filter.mp h
      obtain ⟨sub,n,cl⟩ := Repair.edge_info G pm
      obtain ⟨w,wp,ne⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) b
      have bw := cl b bp w wp ne.symm
      have shape := eq_of_subset_of_card_le (insert_subset bp (singleton_subset_iff.mpr wp)) (by rw [n,card_pair ne.symm])
      exact mem_image.mpr ⟨w,mem_filter.mpr ⟨(G.mem_neighborFinset ..).mpr bw,(G.mem_neighborFinset ..).mp (sub wp)⟩,shape⟩
    · intro h
      obtain ⟨w,wm,rfl⟩ := mem_image.mp h
      obtain ⟨wb,vw⟩ := mem_filter.mp wm
      exact mem_filter.mpr ⟨mem_pair G vb vw ((G.mem_neighborFinset ..).mp wb),mem_insert_self ..⟩
  rw [eq]
  apply card_image_of_injOn
  intro x hx y hy hxy
  have bx := ((G.mem_neighborFinset ..).mp (mem_filter.mp hx).1).ne
  have by' := ((G.mem_neighborFinset ..).mp (mem_filter.mp hy).1).ne
  have er := congrArg (fun p : Finset V => p.erase b) hxy
  simpa [bx,bx.symm,by',by'.symm] using er

omit [DecidableEq V] in
theorem common_symm (x y : V) : nbr G x (G.neighborFinset y)=nbr G y (G.neighborFinset x) := by
  unfold nbr; congr 1; ext u; simp [and_comm]

private theorem all_through {x b : V} (no : ¬Avoids G x b) :
    (link G x).filter (fun p => b∈p)=link G x := by
  apply filter_true_of_mem
  intro p pm; by_contra out; exact no ⟨p,pm,out⟩

theorem avoids_smaller {x b : V} (xb : G.Adj x b) (lt : trianglesAt G b<trianglesAt G x) :
    Avoids G x b := by
  by_contra no
  have f := fiber_count G xb
  rw [all_through G no,common_symm G x b,←fiber_count G xb.symm] at f
  have le := card_filter_le (link G b) (fun p => x∈p)
  change (link G b).card<(link G x).card at lt
  omega

/-- If the triangle neighbors of b other than a have distinct scores at least two,
one of them has a triangle avoiding b. Isolated vertices and leaves have no effect. -/
theorem other_escape {a b : V} (positive : 0<trianglesAt G b)
    (rich : ∀x∈(Repair.linkSupport G b).erase a,2≤trianglesAt G x)
    (inj : Set.InjOn (trianglesAt G) (((Repair.linkSupport G b).erase a : Finset V) : Set V)) :
    ∃x∈(Repair.linkSupport G b).erase a,Avoids G x b := by
  classical
  let S := Repair.linkSupport G b
  have n : 2≤S.card := by
    obtain ⟨p,pm⟩ := card_pos.mp (show 0<(link G b).card from positive)
    have inside : p⊆S := fun v vm => mem_biUnion.mpr ⟨p,pm,vm⟩
    simpa only [(Repair.edge_info G pm).2.1] using card_le_card inside
  by_contra! no
  have cap (x : V) (xs : x∈S.erase a) : trianglesAt G x<S.card := by
    have xb := ((G.mem_neighborFinset ..).mp (Repair.support_sub G b (mem_erase.mp xs).2)).symm
    have f := fiber_count G xb
    rw [all_through G (no x xs),common_symm G x b,←fiber_count G xb.symm] at f
    have g := Repair.edge_fiber G (mem_erase.mp xs).2
    have inc : S.filter (G.Adj x)⊆S.erase x := fun z zm =>
      mem_erase.mpr ⟨(mem_filter.mp zm).2.ne.symm,(mem_filter.mp zm).1⟩
    have le := card_le_card inc
    rw [card_erase_of_mem (mem_erase.mp xs).2] at le
    change ((link G b).filter (fun p => x∈p)).card=(S.filter (G.Adj x)).card at g
    change (link G x).card<S.card
    omega
  have sub : (S.erase a).image (trianglesAt G)⊆Ico 2 S.card := by
    intro k km; obtain ⟨x,xs,rfl⟩ := mem_image.mp km
    exact mem_Ico.mpr ⟨rich x xs,cap x xs⟩
  have le := card_le_card sub
  rw [card_image_of_injOn inj,Nat.card_Ico] at le
  by_cases ha : a∈S
  · rw [card_erase_of_mem ha] at le; omega
  · rw [erase_eq_of_not_mem ha] at le; omega

end Graffiti384b.EarRooted
#print axioms Graffiti384b.EarRooted.fiber_count
#print axioms Graffiti384b.EarRooted.avoids_smaller
#print axioms Graffiti384b.EarRooted.other_escape
