import EarNeighborhood
namespace Graffiti384b.EarRooted
open Finset SimpleGraph TriangleFrame PrivatePatch PinnedColor34 FiveChoice SixFront
open private Repair.nbr_mono from Repair384b
open private TriangleFrame.private_escape from EarNeighborhood
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Arbitrary prescribed shores with a private triangle escape at each singly protected left pin. -/
theorem escaping_pins {W E : Finset V} (apart : Disjoint W E)
    (protectedQ : ∀v∈E,2≤nbr G v W) (touch : ∀a∈W,∃e∈E,G.Adj a e)
    (thin : NoThinPair G W E)
    (escape : ∀a∈W,nbr G a E=1 → ∃p∈link G a,Disjoint p E ∧ ¬p⊆W) :
    Extension G W E := by
  classical
  let C := (W∪E)ᶜ
  have wc : Disjoint W C := disjoint_compl_right.mono_left (show W⊆W∪E from subset_union_left)
  have ec : Disjoint E C := disjoint_compl_right.mono_left (show E⊆W∪E from subset_union_right)
  obtain ⟨P,Q,wp,eq',apart,right,left,one,free⟩ := PrivatePatch.assemble G wc apart ec protectedQ touch
  let D := P.filter (fun a => nbr G a Q<2)
  have classify {a : V} (ad : a∈D) : a∈W ∧ Weak G W C a ∧ nbr G a E=1 := by
    obtain ⟨ap,bad⟩ := mem_filter.mp ad
    have n : ¬(a∉W ∨ ¬Weak G W C a) := fun h => (not_lt_of_ge (left a ap h)) bad
    push_neg at n
    obtain ⟨e,em,ae⟩ := touch a n.1
    have ge : 1≤nbr G a E := card_pos.mpr ⟨e,mem_filter.mpr ⟨em,ae⟩⟩
    have le : nbr G a E≤nbr G a Q := Repair.nbr_mono G a eq'
    exact ⟨n.1,n.2,by omega⟩
  have choosePair (a : V) : ∃p : Finset V,a∈D →
      p⊆privateAt G W C a ∧ ∃x y,p={x,y} ∧ G.Adj a x ∧ G.Adj a y ∧ G.Adj x y := by
    by_cases ad : a∈D
    · obtain ⟨aw,weak,single⟩ := classify ad
      obtain ⟨p,pm,pe,pw⟩ := escape a aw single
      obtain ⟨x,y,shape,ax,ay,xy,inc⟩ := TriangleFrame.private_escape G aw weak (rfl : C=(W∪E)ᶜ) pm pe pw
      exact ⟨p,fun _ => ⟨inc,x,y,shape,ax,ay,xy⟩⟩
    · exact ⟨∅,fun h => (ad h).elim⟩
  choose A chosen using choosePair
  have F : Frame G P Q D A := by
    refine ⟨apart,filter_subset ..,fun a ad => one a (classify ad).1,?_,right,fun a ad => (chosen a ad).2,?_,?_⟩
    · intro a ap na
      exact Nat.le_of_not_gt (fun bad => na (mem_filter.mpr ⟨ap,bad⟩))
    · intro a ad; exact (free a (classify ad).1 (classify ad).2.1).mono_left (chosen a ad).1
    · intro a ad b bd ab
      apply disjoint_left.mpr
      intro x xa xb
      have am := (mem_filter.mp ((chosen a ad).1 xa)).2
      have bm := (mem_filter.mp ((chosen b bd).1 xb)).2
      exact ab (bm.2 a (classify ad).1 am.1)
  have prior := union_subset_union wp eq'
  have lifted : NoThinPair G P Q := fun a x m xo mo => thin a x m (fun h => xo (prior h)) (fun h => mo (prior h))
  obtain ⟨L,R,pl,qr,cut⟩ := simultaneous_extension G P Q D A F lifted
  exact ⟨L,R,wp.trans pl,eq'.trans qr,cut⟩

end Graffiti384b.EarRooted
#print axioms Graffiti384b.EarRooted.escaping_pins
