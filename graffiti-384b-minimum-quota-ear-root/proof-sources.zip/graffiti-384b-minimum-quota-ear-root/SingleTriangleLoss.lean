import EdgeSpectrum
namespace Graffiti384b.EarRooted
open Finset SimpleGraph FiveChoice
open private Repair.isolate Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem isolated_links {v x : V} (ne : v≠x) :
    (link G v).filter (fun p => x∉p)=link (Repair.isolate G x) v := by
  ext p
  simp only [link,Repair.linkEdges,mem_filter,mem_powersetCard,subset_iff,mem_neighborFinset]
  change (((∀ a ∈ p, G.Adj v a) ∧ p.card = 2) ∧ _) ∧ x ∉ p ↔
    ((∀ a ∈ p, G.Adj v a ∧ v ≠ x ∧ a ≠ x) ∧ p.card = 2) ∧
      (∀ a ∈ p, ∀ b ∈ p, a ≠ b → G.Adj a b ∧ a ≠ x ∧ b ≠ x)
  constructor
  · rintro ⟨⟨⟨hs,hs₂⟩,hp⟩,hn⟩
    exact ⟨⟨fun a ha => ⟨hs a ha, ne, fun ee => hn (ee ▸ ha)⟩,hs₂⟩,
      fun a ha b hb h => ⟨hp a ha b hb h,fun ee => hn (ee ▸ ha),fun ee => hn (ee ▸ hb)⟩⟩
  · rintro ⟨⟨hs,hs₂⟩,hp⟩
    exact ⟨⟨⟨fun a ha => (hs a ha).1,hs₂⟩, fun a ha b hb h => (hp a ha b hb h).1⟩,
      fun hx => (hs x hx).2.2 rfl⟩

private theorem reverse_fiber (x b : V) :
    ((link G x).filter (fun p => b∈p)).card=((link G b).filter (fun p => x∈p)).card := by
  by_cases xb : G.Adj x b
  · rw [fiber_count G xb,fiber_count G xb.symm,common_symm]
  · have none {v z : V} (vz : ¬G.Adj v z) : (link G v).filter (fun p => z∈p)=∅ := by
      apply eq_empty_of_forall_not_mem
      intro p m
      obtain ⟨pm,zp⟩ := mem_filter.mp m
      exact vz ((G.mem_neighborFinset ..).mp ((Repair.edge_info G pm).1 zp))
    rw [none xb,none (fun h => xb h.symm)]

/-- Isolating a vertex belonging to exactly one triangle reduces the two other triangle counts by
one each. Every other vertex keeps its count, irrespective of unsupported edges at the isolated vertex. -/
theorem isolated_score {e a b v : V} (ve : v≠e) (only : link G e={{a,b}}) :
    trianglesAt G v=trianglesAt (Repair.isolate G e) v+(if v∈({a,b}:Finset V) then 1 else 0) := by
  classical
  have split := filter_card_add_filter_neg_card_eq_card (s:=link G v) (fun p => e∈p)
  rw [isolated_links G ve,reverse_fiber G v e,only] at split
  change (link G v).card=(link (Repair.isolate G e) v).card+_
  by_cases vpair : v∈({a,b}:Finset V)
  · have eq : ({{a,b}} : Finset (Finset V)).filter (fun p => v∈p)={{a,b}} := by
      apply filter_true_of_mem; intro p pm; obtain rfl := mem_singleton.mp pm; exact vpair
    rw [eq,card_singleton] at split
    rw [if_pos vpair]; omega
  · have eq : ({{a,b}} : Finset (Finset V)).filter (fun p => v∈p)=∅ := by
      apply eq_empty_of_forall_not_mem; intro p pm
      obtain ⟨hp,vp⟩ := mem_filter.mp pm; obtain rfl := mem_singleton.mp hp; exact vpair vp
    rw [eq,card_empty] at split
    rw [if_neg vpair]; omega

theorem isolated_zero (e : V) : trianglesAt (Repair.isolate G e) e=0 := by
  apply Nat.eq_zero_of_not_pos
  intro pos
  obtain ⟨p,pm⟩ := card_pos.mp (show 0<(link (Repair.isolate G e) e).card from pos)
  obtain ⟨sub,size,_⟩ := Repair.edge_info _ pm
  obtain ⟨v,vp⟩ := card_pos.mp (by omega : 0<p.card)
  exact ((show (Repair.isolate G e).Adj e v from ((Repair.isolate G e).mem_neighborFinset ..).mp (sub vp))).2.1 rfl

end Graffiti384b.EarRooted
#print axioms Graffiti384b.EarRooted.isolated_links
#print axioms Graffiti384b.EarRooted.isolated_score
#print axioms Graffiti384b.EarRooted.isolated_zero
