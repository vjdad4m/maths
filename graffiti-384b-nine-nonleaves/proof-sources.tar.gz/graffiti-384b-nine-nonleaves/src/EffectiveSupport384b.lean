import Proof384b

namespace Graffiti384b.EffectiveSupport
open Finset SimpleGraph
set_option linter.unusedSectionVars false
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The roots in O retain their ambient neighbors inside P outside O and
receive the smallest fixed number of external neighbors compatible with
having ambient degree at least two. -/
def capacity (P O : Finset V) (v : V) : ℕ :=
  nbr G v (P \ O) + (2 - nbr G v P)

omit [Fintype V] in
theorem nbr_disjoint_union (v : V) {A B : Finset V} (dis : Disjoint A B) :
    nbr G v (A∪B) = nbr G v A + nbr G v B := by
  unfold nbr
  rw [filter_union, card_union_of_disjoint]
  exact dis.mono (filter_subset _ _) (filter_subset _ _)

theorem nbr_univ (v : V) : nbr G v univ = G.degree v := by
  rw [← card_neighborFinset_eq_degree]
  unfold nbr
  congr 1
  ext w
  simp

theorem nbr_partition (P : Finset V) (v : V) :
    nbr G v P + nbr G v Pᶜ = G.degree v := by
  rw [← nbr_disjoint_union G v disjoint_compl_right, union_compl, nbr_univ G]

theorem nbr_split (P O : Finset V) (sub : O⊆P) (v : V) :
    nbr G v (P \ O)+nbr G v O=nbr G v P := by
  have dis : Disjoint (P \ O) O := disjoint_left.mpr (fun _ h m=>(mem_sdiff.mp h).2 m)
  rw [←nbr_disjoint_union G v dis]
  congr 1
  ext x
  simp only [mem_union,mem_sdiff]
  constructor
  · rintro (h|h)
    · exact h.1
    · exact sub h
  · intro p
    by_cases xO : x∈O
    · exact Or.inr xO
    · exact Or.inl ⟨p,xO⟩

/-- The exact Boolean deficit criterion on the graph induced by P. -/
theorem capacity_failure (P O : Finset V) (sub : O⊆P) (v : V) :
    capacity G P O v < 2 ↔ nbr G v (P \ O) ≤ 1 ∧ 0 < nbr G v O := by
  have eq := nbr_split G P O sub v
  unfold capacity
  omega

theorem nbr_routed (P O : Finset V) (sub : O⊆P) (v : V) :
    nbr G v Oᶜ = nbr G v (P \ O) + nbr G v Pᶜ := by
  have dis : Disjoint (P \ O) Pᶜ := disjoint_left.mpr (fun _ h m=>mem_compl.mp m (mem_sdiff.mp h).1)
  rw [←nbr_disjoint_union G v dis]
  congr 1
  ext w
  simp only [mem_union,mem_sdiff,mem_compl]
  constructor
  · intro no
    by_cases inP : w∈P
    · exact Or.inl ⟨inP,no⟩
    · exact Or.inr inP
  · rintro (h|h)
    · exact h.2
    · exact fun wo=>h (sub wo)

theorem capacity_le_actual (P O : Finset V) (sub : O⊆P) (v : V)
    (nonleaf : 2≤G.degree v) : capacity G P O v ≤ nbr G v Oᶜ := by
  rw [nbr_routed G P O sub]
  have e := nbr_partition G P v
  unfold capacity
  omega

theorem two_domination_iff_routed (P O : Finset V) (sub : O⊆P) :
    TwoDominates G Oᶜ ↔ ∀ v∈O,2≤nbr G v (P \ O)+nbr G v Pᶜ := by
  unfold TwoDominates
  simp only [mem_compl,not_not,nbr_routed G P O sub]

theorem two_domination_iff_exact_support (P O : Finset V) (sub : O⊆P)
    (exact : ∀ v∈O,nbr G v Pᶜ=2-nbr G v P) :
    TwoDominates G Oᶜ ↔ ∀ v∈O,2≤capacity G P O v := by
  rw [two_domination_iff_routed G P O sub]
  constructor <;> intro h v hv
  · simpa only [capacity,←exact v hv] using h v hv
  · simpa only [capacity,exact v hv] using h v hv

theorem lift_omissions (P O : Finset V) (sub : O⊆P) (nonleaf : ∀ v∈O,2≤G.degree v)
    (effective : ∀ v∈O,2≤capacity G P O v) : TwoDominates G Oᶜ := by
  intro v hv
  have ho : v∈O := by simpa only [mem_compl,not_not] using hv
  exact (effective v ho).trans (capacity_le_actual G P O sub v (nonleaf v ho))

theorem gamma_le_from_effective (P O : Finset V) (sub : O⊆P) (nonleaf : ∀ v∈O,2≤G.degree v)
    (effective : ∀ v∈O,2≤capacity G P O v) : gamma G≤Fintype.card V-O.card := by
  rw [←card_compl]
  exact Nat.sInf_le ⟨_,lift_omissions G P O sub nonleaf effective,rfl⟩

/-- Under a counterexample, every quota-size board omission needs an explicit
root witnessing the Boolean failure condition. -/
theorem checked_failure_marker (fail : bound G<gamma G) (P O : Finset V) (sub : O⊆P)
    (nonleaf : ∀ v∈O,2≤G.degree v) (many : ((types G).card+1)/2≤O.card) :
    ∃ v∈O,nbr G v (P\O)≤1 ∧ 0<nbr G v O := by
  classical
  by_contra! bad
  have good (v : V) (vo : v∈O) : 2≤capacity G P O v := by
    by_contra! hd
    obtain ⟨few,one⟩ := (capacity_failure G P O sub v).mp hd
    have zero := bad v vo few
    omega
  have le := gamma_le_from_effective G P O sub nonleaf good
  unfold bound at fail
  omega

#print axioms Graffiti384b.EffectiveSupport.capacity_failure
#print axioms Graffiti384b.EffectiveSupport.two_domination_iff_exact_support
#print axioms Graffiti384b.EffectiveSupport.gamma_le_from_effective
#print axioms Graffiti384b.EffectiveSupport.checked_failure_marker
end Graffiti384b.EffectiveSupport
