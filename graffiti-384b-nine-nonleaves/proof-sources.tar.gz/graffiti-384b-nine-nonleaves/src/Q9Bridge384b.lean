import Q9GraphTransfer384b
import Q9Original384b

namespace Graffiti384b.Q9
open SimpleGraph Finset

theorem trianglePalette_eq_positiveScores (G : SimpleGraph (Fin 9))
    [DecidableRel G.Adj] : trianglePalette G = Q9Original.PositiveScores G := by
  ext t
  simp only [trianglePalette, Q9Original.PositiveScores, types, mem_erase, mem_image, mem_filter,
    mem_univ, true_and]
  constructor
  · rintro ⟨i,hi,rfl⟩
    exact ⟨Nat.ne_of_gt hi, i, rfl⟩
  · rintro ⟨ht,i,rfl⟩
    exact ⟨i,Nat.pos_of_ne_zero ht,rfl⟩

theorem nonleaf_nine_from_distinct_certificates
    (covers : ∀ (s : Fin 16) (bits : Nat→Bool),
      score (adj (forms s) bits) 0 ≠ score (adj (forms s) bits) 1 →
      Ranked (adj (forms s) bits)→
      ∃ a b c d,Effective (adj (forms s) bits) (adj (forms s) bits) a b c d)
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (nine : (nonleaves G).card = 9) (diverse : 9 ≤ (types G).card) : gamma G ≤ bound G := by
  apply Q9Original.nonleaf_nine_of_fin9_effective _ G nine diverse
  intro K dk
  letI := dk
  intro h
  rw [←trianglePalette_eq_positiveScores] at h
  exact quota_from_distinct_certificates K covers h

#print axioms nonleaf_nine_from_distinct_certificates
end Graffiti384b.Q9
