import Q9ScoreTransfer384b
import Q9AnchorNormalize384b

namespace Graffiti384b.Q9
open Finset SimpleGraph
set_option linter.unusedSectionVars false
set_option maxHeartbeats 4500000

private def pairsSeven : Fin 21→Label×Label :=
  ![(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(3,4),(3,5),(3,6),(3,7),(3,8),(4,5),(4,6),(4,7),(4,8),(5,6),(5,7),(5,8),(6,7),(6,8),(7,8)]

private theorem slot_total : ∀ i j : Label, 2≤i.val→i<j→
    ∃ k : Fin 21,k.val=slot i.val j.val ∧ pairsSeven k=(i,j) := by decide

private theorem data_eq : ∀ s : Fin 16,
    let S := forms s
    let T := Graffiti384bQ9.anchorTable s
    (S.edge01=true↔T.1=1) ∧ (if S.edge01 then 1 else 0)=T.1 ∧
      S.d0=T.2.1 ∧ S.d1=T.2.2.1 ∧ S.common=T.2.2.2 := by decide

private theorem degree_triangle_bound {W : Type*} [Fintype W] [DecidableEq W] (J : SimpleGraph W)
    [DecidableRel J.Adj] (v : W) : trianglesAt J v≤(J.degree v).choose 2 := by
  unfold trianglesAt
  exact (card_filter_le _ _).trans_eq (by rw [card_powersetCard,card_neighborFinset_eq_degree])

variable (G : SimpleGraph Label) [DecidableRel G.Adj]

/-- The actual graph supplies the free bits; all anchor rows remain fixed. -/
theorem entries_of_shape (s : Fin 16) (p : Label≃Label)
    (edge01 : G.Adj (p 0) (p 1)↔(Graffiti384bQ9.anchorTable s).1=1)
    (contact : ∀ j : Label,2≤j.val→
      let t := Graffiti384bQ9.anchorTable s
      let a := t.2.1-t.1
      let b := t.2.2.1-t.1
      let c := t.2.2.2
      let r := j.val-2
      (G.Adj (p 0) (p j)↔r<a) ∧
      (G.Adj (p 1) (p j)↔r<c ∨ (a≤r ∧ r<a+b-c))) :
    ∃ bits : Nat→Bool, ∀ i j,adj (forms s) bits i j=true↔G.Adj (p i) (p j) := by
  let bits (k : Nat) := if h:k<21 then
    let t := pairsSeven ⟨k,h⟩
    decide (G.Adj (p t.1) (p t.2))
    else false
  refine ⟨bits,?_⟩
  have ordered (i j : Label) (lt : i<j) : adj (forms s) bits i j=true↔G.Adj (p i) (p j) := by
    have ni : i.val < j.val := lt
    dsimp [adj]
    simp only [min_eq_left ni.le,max_eq_right ni.le,if_neg (ne_of_lt ni)]
    have eq := data_eq s
    by_cases z : i.val=0
    · have zi : i=0 := Fin.ext z
      rw [if_pos z]
      by_cases w : j.val=1
      · have wj : j=1 := Fin.ext w
        simpa only [if_pos w,zi,wj] using eq.1.trans edge01.symm
      have up : 2≤j.val := by omega
      rw [if_neg w,zi]
      simpa only [anchorZero,eq.2.1,eq.2.2.1,decide_eq_true_eq] using (contact j up).1.symm
    rw [if_neg z]
    by_cases o : i.val=1
    · have oi : i=1 := Fin.ext o
      have up : 2≤j.val := by omega
      rw [if_pos o,oi]
      simpa only [anchorOne,eq.2.1,eq.2.2.1,eq.2.2.2.1,eq.2.2.2.2,decide_eq_true_eq]
        using (contact j up).2.symm
    rw [if_neg o]
    obtain ⟨k,kVal,matchPair⟩ := slot_total i j (by omega) lt
    rw [←kVal]
    simp only [bits,dif_pos k.isLt,matchPair,decide_eq_true_eq]
  intro i j
  rcases lt_trichotomy i j with lo|same|hi
  · exact ordered i j lo
  · subst j
    simp [adj,G.loopless]
  · have swap : adj (forms s) bits i j = adj (forms s) bits j i := by simp [adj,min_comm,max_comm]
    rw [swap,SimpleGraph.adj_comm]
    exact ordered j i hi


def trianglePalette : Finset Nat :=
  (univ.filter fun v=>0<trianglesAt G v).image (trianglesAt G)

theorem model_palette (p : Label ≃ Label) (E : Rel)
    (fits : ∀ i j,E i j=true↔G.Adj (p i) (p j)) :
    palette E = trianglePalette G := by
  ext q
  simp only [palette, trianglePalette, mem_image, mem_filter, mem_univ, true_and,
    score_eq_triangles G p E fits]
  constructor
  · rintro ⟨v,hv,he⟩
    exact ⟨p v,hv,he⟩
  · rintro ⟨v,hv,he⟩
    obtain ⟨i,rfl⟩ := p.surjective v
    exact ⟨i,hv,he⟩

theorem top_two_values (hP : 8 ≤ (trianglePalette G).card) :
    ∃ x y : Label, trianglesAt G y < trianglesAt G x ∧ 7 ≤ trianglesAt G y ∧
      (∀ v, trianglesAt G v ≤ trianglesAt G x) ∧
      (∀ v, trianglesAt G v ≠ trianglesAt G x → trianglesAt G v ≤ trianglesAt G y) := by
  let P := trianglePalette G
  have hP0 : 0<P.card := by change 8≤P.card at hP; omega
  obtain ⟨X,Xm,MX⟩ := exists_max_image P id (card_pos.mp hP0)
  let Q := P.erase X
  have hQ : 7≤Q.card := by
    change 8≤P.card at hP
    simp only [Q, card_erase_of_mem Xm]
    omega
  obtain ⟨Y,Ym,MY⟩ := exists_max_image Q id (card_pos.mp (by omega))
  obtain ⟨YX,YP⟩ := mem_erase.mp Ym
  have YXlt : Y<X := lt_of_le_of_ne (MX _ YP) YX
  have rangeS : Q ⊆ (Finset.range (Y+1)).erase 0 := by
    intro z zQ
    have hm := MY _ zQ
    have zP := (mem_erase.mp zQ).2
    obtain ⟨v,vp,rfl⟩ := mem_image.mp zP
    exact mem_erase.mpr ⟨by have := (mem_filter.mp vp).2; omega,
      mem_range.mpr (by simpa using Nat.lt_succ_of_le hm)⟩
  have cr := card_le_card rangeS
  rw [Finset.card_erase_of_mem (show 0∈Finset.range (Y+1) by simp), card_range] at cr
  have Y7 : 7≤Y := by omega
  obtain ⟨x,xm,hx⟩ := mem_image.mp Xm
  obtain ⟨y,ym,hy⟩ := mem_image.mp YP
  refine ⟨x,y,by omega,by omega,?_,?_⟩
  · intro v
    by_cases vv : 0<trianglesAt G v
    · have h := MX _ (mem_image.mpr ⟨v,mem_filter.mpr ⟨mem_univ _,vv⟩,rfl⟩)
      change trianglesAt G v≤X at h
      omega
    · omega
  · intro v n
    by_cases vv : 0<trianglesAt G v
    · have h := MY _ (mem_erase.mpr ⟨by omega,
        mem_image.mpr ⟨v,mem_filter.mpr ⟨mem_univ _,vv⟩,rfl⟩⟩)
      change trianglesAt G v≤Y at h
      omega
    · omega

private theorem five_degree {v : Label} (score : 7≤trianglesAt G v) : 5≤G.degree v := by
  have le := degree_triangle_bound G v
  by_contra low
  have d4 : G.degree v≤4 := Nat.lt_succ_iff.mp (Nat.lt_of_not_ge low)
  have r := Nat.choose_le_choose 2 d4
  have n4 : (4:Nat).choose 2=6 := by decide
  omega


/-- The effective retained set on the nine-vertex board. -/
def EffectiveSet (D : Finset Label) : Prop :=
  ∀ v : Label, v∉D →
    (∃ x y, x∈D ∧ y∈D ∧ x≠y ∧ G.Adj v x ∧ G.Adj v y) ∨
    (∀ w : Label, w∉D → ¬ G.Adj v w)

theorem quota_from_distinct_certificates
    (covers : ∀ (s : Fin 16) (bits : Nat→Bool),
      score (adj (forms s) bits) 0 ≠ score (adj (forms s) bits) 1 →
      Ranked (adj (forms s) bits)→
      ∃ a b c d,Effective (adj (forms s) bits) (adj (forms s) bits) a b c d)
    (diverse : 8≤(trianglePalette G).card) :
    ∃ D : Finset Label,D.card≤4 ∧ EffectiveSet G D := by
  obtain ⟨x,y,ord,yl,mx,my⟩ := top_two_values G diverse
  have xy : x≠y := fun eq=>by rw [eq] at ord; omega
  have xl : 7≤trianglesAt G x := le_trans yl ord.le
  by_cases large : 5≤(G.neighborFinset x∩G.neighborFinset y).card
  · obtain ⟨S,sub,sz⟩ := exists_subset_card_eq large
    have count : Sᶜ.card=4 := by rw [card_compl,sz]; decide
    refine ⟨Sᶜ,count.le,?_⟩
    intro z zo
    have zin : z∈S := by simpa using zo
    have edges := mem_inter.mp (sub zin)
    have xa := (G.mem_neighborFinset _ _).mp edges.1
    have ya := (G.mem_neighborFinset _ _).mp edges.2
    have xo : x∈Sᶜ := mem_compl.mpr (fun xs=>G.loopless x
      ((G.mem_neighborFinset _ _).mp (mem_inter.mp (sub xs)).1))
    have yo : y∈Sᶜ := mem_compl.mpr (fun ys=>G.loopless y
      ((G.mem_neighborFinset _ _).mp (mem_inter.mp (sub ys)).2))
    exact Or.inl ⟨x,y,xo,yo,xy,xa.symm,ya.symm⟩
  obtain ⟨s,p,roots,edge01,contact⟩ := Graffiti384bQ9.normalize_two_anchors G x y xy
    (five_degree G xl) (five_degree G yl) (by omega)
  obtain ⟨bits,fit⟩ := entries_of_shape G s p edge01 contact
  let E := adj (forms s) bits
  have ex := score_eq_triangles G p E fit
  have pa := model_palette G p E fit
  have atAnchor (r : Fin 2) : p (anchor r)=x ∨ p (anchor r)=y := by
    fin_cases r
    · exact roots.imp And.left And.left
    · exact roots.symm.imp And.right And.right
  have rank : Ranked E := by
    refine ⟨by rwa [pa],?_,?_⟩
    · intro r
      rw [ex]
      rcases atAnchor r with h|h
      · rwa [h]
      · rwa [h]
    · intro v w v2 w2 ne r h
      have notRoot (i : Label) (hi : 2≤i.val) (j : Fin 2) : anchor j≠i := by
        intro eq
        have eq' : j.val=i.val := congrArg Fin.val eq
        have := j.isLt
        omega
      have valClass (i : Label) (hi : trianglesAt G y≤score E i) :
          trianglesAt G (p i)=trianglesAt G x ∨ trianglesAt G (p i)=trianglesAt G y := by
        by_cases m : trianglesAt G (p i)=trianglesAt G x
        · exact Or.inl m
        · exact Or.inr (by have := my _ m; rw [ex] at hi; omega)
      have R (i : Label) (hi : 2≤i.val) (big : score E (anchor r)≤score E i) :
          ∃ a, a≠v ∧ a≠w ∧ score E a=score E i := by
        have lo : trianglesAt G y≤score E i := by
          apply le_trans _ big
          rw [ex]
          rcases atAnchor r with hx|hy
          · simpa [hx] using ord.le
          · simp [hy]
        have atOriginal : ∃ j : Fin 2, trianglesAt G (p (anchor j))=trianglesAt G (p i) := by
          rcases valClass i lo with a|b <;> rcases roots with ⟨hx,hy⟩|⟨hy,hx⟩
          · exact ⟨0,by simpa only [a] using congrArg (trianglesAt G) hx⟩
          · exact ⟨1,by simpa only [a] using congrArg (trianglesAt G) hx⟩
          · exact ⟨1,by simpa only [b] using congrArg (trianglesAt G) hy⟩
          · exact ⟨0,by simpa only [b] using congrArg (trianglesAt G) hy⟩
        obtain ⟨j,jj⟩ := atOriginal
        exact ⟨anchor j,notRoot v v2 j,notRoot w w2 j,by simpa only [ex] using jj⟩
      have contra := palette_drop ne (by
        intro i hi _
        rcases hi with rfl|rfl
        · exact R _ v2 h.1
        · exact R _ w2 h.2)
      rw [pa] at contra
      omega
  have neqScore : score E 0 ≠ score E 1 := by
    rw [ex,ex]
    rcases roots with ⟨hx,hy⟩|⟨hy,hx⟩
    · rw [hx,hy]
      omega
    · rw [hy,hx]
      omega
  obtain ⟨a,b,c,d,h⟩ := covers s bits neqScore rank
  let D := (D4 a b c d).map p.toEmbedding
  have count : D.card≤4 := by
    rw [card_map]
    unfold D4
    have h₁ := card_insert_le a ({b,c,d}:Finset Label)
    have h₂ := card_insert_le b ({c,d}:Finset Label)
    have h₃ := card_insert_le c ({d}:Finset Label)
    rw [card_singleton] at h₃
    omega
  refine ⟨D,count,?_⟩
  have mem (u : Label) : p u∈D↔u∈D4 a b c d := by simp [D]
  intro u hu
  obtain ⟨v,rfl⟩ := p.surjective u
  rcases h v (fun hv=>hu ((mem v).2 hv)) with ⟨i,j,ii,jj,ij,vi,vj⟩|off
  · exact Or.inl ⟨p i,p j,(mem i).2 ii,(mem j).2 jj,
      fun e=>ij (p.injective e),(fit _ _).1 vi,(fit _ _).1 vj⟩
  · right
    intro w hw vw
    obtain ⟨j,rfl⟩ := p.surjective w
    have f := off j (fun hj=>hw ((mem j).2 hj))
    exact Bool.noConfusion (((fit _ _).2 vw).symm.trans f)

#print axioms quota_from_distinct_certificates
end Graffiti384b.Q9
