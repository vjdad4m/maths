import Q8Original384b
import EffectiveSupport384b

namespace Graffiti384b.Q9Original
open Finset SimpleGraph
open private Prune.outside_zero from Prune384b
open private Q8Original.triangle_comap from Q8Original384b

def PositiveScores {W : Type*} [Fintype W] [DecidableEq W]
    (H : SimpleGraph W) [DecidableRel H.Adj] : Finset ℕ :=
  (types H).erase 0

/-- Every omitted vertex either already has two retained core neighbors or
has no neighbor among the omitted vertices. -/
def Effective {W : Type*} (H : SimpleGraph W) [DecidableEq W]
    (D : Finset W) : Prop :=
  ∀ v ∉ D, (∃ x y, x∈D ∧ y∈D ∧ x≠y ∧ H.Adj v x ∧ H.Adj v y) ∨
    (∀ w ∉ D, ¬H.Adj v w)

/-- Any Fin 9 effective-support quota closes the original graph inequality
for exactly nine nonleaves and at least nine triangle-count types. -/
theorem nonleaf_nine_of_fin9_effective
    (quota : ∀ (K : SimpleGraph (Fin 9)) (dk : DecidableRel K.Adj),
      letI := dk
      8 ≤ (PositiveScores K).card →
        ∃ D : Finset (Fin 9), D.card ≤ 4 ∧ Effective K D)
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (nine : (nonleaves G).card = 9) (diverse : 9 ≤ (types G).card) :
    gamma G ≤ bound G := by
  classical
  let P := nonleaves G
  let H := G.induce (P : Set V)
  let e : Fin 9 ≃ P := (Fintype.equivFinOfCardEq ((Fintype.card_coe P).trans nine)).symm
  let K := H.comap (e : Fin 9→P)
  let dk : DecidableRel K.Adj := inferInstanceAs (DecidableRel (H.comap (e : Fin 9→P)).Adj)
  let f : Fin 9 ↪ V := e.toEmbedding.trans (Function.Embedding.subtype _)
  have finP (i : Fin 9) : f i ∈ P := (e i).property
  have allP (v : V) (hv : v∈P) : ∃ j, f j=v := by
    exact ⟨e.symm ⟨v,hv⟩,congrArg Subtype.val (e.apply_symm_apply ⟨v,hv⟩)⟩
  have score (i : Fin 9) : trianglesAt K i = trianglesAt G (f i) :=
    (Q8Original.triangle_comap H e i).trans (Prune.counts_preserved G P Subset.rfl (e i))
  have cover : types G ⊆ insert 0 (PositiveScores K) := by
    intro s hs
    obtain ⟨v,_,rfl⟩ := mem_image.mp hs
    by_cases z : trianglesAt G v = 0
    · rw [z]; exact mem_insert_self _ _
    have vp : v∈P := Classical.byContradiction fun no =>
      z (Prune.outside_zero G no)
    obtain ⟨i,hi⟩ := allP v vp
    have t : trianglesAt K i = trianglesAt G v := (score i).trans (congrArg (trianglesAt G) hi)
    apply mem_insert_of_mem
    exact mem_erase.mpr ⟨z,mem_image.mpr ⟨i,mem_univ _,t⟩⟩
  have cc := card_le_card cover
  have inc := card_insert_le 0 (PositiveScores K)
  have up : (PositiveScores K).card ≤ 9 :=
    (card_le_card (erase_subset _ _)).trans (card_image_le.trans_eq (by decide))
  obtain ⟨D,dcard,eff⟩ := quota K dk (by omega)
  let O := Dᶜ.map f
  have ocard : 5 ≤ O.card := by
    have eqn := card_compl D
    rw [Fintype.card_fin] at eqn
    change 5 ≤ (Dᶜ.map f).card
    rw [card_map,eqn]
    omega
  have sub : O ⊆ P := by
    intro v hv
    obtain ⟨i,_,rfl⟩ := mem_map.mp hv
    exact finP i
  have ambient_eff (v : V) (vo : v∈O) : 2 ≤ EffectiveSupport.capacity G P O v := by
    obtain ⟨i,hi,rfl⟩ := mem_map.mp vo
    have noD := mem_compl.mp hi
    rcases eff i noD with ⟨x,y,hx,hy,hxy,hix,hiy⟩ | none
    · have retain (j : Fin 9) (hj : j∈D) : f j∈P\O := by
        refine mem_sdiff.mpr ⟨finP j,?_⟩
        intro hm
        obtain ⟨k,km,eq⟩ := mem_map.mp hm
        exact mem_compl.mp km ((f.injective eq).symm ▸ hj)
      have card : 1 < ((P\O).filter (G.Adj (f i))).card :=
        one_lt_card.mpr ⟨f x,mem_filter.mpr ⟨retain x hx,hix⟩,
          f y,mem_filter.mpr ⟨retain y hy,hiy⟩,fun eq => hxy (f.injective eq)⟩
      unfold EffectiveSupport.capacity nbr
      omega
    · have zero : nbr G (f i) O = 0 := by
        unfold nbr
        rw [card_eq_zero]
        apply subset_empty.mp
        intro w hw
        obtain ⟨ho,ad⟩ := mem_filter.mp hw
        obtain ⟨j,hj,rfl⟩ := mem_map.mp ho
        exact False.elim (none j (mem_compl.mp hj) ad)
      have crit := EffectiveSupport.capacity_failure G P O sub (f i)
      omega
  have nonleaf (v : V) (vo : v∈O) : 2 ≤ G.degree v := (mem_filter.mp (sub vo)).2
  have g := EffectiveSupport.gamma_le_from_effective G P O sub nonleaf ambient_eff
  unfold bound
  omega

end Graffiti384b.Q9Original

#print axioms Graffiti384b.Q9Original.nonleaf_nine_of_fin9_effective
