import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape0T2 : Tree := (.split 6 (.split 15 (.tip (.small 0)) (.split 20 (.tip (.small 1)) (.tip (.cover 0 1 5 7)))) (.split 15 (.split 20 (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover 0 1 2 8))))) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 7))))) (.split 20 (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 5))))) (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 5)))) (.split 4 (.tip (.small 1)) (.tip (.cover 0 1 2 8))))) (.tip (.cover 0 1 5 7)))))
private theorem q9Shape0T2OK : treeOK (forms 0) 0 3 q9Shape0T2=true := by decide

private def q9Shape0T4 : Tree := (.split 15 (.split 20 (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover 0 1 2 8))))) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 7))))) (.split 20 (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 5))))) (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 5)))) (.split 4 (.tip (.small 1)) (.tip (.cover 0 1 2 8))))) (.tip (.cover 0 1 5 7))))
private theorem q9Shape0T4OK : treeOK (forms 0) 2 65 q9Shape0T4=true := by decide

private def q9Shape0T7 : Tree := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5))))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 6)))) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8)))))
private theorem q9Shape0T7OK : treeOK (forms 0) 66 1081345 q9Shape0T7=true := by decide

private def q9Shape0T8 : Tree := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 3 7)))) (.split 5 (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 1 2 5))))) (.split 3 (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.split 7 (.tip (.small 0)) (.tip (.cover 2 3 6 7)))) (.split 5 (.split 7 (.tip (.small 0)) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 1 2 6)))) (.tip (.cover 0 1 2 7))))
private theorem q9Shape0T8OK : treeOK (forms 0) 1048642 32769 q9Shape0T8=true := by decide

private def q9Shape0T6 : Tree := .split 20 q9Shape0T7 q9Shape0T8
private theorem q9Shape0T6OK : treeOK (forms 0) 66 32769 q9Shape0T6=true := by
  change (treeOK (forms 0) 66 (32769 ||| 2^20) q9Shape0T7 &&
    treeOK (forms 0) (66 ||| 2^20) 32769 q9Shape0T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T7OK,q9Shape0T8OK⟩

private def q9Shape0T11 : Tree := (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5)))) (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 1 2 3 5)))) (.tip (.cover 1 2 5 7)))) (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 2 3 5 8)))) (.tip (.cover 1 2 5 8))) (.tip (.cover 0 1 2 5)))))
private theorem q9Shape0T11OK : treeOK (forms 0) 32834 1048581 q9Shape0T11=true := by decide

private def q9Shape0T12 : Tree := (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 6 7))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 1 2 3 6))) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 6 8))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5)))) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape0T12OK : treeOK (forms 0) 32838 1048577 q9Shape0T12=true := by decide

private def q9Shape0T10 : Tree := .split 2 q9Shape0T11 q9Shape0T12
private theorem q9Shape0T10OK : treeOK (forms 0) 32834 1048577 q9Shape0T10=true := by
  change (treeOK (forms 0) 32834 (1048577 ||| 2^2) q9Shape0T11 &&
    treeOK (forms 0) (32834 ||| 2^2) 1048577 q9Shape0T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T11OK,q9Shape0T12OK⟩

private def q9Shape0T13 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape0T13OK : treeOK (forms 0) 1081410 1 q9Shape0T13=true := by decide

private def q9Shape0T9 : Tree := .split 20 q9Shape0T10 q9Shape0T13
private theorem q9Shape0T9OK : treeOK (forms 0) 32834 1 q9Shape0T9=true := by
  change (treeOK (forms 0) 32834 (1 ||| 2^20) q9Shape0T10 &&
    treeOK (forms 0) (32834 ||| 2^20) 1 q9Shape0T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T10OK,q9Shape0T13OK⟩

private def q9Shape0T5 : Tree := .split 15 q9Shape0T6 q9Shape0T9
private theorem q9Shape0T5OK : treeOK (forms 0) 66 1 q9Shape0T5=true := by
  change (treeOK (forms 0) 66 (1 ||| 2^15) q9Shape0T6 &&
    treeOK (forms 0) (66 ||| 2^15) 1 q9Shape0T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T6OK,q9Shape0T9OK⟩

private def q9Shape0T3 : Tree := .split 6 q9Shape0T4 q9Shape0T5
private theorem q9Shape0T3OK : treeOK (forms 0) 2 1 q9Shape0T3=true := by
  change (treeOK (forms 0) 2 (1 ||| 2^6) q9Shape0T4 &&
    treeOK (forms 0) (2 ||| 2^6) 1 q9Shape0T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T4OK,q9Shape0T5OK⟩

private def q9Shape0T1 : Tree := .split 1 q9Shape0T2 q9Shape0T3
private theorem q9Shape0T1OK : treeOK (forms 0) 0 1 q9Shape0T1=true := by
  change (treeOK (forms 0) 0 (1 ||| 2^1) q9Shape0T2 &&
    treeOK (forms 0) (0 ||| 2^1) 1 q9Shape0T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T2OK,q9Shape0T3OK⟩

private def q9Shape0T16 : Tree := (.split 15 (.split 20 (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.tip (.cover 0 1 2 8))))) (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 7))))) (.split 20 (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 5))))) (.split 3 (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 5)))) (.split 4 (.tip (.small 1)) (.tip (.cover 0 1 2 8))))) (.tip (.cover 0 1 5 7))))
private theorem q9Shape0T16OK : treeOK (forms 0) 1 66 q9Shape0T16=true := by decide

private def q9Shape0T19 : Tree := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5))))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 6)))) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8)))))
private theorem q9Shape0T19OK : treeOK (forms 0) 65 1081346 q9Shape0T19=true := by decide

private def q9Shape0T20 : Tree := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 3 7)))) (.split 5 (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 1 2 5))))) (.split 3 (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.tip (.cover 0 1 2 6)))) (.tip (.cover 0 1 2 7))))
private theorem q9Shape0T20OK : treeOK (forms 0) 1048641 32770 q9Shape0T20=true := by decide

private def q9Shape0T18 : Tree := .split 20 q9Shape0T19 q9Shape0T20
private theorem q9Shape0T18OK : treeOK (forms 0) 65 32770 q9Shape0T18=true := by
  change (treeOK (forms 0) 65 (32770 ||| 2^20) q9Shape0T19 &&
    treeOK (forms 0) (65 ||| 2^20) 32770 q9Shape0T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T19OK,q9Shape0T20OK⟩

private def q9Shape0T24 : Tree := (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5))))
private theorem q9Shape0T24OK : treeOK (forms 0) 32833 1048590 q9Shape0T24=true := by decide

private def q9Shape0T25 : Tree := (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 1 2 3 5)))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 0 1 2 3))) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 1 3 5 8)))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5))))
private theorem q9Shape0T25OK : treeOK (forms 0) 32841 1048582 q9Shape0T25=true := by decide

private def q9Shape0T23 : Tree := .split 3 q9Shape0T24 q9Shape0T25
private theorem q9Shape0T23OK : treeOK (forms 0) 32833 1048582 q9Shape0T23=true := by
  change (treeOK (forms 0) 32833 (1048582 ||| 2^3) q9Shape0T24 &&
    treeOK (forms 0) (32833 ||| 2^3) 1048582 q9Shape0T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T24OK,q9Shape0T25OK⟩

private def q9Shape0T26 : Tree := (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 0 1 2 3)))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 1 2 3 6))) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 0 2 3 8)))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 1 3 6 8))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5)))) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape0T26OK : treeOK (forms 0) 32837 1048578 q9Shape0T26=true := by decide

private def q9Shape0T22 : Tree := .split 2 q9Shape0T23 q9Shape0T26
private theorem q9Shape0T22OK : treeOK (forms 0) 32833 1048578 q9Shape0T22=true := by
  change (treeOK (forms 0) 32833 (1048578 ||| 2^2) q9Shape0T23 &&
    treeOK (forms 0) (32833 ||| 2^2) 1048578 q9Shape0T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T23OK,q9Shape0T26OK⟩

private def q9Shape0T27 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape0T27OK : treeOK (forms 0) 1081409 2 q9Shape0T27=true := by decide

private def q9Shape0T21 : Tree := .split 20 q9Shape0T22 q9Shape0T27
private theorem q9Shape0T21OK : treeOK (forms 0) 32833 2 q9Shape0T21=true := by
  change (treeOK (forms 0) 32833 (2 ||| 2^20) q9Shape0T22 &&
    treeOK (forms 0) (32833 ||| 2^20) 2 q9Shape0T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T22OK,q9Shape0T27OK⟩

private def q9Shape0T17 : Tree := .split 15 q9Shape0T18 q9Shape0T21
private theorem q9Shape0T17OK : treeOK (forms 0) 65 2 q9Shape0T17=true := by
  change (treeOK (forms 0) 65 (2 ||| 2^15) q9Shape0T18 &&
    treeOK (forms 0) (65 ||| 2^15) 2 q9Shape0T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T18OK,q9Shape0T21OK⟩

private def q9Shape0T15 : Tree := .split 6 q9Shape0T16 q9Shape0T17
private theorem q9Shape0T15OK : treeOK (forms 0) 1 2 q9Shape0T15=true := by
  change (treeOK (forms 0) 1 (2 ||| 2^6) q9Shape0T16 &&
    treeOK (forms 0) (1 ||| 2^6) 2 q9Shape0T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T16OK,q9Shape0T17OK⟩

private def q9Shape0T32 : Tree := (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 0 1 3 8)))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.unordered 2 3 0))))) (.tip (.cover 0 1 2 5)))))
private theorem q9Shape0T32OK : treeOK (forms 0) 3 1081412 q9Shape0T32=true := by decide

private def q9Shape0T33 : Tree := (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 0 1 3 8)))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.unordered 2 3 0))))) (.tip (.cover 0 1 2 6)))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape0T33OK : treeOK (forms 0) 7 1081408 q9Shape0T33=true := by decide

private def q9Shape0T31 : Tree := .split 2 q9Shape0T32 q9Shape0T33
private theorem q9Shape0T31OK : treeOK (forms 0) 3 1081408 q9Shape0T31=true := by
  change (treeOK (forms 0) 3 (1081408 ||| 2^2) q9Shape0T32 &&
    treeOK (forms 0) (3 ||| 2^2) 1081408 q9Shape0T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T32OK,q9Shape0T33OK⟩

private def q9Shape0T34 : Tree := (.split 2 (.split 3 (.tip (.small 0)) (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 2 5 8)))) (.split 3 (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 1 2 7))))
private theorem q9Shape0T34OK : treeOK (forms 0) 1048579 32832 q9Shape0T34=true := by decide

private def q9Shape0T30 : Tree := .split 20 q9Shape0T31 q9Shape0T34
private theorem q9Shape0T30OK : treeOK (forms 0) 3 32832 q9Shape0T30=true := by
  change (treeOK (forms 0) 3 (32832 ||| 2^20) q9Shape0T31 &&
    treeOK (forms 0) (3 ||| 2^20) 32832 q9Shape0T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T31OK,q9Shape0T34OK⟩

private def q9Shape0T35 : Tree := (.split 20 (.split 2 (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 0 1 3 8)))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 0 1 3 8))))) (.tip (.cover 0 1 2 5)))) (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 2 5 7))) (.tip (.cover 1 2 5 8)))) (.split 3 (.split 4 (.split 5 (.tip (.small 1)) (.tip (.cover 1 2 6 7))) (.tip (.cover 1 2 6 8))) (.tip (.cover 0 2 7 8)))) (.tip (.cover 0 1 5 7)))
private theorem q9Shape0T35OK : treeOK (forms 0) 32771 64 q9Shape0T35=true := by decide

private def q9Shape0T29 : Tree := .split 15 q9Shape0T30 q9Shape0T35
private theorem q9Shape0T29OK : treeOK (forms 0) 3 64 q9Shape0T29=true := by
  change (treeOK (forms 0) 3 (64 ||| 2^15) q9Shape0T30 &&
    treeOK (forms 0) (3 ||| 2^15) 64 q9Shape0T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T30OK,q9Shape0T35OK⟩

private def q9Shape0T40 : Tree := (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 1 2 5 6))))
private theorem q9Shape0T40OK : treeOK (forms 0) 67 1081356 q9Shape0T40=true := by decide

private def q9Shape0T41 : Tree := (.split 4 (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.split 8 (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 3 6)))) (.tip (.unordered 2 3 1)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.split 8 (.split 9 (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))) (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.split 8 (.split 9 (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 1 2 5))))
private theorem q9Shape0T41OK : treeOK (forms 0) 75 1081348 q9Shape0T41=true := by decide

private def q9Shape0T39 : Tree := .split 3 q9Shape0T40 q9Shape0T41
private theorem q9Shape0T39OK : treeOK (forms 0) 67 1081348 q9Shape0T39=true := by
  change (treeOK (forms 0) 67 (1081348 ||| 2^3) q9Shape0T40 &&
    treeOK (forms 0) (67 ||| 2^3) 1081348 q9Shape0T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T40OK,q9Shape0T41OK⟩

private def q9Shape0T42 : Tree := (.split 3 (.split 4 (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 3 5))))) (.tip (.unordered 2 3 1))) (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))) (.split 8 (.tip (.unordered 2 3 0)) (.tip (.unordered 2 3 0))))) (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))) (.split 8 (.tip (.unordered 2 3 0)) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 1 2 6)))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape0T42OK : treeOK (forms 0) 71 1081344 q9Shape0T42=true := by decide

private def q9Shape0T38 : Tree := .split 2 q9Shape0T39 q9Shape0T42
private theorem q9Shape0T38OK : treeOK (forms 0) 67 1081344 q9Shape0T38=true := by
  change (treeOK (forms 0) 67 (1081344 ||| 2^2) q9Shape0T39 &&
    treeOK (forms 0) (67 ||| 2^2) 1081344 q9Shape0T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T39OK,q9Shape0T42OK⟩

private def q9Shape0T44 : Tree := (.split 3 (.split 4 (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7))))) (.split 5 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7)))) (.tip (.cover 1 2 5 6)))) (.split 4 (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.split 8 (.split 9 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 1 3 7)))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 2 5 8))))
private theorem q9Shape0T44OK : treeOK (forms 0) 1048643 32772 q9Shape0T44=true := by decide

private def q9Shape0T45 : Tree := (.split 3 (.split 4 (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.split 10 (.tip (.small 1)) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 2 3 8)))) (.split 8 (.tip (.unordered 2 3 0)) (.tip (.cover 0 1 3 7)))) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 1 2 7)))
private theorem q9Shape0T45OK : treeOK (forms 0) 1048647 32768 q9Shape0T45=true := by decide

private def q9Shape0T43 : Tree := .split 2 q9Shape0T44 q9Shape0T45
private theorem q9Shape0T43OK : treeOK (forms 0) 1048643 32768 q9Shape0T43=true := by
  change (treeOK (forms 0) 1048643 (32768 ||| 2^2) q9Shape0T44 &&
    treeOK (forms 0) (1048643 ||| 2^2) 32768 q9Shape0T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T44OK,q9Shape0T45OK⟩

private def q9Shape0T37 : Tree := .split 20 q9Shape0T38 q9Shape0T43
private theorem q9Shape0T37OK : treeOK (forms 0) 67 32768 q9Shape0T37=true := by
  change (treeOK (forms 0) 67 (32768 ||| 2^20) q9Shape0T38 &&
    treeOK (forms 0) (67 ||| 2^20) 32768 q9Shape0T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T38OK,q9Shape0T43OK⟩

private def q9Shape0T50 : Tree := (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 1)) (.tip (.cover 1 3 5 8)))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 1 3 6 8))) (.tip (.cover 0 3 7 8)))) (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 0))) (.tip (.cover 1 2 3 5)))) (.split 8 (.split 9 (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 0))) (.tip (.cover 1 2 3 6))) (.tip (.cover 0 3 7 8)))))
private theorem q9Shape0T50OK : treeOK (forms 0) 32835 1048604 q9Shape0T50=true := by decide

private def q9Shape0T51 : Tree := (.split 5 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 3 5))) (.tip (.unordered 2 3 0)))) (.split 8 (.split 9 (.split 10 (.tip (.small 1)) (.tip (.cover 1 2 3 6))) (.tip (.unordered 2 3 0))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 5)))
private theorem q9Shape0T51OK : treeOK (forms 0) 32851 1048588 q9Shape0T51=true := by decide

private def q9Shape0T49 : Tree := .split 4 q9Shape0T50 q9Shape0T51
private theorem q9Shape0T49OK : treeOK (forms 0) 32835 1048588 q9Shape0T49=true := by
  change (treeOK (forms 0) 32835 (1048588 ||| 2^4) q9Shape0T50 &&
    treeOK (forms 0) (32835 ||| 2^4) 1048588 q9Shape0T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T50OK,q9Shape0T51OK⟩

private def q9Shape0T52 : Tree := (.split 4 (.split 5 (.split 7 (.split 8 (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 3 5)))) (.tip (.unordered 2 3 1))) (.split 8 (.split 9 (.tip (.small 1)) (.tip (.cover 1 3 6 8))) (.tip (.unordered 2 3 1)))) (.tip (.cover 1 2 5 7))) (.tip (.cover 1 2 5 8)))
private theorem q9Shape0T52OK : treeOK (forms 0) 32843 1048580 q9Shape0T52=true := by decide

private def q9Shape0T48 : Tree := .split 3 q9Shape0T49 q9Shape0T52
private theorem q9Shape0T48OK : treeOK (forms 0) 32835 1048580 q9Shape0T48=true := by
  change (treeOK (forms 0) 32835 (1048580 ||| 2^3) q9Shape0T49 &&
    treeOK (forms 0) (32835 ||| 2^3) 1048580 q9Shape0T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T49OK,q9Shape0T52OK⟩

private def q9Shape0T53 : Tree := (.split 3 (.split 4 (.split 5 (.split 7 (.split 8 (.split 9 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 0 1 3 5)))) (.split 9 (.tip (.small 1)) (.tip (.cover 1 3 5 8)))) (.tip (.unordered 2 3 1))) (.tip (.cover 1 2 6 7))) (.tip (.cover 1 2 6 8))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape0T53OK : treeOK (forms 0) 32839 1048576 q9Shape0T53=true := by decide

private def q9Shape0T47 : Tree := .split 2 q9Shape0T48 q9Shape0T53
private theorem q9Shape0T47OK : treeOK (forms 0) 32835 1048576 q9Shape0T47=true := by
  change (treeOK (forms 0) 32835 (1048576 ||| 2^2) q9Shape0T48 &&
    treeOK (forms 0) (32835 ||| 2^2) 1048576 q9Shape0T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T48OK,q9Shape0T53OK⟩

private def q9Shape0T54 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape0T54OK : treeOK (forms 0) 1081411 0 q9Shape0T54=true := by decide

private def q9Shape0T46 : Tree := .split 20 q9Shape0T47 q9Shape0T54
private theorem q9Shape0T46OK : treeOK (forms 0) 32835 0 q9Shape0T46=true := by
  change (treeOK (forms 0) 32835 (0 ||| 2^20) q9Shape0T47 &&
    treeOK (forms 0) (32835 ||| 2^20) 0 q9Shape0T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T47OK,q9Shape0T54OK⟩

private def q9Shape0T36 : Tree := .split 15 q9Shape0T37 q9Shape0T46
private theorem q9Shape0T36OK : treeOK (forms 0) 67 0 q9Shape0T36=true := by
  change (treeOK (forms 0) 67 (0 ||| 2^15) q9Shape0T37 &&
    treeOK (forms 0) (67 ||| 2^15) 0 q9Shape0T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T37OK,q9Shape0T46OK⟩

private def q9Shape0T28 : Tree := .split 6 q9Shape0T29 q9Shape0T36
private theorem q9Shape0T28OK : treeOK (forms 0) 3 0 q9Shape0T28=true := by
  change (treeOK (forms 0) 3 (0 ||| 2^6) q9Shape0T29 &&
    treeOK (forms 0) (3 ||| 2^6) 0 q9Shape0T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T29OK,q9Shape0T36OK⟩

private def q9Shape0T14 : Tree := .split 1 q9Shape0T15 q9Shape0T28
private theorem q9Shape0T14OK : treeOK (forms 0) 1 0 q9Shape0T14=true := by
  change (treeOK (forms 0) 1 (0 ||| 2^1) q9Shape0T15 &&
    treeOK (forms 0) (1 ||| 2^1) 0 q9Shape0T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T15OK,q9Shape0T28OK⟩

private def q9Shape0T0 : Tree := .split 0 q9Shape0T1 q9Shape0T14
private theorem q9Shape0T0OK : treeOK (forms 0) 0 0 q9Shape0T0=true := by
  change (treeOK (forms 0) 0 (0 ||| 2^0) q9Shape0T1 &&
    treeOK (forms 0) (0 ||| 2^0) 0 q9Shape0T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape0T1OK,q9Shape0T14OK⟩


theorem q9Shape0_cover (b : Nat→Bool) (H : Ranked (adj (forms 0) b)) :
    ∃ u v w z,Effective (adj (forms 0) b) (adj (forms 0) b) u v w z :=
  checked_tree (forms 0) b H q9Shape0T0 q9Shape0T0OK

#print axioms q9Shape0_cover
end Graffiti384b.Q9
