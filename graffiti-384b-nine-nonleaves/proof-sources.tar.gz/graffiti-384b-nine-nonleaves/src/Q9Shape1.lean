import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape1T7 : Tree := (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 15 (.tip (.small 0)) (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.tip (.cover 1 4 6 8)))))) (.tip (.cover 0 1 5 8))))) (.split 13 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.tip (.cover 0 4 7 8))))))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape1T7OK : treeOK (forms 1) 0 1835800 q9Shape1T7=true := by decide

private def q9Shape1T9 : Tree := (.split 13 (.split 15 (.tip (.small 0)) (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.tip (.cover 1 3 6 8)))))) (.tip (.cover 0 1 5 8)))) (.split 15 (.tip (.small 0)) (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 2 6 7 8))))) (.tip (.cover 0 1 5 8)))))
private theorem q9Shape1T9OK : treeOK (forms 1) 512 1839384 q9Shape1T9=true := by decide

private def q9Shape1T10 : Tree := (.split 13 (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))))))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 0 4 7 8))))) (.split 16 (.split 0 (.tip (.small 1)) (.tip (.cover 1 3 6 8))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape1T10OK : treeOK (forms 1) 4608 1835288 q9Shape1T10=true := by decide

private def q9Shape1T8 : Tree := .split 12 q9Shape1T9 q9Shape1T10
private theorem q9Shape1T8OK : treeOK (forms 1) 512 1835288 q9Shape1T8=true := by
  change (treeOK (forms 1) 512 (1835288 ||| 2^12) q9Shape1T9 &&
    treeOK (forms 1) (512 ||| 2^12) 1835288 q9Shape1T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T9OK,q9Shape1T10OK⟩

private def q9Shape1T6 : Tree := .split 9 q9Shape1T7 q9Shape1T8
private theorem q9Shape1T6OK : treeOK (forms 1) 0 1835288 q9Shape1T6=true := by
  change (treeOK (forms 1) 0 (1835288 ||| 2^9) q9Shape1T7 &&
    treeOK (forms 1) (0 ||| 2^9) 1835288 q9Shape1T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T7OK,q9Shape1T8OK⟩

private def q9Shape1T13 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.tip (.cover 0 3 7 8))))))) (.tip (.cover 0 1 5 8))) (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))))))) (.split 0 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 4 6 8)))) (.tip (.cover 0 1 5 8)))))
private theorem q9Shape1T13OK : treeOK (forms 1) 256 1839640 q9Shape1T13=true := by decide

private def q9Shape1T14 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 2 6 7 8)))))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape1T14OK : treeOK (forms 1) 4352 1835544 q9Shape1T14=true := by decide

private def q9Shape1T12 : Tree := .split 12 q9Shape1T13 q9Shape1T14
private theorem q9Shape1T12OK : treeOK (forms 1) 256 1835544 q9Shape1T12=true := by
  change (treeOK (forms 1) 256 (1835544 ||| 2^12) q9Shape1T13 &&
    treeOK (forms 1) (256 ||| 2^12) 1835544 q9Shape1T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T13OK,q9Shape1T14OK⟩

private def q9Shape1T15 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape1T15OK : treeOK (forms 1) 768 1835032 q9Shape1T15=true := by decide

private def q9Shape1T11 : Tree := .split 9 q9Shape1T12 q9Shape1T15
private theorem q9Shape1T11OK : treeOK (forms 1) 256 1835032 q9Shape1T11=true := by
  change (treeOK (forms 1) 256 (1835032 ||| 2^9) q9Shape1T12 &&
    treeOK (forms 1) (256 ||| 2^9) 1835032 q9Shape1T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T12OK,q9Shape1T15OK⟩

private def q9Shape1T5 : Tree := .split 8 q9Shape1T6 q9Shape1T11
private theorem q9Shape1T5OK : treeOK (forms 1) 0 1835032 q9Shape1T5=true := by
  change (treeOK (forms 1) 0 (1835032 ||| 2^8) q9Shape1T6 &&
    treeOK (forms 1) (0 ||| 2^8) 1835032 q9Shape1T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T6OK,q9Shape1T11OK⟩

private def q9Shape1T19 : Tree := (.split 13 (.split 15 (.tip (.small 0)) (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 1 2 6 8)))) (.tip (.cover 0 1 5 8)))) (.split 15 (.tip (.small 0)) (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 1 2 6 8)))) (.tip (.cover 0 1 5 8)))))
private theorem q9Shape1T19OK : treeOK (forms 1) 16 1839880 q9Shape1T19=true := by decide

private def q9Shape1T20 : Tree := (.split 13 (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8))))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8)))))) (.split 16 (.split 0 (.tip (.small 1)) (.tip (.cover 1 2 6 8))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape1T20OK : treeOK (forms 1) 4112 1835784 q9Shape1T20=true := by decide

private def q9Shape1T18 : Tree := .split 12 q9Shape1T19 q9Shape1T20
private theorem q9Shape1T18OK : treeOK (forms 1) 16 1835784 q9Shape1T18=true := by
  change (treeOK (forms 1) 16 (1835784 ||| 2^12) q9Shape1T19 &&
    treeOK (forms 1) (16 ||| 2^12) 1835784 q9Shape1T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T19OK,q9Shape1T20OK⟩

private def q9Shape1T21 : Tree := (.split 12 (.split 13 (.split 15 (.tip (.small 0)) (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 1 2 6 8)))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 5 7 8))) (.split 13 (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape1T21OK : treeOK (forms 1) 528 1835272 q9Shape1T21=true := by decide

private def q9Shape1T17 : Tree := .split 9 q9Shape1T18 q9Shape1T21
private theorem q9Shape1T17OK : treeOK (forms 1) 16 1835272 q9Shape1T17=true := by
  change (treeOK (forms 1) 16 (1835272 ||| 2^9) q9Shape1T18 &&
    treeOK (forms 1) (16 ||| 2^9) 1835272 q9Shape1T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T18OK,q9Shape1T21OK⟩

private def q9Shape1T24 : Tree := (.split 13 (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8))))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8)))))) (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 1 2 6 8)))) (.tip (.cover 0 1 5 8)))) (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 1 2 6 8))))) (.tip (.cover 0 3 7 8))) (.tip (.cover 2 3 4 5))))
private theorem q9Shape1T24OK : treeOK (forms 1) 272 1839624 q9Shape1T24=true := by decide

private def q9Shape1T25 : Tree := (.split 13 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 1 2 6 8))))) (.tip (.cover 2 3 4 5))) (.tip (.cover 1 2 6 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape1T25OK : treeOK (forms 1) 4368 1835528 q9Shape1T25=true := by decide

private def q9Shape1T23 : Tree := .split 12 q9Shape1T24 q9Shape1T25
private theorem q9Shape1T23OK : treeOK (forms 1) 272 1835528 q9Shape1T23=true := by
  change (treeOK (forms 1) 272 (1835528 ||| 2^12) q9Shape1T24 &&
    treeOK (forms 1) (272 ||| 2^12) 1835528 q9Shape1T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T24OK,q9Shape1T25OK⟩

private def q9Shape1T26 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape1T26OK : treeOK (forms 1) 784 1835016 q9Shape1T26=true := by decide

private def q9Shape1T22 : Tree := .split 9 q9Shape1T23 q9Shape1T26
private theorem q9Shape1T22OK : treeOK (forms 1) 272 1835016 q9Shape1T22=true := by
  change (treeOK (forms 1) 272 (1835016 ||| 2^9) q9Shape1T23 &&
    treeOK (forms 1) (272 ||| 2^9) 1835016 q9Shape1T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T23OK,q9Shape1T26OK⟩

private def q9Shape1T16 : Tree := .split 8 q9Shape1T17 q9Shape1T22
private theorem q9Shape1T16OK : treeOK (forms 1) 16 1835016 q9Shape1T16=true := by
  change (treeOK (forms 1) 16 (1835016 ||| 2^8) q9Shape1T17 &&
    treeOK (forms 1) (16 ||| 2^8) 1835016 q9Shape1T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T17OK,q9Shape1T22OK⟩

private def q9Shape1T4 : Tree := .split 4 q9Shape1T5 q9Shape1T16
private theorem q9Shape1T4OK : treeOK (forms 1) 0 1835016 q9Shape1T4=true := by
  change (treeOK (forms 1) 0 (1835016 ||| 2^4) q9Shape1T5 &&
    treeOK (forms 1) (0 ||| 2^4) 1835016 q9Shape1T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T5OK,q9Shape1T16OK⟩

private def q9Shape1T31 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 1 5 8))) (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8))))) (.split 0 (.tip (.small 0)) (.tip (.cover 0 2 7 8)))) (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 1 5 8)))))
private theorem q9Shape1T31OK : treeOK (forms 1) 8 1839888 q9Shape1T31=true := by decide

private def q9Shape1T32 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape1T32OK : treeOK (forms 1) 4104 1835792 q9Shape1T32=true := by decide

private def q9Shape1T30 : Tree := .split 12 q9Shape1T31 q9Shape1T32
private theorem q9Shape1T30OK : treeOK (forms 1) 8 1835792 q9Shape1T30=true := by
  change (treeOK (forms 1) 8 (1835792 ||| 2^12) q9Shape1T31 &&
    treeOK (forms 1) (8 ||| 2^12) 1835792 q9Shape1T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T31OK,q9Shape1T32OK⟩

private def q9Shape1T34 : Tree := (.split 13 (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8))))) (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.tip (.cover 0 2 7 8))))) (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 1 5 8)))) (.split 15 (.split 16 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 2 7 8))) (.tip (.cover 2 3 4 5))))
private theorem q9Shape1T34OK : treeOK (forms 1) 520 1839376 q9Shape1T34=true := by decide

private def q9Shape1T35 : Tree := (.split 13 (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 2 3 4 5))) (.tip (.cover 1 3 6 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape1T35OK : treeOK (forms 1) 4616 1835280 q9Shape1T35=true := by decide

private def q9Shape1T33 : Tree := .split 12 q9Shape1T34 q9Shape1T35
private theorem q9Shape1T33OK : treeOK (forms 1) 520 1835280 q9Shape1T33=true := by
  change (treeOK (forms 1) 520 (1835280 ||| 2^12) q9Shape1T34 &&
    treeOK (forms 1) (520 ||| 2^12) 1835280 q9Shape1T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T34OK,q9Shape1T35OK⟩

private def q9Shape1T29 : Tree := .split 9 q9Shape1T30 q9Shape1T33
private theorem q9Shape1T29OK : treeOK (forms 1) 8 1835280 q9Shape1T29=true := by
  change (treeOK (forms 1) 8 (1835280 ||| 2^9) q9Shape1T30 &&
    treeOK (forms 1) (8 ||| 2^9) 1835280 q9Shape1T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T30OK,q9Shape1T33OK⟩

private def q9Shape1T36 : Tree := (.split 9 (.split 12 (.split 13 (.split 15 (.split 16 (.tip (.small 1)) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 1 5 8))) (.split 15 (.split 16 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 7 8))))) (.tip (.cover 2 3 4 5))) (.tip (.cover 1 4 6 8)))) (.split 13 (.tip (.cover 1 5 6 8)) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape1T36OK : treeOK (forms 1) 264 1835024 q9Shape1T36=true := by decide

private def q9Shape1T28 : Tree := .split 8 q9Shape1T29 q9Shape1T36
private theorem q9Shape1T28OK : treeOK (forms 1) 8 1835024 q9Shape1T28=true := by
  change (treeOK (forms 1) 8 (1835024 ||| 2^8) q9Shape1T29 &&
    treeOK (forms 1) (8 ||| 2^8) 1835024 q9Shape1T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T29OK,q9Shape1T36OK⟩

private def q9Shape1T37 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape1T37OK : treeOK (forms 1) 24 1835008 q9Shape1T37=true := by decide

private def q9Shape1T27 : Tree := .split 4 q9Shape1T28 q9Shape1T37
private theorem q9Shape1T27OK : treeOK (forms 1) 8 1835008 q9Shape1T27=true := by
  change (treeOK (forms 1) 8 (1835008 ||| 2^4) q9Shape1T28 &&
    treeOK (forms 1) (8 ||| 2^4) 1835008 q9Shape1T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T28OK,q9Shape1T37OK⟩

private def q9Shape1T3 : Tree := .split 3 q9Shape1T4 q9Shape1T27
private theorem q9Shape1T3OK : treeOK (forms 1) 0 1835008 q9Shape1T3=true := by
  change (treeOK (forms 1) 0 (1835008 ||| 2^3) q9Shape1T4 &&
    treeOK (forms 1) (0 ||| 2^3) 1835008 q9Shape1T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T4OK,q9Shape1T27OK⟩

private def q9Shape1T38 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape1T38OK : treeOK (forms 1) 1048576 786432 q9Shape1T38=true := by decide

private def q9Shape1T2 : Tree := .split 20 q9Shape1T3 q9Shape1T38
private theorem q9Shape1T2OK : treeOK (forms 1) 0 786432 q9Shape1T2=true := by
  change (treeOK (forms 1) 0 (786432 ||| 2^20) q9Shape1T3 &&
    treeOK (forms 1) (0 ||| 2^20) 786432 q9Shape1T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T3OK,q9Shape1T38OK⟩

private def q9Shape1T39 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape1T39OK : treeOK (forms 1) 524288 262144 q9Shape1T39=true := by decide

private def q9Shape1T1 : Tree := .split 19 q9Shape1T2 q9Shape1T39
private theorem q9Shape1T1OK : treeOK (forms 1) 0 262144 q9Shape1T1=true := by
  change (treeOK (forms 1) 0 (262144 ||| 2^19) q9Shape1T2 &&
    treeOK (forms 1) (0 ||| 2^19) 262144 q9Shape1T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T2OK,q9Shape1T39OK⟩

private def q9Shape1T40 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape1T40OK : treeOK (forms 1) 262144 0 q9Shape1T40=true := by decide

private def q9Shape1T0 : Tree := .split 18 q9Shape1T1 q9Shape1T40
private theorem q9Shape1T0OK : treeOK (forms 1) 0 0 q9Shape1T0=true := by
  change (treeOK (forms 1) 0 (0 ||| 2^18) q9Shape1T1 &&
    treeOK (forms 1) (0 ||| 2^18) 0 q9Shape1T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape1T1OK,q9Shape1T40OK⟩


theorem q9Shape1_cover (b : Nat→Bool) (H : Ranked (adj (forms 1) b)) :
    ∃ u v w z,Effective (adj (forms 1) b) (adj (forms 1) b) u v w z :=
  checked_tree (forms 1) b H q9Shape1T0 q9Shape1T0OK

#print axioms q9Shape1_cover
end Graffiti384b.Q9
