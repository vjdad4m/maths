import Q9FastKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape10T10 : Tree := (.tip (.cover 0 1 3 4))
private theorem q9Shape10T10OK : fastTreeOK (forms 10) 0 2064444 q9Shape10T10=true := by decide

private def q9Shape10T12 : Tree := (.split 8 (.split 9 (.tip (.cover 0 1 4 8)) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 8))) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 4))) (.split 10 (.split 11 (.tip (.cover 0 1 3 8)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T12OK : fastTreeOK (forms 10) 32 2064540 q9Shape10T12=true := by decide

private def q9Shape10T13 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5))))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 1 3 4))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 3 8)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 3 4 8)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.tip (.cover 0 1 3 8)) (.tip (.cover 0 3 7 8)))) (.split 12 (.split 13 (.tip (.cover 0 1 3 8)) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T13OK : fastTreeOK (forms 10) 160 2064412 q9Shape10T13=true := by decide

private def q9Shape10T11 : Tree := .split 7 q9Shape10T12 q9Shape10T13
private theorem q9Shape10T11OK : fastTreeOK (forms 10) 32 2064412 q9Shape10T11=true := by
  change (fastTreeOK (forms 10) 32 (2064412 ||| 2^7) q9Shape10T12 &&
    fastTreeOK (forms 10) (32 ||| 2^7) 2064412 q9Shape10T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T12OK,q9Shape10T13OK⟩

private def q9Shape10T9 : Tree := .split 5 q9Shape10T10 q9Shape10T11
private theorem q9Shape10T9OK : fastTreeOK (forms 10) 0 2064412 q9Shape10T9=true := by
  change (fastTreeOK (forms 10) 0 (2064412 ||| 2^5) q9Shape10T10 &&
    fastTreeOK (forms 10) (0 ||| 2^5) 2064412 q9Shape10T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T10OK,q9Shape10T11OK⟩

private def q9Shape10T16 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 7)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 7))) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 7)))) (.split 11 (.tip (.cover 0 1 3 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 4 7 8))))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape10T16OK : fastTreeOK (forms 10) 16 2064556 q9Shape10T16=true := by decide

private def q9Shape10T18 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 1 4 5))) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 3 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape10T18OK : fastTreeOK (forms 10) 144 2064684 q9Shape10T18=true := by decide

private def q9Shape10T19 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 3 4))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5)))) (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape10T19OK : fastTreeOK (forms 10) 400 2064428 q9Shape10T19=true := by decide

private def q9Shape10T17 : Tree := .split 8 q9Shape10T18 q9Shape10T19
private theorem q9Shape10T17OK : fastTreeOK (forms 10) 144 2064428 q9Shape10T17=true := by
  change (fastTreeOK (forms 10) 144 (2064428 ||| 2^8) q9Shape10T18 &&
    fastTreeOK (forms 10) (144 ||| 2^8) 2064428 q9Shape10T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T18OK,q9Shape10T19OK⟩

private def q9Shape10T15 : Tree := .split 7 q9Shape10T16 q9Shape10T17
private theorem q9Shape10T15OK : fastTreeOK (forms 10) 16 2064428 q9Shape10T15=true := by
  change (fastTreeOK (forms 10) 16 (2064428 ||| 2^7) q9Shape10T16 &&
    fastTreeOK (forms 10) (16 ||| 2^7) 2064428 q9Shape10T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T16OK,q9Shape10T17OK⟩

private def q9Shape10T20 : Tree := (.split 7 (.split 8 (.tip (.cover 0 1 2 4)) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 2 6)) (.tip (.cover 1 2 5 6))) (.split 11 (.tip (.cover 0 1 2 6)) (.tip (.cover 1 2 5 6)))) (.split 10 (.split 11 (.tip (.cover 0 1 2 6)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 5))))) (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 2 5)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.tip (.cover 0 1 2 5)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 4)))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 2 5)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T20OK : fastTreeOK (forms 10) 48 2064396 q9Shape10T20=true := by decide

private def q9Shape10T14 : Tree := .split 5 q9Shape10T15 q9Shape10T20
private theorem q9Shape10T14OK : fastTreeOK (forms 10) 16 2064396 q9Shape10T14=true := by
  change (fastTreeOK (forms 10) 16 (2064396 ||| 2^5) q9Shape10T15 &&
    fastTreeOK (forms 10) (16 ||| 2^5) 2064396 q9Shape10T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T15OK,q9Shape10T20OK⟩

private def q9Shape10T8 : Tree := .split 4 q9Shape10T9 q9Shape10T14
private theorem q9Shape10T8OK : fastTreeOK (forms 10) 0 2064396 q9Shape10T8=true := by
  change (fastTreeOK (forms 10) 0 (2064396 ||| 2^4) q9Shape10T9 &&
    fastTreeOK (forms 10) (0 ||| 2^4) 2064396 q9Shape10T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T9OK,q9Shape10T14OK⟩

private def q9Shape10T24 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 8))) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 8))))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 7))) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 7)))) (.split 11 (.tip (.cover 0 1 3 6)) (.tip (.cover 1 3 5 6))))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape10T24OK : fastTreeOK (forms 10) 8 2064564 q9Shape10T24=true := by decide

private def q9Shape10T25 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 3 4 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 1 4 5 6))) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 3 4 6))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape10T25OK : fastTreeOK (forms 10) 136 2064436 q9Shape10T25=true := by decide

private def q9Shape10T23 : Tree := .split 7 q9Shape10T24 q9Shape10T25
private theorem q9Shape10T23OK : fastTreeOK (forms 10) 8 2064436 q9Shape10T23=true := by
  change (fastTreeOK (forms 10) 8 (2064436 ||| 2^7) q9Shape10T24 &&
    fastTreeOK (forms 10) (8 ||| 2^7) 2064436 q9Shape10T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T24OK,q9Shape10T25OK⟩

private def q9Shape10T27 : Tree := (.split 8 (.split 9 (.tip (.cover 0 1 2 4)) (.split 10 (.split 11 (.tip (.cover 0 1 2 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 7 8)))) (.split 11 (.tip (.cover 0 1 2 7)) (.tip (.cover 1 3 5 6))))) (.split 9 (.tip (.cover 0 1 2 4)) (.split 10 (.split 11 (.tip (.cover 0 1 2 7)) (.tip (.cover 1 2 3 5))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T27OK : fastTreeOK (forms 10) 40 2064532 q9Shape10T27=true := by decide

private def q9Shape10T28 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 2 4)))) (.tip (.cover 0 1 2 3))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T28OK : fastTreeOK (forms 10) 168 2064404 q9Shape10T28=true := by decide

private def q9Shape10T26 : Tree := .split 7 q9Shape10T27 q9Shape10T28
private theorem q9Shape10T26OK : fastTreeOK (forms 10) 40 2064404 q9Shape10T26=true := by
  change (fastTreeOK (forms 10) 40 (2064404 ||| 2^7) q9Shape10T27 &&
    fastTreeOK (forms 10) (40 ||| 2^7) 2064404 q9Shape10T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T27OK,q9Shape10T28OK⟩

private def q9Shape10T22 : Tree := .split 5 q9Shape10T23 q9Shape10T26
private theorem q9Shape10T22OK : fastTreeOK (forms 10) 8 2064404 q9Shape10T22=true := by
  change (fastTreeOK (forms 10) 8 (2064404 ||| 2^5) q9Shape10T23 &&
    fastTreeOK (forms 10) (8 ||| 2^5) 2064404 q9Shape10T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T23OK,q9Shape10T26OK⟩

private def q9Shape10T31 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.tip (.cover 0 1 2 8)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))))) (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.tip (.cover 0 1 2 8)) (.tip (.cover 1 3 5 6))))) (.split 9 (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.tip (.cover 0 1 2 8)) (.tip (.cover 1 2 3 5)))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape10T31OK : fastTreeOK (forms 10) 24 2064548 q9Shape10T31=true := by decide

private def q9Shape10T32 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 2 3))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) none)) (.tip (.drop 6 8 (some 5) (some 5)))) (.tip (.cover 1 4 5 6))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T32OK : fastTreeOK (forms 10) 152 2064420 q9Shape10T32=true := by decide

private def q9Shape10T30 : Tree := .split 7 q9Shape10T31 q9Shape10T32
private theorem q9Shape10T30OK : fastTreeOK (forms 10) 24 2064420 q9Shape10T30=true := by
  change (fastTreeOK (forms 10) 24 (2064420 ||| 2^7) q9Shape10T31 &&
    fastTreeOK (forms 10) (24 ||| 2^7) 2064420 q9Shape10T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T31OK,q9Shape10T32OK⟩

private def q9Shape10T33 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T33OK : fastTreeOK (forms 10) 56 2064388 q9Shape10T33=true := by decide

private def q9Shape10T29 : Tree := .split 5 q9Shape10T30 q9Shape10T33
private theorem q9Shape10T29OK : fastTreeOK (forms 10) 24 2064388 q9Shape10T29=true := by
  change (fastTreeOK (forms 10) 24 (2064388 ||| 2^5) q9Shape10T30 &&
    fastTreeOK (forms 10) (24 ||| 2^5) 2064388 q9Shape10T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T30OK,q9Shape10T33OK⟩

private def q9Shape10T21 : Tree := .split 4 q9Shape10T22 q9Shape10T29
private theorem q9Shape10T21OK : fastTreeOK (forms 10) 8 2064388 q9Shape10T21=true := by
  change (fastTreeOK (forms 10) 8 (2064388 ||| 2^4) q9Shape10T22 &&
    fastTreeOK (forms 10) (8 ||| 2^4) 2064388 q9Shape10T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T22OK,q9Shape10T29OK⟩

private def q9Shape10T7 : Tree := .split 3 q9Shape10T8 q9Shape10T21
private theorem q9Shape10T7OK : fastTreeOK (forms 10) 0 2064388 q9Shape10T7=true := by
  change (fastTreeOK (forms 10) 0 (2064388 ||| 2^3) q9Shape10T8 &&
    fastTreeOK (forms 10) (0 ||| 2^3) 2064388 q9Shape10T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T8OK,q9Shape10T21OK⟩

private def q9Shape10T39 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5))))) (.tip (.cover 0 1 4 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 1 4 5))) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 3 5)) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 4)))))
private theorem q9Shape10T39OK : fastTreeOK (forms 10) 4 2064824 q9Shape10T39=true := by decide

private def q9Shape10T40 : Tree := (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 3 4 5))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 3 4 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T40OK : fastTreeOK (forms 10) 260 2064568 q9Shape10T40=true := by decide

private def q9Shape10T38 : Tree := .split 8 q9Shape10T39 q9Shape10T40
private theorem q9Shape10T38OK : fastTreeOK (forms 10) 4 2064568 q9Shape10T38=true := by
  change (fastTreeOK (forms 10) 4 (2064568 ||| 2^8) q9Shape10T39 &&
    fastTreeOK (forms 10) (4 ||| 2^8) 2064568 q9Shape10T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T39OK,q9Shape10T40OK⟩

private def q9Shape10T41 : Tree := (.tip (.cover 0 1 3 4))
private theorem q9Shape10T41OK : fastTreeOK (forms 10) 132 2064440 q9Shape10T41=true := by decide

private def q9Shape10T37 : Tree := .split 7 q9Shape10T38 q9Shape10T41
private theorem q9Shape10T37OK : fastTreeOK (forms 10) 4 2064440 q9Shape10T37=true := by
  change (fastTreeOK (forms 10) 4 (2064440 ||| 2^7) q9Shape10T38 &&
    fastTreeOK (forms 10) (4 ||| 2^7) 2064440 q9Shape10T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T38OK,q9Shape10T41OK⟩

private def q9Shape10T43 : Tree := (.split 8 (.split 9 (.tip (.cover 0 1 2 4)) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 2 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 2 4)))) (.tip (.cover 0 4 7 8))) (.split 11 (.split 12 (.tip (.cover 0 1 2 7)) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 4))))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T43OK : fastTreeOK (forms 10) 36 2064536 q9Shape10T43=true := by decide

private def q9Shape10T44 : Tree := (.split 8 (.split 9 (.tip (.cover 0 1 2 4)) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 2 7)) (.tip (.cover 1 2 3 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 2 6)) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 4 6))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T44OK : fastTreeOK (forms 10) 164 2064408 q9Shape10T44=true := by decide

private def q9Shape10T42 : Tree := .split 7 q9Shape10T43 q9Shape10T44
private theorem q9Shape10T42OK : fastTreeOK (forms 10) 36 2064408 q9Shape10T42=true := by
  change (fastTreeOK (forms 10) 36 (2064408 ||| 2^7) q9Shape10T43 &&
    fastTreeOK (forms 10) (36 ||| 2^7) 2064408 q9Shape10T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T43OK,q9Shape10T44OK⟩

private def q9Shape10T36 : Tree := .split 5 q9Shape10T37 q9Shape10T42
private theorem q9Shape10T36OK : fastTreeOK (forms 10) 4 2064408 q9Shape10T36=true := by
  change (fastTreeOK (forms 10) 4 (2064408 ||| 2^5) q9Shape10T37 &&
    fastTreeOK (forms 10) (4 ||| 2^5) 2064408 q9Shape10T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T37OK,q9Shape10T42OK⟩

private def q9Shape10T47 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.split 12 (.tip (.cover 0 1 2 8)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 4 8)))) (.tip (.cover 0 4 7 8)))) (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.split 12 (.tip (.cover 0 1 2 8)) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 4))))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 1 4 5 6))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 4 6))) (.tip (.cover 0 1 2 3))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) none)) (.tip (.drop 6 8 (some 5) (some 5)))) (.tip (.cover 1 4 5 6))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T47OK : fastTreeOK (forms 10) 20 2064552 q9Shape10T47=true := by decide

private def q9Shape10T48 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.split 12 (.tip (.cover 0 1 2 8)) (.tip (.cover 1 2 3 6))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 0 1 3 4))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 4 6))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T48OK : fastTreeOK (forms 10) 148 2064424 q9Shape10T48=true := by decide

private def q9Shape10T46 : Tree := .split 7 q9Shape10T47 q9Shape10T48
private theorem q9Shape10T46OK : fastTreeOK (forms 10) 20 2064424 q9Shape10T46=true := by
  change (fastTreeOK (forms 10) 20 (2064424 ||| 2^7) q9Shape10T47 &&
    fastTreeOK (forms 10) (20 ||| 2^7) 2064424 q9Shape10T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T47OK,q9Shape10T48OK⟩

private def q9Shape10T49 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T49OK : fastTreeOK (forms 10) 52 2064392 q9Shape10T49=true := by decide

private def q9Shape10T45 : Tree := .split 5 q9Shape10T46 q9Shape10T49
private theorem q9Shape10T45OK : fastTreeOK (forms 10) 20 2064392 q9Shape10T45=true := by
  change (fastTreeOK (forms 10) 20 (2064392 ||| 2^5) q9Shape10T46 &&
    fastTreeOK (forms 10) (20 ||| 2^5) 2064392 q9Shape10T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T46OK,q9Shape10T49OK⟩

private def q9Shape10T35 : Tree := .split 4 q9Shape10T36 q9Shape10T45
private theorem q9Shape10T35OK : fastTreeOK (forms 10) 4 2064392 q9Shape10T35=true := by
  change (fastTreeOK (forms 10) 4 (2064392 ||| 2^4) q9Shape10T36 &&
    fastTreeOK (forms 10) (4 ||| 2^4) 2064392 q9Shape10T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T36OK,q9Shape10T45OK⟩

private def q9Shape10T54 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.tip (.cover 0 1 2 8)) (.tip (.cover 0 2 7 8)))) (.split 12 (.split 13 (.tip (.cover 0 1 2 8)) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 4 8))))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 2 4))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5)))) (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T54OK : fastTreeOK (forms 10) 12 2064816 q9Shape10T54=true := by decide

private def q9Shape10T55 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 2 8)) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 3 4 5))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 3 4 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T55OK : fastTreeOK (forms 10) 268 2064560 q9Shape10T55=true := by decide

private def q9Shape10T53 : Tree := .split 8 q9Shape10T54 q9Shape10T55
private theorem q9Shape10T53OK : fastTreeOK (forms 10) 12 2064560 q9Shape10T53=true := by
  change (fastTreeOK (forms 10) 12 (2064560 ||| 2^8) q9Shape10T54 &&
    fastTreeOK (forms 10) (12 ||| 2^8) 2064560 q9Shape10T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T54OK,q9Shape10T55OK⟩

private def q9Shape10T56 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 2 4)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 2 8)) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 3 4 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 3 4 6))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape10T56OK : fastTreeOK (forms 10) 140 2064432 q9Shape10T56=true := by decide

private def q9Shape10T52 : Tree := .split 7 q9Shape10T53 q9Shape10T56
private theorem q9Shape10T52OK : fastTreeOK (forms 10) 12 2064432 q9Shape10T52=true := by
  change (fastTreeOK (forms 10) 12 (2064432 ||| 2^7) q9Shape10T53 &&
    fastTreeOK (forms 10) (12 ||| 2^7) 2064432 q9Shape10T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T53OK,q9Shape10T56OK⟩

private def q9Shape10T57 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape10T57OK : fastTreeOK (forms 10) 44 2064400 q9Shape10T57=true := by decide

private def q9Shape10T51 : Tree := .split 5 q9Shape10T52 q9Shape10T57
private theorem q9Shape10T51OK : fastTreeOK (forms 10) 12 2064400 q9Shape10T51=true := by
  change (fastTreeOK (forms 10) 12 (2064400 ||| 2^5) q9Shape10T52 &&
    fastTreeOK (forms 10) (12 ||| 2^5) 2064400 q9Shape10T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T52OK,q9Shape10T57OK⟩

private def q9Shape10T58 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape10T58OK : fastTreeOK (forms 10) 28 2064384 q9Shape10T58=true := by decide

private def q9Shape10T50 : Tree := .split 4 q9Shape10T51 q9Shape10T58
private theorem q9Shape10T50OK : fastTreeOK (forms 10) 12 2064384 q9Shape10T50=true := by
  change (fastTreeOK (forms 10) 12 (2064384 ||| 2^4) q9Shape10T51 &&
    fastTreeOK (forms 10) (12 ||| 2^4) 2064384 q9Shape10T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T51OK,q9Shape10T58OK⟩

private def q9Shape10T34 : Tree := .split 3 q9Shape10T35 q9Shape10T50
private theorem q9Shape10T34OK : fastTreeOK (forms 10) 4 2064384 q9Shape10T34=true := by
  change (fastTreeOK (forms 10) 4 (2064384 ||| 2^3) q9Shape10T35 &&
    fastTreeOK (forms 10) (4 ||| 2^3) 2064384 q9Shape10T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T35OK,q9Shape10T50OK⟩

private def q9Shape10T6 : Tree := .split 2 q9Shape10T7 q9Shape10T34
private theorem q9Shape10T6OK : fastTreeOK (forms 10) 0 2064384 q9Shape10T6=true := by
  change (fastTreeOK (forms 10) 0 (2064384 ||| 2^2) q9Shape10T7 &&
    fastTreeOK (forms 10) (0 ||| 2^2) 2064384 q9Shape10T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T7OK,q9Shape10T34OK⟩

private def q9Shape10T64 : Tree := (.split 8 (.split 9 (.tip (.cover 0 1 4 6)) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 1 4 6))) (.split 13 (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 5) (some 6)))) (.tip (.cover 0 1 4 6))))) (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 4)))))) (.split 9 (.tip (.cover 0 1 4 6)) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 6))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 6))))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T64OK : fastTreeOK (forms 10) 524288 1540284 q9Shape10T64=true := by decide

private def q9Shape10T65 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 5) (some 6)))))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 3 6))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 6))))
private theorem q9Shape10T65OK : fastTreeOK (forms 10) 524416 1540156 q9Shape10T65=true := by decide

private def q9Shape10T63 : Tree := .split 7 q9Shape10T64 q9Shape10T65
private theorem q9Shape10T63OK : fastTreeOK (forms 10) 524288 1540156 q9Shape10T63=true := by
  change (fastTreeOK (forms 10) 524288 (1540156 ||| 2^7) q9Shape10T64 &&
    fastTreeOK (forms 10) (524288 ||| 2^7) 1540156 q9Shape10T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T64OK,q9Shape10T65OK⟩

private def q9Shape10T66 : Tree := (.split 7 (.split 8 (.split 9 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8))) (.split 9 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8)))) (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 1 4 5 8))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 3 6))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 4 5 8))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 6)))))
private theorem q9Shape10T66OK : fastTreeOK (forms 10) 524320 1540124 q9Shape10T66=true := by decide

private def q9Shape10T62 : Tree := .split 5 q9Shape10T63 q9Shape10T66
private theorem q9Shape10T62OK : fastTreeOK (forms 10) 524288 1540124 q9Shape10T62=true := by
  change (fastTreeOK (forms 10) 524288 (1540124 ||| 2^5) q9Shape10T63 &&
    fastTreeOK (forms 10) (524288 ||| 2^5) 1540124 q9Shape10T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T63OK,q9Shape10T66OK⟩

private def q9Shape10T69 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 1 4 6))) (.split 13 (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 5) (some 6)))) (.tip (.cover 0 1 4 6))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))))
private theorem q9Shape10T69OK : fastTreeOK (forms 10) 524304 1540268 q9Shape10T69=true := by decide

private def q9Shape10T70 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 3 6 7))) (.tip (.cover 0 3 6 7))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 0 1 3 6))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 6))))
private theorem q9Shape10T70OK : fastTreeOK (forms 10) 524432 1540140 q9Shape10T70=true := by decide

private def q9Shape10T68 : Tree := .split 7 q9Shape10T69 q9Shape10T70
private theorem q9Shape10T68OK : fastTreeOK (forms 10) 524304 1540140 q9Shape10T68=true := by
  change (fastTreeOK (forms 10) 524304 (1540140 ||| 2^7) q9Shape10T69 &&
    fastTreeOK (forms 10) (524304 ||| 2^7) 1540140 q9Shape10T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T69OK,q9Shape10T70OK⟩

private def q9Shape10T71 : Tree := (.split 7 (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 2 4)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8)))) (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 3 6 7))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T71OK : fastTreeOK (forms 10) 524336 1540108 q9Shape10T71=true := by decide

private def q9Shape10T67 : Tree := .split 5 q9Shape10T68 q9Shape10T71
private theorem q9Shape10T67OK : fastTreeOK (forms 10) 524304 1540108 q9Shape10T67=true := by
  change (fastTreeOK (forms 10) 524304 (1540108 ||| 2^5) q9Shape10T68 &&
    fastTreeOK (forms 10) (524304 ||| 2^5) 1540108 q9Shape10T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T68OK,q9Shape10T71OK⟩

private def q9Shape10T61 : Tree := .split 4 q9Shape10T62 q9Shape10T67
private theorem q9Shape10T61OK : fastTreeOK (forms 10) 524288 1540108 q9Shape10T61=true := by
  change (fastTreeOK (forms 10) 524288 (1540108 ||| 2^4) q9Shape10T62 &&
    fastTreeOK (forms 10) (524288 ||| 2^4) 1540108 q9Shape10T67)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T62OK,q9Shape10T67OK⟩

private def q9Shape10T74 : Tree := (.split 7 (.split 8 (.split 9 (.tip (.cover 0 1 4 6)) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 3 5 6))) (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 3 5 6))))) (.split 9 (.tip (.cover 0 1 4 6)) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 5))))) (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))))
private theorem q9Shape10T74OK : fastTreeOK (forms 10) 524296 1540148 q9Shape10T74=true := by decide

private def q9Shape10T75 : Tree := (.split 7 (.split 8 (.split 9 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8))) (.split 9 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8)))) (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))))
private theorem q9Shape10T75OK : fastTreeOK (forms 10) 524328 1540116 q9Shape10T75=true := by decide

private def q9Shape10T73 : Tree := .split 5 q9Shape10T74 q9Shape10T75
private theorem q9Shape10T73OK : fastTreeOK (forms 10) 524296 1540116 q9Shape10T73=true := by
  change (fastTreeOK (forms 10) 524296 (1540116 ||| 2^5) q9Shape10T74 &&
    fastTreeOK (forms 10) (524296 ||| 2^5) 1540116 q9Shape10T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T74OK,q9Shape10T75OK⟩

private def q9Shape10T78 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 6))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 6))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))))
private theorem q9Shape10T78OK : fastTreeOK (forms 10) 524312 1540260 q9Shape10T78=true := by decide

private def q9Shape10T79 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 2 3))) (.tip (.cover 0 1 3 6))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 6))))
private theorem q9Shape10T79OK : fastTreeOK (forms 10) 524440 1540132 q9Shape10T79=true := by decide

private def q9Shape10T77 : Tree := .split 7 q9Shape10T78 q9Shape10T79
private theorem q9Shape10T77OK : fastTreeOK (forms 10) 524312 1540132 q9Shape10T77=true := by
  change (fastTreeOK (forms 10) 524312 (1540132 ||| 2^7) q9Shape10T78 &&
    fastTreeOK (forms 10) (524312 ||| 2^7) 1540132 q9Shape10T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T78OK,q9Shape10T79OK⟩

private def q9Shape10T80 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T80OK : fastTreeOK (forms 10) 524344 1540100 q9Shape10T80=true := by decide

private def q9Shape10T76 : Tree := .split 5 q9Shape10T77 q9Shape10T80
private theorem q9Shape10T76OK : fastTreeOK (forms 10) 524312 1540100 q9Shape10T76=true := by
  change (fastTreeOK (forms 10) 524312 (1540100 ||| 2^5) q9Shape10T77 &&
    fastTreeOK (forms 10) (524312 ||| 2^5) 1540100 q9Shape10T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T77OK,q9Shape10T80OK⟩

private def q9Shape10T72 : Tree := .split 4 q9Shape10T73 q9Shape10T76
private theorem q9Shape10T72OK : fastTreeOK (forms 10) 524296 1540100 q9Shape10T72=true := by
  change (fastTreeOK (forms 10) 524296 (1540100 ||| 2^4) q9Shape10T73 &&
    fastTreeOK (forms 10) (524296 ||| 2^4) 1540100 q9Shape10T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T73OK,q9Shape10T76OK⟩

private def q9Shape10T60 : Tree := .split 3 q9Shape10T61 q9Shape10T72
private theorem q9Shape10T60OK : fastTreeOK (forms 10) 524288 1540100 q9Shape10T60=true := by
  change (fastTreeOK (forms 10) 524288 (1540100 ||| 2^3) q9Shape10T61 &&
    fastTreeOK (forms 10) (524288 ||| 2^3) 1540100 q9Shape10T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T61OK,q9Shape10T72OK⟩

private def q9Shape10T86 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 5) (some 6)))))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 1 4 5 8))) (.tip (.cover 0 1 4 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8)))))
private theorem q9Shape10T86OK : fastTreeOK (forms 10) 524292 1540536 q9Shape10T86=true := by decide

private def q9Shape10T87 : Tree := (.split 9 (.tip (.cover 1 4 5 6)) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T87OK : fastTreeOK (forms 10) 524548 1540280 q9Shape10T87=true := by decide

private def q9Shape10T85 : Tree := .split 8 q9Shape10T86 q9Shape10T87
private theorem q9Shape10T85OK : fastTreeOK (forms 10) 524292 1540280 q9Shape10T85=true := by
  change (fastTreeOK (forms 10) 524292 (1540280 ||| 2^8) q9Shape10T86 &&
    fastTreeOK (forms 10) (524292 ||| 2^8) 1540280 q9Shape10T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T86OK,q9Shape10T87OK⟩

private def q9Shape10T88 : Tree := (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))))
private theorem q9Shape10T88OK : fastTreeOK (forms 10) 524420 1540152 q9Shape10T88=true := by decide

private def q9Shape10T84 : Tree := .split 7 q9Shape10T85 q9Shape10T88
private theorem q9Shape10T84OK : fastTreeOK (forms 10) 524292 1540152 q9Shape10T84=true := by
  change (fastTreeOK (forms 10) 524292 (1540152 ||| 2^7) q9Shape10T85 &&
    fastTreeOK (forms 10) (524292 ||| 2^7) 1540152 q9Shape10T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T85OK,q9Shape10T88OK⟩

private def q9Shape10T90 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 4 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 4 7 8))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 2 6 7))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 7 8))))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T90OK : fastTreeOK (forms 10) 524324 1540248 q9Shape10T90=true := by decide

private def q9Shape10T91 : Tree := (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))))
private theorem q9Shape10T91OK : fastTreeOK (forms 10) 524452 1540120 q9Shape10T91=true := by decide

private def q9Shape10T89 : Tree := .split 7 q9Shape10T90 q9Shape10T91
private theorem q9Shape10T89OK : fastTreeOK (forms 10) 524324 1540120 q9Shape10T89=true := by
  change (fastTreeOK (forms 10) 524324 (1540120 ||| 2^7) q9Shape10T90 &&
    fastTreeOK (forms 10) (524324 ||| 2^7) 1540120 q9Shape10T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T90OK,q9Shape10T91OK⟩

private def q9Shape10T83 : Tree := .split 5 q9Shape10T84 q9Shape10T89
private theorem q9Shape10T83OK : fastTreeOK (forms 10) 524292 1540120 q9Shape10T83=true := by
  change (fastTreeOK (forms 10) 524292 (1540120 ||| 2^5) q9Shape10T84 &&
    fastTreeOK (forms 10) (524292 ||| 2^5) 1540120 q9Shape10T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T84OK,q9Shape10T89OK⟩

private def q9Shape10T92 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T92OK : fastTreeOK (forms 10) 524308 1540104 q9Shape10T92=true := by decide

private def q9Shape10T82 : Tree := .split 4 q9Shape10T83 q9Shape10T92
private theorem q9Shape10T82OK : fastTreeOK (forms 10) 524292 1540104 q9Shape10T82=true := by
  change (fastTreeOK (forms 10) 524292 (1540104 ||| 2^4) q9Shape10T83 &&
    fastTreeOK (forms 10) (524292 ||| 2^4) 1540104 q9Shape10T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T83OK,q9Shape10T92OK⟩

private def q9Shape10T97 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 4 5 8))) (.tip (.cover 0 1 4 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T97OK : fastTreeOK (forms 10) 524300 1540528 q9Shape10T97=true := by decide

private def q9Shape10T98 : Tree := (.split 9 (.tip (.cover 1 4 5 6)) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T98OK : fastTreeOK (forms 10) 524556 1540272 q9Shape10T98=true := by decide

private def q9Shape10T96 : Tree := .split 8 q9Shape10T97 q9Shape10T98
private theorem q9Shape10T96OK : fastTreeOK (forms 10) 524300 1540272 q9Shape10T96=true := by
  change (fastTreeOK (forms 10) 524300 (1540272 ||| 2^8) q9Shape10T97 &&
    fastTreeOK (forms 10) (524300 ||| 2^8) 1540272 q9Shape10T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T97OK,q9Shape10T98OK⟩

private def q9Shape10T99 : Tree := (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))))
private theorem q9Shape10T99OK : fastTreeOK (forms 10) 524428 1540144 q9Shape10T99=true := by decide

private def q9Shape10T95 : Tree := .split 7 q9Shape10T96 q9Shape10T99
private theorem q9Shape10T95OK : fastTreeOK (forms 10) 524300 1540144 q9Shape10T95=true := by
  change (fastTreeOK (forms 10) 524300 (1540144 ||| 2^7) q9Shape10T96 &&
    fastTreeOK (forms 10) (524300 ||| 2^7) 1540144 q9Shape10T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T96OK,q9Shape10T99OK⟩

private def q9Shape10T100 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape10T100OK : fastTreeOK (forms 10) 524332 1540112 q9Shape10T100=true := by decide

private def q9Shape10T94 : Tree := .split 5 q9Shape10T95 q9Shape10T100
private theorem q9Shape10T94OK : fastTreeOK (forms 10) 524300 1540112 q9Shape10T94=true := by
  change (fastTreeOK (forms 10) 524300 (1540112 ||| 2^5) q9Shape10T95 &&
    fastTreeOK (forms 10) (524300 ||| 2^5) 1540112 q9Shape10T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T95OK,q9Shape10T100OK⟩

private def q9Shape10T101 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T101OK : fastTreeOK (forms 10) 524316 1540096 q9Shape10T101=true := by decide

private def q9Shape10T93 : Tree := .split 4 q9Shape10T94 q9Shape10T101
private theorem q9Shape10T93OK : fastTreeOK (forms 10) 524300 1540096 q9Shape10T93=true := by
  change (fastTreeOK (forms 10) 524300 (1540096 ||| 2^4) q9Shape10T94 &&
    fastTreeOK (forms 10) (524300 ||| 2^4) 1540096 q9Shape10T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T94OK,q9Shape10T101OK⟩

private def q9Shape10T81 : Tree := .split 3 q9Shape10T82 q9Shape10T93
private theorem q9Shape10T81OK : fastTreeOK (forms 10) 524292 1540096 q9Shape10T81=true := by
  change (fastTreeOK (forms 10) 524292 (1540096 ||| 2^3) q9Shape10T82 &&
    fastTreeOK (forms 10) (524292 ||| 2^3) 1540096 q9Shape10T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T82OK,q9Shape10T93OK⟩

private def q9Shape10T59 : Tree := .split 2 q9Shape10T60 q9Shape10T81
private theorem q9Shape10T59OK : fastTreeOK (forms 10) 524288 1540096 q9Shape10T59=true := by
  change (fastTreeOK (forms 10) 524288 (1540096 ||| 2^2) q9Shape10T60 &&
    fastTreeOK (forms 10) (524288 ||| 2^2) 1540096 q9Shape10T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T60OK,q9Shape10T81OK⟩

private def q9Shape10T5 : Tree := .split 19 q9Shape10T6 q9Shape10T59
private theorem q9Shape10T5OK : fastTreeOK (forms 10) 0 1540096 q9Shape10T5=true := by
  change (fastTreeOK (forms 10) 0 (1540096 ||| 2^19) q9Shape10T6 &&
    fastTreeOK (forms 10) (0 ||| 2^19) 1540096 q9Shape10T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T6OK,q9Shape10T59OK⟩

private def q9Shape10T108 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.split 11 (.tip (.cover 0 1 6 8)) (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 8)))))) (.split 10 (.tip (.cover 0 1 4 6)) (.split 11 (.tip (.cover 0 1 6 8)) (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.split 14 (.tip (.drop 6 8 none (some 5))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 3 4)))))) (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.split 11 (.tip (.cover 0 1 6 8)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.split 14 (.tip (.drop 7 8 none (some 5))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 8)))))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape10T108OK : fastTreeOK (forms 10) 262144 1802428 q9Shape10T108=true := by decide

private def q9Shape10T109 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 6))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.split 14 (.tip (.drop 6 8 none none)) (.tip (.drop 6 8 none (some 5))))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.split 14 (.tip (.small 1)) (.tip (.drop 7 8 none (some 5)))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T109OK : fastTreeOK (forms 10) 262272 1802300 q9Shape10T109=true := by decide

private def q9Shape10T107 : Tree := .split 7 q9Shape10T108 q9Shape10T109
private theorem q9Shape10T107OK : fastTreeOK (forms 10) 262144 1802300 q9Shape10T107=true := by
  change (fastTreeOK (forms 10) 262144 (1802300 ||| 2^7) q9Shape10T108 &&
    fastTreeOK (forms 10) (262144 ||| 2^7) 1802300 q9Shape10T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T108OK,q9Shape10T109OK⟩

private def q9Shape10T111 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 8)) (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 8))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 8)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))))
private theorem q9Shape10T111OK : fastTreeOK (forms 10) 262176 1802396 q9Shape10T111=true := by decide

private def q9Shape10T112 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 6))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 3 6 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T112OK : fastTreeOK (forms 10) 262304 1802268 q9Shape10T112=true := by decide

private def q9Shape10T110 : Tree := .split 7 q9Shape10T111 q9Shape10T112
private theorem q9Shape10T110OK : fastTreeOK (forms 10) 262176 1802268 q9Shape10T110=true := by
  change (fastTreeOK (forms 10) 262176 (1802268 ||| 2^7) q9Shape10T111 &&
    fastTreeOK (forms 10) (262176 ||| 2^7) 1802268 q9Shape10T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T111OK,q9Shape10T112OK⟩

private def q9Shape10T106 : Tree := .split 5 q9Shape10T107 q9Shape10T110
private theorem q9Shape10T106OK : fastTreeOK (forms 10) 262144 1802268 q9Shape10T106=true := by
  change (fastTreeOK (forms 10) 262144 (1802268 ||| 2^5) q9Shape10T107 &&
    fastTreeOK (forms 10) (262144 ||| 2^5) 1802268 q9Shape10T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T107OK,q9Shape10T110OK⟩

private def q9Shape10T115 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape10T115OK : fastTreeOK (forms 10) 262160 1802412 q9Shape10T115=true := by decide

private def q9Shape10T116 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 4 5 7))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 6))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 none none)) (.tip (.drop 6 8 none (some 5)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 4 5 7))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T116OK : fastTreeOK (forms 10) 262288 1802284 q9Shape10T116=true := by decide

private def q9Shape10T114 : Tree := .split 7 q9Shape10T115 q9Shape10T116
private theorem q9Shape10T114OK : fastTreeOK (forms 10) 262160 1802284 q9Shape10T114=true := by
  change (fastTreeOK (forms 10) 262160 (1802284 ||| 2^7) q9Shape10T115 &&
    fastTreeOK (forms 10) (262160 ||| 2^7) 1802284 q9Shape10T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T115OK,q9Shape10T116OK⟩

private def q9Shape10T118 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 8)) (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.split 14 (.tip (.drop 6 8 none (some 5))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 2 4)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 8)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))))
private theorem q9Shape10T118OK : fastTreeOK (forms 10) 262192 1802380 q9Shape10T118=true := by decide

private def q9Shape10T119 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 6))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 none (some 5))) (.tip (.cover 0 3 6 8))) (.tip (.cover 0 3 7 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape10T119OK : fastTreeOK (forms 10) 262320 1802252 q9Shape10T119=true := by decide

private def q9Shape10T117 : Tree := .split 7 q9Shape10T118 q9Shape10T119
private theorem q9Shape10T117OK : fastTreeOK (forms 10) 262192 1802252 q9Shape10T117=true := by
  change (fastTreeOK (forms 10) 262192 (1802252 ||| 2^7) q9Shape10T118 &&
    fastTreeOK (forms 10) (262192 ||| 2^7) 1802252 q9Shape10T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T118OK,q9Shape10T119OK⟩

private def q9Shape10T113 : Tree := .split 5 q9Shape10T114 q9Shape10T117
private theorem q9Shape10T113OK : fastTreeOK (forms 10) 262160 1802252 q9Shape10T113=true := by
  change (fastTreeOK (forms 10) 262160 (1802252 ||| 2^5) q9Shape10T114 &&
    fastTreeOK (forms 10) (262160 ||| 2^5) 1802252 q9Shape10T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T114OK,q9Shape10T117OK⟩

private def q9Shape10T105 : Tree := .split 4 q9Shape10T106 q9Shape10T113
private theorem q9Shape10T105OK : fastTreeOK (forms 10) 262144 1802252 q9Shape10T105=true := by
  change (fastTreeOK (forms 10) 262144 (1802252 ||| 2^4) q9Shape10T106 &&
    fastTreeOK (forms 10) (262144 ||| 2^4) 1802252 q9Shape10T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T106OK,q9Shape10T113OK⟩

private def q9Shape10T122 : Tree := (.split 7 (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.split 11 (.tip (.cover 0 1 6 8)) (.tip (.cover 1 3 5 6)))) (.split 10 (.tip (.cover 0 1 4 6)) (.split 11 (.tip (.cover 0 1 6 8)) (.tip (.cover 1 3 5 6))))) (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.split 11 (.tip (.cover 0 1 6 8)) (.tip (.cover 1 3 5 6)))) (.tip (.cover 0 1 3 4)))) (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8)))))
private theorem q9Shape10T122OK : fastTreeOK (forms 10) 262152 1802292 q9Shape10T122=true := by decide

private def q9Shape10T124 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 8)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.split 14 (.tip (.drop 7 8 none (some 5))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 8))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 8)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))))
private theorem q9Shape10T124OK : fastTreeOK (forms 10) 262184 1802388 q9Shape10T124=true := by decide

private def q9Shape10T125 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 2 3))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 none (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 4 5 6 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T125OK : fastTreeOK (forms 10) 262312 1802260 q9Shape10T125=true := by decide

private def q9Shape10T123 : Tree := .split 7 q9Shape10T124 q9Shape10T125
private theorem q9Shape10T123OK : fastTreeOK (forms 10) 262184 1802260 q9Shape10T123=true := by
  change (fastTreeOK (forms 10) 262184 (1802260 ||| 2^7) q9Shape10T124 &&
    fastTreeOK (forms 10) (262184 ||| 2^7) 1802260 q9Shape10T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T124OK,q9Shape10T125OK⟩

private def q9Shape10T121 : Tree := .split 5 q9Shape10T122 q9Shape10T123
private theorem q9Shape10T121OK : fastTreeOK (forms 10) 262152 1802260 q9Shape10T121=true := by
  change (fastTreeOK (forms 10) 262152 (1802260 ||| 2^5) q9Shape10T122 &&
    fastTreeOK (forms 10) (262152 ||| 2^5) 1802260 q9Shape10T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T122OK,q9Shape10T123OK⟩

private def q9Shape10T126 : Tree := (.split 5 (.split 7 (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4)))) (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))) (.tip (.cover 0 1 2 5)))
private theorem q9Shape10T126OK : fastTreeOK (forms 10) 262168 1802244 q9Shape10T126=true := by decide

private def q9Shape10T120 : Tree := .split 4 q9Shape10T121 q9Shape10T126
private theorem q9Shape10T120OK : fastTreeOK (forms 10) 262152 1802244 q9Shape10T120=true := by
  change (fastTreeOK (forms 10) 262152 (1802244 ||| 2^4) q9Shape10T121 &&
    fastTreeOK (forms 10) (262152 ||| 2^4) 1802244 q9Shape10T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T121OK,q9Shape10T126OK⟩

private def q9Shape10T104 : Tree := .split 3 q9Shape10T105 q9Shape10T120
private theorem q9Shape10T104OK : fastTreeOK (forms 10) 262144 1802244 q9Shape10T104=true := by
  change (fastTreeOK (forms 10) 262144 (1802244 ||| 2^3) q9Shape10T105 &&
    fastTreeOK (forms 10) (262144 ||| 2^3) 1802244 q9Shape10T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T105OK,q9Shape10T120OK⟩

private def q9Shape10T132 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none none)) (.tip (.drop 6 7 none (some 5)))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 4 5 7))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8)))))
private theorem q9Shape10T132OK : fastTreeOK (forms 10) 262148 1802680 q9Shape10T132=true := by decide

private def q9Shape10T133 : Tree := (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8)))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T133OK : fastTreeOK (forms 10) 262404 1802424 q9Shape10T133=true := by decide

private def q9Shape10T131 : Tree := .split 8 q9Shape10T132 q9Shape10T133
private theorem q9Shape10T131OK : fastTreeOK (forms 10) 262148 1802424 q9Shape10T131=true := by
  change (fastTreeOK (forms 10) 262148 (1802424 ||| 2^8) q9Shape10T132 &&
    fastTreeOK (forms 10) (262148 ||| 2^8) 1802424 q9Shape10T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T132OK,q9Shape10T133OK⟩

private def q9Shape10T134 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T134OK : fastTreeOK (forms 10) 262276 1802296 q9Shape10T134=true := by decide

private def q9Shape10T130 : Tree := .split 7 q9Shape10T131 q9Shape10T134
private theorem q9Shape10T130OK : fastTreeOK (forms 10) 262148 1802296 q9Shape10T130=true := by
  change (fastTreeOK (forms 10) 262148 (1802296 ||| 2^7) q9Shape10T131 &&
    fastTreeOK (forms 10) (262148 ||| 2^7) 1802296 q9Shape10T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T131OK,q9Shape10T134OK⟩

private def q9Shape10T135 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T135OK : fastTreeOK (forms 10) 262180 1802264 q9Shape10T135=true := by decide

private def q9Shape10T129 : Tree := .split 5 q9Shape10T130 q9Shape10T135
private theorem q9Shape10T129OK : fastTreeOK (forms 10) 262148 1802264 q9Shape10T129=true := by
  change (fastTreeOK (forms 10) 262148 (1802264 ||| 2^5) q9Shape10T130 &&
    fastTreeOK (forms 10) (262148 ||| 2^5) 1802264 q9Shape10T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T130OK,q9Shape10T135OK⟩

private def q9Shape10T139 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.split 14 (.tip (.drop 6 8 none none)) (.tip (.drop 6 8 none (some 5))))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 none (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 4 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 none none)) (.tip (.drop 6 8 none (some 5)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 none (some 5))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 2 7 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 7 8)))))
private theorem q9Shape10T139OK : fastTreeOK (forms 10) 262164 1802664 q9Shape10T139=true := by decide

private def q9Shape10T140 : Tree := (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 2 3))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T140OK : fastTreeOK (forms 10) 262420 1802408 q9Shape10T140=true := by decide

private def q9Shape10T138 : Tree := .split 8 q9Shape10T139 q9Shape10T140
private theorem q9Shape10T138OK : fastTreeOK (forms 10) 262164 1802408 q9Shape10T138=true := by
  change (fastTreeOK (forms 10) 262164 (1802408 ||| 2^8) q9Shape10T139 &&
    fastTreeOK (forms 10) (262164 ||| 2^8) 1802408 q9Shape10T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T139OK,q9Shape10T140OK⟩

private def q9Shape10T141 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T141OK : fastTreeOK (forms 10) 262292 1802280 q9Shape10T141=true := by decide

private def q9Shape10T137 : Tree := .split 7 q9Shape10T138 q9Shape10T141
private theorem q9Shape10T137OK : fastTreeOK (forms 10) 262164 1802280 q9Shape10T137=true := by
  change (fastTreeOK (forms 10) 262164 (1802280 ||| 2^7) q9Shape10T138 &&
    fastTreeOK (forms 10) (262164 ||| 2^7) 1802280 q9Shape10T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T138OK,q9Shape10T141OK⟩

private def q9Shape10T142 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T142OK : fastTreeOK (forms 10) 262196 1802248 q9Shape10T142=true := by decide

private def q9Shape10T136 : Tree := .split 5 q9Shape10T137 q9Shape10T142
private theorem q9Shape10T136OK : fastTreeOK (forms 10) 262164 1802248 q9Shape10T136=true := by
  change (fastTreeOK (forms 10) 262164 (1802248 ||| 2^5) q9Shape10T137 &&
    fastTreeOK (forms 10) (262164 ||| 2^5) 1802248 q9Shape10T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T137OK,q9Shape10T142OK⟩

private def q9Shape10T128 : Tree := .split 4 q9Shape10T129 q9Shape10T136
private theorem q9Shape10T128OK : fastTreeOK (forms 10) 262148 1802248 q9Shape10T128=true := by
  change (fastTreeOK (forms 10) 262148 (1802248 ||| 2^4) q9Shape10T129 &&
    fastTreeOK (forms 10) (262148 ||| 2^4) 1802248 q9Shape10T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T129OK,q9Shape10T136OK⟩

private def q9Shape10T147 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.split 14 (.tip (.small 1)) (.tip (.drop 7 8 none (some 5)))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 4 5 7))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T147OK : fastTreeOK (forms 10) 262156 1802672 q9Shape10T147=true := by decide

private def q9Shape10T148 : Tree := (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 none (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 4 5 6 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 5 7 8)))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T148OK : fastTreeOK (forms 10) 262412 1802416 q9Shape10T148=true := by decide

private def q9Shape10T146 : Tree := .split 8 q9Shape10T147 q9Shape10T148
private theorem q9Shape10T146OK : fastTreeOK (forms 10) 262156 1802416 q9Shape10T146=true := by
  change (fastTreeOK (forms 10) 262156 (1802416 ||| 2^8) q9Shape10T147 &&
    fastTreeOK (forms 10) (262156 ||| 2^8) 1802416 q9Shape10T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T147OK,q9Shape10T148OK⟩

private def q9Shape10T149 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T149OK : fastTreeOK (forms 10) 262284 1802288 q9Shape10T149=true := by decide

private def q9Shape10T145 : Tree := .split 7 q9Shape10T146 q9Shape10T149
private theorem q9Shape10T145OK : fastTreeOK (forms 10) 262156 1802288 q9Shape10T145=true := by
  change (fastTreeOK (forms 10) 262156 (1802288 ||| 2^7) q9Shape10T146 &&
    fastTreeOK (forms 10) (262156 ||| 2^7) 1802288 q9Shape10T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T146OK,q9Shape10T149OK⟩

private def q9Shape10T150 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T150OK : fastTreeOK (forms 10) 262188 1802256 q9Shape10T150=true := by decide

private def q9Shape10T144 : Tree := .split 5 q9Shape10T145 q9Shape10T150
private theorem q9Shape10T144OK : fastTreeOK (forms 10) 262156 1802256 q9Shape10T144=true := by
  change (fastTreeOK (forms 10) 262156 (1802256 ||| 2^5) q9Shape10T145 &&
    fastTreeOK (forms 10) (262156 ||| 2^5) 1802256 q9Shape10T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T145OK,q9Shape10T150OK⟩

private def q9Shape10T151 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape10T151OK : fastTreeOK (forms 10) 262172 1802240 q9Shape10T151=true := by decide

private def q9Shape10T143 : Tree := .split 4 q9Shape10T144 q9Shape10T151
private theorem q9Shape10T143OK : fastTreeOK (forms 10) 262156 1802240 q9Shape10T143=true := by
  change (fastTreeOK (forms 10) 262156 (1802240 ||| 2^4) q9Shape10T144 &&
    fastTreeOK (forms 10) (262156 ||| 2^4) 1802240 q9Shape10T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T144OK,q9Shape10T151OK⟩

private def q9Shape10T127 : Tree := .split 3 q9Shape10T128 q9Shape10T143
private theorem q9Shape10T127OK : fastTreeOK (forms 10) 262148 1802240 q9Shape10T127=true := by
  change (fastTreeOK (forms 10) 262148 (1802240 ||| 2^3) q9Shape10T128 &&
    fastTreeOK (forms 10) (262148 ||| 2^3) 1802240 q9Shape10T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T128OK,q9Shape10T143OK⟩

private def q9Shape10T103 : Tree := .split 2 q9Shape10T104 q9Shape10T127
private theorem q9Shape10T103OK : fastTreeOK (forms 10) 262144 1802240 q9Shape10T103=true := by
  change (fastTreeOK (forms 10) 262144 (1802240 ||| 2^2) q9Shape10T104 &&
    fastTreeOK (forms 10) (262144 ||| 2^2) 1802240 q9Shape10T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T104OK,q9Shape10T127OK⟩

private def q9Shape10T152 : Tree := (.tip (.cover 0 1 5 6))
private theorem q9Shape10T152OK : fastTreeOK (forms 10) 786432 1277952 q9Shape10T152=true := by decide

private def q9Shape10T102 : Tree := .split 19 q9Shape10T103 q9Shape10T152
private theorem q9Shape10T102OK : fastTreeOK (forms 10) 262144 1277952 q9Shape10T102=true := by
  change (fastTreeOK (forms 10) 262144 (1277952 ||| 2^19) q9Shape10T103 &&
    fastTreeOK (forms 10) (262144 ||| 2^19) 1277952 q9Shape10T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T103OK,q9Shape10T152OK⟩

private def q9Shape10T4 : Tree := .split 18 q9Shape10T5 q9Shape10T102
private theorem q9Shape10T4OK : fastTreeOK (forms 10) 0 1277952 q9Shape10T4=true := by
  change (fastTreeOK (forms 10) 0 (1277952 ||| 2^18) q9Shape10T5 &&
    fastTreeOK (forms 10) (0 ||| 2^18) 1277952 q9Shape10T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T5OK,q9Shape10T102OK⟩

private def q9Shape10T161 : Tree := (.split 9 (.tip (.cover 0 1 4 5)) (.split 10 (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 1 4 5)))) (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 6) (some 5)))) (.tip (.cover 0 1 4 5))))) (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 3 4)))))
private theorem q9Shape10T161OK : fastTreeOK (forms 10) 131072 1933756 q9Shape10T161=true := by decide

private def q9Shape10T162 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 6) (some 5))))) (.tip (.cover 0 1 4 5)))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 1 3 5)))
private theorem q9Shape10T162OK : fastTreeOK (forms 10) 131328 1933500 q9Shape10T162=true := by decide

private def q9Shape10T160 : Tree := .split 8 q9Shape10T161 q9Shape10T162
private theorem q9Shape10T160OK : fastTreeOK (forms 10) 131072 1933500 q9Shape10T160=true := by
  change (fastTreeOK (forms 10) 131072 (1933500 ||| 2^8) q9Shape10T161 &&
    fastTreeOK (forms 10) (131072 ||| 2^8) 1933500 q9Shape10T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T161OK,q9Shape10T162OK⟩

private def q9Shape10T163 : Tree := (.split 8 (.split 9 (.tip (.cover 0 1 4 5)) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 5)))) (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T163OK : fastTreeOK (forms 10) 131200 1933372 q9Shape10T163=true := by decide

private def q9Shape10T159 : Tree := .split 7 q9Shape10T160 q9Shape10T163
private theorem q9Shape10T159OK : fastTreeOK (forms 10) 131072 1933372 q9Shape10T159=true := by
  change (fastTreeOK (forms 10) 131072 (1933372 ||| 2^7) q9Shape10T160 &&
    fastTreeOK (forms 10) (131072 ||| 2^7) 1933372 q9Shape10T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T160OK,q9Shape10T163OK⟩

private def q9Shape10T164 : Tree := (.split 7 (.split 8 (.split 9 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 8))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 1 3 5)))) (.split 8 (.split 9 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T164OK : fastTreeOK (forms 10) 131104 1933340 q9Shape10T164=true := by decide

private def q9Shape10T158 : Tree := .split 5 q9Shape10T159 q9Shape10T164
private theorem q9Shape10T158OK : fastTreeOK (forms 10) 131072 1933340 q9Shape10T158=true := by
  change (fastTreeOK (forms 10) 131072 (1933340 ||| 2^5) q9Shape10T159 &&
    fastTreeOK (forms 10) (131072 ||| 2^5) 1933340 q9Shape10T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T159OK,q9Shape10T164OK⟩

private def q9Shape10T167 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 1 4 5)))) (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 6) (some 5)))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T167OK : fastTreeOK (forms 10) 131088 1933484 q9Shape10T167=true := by decide

private def q9Shape10T168 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T168OK : fastTreeOK (forms 10) 131216 1933356 q9Shape10T168=true := by decide

private def q9Shape10T166 : Tree := .split 7 q9Shape10T167 q9Shape10T168
private theorem q9Shape10T166OK : fastTreeOK (forms 10) 131088 1933356 q9Shape10T166=true := by
  change (fastTreeOK (forms 10) 131088 (1933356 ||| 2^7) q9Shape10T167 &&
    fastTreeOK (forms 10) (131088 ||| 2^7) 1933356 q9Shape10T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T167OK,q9Shape10T168OK⟩

private def q9Shape10T170 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 4 7 8))) (.tip (.cover 4 6 7 8)))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T170OK : fastTreeOK (forms 10) 131120 1933452 q9Shape10T170=true := by decide

private def q9Shape10T171 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape10T171OK : fastTreeOK (forms 10) 131248 1933324 q9Shape10T171=true := by decide

private def q9Shape10T169 : Tree := .split 7 q9Shape10T170 q9Shape10T171
private theorem q9Shape10T169OK : fastTreeOK (forms 10) 131120 1933324 q9Shape10T169=true := by
  change (fastTreeOK (forms 10) 131120 (1933324 ||| 2^7) q9Shape10T170 &&
    fastTreeOK (forms 10) (131120 ||| 2^7) 1933324 q9Shape10T171)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T170OK,q9Shape10T171OK⟩

private def q9Shape10T165 : Tree := .split 5 q9Shape10T166 q9Shape10T169
private theorem q9Shape10T165OK : fastTreeOK (forms 10) 131088 1933324 q9Shape10T165=true := by
  change (fastTreeOK (forms 10) 131088 (1933324 ||| 2^5) q9Shape10T166 &&
    fastTreeOK (forms 10) (131088 ||| 2^5) 1933324 q9Shape10T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T166OK,q9Shape10T169OK⟩

private def q9Shape10T157 : Tree := .split 4 q9Shape10T158 q9Shape10T165
private theorem q9Shape10T157OK : fastTreeOK (forms 10) 131072 1933324 q9Shape10T157=true := by
  change (fastTreeOK (forms 10) 131072 (1933324 ||| 2^4) q9Shape10T158 &&
    fastTreeOK (forms 10) (131072 ||| 2^4) 1933324 q9Shape10T165)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T158OK,q9Shape10T165OK⟩

private def q9Shape10T176 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.drop 7 8 (some 6) (some 5))))) (.tip (.cover 0 1 4 5)))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6)))))
private theorem q9Shape10T176OK : fastTreeOK (forms 10) 131080 1933748 q9Shape10T176=true := by decide

private def q9Shape10T177 : Tree := (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5)))
private theorem q9Shape10T177OK : fastTreeOK (forms 10) 131336 1933492 q9Shape10T177=true := by decide

private def q9Shape10T175 : Tree := .split 8 q9Shape10T176 q9Shape10T177
private theorem q9Shape10T175OK : fastTreeOK (forms 10) 131080 1933492 q9Shape10T175=true := by
  change (fastTreeOK (forms 10) 131080 (1933492 ||| 2^8) q9Shape10T176 &&
    fastTreeOK (forms 10) (131080 ||| 2^8) 1933492 q9Shape10T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T176OK,q9Shape10T177OK⟩

private def q9Shape10T178 : Tree := (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 6)))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T178OK : fastTreeOK (forms 10) 131208 1933364 q9Shape10T178=true := by decide

private def q9Shape10T174 : Tree := .split 7 q9Shape10T175 q9Shape10T178
private theorem q9Shape10T174OK : fastTreeOK (forms 10) 131080 1933364 q9Shape10T174=true := by
  change (fastTreeOK (forms 10) 131080 (1933364 ||| 2^7) q9Shape10T175 &&
    fastTreeOK (forms 10) (131080 ||| 2^7) 1933364 q9Shape10T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T175OK,q9Shape10T178OK⟩

private def q9Shape10T180 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 2 4)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 5 7))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 4 7 8))) (.tip (.cover 4 6 7 8))))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T180OK : fastTreeOK (forms 10) 131112 1933460 q9Shape10T180=true := by decide

private def q9Shape10T181 : Tree := (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 2 3))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T181OK : fastTreeOK (forms 10) 131240 1933332 q9Shape10T181=true := by decide

private def q9Shape10T179 : Tree := .split 7 q9Shape10T180 q9Shape10T181
private theorem q9Shape10T179OK : fastTreeOK (forms 10) 131112 1933332 q9Shape10T179=true := by
  change (fastTreeOK (forms 10) 131112 (1933332 ||| 2^7) q9Shape10T180 &&
    fastTreeOK (forms 10) (131112 ||| 2^7) 1933332 q9Shape10T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T180OK,q9Shape10T181OK⟩

private def q9Shape10T173 : Tree := .split 5 q9Shape10T174 q9Shape10T179
private theorem q9Shape10T173OK : fastTreeOK (forms 10) 131080 1933332 q9Shape10T173=true := by
  change (fastTreeOK (forms 10) 131080 (1933332 ||| 2^5) q9Shape10T174 &&
    fastTreeOK (forms 10) (131080 ||| 2^5) 1933332 q9Shape10T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T174OK,q9Shape10T179OK⟩

private def q9Shape10T182 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T182OK : fastTreeOK (forms 10) 131096 1933316 q9Shape10T182=true := by decide

private def q9Shape10T172 : Tree := .split 4 q9Shape10T173 q9Shape10T182
private theorem q9Shape10T172OK : fastTreeOK (forms 10) 131080 1933316 q9Shape10T172=true := by
  change (fastTreeOK (forms 10) 131080 (1933316 ||| 2^4) q9Shape10T173 &&
    fastTreeOK (forms 10) (131080 ||| 2^4) 1933316 q9Shape10T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T173OK,q9Shape10T182OK⟩

private def q9Shape10T156 : Tree := .split 3 q9Shape10T157 q9Shape10T172
private theorem q9Shape10T156OK : fastTreeOK (forms 10) 131072 1933316 q9Shape10T156=true := by
  change (fastTreeOK (forms 10) 131072 (1933316 ||| 2^3) q9Shape10T157 &&
    fastTreeOK (forms 10) (131072 ||| 2^3) 1933316 q9Shape10T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T157OK,q9Shape10T172OK⟩

private def q9Shape10T186 : Tree := (.split 7 (.split 8 (.split 9 (.tip (.cover 0 1 4 5)) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 3 5 6))) (.tip (.cover 1 3 5 6))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 4))))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5)))) (.split 8 (.split 9 (.tip (.cover 0 1 4 5)) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 3 5 6))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 6)))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T186OK : fastTreeOK (forms 10) 131076 1933368 q9Shape10T186=true := by decide

private def q9Shape10T187 : Tree := (.split 7 (.split 8 (.split 9 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5)))) (.split 8 (.split 9 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T187OK : fastTreeOK (forms 10) 131108 1933336 q9Shape10T187=true := by decide

private def q9Shape10T185 : Tree := .split 5 q9Shape10T186 q9Shape10T187
private theorem q9Shape10T185OK : fastTreeOK (forms 10) 131076 1933336 q9Shape10T185=true := by
  change (fastTreeOK (forms 10) 131076 (1933336 ||| 2^5) q9Shape10T186 &&
    fastTreeOK (forms 10) (131076 ||| 2^5) 1933336 q9Shape10T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T186OK,q9Shape10T187OK⟩

private def q9Shape10T190 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 5)))) (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 3))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T190OK : fastTreeOK (forms 10) 131092 1933480 q9Shape10T190=true := by decide

private def q9Shape10T191 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T191OK : fastTreeOK (forms 10) 131220 1933352 q9Shape10T191=true := by decide

private def q9Shape10T189 : Tree := .split 7 q9Shape10T190 q9Shape10T191
private theorem q9Shape10T189OK : fastTreeOK (forms 10) 131092 1933352 q9Shape10T189=true := by
  change (fastTreeOK (forms 10) 131092 (1933352 ||| 2^7) q9Shape10T190 &&
    fastTreeOK (forms 10) (131092 ||| 2^7) 1933352 q9Shape10T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T190OK,q9Shape10T191OK⟩

private def q9Shape10T192 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T192OK : fastTreeOK (forms 10) 131124 1933320 q9Shape10T192=true := by decide

private def q9Shape10T188 : Tree := .split 5 q9Shape10T189 q9Shape10T192
private theorem q9Shape10T188OK : fastTreeOK (forms 10) 131092 1933320 q9Shape10T188=true := by
  change (fastTreeOK (forms 10) 131092 (1933320 ||| 2^5) q9Shape10T189 &&
    fastTreeOK (forms 10) (131092 ||| 2^5) 1933320 q9Shape10T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T189OK,q9Shape10T192OK⟩

private def q9Shape10T184 : Tree := .split 4 q9Shape10T185 q9Shape10T188
private theorem q9Shape10T184OK : fastTreeOK (forms 10) 131076 1933320 q9Shape10T184=true := by
  change (fastTreeOK (forms 10) 131076 (1933320 ||| 2^4) q9Shape10T185 &&
    fastTreeOK (forms 10) (131076 ||| 2^4) 1933320 q9Shape10T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T185OK,q9Shape10T188OK⟩

private def q9Shape10T196 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.tip (.cover 0 1 5 6)) (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 5)))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 2 3)))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T196OK : fastTreeOK (forms 10) 131084 1933488 q9Shape10T196=true := by decide

private def q9Shape10T197 : Tree := (.split 8 (.split 9 (.tip (.cover 1 4 5 6)) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 6)))) (.split 9 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T197OK : fastTreeOK (forms 10) 131212 1933360 q9Shape10T197=true := by decide

private def q9Shape10T195 : Tree := .split 7 q9Shape10T196 q9Shape10T197
private theorem q9Shape10T195OK : fastTreeOK (forms 10) 131084 1933360 q9Shape10T195=true := by
  change (fastTreeOK (forms 10) 131084 (1933360 ||| 2^7) q9Shape10T196 &&
    fastTreeOK (forms 10) (131084 ||| 2^7) 1933360 q9Shape10T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T196OK,q9Shape10T197OK⟩

private def q9Shape10T198 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape10T198OK : fastTreeOK (forms 10) 131116 1933328 q9Shape10T198=true := by decide

private def q9Shape10T194 : Tree := .split 5 q9Shape10T195 q9Shape10T198
private theorem q9Shape10T194OK : fastTreeOK (forms 10) 131084 1933328 q9Shape10T194=true := by
  change (fastTreeOK (forms 10) 131084 (1933328 ||| 2^5) q9Shape10T195 &&
    fastTreeOK (forms 10) (131084 ||| 2^5) 1933328 q9Shape10T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T195OK,q9Shape10T198OK⟩

private def q9Shape10T199 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T199OK : fastTreeOK (forms 10) 131100 1933312 q9Shape10T199=true := by decide

private def q9Shape10T193 : Tree := .split 4 q9Shape10T194 q9Shape10T199
private theorem q9Shape10T193OK : fastTreeOK (forms 10) 131084 1933312 q9Shape10T193=true := by
  change (fastTreeOK (forms 10) 131084 (1933312 ||| 2^4) q9Shape10T194 &&
    fastTreeOK (forms 10) (131084 ||| 2^4) 1933312 q9Shape10T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T194OK,q9Shape10T199OK⟩

private def q9Shape10T183 : Tree := .split 3 q9Shape10T184 q9Shape10T193
private theorem q9Shape10T183OK : fastTreeOK (forms 10) 131076 1933312 q9Shape10T183=true := by
  change (fastTreeOK (forms 10) 131076 (1933312 ||| 2^3) q9Shape10T184 &&
    fastTreeOK (forms 10) (131076 ||| 2^3) 1933312 q9Shape10T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T184OK,q9Shape10T193OK⟩

private def q9Shape10T155 : Tree := .split 2 q9Shape10T156 q9Shape10T183
private theorem q9Shape10T155OK : fastTreeOK (forms 10) 131072 1933312 q9Shape10T155=true := by
  change (fastTreeOK (forms 10) 131072 (1933312 ||| 2^2) q9Shape10T156 &&
    fastTreeOK (forms 10) (131072 ||| 2^2) 1933312 q9Shape10T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T156OK,q9Shape10T183OK⟩

private def q9Shape10T200 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape10T200OK : fastTreeOK (forms 10) 655360 1409024 q9Shape10T200=true := by decide

private def q9Shape10T154 : Tree := .split 19 q9Shape10T155 q9Shape10T200
private theorem q9Shape10T154OK : fastTreeOK (forms 10) 131072 1409024 q9Shape10T154=true := by
  change (fastTreeOK (forms 10) 131072 (1409024 ||| 2^19) q9Shape10T155 &&
    fastTreeOK (forms 10) (131072 ||| 2^19) 1409024 q9Shape10T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T155OK,q9Shape10T200OK⟩

private def q9Shape10T201 : Tree := (.tip (.cover 0 1 5 6))
private theorem q9Shape10T201OK : fastTreeOK (forms 10) 393216 1146880 q9Shape10T201=true := by decide

private def q9Shape10T153 : Tree := .split 18 q9Shape10T154 q9Shape10T201
private theorem q9Shape10T153OK : fastTreeOK (forms 10) 131072 1146880 q9Shape10T153=true := by
  change (fastTreeOK (forms 10) 131072 (1146880 ||| 2^18) q9Shape10T154 &&
    fastTreeOK (forms 10) (131072 ||| 2^18) 1146880 q9Shape10T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T154OK,q9Shape10T201OK⟩

private def q9Shape10T3 : Tree := .split 17 q9Shape10T4 q9Shape10T153
private theorem q9Shape10T3OK : fastTreeOK (forms 10) 0 1146880 q9Shape10T3=true := by
  change (fastTreeOK (forms 10) 0 (1146880 ||| 2^17) q9Shape10T4 &&
    fastTreeOK (forms 10) (0 ||| 2^17) 1146880 q9Shape10T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T4OK,q9Shape10T153OK⟩

private def q9Shape10T211 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6))))) (.split 12 (.tip (.cover 0 1 5 8)) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 8)))))) (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none (some 6))) (.split 14 (.tip (.drop 5 8 none (some 6))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 3 4)))))
private theorem q9Shape10T211OK : fastTreeOK (forms 10) 65536 1999292 q9Shape10T211=true := by decide

private def q9Shape10T212 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 3 5))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.split 14 (.tip (.drop 5 8 none none)) (.tip (.drop 5 8 none (some 6))))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T212OK : fastTreeOK (forms 10) 65792 1999036 q9Shape10T212=true := by decide

private def q9Shape10T210 : Tree := .split 8 q9Shape10T211 q9Shape10T212
private theorem q9Shape10T210OK : fastTreeOK (forms 10) 65536 1999036 q9Shape10T210=true := by
  change (fastTreeOK (forms 10) 65536 (1999036 ||| 2^8) q9Shape10T211 &&
    fastTreeOK (forms 10) (65536 ||| 2^8) 1999036 q9Shape10T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T211OK,q9Shape10T212OK⟩

private def q9Shape10T213 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5))))) (.split 12 (.tip (.cover 0 1 5 8)) (.split 13 (.split 14 (.tip (.drop 7 8 none (some 6))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 4 8)))))) (.tip (.cover 0 1 3 4))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.split 14 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T213OK : fastTreeOK (forms 10) 65664 1998908 q9Shape10T213=true := by decide

private def q9Shape10T209 : Tree := .split 7 q9Shape10T210 q9Shape10T213
private theorem q9Shape10T209OK : fastTreeOK (forms 10) 65536 1998908 q9Shape10T209=true := by
  change (fastTreeOK (forms 10) 65536 (1998908 ||| 2^7) q9Shape10T210 &&
    fastTreeOK (forms 10) (65536 ||| 2^7) 1998908 q9Shape10T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T210OK,q9Shape10T213OK⟩

private def q9Shape10T215 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6))))) (.split 12 (.tip (.cover 0 1 5 8)) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 8))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 5))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T215OK : fastTreeOK (forms 10) 65568 1999004 q9Shape10T215=true := by decide

private def q9Shape10T216 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.tip (.cover 1 2 5 6))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T216OK : fastTreeOK (forms 10) 65696 1998876 q9Shape10T216=true := by decide

private def q9Shape10T214 : Tree := .split 7 q9Shape10T215 q9Shape10T216
private theorem q9Shape10T214OK : fastTreeOK (forms 10) 65568 1998876 q9Shape10T214=true := by
  change (fastTreeOK (forms 10) 65568 (1998876 ||| 2^7) q9Shape10T215 &&
    fastTreeOK (forms 10) (65568 ||| 2^7) 1998876 q9Shape10T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T215OK,q9Shape10T216OK⟩

private def q9Shape10T208 : Tree := .split 5 q9Shape10T209 q9Shape10T214
private theorem q9Shape10T208OK : fastTreeOK (forms 10) 65536 1998876 q9Shape10T208=true := by
  change (fastTreeOK (forms 10) 65536 (1998876 ||| 2^5) q9Shape10T209 &&
    fastTreeOK (forms 10) (65536 ||| 2^5) 1998876 q9Shape10T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T209OK,q9Shape10T214OK⟩

private def q9Shape10T219 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 7))) (.tip (.cover 0 1 3 5))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 5 8 none none)) (.tip (.drop 5 8 none (some 6)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T219OK : fastTreeOK (forms 10) 65552 1999020 q9Shape10T219=true := by decide

private def q9Shape10T220 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 7))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T220OK : fastTreeOK (forms 10) 65680 1998892 q9Shape10T220=true := by decide

private def q9Shape10T218 : Tree := .split 7 q9Shape10T219 q9Shape10T220
private theorem q9Shape10T218OK : fastTreeOK (forms 10) 65552 1998892 q9Shape10T218=true := by
  change (fastTreeOK (forms 10) 65552 (1998892 ||| 2^7) q9Shape10T219 &&
    fastTreeOK (forms 10) (65552 ||| 2^7) 1998892 q9Shape10T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T219OK,q9Shape10T220OK⟩

private def q9Shape10T222 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.small 0)) (.split 13 (.tip (.drop 5 7 none (some 6))) (.split 14 (.tip (.drop 5 8 none (some 6))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 5))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 5 8 none (some 6))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T222OK : fastTreeOK (forms 10) 65584 1998988 q9Shape10T222=true := by decide

private def q9Shape10T223 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape10T223OK : fastTreeOK (forms 10) 65712 1998860 q9Shape10T223=true := by decide

private def q9Shape10T221 : Tree := .split 7 q9Shape10T222 q9Shape10T223
private theorem q9Shape10T221OK : fastTreeOK (forms 10) 65584 1998860 q9Shape10T221=true := by
  change (fastTreeOK (forms 10) 65584 (1998860 ||| 2^7) q9Shape10T222 &&
    fastTreeOK (forms 10) (65584 ||| 2^7) 1998860 q9Shape10T223)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T222OK,q9Shape10T223OK⟩

private def q9Shape10T217 : Tree := .split 5 q9Shape10T218 q9Shape10T221
private theorem q9Shape10T217OK : fastTreeOK (forms 10) 65552 1998860 q9Shape10T217=true := by
  change (fastTreeOK (forms 10) 65552 (1998860 ||| 2^5) q9Shape10T218 &&
    fastTreeOK (forms 10) (65552 ||| 2^5) 1998860 q9Shape10T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T218OK,q9Shape10T221OK⟩

private def q9Shape10T207 : Tree := .split 4 q9Shape10T208 q9Shape10T217
private theorem q9Shape10T207OK : fastTreeOK (forms 10) 65536 1998860 q9Shape10T207=true := by
  change (fastTreeOK (forms 10) 65536 (1998860 ||| 2^4) q9Shape10T208 &&
    fastTreeOK (forms 10) (65536 ||| 2^4) 1998860 q9Shape10T217)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T208OK,q9Shape10T217OK⟩

private def q9Shape10T228 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 5)))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none none)) (.tip (.drop 5 7 none (some 6)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 7))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6)))))
private theorem q9Shape10T228OK : fastTreeOK (forms 10) 65544 1999284 q9Shape10T228=true := by decide

private def q9Shape10T229 : Tree := (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T229OK : fastTreeOK (forms 10) 65800 1999028 q9Shape10T229=true := by decide

private def q9Shape10T227 : Tree := .split 8 q9Shape10T228 q9Shape10T229
private theorem q9Shape10T227OK : fastTreeOK (forms 10) 65544 1999028 q9Shape10T227=true := by
  change (fastTreeOK (forms 10) 65544 (1999028 ||| 2^8) q9Shape10T228 &&
    fastTreeOK (forms 10) (65544 ||| 2^8) 1999028 q9Shape10T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T228OK,q9Shape10T229OK⟩

private def q9Shape10T230 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6)))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T230OK : fastTreeOK (forms 10) 65672 1998900 q9Shape10T230=true := by decide

private def q9Shape10T226 : Tree := .split 7 q9Shape10T227 q9Shape10T230
private theorem q9Shape10T226OK : fastTreeOK (forms 10) 65544 1998900 q9Shape10T226=true := by
  change (fastTreeOK (forms 10) 65544 (1998900 ||| 2^7) q9Shape10T227 &&
    fastTreeOK (forms 10) (65544 ||| 2^7) 1998900 q9Shape10T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T227OK,q9Shape10T230OK⟩

private def q9Shape10T231 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T231OK : fastTreeOK (forms 10) 65576 1998868 q9Shape10T231=true := by decide

private def q9Shape10T225 : Tree := .split 5 q9Shape10T226 q9Shape10T231
private theorem q9Shape10T225OK : fastTreeOK (forms 10) 65544 1998868 q9Shape10T225=true := by
  change (fastTreeOK (forms 10) 65544 (1998868 ||| 2^5) q9Shape10T226 &&
    fastTreeOK (forms 10) (65544 ||| 2^5) 1998868 q9Shape10T231)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T226OK,q9Shape10T231OK⟩

private def q9Shape10T235 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.split 14 (.tip (.drop 5 8 none none)) (.tip (.drop 5 8 none (some 6))))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.tip (.drop 5 7 none (some 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 5 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 5 8 none none)) (.tip (.drop 5 8 none (some 6)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 5 8 none (some 6))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 4 6 7 8)))))
private theorem q9Shape10T235OK : fastTreeOK (forms 10) 65560 1999268 q9Shape10T235=true := by decide

private def q9Shape10T236 : Tree := (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T236OK : fastTreeOK (forms 10) 65816 1999012 q9Shape10T236=true := by decide

private def q9Shape10T234 : Tree := .split 8 q9Shape10T235 q9Shape10T236
private theorem q9Shape10T234OK : fastTreeOK (forms 10) 65560 1999012 q9Shape10T234=true := by
  change (fastTreeOK (forms 10) 65560 (1999012 ||| 2^8) q9Shape10T235 &&
    fastTreeOK (forms 10) (65560 ||| 2^8) 1999012 q9Shape10T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T235OK,q9Shape10T236OK⟩

private def q9Shape10T237 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 2 3))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T237OK : fastTreeOK (forms 10) 65688 1998884 q9Shape10T237=true := by decide

private def q9Shape10T233 : Tree := .split 7 q9Shape10T234 q9Shape10T237
private theorem q9Shape10T233OK : fastTreeOK (forms 10) 65560 1998884 q9Shape10T233=true := by
  change (fastTreeOK (forms 10) 65560 (1998884 ||| 2^7) q9Shape10T234 &&
    fastTreeOK (forms 10) (65560 ||| 2^7) 1998884 q9Shape10T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T234OK,q9Shape10T237OK⟩

private def q9Shape10T238 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T238OK : fastTreeOK (forms 10) 65592 1998852 q9Shape10T238=true := by decide

private def q9Shape10T232 : Tree := .split 5 q9Shape10T233 q9Shape10T238
private theorem q9Shape10T232OK : fastTreeOK (forms 10) 65560 1998852 q9Shape10T232=true := by
  change (fastTreeOK (forms 10) 65560 (1998852 ||| 2^5) q9Shape10T233 &&
    fastTreeOK (forms 10) (65560 ||| 2^5) 1998852 q9Shape10T238)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T233OK,q9Shape10T238OK⟩

private def q9Shape10T224 : Tree := .split 4 q9Shape10T225 q9Shape10T232
private theorem q9Shape10T224OK : fastTreeOK (forms 10) 65544 1998852 q9Shape10T224=true := by
  change (fastTreeOK (forms 10) 65544 (1998852 ||| 2^4) q9Shape10T225 &&
    fastTreeOK (forms 10) (65544 ||| 2^4) 1998852 q9Shape10T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T225OK,q9Shape10T232OK⟩

private def q9Shape10T206 : Tree := .split 3 q9Shape10T207 q9Shape10T224
private theorem q9Shape10T206OK : fastTreeOK (forms 10) 65536 1998852 q9Shape10T206=true := by
  change (fastTreeOK (forms 10) 65536 (1998852 ||| 2^3) q9Shape10T207 &&
    fastTreeOK (forms 10) (65536 ||| 2^3) 1998852 q9Shape10T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T207OK,q9Shape10T224OK⟩

private def q9Shape10T242 : Tree := (.split 7 (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.tip (.cover 1 3 5 6))) (.tip (.cover 1 3 5 6)))) (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 4))))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))) (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.tip (.cover 1 3 5 6))) (.tip (.cover 1 3 5 6)))) (.tip (.cover 0 1 3 4))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8)))))
private theorem q9Shape10T242OK : fastTreeOK (forms 10) 65540 1998904 q9Shape10T242=true := by decide

private def q9Shape10T244 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5))))) (.split 12 (.tip (.cover 0 1 5 8)) (.split 13 (.split 14 (.tip (.drop 7 8 none (some 6))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 4 8))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T244OK : fastTreeOK (forms 10) 65572 1999000 q9Shape10T244=true := by decide

private def q9Shape10T245 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 8)) (.tip (.cover 1 2 5 6))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 none (some 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T245OK : fastTreeOK (forms 10) 65700 1998872 q9Shape10T245=true := by decide

private def q9Shape10T243 : Tree := .split 7 q9Shape10T244 q9Shape10T245
private theorem q9Shape10T243OK : fastTreeOK (forms 10) 65572 1998872 q9Shape10T243=true := by
  change (fastTreeOK (forms 10) 65572 (1998872 ||| 2^7) q9Shape10T244 &&
    fastTreeOK (forms 10) (65572 ||| 2^7) 1998872 q9Shape10T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T244OK,q9Shape10T245OK⟩

private def q9Shape10T241 : Tree := .split 5 q9Shape10T242 q9Shape10T243
private theorem q9Shape10T241OK : fastTreeOK (forms 10) 65540 1998872 q9Shape10T241=true := by
  change (fastTreeOK (forms 10) 65540 (1998872 ||| 2^5) q9Shape10T242 &&
    fastTreeOK (forms 10) (65540 ||| 2^5) 1998872 q9Shape10T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T242OK,q9Shape10T243OK⟩

private def q9Shape10T246 : Tree := (.split 5 (.split 7 (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))))) (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))) (.tip (.cover 0 1 2 6)))
private theorem q9Shape10T246OK : fastTreeOK (forms 10) 65556 1998856 q9Shape10T246=true := by decide

private def q9Shape10T240 : Tree := .split 4 q9Shape10T241 q9Shape10T246
private theorem q9Shape10T240OK : fastTreeOK (forms 10) 65540 1998856 q9Shape10T240=true := by
  change (fastTreeOK (forms 10) 65540 (1998856 ||| 2^4) q9Shape10T241 &&
    fastTreeOK (forms 10) (65540 ||| 2^4) 1998856 q9Shape10T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T241OK,q9Shape10T246OK⟩

private def q9Shape10T250 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.split 12 (.split 13 (.split 14 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 1 4 5)))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 4 6 7))) (.tip (.cover 0 1 2 3)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T250OK : fastTreeOK (forms 10) 65548 1999024 q9Shape10T250=true := by decide

private def q9Shape10T251 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 none (some 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 5 6)))) (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 6)))) (.split 9 (.split 10 (.tip (.cover 1 4 5 6)) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T251OK : fastTreeOK (forms 10) 65676 1998896 q9Shape10T251=true := by decide

private def q9Shape10T249 : Tree := .split 7 q9Shape10T250 q9Shape10T251
private theorem q9Shape10T249OK : fastTreeOK (forms 10) 65548 1998896 q9Shape10T249=true := by
  change (fastTreeOK (forms 10) 65548 (1998896 ||| 2^7) q9Shape10T250 &&
    fastTreeOK (forms 10) (65548 ||| 2^7) 1998896 q9Shape10T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T250OK,q9Shape10T251OK⟩

private def q9Shape10T252 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T252OK : fastTreeOK (forms 10) 65580 1998864 q9Shape10T252=true := by decide

private def q9Shape10T248 : Tree := .split 5 q9Shape10T249 q9Shape10T252
private theorem q9Shape10T248OK : fastTreeOK (forms 10) 65548 1998864 q9Shape10T248=true := by
  change (fastTreeOK (forms 10) 65548 (1998864 ||| 2^5) q9Shape10T249 &&
    fastTreeOK (forms 10) (65548 ||| 2^5) 1998864 q9Shape10T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T249OK,q9Shape10T252OK⟩

private def q9Shape10T253 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape10T253OK : fastTreeOK (forms 10) 65564 1998848 q9Shape10T253=true := by decide

private def q9Shape10T247 : Tree := .split 4 q9Shape10T248 q9Shape10T253
private theorem q9Shape10T247OK : fastTreeOK (forms 10) 65548 1998848 q9Shape10T247=true := by
  change (fastTreeOK (forms 10) 65548 (1998848 ||| 2^4) q9Shape10T248 &&
    fastTreeOK (forms 10) (65548 ||| 2^4) 1998848 q9Shape10T253)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T248OK,q9Shape10T253OK⟩

private def q9Shape10T239 : Tree := .split 3 q9Shape10T240 q9Shape10T247
private theorem q9Shape10T239OK : fastTreeOK (forms 10) 65540 1998848 q9Shape10T239=true := by
  change (fastTreeOK (forms 10) 65540 (1998848 ||| 2^3) q9Shape10T240 &&
    fastTreeOK (forms 10) (65540 ||| 2^3) 1998848 q9Shape10T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T240OK,q9Shape10T247OK⟩

private def q9Shape10T205 : Tree := .split 2 q9Shape10T206 q9Shape10T239
private theorem q9Shape10T205OK : fastTreeOK (forms 10) 65536 1998848 q9Shape10T205=true := by
  change (fastTreeOK (forms 10) 65536 (1998848 ||| 2^2) q9Shape10T206 &&
    fastTreeOK (forms 10) (65536 ||| 2^2) 1998848 q9Shape10T239)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T206OK,q9Shape10T239OK⟩

private def q9Shape10T254 : Tree := (.tip (.cover 0 1 5 6))
private theorem q9Shape10T254OK : fastTreeOK (forms 10) 589824 1474560 q9Shape10T254=true := by decide

private def q9Shape10T204 : Tree := .split 19 q9Shape10T205 q9Shape10T254
private theorem q9Shape10T204OK : fastTreeOK (forms 10) 65536 1474560 q9Shape10T204=true := by
  change (fastTreeOK (forms 10) 65536 (1474560 ||| 2^19) q9Shape10T205 &&
    fastTreeOK (forms 10) (65536 ||| 2^19) 1474560 q9Shape10T254)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T205OK,q9Shape10T254OK⟩

private def q9Shape10T255 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape10T255OK : fastTreeOK (forms 10) 327680 1212416 q9Shape10T255=true := by decide

private def q9Shape10T203 : Tree := .split 18 q9Shape10T204 q9Shape10T255
private theorem q9Shape10T203OK : fastTreeOK (forms 10) 65536 1212416 q9Shape10T203=true := by
  change (fastTreeOK (forms 10) 65536 (1212416 ||| 2^18) q9Shape10T204 &&
    fastTreeOK (forms 10) (65536 ||| 2^18) 1212416 q9Shape10T255)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T204OK,q9Shape10T255OK⟩

private def q9Shape10T256 : Tree := (.tip (.cover 0 1 5 6))
private theorem q9Shape10T256OK : fastTreeOK (forms 10) 196608 1081344 q9Shape10T256=true := by decide

private def q9Shape10T202 : Tree := .split 17 q9Shape10T203 q9Shape10T256
private theorem q9Shape10T202OK : fastTreeOK (forms 10) 65536 1081344 q9Shape10T202=true := by
  change (fastTreeOK (forms 10) 65536 (1081344 ||| 2^17) q9Shape10T203 &&
    fastTreeOK (forms 10) (65536 ||| 2^17) 1081344 q9Shape10T256)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T203OK,q9Shape10T256OK⟩

private def q9Shape10T2 : Tree := .split 16 q9Shape10T3 q9Shape10T202
private theorem q9Shape10T2OK : fastTreeOK (forms 10) 0 1081344 q9Shape10T2=true := by
  change (fastTreeOK (forms 10) 0 (1081344 ||| 2^16) q9Shape10T3 &&
    fastTreeOK (forms 10) (0 ||| 2^16) 1081344 q9Shape10T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T3OK,q9Shape10T202OK⟩

private def q9Shape10T266 : Tree := (.split 8 (.tip (.cover 0 1 4 7)) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7))))) (.tip (.cover 0 1 4 7)))) (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 4 7))))) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T266OK : fastTreeOK (forms 10) 1048576 1015996 q9Shape10T266=true := by decide

private def q9Shape10T267 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 1 4 7)))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 7)))
private theorem q9Shape10T267OK : fastTreeOK (forms 10) 1048704 1015868 q9Shape10T267=true := by decide

private def q9Shape10T265 : Tree := .split 7 q9Shape10T266 q9Shape10T267
private theorem q9Shape10T265OK : fastTreeOK (forms 10) 1048576 1015868 q9Shape10T265=true := by
  change (fastTreeOK (forms 10) 1048576 (1015868 ||| 2^7) q9Shape10T266 &&
    fastTreeOK (forms 10) (1048576 ||| 2^7) 1015868 q9Shape10T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T266OK,q9Shape10T267OK⟩

private def q9Shape10T268 : Tree := (.split 7 (.split 8 (.tip (.cover 0 1 4 7)) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 8))) (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 8)))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 8))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 8))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 3 7))))
private theorem q9Shape10T268OK : fastTreeOK (forms 10) 1048608 1015836 q9Shape10T268=true := by decide

private def q9Shape10T264 : Tree := .split 5 q9Shape10T265 q9Shape10T268
private theorem q9Shape10T264OK : fastTreeOK (forms 10) 1048576 1015836 q9Shape10T264=true := by
  change (fastTreeOK (forms 10) 1048576 (1015836 ||| 2^5) q9Shape10T265 &&
    fastTreeOK (forms 10) (1048576 ||| 2^5) 1015836 q9Shape10T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T265OK,q9Shape10T268OK⟩

private def q9Shape10T270 : Tree := (.split 7 (.split 8 (.tip (.cover 0 1 4 7)) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 3 4 7))) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 3 5))))) (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 3 4 7))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 7))))
private theorem q9Shape10T270OK : fastTreeOK (forms 10) 1048592 1015852 q9Shape10T270=true := by decide

private def q9Shape10T271 : Tree := (.split 7 (.split 8 (.tip (.cover 0 1 4 7)) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 3 7))))
private theorem q9Shape10T271OK : fastTreeOK (forms 10) 1048624 1015820 q9Shape10T271=true := by decide

private def q9Shape10T269 : Tree := .split 5 q9Shape10T270 q9Shape10T271
private theorem q9Shape10T269OK : fastTreeOK (forms 10) 1048592 1015820 q9Shape10T269=true := by
  change (fastTreeOK (forms 10) 1048592 (1015820 ||| 2^5) q9Shape10T270 &&
    fastTreeOK (forms 10) (1048592 ||| 2^5) 1015820 q9Shape10T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T270OK,q9Shape10T271OK⟩

private def q9Shape10T263 : Tree := .split 4 q9Shape10T264 q9Shape10T269
private theorem q9Shape10T263OK : fastTreeOK (forms 10) 1048576 1015820 q9Shape10T263=true := by
  change (fastTreeOK (forms 10) 1048576 (1015820 ||| 2^4) q9Shape10T264 &&
    fastTreeOK (forms 10) (1048576 ||| 2^4) 1015820 q9Shape10T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T264OK,q9Shape10T269OK⟩

private def q9Shape10T275 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7))))) (.tip (.cover 0 1 4 7)))) (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 8)))) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 3 5 6))))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7)))) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T275OK : fastTreeOK (forms 10) 1048584 1015988 q9Shape10T275=true := by decide

private def q9Shape10T276 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 1 5 6 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 1 5 6 7))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 3 6 7))) (.tip (.cover 1 5 6 7)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 3 6 8))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 7)))
private theorem q9Shape10T276OK : fastTreeOK (forms 10) 1048712 1015860 q9Shape10T276=true := by decide

private def q9Shape10T274 : Tree := .split 7 q9Shape10T275 q9Shape10T276
private theorem q9Shape10T274OK : fastTreeOK (forms 10) 1048584 1015860 q9Shape10T274=true := by
  change (fastTreeOK (forms 10) 1048584 (1015860 ||| 2^7) q9Shape10T275 &&
    fastTreeOK (forms 10) (1048584 ||| 2^7) 1015860 q9Shape10T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T275OK,q9Shape10T276OK⟩

private def q9Shape10T278 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 4 7)))) (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 8)))) (.tip (.cover 0 2 4 7))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7)))) (.tip (.cover 0 2 4 7))))
private theorem q9Shape10T278OK : fastTreeOK (forms 10) 1048616 1015956 q9Shape10T278=true := by decide

private def q9Shape10T279 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 3 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 2 5 7))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 3 6 7))) (.tip (.cover 0 2 5 7)))) (.tip (.cover 0 1 2 3))) (.tip (.cover 0 1 3 7)))
private theorem q9Shape10T279OK : fastTreeOK (forms 10) 1048744 1015828 q9Shape10T279=true := by decide

private def q9Shape10T277 : Tree := .split 7 q9Shape10T278 q9Shape10T279
private theorem q9Shape10T277OK : fastTreeOK (forms 10) 1048616 1015828 q9Shape10T277=true := by
  change (fastTreeOK (forms 10) 1048616 (1015828 ||| 2^7) q9Shape10T278 &&
    fastTreeOK (forms 10) (1048616 ||| 2^7) 1015828 q9Shape10T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T278OK,q9Shape10T279OK⟩

private def q9Shape10T273 : Tree := .split 5 q9Shape10T274 q9Shape10T277
private theorem q9Shape10T273OK : fastTreeOK (forms 10) 1048584 1015828 q9Shape10T273=true := by
  change (fastTreeOK (forms 10) 1048584 (1015828 ||| 2^5) q9Shape10T274 &&
    fastTreeOK (forms 10) (1048584 ||| 2^5) 1015828 q9Shape10T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T274OK,q9Shape10T277OK⟩

private def q9Shape10T282 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 2 4 8))) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 2 4 8)))) (.split 9 (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 2 4 8))) (.split 10 (.split 11 (.tip (.cover 0 1 6 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape10T282OK : fastTreeOK (forms 10) 1048600 1015972 q9Shape10T282=true := by decide

private def q9Shape10T283 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.tip (.cover 1 5 6 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 1 2 3))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.cover 4 5 6 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 3 6 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 7)))
private theorem q9Shape10T283OK : fastTreeOK (forms 10) 1048728 1015844 q9Shape10T283=true := by decide

private def q9Shape10T281 : Tree := .split 7 q9Shape10T282 q9Shape10T283
private theorem q9Shape10T281OK : fastTreeOK (forms 10) 1048600 1015844 q9Shape10T281=true := by
  change (fastTreeOK (forms 10) 1048600 (1015844 ||| 2^7) q9Shape10T282 &&
    fastTreeOK (forms 10) (1048600 ||| 2^7) 1015844 q9Shape10T283)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T282OK,q9Shape10T283OK⟩

private def q9Shape10T284 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T284OK : fastTreeOK (forms 10) 1048632 1015812 q9Shape10T284=true := by decide

private def q9Shape10T280 : Tree := .split 5 q9Shape10T281 q9Shape10T284
private theorem q9Shape10T280OK : fastTreeOK (forms 10) 1048600 1015812 q9Shape10T280=true := by
  change (fastTreeOK (forms 10) 1048600 (1015812 ||| 2^5) q9Shape10T281 &&
    fastTreeOK (forms 10) (1048600 ||| 2^5) 1015812 q9Shape10T284)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T281OK,q9Shape10T284OK⟩

private def q9Shape10T272 : Tree := .split 4 q9Shape10T273 q9Shape10T280
private theorem q9Shape10T272OK : fastTreeOK (forms 10) 1048584 1015812 q9Shape10T272=true := by
  change (fastTreeOK (forms 10) 1048584 (1015812 ||| 2^4) q9Shape10T273 &&
    fastTreeOK (forms 10) (1048584 ||| 2^4) 1015812 q9Shape10T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T273OK,q9Shape10T280OK⟩

private def q9Shape10T262 : Tree := .split 3 q9Shape10T263 q9Shape10T272
private theorem q9Shape10T262OK : fastTreeOK (forms 10) 1048576 1015812 q9Shape10T262=true := by
  change (fastTreeOK (forms 10) 1048576 (1015812 ||| 2^3) q9Shape10T263 &&
    fastTreeOK (forms 10) (1048576 ||| 2^3) 1015812 q9Shape10T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T263OK,q9Shape10T272OK⟩

private def q9Shape10T290 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 8))) (.tip (.cover 0 1 4 7)))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 4 7)))))
private theorem q9Shape10T290OK : fastTreeOK (forms 10) 1048580 1016248 q9Shape10T290=true := by decide

private def q9Shape10T291 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 1 5 6 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 1 5 6 7))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 3 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 3 5 7)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.tip (.cover 1 5 6 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T291OK : fastTreeOK (forms 10) 1048836 1015992 q9Shape10T291=true := by decide

private def q9Shape10T289 : Tree := .split 8 q9Shape10T290 q9Shape10T291
private theorem q9Shape10T289OK : fastTreeOK (forms 10) 1048580 1015992 q9Shape10T289=true := by
  change (fastTreeOK (forms 10) 1048580 (1015992 ||| 2^8) q9Shape10T290 &&
    fastTreeOK (forms 10) (1048580 ||| 2^8) 1015992 q9Shape10T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T290OK,q9Shape10T291OK⟩

private def q9Shape10T292 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7)))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 7)))
private theorem q9Shape10T292OK : fastTreeOK (forms 10) 1048708 1015864 q9Shape10T292=true := by decide

private def q9Shape10T288 : Tree := .split 7 q9Shape10T289 q9Shape10T292
private theorem q9Shape10T288OK : fastTreeOK (forms 10) 1048580 1015864 q9Shape10T288=true := by
  change (fastTreeOK (forms 10) 1048580 (1015864 ||| 2^7) q9Shape10T289 &&
    fastTreeOK (forms 10) (1048580 ||| 2^7) 1015864 q9Shape10T292)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T289OK,q9Shape10T292OK⟩

private def q9Shape10T294 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 2 4)))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 8))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 2 4 7))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 2 6 7))) (.tip (.cover 1 5 6 7))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T294OK : fastTreeOK (forms 10) 1048612 1015960 q9Shape10T294=true := by decide

private def q9Shape10T295 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 3 7)))
private theorem q9Shape10T295OK : fastTreeOK (forms 10) 1048740 1015832 q9Shape10T295=true := by decide

private def q9Shape10T293 : Tree := .split 7 q9Shape10T294 q9Shape10T295
private theorem q9Shape10T293OK : fastTreeOK (forms 10) 1048612 1015832 q9Shape10T293=true := by
  change (fastTreeOK (forms 10) 1048612 (1015832 ||| 2^7) q9Shape10T294 &&
    fastTreeOK (forms 10) (1048612 ||| 2^7) 1015832 q9Shape10T295)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T294OK,q9Shape10T295OK⟩

private def q9Shape10T287 : Tree := .split 5 q9Shape10T288 q9Shape10T293
private theorem q9Shape10T287OK : fastTreeOK (forms 10) 1048580 1015832 q9Shape10T287=true := by
  change (fastTreeOK (forms 10) 1048580 (1015832 ||| 2^5) q9Shape10T288 &&
    fastTreeOK (forms 10) (1048580 ||| 2^5) 1015832 q9Shape10T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T288OK,q9Shape10T293OK⟩

private def q9Shape10T299 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 2 4 8))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 2 4 8))))
private theorem q9Shape10T299OK : fastTreeOK (forms 10) 1048596 1016232 q9Shape10T299=true := by decide

private def q9Shape10T300 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.drop 6 8 (some 5) (some 7)))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 2 6 8))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 2 3))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) (some 5))) (.tip (.cover 4 5 6 7))) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T300OK : fastTreeOK (forms 10) 1048852 1015976 q9Shape10T300=true := by decide

private def q9Shape10T298 : Tree := .split 8 q9Shape10T299 q9Shape10T300
private theorem q9Shape10T298OK : fastTreeOK (forms 10) 1048596 1015976 q9Shape10T298=true := by
  change (fastTreeOK (forms 10) 1048596 (1015976 ||| 2^8) q9Shape10T299 &&
    fastTreeOK (forms 10) (1048596 ||| 2^8) 1015976 q9Shape10T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T299OK,q9Shape10T300OK⟩

private def q9Shape10T301 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 2 4 8))) (.split 10 (.split 11 (.split 12 (.tip (.cover 0 1 5 7)) (.tip (.cover 1 5 6 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 3 6)))) (.tip (.cover 0 1 3 7)))
private theorem q9Shape10T301OK : fastTreeOK (forms 10) 1048724 1015848 q9Shape10T301=true := by decide

private def q9Shape10T297 : Tree := .split 7 q9Shape10T298 q9Shape10T301
private theorem q9Shape10T297OK : fastTreeOK (forms 10) 1048596 1015848 q9Shape10T297=true := by
  change (fastTreeOK (forms 10) 1048596 (1015848 ||| 2^7) q9Shape10T298 &&
    fastTreeOK (forms 10) (1048596 ||| 2^7) 1015848 q9Shape10T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T298OK,q9Shape10T301OK⟩

private def q9Shape10T302 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape10T302OK : fastTreeOK (forms 10) 1048628 1015816 q9Shape10T302=true := by decide

private def q9Shape10T296 : Tree := .split 5 q9Shape10T297 q9Shape10T302
private theorem q9Shape10T296OK : fastTreeOK (forms 10) 1048596 1015816 q9Shape10T296=true := by
  change (fastTreeOK (forms 10) 1048596 (1015816 ||| 2^5) q9Shape10T297 &&
    fastTreeOK (forms 10) (1048596 ||| 2^5) 1015816 q9Shape10T302)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T297OK,q9Shape10T302OK⟩

private def q9Shape10T286 : Tree := .split 4 q9Shape10T287 q9Shape10T296
private theorem q9Shape10T286OK : fastTreeOK (forms 10) 1048580 1015816 q9Shape10T286=true := by
  change (fastTreeOK (forms 10) 1048580 (1015816 ||| 2^4) q9Shape10T287 &&
    fastTreeOK (forms 10) (1048580 ||| 2^4) 1015816 q9Shape10T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T287OK,q9Shape10T296OK⟩

private def q9Shape10T303 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape10T303OK : fastTreeOK (forms 10) 1048588 1015808 q9Shape10T303=true := by decide

private def q9Shape10T285 : Tree := .split 3 q9Shape10T286 q9Shape10T303
private theorem q9Shape10T285OK : fastTreeOK (forms 10) 1048580 1015808 q9Shape10T285=true := by
  change (fastTreeOK (forms 10) 1048580 (1015808 ||| 2^3) q9Shape10T286 &&
    fastTreeOK (forms 10) (1048580 ||| 2^3) 1015808 q9Shape10T303)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T286OK,q9Shape10T303OK⟩

private def q9Shape10T261 : Tree := .split 2 q9Shape10T262 q9Shape10T285
private theorem q9Shape10T261OK : fastTreeOK (forms 10) 1048576 1015808 q9Shape10T261=true := by
  change (fastTreeOK (forms 10) 1048576 (1015808 ||| 2^2) q9Shape10T262 &&
    fastTreeOK (forms 10) (1048576 ||| 2^2) 1015808 q9Shape10T285)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T262OK,q9Shape10T285OK⟩

private def q9Shape10T304 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape10T304OK : fastTreeOK (forms 10) 1572864 491520 q9Shape10T304=true := by decide

private def q9Shape10T260 : Tree := .split 19 q9Shape10T261 q9Shape10T304
private theorem q9Shape10T260OK : fastTreeOK (forms 10) 1048576 491520 q9Shape10T260=true := by
  change (fastTreeOK (forms 10) 1048576 (491520 ||| 2^19) q9Shape10T261 &&
    fastTreeOK (forms 10) (1048576 ||| 2^19) 491520 q9Shape10T304)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T261OK,q9Shape10T304OK⟩

private def q9Shape10T305 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape10T305OK : fastTreeOK (forms 10) 1310720 229376 q9Shape10T305=true := by decide

private def q9Shape10T259 : Tree := .split 18 q9Shape10T260 q9Shape10T305
private theorem q9Shape10T259OK : fastTreeOK (forms 10) 1048576 229376 q9Shape10T259=true := by
  change (fastTreeOK (forms 10) 1048576 (229376 ||| 2^18) q9Shape10T260 &&
    fastTreeOK (forms 10) (1048576 ||| 2^18) 229376 q9Shape10T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T260OK,q9Shape10T305OK⟩

private def q9Shape10T306 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape10T306OK : fastTreeOK (forms 10) 1179648 98304 q9Shape10T306=true := by decide

private def q9Shape10T258 : Tree := .split 17 q9Shape10T259 q9Shape10T306
private theorem q9Shape10T258OK : fastTreeOK (forms 10) 1048576 98304 q9Shape10T258=true := by
  change (fastTreeOK (forms 10) 1048576 (98304 ||| 2^17) q9Shape10T259 &&
    fastTreeOK (forms 10) (1048576 ||| 2^17) 98304 q9Shape10T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T259OK,q9Shape10T306OK⟩

private def q9Shape10T307 : Tree := (.tip (.cover 0 1 6 7))
private theorem q9Shape10T307OK : fastTreeOK (forms 10) 1114112 32768 q9Shape10T307=true := by decide

private def q9Shape10T257 : Tree := .split 16 q9Shape10T258 q9Shape10T307
private theorem q9Shape10T257OK : fastTreeOK (forms 10) 1048576 32768 q9Shape10T257=true := by
  change (fastTreeOK (forms 10) 1048576 (32768 ||| 2^16) q9Shape10T258 &&
    fastTreeOK (forms 10) (1048576 ||| 2^16) 32768 q9Shape10T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T258OK,q9Shape10T307OK⟩

private def q9Shape10T1 : Tree := .split 20 q9Shape10T2 q9Shape10T257
private theorem q9Shape10T1OK : fastTreeOK (forms 10) 0 32768 q9Shape10T1=true := by
  change (fastTreeOK (forms 10) 0 (32768 ||| 2^20) q9Shape10T2 &&
    fastTreeOK (forms 10) (0 ||| 2^20) 32768 q9Shape10T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T2OK,q9Shape10T257OK⟩

private def q9Shape10T319 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5))))) (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 8))))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5)))) (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T319OK : fastTreeOK (forms 10) 32768 2032060 q9Shape10T319=true := by decide

private def q9Shape10T320 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5)))) (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T320OK : fastTreeOK (forms 10) 33024 2031804 q9Shape10T320=true := by decide

private def q9Shape10T318 : Tree := .split 8 q9Shape10T319 q9Shape10T320
private theorem q9Shape10T318OK : fastTreeOK (forms 10) 32768 2031804 q9Shape10T318=true := by
  change (fastTreeOK (forms 10) 32768 (2031804 ||| 2^8) q9Shape10T319 &&
    fastTreeOK (forms 10) (32768 ||| 2^8) 2031804 q9Shape10T320)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T319OK,q9Shape10T320OK⟩

private def q9Shape10T321 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 3 4))) (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 8))))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 4))) (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 4 7)))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape10T321OK : fastTreeOK (forms 10) 32896 2031676 q9Shape10T321=true := by decide

private def q9Shape10T317 : Tree := .split 7 q9Shape10T318 q9Shape10T321
private theorem q9Shape10T317OK : fastTreeOK (forms 10) 32768 2031676 q9Shape10T317=true := by
  change (fastTreeOK (forms 10) 32768 (2031676 ||| 2^7) q9Shape10T318 &&
    fastTreeOK (forms 10) (32768 ||| 2^7) 2031676 q9Shape10T321)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T318OK,q9Shape10T321OK⟩

private def q9Shape10T324 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5))))) (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 8)))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.drop 6 7 (some 5) (some 5)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T324OK : fastTreeOK (forms 10) 32800 2032028 q9Shape10T324=true := by decide

private def q9Shape10T325 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 4 6))) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T325OK : fastTreeOK (forms 10) 33056 2031772 q9Shape10T325=true := by decide

private def q9Shape10T323 : Tree := .split 8 q9Shape10T324 q9Shape10T325
private theorem q9Shape10T323OK : fastTreeOK (forms 10) 32800 2031772 q9Shape10T323=true := by
  change (fastTreeOK (forms 10) 32800 (2031772 ||| 2^8) q9Shape10T324 &&
    fastTreeOK (forms 10) (32800 ||| 2^8) 2031772 q9Shape10T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T324OK,q9Shape10T325OK⟩

private def q9Shape10T326 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5)))) (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T326OK : fastTreeOK (forms 10) 32928 2031644 q9Shape10T326=true := by decide

private def q9Shape10T322 : Tree := .split 7 q9Shape10T323 q9Shape10T326
private theorem q9Shape10T322OK : fastTreeOK (forms 10) 32800 2031644 q9Shape10T322=true := by
  change (fastTreeOK (forms 10) 32800 (2031644 ||| 2^7) q9Shape10T323 &&
    fastTreeOK (forms 10) (32800 ||| 2^7) 2031644 q9Shape10T326)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T323OK,q9Shape10T326OK⟩

private def q9Shape10T316 : Tree := .split 5 q9Shape10T317 q9Shape10T322
private theorem q9Shape10T316OK : fastTreeOK (forms 10) 32768 2031644 q9Shape10T316=true := by
  change (fastTreeOK (forms 10) 32768 (2031644 ||| 2^5) q9Shape10T317 &&
    fastTreeOK (forms 10) (32768 ||| 2^5) 2031644 q9Shape10T322)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T317OK,q9Shape10T322OK⟩

private def q9Shape10T330 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5)))) (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 4 7)))) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) none)) (.tip (.drop 6 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T330OK : fastTreeOK (forms 10) 32784 2032044 q9Shape10T330=true := by decide

private def q9Shape10T331 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 2 4 6))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T331OK : fastTreeOK (forms 10) 33040 2031788 q9Shape10T331=true := by decide

private def q9Shape10T329 : Tree := .split 8 q9Shape10T330 q9Shape10T331
private theorem q9Shape10T329OK : fastTreeOK (forms 10) 32784 2031788 q9Shape10T329=true := by
  change (fastTreeOK (forms 10) 32784 (2031788 ||| 2^8) q9Shape10T330 &&
    fastTreeOK (forms 10) (32784 ||| 2^8) 2031788 q9Shape10T331)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T330OK,q9Shape10T331OK⟩

private def q9Shape10T333 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T333OK : fastTreeOK (forms 10) 32912 2031916 q9Shape10T333=true := by decide

private def q9Shape10T334 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) none)) (.tip (.drop 6 8 (some 5) (some 7)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape10T334OK : fastTreeOK (forms 10) 33168 2031660 q9Shape10T334=true := by decide

private def q9Shape10T332 : Tree := .split 8 q9Shape10T333 q9Shape10T334
private theorem q9Shape10T332OK : fastTreeOK (forms 10) 32912 2031660 q9Shape10T332=true := by
  change (fastTreeOK (forms 10) 32912 (2031660 ||| 2^8) q9Shape10T333 &&
    fastTreeOK (forms 10) (32912 ||| 2^8) 2031660 q9Shape10T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T333OK,q9Shape10T334OK⟩

private def q9Shape10T328 : Tree := .split 7 q9Shape10T329 q9Shape10T332
private theorem q9Shape10T328OK : fastTreeOK (forms 10) 32784 2031660 q9Shape10T328=true := by
  change (fastTreeOK (forms 10) 32784 (2031660 ||| 2^7) q9Shape10T329 &&
    fastTreeOK (forms 10) (32784 ||| 2^7) 2031660 q9Shape10T332)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T329OK,q9Shape10T332OK⟩

private def q9Shape10T335 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T335OK : fastTreeOK (forms 10) 32816 2031628 q9Shape10T335=true := by decide

private def q9Shape10T327 : Tree := .split 5 q9Shape10T328 q9Shape10T335
private theorem q9Shape10T327OK : fastTreeOK (forms 10) 32784 2031628 q9Shape10T327=true := by
  change (fastTreeOK (forms 10) 32784 (2031628 ||| 2^5) q9Shape10T328 &&
    fastTreeOK (forms 10) (32784 ||| 2^5) 2031628 q9Shape10T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T328OK,q9Shape10T335OK⟩

private def q9Shape10T315 : Tree := .split 4 q9Shape10T316 q9Shape10T327
private theorem q9Shape10T315OK : fastTreeOK (forms 10) 32768 2031628 q9Shape10T315=true := by
  change (fastTreeOK (forms 10) 32768 (2031628 ||| 2^4) q9Shape10T316 &&
    fastTreeOK (forms 10) (32768 ||| 2^4) 2031628 q9Shape10T327)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T316OK,q9Shape10T327OK⟩

private def q9Shape10T340 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 4 6)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 3 4 6))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T340OK : fastTreeOK (forms 10) 32776 2032052 q9Shape10T340=true := by decide

private def q9Shape10T341 : Tree := (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T341OK : fastTreeOK (forms 10) 33032 2031796 q9Shape10T341=true := by decide

private def q9Shape10T339 : Tree := .split 8 q9Shape10T340 q9Shape10T341
private theorem q9Shape10T339OK : fastTreeOK (forms 10) 32776 2031796 q9Shape10T339=true := by
  change (fastTreeOK (forms 10) 32776 (2031796 ||| 2^8) q9Shape10T340 &&
    fastTreeOK (forms 10) (32776 ||| 2^8) 2031796 q9Shape10T341)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T340OK,q9Shape10T341OK⟩

private def q9Shape10T342 : Tree := (.tip (.cover 1 3 4 6))
private theorem q9Shape10T342OK : fastTreeOK (forms 10) 32904 2031668 q9Shape10T342=true := by decide

private def q9Shape10T338 : Tree := .split 7 q9Shape10T339 q9Shape10T342
private theorem q9Shape10T338OK : fastTreeOK (forms 10) 32776 2031668 q9Shape10T338=true := by
  change (fastTreeOK (forms 10) 32776 (2031668 ||| 2^7) q9Shape10T339 &&
    fastTreeOK (forms 10) (32776 ||| 2^7) 2031668 q9Shape10T342)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T339OK,q9Shape10T342OK⟩

private def q9Shape10T345 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5)))) (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 1 4 5))))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 2 4)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T345OK : fastTreeOK (forms 10) 32808 2032020 q9Shape10T345=true := by decide

private def q9Shape10T346 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 4 6 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T346OK : fastTreeOK (forms 10) 33064 2031764 q9Shape10T346=true := by decide

private def q9Shape10T344 : Tree := .split 8 q9Shape10T345 q9Shape10T346
private theorem q9Shape10T344OK : fastTreeOK (forms 10) 32808 2031764 q9Shape10T344=true := by
  change (fastTreeOK (forms 10) 32808 (2031764 ||| 2^8) q9Shape10T345 &&
    fastTreeOK (forms 10) (32808 ||| 2^8) 2031764 q9Shape10T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T345OK,q9Shape10T346OK⟩

private def q9Shape10T347 : Tree := (.split 8 (.split 9 (.tip (.cover 1 2 4 5)) (.tip (.cover 0 1 2 3))) (.split 9 (.tip (.cover 1 2 4 5)) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T347OK : fastTreeOK (forms 10) 32936 2031636 q9Shape10T347=true := by decide

private def q9Shape10T343 : Tree := .split 7 q9Shape10T344 q9Shape10T347
private theorem q9Shape10T343OK : fastTreeOK (forms 10) 32808 2031636 q9Shape10T343=true := by
  change (fastTreeOK (forms 10) 32808 (2031636 ||| 2^7) q9Shape10T344 &&
    fastTreeOK (forms 10) (32808 ||| 2^7) 2031636 q9Shape10T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T344OK,q9Shape10T347OK⟩

private def q9Shape10T337 : Tree := .split 5 q9Shape10T338 q9Shape10T343
private theorem q9Shape10T337OK : fastTreeOK (forms 10) 32776 2031636 q9Shape10T337=true := by
  change (fastTreeOK (forms 10) 32776 (2031636 ||| 2^5) q9Shape10T338 &&
    fastTreeOK (forms 10) (32776 ||| 2^5) 2031636 q9Shape10T343)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T338OK,q9Shape10T343OK⟩

private def q9Shape10T351 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T351OK : fastTreeOK (forms 10) 32792 2032036 q9Shape10T351=true := by decide

private def q9Shape10T352 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) none)) (.tip (.drop 7 8 (some 5) (some 5)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 2 4))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 5) (some 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 4 6 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T352OK : fastTreeOK (forms 10) 33048 2031780 q9Shape10T352=true := by decide

private def q9Shape10T350 : Tree := .split 8 q9Shape10T351 q9Shape10T352
private theorem q9Shape10T350OK : fastTreeOK (forms 10) 32792 2031780 q9Shape10T350=true := by
  change (fastTreeOK (forms 10) 32792 (2031780 ||| 2^8) q9Shape10T351 &&
    fastTreeOK (forms 10) (32792 ||| 2^8) 2031780 q9Shape10T352)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T351OK,q9Shape10T352OK⟩

private def q9Shape10T353 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 1 2 4 5)) (.tip (.cover 0 1 2 3))) (.tip (.cover 1 3 4 6))) (.split 9 (.split 10 (.tip (.cover 1 2 4 5)) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T353OK : fastTreeOK (forms 10) 32920 2031652 q9Shape10T353=true := by decide

private def q9Shape10T349 : Tree := .split 7 q9Shape10T350 q9Shape10T353
private theorem q9Shape10T349OK : fastTreeOK (forms 10) 32792 2031652 q9Shape10T349=true := by
  change (fastTreeOK (forms 10) 32792 (2031652 ||| 2^7) q9Shape10T350 &&
    fastTreeOK (forms 10) (32792 ||| 2^7) 2031652 q9Shape10T353)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T350OK,q9Shape10T353OK⟩

private def q9Shape10T354 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T354OK : fastTreeOK (forms 10) 32824 2031620 q9Shape10T354=true := by decide

private def q9Shape10T348 : Tree := .split 5 q9Shape10T349 q9Shape10T354
private theorem q9Shape10T348OK : fastTreeOK (forms 10) 32792 2031620 q9Shape10T348=true := by
  change (fastTreeOK (forms 10) 32792 (2031620 ||| 2^5) q9Shape10T349 &&
    fastTreeOK (forms 10) (32792 ||| 2^5) 2031620 q9Shape10T354)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T349OK,q9Shape10T354OK⟩

private def q9Shape10T336 : Tree := .split 4 q9Shape10T337 q9Shape10T348
private theorem q9Shape10T336OK : fastTreeOK (forms 10) 32776 2031620 q9Shape10T336=true := by
  change (fastTreeOK (forms 10) 32776 (2031620 ||| 2^4) q9Shape10T337 &&
    fastTreeOK (forms 10) (32776 ||| 2^4) 2031620 q9Shape10T348)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T337OK,q9Shape10T348OK⟩

private def q9Shape10T314 : Tree := .split 3 q9Shape10T315 q9Shape10T336
private theorem q9Shape10T314OK : fastTreeOK (forms 10) 32768 2031620 q9Shape10T314=true := by
  change (fastTreeOK (forms 10) 32768 (2031620 ||| 2^3) q9Shape10T315 &&
    fastTreeOK (forms 10) (32768 ||| 2^3) 2031620 q9Shape10T336)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T315OK,q9Shape10T336OK⟩

private def q9Shape10T359 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 1 3 4 5))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 1 3 4 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 1 3 4 5)))
private theorem q9Shape10T359OK : fastTreeOK (forms 10) 32772 2031800 q9Shape10T359=true := by decide

private def q9Shape10T360 : Tree := (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 4))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape10T360OK : fastTreeOK (forms 10) 32900 2031672 q9Shape10T360=true := by decide

private def q9Shape10T358 : Tree := .split 7 q9Shape10T359 q9Shape10T360
private theorem q9Shape10T358OK : fastTreeOK (forms 10) 32772 2031672 q9Shape10T358=true := by
  change (fastTreeOK (forms 10) 32772 (2031672 ||| 2^7) q9Shape10T359 &&
    fastTreeOK (forms 10) (32772 ||| 2^7) 2031672 q9Shape10T360)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T359OK,q9Shape10T360OK⟩

private def q9Shape10T362 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 2 4))) (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 1 4 8)))) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5)))) (.split 9 (.tip (.cover 1 2 4 6)) (.tip (.cover 0 1 2 3))))
private theorem q9Shape10T362OK : fastTreeOK (forms 10) 32804 2031768 q9Shape10T362=true := by decide

private def q9Shape10T363 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 5 7 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5)))) (.split 9 (.tip (.cover 1 2 4 6)) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T363OK : fastTreeOK (forms 10) 32932 2031640 q9Shape10T363=true := by decide

private def q9Shape10T361 : Tree := .split 7 q9Shape10T362 q9Shape10T363
private theorem q9Shape10T361OK : fastTreeOK (forms 10) 32804 2031640 q9Shape10T361=true := by
  change (fastTreeOK (forms 10) 32804 (2031640 ||| 2^7) q9Shape10T362 &&
    fastTreeOK (forms 10) (32804 ||| 2^7) 2031640 q9Shape10T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T362OK,q9Shape10T363OK⟩

private def q9Shape10T357 : Tree := .split 5 q9Shape10T358 q9Shape10T361
private theorem q9Shape10T357OK : fastTreeOK (forms 10) 32772 2031640 q9Shape10T357=true := by
  change (fastTreeOK (forms 10) 32772 (2031640 ||| 2^5) q9Shape10T358 &&
    fastTreeOK (forms 10) (32772 ||| 2^5) 2031640 q9Shape10T361)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T358OK,q9Shape10T361OK⟩

private def q9Shape10T367 : Tree := (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 2 4))) (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 4 7)))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape10T367OK : fastTreeOK (forms 10) 32788 2032040 q9Shape10T367=true := by decide

private def q9Shape10T368 : Tree := (.split 9 (.split 10 (.tip (.cover 1 2 4 6)) (.tip (.cover 0 1 2 3))) (.tip (.cover 1 3 4 5)))
private theorem q9Shape10T368OK : fastTreeOK (forms 10) 33044 2031784 q9Shape10T368=true := by decide

private def q9Shape10T366 : Tree := .split 8 q9Shape10T367 q9Shape10T368
private theorem q9Shape10T366OK : fastTreeOK (forms 10) 32788 2031784 q9Shape10T366=true := by
  change (fastTreeOK (forms 10) 32788 (2031784 ||| 2^8) q9Shape10T367 &&
    fastTreeOK (forms 10) (32788 ||| 2^8) 2031784 q9Shape10T368)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T367OK,q9Shape10T368OK⟩

private def q9Shape10T369 : Tree := (.split 8 (.split 9 (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 4 5))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5)))) (.split 9 (.split 10 (.tip (.cover 1 2 4 6)) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape10T369OK : fastTreeOK (forms 10) 32916 2031656 q9Shape10T369=true := by decide

private def q9Shape10T365 : Tree := .split 7 q9Shape10T366 q9Shape10T369
private theorem q9Shape10T365OK : fastTreeOK (forms 10) 32788 2031656 q9Shape10T365=true := by
  change (fastTreeOK (forms 10) 32788 (2031656 ||| 2^7) q9Shape10T366 &&
    fastTreeOK (forms 10) (32788 ||| 2^7) 2031656 q9Shape10T369)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T366OK,q9Shape10T369OK⟩

private def q9Shape10T370 : Tree := (.tip (.cover 0 1 2 5))
private theorem q9Shape10T370OK : fastTreeOK (forms 10) 32820 2031624 q9Shape10T370=true := by decide

private def q9Shape10T364 : Tree := .split 5 q9Shape10T365 q9Shape10T370
private theorem q9Shape10T364OK : fastTreeOK (forms 10) 32788 2031624 q9Shape10T364=true := by
  change (fastTreeOK (forms 10) 32788 (2031624 ||| 2^5) q9Shape10T365 &&
    fastTreeOK (forms 10) (32788 ||| 2^5) 2031624 q9Shape10T370)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T365OK,q9Shape10T370OK⟩

private def q9Shape10T356 : Tree := .split 4 q9Shape10T357 q9Shape10T364
private theorem q9Shape10T356OK : fastTreeOK (forms 10) 32772 2031624 q9Shape10T356=true := by
  change (fastTreeOK (forms 10) 32772 (2031624 ||| 2^4) q9Shape10T357 &&
    fastTreeOK (forms 10) (32772 ||| 2^4) 2031624 q9Shape10T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T357OK,q9Shape10T364OK⟩

private def q9Shape10T371 : Tree := (.split 4 (.split 5 (.split 7 (.split 8 (.split 9 (.split 10 (.tip (.cover 0 1 4 5)) (.split 11 (.split 12 (.split 13 (.tip (.drop 6 7 (some 5) none)) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 11 (.split 12 (.split 13 (.split 14 (.tip (.drop 6 8 (some 5) none)) (.tip (.drop 6 8 (some 5) (some 7)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 1 3 4 5))) (.tip (.cover 1 3 4 6))) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape10T371OK : fastTreeOK (forms 10) 32780 2031616 q9Shape10T371=true := by decide

private def q9Shape10T355 : Tree := .split 3 q9Shape10T356 q9Shape10T371
private theorem q9Shape10T355OK : fastTreeOK (forms 10) 32772 2031616 q9Shape10T355=true := by
  change (fastTreeOK (forms 10) 32772 (2031616 ||| 2^3) q9Shape10T356 &&
    fastTreeOK (forms 10) (32772 ||| 2^3) 2031616 q9Shape10T371)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T356OK,q9Shape10T371OK⟩

private def q9Shape10T313 : Tree := .split 2 q9Shape10T314 q9Shape10T355
private theorem q9Shape10T313OK : fastTreeOK (forms 10) 32768 2031616 q9Shape10T313=true := by
  change (fastTreeOK (forms 10) 32768 (2031616 ||| 2^2) q9Shape10T314 &&
    fastTreeOK (forms 10) (32768 ||| 2^2) 2031616 q9Shape10T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T314OK,q9Shape10T355OK⟩

private def q9Shape10T372 : Tree := (.tip (.cover 0 1 6 7))
private theorem q9Shape10T372OK : fastTreeOK (forms 10) 557056 1507328 q9Shape10T372=true := by decide

private def q9Shape10T312 : Tree := .split 19 q9Shape10T313 q9Shape10T372
private theorem q9Shape10T312OK : fastTreeOK (forms 10) 32768 1507328 q9Shape10T312=true := by
  change (fastTreeOK (forms 10) 32768 (1507328 ||| 2^19) q9Shape10T313 &&
    fastTreeOK (forms 10) (32768 ||| 2^19) 1507328 q9Shape10T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T313OK,q9Shape10T372OK⟩

private def q9Shape10T373 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape10T373OK : fastTreeOK (forms 10) 294912 1245184 q9Shape10T373=true := by decide

private def q9Shape10T311 : Tree := .split 18 q9Shape10T312 q9Shape10T373
private theorem q9Shape10T311OK : fastTreeOK (forms 10) 32768 1245184 q9Shape10T311=true := by
  change (fastTreeOK (forms 10) 32768 (1245184 ||| 2^18) q9Shape10T312 &&
    fastTreeOK (forms 10) (32768 ||| 2^18) 1245184 q9Shape10T373)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T312OK,q9Shape10T373OK⟩

private def q9Shape10T374 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape10T374OK : fastTreeOK (forms 10) 163840 1114112 q9Shape10T374=true := by decide

private def q9Shape10T310 : Tree := .split 17 q9Shape10T311 q9Shape10T374
private theorem q9Shape10T310OK : fastTreeOK (forms 10) 32768 1114112 q9Shape10T310=true := by
  change (fastTreeOK (forms 10) 32768 (1114112 ||| 2^17) q9Shape10T311 &&
    fastTreeOK (forms 10) (32768 ||| 2^17) 1114112 q9Shape10T374)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T311OK,q9Shape10T374OK⟩

private def q9Shape10T375 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape10T375OK : fastTreeOK (forms 10) 98304 1048576 q9Shape10T375=true := by decide

private def q9Shape10T309 : Tree := .split 16 q9Shape10T310 q9Shape10T375
private theorem q9Shape10T309OK : fastTreeOK (forms 10) 32768 1048576 q9Shape10T309=true := by
  change (fastTreeOK (forms 10) 32768 (1048576 ||| 2^16) q9Shape10T310 &&
    fastTreeOK (forms 10) (32768 ||| 2^16) 1048576 q9Shape10T375)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T310OK,q9Shape10T375OK⟩

private def q9Shape10T376 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape10T376OK : fastTreeOK (forms 10) 1081344 0 q9Shape10T376=true := by decide

private def q9Shape10T308 : Tree := .split 20 q9Shape10T309 q9Shape10T376
private theorem q9Shape10T308OK : fastTreeOK (forms 10) 32768 0 q9Shape10T308=true := by
  change (fastTreeOK (forms 10) 32768 (0 ||| 2^20) q9Shape10T309 &&
    fastTreeOK (forms 10) (32768 ||| 2^20) 0 q9Shape10T376)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T309OK,q9Shape10T376OK⟩

private def q9Shape10T0 : Tree := .split 15 q9Shape10T1 q9Shape10T308
private theorem q9Shape10T0OK : fastTreeOK (forms 10) 0 0 q9Shape10T0=true := by
  change (fastTreeOK (forms 10) 0 (0 ||| 2^15) q9Shape10T1 &&
    fastTreeOK (forms 10) (0 ||| 2^15) 0 q9Shape10T308)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape10T1OK,q9Shape10T308OK⟩


theorem q9Shape10_cover (b : Nat→Bool) (H : Ranked (adj (forms 10) b)) :
    ∃ u v w z,Effective (adj (forms 10) b) (adj (forms 10) b) u v w z :=
  checked_fastTree (forms 10) b H q9Shape10T0 q9Shape10T0OK

#print axioms q9Shape10_cover
end Graffiti384b.Q9
