import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape11T9 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape11T9OK : treeOK (forms 11) 0 1848088 q9Shape11T9=true := by decide

private def q9Shape11T11 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape11T11OK : treeOK (forms 11) 8192 1872664 q9Shape11T11=true := by decide

private def q9Shape11T14 : Tree := (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 5 7))) (.tip (.cover 1 4 6 8))) (.tip (.cover 0 3 5 7)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 5 7 8))) (.tip (.cover 1 3 4 6))) (.tip (.cover 1 3 4 6))) (.tip (.cover 0 1 4 5)))))
private theorem q9Shape11T14OK : treeOK (forms 11) 40960 1905464 q9Shape11T14=true := by decide

private def q9Shape11T15 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 5 7)))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 4 6))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape11T15OK : treeOK (forms 11) 40992 1905432 q9Shape11T15=true := by decide

private def q9Shape11T13 : Tree := .split 5 q9Shape11T14 q9Shape11T15
private theorem q9Shape11T13OK : treeOK (forms 11) 40960 1905432 q9Shape11T13=true := by
  change (treeOK (forms 11) 40960 (1905432 ||| 2^5) q9Shape11T14 &&
    treeOK (forms 11) (40960 ||| 2^5) 1905432 q9Shape11T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T14OK,q9Shape11T15OK⟩

private def q9Shape11T16 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape11T16OK : treeOK (forms 11) 106496 1839896 q9Shape11T16=true := by decide

private def q9Shape11T12 : Tree := .split 16 q9Shape11T13 q9Shape11T16
private theorem q9Shape11T12OK : treeOK (forms 11) 40960 1839896 q9Shape11T12=true := by
  change (treeOK (forms 11) 40960 (1839896 ||| 2^16) q9Shape11T13 &&
    treeOK (forms 11) (40960 ||| 2^16) 1839896 q9Shape11T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T13OK,q9Shape11T16OK⟩

private def q9Shape11T10 : Tree := .split 15 q9Shape11T11 q9Shape11T12
private theorem q9Shape11T10OK : treeOK (forms 11) 8192 1839896 q9Shape11T10=true := by
  change (treeOK (forms 11) 8192 (1839896 ||| 2^15) q9Shape11T11 &&
    treeOK (forms 11) (8192 ||| 2^15) 1839896 q9Shape11T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T11OK,q9Shape11T12OK⟩

private def q9Shape11T8 : Tree := .split 13 q9Shape11T9 q9Shape11T10
private theorem q9Shape11T8OK : treeOK (forms 11) 0 1839896 q9Shape11T8=true := by
  change (treeOK (forms 11) 0 (1839896 ||| 2^13) q9Shape11T9 &&
    treeOK (forms 11) (0 ||| 2^13) 1839896 q9Shape11T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T9OK,q9Shape11T10OK⟩

private def q9Shape11T20 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape11T20OK : treeOK (forms 11) 4096 1942296 q9Shape11T20=true := by decide

private def q9Shape11T22 : Tree := (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 1 3 5 6)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 1 5 6 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 4 5)))))
private theorem q9Shape11T22OK : treeOK (forms 11) 69632 1876792 q9Shape11T22=true := by decide

private def q9Shape11T23 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 1 2 5 6)))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 4 7 8)))
private theorem q9Shape11T23OK : treeOK (forms 11) 69664 1876760 q9Shape11T23=true := by decide

private def q9Shape11T21 : Tree := .split 5 q9Shape11T22 q9Shape11T23
private theorem q9Shape11T21OK : treeOK (forms 11) 69632 1876760 q9Shape11T21=true := by
  change (treeOK (forms 11) 69632 (1876760 ||| 2^5) q9Shape11T22 &&
    treeOK (forms 11) (69632 ||| 2^5) 1876760 q9Shape11T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T22OK,q9Shape11T23OK⟩

private def q9Shape11T19 : Tree := .split 16 q9Shape11T20 q9Shape11T21
private theorem q9Shape11T19OK : treeOK (forms 11) 4096 1876760 q9Shape11T19=true := by
  change (treeOK (forms 11) 4096 (1876760 ||| 2^16) q9Shape11T20 &&
    treeOK (forms 11) (4096 ||| 2^16) 1876760 q9Shape11T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T20OK,q9Shape11T21OK⟩

private def q9Shape11T24 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape11T24OK : treeOK (forms 11) 36864 1843992 q9Shape11T24=true := by decide

private def q9Shape11T18 : Tree := .split 15 q9Shape11T19 q9Shape11T24
private theorem q9Shape11T18OK : treeOK (forms 11) 4096 1843992 q9Shape11T18=true := by
  change (treeOK (forms 11) 4096 (1843992 ||| 2^15) q9Shape11T19 &&
    treeOK (forms 11) (4096 ||| 2^15) 1843992 q9Shape11T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T19OK,q9Shape11T24OK⟩

private def q9Shape11T25 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape11T25OK : treeOK (forms 11) 12288 1835800 q9Shape11T25=true := by decide

private def q9Shape11T17 : Tree := .split 13 q9Shape11T18 q9Shape11T25
private theorem q9Shape11T17OK : treeOK (forms 11) 4096 1835800 q9Shape11T17=true := by
  change (treeOK (forms 11) 4096 (1835800 ||| 2^13) q9Shape11T18 &&
    treeOK (forms 11) (4096 ||| 2^13) 1835800 q9Shape11T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T18OK,q9Shape11T25OK⟩

private def q9Shape11T7 : Tree := .split 12 q9Shape11T8 q9Shape11T17
private theorem q9Shape11T7OK : treeOK (forms 11) 0 1835800 q9Shape11T7=true := by
  change (treeOK (forms 11) 0 (1835800 ||| 2^12) q9Shape11T8 &&
    treeOK (forms 11) (0 ||| 2^12) 1835800 q9Shape11T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T8OK,q9Shape11T17OK⟩

private def q9Shape11T29 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape11T29OK : treeOK (forms 11) 512 1880344 q9Shape11T29=true := by decide

private def q9Shape11T32 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.tip (.cover 1 3 6 8))))) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 5 7 8))) (.tip (.cover 1 3 4 6))) (.tip (.cover 1 3 4 6))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape11T32OK : treeOK (forms 11) 33280 1913144 q9Shape11T32=true := by decide

private def q9Shape11T33 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 5 7))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 5 7))))) (.tip (.cover 0 5 7 8))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 5 7 8))))
private theorem q9Shape11T33OK : treeOK (forms 11) 33312 1913112 q9Shape11T33=true := by decide

private def q9Shape11T31 : Tree := .split 5 q9Shape11T32 q9Shape11T33
private theorem q9Shape11T31OK : treeOK (forms 11) 33280 1913112 q9Shape11T31=true := by
  change (treeOK (forms 11) 33280 (1913112 ||| 2^5) q9Shape11T32 &&
    treeOK (forms 11) (33280 ||| 2^5) 1913112 q9Shape11T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T32OK,q9Shape11T33OK⟩

private def q9Shape11T34 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape11T34OK : treeOK (forms 11) 98816 1847576 q9Shape11T34=true := by decide

private def q9Shape11T30 : Tree := .split 16 q9Shape11T31 q9Shape11T34
private theorem q9Shape11T30OK : treeOK (forms 11) 33280 1847576 q9Shape11T30=true := by
  change (treeOK (forms 11) 33280 (1847576 ||| 2^16) q9Shape11T31 &&
    treeOK (forms 11) (33280 ||| 2^16) 1847576 q9Shape11T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T31OK,q9Shape11T34OK⟩

private def q9Shape11T28 : Tree := .split 15 q9Shape11T29 q9Shape11T30
private theorem q9Shape11T28OK : treeOK (forms 11) 512 1847576 q9Shape11T28=true := by
  change (treeOK (forms 11) 512 (1847576 ||| 2^15) q9Shape11T29 &&
    treeOK (forms 11) (512 ||| 2^15) 1847576 q9Shape11T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T29OK,q9Shape11T30OK⟩

private def q9Shape11T35 : Tree := (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 6 8 (some 2) none)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5))))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape11T35OK : treeOK (forms 11) 8704 1839384 q9Shape11T35=true := by decide

private def q9Shape11T27 : Tree := .split 13 q9Shape11T28 q9Shape11T35
private theorem q9Shape11T27OK : treeOK (forms 11) 512 1839384 q9Shape11T27=true := by
  change (treeOK (forms 11) 512 (1839384 ||| 2^13) q9Shape11T28 &&
    treeOK (forms 11) (512 ||| 2^13) 1839384 q9Shape11T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T28OK,q9Shape11T35OK⟩

private def q9Shape11T40 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.tip (.cover 1 3 6 8))))) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 1 3 5 6)))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape11T40OK : treeOK (forms 11) 4608 1941816 q9Shape11T40=true := by decide

private def q9Shape11T41 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 4 7 8))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 4 7 8)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape11T41OK : treeOK (forms 11) 4640 1941784 q9Shape11T41=true := by decide

private def q9Shape11T39 : Tree := .split 5 q9Shape11T40 q9Shape11T41
private theorem q9Shape11T39OK : treeOK (forms 11) 4608 1941784 q9Shape11T39=true := by
  change (treeOK (forms 11) 4608 (1941784 ||| 2^5) q9Shape11T40 &&
    treeOK (forms 11) (4608 ||| 2^5) 1941784 q9Shape11T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T40OK,q9Shape11T41OK⟩

private def q9Shape11T42 : Tree := (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 4 7 8)))
private theorem q9Shape11T42OK : treeOK (forms 11) 70144 1876248 q9Shape11T42=true := by decide

private def q9Shape11T38 : Tree := .split 16 q9Shape11T39 q9Shape11T42
private theorem q9Shape11T38OK : treeOK (forms 11) 4608 1876248 q9Shape11T38=true := by
  change (treeOK (forms 11) 4608 (1876248 ||| 2^16) q9Shape11T39 &&
    treeOK (forms 11) (4608 ||| 2^16) 1876248 q9Shape11T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T39OK,q9Shape11T42OK⟩

private def q9Shape11T43 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.tip (.cover 2 4 5 7))))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape11T43OK : treeOK (forms 11) 37376 1843480 q9Shape11T43=true := by decide

private def q9Shape11T37 : Tree := .split 15 q9Shape11T38 q9Shape11T43
private theorem q9Shape11T37OK : treeOK (forms 11) 4608 1843480 q9Shape11T37=true := by
  change (treeOK (forms 11) 4608 (1843480 ||| 2^15) q9Shape11T38 &&
    treeOK (forms 11) (4608 ||| 2^15) 1843480 q9Shape11T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T38OK,q9Shape11T43OK⟩

private def q9Shape11T44 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape11T44OK : treeOK (forms 11) 12800 1835288 q9Shape11T44=true := by decide

private def q9Shape11T36 : Tree := .split 13 q9Shape11T37 q9Shape11T44
private theorem q9Shape11T36OK : treeOK (forms 11) 4608 1835288 q9Shape11T36=true := by
  change (treeOK (forms 11) 4608 (1835288 ||| 2^13) q9Shape11T37 &&
    treeOK (forms 11) (4608 ||| 2^13) 1835288 q9Shape11T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T37OK,q9Shape11T44OK⟩

private def q9Shape11T26 : Tree := .split 12 q9Shape11T27 q9Shape11T36
private theorem q9Shape11T26OK : treeOK (forms 11) 512 1835288 q9Shape11T26=true := by
  change (treeOK (forms 11) 512 (1835288 ||| 2^12) q9Shape11T27 &&
    treeOK (forms 11) (512 ||| 2^12) 1835288 q9Shape11T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T27OK,q9Shape11T36OK⟩

private def q9Shape11T6 : Tree := .split 9 q9Shape11T7 q9Shape11T26
private theorem q9Shape11T6OK : treeOK (forms 11) 0 1835288 q9Shape11T6=true := by
  change (treeOK (forms 11) 0 (1835288 ||| 2^9) q9Shape11T7 &&
    treeOK (forms 11) (0 ||| 2^9) 1835288 q9Shape11T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T7OK,q9Shape11T26OK⟩

private def q9Shape11T50 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape11T50OK : treeOK (forms 11) 256 1946136 q9Shape11T50=true := by decide

private def q9Shape11T52 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))) (.tip (.cover 0 3 7 8))))) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 1 5 6 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape11T52OK : treeOK (forms 11) 65792 1880632 q9Shape11T52=true := by decide

private def q9Shape11T53 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 5 6))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 5 6))))) (.tip (.cover 0 3 7 8))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape11T53OK : treeOK (forms 11) 65824 1880600 q9Shape11T53=true := by decide

private def q9Shape11T51 : Tree := .split 5 q9Shape11T52 q9Shape11T53
private theorem q9Shape11T51OK : treeOK (forms 11) 65792 1880600 q9Shape11T51=true := by
  change (treeOK (forms 11) 65792 (1880600 ||| 2^5) q9Shape11T52 &&
    treeOK (forms 11) (65792 ||| 2^5) 1880600 q9Shape11T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T52OK,q9Shape11T53OK⟩

private def q9Shape11T49 : Tree := .split 16 q9Shape11T50 q9Shape11T51
private theorem q9Shape11T49OK : treeOK (forms 11) 256 1880600 q9Shape11T49=true := by
  change (treeOK (forms 11) 256 (1880600 ||| 2^16) q9Shape11T50 &&
    treeOK (forms 11) (256 ||| 2^16) 1880600 q9Shape11T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T50OK,q9Shape11T51OK⟩

private def q9Shape11T54 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape11T54OK : treeOK (forms 11) 33024 1847832 q9Shape11T54=true := by decide

private def q9Shape11T48 : Tree := .split 15 q9Shape11T49 q9Shape11T54
private theorem q9Shape11T48OK : treeOK (forms 11) 256 1847832 q9Shape11T48=true := by
  change (treeOK (forms 11) 256 (1847832 ||| 2^15) q9Shape11T49 &&
    treeOK (forms 11) (256 ||| 2^15) 1847832 q9Shape11T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T49OK,q9Shape11T54OK⟩

private def q9Shape11T58 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))) (.tip (.cover 0 3 7 8))))) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 5 7))) (.tip (.cover 1 4 6 8))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape11T58OK : treeOK (forms 11) 8448 1937976 q9Shape11T58=true := by decide

private def q9Shape11T59 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 3 7 8))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 3 7 8)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape11T59OK : treeOK (forms 11) 8480 1937944 q9Shape11T59=true := by decide

private def q9Shape11T57 : Tree := .split 5 q9Shape11T58 q9Shape11T59
private theorem q9Shape11T57OK : treeOK (forms 11) 8448 1937944 q9Shape11T57=true := by
  change (treeOK (forms 11) 8448 (1937944 ||| 2^5) q9Shape11T58 &&
    treeOK (forms 11) (8448 ||| 2^5) 1937944 q9Shape11T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T58OK,q9Shape11T59OK⟩

private def q9Shape11T60 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.split 17 (.tip (.cover 0 1 4 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 3 7 8)))
private theorem q9Shape11T60OK : treeOK (forms 11) 73984 1872408 q9Shape11T60=true := by decide

private def q9Shape11T56 : Tree := .split 16 q9Shape11T57 q9Shape11T60
private theorem q9Shape11T56OK : treeOK (forms 11) 8448 1872408 q9Shape11T56=true := by
  change (treeOK (forms 11) 8448 (1872408 ||| 2^16) q9Shape11T57 &&
    treeOK (forms 11) (8448 ||| 2^16) 1872408 q9Shape11T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T57OK,q9Shape11T60OK⟩

private def q9Shape11T61 : Tree := (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 2) (some 2)))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 3 5 7))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape11T61OK : treeOK (forms 11) 41216 1839640 q9Shape11T61=true := by decide

private def q9Shape11T55 : Tree := .split 15 q9Shape11T56 q9Shape11T61
private theorem q9Shape11T55OK : treeOK (forms 11) 8448 1839640 q9Shape11T55=true := by
  change (treeOK (forms 11) 8448 (1839640 ||| 2^15) q9Shape11T56 &&
    treeOK (forms 11) (8448 ||| 2^15) 1839640 q9Shape11T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T56OK,q9Shape11T61OK⟩

private def q9Shape11T47 : Tree := .split 13 q9Shape11T48 q9Shape11T55
private theorem q9Shape11T47OK : treeOK (forms 11) 256 1839640 q9Shape11T47=true := by
  change (treeOK (forms 11) 256 (1839640 ||| 2^13) q9Shape11T48 &&
    treeOK (forms 11) (256 ||| 2^13) 1839640 q9Shape11T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T48OK,q9Shape11T55OK⟩

private def q9Shape11T62 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 2) none)) (.tip (.drop 7 8 (some 2) (some 2)))) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 3 5))))) (.tip (.cover 0 6 7 8)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape11T62OK : treeOK (forms 11) 4352 1835544 q9Shape11T62=true := by decide

private def q9Shape11T46 : Tree := .split 12 q9Shape11T47 q9Shape11T62
private theorem q9Shape11T46OK : treeOK (forms 11) 256 1835544 q9Shape11T46=true := by
  change (treeOK (forms 11) 256 (1835544 ||| 2^12) q9Shape11T47 &&
    treeOK (forms 11) (256 ||| 2^12) 1835544 q9Shape11T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T47OK,q9Shape11T62OK⟩

private def q9Shape11T63 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape11T63OK : treeOK (forms 11) 768 1835032 q9Shape11T63=true := by decide

private def q9Shape11T45 : Tree := .split 9 q9Shape11T46 q9Shape11T63
private theorem q9Shape11T45OK : treeOK (forms 11) 256 1835032 q9Shape11T45=true := by
  change (treeOK (forms 11) 256 (1835032 ||| 2^9) q9Shape11T46 &&
    treeOK (forms 11) (256 ||| 2^9) 1835032 q9Shape11T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T46OK,q9Shape11T63OK⟩

private def q9Shape11T5 : Tree := .split 8 q9Shape11T6 q9Shape11T45
private theorem q9Shape11T5OK : treeOK (forms 11) 0 1835032 q9Shape11T5=true := by
  change (treeOK (forms 11) 0 (1835032 ||| 2^8) q9Shape11T6 &&
    treeOK (forms 11) (0 ||| 2^8) 1835032 q9Shape11T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T6OK,q9Shape11T45OK⟩

private def q9Shape11T69 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape11T69OK : treeOK (forms 11) 16 1880840 q9Shape11T69=true := by decide

private def q9Shape11T73 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7)))) (.split 2 (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))))) (.tip (.cover 1 2 6 8)))))
private theorem q9Shape11T73OK : treeOK (forms 11) 32784 1914664 q9Shape11T73=true := by decide

private def q9Shape11T74 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 5 7))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 1 2 6 8))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 5 7))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 1 2 6 8))))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape11T74OK : treeOK (forms 11) 33808 1913640 q9Shape11T74=true := by decide

private def q9Shape11T72 : Tree := .split 10 q9Shape11T73 q9Shape11T74
private theorem q9Shape11T72OK : treeOK (forms 11) 32784 1913640 q9Shape11T72=true := by
  change (treeOK (forms 11) 32784 (1913640 ||| 2^10) q9Shape11T73 &&
    treeOK (forms 11) (32784 ||| 2^10) 1913640 q9Shape11T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T73OK,q9Shape11T74OK⟩

private def q9Shape11T75 : Tree := (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 4 6))) (.tip (.cover 0 1 2 5)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 5 7 8))))
private theorem q9Shape11T75OK : treeOK (forms 11) 32816 1913608 q9Shape11T75=true := by decide

private def q9Shape11T71 : Tree := .split 5 q9Shape11T72 q9Shape11T75
private theorem q9Shape11T71OK : treeOK (forms 11) 32784 1913608 q9Shape11T71=true := by
  change (treeOK (forms 11) 32784 (1913608 ||| 2^5) q9Shape11T72 &&
    treeOK (forms 11) (32784 ||| 2^5) 1913608 q9Shape11T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T72OK,q9Shape11T75OK⟩

private def q9Shape11T76 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape11T76OK : treeOK (forms 11) 98320 1848072 q9Shape11T76=true := by decide

private def q9Shape11T70 : Tree := .split 16 q9Shape11T71 q9Shape11T76
private theorem q9Shape11T70OK : treeOK (forms 11) 32784 1848072 q9Shape11T70=true := by
  change (treeOK (forms 11) 32784 (1848072 ||| 2^16) q9Shape11T71 &&
    treeOK (forms 11) (32784 ||| 2^16) 1848072 q9Shape11T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T71OK,q9Shape11T76OK⟩

private def q9Shape11T68 : Tree := .split 15 q9Shape11T69 q9Shape11T70
private theorem q9Shape11T68OK : treeOK (forms 11) 16 1848072 q9Shape11T68=true := by
  change (treeOK (forms 11) 16 (1848072 ||| 2^15) q9Shape11T69 &&
    treeOK (forms 11) (16 ||| 2^15) 1848072 q9Shape11T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T69OK,q9Shape11T70OK⟩

private def q9Shape11T77 : Tree := (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 5 7 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.split 2 (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.drop 7 8 (some 3) (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 4 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 5 7 8)))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape11T77OK : treeOK (forms 11) 8208 1839880 q9Shape11T77=true := by decide

private def q9Shape11T67 : Tree := .split 13 q9Shape11T68 q9Shape11T77
private theorem q9Shape11T67OK : treeOK (forms 11) 16 1839880 q9Shape11T67=true := by
  change (treeOK (forms 11) 16 (1839880 ||| 2^13) q9Shape11T68 &&
    treeOK (forms 11) (16 ||| 2^13) 1839880 q9Shape11T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T68OK,q9Shape11T77OK⟩

private def q9Shape11T83 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7)))) (.split 2 (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))))) (.tip (.cover 1 2 6 8)))))
private theorem q9Shape11T83OK : treeOK (forms 11) 4112 1943336 q9Shape11T83=true := by decide

private def q9Shape11T84 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 4 7 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8))))) (.tip (.cover 0 4 7 8))))
private theorem q9Shape11T84OK : treeOK (forms 11) 5136 1942312 q9Shape11T84=true := by decide

private def q9Shape11T82 : Tree := .split 10 q9Shape11T83 q9Shape11T84
private theorem q9Shape11T82OK : treeOK (forms 11) 4112 1942312 q9Shape11T82=true := by
  change (treeOK (forms 11) 4112 (1942312 ||| 2^10) q9Shape11T83 &&
    treeOK (forms 11) (4112 ||| 2^10) 1942312 q9Shape11T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T83OK,q9Shape11T84OK⟩

private def q9Shape11T85 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 1 2 5 6)))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape11T85OK : treeOK (forms 11) 4144 1942280 q9Shape11T85=true := by decide

private def q9Shape11T81 : Tree := .split 5 q9Shape11T82 q9Shape11T85
private theorem q9Shape11T81OK : treeOK (forms 11) 4112 1942280 q9Shape11T81=true := by
  change (treeOK (forms 11) 4112 (1942280 ||| 2^5) q9Shape11T82 &&
    treeOK (forms 11) (4112 ||| 2^5) 1942280 q9Shape11T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T82OK,q9Shape11T85OK⟩

private def q9Shape11T86 : Tree := (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.drop 7 8 (some 3) (some 6)))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 7 8))))
private theorem q9Shape11T86OK : treeOK (forms 11) 69648 1876744 q9Shape11T86=true := by decide

private def q9Shape11T80 : Tree := .split 16 q9Shape11T81 q9Shape11T86
private theorem q9Shape11T80OK : treeOK (forms 11) 4112 1876744 q9Shape11T80=true := by
  change (treeOK (forms 11) 4112 (1876744 ||| 2^16) q9Shape11T81 &&
    treeOK (forms 11) (4112 ||| 2^16) 1876744 q9Shape11T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T81OK,q9Shape11T86OK⟩

private def q9Shape11T87 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))))) (.tip (.cover 0 6 7 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 6 7 8)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape11T87OK : treeOK (forms 11) 36880 1843976 q9Shape11T87=true := by decide

private def q9Shape11T79 : Tree := .split 15 q9Shape11T80 q9Shape11T87
private theorem q9Shape11T79OK : treeOK (forms 11) 4112 1843976 q9Shape11T79=true := by
  change (treeOK (forms 11) 4112 (1843976 ||| 2^15) q9Shape11T80 &&
    treeOK (forms 11) (4112 ||| 2^15) 1843976 q9Shape11T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T80OK,q9Shape11T87OK⟩

private def q9Shape11T88 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape11T88OK : treeOK (forms 11) 12304 1835784 q9Shape11T88=true := by decide

private def q9Shape11T78 : Tree := .split 13 q9Shape11T79 q9Shape11T88
private theorem q9Shape11T78OK : treeOK (forms 11) 4112 1835784 q9Shape11T78=true := by
  change (treeOK (forms 11) 4112 (1835784 ||| 2^13) q9Shape11T79 &&
    treeOK (forms 11) (4112 ||| 2^13) 1835784 q9Shape11T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T79OK,q9Shape11T88OK⟩

private def q9Shape11T66 : Tree := .split 12 q9Shape11T67 q9Shape11T78
private theorem q9Shape11T66OK : treeOK (forms 11) 16 1835784 q9Shape11T66=true := by
  change (treeOK (forms 11) 16 (1835784 ||| 2^12) q9Shape11T67 &&
    treeOK (forms 11) (16 ||| 2^12) 1835784 q9Shape11T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T67OK,q9Shape11T78OK⟩

private def q9Shape11T90 : Tree := (.split 13 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 5 7 8))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 3 8 (some 2) (some 6))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 5 7 8))))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape11T90OK : treeOK (forms 11) 528 1839368 q9Shape11T90=true := by decide

private def q9Shape11T91 : Tree := (.split 13 (.split 15 (.split 16 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 3 8 (some 2) (some 6))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 2 4))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape11T91OK : treeOK (forms 11) 4624 1835272 q9Shape11T91=true := by decide

private def q9Shape11T89 : Tree := .split 12 q9Shape11T90 q9Shape11T91
private theorem q9Shape11T89OK : treeOK (forms 11) 528 1835272 q9Shape11T89=true := by
  change (treeOK (forms 11) 528 (1835272 ||| 2^12) q9Shape11T90 &&
    treeOK (forms 11) (528 ||| 2^12) 1835272 q9Shape11T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T90OK,q9Shape11T91OK⟩

private def q9Shape11T65 : Tree := .split 9 q9Shape11T66 q9Shape11T89
private theorem q9Shape11T65OK : treeOK (forms 11) 16 1835272 q9Shape11T65=true := by
  change (treeOK (forms 11) 16 (1835272 ||| 2^9) q9Shape11T66 &&
    treeOK (forms 11) (16 ||| 2^9) 1835272 q9Shape11T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T66OK,q9Shape11T89OK⟩

private def q9Shape11T99 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 3 7 8))))
private theorem q9Shape11T99OK : treeOK (forms 11) 272 1947176 q9Shape11T99=true := by decide

private def q9Shape11T101 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 5 7))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 1 2 6 8))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 3 7 (some 2) (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 5 7))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 5 7)))) (.tip (.cover 1 2 6 8)))))
private theorem q9Shape11T101OK : treeOK (forms 11) 1296 1962536 q9Shape11T101=true := by decide

private def q9Shape11T102 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 6 8))))) (.tip (.cover 0 3 7 8)))
private theorem q9Shape11T102OK : treeOK (forms 11) 17680 1946152 q9Shape11T102=true := by decide

private def q9Shape11T100 : Tree := .split 14 q9Shape11T101 q9Shape11T102
private theorem q9Shape11T100OK : treeOK (forms 11) 1296 1946152 q9Shape11T100=true := by
  change (treeOK (forms 11) 1296 (1946152 ||| 2^14) q9Shape11T101 &&
    treeOK (forms 11) (1296 ||| 2^14) 1946152 q9Shape11T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T101OK,q9Shape11T102OK⟩

private def q9Shape11T98 : Tree := .split 10 q9Shape11T99 q9Shape11T100
private theorem q9Shape11T98OK : treeOK (forms 11) 272 1946152 q9Shape11T98=true := by
  change (treeOK (forms 11) 272 (1946152 ||| 2^10) q9Shape11T99 &&
    treeOK (forms 11) (272 ||| 2^10) 1946152 q9Shape11T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T99OK,q9Shape11T100OK⟩

private def q9Shape11T103 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 5 6))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 2 5 6))))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape11T103OK : treeOK (forms 11) 304 1946120 q9Shape11T103=true := by decide

private def q9Shape11T97 : Tree := .split 5 q9Shape11T98 q9Shape11T103
private theorem q9Shape11T97OK : treeOK (forms 11) 272 1946120 q9Shape11T97=true := by
  change (treeOK (forms 11) 272 (1946120 ||| 2^5) q9Shape11T98 &&
    treeOK (forms 11) (272 ||| 2^5) 1946120 q9Shape11T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T98OK,q9Shape11T103OK⟩

private def q9Shape11T104 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.tip (.cover 0 3 7 8))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 3 4 7)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.split 6 (.split 7 (.split 11 (.tip (.small 0)) (.tip (.drop 5 7 (some 1) (some 4)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape11T104OK : treeOK (forms 11) 65808 1880584 q9Shape11T104=true := by decide

private def q9Shape11T96 : Tree := .split 16 q9Shape11T97 q9Shape11T104
private theorem q9Shape11T96OK : treeOK (forms 11) 272 1880584 q9Shape11T96=true := by
  change (treeOK (forms 11) 272 (1880584 ||| 2^16) q9Shape11T97 &&
    treeOK (forms 11) (272 ||| 2^16) 1880584 q9Shape11T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T97OK,q9Shape11T104OK⟩

private def q9Shape11T105 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 6 7 8))) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 5 6 (some 0) (some 4))))) (.tip (.cover 0 3 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7)))) (.tip (.cover 0 5 7 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape11T105OK : treeOK (forms 11) 33040 1847816 q9Shape11T105=true := by decide

private def q9Shape11T95 : Tree := .split 15 q9Shape11T96 q9Shape11T105
private theorem q9Shape11T95OK : treeOK (forms 11) 272 1847816 q9Shape11T95=true := by
  change (treeOK (forms 11) 272 (1847816 ||| 2^15) q9Shape11T96 &&
    treeOK (forms 11) (272 ||| 2^15) 1847816 q9Shape11T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T96OK,q9Shape11T105OK⟩

private def q9Shape11T106 : Tree := (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 3 5 7)) (.split 17 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 3 7 8)))) (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.tip (.cover 0 3 7 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.split 7 (.split 11 (.tip (.small 0)) (.tip (.drop 4 7 (some 1) (some 5)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 2 3 4 5)))
private theorem q9Shape11T106OK : treeOK (forms 11) 8464 1839624 q9Shape11T106=true := by decide

private def q9Shape11T94 : Tree := .split 13 q9Shape11T95 q9Shape11T106
private theorem q9Shape11T94OK : treeOK (forms 11) 272 1839624 q9Shape11T94=true := by
  change (treeOK (forms 11) 272 (1839624 ||| 2^13) q9Shape11T95 &&
    treeOK (forms 11) (272 ||| 2^13) 1839624 q9Shape11T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T95OK,q9Shape11T106OK⟩

private def q9Shape11T107 : Tree := (.split 13 (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 5 6 7)) (.split 17 (.tip (.cover 0 1 4 7)) (.tip (.cover 0 3 7 8)))) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.tip (.cover 0 4 7 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 6 8 (some 2) none)) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 6 (some 0) (some 5)))) (.tip (.cover 0 3 4 7)))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 0 3 7 8))))) (.split 10 (.split 14 (.tip (.cover 1 2 5 6)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape11T107OK : treeOK (forms 11) 4368 1835528 q9Shape11T107=true := by decide

private def q9Shape11T93 : Tree := .split 12 q9Shape11T94 q9Shape11T107
private theorem q9Shape11T93OK : treeOK (forms 11) 272 1835528 q9Shape11T93=true := by
  change (treeOK (forms 11) 272 (1835528 ||| 2^12) q9Shape11T94 &&
    treeOK (forms 11) (272 ||| 2^12) 1835528 q9Shape11T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T94OK,q9Shape11T107OK⟩

private def q9Shape11T108 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape11T108OK : treeOK (forms 11) 784 1835016 q9Shape11T108=true := by decide

private def q9Shape11T92 : Tree := .split 9 q9Shape11T93 q9Shape11T108
private theorem q9Shape11T92OK : treeOK (forms 11) 272 1835016 q9Shape11T92=true := by
  change (treeOK (forms 11) 272 (1835016 ||| 2^9) q9Shape11T93 &&
    treeOK (forms 11) (272 ||| 2^9) 1835016 q9Shape11T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T93OK,q9Shape11T108OK⟩

private def q9Shape11T64 : Tree := .split 8 q9Shape11T65 q9Shape11T92
private theorem q9Shape11T64OK : treeOK (forms 11) 16 1835016 q9Shape11T64=true := by
  change (treeOK (forms 11) 16 (1835016 ||| 2^8) q9Shape11T65 &&
    treeOK (forms 11) (16 ||| 2^8) 1835016 q9Shape11T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T65OK,q9Shape11T92OK⟩

private def q9Shape11T4 : Tree := .split 4 q9Shape11T5 q9Shape11T64
private theorem q9Shape11T4OK : treeOK (forms 11) 0 1835016 q9Shape11T4=true := by
  change (treeOK (forms 11) 0 (1835016 ||| 2^4) q9Shape11T5 &&
    treeOK (forms 11) (0 ||| 2^4) 1835016 q9Shape11T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T5OK,q9Shape11T64OK⟩

private def q9Shape11T116 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape11T116OK : treeOK (forms 11) 8 1946384 q9Shape11T116=true := by decide

private def q9Shape11T119 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6)))) (.split 2 (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))))) (.tip (.cover 0 2 7 8)))))
private theorem q9Shape11T119OK : treeOK (forms 11) 65544 1881904 q9Shape11T119=true := by decide

private def q9Shape11T120 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 1 3 5 6)))) (.tip (.cover 0 2 7 8))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 1 3 5 6)))) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape11T120OK : treeOK (forms 11) 66568 1880880 q9Shape11T120=true := by decide

private def q9Shape11T118 : Tree := .split 10 q9Shape11T119 q9Shape11T120
private theorem q9Shape11T118OK : treeOK (forms 11) 65544 1880880 q9Shape11T118=true := by
  change (treeOK (forms 11) 65544 (1880880 ||| 2^10) q9Shape11T119 &&
    treeOK (forms 11) (65544 ||| 2^10) 1880880 q9Shape11T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T119OK,q9Shape11T120OK⟩

private def q9Shape11T121 : Tree := (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 2 5)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 2 7 8))))
private theorem q9Shape11T121OK : treeOK (forms 11) 65576 1880848 q9Shape11T121=true := by decide

private def q9Shape11T117 : Tree := .split 5 q9Shape11T118 q9Shape11T121
private theorem q9Shape11T117OK : treeOK (forms 11) 65544 1880848 q9Shape11T117=true := by
  change (treeOK (forms 11) 65544 (1880848 ||| 2^5) q9Shape11T118 &&
    treeOK (forms 11) (65544 ||| 2^5) 1880848 q9Shape11T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T118OK,q9Shape11T121OK⟩

private def q9Shape11T115 : Tree := .split 16 q9Shape11T116 q9Shape11T117
private theorem q9Shape11T115OK : treeOK (forms 11) 8 1880848 q9Shape11T115=true := by
  change (treeOK (forms 11) 8 (1880848 ||| 2^16) q9Shape11T116 &&
    treeOK (forms 11) (8 ||| 2^16) 1880848 q9Shape11T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T116OK,q9Shape11T117OK⟩

private def q9Shape11T122 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape11T122OK : treeOK (forms 11) 32776 1848080 q9Shape11T122=true := by decide

private def q9Shape11T114 : Tree := .split 15 q9Shape11T115 q9Shape11T122
private theorem q9Shape11T114OK : treeOK (forms 11) 8 1848080 q9Shape11T114=true := by
  change (treeOK (forms 11) 8 (1848080 ||| 2^15) q9Shape11T115 &&
    treeOK (forms 11) (8 ||| 2^15) 1848080 q9Shape11T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T115OK,q9Shape11T122OK⟩

private def q9Shape11T127 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6)))) (.split 2 (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 1 4 5 6))) (.tip (.cover 1 4 5 6))))) (.tip (.cover 0 2 7 8)))))
private theorem q9Shape11T127OK : treeOK (forms 11) 8200 1939248 q9Shape11T127=true := by decide

private def q9Shape11T128 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 2 7 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 2 7 8))))
private theorem q9Shape11T128OK : treeOK (forms 11) 9224 1938224 q9Shape11T128=true := by decide

private def q9Shape11T126 : Tree := .split 10 q9Shape11T127 q9Shape11T128
private theorem q9Shape11T126OK : treeOK (forms 11) 8200 1938224 q9Shape11T126=true := by
  change (treeOK (forms 11) 8200 (1938224 ||| 2^10) q9Shape11T127 &&
    treeOK (forms 11) (8200 ||| 2^10) 1938224 q9Shape11T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T127OK,q9Shape11T128OK⟩

private def q9Shape11T129 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 5 7)))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape11T129OK : treeOK (forms 11) 8232 1938192 q9Shape11T129=true := by decide

private def q9Shape11T125 : Tree := .split 5 q9Shape11T126 q9Shape11T129
private theorem q9Shape11T125OK : treeOK (forms 11) 8200 1938192 q9Shape11T125=true := by
  change (treeOK (forms 11) 8200 (1938192 ||| 2^5) q9Shape11T126 &&
    treeOK (forms 11) (8200 ||| 2^5) 1938192 q9Shape11T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T126OK,q9Shape11T129OK⟩

private def q9Shape11T130 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.split 17 (.tip (.cover 0 1 4 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))))) (.tip (.cover 0 2 7 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape11T130OK : treeOK (forms 11) 73736 1872656 q9Shape11T130=true := by decide

private def q9Shape11T124 : Tree := .split 16 q9Shape11T125 q9Shape11T130
private theorem q9Shape11T124OK : treeOK (forms 11) 8200 1872656 q9Shape11T124=true := by
  change (treeOK (forms 11) 8200 (1872656 ||| 2^16) q9Shape11T125 &&
    treeOK (forms 11) (8200 ||| 2^16) 1872656 q9Shape11T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T125OK,q9Shape11T130OK⟩

private def q9Shape11T131 : Tree := (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 6 7 8))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.drop 7 8 (some 3) (some 3))) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 2 3 5 7)))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 5 7)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 5 7 8)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape11T131OK : treeOK (forms 11) 40968 1839888 q9Shape11T131=true := by decide

private def q9Shape11T123 : Tree := .split 15 q9Shape11T124 q9Shape11T131
private theorem q9Shape11T123OK : treeOK (forms 11) 8200 1839888 q9Shape11T123=true := by
  change (treeOK (forms 11) 8200 (1839888 ||| 2^15) q9Shape11T124 &&
    treeOK (forms 11) (8200 ||| 2^15) 1839888 q9Shape11T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T124OK,q9Shape11T131OK⟩

private def q9Shape11T113 : Tree := .split 13 q9Shape11T114 q9Shape11T123
private theorem q9Shape11T113OK : treeOK (forms 11) 8 1839888 q9Shape11T113=true := by
  change (treeOK (forms 11) 8 (1839888 ||| 2^13) q9Shape11T114 &&
    treeOK (forms 11) (8 ||| 2^13) 1839888 q9Shape11T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T114OK,q9Shape11T123OK⟩

private def q9Shape11T132 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 6 7 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 7))) (.split 2 (.split 6 (.split 7 (.tip (.drop 7 8 (some 3) (some 3))) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 0 2 4 7))) (.tip (.cover 2 3 4 7)))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 4 7 8))))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape11T132OK : treeOK (forms 11) 4104 1835792 q9Shape11T132=true := by decide

private def q9Shape11T112 : Tree := .split 12 q9Shape11T113 q9Shape11T132
private theorem q9Shape11T112OK : treeOK (forms 11) 8 1835792 q9Shape11T112=true := by
  change (treeOK (forms 11) 8 (1835792 ||| 2^12) q9Shape11T113 &&
    treeOK (forms 11) (8 ||| 2^12) 1835792 q9Shape11T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T113OK,q9Shape11T132OK⟩

private def q9Shape11T139 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 2 7 8))))
private theorem q9Shape11T139OK : treeOK (forms 11) 520 1946928 q9Shape11T139=true := by decide

private def q9Shape11T141 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 3 5 6)))) (.tip (.cover 0 2 7 8))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 3 7 (some 2) (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 1 3 5 6)))) (.tip (.cover 0 2 7 8)))))
private theorem q9Shape11T141OK : treeOK (forms 11) 1544 1962288 q9Shape11T141=true := by decide

private def q9Shape11T142 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 7 8))))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape11T142OK : treeOK (forms 11) 17928 1945904 q9Shape11T142=true := by decide

private def q9Shape11T140 : Tree := .split 14 q9Shape11T141 q9Shape11T142
private theorem q9Shape11T140OK : treeOK (forms 11) 1544 1945904 q9Shape11T140=true := by
  change (treeOK (forms 11) 1544 (1945904 ||| 2^14) q9Shape11T141 &&
    treeOK (forms 11) (1544 ||| 2^14) 1945904 q9Shape11T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T141OK,q9Shape11T142OK⟩

private def q9Shape11T138 : Tree := .split 10 q9Shape11T139 q9Shape11T140
private theorem q9Shape11T138OK : treeOK (forms 11) 520 1945904 q9Shape11T138=true := by
  change (treeOK (forms 11) 520 (1945904 ||| 2^10) q9Shape11T139 &&
    treeOK (forms 11) (520 ||| 2^10) 1945904 q9Shape11T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T139OK,q9Shape11T140OK⟩

private def q9Shape11T143 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 5 7))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 5 7))))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 7 8)))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape11T143OK : treeOK (forms 11) 552 1945872 q9Shape11T143=true := by decide

private def q9Shape11T137 : Tree := .split 5 q9Shape11T138 q9Shape11T143
private theorem q9Shape11T137OK : treeOK (forms 11) 520 1945872 q9Shape11T137=true := by
  change (treeOK (forms 11) 520 (1945872 ||| 2^5) q9Shape11T138 &&
    treeOK (forms 11) (520 ||| 2^5) 1945872 q9Shape11T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T138OK,q9Shape11T143OK⟩

private def q9Shape11T144 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.tip (.cover 0 2 7 8))) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.drop 5 7 (some 1) (some 4))))) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))) (.tip (.cover 0 2 7 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape11T144OK : treeOK (forms 11) 66056 1880336 q9Shape11T144=true := by decide

private def q9Shape11T136 : Tree := .split 16 q9Shape11T137 q9Shape11T144
private theorem q9Shape11T136OK : treeOK (forms 11) 520 1880336 q9Shape11T136=true := by
  change (treeOK (forms 11) 520 (1880336 ||| 2^16) q9Shape11T137 &&
    treeOK (forms 11) (520 ||| 2^16) 1880336 q9Shape11T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T137OK,q9Shape11T144OK⟩

private def q9Shape11T145 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 6 7 8))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 6 7 8)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 5 6 (some 0) (some 4)))) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7)))) (.tip (.cover 0 2 5 7))) (.tip (.cover 2 4 5 7)))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape11T145OK : treeOK (forms 11) 33288 1847568 q9Shape11T145=true := by decide

private def q9Shape11T135 : Tree := .split 15 q9Shape11T136 q9Shape11T145
private theorem q9Shape11T135OK : treeOK (forms 11) 520 1847568 q9Shape11T135=true := by
  change (treeOK (forms 11) 520 (1847568 ||| 2^15) q9Shape11T136 &&
    treeOK (forms 11) (520 ||| 2^15) 1847568 q9Shape11T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T136OK,q9Shape11T145OK⟩

private def q9Shape11T146 : Tree := (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.split 17 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 2 7 8)))) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.tip (.cover 0 2 7 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 2) none)) (.split 7 (.split 11 (.tip (.small 0)) (.tip (.drop 4 7 (some 1) (some 5)))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 7 8))))) (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 2 3 4 5)))
private theorem q9Shape11T146OK : treeOK (forms 11) 8712 1839376 q9Shape11T146=true := by decide

private def q9Shape11T134 : Tree := .split 13 q9Shape11T135 q9Shape11T146
private theorem q9Shape11T134OK : treeOK (forms 11) 520 1839376 q9Shape11T134=true := by
  change (treeOK (forms 11) 520 (1839376 ||| 2^13) q9Shape11T135 &&
    treeOK (forms 11) (520 ||| 2^13) 1839376 q9Shape11T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T135OK,q9Shape11T146OK⟩

private def q9Shape11T147 : Tree := (.split 13 (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 5 6 7)) (.split 17 (.tip (.cover 0 1 4 7)) (.tip (.cover 0 2 7 8)))) (.split 14 (.tip (.cover 1 3 5 6)) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.tip (.cover 0 4 7 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 4 7))) (.split 2 (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 6 (some 0) (some 5)))) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 2 4 7)))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 2 7 8)))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape11T147OK : treeOK (forms 11) 4616 1835280 q9Shape11T147=true := by decide

private def q9Shape11T133 : Tree := .split 12 q9Shape11T134 q9Shape11T147
private theorem q9Shape11T133OK : treeOK (forms 11) 520 1835280 q9Shape11T133=true := by
  change (treeOK (forms 11) 520 (1835280 ||| 2^12) q9Shape11T134 &&
    treeOK (forms 11) (520 ||| 2^12) 1835280 q9Shape11T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T134OK,q9Shape11T147OK⟩

private def q9Shape11T111 : Tree := .split 9 q9Shape11T112 q9Shape11T133
private theorem q9Shape11T111OK : treeOK (forms 11) 8 1835280 q9Shape11T111=true := by
  change (treeOK (forms 11) 8 (1835280 ||| 2^9) q9Shape11T112 &&
    treeOK (forms 11) (8 ||| 2^9) 1835280 q9Shape11T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T112OK,q9Shape11T133OK⟩

private def q9Shape11T151 : Tree := (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 5 (.split 10 (.tip (.cover 1 4 5 6)) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 2 7 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 3 7 8))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 2 3 7))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 3 8 (some 2) (some 7))) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 2 3 7))) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 2 3 7)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 2 7 8)))))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape11T151OK : treeOK (forms 11) 264 1847824 q9Shape11T151=true := by decide

private def q9Shape11T152 : Tree := (.split 15 (.split 16 (.split 5 (.split 10 (.tip (.cover 1 4 5 6)) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 7))) (.tip (.cover 2 3 5 7))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.drop 3 8 (some 2) (some 7))) (.tip (.cover 0 2 3 7))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 3 7))) (.tip (.cover 2 3 5 7)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 1 2 4))))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 6 7 8)))
private theorem q9Shape11T152OK : treeOK (forms 11) 8456 1839632 q9Shape11T152=true := by decide

private def q9Shape11T150 : Tree := .split 13 q9Shape11T151 q9Shape11T152
private theorem q9Shape11T150OK : treeOK (forms 11) 264 1839632 q9Shape11T150=true := by
  change (treeOK (forms 11) 264 (1839632 ||| 2^13) q9Shape11T151 &&
    treeOK (forms 11) (264 ||| 2^13) 1839632 q9Shape11T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T151OK,q9Shape11T152OK⟩

private def q9Shape11T153 : Tree := (.split 13 (.tip (.cover 1 5 6 8)) (.tip (.cover 0 1 4 8)))
private theorem q9Shape11T153OK : treeOK (forms 11) 4360 1835536 q9Shape11T153=true := by decide

private def q9Shape11T149 : Tree := .split 12 q9Shape11T150 q9Shape11T153
private theorem q9Shape11T149OK : treeOK (forms 11) 264 1835536 q9Shape11T149=true := by
  change (treeOK (forms 11) 264 (1835536 ||| 2^12) q9Shape11T150 &&
    treeOK (forms 11) (264 ||| 2^12) 1835536 q9Shape11T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T150OK,q9Shape11T153OK⟩

private def q9Shape11T154 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape11T154OK : treeOK (forms 11) 776 1835024 q9Shape11T154=true := by decide

private def q9Shape11T148 : Tree := .split 9 q9Shape11T149 q9Shape11T154
private theorem q9Shape11T148OK : treeOK (forms 11) 264 1835024 q9Shape11T148=true := by
  change (treeOK (forms 11) 264 (1835024 ||| 2^9) q9Shape11T149 &&
    treeOK (forms 11) (264 ||| 2^9) 1835024 q9Shape11T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T149OK,q9Shape11T154OK⟩

private def q9Shape11T110 : Tree := .split 8 q9Shape11T111 q9Shape11T148
private theorem q9Shape11T110OK : treeOK (forms 11) 8 1835024 q9Shape11T110=true := by
  change (treeOK (forms 11) 8 (1835024 ||| 2^8) q9Shape11T111 &&
    treeOK (forms 11) (8 ||| 2^8) 1835024 q9Shape11T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T111OK,q9Shape11T148OK⟩

private def q9Shape11T155 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape11T155OK : treeOK (forms 11) 24 1835008 q9Shape11T155=true := by decide

private def q9Shape11T109 : Tree := .split 4 q9Shape11T110 q9Shape11T155
private theorem q9Shape11T109OK : treeOK (forms 11) 8 1835008 q9Shape11T109=true := by
  change (treeOK (forms 11) 8 (1835008 ||| 2^4) q9Shape11T110 &&
    treeOK (forms 11) (8 ||| 2^4) 1835008 q9Shape11T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T110OK,q9Shape11T155OK⟩

private def q9Shape11T3 : Tree := .split 3 q9Shape11T4 q9Shape11T109
private theorem q9Shape11T3OK : treeOK (forms 11) 0 1835008 q9Shape11T3=true := by
  change (treeOK (forms 11) 0 (1835008 ||| 2^3) q9Shape11T4 &&
    treeOK (forms 11) (0 ||| 2^3) 1835008 q9Shape11T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T4OK,q9Shape11T109OK⟩

private def q9Shape11T156 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape11T156OK : treeOK (forms 11) 1048576 786432 q9Shape11T156=true := by decide

private def q9Shape11T2 : Tree := .split 20 q9Shape11T3 q9Shape11T156
private theorem q9Shape11T2OK : treeOK (forms 11) 0 786432 q9Shape11T2=true := by
  change (treeOK (forms 11) 0 (786432 ||| 2^20) q9Shape11T3 &&
    treeOK (forms 11) (0 ||| 2^20) 786432 q9Shape11T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T3OK,q9Shape11T156OK⟩

private def q9Shape11T157 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape11T157OK : treeOK (forms 11) 524288 262144 q9Shape11T157=true := by decide

private def q9Shape11T1 : Tree := .split 19 q9Shape11T2 q9Shape11T157
private theorem q9Shape11T1OK : treeOK (forms 11) 0 262144 q9Shape11T1=true := by
  change (treeOK (forms 11) 0 (262144 ||| 2^19) q9Shape11T2 &&
    treeOK (forms 11) (0 ||| 2^19) 262144 q9Shape11T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T2OK,q9Shape11T157OK⟩

private def q9Shape11T158 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape11T158OK : treeOK (forms 11) 262144 0 q9Shape11T158=true := by decide

private def q9Shape11T0 : Tree := .split 18 q9Shape11T1 q9Shape11T158
private theorem q9Shape11T0OK : treeOK (forms 11) 0 0 q9Shape11T0=true := by
  change (treeOK (forms 11) 0 (0 ||| 2^18) q9Shape11T1 &&
    treeOK (forms 11) (0 ||| 2^18) 0 q9Shape11T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape11T1OK,q9Shape11T158OK⟩


theorem q9Shape11_cover (b : Nat→Bool) (H : Ranked (adj (forms 11) b)) :
    ∃ u v w z,Effective (adj (forms 11) b) (adj (forms 11) b) u v w z :=
  checked_tree (forms 11) b H q9Shape11T0 q9Shape11T0OK

#print axioms q9Shape11_cover
end Graffiti384b.Q9
