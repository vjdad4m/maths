import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape12T3 : Tree := (.tip (.small 1))
private theorem q9Shape12T3OK : treeOK (forms 12) 0 67 q9Shape12T3=true := by decide

private def q9Shape12T5 : Tree := (.tip (.small 1))
private theorem q9Shape12T5OK : treeOK (forms 12) 64 35 q9Shape12T5=true := by decide

private def q9Shape12T6 : Tree := (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 7 8)))))
private theorem q9Shape12T6OK : treeOK (forms 12) 96 3 q9Shape12T6=true := by decide

private def q9Shape12T4 : Tree := .split 5 q9Shape12T5 q9Shape12T6
private theorem q9Shape12T4OK : treeOK (forms 12) 64 3 q9Shape12T4=true := by
  change (treeOK (forms 12) 64 (3 ||| 2^5) q9Shape12T5 &&
    treeOK (forms 12) (64 ||| 2^5) 3 q9Shape12T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T5OK,q9Shape12T6OK⟩

private def q9Shape12T2 : Tree := .split 6 q9Shape12T3 q9Shape12T4
private theorem q9Shape12T2OK : treeOK (forms 12) 0 3 q9Shape12T2=true := by
  change (treeOK (forms 12) 0 (3 ||| 2^6) q9Shape12T3 &&
    treeOK (forms 12) (0 ||| 2^6) 3 q9Shape12T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T3OK,q9Shape12T4OK⟩

private def q9Shape12T9 : Tree := (.tip (.small 1))
private theorem q9Shape12T9OK : treeOK (forms 12) 2 97 q9Shape12T9=true := by decide

private def q9Shape12T10 : Tree := (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 15 (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 7 8)))))
private theorem q9Shape12T10OK : treeOK (forms 12) 34 65 q9Shape12T10=true := by decide

private def q9Shape12T8 : Tree := .split 5 q9Shape12T9 q9Shape12T10
private theorem q9Shape12T8OK : treeOK (forms 12) 2 65 q9Shape12T8=true := by
  change (treeOK (forms 12) 2 (65 ||| 2^5) q9Shape12T9 &&
    treeOK (forms 12) (2 ||| 2^5) 65 q9Shape12T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T9OK,q9Shape12T10OK⟩

private def q9Shape12T13 : Tree := (.tip (.small 1))
private theorem q9Shape12T13OK : treeOK (forms 12) 66 1057 q9Shape12T13=true := by decide

private def q9Shape12T15 : Tree := (.tip (.small 1))
private theorem q9Shape12T15OK : treeOK (forms 12) 1090 16417 q9Shape12T15=true := by decide

private def q9Shape12T21 : Tree := (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.split 9 (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 3 4 1)))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1)))))
private theorem q9Shape12T21OK : treeOK (forms 12) 17474 360493 q9Shape12T21=true := by decide

private def q9Shape12T22 : Tree := (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 0 3 4 8))) (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 7))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1)))) (.tip (.cover 0 2 5 8)))
private theorem q9Shape12T22OK : treeOK (forms 12) 17482 360485 q9Shape12T22=true := by decide

private def q9Shape12T20 : Tree := .split 3 q9Shape12T21 q9Shape12T22
private theorem q9Shape12T20OK : treeOK (forms 12) 17474 360485 q9Shape12T20=true := by
  change (treeOK (forms 12) 17474 (360485 ||| 2^3) q9Shape12T21 &&
    treeOK (forms 12) (17474 ||| 2^3) 360485 q9Shape12T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T21OK,q9Shape12T22OK⟩

private def q9Shape12T23 : Tree := (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 6)))) (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.cover 0 2 3 4))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 3 4 7))) (.tip (.unordered 3 4 1)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape12T23OK : treeOK (forms 12) 17478 360481 q9Shape12T23=true := by decide

private def q9Shape12T19 : Tree := .split 2 q9Shape12T20 q9Shape12T23
private theorem q9Shape12T19OK : treeOK (forms 12) 17474 360481 q9Shape12T19=true := by
  change (treeOK (forms 12) 17474 (360481 ||| 2^2) q9Shape12T20 &&
    treeOK (forms 12) (17474 ||| 2^2) 360481 q9Shape12T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T20OK,q9Shape12T23OK⟩

private def q9Shape12T24 : Tree := (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 2 6 8)))
private theorem q9Shape12T24OK : treeOK (forms 12) 279618 98337 q9Shape12T24=true := by decide

private def q9Shape12T18 : Tree := .split 18 q9Shape12T19 q9Shape12T24
private theorem q9Shape12T18OK : treeOK (forms 12) 17474 98337 q9Shape12T18=true := by
  change (treeOK (forms 12) 17474 (98337 ||| 2^18) q9Shape12T19 &&
    treeOK (forms 12) (17474 ||| 2^18) 98337 q9Shape12T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T19OK,q9Shape12T24OK⟩

private def q9Shape12T25 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.unordered 3 4 1)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T25OK : treeOK (forms 12) 83010 32801 q9Shape12T25=true := by decide

private def q9Shape12T17 : Tree := .split 16 q9Shape12T18 q9Shape12T25
private theorem q9Shape12T17OK : treeOK (forms 12) 17474 32801 q9Shape12T17=true := by
  change (treeOK (forms 12) 17474 (32801 ||| 2^16) q9Shape12T18 &&
    treeOK (forms 12) (17474 ||| 2^16) 32801 q9Shape12T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T18OK,q9Shape12T25OK⟩

private def q9Shape12T26 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.unordered 3 4 1)))) (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1)))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T26OK : treeOK (forms 12) 50242 33 q9Shape12T26=true := by decide

private def q9Shape12T16 : Tree := .split 15 q9Shape12T17 q9Shape12T26
private theorem q9Shape12T16OK : treeOK (forms 12) 17474 33 q9Shape12T16=true := by
  change (treeOK (forms 12) 17474 (33 ||| 2^15) q9Shape12T17 &&
    treeOK (forms 12) (17474 ||| 2^15) 33 q9Shape12T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T17OK,q9Shape12T26OK⟩

private def q9Shape12T14 : Tree := .split 14 q9Shape12T15 q9Shape12T16
private theorem q9Shape12T14OK : treeOK (forms 12) 1090 33 q9Shape12T14=true := by
  change (treeOK (forms 12) 1090 (33 ||| 2^14) q9Shape12T15 &&
    treeOK (forms 12) (1090 ||| 2^14) 33 q9Shape12T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T15OK,q9Shape12T16OK⟩

private def q9Shape12T12 : Tree := .split 10 q9Shape12T13 q9Shape12T14
private theorem q9Shape12T12OK : treeOK (forms 12) 66 33 q9Shape12T12=true := by
  change (treeOK (forms 12) 66 (33 ||| 2^10) q9Shape12T13 &&
    treeOK (forms 12) (66 ||| 2^10) 33 q9Shape12T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T13OK,q9Shape12T14OK⟩

private def q9Shape12T29 : Tree := (.tip (.small 1))
private theorem q9Shape12T29OK : treeOK (forms 12) 98 17409 q9Shape12T29=true := by decide

private def q9Shape12T35 : Tree := (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.split 9 (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 2 4 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 3)))))
private theorem q9Shape12T35OK : treeOK (forms 12) 16482 361485 q9Shape12T35=true := by decide

private def q9Shape12T36 : Tree := (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 0 3 4 8))) (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.cover 0 2 3 4))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 2 3))) (.tip (.cover 0 3 4 8)))) (.tip (.unordered 2 4 1)))
private theorem q9Shape12T36OK : treeOK (forms 12) 16490 361477 q9Shape12T36=true := by decide

private def q9Shape12T34 : Tree := .split 3 q9Shape12T35 q9Shape12T36
private theorem q9Shape12T34OK : treeOK (forms 12) 16482 361477 q9Shape12T34=true := by
  change (treeOK (forms 12) 16482 (361477 ||| 2^3) q9Shape12T35 &&
    treeOK (forms 12) (16482 ||| 2^3) 361477 q9Shape12T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T35OK,q9Shape12T36OK⟩

private def q9Shape12T37 : Tree := (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 2 4 1)))) (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 2 4 7))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 3 4 8))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1)))
private theorem q9Shape12T37OK : treeOK (forms 12) 16486 361473 q9Shape12T37=true := by decide

private def q9Shape12T33 : Tree := .split 2 q9Shape12T34 q9Shape12T37
private theorem q9Shape12T33OK : treeOK (forms 12) 16482 361473 q9Shape12T33=true := by
  change (treeOK (forms 12) 16482 (361473 ||| 2^2) q9Shape12T34 &&
    treeOK (forms 12) (16482 ||| 2^2) 361473 q9Shape12T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T34OK,q9Shape12T37OK⟩

private def q9Shape12T38 : Tree := (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 3 6 8))) (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 2 4 5 6)))) (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 2 4 5 7))) (.tip (.unordered 2 4 1)))) (.tip (.cover 0 1 2 6)))
private theorem q9Shape12T38OK : treeOK (forms 12) 278626 99329 q9Shape12T38=true := by decide

private def q9Shape12T32 : Tree := .split 18 q9Shape12T33 q9Shape12T38
private theorem q9Shape12T32OK : treeOK (forms 12) 16482 99329 q9Shape12T32=true := by
  change (treeOK (forms 12) 16482 (99329 ||| 2^18) q9Shape12T33 &&
    treeOK (forms 12) (16482 ||| 2^18) 99329 q9Shape12T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T33OK,q9Shape12T38OK⟩

private def q9Shape12T39 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 5 6 8))) (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 1 2 5))) (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 5 6 8))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1)))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T39OK : treeOK (forms 12) 82018 33793 q9Shape12T39=true := by decide

private def q9Shape12T31 : Tree := .split 16 q9Shape12T32 q9Shape12T39
private theorem q9Shape12T31OK : treeOK (forms 12) 16482 33793 q9Shape12T31=true := by
  change (treeOK (forms 12) 16482 (33793 ||| 2^16) q9Shape12T32 &&
    treeOK (forms 12) (16482 ||| 2^16) 33793 q9Shape12T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T32OK,q9Shape12T39OK⟩

private def q9Shape12T40 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 2 5))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 6 7 8))) (.tip (.cover 2 4 5 7))) (.tip (.unordered 2 4 1)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 2 4 6 7))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 5 7 8))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1)))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T40OK : treeOK (forms 12) 49250 1025 q9Shape12T40=true := by decide

private def q9Shape12T30 : Tree := .split 15 q9Shape12T31 q9Shape12T40
private theorem q9Shape12T30OK : treeOK (forms 12) 16482 1025 q9Shape12T30=true := by
  change (treeOK (forms 12) 16482 (1025 ||| 2^15) q9Shape12T31 &&
    treeOK (forms 12) (16482 ||| 2^15) 1025 q9Shape12T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T31OK,q9Shape12T40OK⟩

private def q9Shape12T28 : Tree := .split 14 q9Shape12T29 q9Shape12T30
private theorem q9Shape12T28OK : treeOK (forms 12) 98 1025 q9Shape12T28=true := by
  change (treeOK (forms 12) 98 (1025 ||| 2^14) q9Shape12T29 &&
    treeOK (forms 12) (98 ||| 2^14) 1025 q9Shape12T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T29OK,q9Shape12T30OK⟩

private def q9Shape12T44 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6))) (.tip (.cover 2 3 5 6))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 1 2 6))))
private theorem q9Shape12T44OK : treeOK (forms 12) 1122 114689 q9Shape12T44=true := by decide

private def q9Shape12T45 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 2 3 6 7))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 1 2 5))) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T45OK : treeOK (forms 12) 66658 49153 q9Shape12T45=true := by decide

private def q9Shape12T43 : Tree := .split 16 q9Shape12T44 q9Shape12T45
private theorem q9Shape12T43OK : treeOK (forms 12) 1122 49153 q9Shape12T43=true := by
  change (treeOK (forms 12) 1122 (49153 ||| 2^16) q9Shape12T44 &&
    treeOK (forms 12) (1122 ||| 2^16) 49153 q9Shape12T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T44OK,q9Shape12T45OK⟩

private def q9Shape12T46 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 2 3 5 7))) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 1 2 5))) (.tip (.cover 2 3 5 7))) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T46OK : treeOK (forms 12) 33890 16385 q9Shape12T46=true := by decide

private def q9Shape12T42 : Tree := .split 15 q9Shape12T43 q9Shape12T46
private theorem q9Shape12T42OK : treeOK (forms 12) 1122 16385 q9Shape12T42=true := by
  change (treeOK (forms 12) 1122 (16385 ||| 2^15) q9Shape12T43 &&
    treeOK (forms 12) (1122 ||| 2^15) 16385 q9Shape12T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T43OK,q9Shape12T46OK⟩

private def q9Shape12T47 : Tree := (.split 15 (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape12T47OK : treeOK (forms 12) 17506 1 q9Shape12T47=true := by decide

private def q9Shape12T41 : Tree := .split 14 q9Shape12T42 q9Shape12T47
private theorem q9Shape12T41OK : treeOK (forms 12) 1122 1 q9Shape12T41=true := by
  change (treeOK (forms 12) 1122 (1 ||| 2^14) q9Shape12T42 &&
    treeOK (forms 12) (1122 ||| 2^14) 1 q9Shape12T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T42OK,q9Shape12T47OK⟩

private def q9Shape12T27 : Tree := .split 10 q9Shape12T28 q9Shape12T41
private theorem q9Shape12T27OK : treeOK (forms 12) 98 1 q9Shape12T27=true := by
  change (treeOK (forms 12) 98 (1 ||| 2^10) q9Shape12T28 &&
    treeOK (forms 12) (98 ||| 2^10) 1 q9Shape12T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T28OK,q9Shape12T41OK⟩

private def q9Shape12T11 : Tree := .split 5 q9Shape12T12 q9Shape12T27
private theorem q9Shape12T11OK : treeOK (forms 12) 66 1 q9Shape12T11=true := by
  change (treeOK (forms 12) 66 (1 ||| 2^5) q9Shape12T12 &&
    treeOK (forms 12) (66 ||| 2^5) 1 q9Shape12T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T12OK,q9Shape12T27OK⟩

private def q9Shape12T7 : Tree := .split 6 q9Shape12T8 q9Shape12T11
private theorem q9Shape12T7OK : treeOK (forms 12) 2 1 q9Shape12T7=true := by
  change (treeOK (forms 12) 2 (1 ||| 2^6) q9Shape12T8 &&
    treeOK (forms 12) (2 ||| 2^6) 1 q9Shape12T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T8OK,q9Shape12T11OK⟩

private def q9Shape12T1 : Tree := .split 1 q9Shape12T2 q9Shape12T7
private theorem q9Shape12T1OK : treeOK (forms 12) 0 1 q9Shape12T1=true := by
  change (treeOK (forms 12) 0 (1 ||| 2^1) q9Shape12T2 &&
    treeOK (forms 12) (0 ||| 2^1) 1 q9Shape12T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T2OK,q9Shape12T7OK⟩

private def q9Shape12T51 : Tree := (.tip (.small 1))
private theorem q9Shape12T51OK : treeOK (forms 12) 1 98 q9Shape12T51=true := by decide

private def q9Shape12T53 : Tree := (.tip (.small 1))
private theorem q9Shape12T53OK : treeOK (forms 12) 33 1090 q9Shape12T53=true := by decide

private def q9Shape12T55 : Tree := (.tip (.small 1))
private theorem q9Shape12T55OK : treeOK (forms 12) 1057 16450 q9Shape12T55=true := by decide

private def q9Shape12T60 : Tree := (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.split 9 (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 2 3 1)))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 3 4 6 7))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 3 7))))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4)))) (.tip (.unordered 2 3 1))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.interval 6 2)) (.tip (.cover 2 4 5 7))) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 1 3 6))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 1 2 5))))
private theorem q9Shape12T60OK : treeOK (forms 12) 17441 360518 q9Shape12T60=true := by decide

private def q9Shape12T61 : Tree := (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 4 6 7)))) (.split 9 (.split 11 (.split 12 (.tip (.interval 6 2)) (.tip (.cover 3 4 5 7))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 1 3 5)))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))
private theorem q9Shape12T61OK : treeOK (forms 12) 17445 360514 q9Shape12T61=true := by decide

private def q9Shape12T59 : Tree := .split 2 q9Shape12T60 q9Shape12T61
private theorem q9Shape12T59OK : treeOK (forms 12) 17441 360514 q9Shape12T59=true := by
  change (treeOK (forms 12) 17441 (360514 ||| 2^2) q9Shape12T60 &&
    treeOK (forms 12) (17441 ||| 2^2) 360514 q9Shape12T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T60OK,q9Shape12T61OK⟩

private def q9Shape12T62 : Tree := (.tip (.cover 0 5 6 8))
private theorem q9Shape12T62OK : treeOK (forms 12) 279585 98370 q9Shape12T62=true := by decide

private def q9Shape12T58 : Tree := .split 18 q9Shape12T59 q9Shape12T62
private theorem q9Shape12T58OK : treeOK (forms 12) 17441 98370 q9Shape12T58=true := by
  change (treeOK (forms 12) 17441 (98370 ||| 2^18) q9Shape12T59 &&
    treeOK (forms 12) (17441 ||| 2^18) 98370 q9Shape12T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T59OK,q9Shape12T62OK⟩

private def q9Shape12T63 : Tree := (.tip (.cover 0 5 6 8))
private theorem q9Shape12T63OK : treeOK (forms 12) 82977 32834 q9Shape12T63=true := by decide

private def q9Shape12T57 : Tree := .split 16 q9Shape12T58 q9Shape12T63
private theorem q9Shape12T57OK : treeOK (forms 12) 17441 32834 q9Shape12T57=true := by
  change (treeOK (forms 12) 17441 (32834 ||| 2^16) q9Shape12T58 &&
    treeOK (forms 12) (17441 ||| 2^16) 32834 q9Shape12T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T58OK,q9Shape12T63OK⟩

private def q9Shape12T64 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape12T64OK : treeOK (forms 12) 50209 66 q9Shape12T64=true := by decide

private def q9Shape12T56 : Tree := .split 15 q9Shape12T57 q9Shape12T64
private theorem q9Shape12T56OK : treeOK (forms 12) 17441 66 q9Shape12T56=true := by
  change (treeOK (forms 12) 17441 (66 ||| 2^15) q9Shape12T57 &&
    treeOK (forms 12) (17441 ||| 2^15) 66 q9Shape12T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T57OK,q9Shape12T64OK⟩

private def q9Shape12T54 : Tree := .split 14 q9Shape12T55 q9Shape12T56
private theorem q9Shape12T54OK : treeOK (forms 12) 1057 66 q9Shape12T54=true := by
  change (treeOK (forms 12) 1057 (66 ||| 2^14) q9Shape12T55 &&
    treeOK (forms 12) (1057 ||| 2^14) 66 q9Shape12T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T55OK,q9Shape12T56OK⟩

private def q9Shape12T52 : Tree := .split 10 q9Shape12T53 q9Shape12T54
private theorem q9Shape12T52OK : treeOK (forms 12) 33 66 q9Shape12T52=true := by
  change (treeOK (forms 12) 33 (66 ||| 2^10) q9Shape12T53 &&
    treeOK (forms 12) (33 ||| 2^10) 66 q9Shape12T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T53OK,q9Shape12T54OK⟩

private def q9Shape12T50 : Tree := .split 5 q9Shape12T51 q9Shape12T52
private theorem q9Shape12T50OK : treeOK (forms 12) 1 66 q9Shape12T50=true := by
  change (treeOK (forms 12) 1 (66 ||| 2^5) q9Shape12T51 &&
    treeOK (forms 12) (1 ||| 2^5) 66 q9Shape12T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T51OK,q9Shape12T52OK⟩

private def q9Shape12T67 : Tree := (.tip (.small 1))
private theorem q9Shape12T67OK : treeOK (forms 12) 65 1058 q9Shape12T67=true := by decide

private def q9Shape12T69 : Tree := (.tip (.small 1))
private theorem q9Shape12T69OK : treeOK (forms 12) 1089 16418 q9Shape12T69=true := by decide

private def q9Shape12T75 : Tree := (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.split 9 (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 1 3 5)))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 7)))))
private theorem q9Shape12T75OK : treeOK (forms 12) 17473 360494 q9Shape12T75=true := by decide

private def q9Shape12T76 : Tree := (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 0 3 4 8))) (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 7))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 1 3 7)))) (.tip (.cover 0 2 5 8)))
private theorem q9Shape12T76OK : treeOK (forms 12) 17481 360486 q9Shape12T76=true := by decide

private def q9Shape12T74 : Tree := .split 3 q9Shape12T75 q9Shape12T76
private theorem q9Shape12T74OK : treeOK (forms 12) 17473 360486 q9Shape12T74=true := by
  change (treeOK (forms 12) 17473 (360486 ||| 2^3) q9Shape12T75 &&
    treeOK (forms 12) (17473 ||| 2^3) 360486 q9Shape12T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T75OK,q9Shape12T76OK⟩

private def q9Shape12T77 : Tree := (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 6)))) (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape12T77OK : treeOK (forms 12) 17477 360482 q9Shape12T77=true := by decide

private def q9Shape12T73 : Tree := .split 2 q9Shape12T74 q9Shape12T77
private theorem q9Shape12T73OK : treeOK (forms 12) 17473 360482 q9Shape12T73=true := by
  change (treeOK (forms 12) 17473 (360482 ||| 2^2) q9Shape12T74 &&
    treeOK (forms 12) (17473 ||| 2^2) 360482 q9Shape12T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T74OK,q9Shape12T77OK⟩

private def q9Shape12T78 : Tree := (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.split 11 (.tip (.drop 3 5 (some 1) none)) (.tip (.cover 0 1 4 6))) (.tip (.cover 1 3 5 6))) (.tip (.cover 1 3 5 7))) (.tip (.cover 0 1 3 6))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 2 6 8)))
private theorem q9Shape12T78OK : treeOK (forms 12) 279617 98338 q9Shape12T78=true := by decide

private def q9Shape12T72 : Tree := .split 18 q9Shape12T73 q9Shape12T78
private theorem q9Shape12T72OK : treeOK (forms 12) 17473 98338 q9Shape12T72=true := by
  change (treeOK (forms 12) 17473 (98338 ||| 2^18) q9Shape12T73 &&
    treeOK (forms 12) (17473 ||| 2^18) 98338 q9Shape12T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T73OK,q9Shape12T78OK⟩

private def q9Shape12T79 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.drop 3 6 (some 1) none)) (.tip (.cover 0 1 4 5))) (.split 12 (.tip (.drop 3 6 (some 1) none)) (.tip (.unordered 3 4 1)))) (.tip (.cover 1 3 5 6))) (.tip (.cover 0 1 3 5))) (.tip (.cover 1 3 6 7))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T79OK : treeOK (forms 12) 83009 32802 q9Shape12T79=true := by decide

private def q9Shape12T71 : Tree := .split 16 q9Shape12T72 q9Shape12T79
private theorem q9Shape12T71OK : treeOK (forms 12) 17473 32802 q9Shape12T71=true := by
  change (treeOK (forms 12) 17473 (32802 ||| 2^16) q9Shape12T72 &&
    treeOK (forms 12) (17473 ||| 2^16) 32802 q9Shape12T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T72OK,q9Shape12T79OK⟩

private def q9Shape12T80 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.small 0)) (.tip (.drop 1 3 (some 0) (some 0)))) (.split 13 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.unordered 3 4 1)))) (.split 12 (.split 13 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1)))) (.tip (.cover 0 1 3 5))) (.tip (.cover 1 3 5 7))) (.tip (.cover 1 3 6 7))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T80OK : treeOK (forms 12) 50241 34 q9Shape12T80=true := by decide

private def q9Shape12T70 : Tree := .split 15 q9Shape12T71 q9Shape12T80
private theorem q9Shape12T70OK : treeOK (forms 12) 17473 34 q9Shape12T70=true := by
  change (treeOK (forms 12) 17473 (34 ||| 2^15) q9Shape12T71 &&
    treeOK (forms 12) (17473 ||| 2^15) 34 q9Shape12T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T71OK,q9Shape12T80OK⟩

private def q9Shape12T68 : Tree := .split 14 q9Shape12T69 q9Shape12T70
private theorem q9Shape12T68OK : treeOK (forms 12) 1089 34 q9Shape12T68=true := by
  change (treeOK (forms 12) 1089 (34 ||| 2^14) q9Shape12T69 &&
    treeOK (forms 12) (1089 ||| 2^14) 34 q9Shape12T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T69OK,q9Shape12T70OK⟩

private def q9Shape12T66 : Tree := .split 10 q9Shape12T67 q9Shape12T68
private theorem q9Shape12T66OK : treeOK (forms 12) 65 34 q9Shape12T66=true := by
  change (treeOK (forms 12) 65 (34 ||| 2^10) q9Shape12T67 &&
    treeOK (forms 12) (65 ||| 2^10) 34 q9Shape12T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T67OK,q9Shape12T68OK⟩

private def q9Shape12T83 : Tree := (.tip (.small 1))
private theorem q9Shape12T83OK : treeOK (forms 12) 97 17410 q9Shape12T83=true := by decide

private def q9Shape12T89 : Tree := (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.split 9 (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 2 4 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 3)))))
private theorem q9Shape12T89OK : treeOK (forms 12) 16481 361486 q9Shape12T89=true := by decide

private def q9Shape12T90 : Tree := (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 0 3 4 8))) (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 2 3))) (.tip (.cover 0 3 4 8)))) (.tip (.cover 0 1 2 5)))
private theorem q9Shape12T90OK : treeOK (forms 12) 16489 361478 q9Shape12T90=true := by decide

private def q9Shape12T88 : Tree := .split 3 q9Shape12T89 q9Shape12T90
private theorem q9Shape12T88OK : treeOK (forms 12) 16481 361478 q9Shape12T88=true := by
  change (treeOK (forms 12) 16481 (361478 ||| 2^3) q9Shape12T89 &&
    treeOK (forms 12) (16481 ||| 2^3) 361478 q9Shape12T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T89OK,q9Shape12T90OK⟩

private def q9Shape12T91 : Tree := (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 4 6 7)))) (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 2 4 7))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))
private theorem q9Shape12T91OK : treeOK (forms 12) 16485 361474 q9Shape12T91=true := by decide

private def q9Shape12T87 : Tree := .split 2 q9Shape12T88 q9Shape12T91
private theorem q9Shape12T87OK : treeOK (forms 12) 16481 361474 q9Shape12T87=true := by
  change (treeOK (forms 12) 16481 (361474 ||| 2^2) q9Shape12T88 &&
    treeOK (forms 12) (16481 ||| 2^2) 361474 q9Shape12T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T88OK,q9Shape12T91OK⟩

private def q9Shape12T92 : Tree := (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 3 6 8))) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 1 2 6)))
private theorem q9Shape12T92OK : treeOK (forms 12) 278625 99330 q9Shape12T92=true := by decide

private def q9Shape12T86 : Tree := .split 18 q9Shape12T87 q9Shape12T92
private theorem q9Shape12T86OK : treeOK (forms 12) 16481 99330 q9Shape12T86=true := by
  change (treeOK (forms 12) 16481 (99330 ||| 2^18) q9Shape12T87 &&
    treeOK (forms 12) (16481 ||| 2^18) 99330 q9Shape12T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T87OK,q9Shape12T92OK⟩

private def q9Shape12T93 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 3 5 8))) (.tip (.cover 3 6 7 8))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 1 2 5))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T93OK : treeOK (forms 12) 82017 33794 q9Shape12T93=true := by decide

private def q9Shape12T85 : Tree := .split 16 q9Shape12T86 q9Shape12T93
private theorem q9Shape12T85OK : treeOK (forms 12) 16481 33794 q9Shape12T85=true := by
  change (treeOK (forms 12) 16481 (33794 ||| 2^16) q9Shape12T86 &&
    treeOK (forms 12) (16481 ||| 2^16) 33794 q9Shape12T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T86OK,q9Shape12T93OK⟩

private def q9Shape12T94 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 3 5 8))) (.tip (.cover 3 5 7 8))) (.tip (.cover 3 6 7 8))) (.tip (.cover 0 1 2 5))) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T94OK : treeOK (forms 12) 49249 1026 q9Shape12T94=true := by decide

private def q9Shape12T84 : Tree := .split 15 q9Shape12T85 q9Shape12T94
private theorem q9Shape12T84OK : treeOK (forms 12) 16481 1026 q9Shape12T84=true := by
  change (treeOK (forms 12) 16481 (1026 ||| 2^15) q9Shape12T85 &&
    treeOK (forms 12) (16481 ||| 2^15) 1026 q9Shape12T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T85OK,q9Shape12T94OK⟩

private def q9Shape12T82 : Tree := .split 14 q9Shape12T83 q9Shape12T84
private theorem q9Shape12T82OK : treeOK (forms 12) 97 1026 q9Shape12T82=true := by
  change (treeOK (forms 12) 97 (1026 ||| 2^14) q9Shape12T83 &&
    treeOK (forms 12) (97 ||| 2^14) 1026 q9Shape12T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T83OK,q9Shape12T84OK⟩

private def q9Shape12T99 : Tree := (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 7))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))))
private theorem q9Shape12T99OK : treeOK (forms 12) 1121 376834 q9Shape12T99=true := by decide

private def q9Shape12T100 : Tree := (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6))) (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6)))) (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 1 2 6)))
private theorem q9Shape12T100OK : treeOK (forms 12) 263265 114690 q9Shape12T100=true := by decide

private def q9Shape12T98 : Tree := .split 18 q9Shape12T99 q9Shape12T100
private theorem q9Shape12T98OK : treeOK (forms 12) 1121 114690 q9Shape12T98=true := by
  change (treeOK (forms 12) 1121 (114690 ||| 2^18) q9Shape12T99 &&
    treeOK (forms 12) (1121 ||| 2^18) 114690 q9Shape12T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T99OK,q9Shape12T100OK⟩

private def q9Shape12T101 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 1 3 6 7))) (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 2 3 6)))) (.tip (.cover 0 1 2 5))) (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T101OK : treeOK (forms 12) 66657 49154 q9Shape12T101=true := by decide

private def q9Shape12T97 : Tree := .split 16 q9Shape12T98 q9Shape12T101
private theorem q9Shape12T97OK : treeOK (forms 12) 1121 49154 q9Shape12T97=true := by
  change (treeOK (forms 12) 1121 (49154 ||| 2^16) q9Shape12T98 &&
    treeOK (forms 12) (1121 ||| 2^16) 49154 q9Shape12T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T98OK,q9Shape12T101OK⟩

private def q9Shape12T102 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 1 3 5 7))) (.tip (.cover 1 3 6 7))) (.tip (.cover 0 1 2 5))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 7))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 2 3 7))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T102OK : treeOK (forms 12) 33889 16386 q9Shape12T102=true := by decide

private def q9Shape12T96 : Tree := .split 15 q9Shape12T97 q9Shape12T102
private theorem q9Shape12T96OK : treeOK (forms 12) 1121 16386 q9Shape12T96=true := by
  change (treeOK (forms 12) 1121 (16386 ||| 2^15) q9Shape12T97 &&
    treeOK (forms 12) (1121 ||| 2^15) 16386 q9Shape12T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T97OK,q9Shape12T102OK⟩

private def q9Shape12T103 : Tree := (.split 15 (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape12T103OK : treeOK (forms 12) 17505 2 q9Shape12T103=true := by decide

private def q9Shape12T95 : Tree := .split 14 q9Shape12T96 q9Shape12T103
private theorem q9Shape12T95OK : treeOK (forms 12) 1121 2 q9Shape12T95=true := by
  change (treeOK (forms 12) 1121 (2 ||| 2^14) q9Shape12T96 &&
    treeOK (forms 12) (1121 ||| 2^14) 2 q9Shape12T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T96OK,q9Shape12T103OK⟩

private def q9Shape12T81 : Tree := .split 10 q9Shape12T82 q9Shape12T95
private theorem q9Shape12T81OK : treeOK (forms 12) 97 2 q9Shape12T81=true := by
  change (treeOK (forms 12) 97 (2 ||| 2^10) q9Shape12T82 &&
    treeOK (forms 12) (97 ||| 2^10) 2 q9Shape12T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T82OK,q9Shape12T95OK⟩

private def q9Shape12T65 : Tree := .split 5 q9Shape12T66 q9Shape12T81
private theorem q9Shape12T65OK : treeOK (forms 12) 65 2 q9Shape12T65=true := by
  change (treeOK (forms 12) 65 (2 ||| 2^5) q9Shape12T66 &&
    treeOK (forms 12) (65 ||| 2^5) 2 q9Shape12T81)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T66OK,q9Shape12T81OK⟩

private def q9Shape12T49 : Tree := .split 6 q9Shape12T50 q9Shape12T65
private theorem q9Shape12T49OK : treeOK (forms 12) 1 2 q9Shape12T49=true := by
  change (treeOK (forms 12) 1 (2 ||| 2^6) q9Shape12T50 &&
    treeOK (forms 12) (1 ||| 2^6) 2 q9Shape12T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T50OK,q9Shape12T65OK⟩

private def q9Shape12T107 : Tree := (.tip (.small 1))
private theorem q9Shape12T107OK : treeOK (forms 12) 3 1120 q9Shape12T107=true := by decide

private def q9Shape12T109 : Tree := (.tip (.small 1))
private theorem q9Shape12T109OK : treeOK (forms 12) 1027 16480 q9Shape12T109=true := by decide

private def q9Shape12T115 : Tree := (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.split 9 (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 2 3 1)))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 3 4 6 7))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 3 7)))))
private theorem q9Shape12T115OK : treeOK (forms 12) 17411 360556 q9Shape12T115=true := by decide

private def q9Shape12T116 : Tree := (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 0 3 4 8))) (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 7))) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 1 3 6))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 2 5 8)))
private theorem q9Shape12T116OK : treeOK (forms 12) 17419 360548 q9Shape12T116=true := by decide

private def q9Shape12T114 : Tree := .split 3 q9Shape12T115 q9Shape12T116
private theorem q9Shape12T114OK : treeOK (forms 12) 17411 360548 q9Shape12T114=true := by
  change (treeOK (forms 12) 17411 (360548 ||| 2^3) q9Shape12T115 &&
    treeOK (forms 12) (17411 ||| 2^3) 360548 q9Shape12T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T115OK,q9Shape12T116OK⟩

private def q9Shape12T117 : Tree := (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 6)))) (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 3 4 5 7))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape12T117OK : treeOK (forms 12) 17415 360544 q9Shape12T117=true := by decide

private def q9Shape12T113 : Tree := .split 2 q9Shape12T114 q9Shape12T117
private theorem q9Shape12T113OK : treeOK (forms 12) 17411 360544 q9Shape12T113=true := by
  change (treeOK (forms 12) 17411 (360544 ||| 2^2) q9Shape12T114 &&
    treeOK (forms 12) (17411 ||| 2^2) 360544 q9Shape12T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T114OK,q9Shape12T117OK⟩

private def q9Shape12T118 : Tree := (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6))) (.tip (.cover 2 5 6 8))) (.tip (.cover 2 5 7 8))) (.tip (.cover 0 2 6 8)))
private theorem q9Shape12T118OK : treeOK (forms 12) 279555 98400 q9Shape12T118=true := by decide

private def q9Shape12T112 : Tree := .split 18 q9Shape12T113 q9Shape12T118
private theorem q9Shape12T112OK : treeOK (forms 12) 17411 98400 q9Shape12T112=true := by
  change (treeOK (forms 12) 17411 (98400 ||| 2^18) q9Shape12T113 &&
    treeOK (forms 12) (17411 ||| 2^18) 98400 q9Shape12T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T113OK,q9Shape12T118OK⟩

private def q9Shape12T119 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 3 4 6 7))) (.tip (.cover 2 5 6 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 2 6 7 8))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T119OK : treeOK (forms 12) 82947 32864 q9Shape12T119=true := by decide

private def q9Shape12T111 : Tree := .split 16 q9Shape12T112 q9Shape12T119
private theorem q9Shape12T111OK : treeOK (forms 12) 17411 32864 q9Shape12T111=true := by
  change (treeOK (forms 12) 17411 (32864 ||| 2^16) q9Shape12T112 &&
    treeOK (forms 12) (17411 ||| 2^16) 32864 q9Shape12T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T112OK,q9Shape12T119OK⟩

private def q9Shape12T120 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 2 5 8))) (.tip (.cover 2 5 7 8))) (.tip (.cover 2 6 7 8))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T120OK : treeOK (forms 12) 50179 96 q9Shape12T120=true := by decide

private def q9Shape12T110 : Tree := .split 15 q9Shape12T111 q9Shape12T120
private theorem q9Shape12T110OK : treeOK (forms 12) 17411 96 q9Shape12T110=true := by
  change (treeOK (forms 12) 17411 (96 ||| 2^15) q9Shape12T111 &&
    treeOK (forms 12) (17411 ||| 2^15) 96 q9Shape12T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T111OK,q9Shape12T120OK⟩

private def q9Shape12T108 : Tree := .split 14 q9Shape12T109 q9Shape12T110
private theorem q9Shape12T108OK : treeOK (forms 12) 1027 96 q9Shape12T108=true := by
  change (treeOK (forms 12) 1027 (96 ||| 2^14) q9Shape12T109 &&
    treeOK (forms 12) (1027 ||| 2^14) 96 q9Shape12T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T109OK,q9Shape12T110OK⟩

private def q9Shape12T106 : Tree := .split 10 q9Shape12T107 q9Shape12T108
private theorem q9Shape12T106OK : treeOK (forms 12) 3 96 q9Shape12T106=true := by
  change (treeOK (forms 12) 3 (96 ||| 2^10) q9Shape12T107 &&
    treeOK (forms 12) (3 ||| 2^10) 96 q9Shape12T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T107OK,q9Shape12T108OK⟩

private def q9Shape12T123 : Tree := (.tip (.small 1))
private theorem q9Shape12T123OK : treeOK (forms 12) 35 17472 q9Shape12T123=true := by decide

private def q9Shape12T129 : Tree := (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.split 9 (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 2 4 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 3)))))
private theorem q9Shape12T129OK : treeOK (forms 12) 16419 361548 q9Shape12T129=true := by decide

private def q9Shape12T130 : Tree := (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 0 3 4 8))) (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 2 3))) (.tip (.cover 0 3 4 8)))) (.tip (.cover 0 1 2 5)))
private theorem q9Shape12T130OK : treeOK (forms 12) 16427 361540 q9Shape12T130=true := by decide

private def q9Shape12T128 : Tree := .split 3 q9Shape12T129 q9Shape12T130
private theorem q9Shape12T128OK : treeOK (forms 12) 16419 361540 q9Shape12T128=true := by
  change (treeOK (forms 12) 16419 (361540 ||| 2^3) q9Shape12T129 &&
    treeOK (forms 12) (16419 ||| 2^3) 361540 q9Shape12T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T129OK,q9Shape12T130OK⟩

private def q9Shape12T131 : Tree := (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.split 11 (.split 12 (.tip (.cover 0 2 3 8)) (.tip (.cover 0 2 3 4))) (.tip (.unordered 2 4 1)))) (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.drop 1 7 (some 0) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 0 2 4 7))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))
private theorem q9Shape12T131OK : treeOK (forms 12) 16423 361536 q9Shape12T131=true := by decide

private def q9Shape12T127 : Tree := .split 2 q9Shape12T128 q9Shape12T131
private theorem q9Shape12T127OK : treeOK (forms 12) 16419 361536 q9Shape12T127=true := by
  change (treeOK (forms 12) 16419 (361536 ||| 2^2) q9Shape12T128 &&
    treeOK (forms 12) (16419 ||| 2^2) 361536 q9Shape12T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T128OK,q9Shape12T131OK⟩

private def q9Shape12T132 : Tree := (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.split 11 (.tip (.drop 2 5 (some 1) none)) (.tip (.cover 0 1 4 6))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 6 8))) (.tip (.cover 0 3 6 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 1 2 5 7))) (.tip (.cover 0 1 2 6)))
private theorem q9Shape12T132OK : treeOK (forms 12) 278563 99392 q9Shape12T132=true := by decide

private def q9Shape12T126 : Tree := .split 18 q9Shape12T127 q9Shape12T132
private theorem q9Shape12T126OK : treeOK (forms 12) 16419 99392 q9Shape12T126=true := by
  change (treeOK (forms 12) 16419 (99392 ||| 2^18) q9Shape12T127 &&
    treeOK (forms 12) (16419 ||| 2^18) 99392 q9Shape12T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T127OK,q9Shape12T132OK⟩

private def q9Shape12T133 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.split 11 (.split 12 (.tip (.drop 2 6 (some 1) none)) (.tip (.cover 0 1 4 5))) (.split 12 (.tip (.drop 2 6 (some 1) none)) (.tip (.unordered 2 4 1)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 5))) (.tip (.cover 1 2 6 7))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T133OK : treeOK (forms 12) 81955 33856 q9Shape12T133=true := by decide

private def q9Shape12T125 : Tree := .split 16 q9Shape12T126 q9Shape12T133
private theorem q9Shape12T125OK : treeOK (forms 12) 16419 33856 q9Shape12T125=true := by
  change (treeOK (forms 12) 16419 (33856 ||| 2^16) q9Shape12T126 &&
    treeOK (forms 12) (16419 ||| 2^16) 33856 q9Shape12T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T126OK,q9Shape12T133OK⟩

private def q9Shape12T134 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.split 11 (.split 12 (.split 13 (.tip (.small 0)) (.tip (.drop 1 2 (some 0) (some 0)))) (.split 13 (.tip (.drop 1 2 (some 0) (some 0))) (.tip (.unordered 2 4 1)))) (.split 12 (.split 13 (.tip (.drop 1 2 (some 0) (some 0))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1)))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 2 5))) (.tip (.cover 1 2 5 7))) (.tip (.cover 1 2 6 7))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T134OK : treeOK (forms 12) 49187 1088 q9Shape12T134=true := by decide

private def q9Shape12T124 : Tree := .split 15 q9Shape12T125 q9Shape12T134
private theorem q9Shape12T124OK : treeOK (forms 12) 16419 1088 q9Shape12T124=true := by
  change (treeOK (forms 12) 16419 (1088 ||| 2^15) q9Shape12T125 &&
    treeOK (forms 12) (16419 ||| 2^15) 1088 q9Shape12T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T125OK,q9Shape12T134OK⟩

private def q9Shape12T122 : Tree := .split 14 q9Shape12T123 q9Shape12T124
private theorem q9Shape12T122OK : treeOK (forms 12) 35 1088 q9Shape12T122=true := by
  change (treeOK (forms 12) 35 (1088 ||| 2^14) q9Shape12T123 &&
    treeOK (forms 12) (35 ||| 2^14) 1088 q9Shape12T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T123OK,q9Shape12T124OK⟩

private def q9Shape12T138 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6))) (.tip (.cover 1 2 5 6))) (.tip (.cover 1 2 5 7))) (.tip (.cover 0 1 2 6))))
private theorem q9Shape12T138OK : treeOK (forms 12) 1059 114752 q9Shape12T138=true := by decide

private def q9Shape12T139 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.unordered 2 3 1)))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 5))) (.tip (.cover 1 2 6 7))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T139OK : treeOK (forms 12) 66595 49216 q9Shape12T139=true := by decide

private def q9Shape12T137 : Tree := .split 16 q9Shape12T138 q9Shape12T139
private theorem q9Shape12T137OK : treeOK (forms 12) 1059 49216 q9Shape12T137=true := by
  change (treeOK (forms 12) 1059 (49216 ||| 2^16) q9Shape12T138 &&
    treeOK (forms 12) (1059 ||| 2^16) 49216 q9Shape12T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T138OK,q9Shape12T139OK⟩

private def q9Shape12T140 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.unordered 2 3 1)))) (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 1 2 5 7))) (.tip (.cover 1 2 6 7))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T140OK : treeOK (forms 12) 33827 16448 q9Shape12T140=true := by decide

private def q9Shape12T136 : Tree := .split 15 q9Shape12T137 q9Shape12T140
private theorem q9Shape12T136OK : treeOK (forms 12) 1059 16448 q9Shape12T136=true := by
  change (treeOK (forms 12) 1059 (16448 ||| 2^15) q9Shape12T137 &&
    treeOK (forms 12) (1059 ||| 2^15) 16448 q9Shape12T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T137OK,q9Shape12T140OK⟩

private def q9Shape12T141 : Tree := (.split 15 (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 2 3 6)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 5))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 6 8))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape12T141OK : treeOK (forms 12) 17443 64 q9Shape12T141=true := by decide

private def q9Shape12T135 : Tree := .split 14 q9Shape12T136 q9Shape12T141
private theorem q9Shape12T135OK : treeOK (forms 12) 1059 64 q9Shape12T135=true := by
  change (treeOK (forms 12) 1059 (64 ||| 2^14) q9Shape12T136 &&
    treeOK (forms 12) (1059 ||| 2^14) 64 q9Shape12T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T136OK,q9Shape12T141OK⟩

private def q9Shape12T121 : Tree := .split 10 q9Shape12T122 q9Shape12T135
private theorem q9Shape12T121OK : treeOK (forms 12) 35 64 q9Shape12T121=true := by
  change (treeOK (forms 12) 35 (64 ||| 2^10) q9Shape12T122 &&
    treeOK (forms 12) (35 ||| 2^10) 64 q9Shape12T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T122OK,q9Shape12T135OK⟩

private def q9Shape12T105 : Tree := .split 5 q9Shape12T106 q9Shape12T121
private theorem q9Shape12T105OK : treeOK (forms 12) 3 64 q9Shape12T105=true := by
  change (treeOK (forms 12) 3 (64 ||| 2^5) q9Shape12T106 &&
    treeOK (forms 12) (3 ||| 2^5) 64 q9Shape12T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T106OK,q9Shape12T121OK⟩

private def q9Shape12T145 : Tree := (.tip (.small 1))
private theorem q9Shape12T145OK : treeOK (forms 12) 67 17440 q9Shape12T145=true := by decide

private def q9Shape12T147 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.unordered 3 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1)))) (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 1 7 8))))
private theorem q9Shape12T147OK : treeOK (forms 12) 16451 33824 q9Shape12T147=true := by decide

private def q9Shape12T148 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T148OK : treeOK (forms 12) 49219 1056 q9Shape12T148=true := by decide

private def q9Shape12T146 : Tree := .split 15 q9Shape12T147 q9Shape12T148
private theorem q9Shape12T146OK : treeOK (forms 12) 16451 1056 q9Shape12T146=true := by
  change (treeOK (forms 12) 16451 (1056 ||| 2^15) q9Shape12T147 &&
    treeOK (forms 12) (16451 ||| 2^15) 1056 q9Shape12T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T147OK,q9Shape12T148OK⟩

private def q9Shape12T144 : Tree := .split 14 q9Shape12T145 q9Shape12T146
private theorem q9Shape12T144OK : treeOK (forms 12) 67 1056 q9Shape12T144=true := by
  change (treeOK (forms 12) 67 (1056 ||| 2^14) q9Shape12T145 &&
    treeOK (forms 12) (67 ||| 2^14) 1056 q9Shape12T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T145OK,q9Shape12T146OK⟩

private def q9Shape12T151 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.cover 0 1 3 6))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 1 3 6 7))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 7 8))))
private theorem q9Shape12T151OK : treeOK (forms 12) 1091 49184 q9Shape12T151=true := by decide

private def q9Shape12T152 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.cover 0 1 3 5))) (.tip (.cover 1 3 5 7))) (.tip (.cover 1 3 6 7))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T152OK : treeOK (forms 12) 33859 16416 q9Shape12T152=true := by decide

private def q9Shape12T150 : Tree := .split 15 q9Shape12T151 q9Shape12T152
private theorem q9Shape12T150OK : treeOK (forms 12) 1091 16416 q9Shape12T150=true := by
  change (treeOK (forms 12) 1091 (16416 ||| 2^15) q9Shape12T151 &&
    treeOK (forms 12) (1091 ||| 2^15) 16416 q9Shape12T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T151OK,q9Shape12T152OK⟩

private def q9Shape12T153 : Tree := (.tip (.unordered 3 4 1))
private theorem q9Shape12T153OK : treeOK (forms 12) 17475 32 q9Shape12T153=true := by decide

private def q9Shape12T149 : Tree := .split 14 q9Shape12T150 q9Shape12T153
private theorem q9Shape12T149OK : treeOK (forms 12) 1091 32 q9Shape12T149=true := by
  change (treeOK (forms 12) 1091 (32 ||| 2^14) q9Shape12T150 &&
    treeOK (forms 12) (1091 ||| 2^14) 32 q9Shape12T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T150OK,q9Shape12T153OK⟩

private def q9Shape12T143 : Tree := .split 10 q9Shape12T144 q9Shape12T149
private theorem q9Shape12T143OK : treeOK (forms 12) 67 32 q9Shape12T143=true := by
  change (treeOK (forms 12) 67 (32 ||| 2^10) q9Shape12T144 &&
    treeOK (forms 12) (67 ||| 2^10) 32 q9Shape12T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T144OK,q9Shape12T149OK⟩

private def q9Shape12T158 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.tip (.cover 0 3 4 8)) (.split 7 (.split 8 (.tip (.cover 0 2 4 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 5)))) (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 2 4 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 6))) (.tip (.cover 0 1 2 7)))) (.split 2 (.split 3 (.split 4 (.split 7 (.tip (.cover 0 4 6 8)) (.tip (.unordered 2 3 1))) (.tip (.cover 1 2 5 6))) (.tip (.cover 1 2 5 7))) (.tip (.cover 0 1 2 6))))
private theorem q9Shape12T158OK : treeOK (forms 12) 99 115712 q9Shape12T158=true := by decide

private def q9Shape12T159 : Tree := (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.tip (.cover 0 4 5 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 5))) (.tip (.cover 1 2 6 7))) (.tip (.cover 0 1 7 8)))
private theorem q9Shape12T159OK : treeOK (forms 12) 65635 50176 q9Shape12T159=true := by decide

private def q9Shape12T157 : Tree := .split 16 q9Shape12T158 q9Shape12T159
private theorem q9Shape12T157OK : treeOK (forms 12) 99 50176 q9Shape12T157=true := by
  change (treeOK (forms 12) 99 (50176 ||| 2^16) q9Shape12T158 &&
    treeOK (forms 12) (99 ||| 2^16) 50176 q9Shape12T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T158OK,q9Shape12T159OK⟩

private def q9Shape12T160 : Tree := (.split 16 (.split 18 (.split 2 (.split 3 (.split 4 (.split 7 (.split 8 (.split 9 (.tip (.cover 0 4 5 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 5))) (.tip (.cover 1 2 5 7))) (.tip (.cover 1 2 6 7))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape12T160OK : treeOK (forms 12) 32867 17408 q9Shape12T160=true := by decide

private def q9Shape12T156 : Tree := .split 15 q9Shape12T157 q9Shape12T160
private theorem q9Shape12T156OK : treeOK (forms 12) 99 17408 q9Shape12T156=true := by
  change (treeOK (forms 12) 99 (17408 ||| 2^15) q9Shape12T157 &&
    treeOK (forms 12) (99 ||| 2^15) 17408 q9Shape12T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T157OK,q9Shape12T160OK⟩

private def q9Shape12T161 : Tree := (.tip (.unordered 2 4 1))
private theorem q9Shape12T161OK : treeOK (forms 12) 16483 1024 q9Shape12T161=true := by decide

private def q9Shape12T155 : Tree := .split 14 q9Shape12T156 q9Shape12T161
private theorem q9Shape12T155OK : treeOK (forms 12) 99 1024 q9Shape12T155=true := by
  change (treeOK (forms 12) 99 (1024 ||| 2^14) q9Shape12T156 &&
    treeOK (forms 12) (99 ||| 2^14) 1024 q9Shape12T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T156OK,q9Shape12T161OK⟩

private def q9Shape12T162 : Tree := (.split 14 (.tip (.unordered 2 3 1)) (.tip (.unordered 2 3 1)))
private theorem q9Shape12T162OK : treeOK (forms 12) 1123 0 q9Shape12T162=true := by decide

private def q9Shape12T154 : Tree := .split 10 q9Shape12T155 q9Shape12T162
private theorem q9Shape12T154OK : treeOK (forms 12) 99 0 q9Shape12T154=true := by
  change (treeOK (forms 12) 99 (0 ||| 2^10) q9Shape12T155 &&
    treeOK (forms 12) (99 ||| 2^10) 0 q9Shape12T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T155OK,q9Shape12T162OK⟩

private def q9Shape12T142 : Tree := .split 5 q9Shape12T143 q9Shape12T154
private theorem q9Shape12T142OK : treeOK (forms 12) 67 0 q9Shape12T142=true := by
  change (treeOK (forms 12) 67 (0 ||| 2^5) q9Shape12T143 &&
    treeOK (forms 12) (67 ||| 2^5) 0 q9Shape12T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T143OK,q9Shape12T154OK⟩

private def q9Shape12T104 : Tree := .split 6 q9Shape12T105 q9Shape12T142
private theorem q9Shape12T104OK : treeOK (forms 12) 3 0 q9Shape12T104=true := by
  change (treeOK (forms 12) 3 (0 ||| 2^6) q9Shape12T105 &&
    treeOK (forms 12) (3 ||| 2^6) 0 q9Shape12T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T105OK,q9Shape12T142OK⟩

private def q9Shape12T48 : Tree := .split 1 q9Shape12T49 q9Shape12T104
private theorem q9Shape12T48OK : treeOK (forms 12) 1 0 q9Shape12T48=true := by
  change (treeOK (forms 12) 1 (0 ||| 2^1) q9Shape12T49 &&
    treeOK (forms 12) (1 ||| 2^1) 0 q9Shape12T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T49OK,q9Shape12T104OK⟩

private def q9Shape12T0 : Tree := .split 0 q9Shape12T1 q9Shape12T48
private theorem q9Shape12T0OK : treeOK (forms 12) 0 0 q9Shape12T0=true := by
  change (treeOK (forms 12) 0 (0 ||| 2^0) q9Shape12T1 &&
    treeOK (forms 12) (0 ||| 2^0) 0 q9Shape12T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape12T1OK,q9Shape12T48OK⟩


theorem q9Shape12_cover (b : Nat→Bool) (H : Ranked (adj (forms 12) b)) :
    ∃ u v w z,Effective (adj (forms 12) b) (adj (forms 12) b) u v w z :=
  checked_tree (forms 12) b H q9Shape12T0 q9Shape12T0OK

#print axioms q9Shape12_cover
end Graffiti384b.Q9
