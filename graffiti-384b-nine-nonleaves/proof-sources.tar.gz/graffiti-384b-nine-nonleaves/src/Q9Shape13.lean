import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape13T9 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape13T9OK : treeOK (forms 13) 0 1848088 q9Shape13T9=true := by decide

private def q9Shape13T11 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape13T11OK : treeOK (forms 13) 8192 1872664 q9Shape13T11=true := by decide

private def q9Shape13T14 : Tree := (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 4 5)))))
private theorem q9Shape13T14OK : treeOK (forms 13) 40960 1905464 q9Shape13T14=true := by decide

private def q9Shape13T15 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5)))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 4 5 8)))
private theorem q9Shape13T15OK : treeOK (forms 13) 40992 1905432 q9Shape13T15=true := by decide

private def q9Shape13T13 : Tree := .split 5 q9Shape13T14 q9Shape13T15
private theorem q9Shape13T13OK : treeOK (forms 13) 40960 1905432 q9Shape13T13=true := by
  change (treeOK (forms 13) 40960 (1905432 ||| 2^5) q9Shape13T14 &&
    treeOK (forms 13) (40960 ||| 2^5) 1905432 q9Shape13T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T14OK,q9Shape13T15OK⟩

private def q9Shape13T16 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape13T16OK : treeOK (forms 13) 106496 1839896 q9Shape13T16=true := by decide

private def q9Shape13T12 : Tree := .split 16 q9Shape13T13 q9Shape13T16
private theorem q9Shape13T12OK : treeOK (forms 13) 40960 1839896 q9Shape13T12=true := by
  change (treeOK (forms 13) 40960 (1839896 ||| 2^16) q9Shape13T13 &&
    treeOK (forms 13) (40960 ||| 2^16) 1839896 q9Shape13T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T13OK,q9Shape13T16OK⟩

private def q9Shape13T10 : Tree := .split 15 q9Shape13T11 q9Shape13T12
private theorem q9Shape13T10OK : treeOK (forms 13) 8192 1839896 q9Shape13T10=true := by
  change (treeOK (forms 13) 8192 (1839896 ||| 2^15) q9Shape13T11 &&
    treeOK (forms 13) (8192 ||| 2^15) 1839896 q9Shape13T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T11OK,q9Shape13T12OK⟩

private def q9Shape13T8 : Tree := .split 13 q9Shape13T9 q9Shape13T10
private theorem q9Shape13T8OK : treeOK (forms 13) 0 1839896 q9Shape13T8=true := by
  change (treeOK (forms 13) 0 (1839896 ||| 2^13) q9Shape13T9 &&
    treeOK (forms 13) (0 ||| 2^13) 1839896 q9Shape13T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T9OK,q9Shape13T10OK⟩

private def q9Shape13T20 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape13T20OK : treeOK (forms 13) 4096 1942296 q9Shape13T20=true := by decide

private def q9Shape13T22 : Tree := (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 4 5)))))
private theorem q9Shape13T22OK : treeOK (forms 13) 69632 1876792 q9Shape13T22=true := by decide

private def q9Shape13T23 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5)))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 4 5)))) (.tip (.cover 0 4 5 8)))
private theorem q9Shape13T23OK : treeOK (forms 13) 69664 1876760 q9Shape13T23=true := by decide

private def q9Shape13T21 : Tree := .split 5 q9Shape13T22 q9Shape13T23
private theorem q9Shape13T21OK : treeOK (forms 13) 69632 1876760 q9Shape13T21=true := by
  change (treeOK (forms 13) 69632 (1876760 ||| 2^5) q9Shape13T22 &&
    treeOK (forms 13) (69632 ||| 2^5) 1876760 q9Shape13T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T22OK,q9Shape13T23OK⟩

private def q9Shape13T19 : Tree := .split 16 q9Shape13T20 q9Shape13T21
private theorem q9Shape13T19OK : treeOK (forms 13) 4096 1876760 q9Shape13T19=true := by
  change (treeOK (forms 13) 4096 (1876760 ||| 2^16) q9Shape13T20 &&
    treeOK (forms 13) (4096 ||| 2^16) 1876760 q9Shape13T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T20OK,q9Shape13T21OK⟩

private def q9Shape13T24 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape13T24OK : treeOK (forms 13) 36864 1843992 q9Shape13T24=true := by decide

private def q9Shape13T18 : Tree := .split 15 q9Shape13T19 q9Shape13T24
private theorem q9Shape13T18OK : treeOK (forms 13) 4096 1843992 q9Shape13T18=true := by
  change (treeOK (forms 13) 4096 (1843992 ||| 2^15) q9Shape13T19 &&
    treeOK (forms 13) (4096 ||| 2^15) 1843992 q9Shape13T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T19OK,q9Shape13T24OK⟩

private def q9Shape13T25 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape13T25OK : treeOK (forms 13) 12288 1835800 q9Shape13T25=true := by decide

private def q9Shape13T17 : Tree := .split 13 q9Shape13T18 q9Shape13T25
private theorem q9Shape13T17OK : treeOK (forms 13) 4096 1835800 q9Shape13T17=true := by
  change (treeOK (forms 13) 4096 (1835800 ||| 2^13) q9Shape13T18 &&
    treeOK (forms 13) (4096 ||| 2^13) 1835800 q9Shape13T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T18OK,q9Shape13T25OK⟩

private def q9Shape13T7 : Tree := .split 12 q9Shape13T8 q9Shape13T17
private theorem q9Shape13T7OK : treeOK (forms 13) 0 1835800 q9Shape13T7=true := by
  change (treeOK (forms 13) 0 (1835800 ||| 2^12) q9Shape13T8 &&
    treeOK (forms 13) (0 ||| 2^12) 1835800 q9Shape13T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T8OK,q9Shape13T17OK⟩

private def q9Shape13T29 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape13T29OK : treeOK (forms 13) 512 1880344 q9Shape13T29=true := by decide

private def q9Shape13T32 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape13T32OK : treeOK (forms 13) 33280 1913144 q9Shape13T32=true := by decide

private def q9Shape13T33 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 3 5 8))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 3 5 8))))
private theorem q9Shape13T33OK : treeOK (forms 13) 33312 1913112 q9Shape13T33=true := by decide

private def q9Shape13T31 : Tree := .split 5 q9Shape13T32 q9Shape13T33
private theorem q9Shape13T31OK : treeOK (forms 13) 33280 1913112 q9Shape13T31=true := by
  change (treeOK (forms 13) 33280 (1913112 ||| 2^5) q9Shape13T32 &&
    treeOK (forms 13) (33280 ||| 2^5) 1913112 q9Shape13T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T32OK,q9Shape13T33OK⟩

private def q9Shape13T34 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape13T34OK : treeOK (forms 13) 98816 1847576 q9Shape13T34=true := by decide

private def q9Shape13T30 : Tree := .split 16 q9Shape13T31 q9Shape13T34
private theorem q9Shape13T30OK : treeOK (forms 13) 33280 1847576 q9Shape13T30=true := by
  change (treeOK (forms 13) 33280 (1847576 ||| 2^16) q9Shape13T31 &&
    treeOK (forms 13) (33280 ||| 2^16) 1847576 q9Shape13T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T31OK,q9Shape13T34OK⟩

private def q9Shape13T28 : Tree := .split 15 q9Shape13T29 q9Shape13T30
private theorem q9Shape13T28OK : treeOK (forms 13) 512 1847576 q9Shape13T28=true := by
  change (treeOK (forms 13) 512 (1847576 ||| 2^15) q9Shape13T29 &&
    treeOK (forms 13) (512 ||| 2^15) 1847576 q9Shape13T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T29OK,q9Shape13T30OK⟩

private def q9Shape13T35 : Tree := (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5))))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape13T35OK : treeOK (forms 13) 8704 1839384 q9Shape13T35=true := by decide

private def q9Shape13T27 : Tree := .split 13 q9Shape13T28 q9Shape13T35
private theorem q9Shape13T27OK : treeOK (forms 13) 512 1839384 q9Shape13T27=true := by
  change (treeOK (forms 13) 512 (1839384 ||| 2^13) q9Shape13T28 &&
    treeOK (forms 13) (512 ||| 2^13) 1839384 q9Shape13T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T28OK,q9Shape13T35OK⟩

private def q9Shape13T40 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape13T40OK : treeOK (forms 13) 4608 1941816 q9Shape13T40=true := by decide

private def q9Shape13T41 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 3 4 8))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 3 4 8)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape13T41OK : treeOK (forms 13) 4640 1941784 q9Shape13T41=true := by decide

private def q9Shape13T39 : Tree := .split 5 q9Shape13T40 q9Shape13T41
private theorem q9Shape13T39OK : treeOK (forms 13) 4608 1941784 q9Shape13T39=true := by
  change (treeOK (forms 13) 4608 (1941784 ||| 2^5) q9Shape13T40 &&
    treeOK (forms 13) (4608 ||| 2^5) 1941784 q9Shape13T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T40OK,q9Shape13T41OK⟩

private def q9Shape13T42 : Tree := (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 4 7 8)))
private theorem q9Shape13T42OK : treeOK (forms 13) 70144 1876248 q9Shape13T42=true := by decide

private def q9Shape13T38 : Tree := .split 16 q9Shape13T39 q9Shape13T42
private theorem q9Shape13T38OK : treeOK (forms 13) 4608 1876248 q9Shape13T38=true := by
  change (treeOK (forms 13) 4608 (1876248 ||| 2^16) q9Shape13T39 &&
    treeOK (forms 13) (4608 ||| 2^16) 1876248 q9Shape13T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T39OK,q9Shape13T42OK⟩

private def q9Shape13T43 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 7))))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 3 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape13T43OK : treeOK (forms 13) 37376 1843480 q9Shape13T43=true := by decide

private def q9Shape13T37 : Tree := .split 15 q9Shape13T38 q9Shape13T43
private theorem q9Shape13T37OK : treeOK (forms 13) 4608 1843480 q9Shape13T37=true := by
  change (treeOK (forms 13) 4608 (1843480 ||| 2^15) q9Shape13T38 &&
    treeOK (forms 13) (4608 ||| 2^15) 1843480 q9Shape13T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T38OK,q9Shape13T43OK⟩

private def q9Shape13T44 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape13T44OK : treeOK (forms 13) 12800 1835288 q9Shape13T44=true := by decide

private def q9Shape13T36 : Tree := .split 13 q9Shape13T37 q9Shape13T44
private theorem q9Shape13T36OK : treeOK (forms 13) 4608 1835288 q9Shape13T36=true := by
  change (treeOK (forms 13) 4608 (1835288 ||| 2^13) q9Shape13T37 &&
    treeOK (forms 13) (4608 ||| 2^13) 1835288 q9Shape13T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T37OK,q9Shape13T44OK⟩

private def q9Shape13T26 : Tree := .split 12 q9Shape13T27 q9Shape13T36
private theorem q9Shape13T26OK : treeOK (forms 13) 512 1835288 q9Shape13T26=true := by
  change (treeOK (forms 13) 512 (1835288 ||| 2^12) q9Shape13T27 &&
    treeOK (forms 13) (512 ||| 2^12) 1835288 q9Shape13T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T27OK,q9Shape13T36OK⟩

private def q9Shape13T6 : Tree := .split 9 q9Shape13T7 q9Shape13T26
private theorem q9Shape13T6OK : treeOK (forms 13) 0 1835288 q9Shape13T6=true := by
  change (treeOK (forms 13) 0 (1835288 ||| 2^9) q9Shape13T7 &&
    treeOK (forms 13) (0 ||| 2^9) 1835288 q9Shape13T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T7OK,q9Shape13T26OK⟩

private def q9Shape13T50 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape13T50OK : treeOK (forms 13) 256 1946136 q9Shape13T50=true := by decide

private def q9Shape13T52 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape13T52OK : treeOK (forms 13) 65792 1880632 q9Shape13T52=true := by decide

private def q9Shape13T53 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 3 5 8))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 3 5 8))))
private theorem q9Shape13T53OK : treeOK (forms 13) 65824 1880600 q9Shape13T53=true := by decide

private def q9Shape13T51 : Tree := .split 5 q9Shape13T52 q9Shape13T53
private theorem q9Shape13T51OK : treeOK (forms 13) 65792 1880600 q9Shape13T51=true := by
  change (treeOK (forms 13) 65792 (1880600 ||| 2^5) q9Shape13T52 &&
    treeOK (forms 13) (65792 ||| 2^5) 1880600 q9Shape13T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T52OK,q9Shape13T53OK⟩

private def q9Shape13T49 : Tree := .split 16 q9Shape13T50 q9Shape13T51
private theorem q9Shape13T49OK : treeOK (forms 13) 256 1880600 q9Shape13T49=true := by
  change (treeOK (forms 13) 256 (1880600 ||| 2^16) q9Shape13T50 &&
    treeOK (forms 13) (256 ||| 2^16) 1880600 q9Shape13T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T50OK,q9Shape13T51OK⟩

private def q9Shape13T54 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape13T54OK : treeOK (forms 13) 33024 1847832 q9Shape13T54=true := by decide

private def q9Shape13T48 : Tree := .split 15 q9Shape13T49 q9Shape13T54
private theorem q9Shape13T48OK : treeOK (forms 13) 256 1847832 q9Shape13T48=true := by
  change (treeOK (forms 13) 256 (1847832 ||| 2^15) q9Shape13T49 &&
    treeOK (forms 13) (256 ||| 2^15) 1847832 q9Shape13T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T49OK,q9Shape13T54OK⟩

private def q9Shape13T58 : Tree := (.split 10 (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))) (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape13T58OK : treeOK (forms 13) 8448 1937976 q9Shape13T58=true := by decide

private def q9Shape13T59 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 3 4 8))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 3 4 8)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape13T59OK : treeOK (forms 13) 8480 1937944 q9Shape13T59=true := by decide

private def q9Shape13T57 : Tree := .split 5 q9Shape13T58 q9Shape13T59
private theorem q9Shape13T57OK : treeOK (forms 13) 8448 1937944 q9Shape13T57=true := by
  change (treeOK (forms 13) 8448 (1937944 ||| 2^5) q9Shape13T58 &&
    treeOK (forms 13) (8448 ||| 2^5) 1937944 q9Shape13T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T58OK,q9Shape13T59OK⟩

private def q9Shape13T60 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.split 17 (.tip (.cover 0 1 4 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 3 7 8)))
private theorem q9Shape13T60OK : treeOK (forms 13) 73984 1872408 q9Shape13T60=true := by decide

private def q9Shape13T56 : Tree := .split 16 q9Shape13T57 q9Shape13T60
private theorem q9Shape13T56OK : treeOK (forms 13) 8448 1872408 q9Shape13T56=true := by
  change (treeOK (forms 13) 8448 (1872408 ||| 2^16) q9Shape13T57 &&
    treeOK (forms 13) (8448 ||| 2^16) 1872408 q9Shape13T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T57OK,q9Shape13T60OK⟩

private def q9Shape13T61 : Tree := (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 4)))) (.tip (.cover 0 4 6 8))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape13T61OK : treeOK (forms 13) 41216 1839640 q9Shape13T61=true := by decide

private def q9Shape13T55 : Tree := .split 15 q9Shape13T56 q9Shape13T61
private theorem q9Shape13T55OK : treeOK (forms 13) 8448 1839640 q9Shape13T55=true := by
  change (treeOK (forms 13) 8448 (1839640 ||| 2^15) q9Shape13T56 &&
    treeOK (forms 13) (8448 ||| 2^15) 1839640 q9Shape13T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T56OK,q9Shape13T61OK⟩

private def q9Shape13T47 : Tree := .split 13 q9Shape13T48 q9Shape13T55
private theorem q9Shape13T47OK : treeOK (forms 13) 256 1839640 q9Shape13T47=true := by
  change (treeOK (forms 13) 256 (1839640 ||| 2^13) q9Shape13T48 &&
    treeOK (forms 13) (256 ||| 2^13) 1839640 q9Shape13T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T48OK,q9Shape13T55OK⟩

private def q9Shape13T62 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.split 14 (.tip (.cover 0 1 3 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 2) (some 2)))) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5))))) (.tip (.cover 0 5 6 8)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape13T62OK : treeOK (forms 13) 4352 1835544 q9Shape13T62=true := by decide

private def q9Shape13T46 : Tree := .split 12 q9Shape13T47 q9Shape13T62
private theorem q9Shape13T46OK : treeOK (forms 13) 256 1835544 q9Shape13T46=true := by
  change (treeOK (forms 13) 256 (1835544 ||| 2^12) q9Shape13T47 &&
    treeOK (forms 13) (256 ||| 2^12) 1835544 q9Shape13T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T47OK,q9Shape13T62OK⟩

private def q9Shape13T63 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape13T63OK : treeOK (forms 13) 768 1835032 q9Shape13T63=true := by decide

private def q9Shape13T45 : Tree := .split 9 q9Shape13T46 q9Shape13T63
private theorem q9Shape13T45OK : treeOK (forms 13) 256 1835032 q9Shape13T45=true := by
  change (treeOK (forms 13) 256 (1835032 ||| 2^9) q9Shape13T46 &&
    treeOK (forms 13) (256 ||| 2^9) 1835032 q9Shape13T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T46OK,q9Shape13T63OK⟩

private def q9Shape13T5 : Tree := .split 8 q9Shape13T6 q9Shape13T45
private theorem q9Shape13T5OK : treeOK (forms 13) 0 1835032 q9Shape13T5=true := by
  change (treeOK (forms 13) 0 (1835032 ||| 2^8) q9Shape13T6 &&
    treeOK (forms 13) (0 ||| 2^8) 1835032 q9Shape13T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T6OK,q9Shape13T45OK⟩

private def q9Shape13T69 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape13T69OK : treeOK (forms 13) 16 1880840 q9Shape13T69=true := by decide

private def q9Shape13T73 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape13T73OK : treeOK (forms 13) 32784 1914664 q9Shape13T73=true := by decide

private def q9Shape13T74 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 2 5 8)))
private theorem q9Shape13T74OK : treeOK (forms 13) 33808 1913640 q9Shape13T74=true := by decide

private def q9Shape13T72 : Tree := .split 10 q9Shape13T73 q9Shape13T74
private theorem q9Shape13T72OK : treeOK (forms 13) 32784 1913640 q9Shape13T72=true := by
  change (treeOK (forms 13) 32784 (1913640 ||| 2^10) q9Shape13T73 &&
    treeOK (forms 13) (32784 ||| 2^10) 1913640 q9Shape13T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T73OK,q9Shape13T74OK⟩

private def q9Shape13T75 : Tree := (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 2 5 8))))
private theorem q9Shape13T75OK : treeOK (forms 13) 32816 1913608 q9Shape13T75=true := by decide

private def q9Shape13T71 : Tree := .split 5 q9Shape13T72 q9Shape13T75
private theorem q9Shape13T71OK : treeOK (forms 13) 32784 1913608 q9Shape13T71=true := by
  change (treeOK (forms 13) 32784 (1913608 ||| 2^5) q9Shape13T72 &&
    treeOK (forms 13) (32784 ||| 2^5) 1913608 q9Shape13T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T72OK,q9Shape13T75OK⟩

private def q9Shape13T76 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape13T76OK : treeOK (forms 13) 98320 1848072 q9Shape13T76=true := by decide

private def q9Shape13T70 : Tree := .split 16 q9Shape13T71 q9Shape13T76
private theorem q9Shape13T70OK : treeOK (forms 13) 32784 1848072 q9Shape13T70=true := by
  change (treeOK (forms 13) 32784 (1848072 ||| 2^16) q9Shape13T71 &&
    treeOK (forms 13) (32784 ||| 2^16) 1848072 q9Shape13T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T71OK,q9Shape13T76OK⟩

private def q9Shape13T68 : Tree := .split 15 q9Shape13T69 q9Shape13T70
private theorem q9Shape13T68OK : treeOK (forms 13) 16 1848072 q9Shape13T68=true := by
  change (treeOK (forms 13) 16 (1848072 ||| 2^15) q9Shape13T69 &&
    treeOK (forms 13) (16 ||| 2^15) 1848072 q9Shape13T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T69OK,q9Shape13T70OK⟩

private def q9Shape13T77 : Tree := (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 5 7 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 3) (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 4 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 4 5 8)))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape13T77OK : treeOK (forms 13) 8208 1839880 q9Shape13T77=true := by decide

private def q9Shape13T67 : Tree := .split 13 q9Shape13T68 q9Shape13T77
private theorem q9Shape13T67OK : treeOK (forms 13) 16 1839880 q9Shape13T67=true := by
  change (treeOK (forms 13) 16 (1839880 ||| 2^13) q9Shape13T68 &&
    treeOK (forms 13) (16 ||| 2^13) 1839880 q9Shape13T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T68OK,q9Shape13T77OK⟩

private def q9Shape13T83 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape13T83OK : treeOK (forms 13) 4112 1943336 q9Shape13T83=true := by decide

private def q9Shape13T84 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 2 4 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 4 8))))
private theorem q9Shape13T84OK : treeOK (forms 13) 5136 1942312 q9Shape13T84=true := by decide

private def q9Shape13T82 : Tree := .split 10 q9Shape13T83 q9Shape13T84
private theorem q9Shape13T82OK : treeOK (forms 13) 4112 1942312 q9Shape13T82=true := by
  change (treeOK (forms 13) 4112 (1942312 ||| 2^10) q9Shape13T83 &&
    treeOK (forms 13) (4112 ||| 2^10) 1942312 q9Shape13T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T83OK,q9Shape13T84OK⟩

private def q9Shape13T85 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape13T85OK : treeOK (forms 13) 4144 1942280 q9Shape13T85=true := by decide

private def q9Shape13T81 : Tree := .split 5 q9Shape13T82 q9Shape13T85
private theorem q9Shape13T81OK : treeOK (forms 13) 4112 1942280 q9Shape13T81=true := by
  change (treeOK (forms 13) 4112 (1942280 ||| 2^5) q9Shape13T82 &&
    treeOK (forms 13) (4112 ||| 2^5) 1942280 q9Shape13T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T82OK,q9Shape13T85OK⟩

private def q9Shape13T86 : Tree := (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 7 8))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 3) (some 6)))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 5 8))))
private theorem q9Shape13T86OK : treeOK (forms 13) 69648 1876744 q9Shape13T86=true := by decide

private def q9Shape13T80 : Tree := .split 16 q9Shape13T81 q9Shape13T86
private theorem q9Shape13T80OK : treeOK (forms 13) 4112 1876744 q9Shape13T80=true := by
  change (treeOK (forms 13) 4112 (1876744 ||| 2^16) q9Shape13T81 &&
    treeOK (forms 13) (4112 ||| 2^16) 1876744 q9Shape13T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T81OK,q9Shape13T86OK⟩

private def q9Shape13T87 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))))) (.tip (.cover 0 2 6 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 2 3 6)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape13T87OK : treeOK (forms 13) 36880 1843976 q9Shape13T87=true := by decide

private def q9Shape13T79 : Tree := .split 15 q9Shape13T80 q9Shape13T87
private theorem q9Shape13T79OK : treeOK (forms 13) 4112 1843976 q9Shape13T79=true := by
  change (treeOK (forms 13) 4112 (1843976 ||| 2^15) q9Shape13T80 &&
    treeOK (forms 13) (4112 ||| 2^15) 1843976 q9Shape13T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T80OK,q9Shape13T87OK⟩

private def q9Shape13T88 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape13T88OK : treeOK (forms 13) 12304 1835784 q9Shape13T88=true := by decide

private def q9Shape13T78 : Tree := .split 13 q9Shape13T79 q9Shape13T88
private theorem q9Shape13T78OK : treeOK (forms 13) 4112 1835784 q9Shape13T78=true := by
  change (treeOK (forms 13) 4112 (1835784 ||| 2^13) q9Shape13T79 &&
    treeOK (forms 13) (4112 ||| 2^13) 1835784 q9Shape13T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T79OK,q9Shape13T88OK⟩

private def q9Shape13T66 : Tree := .split 12 q9Shape13T67 q9Shape13T78
private theorem q9Shape13T66OK : treeOK (forms 13) 16 1835784 q9Shape13T66=true := by
  change (treeOK (forms 13) 16 (1835784 ||| 2^12) q9Shape13T67 &&
    treeOK (forms 13) (16 ||| 2^12) 1835784 q9Shape13T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T67OK,q9Shape13T78OK⟩

private def q9Shape13T90 : Tree := (.split 13 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 2 5 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 3 5 8))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 2 5 8))))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape13T90OK : treeOK (forms 13) 528 1839368 q9Shape13T90=true := by decide

private def q9Shape13T91 : Tree := (.split 13 (.split 15 (.split 16 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 1 2 4))))) (.tip (.cover 0 4 7 8))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape13T91OK : treeOK (forms 13) 4624 1835272 q9Shape13T91=true := by decide

private def q9Shape13T89 : Tree := .split 12 q9Shape13T90 q9Shape13T91
private theorem q9Shape13T89OK : treeOK (forms 13) 528 1835272 q9Shape13T89=true := by
  change (treeOK (forms 13) 528 (1835272 ||| 2^12) q9Shape13T90 &&
    treeOK (forms 13) (528 ||| 2^12) 1835272 q9Shape13T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T90OK,q9Shape13T91OK⟩

private def q9Shape13T65 : Tree := .split 9 q9Shape13T66 q9Shape13T89
private theorem q9Shape13T65OK : treeOK (forms 13) 16 1835272 q9Shape13T65=true := by
  change (treeOK (forms 13) 16 (1835272 ||| 2^9) q9Shape13T66 &&
    treeOK (forms 13) (16 ||| 2^9) 1835272 q9Shape13T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T66OK,q9Shape13T89OK⟩

private def q9Shape13T99 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 2 3 8))))
private theorem q9Shape13T99OK : treeOK (forms 13) 272 1947176 q9Shape13T99=true := by decide

private def q9Shape13T101 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape13T101OK : treeOK (forms 13) 1296 1962536 q9Shape13T101=true := by decide

private def q9Shape13T102 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 3 8)))
private theorem q9Shape13T102OK : treeOK (forms 13) 17680 1946152 q9Shape13T102=true := by decide

private def q9Shape13T100 : Tree := .split 14 q9Shape13T101 q9Shape13T102
private theorem q9Shape13T100OK : treeOK (forms 13) 1296 1946152 q9Shape13T100=true := by
  change (treeOK (forms 13) 1296 (1946152 ||| 2^14) q9Shape13T101 &&
    treeOK (forms 13) (1296 ||| 2^14) 1946152 q9Shape13T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T101OK,q9Shape13T102OK⟩

private def q9Shape13T98 : Tree := .split 10 q9Shape13T99 q9Shape13T100
private theorem q9Shape13T98OK : treeOK (forms 13) 272 1946152 q9Shape13T98=true := by
  change (treeOK (forms 13) 272 (1946152 ||| 2^10) q9Shape13T99 &&
    treeOK (forms 13) (272 ||| 2^10) 1946152 q9Shape13T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T99OK,q9Shape13T100OK⟩

private def q9Shape13T103 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 3 8)))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape13T103OK : treeOK (forms 13) 304 1946120 q9Shape13T103=true := by decide

private def q9Shape13T97 : Tree := .split 5 q9Shape13T98 q9Shape13T103
private theorem q9Shape13T97OK : treeOK (forms 13) 272 1946120 q9Shape13T97=true := by
  change (treeOK (forms 13) 272 (1946120 ||| 2^5) q9Shape13T98 &&
    treeOK (forms 13) (272 ||| 2^5) 1946120 q9Shape13T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T98OK,q9Shape13T103OK⟩

private def q9Shape13T104 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.tip (.cover 0 3 7 8))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 3 4 7)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape13T104OK : treeOK (forms 13) 65808 1880584 q9Shape13T104=true := by decide

private def q9Shape13T96 : Tree := .split 16 q9Shape13T97 q9Shape13T104
private theorem q9Shape13T96OK : treeOK (forms 13) 272 1880584 q9Shape13T96=true := by
  change (treeOK (forms 13) 272 (1880584 ||| 2^16) q9Shape13T97 &&
    treeOK (forms 13) (272 ||| 2^16) 1880584 q9Shape13T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T97OK,q9Shape13T104OK⟩

private def q9Shape13T105 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 2 6 8))) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7)))) (.tip (.cover 0 2 5 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 2 4 6))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape13T105OK : treeOK (forms 13) 33040 1847816 q9Shape13T105=true := by decide

private def q9Shape13T95 : Tree := .split 15 q9Shape13T96 q9Shape13T105
private theorem q9Shape13T95OK : treeOK (forms 13) 272 1847816 q9Shape13T95=true := by
  change (treeOK (forms 13) 272 (1847816 ||| 2^15) q9Shape13T96 &&
    treeOK (forms 13) (272 ||| 2^15) 1847816 q9Shape13T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T96OK,q9Shape13T105OK⟩

private def q9Shape13T106 : Tree := (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 3 5 7)) (.split 17 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 2 3 8)))) (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 6)) (.tip (.cover 0 3 4 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 8)))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 3 7 8))) (.tip (.cover 2 3 4 5)))
private theorem q9Shape13T106OK : treeOK (forms 13) 8464 1839624 q9Shape13T106=true := by decide

private def q9Shape13T94 : Tree := .split 13 q9Shape13T95 q9Shape13T106
private theorem q9Shape13T94OK : treeOK (forms 13) 272 1839624 q9Shape13T94=true := by
  change (treeOK (forms 13) 272 (1839624 ||| 2^13) q9Shape13T95 &&
    treeOK (forms 13) (272 ||| 2^13) 1839624 q9Shape13T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T95OK,q9Shape13T106OK⟩

private def q9Shape13T107 : Tree := (.split 13 (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 2 5 6)) (.split 17 (.tip (.cover 0 1 4 7)) (.tip (.cover 0 2 3 8)))) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.tip (.cover 0 2 4 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 3 4 5 7))) (.tip (.cover 0 2 3 8))))) (.split 10 (.split 14 (.tip (.cover 0 2 5 6)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape13T107OK : treeOK (forms 13) 4368 1835528 q9Shape13T107=true := by decide

private def q9Shape13T93 : Tree := .split 12 q9Shape13T94 q9Shape13T107
private theorem q9Shape13T93OK : treeOK (forms 13) 272 1835528 q9Shape13T93=true := by
  change (treeOK (forms 13) 272 (1835528 ||| 2^12) q9Shape13T94 &&
    treeOK (forms 13) (272 ||| 2^12) 1835528 q9Shape13T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T94OK,q9Shape13T107OK⟩

private def q9Shape13T108 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape13T108OK : treeOK (forms 13) 784 1835016 q9Shape13T108=true := by decide

private def q9Shape13T92 : Tree := .split 9 q9Shape13T93 q9Shape13T108
private theorem q9Shape13T92OK : treeOK (forms 13) 272 1835016 q9Shape13T92=true := by
  change (treeOK (forms 13) 272 (1835016 ||| 2^9) q9Shape13T93 &&
    treeOK (forms 13) (272 ||| 2^9) 1835016 q9Shape13T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T93OK,q9Shape13T108OK⟩

private def q9Shape13T64 : Tree := .split 8 q9Shape13T65 q9Shape13T92
private theorem q9Shape13T64OK : treeOK (forms 13) 16 1835016 q9Shape13T64=true := by
  change (treeOK (forms 13) 16 (1835016 ||| 2^8) q9Shape13T65 &&
    treeOK (forms 13) (16 ||| 2^8) 1835016 q9Shape13T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T65OK,q9Shape13T92OK⟩

private def q9Shape13T4 : Tree := .split 4 q9Shape13T5 q9Shape13T64
private theorem q9Shape13T4OK : treeOK (forms 13) 0 1835016 q9Shape13T4=true := by
  change (treeOK (forms 13) 0 (1835016 ||| 2^4) q9Shape13T5 &&
    treeOK (forms 13) (0 ||| 2^4) 1835016 q9Shape13T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T5OK,q9Shape13T64OK⟩

private def q9Shape13T116 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape13T116OK : treeOK (forms 13) 8 1946384 q9Shape13T116=true := by decide

private def q9Shape13T119 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape13T119OK : treeOK (forms 13) 65544 1881904 q9Shape13T119=true := by decide

private def q9Shape13T120 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 2 5 8)))
private theorem q9Shape13T120OK : treeOK (forms 13) 66568 1880880 q9Shape13T120=true := by decide

private def q9Shape13T118 : Tree := .split 10 q9Shape13T119 q9Shape13T120
private theorem q9Shape13T118OK : treeOK (forms 13) 65544 1880880 q9Shape13T118=true := by
  change (treeOK (forms 13) 65544 (1880880 ||| 2^10) q9Shape13T119 &&
    treeOK (forms 13) (65544 ||| 2^10) 1880880 q9Shape13T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T119OK,q9Shape13T120OK⟩

private def q9Shape13T121 : Tree := (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5)))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 2 5 8))))
private theorem q9Shape13T121OK : treeOK (forms 13) 65576 1880848 q9Shape13T121=true := by decide

private def q9Shape13T117 : Tree := .split 5 q9Shape13T118 q9Shape13T121
private theorem q9Shape13T117OK : treeOK (forms 13) 65544 1880848 q9Shape13T117=true := by
  change (treeOK (forms 13) 65544 (1880848 ||| 2^5) q9Shape13T118 &&
    treeOK (forms 13) (65544 ||| 2^5) 1880848 q9Shape13T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T118OK,q9Shape13T121OK⟩

private def q9Shape13T115 : Tree := .split 16 q9Shape13T116 q9Shape13T117
private theorem q9Shape13T115OK : treeOK (forms 13) 8 1880848 q9Shape13T115=true := by
  change (treeOK (forms 13) 8 (1880848 ||| 2^16) q9Shape13T116 &&
    treeOK (forms 13) (8 ||| 2^16) 1880848 q9Shape13T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T116OK,q9Shape13T117OK⟩

private def q9Shape13T122 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape13T122OK : treeOK (forms 13) 32776 1848080 q9Shape13T122=true := by decide

private def q9Shape13T114 : Tree := .split 15 q9Shape13T115 q9Shape13T122
private theorem q9Shape13T114OK : treeOK (forms 13) 8 1848080 q9Shape13T114=true := by
  change (treeOK (forms 13) 8 (1848080 ||| 2^15) q9Shape13T115 &&
    treeOK (forms 13) (8 ||| 2^15) 1848080 q9Shape13T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T115OK,q9Shape13T122OK⟩

private def q9Shape13T127 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape13T127OK : treeOK (forms 13) 8200 1939248 q9Shape13T127=true := by decide

private def q9Shape13T128 : Tree := (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 2 4 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 4 8))))
private theorem q9Shape13T128OK : treeOK (forms 13) 9224 1938224 q9Shape13T128=true := by decide

private def q9Shape13T126 : Tree := .split 10 q9Shape13T127 q9Shape13T128
private theorem q9Shape13T126OK : treeOK (forms 13) 8200 1938224 q9Shape13T126=true := by
  change (treeOK (forms 13) 8200 (1938224 ||| 2^10) q9Shape13T127 &&
    treeOK (forms 13) (8200 ||| 2^10) 1938224 q9Shape13T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T127OK,q9Shape13T128OK⟩

private def q9Shape13T129 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape13T129OK : treeOK (forms 13) 8232 1938192 q9Shape13T129=true := by decide

private def q9Shape13T125 : Tree := .split 5 q9Shape13T126 q9Shape13T129
private theorem q9Shape13T125OK : treeOK (forms 13) 8200 1938192 q9Shape13T125=true := by
  change (treeOK (forms 13) 8200 (1938192 ||| 2^5) q9Shape13T126 &&
    treeOK (forms 13) (8200 ||| 2^5) 1938192 q9Shape13T129)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T126OK,q9Shape13T129OK⟩

private def q9Shape13T130 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.split 17 (.tip (.cover 0 1 4 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))))) (.tip (.cover 0 2 7 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape13T130OK : treeOK (forms 13) 73736 1872656 q9Shape13T130=true := by decide

private def q9Shape13T124 : Tree := .split 16 q9Shape13T125 q9Shape13T130
private theorem q9Shape13T124OK : treeOK (forms 13) 8200 1872656 q9Shape13T124=true := by
  change (treeOK (forms 13) 8200 (1872656 ||| 2^16) q9Shape13T125 &&
    treeOK (forms 13) (8200 ||| 2^16) 1872656 q9Shape13T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T125OK,q9Shape13T130OK⟩

private def q9Shape13T131 : Tree := (.split 16 (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 4 6 8))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 2 3 5 7)))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 4 5 8)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape13T131OK : treeOK (forms 13) 40968 1839888 q9Shape13T131=true := by decide

private def q9Shape13T123 : Tree := .split 15 q9Shape13T124 q9Shape13T131
private theorem q9Shape13T123OK : treeOK (forms 13) 8200 1839888 q9Shape13T123=true := by
  change (treeOK (forms 13) 8200 (1839888 ||| 2^15) q9Shape13T124 &&
    treeOK (forms 13) (8200 ||| 2^15) 1839888 q9Shape13T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T124OK,q9Shape13T131OK⟩

private def q9Shape13T113 : Tree := .split 13 q9Shape13T114 q9Shape13T123
private theorem q9Shape13T113OK : treeOK (forms 13) 8 1839888 q9Shape13T113=true := by
  change (treeOK (forms 13) 8 (1839888 ||| 2^13) q9Shape13T114 &&
    treeOK (forms 13) (8 ||| 2^13) 1839888 q9Shape13T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T114OK,q9Shape13T123OK⟩

private def q9Shape13T132 : Tree := (.split 13 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 5 (.split 10 (.tip (.cover 0 1 4 5)) (.tip (.cover 0 5 6 8))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 7))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 4 7)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 4 5 8))))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape13T132OK : treeOK (forms 13) 4104 1835792 q9Shape13T132=true := by decide

private def q9Shape13T112 : Tree := .split 12 q9Shape13T113 q9Shape13T132
private theorem q9Shape13T112OK : treeOK (forms 13) 8 1835792 q9Shape13T112=true := by
  change (treeOK (forms 13) 8 (1835792 ||| 2^12) q9Shape13T113 &&
    treeOK (forms 13) (8 ||| 2^12) 1835792 q9Shape13T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T113OK,q9Shape13T132OK⟩

private def q9Shape13T139 : Tree := (.split 14 (.tip (.drop 7 8 (some 6) none)) (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.cover 0 2 3 8))))
private theorem q9Shape13T139OK : treeOK (forms 13) 520 1946928 q9Shape13T139=true := by decide

private def q9Shape13T141 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape13T141OK : treeOK (forms 13) 1544 1962288 q9Shape13T141=true := by decide

private def q9Shape13T142 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 3 8)))
private theorem q9Shape13T142OK : treeOK (forms 13) 17928 1945904 q9Shape13T142=true := by decide

private def q9Shape13T140 : Tree := .split 14 q9Shape13T141 q9Shape13T142
private theorem q9Shape13T140OK : treeOK (forms 13) 1544 1945904 q9Shape13T140=true := by
  change (treeOK (forms 13) 1544 (1945904 ||| 2^14) q9Shape13T141 &&
    treeOK (forms 13) (1544 ||| 2^14) 1945904 q9Shape13T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T141OK,q9Shape13T142OK⟩

private def q9Shape13T138 : Tree := .split 10 q9Shape13T139 q9Shape13T140
private theorem q9Shape13T138OK : treeOK (forms 13) 520 1945904 q9Shape13T138=true := by
  change (treeOK (forms 13) 520 (1945904 ||| 2^10) q9Shape13T139 &&
    treeOK (forms 13) (520 ||| 2^10) 1945904 q9Shape13T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T139OK,q9Shape13T140OK⟩

private def q9Shape13T143 : Tree := (.split 10 (.split 14 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))))) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 3 8)))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape13T143OK : treeOK (forms 13) 552 1945872 q9Shape13T143=true := by decide

private def q9Shape13T137 : Tree := .split 5 q9Shape13T138 q9Shape13T143
private theorem q9Shape13T137OK : treeOK (forms 13) 520 1945872 q9Shape13T137=true := by
  change (treeOK (forms 13) 520 (1945872 ||| 2^5) q9Shape13T138 &&
    treeOK (forms 13) (520 ||| 2^5) 1945872 q9Shape13T143)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T138OK,q9Shape13T143OK⟩

private def q9Shape13T144 : Tree := (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 6)) (.tip (.cover 0 2 7 8))) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))) (.tip (.cover 0 2 5 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 2 3))))
private theorem q9Shape13T144OK : treeOK (forms 13) 66056 1880336 q9Shape13T144=true := by decide

private def q9Shape13T136 : Tree := .split 16 q9Shape13T137 q9Shape13T144
private theorem q9Shape13T136OK : treeOK (forms 13) 520 1880336 q9Shape13T136=true := by
  change (treeOK (forms 13) 520 (1880336 ||| 2^16) q9Shape13T137 &&
    treeOK (forms 13) (520 ||| 2^16) 1880336 q9Shape13T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T137OK,q9Shape13T144OK⟩

private def q9Shape13T145 : Tree := (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 3 6 8))) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 3 4 6)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 7)))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape13T145OK : treeOK (forms 13) 33288 1847568 q9Shape13T145=true := by decide

private def q9Shape13T135 : Tree := .split 15 q9Shape13T136 q9Shape13T145
private theorem q9Shape13T135OK : treeOK (forms 13) 520 1847568 q9Shape13T135=true := by
  change (treeOK (forms 13) 520 (1847568 ||| 2^15) q9Shape13T136 &&
    treeOK (forms 13) (520 ||| 2^15) 1847568 q9Shape13T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T136OK,q9Shape13T145OK⟩

private def q9Shape13T146 : Tree := (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.split 17 (.tip (.cover 0 1 4 6)) (.tip (.cover 0 2 3 8)))) (.split 14 (.split 17 (.tip (.cover 0 1 3 6)) (.tip (.cover 0 2 4 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 3 8))))) (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.cover 0 1 2 4))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 0 2 7 8))) (.tip (.cover 2 3 4 5)))
private theorem q9Shape13T146OK : treeOK (forms 13) 8712 1839376 q9Shape13T146=true := by decide

private def q9Shape13T134 : Tree := .split 13 q9Shape13T135 q9Shape13T146
private theorem q9Shape13T134OK : treeOK (forms 13) 520 1839376 q9Shape13T134=true := by
  change (treeOK (forms 13) 520 (1839376 ||| 2^13) q9Shape13T135 &&
    treeOK (forms 13) (520 ||| 2^13) 1839376 q9Shape13T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T135OK,q9Shape13T146OK⟩

private def q9Shape13T147 : Tree := (.split 13 (.split 15 (.split 16 (.split 5 (.split 10 (.split 14 (.tip (.cover 0 3 5 6)) (.split 17 (.tip (.cover 0 1 4 7)) (.tip (.cover 0 2 3 8)))) (.split 14 (.tip (.cover 0 3 5 6)) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.tip (.cover 0 3 4 8))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 2 3 8)))) (.tip (.cover 0 1 2 3)))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 3 6 8))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape13T147OK : treeOK (forms 13) 4616 1835280 q9Shape13T147=true := by decide

private def q9Shape13T133 : Tree := .split 12 q9Shape13T134 q9Shape13T147
private theorem q9Shape13T133OK : treeOK (forms 13) 520 1835280 q9Shape13T133=true := by
  change (treeOK (forms 13) 520 (1835280 ||| 2^12) q9Shape13T134 &&
    treeOK (forms 13) (520 ||| 2^12) 1835280 q9Shape13T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T134OK,q9Shape13T147OK⟩

private def q9Shape13T111 : Tree := .split 9 q9Shape13T112 q9Shape13T133
private theorem q9Shape13T111OK : treeOK (forms 13) 8 1835280 q9Shape13T111=true := by
  change (treeOK (forms 13) 8 (1835280 ||| 2^9) q9Shape13T112 &&
    treeOK (forms 13) (8 ||| 2^9) 1835280 q9Shape13T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T112OK,q9Shape13T133OK⟩

private def q9Shape13T151 : Tree := (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 5 (.split 10 (.tip (.cover 0 4 5 6)) (.split 14 (.tip (.cover 0 1 3 5)) (.tip (.cover 0 2 5 8)))) (.split 10 (.split 14 (.tip (.cover 0 1 2 5)) (.tip (.cover 0 3 5 8))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 2 5 8)))))) (.tip (.cover 0 1 5 8)))
private theorem q9Shape13T151OK : treeOK (forms 13) 264 1847824 q9Shape13T151=true := by decide

private def q9Shape13T152 : Tree := (.split 15 (.split 16 (.split 5 (.split 10 (.tip (.cover 0 4 5 6)) (.split 14 (.split 17 (.tip (.cover 0 1 3 7)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 1 3 4)))) (.split 10 (.split 14 (.split 17 (.tip (.cover 0 1 2 7)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 1 2 4))) (.split 14 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 7))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 7)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 1 2 4))))) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 4 6 8)))
private theorem q9Shape13T152OK : treeOK (forms 13) 8456 1839632 q9Shape13T152=true := by decide

private def q9Shape13T150 : Tree := .split 13 q9Shape13T151 q9Shape13T152
private theorem q9Shape13T150OK : treeOK (forms 13) 264 1839632 q9Shape13T150=true := by
  change (treeOK (forms 13) 264 (1839632 ||| 2^13) q9Shape13T151 &&
    treeOK (forms 13) (264 ||| 2^13) 1839632 q9Shape13T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T151OK,q9Shape13T152OK⟩

private def q9Shape13T153 : Tree := (.split 13 (.tip (.cover 0 5 6 8)) (.tip (.cover 0 1 4 8)))
private theorem q9Shape13T153OK : treeOK (forms 13) 4360 1835536 q9Shape13T153=true := by decide

private def q9Shape13T149 : Tree := .split 12 q9Shape13T150 q9Shape13T153
private theorem q9Shape13T149OK : treeOK (forms 13) 264 1835536 q9Shape13T149=true := by
  change (treeOK (forms 13) 264 (1835536 ||| 2^12) q9Shape13T150 &&
    treeOK (forms 13) (264 ||| 2^12) 1835536 q9Shape13T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T150OK,q9Shape13T153OK⟩

private def q9Shape13T154 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape13T154OK : treeOK (forms 13) 776 1835024 q9Shape13T154=true := by decide

private def q9Shape13T148 : Tree := .split 9 q9Shape13T149 q9Shape13T154
private theorem q9Shape13T148OK : treeOK (forms 13) 264 1835024 q9Shape13T148=true := by
  change (treeOK (forms 13) 264 (1835024 ||| 2^9) q9Shape13T149 &&
    treeOK (forms 13) (264 ||| 2^9) 1835024 q9Shape13T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T149OK,q9Shape13T154OK⟩

private def q9Shape13T110 : Tree := .split 8 q9Shape13T111 q9Shape13T148
private theorem q9Shape13T110OK : treeOK (forms 13) 8 1835024 q9Shape13T110=true := by
  change (treeOK (forms 13) 8 (1835024 ||| 2^8) q9Shape13T111 &&
    treeOK (forms 13) (8 ||| 2^8) 1835024 q9Shape13T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T111OK,q9Shape13T148OK⟩

private def q9Shape13T155 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape13T155OK : treeOK (forms 13) 24 1835008 q9Shape13T155=true := by decide

private def q9Shape13T109 : Tree := .split 4 q9Shape13T110 q9Shape13T155
private theorem q9Shape13T109OK : treeOK (forms 13) 8 1835008 q9Shape13T109=true := by
  change (treeOK (forms 13) 8 (1835008 ||| 2^4) q9Shape13T110 &&
    treeOK (forms 13) (8 ||| 2^4) 1835008 q9Shape13T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T110OK,q9Shape13T155OK⟩

private def q9Shape13T3 : Tree := .split 3 q9Shape13T4 q9Shape13T109
private theorem q9Shape13T3OK : treeOK (forms 13) 0 1835008 q9Shape13T3=true := by
  change (treeOK (forms 13) 0 (1835008 ||| 2^3) q9Shape13T4 &&
    treeOK (forms 13) (0 ||| 2^3) 1835008 q9Shape13T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T4OK,q9Shape13T109OK⟩

private def q9Shape13T156 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape13T156OK : treeOK (forms 13) 1048576 786432 q9Shape13T156=true := by decide

private def q9Shape13T2 : Tree := .split 20 q9Shape13T3 q9Shape13T156
private theorem q9Shape13T2OK : treeOK (forms 13) 0 786432 q9Shape13T2=true := by
  change (treeOK (forms 13) 0 (786432 ||| 2^20) q9Shape13T3 &&
    treeOK (forms 13) (0 ||| 2^20) 786432 q9Shape13T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T3OK,q9Shape13T156OK⟩

private def q9Shape13T157 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape13T157OK : treeOK (forms 13) 524288 262144 q9Shape13T157=true := by decide

private def q9Shape13T1 : Tree := .split 19 q9Shape13T2 q9Shape13T157
private theorem q9Shape13T1OK : treeOK (forms 13) 0 262144 q9Shape13T1=true := by
  change (treeOK (forms 13) 0 (262144 ||| 2^19) q9Shape13T2 &&
    treeOK (forms 13) (0 ||| 2^19) 262144 q9Shape13T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T2OK,q9Shape13T157OK⟩

private def q9Shape13T158 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape13T158OK : treeOK (forms 13) 262144 0 q9Shape13T158=true := by decide

private def q9Shape13T0 : Tree := .split 18 q9Shape13T1 q9Shape13T158
private theorem q9Shape13T0OK : treeOK (forms 13) 0 0 q9Shape13T0=true := by
  change (treeOK (forms 13) 0 (0 ||| 2^18) q9Shape13T1 &&
    treeOK (forms 13) (0 ||| 2^18) 0 q9Shape13T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape13T1OK,q9Shape13T158OK⟩


theorem q9Shape13_cover (b : Nat→Bool) (H : Ranked (adj (forms 13) b)) :
    ∃ u v w z,Effective (adj (forms 13) b) (adj (forms 13) b) u v w z :=
  checked_tree (forms 13) b H q9Shape13T0 q9Shape13T0OK

#print axioms q9Shape13_cover
end Graffiti384b.Q9
