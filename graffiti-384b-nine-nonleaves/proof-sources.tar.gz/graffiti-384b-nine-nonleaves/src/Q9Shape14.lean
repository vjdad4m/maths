import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape14T8 : Tree := (.split 10 (.tip (.cover 0 1 4 5)) (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))))
private theorem q9Shape14T8OK : treeOK (forms 14) 0 1835832 q9Shape14T8=true := by decide

private def q9Shape14T9 : Tree := (.split 10 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 6)))
private theorem q9Shape14T9OK : treeOK (forms 14) 512 1835320 q9Shape14T9=true := by decide

private def q9Shape14T7 : Tree := .split 9 q9Shape14T8 q9Shape14T9
private theorem q9Shape14T7OK : treeOK (forms 14) 0 1835320 q9Shape14T7=true := by
  change (treeOK (forms 14) 0 (1835320 ||| 2^9) q9Shape14T8 &&
    treeOK (forms 14) (0 ||| 2^9) 1835320 q9Shape14T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T8OK,q9Shape14T9OK⟩

private def q9Shape14T10 : Tree := (.split 9 (.split 10 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 6)) (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8)))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape14T10OK : treeOK (forms 14) 256 1835064 q9Shape14T10=true := by decide

private def q9Shape14T6 : Tree := .split 8 q9Shape14T7 q9Shape14T10
private theorem q9Shape14T6OK : treeOK (forms 14) 0 1835064 q9Shape14T6=true := by
  change (treeOK (forms 14) 0 (1835064 ||| 2^8) q9Shape14T7 &&
    treeOK (forms 14) (0 ||| 2^8) 1835064 q9Shape14T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T7OK,q9Shape14T10OK⟩

private def q9Shape14T13 : Tree := (.split 10 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 4 5 8)))
private theorem q9Shape14T13OK : treeOK (forms 14) 32 1835800 q9Shape14T13=true := by decide

private def q9Shape14T14 : Tree := (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 5 7 8))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 3 6 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 6)))
private theorem q9Shape14T14OK : treeOK (forms 14) 544 1835288 q9Shape14T14=true := by decide

private def q9Shape14T12 : Tree := .split 9 q9Shape14T13 q9Shape14T14
private theorem q9Shape14T12OK : treeOK (forms 14) 32 1835288 q9Shape14T12=true := by
  change (treeOK (forms 14) 32 (1835288 ||| 2^9) q9Shape14T13 &&
    treeOK (forms 14) (32 ||| 2^9) 1835288 q9Shape14T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T13OK,q9Shape14T14OK⟩

private def q9Shape14T15 : Tree := (.split 9 (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 3 5 8))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 4 6 8))) (.tip (.cover 0 1 4 6)))) (.split 13 (.tip (.cover 0 5 6 8)) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape14T15OK : treeOK (forms 14) 288 1835032 q9Shape14T15=true := by decide

private def q9Shape14T11 : Tree := .split 8 q9Shape14T12 q9Shape14T15
private theorem q9Shape14T11OK : treeOK (forms 14) 32 1835032 q9Shape14T11=true := by
  change (treeOK (forms 14) 32 (1835032 ||| 2^8) q9Shape14T12 &&
    treeOK (forms 14) (32 ||| 2^8) 1835032 q9Shape14T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T12OK,q9Shape14T15OK⟩

private def q9Shape14T5 : Tree := .split 5 q9Shape14T6 q9Shape14T11
private theorem q9Shape14T5OK : treeOK (forms 14) 0 1835032 q9Shape14T5=true := by
  change (treeOK (forms 14) 0 (1835032 ||| 2^5) q9Shape14T6 &&
    treeOK (forms 14) (0 ||| 2^5) 1835032 q9Shape14T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T6OK,q9Shape14T11OK⟩

private def q9Shape14T20 : Tree := (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape14T20OK : treeOK (forms 14) 16 1836840 q9Shape14T20=true := by decide

private def q9Shape14T21 : Tree := (.split 12 (.split 13 (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 5 7 8))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape14T21OK : treeOK (forms 14) 1040 1835816 q9Shape14T21=true := by decide

private def q9Shape14T19 : Tree := .split 10 q9Shape14T20 q9Shape14T21
private theorem q9Shape14T19OK : treeOK (forms 14) 16 1835816 q9Shape14T19=true := by
  change (treeOK (forms 14) 16 (1835816 ||| 2^10) q9Shape14T20 &&
    treeOK (forms 14) (16 ||| 2^10) 1835816 q9Shape14T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T20OK,q9Shape14T21OK⟩

private def q9Shape14T22 : Tree := (.split 10 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.tip (.cover 1 5 6 7)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 6)))
private theorem q9Shape14T22OK : treeOK (forms 14) 528 1835304 q9Shape14T22=true := by decide

private def q9Shape14T18 : Tree := .split 9 q9Shape14T19 q9Shape14T22
private theorem q9Shape14T18OK : treeOK (forms 14) 16 1835304 q9Shape14T18=true := by
  change (treeOK (forms 14) 16 (1835304 ||| 2^9) q9Shape14T19 &&
    treeOK (forms 14) (16 ||| 2^9) 1835304 q9Shape14T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T19OK,q9Shape14T22OK⟩

private def q9Shape14T23 : Tree := (.split 9 (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 2 6 8)))) (.split 14 (.tip (.cover 1 5 6 7)) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.tip (.cover 1 5 6 7)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape14T23OK : treeOK (forms 14) 272 1835048 q9Shape14T23=true := by decide

private def q9Shape14T17 : Tree := .split 8 q9Shape14T18 q9Shape14T23
private theorem q9Shape14T17OK : treeOK (forms 14) 16 1835048 q9Shape14T17=true := by
  change (treeOK (forms 14) 16 (1835048 ||| 2^8) q9Shape14T18 &&
    treeOK (forms 14) (16 ||| 2^8) 1835048 q9Shape14T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T18OK,q9Shape14T23OK⟩

private def q9Shape14T24 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape14T24OK : treeOK (forms 14) 48 1835016 q9Shape14T24=true := by decide

private def q9Shape14T16 : Tree := .split 5 q9Shape14T17 q9Shape14T24
private theorem q9Shape14T16OK : treeOK (forms 14) 16 1835016 q9Shape14T16=true := by
  change (treeOK (forms 14) 16 (1835016 ||| 2^5) q9Shape14T17 &&
    treeOK (forms 14) (16 ||| 2^5) 1835016 q9Shape14T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T17OK,q9Shape14T24OK⟩

private def q9Shape14T4 : Tree := .split 4 q9Shape14T5 q9Shape14T16
private theorem q9Shape14T4OK : treeOK (forms 14) 0 1835016 q9Shape14T4=true := by
  change (treeOK (forms 14) 0 (1835016 ||| 2^4) q9Shape14T5 &&
    treeOK (forms 14) (0 ||| 2^4) 1835016 q9Shape14T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T5OK,q9Shape14T16OK⟩

private def q9Shape14T30 : Tree := (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 6)) (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8)))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 5)))
private theorem q9Shape14T30OK : treeOK (forms 14) 8 1836848 q9Shape14T30=true := by decide

private def q9Shape14T31 : Tree := (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 2 5 8))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 4 6 8))) (.tip (.cover 0 1 4 6)))) (.split 13 (.tip (.cover 0 5 6 8)) (.tip (.cover 0 1 4 8))))
private theorem q9Shape14T31OK : treeOK (forms 14) 1032 1835824 q9Shape14T31=true := by decide

private def q9Shape14T29 : Tree := .split 10 q9Shape14T30 q9Shape14T31
private theorem q9Shape14T29OK : treeOK (forms 14) 8 1835824 q9Shape14T29=true := by
  change (treeOK (forms 14) 8 (1835824 ||| 2^10) q9Shape14T30 &&
    treeOK (forms 14) (8 ||| 2^10) 1835824 q9Shape14T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T30OK,q9Shape14T31OK⟩

private def q9Shape14T32 : Tree := (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 3 6 8)))) (.split 14 (.tip (.cover 1 5 6 7)) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.tip (.cover 1 5 6 7)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 6)))
private theorem q9Shape14T32OK : treeOK (forms 14) 520 1835312 q9Shape14T32=true := by decide

private def q9Shape14T28 : Tree := .split 9 q9Shape14T29 q9Shape14T32
private theorem q9Shape14T28OK : treeOK (forms 14) 8 1835312 q9Shape14T28=true := by
  change (treeOK (forms 14) 8 (1835312 ||| 2^9) q9Shape14T29 &&
    treeOK (forms 14) (8 ||| 2^9) 1835312 q9Shape14T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T29OK,q9Shape14T32OK⟩

private def q9Shape14T33 : Tree := (.split 9 (.split 10 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 6)) (.tip (.cover 0 5 6 8))) (.split 14 (.tip (.cover 1 5 6 7)) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape14T33OK : treeOK (forms 14) 264 1835056 q9Shape14T33=true := by decide

private def q9Shape14T27 : Tree := .split 8 q9Shape14T28 q9Shape14T33
private theorem q9Shape14T27OK : treeOK (forms 14) 8 1835056 q9Shape14T27=true := by
  change (treeOK (forms 14) 8 (1835056 ||| 2^8) q9Shape14T28 &&
    treeOK (forms 14) (8 ||| 2^8) 1835056 q9Shape14T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T28OK,q9Shape14T33OK⟩

private def q9Shape14T34 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape14T34OK : treeOK (forms 14) 40 1835024 q9Shape14T34=true := by decide

private def q9Shape14T26 : Tree := .split 5 q9Shape14T27 q9Shape14T34
private theorem q9Shape14T26OK : treeOK (forms 14) 8 1835024 q9Shape14T26=true := by
  change (treeOK (forms 14) 8 (1835024 ||| 2^5) q9Shape14T27 &&
    treeOK (forms 14) (8 ||| 2^5) 1835024 q9Shape14T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T27OK,q9Shape14T34OK⟩

private def q9Shape14T35 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape14T35OK : treeOK (forms 14) 24 1835008 q9Shape14T35=true := by decide

private def q9Shape14T25 : Tree := .split 4 q9Shape14T26 q9Shape14T35
private theorem q9Shape14T25OK : treeOK (forms 14) 8 1835008 q9Shape14T25=true := by
  change (treeOK (forms 14) 8 (1835008 ||| 2^4) q9Shape14T26 &&
    treeOK (forms 14) (8 ||| 2^4) 1835008 q9Shape14T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T26OK,q9Shape14T35OK⟩

private def q9Shape14T3 : Tree := .split 3 q9Shape14T4 q9Shape14T25
private theorem q9Shape14T3OK : treeOK (forms 14) 0 1835008 q9Shape14T3=true := by
  change (treeOK (forms 14) 0 (1835008 ||| 2^3) q9Shape14T4 &&
    treeOK (forms 14) (0 ||| 2^3) 1835008 q9Shape14T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T4OK,q9Shape14T25OK⟩

private def q9Shape14T36 : Tree := (.tip (.cover 0 1 6 7))
private theorem q9Shape14T36OK : treeOK (forms 14) 1048576 786432 q9Shape14T36=true := by decide

private def q9Shape14T2 : Tree := .split 20 q9Shape14T3 q9Shape14T36
private theorem q9Shape14T2OK : treeOK (forms 14) 0 786432 q9Shape14T2=true := by
  change (treeOK (forms 14) 0 (786432 ||| 2^20) q9Shape14T3 &&
    treeOK (forms 14) (0 ||| 2^20) 786432 q9Shape14T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T3OK,q9Shape14T36OK⟩

private def q9Shape14T37 : Tree := (.tip (.cover 0 1 6 7))
private theorem q9Shape14T37OK : treeOK (forms 14) 524288 262144 q9Shape14T37=true := by decide

private def q9Shape14T1 : Tree := .split 19 q9Shape14T2 q9Shape14T37
private theorem q9Shape14T1OK : treeOK (forms 14) 0 262144 q9Shape14T1=true := by
  change (treeOK (forms 14) 0 (262144 ||| 2^19) q9Shape14T2 &&
    treeOK (forms 14) (0 ||| 2^19) 262144 q9Shape14T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T2OK,q9Shape14T37OK⟩

private def q9Shape14T38 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape14T38OK : treeOK (forms 14) 262144 0 q9Shape14T38=true := by decide

private def q9Shape14T0 : Tree := .split 18 q9Shape14T1 q9Shape14T38
private theorem q9Shape14T0OK : treeOK (forms 14) 0 0 q9Shape14T0=true := by
  change (treeOK (forms 14) 0 (0 ||| 2^18) q9Shape14T1 &&
    treeOK (forms 14) (0 ||| 2^18) 0 q9Shape14T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape14T1OK,q9Shape14T38OK⟩


theorem q9Shape14_cover (b : Nat→Bool) (H : Ranked (adj (forms 14) b)) :
    ∃ u v w z,Effective (adj (forms 14) b) (adj (forms 14) b) u v w z :=
  checked_tree (forms 14) b H q9Shape14T0 q9Shape14T0OK

#print axioms q9Shape14_cover
end Graffiti384b.Q9
