import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape15T8 : Tree := (.split 10 (.tip (.cover 0 1 4 5)) (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))))
private theorem q9Shape15T8OK : treeOK (forms 15) 0 1835832 q9Shape15T8=true := by decide

private def q9Shape15T9 : Tree := (.split 10 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 6)))
private theorem q9Shape15T9OK : treeOK (forms 15) 512 1835320 q9Shape15T9=true := by decide

private def q9Shape15T7 : Tree := .split 9 q9Shape15T8 q9Shape15T9
private theorem q9Shape15T7OK : treeOK (forms 15) 0 1835320 q9Shape15T7=true := by
  change (treeOK (forms 15) 0 (1835320 ||| 2^9) q9Shape15T8 &&
    treeOK (forms 15) (0 ||| 2^9) 1835320 q9Shape15T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T8OK,q9Shape15T9OK⟩

private def q9Shape15T10 : Tree := (.split 9 (.split 10 (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 6)) (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8)))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 5))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape15T10OK : treeOK (forms 15) 256 1835064 q9Shape15T10=true := by decide

private def q9Shape15T6 : Tree := .split 8 q9Shape15T7 q9Shape15T10
private theorem q9Shape15T6OK : treeOK (forms 15) 0 1835064 q9Shape15T6=true := by
  change (treeOK (forms 15) 0 (1835064 ||| 2^8) q9Shape15T7 &&
    treeOK (forms 15) (0 ||| 2^8) 1835064 q9Shape15T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T7OK,q9Shape15T10OK⟩

private def q9Shape15T13 : Tree := (.split 10 (.split 12 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 4 5 8)))
private theorem q9Shape15T13OK : treeOK (forms 15) 32 1835800 q9Shape15T13=true := by decide

private def q9Shape15T14 : Tree := (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 2 5 7))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 6)))
private theorem q9Shape15T14OK : treeOK (forms 15) 544 1835288 q9Shape15T14=true := by decide

private def q9Shape15T12 : Tree := .split 9 q9Shape15T13 q9Shape15T14
private theorem q9Shape15T12OK : treeOK (forms 15) 32 1835288 q9Shape15T12=true := by
  change (treeOK (forms 15) 32 (1835288 ||| 2^9) q9Shape15T13 &&
    treeOK (forms 15) (32 ||| 2^9) 1835288 q9Shape15T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T13OK,q9Shape15T14OK⟩

private def q9Shape15T15 : Tree := (.split 9 (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 3 5 8))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 2 4 6))) (.tip (.cover 0 1 4 6)))) (.split 13 (.tip (.cover 0 2 5 6)) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape15T15OK : treeOK (forms 15) 288 1835032 q9Shape15T15=true := by decide

private def q9Shape15T11 : Tree := .split 8 q9Shape15T12 q9Shape15T15
private theorem q9Shape15T11OK : treeOK (forms 15) 32 1835032 q9Shape15T11=true := by
  change (treeOK (forms 15) 32 (1835032 ||| 2^8) q9Shape15T12 &&
    treeOK (forms 15) (32 ||| 2^8) 1835032 q9Shape15T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T12OK,q9Shape15T15OK⟩

private def q9Shape15T5 : Tree := .split 5 q9Shape15T6 q9Shape15T11
private theorem q9Shape15T5OK : treeOK (forms 15) 0 1835032 q9Shape15T5=true := by
  change (treeOK (forms 15) 0 (1835032 ||| 2^5) q9Shape15T6 &&
    treeOK (forms 15) (0 ||| 2^5) 1835032 q9Shape15T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T6OK,q9Shape15T11OK⟩

private def q9Shape15T20 : Tree := (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.tip (.cover 0 1 4 5))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape15T20OK : treeOK (forms 15) 16 1836840 q9Shape15T20=true := by decide

private def q9Shape15T21 : Tree := (.split 12 (.split 13 (.split 14 (.split 15 (.tip (.cover 0 1 7 8)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 3 5 7))) (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 2 3 6))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape15T21OK : treeOK (forms 15) 1040 1835816 q9Shape15T21=true := by decide

private def q9Shape15T19 : Tree := .split 10 q9Shape15T20 q9Shape15T21
private theorem q9Shape15T19OK : treeOK (forms 15) 16 1835816 q9Shape15T19=true := by
  change (treeOK (forms 15) 16 (1835816 ||| 2^10) q9Shape15T20 &&
    treeOK (forms 15) (16 ||| 2^10) 1835816 q9Shape15T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T20OK,q9Shape15T21OK⟩

private def q9Shape15T22 : Tree := (.split 10 (.tip (.cover 0 4 5 7)) (.tip (.cover 0 1 3 6)))
private theorem q9Shape15T22OK : treeOK (forms 15) 528 1835304 q9Shape15T22=true := by decide

private def q9Shape15T18 : Tree := .split 9 q9Shape15T19 q9Shape15T22
private theorem q9Shape15T18OK : treeOK (forms 15) 16 1835304 q9Shape15T18=true := by
  change (treeOK (forms 15) 16 (1835304 ||| 2^9) q9Shape15T19 &&
    treeOK (forms 15) (16 ||| 2^9) 1835304 q9Shape15T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T19OK,q9Shape15T22OK⟩

private def q9Shape15T23 : Tree := (.split 9 (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 2 4 6)))) (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.tip (.cover 0 2 5 6)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape15T23OK : treeOK (forms 15) 272 1835048 q9Shape15T23=true := by decide

private def q9Shape15T17 : Tree := .split 8 q9Shape15T18 q9Shape15T23
private theorem q9Shape15T17OK : treeOK (forms 15) 16 1835048 q9Shape15T17=true := by
  change (treeOK (forms 15) 16 (1835048 ||| 2^8) q9Shape15T18 &&
    treeOK (forms 15) (16 ||| 2^8) 1835048 q9Shape15T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T18OK,q9Shape15T23OK⟩

private def q9Shape15T24 : Tree := (.tip (.cover 0 1 2 6))
private theorem q9Shape15T24OK : treeOK (forms 15) 48 1835016 q9Shape15T24=true := by decide

private def q9Shape15T16 : Tree := .split 5 q9Shape15T17 q9Shape15T24
private theorem q9Shape15T16OK : treeOK (forms 15) 16 1835016 q9Shape15T16=true := by
  change (treeOK (forms 15) 16 (1835016 ||| 2^5) q9Shape15T17 &&
    treeOK (forms 15) (16 ||| 2^5) 1835016 q9Shape15T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T17OK,q9Shape15T24OK⟩

private def q9Shape15T4 : Tree := .split 4 q9Shape15T5 q9Shape15T16
private theorem q9Shape15T4OK : treeOK (forms 15) 0 1835016 q9Shape15T4=true := by
  change (treeOK (forms 15) 0 (1835016 ||| 2^4) q9Shape15T5 &&
    treeOK (forms 15) (0 ||| 2^4) 1835016 q9Shape15T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T5OK,q9Shape15T16OK⟩

private def q9Shape15T30 : Tree := (.split 12 (.split 13 (.split 14 (.tip (.cover 0 1 5 6)) (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8)))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 4 6)))) (.tip (.cover 0 1 4 5)))
private theorem q9Shape15T30OK : treeOK (forms 15) 8 1836848 q9Shape15T30=true := by decide

private def q9Shape15T31 : Tree := (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 6)))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 2 5 8))) (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 3 4 6))) (.tip (.cover 0 1 4 6)))) (.split 13 (.tip (.cover 0 3 5 6)) (.tip (.cover 0 1 4 8))))
private theorem q9Shape15T31OK : treeOK (forms 15) 1032 1835824 q9Shape15T31=true := by decide

private def q9Shape15T29 : Tree := .split 10 q9Shape15T30 q9Shape15T31
private theorem q9Shape15T29OK : treeOK (forms 15) 8 1835824 q9Shape15T29=true := by
  change (treeOK (forms 15) 8 (1835824 ||| 2^10) q9Shape15T30 &&
    treeOK (forms 15) (8 ||| 2^10) 1835824 q9Shape15T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T30OK,q9Shape15T31OK⟩

private def q9Shape15T32 : Tree := (.split 10 (.split 12 (.split 13 (.split 14 (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 1 5 6))) (.tip (.cover 0 1 5 7))) (.split 15 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 3 4 6)))) (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.cover 0 1 4 6)))) (.split 13 (.split 14 (.tip (.cover 0 3 5 6)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))) (.tip (.cover 0 1 3 6)))
private theorem q9Shape15T32OK : treeOK (forms 15) 520 1835312 q9Shape15T32=true := by decide

private def q9Shape15T28 : Tree := .split 9 q9Shape15T29 q9Shape15T32
private theorem q9Shape15T28OK : treeOK (forms 15) 8 1835312 q9Shape15T28=true := by
  change (treeOK (forms 15) 8 (1835312 ||| 2^9) q9Shape15T29 &&
    treeOK (forms 15) (8 ||| 2^9) 1835312 q9Shape15T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T29OK,q9Shape15T32OK⟩

private def q9Shape15T33 : Tree := (.split 9 (.split 10 (.tip (.cover 0 4 5 6)) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape15T33OK : treeOK (forms 15) 264 1835056 q9Shape15T33=true := by decide

private def q9Shape15T27 : Tree := .split 8 q9Shape15T28 q9Shape15T33
private theorem q9Shape15T27OK : treeOK (forms 15) 8 1835056 q9Shape15T27=true := by
  change (treeOK (forms 15) 8 (1835056 ||| 2^8) q9Shape15T28 &&
    treeOK (forms 15) (8 ||| 2^8) 1835056 q9Shape15T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T28OK,q9Shape15T33OK⟩

private def q9Shape15T34 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape15T34OK : treeOK (forms 15) 40 1835024 q9Shape15T34=true := by decide

private def q9Shape15T26 : Tree := .split 5 q9Shape15T27 q9Shape15T34
private theorem q9Shape15T26OK : treeOK (forms 15) 8 1835024 q9Shape15T26=true := by
  change (treeOK (forms 15) 8 (1835024 ||| 2^5) q9Shape15T27 &&
    treeOK (forms 15) (8 ||| 2^5) 1835024 q9Shape15T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T27OK,q9Shape15T34OK⟩

private def q9Shape15T35 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape15T35OK : treeOK (forms 15) 24 1835008 q9Shape15T35=true := by decide

private def q9Shape15T25 : Tree := .split 4 q9Shape15T26 q9Shape15T35
private theorem q9Shape15T25OK : treeOK (forms 15) 8 1835008 q9Shape15T25=true := by
  change (treeOK (forms 15) 8 (1835008 ||| 2^4) q9Shape15T26 &&
    treeOK (forms 15) (8 ||| 2^4) 1835008 q9Shape15T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T26OK,q9Shape15T35OK⟩

private def q9Shape15T3 : Tree := .split 3 q9Shape15T4 q9Shape15T25
private theorem q9Shape15T3OK : treeOK (forms 15) 0 1835008 q9Shape15T3=true := by
  change (treeOK (forms 15) 0 (1835008 ||| 2^3) q9Shape15T4 &&
    treeOK (forms 15) (0 ||| 2^3) 1835008 q9Shape15T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T4OK,q9Shape15T25OK⟩

private def q9Shape15T36 : Tree := (.tip (.cover 0 1 6 7))
private theorem q9Shape15T36OK : treeOK (forms 15) 1048576 786432 q9Shape15T36=true := by decide

private def q9Shape15T2 : Tree := .split 20 q9Shape15T3 q9Shape15T36
private theorem q9Shape15T2OK : treeOK (forms 15) 0 786432 q9Shape15T2=true := by
  change (treeOK (forms 15) 0 (786432 ||| 2^20) q9Shape15T3 &&
    treeOK (forms 15) (0 ||| 2^20) 786432 q9Shape15T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T3OK,q9Shape15T36OK⟩

private def q9Shape15T37 : Tree := (.tip (.cover 0 1 6 7))
private theorem q9Shape15T37OK : treeOK (forms 15) 524288 262144 q9Shape15T37=true := by decide

private def q9Shape15T1 : Tree := .split 19 q9Shape15T2 q9Shape15T37
private theorem q9Shape15T1OK : treeOK (forms 15) 0 262144 q9Shape15T1=true := by
  change (treeOK (forms 15) 0 (262144 ||| 2^19) q9Shape15T2 &&
    treeOK (forms 15) (0 ||| 2^19) 262144 q9Shape15T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T2OK,q9Shape15T37OK⟩

private def q9Shape15T38 : Tree := (.tip (.cover 0 1 6 8))
private theorem q9Shape15T38OK : treeOK (forms 15) 262144 0 q9Shape15T38=true := by decide

private def q9Shape15T0 : Tree := .split 18 q9Shape15T1 q9Shape15T38
private theorem q9Shape15T0OK : treeOK (forms 15) 0 0 q9Shape15T0=true := by
  change (treeOK (forms 15) 0 (0 ||| 2^18) q9Shape15T1 &&
    treeOK (forms 15) (0 ||| 2^18) 0 q9Shape15T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape15T1OK,q9Shape15T38OK⟩


theorem q9Shape15_cover (b : Nat→Bool) (H : Ranked (adj (forms 15) b)) :
    ∃ u v w z,Effective (adj (forms 15) b) (adj (forms 15) b) u v w z :=
  checked_tree (forms 15) b H q9Shape15T0 q9Shape15T0OK

#print axioms q9Shape15_cover
end Graffiti384b.Q9
