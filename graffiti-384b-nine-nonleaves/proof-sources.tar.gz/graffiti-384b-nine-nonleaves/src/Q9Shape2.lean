import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape2T3 : Tree := (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.unordered 3 4 1))))))))
private theorem q9Shape2T3OK : treeOK (forms 2) 0 7 q9Shape2T3=true := by decide

private def q9Shape2T5 : Tree := (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover 5 6 7 8)))))))
private theorem q9Shape2T5OK : treeOK (forms 2) 4 67 q9Shape2T5=true := by decide

private def q9Shape2T6 : Tree := (.split 7 (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 4 5 1))))))) (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 3 5 1)))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.unordered 3 4 1)))) (.split 10 (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 4 5 1)))) (.split 14 (.split 17 (.tip (.small 1)) (.tip (.unordered 3 5 1))) (.tip (.cover 5 6 7 8)))))))
private theorem q9Shape2T6OK : treeOK (forms 2) 68 3 q9Shape2T6=true := by decide

private def q9Shape2T4 : Tree := .split 6 q9Shape2T5 q9Shape2T6
private theorem q9Shape2T4OK : treeOK (forms 2) 4 3 q9Shape2T4=true := by
  change (treeOK (forms 2) 4 (3 ||| 2^6) q9Shape2T5 &&
    treeOK (forms 2) (4 ||| 2^6) 3 q9Shape2T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T5OK,q9Shape2T6OK⟩

private def q9Shape2T2 : Tree := .split 2 q9Shape2T3 q9Shape2T4
private theorem q9Shape2T2OK : treeOK (forms 2) 0 3 q9Shape2T2=true := by
  change (treeOK (forms 2) 0 (3 ||| 2^2) q9Shape2T3 &&
    treeOK (forms 2) (0 ||| 2^2) 3 q9Shape2T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T3OK,q9Shape2T4OK⟩

private def q9Shape2T9 : Tree := (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 4 5 1))))))))
private theorem q9Shape2T9OK : treeOK (forms 2) 2 69 q9Shape2T9=true := by decide

private def q9Shape2T10 : Tree := (.split 7 (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover 1 4 6 7)))))) (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 3 4 1)))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.unordered 3 4 1)))) (.split 10 (.split 14 (.tip (.small 1)) (.tip (.cover 1 4 6 7))) (.split 14 (.split 17 (.tip (.small 1)) (.tip (.unordered 3 4 1))) (.tip (.cover 1 4 6 7)))))))
private theorem q9Shape2T10OK : treeOK (forms 2) 66 5 q9Shape2T10=true := by decide

private def q9Shape2T8 : Tree := .split 6 q9Shape2T9 q9Shape2T10
private theorem q9Shape2T8OK : treeOK (forms 2) 2 5 q9Shape2T8=true := by
  change (treeOK (forms 2) 2 (5 ||| 2^6) q9Shape2T9 &&
    treeOK (forms 2) (2 ||| 2^6) 5 q9Shape2T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T9OK,q9Shape2T10OK⟩

private def q9Shape2T12 : Tree := (.split 7 (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.unordered 2 4 1)))))) (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 5 1)))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 4 5 1))))) (.split 10 (.split 14 (.tip (.small 1)) (.tip (.unordered 2 4 1))) (.split 14 (.split 17 (.tip (.small 1)) (.tip (.unordered 2 5 1))) (.tip (.cover 5 6 7 8)))))))
private theorem q9Shape2T12OK : treeOK (forms 2) 6 65 q9Shape2T12=true := by decide

private def q9Shape2T14 : Tree := (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 4 1)))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover 1 4 6 7)))) (.split 10 (.split 14 (.tip (.small 1)) (.tip (.unordered 2 4 1))) (.split 14 (.split 17 (.tip (.small 1)) (.tip (.unordered 2 4 1))) (.tip (.cover 1 4 6 7))))))
private theorem q9Shape2T14OK : treeOK (forms 2) 70 129 q9Shape2T14=true := by decide

private def q9Shape2T15 : Tree := (.split 11 (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 4 5 6 7))))) (.split 10 (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 4 5 6 7)))) (.tip (.cover 2 3 6 7)))) (.split 5 (.tip (.unordered 4 5 1)) (.split 10 (.tip (.unordered 4 5 1)) (.tip (.cover 2 3 6 7)))))
private theorem q9Shape2T15OK : treeOK (forms 2) 198 1 q9Shape2T15=true := by decide

private def q9Shape2T13 : Tree := .split 7 q9Shape2T14 q9Shape2T15
private theorem q9Shape2T13OK : treeOK (forms 2) 70 1 q9Shape2T13=true := by
  change (treeOK (forms 2) 70 (1 ||| 2^7) q9Shape2T14 &&
    treeOK (forms 2) (70 ||| 2^7) 1 q9Shape2T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T14OK,q9Shape2T15OK⟩

private def q9Shape2T11 : Tree := .split 6 q9Shape2T12 q9Shape2T13
private theorem q9Shape2T11OK : treeOK (forms 2) 6 1 q9Shape2T11=true := by
  change (treeOK (forms 2) 6 (1 ||| 2^6) q9Shape2T12 &&
    treeOK (forms 2) (6 ||| 2^6) 1 q9Shape2T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T12OK,q9Shape2T13OK⟩

private def q9Shape2T7 : Tree := .split 2 q9Shape2T8 q9Shape2T11
private theorem q9Shape2T7OK : treeOK (forms 2) 2 1 q9Shape2T7=true := by
  change (treeOK (forms 2) 2 (1 ||| 2^2) q9Shape2T8 &&
    treeOK (forms 2) (2 ||| 2^2) 1 q9Shape2T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T8OK,q9Shape2T11OK⟩

private def q9Shape2T1 : Tree := .split 1 q9Shape2T2 q9Shape2T7
private theorem q9Shape2T1OK : treeOK (forms 2) 0 1 q9Shape2T1=true := by
  change (treeOK (forms 2) 0 (1 ||| 2^1) q9Shape2T2 &&
    treeOK (forms 2) (0 ||| 2^1) 1 q9Shape2T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T2OK,q9Shape2T7OK⟩

private def q9Shape2T19 : Tree := (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 3 5 1))))))))
private theorem q9Shape2T19OK : treeOK (forms 2) 1 70 q9Shape2T19=true := by decide

private def q9Shape2T20 : Tree := (.split 7 (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 3 4 1))))))) (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.cover 1 3 6 7)))) (.split 5 (.split 10 (.tip (.small 1)) (.tip (.cover 1 3 6 7))) (.split 10 (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 3 4 1)))) (.tip (.cover 1 3 6 7))))))
private theorem q9Shape2T20OK : treeOK (forms 2) 65 6 q9Shape2T20=true := by decide

private def q9Shape2T18 : Tree := .split 6 q9Shape2T19 q9Shape2T20
private theorem q9Shape2T18OK : treeOK (forms 2) 1 6 q9Shape2T18=true := by
  change (treeOK (forms 2) 1 (6 ||| 2^6) q9Shape2T19 &&
    treeOK (forms 2) (1 ||| 2^6) 6 q9Shape2T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T19OK,q9Shape2T20OK⟩

private def q9Shape2T22 : Tree := (.split 7 (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 5 1))))))) (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 1)))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 3 5 1))))) (.split 10 (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 5 1)))) (.split 14 (.tip (.unordered 2 3 1)) (.tip (.cover 5 6 7 8)))))))
private theorem q9Shape2T22OK : treeOK (forms 2) 5 66 q9Shape2T22=true := by decide

private def q9Shape2T24 : Tree := (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 3 1)))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 3 5 6 7))))) (.split 10 (.split 14 (.tip (.small 1)) (.tip (.cover 2 4 6 7))) (.split 14 (.split 17 (.tip (.small 1)) (.tip (.cover 3 5 6 7))) (.tip (.cover 2 4 6 7))))))
private theorem q9Shape2T24OK : treeOK (forms 2) 69 130 q9Shape2T24=true := by decide

private def q9Shape2T25 : Tree := (.split 11 (.split 5 (.split 10 (.tip (.small 1)) (.tip (.cover 1 3 6 7))) (.split 10 (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 3 1)))) (.tip (.cover 1 3 6 7)))) (.split 5 (.tip (.unordered 3 5 1)) (.split 10 (.tip (.unordered 3 5 1)) (.tip (.cover 1 3 6 7)))))
private theorem q9Shape2T25OK : treeOK (forms 2) 197 2 q9Shape2T25=true := by decide

private def q9Shape2T23 : Tree := .split 7 q9Shape2T24 q9Shape2T25
private theorem q9Shape2T23OK : treeOK (forms 2) 69 2 q9Shape2T23=true := by
  change (treeOK (forms 2) 69 (2 ||| 2^7) q9Shape2T24 &&
    treeOK (forms 2) (69 ||| 2^7) 2 q9Shape2T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T24OK,q9Shape2T25OK⟩

private def q9Shape2T21 : Tree := .split 6 q9Shape2T22 q9Shape2T23
private theorem q9Shape2T21OK : treeOK (forms 2) 5 2 q9Shape2T21=true := by
  change (treeOK (forms 2) 5 (2 ||| 2^6) q9Shape2T22 &&
    treeOK (forms 2) (5 ||| 2^6) 2 q9Shape2T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T22OK,q9Shape2T23OK⟩

private def q9Shape2T17 : Tree := .split 2 q9Shape2T18 q9Shape2T21
private theorem q9Shape2T17OK : treeOK (forms 2) 1 2 q9Shape2T17=true := by
  change (treeOK (forms 2) 1 (2 ||| 2^2) q9Shape2T18 &&
    treeOK (forms 2) (1 ||| 2^2) 2 q9Shape2T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T18OK,q9Shape2T21OK⟩

private def q9Shape2T28 : Tree := (.split 7 (.split 11 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 4 1))))))) (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 3 1)))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.cover 3 4 6 7)))) (.split 10 (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.cover 2 5 6 7)))) (.split 14 (.split 17 (.tip (.small 1)) (.tip (.cover 2 5 6 7))) (.tip (.cover 3 4 6 7)))))))
private theorem q9Shape2T28OK : treeOK (forms 2) 3 68 q9Shape2T28=true := by decide

private def q9Shape2T29 : Tree := (.split 7 (.split 11 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.tip (.unordered 2 3 1)))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.unordered 3 4 1)))) (.split 10 (.split 14 (.tip (.small 1)) (.tip (.unordered 2 4 1))) (.split 14 (.tip (.unordered 2 3 1)) (.tip (.unordered 2 3 1)))))) (.split 11 (.split 5 (.split 10 (.tip (.small 1)) (.tip (.cover 1 3 6 7))) (.split 10 (.split 14 (.tip (.small 1)) (.tip (.unordered 2 3 1))) (.tip (.cover 1 3 6 7)))) (.split 5 (.tip (.unordered 3 4 1)) (.split 10 (.tip (.unordered 3 4 1)) (.tip (.cover 1 3 6 7))))))
private theorem q9Shape2T29OK : treeOK (forms 2) 67 4 q9Shape2T29=true := by decide

private def q9Shape2T27 : Tree := .split 6 q9Shape2T28 q9Shape2T29
private theorem q9Shape2T27OK : treeOK (forms 2) 3 4 q9Shape2T27=true := by
  change (treeOK (forms 2) 3 (4 ||| 2^6) q9Shape2T28 &&
    treeOK (forms 2) (3 ||| 2^6) 4 q9Shape2T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T28OK,q9Shape2T29OK⟩

private def q9Shape2T31 : Tree := (.split 7 (.split 11 (.split 5 (.tip (.small 1)) (.tip (.cover 1 2 6 7))) (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 4 1))))) (.tip (.cover 1 2 6 7)))) (.split 11 (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 17 (.tip (.small 1)) (.tip (.unordered 2 3 1))))) (.tip (.cover 1 2 6 7))) (.split 5 (.tip (.unordered 2 5 1)) (.tip (.cover 1 2 6 7)))))
private theorem q9Shape2T31OK : treeOK (forms 2) 7 64 q9Shape2T31=true := by decide

private def q9Shape2T32 : Tree := (.split 7 (.split 11 (.split 5 (.split 10 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.tip (.unordered 2 3 1)))) (.tip (.cover 1 2 6 7))) (.split 5 (.tip (.unordered 2 4 1)) (.tip (.cover 1 2 6 7)))) (.split 11 (.split 5 (.tip (.unordered 2 3 1)) (.tip (.cover 1 2 6 7))) (.split 5 (.tip (.unordered 2 3 1)) (.tip (.cover 1 2 6 7)))))
private theorem q9Shape2T32OK : treeOK (forms 2) 71 0 q9Shape2T32=true := by decide

private def q9Shape2T30 : Tree := .split 6 q9Shape2T31 q9Shape2T32
private theorem q9Shape2T30OK : treeOK (forms 2) 7 0 q9Shape2T30=true := by
  change (treeOK (forms 2) 7 (0 ||| 2^6) q9Shape2T31 &&
    treeOK (forms 2) (7 ||| 2^6) 0 q9Shape2T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T31OK,q9Shape2T32OK⟩

private def q9Shape2T26 : Tree := .split 2 q9Shape2T27 q9Shape2T30
private theorem q9Shape2T26OK : treeOK (forms 2) 3 0 q9Shape2T26=true := by
  change (treeOK (forms 2) 3 (0 ||| 2^2) q9Shape2T27 &&
    treeOK (forms 2) (3 ||| 2^2) 0 q9Shape2T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T27OK,q9Shape2T30OK⟩

private def q9Shape2T16 : Tree := .split 1 q9Shape2T17 q9Shape2T26
private theorem q9Shape2T16OK : treeOK (forms 2) 1 0 q9Shape2T16=true := by
  change (treeOK (forms 2) 1 (0 ||| 2^1) q9Shape2T17 &&
    treeOK (forms 2) (1 ||| 2^1) 0 q9Shape2T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T17OK,q9Shape2T26OK⟩

private def q9Shape2T0 : Tree := .split 0 q9Shape2T1 q9Shape2T16
private theorem q9Shape2T0OK : treeOK (forms 2) 0 0 q9Shape2T0=true := by
  change (treeOK (forms 2) 0 (0 ||| 2^0) q9Shape2T1 &&
    treeOK (forms 2) (0 ||| 2^0) 0 q9Shape2T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape2T1OK,q9Shape2T16OK⟩


theorem q9Shape2_cover (b : Nat→Bool) (H : Ranked (adj (forms 2) b)) :
    ∃ u v w z,Effective (adj (forms 2) b) (adj (forms 2) b) u v w z :=
  checked_tree (forms 2) b H q9Shape2T0 q9Shape2T0OK

#print axioms q9Shape2_cover
end Graffiti384b.Q9
