import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape3T0 : Tree := (.split 18 (.tip (.small 1)) (.split 19 (.tip (.small 1)) (.split 20 (.tip (.small 1)) (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 3 6)))))))
private theorem q9Shape3T0OK : treeOK (forms 3) 0 0 q9Shape3T0=true := by decide


theorem q9Shape3_cover (b : Nat→Bool) (H : Ranked (adj (forms 3) b)) :
    ∃ u v w z,Effective (adj (forms 3) b) (adj (forms 3) b) u v w z :=
  checked_tree (forms 3) b H q9Shape3T0 q9Shape3T0OK

#print axioms q9Shape3_cover
end Graffiti384b.Q9
