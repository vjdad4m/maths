import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape4T1 : Tree := (.split 18 (.tip (.small 1)) (.split 11 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 1 (.tip (.small 0)) (.tip (.cover 2 3 5 8)))))))))
private theorem q9Shape4T1OK : treeOK (forms 4) 0 1 q9Shape4T1=true := by decide

private def q9Shape4T3 : Tree := (.split 11 (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.tip (.unordered 2 3 0)))))) (.split 3 (.tip (.small 1)) (.split 4 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.tip (.unordered 2 3 1)))))))
private theorem q9Shape4T3OK : treeOK (forms 4) 1 262144 q9Shape4T3=true := by decide

private def q9Shape4T5 : Tree := (.split 3 (.split 4 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.unordered 2 3 0))))))) (.split 4 (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.unordered 2 3 0)))))) (.split 8 (.split 9 (.tip (.small 1)) (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 1 2 8))))) (.split 9 (.split 1 (.tip (.small 0)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 1 2 8)))) (.tip (.unordered 2 3 0))))))
private theorem q9Shape4T5OK : treeOK (forms 4) 262145 2048 q9Shape4T5=true := by decide

private def q9Shape4T6 : Tree := (.split 3 (.split 4 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 2 4 6 8))) (.tip (.cover 2 5 6 8)))))) (.split 4 (.split 8 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 2 4 7 8))) (.tip (.cover 2 5 7 8))))) (.split 8 (.split 9 (.tip (.small 1)) (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 2 4 7 8))) (.tip (.cover 2 5 7 8)))) (.split 9 (.split 1 (.split 2 (.tip (.small 0)) (.tip (.cover 2 4 6 8))) (.tip (.cover 2 5 6 8))) (.tip (.unordered 2 3 0))))))
private theorem q9Shape4T6OK : treeOK (forms 4) 264193 0 q9Shape4T6=true := by decide

private def q9Shape4T4 : Tree := .split 11 q9Shape4T5 q9Shape4T6
private theorem q9Shape4T4OK : treeOK (forms 4) 262145 0 q9Shape4T4=true := by
  change (treeOK (forms 4) 262145 (0 ||| 2^11) q9Shape4T5 &&
    treeOK (forms 4) (262145 ||| 2^11) 0 q9Shape4T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape4T5OK,q9Shape4T6OK⟩

private def q9Shape4T2 : Tree := .split 18 q9Shape4T3 q9Shape4T4
private theorem q9Shape4T2OK : treeOK (forms 4) 1 0 q9Shape4T2=true := by
  change (treeOK (forms 4) 1 (0 ||| 2^18) q9Shape4T3 &&
    treeOK (forms 4) (1 ||| 2^18) 0 q9Shape4T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape4T3OK,q9Shape4T4OK⟩

private def q9Shape4T0 : Tree := .split 0 q9Shape4T1 q9Shape4T2
private theorem q9Shape4T0OK : treeOK (forms 4) 0 0 q9Shape4T0=true := by
  change (treeOK (forms 4) 0 (0 ||| 2^0) q9Shape4T1 &&
    treeOK (forms 4) (0 ||| 2^0) 0 q9Shape4T2)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape4T1OK,q9Shape4T2OK⟩


theorem q9Shape4_cover (b : Nat→Bool) (H : Ranked (adj (forms 4) b)) :
    ∃ u v w z,Effective (adj (forms 4) b) (adj (forms 4) b) u v w z :=
  checked_tree (forms 4) b H q9Shape4T0 q9Shape4T0OK

#print axioms q9Shape4_cover
end Graffiti384b.Q9
