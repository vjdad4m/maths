import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape5T2 : Tree := (.split 6 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.unordered 3 4 0)))))))))
private theorem q9Shape5T2OK : treeOK (forms 5) 0 3 q9Shape5T2=true := by decide

private def q9Shape5T4 : Tree := (.split 3 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.unordered 2 4 0))))))))
private theorem q9Shape5T4OK : treeOK (forms 5) 2 65 q9Shape5T4=true := by decide

private def q9Shape5T7 : Tree := (.tip (.small 1))
private theorem q9Shape5T7OK : treeOK (forms 5) 66 265 q9Shape5T7=true := by decide

private def q9Shape5T9 : Tree := (.tip (.small 1))
private theorem q9Shape5T9OK : treeOK (forms 5) 322 4105 q9Shape5T9=true := by decide

private def q9Shape5T11 : Tree := (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.unordered 3 4 0))))
private theorem q9Shape5T11OK : treeOK (forms 5) 4418 13 q9Shape5T11=true := by decide

private def q9Shape5T14 : Tree := (.tip (.small 0))
private theorem q9Shape5T14OK : treeOK (forms 5) 4422 2185 q9Shape5T14=true := by decide

private def q9Shape5T17 : Tree := (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.split 18 (.tip (.cover 3 4 5 8)) (.tip (.cover 2 4 7 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7)))))
private theorem q9Shape5T17OK : treeOK (forms 5) 6470 32921 q9Shape5T17=true := by decide

private def q9Shape5T18 : Tree := (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.split 14 (.split 18 (.split 19 (.split 16 (.tip (.cover 2 3 4 8)) (.tip (.cover 3 4 7 8))) (.tip (.cover 2 3 5 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))
private theorem q9Shape5T18OK : treeOK (forms 5) 6486 32905 q9Shape5T18=true := by decide

private def q9Shape5T16 : Tree := .split 4 q9Shape5T17 q9Shape5T18
private theorem q9Shape5T16OK : treeOK (forms 5) 6470 32905 q9Shape5T16=true := by
  change (treeOK (forms 5) 6470 (32905 ||| 2^4) q9Shape5T17 &&
    treeOK (forms 5) (6470 ||| 2^4) 32905 q9Shape5T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T17OK,q9Shape5T18OK⟩

private def q9Shape5T19 : Tree := (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.tip (.cover 1 5 7 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 6 7 8)))
private theorem q9Shape5T19OK : treeOK (forms 5) 39238 137 q9Shape5T19=true := by decide

private def q9Shape5T15 : Tree := .split 15 q9Shape5T16 q9Shape5T19
private theorem q9Shape5T15OK : treeOK (forms 5) 6470 137 q9Shape5T15=true := by
  change (treeOK (forms 5) 6470 (137 ||| 2^15) q9Shape5T16 &&
    treeOK (forms 5) (6470 ||| 2^15) 137 q9Shape5T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T16OK,q9Shape5T19OK⟩

private def q9Shape5T13 : Tree := .split 11 q9Shape5T14 q9Shape5T15
private theorem q9Shape5T13OK : treeOK (forms 5) 4422 137 q9Shape5T13=true := by
  change (treeOK (forms 5) 4422 (137 ||| 2^11) q9Shape5T14 &&
    treeOK (forms 5) (4422 ||| 2^11) 137 q9Shape5T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T14OK,q9Shape5T15OK⟩

private def q9Shape5T20 : Tree := (.split 11 (.split 15 (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 3 4 0))) (.tip (.unordered 3 4 0))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 3 4 0))) (.tip (.unordered 3 4 1)))
private theorem q9Shape5T20OK : treeOK (forms 5) 4550 9 q9Shape5T20=true := by decide

private def q9Shape5T12 : Tree := .split 7 q9Shape5T13 q9Shape5T20
private theorem q9Shape5T12OK : treeOK (forms 5) 4422 9 q9Shape5T12=true := by
  change (treeOK (forms 5) 4422 (9 ||| 2^7) q9Shape5T13 &&
    treeOK (forms 5) (4422 ||| 2^7) 9 q9Shape5T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T13OK,q9Shape5T20OK⟩

private def q9Shape5T10 : Tree := .split 2 q9Shape5T11 q9Shape5T12
private theorem q9Shape5T10OK : treeOK (forms 5) 4418 9 q9Shape5T10=true := by
  change (treeOK (forms 5) 4418 (9 ||| 2^2) q9Shape5T11 &&
    treeOK (forms 5) (4418 ||| 2^2) 9 q9Shape5T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T11OK,q9Shape5T12OK⟩

private def q9Shape5T8 : Tree := .split 12 q9Shape5T9 q9Shape5T10
private theorem q9Shape5T8OK : treeOK (forms 5) 322 9 q9Shape5T8=true := by
  change (treeOK (forms 5) 322 (9 ||| 2^12) q9Shape5T9 &&
    treeOK (forms 5) (322 ||| 2^12) 9 q9Shape5T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T9OK,q9Shape5T10OK⟩

private def q9Shape5T6 : Tree := .split 8 q9Shape5T7 q9Shape5T8
private theorem q9Shape5T6OK : treeOK (forms 5) 66 9 q9Shape5T6=true := by
  change (treeOK (forms 5) 66 (9 ||| 2^8) q9Shape5T7 &&
    treeOK (forms 5) (66 ||| 2^8) 9 q9Shape5T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T7OK,q9Shape5T8OK⟩

private def q9Shape5T23 : Tree := (.tip (.small 1))
private theorem q9Shape5T23OK : treeOK (forms 5) 74 4353 q9Shape5T23=true := by decide

private def q9Shape5T26 : Tree := (.tip (.small 0))
private theorem q9Shape5T26OK : treeOK (forms 5) 4170 389 q9Shape5T26=true := by decide

private def q9Shape5T28 : Tree := (.tip (.small 0))
private theorem q9Shape5T28OK : treeOK (forms 5) 4298 2309 q9Shape5T28=true := by decide

private def q9Shape5T31 : Tree := (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.split 18 (.split 19 (.split 16 (.tip (.cover 2 3 4 8)) (.tip (.cover 2 4 7 8))) (.tip (.cover 2 3 5 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7)))))
private theorem q9Shape5T31OK : treeOK (forms 5) 6346 33045 q9Shape5T31=true := by decide

private def q9Shape5T32 : Tree := (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.split 14 (.split 18 (.tip (.cover 2 4 5 8)) (.tip (.cover 3 4 7 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))
private theorem q9Shape5T32OK : treeOK (forms 5) 6362 33029 q9Shape5T32=true := by decide

private def q9Shape5T30 : Tree := .split 4 q9Shape5T31 q9Shape5T32
private theorem q9Shape5T30OK : treeOK (forms 5) 6346 33029 q9Shape5T30=true := by
  change (treeOK (forms 5) 6346 (33029 ||| 2^4) q9Shape5T31 &&
    treeOK (forms 5) (6346 ||| 2^4) 33029 q9Shape5T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T31OK,q9Shape5T32OK⟩

private def q9Shape5T33 : Tree := (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.tip (.cover 0 6 7 8))) (.tip (.cover 1 5 7 8))) (.tip (.cover 1 5 7 8)))
private theorem q9Shape5T33OK : treeOK (forms 5) 39114 261 q9Shape5T33=true := by decide

private def q9Shape5T29 : Tree := .split 15 q9Shape5T30 q9Shape5T33
private theorem q9Shape5T29OK : treeOK (forms 5) 6346 261 q9Shape5T29=true := by
  change (treeOK (forms 5) 6346 (261 ||| 2^15) q9Shape5T30 &&
    treeOK (forms 5) (6346 ||| 2^15) 261 q9Shape5T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T30OK,q9Shape5T33OK⟩

private def q9Shape5T27 : Tree := .split 11 q9Shape5T28 q9Shape5T29
private theorem q9Shape5T27OK : treeOK (forms 5) 4298 261 q9Shape5T27=true := by
  change (treeOK (forms 5) 4298 (261 ||| 2^11) q9Shape5T28 &&
    treeOK (forms 5) (4298 ||| 2^11) 261 q9Shape5T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T28OK,q9Shape5T29OK⟩

private def q9Shape5T25 : Tree := .split 7 q9Shape5T26 q9Shape5T27
private theorem q9Shape5T25OK : treeOK (forms 5) 4170 261 q9Shape5T25=true := by
  change (treeOK (forms 5) 4170 (261 ||| 2^7) q9Shape5T26 &&
    treeOK (forms 5) (4170 ||| 2^7) 261 q9Shape5T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T26OK,q9Shape5T27OK⟩

private def q9Shape5T35 : Tree := (.split 11 (.tip (.small 0)) (.tip (.unordered 2 4 0)))
private theorem q9Shape5T35OK : treeOK (forms 5) 4174 385 q9Shape5T35=true := by decide

private def q9Shape5T36 : Tree := (.split 11 (.split 15 (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 4 1)))
private theorem q9Shape5T36OK : treeOK (forms 5) 4302 257 q9Shape5T36=true := by decide

private def q9Shape5T34 : Tree := .split 7 q9Shape5T35 q9Shape5T36
private theorem q9Shape5T34OK : treeOK (forms 5) 4174 257 q9Shape5T34=true := by
  change (treeOK (forms 5) 4174 (257 ||| 2^7) q9Shape5T35 &&
    treeOK (forms 5) (4174 ||| 2^7) 257 q9Shape5T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T35OK,q9Shape5T36OK⟩

private def q9Shape5T24 : Tree := .split 2 q9Shape5T25 q9Shape5T34
private theorem q9Shape5T24OK : treeOK (forms 5) 4170 257 q9Shape5T24=true := by
  change (treeOK (forms 5) 4170 (257 ||| 2^2) q9Shape5T25 &&
    treeOK (forms 5) (4170 ||| 2^2) 257 q9Shape5T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T25OK,q9Shape5T34OK⟩

private def q9Shape5T22 : Tree := .split 12 q9Shape5T23 q9Shape5T24
private theorem q9Shape5T22OK : treeOK (forms 5) 74 257 q9Shape5T22=true := by
  change (treeOK (forms 5) 74 (257 ||| 2^12) q9Shape5T23 &&
    treeOK (forms 5) (74 ||| 2^12) 257 q9Shape5T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T23OK,q9Shape5T24OK⟩

private def q9Shape5T39 : Tree := (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 15 (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 3 4 0))) (.tip (.unordered 3 4 0))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 3 4 0)))))
private theorem q9Shape5T39OK : treeOK (forms 5) 330 4101 q9Shape5T39=true := by decide

private def q9Shape5T40 : Tree := (.split 7 (.split 11 (.tip (.small 0)) (.split 15 (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 2 4 0)))) (.tip (.cover 2 3 7 8)))
private theorem q9Shape5T40OK : treeOK (forms 5) 334 4097 q9Shape5T40=true := by decide

private def q9Shape5T38 : Tree := .split 2 q9Shape5T39 q9Shape5T40
private theorem q9Shape5T38OK : treeOK (forms 5) 330 4097 q9Shape5T38=true := by
  change (treeOK (forms 5) 330 (4097 ||| 2^2) q9Shape5T39 &&
    treeOK (forms 5) (330 ||| 2^2) 4097 q9Shape5T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T39OK,q9Shape5T40OK⟩

private def q9Shape5T41 : Tree := (.split 2 (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.unordered 3 4 0)))) (.split 7 (.split 11 (.tip (.small 0)) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 7 8))))
private theorem q9Shape5T41OK : treeOK (forms 5) 4426 1 q9Shape5T41=true := by decide

private def q9Shape5T37 : Tree := .split 12 q9Shape5T38 q9Shape5T41
private theorem q9Shape5T37OK : treeOK (forms 5) 330 1 q9Shape5T37=true := by
  change (treeOK (forms 5) 330 (1 ||| 2^12) q9Shape5T38 &&
    treeOK (forms 5) (330 ||| 2^12) 1 q9Shape5T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T38OK,q9Shape5T41OK⟩

private def q9Shape5T21 : Tree := .split 8 q9Shape5T22 q9Shape5T37
private theorem q9Shape5T21OK : treeOK (forms 5) 74 1 q9Shape5T21=true := by
  change (treeOK (forms 5) 74 (1 ||| 2^8) q9Shape5T22 &&
    treeOK (forms 5) (74 ||| 2^8) 1 q9Shape5T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T22OK,q9Shape5T37OK⟩

private def q9Shape5T5 : Tree := .split 3 q9Shape5T6 q9Shape5T21
private theorem q9Shape5T5OK : treeOK (forms 5) 66 1 q9Shape5T5=true := by
  change (treeOK (forms 5) 66 (1 ||| 2^3) q9Shape5T6 &&
    treeOK (forms 5) (66 ||| 2^3) 1 q9Shape5T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T6OK,q9Shape5T21OK⟩

private def q9Shape5T3 : Tree := .split 6 q9Shape5T4 q9Shape5T5
private theorem q9Shape5T3OK : treeOK (forms 5) 2 1 q9Shape5T3=true := by
  change (treeOK (forms 5) 2 (1 ||| 2^6) q9Shape5T4 &&
    treeOK (forms 5) (2 ||| 2^6) 1 q9Shape5T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T4OK,q9Shape5T5OK⟩

private def q9Shape5T1 : Tree := .split 1 q9Shape5T2 q9Shape5T3
private theorem q9Shape5T1OK : treeOK (forms 5) 0 1 q9Shape5T1=true := by
  change (treeOK (forms 5) 0 (1 ||| 2^1) q9Shape5T2 &&
    treeOK (forms 5) (0 ||| 2^1) 1 q9Shape5T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T2OK,q9Shape5T3OK⟩

private def q9Shape5T44 : Tree := (.split 3 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 2 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0)))))))
private theorem q9Shape5T44OK : treeOK (forms 5) 1 66 q9Shape5T44=true := by decide

private def q9Shape5T47 : Tree := (.tip (.small 1))
private theorem q9Shape5T47OK : treeOK (forms 5) 65 266 q9Shape5T47=true := by decide

private def q9Shape5T49 : Tree := (.tip (.small 1))
private theorem q9Shape5T49OK : treeOK (forms 5) 321 4106 q9Shape5T49=true := by decide

private def q9Shape5T51 : Tree := (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.unordered 3 4 0))))
private theorem q9Shape5T51OK : treeOK (forms 5) 4417 14 q9Shape5T51=true := by decide

private def q9Shape5T54 : Tree := (.tip (.small 0))
private theorem q9Shape5T54OK : treeOK (forms 5) 4421 2186 q9Shape5T54=true := by decide

private def q9Shape5T55 : Tree := (.split 15 (.split 4 (.split 5 (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.unordered 3 4 0))))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 3 4 0)))
private theorem q9Shape5T55OK : treeOK (forms 5) 6469 138 q9Shape5T55=true := by decide

private def q9Shape5T53 : Tree := .split 11 q9Shape5T54 q9Shape5T55
private theorem q9Shape5T53OK : treeOK (forms 5) 4421 138 q9Shape5T53=true := by
  change (treeOK (forms 5) 4421 (138 ||| 2^11) q9Shape5T54 &&
    treeOK (forms 5) (4421 ||| 2^11) 138 q9Shape5T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T54OK,q9Shape5T55OK⟩

private def q9Shape5T59 : Tree := (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.split 18 (.tip (.cover 3 4 5 8)) (.tip (.cover 2 3 7 8))))) (.split 13 (.tip (.cover 3 5 6 8)) (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.cover 2 3 4 7))))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7)))))
private theorem q9Shape5T59OK : treeOK (forms 5) 4549 34842 q9Shape5T59=true := by decide

private def q9Shape5T60 : Tree := (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.split 14 (.split 18 (.split 19 (.split 16 (.tip (.cover 2 3 4 8)) (.tip (.cover 3 4 7 8))) (.tip (.cover 2 3 6 7))) (.tip (.cover 2 3 6 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))
private theorem q9Shape5T60OK : treeOK (forms 5) 4565 34826 q9Shape5T60=true := by decide

private def q9Shape5T58 : Tree := .split 4 q9Shape5T59 q9Shape5T60
private theorem q9Shape5T58OK : treeOK (forms 5) 4549 34826 q9Shape5T58=true := by
  change (treeOK (forms 5) 4549 (34826 ||| 2^4) q9Shape5T59 &&
    treeOK (forms 5) (4549 ||| 2^4) 34826 q9Shape5T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T59OK,q9Shape5T60OK⟩

private def q9Shape5T61 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 1 5 7 8))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 1 5 7 8)))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 6 7 8)))
private theorem q9Shape5T61OK : treeOK (forms 5) 37317 2058 q9Shape5T61=true := by decide

private def q9Shape5T57 : Tree := .split 15 q9Shape5T58 q9Shape5T61
private theorem q9Shape5T57OK : treeOK (forms 5) 4549 2058 q9Shape5T57=true := by
  change (treeOK (forms 5) 4549 (2058 ||| 2^15) q9Shape5T58 &&
    treeOK (forms 5) (4549 ||| 2^15) 2058 q9Shape5T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T58OK,q9Shape5T61OK⟩

private def q9Shape5T62 : Tree := (.tip (.unordered 3 4 1))
private theorem q9Shape5T62OK : treeOK (forms 5) 6597 10 q9Shape5T62=true := by decide

private def q9Shape5T56 : Tree := .split 11 q9Shape5T57 q9Shape5T62
private theorem q9Shape5T56OK : treeOK (forms 5) 4549 10 q9Shape5T56=true := by
  change (treeOK (forms 5) 4549 (10 ||| 2^11) q9Shape5T57 &&
    treeOK (forms 5) (4549 ||| 2^11) 10 q9Shape5T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T57OK,q9Shape5T62OK⟩

private def q9Shape5T52 : Tree := .split 7 q9Shape5T53 q9Shape5T56
private theorem q9Shape5T52OK : treeOK (forms 5) 4421 10 q9Shape5T52=true := by
  change (treeOK (forms 5) 4421 (10 ||| 2^7) q9Shape5T53 &&
    treeOK (forms 5) (4421 ||| 2^7) 10 q9Shape5T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T53OK,q9Shape5T56OK⟩

private def q9Shape5T50 : Tree := .split 2 q9Shape5T51 q9Shape5T52
private theorem q9Shape5T50OK : treeOK (forms 5) 4417 10 q9Shape5T50=true := by
  change (treeOK (forms 5) 4417 (10 ||| 2^2) q9Shape5T51 &&
    treeOK (forms 5) (4417 ||| 2^2) 10 q9Shape5T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T51OK,q9Shape5T52OK⟩

private def q9Shape5T48 : Tree := .split 12 q9Shape5T49 q9Shape5T50
private theorem q9Shape5T48OK : treeOK (forms 5) 321 10 q9Shape5T48=true := by
  change (treeOK (forms 5) 321 (10 ||| 2^12) q9Shape5T49 &&
    treeOK (forms 5) (321 ||| 2^12) 10 q9Shape5T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T49OK,q9Shape5T50OK⟩

private def q9Shape5T46 : Tree := .split 8 q9Shape5T47 q9Shape5T48
private theorem q9Shape5T46OK : treeOK (forms 5) 65 10 q9Shape5T46=true := by
  change (treeOK (forms 5) 65 (10 ||| 2^8) q9Shape5T47 &&
    treeOK (forms 5) (65 ||| 2^8) 10 q9Shape5T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T47OK,q9Shape5T48OK⟩

private def q9Shape5T65 : Tree := (.tip (.small 1))
private theorem q9Shape5T65OK : treeOK (forms 5) 73 4354 q9Shape5T65=true := by decide

private def q9Shape5T68 : Tree := (.tip (.small 0))
private theorem q9Shape5T68OK : treeOK (forms 5) 4169 390 q9Shape5T68=true := by decide

private def q9Shape5T70 : Tree := (.tip (.small 0))
private theorem q9Shape5T70OK : treeOK (forms 5) 4297 2310 q9Shape5T70=true := by decide

private def q9Shape5T71 : Tree := (.split 15 (.split 4 (.split 5 (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.unordered 3 4 0))))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.unordered 3 4 0))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 3 4 0)))
private theorem q9Shape5T71OK : treeOK (forms 5) 6345 262 q9Shape5T71=true := by decide

private def q9Shape5T69 : Tree := .split 11 q9Shape5T70 q9Shape5T71
private theorem q9Shape5T69OK : treeOK (forms 5) 4297 262 q9Shape5T69=true := by
  change (treeOK (forms 5) 4297 (262 ||| 2^11) q9Shape5T70 &&
    treeOK (forms 5) (4297 ||| 2^11) 262 q9Shape5T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T70OK,q9Shape5T71OK⟩

private def q9Shape5T67 : Tree := .split 7 q9Shape5T68 q9Shape5T69
private theorem q9Shape5T67OK : treeOK (forms 5) 4169 262 q9Shape5T67=true := by
  change (treeOK (forms 5) 4169 (262 ||| 2^7) q9Shape5T68 &&
    treeOK (forms 5) (4169 ||| 2^7) 262 q9Shape5T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T68OK,q9Shape5T69OK⟩

private def q9Shape5T72 : Tree := (.split 7 (.split 11 (.tip (.small 0)) (.tip (.cover 2 4 7 8))) (.split 11 (.split 15 (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.unordered 2 3 0))))) (.split 5 (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 13 (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))) (.tip (.unordered 2 3 0))) (.tip (.cover 2 4 7 8))))
private theorem q9Shape5T72OK : treeOK (forms 5) 4173 258 q9Shape5T72=true := by decide

private def q9Shape5T66 : Tree := .split 2 q9Shape5T67 q9Shape5T72
private theorem q9Shape5T66OK : treeOK (forms 5) 4169 258 q9Shape5T66=true := by
  change (treeOK (forms 5) 4169 (258 ||| 2^2) q9Shape5T67 &&
    treeOK (forms 5) (4169 ||| 2^2) 258 q9Shape5T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T67OK,q9Shape5T72OK⟩

private def q9Shape5T64 : Tree := .split 12 q9Shape5T65 q9Shape5T66
private theorem q9Shape5T64OK : treeOK (forms 5) 73 258 q9Shape5T64=true := by
  change (treeOK (forms 5) 73 (258 ||| 2^12) q9Shape5T65 &&
    treeOK (forms 5) (73 ||| 2^12) 258 q9Shape5T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T65OK,q9Shape5T66OK⟩

private def q9Shape5T76 : Tree := (.tip (.small 0))
private theorem q9Shape5T76OK : treeOK (forms 5) 329 4230 q9Shape5T76=true := by decide

private def q9Shape5T78 : Tree := (.tip (.small 0))
private theorem q9Shape5T78OK : treeOK (forms 5) 457 6150 q9Shape5T78=true := by decide

private def q9Shape5T81 : Tree := (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.split 18 (.split 19 (.split 16 (.tip (.cover 2 3 4 8)) (.tip (.cover 2 3 7 8))) (.tip (.cover 2 4 5 8))) (.tip (.cover 3 4 6 8))))) (.split 13 (.tip (.cover 3 5 6 8)) (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.cover 2 3 4 7))))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7)))))
private theorem q9Shape5T81OK : treeOK (forms 5) 2505 36886 q9Shape5T81=true := by decide

private def q9Shape5T82 : Tree := (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.split 14 (.split 18 (.tip (.cover 2 3 5 8)) (.tip (.cover 3 4 7 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))
private theorem q9Shape5T82OK : treeOK (forms 5) 2521 36870 q9Shape5T82=true := by decide

private def q9Shape5T80 : Tree := .split 4 q9Shape5T81 q9Shape5T82
private theorem q9Shape5T80OK : treeOK (forms 5) 2505 36870 q9Shape5T80=true := by
  change (treeOK (forms 5) 2505 (36870 ||| 2^4) q9Shape5T81 &&
    treeOK (forms 5) (2505 ||| 2^4) 36870 q9Shape5T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T81OK,q9Shape5T82OK⟩

private def q9Shape5T83 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 0 6 7 8))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 0 6 7 8)))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.tip (.cover 1 5 7 8))) (.tip (.cover 1 5 7 8)))
private theorem q9Shape5T83OK : treeOK (forms 5) 35273 4102 q9Shape5T83=true := by decide

private def q9Shape5T79 : Tree := .split 15 q9Shape5T80 q9Shape5T83
private theorem q9Shape5T79OK : treeOK (forms 5) 2505 4102 q9Shape5T79=true := by
  change (treeOK (forms 5) 2505 (4102 ||| 2^15) q9Shape5T80 &&
    treeOK (forms 5) (2505 ||| 2^15) 4102 q9Shape5T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T80OK,q9Shape5T83OK⟩

private def q9Shape5T77 : Tree := .split 11 q9Shape5T78 q9Shape5T79
private theorem q9Shape5T77OK : treeOK (forms 5) 457 4102 q9Shape5T77=true := by
  change (treeOK (forms 5) 457 (4102 ||| 2^11) q9Shape5T78 &&
    treeOK (forms 5) (457 ||| 2^11) 4102 q9Shape5T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T78OK,q9Shape5T79OK⟩

private def q9Shape5T75 : Tree := .split 7 q9Shape5T76 q9Shape5T77
private theorem q9Shape5T75OK : treeOK (forms 5) 329 4102 q9Shape5T75=true := by
  change (treeOK (forms 5) 329 (4102 ||| 2^7) q9Shape5T76 &&
    treeOK (forms 5) (329 ||| 2^7) 4102 q9Shape5T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T76OK,q9Shape5T77OK⟩

private def q9Shape5T84 : Tree := (.split 7 (.split 11 (.tip (.small 0)) (.split 15 (.split 4 (.split 5 (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.unordered 2 3 0))))) (.split 5 (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 13 (.split 14 (.tip (.cover 3 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))) (.tip (.unordered 2 3 0)))) (.tip (.unordered 2 3 1)))
private theorem q9Shape5T84OK : treeOK (forms 5) 333 4098 q9Shape5T84=true := by decide

private def q9Shape5T74 : Tree := .split 2 q9Shape5T75 q9Shape5T84
private theorem q9Shape5T74OK : treeOK (forms 5) 329 4098 q9Shape5T74=true := by
  change (treeOK (forms 5) 329 (4098 ||| 2^2) q9Shape5T75 &&
    treeOK (forms 5) (329 ||| 2^2) 4098 q9Shape5T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T75OK,q9Shape5T84OK⟩

private def q9Shape5T85 : Tree := (.split 2 (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.unordered 3 4 0)))) (.split 7 (.split 11 (.tip (.small 0)) (.tip (.cover 2 4 7 8))) (.split 11 (.tip (.unordered 2 3 0)) (.tip (.cover 2 4 7 8)))))
private theorem q9Shape5T85OK : treeOK (forms 5) 4425 2 q9Shape5T85=true := by decide

private def q9Shape5T73 : Tree := .split 12 q9Shape5T74 q9Shape5T85
private theorem q9Shape5T73OK : treeOK (forms 5) 329 2 q9Shape5T73=true := by
  change (treeOK (forms 5) 329 (2 ||| 2^12) q9Shape5T74 &&
    treeOK (forms 5) (329 ||| 2^12) 2 q9Shape5T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T74OK,q9Shape5T85OK⟩

private def q9Shape5T63 : Tree := .split 8 q9Shape5T64 q9Shape5T73
private theorem q9Shape5T63OK : treeOK (forms 5) 73 2 q9Shape5T63=true := by
  change (treeOK (forms 5) 73 (2 ||| 2^8) q9Shape5T64 &&
    treeOK (forms 5) (73 ||| 2^8) 2 q9Shape5T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T64OK,q9Shape5T73OK⟩

private def q9Shape5T45 : Tree := .split 3 q9Shape5T46 q9Shape5T63
private theorem q9Shape5T45OK : treeOK (forms 5) 65 2 q9Shape5T45=true := by
  change (treeOK (forms 5) 65 (2 ||| 2^3) q9Shape5T46 &&
    treeOK (forms 5) (65 ||| 2^3) 2 q9Shape5T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T46OK,q9Shape5T63OK⟩

private def q9Shape5T43 : Tree := .split 6 q9Shape5T44 q9Shape5T45
private theorem q9Shape5T43OK : treeOK (forms 5) 1 2 q9Shape5T43=true := by
  change (treeOK (forms 5) 1 (2 ||| 2^6) q9Shape5T44 &&
    treeOK (forms 5) (1 ||| 2^6) 2 q9Shape5T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T44OK,q9Shape5T45OK⟩

private def q9Shape5T89 : Tree := (.tip (.small 1))
private theorem q9Shape5T89OK : treeOK (forms 5) 3 328 q9Shape5T89=true := by decide

private def q9Shape5T91 : Tree := (.tip (.small 1))
private theorem q9Shape5T91OK : treeOK (forms 5) 259 4168 q9Shape5T91=true := by decide

private def q9Shape5T93 : Tree := (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover 3 4 7 8))))
private theorem q9Shape5T93OK : treeOK (forms 5) 4355 76 q9Shape5T93=true := by decide

private def q9Shape5T95 : Tree := (.split 11 (.tip (.small 0)) (.split 15 (.split 4 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.unordered 2 4 0)))) (.tip (.cover 2 3 4 7))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0))) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 2 4 0))))
private theorem q9Shape5T95OK : treeOK (forms 5) 4359 200 q9Shape5T95=true := by decide

private def q9Shape5T96 : Tree := (.split 11 (.split 15 (.split 4 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.unordered 2 3 0))))) (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))) (.tip (.unordered 2 3 0))) (.tip (.cover 3 4 7 8)))
private theorem q9Shape5T96OK : treeOK (forms 5) 4487 72 q9Shape5T96=true := by decide

private def q9Shape5T94 : Tree := .split 7 q9Shape5T95 q9Shape5T96
private theorem q9Shape5T94OK : treeOK (forms 5) 4359 72 q9Shape5T94=true := by
  change (treeOK (forms 5) 4359 (72 ||| 2^7) q9Shape5T95 &&
    treeOK (forms 5) (4359 ||| 2^7) 72 q9Shape5T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T95OK,q9Shape5T96OK⟩

private def q9Shape5T92 : Tree := .split 2 q9Shape5T93 q9Shape5T94
private theorem q9Shape5T92OK : treeOK (forms 5) 4355 72 q9Shape5T92=true := by
  change (treeOK (forms 5) 4355 (72 ||| 2^2) q9Shape5T93 &&
    treeOK (forms 5) (4355 ||| 2^2) 72 q9Shape5T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T93OK,q9Shape5T94OK⟩

private def q9Shape5T90 : Tree := .split 12 q9Shape5T91 q9Shape5T92
private theorem q9Shape5T90OK : treeOK (forms 5) 259 72 q9Shape5T90=true := by
  change (treeOK (forms 5) 259 (72 ||| 2^12) q9Shape5T91 &&
    treeOK (forms 5) (259 ||| 2^12) 72 q9Shape5T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T91OK,q9Shape5T92OK⟩

private def q9Shape5T88 : Tree := .split 8 q9Shape5T89 q9Shape5T90
private theorem q9Shape5T88OK : treeOK (forms 5) 3 72 q9Shape5T88=true := by
  change (treeOK (forms 5) 3 (72 ||| 2^8) q9Shape5T89 &&
    treeOK (forms 5) (3 ||| 2^8) 72 q9Shape5T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T89OK,q9Shape5T90OK⟩

private def q9Shape5T99 : Tree := (.tip (.small 1))
private theorem q9Shape5T99OK : treeOK (forms 5) 11 4416 q9Shape5T99=true := by decide

private def q9Shape5T101 : Tree := (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 15 (.split 4 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.unordered 2 4 0)))) (.tip (.cover 2 3 4 7))) (.split 10 (.split 13 (.tip (.cover 3 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))))) (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0))) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.tip (.unordered 2 4 0)))))
private theorem q9Shape5T101OK : treeOK (forms 5) 4107 324 q9Shape5T101=true := by decide

private def q9Shape5T103 : Tree := (.split 11 (.tip (.small 0)) (.tip (.unordered 2 4 0)))
private theorem q9Shape5T103OK : treeOK (forms 5) 4111 448 q9Shape5T103=true := by decide

private def q9Shape5T107 : Tree := (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.split 18 (.tip (.cover 2 4 5 8)) (.tip (.cover 2 3 7 8))))) (.tip (.cover 4 5 6 8))) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.split 18 (.split 19 (.split 16 (.tip (.cover 2 3 4 8)) (.tip (.cover 2 4 7 8))) (.tip (.cover 2 3 6 7))) (.tip (.cover 2 3 6 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.cover 2 3 4 7)))) (.tip (.cover 2 3 4 7))) (.split 10 (.split 13 (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7)))))
private theorem q9Shape5T107OK : treeOK (forms 5) 4239 35152 q9Shape5T107=true := by decide

private def q9Shape5T108 : Tree := (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))
private theorem q9Shape5T108OK : treeOK (forms 5) 4255 35136 q9Shape5T108=true := by decide

private def q9Shape5T106 : Tree := .split 4 q9Shape5T107 q9Shape5T108
private theorem q9Shape5T106OK : treeOK (forms 5) 4239 35136 q9Shape5T106=true := by
  change (treeOK (forms 5) 4239 (35136 ||| 2^4) q9Shape5T107 &&
    treeOK (forms 5) (4239 ||| 2^4) 35136 q9Shape5T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T107OK,q9Shape5T108OK⟩

private def q9Shape5T109 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 1 5 7 8))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 6 7 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 1 5 7 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 0 6 7 8)))) (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8)))))
private theorem q9Shape5T109OK : treeOK (forms 5) 37007 2368 q9Shape5T109=true := by decide

private def q9Shape5T105 : Tree := .split 15 q9Shape5T106 q9Shape5T109
private theorem q9Shape5T105OK : treeOK (forms 5) 4239 2368 q9Shape5T105=true := by
  change (treeOK (forms 5) 4239 (2368 ||| 2^15) q9Shape5T106 &&
    treeOK (forms 5) (4239 ||| 2^15) 2368 q9Shape5T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T106OK,q9Shape5T109OK⟩

private def q9Shape5T110 : Tree := (.tip (.unordered 2 4 1))
private theorem q9Shape5T110OK : treeOK (forms 5) 6287 320 q9Shape5T110=true := by decide

private def q9Shape5T104 : Tree := .split 11 q9Shape5T105 q9Shape5T110
private theorem q9Shape5T104OK : treeOK (forms 5) 4239 320 q9Shape5T104=true := by
  change (treeOK (forms 5) 4239 (320 ||| 2^11) q9Shape5T105 &&
    treeOK (forms 5) (4239 ||| 2^11) 320 q9Shape5T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T105OK,q9Shape5T110OK⟩

private def q9Shape5T102 : Tree := .split 7 q9Shape5T103 q9Shape5T104
private theorem q9Shape5T102OK : treeOK (forms 5) 4111 320 q9Shape5T102=true := by
  change (treeOK (forms 5) 4111 (320 ||| 2^7) q9Shape5T103 &&
    treeOK (forms 5) (4111 ||| 2^7) 320 q9Shape5T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T103OK,q9Shape5T104OK⟩

private def q9Shape5T100 : Tree := .split 2 q9Shape5T101 q9Shape5T102
private theorem q9Shape5T100OK : treeOK (forms 5) 4107 320 q9Shape5T100=true := by
  change (treeOK (forms 5) 4107 (320 ||| 2^2) q9Shape5T101 &&
    treeOK (forms 5) (4107 ||| 2^2) 320 q9Shape5T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T101OK,q9Shape5T102OK⟩

private def q9Shape5T98 : Tree := .split 12 q9Shape5T99 q9Shape5T100
private theorem q9Shape5T98OK : treeOK (forms 5) 11 320 q9Shape5T98=true := by
  change (treeOK (forms 5) 11 (320 ||| 2^12) q9Shape5T99 &&
    treeOK (forms 5) (11 ||| 2^12) 320 q9Shape5T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T99OK,q9Shape5T100OK⟩

private def q9Shape5T113 : Tree := (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 15 (.split 4 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.unordered 2 3 0))))) (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))) (.tip (.unordered 2 3 0)))))
private theorem q9Shape5T113OK : treeOK (forms 5) 267 4164 q9Shape5T113=true := by decide

private def q9Shape5T116 : Tree := (.tip (.small 0))
private theorem q9Shape5T116OK : treeOK (forms 5) 271 6336 q9Shape5T116=true := by decide

private def q9Shape5T119 : Tree := (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.split 18 (.split 19 (.split 16 (.tip (.cover 2 3 4 8)) (.tip (.cover 2 3 7 8))) (.tip (.cover 2 4 6 7))) (.tip (.cover 2 4 6 8))))) (.tip (.cover 4 5 6 8))) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.split 18 (.tip (.cover 2 3 5 8)) (.tip (.cover 2 4 7 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.cover 2 3 4 7)))) (.tip (.cover 2 3 4 7))) (.split 10 (.split 13 (.split 14 (.tip (.cover 2 5 6 7)) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7)))))
private theorem q9Shape5T119OK : treeOK (forms 5) 2319 37072 q9Shape5T119=true := by decide

private def q9Shape5T120 : Tree := (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8)))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8))))
private theorem q9Shape5T120OK : treeOK (forms 5) 2335 37056 q9Shape5T120=true := by decide

private def q9Shape5T118 : Tree := .split 4 q9Shape5T119 q9Shape5T120
private theorem q9Shape5T118OK : treeOK (forms 5) 2319 37056 q9Shape5T118=true := by
  change (treeOK (forms 5) 2319 (37056 ||| 2^4) q9Shape5T119 &&
    treeOK (forms 5) (2319 ||| 2^4) 37056 q9Shape5T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T119OK,q9Shape5T120OK⟩

private def q9Shape5T121 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 0 6 7 8))) (.tip (.cover 4 5 6 8))) (.tip (.cover 1 5 7 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 0 6 7 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 1 5 7 8)))) (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 1 5 7 8))) (.tip (.cover 2 3 4 8))) (.split 9 (.split 10 (.split 13 (.tip (.cover 2 5 6 8)) (.tip (.cover 2 3 4 8))) (.tip (.cover 2 3 4 7))) (.tip (.cover 2 3 4 8)))))
private theorem q9Shape5T121OK : treeOK (forms 5) 35087 4288 q9Shape5T121=true := by decide

private def q9Shape5T117 : Tree := .split 15 q9Shape5T118 q9Shape5T121
private theorem q9Shape5T117OK : treeOK (forms 5) 2319 4288 q9Shape5T117=true := by
  change (treeOK (forms 5) 2319 (4288 ||| 2^15) q9Shape5T118 &&
    treeOK (forms 5) (2319 ||| 2^15) 4288 q9Shape5T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T118OK,q9Shape5T121OK⟩

private def q9Shape5T115 : Tree := .split 11 q9Shape5T116 q9Shape5T117
private theorem q9Shape5T115OK : treeOK (forms 5) 271 4288 q9Shape5T115=true := by
  change (treeOK (forms 5) 271 (4288 ||| 2^11) q9Shape5T116 &&
    treeOK (forms 5) (271 ||| 2^11) 4288 q9Shape5T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T116OK,q9Shape5T117OK⟩

private def q9Shape5T122 : Tree := (.tip (.unordered 2 3 1))
private theorem q9Shape5T122OK : treeOK (forms 5) 399 4160 q9Shape5T122=true := by decide

private def q9Shape5T114 : Tree := .split 7 q9Shape5T115 q9Shape5T122
private theorem q9Shape5T114OK : treeOK (forms 5) 271 4160 q9Shape5T114=true := by
  change (treeOK (forms 5) 271 (4160 ||| 2^7) q9Shape5T115 &&
    treeOK (forms 5) (271 ||| 2^7) 4160 q9Shape5T122)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T115OK,q9Shape5T122OK⟩

private def q9Shape5T112 : Tree := .split 2 q9Shape5T113 q9Shape5T114
private theorem q9Shape5T112OK : treeOK (forms 5) 267 4160 q9Shape5T112=true := by
  change (treeOK (forms 5) 267 (4160 ||| 2^2) q9Shape5T113 &&
    treeOK (forms 5) (267 ||| 2^2) 4160 q9Shape5T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T113OK,q9Shape5T114OK⟩

private def q9Shape5T123 : Tree := (.split 2 (.split 7 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover 3 4 7 8)))) (.split 7 (.split 11 (.tip (.small 0)) (.tip (.unordered 2 4 0))) (.split 11 (.tip (.unordered 2 3 0)) (.tip (.cover 3 4 7 8)))))
private theorem q9Shape5T123OK : treeOK (forms 5) 4363 64 q9Shape5T123=true := by decide

private def q9Shape5T111 : Tree := .split 12 q9Shape5T112 q9Shape5T123
private theorem q9Shape5T111OK : treeOK (forms 5) 267 64 q9Shape5T111=true := by
  change (treeOK (forms 5) 267 (64 ||| 2^12) q9Shape5T112 &&
    treeOK (forms 5) (267 ||| 2^12) 64 q9Shape5T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T112OK,q9Shape5T123OK⟩

private def q9Shape5T97 : Tree := .split 8 q9Shape5T98 q9Shape5T111
private theorem q9Shape5T97OK : treeOK (forms 5) 11 64 q9Shape5T97=true := by
  change (treeOK (forms 5) 11 (64 ||| 2^8) q9Shape5T98 &&
    treeOK (forms 5) (11 ||| 2^8) 64 q9Shape5T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T98OK,q9Shape5T111OK⟩

private def q9Shape5T87 : Tree := .split 3 q9Shape5T88 q9Shape5T97
private theorem q9Shape5T87OK : treeOK (forms 5) 3 64 q9Shape5T87=true := by
  change (treeOK (forms 5) 3 (64 ||| 2^3) q9Shape5T88 &&
    treeOK (forms 5) (3 ||| 2^3) 64 q9Shape5T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T88OK,q9Shape5T97OK⟩

private def q9Shape5T127 : Tree := (.tip (.small 1))
private theorem q9Shape5T127OK : treeOK (forms 5) 67 4360 q9Shape5T127=true := by decide

private def q9Shape5T131 : Tree := (.tip (.small 0))
private theorem q9Shape5T131OK : treeOK (forms 5) 4163 2444 q9Shape5T131=true := by decide

private def q9Shape5T133 : Tree := (.split 4 (.split 5 (.split 9 (.tip (.interval 6 2)) (.split 10 (.tip (.interval 6 2)) (.split 13 (.split 14 (.tip (.interval 6 2)) (.tip (.unordered 3 4 0))) (.tip (.unordered 3 4 0))))) (.split 9 (.split 10 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.split 10 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))))) (.split 5 (.split 9 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.interval 6 2)) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))))
private theorem q9Shape5T133OK : treeOK (forms 5) 6211 33164 q9Shape5T133=true := by decide

private def q9Shape5T134 : Tree := (.split 4 (.split 5 (.split 9 (.tip (.interval 6 2)) (.split 10 (.tip (.interval 6 2)) (.split 13 (.split 14 (.tip (.interval 6 2)) (.tip (.unordered 3 4 0))) (.tip (.unordered 3 4 0))))) (.split 9 (.split 10 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.tip (.cover 0 6 7 8)))) (.split 5 (.split 9 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.interval 6 2)) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))))
private theorem q9Shape5T134OK : treeOK (forms 5) 38979 396 q9Shape5T134=true := by decide

private def q9Shape5T132 : Tree := .split 15 q9Shape5T133 q9Shape5T134
private theorem q9Shape5T132OK : treeOK (forms 5) 6211 396 q9Shape5T132=true := by
  change (treeOK (forms 5) 6211 (396 ||| 2^15) q9Shape5T133 &&
    treeOK (forms 5) (6211 ||| 2^15) 396 q9Shape5T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T133OK,q9Shape5T134OK⟩

private def q9Shape5T130 : Tree := .split 11 q9Shape5T131 q9Shape5T132
private theorem q9Shape5T130OK : treeOK (forms 5) 4163 396 q9Shape5T130=true := by
  change (treeOK (forms 5) 4163 (396 ||| 2^11) q9Shape5T131 &&
    treeOK (forms 5) (4163 ||| 2^11) 396 q9Shape5T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T131OK,q9Shape5T132OK⟩

private def q9Shape5T135 : Tree := (.tip (.unordered 3 4 1))
private theorem q9Shape5T135OK : treeOK (forms 5) 4291 268 q9Shape5T135=true := by decide

private def q9Shape5T129 : Tree := .split 7 q9Shape5T130 q9Shape5T135
private theorem q9Shape5T129OK : treeOK (forms 5) 4163 268 q9Shape5T129=true := by
  change (treeOK (forms 5) 4163 (268 ||| 2^7) q9Shape5T130 &&
    treeOK (forms 5) (4163 ||| 2^7) 268 q9Shape5T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T130OK,q9Shape5T135OK⟩

private def q9Shape5T136 : Tree := (.tip (.unordered 2 4 1))
private theorem q9Shape5T136OK : treeOK (forms 5) 4167 264 q9Shape5T136=true := by decide

private def q9Shape5T128 : Tree := .split 2 q9Shape5T129 q9Shape5T136
private theorem q9Shape5T128OK : treeOK (forms 5) 4163 264 q9Shape5T128=true := by
  change (treeOK (forms 5) 4163 (264 ||| 2^2) q9Shape5T129 &&
    treeOK (forms 5) (4163 ||| 2^2) 264 q9Shape5T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T129OK,q9Shape5T136OK⟩

private def q9Shape5T126 : Tree := .split 12 q9Shape5T127 q9Shape5T128
private theorem q9Shape5T126OK : treeOK (forms 5) 67 264 q9Shape5T126=true := by
  change (treeOK (forms 5) 67 (264 ||| 2^12) q9Shape5T127 &&
    treeOK (forms 5) (67 ||| 2^12) 264 q9Shape5T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T127OK,q9Shape5T128OK⟩

private def q9Shape5T140 : Tree := (.split 11 (.tip (.small 0)) (.tip (.unordered 3 4 0)))
private theorem q9Shape5T140OK : treeOK (forms 5) 323 4236 q9Shape5T140=true := by decide

private def q9Shape5T143 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.tip (.interval 6 2)) (.split 13 (.tip (.interval 6 2)) (.split 14 (.tip (.drop 1 4 (some 0) (some 2))) (.tip (.unordered 3 4 0))))) (.split 10 (.split 13 (.tip (.drop 1 4 (some 0) (some 2))) (.tip (.unordered 3 4 0))) (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 3 4 0))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 3 4 0))) (.tip (.unordered 2 3 0))))) (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.tip (.interval 6 3)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))))
private theorem q9Shape5T143OK : treeOK (forms 5) 451 38924 q9Shape5T143=true := by decide

private def q9Shape5T145 : Tree := (.split 5 (.split 9 (.split 10 (.tip (.interval 6 2)) (.split 13 (.tip (.interval 6 2)) (.split 14 (.tip (.drop 1 4 (some 0) (some 2))) (.tip (.unordered 3 4 0))))) (.split 10 (.split 13 (.tip (.drop 1 4 (some 0) (some 2))) (.tip (.unordered 3 4 0))) (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 3 4 0))))) (.split 9 (.tip (.cover 4 5 6 8)) (.split 10 (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 3 4 0))) (.tip (.unordered 2 3 0)))))
private theorem q9Shape5T145OK : treeOK (forms 5) 33219 6172 q9Shape5T145=true := by decide

private def q9Shape5T146 : Tree := (.split 5 (.split 9 (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))
private theorem q9Shape5T146OK : treeOK (forms 5) 33235 6156 q9Shape5T146=true := by decide

private def q9Shape5T144 : Tree := .split 4 q9Shape5T145 q9Shape5T146
private theorem q9Shape5T144OK : treeOK (forms 5) 33219 6156 q9Shape5T144=true := by
  change (treeOK (forms 5) 33219 (6156 ||| 2^4) q9Shape5T145 &&
    treeOK (forms 5) (33219 ||| 2^4) 6156 q9Shape5T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T145OK,q9Shape5T146OK⟩

private def q9Shape5T142 : Tree := .split 15 q9Shape5T143 q9Shape5T144
private theorem q9Shape5T142OK : treeOK (forms 5) 451 6156 q9Shape5T142=true := by
  change (treeOK (forms 5) 451 (6156 ||| 2^15) q9Shape5T143 &&
    treeOK (forms 5) (451 ||| 2^15) 6156 q9Shape5T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T143OK,q9Shape5T144OK⟩

private def q9Shape5T147 : Tree := (.tip (.unordered 3 4 1))
private theorem q9Shape5T147OK : treeOK (forms 5) 2499 4108 q9Shape5T147=true := by decide

private def q9Shape5T141 : Tree := .split 11 q9Shape5T142 q9Shape5T147
private theorem q9Shape5T141OK : treeOK (forms 5) 451 4108 q9Shape5T141=true := by
  change (treeOK (forms 5) 451 (4108 ||| 2^11) q9Shape5T142 &&
    treeOK (forms 5) (451 ||| 2^11) 4108 q9Shape5T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T142OK,q9Shape5T147OK⟩

private def q9Shape5T139 : Tree := .split 7 q9Shape5T140 q9Shape5T141
private theorem q9Shape5T139OK : treeOK (forms 5) 323 4108 q9Shape5T139=true := by
  change (treeOK (forms 5) 323 (4108 ||| 2^7) q9Shape5T140 &&
    treeOK (forms 5) (323 ||| 2^7) 4108 q9Shape5T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T140OK,q9Shape5T141OK⟩

private def q9Shape5T148 : Tree := (.tip (.unordered 2 3 1))
private theorem q9Shape5T148OK : treeOK (forms 5) 327 4104 q9Shape5T148=true := by decide

private def q9Shape5T138 : Tree := .split 2 q9Shape5T139 q9Shape5T148
private theorem q9Shape5T138OK : treeOK (forms 5) 323 4104 q9Shape5T138=true := by
  change (treeOK (forms 5) 323 (4104 ||| 2^2) q9Shape5T139 &&
    treeOK (forms 5) (323 ||| 2^2) 4104 q9Shape5T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T139OK,q9Shape5T148OK⟩

private def q9Shape5T149 : Tree := (.tip (.unordered 3 4 1))
private theorem q9Shape5T149OK : treeOK (forms 5) 4419 8 q9Shape5T149=true := by decide

private def q9Shape5T137 : Tree := .split 12 q9Shape5T138 q9Shape5T149
private theorem q9Shape5T137OK : treeOK (forms 5) 323 8 q9Shape5T137=true := by
  change (treeOK (forms 5) 323 (8 ||| 2^12) q9Shape5T138 &&
    treeOK (forms 5) (323 ||| 2^12) 8 q9Shape5T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T138OK,q9Shape5T149OK⟩

private def q9Shape5T125 : Tree := .split 8 q9Shape5T126 q9Shape5T137
private theorem q9Shape5T125OK : treeOK (forms 5) 67 8 q9Shape5T125=true := by
  change (treeOK (forms 5) 67 (8 ||| 2^8) q9Shape5T126 &&
    treeOK (forms 5) (67 ||| 2^8) 8 q9Shape5T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T126OK,q9Shape5T137OK⟩

private def q9Shape5T153 : Tree := (.split 7 (.split 11 (.tip (.small 0)) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 3 1)))
private theorem q9Shape5T153OK : treeOK (forms 5) 75 4356 q9Shape5T153=true := by decide

private def q9Shape5T157 : Tree := (.split 4 (.split 5 (.split 9 (.tip (.interval 6 3)) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.tip (.interval 6 3)) (.tip (.unordered 2 3 0))))) (.split 9 (.split 10 (.split 13 (.tip (.interval 6 2)) (.split 14 (.tip (.drop 1 4 (some 0) (some 3))) (.tip (.unordered 2 4 0)))) (.tip (.unordered 2 3 0))) (.split 10 (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))) (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.drop 1 4 (some 0) (some 3))) (.tip (.unordered 2 4 0))) (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 4 0)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))))
private theorem q9Shape5T157OK : treeOK (forms 5) 79 39296 q9Shape5T157=true := by decide

private def q9Shape5T159 : Tree := (.split 5 (.split 9 (.split 10 (.tip (.interval 6 2)) (.tip (.cover 4 5 6 8))) (.split 10 (.tip (.cover 4 5 6 7)) (.split 13 (.split 14 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))) (.split 9 (.split 10 (.split 13 (.tip (.interval 6 2)) (.split 14 (.tip (.drop 1 4 (some 0) (some 3))) (.tip (.unordered 2 4 0)))) (.tip (.unordered 2 3 0))) (.split 10 (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0)))))
private theorem q9Shape5T159OK : treeOK (forms 5) 32847 6544 q9Shape5T159=true := by decide

private def q9Shape5T160 : Tree := (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.drop 1 4 (some 0) (some 3))) (.tip (.unordered 2 4 0))) (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 4 0)))) (.tip (.unordered 2 3 0))) (.split 9 (.split 10 (.split 13 (.tip (.interval 6 2)) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 0))))
private theorem q9Shape5T160OK : treeOK (forms 5) 32863 6528 q9Shape5T160=true := by decide

private def q9Shape5T158 : Tree := .split 4 q9Shape5T159 q9Shape5T160
private theorem q9Shape5T158OK : treeOK (forms 5) 32847 6528 q9Shape5T158=true := by
  change (treeOK (forms 5) 32847 (6528 ||| 2^4) q9Shape5T159 &&
    treeOK (forms 5) (32847 ||| 2^4) 6528 q9Shape5T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T159OK,q9Shape5T160OK⟩

private def q9Shape5T156 : Tree := .split 15 q9Shape5T157 q9Shape5T158
private theorem q9Shape5T156OK : treeOK (forms 5) 79 6528 q9Shape5T156=true := by
  change (treeOK (forms 5) 79 (6528 ||| 2^15) q9Shape5T157 &&
    treeOK (forms 5) (79 ||| 2^15) 6528 q9Shape5T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T157OK,q9Shape5T158OK⟩

private def q9Shape5T161 : Tree := (.tip (.unordered 2 4 1))
private theorem q9Shape5T161OK : treeOK (forms 5) 2127 4480 q9Shape5T161=true := by decide

private def q9Shape5T155 : Tree := .split 11 q9Shape5T156 q9Shape5T161
private theorem q9Shape5T155OK : treeOK (forms 5) 79 4480 q9Shape5T155=true := by
  change (treeOK (forms 5) 79 (4480 ||| 2^11) q9Shape5T156 &&
    treeOK (forms 5) (79 ||| 2^11) 4480 q9Shape5T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T156OK,q9Shape5T161OK⟩

private def q9Shape5T162 : Tree := (.tip (.unordered 2 3 1))
private theorem q9Shape5T162OK : treeOK (forms 5) 207 4352 q9Shape5T162=true := by decide

private def q9Shape5T154 : Tree := .split 7 q9Shape5T155 q9Shape5T162
private theorem q9Shape5T154OK : treeOK (forms 5) 79 4352 q9Shape5T154=true := by
  change (treeOK (forms 5) 79 (4352 ||| 2^7) q9Shape5T155 &&
    treeOK (forms 5) (79 ||| 2^7) 4352 q9Shape5T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T155OK,q9Shape5T162OK⟩

private def q9Shape5T152 : Tree := .split 2 q9Shape5T153 q9Shape5T154
private theorem q9Shape5T152OK : treeOK (forms 5) 75 4352 q9Shape5T152=true := by
  change (treeOK (forms 5) 75 (4352 ||| 2^2) q9Shape5T153 &&
    treeOK (forms 5) (75 ||| 2^2) 4352 q9Shape5T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T153OK,q9Shape5T154OK⟩

private def q9Shape5T163 : Tree := (.tip (.unordered 2 4 1))
private theorem q9Shape5T163OK : treeOK (forms 5) 4171 256 q9Shape5T163=true := by decide

private def q9Shape5T151 : Tree := .split 12 q9Shape5T152 q9Shape5T163
private theorem q9Shape5T151OK : treeOK (forms 5) 75 256 q9Shape5T151=true := by
  change (treeOK (forms 5) 75 (256 ||| 2^12) q9Shape5T152 &&
    treeOK (forms 5) (75 ||| 2^12) 256 q9Shape5T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T152OK,q9Shape5T163OK⟩

private def q9Shape5T164 : Tree := (.split 12 (.tip (.unordered 2 3 1)) (.tip (.unordered 2 3 0)))
private theorem q9Shape5T164OK : treeOK (forms 5) 331 0 q9Shape5T164=true := by decide

private def q9Shape5T150 : Tree := .split 8 q9Shape5T151 q9Shape5T164
private theorem q9Shape5T150OK : treeOK (forms 5) 75 0 q9Shape5T150=true := by
  change (treeOK (forms 5) 75 (0 ||| 2^8) q9Shape5T151 &&
    treeOK (forms 5) (75 ||| 2^8) 0 q9Shape5T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T151OK,q9Shape5T164OK⟩

private def q9Shape5T124 : Tree := .split 3 q9Shape5T125 q9Shape5T150
private theorem q9Shape5T124OK : treeOK (forms 5) 67 0 q9Shape5T124=true := by
  change (treeOK (forms 5) 67 (0 ||| 2^3) q9Shape5T125 &&
    treeOK (forms 5) (67 ||| 2^3) 0 q9Shape5T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T125OK,q9Shape5T150OK⟩

private def q9Shape5T86 : Tree := .split 6 q9Shape5T87 q9Shape5T124
private theorem q9Shape5T86OK : treeOK (forms 5) 3 0 q9Shape5T86=true := by
  change (treeOK (forms 5) 3 (0 ||| 2^6) q9Shape5T87 &&
    treeOK (forms 5) (3 ||| 2^6) 0 q9Shape5T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T87OK,q9Shape5T124OK⟩

private def q9Shape5T42 : Tree := .split 1 q9Shape5T43 q9Shape5T86
private theorem q9Shape5T42OK : treeOK (forms 5) 1 0 q9Shape5T42=true := by
  change (treeOK (forms 5) 1 (0 ||| 2^1) q9Shape5T43 &&
    treeOK (forms 5) (1 ||| 2^1) 0 q9Shape5T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T43OK,q9Shape5T86OK⟩

private def q9Shape5T0 : Tree := .split 0 q9Shape5T1 q9Shape5T42
private theorem q9Shape5T0OK : treeOK (forms 5) 0 0 q9Shape5T0=true := by
  change (treeOK (forms 5) 0 (0 ||| 2^0) q9Shape5T1 &&
    treeOK (forms 5) (0 ||| 2^0) 0 q9Shape5T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape5T1OK,q9Shape5T42OK⟩


theorem q9Shape5_cover (b : Nat→Bool) (H : Ranked (adj (forms 5) b)) :
    ∃ u v w z,Effective (adj (forms 5) b) (adj (forms 5) b) u v w z :=
  checked_tree (forms 5) b H q9Shape5T0 q9Shape5T0OK

#print axioms q9Shape5_cover
end Graffiti384b.Q9
