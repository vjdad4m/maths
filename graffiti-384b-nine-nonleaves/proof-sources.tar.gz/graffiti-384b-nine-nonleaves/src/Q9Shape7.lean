import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape7T2 : Tree := (.tip (.small 1))
private theorem q9Shape7T2OK : treeOK (forms 7) 0 17 q9Shape7T2=true := by decide

private def q9Shape7T4 : Tree := (.tip (.small 1))
private theorem q9Shape7T4OK : treeOK (forms 7) 16 33 q9Shape7T4=true := by decide

private def q9Shape7T6 : Tree := (.tip (.small 1))
private theorem q9Shape7T6OK : treeOK (forms 7) 48 513 q9Shape7T6=true := by decide

private def q9Shape7T8 : Tree := (.tip (.small 1))
private theorem q9Shape7T8OK : treeOK (forms 7) 560 1025 q9Shape7T8=true := by decide

private def q9Shape7T10 : Tree := (.split 12 (.split 15 (.split 1 (.split 2 (.tip (.small 0)) (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 4)))) (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 1 2 6)))) (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 2 3 4 5))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 1 2 5)))) (.split 15 (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 2 3 5 6))) (.tip (.cover 2 3 4 5))))
private theorem q9Shape7T10OK : treeOK (forms 7) 1584 2049 q9Shape7T10=true := by decide

private def q9Shape7T11 : Tree := (.split 12 (.split 15 (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 4))) (.tip (.cover 2 3 4 6))) (.tip (.cover 2 3 5 6))) (.tip (.cover 2 3 4 6))) (.tip (.cover 2 3 5 6)))
private theorem q9Shape7T11OK : treeOK (forms 7) 3632 1 q9Shape7T11=true := by decide

private def q9Shape7T9 : Tree := .split 11 q9Shape7T10 q9Shape7T11
private theorem q9Shape7T9OK : treeOK (forms 7) 1584 1 q9Shape7T9=true := by
  change (treeOK (forms 7) 1584 (1 ||| 2^11) q9Shape7T10 &&
    treeOK (forms 7) (1584 ||| 2^11) 1 q9Shape7T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T10OK,q9Shape7T11OK⟩

private def q9Shape7T7 : Tree := .split 10 q9Shape7T8 q9Shape7T9
private theorem q9Shape7T7OK : treeOK (forms 7) 560 1 q9Shape7T7=true := by
  change (treeOK (forms 7) 560 (1 ||| 2^10) q9Shape7T8 &&
    treeOK (forms 7) (560 ||| 2^10) 1 q9Shape7T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T8OK,q9Shape7T9OK⟩

private def q9Shape7T5 : Tree := .split 9 q9Shape7T6 q9Shape7T7
private theorem q9Shape7T5OK : treeOK (forms 7) 48 1 q9Shape7T5=true := by
  change (treeOK (forms 7) 48 (1 ||| 2^9) q9Shape7T6 &&
    treeOK (forms 7) (48 ||| 2^9) 1 q9Shape7T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T6OK,q9Shape7T7OK⟩

private def q9Shape7T3 : Tree := .split 5 q9Shape7T4 q9Shape7T5
private theorem q9Shape7T3OK : treeOK (forms 7) 16 1 q9Shape7T3=true := by
  change (treeOK (forms 7) 16 (1 ||| 2^5) q9Shape7T4 &&
    treeOK (forms 7) (16 ||| 2^5) 1 q9Shape7T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T4OK,q9Shape7T5OK⟩

private def q9Shape7T1 : Tree := .split 4 q9Shape7T2 q9Shape7T3
private theorem q9Shape7T1OK : treeOK (forms 7) 0 1 q9Shape7T1=true := by
  change (treeOK (forms 7) 0 (1 ||| 2^4) q9Shape7T2 &&
    treeOK (forms 7) (0 ||| 2^4) 1 q9Shape7T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T2OK,q9Shape7T3OK⟩

private def q9Shape7T14 : Tree := (.tip (.small 1))
private theorem q9Shape7T14OK : treeOK (forms 7) 1 48 q9Shape7T14=true := by decide

private def q9Shape7T16 : Tree := (.tip (.small 1))
private theorem q9Shape7T16OK : treeOK (forms 7) 33 528 q9Shape7T16=true := by decide

private def q9Shape7T18 : Tree := (.tip (.small 1))
private theorem q9Shape7T18OK : treeOK (forms 7) 545 1040 q9Shape7T18=true := by decide

private def q9Shape7T22 : Tree := (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 3 6))))) (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0)))) (.split 6 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 3 1))))) (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 7)))))
private theorem q9Shape7T22OK : treeOK (forms 7) 1569 38928 q9Shape7T22=true := by decide

private def q9Shape7T23 : Tree := (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.cover 0 1 3 5))) (.split 6 (.tip (.cover 0 5 7 8)) (.tip (.cover 0 1 3 5)))) (.split 3 (.split 6 (.tip (.cover 0 5 7 8)) (.tip (.cover 0 1 3 5))) (.split 6 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 3 1))))) (.split 2 (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 3 4 6))) (.tip (.unordered 2 3 1))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 7)))))
private theorem q9Shape7T23OK : treeOK (forms 7) 34337 6160 q9Shape7T23=true := by decide

private def q9Shape7T21 : Tree := .split 15 q9Shape7T22 q9Shape7T23
private theorem q9Shape7T21OK : treeOK (forms 7) 1569 6160 q9Shape7T21=true := by
  change (treeOK (forms 7) 1569 (6160 ||| 2^15) q9Shape7T22 &&
    treeOK (forms 7) (1569 ||| 2^15) 6160 q9Shape7T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T22OK,q9Shape7T23OK⟩

private def q9Shape7T26 : Tree := (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 3 5 6)))) (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))))
private theorem q9Shape7T26OK : treeOK (forms 7) 5665 34834 q9Shape7T26=true := by decide

private def q9Shape7T27 : Tree := (.split 2 (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 3 4))) (.tip (.unordered 2 3 1))) (.split 6 (.split 7 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 7))))
private theorem q9Shape7T27OK : treeOK (forms 7) 5667 34832 q9Shape7T27=true := by decide

private def q9Shape7T25 : Tree := .split 1 q9Shape7T26 q9Shape7T27
private theorem q9Shape7T25OK : treeOK (forms 7) 5665 34832 q9Shape7T25=true := by
  change (treeOK (forms 7) 5665 (34832 ||| 2^1) q9Shape7T26 &&
    treeOK (forms 7) (5665 ||| 2^1) 34832 q9Shape7T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T26OK,q9Shape7T27OK⟩

private def q9Shape7T28 : Tree := (.tip (.cover 0 1 3 6))
private theorem q9Shape7T28OK : treeOK (forms 7) 38433 2064 q9Shape7T28=true := by decide

private def q9Shape7T24 : Tree := .split 15 q9Shape7T25 q9Shape7T28
private theorem q9Shape7T24OK : treeOK (forms 7) 5665 2064 q9Shape7T24=true := by
  change (treeOK (forms 7) 5665 (2064 ||| 2^15) q9Shape7T25 &&
    treeOK (forms 7) (5665 ||| 2^15) 2064 q9Shape7T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T25OK,q9Shape7T28OK⟩

private def q9Shape7T20 : Tree := .split 12 q9Shape7T21 q9Shape7T24
private theorem q9Shape7T20OK : treeOK (forms 7) 1569 2064 q9Shape7T20=true := by
  change (treeOK (forms 7) 1569 (2064 ||| 2^12) q9Shape7T21 &&
    treeOK (forms 7) (1569 ||| 2^12) 2064 q9Shape7T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T21OK,q9Shape7T24OK⟩

private def q9Shape7T32 : Tree := (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 3 4 6))) (.tip (.cover 1 3 5 6)))) (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))))
private theorem q9Shape7T32OK : treeOK (forms 7) 3617 36882 q9Shape7T32=true := by decide

private def q9Shape7T33 : Tree := (.split 2 (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 3 4 6))) (.tip (.unordered 2 3 1))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 7))))
private theorem q9Shape7T33OK : treeOK (forms 7) 3619 36880 q9Shape7T33=true := by decide

private def q9Shape7T31 : Tree := .split 1 q9Shape7T32 q9Shape7T33
private theorem q9Shape7T31OK : treeOK (forms 7) 3617 36880 q9Shape7T31=true := by
  change (treeOK (forms 7) 3617 (36880 ||| 2^1) q9Shape7T32 &&
    treeOK (forms 7) (3617 ||| 2^1) 36880 q9Shape7T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T32OK,q9Shape7T33OK⟩

private def q9Shape7T34 : Tree := (.tip (.cover 0 1 3 5))
private theorem q9Shape7T34OK : treeOK (forms 7) 36385 4112 q9Shape7T34=true := by decide

private def q9Shape7T30 : Tree := .split 15 q9Shape7T31 q9Shape7T34
private theorem q9Shape7T30OK : treeOK (forms 7) 3617 4112 q9Shape7T30=true := by
  change (treeOK (forms 7) 3617 (4112 ||| 2^15) q9Shape7T31 &&
    treeOK (forms 7) (3617 ||| 2^15) 4112 q9Shape7T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T31OK,q9Shape7T34OK⟩

private def q9Shape7T35 : Tree := (.tip (.cover 0 1 3 4))
private theorem q9Shape7T35OK : treeOK (forms 7) 7713 16 q9Shape7T35=true := by decide

private def q9Shape7T29 : Tree := .split 12 q9Shape7T30 q9Shape7T35
private theorem q9Shape7T29OK : treeOK (forms 7) 3617 16 q9Shape7T29=true := by
  change (treeOK (forms 7) 3617 (16 ||| 2^12) q9Shape7T30 &&
    treeOK (forms 7) (3617 ||| 2^12) 16 q9Shape7T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T30OK,q9Shape7T35OK⟩

private def q9Shape7T19 : Tree := .split 11 q9Shape7T20 q9Shape7T29
private theorem q9Shape7T19OK : treeOK (forms 7) 1569 16 q9Shape7T19=true := by
  change (treeOK (forms 7) 1569 (16 ||| 2^11) q9Shape7T20 &&
    treeOK (forms 7) (1569 ||| 2^11) 16 q9Shape7T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T20OK,q9Shape7T29OK⟩

private def q9Shape7T17 : Tree := .split 10 q9Shape7T18 q9Shape7T19
private theorem q9Shape7T17OK : treeOK (forms 7) 545 16 q9Shape7T17=true := by
  change (treeOK (forms 7) 545 (16 ||| 2^10) q9Shape7T18 &&
    treeOK (forms 7) (545 ||| 2^10) 16 q9Shape7T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T18OK,q9Shape7T19OK⟩

private def q9Shape7T15 : Tree := .split 9 q9Shape7T16 q9Shape7T17
private theorem q9Shape7T15OK : treeOK (forms 7) 33 16 q9Shape7T15=true := by
  change (treeOK (forms 7) 33 (16 ||| 2^9) q9Shape7T16 &&
    treeOK (forms 7) (33 ||| 2^9) 16 q9Shape7T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T16OK,q9Shape7T17OK⟩

private def q9Shape7T13 : Tree := .split 5 q9Shape7T14 q9Shape7T15
private theorem q9Shape7T13OK : treeOK (forms 7) 1 16 q9Shape7T13=true := by
  change (treeOK (forms 7) 1 (16 ||| 2^5) q9Shape7T14 &&
    treeOK (forms 7) (1 ||| 2^5) 16 q9Shape7T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T14OK,q9Shape7T15OK⟩

private def q9Shape7T38 : Tree := (.tip (.small 1))
private theorem q9Shape7T38OK : treeOK (forms 7) 17 544 q9Shape7T38=true := by decide

private def q9Shape7T40 : Tree := (.tip (.small 1))
private theorem q9Shape7T40OK : treeOK (forms 7) 529 1056 q9Shape7T40=true := by decide

private def q9Shape7T44 : Tree := (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 3 6))))) (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0)))) (.split 6 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 3 1))))) (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 8)))))
private theorem q9Shape7T44OK : treeOK (forms 7) 1553 38944 q9Shape7T44=true := by decide

private def q9Shape7T45 : Tree := (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.cover 0 1 3 5))) (.split 6 (.tip (.cover 0 5 7 8)) (.tip (.cover 0 1 3 5)))) (.split 3 (.split 6 (.tip (.cover 0 5 7 8)) (.tip (.cover 0 1 3 5))) (.split 6 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 3 1))))) (.split 2 (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 3 4 6))) (.tip (.unordered 2 3 1))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 8)))))
private theorem q9Shape7T45OK : treeOK (forms 7) 34321 6176 q9Shape7T45=true := by decide

private def q9Shape7T43 : Tree := .split 15 q9Shape7T44 q9Shape7T45
private theorem q9Shape7T43OK : treeOK (forms 7) 1553 6176 q9Shape7T43=true := by
  change (treeOK (forms 7) 1553 (6176 ||| 2^15) q9Shape7T44 &&
    treeOK (forms 7) (1553 ||| 2^15) 6176 q9Shape7T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T44OK,q9Shape7T45OK⟩

private def q9Shape7T48 : Tree := (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 3 4))) (.tip (.cover 1 3 5 6)))) (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))))
private theorem q9Shape7T48OK : treeOK (forms 7) 5649 34850 q9Shape7T48=true := by decide

private def q9Shape7T49 : Tree := (.split 2 (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 0 1 3 4))) (.tip (.unordered 2 3 1))) (.split 6 (.split 7 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape7T49OK : treeOK (forms 7) 5651 34848 q9Shape7T49=true := by decide

private def q9Shape7T47 : Tree := .split 1 q9Shape7T48 q9Shape7T49
private theorem q9Shape7T47OK : treeOK (forms 7) 5649 34848 q9Shape7T47=true := by
  change (treeOK (forms 7) 5649 (34848 ||| 2^1) q9Shape7T48 &&
    treeOK (forms 7) (5649 ||| 2^1) 34848 q9Shape7T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T48OK,q9Shape7T49OK⟩

private def q9Shape7T50 : Tree := (.tip (.cover 0 1 3 6))
private theorem q9Shape7T50OK : treeOK (forms 7) 38417 2080 q9Shape7T50=true := by decide

private def q9Shape7T46 : Tree := .split 15 q9Shape7T47 q9Shape7T50
private theorem q9Shape7T46OK : treeOK (forms 7) 5649 2080 q9Shape7T46=true := by
  change (treeOK (forms 7) 5649 (2080 ||| 2^15) q9Shape7T47 &&
    treeOK (forms 7) (5649 ||| 2^15) 2080 q9Shape7T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T47OK,q9Shape7T50OK⟩

private def q9Shape7T42 : Tree := .split 12 q9Shape7T43 q9Shape7T46
private theorem q9Shape7T42OK : treeOK (forms 7) 1553 2080 q9Shape7T42=true := by
  change (treeOK (forms 7) 1553 (2080 ||| 2^12) q9Shape7T43 &&
    treeOK (forms 7) (1553 ||| 2^12) 2080 q9Shape7T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T43OK,q9Shape7T46OK⟩

private def q9Shape7T54 : Tree := (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 3 4 6))) (.tip (.cover 1 3 5 6)))) (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.cover 1 3 5 6))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))))
private theorem q9Shape7T54OK : treeOK (forms 7) 3601 36898 q9Shape7T54=true := by decide

private def q9Shape7T55 : Tree := (.split 2 (.split 3 (.split 6 (.split 7 (.tip (.small 0)) (.tip (.cover 1 3 4 6))) (.tip (.unordered 2 3 1))) (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 6 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape7T55OK : treeOK (forms 7) 3603 36896 q9Shape7T55=true := by decide

private def q9Shape7T53 : Tree := .split 1 q9Shape7T54 q9Shape7T55
private theorem q9Shape7T53OK : treeOK (forms 7) 3601 36896 q9Shape7T53=true := by
  change (treeOK (forms 7) 3601 (36896 ||| 2^1) q9Shape7T54 &&
    treeOK (forms 7) (3601 ||| 2^1) 36896 q9Shape7T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T54OK,q9Shape7T55OK⟩

private def q9Shape7T56 : Tree := (.tip (.cover 0 1 3 5))
private theorem q9Shape7T56OK : treeOK (forms 7) 36369 4128 q9Shape7T56=true := by decide

private def q9Shape7T52 : Tree := .split 15 q9Shape7T53 q9Shape7T56
private theorem q9Shape7T52OK : treeOK (forms 7) 3601 4128 q9Shape7T52=true := by
  change (treeOK (forms 7) 3601 (4128 ||| 2^15) q9Shape7T53 &&
    treeOK (forms 7) (3601 ||| 2^15) 4128 q9Shape7T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T53OK,q9Shape7T56OK⟩

private def q9Shape7T57 : Tree := (.tip (.cover 0 1 3 4))
private theorem q9Shape7T57OK : treeOK (forms 7) 7697 32 q9Shape7T57=true := by decide

private def q9Shape7T51 : Tree := .split 12 q9Shape7T52 q9Shape7T57
private theorem q9Shape7T51OK : treeOK (forms 7) 3601 32 q9Shape7T51=true := by
  change (treeOK (forms 7) 3601 (32 ||| 2^12) q9Shape7T52 &&
    treeOK (forms 7) (3601 ||| 2^12) 32 q9Shape7T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T52OK,q9Shape7T57OK⟩

private def q9Shape7T41 : Tree := .split 11 q9Shape7T42 q9Shape7T51
private theorem q9Shape7T41OK : treeOK (forms 7) 1553 32 q9Shape7T41=true := by
  change (treeOK (forms 7) 1553 (32 ||| 2^11) q9Shape7T42 &&
    treeOK (forms 7) (1553 ||| 2^11) 32 q9Shape7T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T42OK,q9Shape7T51OK⟩

private def q9Shape7T39 : Tree := .split 10 q9Shape7T40 q9Shape7T41
private theorem q9Shape7T39OK : treeOK (forms 7) 529 32 q9Shape7T39=true := by
  change (treeOK (forms 7) 529 (32 ||| 2^10) q9Shape7T40 &&
    treeOK (forms 7) (529 ||| 2^10) 32 q9Shape7T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T40OK,q9Shape7T41OK⟩

private def q9Shape7T37 : Tree := .split 9 q9Shape7T38 q9Shape7T39
private theorem q9Shape7T37OK : treeOK (forms 7) 17 32 q9Shape7T37=true := by
  change (treeOK (forms 7) 17 (32 ||| 2^9) q9Shape7T38 &&
    treeOK (forms 7) (17 ||| 2^9) 32 q9Shape7T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T38OK,q9Shape7T39OK⟩

private def q9Shape7T60 : Tree := (.tip (.small 1))
private theorem q9Shape7T60OK : treeOK (forms 7) 49 1536 q9Shape7T60=true := by decide

private def q9Shape7T63 : Tree := (.split 15 (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))))) (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 1 2 4)))) (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 1 2 6)))) (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7))))) (.tip (.cover 1 2 4 5))) (.tip (.cover 1 2 4 6))) (.tip (.cover 0 1 2 5))))
private theorem q9Shape7T63OK : treeOK (forms 7) 1073 6656 q9Shape7T63=true := by decide

private def q9Shape7T64 : Tree := (.split 15 (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 7))))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 6)))
private theorem q9Shape7T64OK : treeOK (forms 7) 5169 2560 q9Shape7T64=true := by decide

private def q9Shape7T62 : Tree := .split 12 q9Shape7T63 q9Shape7T64
private theorem q9Shape7T62OK : treeOK (forms 7) 1073 2560 q9Shape7T62=true := by
  change (treeOK (forms 7) 1073 (2560 ||| 2^12) q9Shape7T63 &&
    treeOK (forms 7) (1073 ||| 2^12) 2560 q9Shape7T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T63OK,q9Shape7T64OK⟩

private def q9Shape7T65 : Tree := (.split 12 (.split 15 (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 4 6))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 1 2 4)))
private theorem q9Shape7T65OK : treeOK (forms 7) 3121 512 q9Shape7T65=true := by decide

private def q9Shape7T61 : Tree := .split 11 q9Shape7T62 q9Shape7T65
private theorem q9Shape7T61OK : treeOK (forms 7) 1073 512 q9Shape7T61=true := by
  change (treeOK (forms 7) 1073 (512 ||| 2^11) q9Shape7T62 &&
    treeOK (forms 7) (1073 ||| 2^11) 512 q9Shape7T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T62OK,q9Shape7T65OK⟩

private def q9Shape7T59 : Tree := .split 10 q9Shape7T60 q9Shape7T61
private theorem q9Shape7T59OK : treeOK (forms 7) 49 512 q9Shape7T59=true := by
  change (treeOK (forms 7) 49 (512 ||| 2^10) q9Shape7T60 &&
    treeOK (forms 7) (49 ||| 2^10) 512 q9Shape7T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T60OK,q9Shape7T61OK⟩

private def q9Shape7T69 : Tree := (.split 15 (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0))))) (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 1 2 4)))) (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.tip (.unordered 2 3 0))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 1 2 6)))) (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 8))))) (.tip (.cover 1 2 4 5))) (.tip (.cover 1 2 4 6))) (.tip (.cover 0 1 2 5))))
private theorem q9Shape7T69OK : treeOK (forms 7) 561 7168 q9Shape7T69=true := by decide

private def q9Shape7T70 : Tree := (.split 15 (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 8))))) (.tip (.cover 1 2 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 6)))
private theorem q9Shape7T70OK : treeOK (forms 7) 4657 3072 q9Shape7T70=true := by decide

private def q9Shape7T68 : Tree := .split 12 q9Shape7T69 q9Shape7T70
private theorem q9Shape7T68OK : treeOK (forms 7) 561 3072 q9Shape7T68=true := by
  change (treeOK (forms 7) 561 (3072 ||| 2^12) q9Shape7T69 &&
    treeOK (forms 7) (561 ||| 2^12) 3072 q9Shape7T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T69OK,q9Shape7T70OK⟩

private def q9Shape7T71 : Tree := (.split 12 (.split 15 (.split 1 (.split 2 (.split 3 (.split 6 (.tip (.small 0)) (.split 7 (.tip (.small 0)) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 4))) (.tip (.cover 1 2 4 6))) (.tip (.cover 1 2 5 6))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 1 2 4)))
private theorem q9Shape7T71OK : treeOK (forms 7) 2609 1024 q9Shape7T71=true := by decide

private def q9Shape7T67 : Tree := .split 11 q9Shape7T68 q9Shape7T71
private theorem q9Shape7T67OK : treeOK (forms 7) 561 1024 q9Shape7T67=true := by
  change (treeOK (forms 7) 561 (1024 ||| 2^11) q9Shape7T68 &&
    treeOK (forms 7) (561 ||| 2^11) 1024 q9Shape7T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T68OK,q9Shape7T71OK⟩

private def q9Shape7T73 : Tree := (.split 12 (.split 15 (.split 1 (.split 2 (.tip (.unordered 2 3 0)) (.split 3 (.tip (.unordered 2 3 0)) (.tip (.cover 0 1 2 4)))) (.split 2 (.split 3 (.tip (.unordered 2 3 0)) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 1 2 6)))) (.split 1 (.split 2 (.split 3 (.tip (.unordered 2 3 0)) (.tip (.cover 2 3 4 5))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 1 2 5)))) (.split 15 (.split 1 (.split 2 (.split 3 (.tip (.unordered 2 3 0)) (.tip (.cover 2 3 4 5))) (.tip (.cover 0 1 2 4))) (.tip (.cover 2 3 5 6))) (.tip (.cover 2 3 4 5))))
private theorem q9Shape7T73OK : treeOK (forms 7) 1585 2048 q9Shape7T73=true := by decide

private def q9Shape7T74 : Tree := (.split 12 (.split 15 (.split 1 (.split 2 (.split 3 (.tip (.unordered 2 3 0)) (.tip (.cover 0 1 2 4))) (.tip (.cover 2 3 4 6))) (.tip (.cover 2 3 5 6))) (.tip (.cover 2 3 4 6))) (.tip (.cover 2 3 5 6)))
private theorem q9Shape7T74OK : treeOK (forms 7) 3633 0 q9Shape7T74=true := by decide

private def q9Shape7T72 : Tree := .split 11 q9Shape7T73 q9Shape7T74
private theorem q9Shape7T72OK : treeOK (forms 7) 1585 0 q9Shape7T72=true := by
  change (treeOK (forms 7) 1585 (0 ||| 2^11) q9Shape7T73 &&
    treeOK (forms 7) (1585 ||| 2^11) 0 q9Shape7T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T73OK,q9Shape7T74OK⟩

private def q9Shape7T66 : Tree := .split 10 q9Shape7T67 q9Shape7T72
private theorem q9Shape7T66OK : treeOK (forms 7) 561 0 q9Shape7T66=true := by
  change (treeOK (forms 7) 561 (0 ||| 2^10) q9Shape7T67 &&
    treeOK (forms 7) (561 ||| 2^10) 0 q9Shape7T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T67OK,q9Shape7T72OK⟩

private def q9Shape7T58 : Tree := .split 9 q9Shape7T59 q9Shape7T66
private theorem q9Shape7T58OK : treeOK (forms 7) 49 0 q9Shape7T58=true := by
  change (treeOK (forms 7) 49 (0 ||| 2^9) q9Shape7T59 &&
    treeOK (forms 7) (49 ||| 2^9) 0 q9Shape7T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T59OK,q9Shape7T66OK⟩

private def q9Shape7T36 : Tree := .split 5 q9Shape7T37 q9Shape7T58
private theorem q9Shape7T36OK : treeOK (forms 7) 17 0 q9Shape7T36=true := by
  change (treeOK (forms 7) 17 (0 ||| 2^5) q9Shape7T37 &&
    treeOK (forms 7) (17 ||| 2^5) 0 q9Shape7T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T37OK,q9Shape7T58OK⟩

private def q9Shape7T12 : Tree := .split 4 q9Shape7T13 q9Shape7T36
private theorem q9Shape7T12OK : treeOK (forms 7) 1 0 q9Shape7T12=true := by
  change (treeOK (forms 7) 1 (0 ||| 2^4) q9Shape7T13 &&
    treeOK (forms 7) (1 ||| 2^4) 0 q9Shape7T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T13OK,q9Shape7T36OK⟩

private def q9Shape7T0 : Tree := .split 0 q9Shape7T1 q9Shape7T12
private theorem q9Shape7T0OK : treeOK (forms 7) 0 0 q9Shape7T0=true := by
  change (treeOK (forms 7) 0 (0 ||| 2^0) q9Shape7T1 &&
    treeOK (forms 7) (0 ||| 2^0) 0 q9Shape7T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape7T1OK,q9Shape7T12OK⟩


theorem q9Shape7_cover (b : Nat→Bool) (H : Ranked (adj (forms 7) b)) :
    ∃ u v w z,Effective (adj (forms 7) b) (adj (forms 7) b) u v w z :=
  checked_tree (forms 7) b H q9Shape7T0 q9Shape7T0OK

#print axioms q9Shape7_cover
end Graffiti384b.Q9
