import Q9MaskKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape8T3 : Tree := (.tip (.small 1))
private theorem q9Shape8T3OK : treeOK (forms 8) 0 67 q9Shape8T3=true := by decide

private def q9Shape8T5 : Tree := (.tip (.small 1))
private theorem q9Shape8T5OK : treeOK (forms 8) 64 19 q9Shape8T5=true := by decide

private def q9Shape8T7 : Tree := (.tip (.small 1))
private theorem q9Shape8T7OK : treeOK (forms 8) 80 515 q9Shape8T7=true := by decide

private def q9Shape8T9 : Tree := (.tip (.small 1))
private theorem q9Shape8T9OK : treeOK (forms 8) 592 8195 q9Shape8T9=true := by decide

private def q9Shape8T11 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 0)) (.tip (.unordered 3 4 0))))) (.split 8 (.split 11 (.tip (.small 0)) (.tip (.unordered 3 4 0))) (.tip (.cover 0 1 3 8)))) (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 2 3 5 8)))) (.tip (.cover 0 2 3 8)))) (.split 3 (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 3 8))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 2 3 6 8))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 1 3 8)))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape8T11OK : treeOK (forms 8) 8784 32771 q9Shape8T11=true := by decide

private def q9Shape8T12 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape8T12OK : treeOK (forms 8) 41552 3 q9Shape8T12=true := by decide

private def q9Shape8T10 : Tree := .split 15 q9Shape8T11 q9Shape8T12
private theorem q9Shape8T10OK : treeOK (forms 8) 8784 3 q9Shape8T10=true := by
  change (treeOK (forms 8) 8784 (3 ||| 2^15) q9Shape8T11 &&
    treeOK (forms 8) (8784 ||| 2^15) 3 q9Shape8T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T11OK,q9Shape8T12OK⟩

private def q9Shape8T8 : Tree := .split 13 q9Shape8T9 q9Shape8T10
private theorem q9Shape8T8OK : treeOK (forms 8) 592 3 q9Shape8T8=true := by
  change (treeOK (forms 8) 592 (3 ||| 2^13) q9Shape8T9 &&
    treeOK (forms 8) (592 ||| 2^13) 3 q9Shape8T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T9OK,q9Shape8T10OK⟩

private def q9Shape8T6 : Tree := .split 9 q9Shape8T7 q9Shape8T8
private theorem q9Shape8T6OK : treeOK (forms 8) 80 3 q9Shape8T6=true := by
  change (treeOK (forms 8) 80 (3 ||| 2^9) q9Shape8T7 &&
    treeOK (forms 8) (80 ||| 2^9) 3 q9Shape8T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T7OK,q9Shape8T8OK⟩

private def q9Shape8T4 : Tree := .split 4 q9Shape8T5 q9Shape8T6
private theorem q9Shape8T4OK : treeOK (forms 8) 64 3 q9Shape8T4=true := by
  change (treeOK (forms 8) 64 (3 ||| 2^4) q9Shape8T5 &&
    treeOK (forms 8) (64 ||| 2^4) 3 q9Shape8T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T5OK,q9Shape8T6OK⟩

private def q9Shape8T2 : Tree := .split 6 q9Shape8T3 q9Shape8T4
private theorem q9Shape8T2OK : treeOK (forms 8) 0 3 q9Shape8T2=true := by
  change (treeOK (forms 8) 0 (3 ||| 2^6) q9Shape8T3 &&
    treeOK (forms 8) (0 ||| 2^6) 3 q9Shape8T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T3OK,q9Shape8T4OK⟩

private def q9Shape8T15 : Tree := (.tip (.small 1))
private theorem q9Shape8T15OK : treeOK (forms 8) 2 81 q9Shape8T15=true := by decide

private def q9Shape8T17 : Tree := (.tip (.small 1))
private theorem q9Shape8T17OK : treeOK (forms 8) 18 577 q9Shape8T17=true := by decide

private def q9Shape8T19 : Tree := (.tip (.small 1))
private theorem q9Shape8T19OK : treeOK (forms 8) 530 8257 q9Shape8T19=true := by decide

private def q9Shape8T21 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.tip (.small 0)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 8)))) (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 0)) (.tip (.unordered 2 4 0)))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 2 3 5 8)))) (.tip (.cover 0 2 3 8)))) (.split 3 (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.tip (.unordered 2 4 0))) (.tip (.cover 0 2 3 8))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 2 3 6 8))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 1 3 8)))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape8T21OK : treeOK (forms 8) 8722 32833 q9Shape8T21=true := by decide

private def q9Shape8T22 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape8T22OK : treeOK (forms 8) 41490 65 q9Shape8T22=true := by decide

private def q9Shape8T20 : Tree := .split 15 q9Shape8T21 q9Shape8T22
private theorem q9Shape8T20OK : treeOK (forms 8) 8722 65 q9Shape8T20=true := by
  change (treeOK (forms 8) 8722 (65 ||| 2^15) q9Shape8T21 &&
    treeOK (forms 8) (8722 ||| 2^15) 65 q9Shape8T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T21OK,q9Shape8T22OK⟩

private def q9Shape8T18 : Tree := .split 13 q9Shape8T19 q9Shape8T20
private theorem q9Shape8T18OK : treeOK (forms 8) 530 65 q9Shape8T18=true := by
  change (treeOK (forms 8) 530 (65 ||| 2^13) q9Shape8T19 &&
    treeOK (forms 8) (530 ||| 2^13) 65 q9Shape8T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T19OK,q9Shape8T20OK⟩

private def q9Shape8T16 : Tree := .split 9 q9Shape8T17 q9Shape8T18
private theorem q9Shape8T16OK : treeOK (forms 8) 18 65 q9Shape8T16=true := by
  change (treeOK (forms 8) 18 (65 ||| 2^9) q9Shape8T17 &&
    treeOK (forms 8) (18 ||| 2^9) 65 q9Shape8T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T17OK,q9Shape8T18OK⟩

private def q9Shape8T14 : Tree := .split 4 q9Shape8T15 q9Shape8T16
private theorem q9Shape8T14OK : treeOK (forms 8) 2 65 q9Shape8T14=true := by
  change (treeOK (forms 8) 2 (65 ||| 2^4) q9Shape8T15 &&
    treeOK (forms 8) (2 ||| 2^4) 65 q9Shape8T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T15OK,q9Shape8T16OK⟩

private def q9Shape8T25 : Tree := (.tip (.small 1))
private theorem q9Shape8T25OK : treeOK (forms 8) 66 529 q9Shape8T25=true := by decide

private def q9Shape8T27 : Tree := (.tip (.small 1))
private theorem q9Shape8T27OK : treeOK (forms 8) 578 8209 q9Shape8T27=true := by decide

private def q9Shape8T31 : Tree := (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.split 12 (.tip (.small 0)) (.tip (.unordered 3 4 0))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 3 4 8))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))))
private theorem q9Shape8T31OK : treeOK (forms 8) 8770 32797 q9Shape8T31=true := by decide

private def q9Shape8T32 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 4 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 4 6 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 1 4 8)))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 3 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 2 5 7 8))) (.tip (.unordered 3 4 0))) (.tip (.cover 0 3 4 8))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))))
private theorem q9Shape8T32OK : treeOK (forms 8) 8778 32789 q9Shape8T32=true := by decide

private def q9Shape8T30 : Tree := .split 3 q9Shape8T31 q9Shape8T32
private theorem q9Shape8T30OK : treeOK (forms 8) 8770 32789 q9Shape8T30=true := by
  change (treeOK (forms 8) 8770 (32789 ||| 2^3) q9Shape8T31 &&
    treeOK (forms 8) (8770 ||| 2^3) 32789 q9Shape8T32)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T31OK,q9Shape8T32OK⟩

private def q9Shape8T33 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 3 4 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 5 8)))) (.tip (.cover 0 4 7 8))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 3 4 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.unordered 3 4 0))) (.tip (.cover 2 6 7 8))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 3 4 8))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1)))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape8T33OK : treeOK (forms 8) 8774 32785 q9Shape8T33=true := by decide

private def q9Shape8T29 : Tree := .split 2 q9Shape8T30 q9Shape8T33
private theorem q9Shape8T29OK : treeOK (forms 8) 8770 32785 q9Shape8T29=true := by
  change (treeOK (forms 8) 8770 (32785 ||| 2^2) q9Shape8T30 &&
    treeOK (forms 8) (8770 ||| 2^2) 32785 q9Shape8T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T30OK,q9Shape8T33OK⟩

private def q9Shape8T37 : Tree := (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 1 4 5 8))) (.tip (.cover 1 4 6 8))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 3 4 0)))) (.tip (.cover 3 4 5 8))) (.tip (.cover 1 4 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.unordered 3 4 0))) (.tip (.cover 0 1 5 8))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 3 4 8))))
private theorem q9Shape8T37OK : treeOK (forms 8) 41538 157 q9Shape8T37=true := by decide

private def q9Shape8T38 : Tree := (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 3 4 0)))) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 1 3 8))) (.tip (.cover 1 4 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.unordered 3 4 0))) (.tip (.cover 0 3 4 8))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1)))
private theorem q9Shape8T38OK : treeOK (forms 8) 41666 29 q9Shape8T38=true := by decide

private def q9Shape8T36 : Tree := .split 7 q9Shape8T37 q9Shape8T38
private theorem q9Shape8T36OK : treeOK (forms 8) 41538 29 q9Shape8T36=true := by
  change (treeOK (forms 8) 41538 (29 ||| 2^7) q9Shape8T37 &&
    treeOK (forms 8) (41538 ||| 2^7) 29 q9Shape8T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T37OK,q9Shape8T38OK⟩

private def q9Shape8T39 : Tree := (.tip (.cover 0 6 7 8))
private theorem q9Shape8T39OK : treeOK (forms 8) 41546 21 q9Shape8T39=true := by decide

private def q9Shape8T35 : Tree := .split 3 q9Shape8T36 q9Shape8T39
private theorem q9Shape8T35OK : treeOK (forms 8) 41538 21 q9Shape8T35=true := by
  change (treeOK (forms 8) 41538 (21 ||| 2^3) q9Shape8T36 &&
    treeOK (forms 8) (41538 ||| 2^3) 21 q9Shape8T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T36OK,q9Shape8T39OK⟩

private def q9Shape8T40 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape8T40OK : treeOK (forms 8) 41542 17 q9Shape8T40=true := by decide

private def q9Shape8T34 : Tree := .split 2 q9Shape8T35 q9Shape8T40
private theorem q9Shape8T34OK : treeOK (forms 8) 41538 17 q9Shape8T34=true := by
  change (treeOK (forms 8) 41538 (17 ||| 2^2) q9Shape8T35 &&
    treeOK (forms 8) (41538 ||| 2^2) 17 q9Shape8T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T35OK,q9Shape8T40OK⟩

private def q9Shape8T28 : Tree := .split 15 q9Shape8T29 q9Shape8T34
private theorem q9Shape8T28OK : treeOK (forms 8) 8770 17 q9Shape8T28=true := by
  change (treeOK (forms 8) 8770 (17 ||| 2^15) q9Shape8T29 &&
    treeOK (forms 8) (8770 ||| 2^15) 17 q9Shape8T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T29OK,q9Shape8T34OK⟩

private def q9Shape8T26 : Tree := .split 13 q9Shape8T27 q9Shape8T28
private theorem q9Shape8T26OK : treeOK (forms 8) 578 17 q9Shape8T26=true := by
  change (treeOK (forms 8) 578 (17 ||| 2^13) q9Shape8T27 &&
    treeOK (forms 8) (578 ||| 2^13) 17 q9Shape8T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T27OK,q9Shape8T28OK⟩

private def q9Shape8T24 : Tree := .split 9 q9Shape8T25 q9Shape8T26
private theorem q9Shape8T24OK : treeOK (forms 8) 66 17 q9Shape8T24=true := by
  change (treeOK (forms 8) 66 (17 ||| 2^9) q9Shape8T25 &&
    treeOK (forms 8) (66 ||| 2^9) 17 q9Shape8T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T25OK,q9Shape8T26OK⟩

private def q9Shape8T43 : Tree := (.tip (.small 1))
private theorem q9Shape8T43OK : treeOK (forms 8) 82 8705 q9Shape8T43=true := by decide

private def q9Shape8T47 : Tree := (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 4 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 4 6 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 1 4 8))))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 4 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 5 8)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape8T47OK : treeOK (forms 8) 8274 33293 q9Shape8T47=true := by decide

private def q9Shape8T48 : Tree := (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.unordered 2 4 0))) (.tip (.cover 0 2 4 8))) (.split 11 (.tip (.cover 0 3 7 8)) (.tip (.cover 0 2 4 8)))) (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 4 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.unordered 2 4 0))) (.tip (.cover 3 6 7 8))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape8T48OK : treeOK (forms 8) 8282 33285 q9Shape8T48=true := by decide

private def q9Shape8T46 : Tree := .split 3 q9Shape8T47 q9Shape8T48
private theorem q9Shape8T46OK : treeOK (forms 8) 8274 33285 q9Shape8T46=true := by
  change (treeOK (forms 8) 8274 (33285 ||| 2^3) q9Shape8T47 &&
    treeOK (forms 8) (8274 ||| 2^3) 33285 q9Shape8T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T47OK,q9Shape8T48OK⟩

private def q9Shape8T49 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 4 1))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 3 5 7 8))) (.tip (.unordered 2 4 0))) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 4 1)))) (.split 8 (.split 11 (.split 12 (.tip (.cover 0 3 7 8)) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 3 7 8)))) (.tip (.unordered 2 4 1)))
private theorem q9Shape8T49OK : treeOK (forms 8) 8278 33281 q9Shape8T49=true := by decide

private def q9Shape8T45 : Tree := .split 2 q9Shape8T46 q9Shape8T49
private theorem q9Shape8T45OK : treeOK (forms 8) 8274 33281 q9Shape8T45=true := by
  change (treeOK (forms 8) 8274 (33281 ||| 2^2) q9Shape8T46 &&
    treeOK (forms 8) (8274 ||| 2^2) 33281 q9Shape8T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T46OK,q9Shape8T49OK⟩

private def q9Shape8T51 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 1 4 5 8))) (.tip (.cover 1 4 6 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.split 7 (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.tip (.cover 2 4 5 8))) (.split 10 (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 5)))) (.tip (.cover 1 4 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.unordered 2 4 0))) (.tip (.cover 0 1 5 8))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 2 4 5 8))))
private theorem q9Shape8T51OK : treeOK (forms 8) 41042 517 q9Shape8T51=true := by decide

private def q9Shape8T52 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.cover 0 4 5 7)) (.tip (.cover 2 4 6 8))) (.split 10 (.split 14 (.tip (.drop 1 4 (some 0) (some 0))) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 6)))) (.tip (.cover 0 1 2 8))) (.tip (.cover 1 4 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.unordered 2 4 0))) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 4 1))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 5 7 8))) (.tip (.unordered 2 4 1)))
private theorem q9Shape8T52OK : treeOK (forms 8) 41046 513 q9Shape8T52=true := by decide

private def q9Shape8T50 : Tree := .split 2 q9Shape8T51 q9Shape8T52
private theorem q9Shape8T50OK : treeOK (forms 8) 41042 513 q9Shape8T50=true := by
  change (treeOK (forms 8) 41042 (513 ||| 2^2) q9Shape8T51 &&
    treeOK (forms 8) (41042 ||| 2^2) 513 q9Shape8T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T51OK,q9Shape8T52OK⟩

private def q9Shape8T44 : Tree := .split 15 q9Shape8T45 q9Shape8T50
private theorem q9Shape8T44OK : treeOK (forms 8) 8274 513 q9Shape8T44=true := by
  change (treeOK (forms 8) 8274 (513 ||| 2^15) q9Shape8T45 &&
    treeOK (forms 8) (8274 ||| 2^15) 513 q9Shape8T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T45OK,q9Shape8T50OK⟩

private def q9Shape8T42 : Tree := .split 13 q9Shape8T43 q9Shape8T44
private theorem q9Shape8T42OK : treeOK (forms 8) 82 513 q9Shape8T42=true := by
  change (treeOK (forms 8) 82 (513 ||| 2^13) q9Shape8T43 &&
    treeOK (forms 8) (82 ||| 2^13) 513 q9Shape8T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T43OK,q9Shape8T44OK⟩

private def q9Shape8T57 : Tree := (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 4 7 8))))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 3 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape8T57OK : treeOK (forms 8) 594 40973 q9Shape8T57=true := by decide

private def q9Shape8T58 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 2 3 8)))
private theorem q9Shape8T58OK : treeOK (forms 8) 602 40965 q9Shape8T58=true := by decide

private def q9Shape8T56 : Tree := .split 3 q9Shape8T57 q9Shape8T58
private theorem q9Shape8T56OK : treeOK (forms 8) 594 40965 q9Shape8T56=true := by
  change (treeOK (forms 8) 594 (40965 ||| 2^3) q9Shape8T57 &&
    treeOK (forms 8) (594 ||| 2^3) 40965 q9Shape8T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T57OK,q9Shape8T58OK⟩

private def q9Shape8T59 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 4 5 7 8))) (.tip (.cover 0 4 7 8)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 3 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape8T59OK : treeOK (forms 8) 598 40961 q9Shape8T59=true := by decide

private def q9Shape8T55 : Tree := .split 2 q9Shape8T56 q9Shape8T59
private theorem q9Shape8T55OK : treeOK (forms 8) 594 40961 q9Shape8T55=true := by
  change (treeOK (forms 8) 594 (40961 ||| 2^2) q9Shape8T56 &&
    treeOK (forms 8) (594 ||| 2^2) 40961 q9Shape8T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T56OK,q9Shape8T59OK⟩

private def q9Shape8T60 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 4 5 7 8))) (.tip (.cover 4 6 7 8))) (.tip (.cover 2 3 5 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 2 3 5 8))) (.tip (.cover 2 3 6 8)))
private theorem q9Shape8T60OK : treeOK (forms 8) 33362 8193 q9Shape8T60=true := by decide

private def q9Shape8T54 : Tree := .split 15 q9Shape8T55 q9Shape8T60
private theorem q9Shape8T54OK : treeOK (forms 8) 594 8193 q9Shape8T54=true := by
  change (treeOK (forms 8) 594 (8193 ||| 2^15) q9Shape8T55 &&
    treeOK (forms 8) (594 ||| 2^15) 8193 q9Shape8T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T55OK,q9Shape8T60OK⟩

private def q9Shape8T61 : Tree := (.split 15 (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 8)))) (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 2 3 8)))) (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 3 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 1 2 8)))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape8T61OK : treeOK (forms 8) 8786 1 q9Shape8T61=true := by decide

private def q9Shape8T53 : Tree := .split 13 q9Shape8T54 q9Shape8T61
private theorem q9Shape8T53OK : treeOK (forms 8) 594 1 q9Shape8T53=true := by
  change (treeOK (forms 8) 594 (1 ||| 2^13) q9Shape8T54 &&
    treeOK (forms 8) (594 ||| 2^13) 1 q9Shape8T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T54OK,q9Shape8T61OK⟩

private def q9Shape8T41 : Tree := .split 9 q9Shape8T42 q9Shape8T53
private theorem q9Shape8T41OK : treeOK (forms 8) 82 1 q9Shape8T41=true := by
  change (treeOK (forms 8) 82 (1 ||| 2^9) q9Shape8T42 &&
    treeOK (forms 8) (82 ||| 2^9) 1 q9Shape8T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T42OK,q9Shape8T53OK⟩

private def q9Shape8T23 : Tree := .split 4 q9Shape8T24 q9Shape8T41
private theorem q9Shape8T23OK : treeOK (forms 8) 66 1 q9Shape8T23=true := by
  change (treeOK (forms 8) 66 (1 ||| 2^4) q9Shape8T24 &&
    treeOK (forms 8) (66 ||| 2^4) 1 q9Shape8T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T24OK,q9Shape8T41OK⟩

private def q9Shape8T13 : Tree := .split 6 q9Shape8T14 q9Shape8T23
private theorem q9Shape8T13OK : treeOK (forms 8) 2 1 q9Shape8T13=true := by
  change (treeOK (forms 8) 2 (1 ||| 2^6) q9Shape8T14 &&
    treeOK (forms 8) (2 ||| 2^6) 1 q9Shape8T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T14OK,q9Shape8T23OK⟩

private def q9Shape8T1 : Tree := .split 1 q9Shape8T2 q9Shape8T13
private theorem q9Shape8T1OK : treeOK (forms 8) 0 1 q9Shape8T1=true := by
  change (treeOK (forms 8) 0 (1 ||| 2^1) q9Shape8T2 &&
    treeOK (forms 8) (0 ||| 2^1) 1 q9Shape8T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T2OK,q9Shape8T13OK⟩

private def q9Shape8T65 : Tree := (.tip (.small 1))
private theorem q9Shape8T65OK : treeOK (forms 8) 1 82 q9Shape8T65=true := by decide

private def q9Shape8T67 : Tree := (.tip (.small 1))
private theorem q9Shape8T67OK : treeOK (forms 8) 17 578 q9Shape8T67=true := by decide

private def q9Shape8T69 : Tree := (.tip (.small 1))
private theorem q9Shape8T69OK : treeOK (forms 8) 529 8258 q9Shape8T69=true := by decide

private def q9Shape8T71 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.split 11 (.tip (.small 0)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.tip (.small 0)) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 8)))) (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 3 1))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 2 4 5 8))) (.tip (.cover 3 4 6 8))) (.tip (.unordered 2 3 1))))) (.split 3 (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.tip (.cover 0 4 7 8))) (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 3 4 5 8))) (.tip (.cover 2 4 6 8)))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape8T71OK : treeOK (forms 8) 8721 32834 q9Shape8T71=true := by decide

private def q9Shape8T72 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape8T72OK : treeOK (forms 8) 41489 66 q9Shape8T72=true := by decide

private def q9Shape8T70 : Tree := .split 15 q9Shape8T71 q9Shape8T72
private theorem q9Shape8T70OK : treeOK (forms 8) 8721 66 q9Shape8T70=true := by
  change (treeOK (forms 8) 8721 (66 ||| 2^15) q9Shape8T71 &&
    treeOK (forms 8) (8721 ||| 2^15) 66 q9Shape8T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T71OK,q9Shape8T72OK⟩

private def q9Shape8T68 : Tree := .split 13 q9Shape8T69 q9Shape8T70
private theorem q9Shape8T68OK : treeOK (forms 8) 529 66 q9Shape8T68=true := by
  change (treeOK (forms 8) 529 (66 ||| 2^13) q9Shape8T69 &&
    treeOK (forms 8) (529 ||| 2^13) 66 q9Shape8T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T69OK,q9Shape8T70OK⟩

private def q9Shape8T66 : Tree := .split 9 q9Shape8T67 q9Shape8T68
private theorem q9Shape8T66OK : treeOK (forms 8) 17 66 q9Shape8T66=true := by
  change (treeOK (forms 8) 17 (66 ||| 2^9) q9Shape8T67 &&
    treeOK (forms 8) (17 ||| 2^9) 66 q9Shape8T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T67OK,q9Shape8T68OK⟩

private def q9Shape8T64 : Tree := .split 4 q9Shape8T65 q9Shape8T66
private theorem q9Shape8T64OK : treeOK (forms 8) 1 66 q9Shape8T64=true := by
  change (treeOK (forms 8) 1 (66 ||| 2^4) q9Shape8T65 &&
    treeOK (forms 8) (1 ||| 2^4) 66 q9Shape8T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T65OK,q9Shape8T66OK⟩

private def q9Shape8T75 : Tree := (.tip (.small 1))
private theorem q9Shape8T75OK : treeOK (forms 8) 65 530 q9Shape8T75=true := by decide

private def q9Shape8T77 : Tree := (.tip (.small 1))
private theorem q9Shape8T77OK : treeOK (forms 8) 577 8210 q9Shape8T77=true := by decide

private def q9Shape8T81 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 0)) (.tip (.unordered 3 4 0)))) (.split 11 (.tip (.cover 0 3 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 3 4 8))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape8T81OK : treeOK (forms 8) 8769 32798 q9Shape8T81=true := by decide

private def q9Shape8T82 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 4 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 2 5 7 8))) (.tip (.unordered 3 4 0))) (.tip (.unordered 3 4 1)))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 3 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 3 6 8))) (.tip (.cover 3 6 7 8))) (.tip (.cover 0 3 4 8))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape8T82OK : treeOK (forms 8) 8777 32790 q9Shape8T82=true := by decide

private def q9Shape8T80 : Tree := .split 3 q9Shape8T81 q9Shape8T82
private theorem q9Shape8T80OK : treeOK (forms 8) 8769 32790 q9Shape8T80=true := by
  change (treeOK (forms 8) 8769 (32790 ||| 2^3) q9Shape8T81 &&
    treeOK (forms 8) (8769 ||| 2^3) 32790 q9Shape8T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T81OK,q9Shape8T82OK⟩

private def q9Shape8T83 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 3 4 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.unordered 3 4 0))) (.tip (.cover 2 6 7 8)))) (.split 12 (.tip (.cover 0 2 7 8)) (.tip (.unordered 3 4 1)))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 3 4 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.cover 3 5 7 8))) (.tip (.cover 0 3 5 8))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 3 4 8))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 1 3 8)))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape8T83OK : treeOK (forms 8) 8773 32786 q9Shape8T83=true := by decide

private def q9Shape8T79 : Tree := .split 2 q9Shape8T80 q9Shape8T83
private theorem q9Shape8T79OK : treeOK (forms 8) 8769 32786 q9Shape8T79=true := by
  change (treeOK (forms 8) 8769 (32786 ||| 2^2) q9Shape8T80 &&
    treeOK (forms 8) (8769 ||| 2^2) 32786 q9Shape8T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T80OK,q9Shape8T83OK⟩

private def q9Shape8T86 : Tree := (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.unordered 3 4 0)))) (.tip (.cover 3 4 5 8))) (.tip (.cover 1 3 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.unordered 3 4 0))) (.tip (.cover 0 1 5 8)))) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.unordered 3 4 0)))) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 1 4 8))) (.tip (.cover 1 3 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.unordered 3 4 0))) (.tip (.unordered 3 4 1)))) (.tip (.cover 1 3 5 8))) (.tip (.cover 1 3 6 8)))
private theorem q9Shape8T86OK : treeOK (forms 8) 41537 30 q9Shape8T86=true := by decide

private def q9Shape8T87 : Tree := (.tip (.cover 0 6 7 8))
private theorem q9Shape8T87OK : treeOK (forms 8) 41545 22 q9Shape8T87=true := by decide

private def q9Shape8T85 : Tree := .split 3 q9Shape8T86 q9Shape8T87
private theorem q9Shape8T85OK : treeOK (forms 8) 41537 22 q9Shape8T85=true := by
  change (treeOK (forms 8) 41537 (22 ||| 2^3) q9Shape8T86 &&
    treeOK (forms 8) (41537 ||| 2^3) 22 q9Shape8T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T86OK,q9Shape8T87OK⟩

private def q9Shape8T88 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape8T88OK : treeOK (forms 8) 41541 18 q9Shape8T88=true := by decide

private def q9Shape8T84 : Tree := .split 2 q9Shape8T85 q9Shape8T88
private theorem q9Shape8T84OK : treeOK (forms 8) 41537 18 q9Shape8T84=true := by
  change (treeOK (forms 8) 41537 (18 ||| 2^2) q9Shape8T85 &&
    treeOK (forms 8) (41537 ||| 2^2) 18 q9Shape8T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T85OK,q9Shape8T88OK⟩

private def q9Shape8T78 : Tree := .split 15 q9Shape8T79 q9Shape8T84
private theorem q9Shape8T78OK : treeOK (forms 8) 8769 18 q9Shape8T78=true := by
  change (treeOK (forms 8) 8769 (18 ||| 2^15) q9Shape8T79 &&
    treeOK (forms 8) (8769 ||| 2^15) 18 q9Shape8T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T79OK,q9Shape8T84OK⟩

private def q9Shape8T76 : Tree := .split 13 q9Shape8T77 q9Shape8T78
private theorem q9Shape8T76OK : treeOK (forms 8) 577 18 q9Shape8T76=true := by
  change (treeOK (forms 8) 577 (18 ||| 2^13) q9Shape8T77 &&
    treeOK (forms 8) (577 ||| 2^13) 18 q9Shape8T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T77OK,q9Shape8T78OK⟩

private def q9Shape8T74 : Tree := .split 9 q9Shape8T75 q9Shape8T76
private theorem q9Shape8T74OK : treeOK (forms 8) 65 18 q9Shape8T74=true := by
  change (treeOK (forms 8) 65 (18 ||| 2^9) q9Shape8T75 &&
    treeOK (forms 8) (65 ||| 2^9) 18 q9Shape8T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T75OK,q9Shape8T76OK⟩

private def q9Shape8T91 : Tree := (.tip (.small 1))
private theorem q9Shape8T91OK : treeOK (forms 8) 81 8706 q9Shape8T91=true := by decide

private def q9Shape8T95 : Tree := (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 4 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 3 5 7 8))) (.tip (.cover 0 3 7 8))) (.tip (.unordered 3 4 1))))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 4 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 3 7 8))) (.tip (.cover 3 6 7 8)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape8T95OK : treeOK (forms 8) 8273 33294 q9Shape8T95=true := by decide

private def q9Shape8T96 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8)))) (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 4 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.cover 0 3 7 8))) (.tip (.cover 3 6 7 8))) (.tip (.cover 2 4 5 8))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape8T96OK : treeOK (forms 8) 8281 33286 q9Shape8T96=true := by decide

private def q9Shape8T94 : Tree := .split 3 q9Shape8T95 q9Shape8T96
private theorem q9Shape8T94OK : treeOK (forms 8) 8273 33286 q9Shape8T94=true := by
  change (treeOK (forms 8) 8273 (33286 ||| 2^3) q9Shape8T95 &&
    treeOK (forms 8) (8273 ||| 2^3) 33286 q9Shape8T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T95OK,q9Shape8T96OK⟩

private def q9Shape8T97 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.tip (.cover 2 4 6 8))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 3 5 7 8))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 2 4 8))) (.tip (.cover 2 4 6 8)))) (.split 8 (.split 11 (.split 12 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape8T97OK : treeOK (forms 8) 8277 33282 q9Shape8T97=true := by decide

private def q9Shape8T93 : Tree := .split 2 q9Shape8T94 q9Shape8T97
private theorem q9Shape8T93OK : treeOK (forms 8) 8273 33282 q9Shape8T93=true := by
  change (treeOK (forms 8) 8273 (33282 ||| 2^2) q9Shape8T94 &&
    treeOK (forms 8) (8273 ||| 2^2) 33282 q9Shape8T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T94OK,q9Shape8T97OK⟩

private def q9Shape8T98 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 2 4 5 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 3 5 7 8))) (.tip (.cover 3 6 7 8))) (.tip (.cover 2 4 5 8))) (.tip (.cover 2 4 6 8)))
private theorem q9Shape8T98OK : treeOK (forms 8) 41041 514 q9Shape8T98=true := by decide

private def q9Shape8T92 : Tree := .split 15 q9Shape8T93 q9Shape8T98
private theorem q9Shape8T92OK : treeOK (forms 8) 8273 514 q9Shape8T92=true := by
  change (treeOK (forms 8) 8273 (514 ||| 2^15) q9Shape8T93 &&
    treeOK (forms 8) (8273 ||| 2^15) 514 q9Shape8T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T93OK,q9Shape8T98OK⟩

private def q9Shape8T90 : Tree := .split 13 q9Shape8T91 q9Shape8T92
private theorem q9Shape8T90OK : treeOK (forms 8) 81 514 q9Shape8T90=true := by
  change (treeOK (forms 8) 81 (514 ||| 2^13) q9Shape8T91 &&
    treeOK (forms 8) (81 ||| 2^13) 514 q9Shape8T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T91OK,q9Shape8T92OK⟩

private def q9Shape8T103 : Tree := (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.cover 3 5 7 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 4 7 8))))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 3 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 3 6 8))) (.tip (.cover 3 6 7 8)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape8T103OK : treeOK (forms 8) 593 40974 q9Shape8T103=true := by decide

private def q9Shape8T104 : Tree := (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 4 7 8))) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.unordered 2 3 0))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 4 7 8)))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 8)))
private theorem q9Shape8T104OK : treeOK (forms 8) 601 40966 q9Shape8T104=true := by decide

private def q9Shape8T102 : Tree := .split 3 q9Shape8T103 q9Shape8T104
private theorem q9Shape8T102OK : treeOK (forms 8) 593 40966 q9Shape8T102=true := by
  change (treeOK (forms 8) 593 (40966 ||| 2^3) q9Shape8T103 &&
    treeOK (forms 8) (593 ||| 2^3) 40966 q9Shape8T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T103OK,q9Shape8T104OK⟩

private def q9Shape8T105 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 4 5 7 8))) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 3 8))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))
private theorem q9Shape8T105OK : treeOK (forms 8) 597 40962 q9Shape8T105=true := by decide

private def q9Shape8T101 : Tree := .split 2 q9Shape8T102 q9Shape8T105
private theorem q9Shape8T101OK : treeOK (forms 8) 593 40962 q9Shape8T101=true := by
  change (treeOK (forms 8) 593 (40962 ||| 2^2) q9Shape8T102 &&
    treeOK (forms 8) (593 ||| 2^2) 40962 q9Shape8T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T102OK,q9Shape8T105OK⟩

private def q9Shape8T107 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 1 3 5 8))) (.tip (.cover 1 3 6 8))) (.split 7 (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.cover 2 3 4 5)))) (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.unordered 2 3 0)))) (.tip (.cover 1 3 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.unordered 2 3 0))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 2 3 5 8))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 8))))
private theorem q9Shape8T107OK : treeOK (forms 8) 33361 8198 q9Shape8T107=true := by decide

private def q9Shape8T108 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.cover 2 3 4 6)))) (.split 10 (.tip (.drop 1 3 (some 0) (some 0))) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 1 2 8))) (.tip (.cover 1 3 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.unordered 2 3 0))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 2 3 8))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))
private theorem q9Shape8T108OK : treeOK (forms 8) 33365 8194 q9Shape8T108=true := by decide

private def q9Shape8T106 : Tree := .split 2 q9Shape8T107 q9Shape8T108
private theorem q9Shape8T106OK : treeOK (forms 8) 33361 8194 q9Shape8T106=true := by
  change (treeOK (forms 8) 33361 (8194 ||| 2^2) q9Shape8T107 &&
    treeOK (forms 8) (33361 ||| 2^2) 8194 q9Shape8T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T107OK,q9Shape8T108OK⟩

private def q9Shape8T100 : Tree := .split 15 q9Shape8T101 q9Shape8T106
private theorem q9Shape8T100OK : treeOK (forms 8) 593 8194 q9Shape8T100=true := by
  change (treeOK (forms 8) 593 (8194 ||| 2^15) q9Shape8T101 &&
    treeOK (forms 8) (593 ||| 2^15) 8194 q9Shape8T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T101OK,q9Shape8T106OK⟩

private def q9Shape8T111 : Tree := (.split 3 (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 8)))) (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 2 3 5 8)))) (.tip (.cover 0 2 3 8))))
private theorem q9Shape8T111OK : treeOK (forms 8) 8785 32774 q9Shape8T111=true := by decide

private def q9Shape8T112 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 3 8))) (.split 8 (.split 11 (.split 12 (.tip (.unordered 2 3 0)) (.tip (.cover 2 3 6 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 1 3 8)))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape8T112OK : treeOK (forms 8) 8789 32770 q9Shape8T112=true := by decide

private def q9Shape8T110 : Tree := .split 2 q9Shape8T111 q9Shape8T112
private theorem q9Shape8T110OK : treeOK (forms 8) 8785 32770 q9Shape8T110=true := by
  change (treeOK (forms 8) 8785 (32770 ||| 2^2) q9Shape8T111 &&
    treeOK (forms 8) (8785 ||| 2^2) 32770 q9Shape8T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T111OK,q9Shape8T112OK⟩

private def q9Shape8T113 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape8T113OK : treeOK (forms 8) 41553 2 q9Shape8T113=true := by decide

private def q9Shape8T109 : Tree := .split 15 q9Shape8T110 q9Shape8T113
private theorem q9Shape8T109OK : treeOK (forms 8) 8785 2 q9Shape8T109=true := by
  change (treeOK (forms 8) 8785 (2 ||| 2^15) q9Shape8T110 &&
    treeOK (forms 8) (8785 ||| 2^15) 2 q9Shape8T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T110OK,q9Shape8T113OK⟩

private def q9Shape8T99 : Tree := .split 13 q9Shape8T100 q9Shape8T109
private theorem q9Shape8T99OK : treeOK (forms 8) 593 2 q9Shape8T99=true := by
  change (treeOK (forms 8) 593 (2 ||| 2^13) q9Shape8T100 &&
    treeOK (forms 8) (593 ||| 2^13) 2 q9Shape8T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T100OK,q9Shape8T109OK⟩

private def q9Shape8T89 : Tree := .split 9 q9Shape8T90 q9Shape8T99
private theorem q9Shape8T89OK : treeOK (forms 8) 81 2 q9Shape8T89=true := by
  change (treeOK (forms 8) 81 (2 ||| 2^9) q9Shape8T90 &&
    treeOK (forms 8) (81 ||| 2^9) 2 q9Shape8T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T90OK,q9Shape8T99OK⟩

private def q9Shape8T73 : Tree := .split 4 q9Shape8T74 q9Shape8T89
private theorem q9Shape8T73OK : treeOK (forms 8) 65 2 q9Shape8T73=true := by
  change (treeOK (forms 8) 65 (2 ||| 2^4) q9Shape8T74 &&
    treeOK (forms 8) (65 ||| 2^4) 2 q9Shape8T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T74OK,q9Shape8T89OK⟩

private def q9Shape8T63 : Tree := .split 6 q9Shape8T64 q9Shape8T73
private theorem q9Shape8T63OK : treeOK (forms 8) 1 2 q9Shape8T63=true := by
  change (treeOK (forms 8) 1 (2 ||| 2^6) q9Shape8T64 &&
    treeOK (forms 8) (1 ||| 2^6) 2 q9Shape8T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T64OK,q9Shape8T73OK⟩

private def q9Shape8T117 : Tree := (.tip (.small 1))
private theorem q9Shape8T117OK : treeOK (forms 8) 3 592 q9Shape8T117=true := by decide

private def q9Shape8T119 : Tree := (.tip (.small 1))
private theorem q9Shape8T119OK : treeOK (forms 8) 515 8272 q9Shape8T119=true := by decide

private def q9Shape8T123 : Tree := (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 3 4 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 1 3 8))))
private theorem q9Shape8T123OK : treeOK (forms 8) 8707 32860 q9Shape8T123=true := by decide

private def q9Shape8T124 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 4 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 2 5 7 8))) (.tip (.cover 0 2 7 8))) (.tip (.unordered 2 4 1)))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 3 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 2 5 7 8))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 3 4 8))) (.tip (.cover 3 4 6 8))) (.tip (.unordered 2 3 1))))
private theorem q9Shape8T124OK : treeOK (forms 8) 8715 32852 q9Shape8T124=true := by decide

private def q9Shape8T122 : Tree := .split 3 q9Shape8T123 q9Shape8T124
private theorem q9Shape8T122OK : treeOK (forms 8) 8707 32852 q9Shape8T122=true := by
  change (treeOK (forms 8) 8707 (32852 ||| 2^3) q9Shape8T123 &&
    treeOK (forms 8) (8707 ||| 2^3) 32852 q9Shape8T124)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T123OK,q9Shape8T124OK⟩

private def q9Shape8T125 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 3 4 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 2 7 8))) (.tip (.cover 2 6 7 8)))) (.tip (.cover 0 4 7 8))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 3 4 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.cover 0 2 7 8))) (.tip (.cover 2 6 7 8))) (.tip (.cover 3 4 5 8))) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 3 4 8))) (.tip (.cover 3 4 6 8))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape8T125OK : treeOK (forms 8) 8711 32848 q9Shape8T125=true := by decide

private def q9Shape8T121 : Tree := .split 2 q9Shape8T122 q9Shape8T125
private theorem q9Shape8T121OK : treeOK (forms 8) 8707 32848 q9Shape8T121=true := by
  change (treeOK (forms 8) 8707 (32848 ||| 2^2) q9Shape8T122 &&
    treeOK (forms 8) (8707 ||| 2^2) 32848 q9Shape8T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T122OK,q9Shape8T125OK⟩

private def q9Shape8T126 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 3 4 5 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 3 4 5 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 2 5 7 8))) (.tip (.cover 2 6 7 8)))
private theorem q9Shape8T126OK : treeOK (forms 8) 41475 80 q9Shape8T126=true := by decide

private def q9Shape8T120 : Tree := .split 15 q9Shape8T121 q9Shape8T126
private theorem q9Shape8T120OK : treeOK (forms 8) 8707 80 q9Shape8T120=true := by
  change (treeOK (forms 8) 8707 (80 ||| 2^15) q9Shape8T121 &&
    treeOK (forms 8) (8707 ||| 2^15) 80 q9Shape8T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T121OK,q9Shape8T126OK⟩

private def q9Shape8T118 : Tree := .split 13 q9Shape8T119 q9Shape8T120
private theorem q9Shape8T118OK : treeOK (forms 8) 515 80 q9Shape8T118=true := by
  change (treeOK (forms 8) 515 (80 ||| 2^13) q9Shape8T119 &&
    treeOK (forms 8) (515 ||| 2^13) 80 q9Shape8T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T119OK,q9Shape8T120OK⟩

private def q9Shape8T116 : Tree := .split 9 q9Shape8T117 q9Shape8T118
private theorem q9Shape8T116OK : treeOK (forms 8) 3 80 q9Shape8T116=true := by
  change (treeOK (forms 8) 3 (80 ||| 2^9) q9Shape8T117 &&
    treeOK (forms 8) (3 ||| 2^9) 80 q9Shape8T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T117OK,q9Shape8T118OK⟩

private def q9Shape8T129 : Tree := (.tip (.small 1))
private theorem q9Shape8T129OK : treeOK (forms 8) 19 8768 q9Shape8T129=true := by decide

private def q9Shape8T133 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.small 0)) (.split 12 (.tip (.small 0)) (.tip (.unordered 2 4 0)))) (.split 11 (.tip (.cover 0 3 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 4 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 3 5 7 8))) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 4 1))))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 4 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.unordered 2 4 0))) (.tip (.cover 3 6 7 8)))) (.split 12 (.tip (.cover 0 3 7 8)) (.tip (.unordered 2 4 1)))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape8T133OK : treeOK (forms 8) 8211 33356 q9Shape8T133=true := by decide

private def q9Shape8T134 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8)))) (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 4 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 5 7 8))) (.tip (.cover 0 2 5 8))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape8T134OK : treeOK (forms 8) 8219 33348 q9Shape8T134=true := by decide

private def q9Shape8T132 : Tree := .split 3 q9Shape8T133 q9Shape8T134
private theorem q9Shape8T132OK : treeOK (forms 8) 8211 33348 q9Shape8T132=true := by
  change (treeOK (forms 8) 8211 (33348 ||| 2^3) q9Shape8T133 &&
    treeOK (forms 8) (8211 ||| 2^3) 33348 q9Shape8T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T133OK,q9Shape8T134OK⟩

private def q9Shape8T135 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 4 1))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 2 6 7 8))) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 4 1)))) (.split 8 (.split 11 (.split 12 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8))) (.tip (.unordered 2 4 1))) (.tip (.cover 0 3 7 8)))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape8T135OK : treeOK (forms 8) 8215 33344 q9Shape8T135=true := by decide

private def q9Shape8T131 : Tree := .split 2 q9Shape8T132 q9Shape8T135
private theorem q9Shape8T131OK : treeOK (forms 8) 8211 33344 q9Shape8T131=true := by
  change (treeOK (forms 8) 8211 (33344 ||| 2^2) q9Shape8T132 &&
    treeOK (forms 8) (8211 ||| 2^2) 33344 q9Shape8T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T132OK,q9Shape8T135OK⟩

private def q9Shape8T138 : Tree := (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 5)))) (.tip (.cover 1 2 5 8))) (.tip (.cover 0 1 4 8))) (.tip (.unordered 2 4 0))) (.tip (.cover 0 1 5 8)))) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.unordered 2 4 0))) (.tip (.cover 2 3 4 6)))) (.tip (.cover 0 1 4 8))) (.tip (.cover 1 2 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.unordered 2 4 0))) (.tip (.unordered 2 4 1)))) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape8T138OK : treeOK (forms 8) 40979 588 q9Shape8T138=true := by decide

private def q9Shape8T139 : Tree := (.tip (.cover 1 2 5 8))
private theorem q9Shape8T139OK : treeOK (forms 8) 40987 580 q9Shape8T139=true := by decide

private def q9Shape8T137 : Tree := .split 3 q9Shape8T138 q9Shape8T139
private theorem q9Shape8T137OK : treeOK (forms 8) 40979 580 q9Shape8T137=true := by
  change (treeOK (forms 8) 40979 (580 ||| 2^3) q9Shape8T138 &&
    treeOK (forms 8) (40979 ||| 2^3) 580 q9Shape8T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T138OK,q9Shape8T139OK⟩

private def q9Shape8T140 : Tree := (.tip (.cover 1 2 6 8))
private theorem q9Shape8T140OK : treeOK (forms 8) 40983 576 q9Shape8T140=true := by decide

private def q9Shape8T136 : Tree := .split 2 q9Shape8T137 q9Shape8T140
private theorem q9Shape8T136OK : treeOK (forms 8) 40979 576 q9Shape8T136=true := by
  change (treeOK (forms 8) 40979 (576 ||| 2^2) q9Shape8T137 &&
    treeOK (forms 8) (40979 ||| 2^2) 576 q9Shape8T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T137OK,q9Shape8T140OK⟩

private def q9Shape8T130 : Tree := .split 15 q9Shape8T131 q9Shape8T136
private theorem q9Shape8T130OK : treeOK (forms 8) 8211 576 q9Shape8T130=true := by
  change (treeOK (forms 8) 8211 (576 ||| 2^15) q9Shape8T131 &&
    treeOK (forms 8) (8211 ||| 2^15) 576 q9Shape8T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T131OK,q9Shape8T136OK⟩

private def q9Shape8T128 : Tree := .split 13 q9Shape8T129 q9Shape8T130
private theorem q9Shape8T128OK : treeOK (forms 8) 19 576 q9Shape8T128=true := by
  change (treeOK (forms 8) 19 (576 ||| 2^13) q9Shape8T129 &&
    treeOK (forms 8) (19 ||| 2^13) 576 q9Shape8T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T129OK,q9Shape8T130OK⟩

private def q9Shape8T145 : Tree := (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 4 7 8))) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.unordered 2 3 0))) (.tip (.cover 4 6 7 8))) (.tip (.cover 0 4 7 8))))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 3 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 4 5 7 8))) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 4 7 8))) (.tip (.unordered 2 3 1))))
private theorem q9Shape8T145OK : treeOK (forms 8) 531 41036 q9Shape8T145=true := by decide

private def q9Shape8T146 : Tree := (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 2 3 5 8))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 5 7 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 4 7 8)))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 8)))
private theorem q9Shape8T146OK : treeOK (forms 8) 539 41028 q9Shape8T146=true := by decide

private def q9Shape8T144 : Tree := .split 3 q9Shape8T145 q9Shape8T146
private theorem q9Shape8T144OK : treeOK (forms 8) 531 41028 q9Shape8T144=true := by
  change (treeOK (forms 8) 531 (41028 ||| 2^3) q9Shape8T145 &&
    treeOK (forms 8) (531 ||| 2^3) 41028 q9Shape8T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T145OK,q9Shape8T146OK⟩

private def q9Shape8T147 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.split 16 (.split 18 (.split 17 (.split 19 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 0 1 2 8))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 2 6 7 8)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 3 8))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape8T147OK : treeOK (forms 8) 535 41024 q9Shape8T147=true := by decide

private def q9Shape8T143 : Tree := .split 2 q9Shape8T144 q9Shape8T147
private theorem q9Shape8T143OK : treeOK (forms 8) 531 41024 q9Shape8T143=true := by
  change (treeOK (forms 8) 531 (41024 ||| 2^2) q9Shape8T144 &&
    treeOK (forms 8) (531 ||| 2^2) 41024 q9Shape8T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T144OK,q9Shape8T147OK⟩

private def q9Shape8T151 : Tree := (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 6 7 8))) (.tip (.cover 0 5 7 8))) (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.cover 2 3 4 5))) (.tip (.unordered 2 3 0)))) (.tip (.cover 1 2 5 8))) (.tip (.cover 0 1 3 8))) (.tip (.unordered 2 3 0))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 6 7 8))) (.tip (.cover 2 3 5 8))))
private theorem q9Shape8T151OK : treeOK (forms 8) 33299 8396 q9Shape8T151=true := by decide

private def q9Shape8T152 : Tree := (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.split 19 (.split 5 (.tip (.drop 1 2 (some 0) (some 0))) (.split 10 (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.cover 2 3 4 6))) (.tip (.unordered 2 3 0)))) (.tip (.cover 0 1 3 8))) (.tip (.cover 1 2 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.unordered 2 3 0))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 5 7 8))) (.tip (.unordered 2 3 1)))
private theorem q9Shape8T152OK : treeOK (forms 8) 33427 8268 q9Shape8T152=true := by decide

private def q9Shape8T150 : Tree := .split 7 q9Shape8T151 q9Shape8T152
private theorem q9Shape8T150OK : treeOK (forms 8) 33299 8268 q9Shape8T150=true := by
  change (treeOK (forms 8) 33299 (8268 ||| 2^7) q9Shape8T151 &&
    treeOK (forms 8) (33299 ||| 2^7) 8268 q9Shape8T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T151OK,q9Shape8T152OK⟩

private def q9Shape8T153 : Tree := (.tip (.cover 1 2 5 8))
private theorem q9Shape8T153OK : treeOK (forms 8) 33307 8260 q9Shape8T153=true := by decide

private def q9Shape8T149 : Tree := .split 3 q9Shape8T150 q9Shape8T153
private theorem q9Shape8T149OK : treeOK (forms 8) 33299 8260 q9Shape8T149=true := by
  change (treeOK (forms 8) 33299 (8260 ||| 2^3) q9Shape8T150 &&
    treeOK (forms 8) (33299 ||| 2^3) 8260 q9Shape8T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T150OK,q9Shape8T153OK⟩

private def q9Shape8T154 : Tree := (.tip (.cover 1 2 6 8))
private theorem q9Shape8T154OK : treeOK (forms 8) 33303 8256 q9Shape8T154=true := by decide

private def q9Shape8T148 : Tree := .split 2 q9Shape8T149 q9Shape8T154
private theorem q9Shape8T148OK : treeOK (forms 8) 33299 8256 q9Shape8T148=true := by
  change (treeOK (forms 8) 33299 (8256 ||| 2^2) q9Shape8T149 &&
    treeOK (forms 8) (33299 ||| 2^2) 8256 q9Shape8T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T149OK,q9Shape8T154OK⟩

private def q9Shape8T142 : Tree := .split 15 q9Shape8T143 q9Shape8T148
private theorem q9Shape8T142OK : treeOK (forms 8) 531 8256 q9Shape8T142=true := by
  change (treeOK (forms 8) 531 (8256 ||| 2^15) q9Shape8T143 &&
    treeOK (forms 8) (531 ||| 2^15) 8256 q9Shape8T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T143OK,q9Shape8T148OK⟩

private def q9Shape8T157 : Tree := (.split 3 (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.tip (.cover 0 3 4 8)))) (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 3 4 8))) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 1 3 8)))) (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 0 2 4 8))) (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.cover 2 3 5 8)))) (.tip (.cover 0 2 3 8))))
private theorem q9Shape8T157OK : treeOK (forms 8) 8723 32836 q9Shape8T157=true := by decide

private def q9Shape8T158 : Tree := (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.small 0)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 2 3 8))) (.split 8 (.split 11 (.split 12 (.tip (.unordered 2 3 0)) (.tip (.cover 2 3 6 8))) (.tip (.cover 3 4 6 8))) (.tip (.unordered 2 3 1)))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape8T158OK : treeOK (forms 8) 8727 32832 q9Shape8T158=true := by decide

private def q9Shape8T156 : Tree := .split 2 q9Shape8T157 q9Shape8T158
private theorem q9Shape8T156OK : treeOK (forms 8) 8723 32832 q9Shape8T156=true := by
  change (treeOK (forms 8) 8723 (32832 ||| 2^2) q9Shape8T157 &&
    treeOK (forms 8) (8723 ||| 2^2) 32832 q9Shape8T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T157OK,q9Shape8T158OK⟩

private def q9Shape8T159 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape8T159OK : treeOK (forms 8) 41491 64 q9Shape8T159=true := by decide

private def q9Shape8T155 : Tree := .split 15 q9Shape8T156 q9Shape8T159
private theorem q9Shape8T155OK : treeOK (forms 8) 8723 64 q9Shape8T155=true := by
  change (treeOK (forms 8) 8723 (64 ||| 2^15) q9Shape8T156 &&
    treeOK (forms 8) (8723 ||| 2^15) 64 q9Shape8T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T156OK,q9Shape8T159OK⟩

private def q9Shape8T141 : Tree := .split 13 q9Shape8T142 q9Shape8T155
private theorem q9Shape8T141OK : treeOK (forms 8) 531 64 q9Shape8T141=true := by
  change (treeOK (forms 8) 531 (64 ||| 2^13) q9Shape8T142 &&
    treeOK (forms 8) (531 ||| 2^13) 64 q9Shape8T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T142OK,q9Shape8T155OK⟩

private def q9Shape8T127 : Tree := .split 9 q9Shape8T128 q9Shape8T141
private theorem q9Shape8T127OK : treeOK (forms 8) 19 64 q9Shape8T127=true := by
  change (treeOK (forms 8) 19 (64 ||| 2^9) q9Shape8T128 &&
    treeOK (forms 8) (19 ||| 2^9) 64 q9Shape8T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T128OK,q9Shape8T141OK⟩

private def q9Shape8T115 : Tree := .split 4 q9Shape8T116 q9Shape8T127
private theorem q9Shape8T115OK : treeOK (forms 8) 3 64 q9Shape8T115=true := by
  change (treeOK (forms 8) 3 (64 ||| 2^4) q9Shape8T116 &&
    treeOK (forms 8) (3 ||| 2^4) 64 q9Shape8T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T116OK,q9Shape8T127OK⟩

private def q9Shape8T162 : Tree := (.split 13 (.tip (.small 1)) (.split 15 (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.split 2 (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 1 4 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8))) (.tip (.cover 1 4 5 8))) (.tip (.cover 1 4 6 8))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1)))))
private theorem q9Shape8T162OK : treeOK (forms 8) 67 528 q9Shape8T162=true := by decide

private def q9Shape8T163 : Tree := (.split 13 (.split 15 (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.split 11 (.tip (.cover 0 3 7 8)) (.tip (.unordered 3 4 1)))) (.split 8 (.split 11 (.split 12 (.tip (.cover 0 3 7 8)) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.cover 0 1 3 8)))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.split 2 (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 1 3 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8))) (.tip (.unordered 3 4 1))) (.tip (.unordered 3 4 1))) (.tip (.cover 1 3 5 8))) (.tip (.cover 1 3 6 8))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.tip (.unordered 3 4 1)))
private theorem q9Shape8T163OK : treeOK (forms 8) 579 16 q9Shape8T163=true := by decide

private def q9Shape8T161 : Tree := .split 9 q9Shape8T162 q9Shape8T163
private theorem q9Shape8T161OK : treeOK (forms 8) 67 16 q9Shape8T161=true := by
  change (treeOK (forms 8) 67 (16 ||| 2^9) q9Shape8T162 &&
    treeOK (forms 8) (67 ||| 2^9) 16 q9Shape8T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T162OK,q9Shape8T163OK⟩

private def q9Shape8T167 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.cover 0 4 7 8)) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.split 7 (.split 8 (.split 11 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1)))) (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.tip (.cover 0 2 7 8)) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 1 2 8))))
private theorem q9Shape8T167OK : treeOK (forms 8) 83 41472 q9Shape8T167=true := by decide

private def q9Shape8T168 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.split 11 (.split 12 (.split 16 (.split 18 (.split 17 (.tip (.drop 1 6 (some 0) (some 5))) (.tip (.cover 1 2 6 8))) (.tip (.cover 0 1 6 8))) (.tip (.cover 0 1 5 8))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 4 1))) (.tip (.unordered 2 3 1))) (.tip (.unordered 2 3 1))) (.tip (.cover 1 2 5 8))) (.tip (.cover 1 2 6 8)))
private theorem q9Shape8T168OK : treeOK (forms 8) 32851 8704 q9Shape8T168=true := by decide

private def q9Shape8T166 : Tree := .split 15 q9Shape8T167 q9Shape8T168
private theorem q9Shape8T166OK : treeOK (forms 8) 83 8704 q9Shape8T166=true := by
  change (treeOK (forms 8) 83 (8704 ||| 2^15) q9Shape8T167 &&
    treeOK (forms 8) (83 ||| 2^15) 8704 q9Shape8T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T167OK,q9Shape8T168OK⟩

private def q9Shape8T169 : Tree := (.tip (.unordered 2 4 1))
private theorem q9Shape8T169OK : treeOK (forms 8) 8275 512 q9Shape8T169=true := by decide

private def q9Shape8T165 : Tree := .split 13 q9Shape8T166 q9Shape8T169
private theorem q9Shape8T165OK : treeOK (forms 8) 83 512 q9Shape8T165=true := by
  change (treeOK (forms 8) 83 (512 ||| 2^13) q9Shape8T166 &&
    treeOK (forms 8) (83 ||| 2^13) 512 q9Shape8T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T166OK,q9Shape8T169OK⟩

private def q9Shape8T170 : Tree := (.split 13 (.tip (.unordered 2 3 1)) (.tip (.unordered 2 3 1)))
private theorem q9Shape8T170OK : treeOK (forms 8) 595 0 q9Shape8T170=true := by decide

private def q9Shape8T164 : Tree := .split 9 q9Shape8T165 q9Shape8T170
private theorem q9Shape8T164OK : treeOK (forms 8) 83 0 q9Shape8T164=true := by
  change (treeOK (forms 8) 83 (0 ||| 2^9) q9Shape8T165 &&
    treeOK (forms 8) (83 ||| 2^9) 0 q9Shape8T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T165OK,q9Shape8T170OK⟩

private def q9Shape8T160 : Tree := .split 4 q9Shape8T161 q9Shape8T164
private theorem q9Shape8T160OK : treeOK (forms 8) 67 0 q9Shape8T160=true := by
  change (treeOK (forms 8) 67 (0 ||| 2^4) q9Shape8T161 &&
    treeOK (forms 8) (67 ||| 2^4) 0 q9Shape8T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T161OK,q9Shape8T164OK⟩

private def q9Shape8T114 : Tree := .split 6 q9Shape8T115 q9Shape8T160
private theorem q9Shape8T114OK : treeOK (forms 8) 3 0 q9Shape8T114=true := by
  change (treeOK (forms 8) 3 (0 ||| 2^6) q9Shape8T115 &&
    treeOK (forms 8) (3 ||| 2^6) 0 q9Shape8T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T115OK,q9Shape8T160OK⟩

private def q9Shape8T62 : Tree := .split 1 q9Shape8T63 q9Shape8T114
private theorem q9Shape8T62OK : treeOK (forms 8) 1 0 q9Shape8T62=true := by
  change (treeOK (forms 8) 1 (0 ||| 2^1) q9Shape8T63 &&
    treeOK (forms 8) (1 ||| 2^1) 0 q9Shape8T114)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T63OK,q9Shape8T114OK⟩

private def q9Shape8T0 : Tree := .split 0 q9Shape8T1 q9Shape8T62
private theorem q9Shape8T0OK : treeOK (forms 8) 0 0 q9Shape8T0=true := by
  change (treeOK (forms 8) 0 (0 ||| 2^0) q9Shape8T1 &&
    treeOK (forms 8) (0 ||| 2^0) 0 q9Shape8T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape8T1OK,q9Shape8T62OK⟩


theorem q9Shape8_cover (b : Nat→Bool) (H : Ranked (adj (forms 8) b)) :
    ∃ u v w z,Effective (adj (forms 8) b) (adj (forms 8) b) u v w z :=
  checked_tree (forms 8) b H q9Shape8T0 q9Shape8T0OK

#print axioms q9Shape8_cover
end Graffiti384b.Q9
