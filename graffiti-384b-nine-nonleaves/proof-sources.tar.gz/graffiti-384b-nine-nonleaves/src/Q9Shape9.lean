import Q9FastKernel384b

namespace Graffiti384b.Q9
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q9Shape9T7 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape9T7OK : fastTreeOK (forms 9) 0 1872136 q9Shape9T7=true := by decide

private def q9Shape9T12 : Tree := (.tip (.cover 0 1 4 5))
private theorem q9Shape9T12OK : fastTreeOK (forms 9) 32768 1840952 q9Shape9T12=true := by decide

private def q9Shape9T14 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape9T14OK : fastTreeOK (forms 9) 33792 1848120 q9Shape9T14=true := by decide

private def q9Shape9T16 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 6 8)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2))))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))))
private theorem q9Shape9T16OK : fastTreeOK (forms 9) 41984 1856312 q9Shape9T16=true := by decide

private def q9Shape9T17 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 4 5))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 4 5))))
private theorem q9Shape9T17OK : fastTreeOK (forms 9) 58368 1839928 q9Shape9T17=true := by decide

private def q9Shape9T15 : Tree := .split 14 q9Shape9T16 q9Shape9T17
private theorem q9Shape9T15OK : fastTreeOK (forms 9) 41984 1839928 q9Shape9T15=true := by
  change (fastTreeOK (forms 9) 41984 (1839928 ||| 2^14) q9Shape9T16 &&
    fastTreeOK (forms 9) (41984 ||| 2^14) 1839928 q9Shape9T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T16OK,q9Shape9T17OK⟩

private def q9Shape9T13 : Tree := .split 13 q9Shape9T14 q9Shape9T15
private theorem q9Shape9T13OK : fastTreeOK (forms 9) 33792 1839928 q9Shape9T13=true := by
  change (fastTreeOK (forms 9) 33792 (1839928 ||| 2^13) q9Shape9T14 &&
    fastTreeOK (forms 9) (33792 ||| 2^13) 1839928 q9Shape9T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T14OK,q9Shape9T15OK⟩

private def q9Shape9T11 : Tree := .split 10 q9Shape9T12 q9Shape9T13
private theorem q9Shape9T11OK : fastTreeOK (forms 9) 32768 1839928 q9Shape9T11=true := by
  change (fastTreeOK (forms 9) 32768 (1839928 ||| 2^10) q9Shape9T12 &&
    fastTreeOK (forms 9) (32768 ||| 2^10) 1839928 q9Shape9T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T12OK,q9Shape9T13OK⟩

private def q9Shape9T20 : Tree := (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 3 4 5)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 6 7))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2))))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))))
private theorem q9Shape9T20OK : fastTreeOK (forms 9) 33280 1848632 q9Shape9T20=true := by decide

private def q9Shape9T21 : Tree := (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 4 5))))
private theorem q9Shape9T21OK : fastTreeOK (forms 9) 41472 1840440 q9Shape9T21=true := by decide

private def q9Shape9T19 : Tree := .split 13 q9Shape9T20 q9Shape9T21
private theorem q9Shape9T19OK : fastTreeOK (forms 9) 33280 1840440 q9Shape9T19=true := by
  change (fastTreeOK (forms 9) 33280 (1840440 ||| 2^13) q9Shape9T20 &&
    fastTreeOK (forms 9) (33280 ||| 2^13) 1840440 q9Shape9T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T20OK,q9Shape9T21OK⟩

private def q9Shape9T23 : Tree := (.split 14 (.tip (.cover 0 1 3 5)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape9T23OK : fastTreeOK (forms 9) 34304 1847608 q9Shape9T23=true := by decide

private def q9Shape9T25 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 5)))
private theorem q9Shape9T25OK : fastTreeOK (forms 9) 42496 1855800 q9Shape9T25=true := by decide

private def q9Shape9T26 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5))))
private theorem q9Shape9T26OK : fastTreeOK (forms 9) 58880 1839416 q9Shape9T26=true := by decide

private def q9Shape9T24 : Tree := .split 14 q9Shape9T25 q9Shape9T26
private theorem q9Shape9T24OK : fastTreeOK (forms 9) 42496 1839416 q9Shape9T24=true := by
  change (fastTreeOK (forms 9) 42496 (1839416 ||| 2^14) q9Shape9T25 &&
    fastTreeOK (forms 9) (42496 ||| 2^14) 1839416 q9Shape9T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T25OK,q9Shape9T26OK⟩

private def q9Shape9T22 : Tree := .split 13 q9Shape9T23 q9Shape9T24
private theorem q9Shape9T22OK : fastTreeOK (forms 9) 34304 1839416 q9Shape9T22=true := by
  change (fastTreeOK (forms 9) 34304 (1839416 ||| 2^13) q9Shape9T23 &&
    fastTreeOK (forms 9) (34304 ||| 2^13) 1839416 q9Shape9T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T23OK,q9Shape9T24OK⟩

private def q9Shape9T18 : Tree := .split 10 q9Shape9T19 q9Shape9T22
private theorem q9Shape9T18OK : fastTreeOK (forms 9) 33280 1839416 q9Shape9T18=true := by
  change (fastTreeOK (forms 9) 33280 (1839416 ||| 2^10) q9Shape9T19 &&
    fastTreeOK (forms 9) (33280 ||| 2^10) 1839416 q9Shape9T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T19OK,q9Shape9T22OK⟩

private def q9Shape9T10 : Tree := .split 9 q9Shape9T11 q9Shape9T18
private theorem q9Shape9T10OK : fastTreeOK (forms 9) 32768 1839416 q9Shape9T10=true := by
  change (fastTreeOK (forms 9) 32768 (1839416 ||| 2^9) q9Shape9T11 &&
    fastTreeOK (forms 9) (32768 ||| 2^9) 1839416 q9Shape9T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T11OK,q9Shape9T18OK⟩

private def q9Shape9T30 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape9T30OK : fastTreeOK (forms 9) 32800 1849112 q9Shape9T30=true := by decide

private def q9Shape9T33 : Tree := (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 3 4 6 8))) (.tip (.cover 3 4 6 8))))
private theorem q9Shape9T33OK : fastTreeOK (forms 9) 40992 1922840 q9Shape9T33=true := by decide

private def q9Shape9T34 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) none))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) none))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5))))
private theorem q9Shape9T34OK : fastTreeOK (forms 9) 106528 1857304 q9Shape9T34=true := by decide

private def q9Shape9T32 : Tree := .split 16 q9Shape9T33 q9Shape9T34
private theorem q9Shape9T32OK : fastTreeOK (forms 9) 40992 1857304 q9Shape9T32=true := by
  change (fastTreeOK (forms 9) 40992 (1857304 ||| 2^16) q9Shape9T33 &&
    fastTreeOK (forms 9) (40992 ||| 2^16) 1857304 q9Shape9T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T33OK,q9Shape9T34OK⟩

private def q9Shape9T35 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 4 5))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) none))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 4 5))))
private theorem q9Shape9T35OK : fastTreeOK (forms 9) 57376 1840920 q9Shape9T35=true := by decide

private def q9Shape9T31 : Tree := .split 14 q9Shape9T32 q9Shape9T35
private theorem q9Shape9T31OK : fastTreeOK (forms 9) 40992 1840920 q9Shape9T31=true := by
  change (fastTreeOK (forms 9) 40992 (1840920 ||| 2^14) q9Shape9T32 &&
    fastTreeOK (forms 9) (40992 ||| 2^14) 1840920 q9Shape9T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T32OK,q9Shape9T35OK⟩

private def q9Shape9T29 : Tree := .split 13 q9Shape9T30 q9Shape9T31
private theorem q9Shape9T29OK : fastTreeOK (forms 9) 32800 1840920 q9Shape9T29=true := by
  change (fastTreeOK (forms 9) 32800 (1840920 ||| 2^13) q9Shape9T30 &&
    fastTreeOK (forms 9) (32800 ||| 2^13) 1840920 q9Shape9T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T30OK,q9Shape9T31OK⟩

private def q9Shape9T36 : Tree := (.tip (.cover 0 4 5 8))
private theorem q9Shape9T36OK : fastTreeOK (forms 9) 33824 1839896 q9Shape9T36=true := by decide

private def q9Shape9T28 : Tree := .split 10 q9Shape9T29 q9Shape9T36
private theorem q9Shape9T28OK : fastTreeOK (forms 9) 32800 1839896 q9Shape9T28=true := by
  change (fastTreeOK (forms 9) 32800 (1839896 ||| 2^10) q9Shape9T29 &&
    fastTreeOK (forms 9) (32800 ||| 2^10) 1839896 q9Shape9T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T29OK,q9Shape9T36OK⟩

private def q9Shape9T41 : Tree := (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 3 4 6 8))) (.tip (.cover 3 4 6 8))))
private theorem q9Shape9T41OK : fastTreeOK (forms 9) 33312 1930520 q9Shape9T41=true := by decide

private def q9Shape9T42 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 2 4 6 7)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 6 7))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape9T42OK : fastTreeOK (forms 9) 98848 1864984 q9Shape9T42=true := by decide

private def q9Shape9T40 : Tree := .split 16 q9Shape9T41 q9Shape9T42
private theorem q9Shape9T40OK : fastTreeOK (forms 9) 33312 1864984 q9Shape9T40=true := by
  change (fastTreeOK (forms 9) 33312 (1864984 ||| 2^16) q9Shape9T41 &&
    fastTreeOK (forms 9) (33312 ||| 2^16) 1864984 q9Shape9T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T41OK,q9Shape9T42OK⟩

private def q9Shape9T43 : Tree := (.tip (.cover 0 3 5 8))
private theorem q9Shape9T43OK : fastTreeOK (forms 9) 49696 1848600 q9Shape9T43=true := by decide

private def q9Shape9T39 : Tree := .split 14 q9Shape9T40 q9Shape9T43
private theorem q9Shape9T39OK : fastTreeOK (forms 9) 33312 1848600 q9Shape9T39=true := by
  change (fastTreeOK (forms 9) 33312 (1848600 ||| 2^14) q9Shape9T40 &&
    fastTreeOK (forms 9) (33312 ||| 2^14) 1848600 q9Shape9T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T40OK,q9Shape9T43OK⟩

private def q9Shape9T44 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape9T44OK : fastTreeOK (forms 9) 41504 1840408 q9Shape9T44=true := by decide

private def q9Shape9T38 : Tree := .split 13 q9Shape9T39 q9Shape9T44
private theorem q9Shape9T38OK : fastTreeOK (forms 9) 33312 1840408 q9Shape9T38=true := by
  change (fastTreeOK (forms 9) 33312 (1840408 ||| 2^13) q9Shape9T39 &&
    fastTreeOK (forms 9) (33312 ||| 2^13) 1840408 q9Shape9T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T39OK,q9Shape9T44OK⟩

private def q9Shape9T45 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 1 3 5))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 none (some 6))) (.tip (.unordered 3 5 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape9T45OK : fastTreeOK (forms 9) 34336 1839384 q9Shape9T45=true := by decide

private def q9Shape9T37 : Tree := .split 10 q9Shape9T38 q9Shape9T45
private theorem q9Shape9T37OK : fastTreeOK (forms 9) 33312 1839384 q9Shape9T37=true := by
  change (fastTreeOK (forms 9) 33312 (1839384 ||| 2^10) q9Shape9T38 &&
    fastTreeOK (forms 9) (33312 ||| 2^10) 1839384 q9Shape9T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T38OK,q9Shape9T45OK⟩

private def q9Shape9T27 : Tree := .split 9 q9Shape9T28 q9Shape9T37
private theorem q9Shape9T27OK : fastTreeOK (forms 9) 32800 1839384 q9Shape9T27=true := by
  change (fastTreeOK (forms 9) 32800 (1839384 ||| 2^9) q9Shape9T28 &&
    fastTreeOK (forms 9) (32800 ||| 2^9) 1839384 q9Shape9T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T28OK,q9Shape9T37OK⟩

private def q9Shape9T9 : Tree := .split 5 q9Shape9T10 q9Shape9T27
private theorem q9Shape9T9OK : fastTreeOK (forms 9) 32768 1839384 q9Shape9T9=true := by
  change (fastTreeOK (forms 9) 32768 (1839384 ||| 2^5) q9Shape9T10 &&
    fastTreeOK (forms 9) (32768 ||| 2^5) 1839384 q9Shape9T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T10OK,q9Shape9T27OK⟩

private def q9Shape9T51 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape9T51OK : fastTreeOK (forms 9) 32784 1865512 q9Shape9T51=true := by decide

private def q9Shape9T53 : Tree := (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) none))) (.tip (.cover 2 3 6 8)))) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 2 4 5))))
private theorem q9Shape9T53OK : fastTreeOK (forms 9) 49168 1914664 q9Shape9T53=true := by decide

private def q9Shape9T54 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 3 4 6 7))) (.tip (.cover 3 4 6 7))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) none))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5))))
private theorem q9Shape9T54OK : fastTreeOK (forms 9) 114704 1849128 q9Shape9T54=true := by decide

private def q9Shape9T52 : Tree := .split 16 q9Shape9T53 q9Shape9T54
private theorem q9Shape9T52OK : fastTreeOK (forms 9) 49168 1849128 q9Shape9T52=true := by
  change (fastTreeOK (forms 9) 49168 (1849128 ||| 2^16) q9Shape9T53 &&
    fastTreeOK (forms 9) (49168 ||| 2^16) 1849128 q9Shape9T54)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T53OK,q9Shape9T54OK⟩

private def q9Shape9T50 : Tree := .split 14 q9Shape9T51 q9Shape9T52
private theorem q9Shape9T50OK : fastTreeOK (forms 9) 32784 1849128 q9Shape9T50=true := by
  change (fastTreeOK (forms 9) 32784 (1849128 ||| 2^14) q9Shape9T51 &&
    fastTreeOK (forms 9) (32784 ||| 2^14) 1849128 q9Shape9T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T51OK,q9Shape9T52OK⟩

private def q9Shape9T55 : Tree := (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) none))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 4 5))))
private theorem q9Shape9T55OK : fastTreeOK (forms 9) 40976 1840936 q9Shape9T55=true := by decide

private def q9Shape9T49 : Tree := .split 13 q9Shape9T50 q9Shape9T55
private theorem q9Shape9T49OK : fastTreeOK (forms 9) 32784 1840936 q9Shape9T49=true := by
  change (fastTreeOK (forms 9) 32784 (1840936 ||| 2^13) q9Shape9T50 &&
    fastTreeOK (forms 9) (32784 ||| 2^13) 1840936 q9Shape9T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T50OK,q9Shape9T55OK⟩

private def q9Shape9T59 : Tree := (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 2 4 6 8)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 6 8))))
private theorem q9Shape9T59OK : fastTreeOK (forms 9) 33808 1930024 q9Shape9T59=true := by decide

private def q9Shape9T60 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 3 4 6 7))) (.tip (.cover 3 4 6 7))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape9T60OK : fastTreeOK (forms 9) 99344 1864488 q9Shape9T60=true := by decide

private def q9Shape9T58 : Tree := .split 16 q9Shape9T59 q9Shape9T60
private theorem q9Shape9T58OK : fastTreeOK (forms 9) 33808 1864488 q9Shape9T58=true := by
  change (fastTreeOK (forms 9) 33808 (1864488 ||| 2^16) q9Shape9T59 &&
    fastTreeOK (forms 9) (33808 ||| 2^16) 1864488 q9Shape9T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T59OK,q9Shape9T60OK⟩

private def q9Shape9T61 : Tree := (.tip (.cover 0 2 5 8))
private theorem q9Shape9T61OK : fastTreeOK (forms 9) 50192 1848104 q9Shape9T61=true := by decide

private def q9Shape9T57 : Tree := .split 14 q9Shape9T58 q9Shape9T61
private theorem q9Shape9T57OK : fastTreeOK (forms 9) 33808 1848104 q9Shape9T57=true := by
  change (fastTreeOK (forms 9) 33808 (1848104 ||| 2^14) q9Shape9T58 &&
    fastTreeOK (forms 9) (33808 ||| 2^14) 1848104 q9Shape9T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T58OK,q9Shape9T61OK⟩

private def q9Shape9T62 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape9T62OK : fastTreeOK (forms 9) 42000 1839912 q9Shape9T62=true := by decide

private def q9Shape9T56 : Tree := .split 13 q9Shape9T57 q9Shape9T62
private theorem q9Shape9T56OK : fastTreeOK (forms 9) 33808 1839912 q9Shape9T56=true := by
  change (fastTreeOK (forms 9) 33808 (1839912 ||| 2^13) q9Shape9T57 &&
    fastTreeOK (forms 9) (33808 ||| 2^13) 1839912 q9Shape9T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T57OK,q9Shape9T62OK⟩

private def q9Shape9T48 : Tree := .split 10 q9Shape9T49 q9Shape9T56
private theorem q9Shape9T48OK : fastTreeOK (forms 9) 32784 1839912 q9Shape9T48=true := by
  change (fastTreeOK (forms 9) 32784 (1839912 ||| 2^10) q9Shape9T49 &&
    fastTreeOK (forms 9) (32784 ||| 2^10) 1839912 q9Shape9T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T49OK,q9Shape9T56OK⟩

private def q9Shape9T63 : Tree := (.split 10 (.tip (.cover 0 4 5 7)) (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.unordered 3 5 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8))))
private theorem q9Shape9T63OK : fastTreeOK (forms 9) 33296 1839400 q9Shape9T63=true := by decide

private def q9Shape9T47 : Tree := .split 9 q9Shape9T48 q9Shape9T63
private theorem q9Shape9T47OK : fastTreeOK (forms 9) 32784 1839400 q9Shape9T47=true := by
  change (fastTreeOK (forms 9) 32784 (1839400 ||| 2^9) q9Shape9T48 &&
    fastTreeOK (forms 9) (32784 ||| 2^9) 1839400 q9Shape9T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T48OK,q9Shape9T63OK⟩

private def q9Shape9T67 : Tree := (.split 14 (.tip (.cover 0 1 2 5)) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.split 2 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5)))))
private theorem q9Shape9T67OK : fastTreeOK (forms 9) 32816 1849096 q9Shape9T67=true := by decide

private def q9Shape9T69 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 5)))
private theorem q9Shape9T69OK : fastTreeOK (forms 9) 41008 1857288 q9Shape9T69=true := by decide

private def q9Shape9T70 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 3 4 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 4 6)))) (.tip (.cover 0 2 4 5)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 4 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5))))
private theorem q9Shape9T70OK : fastTreeOK (forms 9) 57392 1840904 q9Shape9T70=true := by decide

private def q9Shape9T68 : Tree := .split 14 q9Shape9T69 q9Shape9T70
private theorem q9Shape9T68OK : fastTreeOK (forms 9) 41008 1840904 q9Shape9T68=true := by
  change (fastTreeOK (forms 9) 41008 (1840904 ||| 2^14) q9Shape9T69 &&
    fastTreeOK (forms 9) (41008 ||| 2^14) 1840904 q9Shape9T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T69OK,q9Shape9T70OK⟩

private def q9Shape9T66 : Tree := .split 13 q9Shape9T67 q9Shape9T68
private theorem q9Shape9T66OK : fastTreeOK (forms 9) 32816 1840904 q9Shape9T66=true := by
  change (fastTreeOK (forms 9) 32816 (1840904 ||| 2^13) q9Shape9T67 &&
    fastTreeOK (forms 9) (32816 ||| 2^13) 1840904 q9Shape9T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T67OK,q9Shape9T68OK⟩

private def q9Shape9T71 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 1 2 5))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape9T71OK : fastTreeOK (forms 9) 33840 1839880 q9Shape9T71=true := by decide

private def q9Shape9T65 : Tree := .split 10 q9Shape9T66 q9Shape9T71
private theorem q9Shape9T65OK : fastTreeOK (forms 9) 32816 1839880 q9Shape9T65=true := by
  change (fastTreeOK (forms 9) 32816 (1839880 ||| 2^10) q9Shape9T66 &&
    fastTreeOK (forms 9) (32816 ||| 2^10) 1839880 q9Shape9T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T66OK,q9Shape9T71OK⟩

private def q9Shape9T73 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 5 7 8))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape9T73OK : fastTreeOK (forms 9) 33328 1840392 q9Shape9T73=true := by decide

private def q9Shape9T75 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 5 7 8)))
private theorem q9Shape9T75OK : fastTreeOK (forms 9) 34352 1847560 q9Shape9T75=true := by decide

private def q9Shape9T76 : Tree := (.tip (.cover 0 5 7 8))
private theorem q9Shape9T76OK : fastTreeOK (forms 9) 42544 1839368 q9Shape9T76=true := by decide

private def q9Shape9T74 : Tree := .split 13 q9Shape9T75 q9Shape9T76
private theorem q9Shape9T74OK : fastTreeOK (forms 9) 34352 1839368 q9Shape9T74=true := by
  change (fastTreeOK (forms 9) 34352 (1839368 ||| 2^13) q9Shape9T75 &&
    fastTreeOK (forms 9) (34352 ||| 2^13) 1839368 q9Shape9T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T75OK,q9Shape9T76OK⟩

private def q9Shape9T72 : Tree := .split 10 q9Shape9T73 q9Shape9T74
private theorem q9Shape9T72OK : fastTreeOK (forms 9) 33328 1839368 q9Shape9T72=true := by
  change (fastTreeOK (forms 9) 33328 (1839368 ||| 2^10) q9Shape9T73 &&
    fastTreeOK (forms 9) (33328 ||| 2^10) 1839368 q9Shape9T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T73OK,q9Shape9T74OK⟩

private def q9Shape9T64 : Tree := .split 9 q9Shape9T65 q9Shape9T72
private theorem q9Shape9T64OK : fastTreeOK (forms 9) 32816 1839368 q9Shape9T64=true := by
  change (fastTreeOK (forms 9) 32816 (1839368 ||| 2^9) q9Shape9T65 &&
    fastTreeOK (forms 9) (32816 ||| 2^9) 1839368 q9Shape9T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T65OK,q9Shape9T72OK⟩

private def q9Shape9T46 : Tree := .split 5 q9Shape9T47 q9Shape9T64
private theorem q9Shape9T46OK : fastTreeOK (forms 9) 32784 1839368 q9Shape9T46=true := by
  change (fastTreeOK (forms 9) 32784 (1839368 ||| 2^5) q9Shape9T47 &&
    fastTreeOK (forms 9) (32784 ||| 2^5) 1839368 q9Shape9T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T47OK,q9Shape9T64OK⟩

private def q9Shape9T8 : Tree := .split 4 q9Shape9T9 q9Shape9T46
private theorem q9Shape9T8OK : fastTreeOK (forms 9) 32768 1839368 q9Shape9T8=true := by
  change (fastTreeOK (forms 9) 32768 (1839368 ||| 2^4) q9Shape9T9 &&
    fastTreeOK (forms 9) (32768 ||| 2^4) 1839368 q9Shape9T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T9OK,q9Shape9T46OK⟩

private def q9Shape9T6 : Tree := .split 15 q9Shape9T7 q9Shape9T8
private theorem q9Shape9T6OK : fastTreeOK (forms 9) 0 1839368 q9Shape9T6=true := by
  change (fastTreeOK (forms 9) 0 (1839368 ||| 2^15) q9Shape9T7 &&
    fastTreeOK (forms 9) (0 ||| 2^15) 1839368 q9Shape9T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T7OK,q9Shape9T8OK⟩

private def q9Shape9T82 : Tree := (.tip (.cover 0 1 4 5))
private theorem q9Shape9T82OK : fastTreeOK (forms 9) 4096 1869624 q9Shape9T82=true := by decide

private def q9Shape9T84 : Tree := (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))))) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 5 6 8))) (.tip (.cover 0 1 4 5)))))
private theorem q9Shape9T84OK : fastTreeOK (forms 9) 5120 1876792 q9Shape9T84=true := by decide

private def q9Shape9T85 : Tree := (.split 14 (.split 16 (.tip (.cover 0 1 4 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2))))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))) (.split 16 (.tip (.cover 0 1 4 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 4 5)))))
private theorem q9Shape9T85OK : fastTreeOK (forms 9) 13312 1868600 q9Shape9T85=true := by decide

private def q9Shape9T83 : Tree := .split 13 q9Shape9T84 q9Shape9T85
private theorem q9Shape9T83OK : fastTreeOK (forms 9) 5120 1868600 q9Shape9T83=true := by
  change (fastTreeOK (forms 9) 5120 (1868600 ||| 2^13) q9Shape9T84 &&
    fastTreeOK (forms 9) (5120 ||| 2^13) 1868600 q9Shape9T85)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T84OK,q9Shape9T85OK⟩

private def q9Shape9T81 : Tree := .split 10 q9Shape9T82 q9Shape9T83
private theorem q9Shape9T81OK : fastTreeOK (forms 9) 4096 1868600 q9Shape9T81=true := by
  change (fastTreeOK (forms 9) 4096 (1868600 ||| 2^10) q9Shape9T82 &&
    fastTreeOK (forms 9) (4096 ||| 2^10) 1868600 q9Shape9T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T82OK,q9Shape9T83OK⟩

private def q9Shape9T88 : Tree := (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))))) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2))))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))))
private theorem q9Shape9T88OK : fastTreeOK (forms 9) 4608 1877304 q9Shape9T88=true := by decide

private def q9Shape9T89 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 1 4 5))) (.split 16 (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 4 5))))
private theorem q9Shape9T89OK : fastTreeOK (forms 9) 12800 1869112 q9Shape9T89=true := by decide

private def q9Shape9T87 : Tree := .split 13 q9Shape9T88 q9Shape9T89
private theorem q9Shape9T87OK : fastTreeOK (forms 9) 4608 1869112 q9Shape9T87=true := by
  change (fastTreeOK (forms 9) 4608 (1869112 ||| 2^13) q9Shape9T88 &&
    fastTreeOK (forms 9) (4608 ||| 2^13) 1869112 q9Shape9T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T88OK,q9Shape9T89OK⟩

private def q9Shape9T92 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5)))))
private theorem q9Shape9T92OK : fastTreeOK (forms 9) 5632 1892664 q9Shape9T92=true := by decide

private def q9Shape9T93 : Tree := (.split 16 (.tip (.cover 0 1 3 4)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5)))))
private theorem q9Shape9T93OK : fastTreeOK (forms 9) 22016 1876280 q9Shape9T93=true := by decide

private def q9Shape9T91 : Tree := .split 14 q9Shape9T92 q9Shape9T93
private theorem q9Shape9T91OK : fastTreeOK (forms 9) 5632 1876280 q9Shape9T91=true := by
  change (fastTreeOK (forms 9) 5632 (1876280 ||| 2^14) q9Shape9T92 &&
    fastTreeOK (forms 9) (5632 ||| 2^14) 1876280 q9Shape9T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T92OK,q9Shape9T93OK⟩

private def q9Shape9T94 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 3 4)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.split 17 (.tip (.cover 0 1 3 4)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape9T94OK : fastTreeOK (forms 9) 13824 1868088 q9Shape9T94=true := by decide

private def q9Shape9T90 : Tree := .split 13 q9Shape9T91 q9Shape9T94
private theorem q9Shape9T90OK : fastTreeOK (forms 9) 5632 1868088 q9Shape9T90=true := by
  change (fastTreeOK (forms 9) 5632 (1868088 ||| 2^13) q9Shape9T91 &&
    fastTreeOK (forms 9) (5632 ||| 2^13) 1868088 q9Shape9T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T91OK,q9Shape9T94OK⟩

private def q9Shape9T86 : Tree := .split 10 q9Shape9T87 q9Shape9T90
private theorem q9Shape9T86OK : fastTreeOK (forms 9) 4608 1868088 q9Shape9T86=true := by
  change (fastTreeOK (forms 9) 4608 (1868088 ||| 2^10) q9Shape9T87 &&
    fastTreeOK (forms 9) (4608 ||| 2^10) 1868088 q9Shape9T90)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T87OK,q9Shape9T90OK⟩

private def q9Shape9T80 : Tree := .split 9 q9Shape9T81 q9Shape9T86
private theorem q9Shape9T80OK : fastTreeOK (forms 9) 4096 1868088 q9Shape9T80=true := by
  change (fastTreeOK (forms 9) 4096 (1868088 ||| 2^9) q9Shape9T81 &&
    fastTreeOK (forms 9) (4096 ||| 2^9) 1868088 q9Shape9T86)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T81OK,q9Shape9T86OK⟩

private def q9Shape9T98 : Tree := (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5))))) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 1 4 5)))))
private theorem q9Shape9T98OK : fastTreeOK (forms 9) 4128 1877784 q9Shape9T98=true := by decide

private def q9Shape9T100 : Tree := (.split 16 (.tip (.cover 0 1 4 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 3 6 7))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) none))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) none))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape9T100OK : fastTreeOK (forms 9) 12320 1885976 q9Shape9T100=true := by decide

private def q9Shape9T101 : Tree := (.split 16 (.tip (.cover 0 1 4 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) none))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 4 5))))
private theorem q9Shape9T101OK : fastTreeOK (forms 9) 28704 1869592 q9Shape9T101=true := by decide

private def q9Shape9T99 : Tree := .split 14 q9Shape9T100 q9Shape9T101
private theorem q9Shape9T99OK : fastTreeOK (forms 9) 12320 1869592 q9Shape9T99=true := by
  change (fastTreeOK (forms 9) 12320 (1869592 ||| 2^14) q9Shape9T100 &&
    fastTreeOK (forms 9) (12320 ||| 2^14) 1869592 q9Shape9T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T100OK,q9Shape9T101OK⟩

private def q9Shape9T97 : Tree := .split 13 q9Shape9T98 q9Shape9T99
private theorem q9Shape9T97OK : fastTreeOK (forms 9) 4128 1869592 q9Shape9T97=true := by
  change (fastTreeOK (forms 9) 4128 (1869592 ||| 2^13) q9Shape9T98 &&
    fastTreeOK (forms 9) (4128 ||| 2^13) 1869592 q9Shape9T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T98OK,q9Shape9T99OK⟩

private def q9Shape9T102 : Tree := (.tip (.cover 0 4 5 8))
private theorem q9Shape9T102OK : fastTreeOK (forms 9) 5152 1868568 q9Shape9T102=true := by decide

private def q9Shape9T96 : Tree := .split 10 q9Shape9T97 q9Shape9T102
private theorem q9Shape9T96OK : fastTreeOK (forms 9) 4128 1868568 q9Shape9T96=true := by
  change (fastTreeOK (forms 9) 4128 (1868568 ||| 2^10) q9Shape9T97 &&
    fastTreeOK (forms 9) (4128 ||| 2^10) 1868568 q9Shape9T102)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T97OK,q9Shape9T102OK⟩

private def q9Shape9T105 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 4 7))))
private theorem q9Shape9T105OK : fastTreeOK (forms 9) 4640 1877272 q9Shape9T105=true := by decide

private def q9Shape9T107 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 5 6 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8)))
private theorem q9Shape9T107OK : fastTreeOK (forms 9) 12832 1885464 q9Shape9T107=true := by decide

private def q9Shape9T108 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 4 7)))
private theorem q9Shape9T108OK : fastTreeOK (forms 9) 29216 1869080 q9Shape9T108=true := by decide

private def q9Shape9T106 : Tree := .split 14 q9Shape9T107 q9Shape9T108
private theorem q9Shape9T106OK : fastTreeOK (forms 9) 12832 1869080 q9Shape9T106=true := by
  change (fastTreeOK (forms 9) 12832 (1869080 ||| 2^14) q9Shape9T107 &&
    fastTreeOK (forms 9) (12832 ||| 2^14) 1869080 q9Shape9T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T107OK,q9Shape9T108OK⟩

private def q9Shape9T104 : Tree := .split 13 q9Shape9T105 q9Shape9T106
private theorem q9Shape9T104OK : fastTreeOK (forms 9) 4640 1869080 q9Shape9T104=true := by
  change (fastTreeOK (forms 9) 4640 (1869080 ||| 2^13) q9Shape9T105 &&
    fastTreeOK (forms 9) (4640 ||| 2^13) 1869080 q9Shape9T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T105OK,q9Shape9T106OK⟩

private def q9Shape9T109 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.tip (.cover 0 1 3 4)) (.tip (.cover 0 2 4 7)))) (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape9T109OK : fastTreeOK (forms 9) 5664 1868056 q9Shape9T109=true := by decide

private def q9Shape9T103 : Tree := .split 10 q9Shape9T104 q9Shape9T109
private theorem q9Shape9T103OK : fastTreeOK (forms 9) 4640 1868056 q9Shape9T103=true := by
  change (fastTreeOK (forms 9) 4640 (1868056 ||| 2^10) q9Shape9T104 &&
    fastTreeOK (forms 9) (4640 ||| 2^10) 1868056 q9Shape9T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T104OK,q9Shape9T109OK⟩

private def q9Shape9T95 : Tree := .split 9 q9Shape9T96 q9Shape9T103
private theorem q9Shape9T95OK : fastTreeOK (forms 9) 4128 1868056 q9Shape9T95=true := by
  change (fastTreeOK (forms 9) 4128 (1868056 ||| 2^9) q9Shape9T96 &&
    fastTreeOK (forms 9) (4128 ||| 2^9) 1868056 q9Shape9T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T96OK,q9Shape9T103OK⟩

private def q9Shape9T79 : Tree := .split 5 q9Shape9T80 q9Shape9T95
private theorem q9Shape9T79OK : fastTreeOK (forms 9) 4096 1868056 q9Shape9T79=true := by
  change (fastTreeOK (forms 9) 4096 (1868056 ||| 2^5) q9Shape9T80 &&
    fastTreeOK (forms 9) (4096 ||| 2^5) 1868056 q9Shape9T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T80OK,q9Shape9T95OK⟩

private def q9Shape9T115 : Tree := (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape9T115OK : fastTreeOK (forms 9) 4112 1894184 q9Shape9T115=true := by decide

private def q9Shape9T116 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 3 6 8))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) none))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 6 8)))) (.tip (.cover 0 2 4 5)))) (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) none))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape9T116OK : fastTreeOK (forms 9) 20496 1877800 q9Shape9T116=true := by decide

private def q9Shape9T114 : Tree := .split 14 q9Shape9T115 q9Shape9T116
private theorem q9Shape9T114OK : fastTreeOK (forms 9) 4112 1877800 q9Shape9T114=true := by
  change (fastTreeOK (forms 9) 4112 (1877800 ||| 2^14) q9Shape9T115 &&
    fastTreeOK (forms 9) (4112 ||| 2^14) 1877800 q9Shape9T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T115OK,q9Shape9T116OK⟩

private def q9Shape9T117 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 3 5 6 7)))) (.tip (.cover 0 1 4 5))) (.split 16 (.split 17 (.tip (.cover 0 1 4 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) none))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 4 5))))
private theorem q9Shape9T117OK : fastTreeOK (forms 9) 12304 1869608 q9Shape9T117=true := by decide

private def q9Shape9T113 : Tree := .split 13 q9Shape9T114 q9Shape9T117
private theorem q9Shape9T113OK : fastTreeOK (forms 9) 4112 1869608 q9Shape9T113=true := by
  change (fastTreeOK (forms 9) 4112 (1869608 ||| 2^13) q9Shape9T114 &&
    fastTreeOK (forms 9) (4112 ||| 2^13) 1869608 q9Shape9T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T114OK,q9Shape9T117OK⟩

private def q9Shape9T119 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 5 6 8))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 4 7))))
private theorem q9Shape9T119OK : fastTreeOK (forms 9) 5136 1876776 q9Shape9T119=true := by decide

private def q9Shape9T120 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 4 7))))
private theorem q9Shape9T120OK : fastTreeOK (forms 9) 13328 1868584 q9Shape9T120=true := by decide

private def q9Shape9T118 : Tree := .split 13 q9Shape9T119 q9Shape9T120
private theorem q9Shape9T118OK : fastTreeOK (forms 9) 5136 1868584 q9Shape9T118=true := by
  change (fastTreeOK (forms 9) 5136 (1868584 ||| 2^13) q9Shape9T119 &&
    fastTreeOK (forms 9) (5136 ||| 2^13) 1868584 q9Shape9T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T119OK,q9Shape9T120OK⟩

private def q9Shape9T112 : Tree := .split 10 q9Shape9T113 q9Shape9T118
private theorem q9Shape9T112OK : fastTreeOK (forms 9) 4112 1868584 q9Shape9T112=true := by
  change (fastTreeOK (forms 9) 4112 (1868584 ||| 2^10) q9Shape9T113 &&
    fastTreeOK (forms 9) (4112 ||| 2^10) 1868584 q9Shape9T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T113OK,q9Shape9T118OK⟩

private def q9Shape9T122 : Tree := (.tip (.cover 0 4 5 7))
private theorem q9Shape9T122OK : fastTreeOK (forms 9) 4624 1869096 q9Shape9T122=true := by decide

private def q9Shape9T124 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 3 4 7))))
private theorem q9Shape9T124OK : fastTreeOK (forms 9) 5648 1876264 q9Shape9T124=true := by decide

private def q9Shape9T125 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 3 4)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape9T125OK : fastTreeOK (forms 9) 13840 1868072 q9Shape9T125=true := by decide

private def q9Shape9T123 : Tree := .split 13 q9Shape9T124 q9Shape9T125
private theorem q9Shape9T123OK : fastTreeOK (forms 9) 5648 1868072 q9Shape9T123=true := by
  change (fastTreeOK (forms 9) 5648 (1868072 ||| 2^13) q9Shape9T124 &&
    fastTreeOK (forms 9) (5648 ||| 2^13) 1868072 q9Shape9T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T124OK,q9Shape9T125OK⟩

private def q9Shape9T121 : Tree := .split 10 q9Shape9T122 q9Shape9T123
private theorem q9Shape9T121OK : fastTreeOK (forms 9) 4624 1868072 q9Shape9T121=true := by
  change (fastTreeOK (forms 9) 4624 (1868072 ||| 2^10) q9Shape9T122 &&
    fastTreeOK (forms 9) (4624 ||| 2^10) 1868072 q9Shape9T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T122OK,q9Shape9T123OK⟩

private def q9Shape9T111 : Tree := .split 9 q9Shape9T112 q9Shape9T121
private theorem q9Shape9T111OK : fastTreeOK (forms 9) 4112 1868072 q9Shape9T111=true := by
  change (fastTreeOK (forms 9) 4112 (1868072 ||| 2^9) q9Shape9T112 &&
    fastTreeOK (forms 9) (4112 ||| 2^9) 1868072 q9Shape9T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T112OK,q9Shape9T121OK⟩

private def q9Shape9T130 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape9T130OK : fastTreeOK (forms 9) 4144 1894152 q9Shape9T130=true := by decide

private def q9Shape9T131 : Tree := (.split 16 (.tip (.cover 0 1 2 4)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.split 2 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape9T131OK : fastTreeOK (forms 9) 20528 1877768 q9Shape9T131=true := by decide

private def q9Shape9T129 : Tree := .split 14 q9Shape9T130 q9Shape9T131
private theorem q9Shape9T129OK : fastTreeOK (forms 9) 4144 1877768 q9Shape9T129=true := by
  change (fastTreeOK (forms 9) 4144 (1877768 ||| 2^14) q9Shape9T130 &&
    fastTreeOK (forms 9) (4144 ||| 2^14) 1877768 q9Shape9T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T130OK,q9Shape9T131OK⟩

private def q9Shape9T132 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 2 4)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5)))) (.split 17 (.tip (.cover 0 1 2 4)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 1 2 4)))
private theorem q9Shape9T132OK : fastTreeOK (forms 9) 12336 1869576 q9Shape9T132=true := by decide

private def q9Shape9T128 : Tree := .split 13 q9Shape9T129 q9Shape9T132
private theorem q9Shape9T128OK : fastTreeOK (forms 9) 4144 1869576 q9Shape9T128=true := by
  change (fastTreeOK (forms 9) 4144 (1869576 ||| 2^13) q9Shape9T129 &&
    fastTreeOK (forms 9) (4144 ||| 2^13) 1869576 q9Shape9T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T129OK,q9Shape9T132OK⟩

private def q9Shape9T133 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.tip (.cover 0 1 2 4)) (.tip (.cover 0 3 4 7)))) (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 1 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape9T133OK : fastTreeOK (forms 9) 5168 1868552 q9Shape9T133=true := by decide

private def q9Shape9T127 : Tree := .split 10 q9Shape9T128 q9Shape9T133
private theorem q9Shape9T127OK : fastTreeOK (forms 9) 4144 1868552 q9Shape9T127=true := by
  change (fastTreeOK (forms 9) 4144 (1868552 ||| 2^10) q9Shape9T128 &&
    fastTreeOK (forms 9) (4144 ||| 2^10) 1868552 q9Shape9T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T128OK,q9Shape9T133OK⟩

private def q9Shape9T135 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 2 4 7)))) (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 2 4)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape9T135OK : fastTreeOK (forms 9) 4656 1869064 q9Shape9T135=true := by decide

private def q9Shape9T137 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 4 7 8))) (.tip (.cover 0 4 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 2 4 7))))
private theorem q9Shape9T137OK : fastTreeOK (forms 9) 5680 1876232 q9Shape9T137=true := by decide

private def q9Shape9T138 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 1 2 4)))
private theorem q9Shape9T138OK : fastTreeOK (forms 9) 13872 1868040 q9Shape9T138=true := by decide

private def q9Shape9T136 : Tree := .split 13 q9Shape9T137 q9Shape9T138
private theorem q9Shape9T136OK : fastTreeOK (forms 9) 5680 1868040 q9Shape9T136=true := by
  change (fastTreeOK (forms 9) 5680 (1868040 ||| 2^13) q9Shape9T137 &&
    fastTreeOK (forms 9) (5680 ||| 2^13) 1868040 q9Shape9T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T137OK,q9Shape9T138OK⟩

private def q9Shape9T134 : Tree := .split 10 q9Shape9T135 q9Shape9T136
private theorem q9Shape9T134OK : fastTreeOK (forms 9) 4656 1868040 q9Shape9T134=true := by
  change (fastTreeOK (forms 9) 4656 (1868040 ||| 2^10) q9Shape9T135 &&
    fastTreeOK (forms 9) (4656 ||| 2^10) 1868040 q9Shape9T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T135OK,q9Shape9T136OK⟩

private def q9Shape9T126 : Tree := .split 9 q9Shape9T127 q9Shape9T134
private theorem q9Shape9T126OK : fastTreeOK (forms 9) 4144 1868040 q9Shape9T126=true := by
  change (fastTreeOK (forms 9) 4144 (1868040 ||| 2^9) q9Shape9T127 &&
    fastTreeOK (forms 9) (4144 ||| 2^9) 1868040 q9Shape9T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T127OK,q9Shape9T134OK⟩

private def q9Shape9T110 : Tree := .split 5 q9Shape9T111 q9Shape9T126
private theorem q9Shape9T110OK : fastTreeOK (forms 9) 4112 1868040 q9Shape9T110=true := by
  change (fastTreeOK (forms 9) 4112 (1868040 ||| 2^5) q9Shape9T111 &&
    fastTreeOK (forms 9) (4112 ||| 2^5) 1868040 q9Shape9T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T111OK,q9Shape9T126OK⟩

private def q9Shape9T78 : Tree := .split 4 q9Shape9T79 q9Shape9T110
private theorem q9Shape9T78OK : fastTreeOK (forms 9) 4096 1868040 q9Shape9T78=true := by
  change (fastTreeOK (forms 9) 4096 (1868040 ||| 2^4) q9Shape9T79 &&
    fastTreeOK (forms 9) (4096 ||| 2^4) 1868040 q9Shape9T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T79OK,q9Shape9T110OK⟩

private def q9Shape9T139 : Tree := (.tip (.cover 2 3 4 5))
private theorem q9Shape9T139OK : fastTreeOK (forms 9) 36864 1835272 q9Shape9T139=true := by decide

private def q9Shape9T77 : Tree := .split 15 q9Shape9T78 q9Shape9T139
private theorem q9Shape9T77OK : fastTreeOK (forms 9) 4096 1835272 q9Shape9T77=true := by
  change (fastTreeOK (forms 9) 4096 (1835272 ||| 2^15) q9Shape9T78 &&
    fastTreeOK (forms 9) (4096 ||| 2^15) 1835272 q9Shape9T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T78OK,q9Shape9T139OK⟩

private def q9Shape9T5 : Tree := .split 12 q9Shape9T6 q9Shape9T77
private theorem q9Shape9T5OK : fastTreeOK (forms 9) 0 1835272 q9Shape9T5=true := by
  change (fastTreeOK (forms 9) 0 (1835272 ||| 2^12) q9Shape9T6 &&
    fastTreeOK (forms 9) (0 ||| 2^12) 1835272 q9Shape9T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T6OK,q9Shape9T77OK⟩

private def q9Shape9T147 : Tree := (.split 14 (.tip (.drop 7 8 none none)) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))))))
private theorem q9Shape9T147OK : fastTreeOK (forms 9) 256 1881656 q9Shape9T147=true := by decide

private def q9Shape9T148 : Tree := (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))))) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))))))
private theorem q9Shape9T148OK : fastTreeOK (forms 9) 8448 1873464 q9Shape9T148=true := by decide

private def q9Shape9T146 : Tree := .split 13 q9Shape9T147 q9Shape9T148
private theorem q9Shape9T146OK : fastTreeOK (forms 9) 256 1873464 q9Shape9T146=true := by
  change (fastTreeOK (forms 9) 256 (1873464 ||| 2^13) q9Shape9T147 &&
    fastTreeOK (forms 9) (256 ||| 2^13) 1873464 q9Shape9T148)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T147OK,q9Shape9T148OK⟩

private def q9Shape9T150 : Tree := (.split 14 (.tip (.cover 0 1 3 5)) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 5 6 8))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5)))))
private theorem q9Shape9T150OK : fastTreeOK (forms 9) 1280 1880632 q9Shape9T150=true := by decide

private def q9Shape9T152 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2))))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))))
private theorem q9Shape9T152OK : fastTreeOK (forms 9) 9472 1888824 q9Shape9T152=true := by decide

private def q9Shape9T153 : Tree := (.split 16 (.tip (.cover 0 1 3 4)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6)))))
private theorem q9Shape9T153OK : fastTreeOK (forms 9) 25856 1872440 q9Shape9T153=true := by decide

private def q9Shape9T151 : Tree := .split 14 q9Shape9T152 q9Shape9T153
private theorem q9Shape9T151OK : fastTreeOK (forms 9) 9472 1872440 q9Shape9T151=true := by
  change (fastTreeOK (forms 9) 9472 (1872440 ||| 2^14) q9Shape9T152 &&
    fastTreeOK (forms 9) (9472 ||| 2^14) 1872440 q9Shape9T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T152OK,q9Shape9T153OK⟩

private def q9Shape9T149 : Tree := .split 13 q9Shape9T150 q9Shape9T151
private theorem q9Shape9T149OK : fastTreeOK (forms 9) 1280 1872440 q9Shape9T149=true := by
  change (fastTreeOK (forms 9) 1280 (1872440 ||| 2^13) q9Shape9T150 &&
    fastTreeOK (forms 9) (1280 ||| 2^13) 1872440 q9Shape9T151)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T150OK,q9Shape9T151OK⟩

private def q9Shape9T145 : Tree := .split 10 q9Shape9T146 q9Shape9T149
private theorem q9Shape9T145OK : fastTreeOK (forms 9) 256 1872440 q9Shape9T145=true := by
  change (fastTreeOK (forms 9) 256 (1872440 ||| 2^10) q9Shape9T146 &&
    fastTreeOK (forms 9) (256 ||| 2^10) 1872440 q9Shape9T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T146OK,q9Shape9T149OK⟩

private def q9Shape9T156 : Tree := (.split 14 (.tip (.cover 0 1 3 5)) (.split 16 (.tip (.cover 0 1 3 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2))))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))))))
private theorem q9Shape9T156OK : fastTreeOK (forms 9) 768 1881144 q9Shape9T156=true := by decide

private def q9Shape9T157 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 5 6 7))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 5))) (.split 16 (.split 17 (.tip (.cover 0 1 3 4)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.split 17 (.tip (.cover 0 1 3 4)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))))))
private theorem q9Shape9T157OK : fastTreeOK (forms 9) 8960 1872952 q9Shape9T157=true := by decide

private def q9Shape9T155 : Tree := .split 13 q9Shape9T156 q9Shape9T157
private theorem q9Shape9T155OK : fastTreeOK (forms 9) 768 1872952 q9Shape9T155=true := by
  change (fastTreeOK (forms 9) 768 (1872952 ||| 2^13) q9Shape9T156 &&
    fastTreeOK (forms 9) (768 ||| 2^13) 1872952 q9Shape9T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T156OK,q9Shape9T157OK⟩

private def q9Shape9T158 : Tree := (.split 13 (.split 14 (.tip (.cover 0 1 3 5)) (.split 16 (.tip (.cover 0 1 3 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 3 5))))) (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 7 (some 2) (some 2)))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5)))) (.tip (.cover 0 1 3 5))) (.tip (.cover 0 1 3 4))))
private theorem q9Shape9T158OK : fastTreeOK (forms 9) 1792 1871928 q9Shape9T158=true := by decide

private def q9Shape9T154 : Tree := .split 10 q9Shape9T155 q9Shape9T158
private theorem q9Shape9T154OK : fastTreeOK (forms 9) 768 1871928 q9Shape9T154=true := by
  change (fastTreeOK (forms 9) 768 (1871928 ||| 2^10) q9Shape9T155 &&
    fastTreeOK (forms 9) (768 ||| 2^10) 1871928 q9Shape9T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T155OK,q9Shape9T158OK⟩

private def q9Shape9T144 : Tree := .split 9 q9Shape9T145 q9Shape9T154
private theorem q9Shape9T144OK : fastTreeOK (forms 9) 256 1871928 q9Shape9T144=true := by
  change (fastTreeOK (forms 9) 256 (1871928 ||| 2^9) q9Shape9T145 &&
    fastTreeOK (forms 9) (256 ||| 2^9) 1871928 q9Shape9T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T145OK,q9Shape9T154OK⟩

private def q9Shape9T161 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6))))) (.tip (.cover 0 3 5 8))) (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 7 8)))))
private theorem q9Shape9T161OK : fastTreeOK (forms 9) 288 1873432 q9Shape9T161=true := by decide

private def q9Shape9T162 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 0 3 5 8))) (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.split 16 (.tip (.cover 0 1 3 4)) (.tip (.cover 0 2 3 7)))))
private theorem q9Shape9T162OK : fastTreeOK (forms 9) 1312 1872408 q9Shape9T162=true := by decide

private def q9Shape9T160 : Tree := .split 10 q9Shape9T161 q9Shape9T162
private theorem q9Shape9T160OK : fastTreeOK (forms 9) 288 1872408 q9Shape9T160=true := by
  change (fastTreeOK (forms 9) 288 (1872408 ||| 2^10) q9Shape9T161 &&
    fastTreeOK (forms 9) (288 ||| 2^10) 1872408 q9Shape9T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T161OK,q9Shape9T162OK⟩

private def q9Shape9T167 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T167OK : fastTreeOK (forms 9) 800 1963032 q9Shape9T167=true := by decide

private def q9Shape9T168 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 2 3 5)))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 none (some 6))) (.tip (.unordered 3 5 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape9T168OK : fastTreeOK (forms 9) 66336 1897496 q9Shape9T168=true := by decide

private def q9Shape9T166 : Tree := .split 16 q9Shape9T167 q9Shape9T168
private theorem q9Shape9T166OK : fastTreeOK (forms 9) 800 1897496 q9Shape9T166=true := by
  change (fastTreeOK (forms 9) 800 (1897496 ||| 2^16) q9Shape9T167 &&
    fastTreeOK (forms 9) (800 ||| 2^16) 1897496 q9Shape9T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T167OK,q9Shape9T168OK⟩

private def q9Shape9T169 : Tree := (.tip (.cover 0 3 5 8))
private theorem q9Shape9T169OK : fastTreeOK (forms 9) 17184 1881112 q9Shape9T169=true := by decide

private def q9Shape9T165 : Tree := .split 14 q9Shape9T166 q9Shape9T169
private theorem q9Shape9T165OK : fastTreeOK (forms 9) 800 1881112 q9Shape9T165=true := by
  change (fastTreeOK (forms 9) 800 (1881112 ||| 2^14) q9Shape9T166 &&
    fastTreeOK (forms 9) (800 ||| 2^14) 1881112 q9Shape9T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T166OK,q9Shape9T169OK⟩

private def q9Shape9T171 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 5 6 7))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 7 8)))
private theorem q9Shape9T171OK : fastTreeOK (forms 9) 8992 1889304 q9Shape9T171=true := by decide

private def q9Shape9T172 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 5 8)))
private theorem q9Shape9T172OK : fastTreeOK (forms 9) 25376 1872920 q9Shape9T172=true := by decide

private def q9Shape9T170 : Tree := .split 14 q9Shape9T171 q9Shape9T172
private theorem q9Shape9T170OK : fastTreeOK (forms 9) 8992 1872920 q9Shape9T170=true := by
  change (fastTreeOK (forms 9) 8992 (1872920 ||| 2^14) q9Shape9T171 &&
    fastTreeOK (forms 9) (8992 ||| 2^14) 1872920 q9Shape9T172)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T171OK,q9Shape9T172OK⟩

private def q9Shape9T164 : Tree := .split 13 q9Shape9T165 q9Shape9T170
private theorem q9Shape9T164OK : fastTreeOK (forms 9) 800 1872920 q9Shape9T164=true := by
  change (fastTreeOK (forms 9) 800 (1872920 ||| 2^13) q9Shape9T165 &&
    fastTreeOK (forms 9) (800 ||| 2^13) 1872920 q9Shape9T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T165OK,q9Shape9T170OK⟩

private def q9Shape9T174 : Tree := (.split 14 (.split 16 (.tip (.cover 0 1 3 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 3 5)))) (.tip (.cover 0 3 5 8)))
private theorem q9Shape9T174OK : fastTreeOK (forms 9) 1824 1880088 q9Shape9T174=true := by decide

private def q9Shape9T175 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 3 4)))
private theorem q9Shape9T175OK : fastTreeOK (forms 9) 10016 1871896 q9Shape9T175=true := by decide

private def q9Shape9T173 : Tree := .split 13 q9Shape9T174 q9Shape9T175
private theorem q9Shape9T173OK : fastTreeOK (forms 9) 1824 1871896 q9Shape9T173=true := by
  change (fastTreeOK (forms 9) 1824 (1871896 ||| 2^13) q9Shape9T174 &&
    fastTreeOK (forms 9) (1824 ||| 2^13) 1871896 q9Shape9T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T174OK,q9Shape9T175OK⟩

private def q9Shape9T163 : Tree := .split 10 q9Shape9T164 q9Shape9T173
private theorem q9Shape9T163OK : fastTreeOK (forms 9) 800 1871896 q9Shape9T163=true := by
  change (fastTreeOK (forms 9) 800 (1871896 ||| 2^10) q9Shape9T164 &&
    fastTreeOK (forms 9) (800 ||| 2^10) 1871896 q9Shape9T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T164OK,q9Shape9T173OK⟩

private def q9Shape9T159 : Tree := .split 9 q9Shape9T160 q9Shape9T163
private theorem q9Shape9T159OK : fastTreeOK (forms 9) 288 1871896 q9Shape9T159=true := by
  change (fastTreeOK (forms 9) 288 (1871896 ||| 2^9) q9Shape9T160 &&
    fastTreeOK (forms 9) (288 ||| 2^9) 1871896 q9Shape9T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T160OK,q9Shape9T163OK⟩

private def q9Shape9T143 : Tree := .split 5 q9Shape9T144 q9Shape9T159
private theorem q9Shape9T143OK : fastTreeOK (forms 9) 256 1871896 q9Shape9T143=true := by
  change (fastTreeOK (forms 9) 256 (1871896 ||| 2^5) q9Shape9T144 &&
    fastTreeOK (forms 9) (256 ||| 2^5) 1871896 q9Shape9T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T144OK,q9Shape9T159OK⟩

private def q9Shape9T179 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6))))) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 7 8)))) (.split 14 (.tip (.cover 0 3 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 3 7 8)))))
private theorem q9Shape9T179OK : fastTreeOK (forms 9) 272 1873448 q9Shape9T179=true := by decide

private def q9Shape9T183 : Tree := (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape9T183OK : fastTreeOK (forms 9) 1296 1962536 q9Shape9T183=true := by decide

private def q9Shape9T184 : Tree := (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.unordered 3 5 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape9T184OK : fastTreeOK (forms 9) 66832 1897000 q9Shape9T184=true := by decide

private def q9Shape9T182 : Tree := .split 16 q9Shape9T183 q9Shape9T184
private theorem q9Shape9T182OK : fastTreeOK (forms 9) 1296 1897000 q9Shape9T182=true := by
  change (fastTreeOK (forms 9) 1296 (1897000 ||| 2^16) q9Shape9T183 &&
    fastTreeOK (forms 9) (1296 ||| 2^16) 1897000 q9Shape9T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T183OK,q9Shape9T184OK⟩

private def q9Shape9T185 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 5 6 8))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 5 6 8)))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 4 7)))
private theorem q9Shape9T185OK : fastTreeOK (forms 9) 17680 1880616 q9Shape9T185=true := by decide

private def q9Shape9T181 : Tree := .split 14 q9Shape9T182 q9Shape9T185
private theorem q9Shape9T181OK : fastTreeOK (forms 9) 1296 1880616 q9Shape9T181=true := by
  change (fastTreeOK (forms 9) 1296 (1880616 ||| 2^14) q9Shape9T182 &&
    fastTreeOK (forms 9) (1296 ||| 2^14) 1880616 q9Shape9T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T182OK,q9Shape9T185OK⟩

private def q9Shape9T186 : Tree := (.split 14 (.tip (.cover 0 3 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 3 4 7))))
private theorem q9Shape9T186OK : fastTreeOK (forms 9) 9488 1872424 q9Shape9T186=true := by decide

private def q9Shape9T180 : Tree := .split 13 q9Shape9T181 q9Shape9T186
private theorem q9Shape9T180OK : fastTreeOK (forms 9) 1296 1872424 q9Shape9T180=true := by
  change (fastTreeOK (forms 9) 1296 (1872424 ||| 2^13) q9Shape9T181 &&
    fastTreeOK (forms 9) (1296 ||| 2^13) 1872424 q9Shape9T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T181OK,q9Shape9T186OK⟩

private def q9Shape9T178 : Tree := .split 10 q9Shape9T179 q9Shape9T180
private theorem q9Shape9T178OK : fastTreeOK (forms 9) 272 1872424 q9Shape9T178=true := by
  change (fastTreeOK (forms 9) 272 (1872424 ||| 2^10) q9Shape9T179 &&
    fastTreeOK (forms 9) (272 ||| 2^10) 1872424 q9Shape9T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T179OK,q9Shape9T180OK⟩

private def q9Shape9T188 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none)))) (.tip (.cover 0 1 3 5))) (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 7 8)))) (.split 14 (.tip (.cover 0 3 5 7)) (.split 16 (.split 17 (.tip (.cover 0 1 3 4)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 7 8)))))
private theorem q9Shape9T188OK : fastTreeOK (forms 9) 784 1872936 q9Shape9T188=true := by decide

private def q9Shape9T191 : Tree := (.split 16 (.split 17 (.tip (.cover 0 1 3 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 1 3 5)))
private theorem q9Shape9T191OK : fastTreeOK (forms 9) 1808 1896488 q9Shape9T191=true := by decide

private def q9Shape9T192 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 4 7)))
private theorem q9Shape9T192OK : fastTreeOK (forms 9) 18192 1880104 q9Shape9T192=true := by decide

private def q9Shape9T190 : Tree := .split 14 q9Shape9T191 q9Shape9T192
private theorem q9Shape9T190OK : fastTreeOK (forms 9) 1808 1880104 q9Shape9T190=true := by
  change (fastTreeOK (forms 9) 1808 (1880104 ||| 2^14) q9Shape9T191 &&
    fastTreeOK (forms 9) (1808 ||| 2^14) 1880104 q9Shape9T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T191OK,q9Shape9T192OK⟩

private def q9Shape9T193 : Tree := (.split 14 (.tip (.cover 0 3 5 7)) (.tip (.cover 0 1 3 4)))
private theorem q9Shape9T193OK : fastTreeOK (forms 9) 10000 1871912 q9Shape9T193=true := by decide

private def q9Shape9T189 : Tree := .split 13 q9Shape9T190 q9Shape9T193
private theorem q9Shape9T189OK : fastTreeOK (forms 9) 1808 1871912 q9Shape9T189=true := by
  change (fastTreeOK (forms 9) 1808 (1871912 ||| 2^13) q9Shape9T190 &&
    fastTreeOK (forms 9) (1808 ||| 2^13) 1871912 q9Shape9T193)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T190OK,q9Shape9T193OK⟩

private def q9Shape9T187 : Tree := .split 10 q9Shape9T188 q9Shape9T189
private theorem q9Shape9T187OK : fastTreeOK (forms 9) 784 1871912 q9Shape9T187=true := by
  change (fastTreeOK (forms 9) 784 (1871912 ||| 2^10) q9Shape9T188 &&
    fastTreeOK (forms 9) (784 ||| 2^10) 1871912 q9Shape9T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T188OK,q9Shape9T189OK⟩

private def q9Shape9T177 : Tree := .split 9 q9Shape9T178 q9Shape9T187
private theorem q9Shape9T177OK : fastTreeOK (forms 9) 272 1871912 q9Shape9T177=true := by
  change (fastTreeOK (forms 9) 272 (1871912 ||| 2^9) q9Shape9T178 &&
    fastTreeOK (forms 9) (272 ||| 2^9) 1871912 q9Shape9T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T178OK,q9Shape9T187OK⟩

private def q9Shape9T197 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6))))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape9T197OK : fastTreeOK (forms 9) 304 1881608 q9Shape9T197=true := by decide

private def q9Shape9T198 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 3 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 7 8))) (.tip (.cover 0 3 7 8))))
private theorem q9Shape9T198OK : fastTreeOK (forms 9) 8496 1873416 q9Shape9T198=true := by decide

private def q9Shape9T196 : Tree := .split 13 q9Shape9T197 q9Shape9T198
private theorem q9Shape9T196OK : fastTreeOK (forms 9) 304 1873416 q9Shape9T196=true := by
  change (fastTreeOK (forms 9) 304 (1873416 ||| 2^13) q9Shape9T197 &&
    fastTreeOK (forms 9) (304 ||| 2^13) 1873416 q9Shape9T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T197OK,q9Shape9T198OK⟩

private def q9Shape9T200 : Tree := (.split 14 (.split 16 (.tip (.cover 0 1 2 3)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6))))) (.split 16 (.tip (.cover 0 1 2 3)) (.tip (.cover 0 3 4 7))))
private theorem q9Shape9T200OK : fastTreeOK (forms 9) 1328 1880584 q9Shape9T200=true := by decide

private def q9Shape9T201 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 1 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 2 3 7))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T201OK : fastTreeOK (forms 9) 9520 1872392 q9Shape9T201=true := by decide

private def q9Shape9T199 : Tree := .split 13 q9Shape9T200 q9Shape9T201
private theorem q9Shape9T199OK : fastTreeOK (forms 9) 1328 1872392 q9Shape9T199=true := by
  change (fastTreeOK (forms 9) 1328 (1872392 ||| 2^13) q9Shape9T200 &&
    fastTreeOK (forms 9) (1328 ||| 2^13) 1872392 q9Shape9T201)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T200OK,q9Shape9T201OK⟩

private def q9Shape9T195 : Tree := .split 10 q9Shape9T196 q9Shape9T199
private theorem q9Shape9T195OK : fastTreeOK (forms 9) 304 1872392 q9Shape9T195=true := by
  change (fastTreeOK (forms 9) 304 (1872392 ||| 2^10) q9Shape9T196 &&
    fastTreeOK (forms 9) (304 ||| 2^10) 1872392 q9Shape9T199)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T196OK,q9Shape9T199OK⟩

private def q9Shape9T204 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 2 3)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))))) (.split 17 (.tip (.cover 0 1 2 3)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 6)))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6))))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 5 8))))
private theorem q9Shape9T204OK : fastTreeOK (forms 9) 816 1881096 q9Shape9T204=true := by decide

private def q9Shape9T205 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 2 3)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) none)) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 5 8))))
private theorem q9Shape9T205OK : fastTreeOK (forms 9) 9008 1872904 q9Shape9T205=true := by decide

private def q9Shape9T203 : Tree := .split 13 q9Shape9T204 q9Shape9T205
private theorem q9Shape9T203OK : fastTreeOK (forms 9) 816 1872904 q9Shape9T203=true := by
  change (fastTreeOK (forms 9) 816 (1872904 ||| 2^13) q9Shape9T204 &&
    fastTreeOK (forms 9) (816 ||| 2^13) 1872904 q9Shape9T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T204OK,q9Shape9T205OK⟩

private def q9Shape9T206 : Tree := (.tip (.cover 0 1 2 3))
private theorem q9Shape9T206OK : fastTreeOK (forms 9) 1840 1871880 q9Shape9T206=true := by decide

private def q9Shape9T202 : Tree := .split 10 q9Shape9T203 q9Shape9T206
private theorem q9Shape9T202OK : fastTreeOK (forms 9) 816 1871880 q9Shape9T202=true := by
  change (fastTreeOK (forms 9) 816 (1871880 ||| 2^10) q9Shape9T203 &&
    fastTreeOK (forms 9) (816 ||| 2^10) 1871880 q9Shape9T206)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T203OK,q9Shape9T206OK⟩

private def q9Shape9T194 : Tree := .split 9 q9Shape9T195 q9Shape9T202
private theorem q9Shape9T194OK : fastTreeOK (forms 9) 304 1871880 q9Shape9T194=true := by
  change (fastTreeOK (forms 9) 304 (1871880 ||| 2^9) q9Shape9T195 &&
    fastTreeOK (forms 9) (304 ||| 2^9) 1871880 q9Shape9T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T195OK,q9Shape9T202OK⟩

private def q9Shape9T176 : Tree := .split 5 q9Shape9T177 q9Shape9T194
private theorem q9Shape9T176OK : fastTreeOK (forms 9) 272 1871880 q9Shape9T176=true := by
  change (fastTreeOK (forms 9) 272 (1871880 ||| 2^5) q9Shape9T177 &&
    fastTreeOK (forms 9) (272 ||| 2^5) 1871880 q9Shape9T194)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T177OK,q9Shape9T194OK⟩

private def q9Shape9T142 : Tree := .split 4 q9Shape9T143 q9Shape9T176
private theorem q9Shape9T142OK : fastTreeOK (forms 9) 256 1871880 q9Shape9T142=true := by
  change (fastTreeOK (forms 9) 256 (1871880 ||| 2^4) q9Shape9T143 &&
    fastTreeOK (forms 9) (256 ||| 2^4) 1871880 q9Shape9T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T143OK,q9Shape9T176OK⟩

private def q9Shape9T207 : Tree := (.tip (.cover 2 3 4 5))
private theorem q9Shape9T207OK : fastTreeOK (forms 9) 33024 1839112 q9Shape9T207=true := by decide

private def q9Shape9T141 : Tree := .split 15 q9Shape9T142 q9Shape9T207
private theorem q9Shape9T141OK : fastTreeOK (forms 9) 256 1839112 q9Shape9T141=true := by
  change (fastTreeOK (forms 9) 256 (1839112 ||| 2^15) q9Shape9T142 &&
    fastTreeOK (forms 9) (256 ||| 2^15) 1839112 q9Shape9T207)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T142OK,q9Shape9T207OK⟩

private def q9Shape9T208 : Tree := (.tip (.cover 2 3 4 5))
private theorem q9Shape9T208OK : fastTreeOK (forms 9) 4352 1835016 q9Shape9T208=true := by decide

private def q9Shape9T140 : Tree := .split 12 q9Shape9T141 q9Shape9T208
private theorem q9Shape9T140OK : fastTreeOK (forms 9) 256 1835016 q9Shape9T140=true := by
  change (fastTreeOK (forms 9) 256 (1835016 ||| 2^12) q9Shape9T141 &&
    fastTreeOK (forms 9) (256 ||| 2^12) 1835016 q9Shape9T208)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T141OK,q9Shape9T208OK⟩

private def q9Shape9T4 : Tree := .split 8 q9Shape9T5 q9Shape9T140
private theorem q9Shape9T4OK : fastTreeOK (forms 9) 0 1835016 q9Shape9T4=true := by
  change (fastTreeOK (forms 9) 0 (1835016 ||| 2^8) q9Shape9T5 &&
    fastTreeOK (forms 9) (0 ||| 2^8) 1835016 q9Shape9T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T5OK,q9Shape9T140OK⟩

private def q9Shape9T217 : Tree := (.split 14 (.tip (.drop 7 8 none none)) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))))))
private theorem q9Shape9T217OK : fastTreeOK (forms 9) 8 1881904 q9Shape9T217=true := by decide

private def q9Shape9T219 : Tree := (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))))
private theorem q9Shape9T219OK : fastTreeOK (forms 9) 8200 1890096 q9Shape9T219=true := by decide

private def q9Shape9T220 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))))
private theorem q9Shape9T220OK : fastTreeOK (forms 9) 24584 1873712 q9Shape9T220=true := by decide

private def q9Shape9T218 : Tree := .split 14 q9Shape9T219 q9Shape9T220
private theorem q9Shape9T218OK : fastTreeOK (forms 9) 8200 1873712 q9Shape9T218=true := by
  change (fastTreeOK (forms 9) 8200 (1873712 ||| 2^14) q9Shape9T219 &&
    fastTreeOK (forms 9) (8200 ||| 2^14) 1873712 q9Shape9T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T219OK,q9Shape9T220OK⟩

private def q9Shape9T216 : Tree := .split 13 q9Shape9T217 q9Shape9T218
private theorem q9Shape9T216OK : fastTreeOK (forms 9) 8 1873712 q9Shape9T216=true := by
  change (fastTreeOK (forms 9) 8 (1873712 ||| 2^13) q9Shape9T217 &&
    fastTreeOK (forms 9) (8 ||| 2^13) 1873712 q9Shape9T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T217OK,q9Shape9T218OK⟩

private def q9Shape9T221 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))))) (.tip (.cover 0 2 5 8))) (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 7 8)))))
private theorem q9Shape9T221OK : fastTreeOK (forms 9) 1032 1872688 q9Shape9T221=true := by decide

private def q9Shape9T215 : Tree := .split 10 q9Shape9T216 q9Shape9T221
private theorem q9Shape9T215OK : fastTreeOK (forms 9) 8 1872688 q9Shape9T215=true := by
  change (fastTreeOK (forms 9) 8 (1872688 ||| 2^10) q9Shape9T216 &&
    fastTreeOK (forms 9) (8 ||| 2^10) 1872688 q9Shape9T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T216OK,q9Shape9T221OK⟩

private def q9Shape9T223 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))))) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 7 8)))) (.split 14 (.tip (.cover 0 2 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 2 7 8)))))
private theorem q9Shape9T223OK : fastTreeOK (forms 9) 520 1873200 q9Shape9T223=true := by decide

private def q9Shape9T226 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))))
private theorem q9Shape9T226OK : fastTreeOK (forms 9) 1544 1896752 q9Shape9T226=true := by decide

private def q9Shape9T227 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 7 8)))
private theorem q9Shape9T227OK : fastTreeOK (forms 9) 17928 1880368 q9Shape9T227=true := by decide

private def q9Shape9T225 : Tree := .split 14 q9Shape9T226 q9Shape9T227
private theorem q9Shape9T225OK : fastTreeOK (forms 9) 1544 1880368 q9Shape9T225=true := by
  change (fastTreeOK (forms 9) 1544 (1880368 ||| 2^14) q9Shape9T226 &&
    fastTreeOK (forms 9) (1544 ||| 2^14) 1880368 q9Shape9T227)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T226OK,q9Shape9T227OK⟩

private def q9Shape9T228 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 2 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 7 8))) (.tip (.cover 0 2 7 8))))
private theorem q9Shape9T228OK : fastTreeOK (forms 9) 9736 1872176 q9Shape9T228=true := by decide

private def q9Shape9T224 : Tree := .split 13 q9Shape9T225 q9Shape9T228
private theorem q9Shape9T224OK : fastTreeOK (forms 9) 1544 1872176 q9Shape9T224=true := by
  change (fastTreeOK (forms 9) 1544 (1872176 ||| 2^13) q9Shape9T225 &&
    fastTreeOK (forms 9) (1544 ||| 2^13) 1872176 q9Shape9T228)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T225OK,q9Shape9T228OK⟩

private def q9Shape9T222 : Tree := .split 10 q9Shape9T223 q9Shape9T224
private theorem q9Shape9T222OK : fastTreeOK (forms 9) 520 1872176 q9Shape9T222=true := by
  change (fastTreeOK (forms 9) 520 (1872176 ||| 2^10) q9Shape9T223 &&
    fastTreeOK (forms 9) (520 ||| 2^10) 1872176 q9Shape9T224)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T223OK,q9Shape9T224OK⟩

private def q9Shape9T214 : Tree := .split 9 q9Shape9T215 q9Shape9T222
private theorem q9Shape9T214OK : fastTreeOK (forms 9) 8 1872176 q9Shape9T214=true := by
  change (fastTreeOK (forms 9) 8 (1872176 ||| 2^9) q9Shape9T215 &&
    fastTreeOK (forms 9) (8 ||| 2^9) 1872176 q9Shape9T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T215OK,q9Shape9T222OK⟩

private def q9Shape9T232 : Tree := (.split 14 (.tip (.cover 0 1 2 5)) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5)))))
private theorem q9Shape9T232OK : fastTreeOK (forms 9) 40 1881872 q9Shape9T232=true := by decide

private def q9Shape9T234 : Tree := (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6))))) (.tip (.cover 0 2 4 5)))) (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))))
private theorem q9Shape9T234OK : fastTreeOK (forms 9) 8232 1890064 q9Shape9T234=true := by decide

private def q9Shape9T235 : Tree := (.split 16 (.tip (.cover 0 1 2 4)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))))
private theorem q9Shape9T235OK : fastTreeOK (forms 9) 24616 1873680 q9Shape9T235=true := by decide

private def q9Shape9T233 : Tree := .split 14 q9Shape9T234 q9Shape9T235
private theorem q9Shape9T233OK : fastTreeOK (forms 9) 8232 1873680 q9Shape9T233=true := by
  change (fastTreeOK (forms 9) 8232 (1873680 ||| 2^14) q9Shape9T234 &&
    fastTreeOK (forms 9) (8232 ||| 2^14) 1873680 q9Shape9T235)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T234OK,q9Shape9T235OK⟩

private def q9Shape9T231 : Tree := .split 13 q9Shape9T232 q9Shape9T233
private theorem q9Shape9T231OK : fastTreeOK (forms 9) 40 1873680 q9Shape9T231=true := by
  change (fastTreeOK (forms 9) 40 (1873680 ||| 2^13) q9Shape9T232 &&
    fastTreeOK (forms 9) (40 ||| 2^13) 1873680 q9Shape9T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T232OK,q9Shape9T233OK⟩

private def q9Shape9T236 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 2 5 8))) (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 3 7))) (.split 16 (.tip (.cover 0 1 2 4)) (.tip (.cover 0 2 3 7)))))
private theorem q9Shape9T236OK : fastTreeOK (forms 9) 1064 1872656 q9Shape9T236=true := by decide

private def q9Shape9T230 : Tree := .split 10 q9Shape9T231 q9Shape9T236
private theorem q9Shape9T230OK : fastTreeOK (forms 9) 40 1872656 q9Shape9T230=true := by
  change (fastTreeOK (forms 9) 40 (1872656 ||| 2^10) q9Shape9T231 &&
    fastTreeOK (forms 9) (40 ||| 2^10) 1872656 q9Shape9T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T231OK,q9Shape9T236OK⟩

private def q9Shape9T241 : Tree := (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape9T241OK : fastTreeOK (forms 9) 552 1963280 q9Shape9T241=true := by decide

private def q9Shape9T242 : Tree := (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 none (some 6))) (.tip (.unordered 2 5 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))))
private theorem q9Shape9T242OK : fastTreeOK (forms 9) 66088 1897744 q9Shape9T242=true := by decide

private def q9Shape9T240 : Tree := .split 16 q9Shape9T241 q9Shape9T242
private theorem q9Shape9T240OK : fastTreeOK (forms 9) 552 1897744 q9Shape9T240=true := by
  change (fastTreeOK (forms 9) 552 (1897744 ||| 2^16) q9Shape9T241 &&
    fastTreeOK (forms 9) (552 ||| 2^16) 1897744 q9Shape9T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T241OK,q9Shape9T242OK⟩

private def q9Shape9T243 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6))))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 4 7)))
private theorem q9Shape9T243OK : fastTreeOK (forms 9) 16936 1881360 q9Shape9T243=true := by decide

private def q9Shape9T239 : Tree := .split 14 q9Shape9T240 q9Shape9T243
private theorem q9Shape9T239OK : fastTreeOK (forms 9) 552 1881360 q9Shape9T239=true := by
  change (fastTreeOK (forms 9) 552 (1881360 ||| 2^14) q9Shape9T240 &&
    fastTreeOK (forms 9) (552 ||| 2^14) 1881360 q9Shape9T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T240OK,q9Shape9T243OK⟩

private def q9Shape9T244 : Tree := (.split 14 (.tip (.cover 0 2 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 2 4 7))))
private theorem q9Shape9T244OK : fastTreeOK (forms 9) 8744 1873168 q9Shape9T244=true := by decide

private def q9Shape9T238 : Tree := .split 13 q9Shape9T239 q9Shape9T244
private theorem q9Shape9T238OK : fastTreeOK (forms 9) 552 1873168 q9Shape9T238=true := by
  change (fastTreeOK (forms 9) 552 (1873168 ||| 2^13) q9Shape9T239 &&
    fastTreeOK (forms 9) (552 ||| 2^13) 1873168 q9Shape9T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T239OK,q9Shape9T244OK⟩

private def q9Shape9T247 : Tree := (.split 16 (.tip (.cover 0 1 2 3)) (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 none (some 6))) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5)))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))))
private theorem q9Shape9T247OK : fastTreeOK (forms 9) 1576 1896720 q9Shape9T247=true := by decide

private def q9Shape9T248 : Tree := (.split 16 (.tip (.cover 0 1 2 3)) (.tip (.cover 0 2 4 7)))
private theorem q9Shape9T248OK : fastTreeOK (forms 9) 17960 1880336 q9Shape9T248=true := by decide

private def q9Shape9T246 : Tree := .split 14 q9Shape9T247 q9Shape9T248
private theorem q9Shape9T246OK : fastTreeOK (forms 9) 1576 1880336 q9Shape9T246=true := by
  change (fastTreeOK (forms 9) 1576 (1880336 ||| 2^14) q9Shape9T247 &&
    fastTreeOK (forms 9) (1576 ||| 2^14) 1880336 q9Shape9T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T247OK,q9Shape9T248OK⟩

private def q9Shape9T250 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 2 3 7)))
private theorem q9Shape9T250OK : fastTreeOK (forms 9) 9768 1888528 q9Shape9T250=true := by decide

private def q9Shape9T251 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 2 3 7)))
private theorem q9Shape9T251OK : fastTreeOK (forms 9) 26152 1872144 q9Shape9T251=true := by decide

private def q9Shape9T249 : Tree := .split 14 q9Shape9T250 q9Shape9T251
private theorem q9Shape9T249OK : fastTreeOK (forms 9) 9768 1872144 q9Shape9T249=true := by
  change (fastTreeOK (forms 9) 9768 (1872144 ||| 2^14) q9Shape9T250 &&
    fastTreeOK (forms 9) (9768 ||| 2^14) 1872144 q9Shape9T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T250OK,q9Shape9T251OK⟩

private def q9Shape9T245 : Tree := .split 13 q9Shape9T246 q9Shape9T249
private theorem q9Shape9T245OK : fastTreeOK (forms 9) 1576 1872144 q9Shape9T245=true := by
  change (fastTreeOK (forms 9) 1576 (1872144 ||| 2^13) q9Shape9T246 &&
    fastTreeOK (forms 9) (1576 ||| 2^13) 1872144 q9Shape9T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T246OK,q9Shape9T249OK⟩

private def q9Shape9T237 : Tree := .split 10 q9Shape9T238 q9Shape9T245
private theorem q9Shape9T237OK : fastTreeOK (forms 9) 552 1872144 q9Shape9T237=true := by
  change (fastTreeOK (forms 9) 552 (1872144 ||| 2^10) q9Shape9T238 &&
    fastTreeOK (forms 9) (552 ||| 2^10) 1872144 q9Shape9T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T238OK,q9Shape9T245OK⟩

private def q9Shape9T229 : Tree := .split 9 q9Shape9T230 q9Shape9T237
private theorem q9Shape9T229OK : fastTreeOK (forms 9) 40 1872144 q9Shape9T229=true := by
  change (fastTreeOK (forms 9) 40 (1872144 ||| 2^9) q9Shape9T230 &&
    fastTreeOK (forms 9) (40 ||| 2^9) 1872144 q9Shape9T237)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T230OK,q9Shape9T237OK⟩

private def q9Shape9T213 : Tree := .split 5 q9Shape9T214 q9Shape9T229
private theorem q9Shape9T213OK : fastTreeOK (forms 9) 8 1872144 q9Shape9T213=true := by
  change (fastTreeOK (forms 9) 8 (1872144 ||| 2^5) q9Shape9T214 &&
    fastTreeOK (forms 9) (8 ||| 2^5) 1872144 q9Shape9T229)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T214OK,q9Shape9T229OK⟩

private def q9Shape9T256 : Tree := (.split 14 (.tip (.cover 0 1 2 5)) (.split 16 (.tip (.cover 0 1 2 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none)))) (.tip (.cover 0 2 4 5))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5))))))
private theorem q9Shape9T256OK : fastTreeOK (forms 9) 24 1881888 q9Shape9T256=true := by decide

private def q9Shape9T258 : Tree := (.split 16 (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 5)))
private theorem q9Shape9T258OK : fastTreeOK (forms 9) 8216 1890080 q9Shape9T258=true := by decide

private def q9Shape9T259 : Tree := (.split 16 (.split 17 (.tip (.cover 0 1 2 4)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 2 4 5))))) (.tip (.cover 0 2 4 5)))) (.split 17 (.tip (.cover 0 1 2 4)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))))
private theorem q9Shape9T259OK : fastTreeOK (forms 9) 24600 1873696 q9Shape9T259=true := by decide

private def q9Shape9T257 : Tree := .split 14 q9Shape9T258 q9Shape9T259
private theorem q9Shape9T257OK : fastTreeOK (forms 9) 8216 1873696 q9Shape9T257=true := by
  change (fastTreeOK (forms 9) 8216 (1873696 ||| 2^14) q9Shape9T258 &&
    fastTreeOK (forms 9) (8216 ||| 2^14) 1873696 q9Shape9T259)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T258OK,q9Shape9T259OK⟩

private def q9Shape9T255 : Tree := .split 13 q9Shape9T256 q9Shape9T257
private theorem q9Shape9T255OK : fastTreeOK (forms 9) 24 1873696 q9Shape9T255=true := by
  change (fastTreeOK (forms 9) 24 (1873696 ||| 2^13) q9Shape9T256 &&
    fastTreeOK (forms 9) (24 ||| 2^13) 1873696 q9Shape9T257)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T256OK,q9Shape9T257OK⟩

private def q9Shape9T262 : Tree := (.split 16 (.tip (.cover 0 1 2 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5)))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.unordered 2 5 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))))))
private theorem q9Shape9T262OK : fastTreeOK (forms 9) 1048 1897248 q9Shape9T262=true := by decide

private def q9Shape9T263 : Tree := (.tip (.cover 0 2 5 8))
private theorem q9Shape9T263OK : fastTreeOK (forms 9) 17432 1880864 q9Shape9T263=true := by decide

private def q9Shape9T261 : Tree := .split 14 q9Shape9T262 q9Shape9T263
private theorem q9Shape9T261OK : fastTreeOK (forms 9) 1048 1880864 q9Shape9T261=true := by
  change (fastTreeOK (forms 9) 1048 (1880864 ||| 2^14) q9Shape9T262 &&
    fastTreeOK (forms 9) (1048 ||| 2^14) 1880864 q9Shape9T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T262OK,q9Shape9T263OK⟩

private def q9Shape9T264 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 5 8))))
private theorem q9Shape9T264OK : fastTreeOK (forms 9) 9240 1872672 q9Shape9T264=true := by decide

private def q9Shape9T260 : Tree := .split 13 q9Shape9T261 q9Shape9T264
private theorem q9Shape9T260OK : fastTreeOK (forms 9) 1048 1872672 q9Shape9T260=true := by
  change (fastTreeOK (forms 9) 1048 (1872672 ||| 2^13) q9Shape9T261 &&
    fastTreeOK (forms 9) (1048 ||| 2^13) 1872672 q9Shape9T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T261OK,q9Shape9T264OK⟩

private def q9Shape9T254 : Tree := .split 10 q9Shape9T255 q9Shape9T260
private theorem q9Shape9T254OK : fastTreeOK (forms 9) 24 1872672 q9Shape9T254=true := by
  change (fastTreeOK (forms 9) 24 (1872672 ||| 2^10) q9Shape9T255 &&
    fastTreeOK (forms 9) (24 ||| 2^10) 1872672 q9Shape9T260)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T255OK,q9Shape9T260OK⟩

private def q9Shape9T266 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none)))) (.tip (.cover 0 1 2 5))) (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 7 8)))) (.split 14 (.tip (.cover 0 2 5 7)) (.split 16 (.split 17 (.tip (.cover 0 1 2 4)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 7 8)))))
private theorem q9Shape9T266OK : fastTreeOK (forms 9) 536 1873184 q9Shape9T266=true := by decide

private def q9Shape9T269 : Tree := (.split 16 (.split 17 (.tip (.cover 0 1 2 3)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) none))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) none)) (.tip (.unordered 2 3 1))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 2 3 5))))) (.split 17 (.tip (.cover 0 1 2 3)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6)))))
private theorem q9Shape9T269OK : fastTreeOK (forms 9) 1560 1896736 q9Shape9T269=true := by decide

private def q9Shape9T270 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 4)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 4))))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 5 8)))
private theorem q9Shape9T270OK : fastTreeOK (forms 9) 17944 1880352 q9Shape9T270=true := by decide

private def q9Shape9T268 : Tree := .split 14 q9Shape9T269 q9Shape9T270
private theorem q9Shape9T268OK : fastTreeOK (forms 9) 1560 1880352 q9Shape9T268=true := by
  change (fastTreeOK (forms 9) 1560 (1880352 ||| 2^14) q9Shape9T269 &&
    fastTreeOK (forms 9) (1560 ||| 2^14) 1880352 q9Shape9T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T269OK,q9Shape9T270OK⟩

private def q9Shape9T271 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 2 3)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 7 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 5 8))))
private theorem q9Shape9T271OK : fastTreeOK (forms 9) 9752 1872160 q9Shape9T271=true := by decide

private def q9Shape9T267 : Tree := .split 13 q9Shape9T268 q9Shape9T271
private theorem q9Shape9T267OK : fastTreeOK (forms 9) 1560 1872160 q9Shape9T267=true := by
  change (fastTreeOK (forms 9) 1560 (1872160 ||| 2^13) q9Shape9T268 &&
    fastTreeOK (forms 9) (1560 ||| 2^13) 1872160 q9Shape9T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T268OK,q9Shape9T271OK⟩

private def q9Shape9T265 : Tree := .split 10 q9Shape9T266 q9Shape9T267
private theorem q9Shape9T265OK : fastTreeOK (forms 9) 536 1872160 q9Shape9T265=true := by
  change (fastTreeOK (forms 9) 536 (1872160 ||| 2^10) q9Shape9T266 &&
    fastTreeOK (forms 9) (536 ||| 2^10) 1872160 q9Shape9T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T266OK,q9Shape9T267OK⟩

private def q9Shape9T253 : Tree := .split 9 q9Shape9T254 q9Shape9T265
private theorem q9Shape9T253OK : fastTreeOK (forms 9) 24 1872160 q9Shape9T253=true := by
  change (fastTreeOK (forms 9) 24 (1872160 ||| 2^9) q9Shape9T254 &&
    fastTreeOK (forms 9) (24 ||| 2^9) 1872160 q9Shape9T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T254OK,q9Shape9T265OK⟩

private def q9Shape9T274 : Tree := (.split 13 (.split 14 (.tip (.cover 0 1 2 5)) (.split 16 (.tip (.cover 0 1 2 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 2 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 2 5))))) (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 5)))) (.tip (.cover 0 1 2 5))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape9T274OK : fastTreeOK (forms 9) 56 1873664 q9Shape9T274=true := by decide

private def q9Shape9T275 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.cover 0 1 2 8)) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 2 5)))) (.tip (.cover 0 2 5 8))) (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) none))) (.split 1 (.tip (.drop 7 8 none (some 6))) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 3 7))) (.tip (.cover 0 1 2 4))))
private theorem q9Shape9T275OK : fastTreeOK (forms 9) 1080 1872640 q9Shape9T275=true := by decide

private def q9Shape9T273 : Tree := .split 10 q9Shape9T274 q9Shape9T275
private theorem q9Shape9T273OK : fastTreeOK (forms 9) 56 1872640 q9Shape9T273=true := by
  change (fastTreeOK (forms 9) 56 (1872640 ||| 2^10) q9Shape9T274 &&
    fastTreeOK (forms 9) (56 ||| 2^10) 1872640 q9Shape9T275)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T274OK,q9Shape9T275OK⟩

private def q9Shape9T276 : Tree := (.split 10 (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.cover 0 1 2 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6)))) (.tip (.cover 0 2 3 5))))) (.tip (.cover 0 1 2 5))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 none (some 6)))) (.split 1 (.tip (.drop 7 8 (some 6) none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 4 7)))) (.split 14 (.tip (.cover 0 2 5 7)) (.tip (.cover 0 1 2 4)))) (.tip (.cover 0 1 2 3)))
private theorem q9Shape9T276OK : fastTreeOK (forms 9) 568 1872128 q9Shape9T276=true := by decide

private def q9Shape9T272 : Tree := .split 9 q9Shape9T273 q9Shape9T276
private theorem q9Shape9T272OK : fastTreeOK (forms 9) 56 1872128 q9Shape9T272=true := by
  change (fastTreeOK (forms 9) 56 (1872128 ||| 2^9) q9Shape9T273 &&
    fastTreeOK (forms 9) (56 ||| 2^9) 1872128 q9Shape9T276)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T273OK,q9Shape9T276OK⟩

private def q9Shape9T252 : Tree := .split 5 q9Shape9T253 q9Shape9T272
private theorem q9Shape9T252OK : fastTreeOK (forms 9) 24 1872128 q9Shape9T252=true := by
  change (fastTreeOK (forms 9) 24 (1872128 ||| 2^5) q9Shape9T253 &&
    fastTreeOK (forms 9) (24 ||| 2^5) 1872128 q9Shape9T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T253OK,q9Shape9T272OK⟩

private def q9Shape9T212 : Tree := .split 4 q9Shape9T213 q9Shape9T252
private theorem q9Shape9T212OK : fastTreeOK (forms 9) 8 1872128 q9Shape9T212=true := by
  change (fastTreeOK (forms 9) 8 (1872128 ||| 2^4) q9Shape9T213 &&
    fastTreeOK (forms 9) (8 ||| 2^4) 1872128 q9Shape9T252)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T213OK,q9Shape9T252OK⟩

private def q9Shape9T277 : Tree := (.tip (.cover 2 3 4 5))
private theorem q9Shape9T277OK : fastTreeOK (forms 9) 32776 1839360 q9Shape9T277=true := by decide

private def q9Shape9T211 : Tree := .split 15 q9Shape9T212 q9Shape9T277
private theorem q9Shape9T211OK : fastTreeOK (forms 9) 8 1839360 q9Shape9T211=true := by
  change (fastTreeOK (forms 9) 8 (1839360 ||| 2^15) q9Shape9T212 &&
    fastTreeOK (forms 9) (8 ||| 2^15) 1839360 q9Shape9T277)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T212OK,q9Shape9T277OK⟩

private def q9Shape9T278 : Tree := (.tip (.cover 2 3 4 5))
private theorem q9Shape9T278OK : fastTreeOK (forms 9) 4104 1835264 q9Shape9T278=true := by decide

private def q9Shape9T210 : Tree := .split 12 q9Shape9T211 q9Shape9T278
private theorem q9Shape9T210OK : fastTreeOK (forms 9) 8 1835264 q9Shape9T210=true := by
  change (fastTreeOK (forms 9) 8 (1835264 ||| 2^12) q9Shape9T211 &&
    fastTreeOK (forms 9) (8 ||| 2^12) 1835264 q9Shape9T278)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T211OK,q9Shape9T278OK⟩

private def q9Shape9T279 : Tree := (.tip (.cover 2 3 4 5))
private theorem q9Shape9T279OK : fastTreeOK (forms 9) 264 1835008 q9Shape9T279=true := by decide

private def q9Shape9T209 : Tree := .split 8 q9Shape9T210 q9Shape9T279
private theorem q9Shape9T209OK : fastTreeOK (forms 9) 8 1835008 q9Shape9T209=true := by
  change (fastTreeOK (forms 9) 8 (1835008 ||| 2^8) q9Shape9T210 &&
    fastTreeOK (forms 9) (8 ||| 2^8) 1835008 q9Shape9T279)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T210OK,q9Shape9T279OK⟩

private def q9Shape9T3 : Tree := .split 3 q9Shape9T4 q9Shape9T209
private theorem q9Shape9T3OK : fastTreeOK (forms 9) 0 1835008 q9Shape9T3=true := by
  change (fastTreeOK (forms 9) 0 (1835008 ||| 2^3) q9Shape9T4 &&
    fastTreeOK (forms 9) (0 ||| 2^3) 1835008 q9Shape9T209)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T4OK,q9Shape9T209OK⟩

private def q9Shape9T284 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape9T284OK : fastTreeOK (forms 9) 1048576 823560 q9Shape9T284=true := by decide

private def q9Shape9T288 : Tree := (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))))
private theorem q9Shape9T288OK : fastTreeOK (forms 9) 1081344 791352 q9Shape9T288=true := by decide

private def q9Shape9T290 : Tree := (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 2))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))))
private theorem q9Shape9T290OK : fastTreeOK (forms 9) 1081856 791864 q9Shape9T290=true := by decide

private def q9Shape9T292 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape9T292OK : fastTreeOK (forms 9) 1082880 799032 q9Shape9T292=true := by decide

private def q9Shape9T293 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 2))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 7)))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape9T293OK : fastTreeOK (forms 9) 1091072 790840 q9Shape9T293=true := by decide

private def q9Shape9T291 : Tree := .split 13 q9Shape9T292 q9Shape9T293
private theorem q9Shape9T291OK : fastTreeOK (forms 9) 1082880 790840 q9Shape9T291=true := by
  change (fastTreeOK (forms 9) 1082880 (790840 ||| 2^13) q9Shape9T292 &&
    fastTreeOK (forms 9) (1082880 ||| 2^13) 790840 q9Shape9T293)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T292OK,q9Shape9T293OK⟩

private def q9Shape9T289 : Tree := .split 10 q9Shape9T290 q9Shape9T291
private theorem q9Shape9T289OK : fastTreeOK (forms 9) 1081856 790840 q9Shape9T289=true := by
  change (fastTreeOK (forms 9) 1081856 (790840 ||| 2^10) q9Shape9T290 &&
    fastTreeOK (forms 9) (1081856 ||| 2^10) 790840 q9Shape9T291)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T290OK,q9Shape9T291OK⟩

private def q9Shape9T287 : Tree := .split 9 q9Shape9T288 q9Shape9T289
private theorem q9Shape9T287OK : fastTreeOK (forms 9) 1081344 790840 q9Shape9T287=true := by
  change (fastTreeOK (forms 9) 1081344 (790840 ||| 2^9) q9Shape9T288 &&
    fastTreeOK (forms 9) (1081344 ||| 2^9) 790840 q9Shape9T289)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T288OK,q9Shape9T289OK⟩

private def q9Shape9T295 : Tree := (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 4 5 7))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.tip (.cover 0 4 5 8)))
private theorem q9Shape9T295OK : fastTreeOK (forms 9) 1081376 791320 q9Shape9T295=true := by decide

private def q9Shape9T296 : Tree := (.split 10 (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 2 5 7))) (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 3 5 7))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 2 5 7)))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 2 5 7))))
private theorem q9Shape9T296OK : fastTreeOK (forms 9) 1081888 790808 q9Shape9T296=true := by decide

private def q9Shape9T294 : Tree := .split 9 q9Shape9T295 q9Shape9T296
private theorem q9Shape9T294OK : fastTreeOK (forms 9) 1081376 790808 q9Shape9T294=true := by
  change (fastTreeOK (forms 9) 1081376 (790808 ||| 2^9) q9Shape9T295 &&
    fastTreeOK (forms 9) (1081376 ||| 2^9) 790808 q9Shape9T296)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T295OK,q9Shape9T296OK⟩

private def q9Shape9T286 : Tree := .split 5 q9Shape9T287 q9Shape9T294
private theorem q9Shape9T286OK : fastTreeOK (forms 9) 1081344 790808 q9Shape9T286=true := by
  change (fastTreeOK (forms 9) 1081344 (790808 ||| 2^5) q9Shape9T287 &&
    fastTreeOK (forms 9) (1081344 ||| 2^5) 790808 q9Shape9T294)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T287OK,q9Shape9T294OK⟩

private def q9Shape9T299 : Tree := (.split 10 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8)))) (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 4 5 7))) (.tip (.cover 2 3 6 8)))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 3 5 7))))
private theorem q9Shape9T299OK : fastTreeOK (forms 9) 1081360 791336 q9Shape9T299=true := by decide

private def q9Shape9T300 : Tree := (.split 10 (.tip (.cover 0 4 5 7)) (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 3 5 7))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 5 8)))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 3 5 7))))
private theorem q9Shape9T300OK : fastTreeOK (forms 9) 1081872 790824 q9Shape9T300=true := by decide

private def q9Shape9T298 : Tree := .split 9 q9Shape9T299 q9Shape9T300
private theorem q9Shape9T298OK : fastTreeOK (forms 9) 1081360 790824 q9Shape9T298=true := by
  change (fastTreeOK (forms 9) 1081360 (790824 ||| 2^9) q9Shape9T299 &&
    fastTreeOK (forms 9) (1081360 ||| 2^9) 790824 q9Shape9T300)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T299OK,q9Shape9T300OK⟩

private def q9Shape9T304 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 8))) (.tip (.cover 0 4 5 7))) (.tip (.cover 2 3 6 8)))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape9T304OK : fastTreeOK (forms 9) 1081392 800520 q9Shape9T304=true := by decide

private def q9Shape9T305 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 7))) (.tip (.cover 0 4 5 8))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 0 2 5 7))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.tip (.cover 2 3 4 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 3) (some 3)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 2 3 4 6)))) (.tip (.cover 0 2 4 5))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))
private theorem q9Shape9T305OK : fastTreeOK (forms 9) 1089584 792328 q9Shape9T305=true := by decide

private def q9Shape9T303 : Tree := .split 13 q9Shape9T304 q9Shape9T305
private theorem q9Shape9T303OK : fastTreeOK (forms 9) 1081392 792328 q9Shape9T303=true := by
  change (fastTreeOK (forms 9) 1081392 (792328 ||| 2^13) q9Shape9T304 &&
    fastTreeOK (forms 9) (1081392 ||| 2^13) 792328 q9Shape9T305)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T304OK,q9Shape9T305OK⟩

private def q9Shape9T306 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 3 5 7))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 5 7)))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 3 5 7)))
private theorem q9Shape9T306OK : fastTreeOK (forms 9) 1082416 791304 q9Shape9T306=true := by decide

private def q9Shape9T302 : Tree := .split 10 q9Shape9T303 q9Shape9T306
private theorem q9Shape9T302OK : fastTreeOK (forms 9) 1081392 791304 q9Shape9T302=true := by
  change (fastTreeOK (forms 9) 1081392 (791304 ||| 2^10) q9Shape9T303 &&
    fastTreeOK (forms 9) (1081392 ||| 2^10) 791304 q9Shape9T306)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T303OK,q9Shape9T306OK⟩

private def q9Shape9T308 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 2 5 7)))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 2 5 7)))
private theorem q9Shape9T308OK : fastTreeOK (forms 9) 1081904 791816 q9Shape9T308=true := by decide

private def q9Shape9T309 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 3 4 6))) (.tip (.cover 0 2 3 5)))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 2 5 8))) (.tip (.cover 0 2 5 7)))
private theorem q9Shape9T309OK : fastTreeOK (forms 9) 1082928 790792 q9Shape9T309=true := by decide

private def q9Shape9T307 : Tree := .split 10 q9Shape9T308 q9Shape9T309
private theorem q9Shape9T307OK : fastTreeOK (forms 9) 1081904 790792 q9Shape9T307=true := by
  change (fastTreeOK (forms 9) 1081904 (790792 ||| 2^10) q9Shape9T308 &&
    fastTreeOK (forms 9) (1081904 ||| 2^10) 790792 q9Shape9T309)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T308OK,q9Shape9T309OK⟩

private def q9Shape9T301 : Tree := .split 9 q9Shape9T302 q9Shape9T307
private theorem q9Shape9T301OK : fastTreeOK (forms 9) 1081392 790792 q9Shape9T301=true := by
  change (fastTreeOK (forms 9) 1081392 (790792 ||| 2^9) q9Shape9T302 &&
    fastTreeOK (forms 9) (1081392 ||| 2^9) 790792 q9Shape9T307)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T302OK,q9Shape9T307OK⟩

private def q9Shape9T297 : Tree := .split 5 q9Shape9T298 q9Shape9T301
private theorem q9Shape9T297OK : fastTreeOK (forms 9) 1081360 790792 q9Shape9T297=true := by
  change (fastTreeOK (forms 9) 1081360 (790792 ||| 2^5) q9Shape9T298 &&
    fastTreeOK (forms 9) (1081360 ||| 2^5) 790792 q9Shape9T301)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T298OK,q9Shape9T301OK⟩

private def q9Shape9T285 : Tree := .split 4 q9Shape9T286 q9Shape9T297
private theorem q9Shape9T285OK : fastTreeOK (forms 9) 1081344 790792 q9Shape9T285=true := by
  change (fastTreeOK (forms 9) 1081344 (790792 ||| 2^4) q9Shape9T286 &&
    fastTreeOK (forms 9) (1081344 ||| 2^4) 790792 q9Shape9T297)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T286OK,q9Shape9T297OK⟩

private def q9Shape9T283 : Tree := .split 15 q9Shape9T284 q9Shape9T285
private theorem q9Shape9T283OK : fastTreeOK (forms 9) 1048576 790792 q9Shape9T283=true := by
  change (fastTreeOK (forms 9) 1048576 (790792 ||| 2^15) q9Shape9T284 &&
    fastTreeOK (forms 9) (1048576 ||| 2^15) 790792 q9Shape9T285)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T284OK,q9Shape9T285OK⟩

private def q9Shape9T314 : Tree := (.split 10 (.split 13 (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.split 13 (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 7))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape9T314OK : fastTreeOK (forms 9) 1052672 820024 q9Shape9T314=true := by decide

private def q9Shape9T316 : Tree := (.split 13 (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 2))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 4 8))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape9T316OK : fastTreeOK (forms 9) 1053184 820536 q9Shape9T316=true := by decide

private def q9Shape9T317 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 4 5 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 4 8)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 2))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 7))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 3 4 5))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape9T317OK : fastTreeOK (forms 9) 1054208 819512 q9Shape9T317=true := by decide

private def q9Shape9T315 : Tree := .split 10 q9Shape9T316 q9Shape9T317
private theorem q9Shape9T315OK : fastTreeOK (forms 9) 1053184 819512 q9Shape9T315=true := by
  change (fastTreeOK (forms 9) 1053184 (819512 ||| 2^10) q9Shape9T316 &&
    fastTreeOK (forms 9) (1053184 ||| 2^10) 819512 q9Shape9T317)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T316OK,q9Shape9T317OK⟩

private def q9Shape9T313 : Tree := .split 9 q9Shape9T314 q9Shape9T315
private theorem q9Shape9T313OK : fastTreeOK (forms 9) 1052672 819512 q9Shape9T313=true := by
  change (fastTreeOK (forms 9) 1052672 (819512 ||| 2^9) q9Shape9T314 &&
    fastTreeOK (forms 9) (1052672 ||| 2^9) 819512 q9Shape9T315)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T314OK,q9Shape9T315OK⟩

private def q9Shape9T319 : Tree := (.split 10 (.split 13 (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 4 5 7))) (.tip (.cover 2 3 6 7)))) (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 0 2 4 7))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 4 5 8)))
private theorem q9Shape9T319OK : fastTreeOK (forms 9) 1052704 819992 q9Shape9T319=true := by decide

private def q9Shape9T320 : Tree := (.split 10 (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 3 4 7))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape9T320OK : fastTreeOK (forms 9) 1053216 819480 q9Shape9T320=true := by decide

private def q9Shape9T318 : Tree := .split 9 q9Shape9T319 q9Shape9T320
private theorem q9Shape9T318OK : fastTreeOK (forms 9) 1052704 819480 q9Shape9T318=true := by
  change (fastTreeOK (forms 9) 1052704 (819480 ||| 2^9) q9Shape9T319 &&
    fastTreeOK (forms 9) (1052704 ||| 2^9) 819480 q9Shape9T320)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T319OK,q9Shape9T320OK⟩

private def q9Shape9T312 : Tree := .split 5 q9Shape9T313 q9Shape9T318
private theorem q9Shape9T312OK : fastTreeOK (forms 9) 1052672 819480 q9Shape9T312=true := by
  change (fastTreeOK (forms 9) 1052672 (819480 ||| 2^5) q9Shape9T313 &&
    fastTreeOK (forms 9) (1052672 ||| 2^5) 819480 q9Shape9T318)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T313OK,q9Shape9T318OK⟩

private def q9Shape9T323 : Tree := (.split 10 (.split 13 (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 4 5 7))) (.tip (.cover 2 3 6 8)))) (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 3 6 8)))) (.tip (.cover 0 2 4 8))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.split 13 (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape9T323OK : fastTreeOK (forms 9) 1052688 820008 q9Shape9T323=true := by decide

private def q9Shape9T324 : Tree := (.split 10 (.tip (.cover 0 4 5 7)) (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 3 4 7))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 4 8))) (.tip (.cover 2 5 6 8)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape9T324OK : fastTreeOK (forms 9) 1053200 819496 q9Shape9T324=true := by decide

private def q9Shape9T322 : Tree := .split 9 q9Shape9T323 q9Shape9T324
private theorem q9Shape9T322OK : fastTreeOK (forms 9) 1052688 819496 q9Shape9T322=true := by
  change (fastTreeOK (forms 9) 1052688 (819496 ||| 2^9) q9Shape9T323 &&
    fastTreeOK (forms 9) (1052688 ||| 2^9) 819496 q9Shape9T324)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T323OK,q9Shape9T324OK⟩

private def q9Shape9T330 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 4 5 7))) (.tip (.cover 2 3 6 8)))) (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 3 6 8)))) (.tip (.cover 0 2 4 8))))
private theorem q9Shape9T330OK : fastTreeOK (forms 9) 1052720 911112 q9Shape9T330=true := by decide

private def q9Shape9T331 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 4 5 8))) (.tip (.cover 2 3 6 7)))) (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 0 2 4 7))) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 7 8 (some 3) (some 3)))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 4 5))))
private theorem q9Shape9T331OK : fastTreeOK (forms 9) 1118256 845576 q9Shape9T331=true := by decide

private def q9Shape9T329 : Tree := .split 16 q9Shape9T330 q9Shape9T331
private theorem q9Shape9T329OK : fastTreeOK (forms 9) 1052720 845576 q9Shape9T329=true := by
  change (fastTreeOK (forms 9) 1052720 (845576 ||| 2^16) q9Shape9T330 &&
    fastTreeOK (forms 9) (1052720 ||| 2^16) 845576 q9Shape9T331)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T330OK,q9Shape9T331OK⟩

private def q9Shape9T332 : Tree := (.tip (.cover 0 1 4 7))
private theorem q9Shape9T332OK : fastTreeOK (forms 9) 1069104 829192 q9Shape9T332=true := by decide

private def q9Shape9T328 : Tree := .split 14 q9Shape9T329 q9Shape9T332
private theorem q9Shape9T328OK : fastTreeOK (forms 9) 1052720 829192 q9Shape9T328=true := by
  change (fastTreeOK (forms 9) 1052720 (829192 ||| 2^14) q9Shape9T329 &&
    fastTreeOK (forms 9) (1052720 ||| 2^14) 829192 q9Shape9T332)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T329OK,q9Shape9T332OK⟩

private def q9Shape9T333 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape9T333OK : fastTreeOK (forms 9) 1060912 821000 q9Shape9T333=true := by decide

private def q9Shape9T327 : Tree := .split 13 q9Shape9T328 q9Shape9T333
private theorem q9Shape9T327OK : fastTreeOK (forms 9) 1052720 821000 q9Shape9T327=true := by
  change (fastTreeOK (forms 9) 1052720 (821000 ||| 2^13) q9Shape9T328 &&
    fastTreeOK (forms 9) (1052720 ||| 2^13) 821000 q9Shape9T333)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T328OK,q9Shape9T333OK⟩

private def q9Shape9T334 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 3 4 7))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 4 7))) (.tip (.cover 2 5 6 8)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape9T334OK : fastTreeOK (forms 9) 1053744 819976 q9Shape9T334=true := by decide

private def q9Shape9T326 : Tree := .split 10 q9Shape9T327 q9Shape9T334
private theorem q9Shape9T326OK : fastTreeOK (forms 9) 1052720 819976 q9Shape9T326=true := by
  change (fastTreeOK (forms 9) 1052720 (819976 ||| 2^10) q9Shape9T327 &&
    fastTreeOK (forms 9) (1052720 ||| 2^10) 819976 q9Shape9T334)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T327OK,q9Shape9T334OK⟩

private def q9Shape9T336 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.tip (.drop 7 8 (some 6) (some 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 3 4 8))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape9T336OK : fastTreeOK (forms 9) 1053232 820488 q9Shape9T336=true := by decide

private def q9Shape9T337 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6))) (.tip (.cover 0 2 3 4))) (.tip (.cover 2 3 5 6)))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 4 7))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape9T337OK : fastTreeOK (forms 9) 1054256 819464 q9Shape9T337=true := by decide

private def q9Shape9T335 : Tree := .split 10 q9Shape9T336 q9Shape9T337
private theorem q9Shape9T335OK : fastTreeOK (forms 9) 1053232 819464 q9Shape9T335=true := by
  change (fastTreeOK (forms 9) 1053232 (819464 ||| 2^10) q9Shape9T336 &&
    fastTreeOK (forms 9) (1053232 ||| 2^10) 819464 q9Shape9T337)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T336OK,q9Shape9T337OK⟩

private def q9Shape9T325 : Tree := .split 9 q9Shape9T326 q9Shape9T335
private theorem q9Shape9T325OK : fastTreeOK (forms 9) 1052720 819464 q9Shape9T325=true := by
  change (fastTreeOK (forms 9) 1052720 (819464 ||| 2^9) q9Shape9T326 &&
    fastTreeOK (forms 9) (1052720 ||| 2^9) 819464 q9Shape9T335)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T326OK,q9Shape9T335OK⟩

private def q9Shape9T321 : Tree := .split 5 q9Shape9T322 q9Shape9T325
private theorem q9Shape9T321OK : fastTreeOK (forms 9) 1052688 819464 q9Shape9T321=true := by
  change (fastTreeOK (forms 9) 1052688 (819464 ||| 2^5) q9Shape9T322 &&
    fastTreeOK (forms 9) (1052688 ||| 2^5) 819464 q9Shape9T325)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T322OK,q9Shape9T325OK⟩

private def q9Shape9T311 : Tree := .split 4 q9Shape9T312 q9Shape9T321
private theorem q9Shape9T311OK : fastTreeOK (forms 9) 1052672 819464 q9Shape9T311=true := by
  change (fastTreeOK (forms 9) 1052672 (819464 ||| 2^4) q9Shape9T312 &&
    fastTreeOK (forms 9) (1052672 ||| 2^4) 819464 q9Shape9T321)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T312OK,q9Shape9T321OK⟩

private def q9Shape9T341 : Tree := (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 1 4 8))) (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 1 4 8))))
private theorem q9Shape9T341OK : fastTreeOK (forms 9) 1085440 787256 q9Shape9T341=true := by decide

private def q9Shape9T342 : Tree := (.split 10 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 5 6 (some 0) (some 2))))) (.tip (.cover 2 3 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 7))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 6 (some 0) (some 2)))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 0 3 6 7))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))))
private theorem q9Shape9T342OK : fastTreeOK (forms 9) 1085952 786744 q9Shape9T342=true := by decide

private def q9Shape9T340 : Tree := .split 9 q9Shape9T341 q9Shape9T342
private theorem q9Shape9T340OK : fastTreeOK (forms 9) 1085440 786744 q9Shape9T340=true := by
  change (fastTreeOK (forms 9) 1085440 (786744 ||| 2^9) q9Shape9T341 &&
    fastTreeOK (forms 9) (1085440 ||| 2^9) 786744 q9Shape9T342)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T341OK,q9Shape9T342OK⟩

private def q9Shape9T343 : Tree := (.split 9 (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 4 5 8))) (.tip (.cover 0 2 6 7)))
private theorem q9Shape9T343OK : fastTreeOK (forms 9) 1085472 786712 q9Shape9T343=true := by decide

private def q9Shape9T339 : Tree := .split 5 q9Shape9T340 q9Shape9T343
private theorem q9Shape9T339OK : fastTreeOK (forms 9) 1085440 786712 q9Shape9T339=true := by
  change (fastTreeOK (forms 9) 1085440 (786712 ||| 2^5) q9Shape9T340 &&
    fastTreeOK (forms 9) (1085440 ||| 2^5) 786712 q9Shape9T343)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T340OK,q9Shape9T343OK⟩

private def q9Shape9T345 : Tree := (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 1 6 7 8)))
private theorem q9Shape9T345OK : fastTreeOK (forms 9) 1085456 786728 q9Shape9T345=true := by decide

private def q9Shape9T346 : Tree := (.split 9 (.split 10 (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 7)))) (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 5 6 (some 0) (some 3))))) (.tip (.cover 2 3 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 7))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 6 (some 0) (some 3)))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 2 3 6 7)))) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 2 6 7)))
private theorem q9Shape9T346OK : fastTreeOK (forms 9) 1085488 786696 q9Shape9T346=true := by decide

private def q9Shape9T344 : Tree := .split 5 q9Shape9T345 q9Shape9T346
private theorem q9Shape9T344OK : fastTreeOK (forms 9) 1085456 786696 q9Shape9T344=true := by
  change (fastTreeOK (forms 9) 1085456 (786696 ||| 2^5) q9Shape9T345 &&
    fastTreeOK (forms 9) (1085456 ||| 2^5) 786696 q9Shape9T346)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T345OK,q9Shape9T346OK⟩

private def q9Shape9T338 : Tree := .split 4 q9Shape9T339 q9Shape9T344
private theorem q9Shape9T338OK : fastTreeOK (forms 9) 1085440 786696 q9Shape9T338=true := by
  change (fastTreeOK (forms 9) 1085440 (786696 ||| 2^4) q9Shape9T339 &&
    fastTreeOK (forms 9) (1085440 ||| 2^4) 786696 q9Shape9T344)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T339OK,q9Shape9T344OK⟩

private def q9Shape9T310 : Tree := .split 15 q9Shape9T311 q9Shape9T338
private theorem q9Shape9T310OK : fastTreeOK (forms 9) 1052672 786696 q9Shape9T310=true := by
  change (fastTreeOK (forms 9) 1052672 (786696 ||| 2^15) q9Shape9T311 &&
    fastTreeOK (forms 9) (1052672 ||| 2^15) 786696 q9Shape9T338)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T311OK,q9Shape9T338OK⟩

private def q9Shape9T282 : Tree := .split 12 q9Shape9T283 q9Shape9T310
private theorem q9Shape9T282OK : fastTreeOK (forms 9) 1048576 786696 q9Shape9T282=true := by
  change (fastTreeOK (forms 9) 1048576 (786696 ||| 2^12) q9Shape9T283 &&
    fastTreeOK (forms 9) (1048576 ||| 2^12) 786696 q9Shape9T310)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T283OK,q9Shape9T310OK⟩

private def q9Shape9T354 : Tree := (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 7))))))
private theorem q9Shape9T354OK : fastTreeOK (forms 9) 1048832 833080 q9Shape9T354=true := by decide

private def q9Shape9T355 : Tree := (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 2))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 4 8))))) (.split 16 (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.tip (.cover 0 3 5 7))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 3 4 8)))) (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 2))) (.tip (.cover 0 3 5 8))) (.tip (.cover 0 3 4 7))) (.tip (.cover 0 3 4 7))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 3 4 5))) (.tip (.cover 0 3 4 5))) (.tip (.cover 2 4 5 6))))))
private theorem q9Shape9T355OK : fastTreeOK (forms 9) 1057024 824888 q9Shape9T355=true := by decide

private def q9Shape9T353 : Tree := .split 13 q9Shape9T354 q9Shape9T355
private theorem q9Shape9T353OK : fastTreeOK (forms 9) 1048832 824888 q9Shape9T353=true := by
  change (fastTreeOK (forms 9) 1048832 (824888 ||| 2^13) q9Shape9T354 &&
    fastTreeOK (forms 9) (1048832 ||| 2^13) 824888 q9Shape9T355)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T354OK,q9Shape9T355OK⟩

private def q9Shape9T356 : Tree := (.tip (.cover 0 1 3 7))
private theorem q9Shape9T356OK : fastTreeOK (forms 9) 1049856 823864 q9Shape9T356=true := by decide

private def q9Shape9T352 : Tree := .split 10 q9Shape9T353 q9Shape9T356
private theorem q9Shape9T352OK : fastTreeOK (forms 9) 1048832 823864 q9Shape9T352=true := by
  change (fastTreeOK (forms 9) 1048832 (823864 ||| 2^10) q9Shape9T353 &&
    fastTreeOK (forms 9) (1048832 ||| 2^10) 823864 q9Shape9T356)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T353OK,q9Shape9T356OK⟩

private def q9Shape9T357 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T357OK : fastTreeOK (forms 9) 1049344 823352 q9Shape9T357=true := by decide

private def q9Shape9T351 : Tree := .split 9 q9Shape9T352 q9Shape9T357
private theorem q9Shape9T351OK : fastTreeOK (forms 9) 1048832 823352 q9Shape9T351=true := by
  change (fastTreeOK (forms 9) 1048832 (823352 ||| 2^9) q9Shape9T352 &&
    fastTreeOK (forms 9) (1048832 ||| 2^9) 823352 q9Shape9T357)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T352OK,q9Shape9T357OK⟩

private def q9Shape9T361 : Tree := (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 2 4 6 7)))) (.tip (.cover 0 2 3 7))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 2 3 7)))))) (.tip (.cover 0 3 5 8)))
private theorem q9Shape9T361OK : fastTreeOK (forms 9) 1048864 833048 q9Shape9T361=true := by decide

private def q9Shape9T362 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 2 3 7)))) (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T362OK : fastTreeOK (forms 9) 1057056 824856 q9Shape9T362=true := by decide

private def q9Shape9T360 : Tree := .split 13 q9Shape9T361 q9Shape9T362
private theorem q9Shape9T360OK : fastTreeOK (forms 9) 1048864 824856 q9Shape9T360=true := by
  change (fastTreeOK (forms 9) 1048864 (824856 ||| 2^13) q9Shape9T361 &&
    fastTreeOK (forms 9) (1048864 ||| 2^13) 824856 q9Shape9T362)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T361OK,q9Shape9T362OK⟩

private def q9Shape9T363 : Tree := (.tip (.cover 0 1 3 7))
private theorem q9Shape9T363OK : fastTreeOK (forms 9) 1049888 823832 q9Shape9T363=true := by decide

private def q9Shape9T359 : Tree := .split 10 q9Shape9T360 q9Shape9T363
private theorem q9Shape9T359OK : fastTreeOK (forms 9) 1048864 823832 q9Shape9T359=true := by
  change (fastTreeOK (forms 9) 1048864 (823832 ||| 2^10) q9Shape9T360 &&
    fastTreeOK (forms 9) (1048864 ||| 2^10) 823832 q9Shape9T363)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T360OK,q9Shape9T363OK⟩

private def q9Shape9T364 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T364OK : fastTreeOK (forms 9) 1049376 823320 q9Shape9T364=true := by decide

private def q9Shape9T358 : Tree := .split 9 q9Shape9T359 q9Shape9T364
private theorem q9Shape9T358OK : fastTreeOK (forms 9) 1048864 823320 q9Shape9T358=true := by
  change (fastTreeOK (forms 9) 1048864 (823320 ||| 2^9) q9Shape9T359 &&
    fastTreeOK (forms 9) (1048864 ||| 2^9) 823320 q9Shape9T364)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T359OK,q9Shape9T364OK⟩

private def q9Shape9T350 : Tree := .split 5 q9Shape9T351 q9Shape9T358
private theorem q9Shape9T350OK : fastTreeOK (forms 9) 1048832 823320 q9Shape9T350=true := by
  change (fastTreeOK (forms 9) 1048832 (823320 ||| 2^5) q9Shape9T351 &&
    fastTreeOK (forms 9) (1048832 ||| 2^5) 823320 q9Shape9T358)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T351OK,q9Shape9T358OK⟩

private def q9Shape9T369 : Tree := (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 7 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 6)))) (.tip (.cover 2 4 6 8)))) (.tip (.cover 0 2 3 8))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 3 8)))))) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 4 7))))
private theorem q9Shape9T369OK : fastTreeOK (forms 9) 1048848 833064 q9Shape9T369=true := by decide

private def q9Shape9T370 : Tree := (.split 14 (.tip (.cover 0 3 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 6)))) (.tip (.cover 4 5 6 7))) (.tip (.cover 0 2 3 8)))) (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 5 6 8)))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 4 7))))
private theorem q9Shape9T370OK : fastTreeOK (forms 9) 1057040 824872 q9Shape9T370=true := by decide

private def q9Shape9T368 : Tree := .split 13 q9Shape9T369 q9Shape9T370
private theorem q9Shape9T368OK : fastTreeOK (forms 9) 1048848 824872 q9Shape9T368=true := by
  change (fastTreeOK (forms 9) 1048848 (824872 ||| 2^13) q9Shape9T369 &&
    fastTreeOK (forms 9) (1048848 ||| 2^13) 824872 q9Shape9T370)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T369OK,q9Shape9T370OK⟩

private def q9Shape9T371 : Tree := (.tip (.cover 0 1 3 7))
private theorem q9Shape9T371OK : fastTreeOK (forms 9) 1049872 823848 q9Shape9T371=true := by decide

private def q9Shape9T367 : Tree := .split 10 q9Shape9T368 q9Shape9T371
private theorem q9Shape9T367OK : fastTreeOK (forms 9) 1048848 823848 q9Shape9T367=true := by
  change (fastTreeOK (forms 9) 1048848 (823848 ||| 2^10) q9Shape9T368 &&
    fastTreeOK (forms 9) (1048848 ||| 2^10) 823848 q9Shape9T371)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T368OK,q9Shape9T371OK⟩

private def q9Shape9T372 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T372OK : fastTreeOK (forms 9) 1049360 823336 q9Shape9T372=true := by decide

private def q9Shape9T366 : Tree := .split 9 q9Shape9T367 q9Shape9T372
private theorem q9Shape9T366OK : fastTreeOK (forms 9) 1048848 823336 q9Shape9T366=true := by
  change (fastTreeOK (forms 9) 1048848 (823336 ||| 2^9) q9Shape9T367 &&
    fastTreeOK (forms 9) (1048848 ||| 2^9) 823336 q9Shape9T372)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T367OK,q9Shape9T372OK⟩

private def q9Shape9T378 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 4 5 6 7))) (.tip (.cover 2 4 6 8)))) (.tip (.cover 0 2 3 8))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 4 6 8))) (.tip (.cover 0 2 3 8)))))
private theorem q9Shape9T378OK : fastTreeOK (forms 9) 1048880 914952 q9Shape9T378=true := by decide

private def q9Shape9T379 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 4 5 6 8))) (.tip (.cover 2 4 6 7)))) (.tip (.cover 0 2 3 7))) (.split 1 (.split 2 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 2 3 7)))) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6)))) (.tip (.cover 0 2 3 5))) (.tip (.cover 2 4 5 6))))
private theorem q9Shape9T379OK : fastTreeOK (forms 9) 1114416 849416 q9Shape9T379=true := by decide

private def q9Shape9T377 : Tree := .split 16 q9Shape9T378 q9Shape9T379
private theorem q9Shape9T377OK : fastTreeOK (forms 9) 1048880 849416 q9Shape9T377=true := by
  change (fastTreeOK (forms 9) 1048880 (849416 ||| 2^16) q9Shape9T378 &&
    fastTreeOK (forms 9) (1048880 ||| 2^16) 849416 q9Shape9T379)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T378OK,q9Shape9T379OK⟩

private def q9Shape9T380 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 5 6 8))) (.tip (.cover 4 5 6 7))) (.tip (.cover 0 2 3 7)))) (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 5 6 8)))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 3 4 7)))
private theorem q9Shape9T380OK : fastTreeOK (forms 9) 1065264 833032 q9Shape9T380=true := by decide

private def q9Shape9T376 : Tree := .split 14 q9Shape9T377 q9Shape9T380
private theorem q9Shape9T376OK : fastTreeOK (forms 9) 1048880 833032 q9Shape9T376=true := by
  change (fastTreeOK (forms 9) 1048880 (833032 ||| 2^14) q9Shape9T377 &&
    fastTreeOK (forms 9) (1048880 ||| 2^14) 833032 q9Shape9T380)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T377OK,q9Shape9T380OK⟩

private def q9Shape9T381 : Tree := (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 5 6 7))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 2 3 7)))) (.split 1 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 3 4 8))) (.tip (.cover 0 2 3 7))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.tip (.cover 0 2 3 4))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 6))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 4)))) (.tip (.cover 2 4 5 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T381OK : fastTreeOK (forms 9) 1057072 824840 q9Shape9T381=true := by decide

private def q9Shape9T375 : Tree := .split 13 q9Shape9T376 q9Shape9T381
private theorem q9Shape9T375OK : fastTreeOK (forms 9) 1048880 824840 q9Shape9T375=true := by
  change (fastTreeOK (forms 9) 1048880 (824840 ||| 2^13) q9Shape9T376 &&
    fastTreeOK (forms 9) (1048880 ||| 2^13) 824840 q9Shape9T381)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T376OK,q9Shape9T381OK⟩

private def q9Shape9T382 : Tree := (.tip (.cover 0 1 3 7))
private theorem q9Shape9T382OK : fastTreeOK (forms 9) 1049904 823816 q9Shape9T382=true := by decide

private def q9Shape9T374 : Tree := .split 10 q9Shape9T375 q9Shape9T382
private theorem q9Shape9T374OK : fastTreeOK (forms 9) 1048880 823816 q9Shape9T374=true := by
  change (fastTreeOK (forms 9) 1048880 (823816 ||| 2^10) q9Shape9T375 &&
    fastTreeOK (forms 9) (1048880 ||| 2^10) 823816 q9Shape9T382)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T375OK,q9Shape9T382OK⟩

private def q9Shape9T383 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T383OK : fastTreeOK (forms 9) 1049392 823304 q9Shape9T383=true := by decide

private def q9Shape9T373 : Tree := .split 9 q9Shape9T374 q9Shape9T383
private theorem q9Shape9T373OK : fastTreeOK (forms 9) 1048880 823304 q9Shape9T373=true := by
  change (fastTreeOK (forms 9) 1048880 (823304 ||| 2^9) q9Shape9T374 &&
    fastTreeOK (forms 9) (1048880 ||| 2^9) 823304 q9Shape9T383)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T374OK,q9Shape9T383OK⟩

private def q9Shape9T365 : Tree := .split 5 q9Shape9T366 q9Shape9T373
private theorem q9Shape9T365OK : fastTreeOK (forms 9) 1048848 823304 q9Shape9T365=true := by
  change (fastTreeOK (forms 9) 1048848 (823304 ||| 2^5) q9Shape9T366 &&
    fastTreeOK (forms 9) (1048848 ||| 2^5) 823304 q9Shape9T373)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T366OK,q9Shape9T373OK⟩

private def q9Shape9T349 : Tree := .split 4 q9Shape9T350 q9Shape9T365
private theorem q9Shape9T349OK : fastTreeOK (forms 9) 1048832 823304 q9Shape9T349=true := by
  change (fastTreeOK (forms 9) 1048832 (823304 ||| 2^4) q9Shape9T350 &&
    fastTreeOK (forms 9) (1048832 ||| 2^4) 823304 q9Shape9T365)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T350OK,q9Shape9T365OK⟩

private def q9Shape9T386 : Tree := (.split 9 (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.split 14 (.tip (.cover 0 1 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 7)))) (.tip (.cover 2 4 6 7)))) (.tip (.cover 0 4 6 7))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 2) (some 7)))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 8 (some 3) (some 7)))) (.tip (.drop 6 8 (some 2) (some 7))))) (.tip (.cover 2 4 6 7))) (.tip (.cover 3 4 5 7)))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape9T386OK : fastTreeOK (forms 9) 1081600 790584 q9Shape9T386=true := by decide

private def q9Shape9T387 : Tree := (.split 9 (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape9T387OK : fastTreeOK (forms 9) 1081632 790552 q9Shape9T387=true := by decide

private def q9Shape9T385 : Tree := .split 5 q9Shape9T386 q9Shape9T387
private theorem q9Shape9T385OK : fastTreeOK (forms 9) 1081600 790552 q9Shape9T385=true := by
  change (fastTreeOK (forms 9) 1081600 (790552 ||| 2^5) q9Shape9T386 &&
    fastTreeOK (forms 9) (1081600 ||| 2^5) 790552 q9Shape9T387)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T386OK,q9Shape9T387OK⟩

private def q9Shape9T389 : Tree := (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 2 6 8))) (.tip (.cover 1 6 7 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape9T389OK : fastTreeOK (forms 9) 1081616 790568 q9Shape9T389=true := by decide

private def q9Shape9T392 : Tree := (.split 13 (.split 14 (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 7)))) (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 5 6 (some 0) (some 4))))) (.tip (.cover 2 4 6 7)))) (.tip (.cover 0 2 6 7))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.unordered 3 5 1)))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 5 8 (some 2) (some 7)))) (.tip (.cover 0 2 3 7)))) (.tip (.cover 2 4 6 7))) (.tip (.cover 0 2 5 7)))) (.tip (.cover 0 1 5 7))) (.tip (.cover 0 1 5 8))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 2 6 7)))
private theorem q9Shape9T392OK : fastTreeOK (forms 9) 1081648 792072 q9Shape9T392=true := by decide

private def q9Shape9T393 : Tree := (.tip (.cover 0 1 3 7))
private theorem q9Shape9T393OK : fastTreeOK (forms 9) 1082672 791048 q9Shape9T393=true := by decide

private def q9Shape9T391 : Tree := .split 10 q9Shape9T392 q9Shape9T393
private theorem q9Shape9T391OK : fastTreeOK (forms 9) 1081648 791048 q9Shape9T391=true := by
  change (fastTreeOK (forms 9) 1081648 (791048 ||| 2^10) q9Shape9T392 &&
    fastTreeOK (forms 9) (1081648 ||| 2^10) 791048 q9Shape9T393)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T392OK,q9Shape9T393OK⟩

private def q9Shape9T394 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T394OK : fastTreeOK (forms 9) 1082160 790536 q9Shape9T394=true := by decide

private def q9Shape9T390 : Tree := .split 9 q9Shape9T391 q9Shape9T394
private theorem q9Shape9T390OK : fastTreeOK (forms 9) 1081648 790536 q9Shape9T390=true := by
  change (fastTreeOK (forms 9) 1081648 (790536 ||| 2^9) q9Shape9T391 &&
    fastTreeOK (forms 9) (1081648 ||| 2^9) 790536 q9Shape9T394)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T391OK,q9Shape9T394OK⟩

private def q9Shape9T388 : Tree := .split 5 q9Shape9T389 q9Shape9T390
private theorem q9Shape9T388OK : fastTreeOK (forms 9) 1081616 790536 q9Shape9T388=true := by
  change (fastTreeOK (forms 9) 1081616 (790536 ||| 2^5) q9Shape9T389 &&
    fastTreeOK (forms 9) (1081616 ||| 2^5) 790536 q9Shape9T390)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T389OK,q9Shape9T390OK⟩

private def q9Shape9T384 : Tree := .split 4 q9Shape9T385 q9Shape9T388
private theorem q9Shape9T384OK : fastTreeOK (forms 9) 1081600 790536 q9Shape9T384=true := by
  change (fastTreeOK (forms 9) 1081600 (790536 ||| 2^4) q9Shape9T385 &&
    fastTreeOK (forms 9) (1081600 ||| 2^4) 790536 q9Shape9T388)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T385OK,q9Shape9T388OK⟩

private def q9Shape9T348 : Tree := .split 15 q9Shape9T349 q9Shape9T384
private theorem q9Shape9T348OK : fastTreeOK (forms 9) 1048832 790536 q9Shape9T348=true := by
  change (fastTreeOK (forms 9) 1048832 (790536 ||| 2^15) q9Shape9T349 &&
    fastTreeOK (forms 9) (1048832 ||| 2^15) 790536 q9Shape9T384)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T349OK,q9Shape9T384OK⟩

private def q9Shape9T398 : Tree := (.split 9 (.split 10 (.split 13 (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 7 8 (some 2) (some 2))) (.tip (.cover 0 5 6 7))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 5 6 7))) (.tip (.drop 6 8 (some 2) (some 7)))) (.tip (.cover 3 4 5 7)))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 5 8 (some 3) (some 7))))) (.tip (.drop 6 8 (some 2) (some 7)))) (.tip (.cover 3 4 5 7))) (.tip (.cover 2 5 6 7)))))) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape9T398OK : fastTreeOK (forms 9) 1052928 819256 q9Shape9T398=true := by decide

private def q9Shape9T399 : Tree := (.split 9 (.split 10 (.split 13 (.tip (.cover 0 5 6 8)) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape9T399OK : fastTreeOK (forms 9) 1052960 819224 q9Shape9T399=true := by decide

private def q9Shape9T397 : Tree := .split 5 q9Shape9T398 q9Shape9T399
private theorem q9Shape9T397OK : fastTreeOK (forms 9) 1052928 819224 q9Shape9T397=true := by
  change (fastTreeOK (forms 9) 1052928 (819224 ||| 2^5) q9Shape9T398 &&
    fastTreeOK (forms 9) (1052928 ||| 2^5) 819224 q9Shape9T399)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T398OK,q9Shape9T399OK⟩

private def q9Shape9T401 : Tree := (.split 9 (.split 10 (.split 13 (.split 14 (.tip (.cover 0 5 6 7)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8)))
private theorem q9Shape9T401OK : fastTreeOK (forms 9) 1052944 819240 q9Shape9T401=true := by decide

private def q9Shape9T406 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 7)))) (.tip (.cover 0 2 6 7))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 7)))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 6 (some 0) (some 5)))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 2 3 7)))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 4 8 (some 2) (some 7))))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.unordered 3 4 1))) (.tip (.cover 0 2 3 7)))) (.tip (.cover 0 2 4 7))) (.tip (.cover 2 5 6 7)))) (.tip (.cover 0 2 6 8))) (.tip (.cover 0 2 6 7)))
private theorem q9Shape9T406OK : fastTreeOK (forms 9) 1052976 845320 q9Shape9T406=true := by decide

private def q9Shape9T407 : Tree := (.tip (.cover 0 1 4 7))
private theorem q9Shape9T407OK : fastTreeOK (forms 9) 1069360 828936 q9Shape9T407=true := by decide

private def q9Shape9T405 : Tree := .split 14 q9Shape9T406 q9Shape9T407
private theorem q9Shape9T405OK : fastTreeOK (forms 9) 1052976 828936 q9Shape9T405=true := by
  change (fastTreeOK (forms 9) 1052976 (828936 ||| 2^14) q9Shape9T406 &&
    fastTreeOK (forms 9) (1052976 ||| 2^14) 828936 q9Shape9T407)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T406OK,q9Shape9T407OK⟩

private def q9Shape9T408 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape9T408OK : fastTreeOK (forms 9) 1061168 820744 q9Shape9T408=true := by decide

private def q9Shape9T404 : Tree := .split 13 q9Shape9T405 q9Shape9T408
private theorem q9Shape9T404OK : fastTreeOK (forms 9) 1052976 820744 q9Shape9T404=true := by
  change (fastTreeOK (forms 9) 1052976 (820744 ||| 2^13) q9Shape9T405 &&
    fastTreeOK (forms 9) (1052976 ||| 2^13) 820744 q9Shape9T408)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T405OK,q9Shape9T408OK⟩

private def q9Shape9T409 : Tree := (.tip (.cover 0 1 3 7))
private theorem q9Shape9T409OK : fastTreeOK (forms 9) 1054000 819720 q9Shape9T409=true := by decide

private def q9Shape9T403 : Tree := .split 10 q9Shape9T404 q9Shape9T409
private theorem q9Shape9T403OK : fastTreeOK (forms 9) 1052976 819720 q9Shape9T403=true := by
  change (fastTreeOK (forms 9) 1052976 (819720 ||| 2^10) q9Shape9T404 &&
    fastTreeOK (forms 9) (1052976 ||| 2^10) 819720 q9Shape9T409)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T404OK,q9Shape9T409OK⟩

private def q9Shape9T410 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T410OK : fastTreeOK (forms 9) 1053488 819208 q9Shape9T410=true := by decide

private def q9Shape9T402 : Tree := .split 9 q9Shape9T403 q9Shape9T410
private theorem q9Shape9T402OK : fastTreeOK (forms 9) 1052976 819208 q9Shape9T402=true := by
  change (fastTreeOK (forms 9) 1052976 (819208 ||| 2^9) q9Shape9T403 &&
    fastTreeOK (forms 9) (1052976 ||| 2^9) 819208 q9Shape9T410)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T403OK,q9Shape9T410OK⟩

private def q9Shape9T400 : Tree := .split 5 q9Shape9T401 q9Shape9T402
private theorem q9Shape9T400OK : fastTreeOK (forms 9) 1052944 819208 q9Shape9T400=true := by
  change (fastTreeOK (forms 9) 1052944 (819208 ||| 2^5) q9Shape9T401 &&
    fastTreeOK (forms 9) (1052944 ||| 2^5) 819208 q9Shape9T402)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T401OK,q9Shape9T402OK⟩

private def q9Shape9T396 : Tree := .split 4 q9Shape9T397 q9Shape9T400
private theorem q9Shape9T396OK : fastTreeOK (forms 9) 1052928 819208 q9Shape9T396=true := by
  change (fastTreeOK (forms 9) 1052928 (819208 ||| 2^4) q9Shape9T397 &&
    fastTreeOK (forms 9) (1052928 ||| 2^4) 819208 q9Shape9T400)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T397OK,q9Shape9T400OK⟩

private def q9Shape9T411 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))) (.tip (.cover 0 2 6 7))) (.tip (.cover 0 2 6 8)))
private theorem q9Shape9T411OK : fastTreeOK (forms 9) 1085696 786440 q9Shape9T411=true := by decide

private def q9Shape9T395 : Tree := .split 15 q9Shape9T396 q9Shape9T411
private theorem q9Shape9T395OK : fastTreeOK (forms 9) 1052928 786440 q9Shape9T395=true := by
  change (fastTreeOK (forms 9) 1052928 (786440 ||| 2^15) q9Shape9T396 &&
    fastTreeOK (forms 9) (1052928 ||| 2^15) 786440 q9Shape9T411)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T396OK,q9Shape9T411OK⟩

private def q9Shape9T347 : Tree := .split 12 q9Shape9T348 q9Shape9T395
private theorem q9Shape9T347OK : fastTreeOK (forms 9) 1048832 786440 q9Shape9T347=true := by
  change (fastTreeOK (forms 9) 1048832 (786440 ||| 2^12) q9Shape9T348 &&
    fastTreeOK (forms 9) (1048832 ||| 2^12) 786440 q9Shape9T395)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T348OK,q9Shape9T395OK⟩

private def q9Shape9T281 : Tree := .split 8 q9Shape9T282 q9Shape9T347
private theorem q9Shape9T281OK : fastTreeOK (forms 9) 1048576 786440 q9Shape9T281=true := by
  change (fastTreeOK (forms 9) 1048576 (786440 ||| 2^8) q9Shape9T282 &&
    fastTreeOK (forms 9) (1048576 ||| 2^8) 786440 q9Shape9T347)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T282OK,q9Shape9T347OK⟩

private def q9Shape9T420 : Tree := (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.drop 7 8 none none)) (.tip (.drop 7 8 (some 6) (some 6))))) (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 5 8))) (.tip (.cover 3 5 6 8)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 2 4 7))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 3 4 6 7))) (.tip (.cover 3 5 6 8))))) (.tip (.cover 0 2 4 7))))))
private theorem q9Shape9T420OK : fastTreeOK (forms 9) 1048584 833328 q9Shape9T420=true := by decide

private def q9Shape9T422 : Tree := (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 8))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 5 7))) (.tip (.cover 3 5 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 2 4 8))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 3 4 6 8))) (.tip (.cover 3 5 6 7))))) (.tip (.cover 0 2 4 8)))))
private theorem q9Shape9T422OK : fastTreeOK (forms 9) 1056776 841520 q9Shape9T422=true := by decide

private def q9Shape9T424 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 8))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 5 7))) (.tip (.cover 3 5 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 2 4 8))) (.split 6 (.split 7 (.tip (.drop 6 7 (some 3) (some 3))) (.tip (.cover 3 4 6 8))) (.tip (.cover 3 5 6 7))))) (.tip (.cover 0 2 4 8))))
private theorem q9Shape9T424OK : fastTreeOK (forms 9) 1073160 890672 q9Shape9T424=true := by decide

private def q9Shape9T425 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 5 8))) (.tip (.cover 3 5 6 8)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 2 4 7))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 3))) (.tip (.cover 3 4 6 7))) (.tip (.cover 3 5 6 8))))) (.tip (.cover 0 2 4 7))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 4 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))))
private theorem q9Shape9T425OK : fastTreeOK (forms 9) 1138696 825136 q9Shape9T425=true := by decide

private def q9Shape9T423 : Tree := .split 16 q9Shape9T424 q9Shape9T425
private theorem q9Shape9T423OK : fastTreeOK (forms 9) 1073160 825136 q9Shape9T423=true := by
  change (fastTreeOK (forms 9) 1073160 (825136 ||| 2^16) q9Shape9T424 &&
    fastTreeOK (forms 9) (1073160 ||| 2^16) 825136 q9Shape9T425)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T424OK,q9Shape9T425OK⟩

private def q9Shape9T421 : Tree := .split 14 q9Shape9T422 q9Shape9T423
private theorem q9Shape9T421OK : fastTreeOK (forms 9) 1056776 825136 q9Shape9T421=true := by
  change (fastTreeOK (forms 9) 1056776 (825136 ||| 2^14) q9Shape9T422 &&
    fastTreeOK (forms 9) (1056776 ||| 2^14) 825136 q9Shape9T423)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T422OK,q9Shape9T423OK⟩

private def q9Shape9T419 : Tree := .split 13 q9Shape9T420 q9Shape9T421
private theorem q9Shape9T419OK : fastTreeOK (forms 9) 1048584 825136 q9Shape9T419=true := by
  change (fastTreeOK (forms 9) 1048584 (825136 ||| 2^13) q9Shape9T420 &&
    fastTreeOK (forms 9) (1048584 ||| 2^13) 825136 q9Shape9T421)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T420OK,q9Shape9T421OK⟩

private def q9Shape9T427 : Tree := (.split 14 (.split 16 (.tip (.cover 0 1 6 8)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 4 5 6 8)))) (.tip (.cover 0 2 3 7))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 2 3 7))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.drop 3 7 (some 2) (some 6)))) (.tip (.cover 4 5 6 8)))) (.tip (.cover 0 2 3 7)))))) (.tip (.cover 0 2 5 8)))
private theorem q9Shape9T427OK : fastTreeOK (forms 9) 1049608 832304 q9Shape9T427=true := by decide

private def q9Shape9T428 : Tree := (.split 14 (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 3 7))) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 2)))) (.tip (.cover 0 2 3 7))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 2 3 7)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 3 7))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 3 7))))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T428OK : fastTreeOK (forms 9) 1057800 824112 q9Shape9T428=true := by decide

private def q9Shape9T426 : Tree := .split 13 q9Shape9T427 q9Shape9T428
private theorem q9Shape9T426OK : fastTreeOK (forms 9) 1049608 824112 q9Shape9T426=true := by
  change (fastTreeOK (forms 9) 1049608 (824112 ||| 2^13) q9Shape9T427 &&
    fastTreeOK (forms 9) (1049608 ||| 2^13) 824112 q9Shape9T428)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T427OK,q9Shape9T428OK⟩

private def q9Shape9T418 : Tree := .split 10 q9Shape9T419 q9Shape9T426
private theorem q9Shape9T418OK : fastTreeOK (forms 9) 1048584 824112 q9Shape9T418=true := by
  change (fastTreeOK (forms 9) 1048584 (824112 ||| 2^10) q9Shape9T419 &&
    fastTreeOK (forms 9) (1048584 ||| 2^10) 824112 q9Shape9T426)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T419OK,q9Shape9T426OK⟩

private def q9Shape9T431 : Tree := (.split 14 (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.cover 0 1 6 7)) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 8))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 6)))) (.tip (.cover 4 5 6 7)))) (.tip (.cover 0 2 3 8))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 2 3 8))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.drop 3 8 (some 2) (some 6)))) (.tip (.cover 4 5 6 7)))) (.tip (.cover 0 2 3 8)))))) (.split 16 (.split 17 (.tip (.drop 7 8 none none)) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 4 7))))
private theorem q9Shape9T431OK : fastTreeOK (forms 9) 1049096 832816 q9Shape9T431=true := by decide

private def q9Shape9T432 : Tree := (.split 14 (.tip (.cover 0 2 5 7)) (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 2) (some 6)))) (.tip (.cover 0 2 3 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 4 5 6 7))) (.tip (.cover 0 2 3 8)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 2 3 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 2 3 8))))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 4 7))))
private theorem q9Shape9T432OK : fastTreeOK (forms 9) 1057288 824624 q9Shape9T432=true := by decide

private def q9Shape9T430 : Tree := .split 13 q9Shape9T431 q9Shape9T432
private theorem q9Shape9T430OK : fastTreeOK (forms 9) 1049096 824624 q9Shape9T430=true := by
  change (fastTreeOK (forms 9) 1049096 (824624 ||| 2^13) q9Shape9T431 &&
    fastTreeOK (forms 9) (1049096 ||| 2^13) 824624 q9Shape9T432)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T431OK,q9Shape9T432OK⟩

private def q9Shape9T436 : Tree := (.split 17 (.tip (.drop 7 8 (some 6) (some 6))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 8))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 4 5 6 7))) (.tip (.cover 4 5 6 7)))) (.tip (.cover 0 2 3 8))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 8))) (.tip (.cover 0 2 3 8))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 4 6 8))) (.tip (.cover 4 5 6 7)))) (.tip (.cover 0 2 3 8)))))
private theorem q9Shape9T436OK : fastTreeOK (forms 9) 1050120 913712 q9Shape9T436=true := by decide

private def q9Shape9T437 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 4 5 6 8))) (.tip (.cover 4 5 6 8)))) (.tip (.cover 0 2 3 7))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 2 3 7))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 4 6 7))) (.tip (.cover 4 5 6 8)))) (.tip (.cover 0 2 3 7)))) (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.cover 0 2 3 5))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))))
private theorem q9Shape9T437OK : fastTreeOK (forms 9) 1115656 848176 q9Shape9T437=true := by decide

private def q9Shape9T435 : Tree := .split 16 q9Shape9T436 q9Shape9T437
private theorem q9Shape9T435OK : fastTreeOK (forms 9) 1050120 848176 q9Shape9T435=true := by
  change (fastTreeOK (forms 9) 1050120 (848176 ||| 2^16) q9Shape9T436 &&
    fastTreeOK (forms 9) (1050120 ||| 2^16) 848176 q9Shape9T437)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T436OK,q9Shape9T437OK⟩

private def q9Shape9T438 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 6) (some 2)))) (.tip (.cover 0 2 3 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 4 5 6 7))) (.tip (.cover 0 2 3 7)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 2 3 8))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 8))) (.tip (.cover 0 2 3 7))))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 4 7)))
private theorem q9Shape9T438OK : fastTreeOK (forms 9) 1066504 831792 q9Shape9T438=true := by decide

private def q9Shape9T434 : Tree := .split 14 q9Shape9T435 q9Shape9T438
private theorem q9Shape9T434OK : fastTreeOK (forms 9) 1050120 831792 q9Shape9T434=true := by
  change (fastTreeOK (forms 9) 1050120 (831792 ||| 2^14) q9Shape9T435 &&
    fastTreeOK (forms 9) (1050120 ||| 2^14) 831792 q9Shape9T438)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T435OK,q9Shape9T438OK⟩

private def q9Shape9T440 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.tip (.drop 7 8 (some 2) (some 6)))) (.tip (.cover 0 2 3 7))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 4 5 6 8))) (.tip (.cover 0 2 3 7)))) (.split 1 (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 3 7))) (.split 2 (.split 6 (.tip (.drop 7 8 (some 6) (some 6))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 3 7))))) (.tip (.cover 0 2 4 8))) (.tip (.cover 0 2 3 7)))
private theorem q9Shape9T440OK : fastTreeOK (forms 9) 1058312 839984 q9Shape9T440=true := by decide

private def q9Shape9T441 : Tree := (.split 16 (.split 17 (.split 0 (.split 1 (.split 2 (.split 6 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 4)))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 3 4 5 6))) (.tip (.cover 0 2 3 8))) (.tip (.cover 0 2 3 7)))
private theorem q9Shape9T441OK : fastTreeOK (forms 9) 1074696 823600 q9Shape9T441=true := by decide

private def q9Shape9T439 : Tree := .split 14 q9Shape9T440 q9Shape9T441
private theorem q9Shape9T439OK : fastTreeOK (forms 9) 1058312 823600 q9Shape9T439=true := by
  change (fastTreeOK (forms 9) 1058312 (823600 ||| 2^14) q9Shape9T440 &&
    fastTreeOK (forms 9) (1058312 ||| 2^14) 823600 q9Shape9T441)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T440OK,q9Shape9T441OK⟩

private def q9Shape9T433 : Tree := .split 13 q9Shape9T434 q9Shape9T439
private theorem q9Shape9T433OK : fastTreeOK (forms 9) 1050120 823600 q9Shape9T433=true := by
  change (fastTreeOK (forms 9) 1050120 (823600 ||| 2^13) q9Shape9T434 &&
    fastTreeOK (forms 9) (1050120 ||| 2^13) 823600 q9Shape9T439)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T434OK,q9Shape9T439OK⟩

private def q9Shape9T429 : Tree := .split 10 q9Shape9T430 q9Shape9T433
private theorem q9Shape9T429OK : fastTreeOK (forms 9) 1049096 823600 q9Shape9T429=true := by
  change (fastTreeOK (forms 9) 1049096 (823600 ||| 2^10) q9Shape9T430 &&
    fastTreeOK (forms 9) (1049096 ||| 2^10) 823600 q9Shape9T433)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T430OK,q9Shape9T433OK⟩

private def q9Shape9T417 : Tree := .split 9 q9Shape9T418 q9Shape9T429
private theorem q9Shape9T417OK : fastTreeOK (forms 9) 1048584 823600 q9Shape9T417=true := by
  change (fastTreeOK (forms 9) 1048584 (823600 ||| 2^9) q9Shape9T418 &&
    fastTreeOK (forms 9) (1048584 ||| 2^9) 823600 q9Shape9T429)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T418OK,q9Shape9T429OK⟩

private def q9Shape9T442 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape9T442OK : fastTreeOK (forms 9) 1048616 823568 q9Shape9T442=true := by decide

private def q9Shape9T416 : Tree := .split 5 q9Shape9T417 q9Shape9T442
private theorem q9Shape9T416OK : fastTreeOK (forms 9) 1048584 823568 q9Shape9T416=true := by
  change (fastTreeOK (forms 9) 1048584 (823568 ||| 2^5) q9Shape9T417 &&
    fastTreeOK (forms 9) (1048584 ||| 2^5) 823568 q9Shape9T442)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T417OK,q9Shape9T442OK⟩

private def q9Shape9T443 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape9T443OK : fastTreeOK (forms 9) 1048600 823552 q9Shape9T443=true := by decide

private def q9Shape9T415 : Tree := .split 4 q9Shape9T416 q9Shape9T443
private theorem q9Shape9T415OK : fastTreeOK (forms 9) 1048584 823552 q9Shape9T415=true := by
  change (fastTreeOK (forms 9) 1048584 (823552 ||| 2^4) q9Shape9T416 &&
    fastTreeOK (forms 9) (1048584 ||| 2^4) 823552 q9Shape9T443)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T416OK,q9Shape9T443OK⟩

private def q9Shape9T449 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape9T449OK : fastTreeOK (forms 9) 1081352 800560 q9Shape9T449=true := by decide

private def q9Shape9T451 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape9T451OK : fastTreeOK (forms 9) 1089544 808752 q9Shape9T451=true := by decide

private def q9Shape9T453 : Tree := (.split 17 (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 0 2 4 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 4 5 7))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 3) (some 3))) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 0 2 4 7))))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 2 4 7))) (.split 2 (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 8 (some 2) (some 7)))) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7))) (.tip (.cover 0 2 4 7))))) (.tip (.cover 0 1 5 7)))
private theorem q9Shape9T453OK : fastTreeOK (forms 9) 1105928 857904 q9Shape9T453=true := by decide

private def q9Shape9T454 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape9T454OK : fastTreeOK (forms 9) 1171464 792368 q9Shape9T454=true := by decide

private def q9Shape9T452 : Tree := .split 16 q9Shape9T453 q9Shape9T454
private theorem q9Shape9T452OK : fastTreeOK (forms 9) 1105928 792368 q9Shape9T452=true := by
  change (fastTreeOK (forms 9) 1105928 (792368 ||| 2^16) q9Shape9T453 &&
    fastTreeOK (forms 9) (1105928 ||| 2^16) 792368 q9Shape9T454)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T453OK,q9Shape9T454OK⟩

private def q9Shape9T450 : Tree := .split 14 q9Shape9T451 q9Shape9T452
private theorem q9Shape9T450OK : fastTreeOK (forms 9) 1089544 792368 q9Shape9T450=true := by
  change (fastTreeOK (forms 9) 1089544 (792368 ||| 2^14) q9Shape9T451 &&
    fastTreeOK (forms 9) (1089544 ||| 2^14) 792368 q9Shape9T452)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T451OK,q9Shape9T452OK⟩

private def q9Shape9T448 : Tree := .split 13 q9Shape9T449 q9Shape9T450
private theorem q9Shape9T448OK : fastTreeOK (forms 9) 1081352 792368 q9Shape9T448=true := by
  change (fastTreeOK (forms 9) 1081352 (792368 ||| 2^13) q9Shape9T449 &&
    fastTreeOK (forms 9) (1081352 ||| 2^13) 792368 q9Shape9T450)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T449OK,q9Shape9T450OK⟩

private def q9Shape9T455 : Tree := (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 3 6 7)))
private theorem q9Shape9T455OK : fastTreeOK (forms 9) 1082376 791344 q9Shape9T455=true := by decide

private def q9Shape9T447 : Tree := .split 10 q9Shape9T448 q9Shape9T455
private theorem q9Shape9T447OK : fastTreeOK (forms 9) 1081352 791344 q9Shape9T447=true := by
  change (fastTreeOK (forms 9) 1081352 (791344 ||| 2^10) q9Shape9T448 &&
    fastTreeOK (forms 9) (1081352 ||| 2^10) 791344 q9Shape9T455)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T448OK,q9Shape9T455OK⟩

private def q9Shape9T457 : Tree := (.split 13 (.split 14 (.tip (.cover 0 1 5 7)) (.tip (.cover 0 3 6 8))) (.tip (.cover 1 6 7 8)))
private theorem q9Shape9T457OK : fastTreeOK (forms 9) 1081864 791856 q9Shape9T457=true := by decide

private def q9Shape9T463 : Tree := (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 7))) (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 5 6 (some 0) (some 4))))) (.tip (.cover 0 2 3 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T463OK : fastTreeOK (forms 9) 1082888 1012017 q9Shape9T463=true := by decide

private def q9Shape9T464 : Tree := (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 3 4 6 7))) (.tip (.cover 0 3 5 7))) (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.unordered 2 5 1))) (.tip (.unordered 2 5 1))) (.tip (.cover 0 2 3 7)))) (.split 2 (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 5 8 (some 3) (some 7)))) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 2 3 5 7))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T464OK : fastTreeOK (forms 9) 1082889 1012016 q9Shape9T464=true := by decide

private def q9Shape9T462 : Tree := .split 0 q9Shape9T463 q9Shape9T464
private theorem q9Shape9T462OK : fastTreeOK (forms 9) 1082888 1012016 q9Shape9T462=true := by
  change (fastTreeOK (forms 9) 1082888 (1012016 ||| 2^0) q9Shape9T463 &&
    fastTreeOK (forms 9) (1082888 ||| 2^0) 1012016 q9Shape9T464)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T463OK,q9Shape9T464OK⟩

private def q9Shape9T465 : Tree := (.tip (.cover 0 1 5 7))
private theorem q9Shape9T465OK : fastTreeOK (forms 9) 1213960 880944 q9Shape9T465=true := by decide

private def q9Shape9T461 : Tree := .split 17 q9Shape9T462 q9Shape9T465
private theorem q9Shape9T461OK : fastTreeOK (forms 9) 1082888 880944 q9Shape9T461=true := by
  change (fastTreeOK (forms 9) 1082888 (880944 ||| 2^17) q9Shape9T462 &&
    fastTreeOK (forms 9) (1082888 ||| 2^17) 880944 q9Shape9T465)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T462OK,q9Shape9T465OK⟩

private def q9Shape9T466 : Tree := (.tip (.cover 0 1 5 8))
private theorem q9Shape9T466OK : fastTreeOK (forms 9) 1148424 815408 q9Shape9T466=true := by decide

private def q9Shape9T460 : Tree := .split 16 q9Shape9T461 q9Shape9T466
private theorem q9Shape9T460OK : fastTreeOK (forms 9) 1082888 815408 q9Shape9T460=true := by
  change (fastTreeOK (forms 9) 1082888 (815408 ||| 2^16) q9Shape9T461 &&
    fastTreeOK (forms 9) (1082888 ||| 2^16) 815408 q9Shape9T466)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T461OK,q9Shape9T466OK⟩

private def q9Shape9T467 : Tree := (.tip (.cover 0 3 6 8))
private theorem q9Shape9T467OK : fastTreeOK (forms 9) 1099272 799024 q9Shape9T467=true := by decide

private def q9Shape9T459 : Tree := .split 14 q9Shape9T460 q9Shape9T467
private theorem q9Shape9T459OK : fastTreeOK (forms 9) 1082888 799024 q9Shape9T459=true := by
  change (fastTreeOK (forms 9) 1082888 (799024 ||| 2^14) q9Shape9T460 &&
    fastTreeOK (forms 9) (1082888 ||| 2^14) 799024 q9Shape9T467)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T460OK,q9Shape9T467OK⟩

private def q9Shape9T468 : Tree := (.tip (.cover 0 3 6 7))
private theorem q9Shape9T468OK : fastTreeOK (forms 9) 1091080 790832 q9Shape9T468=true := by decide

private def q9Shape9T458 : Tree := .split 13 q9Shape9T459 q9Shape9T468
private theorem q9Shape9T458OK : fastTreeOK (forms 9) 1082888 790832 q9Shape9T458=true := by
  change (fastTreeOK (forms 9) 1082888 (790832 ||| 2^13) q9Shape9T459 &&
    fastTreeOK (forms 9) (1082888 ||| 2^13) 790832 q9Shape9T468)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T459OK,q9Shape9T468OK⟩

private def q9Shape9T456 : Tree := .split 10 q9Shape9T457 q9Shape9T458
private theorem q9Shape9T456OK : fastTreeOK (forms 9) 1081864 790832 q9Shape9T456=true := by
  change (fastTreeOK (forms 9) 1081864 (790832 ||| 2^10) q9Shape9T457 &&
    fastTreeOK (forms 9) (1081864 ||| 2^10) 790832 q9Shape9T458)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T457OK,q9Shape9T458OK⟩

private def q9Shape9T446 : Tree := .split 9 q9Shape9T447 q9Shape9T456
private theorem q9Shape9T446OK : fastTreeOK (forms 9) 1081352 790832 q9Shape9T446=true := by
  change (fastTreeOK (forms 9) 1081352 (790832 ||| 2^9) q9Shape9T447 &&
    fastTreeOK (forms 9) (1081352 ||| 2^9) 790832 q9Shape9T456)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T447OK,q9Shape9T456OK⟩

private def q9Shape9T469 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape9T469OK : fastTreeOK (forms 9) 1081384 790800 q9Shape9T469=true := by decide

private def q9Shape9T445 : Tree := .split 5 q9Shape9T446 q9Shape9T469
private theorem q9Shape9T445OK : fastTreeOK (forms 9) 1081352 790800 q9Shape9T445=true := by
  change (fastTreeOK (forms 9) 1081352 (790800 ||| 2^5) q9Shape9T446 &&
    fastTreeOK (forms 9) (1081352 ||| 2^5) 790800 q9Shape9T469)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T446OK,q9Shape9T469OK⟩

private def q9Shape9T470 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape9T470OK : fastTreeOK (forms 9) 1081368 790784 q9Shape9T470=true := by decide

private def q9Shape9T444 : Tree := .split 4 q9Shape9T445 q9Shape9T470
private theorem q9Shape9T444OK : fastTreeOK (forms 9) 1081352 790784 q9Shape9T444=true := by
  change (fastTreeOK (forms 9) 1081352 (790784 ||| 2^4) q9Shape9T445 &&
    fastTreeOK (forms 9) (1081352 ||| 2^4) 790784 q9Shape9T470)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T445OK,q9Shape9T470OK⟩

private def q9Shape9T414 : Tree := .split 15 q9Shape9T415 q9Shape9T444
private theorem q9Shape9T414OK : fastTreeOK (forms 9) 1048584 790784 q9Shape9T414=true := by
  change (fastTreeOK (forms 9) 1048584 (790784 ||| 2^15) q9Shape9T415 &&
    fastTreeOK (forms 9) (1048584 ||| 2^15) 790784 q9Shape9T444)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T415OK,q9Shape9T444OK⟩

private def q9Shape9T478 : Tree := (.split 16 (.tip (.drop 7 8 none none)) (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 4 5 7))) (.tip (.cover 3 5 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 0 4 5 7))) (.split 6 (.split 7 (.tip (.drop 7 8 (some 3) (some 3))) (.tip (.drop 6 8 (some 3) (some 7)))) (.tip (.cover 3 5 6 7))))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7))) (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 5 8 (some 2) (some 7)))) (.tip (.cover 2 4 5 7))) (.tip (.cover 2 4 5 7)))) (.tip (.cover 0 2 5 7))))))
private theorem q9Shape9T478OK : fastTreeOK (forms 9) 1052680 845616 q9Shape9T478=true := by decide

private def q9Shape9T479 : Tree := (.tip (.cover 0 1 4 7))
private theorem q9Shape9T479OK : fastTreeOK (forms 9) 1069064 829232 q9Shape9T479=true := by decide

private def q9Shape9T477 : Tree := .split 14 q9Shape9T478 q9Shape9T479
private theorem q9Shape9T477OK : fastTreeOK (forms 9) 1052680 829232 q9Shape9T477=true := by
  change (fastTreeOK (forms 9) 1052680 (829232 ||| 2^14) q9Shape9T478 &&
    fastTreeOK (forms 9) (1052680 ||| 2^14) 829232 q9Shape9T479)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T478OK,q9Shape9T479OK⟩

private def q9Shape9T480 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape9T480OK : fastTreeOK (forms 9) 1060872 821040 q9Shape9T480=true := by decide

private def q9Shape9T476 : Tree := .split 13 q9Shape9T477 q9Shape9T480
private theorem q9Shape9T476OK : fastTreeOK (forms 9) 1052680 821040 q9Shape9T476=true := by
  change (fastTreeOK (forms 9) 1052680 (821040 ||| 2^13) q9Shape9T477 &&
    fastTreeOK (forms 9) (1052680 ||| 2^13) 821040 q9Shape9T480)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T477OK,q9Shape9T480OK⟩

private def q9Shape9T481 : Tree := (.split 13 (.tip (.cover 0 5 6 8)) (.tip (.cover 0 1 4 8)))
private theorem q9Shape9T481OK : fastTreeOK (forms 9) 1053704 820016 q9Shape9T481=true := by decide

private def q9Shape9T475 : Tree := .split 10 q9Shape9T476 q9Shape9T481
private theorem q9Shape9T475OK : fastTreeOK (forms 9) 1052680 820016 q9Shape9T475=true := by
  change (fastTreeOK (forms 9) 1052680 (820016 ||| 2^10) q9Shape9T476 &&
    fastTreeOK (forms 9) (1052680 ||| 2^10) 820016 q9Shape9T481)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T476OK,q9Shape9T481OK⟩

private def q9Shape9T483 : Tree := (.split 13 (.split 14 (.tip (.cover 0 5 6 7)) (.tip (.cover 0 1 4 7))) (.tip (.cover 0 1 4 8)))
private theorem q9Shape9T483OK : fastTreeOK (forms 9) 1053192 820528 q9Shape9T483=true := by decide

private def q9Shape9T489 : Tree := (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 3 5 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 7))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 6 (some 0) (some 5)))) (.tip (.cover 0 2 3 7)))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T489OK : fastTreeOK (forms 9) 1054216 1040689 q9Shape9T489=true := by decide

private def q9Shape9T490 : Tree := (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 3 4 7))) (.tip (.cover 3 5 6 7))) (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 4 8 (some 3) (some 7)))) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 3 5 6 7)))) (.split 2 (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.unordered 2 4 1))) (.tip (.cover 0 2 3 7))) (.tip (.cover 3 5 6 7))) (.tip (.cover 0 2 3 7))))
private theorem q9Shape9T490OK : fastTreeOK (forms 9) 1054217 1040688 q9Shape9T490=true := by decide

private def q9Shape9T488 : Tree := .split 0 q9Shape9T489 q9Shape9T490
private theorem q9Shape9T488OK : fastTreeOK (forms 9) 1054216 1040688 q9Shape9T488=true := by
  change (fastTreeOK (forms 9) 1054216 (1040688 ||| 2^0) q9Shape9T489 &&
    fastTreeOK (forms 9) (1054216 ||| 2^0) 1040688 q9Shape9T490)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T489OK,q9Shape9T490OK⟩

private def q9Shape9T491 : Tree := (.tip (.cover 0 3 6 8))
private theorem q9Shape9T491OK : fastTreeOK (forms 9) 1185288 909616 q9Shape9T491=true := by decide

private def q9Shape9T487 : Tree := .split 17 q9Shape9T488 q9Shape9T491
private theorem q9Shape9T487OK : fastTreeOK (forms 9) 1054216 909616 q9Shape9T487=true := by
  change (fastTreeOK (forms 9) 1054216 (909616 ||| 2^17) q9Shape9T488 &&
    fastTreeOK (forms 9) (1054216 ||| 2^17) 909616 q9Shape9T491)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T488OK,q9Shape9T491OK⟩

private def q9Shape9T492 : Tree := (.tip (.cover 0 3 6 7))
private theorem q9Shape9T492OK : fastTreeOK (forms 9) 1119752 844080 q9Shape9T492=true := by decide

private def q9Shape9T486 : Tree := .split 16 q9Shape9T487 q9Shape9T492
private theorem q9Shape9T486OK : fastTreeOK (forms 9) 1054216 844080 q9Shape9T486=true := by
  change (fastTreeOK (forms 9) 1054216 (844080 ||| 2^16) q9Shape9T487 &&
    fastTreeOK (forms 9) (1054216 ||| 2^16) 844080 q9Shape9T492)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T487OK,q9Shape9T492OK⟩

private def q9Shape9T493 : Tree := (.tip (.cover 0 1 4 7))
private theorem q9Shape9T493OK : fastTreeOK (forms 9) 1070600 827696 q9Shape9T493=true := by decide

private def q9Shape9T485 : Tree := .split 14 q9Shape9T486 q9Shape9T493
private theorem q9Shape9T485OK : fastTreeOK (forms 9) 1054216 827696 q9Shape9T485=true := by
  change (fastTreeOK (forms 9) 1054216 (827696 ||| 2^14) q9Shape9T486 &&
    fastTreeOK (forms 9) (1054216 ||| 2^14) 827696 q9Shape9T493)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T486OK,q9Shape9T493OK⟩

private def q9Shape9T494 : Tree := (.tip (.cover 0 1 4 8))
private theorem q9Shape9T494OK : fastTreeOK (forms 9) 1062408 819504 q9Shape9T494=true := by decide

private def q9Shape9T484 : Tree := .split 13 q9Shape9T485 q9Shape9T494
private theorem q9Shape9T484OK : fastTreeOK (forms 9) 1054216 819504 q9Shape9T484=true := by
  change (fastTreeOK (forms 9) 1054216 (819504 ||| 2^13) q9Shape9T485 &&
    fastTreeOK (forms 9) (1054216 ||| 2^13) 819504 q9Shape9T494)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T485OK,q9Shape9T494OK⟩

private def q9Shape9T482 : Tree := .split 10 q9Shape9T483 q9Shape9T484
private theorem q9Shape9T482OK : fastTreeOK (forms 9) 1053192 819504 q9Shape9T482=true := by
  change (fastTreeOK (forms 9) 1053192 (819504 ||| 2^10) q9Shape9T483 &&
    fastTreeOK (forms 9) (1053192 ||| 2^10) 819504 q9Shape9T484)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T483OK,q9Shape9T484OK⟩

private def q9Shape9T474 : Tree := .split 9 q9Shape9T475 q9Shape9T482
private theorem q9Shape9T474OK : fastTreeOK (forms 9) 1052680 819504 q9Shape9T474=true := by
  change (fastTreeOK (forms 9) 1052680 (819504 ||| 2^9) q9Shape9T475 &&
    fastTreeOK (forms 9) (1052680 ||| 2^9) 819504 q9Shape9T482)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T475OK,q9Shape9T482OK⟩

private def q9Shape9T495 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape9T495OK : fastTreeOK (forms 9) 1052712 819472 q9Shape9T495=true := by decide

private def q9Shape9T473 : Tree := .split 5 q9Shape9T474 q9Shape9T495
private theorem q9Shape9T473OK : fastTreeOK (forms 9) 1052680 819472 q9Shape9T473=true := by
  change (fastTreeOK (forms 9) 1052680 (819472 ||| 2^5) q9Shape9T474 &&
    fastTreeOK (forms 9) (1052680 ||| 2^5) 819472 q9Shape9T495)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T474OK,q9Shape9T495OK⟩

private def q9Shape9T496 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape9T496OK : fastTreeOK (forms 9) 1052696 819456 q9Shape9T496=true := by decide

private def q9Shape9T472 : Tree := .split 4 q9Shape9T473 q9Shape9T496
private theorem q9Shape9T472OK : fastTreeOK (forms 9) 1052680 819456 q9Shape9T472=true := by
  change (fastTreeOK (forms 9) 1052680 (819456 ||| 2^4) q9Shape9T473 &&
    fastTreeOK (forms 9) (1052680 ||| 2^4) 819456 q9Shape9T496)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T473OK,q9Shape9T496OK⟩

private def q9Shape9T497 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 3 6 7))) (.tip (.cover 0 3 6 8))) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape9T497OK : fastTreeOK (forms 9) 1085448 786688 q9Shape9T497=true := by decide

private def q9Shape9T471 : Tree := .split 15 q9Shape9T472 q9Shape9T497
private theorem q9Shape9T471OK : fastTreeOK (forms 9) 1052680 786688 q9Shape9T471=true := by
  change (fastTreeOK (forms 9) 1052680 (786688 ||| 2^15) q9Shape9T472 &&
    fastTreeOK (forms 9) (1052680 ||| 2^15) 786688 q9Shape9T497)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T472OK,q9Shape9T497OK⟩

private def q9Shape9T413 : Tree := .split 12 q9Shape9T414 q9Shape9T471
private theorem q9Shape9T413OK : fastTreeOK (forms 9) 1048584 786688 q9Shape9T413=true := by
  change (fastTreeOK (forms 9) 1048584 (786688 ||| 2^12) q9Shape9T414 &&
    fastTreeOK (forms 9) (1048584 ||| 2^12) 786688 q9Shape9T471)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T414OK,q9Shape9T471OK⟩

private def q9Shape9T507 : Tree := (.tip (.drop 7 8 none none))
private theorem q9Shape9T507OK : fastTreeOK (forms 9) 1048840 914992 q9Shape9T507=true := by decide

private def q9Shape9T508 : Tree := (.split 17 (.tip (.drop 7 8 none none)) (.split 0 (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 4 5 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 2 3 5 7))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 7))) (.tip (.cover 4 5 6 7))) (.tip (.cover 2 3 5 7))))) (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.drop 3 6 (some 1) (some 4))))) (.tip (.cover 0 3 5 7))) (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 2 6 (some 1) (some 4)))) (.tip (.unordered 2 3 1))) (.tip (.cover 4 5 6 7)))) (.tip (.cover 0 2 5 7)))))
private theorem q9Shape9T508OK : fastTreeOK (forms 9) 1114376 849456 q9Shape9T508=true := by decide

private def q9Shape9T506 : Tree := .split 16 q9Shape9T507 q9Shape9T508
private theorem q9Shape9T506OK : fastTreeOK (forms 9) 1048840 849456 q9Shape9T506=true := by
  change (fastTreeOK (forms 9) 1048840 (849456 ||| 2^16) q9Shape9T507 &&
    fastTreeOK (forms 9) (1048840 ||| 2^16) 849456 q9Shape9T508)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T507OK,q9Shape9T508OK⟩

private def q9Shape9T509 : Tree := (.tip (.cover 0 5 6 8))
private theorem q9Shape9T509OK : fastTreeOK (forms 9) 1065224 833072 q9Shape9T509=true := by decide

private def q9Shape9T505 : Tree := .split 14 q9Shape9T506 q9Shape9T509
private theorem q9Shape9T505OK : fastTreeOK (forms 9) 1048840 833072 q9Shape9T505=true := by
  change (fastTreeOK (forms 9) 1048840 (833072 ||| 2^14) q9Shape9T506 &&
    fastTreeOK (forms 9) (1048840 ||| 2^14) 833072 q9Shape9T509)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T506OK,q9Shape9T509OK⟩

private def q9Shape9T511 : Tree := (.tip (.cover 0 5 6 7))
private theorem q9Shape9T511OK : fastTreeOK (forms 9) 1057032 841264 q9Shape9T511=true := by decide

private def q9Shape9T515 : Tree := (.split 1 (.split 2 (.tip (.drop 6 8 (some 2) (some 7))) (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 4 5 6 7)))) (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 4 5 6 7))) (.split 6 (.split 7 (.tip (.drop 6 8 (some 3) (some 7))) (.tip (.cover 2 3 4 7))) (.tip (.cover 4 5 6 7)))))
private theorem q9Shape9T515OK : fastTreeOK (forms 9) 1073416 1021489 q9Shape9T515=true := by decide

private def q9Shape9T516 : Tree := (.split 1 (.split 2 (.split 6 (.split 7 (.tip (.small 1)) (.tip (.cover 0 3 4 7))) (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 3 6 (some 1) (some 5)))) (.tip (.cover 0 3 4 7)))) (.tip (.cover 0 2 4 7))) (.split 2 (.split 6 (.split 7 (.split 11 (.tip (.small 1)) (.tip (.drop 2 6 (some 1) (some 5)))) (.tip (.drop 3 8 (some 2) (some 7)))) (.tip (.cover 4 5 6 7))) (.tip (.cover 0 2 4 7))))
private theorem q9Shape9T516OK : fastTreeOK (forms 9) 1073417 1021488 q9Shape9T516=true := by decide

private def q9Shape9T514 : Tree := .split 0 q9Shape9T515 q9Shape9T516
private theorem q9Shape9T514OK : fastTreeOK (forms 9) 1073416 1021488 q9Shape9T514=true := by
  change (fastTreeOK (forms 9) 1073416 (1021488 ||| 2^0) q9Shape9T515 &&
    fastTreeOK (forms 9) (1073416 ||| 2^0) 1021488 q9Shape9T516)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T515OK,q9Shape9T516OK⟩

private def q9Shape9T517 : Tree := (.tip (.cover 0 4 6 8))
private theorem q9Shape9T517OK : fastTreeOK (forms 9) 1204488 890416 q9Shape9T517=true := by decide

private def q9Shape9T513 : Tree := .split 17 q9Shape9T514 q9Shape9T517
private theorem q9Shape9T513OK : fastTreeOK (forms 9) 1073416 890416 q9Shape9T513=true := by
  change (fastTreeOK (forms 9) 1073416 (890416 ||| 2^17) q9Shape9T514 &&
    fastTreeOK (forms 9) (1073416 ||| 2^17) 890416 q9Shape9T517)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T514OK,q9Shape9T517OK⟩

private def q9Shape9T518 : Tree := (.tip (.cover 0 4 6 7))
private theorem q9Shape9T518OK : fastTreeOK (forms 9) 1138952 824880 q9Shape9T518=true := by decide

private def q9Shape9T512 : Tree := .split 16 q9Shape9T513 q9Shape9T518
private theorem q9Shape9T512OK : fastTreeOK (forms 9) 1073416 824880 q9Shape9T512=true := by
  change (fastTreeOK (forms 9) 1073416 (824880 ||| 2^16) q9Shape9T513 &&
    fastTreeOK (forms 9) (1073416 ||| 2^16) 824880 q9Shape9T518)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T513OK,q9Shape9T518OK⟩

private def q9Shape9T510 : Tree := .split 14 q9Shape9T511 q9Shape9T512
private theorem q9Shape9T510OK : fastTreeOK (forms 9) 1057032 824880 q9Shape9T510=true := by
  change (fastTreeOK (forms 9) 1057032 (824880 ||| 2^14) q9Shape9T511 &&
    fastTreeOK (forms 9) (1057032 ||| 2^14) 824880 q9Shape9T512)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T511OK,q9Shape9T512OK⟩

private def q9Shape9T504 : Tree := .split 13 q9Shape9T505 q9Shape9T510
private theorem q9Shape9T504OK : fastTreeOK (forms 9) 1048840 824880 q9Shape9T504=true := by
  change (fastTreeOK (forms 9) 1048840 (824880 ||| 2^13) q9Shape9T505 &&
    fastTreeOK (forms 9) (1048840 ||| 2^13) 824880 q9Shape9T510)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T505OK,q9Shape9T510OK⟩

private def q9Shape9T519 : Tree := (.tip (.cover 0 1 3 7))
private theorem q9Shape9T519OK : fastTreeOK (forms 9) 1049864 823856 q9Shape9T519=true := by decide

private def q9Shape9T503 : Tree := .split 10 q9Shape9T504 q9Shape9T519
private theorem q9Shape9T503OK : fastTreeOK (forms 9) 1048840 823856 q9Shape9T503=true := by
  change (fastTreeOK (forms 9) 1048840 (823856 ||| 2^10) q9Shape9T504 &&
    fastTreeOK (forms 9) (1048840 ||| 2^10) 823856 q9Shape9T519)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T504OK,q9Shape9T519OK⟩

private def q9Shape9T520 : Tree := (.tip (.cover 0 1 3 8))
private theorem q9Shape9T520OK : fastTreeOK (forms 9) 1049352 823344 q9Shape9T520=true := by decide

private def q9Shape9T502 : Tree := .split 9 q9Shape9T503 q9Shape9T520
private theorem q9Shape9T502OK : fastTreeOK (forms 9) 1048840 823344 q9Shape9T502=true := by
  change (fastTreeOK (forms 9) 1048840 (823344 ||| 2^9) q9Shape9T503 &&
    fastTreeOK (forms 9) (1048840 ||| 2^9) 823344 q9Shape9T520)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T503OK,q9Shape9T520OK⟩

private def q9Shape9T521 : Tree := (.tip (.cover 0 1 2 7))
private theorem q9Shape9T521OK : fastTreeOK (forms 9) 1048872 823312 q9Shape9T521=true := by decide

private def q9Shape9T501 : Tree := .split 5 q9Shape9T502 q9Shape9T521
private theorem q9Shape9T501OK : fastTreeOK (forms 9) 1048840 823312 q9Shape9T501=true := by
  change (fastTreeOK (forms 9) 1048840 (823312 ||| 2^5) q9Shape9T502 &&
    fastTreeOK (forms 9) (1048840 ||| 2^5) 823312 q9Shape9T521)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T502OK,q9Shape9T521OK⟩

private def q9Shape9T522 : Tree := (.tip (.cover 0 1 2 8))
private theorem q9Shape9T522OK : fastTreeOK (forms 9) 1048856 823296 q9Shape9T522=true := by decide

private def q9Shape9T500 : Tree := .split 4 q9Shape9T501 q9Shape9T522
private theorem q9Shape9T500OK : fastTreeOK (forms 9) 1048840 823296 q9Shape9T500=true := by
  change (fastTreeOK (forms 9) 1048840 (823296 ||| 2^4) q9Shape9T501 &&
    fastTreeOK (forms 9) (1048840 ||| 2^4) 823296 q9Shape9T522)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T501OK,q9Shape9T522OK⟩

private def q9Shape9T523 : Tree := (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 0 1 5 8)) (.tip (.cover 0 4 6 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8)))
private theorem q9Shape9T523OK : fastTreeOK (forms 9) 1081608 790528 q9Shape9T523=true := by decide

private def q9Shape9T499 : Tree := .split 15 q9Shape9T500 q9Shape9T523
private theorem q9Shape9T499OK : fastTreeOK (forms 9) 1048840 790528 q9Shape9T499=true := by
  change (fastTreeOK (forms 9) 1048840 (790528 ||| 2^15) q9Shape9T500 &&
    fastTreeOK (forms 9) (1048840 ||| 2^15) 790528 q9Shape9T523)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T500OK,q9Shape9T523OK⟩

private def q9Shape9T524 : Tree := (.split 15 (.split 4 (.split 5 (.split 9 (.split 10 (.split 13 (.tip (.cover 0 5 6 8)) (.tip (.cover 0 1 4 8))) (.tip (.cover 0 1 3 7))) (.tip (.cover 0 1 3 8))) (.tip (.cover 0 1 2 7))) (.tip (.cover 0 1 2 8))) (.tip (.cover 1 6 7 8)))
private theorem q9Shape9T524OK : fastTreeOK (forms 9) 1052936 786432 q9Shape9T524=true := by decide

private def q9Shape9T498 : Tree := .split 12 q9Shape9T499 q9Shape9T524
private theorem q9Shape9T498OK : fastTreeOK (forms 9) 1048840 786432 q9Shape9T498=true := by
  change (fastTreeOK (forms 9) 1048840 (786432 ||| 2^12) q9Shape9T499 &&
    fastTreeOK (forms 9) (1048840 ||| 2^12) 786432 q9Shape9T524)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T499OK,q9Shape9T524OK⟩

private def q9Shape9T412 : Tree := .split 8 q9Shape9T413 q9Shape9T498
private theorem q9Shape9T412OK : fastTreeOK (forms 9) 1048584 786432 q9Shape9T412=true := by
  change (fastTreeOK (forms 9) 1048584 (786432 ||| 2^8) q9Shape9T413 &&
    fastTreeOK (forms 9) (1048584 ||| 2^8) 786432 q9Shape9T498)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T413OK,q9Shape9T498OK⟩

private def q9Shape9T280 : Tree := .split 3 q9Shape9T281 q9Shape9T412
private theorem q9Shape9T280OK : fastTreeOK (forms 9) 1048576 786432 q9Shape9T280=true := by
  change (fastTreeOK (forms 9) 1048576 (786432 ||| 2^3) q9Shape9T281 &&
    fastTreeOK (forms 9) (1048576 ||| 2^3) 786432 q9Shape9T412)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T281OK,q9Shape9T412OK⟩

private def q9Shape9T2 : Tree := .split 20 q9Shape9T3 q9Shape9T280
private theorem q9Shape9T2OK : fastTreeOK (forms 9) 0 786432 q9Shape9T2=true := by
  change (fastTreeOK (forms 9) 0 (786432 ||| 2^20) q9Shape9T3 &&
    fastTreeOK (forms 9) (0 ||| 2^20) 786432 q9Shape9T280)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T3OK,q9Shape9T280OK⟩

private def q9Shape9T525 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape9T525OK : fastTreeOK (forms 9) 524288 262144 q9Shape9T525=true := by decide

private def q9Shape9T1 : Tree := .split 19 q9Shape9T2 q9Shape9T525
private theorem q9Shape9T1OK : fastTreeOK (forms 9) 0 262144 q9Shape9T1=true := by
  change (fastTreeOK (forms 9) 0 (262144 ||| 2^19) q9Shape9T2 &&
    fastTreeOK (forms 9) (0 ||| 2^19) 262144 q9Shape9T525)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T2OK,q9Shape9T525OK⟩

private def q9Shape9T526 : Tree := (.tip (.cover 0 1 7 8))
private theorem q9Shape9T526OK : fastTreeOK (forms 9) 262144 0 q9Shape9T526=true := by decide

private def q9Shape9T0 : Tree := .split 18 q9Shape9T1 q9Shape9T526
private theorem q9Shape9T0OK : fastTreeOK (forms 9) 0 0 q9Shape9T0=true := by
  change (fastTreeOK (forms 9) 0 (0 ||| 2^18) q9Shape9T1 &&
    fastTreeOK (forms 9) (0 ||| 2^18) 0 q9Shape9T526)=true
  rw [Bool.and_eq_true]
  exact ⟨q9Shape9T1OK,q9Shape9T526OK⟩


theorem q9Shape9_cover (b : Nat→Bool) (H : Ranked (adj (forms 9) b)) :
    ∃ u v w z,Effective (adj (forms 9) b) (adj (forms 9) b) u v w z :=
  checked_fastTree (forms 9) b H q9Shape9T0 q9Shape9T0OK

#print axioms q9Shape9_cover
end Graffiti384b.Q9
