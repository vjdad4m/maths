import Q9MaskKernel384b
namespace Graffiti384b.Q9
set_option maxHeartbeats 2000000
set_option maxRecDepth 100000
theorem true_twins_shape6 (bits : Nat→Bool) :
    score (adj (forms 6) bits) 0 = score (adj (forms 6) bits) 1 := by
  rfl

#print axioms true_twins_shape6
end Graffiti384b.Q9
