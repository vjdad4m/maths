import StarPalette

namespace Graffiti384b.OddStars.EarExample
open Finset SimpleGraph

abbrev V := Fin 14

def neighbors : V → Finset V
  | 0 => {4,5,6,7,8}
  | 1 => {4,6,7,8}
  | 2 => {5,6,7,8,9,10,12,13}
  | 3 => {5,6,7,8}
  | 4 => {0,1,5,6,7,8}
  | 5 => {0,2,3,4,7,8}
  | 6 => {0,1,2,3,4,8}
  | 7 => {0,1,2,3,4,5,8}
  | 8 => {0,1,2,3,4,5,6,7}
  | 9 => {2,10,11}
  | 10 => {2,9,11,12}
  | 11 => {9,10}
  | 12 => {2,10}
  | 13 => {2}

def graph : SimpleGraph V where
  Adj u v := v ∈ neighbors u
  symm := by
    have h : ∀ u v : V, v ∈ neighbors u → u ∈ neighbors v := by decide
    intro u v adj
    exact h u v adj
  loopless := by
    have h : ∀ v : V, v ∉ neighbors v := by decide
    exact h

instance : DecidableRel graph.Adj := fun u v => inferInstanceAs (Decidable (v ∈ neighbors u))

theorem connected : graph.Connected := by
  apply (connected_iff_exists_forall_reachable graph).mpr
  refine ⟨2,fun v => ?_⟩
  have h : ∀ w : V, w = 2 ∨ graph.Adj 2 w ∨ ∃ u : V, graph.Adj 2 u ∧ graph.Adj u w := by decide
  rcases h v with rfl | ha | ⟨u,h₁,h₂⟩
  · exact Reachable.refl _
  · exact ha.reachable
  · exact h₁.reachable.trans h₂.reachable

set_option maxRecDepth 32768
set_option maxHeartbeats 10000000

theorem triangle_scores : List.ofFn (trianglesAt graph) = [8,5,6,4,11,10,7,12,17,2,3,1,1,0] := by decide

def localVertices : Finset V := {2,9,10,11,12}
def required : Finset V := {9,11,12}

private theorem local_card (u : V) (um : u∈required) (A : Finset V) :
    nbr graph u (localVertices∩A) = nbr graph u A := by
  have incl : ∀ v∈required, ∀ w : V, graph.Adj v w → w∈localVertices := by decide
  unfold nbr
  congr 1
  ext w
  simp only [mem_filter,mem_inter]
  exact ⟨fun h => ⟨h.1.2,h.2⟩,fun h => ⟨⟨incl u um w h.2,h.1⟩,h.2⟩⟩

theorem incompatible : ¬ PositivePalette.Covered graph required := by
  rintro ⟨A,L,R⟩
  let S := localVertices∩A
  have eq : localVertices∩Aᶜ=localVertices\S := by ext x; simp [S]
  have loc : required ⊆ localVertices := by decide
  have check : (localVertices.powerset.filter (fun s =>
      ∀v∈required,2 ≤ nbr graph v (if v∈s then localVertices\s else s)))=∅ := by decide
  have hit : S∈localVertices.powerset.filter (fun s =>
      ∀v∈required,2 ≤ nbr graph v (if v∈s then localVertices\s else s)) := by
    apply mem_filter.mpr
    refine ⟨mem_powerset.mpr inter_subset_left,?_⟩
    intro v vm
    by_cases a : v∈A
    · rw [if_pos (mem_inter.mpr ⟨loc vm,a⟩ : v∈S),←eq,local_card v vm Aᶜ]
      exact L v vm a
    · rw [if_neg (fun (m : v∈S) => a (mem_inter.mp m).2),local_card v vm A]
      exact R v vm (mem_compl.mpr a)
  rw [check] at hit
  exact not_mem_empty _ hit

theorem catalogue : (types graph).card=13 ∧ gamma graph ≤ 6 ∧ bound graph=7 := by
  refine ⟨by decide,?_,by decide⟩
  let D : Finset V := {2,6,7,9,10,13}
  exact Nat.sInf_le ⟨D,(by unfold TwoDominates; decide : TwoDominates graph D),(by decide : D.card=6)⟩

end Graffiti384b.OddStars.EarExample
#print axioms Graffiti384b.OddStars.EarExample.connected
#print axioms Graffiti384b.OddStars.EarExample.triangle_scores
#print axioms Graffiti384b.OddStars.EarExample.incompatible
#print axioms Graffiti384b.OddStars.EarExample.catalogue
