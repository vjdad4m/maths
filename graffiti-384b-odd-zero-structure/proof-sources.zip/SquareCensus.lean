import SquareObstructions

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A failure with a degree-two zero has at most two degree-two vertices on
four-cycles in total, even when both have triangle count zero. -/
theorem at_most_two_square_centers (bad : bound G<gamma G) {z : V}
    (zz : trianglesAt G z=0) (dz : G.degree z=2)
    (S : Finset V) (degree : ∀x∈S,G.degree x=2) (squares : ∀x∈S,secondCenter G x) : S.card≤2 := by
  classical
  by_cases ne : S.Nonempty
  swap
  · simp [not_nonempty_iff_eq_empty.mp ne]
  obtain ⟨x,xm⟩ := ne
  obtain ⟨e,_,one⟩ := mem_image.mp (zero_two_forces_ears G bad zz dz).1
  obtain ⟨_,_,tight,gap⟩ := two_frames G bad zz dz one
  have low (v : V) (vm : v∈S) : v∉high G := by
    intro h; have l := degree v vm; have b := (mem_filter.mp h).2; omega
  have independent : ∀a∈S,∀b∈S,¬G.Adj a b :=
    fun a am b bm edge => low b bm (contacts_high G bad zz dz (degree a am) ((G.mem_neighborFinset ..).mpr edge))
  let A := G.neighborFinset x
  have ax : A.card=2 := (G.card_neighborFinset_eq_degree _).trans (degree x xm)
  have meets {y : V} (ym : y∈S.erase x) : ((G.neighborFinset y)∩A).Nonempty := by
    obtain ⟨yx,ys⟩ := mem_erase.mp ym
    by_contra none
    have dis : Disjoint (G.neighborFinset y) A :=
      disjoint_iff_inter_eq_empty.mpr (not_nonempty_iff_eq_empty.mp none)
    obtain ⟨u,uy,su⟩ := squares y ys
    obtain ⟨v,vx,sv⟩ := squares x xm
    have cut := paired_squares G yx (independent y ys x xm) (degree y ys) (degree x xm) dis uy vx su sv
    have bound := count_covered G cut
    rw [card_insert_of_not_mem (by simp [yx,low y ys]),card_insert_of_not_mem (low x xm)] at bound
    omega
  let R := (S.erase x).biUnion (fun y => G.neighborFinset y \ A)
  have rsize : R.card≤(S.erase x).card := by
    calc
      R.card ≤ ∑y∈S.erase x,(G.neighborFinset y \ A).card := card_biUnion_le
      _ ≤ ∑_y∈S.erase x,1 := by
        apply sum_le_sum
        intro y ym
        have h := card_sdiff_add_card_inter (G.neighborFinset y) A
        have pos := card_pos.mpr (meets ym)
        rw [card_neighborFinset_eq_degree,degree y (mem_erase.mp ym).2] at h
        omega
      _ = _ := by simp
  let U := (high G).filter (fun w => ∃v∈S,G.Adj v w)
  have inc : U⊆A∪R := by
    intro w wm
    obtain ⟨v,vm,edge⟩ := (mem_filter.mp wm).2
    by_cases wa : w∈A
    · exact mem_union_left _ wa
    · have vx : v≠x := fun eq => wa ((G.mem_neighborFinset ..).mpr (eq ▸ edge))
      exact mem_union_right _ (mem_biUnion.mpr ⟨v,mem_erase.mpr ⟨vx,vm⟩,
        mem_sdiff.mpr ⟨(G.mem_neighborFinset ..).mpr edge,wa⟩⟩)
  have us := (card_le_card inc).trans (card_union_le A R)
  have rem := card_erase_of_mem xm
  have failure : (high G).card+2*S.card < (types G).card+U.card := by
    apply Nat.lt_of_not_ge
    intro good
    exact (not_lt_of_ge (Repair.exact_of_low_support G S (disjoint_left.mpr (fun _ m => low _ m))
      (fun v vm => (degree v vm).ge) independent good)) bad
  omega

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.at_most_two_square_centers
