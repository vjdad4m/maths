import SharedZeroAnchor
import CoupledSquares

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette
open private OddStars.no_zero_neighbor from ZeroTwoLayout
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- For a degree-two vertex this asserts that it lies on a four-cycle. -/
def secondCenter (x : V) : Prop := ∃u,u≠x ∧ ∀a,G.Adj x a → G.Adj u a

private theorem forbidden_pair {x y : V} (bad : bound G<gamma G) (xy : x≠y)
    (low : trianglesAt G x≤1) (one : trianglesAt G y=1)
    (cut : Covered G (insert x (insert y (high G)))) : False := by
  classical
  let W := insert x (insert y (high G))
  have xw : x∈W := mem_insert_self ..
  have yw : y∈W := mem_insert_of_mem (mem_insert_self ..)
  have hi : high (patch G univ)⊆high G := by
    intro a am
    have d := (mem_filter.mp am).2
    rw [center_degree G (mem_univ a)] at d
    exact mem_filter.mpr ⟨mem_univ _,d⟩
  have rep := represents_of_high G (W:=W) (hi.trans ((subset_insert ..).trans (subset_insert ..)))
    (fun _ => ⟨y,yw,one⟩)
  obtain ⟨img,inj,_⟩ := rigid G (J:=G) le_rfl rep cut bad
  by_cases zero : trianglesAt G x=0
  · have m := mem_image_of_mem (trianglesAt G) xw
    rw [img,zero] at m
    exact not_mem_erase _ _ m
  · exact xy (inj xw yw (by omega))

/-- If a degree-two zero and a count-one ear both lie on four-cycles,
the bound holds. Their two squares may share vertices. -/
theorem zero_ear_squares {z e : V} (zz : trianglesAt G z=0) (de : G.degree z=2)
    (one : trianglesAt G e=1) (zs : secondCenter G z) (es : secondCenter G e) : gamma G≤bound G := by
  apply Nat.le_of_not_gt
  intro bad
  have ee := (zero_two_forces_ears G bad zz de).2 e one
  have ze : z≠e := fun eq => by rw [eq,one] at zz; contradiction
  have dis : Disjoint (G.neighborFinset z) (G.neighborFinset e) :=
    disjoint_left.mpr (fun _ m n => disjoint_zero_ear G bad zz de one
      ((G.mem_neighborFinset ..).mp m) ((G.mem_neighborFinset ..).mp n))
  obtain ⟨u,uz,us⟩ := zs
  obtain ⟨v,ve,vs⟩ := es
  exact forbidden_pair G bad ze (by omega) one (paired_squares G ze
    (fun h => OddStars.no_zero_neighbor G ee one zz h.symm) de ee dis uz ve us vs)

/-- At a failure, two distinct count-one vertices on four-cycles must
have intersecting neighborhoods. -/
theorem one_ear_squares {x y : V} (xy : x≠y) (sx : trianglesAt G x=1) (sy : trianglesAt G y=1)
    (dis : Disjoint (G.neighborFinset x) (G.neighborFinset y))
    (xs : secondCenter G x) (ys : secondCenter G y) : gamma G≤bound G := by
  apply Nat.le_of_not_gt
  intro bad
  have ear {a b : V} (ab : a≠b) (sa : trianglesAt G a=1) (sb : trianglesAt G b=1) : G.degree a=2 := by
    obtain ⟨u,v,au,av,uv⟩ := (TrianglePrune.triangle_iff G a).mp (by omega)
    have lo := Prerequisites.deg2 G uv.ne au av
    by_contra! ne
    exact ab (rich_one_unique G bad (by omega) sa sb)
  have dx := ear xy sx sy
  have dy := ear xy.symm sy sx
  have off : ¬G.Adj x y := by
    obtain ⟨a,b,nb,xa,xb,ab⟩ := Prerequisites.ear_pair G dx (by omega : 0<trianglesAt G x)
    intro h
    have m := (G.mem_neighborFinset ..).mpr h
    rw [nb,mem_insert,mem_singleton] at m
    rcases m with rfl|rfl
    · exact disjoint_left.mp dis ((G.mem_neighborFinset ..).mpr xb) ((G.mem_neighborFinset ..).mpr ab)
    · exact disjoint_left.mp dis ((G.mem_neighborFinset ..).mpr xa) ((G.mem_neighborFinset ..).mpr ab.symm)
  obtain ⟨u,ux,us⟩ := xs
  obtain ⟨v,vy,vs⟩ := ys
  exact forbidden_pair G bad xy sx.le sy (paired_squares G xy off dx dy dis ux vy us vs)

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.zero_ear_squares
#print axioms Graffiti384b.OddStars.one_ear_squares
