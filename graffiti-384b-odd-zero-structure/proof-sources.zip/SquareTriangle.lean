import SquareCensus

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette
open private OddStars.merge_frames from CoupledSquares
open private Repair.nbr_mono from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem no_pair_cut (bad : bound G<gamma G) {z x y : V}
    (zz : trianglesAt G z=0) (dz : G.degree z=2) (xy : x≠y)
    (dx : G.degree x=2) (dy : G.degree y=2) (cut : Covered G (insert x (insert y (high G)))) : False := by
  obtain ⟨e,_,one⟩ := mem_image.mp (zero_two_forces_ears G bad zz dz).1
  have tight := (two_frames G bad zz dz one).2.2.1
  have nothigh {a : V} (da : G.degree a=2) : a∉high G := fun m => by have := (mem_filter.mp m).2; omega
  have b := count_covered G cut
  rw [card_insert_of_not_mem (by simp [xy,nothigh dx]),card_insert_of_not_mem (nothigh dy)] at b
  omega

private theorem forced_cross (bad : bound G<gamma G) {z x y u v : V}
    (zz : trianglesAt G z=0) (dz : G.degree z=2) (xy : x≠y)
    (dx : G.degree x=2) (dy : G.degree y=2) (ux : u≠x) (vy : v≠y)
    (su : ∀a,G.Adj x a → G.Adj u a) (sv : ∀a,G.Adj y a → G.Adj v a) :
    G.Adj y u ∨ G.Adj x v := by
  classical
  by_contra! no
  have off : ¬G.Adj x y := fun edge => by
    have hh := contacts_high G bad zz dz dx ((G.mem_neighborFinset ..).mpr edge)
    have := (mem_filter.mp hh).2
    omega
  let A := G.neighborFinset x
  let C := G.neighborFinset y
  let B : Finset V := {x,u}
  let D : Finset V := {y,v}
  have half {p q : V} (pq : p≠q) (dp : G.degree p=2) (s : ∀a,G.Adj p a → G.Adj q a) :
      (∀a∈G.neighborFinset p,2≤nbr G a {p,q}) ∧ (∀a∈({p,q}:Finset V),2≤nbr G a (G.neighborFinset p)) := by
    refine ⟨?_,?_⟩
    · intro a am
      have h := (G.mem_neighborFinset ..).mp am
      exact PinnedColor34.two G pq h.symm (s _ h).symm (by simp) (by simp)
    · intro a am
      have alladj : ∀b∈G.neighborFinset p,G.Adj a b := by
        rcases mem_insert.mp am with rfl|am
        · exact fun _ m => (G.mem_neighborFinset ..).mp m
        · obtain rfl := mem_singleton.mp am; exact fun _ m => s _ ((G.mem_neighborFinset ..).mp m)
      rw [nbr,filter_true_of_mem alladj,card_neighborFinset_eq_degree,dp]
  obtain ⟨ab,ba⟩ := half ux.symm dx su
  obtain ⟨cd,dc⟩ := half vy.symm dy sv
  have dis : Disjoint (A∪C) (B∪D) := by
    apply disjoint_left.mpr
    intro t tm mm
    have f {a b : V} (h : t∈({a,b}:Finset V)) : t=a ∨ t=b := by simpa using h
    rcases mem_union.mp tm with am|cm
    · have edge := (G.mem_neighborFinset ..).mp am
      rcases mem_union.mp mm with bm|dm
      · rcases f bm with rfl|rfl
        · exact edge.ne rfl
        · exact (su _ edge).ne rfl
      · rcases f dm with rfl|rfl
        · exact off edge
        · exact no.2 edge
    · have edge := (G.mem_neighborFinset ..).mp cm
      rcases mem_union.mp mm with bm|dm
      · rcases f bm with rfl|rfl
        · exact off edge.symm
        · exact no.1 edge
      · rcases f dm with rfl|rfl
        · exact edge.ne rfl
        · exact (sv _ edge).ne rfl
  exact no_pair_cut G bad zz dz xy dx dy (OddStars.merge_frames G dis ab ba cd dc
    (Or.inr (mem_union_left _ (mem_insert_self ..))) (Or.inr (mem_union_right _ (mem_insert_self ..))))

/-- In a failure with a degree-two zero, any two degree-two vertices on
squares must be count-one ears attached to two distinct edges of one triangle. -/
theorem square_pair_triangle (bad : bound G<gamma G) {z x y : V} (zz : trianglesAt G z=0)
    (dz : G.degree z=2) (xy : x≠y) (dx : G.degree x=2) (dy : G.degree y=2)
    (xs : secondCenter G x) (ys : secondCenter G y) :
    trianglesAt G x=1 ∧ trianglesAt G y=1 ∧ ∃c a b,
      G.neighborFinset x={c,a} ∧ G.neighborFinset y={c,b} ∧
      G.Adj c a ∧ G.Adj c b ∧ G.Adj a b := by
  classical
  obtain ⟨u,ux,su⟩ := xs
  obtain ⟨v,vy,sv⟩ := ys
  have off : ¬G.Adj x y := fun edge => by
    have hh := contacts_high G bad zz dz dx ((G.mem_neighborFinset ..).mpr edge)
    have := (mem_filter.mp hh).2; omega
  have common : ((G.neighborFinset x)∩(G.neighborFinset y)).Nonempty := by
    by_contra none
    have dis := disjoint_iff_inter_eq_empty.mpr (not_nonempty_iff_eq_empty.mp none)
    exact no_pair_cut G bad zz dz xy dx dy (paired_squares G xy off dx dy dis ux vy su sv)
  obtain ⟨c,cm⟩ := common
  have xc := (G.mem_neighborFinset ..).mp (mem_inter.mp cm).1
  have yc := (G.mem_neighborFinset ..).mp (mem_inter.mp cm).2
  have pair {t : V} (dt : G.degree t=2) (tc : G.Adj t c) :
      ∃ a, G.neighborFinset t={c,a} ∧ G.Adj t a ∧ c≠a := by
    have dn := G.card_neighborFinset_eq_degree t
    obtain ⟨a,am,ac⟩ := exists_ne_of_one_lt_card (by omega : 1<(G.neighborFinset t).card) c
    have sub : ({c,a}:Finset V)⊆G.neighborFinset t := insert_subset ((G.mem_neighborFinset ..).mpr tc)
      (singleton_subset_iff.mpr am)
    exact ⟨a,(eq_of_subset_of_card_le sub (by rw [card_pair ac.symm,dn,dt])).symm,(G.mem_neighborFinset ..).mp am,ac.symm⟩
  obtain ⟨a,na,xa,ca⟩ := pair dx xc
  obtain ⟨b,nb,yb,cb⟩ := pair dy yc
  have cross := forced_cross G bad zz dz xy dx dy ux vy su sv
  have sides : G.Adj a b ∧ (G.Adj c a ∨ G.Adj c b) := by
    rcases cross with yu|xv
    · have m := (G.mem_neighborFinset ..).mpr yu
      rw [nb,mem_insert,mem_singleton] at m
      have uc := (su _ xc).ne
      obtain rfl := m.resolve_left uc
      exact ⟨(su _ xa).symm,Or.inr (su _ xc).symm⟩
    · have m := (G.mem_neighborFinset ..).mpr xv
      rw [na,mem_insert,mem_singleton] at m
      have vc := (sv _ yc).ne
      obtain rfl := m.resolve_left vc
      exact ⟨sv _ yb,Or.inl (sv _ yc).symm⟩
  have score {t : V} (dt : G.degree t=2) : trianglesAt G t=0 ∨ trianglesAt G t=1 := by
    have h := (high_description G bad zz dz ∅).2 t
    have low : t∉high G := fun m => by have := (mem_filter.mp m).2; omega
    have := mt h.mpr low
    omega
  have positive {t q a' : V} (dt : G.degree t=2) (dq : G.degree q=2)
      (tc : G.Adj t c) (qc : G.Adj q c) (ta : G.Adj t a') (ct : G.Adj c a') :
      trianglesAt G t=1 ∧ trianglesAt G q=1 := by
    have pos := (TrianglePrune.triangle_iff G t).mpr ⟨c,a',tc,ta,ct⟩
    have st := (score dt).resolve_left (by omega)
    exact ⟨st,(score dq).resolve_left (fun zero => disjoint_zero_ear G bad zero dq st qc tc)⟩
  have sc : trianglesAt G x=1 ∧ trianglesAt G y=1 :=
    sides.2.elim (positive dx dy xc yc xa) (fun h => (positive dy dx yc xc yb h).symm)
  have linked {t d : V} (s : trianglesAt G t=1) (nt : G.neighborFinset t={c,d}) : G.Adj c d := by
    obtain ⟨i,j,ti,tj,ij⟩ := (TrianglePrune.triangle_iff G t).mp (by omega)
    have im := (G.mem_neighborFinset ..).mpr ti
    have jm := (G.mem_neighborFinset ..).mpr tj
    rw [nt,mem_insert,mem_singleton] at im jm
    rcases im with rfl|rfl <;> rcases jm with eq|eq <;> subst_vars
    all_goals first | exact ij | exact ij.symm | exact (ij.ne rfl).elim
  exact ⟨sc.1,sc.2,c,a,b,na,nb,linked sc.1 na,linked sc.2 nb,sides.1⟩

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.square_pair_triangle
