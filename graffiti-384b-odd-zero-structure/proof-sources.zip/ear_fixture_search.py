"""Find a supported core for the proposed two-designated-ear cut obstruction."""
import subprocess, sys, itertools
from search import decode, vertices

def main():
    for n in (6,7,8,9):
        proc = subprocess.Popen([sys.argv[1],'-cq','-d3',str(n)],stdout=subprocess.PIPE)
        try:
            for line in proc.stdout:
                g=decode(line)
                if any(not (g[u]&g[v]) for u in range(n) for v in vertices(g[u])):
                    continue
                scores=[sum((g[u]&g[v]).bit_count() for v in vertices(g[u]))//2 for u in range(n)]
                for c in range(n):
                    final = scores.copy()
                    final[c] += 2
                    final += [2,3,1,1]
                    if len(set(final))!=n+3 or len(set(final))%2 or min(scores)<2:
                        continue
                    print(n,line.strip().decode(),c,final,flush=True)
                    return
        finally:
            proc.stdout.close()
            proc.wait()
if __name__ == '__main__':
    main()
