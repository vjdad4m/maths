"""Diagnostic on connected triangle-supported cores, using nauty graph6 output."""
import itertools
import subprocess
import sys

def decode(line):
    n = line[0] - 63
    adj = [0] * n
    k = 0
    for j in range(1, n):
        for i in range(j):
            if (line[1 + k // 6] - 63) >> (5 - k % 6) & 1:
                adj[i] |= 1 << j
                adj[j] |= 1 << i
            k += 1
    return adj

def vertices(mask):
    while mask:
        bit = mask & -mask
        yield bit.bit_length() - 1
        mask ^= bit

def study(adj, distinct=True):
    n = len(adj)
    allv = (1 << n) - 1
    score = [0] * n
    for u in range(n):
        for v in vertices(adj[u]):
            overlap = (adj[u] & adj[v]).bit_count()
            if not overlap:
                return
            score[u] += overlap
        score[u] //= 2
    rich = tuple(i for i,s in enumerate(score) if s >= 2)
    ears = tuple(i for i,s in enumerate(score) if s == 1)
    if not ears or len(set(score)) % 2 or (distinct and len({score[i] for i in rich}) != len(rich)):
        return
    pairs = {(u,v) for u,v in itertools.combinations(rich,2) if not (adj[u] >> v & 1)}
    initial = len(pairs)
    full = set(pairs)
    for S in range(1 << (n-1)):
        other = allv ^ S
        good = {v for v in range(n) if (adj[v] & (other if S >> v & 1 else S)).bit_count() >= 2}
        if not any(e in good for e in ears):
            continue
        for u,v in tuple(full):
            if (S>>u ^ S>>v)&1:
                continue
            opposite = other if S >> u & 1 else S
            if all(x in good or (x in (u,v) and adj[x]&opposite) for x in rich):
                full.remove((u,v))
            if all(x in good for x in rich):
                pairs.discard((u,v))
        if all(x in good for x in rich):
            pairs = {(u,v) for u,v in pairs if (S>>u ^ S>>v)&1}
        if not pairs:
            break
    return initial, pairs, full, score

def main():
    geng = sys.argv[1]
    for n in map(int,(arg for arg in sys.argv[2:] if arg != "--relax")):
        counts = [0]*5
        examples = [None,None]
        proc = subprocess.Popen([geng,'-cq','-d2',str(n)],stdout=subprocess.PIPE)
        for line in proc.stdout:
            counts[0] += 1
            data = study(decode(line), '--relax' not in sys.argv)
            if data is None:
                continue
            size, weak, full, score = data
            counts[1] += 1
            counts[2] += size
            counts[3] += len(weak)
            counts[4] += len(full)
            for i, obs in enumerate((weak,full)):
                if obs and examples[i] is None:
                    examples[i] = (line.strip().decode(), sorted(obs)[0], score)
        assert proc.wait()==0
        print(n, counts[:5], examples, flush=True)
if __name__=='__main__':
    main()
