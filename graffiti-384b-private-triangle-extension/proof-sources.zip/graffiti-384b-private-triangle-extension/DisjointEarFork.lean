import TrappedAnchor
namespace Graffiti384b.TriangleFrame
open Finset SimpleGraph FiveChoice Four29 LowSample SixFront Exterior PinnedColor34
open private Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- One free triangle around a solitary gap is the one-reservation instance. -/
theorem single_extension {P Q : Finset V} {a x y : V} (H : Gap G P Q a)
    (thin : NoThinPair G P Q) (xo : x∉P∪Q) (yo : y∉P∪Q)
    (ax : G.Adj a x) (ay : G.Adj a y) (xy : G.Adj x y) : Extension G P Q := by
  let A := fun _ : V => ({x,y}:Finset V)
  apply simultaneous_extension G P Q {a} A _ thin
  refine ⟨H.apart,singleton_subset_iff.mpr H.pinned,?_,?_,H.right,?_,?_,?_⟩
  · intro b hb; obtain rfl := mem_singleton.mp hb; exact H.one
  · intro b bp bn; exact H.left b bp (fun eq => bn (mem_singleton.mpr eq))
  · intro b hb; obtain rfl := mem_singleton.mp hb; exact ⟨x,y,rfl,ax,ay,xy⟩
  · intro b _; exact disjoint_left.mpr (fun z hz => by rcases mem_insert.mp hz with rfl|hz; exact xo; exact (mem_singleton.mp hz) ▸ yo)
  · intro b hb c hc ne; exact (ne ((mem_singleton.mp hb).trans (mem_singleton.mp hc).symm)).elim

private theorem finish {P Q : Finset V} (quota : (types G).card≤(nonleaves G).card)
    (pinned : twos G⊆P∪Q) (extn : Extension G P Q) : gamma G≤bound G := by
  obtain ⟨L,R,pl,qr,cut⟩ := extn
  apply PinnedColor34.complete G cut.1 quota _ cut.2.1 cut.2.2
  intro v vn vl vr
  by_contra! small
  have tv : v∈twos G := mem_sdiff.mpr ⟨vn,fun hi => (not_le_of_gt small) (mem_filter.mp hi).2⟩
  exact (mem_union.mp (pinned tv)).elim (fun m => vl (pl m)) (fun m => vr (qr m))

/-- Opposite orientations of two disjoint ear pairs handle a two-edge star between their anchors. -/
theorem fork_bound (quota : (types G).card≤(nonleaves G).card) (l : Fin 6 ↪ V)
    (ears : twos G={l 4,l 5}) (first : G.neighborFinset (l 4)={l 0,l 1})
    (second : G.neighborFinset (l 5)={l 2,l 3})
    (bc : G.Adj (l 1) (l 2)) (bd : G.Adj (l 1) (l 3))
    (thin : NoThinPair G ∅ (twos G)) (rich : 2≤trianglesAt G (l 0)) : gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt
  intro bad
  let P : Finset V := {l 0,l 1,l 5}
  let Q : Finset V := {l 4,l 2,l 3}
  have ni {i j : Fin 6} (ne : i≠j) : l i≠l j := l.injective.ne ne
  have ea : G.Adj (l 4) (l 0) := (G.mem_neighborFinset ..).mp (first ▸ mem_insert_self ..)
  have eb : G.Adj (l 4) (l 1) := (G.mem_neighborFinset ..).mp (first ▸ mem_insert_of_mem (mem_singleton_self _))
  have fc : G.Adj (l 5) (l 2) := (G.mem_neighborFinset ..).mp (second ▸ mem_insert_self ..)
  have fd : G.Adj (l 5) (l 3) := (G.mem_neighborFinset ..).mp (second ▸ mem_insert_of_mem (mem_singleton_self _))
  have gap : Gap G P Q (l 0) := by
    constructor
    · simp [P,Q,l.injective.eq_iff]
    · simp [P]
    · exact card_pos.mpr ⟨l 4,mem_filter.mpr ⟨mem_insert_self ..,ea.symm⟩⟩
    · intro v vm ne
      rcases mem_insert.mp vm with rfl|m
      · exact (ne rfl).elim
      rcases mem_insert.mp m with rfl|m
      · exact PinnedColor34.two G (ni (by decide : (2:Fin 6)≠3)) bc bd (by simp [Q]) (by simp [Q])
      · obtain rfl := mem_singleton.mp m
        exact PinnedColor34.two G (ni (by decide : (2:Fin 6)≠3)) fc fd (by simp [Q]) (by simp [Q])
    · intro v vm
      rcases mem_insert.mp vm with rfl|m
      · exact PinnedColor34.two G (ni (by decide : (0:Fin 6)≠1)) ea eb (by simp [P]) (by simp [P])
      rcases mem_insert.mp m with rfl|m
      · exact PinnedColor34.two G (ni (by decide : (1:Fin 6)≠5)) bc.symm fc.symm (by simp [P]) (by simp [P])
      · obtain rfl := mem_singleton.mp m
        exact PinnedColor34.two G (ni (by decide : (1:Fin 6)≠5)) bd.symm fd.symm (by simp [P]) (by simp [P])
  have pinned : twos G⊆P∪Q := by
    rw [ears]; exact insert_subset (mem_union_right _ (by simp [Q])) (singleton_subset_iff.mpr (mem_union_left _ (by simp [P])))
  have win := fun (E : Extension G P Q) => (not_lt_of_ge (finish G quota pinned E)) bad
  have direct (r : V) (rq : r∈Q) (re : l 4≠r) (edge : G.Adj (l 0) r) : False := by
    apply win
    refine ⟨P,Q,Subset.rfl,Subset.rfl,gap.apart,?_,gap.right⟩
    intro v vm
    by_cases eq : v=l 0
    · subst v; exact PinnedColor34.two G re ea.symm edge (by simp [Q]) rq
    · exact gap.left v vm eq
  have ac : ¬G.Adj (l 0) (l 2) := direct _ (by simp [Q]) (ni (by decide))
  have ad : ¬G.Adj (l 0) (l 3) := direct _ (by simp [Q]) (ni (by decide))
  have af : ¬G.Adj (l 0) (l 5) := by
    intro m
    have n := (G.mem_neighborFinset ..).mpr m.symm
    rw [second] at n
    simp [l.injective.eq_iff] at n
  have s := rich
  change 2≤(link G (l 0)).card at s
  obtain ⟨p,pm,other⟩ := exists_ne_of_one_lt_card (by omega : 1<(link G (l 0)).card) ({l 4,l 1}:Finset V)
  obtain ⟨sub,two,cl⟩ := Repair.edge_info G pm
  obtain ⟨x,y,ne,pair⟩ := card_eq_two.mp two
  have xm : x∈p := pair ▸ mem_insert_self ..
  have ym : y∈p := pair ▸ mem_insert_of_mem (mem_singleton_self _)
  have xy := cl x xm y ym ne
  have adj {u : V} (um : u∈p) : G.Adj (l 0) u := (G.mem_neighborFinset ..).mp (sub um)
  have notEar {u v : V} (_um : u∈p) (vm : v∈p) (uv : G.Adj u v) (eq : p={u,v}) : u≠l 4 := by
    rintro rfl
    have vn := (G.mem_neighborFinset ..).mpr uv
    rw [first,mem_insert,mem_singleton] at vn
    rcases vn with rfl|rfl
    · exact (G.loopless _ (adj vm))
    · exact other eq
  have classify {u : V} (um : u∈p) (ue : u≠l 4) : u=l 1 ∨ u∉P∪Q := by
    by_cases eq : u=l 1
    · exact Or.inl eq
    · right
      simp only [P,Q,mem_union,mem_insert,mem_singleton,not_or]
      exact ⟨⟨(adj um).ne.symm,eq,fun h => af (h ▸ adj um)⟩,ue,fun h => ac (h ▸ adj um),fun h => ad (h ▸ adj um)⟩
  have cx := classify xm (notEar xm ym xy pair)
  have cy := classify ym (notEar ym xm xy.symm (pair.trans (pair_comm ..)))
  rcases cx with rfl|xp <;> rcases cy with rfl|yp
  · exact ne rfl
  · exact win (two_steps G gap disjoint_compl_right (mem_compl.mpr yp) (by simp [P]) (ni (by decide)) (adj ym) xy.symm)
  · exact win (two_steps G gap disjoint_compl_right (mem_compl.mpr xp) (by simp [P]) (ni (by decide)) (adj xm) xy)
  · apply win (single_extension G gap _ xp yp (adj xm) (adj ym) xy)
    intro a v w vo wo
    apply thin a v w
    · simpa using (fun ve => vo (pinned ve) : v∉twos G)
    · simpa using (fun we => wo (pinned we) : w∉twos G)
end Graffiti384b.TriangleFrame
#print axioms Graffiti384b.TriangleFrame.single_extension
#print axioms Graffiti384b.TriangleFrame.fork_bound
