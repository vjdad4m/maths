import PrivateTriangleExtension
namespace Graffiti384b.TriangleFrame
open Finset SimpleGraph PrivatePatch PinnedColor34 FiveChoice LowSample SixFront
open private Repair.edge_info Repair.nbr_mono from Repair384b
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Neighbors of the degree-two vertices, with no disjointness assumption on their neighborhoods. -/
def anchors := (twos G).biUnion (fun e => G.neighborFinset e)

/-- A singly exposed anchor has a triangle avoiding the ears which does not lie entirely among the anchors. -/
def Escapes (a : V) : Prop :=
  ∃p∈link G a,Disjoint p (twos G) ∧ ¬p⊆anchors G

private theorem private_escape {W E C : Finset V} {a : V}
    (aw : a∈W) (weak : Weak G W C a) (cover : C=(W∪E)ᶜ)
    {p : Finset V} (pm : p∈link G a) (pe : Disjoint p E) (away : ¬p⊆W) :
    ∃x y,p={x,y} ∧ G.Adj a x ∧ G.Adj a y ∧ G.Adj x y ∧ p⊆privateAt G W C a := by
  classical
  obtain ⟨sub,size,cl⟩ := Repair.edge_info G pm
  obtain ⟨u,v,ne,shape⟩ := card_eq_two.mp size
  have up : u∈p := shape ▸ mem_insert_self ..
  have vp : v∈p := shape ▸ mem_insert_of_mem (mem_singleton_self _)
  have ax {z : V} (h : z∈p) := (G.mem_neighborFinset ..).mp (sub h)
  have wz {z : V} (h : z∈p) (outside : z∉W) : z∈C := by
    rw [cover,mem_compl,mem_union,not_or]; exact ⟨outside,disjoint_left.mp pe h⟩
  have own {z : V} (h : z∈p) (outside : z∉W) : z∈privateAt G W C a := by
    have zc := wz h outside
    refine mem_filter.mpr ⟨zc,ax h,?_⟩
    intro b bw bz
    by_contra ne
    exact weak.1 z (mem_filter.mpr ⟨zc,two G (Ne.symm ne) (ax h).symm bz.symm aw bw⟩) (ax h)
  have both {z w : V} (zp : z∈p) (wp : w∈p) (zw : G.Adj z w) : z∉W := by
    intro inW
    have outW : w∉W := by
      intro win
      have eq := eq_of_subset_of_card_le (insert_subset zp (singleton_subset_iff.mpr wp))
        (by rw [size,card_pair zw.ne])
      exact away (eq ▸ insert_subset inW (singleton_subset_iff.mpr win))
    have privateW := (mem_filter.mp (own wp outW)).2.2 z inW zw
    exact (ax zp).ne privateW.symm
  have uv := cl u up v vp ne
  refine ⟨u,v,shape,ax up,ax vp,uv,?_⟩
  rw [shape]; exact insert_subset (own up (both up vp uv)) (singleton_subset_iff.mpr (own vp (both vp up uv.symm)))

/-- The simultaneous cut criterion, expressed using only the original graph and the degree-two set.
The ear neighborhoods may overlap and may contain triangles. -/
theorem escaping_anchors (quota : (types G).card≤(nonleaves G).card)
    (indep : Disjoint (twos G) (anchors G)) (thin : NoThinPair G ∅ (twos G))
    (escape : ∀a∈anchors G,nbr G a (twos G)=1 → Escapes G a) : gamma G≤bound G := by
  classical
  let E := twos G
  let W := anchors G
  let C := (W∪E)ᶜ
  have wc : Disjoint W C := disjoint_compl_right.mono_left (show W⊆W∪E from subset_union_left)
  have ec : Disjoint E C := disjoint_compl_right.mono_left (show E⊆W∪E from subset_union_right)
  have ears (v : V) (ve : v∈E) : 2≤nbr G v W := by
    have inc : G.neighborFinset v⊆W.filter (G.Adj v) := fun x xm =>
      mem_filter.mpr ⟨mem_biUnion.mpr ⟨v,ve,xm⟩,(G.mem_neighborFinset ..).mp xm⟩
    have le := card_le_card inc
    rwa [card_neighborFinset_eq_degree,LowSample.two_degree G ve] at le
  have touch (a : V) (aw : a∈W) : ∃v∈E,G.Adj a v := by
    obtain ⟨e,em,ea⟩ := mem_biUnion.mp aw
    exact ⟨e,em,((G.mem_neighborFinset ..).mp ea).symm⟩
  obtain ⟨P,Q,wp,eq',apart,right,left,one,free⟩ := PrivatePatch.assemble G wc indep.symm ec ears touch
  let D := P.filter (fun a => nbr G a Q<2)
  have classify {a : V} (ad : a∈D) : a∈W ∧ Weak G W C a ∧ nbr G a E=1 := by
    obtain ⟨ap,bad⟩ := mem_filter.mp ad
    have n : ¬(a∉W ∨ ¬Weak G W C a) := fun h => (not_lt_of_ge (left a ap h)) bad
    push_neg at n
    obtain ⟨e,em,ae⟩ := touch a n.1
    have ge : 1≤nbr G a E := card_pos.mpr ⟨e,mem_filter.mpr ⟨em,ae⟩⟩
    have le : nbr G a E≤nbr G a Q := Repair.nbr_mono G a eq'
    exact ⟨n.1,n.2,by omega⟩
  have choosePair (a : V) : ∃p : Finset V,a∈D →
      p⊆privateAt G W C a ∧ ∃x y,p={x,y} ∧ G.Adj a x ∧ G.Adj a y ∧ G.Adj x y := by
    by_cases ad : a∈D
    · obtain ⟨aw,weak,single⟩ := classify ad
      obtain ⟨p,pm,pe,pw⟩ := escape a aw single
      obtain ⟨x,y,shape,ax,ay,xy,inc⟩ := private_escape G aw weak (rfl : C=(W∪E)ᶜ) pm pe pw
      exact ⟨p,fun _ => ⟨inc,x,y,shape,ax,ay,xy⟩⟩
    · exact ⟨∅,fun h => (ad h).elim⟩
  choose A chosen using choosePair
  have F : Frame G P Q D A := by
    refine ⟨apart,filter_subset ..,fun a ad => one a (classify ad).1,?_,right,fun a ad => (chosen a ad).2,?_,?_⟩
    · intro a ap na
      exact Nat.le_of_not_gt (fun bad => na (mem_filter.mpr ⟨ap,bad⟩))
    · intro a ad; exact (free a (classify ad).1 (classify ad).2.1).mono_left (chosen a ad).1
    · intro a ad b bd ab
      apply disjoint_left.mpr
      intro x xa xb
      have am := (mem_filter.mp ((chosen a ad).1 xa)).2
      have bm := (mem_filter.mp ((chosen b bd).1 xb)).2
      exact ab (bm.2 a (classify ad).1 am.1)
  have pinned : E⊆P∪Q := eq'.trans subset_union_right
  apply catalogue_bound G P Q D A F _ quota pinned
  intro a x m xo mo
  apply thin a x m
  · simpa using (fun xe => xo (pinned xe) : x∉E)
  · simpa using (fun me => mo (pinned me) : m∉E)

end Graffiti384b.TriangleFrame
#print axioms Graffiti384b.TriangleFrame.escaping_anchors
