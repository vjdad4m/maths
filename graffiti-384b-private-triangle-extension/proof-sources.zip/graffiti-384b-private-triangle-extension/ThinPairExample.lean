import PrivateTriangleExtension
namespace Graffiti384b.TriangleFrame.Example
open Finset SimpleGraph SixFront Exterior

/-- A square and a triangle joined by a bridge. Vertex 0 is the root in the triangle. -/
def edges : Finset (Fin 7 × Fin 7) := {(0,1),(0,2),(1,2),(0,3),(3,4),(4,5),(5,6),(3,6)}
def graph : SimpleGraph (Fin 7) where
  Adj i j := (i,j)∈edges ∨ (j,i)∈edges
  symm := fun _ _ h => h.symm
  loopless := fun i => (show ∀j : Fin 7, ¬((j,j)∈edges ∨ (j,j)∈edges) by decide) i
instance : DecidableRel graph.Adj := fun i j => inferInstanceAs (Decidable ((i,j)∈edges ∨ (j,i)∈edges))

def left : Finset (Fin 7) := {0,4,6}
def right : Finset (Fin 7) := {3,5}
def reserve (_ : Fin 7) : Finset (Fin 7) := {1,2}

theorem frame : Frame graph left right {0} reserve := by
  refine ⟨by decide,by decide,by decide,by decide,by decide,?_,by decide,?_⟩
  · intro a ha; obtain rfl := mem_singleton.mp ha
    exact ⟨1,2,rfl,by decide,by decide,by decide⟩
  · intro a ha b hb ne
    exact (ne ((mem_singleton.mp ha).trans (mem_singleton.mp hb).symm)).elim

theorem two_thin : trianglesAt graph 1=1 ∧ trianglesAt graph 2=1 := by decide

/-- The triangle pair prevents a protected extension of these prescribed shores. -/
theorem no_extension : ¬Extension graph left right := by
  rintro ⟨P,Q,lp,_,dis,goodP,goodQ⟩
  have ap := lp (show 0∈left by decide)
  have aq := disjoint_left.mp dis ap
  have both {v a b : Fin 7} {S : Finset (Fin 7)} (shape : graph.neighborFinset v={a,b})
      (need : 2≤nbr graph v S) : a∈S ∧ b∈S := by
    have inc : S.filter (graph.Adj v)⊆({a,b}:Finset (Fin 7)) := by
      intro z zh; exact shape ▸ (graph.mem_neighborFinset ..).mpr (mem_filter.mp zh).2
    have eq := eq_of_subset_of_card_le inc (by
      have upper : ({a,b}:Finset (Fin 7)).card≤2 := (card_insert_le ..).trans_eq (by simp)
      exact upper.trans need)
    exact ⟨(mem_filter.mp (eq ▸ mem_insert_self a {b})).1,(mem_filter.mp (eq ▸ mem_insert_of_mem (mem_singleton_self b))).1⟩
  have n1 : graph.neighborFinset 1={0,2} := by decide
  have n2 : graph.neighborFinset 2={0,1} := by decide
  have out1 : 1∉Q := fun h => aq (both n2 (goodP 2 (both n1 (goodQ 1 h)).2)).1
  have out2 : 2∉Q := fun h => aq (both n1 (goodP 1 (both n2 (goodQ 2 h)).2)).1
  have sub : Q.filter (graph.Adj 0)⊆{3} := by
    intro v vm
    obtain ⟨vq,adj⟩ := mem_filter.mp vm
    have choices : ∀i : Fin 7,graph.Adj 0 i → i=1 ∨ i=2 ∨ i=3 := by decide
    rcases choices v adj with rfl|rfl|rfl
    · exact (out1 vq).elim
    · exact (out2 vq).elim
    · exact mem_singleton_self _
  have cap := card_le_card sub
  have low := goodP 0 ap
  change 2≤(Q.filter (graph.Adj 0)).card at low
  rw [card_singleton] at cap; omega

end Graffiti384b.TriangleFrame.Example
#print axioms Graffiti384b.TriangleFrame.Example.frame
#print axioms Graffiti384b.TriangleFrame.Example.two_thin
#print axioms Graffiti384b.TriangleFrame.Example.no_extension
