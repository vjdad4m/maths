import EarNeighborhood
namespace Graffiti384b.TriangleFrame
open Finset SimpleGraph FiveChoice LowSample PinnedColor34
open private Repair.edge_info from Repair384b
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def internalTriangles (a : V) := (link G a).filter (fun p => p⊆anchors G)

/-- At a vertex adjacent to a single ear, there is at most one triangle using an ear.
Together with the absence of an escaping triangle this bounds its full score. -/
theorem trapped_score {a : V} (single : nbr G a (twos G)=1) (trapped : ¬Escapes G a) :
    trianglesAt G a≤1+(internalTriangles G a).card := by
  classical
  obtain ⟨e,eu⟩ := card_eq_one.mp single
  have field {z : V} (ze : z∈twos G) (az : G.Adj a z) : z=e :=
    mem_singleton.mp (eu ▸ mem_filter.mpr ⟨ze,az⟩)
  have unique {p : Finset V} (pm : p∈link G a) (ze : ¬Disjoint p (twos G)) :
      p=insert e ((G.neighborFinset e).erase a) := by
    obtain ⟨z,zp,ze⟩ := not_disjoint_iff.mp ze
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info G pm
    have az := (G.mem_neighborFinset ..).mp (sub zp)
    obtain rfl := field ze az
    obtain ⟨b,bp,ne⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) z
    have zb := cl z zp b bp ne.symm
    have ab := (G.mem_neighborFinset ..).mp (sub bp)
    have inc : ({a,b}:Finset V)⊆G.neighborFinset z :=
      insert_subset ((G.mem_neighborFinset ..).mpr az.symm) (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr zb))
    have eq := eq_of_subset_of_card_le inc (by rw [card_neighborFinset_eq_degree,LowSample.two_degree G ze,card_pair ab.ne])
    have pair := eq_of_subset_of_card_le (insert_subset zp (singleton_subset_iff.mpr bp)) (by rw [sz,card_pair ne.symm])
    rw [←eq,←pair]; simp [ab.ne.symm,ab.ne]
  have sub : link G a⊆insert (insert e ((G.neighborFinset e).erase a)) (internalTriangles G a) := by
    intro p pm
    by_cases pe : Disjoint p (twos G)
    · exact mem_insert_of_mem (mem_filter.mpr ⟨pm,by by_contra pw; exact trapped ⟨p,pm,pe,pw⟩⟩)
    · exact mem_insert.mpr (Or.inl (unique pm pe))
  exact (card_le_card sub).trans ((card_insert_le ..).trans_eq (Nat.add_comm ..))

/-- In any failure satisfying the independent-ear and free thin-pair hypotheses,
some singly exposed anchor has all its non-ear triangles internal to the anchor set. -/
theorem necessary_trap (quota : (types G).card≤(nonleaves G).card)
    (indep : Disjoint (twos G) (anchors G)) (thin : NoThinPair G ∅ (twos G)) (bad : bound G<gamma G) :
    ∃a∈anchors G,nbr G a (twos G)=1 ∧
      (∀p∈link G a,Disjoint p (twos G) → p⊆anchors G) ∧
      trianglesAt G a≤1+(internalTriangles G a).card := by
  classical
  have fail : ¬∀a∈anchors G,nbr G a (twos G)=1 → Escapes G a :=
    fun h => (not_lt_of_ge (escaping_anchors G quota indep thin h)) bad
  push_neg at fail
  obtain ⟨a,aw,one,trapped⟩ := fail
  exact ⟨a,aw,one,fun p pm pe => Classical.byContradiction (fun out => trapped ⟨p,pm,pe,out⟩),trapped_score G one trapped⟩

/-- A triangle outside the degree-two set has rich endpoints if every high vertex lies on
at least two triangles. This uses no restrictions on scores at leaves. -/
theorem no_thin_of_rich (rich : ∀v∈high G,2≤trianglesAt G v) : NoThinPair G ∅ (twos G) := by
  intro a x m xo _ ax am xm
  apply Or.inl
  have cap : 2≤G.degree x := by
    rw [←card_neighborFinset_eq_degree]
    exact one_lt_card.mpr ⟨a,(G.mem_neighborFinset ..).mpr ax.symm,m,(G.mem_neighborFinset ..).mpr xm,am.ne⟩
  apply rich x
  by_contra nx
  have xt : x∈twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,cap⟩,nx⟩
  exact xo (mem_union_right _ xt)

/-- A threshold-free palette corollary. If every ear neighbor is high and their induced graph is
triangle-free, maximal diversity relative to the number of high vertices satisfies #384b. -/
theorem triangle_free_anchors (quota : (types G).card≤(nonleaves G).card)
    (maximal : (types G).card=(high G).card+2) (hi : anchors G⊆high G)
    (free : ∀a∈anchors G,∀x∈anchors G,∀y∈anchors G,G.Adj a x → G.Adj a y → ¬G.Adj x y) :
    gamma G≤bound G := by
  classical
  have rich := (Repair.maximal_diversity G maximal).2.1
  apply Nat.le_of_not_gt
  intro bad
  have indep : Disjoint (twos G) (anchors G) :=
    disjoint_left.mpr (fun z zt za => (mem_sdiff.mp zt).2 (hi za))
  obtain ⟨a,aw,_,_,le⟩ := necessary_trap G quota indep (no_thin_of_rich G rich) bad
  have empty : internalTriangles G a=∅ := eq_empty_of_forall_not_mem (by
    intro p pm
    obtain ⟨hit,inside⟩ := mem_filter.mp pm
    obtain ⟨sub,size,cl⟩ := Repair.edge_info G hit
    obtain ⟨x,y,ne,pair⟩ := card_eq_two.mp size
    have xp : x∈p := pair ▸ mem_insert_self ..
    have yp : y∈p := pair ▸ mem_insert_of_mem (mem_singleton_self _)
    exact free a aw x (inside xp) y (inside yp) ((G.mem_neighborFinset ..).mp (sub xp))
      ((G.mem_neighborFinset ..).mp (sub yp)) (cl x xp y yp ne))
  have lower := rich a (hi aw)
  rw [empty,card_empty] at le
  omega

end Graffiti384b.TriangleFrame
#print axioms Graffiti384b.TriangleFrame.trapped_score
#print axioms Graffiti384b.TriangleFrame.necessary_trap
#print axioms Graffiti384b.TriangleFrame.no_thin_of_rich
#print axioms Graffiti384b.TriangleFrame.triangle_free_anchors
