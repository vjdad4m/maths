import TwoGaps
namespace Graffiti384b.TriangleFrame
open Finset SimpleGraph PrivatePatch SixFront PinnedColor34
open private Repair.nbr_mono from Repair384b
open private PrivatePatch.gain from TwoGaps
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A finite collection of deficient pins on the left, each with a disjoint, reserved triangle. -/
structure Frame (P Q D : Finset V) (A : V → Finset V) : Prop where
  apart : Disjoint P Q
  roots : D⊆P
  one : ∀a∈D,1≤nbr G a Q
  left : ∀a∈P,a∉D → 2≤nbr G a Q
  right : ∀a∈Q,2≤nbr G a P
  privatePair : ∀a∈D,∃x y,A a={x,y} ∧ G.Adj a x ∧ G.Adj a y ∧ G.Adj x y
  free : ∀a∈D,Disjoint (A a) (P∪Q)
  separate : D.toSet.PairwiseDisjoint A

variable {P Q D : Finset V} {A : V → Finset V}

/-- Extend the shores by a protected piece. Only reservations used by this piece must be discharged. -/
theorem Frame.consume (F : Frame G P Q D A) {I J R : Finset V}
    (piece : Piece G P Q I J) (resolved : ∀a∈D,a∈R → Reaches G Q J a)
    (spare : ∀a∈D,a∉R → Disjoint (A a) (I∪J)) :
    Frame G (P∪I) (Q∪J) (D\R) A := by
  have pl : P⊆P∪I := subset_union_left
  have qr : Q⊆Q∪J := subset_union_left
  refine ⟨piece.compat,fun a ha => pl (F.roots (mem_sdiff.mp ha).1),?_,?_,?_,?_,?_,?_⟩
  · intro a ha; exact (F.one a (mem_sdiff.mp ha).1).trans (Repair.nbr_mono G a qr)
  · intro a mem h
    rcases mem_union.mp mem with ap|ai
    · by_cases ad : a∈D
      · have ar : a∈R := by by_contra no; exact h (mem_sdiff.mpr ⟨ad,no⟩)
        exact PrivatePatch.gain G (F.one a ad) (resolved a ad ar)
      · exact (F.left a ap ad).trans (Repair.nbr_mono G a qr)
    · exact piece.left a ai
  · intro a mem; exact (mem_union.mp mem).elim (fun aq => (F.right a aq).trans (Repair.nbr_mono G a pl)) (piece.right a)
  · intro a ha; exact F.privatePair a (mem_sdiff.mp ha).1
  · intro a ha
    obtain ⟨ad,ar⟩ := mem_sdiff.mp ha
    have m := disjoint_union_right.mp (F.free a ad)
    have n := disjoint_union_right.mp (spare a ad ar)
    exact disjoint_union_right.mpr ⟨disjoint_union_right.mpr ⟨m.1,n.1⟩,disjoint_union_right.mpr ⟨m.2,n.2⟩⟩
  · intro a ha b hb ne; exact F.separate (mem_sdiff.mp ha).1 (mem_sdiff.mp hb).1 ne

/-- Move a gap along one reserved triangle and reserve a new free triangle at the new gap. -/
theorem Frame.shift (F : Frame G P Q D A) {a x m u v : V} (ad : a∈D)
    (pair : A a={x,m}) (ax : G.Adj a x) (am : G.Adj a m) (xm : G.Adj x m)
    (xu : G.Adj x u) (xv : G.Adj x v) (uv : G.Adj u v)
    (fresh : ∀z∈({u,v}:Finset V), z∉(P∪Q)∪D.biUnion A) :
    Frame G (insert x P) (insert m Q) (insert x (D.erase a)) (Function.update A x {u,v}) := by
  classical
  have xp : x∈A a := pair ▸ mem_insert_self ..
  have mp : m∈A a := pair ▸ mem_insert_of_mem (mem_singleton_self _)
  have xo := disjoint_left.mp (F.free a ad) xp
  have mo := disjoint_left.mp (F.free a ad) mp
  have xP : x∉P := fun h => xo (mem_union_left _ h)
  have xQ : x∉Q := fun h => xo (mem_union_right _ h)
  have mP : m∉P := fun h => mo (mem_union_left _ h)
  have xD : x∉D := fun h => xP (F.roots h)
  have upin {z : V} (zs : z∈({u,v}:Finset V)) : z∉(insert x P)∪(insert m Q) := by
    have no := fresh z zs
    have far : ∀s∈A a,z≠s := fun s sm eq => no (mem_union_right _ (mem_biUnion.mpr ⟨a,ad,eq ▸ sm⟩))
    simp only [mem_union,mem_insert,not_or]
    exact ⟨⟨far x xp,fun h => no (mem_union_left _ (mem_union_left _ h))⟩,
      far m mp,fun h => no (mem_union_left _ (mem_union_right _ h))⟩
  have sep {b : V} (hb : b∈D.erase a) : Disjoint (A b) (A a) :=
    F.separate (mem_erase.mp hb).2 ad (mem_erase.mp hb).1
  have bne {b : V} (hb : b∈D.erase a) : b≠x := fun eq => xD (eq ▸ (mem_erase.mp hb).2)
  refine ⟨by simpa [disjoint_insert_left,disjoint_insert_right,xm.ne,xm.ne.symm,xQ,mP] using F.apart,?_,?_,?_,?_,?_,?_,?_⟩
  · intro z hz; rcases mem_insert.mp hz with rfl|zb
    · exact mem_insert_self ..
    · exact mem_insert_of_mem (F.roots (mem_erase.mp zb).2)
  · intro z hz; rcases mem_insert.mp hz with rfl|zb
    · exact card_pos.mpr ⟨m,mem_filter.mpr ⟨mem_insert_self ..,xm⟩⟩
    · exact (F.one z (mem_erase.mp zb).2).trans (Repair.nbr_mono G z (subset_insert ..))
  · intro z zp zn
    have zx : z≠x := fun eq => zn (mem_insert.mpr (Or.inl eq))
    have old := (mem_insert.mp zp).resolve_left zx
    by_cases za : z=a
    · subst z
      obtain ⟨i,hi⟩ := card_pos.mp (F.one a ad)
      obtain ⟨iq,ai⟩ := mem_filter.mp hi
      exact two G (a:=i) (b:=m) (fun eq => mo (mem_union_right _ (eq ▸ iq))) ai am (mem_insert_of_mem iq) (mem_insert_self ..)
    · exact (F.left z old (fun h => zn (mem_insert_of_mem (mem_erase.mpr ⟨za,h⟩)))).trans (Repair.nbr_mono G z (subset_insert ..))
  · intro z hz; rcases mem_insert.mp hz with rfl|zq
    · exact two G (a:=a) (b:=x) ax.ne am.symm xm.symm (mem_insert_of_mem (F.roots ad)) (mem_insert_self ..)
    · exact (F.right z zq).trans (Repair.nbr_mono G z (subset_insert ..))
  · intro b hb; rcases mem_insert.mp hb with rfl|hb
    · exact ⟨u,v,Function.update_self ..,xu,xv,uv⟩
    · rw [Function.update_of_ne (bne hb)]
      exact F.privatePair b (mem_erase.mp hb).2
  · intro b hb; rcases mem_insert.mp hb with rfl|hb
    · rw [Function.update_self]; exact disjoint_left.mpr (fun _ h => upin h)
    · rw [Function.update_of_ne (bne hb)]
      apply disjoint_left.mpr
      intro z zb hz
      have old := disjoint_left.mp (F.free b (mem_erase.mp hb).2) zb
      have no := disjoint_left.mp (sep hb) zb
      rcases mem_union.mp hz with h|h <;> rcases mem_insert.mp h with rfl|h
      · exact no xp
      · exact old (mem_union_left _ h)
      · exact no mp
      · exact old (mem_union_right _ h)
  · have dis {b : V} (hb : b∈D.erase a) : Disjoint ({u,v}:Finset V) (A b) :=
      disjoint_left.mpr (fun z hz zb => fresh z hz (mem_union_right _ (mem_biUnion.mpr ⟨b,(mem_erase.mp hb).2,zb⟩)))
    intro b hb c hc ne
    change b∈insert x (D.erase a) at hb
    change c∈insert x (D.erase a) at hc
    change Disjoint (Function.update A x {u,v} b) (Function.update A x {u,v} c)
    by_cases bx : b=x
    · subst b
      have cold := (mem_insert.mp hc).resolve_left ne.symm
      simpa [Function.update_of_ne ne.symm] using dis cold
    · have bold := (mem_insert.mp hb).resolve_left bx
      by_cases cx : c=x
      · subst c; simpa [Function.update_of_ne bx] using (dis bold).symm
      · have cold := (mem_insert.mp hc).resolve_left cx
        rw [Function.update_of_ne bx,Function.update_of_ne cx]
        exact F.separate (mem_erase.mp bold).2 (mem_erase.mp cold).2 ne

end Graffiti384b.TriangleFrame
#print axioms Graffiti384b.TriangleFrame.Frame.consume
#print axioms Graffiti384b.TriangleFrame.Frame.shift
