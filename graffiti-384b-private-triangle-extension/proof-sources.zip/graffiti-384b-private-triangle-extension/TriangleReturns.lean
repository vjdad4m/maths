import TriangleFrame
namespace Graffiti384b.TriangleFrame
open Finset SimpleGraph PrivatePatch
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
variable {P Q D : Finset V} {A : V→Finset V} {a x m : V}

/-- Maximality hypothesis used only inside the finite extension proof. -/
def Terminal (P Q : Finset V) : Prop := ∀ (L R T : Finset V) (B : V→Finset V),
  P⊆L → Q⊆R → (∃v∈L∪R,v∉P∪Q) → Frame G L R T B → False

theorem Frame.owner (F : Frame G P Q D A) {a b z : V} (ad : a∈D) (bd : b∈D)
    (za : z∈A a) (zb : z∈A b) : b=a := by
  by_contra ne
  exact disjoint_left.mp (F.separate bd ad ne) zb za

private theorem reject (F : Frame G P Q D A) (T : Terminal G P Q)
    {I J R : Finset V} (piece : Piece G P Q I J)
    (hit : ∀b∈D,b∈R → Reaches G Q J b)
    (owners : ∀b∈D,∀z∈A b,z∈I∪J → b∈R) {z : V} (zj : z∈J) (zo : z∉P∪Q) : False := by
  apply T (P∪I) (Q∪J) (D\R) A subset_union_left subset_union_left
    ⟨z,mem_union_right _ (mem_union_right _ zj),zo⟩
  exact F.consume G piece hit (fun b bd bn => disjoint_left.mpr (fun v vb vh => bn (owners b bd v vb vh)))

/-- Every neighbor of a reserved point in the old shores is its own root. -/
theorem Frame.only_pin (F : Frame G P Q D A) (T : Terminal G P Q) (ad : a∈D)
    (xa : x∈A a) (ma : m∈A a) (ax : G.Adj a x) (am : G.Adj a m) (xm : G.Adj x m)
    {z : V} (xz : G.Adj x z) (zp : z∈P∪Q) : z=a := by
  by_contra ne
  have xo := disjoint_left.mp (F.free a ad) xa
  have mo := disjoint_left.mp (F.free a ad) ma
  rcases mem_union.mp zp with zl|zr
  · apply reject G F T (R:={a}) (piece_two G F.apart (F.roots ad) zl xo (Ne.symm ne) ax xz) ?_ ?_ (mem_singleton_self x) xo
    · intro b _ eq; obtain rfl := mem_singleton.mp eq
      exact ⟨x,mem_singleton_self _,fun h => xo (mem_union_right _ h),ax⟩
    · intro b bd z zb hz
      have eq : z=x := by simpa using hz
      exact mem_singleton.mpr (F.owner G ad bd xa (eq ▸ zb))
  · apply reject G F T (R:={a}) (piece_three G F.apart (F.roots ad) zr mo xo am xm.symm xz) ?_ ?_ (mem_singleton_self m) mo
    · intro b _ eq; obtain rfl := mem_singleton.mp eq
      exact ⟨m,mem_singleton_self _,fun h => mo (mem_union_right _ h),am⟩
    · intro b bd z zb hz
      simp only [mem_union,mem_singleton] at hz
      rcases hz with rfl|rfl
      · exact mem_singleton.mpr (F.owner G ad bd xa zb)
      · exact mem_singleton.mpr (F.owner G ad bd ma zb)

/-- An edge to a different reservation would discharge both roots. -/
theorem Frame.only_reserve (F : Frame G P Q D A) (T : Terminal G P Q) (ad : a∈D)
    (xa : x∈A a) (ma : m∈A a) (am : G.Adj a m) (xm : G.Adj x m)
    {b z : V} (bd : b∈D) (zb : z∈A b) (xz : G.Adj x z) : b=a := by
  by_contra ba
  obtain ⟨u,v,pair,bu,bv,_⟩ := F.privatePair b bd
  have bz : G.Adj b z := by rw [pair,mem_insert,mem_singleton] at zb; rcases zb with rfl|rfl <;> assumption
  have xo := disjoint_left.mp (F.free a ad) xa
  have mo := disjoint_left.mp (F.free a ad) ma
  have zo := disjoint_left.mp (F.free b bd) zb
  have mz : m≠z := fun eq => ba (F.owner G ad bd ma (eq ▸ zb))
  apply reject G F T (R:={a,b}) (piece_four G F.apart (F.roots ad) (F.roots bd) mo xo zo mz am xm.symm xz bz.symm)
    ?_ ?_ (mem_insert_self m {z}) mo
  · intro c _ hc; rcases mem_insert.mp hc with rfl|hc
    · exact ⟨m,mem_insert_self ..,fun h => mo (mem_union_right _ h),am⟩
    · obtain rfl := mem_singleton.mp hc
      exact ⟨z,mem_insert_of_mem (mem_singleton_self _),fun h => zo (mem_union_right _ h),bz⟩
  · intro c cd w wc hw
    simp only [mem_union,mem_insert,mem_singleton] at hw ⊢
    rcases hw with rfl|rfl|rfl
    · exact Or.inl (F.owner G ad cd xa wc)
    · exact Or.inl (F.owner G ad cd ma wc)
    · exact Or.inr (F.owner G bd cd zb wc)

/-- Every neighbor of x other than a and m is exterior to all pins and reservations. -/
theorem Frame.exterior (F : Frame G P Q D A) (T : Terminal G P Q) (ad : a∈D)
    (pair : A a={x,m}) (ax : G.Adj a x) (am : G.Adj a m) (xm : G.Adj x m)
    {z : V} (xz : G.Adj x z) (za : z≠a) (zm : z≠m) : z∉(P∪Q)∪D.biUnion A := by
  have xa : x∈A a := pair ▸ mem_insert_self ..
  have ma : m∈A a := pair ▸ mem_insert_of_mem (mem_singleton_self _)
  intro h; rcases mem_union.mp h with zp|zr
  · exact za (F.only_pin G T ad xa ma ax am xm xz zp)
  · obtain ⟨b,bd,zb⟩ := mem_biUnion.mp zr
    obtain rfl := F.only_reserve G T ad xa ma am xm bd zb xz
    rw [pair,mem_insert,mem_singleton] at zb
    exact zb.elim xz.ne.symm zm

/-- Returning from an exterior neighbor to the root or the mate gives a protected square. -/
theorem Frame.no_return (F : Frame G P Q D A) (T : Terminal G P Q) (ad : a∈D)
    (pair : A a={x,m}) (ax : G.Adj a x) (am : G.Adj a m) (xm : G.Adj x m)
    {z : V} (xz : G.Adj x z) (za : z≠a) (zm : z≠m) : ¬(G.Adj a z ∨ G.Adj m z) := by
  have xa : x∈A a := pair ▸ mem_insert_self ..
  have ma : m∈A a := pair ▸ mem_insert_of_mem (mem_singleton_self _)
  have xo := disjoint_left.mp (F.free a ad) xa
  have mo := disjoint_left.mp (F.free a ad) ma
  have outside := F.exterior G T ad pair ax am xm xz za zm
  have zo : z∉P∪Q := fun h => outside (mem_union_left _ h)
  have no {b : V} (bd : b∈D) : z∉A b := fun zb => outside (mem_union_right _ (mem_biUnion.mpr ⟨b,bd,zb⟩))
  have owner {b w : V} (bd : b∈D) (wb : w∈A b) (hw : w=x ∨ w=m ∨ w=z) : b∈({a}:Finset V) := by
    rcases hw with rfl|rfl|rfl
    · exact mem_singleton.mpr (F.owner G ad bd xa wb)
    · exact mem_singleton.mpr (F.owner G ad bd ma wb)
    · exact (no bd wb).elim
  rintro (az|mz)
  · apply reject G F T (R:={a}) (piece_four G F.apart (F.roots ad) (F.roots ad) mo xo zo zm.symm am xm.symm xz az.symm)
      ?_ ?_ (mem_insert_self m {z}) mo
    · intro b _ eq; obtain rfl := mem_singleton.mp eq
      exact ⟨m,mem_insert_self ..,fun h => mo (mem_union_right _ h),am⟩
    · intro b bd w wb hw
      simp only [mem_union,mem_insert,mem_singleton] at hw
      exact owner bd wb (by rcases hw with h|h|h <;> simp [h])
  · apply reject G F T (R:={a}) (piece_four G F.apart (F.roots ad) (F.roots ad) xo zo mo xm.ne ax xz mz.symm am.symm)
      ?_ ?_ (mem_insert_self x {m}) xo
    · intro b _ eq; obtain rfl := mem_singleton.mp eq
      exact ⟨x,mem_insert_self ..,fun h => xo (mem_union_right _ h),ax⟩
    · intro b bd w wb hw
      simp only [mem_union,mem_insert,mem_singleton] at hw
      exact owner bd wb (by rcases hw with h|h|h <;> simp [h])

end Graffiti384b.TriangleFrame
#print axioms Graffiti384b.TriangleFrame.Frame.exterior
#print axioms Graffiti384b.TriangleFrame.Frame.no_return
