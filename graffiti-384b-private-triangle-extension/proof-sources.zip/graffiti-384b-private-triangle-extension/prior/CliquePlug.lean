import CubicMove
import CubicAnchor33
namespace Graffiti384b.FreeGap
open Finset SimpleGraph Exterior SixFront
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem two_parts {P Q K : Finset V} (dis : Disjoint P Q) (size : K.card=4)
    (lp : (K∩P).card≤2) (rq : (K∩Q).card≤2) :
    ∃L R,K=L∪R ∧ L.card=2 ∧ R.card=2 ∧ Disjoint (P∪L) (Q∪R) := by
  have sub : K∩P⊆K\Q := fun v m => mem_sdiff.mpr ⟨(mem_inter.mp m).1,
    fun q => disjoint_left.mp dis (mem_inter.mp m).2 q⟩
  have room := card_sdiff_add_card_inter K Q
  obtain ⟨L,pl,lk,sz⟩ := exists_subsuperset_card_eq sub lp (by omega : 2≤(K\Q).card)
  have inc := lk.trans (sdiff_subset (s:=K) (t:=Q))
  refine ⟨L,K\L,(union_sdiff_of_subset inc).symm,sz,by rw [card_sdiff inc,size,sz],?_⟩
  apply disjoint_left.mpr
  intro v vl vr
  rcases mem_union.mp vl with vp|vl <;> rcases mem_union.mp vr with vq|vr
  · exact disjoint_left.mp dis vp vq
  · exact (mem_sdiff.mp vr).2 (pl (mem_inter.mpr ⟨(mem_sdiff.mp vr).1,vp⟩))
  · exact (mem_sdiff.mp (lk vl)).2 vq
  · exact (mem_sdiff.mp vr).2 vl

private theorem spare {a s : V} {Q R : Finset V} (one : 1≤nbr G a Q)
    (fresh : s∉Q) (sr : s∈R) (edge : G.Adj a s) : 2≤nbr G a (Q∪R) := by
  obtain ⟨u,um⟩ := card_pos.mp one
  obtain ⟨uq,au⟩ := mem_filter.mp um
  exact PinnedColor34.two G (a:=u) (b:=s) (fun eq => fresh (eq ▸ uq)) au edge (mem_union_left _ uq) (mem_union_right _ sr)

private theorem glue {P Q L R : Finset V} {a : V} (H : Gap G P Q a)
    (dis : Disjoint (P∪L) (Q∪R)) (ready : 2≤nbr G a (Q∪R))
    (lp : ∀v∈L,2≤nbr G v (Q∪R)) (rq : ∀v∈R,2≤nbr G v (P∪L)) : Extension G P Q := by
  refine ⟨P∪L,Q∪R,subset_union_left,subset_union_left,dis,?_,?_⟩
  · intro v vm
    rcases mem_union.mp vm with m|m
    · by_cases eq : v=a
      · exact eq ▸ ready
      · exact (H.left v m eq).trans (Repair.nbr_mono G v subset_union_left)
    · exact lp v m
  · intro v vm
    exact (mem_union.mp vm).elim (fun m => (H.right v m).trans (Repair.nbr_mono G v subset_union_left)) (rq v)

/-- Two unpinned members of a four-clique leave room for a compatible
two-by-two coloring. A free triangle carries either color back to the gap. -/
theorem clique_plug [Fintype V] {P Q K : Finset V} {a x y v : V} (H : Gap G P Q a)
    (four : K.card=4) (edges : ∀u∈K,∀w∈K,u≠w → G.Adj u w)
    (xk : x∈K) (vk : v∈K) (vx : v≠x)
    (xo : x∉P∪Q) (yo : y∉P∪Q) (vo : v∉P∪Q)
    (ax : G.Adj a x) (ay : G.Adj a y) (xy : G.Adj x y)
    (ends : v=y → a∈K) : Extension G P Q := by
  classical
  let F : Finset V := {v,x}
  have fk : F⊆K := insert_subset vk (singleton_subset_iff.mpr xk)
  have fresh : Disjoint F (P∪Q) := disjoint_left.mpr (by
    intro u um; rcases mem_insert.mp um with rfl|last
    · exact vo
    · exact mem_singleton.mp last ▸ xo)
  have cap (S : Finset V) (ss : S⊆P∪Q) : (K∩S).card≤2 := by
    have inc : K∩S⊆K\F := fun u m => mem_sdiff.mpr ⟨(mem_inter.mp m).1,
      fun b => disjoint_left.mp fresh b (ss (mem_inter.mp m).2)⟩
    have le := card_le_card inc
    rw [card_sdiff fk,show F.card=2 from card_pair vx,four] at le
    exact le
  obtain ⟨L,R,split,twoL,twoR,dis⟩ := two_parts H.apart four (cap P subset_union_left) (cap Q subset_union_right)
  have lr : Disjoint L R := dis.mono subset_union_right subset_union_right
  have enough (A B : Finset V) (ab : Disjoint A B) (ak : A⊆K) (bk : B⊆K) (cnt : B.card=2) (u : V) (um : u∈A) :
      2≤nbr G u B := by
    rw [nbr,filter_true_of_mem (fun w wm => edges u (ak um) w (bk wm) (fun eq => disjoint_left.mp ab um (eq ▸ wm))),cnt]
  have lk : L⊆K := split ▸ subset_union_left
  have rk : R⊆K := split ▸ subset_union_right
  have lp (u : V) (um : u∈L) := (enough L R lr lk rk twoR u um).trans (Repair.nbr_mono G u (subset_union_right (s₁:=Q)))
  have rq (u : V) (um : u∈R) := (enough R L lr.symm rk lk twoL u um).trans (Repair.nbr_mono G u (subset_union_right (s₁:=P)))
  by_cases ak : a∈K
  · have al : a∈L := (mem_union.mp (split ▸ ak)).resolve_right (fun ar =>
      disjoint_left.mp dis (mem_union_left _ H.pinned) (mem_union_right _ ar))
    exact glue G H dis (lp a al) lp rq
  by_cases yk : y∈K
  · have vy : v≠y := fun eq => ak (ends eq)
    exact four_steps G H disjoint_compl_right (mem_compl.mpr xo) (mem_compl.mpr vo) (mem_compl.mpr yo)
      H.pinned xy.ne ax (edges x xk v vk vx.symm) (edges v vk y yk vy) ay.symm
  rcases mem_union.mp (split ▸ xk) with xl|xr
  · have yl : y∉P∪L := fun m => (mem_union.mp m).elim (fun yp => yo (mem_union_left _ yp)) (fun yL => yk (lk yL))
    have compat : Disjoint (P∪L) (Q∪insert y R) := by
      apply disjoint_left.mpr
      intro u um ur
      rcases mem_union.mp ur with uq|ui
      · exact disjoint_left.mp dis um (mem_union_left _ uq)
      · rcases mem_insert.mp ui with rfl|uR
        · exact yl um
        · exact disjoint_left.mp dis um (mem_union_right _ uR)
    exact glue G H compat (spare G H.one (fun m => yo (mem_union_right _ m)) (mem_insert_self ..) ay)
      (fun u um => (lp u um).trans (Repair.nbr_mono G u (union_subset_union_right (subset_insert ..))))
      (fun u um => (mem_insert.mp um).elim (fun eq => eq ▸
        PinnedColor34.two G ax.ne ay.symm xy.symm (mem_union_left _ H.pinned) (mem_union_right _ xl)) (rq u))
  · exact glue G H dis (spare G H.one (fun m => xo (mem_union_right _ m)) xr ax) lp rq
end Graffiti384b.FreeGap
#print axioms Graffiti384b.FreeGap.clique_plug
