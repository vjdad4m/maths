import CliquePlug
namespace Graffiti384b.FreeGap
open Finset SimpleGraph PinnedColor34 Exterior Four29 LowSample SixFront
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem blocked_by_clique {P Q : Finset V} {a x y v : V} (H : Gap G P Q a)
    (dg : G.degree v=3) (sc : trianglesAt G v=3) (vx : G.Adj v x) (vo : v∉P∪Q)
    (xo : x∉P∪Q) (yo : y∉P∪Q) (ax : G.Adj a x) (ay : G.Adj a y) (xy : G.Adj x y) :
    Extension G P Q := by
  classical
  let K := insert v (G.neighborFinset v)
  have size : K.card=4 := by simp [K,card_neighborFinset_eq_degree,dg]
  apply clique_plug G H size ?_ (mem_insert_of_mem ((G.mem_neighborFinset ..).mpr vx)) (mem_insert_self ..)
    vx.ne xo yo vo ax ay xy (by rintro rfl; exact mem_insert_of_mem ((G.mem_neighborFinset ..).mpr ay.symm))
  · intro s sm t tm ne
    rcases mem_insert.mp sm with rfl|vs
    · rcases mem_insert.mp tm with rfl|vt
      · exact (ne rfl).elim
      · exact (G.mem_neighborFinset ..).mp vt
    · rcases mem_insert.mp tm with rfl|vt
      · exact ((G.mem_neighborFinset ..).mp vs).symm
      · exact EarAnchor.full_neighbors G dg sc ((G.mem_neighborFinset ..).mp vs) ((G.mem_neighborFinset ..).mp vt) ne

/-- A single deficient pin with two free vertices completing a triangle suffices,
at any contact count and without a triangle-count hypothesis on the pin. -/
theorem free_triangle {P Q : Finset V} {e f a x y : V} (D : Data G e f)
    (quota : (types G).card≤(nonleaves G).card) (H : Gap G P Q a)
    (ep : e∈P∪Q) (fp : f∈P∪Q)
    (xo : x∉P∪Q) (yo : y∉P∪Q) (ax : G.Adj a x) (ay : G.Adj a y) (xy : G.Adj x y) :
    gamma G≤bound G := by
  classical
  have highFree (v : V) (vn : v∈nonleaves G) (vp : v∉P) (vq : v∉Q) : v∈high G := by
    by_contra hi
    have m : v∈twos G := mem_sdiff.mpr ⟨vn,hi⟩
    rw [D.earSet,mem_insert,mem_singleton] at m
    exact (mem_union.mp (m.elim (fun eq => eq ▸ ep) (fun eq => eq ▸ fp))).elim vp vq
  have deg (v : V) (vn : v∈nonleaves G) (vp : v∉P) (vq : v∉Q) :=
    (mem_filter.mp (highFree v vn vp vq)).2
  let safe := fun s : V => ∀v∈nonleaves G,v∉P → v∉Q → G.Adj v s → 4≤G.degree v
  have move {s w : V} (so : s∉P∪Q) (wo : w∉P∪Q) (as' : G.Adj a s) (aw : G.Adj a w)
      (sw : G.Adj s w) (ok : safe s) : gamma G≤bound G :=
    safe_repair G H.apart quota deg ok H.left H.right H.one H.pinned
      (fun m => so (mem_union_left _ m)) (fun m => so (mem_union_right _ m))
      (fun m => wo (mem_union_right _ m)) as' aw sw
  by_cases sx : safe x
  · exact move xo yo ax ay xy sx
  by_cases sy : safe y
  · exact move yo xo ay ax xy.symm sy
  dsimp [safe] at sx sy
  push_neg at sx sy
  obtain ⟨u,un,up,uq,ux,du⟩ := sx
  obtain ⟨v,vn,vp,vq,vy,dv⟩ := sy
  have cub {s : V} (sn : s∈nonleaves G) (sp : s∉P) (sq : s∉Q) (d : G.degree s<4) :
      G.degree s=3 ∧ (trianglesAt G s=2 ∨ trianglesAt G s=3) := by
    have low := deg s sn sp sq
    have cap := Repair.triangles_le_choose G s
    have rich := D.rich s (highFree s sn sp sq)
    have dg : G.degree s=3 := by omega
    rw [dg,show (3:ℕ).choose 2=3 by decide] at cap
    exact ⟨dg,by omega⟩
  have out {s : V} (sp : s∉P) (sq : s∉Q) : s∉P∪Q := fun m => (mem_union.mp m).elim sp sq
  obtain ⟨ud,u2|u3⟩ := cub un up uq du
  · obtain ⟨vd,v2|v3⟩ := cub vn vp vq dv
    · have eq := D.scoreInj (highFree u un up uq) (highFree v vn vp vq) (u2.trans v2.symm)
      subst v
      have um : u∈(P∪Q)ᶜ := mem_compl.mpr (fun m => (mem_union.mp m).elim up uq)
      apply extension_bound G D quota ep fp
      exact four_steps G H disjoint_compl_right (mem_compl.mpr xo) um (mem_compl.mpr yo)
        H.pinned xy.ne ax ux.symm vy ay.symm
    · exact extension_bound G D quota ep fp
        (blocked_by_clique G H vd v3 vy (out vp vq) yo xo ay ax xy.symm)
  · exact extension_bound G D quota ep fp (blocked_by_clique G H ud u3 ux (out up uq) xo yo ax ay xy)
end Graffiti384b.FreeGap
#print axioms Graffiti384b.FreeGap.free_triangle
