import WeakRootPatch
namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph PinnedColor34 Exterior SixFront Four29
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

structure TwoGaps (P Q : Finset V) (a b : V) : Prop where
  apart : Disjoint P Q
  aLeft : a∈P
  bLeft : b∈P
  aOne : 1≤nbr G a Q
  bOne : 1≤nbr G b Q
  left : ∀v∈P,v≠a → v≠b → 2≤nbr G v Q
  right : ∀v∈Q,2≤nbr G v P

omit [DecidableEq V] in
theorem TwoGaps.swap {P Q : Finset V} {a b : V} (H : TwoGaps G P Q a b) : TwoGaps G P Q b a :=
  ⟨H.apart,H.bLeft,H.aLeft,H.bOne,H.aOne,fun v vm vb va => H.left v vm va vb,H.right⟩

structure Piece (P Q I J : Finset V) : Prop where
  compat : Disjoint (P∪I) (Q∪J)
  left : ∀v∈I,2≤nbr G v (Q∪J)
  right : ∀v∈J,2≤nbr G v (P∪I)

def Reaches (Q J : Finset V) (a : V) := ∃x∈J,x∉Q ∧ G.Adj a x

private theorem gain {Q J : Finset V} {a : V} (one : 1≤nbr G a Q) (extra : Reaches G Q J a) :
    2≤nbr G a (Q∪J) := by
  obtain ⟨z,zm⟩ := card_pos.mp one
  obtain ⟨x,xj,xq,ax⟩ := extra
  obtain ⟨zq,az⟩ := mem_filter.mp zm
  exact two G (a:=z) (b:=x) (fun eq => xq (eq ▸ zq)) az ax (mem_union_left _ zq) (mem_union_right _ xj)

theorem extend_one {P Q I J : Finset V} {a b : V} (H : TwoGaps G P Q a b)
    (D : Piece G P Q I J) (extra : Reaches G Q J a) : Gap G (P∪I) (Q∪J) b := by
  refine ⟨D.compat,mem_union_left _ H.bLeft,H.bOne.trans (Repair.nbr_mono G b subset_union_left),?_,?_⟩
  · intro v vm vb
    rcases mem_union.mp vm with p|i
    · by_cases eq : v=a
      · exact eq ▸ gain G H.aOne extra
      · exact (H.left v p eq vb).trans (Repair.nbr_mono G v subset_union_left)
    · exact D.left v i
  · intro v vm
    exact (mem_union.mp vm).elim (fun q => (H.right v q).trans (Repair.nbr_mono G v subset_union_left)) (D.right v)

theorem extend_both {P Q I J : Finset V} {a b : V} (H : TwoGaps G P Q a b)
    (D : Piece G P Q I J) (ae : Reaches G Q J a) (be : Reaches G Q J b) : Extension G P Q := by
  have B := extend_one G H D ae
  refine ⟨P∪I,Q∪J,subset_union_left,subset_union_left,D.compat,?_,B.right⟩
  intro v vm
  by_cases eq : v=b
  · exact eq ▸ gain G H.bOne be
  · exact B.left v vm eq

private theorem compatible {P Q I J : Finset V} (dis : Disjoint P Q)
    (off : Disjoint (P∪Q) (I∪J)) (ij : Disjoint I J) : Disjoint (P∪I) (Q∪J) := by
  simp only [disjoint_union_left,disjoint_union_right]
  exact ⟨⟨dis,(off.mono subset_union_right subset_union_left).symm⟩,off.mono subset_union_left subset_union_right,ij⟩

theorem piece_two {P Q : Finset V} {a x r : V} (dis : Disjoint P Q) (ap : a∈P) (rp : r∈P)
    (xo : x∉P∪Q) (ar : a≠r) (ax : G.Adj a x) (xr : G.Adj x r) : Piece G P Q ∅ {x} := by
  refine ⟨compatible dis (by simpa using xo) (by simp),by simp,?_⟩
  intro v vm; obtain rfl := mem_singleton.mp vm
  exact two G ar ax.symm xr (mem_union_left _ ap) (mem_union_left _ rp)

theorem piece_three {P Q : Finset V} {a x y r : V} (dis : Disjoint P Q) (ap : a∈P) (rq : r∈Q)
    (xo : x∉P∪Q) (yo : y∉P∪Q) (ax : G.Adj a x) (xy : G.Adj x y) (yr : G.Adj y r) :
    Piece G P Q {y} {x} := by
  have ay : a≠y := fun eq => yo (mem_union_left _ (eq ▸ ap))
  have rx : r≠x := fun eq => xo (mem_union_right _ (eq ▸ rq))
  refine ⟨compatible dis (by simp [xo,yo]) (by simp [xy.ne.symm,xy.ne]),?_,?_⟩
  · intro v vm; obtain rfl := mem_singleton.mp vm
    exact two G rx yr xy.symm (mem_union_left _ rq) (mem_union_right _ (by simp))
  · intro v vm; obtain rfl := mem_singleton.mp vm
    exact two G ay ax.symm xy (mem_union_left _ ap) (mem_union_right _ (by simp))

theorem piece_four {P Q : Finset V} {a x y z b : V} (dis : Disjoint P Q) (ap : a∈P) (bp : b∈P)
    (xo : x∉P∪Q) (yo : y∉P∪Q) (zo : z∉P∪Q) (xz : x≠z)
    (ax : G.Adj a x) (xy : G.Adj x y) (yz : G.Adj y z) (zb : G.Adj z b) :
    Piece G P Q {y} {x,z} := by
  have ay : a≠y := fun eq => yo (mem_union_left _ (eq ▸ ap))
  have by' : b≠y := fun eq => yo (mem_union_left _ (eq ▸ bp))
  refine ⟨compatible dis (by simp [xo,yo,zo]) (by simp [xy.ne,yz.ne.symm]),?_,?_⟩
  · intro v vm; obtain rfl := mem_singleton.mp vm
    exact two G xz xy.symm yz (mem_union_right _ (by simp)) (mem_union_right _ (by simp))
  · intro v vm; rcases mem_insert.mp vm with rfl|zm
    · exact two G ay ax.symm xy (mem_union_left _ ap) (mem_union_right _ (by simp))
    · obtain rfl := mem_singleton.mp zm
      exact two G by' zb yz.symm (mem_union_left _ bp) (mem_union_right _ (by simp))
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.extend_one
#print axioms Graffiti384b.PrivatePatch.extend_both
#print axioms Graffiti384b.PrivatePatch.piece_two
#print axioms Graffiti384b.PrivatePatch.piece_three
#print axioms Graffiti384b.PrivatePatch.piece_four
