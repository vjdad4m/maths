import FreeTriangle
import ChoicePatch

namespace Graffiti384b.PrivatePatch
open Finset SimpleGraph LowSample Four29 PinnedColor34 Exterior
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Points of C seeing the anchor a and no other anchor in W. -/
def privateAt (W C : Finset V) (a : V) :=
  C.filter (fun x => G.Adj a x ∧ ∀b∈W,G.Adj b x → b=a)

def shared (W C : Finset V) := C.filter (fun x => 2≤nbr G x W)

/-- A private path of length two makes a four-cycle through the anchor. -/
def PathAt (A : Finset V) := ∃ x∈A,∃ y∈A,∃ z∈A,x≠z ∧ G.Adj x y ∧ G.Adj y z

def Weak (W C : Finset V) (a : V) := (∀x∈shared G W C,¬G.Adj a x) ∧ ¬PathAt G (privateAt G W C a)

private theorem patch (W C : Finset V) (a : V) :
    ∃I J : Finset V,I⊆privateAt G W C a ∧ J⊆privateAt G W C a ∧ Disjoint I J ∧
      (∀v∈I,2≤nbr G v J) ∧ (∀v∈J,2≤nbr G v (insert a I)) ∧
      (PathAt G (privateAt G W C a) → ∃z∈J,G.Adj a z) ∧
      (¬PathAt G (privateAt G W C a) → I=∅ ∧ J=∅) := by
  classical
  by_cases any : PathAt G (privateAt G W C a)
  · obtain ⟨x,xi,y,yi,z,zi,xz,xy,yz⟩ := any
    have ax := (mem_filter.mp xi).2.1
    have ay := (mem_filter.mp yi).2.1
    have az := (mem_filter.mp zi).2.1
    refine ⟨{y},{x,z},singleton_subset_iff.mpr yi,insert_subset xi (singleton_subset_iff.mpr zi),
      by simp [xy.ne,yz.ne.symm],?_,?_,fun _ => ⟨x,by simp,ax⟩,fun no => (no ⟨x,xi,y,yi,z,zi,xz,xy,yz⟩).elim⟩
    · intro v vm; obtain rfl := mem_singleton.mp vm
      exact two G xz xy.symm yz (by simp) (by simp)
    · intro v vm
      rcases mem_insert.mp vm with rfl|vm
      · exact two G ay.ne ax.symm xy (by simp) (by simp)
      · obtain rfl := mem_singleton.mp vm
        exact two G ay.ne az.symm yz.symm (by simp) (by simp)
  · exact ⟨∅,∅,empty_subset _,empty_subset _,by simp,by simp,by simp,fun h => (any h).elim,by simp⟩

/-- Pin shared contacts opposite every root, and pin a private four-cycle at
each root admitting one. Different private regions cannot conflict. -/
theorem assemble {W C E : Finset V} (wc : Disjoint W C) (we : Disjoint W E) (ec : Disjoint E C)
    (ears : ∀v∈E,2≤nbr G v W) (touch : ∀a∈W,∃v∈E,G.Adj a v) :
    ∃P Q, W⊆P ∧ E⊆Q ∧ Disjoint P Q ∧
      (∀v∈Q,2≤nbr G v P) ∧ (∀v∈P, v∉W ∨ ¬Weak G W C v → 2≤nbr G v Q) ∧
      (∀a∈W,1≤nbr G a Q) ∧
      (∀a∈W,Weak G W C a → Disjoint (privateAt G W C a) (P∪Q)) := by
  classical
  choose I J ii jj ij gi gj hit empty using patch G W C
  let L := W.biUnion I
  let R := W.biUnion J
  let S := shared G W C
  let P := W∪L
  let Q := E∪S∪R
  have wp : W⊆P := subset_union_left
  have eq' : E⊆Q := fun x m => mem_union_left _ (mem_union_left _ m)
  have sq : S⊆Q := fun x m => mem_union_left _ (mem_union_right _ m)
  have rq : R⊆Q := subset_union_right
  have ip {a : V} (aw : a∈W) : I a⊆P := fun v m => mem_union_right _ (mem_biUnion.mpr ⟨a,aw,m⟩)
  have jq {a : V} (aw : a∈W) : J a⊆Q := fun v m => rq (mem_biUnion.mpr ⟨a,aw,m⟩)
  have apart {u a b : V} (aw : a∈W) (ua : u∈privateAt G W C a) (ub : u∈privateAt G W C b) : a=b :=
    (mem_filter.mp ub).2.2 a aw (mem_filter.mp ua).2.1
  have ns {a u : V} (ua : u∈privateAt G W C a) : u∉S := by
    intro sm
    have sub : W.filter (G.Adj u)⊆{a} := fun b m => mem_singleton.mpr ((mem_filter.mp ua).2.2 b
      (mem_filter.mp m).1 (mem_filter.mp m).2.symm)
    have le := card_le_card sub
    have ge := (mem_filter.mp sm).2
    change 2≤(W.filter (G.Adj u)).card at ge
    simp at le; omega
  have separate : Disjoint P Q := by
    apply disjoint_left.mpr; intro u up uq
    rcases mem_union.mp up with uw|ul
    · rcases mem_union.mp uq with es|ur
      · rcases mem_union.mp es with ue|us
        · exact disjoint_left.mp we uw ue
        · exact disjoint_left.mp wc uw (mem_filter.mp us).1
      · obtain ⟨a,_,um⟩ := mem_biUnion.mp ur
        exact disjoint_left.mp wc uw (mem_filter.mp (jj a um)).1
    · obtain ⟨a,aw,um⟩ := mem_biUnion.mp ul
      have ua := ii a um
      rcases mem_union.mp uq with es|ur
      · rcases mem_union.mp es with ue|us
        · exact disjoint_left.mp ec ue (mem_filter.mp ua).1
        · exact ns ua us
      · obtain ⟨b,_,uj⟩ := mem_biUnion.mp ur
        obtain rfl := apart aw ua (jj b uj)
        exact disjoint_left.mp (ij a) um uj
  refine ⟨P,Q,wp,eq',separate,?_,?_,?_,?_⟩
  · intro v vm
    rcases mem_union.mp vm with es|r
    · rcases mem_union.mp es with e|s
      · exact (ears v e).trans (Repair.nbr_mono G v wp)
      · exact (mem_filter.mp s).2.trans (Repair.nbr_mono G v wp)
    · obtain ⟨a,aw,vm⟩ := mem_biUnion.mp r
      exact (gj a v vm).trans (Repair.nbr_mono G v (insert_subset (wp aw) (ip aw)))
  · intro v vm ok
    rcases mem_union.mp vm with w|l
    · obtain ⟨e,em,ve⟩ := touch v w
      have step {u : V} (uq : u∈Q) (uc : u∈C) (vu : G.Adj v u) :=
        two G (a:=e) (b:=u) (fun eq => disjoint_left.mp ec em (eq ▸ uc)) ve vu (eq' em) uq
      have n := ok.resolve_left (fun h => h w)
      by_cases path : PathAt G (privateAt G W C v)
      · obtain ⟨u,um,vu⟩ := hit v path
        exact step (jq w um) (mem_filter.mp (jj v um)).1 vu
      · have ex : ∃u∈S,G.Adj v u := by
          by_contra no
          exact n ⟨fun u um vu => no ⟨u,um,vu⟩,path⟩
        obtain ⟨u,um,vu⟩ := ex
        exact step (sq um) (mem_filter.mp um).1 vu
    · obtain ⟨a,aw,vi⟩ := mem_biUnion.mp l
      exact (gi a v vi).trans (Repair.nbr_mono G v (jq aw))
  · intro a aw; obtain ⟨e,em,ae⟩ := touch a aw
    exact card_pos.mpr ⟨e,mem_filter.mpr ⟨eq' em,ae⟩⟩
  · intro a aw weak
    apply disjoint_left.mpr; intro u ua pinned
    obtain ⟨noI,noJ⟩ := empty a weak.2
    rcases mem_union.mp pinned with up|uq
    · rcases mem_union.mp up with uw|ul
      · exact disjoint_left.mp wc uw (mem_filter.mp ua).1
      · obtain ⟨b,_,bi⟩ := mem_biUnion.mp ul
        obtain rfl := apart aw ua (ii b bi)
        simp [noI] at bi
    · rcases mem_union.mp uq with es|ur
      · rcases mem_union.mp es with ue|us
        · exact disjoint_left.mp ec ue (mem_filter.mp ua).1
        · exact ns ua us
      · obtain ⟨b,_,bj⟩ := mem_biUnion.mp ur
        obtain rfl := apart aw ua (jj b bj)
        simp [noJ] at bj
end Graffiti384b.PrivatePatch
#print axioms Graffiti384b.PrivatePatch.assemble
