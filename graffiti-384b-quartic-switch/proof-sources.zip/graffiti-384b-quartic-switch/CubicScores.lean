import QuarticFront
namespace Graffiti384b.QuarticSwitch
open Finset SimpleGraph RichRoot
open private Repair.linkEdges Repair.edge_info Repair.triangles_le_choose from Repair384b
open private QuarticSwitch.pair_link from QuarticTriangle
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- In a cubic neighborhood consisting of an edge a-b and a third vertex c,
the score equals one plus c's number of neighbors on that edge. -/
theorem cubic_score {v c a b : V} (deg : G.degree v=3)
    (vc : G.Adj v c) (va : G.Adj v a) (vb : G.Adj v b)
    (ca : c≠a) (cb : c≠b) (ab : G.Adj a b) :
    G.neighborFinset v={c,a,b} ∧ trianglesAt G v=1+nbr G c {a,b} := by
  classical
  let A : Finset V := {a,b}
  have sub : insert c A⊆G.neighborFinset v := insert_subset ((G.mem_neighborFinset ..).mpr vc)
    (insert_subset ((G.mem_neighborFinset ..).mpr va) (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr vb)))
  have out : c∉A := by simp [A,ca,cb]
  have shape := (eq_of_subset_of_card_le sub (by rw [card_neighborFinset_eq_degree,deg,
    card_insert_of_not_mem out,show A.card=2 from card_pair ab.ne])).symm
  let T := A.filter (G.Adj c)
  let pairs := T.image (fun w => ({c,w}:Finset V))
  have eq : Repair.linkEdges G v=insert A pairs := by
    ext p
    constructor
    · intro pm
      obtain ⟨ps,two,cl⟩ := Repair.edge_info G pm
      rw [shape] at ps
      by_cases cm : c∈p
      · obtain ⟨w,wm,wc⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) c
        have aw := (mem_insert.mp (ps wm)).resolve_left wc
        have inc : ({c,w}:Finset V)⊆p := insert_subset cm (singleton_subset_iff.mpr wm)
        have same := eq_of_subset_of_card_le inc (by rw [two,card_pair wc.symm])
        exact mem_insert_of_mem (mem_image.mpr ⟨w,mem_filter.mpr ⟨aw,cl c cm w wm wc.symm⟩,same⟩)
      · have pA : p⊆A := fun w wm => (mem_insert.mp (ps wm)).resolve_left (fun e => cm (e ▸ wm))
        exact mem_insert.mpr (Or.inl (eq_of_subset_of_card_le pA (by rw [two]; exact le_of_eq (card_pair ab.ne))))
    · intro m
      rcases mem_insert.mp m with q|q
      · exact q ▸ QuarticSwitch.pair_link G va vb ab
      obtain ⟨w,wm,rfl⟩ := mem_image.mp q
      exact QuarticSwitch.pair_link G vc ((G.mem_neighborFinset ..).mp (sub (mem_insert_of_mem (mem_filter.mp wm).1)))
        (mem_filter.mp wm).2
  have fresh : A∉pairs := by
    rintro m
    obtain ⟨w,_,eq⟩ := mem_image.mp m
    exact out (eq ▸ mem_insert_self ..)
  have n : pairs.card=T.card := by
    apply card_image_of_injOn
    intro i im j jm same
    have ci := (mem_filter.mp im).2.ne
    have cj := (mem_filter.mp jm).2.ne
    have erase := congrArg (fun p : Finset V => p.erase c) same
    simpa [ci,ci.symm,cj,cj.symm] using erase
  refine ⟨shape,?_⟩
  change (Repair.linkEdges G v).card=1+T.card
  rw [eq,card_insert_of_not_mem fresh,n,add_comm]

theorem exterior_rich {r e b : V} (h : Ear G r e b) (few : (nonleaves G).card<(types G).card)
    {v : V} (vm : v∈exchangePool G r e b) :
    v∈nonleaves G ∧ 2≤trianglesAt G v ∧ 3≤G.degree v := by
  have nl := (mem_erase.mp (mem_erase.mp (mem_erase.mp vm).2).2).2
  have ve := (mem_erase.mp (mem_erase.mp vm).2).1
  have orig := quota_data G few
  have pos := orig.2 v nl
  have notOne : trianglesAt G v≠1 := fun eq => ve (orig.1 nl (Ear.members G h).2.1 (eq.trans (Ear.one G h).symm))
  refine ⟨nl,by omega,?_⟩
  by_contra! small
  have cap := (Repair.triangles_le_choose G v).trans (Nat.choose_le_choose 2 (by omega : G.degree v≤2))
  rw [Nat.choose_self] at cap; omega
end Graffiti384b.QuarticSwitch
#print axioms Graffiti384b.QuarticSwitch.cubic_score
#print axioms Graffiti384b.QuarticSwitch.exterior_rich
