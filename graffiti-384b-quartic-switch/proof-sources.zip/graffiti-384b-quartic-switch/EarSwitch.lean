import SparseQuartics
namespace Graffiti384b.QuarticSwitch
open Finset SimpleGraph RichRoot
open private RichRoot.quota from RichLeafRoot
open private Repair.nbr_add Repair.nbr_mono Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Hold both ear anchors, and omit the ear and any two other common neighbors.
Failure requires a further vertex whose lost neighbors among the two exceed
its degree surplus and its contacts with the held anchors. -/
theorem switch_obstruction {r e b u w : V} (h : Ear G r e b)
    (um : u∈common G r e b) (wm : w∈common G r e b) (uw : u≠w) (bad : bound G<gamma G) :
    ∃x∈exchangePool G r e b,x≠u ∧ x≠w ∧ G.degree x+nbr G x {r,b}<3+nbr G x {u,w} := by
  classical
  let S := exchangePool G r e b
  let P := (S.erase u).erase w
  let D : Finset V := {e,u,w}
  let K := (D∪P)ᶜ
  obtain ⟨us,ur,ub⟩ := mem_filter.mp um
  obtain ⟨ws,wr,wb⟩ := mem_filter.mp wm
  have props {x : V} (xs : x∈S) : x≠b ∧ x≠e ∧ x≠r ∧ x∈nonleaves G :=
    ⟨(mem_erase.mp xs).1,(mem_erase.mp (mem_erase.mp xs).2).1,
      (mem_erase.mp (mem_erase.mp (mem_erase.mp xs).2).2).1,(mem_erase.mp (mem_erase.mp (mem_erase.mp xs).2).2).2⟩
  have ue := (props us).2.1
  have we := (props ws).2.1
  have pm {x : V} (xp : x∈P) : x∈S ∧ x≠u ∧ x≠w :=
    ⟨(mem_erase.mp (mem_erase.mp xp).2).2,(mem_erase.mp (mem_erase.mp xp).2).1,(mem_erase.mp xp).1⟩
  have dp : Disjoint D P := by
    apply disjoint_left.mpr; intro x xd xp
    simp only [D,mem_insert,mem_singleton] at xd
    exact xd.elim (props (pm xp).1).2.1 (fun choice => choice.elim (pm xp).2.1 (pm xp).2.2)
  have anchors : ({r,b}:Finset V)⊆K := by
    intro x xm
    rcases mem_insert.mp xm with eq|eq
    · subst x
      exact mem_compl.mpr (fun m => (mem_union.mp m).elim
        (fun rd => by simp [D,h.re.ne,ur.ne.symm,wr.ne.symm] at rd)
        (fun rp => (props (pm rp).1).2.2.1 rfl))
    · obtain rfl := mem_singleton.mp eq
      exact mem_compl.mpr (fun m => (mem_union.mp m).elim
        (fun bd => by simp [D,h.be.ne,ub.ne.symm,wb.ne.symm] at bd)
        (fun bp => (props (pm bp).1).1 rfl))
  have fixed (v : V) (vm : v∈D) : 2≤nbr G v K := by
    have adj : G.Adj v r ∧ G.Adj v b := by
      rcases mem_insert.mp vm with ve|more
      · exact ve ▸ ⟨h.re.symm,h.be.symm⟩
      rcases mem_insert.mp more with vu|vw
      · exact vu ▸ ⟨ur,ub⟩
      · exact mem_singleton.mp vw ▸ ⟨wr,wb⟩
    exact PinnedColor34.two G h.rb.ne adj.1 adj.2 (anchors (mem_insert_self ..))
      (anchors (mem_insert_of_mem (mem_singleton_self _)))
  have count : P.card+5=(nonleaves G).card := by
    have rm := (Ear.members G h).1
    have em := mem_erase.mpr ⟨h.re.ne.symm,(Ear.members G h).2.1⟩
    have bm := mem_erase.mpr ⟨h.be.ne,mem_erase.mpr ⟨h.rb.ne.symm,(Ear.members G h).2.2⟩⟩
    have c1 := card_erase_add_one rm
    have c2 := card_erase_add_one em
    have c3 := card_erase_add_one bm
    have c4 := card_erase_add_one us
    have c5 := card_erase_add_one (mem_erase.mpr ⟨uw.symm,ws⟩ : w∈S.erase u)
    change S.card+1=_ at c3; change (S.erase u).card+1=S.card at c4
    change P.card+1=(S.erase u).card at c5; omega
  have dc : D.card=3 := by simp [D,ue.symm,we.symm,uw]
  have weak : ¬∀v∈P,3≤nbr G v P+2*nbr G v K := by
    intro cover
    have sol := Repair.seeded_cut G D K P
      (disjoint_compl_right.mono_left (show D⊆D∪P from subset_union_left)) dp
      (disjoint_compl_left.mono_right (show P⊆D∪P from subset_union_right)) fixed cover
    have tc := RichRoot.quota G; unfold bound at bad; rw [dc] at sol; omega
  push_neg at weak
  obtain ⟨x,xp,short⟩ := weak
  have xinfo := props (pm xp).1
  have xe : ¬G.Adj x e := by
    intro adj
    have m := (G.mem_neighborFinset ..).mpr adj.symm
    rw [h.neighbors] at m
    exact (mem_insert.mp m).elim xinfo.2.2.1 (fun j => xinfo.1 (mem_singleton.mp j))
  have eq : nbr G x D=nbr G x {u,w} := by simp [D,nbr,filter_insert,xe]
  have dg := Repair.full_nbr G x (D∪P)
  rw [Repair.nbr_add G x dp,eq] at dg
  change _+nbr G x K=G.degree x at dg
  have low := Repair.nbr_mono G x anchors
  exact ⟨x,(pm xp).1,(pm xp).2.1,(pm xp).2.2,by omega⟩

omit [Fintype V] in
private theorem hits_two {x a b : V} (ab : a≠b) (m : 2≤nbr G x {a,b}) : G.Adj x a ∧ G.Adj x b := by
  have eq : ({a,b}:Finset V).filter (G.Adj x)={a,b} :=
    eq_of_subset_of_card_le (filter_subset ..) (by rw [card_pair ab]; exact m)
  have full (v : V) (vm : v∈({a,b}:Finset V)) : G.Adj x v :=
    (mem_filter.mp (show v∈({a,b}:Finset V).filter (G.Adj x) by rw [eq]; exact vm)).2
  exact ⟨full a (mem_insert_self ..),full b (mem_insert_of_mem (mem_singleton_self _))⟩

omit [Fintype V] in
private theorem no_contacts {x r b : V} (zero : nbr G x {r,b}=0) : ¬G.Adj x r ∧ ¬G.Adj x b := by
  have none := card_eq_zero.mp zero
  exact ⟨fun adj => not_mem_empty r (none ▸ mem_filter.mpr ⟨mem_insert_self ..,adj⟩),
    fun adj => not_mem_empty b (none ▸ mem_filter.mpr ⟨mem_insert_of_mem (mem_singleton_self _),adj⟩)⟩

/-- When the exterior has minimum original degree four, each pair of common
neighbors must have a common remote degree-four witness in a failure. -/
theorem remote_for_pair {r e b u w : V} (h : Ear G r e b)
    (high : ∀x∈exchangePool G r e b,4≤G.degree x)
    (um : u∈common G r e b) (wm : w∈common G r e b) (uw : u≠w) (bad : bound G<gamma G) :
    ∃x∈remoteLow G r b u,G.Adj x w := by
  obtain ⟨x,xs,_,_,weak⟩ := switch_obstruction G h um wm uw bad
  have cap := (card_filter_le ({u,w}:Finset V) (G.Adj x)).trans_eq (card_pair uw)
  change nbr G x {u,w}≤2 at cap
  have lo := high x xs
  have hu := hits_two G uw (by omega : 2≤nbr G x {u,w})
  have rem := no_contacts G (by omega : nbr G x {r,b}=0)
  exact ⟨x,mem_filter.mpr ⟨(G.mem_neighborFinset ..).mpr hu.1.symm,rem.1,rem.2,by omega⟩,hu.2⟩

end Graffiti384b.QuarticSwitch
#print axioms Graffiti384b.QuarticSwitch.switch_obstruction
#print axioms Graffiti384b.QuarticSwitch.remote_for_pair
