import LocalFrontier
namespace Graffiti384b.QuarticSwitch
open Finset SimpleGraph
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem pair_link {v a b : V} (va : G.Adj v a) (vb : G.Adj v b) (ab : G.Adj a b) :
    ({a,b}:Finset V)∈Repair.linkEdges G v := by
  refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset ((G.mem_neighborFinset ..).mpr va)
    (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr vb)),card_pair ab.ne⟩,?_⟩
  intro i hi j hj ne
  simp only [mem_insert,mem_singleton] at hi hj
  rcases hi with rfl|rfl <;> rcases hj with rfl|rfl <;> first | exact (ne rfl).elim | exact ab | exact ab.symm

/-- A vertex v with only one common neighbor y with x leaves only one possible
triangle at x through v. The other triangles use two of x's remaining neighbors. -/
private theorem marked_cover {x v y : V} (unique : ∀w,G.Adj x w → G.Adj v w → w=y) :
    Repair.linkEdges G x⊆insert {v,y} (((G.neighborFinset x).erase v).powersetCard 2) := by
  intro p pm
  obtain ⟨sub,sz,cl⟩ := Repair.edge_info G pm
  by_cases vp : v∈p
  · obtain ⟨w,wp,wv⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) v
    have eq := unique w ((G.mem_neighborFinset ..).mp (sub wp)) (cl v vp w wp wv.symm)
    subst y
    have both : ({v,w}:Finset V)⊆p := insert_subset vp (singleton_subset_iff.mpr wp)
    exact mem_insert.mpr (Or.inl (eq_of_subset_of_card_le both (by rw [sz,card_pair wv.symm])).symm)
  · exact mem_insert_of_mem (mem_powersetCard.mpr ⟨fun a ap => mem_erase.mpr
      ⟨fun eq => vp (eq ▸ ap),sub ap⟩,sz⟩)

private theorem cap_four {x v y : V} (xv : G.Adj x v) (small : G.degree x≤4)
    (unique : ∀w,G.Adj x w → G.Adj v w → w=y) :
    trianglesAt G x≤4 := by
  let A := (G.neighborFinset x).erase v
  have a := card_erase_add_one ((G.mem_neighborFinset ..).mpr xv)
  rw [card_neighborFinset_eq_degree] at a
  have c := Nat.choose_le_choose 2 (by change ((G.neighborFinset x).erase v).card≤3; omega : A.card≤3)
  have inc := card_le_card (marked_cover G unique)
  have u := card_insert_le ({v,y}:Finset V) (A.powersetCard 2)
  rw [card_powersetCard] at u
  change (Repair.linkEdges G x).card≤4
  change (Repair.linkEdges G x).card≤(insert {v,y} (A.powersetCard 2)).card at inc
  norm_num at c
  omega

/-- At equality the other three neighbors of x are mutually adjacent. The same
four triangles are then visible at y if its edge to v also has a unique third vertex. -/
private theorem transfers_four {x v y : V} (xv : G.Adj x v) (xy : G.Adj x y) (vy : G.Adj v y)
    (small : G.degree x≤4) (unique : ∀w,G.Adj x w → G.Adj v w → w=y)
    (many : 4≤trianglesAt G x) : 4≤trianglesAt G y := by
  classical
  let A := (G.neighborFinset x).erase v
  have ac := card_erase_add_one ((G.mem_neighborFinset ..).mpr xv)
  rw [card_neighborFinset_eq_degree] at ac
  have asmall : A.card≤3 := by change ((G.neighborFinset x).erase v).card≤3; omega
  have lim := Nat.choose_le_choose 2 asmall
  have inc := marked_cover G unique
  have c := card_le_card inc
  have u := card_insert_le ({v,y}:Finset V) (A.powersetCard 2)
  change (Repair.linkEdges G x).card≤(insert {v,y} (A.powersetCard 2)).card at c
  change 4≤(Repair.linkEdges G x).card at many
  rw [card_powersetCard] at u
  norm_num at lim
  have full := eq_of_subset_of_card_le inc (by change (insert {v,y} (A.powersetCard 2)).card≤_; omega)
  have three : A.card=3 := by
    by_contra h
    have le := Nat.choose_le_choose 2 (by omega : A.card≤2)
    norm_num at le; omega
  have cl {a b : V} (am : a∈A) (bm : b∈A) (ne : a≠b) : G.Adj a b := by
    have p : ({a,b}:Finset V)∈Repair.linkEdges G x := full ▸ mem_insert_of_mem
      (mem_powersetCard.mpr ⟨insert_subset am (singleton_subset_iff.mpr bm),card_pair ne⟩)
    exact (Repair.edge_info G p).2.2 _ (mem_insert_self ..) _ (mem_insert_of_mem (mem_singleton_self _)) ne
  have ym : y∈A := mem_erase.mpr ⟨vy.ne.symm,(G.mem_neighborFinset ..).mpr xy⟩
  let B := insert x (A.erase y)
  have xf : x∉A := fun m => G.not_mem_neighborFinset_self _ (mem_erase.mp m).2
  have bc : B.card=3 := by
    have d := card_erase_add_one ym
    rw [show B=insert x (A.erase y) from rfl,card_insert_of_not_mem (fun m => xf (mem_erase.mp m).2)]
    omega
  have out : v∉B := fun m => (mem_insert.mp m).elim xv.ne.symm (fun n => (mem_erase.mp (mem_erase.mp n).2).1 rfl)
  have xedge {w : V} (wm : w∈A) := (G.mem_neighborFinset ..).mp (mem_erase.mp wm).2
  have adjY {a : V} (am : a∈B) : G.Adj y a := by
    rcases mem_insert.mp am with rfl|h
    · exact xy.symm
    · exact cl ym (mem_erase.mp h).2 (mem_erase.mp h).1.symm
  have clique {a b : V} (am : a∈B) (bm : b∈B) (ne : a≠b) : G.Adj a b := by
    rcases mem_insert.mp am with rfl|aa <;> rcases mem_insert.mp bm with rfl|bb
    · exact (ne rfl).elim
    · exact xedge (mem_erase.mp bb).2
    · exact (xedge (mem_erase.mp aa).2).symm
    · exact cl (mem_erase.mp aa).2 (mem_erase.mp bb).2 ne
  have sub : insert {v,x} (B.powersetCard 2)⊆Repair.linkEdges G y := by
    apply insert_subset (pair_link G vy.symm xy.symm xv.symm)
    intro p pm
    obtain ⟨ps,sz⟩ := mem_powersetCard.mp pm
    exact mem_filter.mpr ⟨mem_powersetCard.mpr ⟨fun w wm => (G.mem_neighborFinset ..).mpr (adjY (ps wm)),sz⟩,
      fun a am b bm ne => clique (ps am) (ps bm) ne⟩
  have h := card_le_card sub
  rw [card_insert_of_not_mem (fun m => out ((mem_powersetCard.mp m).1 (mem_insert_self ..))),
    card_powersetCard,bc] at h
  exact h

/-- If both edges to v have just the one common neighbor, unequal triangle
scores at x,y with the smaller at least three force one endpoint to have degree five. -/
theorem no_low_pair {v x y : V} (vx : G.Adj v x) (vy : G.Adj v y) (xy : G.Adj x y)
    (ux : ∀w,G.Adj x w → G.Adj v w → w=y) (uy : ∀w,G.Adj y w → G.Adj v w → w=x)
    (rx : 3≤trianglesAt G x) (ry : 3≤trianglesAt G y) (neq : trianglesAt G x≠trianglesAt G y) :
    5≤G.degree x ∨ 5≤G.degree y := by
  by_contra! both
  have cx := cap_four G vx.symm (by omega : G.degree x≤4) ux
  have cy := cap_four G vy.symm (by omega : G.degree y≤4) uy
  rcases lt_or_gt_of_ne neq with lt|gt
  · have m := transfers_four G vy.symm xy.symm vx (by omega : G.degree y≤4) uy (by omega)
    omega
  · have m := transfers_four G vx.symm xy vy (by omega : G.degree x≤4) ux (by omega)
    omega
end Graffiti384b.QuarticSwitch
#print axioms Graffiti384b.QuarticSwitch.no_low_pair
