import QuarticTriangle
namespace Graffiti384b.QuarticSwitch
open Finset SimpleGraph RichRoot
open private Repair.linkEdges Repair.edge_info Repair.triangles_le_choose from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
open private Prune.outside_zero from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

structure Ear (r e b : V) : Prop where
  rb : G.Adj r b
  re : G.Adj r e
  be : G.Adj b e
  neighbors : G.neighborFinset e={r,b}

def common (r e b : V) := (exchangePool G r e b).filter (fun v => G.Adj v r ∧ G.Adj v b)
def remoteLow (r b v : V) := (G.neighborFinset v).filter (fun w => ¬G.Adj w r ∧ ¬G.Adj w b ∧ G.degree w≤4)

theorem Ear.members {r e b : V} (h : Ear G r e b) : r∈nonleaves G ∧ e∈nonleaves G ∧ b∈nonleaves G :=
  ⟨mem_filter.mpr ⟨mem_univ _,PositivePalette.Prerequisites.deg2 G h.be.ne h.rb h.re⟩,
   mem_filter.mpr ⟨mem_univ _,PositivePalette.Prerequisites.deg2 G h.rb.ne h.re.symm h.be.symm⟩,
   mem_filter.mpr ⟨mem_univ _,PositivePalette.Prerequisites.deg2 G h.re.ne h.rb.symm h.be⟩⟩

theorem Ear.one {r e b : V} (h : Ear G r e b) : trianglesAt G e=1 := by
  have d := congrArg Finset.card h.neighbors
  rw [card_neighborFinset_eq_degree,card_pair h.rb.ne] at d
  have up := Repair.triangles_le_choose G e
  rw [d,Nat.choose_self] at up
  have pos := (TrianglePrune.triangle_iff G e).mpr ⟨r,b,h.re.symm,h.be.symm,h.rb⟩
  omega

theorem quota_data (few : (nonleaves G).card<(types G).card) :
    Set.InjOn (trianglesAt G) (nonleaves G : Set V) ∧ ∀v∈nonleaves G,0<trianglesAt G v := by
  let A := (nonleaves G).image (trianglesAt G)
  have inc : types G⊆insert 0 A := by
    intro k km; obtain ⟨v,_,rfl⟩ := mem_image.mp km
    by_cases vm : v∈nonleaves G
    · exact mem_insert_of_mem (mem_image_of_mem _ vm)
    · exact mem_insert.mpr (Or.inl (Prune.outside_zero G vm))
  have l := card_le_card inc
  have ins := card_insert_le 0 A
  have cap : A.card≤(nonleaves G).card := card_image_le
  refine ⟨card_image_iff.mp (by change A.card=(nonleaves G).card; omega),?_⟩
  intro v vm
  by_contra! non
  have zero : 0∈A := (show trianglesAt G v=0 by omega) ▸ mem_image_of_mem (trianglesAt G) vm
  rw [insert_eq_of_mem zero] at l; omega

private theorem two_pairs {v : V} {A B : Finset V} (shape : G.neighborFinset v=A∪B)
    (ac : A.card=2) (bc : B.card=2) (dis : Disjoint A B)
    (no : ∀a∈A,∀b∈B,¬G.Adj a b) : Repair.linkEdges G v⊆{A,B} := by
  classical
  intro p pm
  obtain ⟨ps,two,cl⟩ := Repair.edge_info G pm
  rw [shape] at ps
  by_cases sub : p⊆A
  · exact mem_insert.mpr (Or.inl (eq_of_subset_of_card_le sub (by omega)))
  · obtain ⟨x,xm,xa⟩ := not_subset.mp sub
    have xb := (mem_union.mp (ps xm)).resolve_left xa
    have inner : p⊆B := by
      intro y ym
      apply (mem_union.mp (ps ym)).resolve_left
      intro ya
      have ne : y≠x := fun eq => disjoint_left.mp dis ya (eq ▸ xb)
      exact no y ya x xb (cl y ym x xm ne)
    exact mem_insert_of_mem (mem_singleton.mpr (eq_of_subset_of_card_le inner (by omega)))

/-- A quartic common neighbor can see at most one vertex of degree at most four
which misses both ear anchors. This is a minimum-quota graph theorem, independent
of domination or the density of either anchor. -/
theorem remote_unique {r e b v : V} (h : Ear G r e b) (few : (nonleaves G).card<(types G).card)
    (vc : v∈common G r e b) (low : G.degree v≤4) : (remoteLow G r b v).card≤1 := by
  classical
  apply card_le_one.mpr
  intro x xm y ym
  by_contra ne
  obtain ⟨vm,vr,vb⟩ := mem_filter.mp vc
  obtain ⟨xn,xr,xb,xd⟩ := mem_filter.mp xm
  obtain ⟨yn,yr,yb,yd⟩ := mem_filter.mp ym
  have vx := (G.mem_neighborFinset ..).mp xn
  have vy := (G.mem_neighborFinset ..).mp yn
  have xnr : x≠r := fun eq => xb (eq ▸ h.rb)
  have xnb : x≠b := fun eq => xr (eq ▸ h.rb.symm)
  have ynr : y≠r := fun eq => yb (eq ▸ h.rb)
  have ynb : y≠b := fun eq => yr (eq ▸ h.rb.symm)
  let A : Finset V := {r,b}
  let B : Finset V := {x,y}
  have ac : A.card=2 := card_pair h.rb.ne
  have bc : B.card=2 := card_pair ne
  have dis : Disjoint A B := by simp [A,B,xnr,xnb,ynr,ynb,xnr.symm,xnb.symm,ynr.symm,ynb.symm]
  have inc : A∪B⊆G.neighborFinset v := by
    apply union_subset
    · exact insert_subset ((G.mem_neighborFinset ..).mpr vr) (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr vb))
    · exact insert_subset xn (singleton_subset_iff.mpr yn)
  have sh : G.neighborFinset v=A∪B := (eq_of_subset_of_card_le inc (by
    rw [card_union_of_disjoint dis,ac,bc,card_neighborFinset_eq_degree]; omega)).symm
  have sep : ∀a∈A,∀u∈B,¬G.Adj a u := by
    intro a am u um au
    rcases mem_insert.mp am with q|q <;> rcases mem_insert.mp um with p|p
    · exact xr (q ▸ p ▸ au.symm)
    · exact yr (q ▸ mem_singleton.mp p ▸ au.symm)
    · exact xb (mem_singleton.mp q ▸ p ▸ au.symm)
    · exact yb (mem_singleton.mp q ▸ mem_singleton.mp p ▸ au.symm)
  have pair := two_pairs G sh ac bc dis sep
  have orig := quota_data G few
  have vnl : v∈nonleaves G := (mem_erase.mp (mem_erase.mp (mem_erase.mp vm).2).2).2
  have ve := (mem_erase.mp (mem_erase.mp vm).2).1
  have vlo := orig.2 v vnl
  have vone : trianglesAt G v≠1 := fun eq => ve (orig.1 vnl (Ear.members G h).2.1 (eq.trans (Ear.one G h).symm))
  have same : Repair.linkEdges G v={A,B} := eq_of_subset_of_card_le pair (by
    have mx := card_insert_le A ({B}:Finset (Finset V))
    rw [card_singleton] at mx; change _≤trianglesAt G v; omega)
  have scv : trianglesAt G v=2 := by
    change (Repair.linkEdges G v).card=2
    rw [same,card_pair (show A≠B from fun eq => disjoint_left.mp dis (mem_insert_self ..) (eq ▸ mem_insert_self ..))]
  have bp : B∈Repair.linkEdges G v := same ▸ mem_insert_of_mem (mem_singleton_self _)
  have xy := (Repair.edge_info G bp).2.2 x (mem_insert_self ..) y (mem_insert_of_mem (mem_singleton_self _)) ne
  have ux {w : V} (xw : G.Adj x w) (vw : G.Adj v w) : w=y := by
    have m := (G.mem_neighborFinset ..).mpr vw; rw [sh] at m
    rcases mem_union.mp m with a|a
    · exact False.elim (sep w a x (mem_insert_self ..) xw.symm)
    · exact (mem_insert.mp a).resolve_left xw.ne.symm |> mem_singleton.mp
  have uy {w : V} (yw : G.Adj y w) (vw : G.Adj v w) : w=x := by
    have m := (G.mem_neighborFinset ..).mpr vw; rw [sh] at m
    rcases mem_union.mp m with a|a
    · exact False.elim (sep w a y (mem_insert_of_mem (mem_singleton_self _)) yw.symm)
    · exact (mem_insert.mp a).resolve_right (fun a => yw.ne.symm (mem_singleton.mp a))
  have xnl : x∈nonleaves G := mem_filter.mpr ⟨mem_univ _,PositivePalette.Prerequisites.deg2 G vy.ne vx.symm xy⟩
  have ynl : y∈nonleaves G := mem_filter.mpr ⟨mem_univ _,PositivePalette.Prerequisites.deg2 G vx.ne vy.symm xy.symm⟩
  have rich {w : V} (wn : w∈nonleaves G) (wv : w≠v) (wr : ¬G.Adj w r) : 3≤trianglesAt G w := by
    have we : w≠e := fun eq => wr (eq ▸ h.re.symm)
    have p := orig.2 w wn
    have n1 : trianglesAt G w≠1 := fun eq => we (orig.1 wn (Ear.members G h).2.1 (eq.trans (Ear.one G h).symm))
    have n2 : trianglesAt G w≠2 := fun eq => wv (orig.1 wn vnl (eq.trans scv.symm))
    omega
  have hi := no_low_pair G vx vy xy (fun _ => ux) (fun _ => uy)
    (rich xnl vx.ne.symm xr) (rich ynl vy.ne.symm yr) (fun eq => ne (orig.1 xnl ynl eq))
  omega

end Graffiti384b.QuarticSwitch
#print axioms Graffiti384b.QuarticSwitch.quota_data
#print axioms Graffiti384b.QuarticSwitch.remote_unique
