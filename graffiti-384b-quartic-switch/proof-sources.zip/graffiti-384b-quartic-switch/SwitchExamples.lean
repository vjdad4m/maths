import HighScore
namespace Graffiti384b.QuarticSwitch.Examples
open Finset SimpleGraph RichRoot
set_option maxRecDepth 65536
set_option maxHeartbeats 16000000

def graph {n : ℕ} (N : Fin n→Finset (Fin n)) (s : ∀u v : Fin n,v∈N u → u∈N v)
    (d : ∀u : Fin n,u∉N u) : SimpleGraph (Fin n) where
  Adj u v := v∈N u
  symm := s
  loopless := d

instance {n : ℕ} (N : Fin n→Finset (Fin n)) (s d) : DecidableRel (graph N s d).Adj :=
  fun u v => inferInstanceAs (Decidable (v∈N u))

def fifteenNeighbors : Fin 15 → Finset (Fin 15)
  | 0 => {1,2}
  | 1 => {0,2,3,5,6,7,8,9,10,11,13,14}
  | 2 => {0,1,3,5,8,9,10,11,12}
  | 3 => {1,2,4,5}
  | 4 => {3,8,9,11}
  | 5 => {1,2,3,6,7,9}
  | 6 => {1,5,9,10,13}
  | 7 => {1,5,8,9,10,11,12,13}
  | 8 => {1,2,4,7,10,11,12,13}
  | 9 => {1,2,4,5,6,7,11,12,13}
  | 10 => {1,2,6,7,8,11}
  | 11 => {1,2,4,7,8,9,10,12,13}
  | 12 => {2,7,8,9,11,13}
  | 13 => {1,6,7,8,9,11,12}
  | 14 => {1}

abbrev fifteen := graph fifteenNeighbors (by decide) (by decide)

def quarticNeighbors : Fin 13 → Finset (Fin 13)
  | 0 => {1,2}
  | 1 => {0,2,3,5,6,7,12}
  | 2 => {0,1,3,5,6,7,8,9,10,11}
  | 3 => {1,2,4,5}
  | 4 => {3,5,6,7}
  | 5 => {1,2,3,4,6,8,9,10,11}
  | 6 => {1,2,4,5,7,8,9,10,11}
  | 7 => {1,2,4,6,8,9,11}
  | 8 => {2,5,6,7,9,10,11}
  | 9 => {2,5,6,7,8}
  | 10 => {2,5,6,8,11}
  | 11 => {2,5,6,7,8,10}
  | 12 => {1}

abbrev quartic := graph quarticNeighbors (by decide) (by decide)

def cubicNeighbors : Fin 13 → Finset (Fin 13)
  | 0 => {1,2}
  | 1 => {0,2,3,5,6,7,9,10,11,12}
  | 2 => {0,1,3,5,6,7,8}
  | 3 => {1,2,5}
  | 4 => {5,6,7}
  | 5 => {1,2,3,4,6,8,9,10,11}
  | 6 => {1,2,4,5,7,9,10,11}
  | 7 => {1,2,4,6,8,9,10,11}
  | 8 => {2,5,7,10,11}
  | 9 => {1,5,6,7,11}
  | 10 => {1,5,6,7,8,11}
  | 11 => {1,5,6,7,8,9,10}
  | 12 => {1}

abbrev cubic := graph cubicNeighbors (by decide) (by decide)

theorem fifteen_profile : (nonleaves fifteen).card=14 ∧ (types fifteen).card=15 ∧
    fifteen.degree 14=1 ∧ fifteen.Adj 1 14 ∧ (common fifteen 1 0 2).card=6 ∧
    fifteen.degree 3=4 ∧ trianglesAt fifteen 3=3 ∧
    trianglesAt (inside fifteen (exchangePool fifteen 1 0 2)) 3=0 ∧
    nbr fifteen 3 (exchangePool fifteen 1 0 2)=2 ∧
    nbr fifteen 3 (insert 2 (({1}:Finset (Fin 15))∪exchangePool fifteen 1 0 2))ᶜ=0 := by decide

theorem fifteen_bound : gamma fifteen≤bound fifteen := by
  have h : Ear fifteen 1 0 2 := ⟨by decide,by decide,by decide,by decide⟩
  obtain ⟨q,t,_⟩ := fifteen_profile
  apply five_common_quartic fifteen (v:=3) h (by omega) (by decide) (by decide) (by decide) (by decide)

theorem quartic_limit : (nonleaves quartic).card=12 ∧ (types quartic).card=13 ∧
    quartic.degree 12=1 ∧ quartic.Adj 1 12 ∧ quartic.degree 3=4 ∧ trianglesAt quartic 3=4 ∧
    common quartic 1 0 2={3,5,6,7} ∧ remoteLow quartic 1 2 3={4} ∧
    quartic.neighborFinset 4=common quartic 1 0 2 ∧ gamma quartic≤bound quartic := by
  have D : TwoDominates quartic ({0,1,5,6,12}:Finset (Fin 13)) :=
    (by decide : ∀v : Fin 13,v∉({0,1,5,6,12}:Finset (Fin 13)) → 2≤nbr quartic v {0,1,5,6,12})
  have ex : ∃S,TwoDominates quartic S ∧ S.card=5 := ⟨_,D,by decide⟩
  exact ⟨by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide,
    (Nat.sInf_le ex).trans (by decide)⟩

theorem cubic_limit : (nonleaves cubic).card=12 ∧ (types cubic).card=13 ∧
    cubic.degree 12=1 ∧ cubic.Adj 1 12 ∧ cubic.degree 3=3 ∧ trianglesAt cubic 3=3 ∧
    common cubic 1 0 2={3,5,6,7} ∧ remoteCubics cubic 1 0 2={4} ∧
    cubic.neighborFinset 4=(common cubic 1 0 2).erase 3 ∧ ¬cubic.Adj 4 3 ∧
    gamma cubic≤bound cubic := by
  have D : TwoDominates cubic ({0,1,5,7,12}:Finset (Fin 13)) :=
    (by decide : ∀v : Fin 13,v∉({0,1,5,7,12}:Finset (Fin 13)) → 2≤nbr cubic v {0,1,5,7,12})
  have ex : ∃S,TwoDominates cubic S ∧ S.card=5 := ⟨_,D,by decide⟩
  exact ⟨by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide,by decide,
    (Nat.sInf_le ex).trans (by decide)⟩

/-- The four-contact witnesses satisfy the actual ear hypotheses.
The quartic example has the full minimum-degree hypothesis on the exterior. -/
theorem limit_hypotheses : Ear quartic 1 0 2 ∧ Ear cubic 1 0 2 ∧
    (∀x∈exchangePool quartic 1 0 2,4≤quartic.degree x) ∧ cubic.degree 4=3 ∧
    trianglesAt cubic 4=2 :=
  ⟨⟨by decide,by decide,by decide,by decide⟩,⟨by decide,by decide,by decide,by decide⟩,
    by decide,by decide,by decide⟩

/-- Both tests from the rich-root cut fail on this ear, although its mate
has the strict contact majority and the new switch proves the bound. -/
theorem fifteen_prior_tests : let S := exchangePool fifteen 1 0 2
    (S.card+1)/2 < (S.filter (fifteen.Adj 2)).card ∧ ¬HasResidualPalette fifteen S ∧
    ¬DegreeTest fifteen S (insert 2 (({1}:Finset (Fin 15))∪S))ᶜ 2 := by
  dsimp only
  have v : 3∈exchangePool fifteen 1 0 2 := by decide
  obtain ⟨_,_,_,_,_,_,_,zero,n,k⟩ := fifteen_profile
  refine ⟨by decide,fun pal => ?_,fun test => ?_⟩
  · have positive := pal.1 3 v
    omega
  · have degree := test.1 3 v
    omega

private theorem connected_star {n : ℕ} (G : SimpleGraph (Fin n)) (r : Fin n)
    (h : ∀v,v=r ∨ G.Adj r v ∨ (∃w,G.Adj r w ∧ G.Adj w v) ∨
      ∃w u,G.Adj r w ∧ G.Adj w u ∧ G.Adj u v) : G.Connected := by
  apply (connected_iff_exists_forall_reachable G).mpr
  refine ⟨r,fun v => ?_⟩
  rcases h v with rfl|adj|⟨w,rw,wv⟩|⟨w,u,rw,wu,uv⟩
  · exact Reachable.refl _
  · exact adj.reachable
  · exact rw.reachable.trans wv.reachable
  · exact rw.reachable.trans (wu.reachable.trans uv.reachable)

theorem connectivity : fifteen.Connected ∧ quartic.Connected ∧ cubic.Connected :=
  ⟨connected_star _ 1 (by decide),connected_star _ 1 (by decide),connected_star _ 1 (by decide)⟩

end Graffiti384b.QuarticSwitch.Examples
#print axioms Graffiti384b.QuarticSwitch.Examples.fifteen_profile
#print axioms Graffiti384b.QuarticSwitch.Examples.fifteen_bound
#print axioms Graffiti384b.QuarticSwitch.Examples.quartic_limit
#print axioms Graffiti384b.QuarticSwitch.Examples.cubic_limit
#print axioms Graffiti384b.QuarticSwitch.Examples.connectivity
#print axioms Graffiti384b.QuarticSwitch.Examples.limit_hypotheses
#print axioms Graffiti384b.QuarticSwitch.Examples.fifteen_prior_tests
