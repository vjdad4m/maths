import ResidualCut
namespace Graffiti384b.RichRoot
open Finset SimpleGraph OddStars
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def swapPart (L R C : Finset V) := (L\C)∪(R∩C)

omit [Fintype V] in
private theorem split_flip {J : SimpleGraph V} [DecidableRel J.Adj] {S L R C : Finset V}
    (cut : Split J S L R) (closed : region J C) :
    Split J S (swapPart L R C) (swapPart R L C) := by
  obtain ⟨ds,cover,l,r⟩ := cut
  have transfer {A B : Finset V} (p : ∀v∈A,2≤nbr J v B) (q : ∀v∈B,2≤nbr J v A) :
      ∀v∈swapPart A B C,2≤nbr J v (swapPart B A C) := by
    intro v vm
    rcases mem_union.mp vm with m|m
    · obtain ⟨va,vc⟩ := mem_sdiff.mp m
      apply (p v va).trans (card_le_card ?_)
      intro w wm; obtain ⟨wb,vw⟩ := mem_filter.mp wm
      exact mem_filter.mpr ⟨mem_union_left _ (mem_sdiff.mpr ⟨wb,fun wc => vc ((closed vw).mpr wc)⟩),vw⟩
    · obtain ⟨vb,vc⟩ := mem_inter.mp m
      apply (q v vb).trans (card_le_card ?_)
      intro w wm; obtain ⟨wa,vw⟩ := mem_filter.mp wm
      exact mem_filter.mpr ⟨mem_union_right _ (mem_inter.mpr ⟨wa,(closed vw).mp vc⟩),vw⟩
  refine ⟨disjoint_left.mpr ?_,?_,transfer l r,transfer r l⟩
  · intro v x y; have dis : v∈L → v∈R → False := fun a b => disjoint_left.mp ds a b
    simp only [swapPart,mem_union,mem_inter,mem_sdiff] at x y
    tauto
  · rw [←cover]; ext v; simp only [swapPart,mem_union,mem_inter,mem_sdiff]; tauto

omit [Fintype V] in
private theorem swap_size (L R C : Finset V) :
    (swapPart L R C).card=(L\C).card+(R∩C).card := by
  apply card_union_of_disjoint
  exact disjoint_left.mpr (fun v x y => (mem_sdiff.mp x).2 (mem_inter.mp y).2)

/-- If there is an outside contact, every closed region is contact-free and
contains exactly as many vertices of the two shores in a failure. -/
theorem region_barrier {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ) (pal : HasResidualPalette G S)
    (contact : (S.filter (G.Adj b)).Nonempty)
    (bad : Fintype.card V-(F.card+1+(S.card+1)/2)<gamma G) :
    ∃L R,Split (triangleEdges G S) S L R ∧ S.filter (G.Adj b)⊆L ∧ L.card=R.card+1 ∧
      ∀C,region (triangleEdges G S) C → ((S.filter (G.Adj b))\C).Nonempty →
        Disjoint (S.filter (G.Adj b)) C ∧ (L∩C).card=(R∩C).card := by
  obtain ⟨L,R,cut,inc,sz⟩ := trapped_shore G fs bf bs kf ks bk fixed pal contact bad
  refine ⟨L,R,cut,inc,sz,?_⟩
  intro C closed outside
  obtain ⟨w,wm⟩ := outside
  obtain ⟨wt,wc⟩ := mem_sdiff.mp wm
  have wleft : w∈swapPart L R C := mem_union_left _ (mem_sdiff.mpr ⟨inc wt,wc⟩)
  obtain ⟨ap,cover,l,r⟩ := split_flip cut closed
  have mono (v : V) (P : Finset V) : nbr (triangleEdges G S) v P≤nbr G v P :=
    card_le_card (fun w wm => mem_filter.mpr ⟨(mem_filter.mp wm).1,(mem_filter.mp wm).2.1.1⟩)
  have h := (single_shore G fs bf bs kf ks bk fixed ap cover
    (fun v vm => (l v vm).trans (mono ..)) (fun v vm => (r v vm).trans (mono ..)) contact bad).resolve_right
      (fun opp => disjoint_left.mp ap wleft (opp.1 wt))
  constructor
  · apply disjoint_left.mpr
    intro x xt xc
    have xr : x∈swapPart R L C := mem_union_right _ (mem_inter.mpr ⟨inc xt,xc⟩)
    exact disjoint_left.mp ap (h.1 xt) xr
  · have oldL := card_sdiff_add_card_inter L C
    have oldR := card_sdiff_add_card_inter R C
    have new := h.2
    rw [swap_size,swap_size] at new; omega

/-- A separated pair of contacts or an odd region away from a contact. -/
def RegionTest (S : Finset V) (b : V) : Prop :=
  let T := S.filter (G.Adj b)
  ∃C,region (triangleEdges G S) C ∧ (T\C).Nonempty ∧
      ((T∩C).Nonempty ∨ (S∩C).card%2=1)

theorem exchange_bound {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ) (pal : HasResidualPalette G S)
    (test : ContactTest G S b ∨ RegionTest G S b) : gamma G≤Fintype.card V-(F.card+1+(S.card+1)/2) := by
  rcases test with t|⟨C,closed,outside,obstruction⟩
  · exact donor_bound G fs bf bs kf ks bk fixed pal t
  by_contra! bad
  obtain ⟨w,wm⟩ := outside
  obtain ⟨L,R,cut,_,_,barrier⟩ := region_barrier G fs bf bs kf ks bk fixed pal
    ⟨w,(mem_sdiff.mp wm).1⟩ bad
  obtain ⟨dis,bal⟩ := barrier C closed ⟨w,wm⟩
  rcases obstruction with ⟨v,vm⟩|odd
  · exact disjoint_left.mp dis (mem_inter.mp vm).1 (mem_inter.mp vm).2
  · have size := card_union_of_disjoint (cut.1.mono
        (show L∩C⊆L from inter_subset_left) (show R∩C⊆R from inter_subset_left))
    rw [←union_inter_distrib_right,cut.2.1] at size
    omega

end Graffiti384b.RichRoot
#print axioms Graffiti384b.RichRoot.region_barrier
#print axioms Graffiti384b.RichRoot.exchange_bound
