import Repair384b
namespace Graffiti384b.RichRoot
open Finset SimpleGraph
open private Repair.omit_set Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- F is always omitted, S varies between two shores, and b has a fixed donor k.
If the extra omission fails, all contacts of b in S lie on the larger shore.
That shore must be larger by exactly one. -/
theorem supported_shore {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ)
    {L R : Finset V} (apart : Disjoint L R) (parts : L∪R=S)
    (left : ∀v∈L,2≤nbr G v (R∪(insert b (F∪S))ᶜ))
    (right : ∀v∈R,2≤nbr G v (L∪(insert b (F∪S))ᶜ))
    (contact : (S.filter (G.Adj b)).Nonempty)
    (bad : Fintype.card V-(F.card+1+(S.card+1)/2)<gamma G) :
    (S.filter (G.Adj b)⊆L ∧ L.card=R.card+1) ∨
    (S.filter (G.Adj b)⊆R ∧ R.card=L.card+1) := by
  classical
  have side {A B : Finset V} (ab : Disjoint A B) (cover : A∪B=S)
      (ok : ∀v∈A,2≤nbr G v (B∪(insert b (F∪S))ᶜ)) :
      gamma G≤Fintype.card V-(F.card+A.card) ∧
      ((B.filter (G.Adj b)).Nonempty → gamma G≤Fintype.card V-(F.card+A.card+1)) := by
    have asub : A⊆S := cover ▸ subset_union_left
    have bsub : B⊆S := cover ▸ subset_union_right
    let D := F∪A
    have dcard : D.card=F.card+A.card := card_union_of_disjoint (fs.mono_right asub)
    have free : b∉D := fun w => (mem_union.mp w).elim bf (fun a => bs (asub a))
    have safe : ∀v∈D,2≤nbr G v (insert b D)ᶜ := by
      intro v vm
      rcases mem_union.mp vm with vf|va
      · exact (fixed v vf).trans (Repair.nbr_mono G _ (compl_subset_compl.mpr
          (insert_subset_insert b (union_subset_union_right asub))))
      · apply (ok v va).trans (Repair.nbr_mono G _ ?_)
        apply union_subset _ (compl_subset_compl.mpr (insert_subset_insert b (union_subset_union_right asub)))
        intro x xb
        exact mem_compl.mpr (fun m => (mem_insert.mp m).elim (fun eq => bs (eq ▸ bsub xb))
          (fun t => (mem_union.mp t).elim (fun xf => disjoint_left.mp fs xf (bsub xb))
            (fun xa => disjoint_left.mp ab xa xb)))
    constructor
    · have h := Repair.omit_set G D (fun v vm => (safe v vm).trans
          (Repair.nbr_mono G _ (compl_subset_compl.mpr (subset_insert ..))))
      rwa [dcard] at h
    · rintro ⟨w,wm⟩
      obtain ⟨wb,bw⟩ := mem_filter.mp wm
      have keepw : w∈(insert b D)ᶜ := mem_compl.mpr (fun m => (mem_insert.mp m).elim bw.ne.symm
        (fun t => (mem_union.mp t).elim (fun wf => disjoint_left.mp fs wf (bsub wb))
          (fun wa => disjoint_left.mp ab wa wb)))
      have keepk : k∈(insert b D)ᶜ := mem_compl.mpr (fun m => (mem_insert.mp m).elim bk.ne.symm
        (fun t => (mem_union.mp t).elim kf (fun ka => ks (asub ka))))
      have sub : ({k,w}:Finset V)⊆((insert b D)ᶜ).filter (G.Adj b) :=
        insert_subset (mem_filter.mpr ⟨keepk,bk⟩) (singleton_subset_iff.mpr (mem_filter.mpr ⟨keepw,bw⟩))
      have two := card_le_card sub
      rw [card_pair (show k≠w from fun eq => ks (eq ▸ bsub wb))] at two
      have h := Repair.omit_set G (insert b D) (fun v vm => (mem_insert.mp vm).elim (fun eq => eq ▸ two) (safe v))
      rwa [card_insert_of_not_mem free,dcard] at h
  have lv := side apart parts left
  have rv := side apart.symm ((union_comm R L).trans parts) right
  have size := card_union_of_disjoint apart
  rw [parts] at size
  have flip {A B : Finset V} (cover : A∪B=S) (none : ¬(B.filter (G.Adj b)).Nonempty) :
      S.filter (G.Adj b)⊆A := by
    intro x xm
    obtain ⟨xs,bx⟩ := mem_filter.mp xm
    exact (mem_union.mp (cover ▸ xs)).resolve_right (fun xb => none ⟨x,mem_filter.mpr ⟨xb,bx⟩⟩)
  by_cases l : (L.filter (G.Adj b)).Nonempty
  · have boundR := rv.2 l
    by_cases r : (R.filter (G.Adj b)).Nonempty
    · have boundL := lv.2 r; omega
    · exact Or.inl ⟨flip parts r,by omega⟩
  · have inc := flip ((union_comm R L).trans parts) l
    obtain ⟨y,ym⟩ := contact
    have boundL := lv.2 ⟨y,mem_filter.mpr ⟨inc ym,(mem_filter.mp ym).2⟩⟩
    exact Or.inr ⟨inc,by omega⟩

theorem single_shore {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ)
    {L R : Finset V} (apart : Disjoint L R) (parts : L∪R=S)
    (left : ∀v∈L,2≤nbr G v R) (right : ∀v∈R,2≤nbr G v L)
    (contact : (S.filter (G.Adj b)).Nonempty)
    (bad : Fintype.card V-(F.card+1+(S.card+1)/2)<gamma G) :
    (S.filter (G.Adj b)⊆L ∧ L.card=R.card+1) ∨
    (S.filter (G.Adj b)⊆R ∧ R.card=L.card+1) :=
  supported_shore G fs bf bs kf ks bk fixed apart parts
    (fun v vm => (left v vm).trans (Repair.nbr_mono G v subset_union_left))
    (fun v vm => (right v vm).trans (Repair.nbr_mono G v subset_union_left)) contact bad

end Graffiti384b.RichRoot
#print axioms Graffiti384b.RichRoot.supported_shore
#print axioms Graffiti384b.RichRoot.single_shore
