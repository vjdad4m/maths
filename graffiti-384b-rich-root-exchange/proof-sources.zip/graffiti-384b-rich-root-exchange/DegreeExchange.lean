import ComponentExchange
namespace Graffiti384b.RichRoot
open Finset SimpleGraph
open private Repair.nbr_add Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- With K kept in both trials, count its neighbors twice. No triangle condition is imposed. -/
def DegreeTest (S K : Finset V) (b : V) : Prop :=
  (∀v∈S,3≤nbr G v S+2*nbr G v K) ∧
  let T := S.filter (G.Adj b)
  (S.card+1)/2<T.card ∨ ∃v∈T,nbr G v (S\T)<nbr G v T

theorem degree_bound {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ) (test : DegreeTest G S (insert b (F∪S))ᶜ b) :
    gamma G≤Fintype.card V-(F.card+1+(S.card+1)/2) := by
  by_contra! bad
  let K := (insert b (F∪S))ᶜ
  let T := S.filter (G.Adj b)
  obtain ⟨L,R,ds,cover,l,r⟩ := Repair.asymmetric_cut G S
  have safe {A B : Finset V} (ab : Disjoint A B) (part : A∪B=S)
      (side : ∀v∈A,nbr G v A≤nbr G v B) (v : V) (va : v∈A) : 2≤nbr G v (B∪K) := by
    have asub : A⊆S := part ▸ subset_union_left
    have bsub : B⊆S := part ▸ subset_union_right
    have dk : Disjoint B K := disjoint_left.mpr (fun x xb xk =>
      mem_compl.mp xk (mem_insert_of_mem (mem_union_right F (bsub xb))))
    have d := test.1 v (asub va); change 3≤nbr G v S+2*nbr G v K at d
    rw [←part,Repair.nbr_add G v ab] at d
    rw [Repair.nbr_add G v dk]
    have h := side v va; omega
  have existT : T.Nonempty := by
    rcases test.2 with many|⟨v,vm,_⟩
    · apply card_pos.mp; change (S.card+1)/2<T.card at many; omega
    · exact ⟨v,vm⟩
  have trap := supported_shore G fs bf bs kf ks bk fixed ds cover (safe ds cover l)
    (safe ds.symm ((union_comm ..).trans cover) (fun v vm => (r v vm).le)) existT bad
  have endgame {A B : Finset V} (apart : Disjoint A B) (part : A∪B=S) (trapT : T⊆A)
      (eq : A.card=B.card+1) (side : ∀v∈A,nbr G v A≤nbr G v B) : False := by
    have size := card_union_of_disjoint apart; rw [part] at size
    rcases test.2 with many|⟨v,vm,more⟩
    · have le := card_le_card trapT; change (S.card+1)/2<T.card at many; omega
    · have sub : B⊆S\T := fun w wb => mem_sdiff.mpr
        ⟨part ▸ mem_union_right _ wb,fun wt => disjoint_left.mp apart (trapT wt) wb⟩
      exact (not_lt_of_ge ((Repair.nbr_mono G v trapT).trans
        ((side v (trapT vm)).trans (Repair.nbr_mono G v sub)))) more
  rcases trap with h|h
  · exact endgame ds cover h.1 h.2 l
  · exact endgame ds.symm ((union_comm ..).trans cover) h.1 h.2 (fun v vm => (r v vm).le)

def ExchangeReady (F S : Finset V) (b : V) : Prop :=
    (HasResidualPalette G S ∧ (ContactTest G S b ∨ RegionTest G S b)) ∨ DegreeTest G S (insert b (F∪S))ᶜ b

theorem reserve_bound {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ) (ready : ExchangeReady G F S b) :
    gamma G≤Fintype.card V-(F.card+1+(S.card+1)/2) := by
  rcases ready with ⟨pal,test⟩|test
  · exact exchange_bound G fs bf bs kf ks bk fixed pal test
  · exact degree_bound G fs bf bs kf ks bk fixed test

end Graffiti384b.RichRoot
#print axioms Graffiti384b.RichRoot.degree_bound
#print axioms Graffiti384b.RichRoot.reserve_bound
