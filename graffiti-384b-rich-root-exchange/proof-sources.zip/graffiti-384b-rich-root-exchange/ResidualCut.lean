import ContactShore
import EarPacking
namespace Graffiti384b.RichRoot
open Finset SimpleGraph OddStars PositivePalette EarPacking
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The graph induced on S with all other vertices left isolated. -/
def inside (S : Finset V) : SimpleGraph V where
  Adj v w := G.Adj v w ∧ v∈S ∧ w∈S
  symm := fun _ _ h => ⟨h.1.symm,h.2.2,h.2.1⟩
  loopless := fun v h => G.loopless v h.1

instance (S : Finset V) : DecidableRel (inside G S).Adj := fun _ _ => inferInstanceAs (Decidable (_∧_∧_))

abbrev triangleEdges (S : Finset V) := patch (inside G S) ∅

/-- The positive-score profile used only on S after deleting the fixed vertices. -/
def HasResidualPalette (S : Finset V) : Prop :=
    (∀v∈S,0<trianglesAt (inside G S) v) ∧
    ∀x∈S,∀y∈S,trianglesAt (inside G S) x=1 → trianglesAt (inside G S) y=1 →
      (triangleEdges G S).Reachable x y → x=y

def Split (J : SimpleGraph V) [DecidableRel J.Adj] (S L R : Finset V) : Prop :=
    Disjoint L R ∧ L∪R=S ∧ (∀v∈L,2≤nbr J v R) ∧ (∀v∈R,2≤nbr J v L)

theorem palette_split {S : Finset V} (pal : HasResidualPalette G S) :
    ∃L R,Split (triangleEdges G S) S L R := by
  classical
  let H := inside G S
  let J := triangleEdges G S
  let block (c : J.ConnectedComponent) := S.filter (fun v => J.connectedComponentMk v=c)
  have cov (c : J.ConnectedComponent) : Covered J (block c) := by
    by_cases has : ∃e∈block c,trianglesAt H e=1
    · obtain ⟨e,es,one⟩ := has
      obtain ⟨A,l,r⟩ := cover_rich_ear H one
      have sub : block c⊆insert e (rich H) := by
        intro x xs
        obtain ⟨xm,xc⟩ := mem_filter.mp xs
        obtain ⟨em,ec⟩ := mem_filter.mp es
        by_cases thin : trianglesAt H x=1
        · exact mem_insert.mpr (Or.inl (pal.2 x xm e em thin one (ConnectedComponent.eq.mp (xc.trans ec.symm))))
        · have pos := pal.1 x xm; change 0<trianglesAt H x at pos
          exact mem_insert_of_mem (mem_filter.mpr ⟨mem_univ _,by omega⟩)
      exact ⟨A,fun _ m => l _ (sub m),fun _ m => r _ (sub m)⟩
    · obtain ⟨A,l,r⟩ := covers_high J
      have sub : block c⊆high J := by
        intro x xs
        have pos := pal.1 x (mem_filter.mp xs).1; change 0<trianglesAt H x at pos
        have ne : trianglesAt H x≠1 := fun h => has ⟨x,xs,h⟩
        exact rich_high H (by omega : 2≤trianglesAt H x) ∅
      exact ⟨A,fun _ m => l _ (sub m),fun _ m => r _ (sub m)⟩
  choose witness lp rp using cov
  let A := univ.filter (fun v => v∈witness (J.connectedComponentMk v))
  have am (v : V) : v∈A ↔ v∈witness (J.connectedComponentMk v) := by simp [A]
  have l (v : V) (vs : v∈S) (va : v∈A) : 2≤nbr J v Aᶜ := by
    apply (lp _ v (mem_filter.mpr ⟨vs,rfl⟩) ((am v).mp va)).trans (card_le_card ?_)
    intro w wm
    obtain ⟨wk,vw⟩ := mem_filter.mp wm
    have eq : J.connectedComponentMk v=J.connectedComponentMk w := ConnectedComponent.eq.mpr vw.reachable
    exact mem_filter.mpr ⟨mem_compl.mpr (fun wa => mem_compl.mp wk (eq ▸ (am w).mp wa)),vw⟩
  have r (v : V) (vs : v∈S) (va : v∈Aᶜ) : 2≤nbr J v A := by
    apply (rp _ v (mem_filter.mpr ⟨vs,rfl⟩) (mem_compl.mpr (fun m => mem_compl.mp va ((am v).mpr m)))).trans (card_le_card ?_)
    intro w wm
    obtain ⟨wk,vw⟩ := mem_filter.mp wm
    have eq : J.connectedComponentMk v=J.connectedComponentMk w := ConnectedComponent.eq.mpr vw.reachable
    exact mem_filter.mpr ⟨(am w).mpr (eq ▸ wk),vw⟩
  have restrict (v : V) (P : Finset V) : nbr J v P≤nbr J v (S∩P) := by
    apply card_le_card
    intro w wm
    obtain ⟨wp,vw⟩ := mem_filter.mp wm
    exact mem_filter.mpr ⟨mem_inter.mpr ⟨vw.1.2.2,wp⟩,vw⟩
  refine ⟨S∩A,S∩Aᶜ,disjoint_left.mpr (fun v vl vr => mem_compl.mp (mem_inter.mp vr).2 (mem_inter.mp vl).2),
    by ext v; by_cases h : v∈A <;> simp [h],?_,?_⟩
  · intro v vm; exact (l v (mem_inter.mp vm).1 (mem_inter.mp vm).2).trans (restrict v Aᶜ)
  · intro v vm; exact (r v (mem_inter.mp vm).1 (mem_inter.mp vm).2).trans (restrict v A)

/-- Every failed donated omission leaves a certified bipartition of the residual graph.
All contacts lie on a shore of size exactly one more than its opposite. -/
theorem trapped_shore {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ) (pal : HasResidualPalette G S)
    (contact : (S.filter (G.Adj b)).Nonempty)
    (bad : Fintype.card V-(F.card+1+(S.card+1)/2)<gamma G) :
    ∃L R,Split (triangleEdges G S) S L R ∧ S.filter (G.Adj b)⊆L ∧ L.card=R.card+1 := by
  obtain ⟨L,R,apart,cover,l,r⟩ := palette_split G pal
  have mono (v : V) (P : Finset V) : nbr (triangleEdges G S) v P≤nbr G v P :=
    card_le_card (fun w wm => mem_filter.mpr ⟨(mem_filter.mp wm).1,(mem_filter.mp wm).2.1.1⟩)
  rcases single_shore G fs bf bs kf ks bk fixed apart cover
      (fun v vm => (l v vm).trans (mono ..)) (fun v vm => (r v vm).trans (mono ..)) contact bad with h|h
  · exact ⟨L,R,⟨apart,cover,l,r⟩,h⟩
  · exact ⟨R,L,⟨apart.symm,(union_comm ..).trans cover,r,l⟩,h⟩

/-- Either more than half (rounded up) of S contacts the pivot, or one contact
has at most one triangle-supported neighbor outside the contact set. -/
def ContactTest (S : Finset V) (b : V) : Prop :=
    let T := S.filter (G.Adj b)
    (S.card+1)/2<T.card ∨ ∃v∈T,nbr (triangleEdges G S) v (S\T)≤1

theorem donor_bound {F S : Finset V} {b k : V} (fs : Disjoint F S) (bf : b∉F) (bs : b∉S)
    (kf : k∉F) (ks : k∉S) (bk : G.Adj b k)
    (fixed : ∀v∈F,2≤nbr G v (insert b (F∪S))ᶜ) (pal : HasResidualPalette G S)
    (test : ContactTest G S b) : gamma G≤Fintype.card V-(F.card+1+(S.card+1)/2) := by
  by_contra! bad
  let T := S.filter (G.Adj b)
  have contact : T.Nonempty := by
    rcases test with many|⟨x,xt,_⟩
    · exact card_pos.mp (by change (S.card+1)/2<T.card at many; omega)
    · exact ⟨x,xt⟩
  obtain ⟨L,R,⟨ds,cover,l,_⟩,inc,sz⟩ := trapped_shore G fs bf bs kf ks bk fixed pal contact bad
  have size := card_union_of_disjoint ds; rw [cover] at size
  rcases test with large|⟨x,xt,few⟩
  · have le := card_le_card inc; omega
  · have sub : R⊆S\T := fun v vr => mem_sdiff.mpr
      ⟨cover ▸ mem_union_right _ vr,fun vt => disjoint_left.mp ds (inc vt) vr⟩
    have bound := (l x (inc xt)).trans (card_le_card (filter_subset_filter _ sub))
    change 2≤nbr (triangleEdges G S) x (S\T) at bound
    change nbr (triangleEdges G S) x (S\T)≤1 at few
    omega

end Graffiti384b.RichRoot
#print axioms Graffiti384b.RichRoot.palette_split
#print axioms Graffiti384b.RichRoot.trapped_shore
#print axioms Graffiti384b.RichRoot.donor_bound
