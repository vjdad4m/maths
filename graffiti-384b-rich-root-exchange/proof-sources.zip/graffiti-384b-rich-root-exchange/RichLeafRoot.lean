import DegreeExchange

namespace Graffiti384b.RichRoot
open Finset SimpleGraph
open private Prune.outside_zero from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

abbrev rootPool (r : V) := (nonleaves G).erase r
abbrev exchangePool (r e b : V) := (((nonleaves G).erase r).erase e).erase b

private theorem quota : (types G).card≤(nonleaves G).card+1 := by
  let I := (nonleaves G).image (trianglesAt G)
  have sub : types G⊆insert 0 I := by
    intro n nm; obtain ⟨v,_,rfl⟩ := mem_image.mp nm
    by_cases vm : v∈nonleaves G
    · exact mem_insert_of_mem (mem_image_of_mem _ vm)
    · exact mem_insert.mpr (Or.inl (Prune.outside_zero G vm))
  have cap := card_le_card sub
  have ins := card_insert_le 0 I
  have sz : I.card≤(nonleaves G).card := card_image_le
  omega

omit [DecidableEq V] in
private theorem outside {z : V} (leaf : G.degree z=1) : z∉nonleaves G := by
  intro h; have low := (mem_filter.mp h).2; omega

/-- Use the leaf as a permanent donor to r. All residual triangles are counted
after r has been removed. The root's original triangle count is unrestricted. -/
theorem root_exchange
    {r z : V} (rm : r∈nonleaves G) (rz : G.Adj r z) (leaf : G.degree z=1)
    (method : ExchangeReady G ∅ (rootPool G r) r) :
    gamma G≤bound G := by
  have val := reserve_bound G (F:=∅) (S:=rootPool G r) (b:=r) (k:=z) (by simp) (by simp)
    (fun h => (mem_erase.mp h).1 rfl) (by simp) (fun m => outside G leaf (erase_subset _ _ m)) rz
    (by simp) method
  have t := quota G
  have q := card_erase_of_mem rm
  have pos := card_pos.mpr ⟨r,rm⟩
  unfold bound; simp only [rootPool,card_empty,zero_add] at val; omega

/-- On z-r-e-b, keep the leaf z and the middle e and always omit r. The other
endpoint b can also be omitted whenever a retained contact supplies its second neighbor.
The path may have chords and e need not have degree two. -/
theorem path_exchange
    {r z e b : V} (rm : r∈nonleaves G) (em : e∈nonleaves G) (bm : b∈nonleaves G)
    (rz : G.Adj r z) (leaf : G.degree z=1) (re : G.Adj r e) (be : G.Adj b e) (br : b≠r)
    (method : ExchangeReady G {r} (exchangePool G r e b) b) :
    gamma G≤bound G := by
  let S := exchangePool G r e b
  have zm := outside G leaf
  have zr : z≠r := rz.ne.symm
  have ze : z≠e := fun eq => zm (eq ▸ em)
  have zb : z≠b := fun eq => zm (eq ▸ bm)
  have ns (v : V) (vm : v∈S) := mem_erase.mp (mem_erase.mp (mem_erase.mp vm).2).2
  have rns : r∉S := fun m => (ns r m).1 rfl
  have ens : e∉S := fun m => (mem_erase.mp (mem_erase.mp m).2).1 rfl
  have fixed : ∀v∈({r}:Finset V),2≤nbr G v (insert b (({r}:Finset V)∪S))ᶜ := by
    intro v vm; obtain rfl := mem_singleton.mp vm
    apply PinnedColor34.two G ze rz re
    · exact mem_compl.mpr (fun h => (mem_insert.mp h).elim zb (fun w =>
        (mem_union.mp w).elim (fun m => zr (mem_singleton.mp m)) (fun m => zm (ns z m).2)))
    · exact mem_compl.mpr (fun h => (mem_insert.mp h).elim be.ne.symm (fun w =>
        (mem_union.mp w).elim (fun m => re.ne.symm (mem_singleton.mp m)) ens))
  have v := reserve_bound G (F:={r}) (S:=S) (b:=b) (k:=e) (by simpa using rns)
    (by simpa using br) (fun h => (mem_erase.mp h).1 rfl) (by simpa using re.ne.symm) ens be fixed method
  have t := quota G
  have er : e∈(nonleaves G).erase r := mem_erase.mpr ⟨re.ne.symm,em⟩
  have bm' : b∈((nonleaves G).erase r).erase e := mem_erase.mpr ⟨be.ne,mem_erase.mpr ⟨br,bm⟩⟩
  have s1 := card_erase_add_one rm
  have s2 := card_erase_add_one er
  have s3 := card_erase_add_one bm'
  change S.card+1=_ at s3
  rw [card_singleton] at v
  unfold bound; omega

end Graffiti384b.RichRoot
#print axioms Graffiti384b.RichRoot.root_exchange
#print axioms Graffiti384b.RichRoot.path_exchange
