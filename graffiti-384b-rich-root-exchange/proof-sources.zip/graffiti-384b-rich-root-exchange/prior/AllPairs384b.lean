import Component384b
import Mathlib.Tactic.FinCases

namespace Graffiti384b.AllPairsExample
open Finset SimpleGraph

abbrev V := Fin 11

def neighbors : V → Finset V
  | 0 => {1,2,3,4,5,8,9}
  | 1 => {0,3,4,5,9}
  | 2 => {0,3,4,7,8}
  | 3 => {0,1,2,4,5,6,8}
  | 4 => {0,1,2,3,7,8,10}
  | 5 => {0,1,3,6}
  | 6 => {3,5,8}
  | 7 => {2,4,8}
  | 8 => {0,2,3,4,6,7}
  | 9 => {0,1}
  | 10 => {4}

def graph : SimpleGraph V where
  Adj u v := v ∈ neighbors u
  symm := by
    have h : ∀ u v : V, v ∈ neighbors u → u ∈ neighbors v := by decide
    intro u v adj
    exact h u v adj
  loopless := by
    have h : ∀ v : V, v ∉ neighbors v := by decide
    exact h

instance : DecidableRel graph.Adj := fun u v => inferInstanceAs (Decidable (v ∈ neighbors u))

theorem connected : graph.Connected := by
  apply (connected_iff_exists_forall_reachable graph).mpr
  refine ⟨0,fun v => ?_⟩
  have h : ∀ w : V, w = 0 ∨ graph.Adj 0 w ∨ ∃ u : V, graph.Adj 0 u ∧ graph.Adj u w := by decide
  rcases h v with rfl | ha | ⟨u,h₁,h₂⟩
  · exact Reachable.refl _
  · exact ha.reachable
  · exact h₁.reachable.trans h₂.reachable

set_option maxRecDepth 32768
set_option maxHeartbeats 10000000

theorem triangle_scores : List.ofFn (trianglesAt graph) = [11,6,8,12,10,4,2,3,9,1,0] := by decide

private instance (d : Finset V) : Decidable (TwoDominates graph d) := by
  unfold TwoDominates
  infer_instance

private theorem noFour :
    ((univ.erase (10 : V)).powersetCard 3).filter
      (fun z => TwoDominates graph (insert 10 z)) = ∅ := by decide

/-- Use the finite minimum-certificate pattern from the checked #398 proof. -/
theorem sharp : gamma graph = 5 ∧ bound graph = 5 := by
  let d : Finset V := {5,7,8,9,10}
  have hd : TwoDominates graph d := by unfold TwoDominates; decide
  have dc : d.card = 5 := by decide
  have lower : ∀ q : Finset V, q.card < 5 → ¬TwoDominates graph q := by
    intro q small good
    obtain ⟨a,qa,_,ac⟩ := exists_subsuperset_card_eq (subset_univ q) (show q.card ≤ 4 by omega)
      (show 4 ≤ (univ : Finset V).card by decide)
    have dom : TwoDominates graph a := fun v hv =>
      (good v (fun h => hv (qa h))).trans (card_le_card (filter_subset_filter _ qa))
    have leaf : (10 : V) ∈ a := by
      by_contra outside
      have h := dom 10 outside
      have upper : nbr graph 10 a ≤ nbr graph 10 univ :=
        card_le_card (filter_subset_filter _ (subset_univ _))
      have one : nbr graph 10 univ = 1 := by decide
      omega
    have listed : a.erase 10 ∈ ((univ.erase (10 : V)).powersetCard 3).filter
        (fun z => TwoDominates graph (insert 10 z)) := by
      apply mem_filter.mpr
      refine ⟨mem_powersetCard.mpr ⟨?_,by rw [card_erase_of_mem leaf,ac]⟩,?_⟩
      · exact fun v hv => mem_erase.mpr ⟨(mem_erase.mp hv).1,mem_univ _⟩
      · simpa only [insert_erase leaf] using dom
    rw [noFour] at listed
    exact not_mem_empty _ listed
  constructor
  · have upper : gamma graph ≤ 5 := Nat.sInf_le ⟨d,hd,dc⟩
    apply le_antisymm upper
    have ne : {k : ℕ | ∃ q, TwoDominates graph q ∧ q.card = k}.Nonempty := ⟨5,d,hd,dc⟩
    obtain ⟨q,good,eq⟩ := Nat.sInf_mem ne
    change 5 ≤ sInf _
    rw [← eq]
    exact Nat.le_of_not_gt (fun h => lower q h good)
  · decide

def anchors (u w : V) : Finset V := {u,w}
def common (u w : V) := neighbors u ∩ neighbors w
def flex (u w : V) (x : Finset V) := (anchors u w ∪ x)ᶜ

private def greedy (r : Finset V) : List V → Finset V → Finset V
  | [], _ => ∅
  | z :: rest, used =>
    let cl := Pins.clause graph r z
    if Disjoint cl used then insert z (greedy r rest (cl ∪ used)) else greedy r rest used

private def pack (u w : V) (x : Finset V) :=
  let r := flex u w x
  let b := Pins.rows graph r (anchors u w)
  let vs := (List.finRange 11).filter (fun z => decide (z ∈ b))
  let forced := fun z => decide (nbr graph z r ≠ 2)
  greedy r (vs.filter forced ++ vs.filter (fun z => !(forced z))) ∅

private def valid (u w : V) (x : Finset V) : Prop :=
  let r := flex u w x
  let s := pack u w x
  s ⊆ Pins.rows graph r (anchors u w) ∧
  (∀ i ∈ s, ∀ j ∈ s, i ≠ j → Disjoint (Pins.clause graph r i) (Pins.clause graph r j)) ∧
  x.card ≤ s.card + 1

private instance (u w : V) (x : Finset V) : Decidable (valid u w x) := by
  unfold valid
  infer_instance

private def failures (u w : V) := (common u w).powerset.filter (fun x => ¬valid u w x)

private theorem tab0 : ∀ w : V, (0 : V) ≠ w → failures 0 w = ∅ := by decide
private theorem tab1 : ∀ w : V, (1 : V) ≠ w → failures 1 w = ∅ := by decide
private theorem tab2 : ∀ w : V, (2 : V) ≠ w → failures 2 w = ∅ := by decide
private theorem tab3 : ∀ w : V, (3 : V) ≠ w → failures 3 w = ∅ := by decide
private theorem tab4 : ∀ w : V, (4 : V) ≠ w → failures 4 w = ∅ := by decide
private theorem tab5 : ∀ w : V, (5 : V) ≠ w → failures 5 w = ∅ := by decide
private theorem tab6 : ∀ w : V, (6 : V) ≠ w → failures 6 w = ∅ := by decide
private theorem tab7 : ∀ w : V, (7 : V) ≠ w → failures 7 w = ∅ := by decide
private theorem tab8 : ∀ w : V, (8 : V) ≠ w → failures 8 w = ∅ := by decide
private theorem tab9 : ∀ w : V, (9 : V) ≠ w → failures 9 w = ∅ := by decide
private theorem tab10 : ∀ w : V, (10 : V) ≠ w → failures 10 w = ∅ := by decide

private theorem table : ∀ u w : V, u ≠ w → failures u w = ∅ := by
  intro u
  fin_cases u
  · exact tab0
  · exact tab1
  · exact tab2
  · exact tab3
  · exact tab4
  · exact tab5
  · exact tab6
  · exact tab7
  · exact tab8
  · exact tab9
  · exact tab10

/-- For every choice of two distinct retained anchors, every set of common
neighbors assigned to permanent omission and every feasible extra pin set,
the symmetric cut cardinality estimate gives at most five omissions.
The graph actually admits six omissions, as sharp verifies. -/
theorem all_pairs_limit (u w : V) (ne : u ≠ w)
    (x p : Finset V) (sub : x ⊆ common u w) (pr : p ⊆ flex u w x)
    (ok : Pins.admissible graph (flex u w x) (anchors u w) p) :
    x.card + ((flex u w x \ p).card + 1)/2 < 6 := by
  classical
  have v : valid u w x := by
    by_contra nh
    have inF : x ∈ failures u w := mem_filter.mpr ⟨mem_powerset.mpr sub,nh⟩
    rw [table u w ne] at inF
    exact not_mem_empty _ inF
  obtain ⟨rows,sep,lower⟩ := v
  let r := flex u w x
  let s := pack u w x
  have rk : Disjoint r (anchors u w) := disjoint_left.mpr
    (fun _ h ha => mem_compl.mp h (mem_union_left _ ha))
  have hit := (Pins.admissible_iff_hit graph rk pr).mp ok
  have exists_pin : ∀ i ∈ s, ∃ z ∈ p, z ∈ Pins.clause graph r i := by
    intro i hi
    obtain ⟨z,hz⟩ := hit i (rows hi)
    exact ⟨z,(mem_inter.mp hz).2,(mem_inter.mp hz).1⟩
  let rep (i : V) := if h : i ∈ s then Classical.choose (exists_pin i h) else i
  have rp (i : V) (hi : i ∈ s) : rep i ∈ p ∧ rep i ∈ Pins.clause graph r i := by
    simpa [rep,hi] using Classical.choose_spec (exists_pin i hi)
  have pc : s.card ≤ p.card := card_le_card_of_injOn rep (fun i hi => (rp i hi).1) (by
    intro i hi j hj same
    by_contra ne
    exact disjoint_left.mp (sep i hi j hj ne) (rp i hi).2 (same ▸ (rp j hj).2))
  have ds : Disjoint (anchors u w) x := by
    apply disjoint_left.mpr
    intro z hz hx
    obtain ⟨h7,hw⟩ := mem_inter.mp (sub hx)
    rcases mem_insert.mp hz with rfl | h
    · exact graph.loopless _ h7
    · obtain rfl := mem_singleton.mp h
      exact graph.loopless _ hw
  have sizeA : (anchors u w).card = 2 := by simp [anchors,ne]
  have cr : (flex u w x).card = 11 - (2 + x.card) := by
    unfold flex
    rw [card_compl,card_union_of_disjoint ds,sizeA]
    rfl
  have cap := card_le_univ (s := anchors u w ∪ x)
  rw [card_union_of_disjoint ds,sizeA] at cap
  change _ ≤ 11 at cap
  have pp := card_le_card pr
  rw [cr] at pp
  rw [card_sdiff pr,cr]
  change x.card ≤ s.card+1 at lower
  omega

/-- A four-vertex flexible component fixes the one-unit shortfall. -/
theorem repaired_by_component : gamma graph ≤ Fintype.card V - 6 := by
  let x : Finset V := {2,4,8}
  let k : Finset V := {0,6,7,10}
  let f : Finset V := {1,3,5,9}
  have H := Component.star_component graph x k ∅ f 1 (by decide)
    (by decide) (by decide) (by decide) (by decide) (by decide) (by decide)
    (by decide) (by decide) (by decide) (by decide)
  have counts : x.card + (f.card-1) + ((∅ : Finset V).card+1)/2 = 6 := by decide
  rwa [counts] at H

end Graffiti384b.AllPairsExample

#print axioms Graffiti384b.AllPairsExample.connected
#print axioms Graffiti384b.AllPairsExample.triangle_scores
#print axioms Graffiti384b.AllPairsExample.sharp
#print axioms Graffiti384b.AllPairsExample.all_pairs_limit

#print axioms Graffiti384b.AllPairsExample.repaired_by_component
