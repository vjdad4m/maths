import Repair384b
import Mathlib.Data.Finset.Prod

namespace Graffiti384b.Anchor
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- High vertices available after assigning the anchors and common neighbors. -/
def residual (a x : Finset V) := high G \ (a ∪ x)

/-- Initially fixed retained vertices. -/
def retained (a x : Finset V) := (x ∪ residual G a x)ᶜ

/-- The vertices whose cut condition fails before any extra pins are selected. -/
def blocked (a x : Finset V) := (residual G a x).filter
  (fun z => G.degree z + nbr G z (retained G a x) < 3 + nbr G z x)

omit [Fintype V] [DecidableEq V] in
private theorem mono_nbr (v : V) {s t : Finset V} (h : s ⊆ t) : nbr G v s ≤ nbr G v t :=
  card_le_card (filter_subset_filter _ h)

omit [Fintype V] in
private theorem add_nbr (v : V) {s t : Finset V} (h : Disjoint s t) :
    nbr G v (s ∪ t) = nbr G v s + nbr G v t := by
  unfold nbr
  rw [filter_union]
  exact card_union_of_disjoint (h.mono (filter_subset _ _) (filter_subset _ _))

private theorem cut_identity (v : V) {x s : Finset V} (h : Disjoint x s) :
    nbr G v x + nbr G v s + nbr G v (x ∪ s)ᶜ = G.degree v := by
  rw [← add_nbr G v h, ← add_nbr G v disjoint_compl_right, union_compl]
  have e : (univ : Finset V).filter (G.Adj v) = G.neighborFinset v := by ext; simp
  simp [nbr,e]

/-- With a seed of size r, only degrees 3 through r+2 can obstruct the cut. -/
theorem blocked_degree {a x : Finset V} {v : V} (h : v ∈ blocked G a x) :
    3 ≤ G.degree v ∧ G.degree v ≤ x.card + 2 := by
  obtain ⟨hr,hh⟩ := mem_filter.mp h
  have hv := (mem_filter.mp (mem_sdiff.mp hr).1).2
  have hx : nbr G v x ≤ x.card := card_filter_le _ _
  exact ⟨hv,by omega⟩

private theorem residual_disj (a x : Finset V) : Disjoint x (residual G a x) :=
  disjoint_left.mpr (fun _ h hr => (mem_sdiff.mp hr).2 (mem_union_right _ h))

/-- Pin all initially blocked vertices. The rest of the residual set
still satisfies the two-sided maximum-cut condition. -/
theorem anchor_bound (a x : Finset V) (dax : Disjoint a x)
    (hx : ∀ v ∈ x, 2 ≤ nbr G v a) :
    gamma G ≤ Fintype.card V - (x.card + ((residual G a x).card - (blocked G a x).card + 1) / 2) := by
  let r := residual G a x
  let s := r \ blocked G a x
  let k := (x ∪ s)ᶜ
  have sr : s ⊆ r := sdiff_subset
  have xs := (residual_disj G a x).mono_right sr
  have ak : a ⊆ k := by
    intro z hz
    exact mem_compl.mpr (fun h => (mem_union.mp h).elim
      (fun h' => disjoint_left.mp dax hz h')
      (fun h' => (mem_sdiff.mp (sr h')).2 (mem_union_left _ hz)))
  have kk : retained G a x ⊆ k := compl_subset_compl.mpr (union_subset_union Subset.rfl sr)
  have H := Repair.seeded_cut G x k s
    (disjoint_left.mpr (fun _ hz hk => mem_compl.mp hk (mem_union_left _ hz)))
    xs (disjoint_left.mpr (fun _ hk hs => mem_compl.mp hk (mem_union_right _ hs)))
    (fun v hv => (hx v hv).trans (mono_nbr G v ak)) (by
      intro v hv
      have notbad := (mem_sdiff.mp hv).2
      have good : 3 + nbr G v x ≤ G.degree v + nbr G v (retained G a x) := by
        exact Nat.le_of_not_gt (fun h => notbad (mem_filter.mpr ⟨sr hv,h⟩))
      have hcount := cut_identity G v xs
      have hk := mono_nbr G v kk
      change _ + _ + nbr G v k = _ at hcount
      omega)
  have bsub : blocked G a x ⊆ r := filter_subset _ _
  simpa only [s, card_sdiff bsub] using H

/-- The accounting form of the certificate, allowing the cut to lose a
bounded number of vertices. A low seed can also be counted through anchor_bound. -/
theorem exact_of_charge (a x : Finset V) (dax : Disjoint a x)
    (hx : ∀ v ∈ x, 2 ≤ nbr G v a)
    (budget : (types G).card + (blocked G a x).card + a.card ≤ (high G).card + x.card) :
    gamma G ≤ bound G := by
  have H := anchor_bound G a x dax hx
  have hsplit : (high G).card ≤ (residual G a x).card + (a ∪ x).card := by
    calc
      _ ≤ ((residual G a x) ∪ (a ∪ x)).card := card_le_card (by
        intro v hv
        by_cases hh : v ∈ a ∪ x
        · exact mem_union_right _ hh
        · exact mem_union_left _ (mem_sdiff.mpr ⟨hv,hh⟩))
      _ ≤ _ := card_union_le _ _
  have := card_union_le a x
  unfold bound
  omega


/-- Number of r-subsets of a q-element pool hitting at least d-2 out
of d designated elements. This pessimistically grants the blocker d neighbors. -/
def weight (q r d : ℕ) := ∑ j ∈ range (r+1),
  if d ≤ j+2 then d.choose j * (q-d).choose (r-j) else 0

private theorem fiber_weight (a c : Finset V) (r : ℕ) (z : V) (hd : G.degree z ≤ c.card) :
    ((c.powersetCard r).filter (fun x => z ∈ blocked G a x)).card ≤
    weight c.card r (G.degree z) := by
  classical
  let d := G.degree z
  let f := (c.powersetCard r).filter (fun x => z ∈ blocked G a x)
  let nb := c.filter (G.Adj z)
  have nd : nb.card ≤ d := by
    simpa [d] using card_le_card (show nb ⊆ G.neighborFinset z from
      fun _ h => (G.mem_neighborFinset _ _).mpr (mem_filter.mp h).2)
  obtain ⟨p, np, pc, pd⟩ := exists_subsuperset_card_eq (filter_subset (G.Adj z) c) nd hd
  let index (x : Finset V) := (x ∩ p).card
  have basics {x : Finset V} (h : x ∈ f) : x ⊆ c ∧ x.card = r :=
    mem_powersetCard.mp (mem_filter.mp h).1
  have split := card_eq_sum_card_fiberwise (s := f) (t := range (r+1)) (f := index) (by
    intro x hx
    apply mem_range.mpr
    have := card_le_card (inter_subset_left (s₂ := p) (s₁ := x))
    have := (basics hx).2
    dsimp [index]
    omega)
  change f.card ≤ _
  rw [split]
  apply sum_le_sum
  intro j hj
  by_cases thresh : d ≤ j+2
  · let target := (p.powersetCard j) ×ˢ ((c \ p).powersetCard (r-j))
    have H : (f.filter (fun x => index x = j)).card ≤ target.card :=
      card_le_card_of_injOn (fun x => (x ∩ p,x \ p)) (by
        intro x hx
        obtain ⟨h,eq⟩ := mem_filter.mp hx
        have sub := (basics h).1
        apply mem_product.mpr
        refine ⟨mem_powersetCard.mpr ⟨inter_subset_right,eq⟩,mem_powersetCard.mpr ⟨?_,?_⟩⟩
        · exact fun w hw => mem_sdiff.mpr ⟨sub (mem_sdiff.mp hw).1,(mem_sdiff.mp hw).2⟩
        · change (x \ p).card = r-j
          have hcard := card_sdiff_add_card_inter x p
          change (x ∩ p).card = j at eq
          rw [(basics h).2,eq] at hcard
          omega) (by
        intro x _ y _ h
        have h₁ := congrArg Prod.fst h
        have h₂ := congrArg Prod.snd h
        change x ∩ p = y ∩ p at h₁
        change x \ p = y \ p at h₂
        calc
          x = (x ∩ p) ∪ (x \ p) := (by rw [union_comm,sdiff_union_inter])
          _ = (y ∩ p) ∪ (y \ p) := by rw [h₁,h₂]
          _ = y := by rw [union_comm,sdiff_union_inter])
    simpa only [target,card_product,card_powersetCard,card_sdiff pc,pd,if_pos thresh,d] using H
  · have empty : f.filter (fun x => index x = j) = ∅ := by
      apply filter_eq_empty_iff.mpr
      intro x hx eq
      have bound := (mem_filter.mp (mem_filter.mp hx).2).2
      have cap : nbr G z x ≤ index x := card_le_card (by
        intro v hv
        obtain ⟨vx,adj⟩ := mem_filter.mp hv
        exact mem_inter.mpr ⟨vx,np (mem_filter.mpr ⟨(basics hx).1 vx,adj⟩)⟩)
      change d + _ < _ at bound
      omega
    simp [empty,show ¬ G.degree z ≤ j+2 from thresh]

private theorem swap_blockers (a c : Finset V) (r : ℕ) :
    ∑ x ∈ c.powersetCard r, (blocked G a x).card =
    ∑ z ∈ high G, ((c.powersetCard r).filter (fun x => z ∈ blocked G a x)).card := by
  classical
  calc
    _ = ∑ x ∈ c.powersetCard r, ∑ z ∈ high G, (if z ∈ blocked G a x then 1 else 0 : ℕ) := by
      apply sum_congr rfl
      intro x _
      rw [Finset.sum_boole]
      have eq : (high G).filter (fun z => z ∈ blocked G a x) = blocked G a x := by
        ext z
        constructor
        · exact fun h => (mem_filter.mp h).2
        · exact fun h => mem_filter.mpr ⟨(mem_sdiff.mp (mem_filter.mp h).1).1,h⟩
      simp [eq]
    _ = _ := by rw [sum_comm]; simp only [Finset.sum_boole,Nat.cast_id]

/-- A local double count covers every fixed-size common-neighbor seed. -/
theorem exact_of_anchor_average (a c : Finset V) (r : ℕ) (dac : Disjoint a c)
    (hc : ∀ z ∈ c, 2 ≤ nbr G z a)
    (budget : ℕ) (fit : (types G).card + budget + a.card ≤ (high G).card + r)
    (light : ∑ v ∈ high G, ((c.powersetCard r).filter (fun x => v ∈ blocked G a x)).card <
      (budget+1)*c.card.choose r) : gamma G ≤ bound G := by
  by_contra! fail
  have large (x : Finset V) (hx : x ∈ c.powersetCard r) : budget+1 ≤ (blocked G a x).card := by
    obtain ⟨sub,card⟩ := mem_powersetCard.mp hx
    by_contra! h
    exact (not_le_of_gt fail) (exact_of_charge G a x (dac.mono_right sub)
      (fun z hz => hc z (sub hz)) (by omega))
  have H := sum_le_sum large
  rw [swap_blockers] at H
  simp only [sum_const, nsmul_eq_mul, card_powersetCard] at H
  rw [Nat.mul_comm] at light
  exact (not_lt_of_ge H) light


def coefficient (q r lo j : ℕ) :=
  if lo ≤ j then weight q r j - weight q r (j+1) else 0

/-- The assumptions on coefficients and mass are arithmetic on a finite list.
At each cumulative degree cutoff the earlier triangle-diversity estimate
bounds the number of possible blockers. -/
theorem exact_of_profile_average (a c : Finset V) (q r lo e budget : ℕ)
    (aq : a.card = 2) (qsize : q ≤ c.card) (qr : r+2 ≤ q) (lo2 : 2 ≤ lo)
    (dac : Disjoint a c) (hc : ∀ z ∈ c, 2 ≤ nbr G z a)
    (types_eq : (types G).card = (high G).card + e)
    (fit : e + budget + 2 ≤ r)
    (localDegree : ∀ x ⊆ c, ∀ z ∈ blocked G a x, lo ≤ G.degree z)
    (upper : ∀ d : Fin (r+3), lo ≤ d.val → weight q r d.val ≤
      ∑ j ∈ range (r+3), (if d.val ≤ j then coefficient q r lo j else 0))
    (mass : ∑ j ∈ range (r+3), coefficient q r lo j * (j.choose 2 + 1 - e) <
      (budget+1)*q.choose r) : gamma G ≤ bound G := by
  classical
  obtain ⟨p,pc,pq⟩ := exists_subset_card_eq qsize
  apply exact_of_anchor_average G a p r (dac.mono_right pc) (fun z hz => hc z (pc hz)) budget (by omega)
  rw [pq]
  let w := coefficient q r lo
  let choices := p.powersetCard r
  have point (z : V) : (choices.filter (fun x => z ∈ blocked G a x)).card ≤
      ∑ j ∈ range (r+3), (if G.degree z ≤ j then w j else 0) := by
    by_cases present : (choices.filter (fun x => z ∈ blocked G a x)).Nonempty
    · obtain ⟨x,hx⟩ := present
      obtain ⟨hin,hz⟩ := mem_filter.mp hx
      obtain ⟨sub,xc⟩ := mem_powersetCard.mp hin
      have dl := localDegree x (sub.trans pc) z hz
      have du := (blocked_degree G hz).2
      have f := fiber_weight G a p r z (by omega)
      rw [pq] at f
      exact f.trans (upper ⟨G.degree z,by omega⟩ dl)
    · rw [not_nonempty_iff_eq_empty.mp present,card_empty]
      exact Nat.zero_le _
  have hw (j : ℕ) :
      (∑ z ∈ high G, if G.degree z ≤ j then w j else 0) ≤ w j * (j.choose 2 + 1-e) := by
    rw [← sum_filter, sum_const, nsmul_eq_mul,Nat.mul_comm]
    by_cases lj : lo ≤ j
    · have h := Repair.profile_count G j (by omega)
      apply Nat.mul_le_mul_left
      simp only [Nat.cast_id]
      omega
    · simp [w,coefficient,lj]
  calc
    _ ≤ ∑ z ∈ high G, ∑ j ∈ range (r+3), (if G.degree z ≤ j then w j else 0) :=
      sum_le_sum (fun z _ => point z)
    _ = ∑ j ∈ range (r+3), ∑ z ∈ high G, (if G.degree z ≤ j then w j else 0) := sum_comm
    _ ≤ _ := sum_le_sum (fun j _ => hw j)
    _ < _ := mass

/-- No locality restriction is needed for degree three and higher. -/
private theorem lowThree (a c : Finset V) :
    ∀ x ⊆ c, ∀ z ∈ blocked G a x, 3 ≤ G.degree z :=
  fun _ _ _ hz => (blocked_degree G hz).1

private theorem pair_data {u v : V} (ne : u ≠ v) :
    let a : Finset V := {u,v}
    let c := (G.neighborFinset u) ∩ (G.neighborFinset v)
    a.card = 2 ∧ Disjoint a c ∧ (∀ z ∈ c, 2 ≤ nbr G z a) := by
  dsimp only
  refine ⟨by simp [ne], disjoint_left.mpr ?_, ?_⟩
  · intro z hz h
    rcases mem_insert.mp hz with rfl | hh
    · exact G.not_mem_neighborFinset_self _ (mem_inter.mp h).1
    · obtain rfl := mem_singleton.mp hh
      exact G.not_mem_neighborFinset_self _ (mem_inter.mp h).2
  · intro z hz
    obtain ⟨h₁,h₂⟩ := mem_inter.mp hz
    have adj₁ := ((G.mem_neighborFinset _ _).mp h₁).symm
    have adj₂ := ((G.mem_neighborFinset _ _).mp h₂).symm
    have eq : ({u,v} : Finset V).filter (G.Adj z) = {u,v} := by
      apply filter_true_of_mem
      intro y hy
      rcases mem_insert.mp hy with rfl | h
      · exact adj₁
      · simpa only [mem_singleton.mp h] using adj₂
    simp [nbr,eq,ne]

set_option maxRecDepth 10000 in
/-- Any two distinct vertices with 21 common neighbors force the exact
catalogue bound, regardless of their adjacency or the order of the graph. -/
theorem exact_of_twenty_one_common {u v : V} (ne : u ≠ v)
    (large : 21 ≤ ((G.neighborFinset u) ∩ (G.neighborFinset v)).card) :
    gamma G ≤ bound G := by
  let a : Finset V := {u,v}
  let c := G.neighborFinset u ∩ G.neighborFinset v
  obtain ⟨size,dis,support⟩ := pair_data G ne
  by_cases basic : (types G).card ≤ (high G).card
  · exact exact_of_high G (by omega)
  have cap := type_bound G
  by_cases one : (types G).card = (high G).card + 1
  · exact exact_of_profile_average G a c 21 6 3 1 3 size large (by decide) (by decide)
      dis support one (by decide) (lowThree G a c) (by decide) (by decide)
  · exact exact_of_profile_average G a c 21 6 3 2 2 size large (by decide) (by decide)
      dis support (by omega) (by decide) (lowThree G a c) (by decide) (by decide)


/-- Check only vertices below lo. Counting neighbors in the full candidate pool
overestimates losses from any individual seed. Anchors stay retained. -/
theorem local_degree_of_screen (a c : Finset V) (lo : ℕ) (dac : Disjoint a c)
    (screen : ∀ z ∈ high G, G.degree z < lo → z ∉ a →
      3 + nbr G z c ≤ G.degree z + nbr G z a ∨ 2 ≤ nbr G z a) :
    ∀ x ⊆ c, ∀ z ∈ blocked G a x, lo ≤ G.degree z := by
  intro x xc z hz
  obtain ⟨hr,hh⟩ := mem_filter.mp hz
  obtain ⟨highz,notin⟩ := mem_sdiff.mp hr
  have za : z ∉ a := fun ha => notin (mem_union_left _ ha)
  have ax := dac.mono_right xc
  have ak : a ⊆ retained G a x := by
    intro w hw
    apply mem_compl.mpr
    intro h
    exact (mem_union.mp h).elim (fun h' => disjoint_left.mp ax hw h')
      (fun h' => (mem_sdiff.mp h').2 (mem_union_left _ hw))
  have pin := mono_nbr G z ak
  have loss := mono_nbr G z xc
  by_contra! small
  rcases screen z highz small za with h | h
  · omega
  · have H := cut_identity G z (residual_disj G a x)
    change _ + _ + nbr G z (retained G a x) = _ at H
    omega

set_option maxRecDepth 10000 in
/-- When the cubic vertices cannot be blocked at these anchors, 19 common
neighbors suffice. The test concerns at most three cubics under failure. -/
theorem exact_of_nineteen_common {u v : V} (ne : u ≠ v)
    (large : 19 ≤ (G.neighborFinset u ∩ G.neighborFinset v).card)
    (screen : ∀ z ∈ high G, G.degree z < 4 → z ∉ ({u,v} : Finset V) →
      3 + nbr G z (G.neighborFinset u ∩ G.neighborFinset v) ≤ G.degree z + nbr G z {u,v} ∨
      2 ≤ nbr G z {u,v}) : gamma G ≤ bound G := by
  let a : Finset V := {u,v}
  let c := G.neighborFinset u ∩ G.neighborFinset v
  obtain ⟨size,dis,support⟩ := pair_data G ne
  change _ ≤ c.card at large
  have localD := local_degree_of_screen G a c 4 dis screen
  by_cases basic : (types G).card ≤ (high G).card
  · exact exact_of_high G (by omega)
  have cap := type_bound G
  by_cases one : (types G).card = (high G).card + 1
  · exact exact_of_profile_average G a c 16 4 4 1 1 size (by omega) (by decide) (by decide)
      dis support one (by decide) localD (by decide) (by decide)
  · exact exact_of_profile_average G a c 19 5 4 2 1 size large (by decide) (by decide)
      dis support (by omega) (by decide) localD (by decide) (by decide)

set_option maxRecDepth 10000 in
/-- Screening both cubic and quartic vertices reduces the threshold to 14. -/
theorem exact_of_fourteen_common {u v : V} (ne : u ≠ v)
    (large : 14 ≤ (G.neighborFinset u ∩ G.neighborFinset v).card)
    (screen : ∀ z ∈ high G, G.degree z < 5 → z ∉ ({u,v} : Finset V) →
      3 + nbr G z (G.neighborFinset u ∩ G.neighborFinset v) ≤ G.degree z + nbr G z {u,v} ∨
      2 ≤ nbr G z {u,v}) : gamma G ≤ bound G := by
  let a : Finset V := {u,v}
  let c := G.neighborFinset u ∩ G.neighborFinset v
  obtain ⟨size,dis,support⟩ := pair_data G ne
  change _ ≤ c.card at large
  have localD := local_degree_of_screen G a c 5 dis screen
  by_cases basic : (types G).card ≤ (high G).card
  · exact exact_of_high G (by omega)
  have cap := type_bound G
  by_cases one : (types G).card = (high G).card + 1
  · exact exact_of_profile_average G a c 12 4 5 1 1 size (by omega) (by decide) (by decide)
      dis support one (by decide) localD (by decide) (by decide)
  · exact exact_of_profile_average G a c 14 4 5 2 0 size large (by decide) (by decide)
      dis support (by omega) (by decide) localD (by decide) (by decide)

/-- Small diversity follows directly from the thick-edge alternative. -/
theorem exact_of_six_types (hc : G.Connected) (hn : 2 < Fintype.card V)
    (ht : (types G).card ≤ 6) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨v,_,hm⟩ := exists_max_image (univ : Finset V) (trianglesAt G) (by
    obtain ⟨x⟩ := hc.nonempty
    exact ⟨x,mem_univ _⟩)
  obtain ⟨u,hu,thick⟩ := (Repair.necessary_profile G hc hn fail).2.2.2.1 v (fun z => hm z (mem_univ _))
  have ne := ((G.mem_neighborFinset _ _).mp hu).ne
  let a : Finset V := {v,u}
  let c := G.neighborFinset v ∩ G.neighborFinset u
  obtain ⟨_,dis,support⟩ := pair_data G ne
  have eq : (G.neighborFinset v).filter (G.Adj u) = c := by
    ext z
    simp [c]
  change 3 ≤ ((G.neighborFinset v).filter (G.Adj u)).card at thick
  rw [eq] at thick
  have H := anchor_bound G a c dis support
  unfold bound at fail
  omega

end Graffiti384b.Anchor

#print axioms Graffiti384b.Anchor.blocked_degree
#print axioms Graffiti384b.Anchor.anchor_bound
#print axioms Graffiti384b.Anchor.exact_of_anchor_average
#print axioms Graffiti384b.Anchor.exact_of_profile_average
#print axioms Graffiti384b.Anchor.exact_of_twenty_one_common
#print axioms Graffiti384b.Anchor.exact_of_nineteen_common
#print axioms Graffiti384b.Anchor.exact_of_fourteen_common
#print axioms Graffiti384b.Anchor.exact_of_six_types
