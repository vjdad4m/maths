import Component384b

namespace Graffiti384b.Capacity
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The part of a flexible block which can be omitted while k is kept. -/
def Feasible (r k o : Finset V) : Prop :=
  o ⊆ r ∧ ∀ v ∈ o, 2 ≤ nbr G v (k ∪ (r \ o))

instance (r k o : Finset V) : Decidable (Feasible G r k o) := by
  unfold Feasible
  infer_instance

def value (r k : Finset V) : ℕ :=
  ((r.powerset.filter (Feasible G r k)).sup Finset.card)

theorem le_value {r k o : Finset V} (h : Feasible G r k o) : o.card ≤ value G r k :=
  le_sup (mem_filter.mpr ⟨mem_powerset.mpr h.1,h⟩)

theorem attained (r k : Finset V) : ∃ o, Feasible G r k o ∧ o.card = value G r k := by
  let opts := r.powerset.filter (Feasible G r k)
  have empty : Feasible G r k ∅ := ⟨empty_subset _,by simp⟩
  obtain ⟨o,ho,best⟩ := exists_max_image opts Finset.card
    ⟨∅,mem_filter.mpr ⟨mem_powerset.mpr empty.1,empty⟩⟩
  have ok := (mem_filter.mp ho).2
  exact ⟨o,ok,le_antisymm (le_value G ok) (Finset.sup_le best)⟩

theorem mono_kept {r k l : Finset V} (h : k ⊆ l) : value G r k ≤ value G r l := by
  obtain ⟨o,⟨orr,good⟩,vo⟩ := attained G r k
  rw [← vo]
  apply le_value G ⟨orr,?_⟩
  intro v hv
  exact (good v hv).trans (card_le_card (filter_subset_filter _ (union_subset_union h Subset.rfl)))

omit [Fintype V] in
private theorem local_nbr {r s x y k : Finset V} (ys : y ⊆ s) (separate : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w) {v : V} (vr : v ∈ r) :
    nbr G v (k ∪ ((r ∪ s) \ (x ∪ y))) = nbr G v (k ∪ (r \ x)) := by
  unfold nbr
  congr 1
  ext w
  by_cases adj : G.Adj v w
  · have ws : w ∉ s := fun h => separate v vr w h adj
    have wy : w ∉ y := fun h => ws (ys h)
    simp [adj,ws,wy]
  · simp [adj]

/-- The optimum is additive over arbitrary anticomplete blocks. -/
theorem separated_add (r s k : Finset V) (rs : Disjoint r s)
    (sep : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w) :
    value G (r ∪ s) k = value G r k + value G s k := by
  have rev (v : V) (hv : v ∈ s) (w : V) (hw : w ∈ r) : ¬G.Adj v w :=
    fun h => sep w hw v hv h.symm
  have decomp {x y : Finset V} (xr : x ⊆ r) (ys : y ⊆ s) :
      Feasible G (r ∪ s) k (x ∪ y) ↔ Feasible G r k x ∧ Feasible G s k y := by
    have first (v : V) (hv : v ∈ x) := local_nbr G (k := k) (x := x) ys sep (xr hv)
    have second (v : V) (hv : v ∈ y) := local_nbr G (k := k) (x := y) xr rev (ys hv)
    simp only [union_comm s r,union_comm y x] at second
    constructor
    · intro h
      exact ⟨⟨xr,fun v hv => (first v hv) ▸ h.2 v (mem_union_left _ hv)⟩,
        ⟨ys,fun v hv => (second v hv) ▸ h.2 v (mem_union_right _ hv)⟩⟩
    · rintro ⟨h,j⟩
      refine ⟨union_subset_union xr ys,?_⟩
      intro v hv
      rcases mem_union.mp hv with h₁ | h₂
      · rw [first v h₁]; exact h.2 v h₁
      · rw [second v h₂]; exact j.2 v h₂
  apply le_antisymm
  · obtain ⟨o,ok,vo⟩ := attained G (r ∪ s) k
    rw [← vo]
    have split : o ∩ r ∪ o ∩ s = o := by rw [← inter_union_distrib_left,inter_eq_left.mpr ok.1]
    have both := (decomp (x := o ∩ r) (y := o ∩ s) inter_subset_right inter_subset_right).mp (by rw [split]; exact ok)
    have d := rs.mono (inter_subset_right (s₁ := o)) (inter_subset_right (s₁ := o))
    have count := card_union_of_disjoint d
    rw [split] at count
    rw [count]
    exact Nat.add_le_add (le_value G both.1) (le_value G both.2)
  · obtain ⟨x,h,vx⟩ := attained G r k
    obtain ⟨y,j,vy⟩ := attained G s k
    rw [← vx,← vy]
    have good := (decomp h.1 j.1).mpr ⟨h,j⟩
    simpa only [card_union_of_disjoint (rs.mono h.1 j.1)] using le_value G good

omit [Fintype V] in
private theorem nbr_add (v : V) {s t : Finset V} (d : Disjoint s t) :
    nbr G v (s ∪ t) = nbr G v s + nbr G v t := by
  unfold nbr
  rw [filter_union,card_union_of_disjoint (d.mono (filter_subset _ _) (filter_subset _ _))]

/-- A valid cut supplies the half-size baseline inside a single block. -/
theorem half_le (r k : Finset V) (d : Disjoint r k)
    (weighted : ∀ z ∈ r, 3 ≤ nbr G z r + 2*nbr G z k) :
    (r.card+1)/2 ≤ value G r k := by
  obtain ⟨a,b,ab,eq,left,right⟩ := Repair.asymmetric_cut G r
  have size := card_union_of_disjoint ab
  rw [eq] at size
  have side {p q : Finset V} (sep : Disjoint p q) (u : p ∪ q = r)
      (cut : ∀ v ∈ p, nbr G v p ≤ nbr G v q) : p.card ≤ value G r k := by
    have pr : p ⊆ r := u ▸ subset_union_left
    have qr : q ⊆ r := u ▸ subset_union_right
    apply le_value G ⟨pr,?_⟩
    intro v hv
    have diff : r \ p = q := by
      rw [← u]
      ext w
      by_cases h : w ∈ p
      · simp [h,fun hh => disjoint_left.mp sep h hh]
      · simp [h]
    rw [diff,nbr_add G v (d.symm.mono_right qr)]
    have h := weighted v (pr hv)
    rw [← u,nbr_add G v sep] at h
    have := cut v hv
    omega
  have A := side ab eq left
  have B := side ab.symm ((union_comm _ _).trans eq) (fun z hz => (right z hz).le)
  omega

/-- Combine the exact component optimum with the earlier three-clause pin test. -/
theorem pinned_separated (r k p f s : Finset V) (rk : Disjoint r k) (pr : p ⊆ r)
    (hits : ∀ v ∈ Pins.rows G r k, ((Pins.clause G r v) ∩ p).Nonempty)
    (parts : f ∪ s = r \ p) (fs : Disjoint f s) (sep : ∀ v ∈ f, ∀ w ∈ s, ¬G.Adj v w) :
    value G f (k ∪ p) + (s.card+1)/2 ≤ value G r k := by
  have good := (Pins.admissible_iff_hit G rk pr).mpr hits
  have sk : Disjoint s (k ∪ p) := by
    refine disjoint_left.mpr ?_
    intro z zs hk
    have zr : z ∈ r \ p := parts ▸ mem_union_right f zs
    exact (mem_union.mp hk).elim (fun h => disjoint_left.mp rk (mem_sdiff.mp zr).1 h) (mem_sdiff.mp zr).2
  have side := half_le G s (k ∪ p) sk (by
    intro z zs
    have h := good z (parts ▸ mem_union_right f zs)
    rw [← parts,nbr_add G z fs] at h
    have empty : f.filter (G.Adj z) = ∅ := filter_eq_empty_iff.mpr (fun w hw h => sep w hw z zs h.symm)
    simpa [nbr,empty] using h)
  have combined := separated_add G f s (k ∪ p) fs sep
  rw [parts] at combined
  obtain ⟨o,ok,vo⟩ := attained G (r \ p) (k ∪ p)
  have lift : Feasible G r k o := by
    refine ⟨ok.1.trans sdiff_subset,?_⟩
    intro z hz
    apply (ok.2 z hz).trans
    apply card_le_card (filter_subset_filter _ ?_)
    intro w hw
    rcases mem_union.mp hw with wk | wr
    · rcases mem_union.mp wk with wk | wp
      · exact mem_union_left _ wk
      · exact mem_union_right _ (mem_sdiff.mpr ⟨pr wp,fun h => (mem_sdiff.mp (ok.1 h)).2 wp⟩)
    · exact mem_union_right _ (mem_sdiff.mpr ⟨(mem_sdiff.mp (mem_sdiff.mp wr).1).1,(mem_sdiff.mp wr).2⟩)
  have := le_value G lift
  omega

theorem seeded_value (x r k : Finset V) (xr : Disjoint x r) (xk : Disjoint x k)
    (rk : Disjoint r k) (seed : ∀ z ∈ x, 2 ≤ nbr G z k) :
    gamma G ≤ Fintype.card V - (x.card + value G r k) := by
  obtain ⟨o,ok,vo⟩ := attained G r k
  rw [← vo]
  have xo := xr.mono_right ok.1
  have kd : k ⊆ (x ∪ o)ᶜ := fun z hz => mem_compl.mpr (fun h =>
    (mem_union.mp h).elim (fun hx => disjoint_left.mp xk hx hz) (fun ho => disjoint_left.mp rk (ok.1 ho) hz))
  have rest : r \ o ⊆ (x ∪ o)ᶜ := fun z hz => mem_compl.mpr (fun h =>
    (mem_union.mp h).elim (fun hx => disjoint_left.mp xr hx (mem_sdiff.mp hz).1) (mem_sdiff.mp hz).2)
  have dom : TwoDominates G (x ∪ o)ᶜ := by
    intro z hz
    have inside : z ∈ x ∪ o := by simpa only [mem_compl,not_not] using hz
    rcases mem_union.mp inside with h | h
    · exact (seed z h).trans (card_le_card (filter_subset_filter _ kd))
    · exact (ok.2 z h).trans (card_le_card (filter_subset_filter _ (union_subset kd rest)))
  have H : gamma G ≤ (x ∪ o)ᶜ.card := Nat.sInf_le ⟨_,dom,rfl⟩
  simpa only [card_compl,card_union_of_disjoint xo] using H

end Graffiti384b.Capacity

#print axioms Graffiti384b.Capacity.separated_add
#print axioms Graffiti384b.Capacity.pinned_separated
#print axioms Graffiti384b.Capacity.seeded_value
