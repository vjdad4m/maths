import Pin384b

namespace Graffiti384b.Component
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Separate a component of the flexible vertices with a center adjacent
to every other vertex. If all other vertices have at most two neighbors
in the component, the ordinary cut hypothesis gives each a kept neighbor.
They may all be omitted simultaneously when their center is kept. -/
theorem star_component (x k s f : Finset V) (c : V) (center : c ∈ f)
    (xk : Disjoint x k) (xs : Disjoint x s) (xf : Disjoint x f)
    (ks : Disjoint k s) (kf : Disjoint k f) (sf : Disjoint s f)
    (separated : ∀ z ∈ s, ∀ w ∈ f, ¬G.Adj z w)
    (seed : ∀ z ∈ x, 2 ≤ nbr G z k)
    (old : ∀ z ∈ s ∪ f, 3 ≤ nbr G z (s ∪ f) + 2*nbr G z k)
    (spokes : ∀ z ∈ f.erase c, G.Adj z c ∧ nbr G z f ≤ 2) :
    gamma G ≤ Fintype.card V - (x.card + (f.card-1) + (s.card+1)/2) := by
  have ck : c ∉ k := fun h => disjoint_left.mp kf h center
  have cs : c ∉ s := fun h => disjoint_left.mp sf h center
  have cx : c ∉ x := fun h => disjoint_left.mp xf h center
  have split (z : V) : nbr G z (s ∪ f) = nbr G z s + nbr G z f := by
    unfold nbr
    rw [filter_union,card_union_of_disjoint (sf.mono (filter_subset _ _) (filter_subset _ _))]
  have more (z : V) : nbr G z k ≤ nbr G z (insert c k) :=
    card_le_card (filter_subset_filter _ (subset_insert _ _))
  have H := Repair.seeded_cut G (x ∪ f.erase c) (insert c k) s
    (disjoint_left.mpr (by
      intro z hz h
      rcases mem_insert.mp h with rfl | hk
      · exact (mem_union.mp hz).elim cx (not_mem_erase _ _)
      · exact (mem_union.mp hz).elim (fun hh => disjoint_left.mp xk hh hk)
          (fun hh => disjoint_left.mp kf hk (mem_erase.mp hh).2)))
    (Finset.disjoint_union_left.mpr ⟨xs,sf.symm.mono_left (erase_subset _ _)⟩)
    (by simpa [disjoint_insert_left] using And.intro cs ks)
    (by
      intro z hz
      rcases mem_union.mp hz with hx | hz
      · exact (seed z hx).trans (more z)
      · obtain ⟨adj,degree⟩ := spokes z hz
        have zf := (mem_erase.mp hz).2
        have empty : s.filter (G.Adj z) = ∅ := filter_eq_empty_iff.mpr
          (fun w hw h => separated w hw z zf h.symm)
        have zero : nbr G z s = 0 := by simp [nbr,empty]
        have h := old z (mem_union_right _ zf)
        rw [split,zero,zero_add] at h
        have e : (insert c k).filter (G.Adj z) = insert c (k.filter (G.Adj z)) := by
          ext y
          by_cases e : y = c
          · subst y
            simp [adj]
          · simp [e]
        have nc : c ∉ k.filter (G.Adj z) := fun h' => ck (mem_filter.mp h').1
        change 2 ≤ ((insert c k).filter (G.Adj z)).card
        rw [e,card_insert_of_not_mem nc]
        change _ + 2*(k.filter (G.Adj z)).card ≥ 3 at h
        omega)
    (by
      intro z hz
      have empty : f.filter (G.Adj z) = ∅ := filter_eq_empty_iff.mpr (separated z hz)
      have zero : nbr G z f = 0 := by simp [nbr,empty]
      have h := old z (mem_union_left _ hz)
      rw [split,zero,add_zero] at h
      have := more z
      omega)
  simpa only [card_union_of_disjoint (xf.mono_right (erase_subset c f)),card_erase_of_mem center] using H

end Graffiti384b.Component

#print axioms Graffiti384b.Component.star_component
