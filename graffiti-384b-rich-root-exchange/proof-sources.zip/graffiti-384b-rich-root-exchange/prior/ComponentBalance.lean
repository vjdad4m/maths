import ZeroTwoLayout

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette
open private TrianglePrune.triangle_iff from TrianglePrune384b
open private Repair.omit_set Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def region (J : SimpleGraph V) (R : Finset V) : Prop := ∀ {u v},J.Adj u v → (u∈R ↔ v∈R)

private def flip (A R : Finset V) := (A\R)∪(R\A)

private theorem flip_sides {J : SimpleGraph V} [DecidableRel J.Adj] {W A R : Finset V}
    (closed : region J R) (L : ∀v∈W,v∈A → 2≤nbr J v Aᶜ)
    (K : ∀v∈W,v∈Aᶜ → 2≤nbr J v A) :
    (∀v∈W,v∈flip A R → 2≤nbr J v (flip A R)ᶜ) ∧
    (∀v∈W,v∈(flip A R)ᶜ → 2≤nbr J v (flip A R)) := by
  have transfer (v : V) (vm : v∈W) :
      2≤nbr J v (if v∈flip A R then (flip A R)ᶜ else flip A R) := by
    have h : 2≤nbr J v (if v∈A then Aᶜ else A) := by
      by_cases va : v∈A
      · simpa [va] using L v vm va
      · simpa [va] using K v vm (mem_compl.mpr va)
    apply h.trans (card_le_card ?_)
    intro w wm
    obtain ⟨side,vw⟩ := mem_filter.mp wm
    apply mem_filter.mpr ⟨?_,vw⟩
    have eq := closed vw
    by_cases va : v∈A <;> by_cases vr : v∈R <;>
      simp_all [flip,mem_compl]
  constructor
  · intro v vm va; simpa only [if_pos va] using transfer v vm
  · intro v vm va; simpa only [if_neg (mem_compl.mp va)] using transfer v vm

theorem region_even {J : SimpleGraph V} [DecidableRel J.Adj] (le : J≤G) {W R : Finset V}
    (tight : 2*gamma G+W.card=2*Fintype.card V) (cov : Covered J W) (closed : region J R) :
    (W∩R).card%2=0 := by
  classical
  obtain ⟨A,L,K⟩ := cov
  have quota (S : Finset V) (l : ∀v∈W,v∈S → 2≤nbr J v Sᶜ)
      (r : ∀v∈W,v∈Sᶜ → 2≤nbr J v S) : 2*(W∩S).card=W.card := by
    have nr (v : V) (P : Finset V) : nbr J v P≤nbr G v P := card_le_card
      (fun _ m => mem_filter.mpr ⟨(mem_filter.mp m).1,le (mem_filter.mp m).2⟩)
    have a := Repair.omit_set G (W∩S) (fun v vm =>
      ((l v (mem_inter.mp vm).1 (mem_inter.mp vm).2).trans (nr ..)).trans (Repair.nbr_mono G _ (fun _ h =>
        mem_compl.mpr (fun m => mem_compl.mp h (mem_inter.mp m).2))))
    have b := Repair.omit_set G (W\S) (fun v vm =>
      ((r v (mem_sdiff.mp vm).1 (mem_compl.mpr (mem_sdiff.mp vm).2)).trans (nr ..)).trans (Repair.nbr_mono G _ (fun _ h =>
        mem_compl.mpr (fun m => (mem_sdiff.mp m).2 h))))
    have := card_le_univ (W∩S); have := card_le_univ (W\S)
    have := card_sdiff_add_card_inter W S
    omega
  obtain ⟨l,r⟩ := flip_sides closed L K
  have same : (W∩flip A R)\R=(W∩A)\R := by ext; simp [flip]; tauto
  have switch : (W∩flip A R)∩R=(W∩R)\A := by ext; simp [flip]; tauto
  have join : (W∩A)∩R=(W∩R)∩A := by ext; simp; tauto
  have q := quota A L K
  have q' := quota _ l r
  have sum := card_sdiff_add_card_inter (W∩flip A R) R
  rw [same,switch] at sum
  have sum' := card_sdiff_add_card_inter (W∩A) R
  rw [join] at sum'
  have t := card_sdiff_add_card_inter (W∩R) A
  omega

private theorem crosses_pair {W A : Finset V} (tight : 2*gamma G+W.card=2*Fintype.card V)
    (l : ∀v∈W,v∈A → 2≤nbr G v Aᶜ) (r : ∀v∈W,v∈Aᶜ → 2≤nbr G v A)
    {z u v : V} (out : z∉W) (dz : G.degree z=2) (nb : G.neighborFinset z={u,v}) :
    (u∈A ↔ v∉A) := by
  obtain ⟨_,⟨a,am,za⟩,⟨b,bm,zb⟩⟩ := split_neighbors G tight l r out dz.ge
  have left := (mem_inter.mp am).2; have right := (mem_sdiff.mp bm).2
  have ea := (G.mem_neighborFinset ..).mpr za; have eb := (G.mem_neighborFinset ..).mpr zb
  simp only [nb,mem_insert,mem_singleton] at ea eb
  rcases ea with rfl|rfl <;> rcases eb with rfl|rfl <;> tauto

/-- In a degree-two-zero failure, both neighbors of that zero belong to
the triangle component of *every* count-one vertex. -/
theorem zero_attachment {z f u : V} (bad : bound G<gamma G) (zz : trianglesAt G z=0)
    (dz : G.degree z=2) (sf : trianglesAt G f=1) (zu : G.Adj z u) :
    (patch G ∅).Reachable f u := by
  classical
  let J := patch G ∅
  let R := univ.filter (fun v => J.Reachable f v)
  have fm : f∈R := mem_filter.mpr ⟨mem_univ _,Reachable.refl _⟩
  have closed : region J R := by
    intro x y xy
    simp only [R,mem_filter,mem_univ,true_and]
    exact ⟨fun r => r.trans xy.reachable,fun r => r.trans xy.symm.reachable⟩
  have isolated {v : V} (edge : J.Adj z v) : False := by
    rcases edge.2 with ⟨w,zw,vw⟩|m|m
    · have := (TrianglePrune.triangle_iff G z).mpr ⟨v,w,edge.1,zw,vw⟩; omega
    · exact not_mem_empty _ m
    · exact not_mem_empty _ m
  have zm : z∉R := by
    intro m
    obtain ⟨p⟩ := (mem_filter.mp m).2.symm
    cases p with
    | nil => omega
    | cons edge _ => exact isolated edge
  obtain ⟨cz,cf,eq,_⟩ := two_frames G bad zz dz sf
  have cls := (high_description G bad zz dz ∅).2
  have fn' : f∉high G := fun m => by have := (cls f).mp m; omega
  have zn : z∉high G := fun m => by have := (cls z).mp m; omega
  let W := insert f (high G)
  have ti : 2*gamma G+W.card=2*Fintype.card V := by simpa [W,fn'] using eq
  have out : z∉W := by
    have ne : z≠f := by rintro rfl; omega
    simp [W,ne,zn]
  obtain ⟨a,b,ab,nb⟩ := card_eq_two.mp (show (G.neighborFinset z).card=2 by rw [card_neighborFinset_eq_degree,dz])
  obtain ⟨A,l,r⟩ := cf
  change (∀v∈W,v∈A → 2≤nbr J v Aᶜ) at l
  change (∀v∈W,v∈Aᶜ → 2≤nbr J v A) at r
  have mono (v : V) (P : Finset V) : nbr J v P≤nbr G v P :=
    card_le_card (fun _ m => mem_filter.mpr ⟨(mem_filter.mp m).1,(mem_filter.mp m).2.1⟩)
  have split (B : Finset V) (h : ∀v∈W,v∈B → 2≤nbr J v Bᶜ)
      (k : ∀v∈W,v∈Bᶜ → 2≤nbr J v B) : (a∈B ↔ b∉B) :=
    crosses_pair G ti (fun v vm vb => (h v vm vb).trans (mono ..))
      (fun v vm vb => (k v vm vb).trans (mono ..)) out dz nb
  have s := split A l r
  obtain ⟨l',r'⟩ := flip_sides closed l r
  have f' := split _ l' r'
  have together : a∈R ↔ b∈R := by
    simp only [flip,mem_union,mem_sdiff] at f'
    tauto
  have first : a∈R := by
    by_contra off
    have bout : b∉R := fun h => off (together.mpr h)
    have away {v : V} (edge : G.Adj z v) : v∉R := by
      have m := (G.mem_neighborFinset ..).mpr edge
      rw [nb,mem_insert,mem_singleton] at m
      rcases m with rfl|rfl <;> assumption
    have c' : region (patch G {z}) R := by
      intro x y xy
      rcases xy.2 with h|m|m
      · exact closed (show J.Adj x y from ⟨xy.1,Or.inl h⟩)
      · obtain rfl := mem_singleton.mp m
        exact iff_of_false zm (away xy.1)
      · obtain rfl := mem_singleton.mp m
        exact iff_of_false (away xy.1.symm) zm
    have pe := region_even G (J:=J) (fun _ _ h => h.1) ti ⟨A,l,r⟩ closed
    have tz : 2*gamma G+(insert z (high G)).card=2*Fintype.card V := by simpa [zn] using eq
    have pz := region_even G (J:=patch G {z}) (fun _ _ h => h.1) tz cz c'
    have wf : W∩R=insert f (high G∩R) := by
      ext x; by_cases xf : x=f
      · subst x; simp [W,fm]
      · simp [W,xf]
    have wz : insert z (high G)∩R=high G∩R := by
      ext x; by_cases xz : x=z
      · subst x; simp [zm]
      · simp [xz]
    rw [wf,card_insert_of_not_mem (fun m => fn' (mem_inter.mp m).1)] at pe
    rw [wz] at pz
    omega
  have um := (G.mem_neighborFinset ..).mpr zu
  rw [nb,mem_insert,mem_singleton] at um
  exact (mem_filter.mp (um.elim (fun h => h ▸ first) (fun h => h ▸ together.mp first))).2

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.region_even
#print axioms Graffiti384b.OddStars.zero_attachment
