import ComponentQuota
namespace Graffiti384b.OddStars.ComponentCenters
open Finset SimpleGraph ComponentQuota
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

noncomputable def component (v : V) : Finset V := by
  classical exact univ.filter (fun w => (patch G ∅).Reachable v w)

omit [DecidableEq V] [DecidableRel G.Adj] in
theorem mem_component (v w : V) : w∈component G v ↔ (patch G ∅).Reachable v w := by
  classical simp [component]

omit [DecidableEq V] [DecidableRel G.Adj] in
theorem closed_component (v : V) : region (patch G ∅) (component G v) := by
  intro x y ed
  rw [mem_component,mem_component]
  exact ⟨fun h => h.trans ed.reachable,fun h => h.trans ed.symm.reachable⟩

theorem local_witness {S : Finset V} {i : ℕ} (m : i∈palette G S) :
    ∃x∈S,trianglesAt G x=i := mem_image.mp (mem_erase.mp m).2

/-- Every positive vertex can reach a vertex of score one or a vertex of
score two using only triangle edges. If its component misses one, it has
both scores two and three. -/
theorem anchors (bad : bound G<gamma G) {x : V} (positive : 0<trianglesAt G x) :
    (∃y,(patch G ∅).Reachable x y ∧ trianglesAt G y=1) ∨
    ((∃y,(patch G ∅).Reachable x y ∧ trianglesAt G y=2) ∧
     (∃y,(patch G ∅).Reachable x y ∧ trianglesAt G y=3)) := by
  classical
  let S := component G x
  have lift {k : ℕ} (km : k∈palette G S) : ∃y,(patch G ∅).Reachable x y ∧ trianglesAt G y=k := by
    obtain ⟨y,ym,eq⟩ := local_witness G km
    exact ⟨y,(mem_component ..).mp ym,eq⟩
  by_cases one : 1∈palette G S
  · exact Or.inl (lift one)
  have xm : x∈S := (mem_component ..).mpr (Reachable.refl _)
  have pos : (palette G S).Nonempty := ⟨_,mem_erase.mpr ⟨by omega,mem_image_of_mem _ xm⟩⟩
  have pair := low_pair G bad S (closed_component G _) pos one
  exact Or.inr ⟨lift pair.1,lift pair.2⟩

/-- Repeated positive scores, including score one, can only occur in one
triangle-edge component of a hypothetical failure. -/
theorem equal_score_connected (bad : bound G<gamma G) {x y : V}
    (pos : 0<trianglesAt G x) (eq : trianglesAt G x=trianglesAt G y) :
    (patch G ∅).Reachable x y := by
  classical
  let S := component G x
  by_contra no
  have xm : x∈S := (mem_component ..).mpr (Reachable.refl _)
  have ym : y∈Sᶜ := mem_compl.mpr (fun m => no ((mem_component ..).mp m))
  have a : trianglesAt G x∈palette G S := mem_erase.mpr ⟨by omega,mem_image_of_mem _ xm⟩
  have b : trianglesAt G x∈palette G Sᶜ := mem_erase.mpr ⟨by omega,mem_image.mpr ⟨y,ym,eq.symm⟩⟩
  exact disjoint_left.mp (split G bad S (closed_component G _)).2.2 a b

/-- The entire disconnected-positive-skeleton profile is closed when one is absent. -/
theorem exact_disconnected_no_one (one : 1∉types G) {x y : V}
    (px : 0<trianglesAt G x) (py : 0<trianglesAt G y) (no : ¬(patch G ∅).Reachable x y) :
    gamma G≤bound G := by
  apply Nat.le_of_not_gt
  intro bad
  have anchor {w : V} (pw : 0<trianglesAt G w) : ∃r,(patch G ∅).Reachable w r ∧ trianglesAt G r=2 := by
    rcases anchors G bad pw with ⟨r,_,oneR⟩|two
    · exact (one (mem_image.mpr ⟨r,mem_univ _,oneR⟩)).elim
    · exact two.1
  obtain ⟨r,xr,sr⟩ := anchor px
  obtain ⟨s,ys,ss⟩ := anchor py
  exact no (xr.trans ((equal_score_connected G bad (by omega) (sr.trans ss.symm)).trans ys.symm))

/-- Of any three positive vertices, two are in the same triangle-edge
component. No restriction on the occurrence of score one is needed. -/
theorem at_most_two (bad : bound G<gamma G) {x y z : V}
    (px : 0<trianglesAt G x) (py : 0<trianglesAt G y) (pz : 0<trianglesAt G z) :
    (patch G ∅).Reachable x y ∨ (patch G ∅).Reachable x z ∨ (patch G ∅).Reachable y z := by
  let J := patch G ∅
  have label {w : V} (pw : 0<trianglesAt G w) :
      ∃r,J.Reachable w r ∧ (trianglesAt G r=1 ∨ trianglesAt G r=2) := by
    rcases anchors G bad pw with ⟨r,wr,hr⟩|⟨⟨r,wr,hr⟩,_⟩
    · exact ⟨r,wr,Or.inl hr⟩
    · exact ⟨r,wr,Or.inr hr⟩
  obtain ⟨a,xa,ha⟩ := label px
  obtain ⟨b,yb,hb⟩ := label py
  obtain ⟨c,zc,hc⟩ := label pz
  have link {i j a b : V} (ia : J.Reachable i a) (jb : J.Reachable j b)
      (pa : 0<trianglesAt G a) (e : trianglesAt G a=trianglesAt G b) : J.Reachable i j :=
    ia.trans ((equal_score_connected G bad pa e).trans jb.symm)
  have dup : trianglesAt G a=trianglesAt G b ∨ trianglesAt G a=trianglesAt G c ∨ trianglesAt G b=trianglesAt G c := by omega
  exact dup.elim (fun e => Or.inl (link xa yb (by omega) e))
    (fun h => h.elim (fun e => Or.inr (Or.inl (link xa zc (by omega) e))) (fun e => Or.inr (Or.inr (link yb zc (by omega) e))))

end Graffiti384b.OddStars.ComponentCenters
#print axioms Graffiti384b.OddStars.ComponentCenters.anchors
#print axioms Graffiti384b.OddStars.ComponentCenters.equal_score_connected
#print axioms Graffiti384b.OddStars.ComponentCenters.exact_disconnected_no_one
#print axioms Graffiti384b.OddStars.ComponentCenters.at_most_two
