import ComponentCenters
import PairAlternative
namespace Graffiti384b.OddStars.ComponentPort
open Finset SimpleGraph PositivePalette ComponentQuota
open private Repair.omit_set Repair.nbr_mono from Repair384b
open private IsolateBasic.minimum from IsolateBasic384b
open private PairAlternative.palette from PairAlternative
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- At positive-palette equality every prescribed vertex can be retained
by a minimum two-dominating set. -/
theorem keep_one (eq : 2*gamma G+((types G).erase 0).card=2*Fintype.card V) (y : V) :
    ∃D : Finset V,TwoDominates G D ∧ D.card=gamma G ∧ y∈D := by
  classical
  obtain ⟨W,_,cov,rep⟩ := representatives G y
  obtain ⟨A,l,r⟩ := covered_mono G (fun _ _ h => h.1 : patch G {y}≤G) cov
  let L := W∩A
  let R := W\A
  have first : TwoDominates G Lᶜ := by
    intro w wm
    have wl : w∈L := by simpa using wm
    exact (l w (mem_inter.mp wl).1 (mem_inter.mp wl).2).trans (Repair.nbr_mono G _ (fun _ h =>
      mem_compl.mpr (fun k => mem_compl.mp h (mem_inter.mp k).2)))
  have second : TwoDominates G Rᶜ := by
    intro w wm
    have wr : w∈R := by simpa using wm
    exact (r w (mem_sdiff.mp wr).1 (mem_compl.mpr (mem_sdiff.mp wr).2)).trans (Repair.nbr_mono G _ (fun _ h =>
      mem_compl.mpr (fun k => (mem_sdiff.mp k).2 h)))
  have low {D : Finset V} (dm : TwoDominates G D) : gamma G≤D.card := Nat.sInf_le ⟨D,dm,rfl⟩
  have lc := low first
  have rc := low second
  have num := (card_le_card rep).trans card_image_le
  have count : R.card+L.card=W.card := card_sdiff_add_card_inter .. 
  have lcap := card_le_univ L
  have rcap := card_le_univ R
  have cl := card_compl L
  have cr := card_compl R
  by_cases ya : y∈A
  · exact ⟨Rᶜ,second,by omega,mem_compl.mpr (fun m => (mem_sdiff.mp m).2 ya)⟩
  · exact ⟨Lᶜ,first,by omega,mem_compl.mpr (fun m => ya (mem_inter.mp m).2)⟩

abbrev withLeaf (r : V) := PairAlternative.attach G r r

omit [Fintype V] in
theorem leaf_set (r : V) (D : Finset (V⊕Unit)) (dm : TwoDominates (withLeaf G r) D) :
    (.inr () : V⊕Unit)∈D := by
  by_contra out
  have lo := dm _ out
  have inc : D.filter ((withLeaf G r).Adj (.inr ()))⊆{.inl r} := by
    intro w wm
    have ed := (mem_filter.mp wm).2
    cases w with
    | inl i => exact mem_singleton.mpr (congrArg Sum.inl (ed.elim id id))
    | inr i => exact ed.elim
  have cnt := card_le_card inc
  rw [card_singleton] at cnt
  unfold nbr at lo; omega

omit [Fintype V] [DecidableEq V] in
private theorem transported {A : Type*} [Fintype A] [DecidableEq A] (E : SimpleGraph A)
    [DecidableRel E.Adj] (f : A ↪ V) (pres : ∀{i j},E.Adj i j → G.Adj (f i) (f j))
    {D : Finset A} (dm : TwoDominates E D) {U : Finset V} (inc : D.map f⊆U)
    {i : A} (out : f i∉U) : 2≤nbr G (f i) U := by
  have off : i∉D := fun m => out (inc (mem_map.mpr ⟨i,m,rfl⟩))
  have sub : (D.filter (E.Adj i)).map f⊆U.filter (G.Adj (f i)) := by
    intro w wm
    obtain ⟨j,jm,rfl⟩ := mem_map.mp wm
    exact mem_filter.mpr ⟨inc (mem_map.mpr ⟨_,(mem_filter.mp jm).1,rfl⟩),pres (mem_filter.mp jm).2⟩
  have sz := card_le_card sub
  rw [card_map] at sz
  exact (dm i off).trans sz

/-- Glue the block with a leaf to a minimum set outside the block which
retains the original contact. The contact is counted only once. -/
private theorem port_bound {S : Finset V} {r : S} {y : V} (yout : y∉S) (ed : G.Adj r.val y)
    (eq : 2*gamma (block G Sᶜ)+((types (block G Sᶜ)).erase 0).card=2*Fintype.card ((Sᶜ:Finset V):Set V)) :
    gamma G+1≤gamma (withLeaf (block G S) r)+gamma (block G Sᶜ) := by
  classical
  let K := block G S
  let B := block G Sᶜ
  let E := withLeaf K r
  let b : (Sᶜ : Finset V) := ⟨y,mem_compl.mpr yout⟩
  obtain ⟨D,dm,ds⟩ := IsolateBasic.minimum E
  have leaf := leaf_set K r D dm
  obtain ⟨T,tm,ts,bm⟩ := keep_one B eq b
  let emb : (S⊕Unit) ↪ V :=
    ⟨Sum.elim Subtype.val (fun _ => y),by
      intro i j h
      cases i with
      | inl i =>
        cases j with
        | inl j => exact congrArg Sum.inl (Subtype.ext h)
        | inr j => exact (yout ((show i.val=y from h) ▸ i.property)).elim
      | inr i =>
        cases j with
        | inl j => exact (yout ((show j.val=y from h.symm) ▸ j.property)).elim
        | inr j => rfl⟩
  let g : (Sᶜ:Finset V) ↪ V := Function.Embedding.subtype _
  have edges {i j : S⊕Unit} (e : E.Adj i j) : G.Adj (emb i) (emb j) := by
    cases i with
    | inl i =>
      cases j with
      | inl j => exact e.1
      | inr j => exact (e.elim id id : i=r) ▸ ed
    | inr i =>
      cases j with
      | inl j => exact (e.elim id id : j=r) ▸ ed.symm
      | inr j => exact e.elim
  let X := D.map emb
  let Y := T.map g
  let U := X∪Y
  have join : TwoDominates G U := by
    intro v vm
    by_cases vs : v∈S
    · exact transported G E emb edges dm (U:=U) subset_union_left (i:=.inl ⟨v,vs⟩) vm
    · exact transported G B g (fun e => e.1) tm (U:=U) subset_union_right (i:=⟨v,mem_compl.mpr vs⟩) vm
  have uC : gamma G≤U.card := Nat.sInf_le ⟨U,join,rfl⟩
  have yint : y∈X∩Y := mem_inter.mpr ⟨mem_map.mpr ⟨.inr (),leaf,rfl⟩,mem_map.mpr ⟨b,bm,rfl⟩⟩
  have pos := card_pos.mpr (show (X∩Y).Nonempty from ⟨y,yint⟩)
  have size := card_union_add_card_inter X Y
  have xx : X.card=gamma E := (card_map ..).trans ds
  have yy : Y.card=gamma B := (card_map ..).trans ts
  change gamma G≤(X∪Y).card at uC
  change gamma G+1≤gamma E+gamma B
  omega

/-- An arbitrary original edge leaving a union of triangle components turns
its endpoint into a leaf root for a new catalogue counterexample. -/
theorem rooted_failure (bad : bound G<gamma G) (S : Finset V) (closed : region (patch G ∅) S)
    (r : S) {y : V} (out : y∉S) (ed : G.Adj r.val y) :
    bound (withLeaf (block G S) r)<gamma (withLeaf (block G S) r) := by
  classical
  let K := block G S
  let B := block G Sᶜ
  let E := withLeaf K r
  have co : region (patch G ∅) Sᶜ := fun edge => by simpa only [mem_compl] using (closed edge).not
  have ⟨kb,_,dis⟩ := split G bad S closed
  have ab := (split G bad Sᶜ co).1
  have scoreB : (types B).erase 0=palette G Sᶜ := congrArg (fun t : Finset ℕ => t.erase 0) (local_scores G Sᶜ co)
  have cardB : Fintype.card ((Sᶜ:Finset V):Set V)=(Sᶜ:Finset V).card := Fintype.card_coe Sᶜ
  have rB : 2*gamma B+((types B).erase 0).card=2*Fintype.card ((Sᶜ:Finset V):Set V) := by rw [cardB,scoreB]; exact ab
  have glue := port_bound G out ed rB
  have full : palette G S∪palette G Sᶜ=(types G).erase 0 := by
    unfold palette types
    rw [← erase_union_distrib,← image_union,union_compl]
  have uni := card_union_of_disjoint dis
  rw [full] at uni
  have zero := card_erase_add_one (failure_requires_odd_zero G bad).2
  have allPos := positive_bound G
  have total := card_compl S
  have cap := card_le_univ S
  have cardK : Fintype.card (S:Set V)=S.card := Fintype.card_coe S
  have scores : types E=insert 0 (palette G S) := by
    change types (PairAlternative.attach K r r)=_
    rw [PairAlternative.palette K (K.loopless r),local_scores G S closed]
    ext; simp [palette]; tauto
  have zoff : 0∉palette G S := not_mem_erase 0 _
  have psize : (types E).card=(palette G S).card+1 := by rw [scores,card_insert_of_not_mem zoff]
  change bound E<gamma E
  unfold bound at bad ⊢
  rw [psize,Fintype.card_sum,Fintype.card_unit,cardK]
  change gamma G+1≤gamma E+gamma B at glue
  change 2*gamma B+(palette G Sᶜ).card=2*(Sᶜ:Finset V).card at ab
  omega

end Graffiti384b.OddStars.ComponentPort
#print axioms Graffiti384b.OddStars.ComponentPort.keep_one
#print axioms Graffiti384b.OddStars.ComponentPort.leaf_set
#print axioms Graffiti384b.OddStars.ComponentPort.rooted_failure
