import CubicComponent
import IsolateBasic384b
namespace Graffiti384b.OddStars.ComponentQuota
open Finset SimpleGraph PositivePalette
open private TrianglePrune.Closed TrianglePrune.scores_closed TrianglePrune.induced_cost from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def palette (S : Finset V) := (S.image (trianglesAt G)).erase 0

abbrev block (S : Finset V) := (patch G ∅).induce (S : Set V)

theorem local_scores (S : Finset V) (closed : region (patch G ∅) S) :
    types (block G S)=S.image (trianglesAt G) := by
  let J := patch G ∅
  have cl : TrianglePrune.Closed J S := fun _ xm _ xy => (closed xy).mp xm
  have sc (v : S) : trianglesAt (block G S) v=trianglesAt G v.val :=
    (TrianglePrune.scores_closed J S cl v).trans (patch_scores G ∅ _)
  ext k
  constructor
  · intro m; obtain ⟨v,_,rfl⟩ := mem_image.mp m
    exact mem_image.mpr ⟨v.val,v.property,(sc v).symm⟩
  · intro m; obtain ⟨v,vm,rfl⟩ := mem_image.mp m
    exact mem_image.mpr ⟨⟨v,vm⟩,mem_univ _,sc ⟨v,vm⟩⟩

/-- In a failure, each union of triangle-edge components spends its exact
half-palette quota, and the two positive palettes are disjoint. -/
theorem split (bad : bound G<gamma G) (S : Finset V) (closed : region (patch G ∅) S) :
    2*gamma (block G S)+(palette G S).card=2*S.card ∧
    (palette G S).card%2=0 ∧ Disjoint (palette G S) (palette G Sᶜ) := by
  classical
  let J := patch G ∅
  have co : region J Sᶜ := fun ed => by simpa only [mem_compl] using (closed ed).not
  have fin (R : Finset V) (cl : region J R) :
      2*gamma (block G R)+(palette G R).card≤2*R.card := by
    have val := positive_bound (block G R)
    rw [local_scores G R cl] at val
    have ct : Fintype.card (R:Set V)=R.card := Fintype.card_coe R
    exact val.trans_eq (congrArg (2*·) ct)
  have a := fin S closed
  have b := fin Sᶜ co
  have ca := TrianglePrune.induced_cost J S
  have cb := TrianglePrune.induced_cost J Sᶜ
  have add := Capacity.separated_add J S Sᶜ ∅ disjoint_compl_right
    (fun _ vm _ wm ed => mem_compl.mp wm ((closed ed).mp vm))
  rw [union_compl] at add
  have upper := Capacity.seeded_value J ∅ univ ∅ (by simp) (by simp) (by simp) (by simp)
  simp only [card_empty,zero_add] at upper
  have mono := Prerequisites.gamma_mono G J (fun _ _ e => e.1)
  have sumsize := card_compl S
  have lim := card_le_univ S
  have both : palette G S∪palette G Sᶜ=(types G).erase 0 := by
    unfold palette types
    rw [← erase_union_distrib,← image_union,union_compl]
  have union := card_union_add_card_inter (palette G S) (palette G Sᶜ)
  rw [both] at union
  have full := card_erase_add_one (failure_requires_odd_zero G bad).2
  change S.card≤gamma (block G S)+Capacity.value J S ∅ at ca
  change Sᶜ.card≤gamma (block G Sᶜ)+Capacity.value J Sᶜ ∅ at cb
  unfold bound at bad
  have eq : 2*gamma (block G S)+(palette G S).card=2*S.card := by omega
  refine ⟨eq,by omega,disjoint_iff_inter_eq_empty.mpr (card_eq_zero.mp ?_)⟩
  omega

/-- Adding a single isolated vertex converts half-palette equality back
to a catalogue failure on an auxiliary graph. -/
theorem local_failure (tight : 2*gamma G+((types G).erase 0).card=2*Fintype.card V) :
    bound (IsolateBasic.extend G)<gamma (IsolateBasic.extend G) := by
  classical
  have eq : insert 0 ((types G).erase 0)=insert 0 (types G) := by ext; simp; tauto
  have sz : (types (IsolateBasic.extend G)).card=((types G).erase 0).card+1 := by
    rw [IsolateBasic.palette,←eq,card_insert_of_not_mem (not_mem_erase 0 (types G))]
  unfold bound
  rw [IsolateBasic.domination,sz,Fintype.card_sum,Fintype.card_unit]
  omega

/-- Every nonempty positive local palette missing one in a failure contains
both two and three, independent of block size or number of isolated vertices. -/
theorem low_pair (bad : bound G<gamma G) (S : Finset V) (closed : region (patch G ∅) S)
    (pos : (palette G S).Nonempty) (one : 1∉palette G S) : 2∈palette G S ∧ 3∈palette G S := by
  classical
  let K := block G S
  let L := IsolateBasic.extend K
  have scores : (types K).erase 0=palette G S := congrArg (fun t : Finset ℕ => t.erase 0) (local_scores G S closed)
  have tight := (split G bad S closed).1
  have cardS : Fintype.card (S:Set V)=S.card := Fintype.card_coe S
  have fail := local_failure K (by rw [scores,cardS]; exact tight)
  have allScores : types L=insert 0 (palette G S) := by
    rw [show types L=insert 0 (types K) from IsolateBasic.palette K,←scores]
    ext; simp; tauto
  have absent : 1∉types L := by simpa [allScores] using one
  have sz := (PaletteCorollaries.upper_iff_no_one L fail).mpr absent
  have num := card_pos.mpr pos
  have has : (high (patch L ∅)).Nonempty := by
    have zoff : 0∉palette G S := not_mem_erase 0 _
    rw [allScores,card_insert_of_not_mem zoff] at sz
    exact card_pos.mp (by omega)
  obtain ⟨u,v,_,su,sv,_⟩ := FixedCubics.fixed_pair L fail sz has
  have two : 2∈types L := mem_image.mpr ⟨u,mem_univ _,su⟩
  have three : 3∈types L := mem_image.mpr ⟨v,mem_univ _,sv⟩
  simpa [allScores] using And.intro two three

end Graffiti384b.OddStars.ComponentQuota
#print axioms Graffiti384b.OddStars.ComponentQuota.local_scores
#print axioms Graffiti384b.OddStars.ComponentQuota.split
#print axioms Graffiti384b.OddStars.ComponentQuota.local_failure
#print axioms Graffiti384b.OddStars.ComponentQuota.low_pair
