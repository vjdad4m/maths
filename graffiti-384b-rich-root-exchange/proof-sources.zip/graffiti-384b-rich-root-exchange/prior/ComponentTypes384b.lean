import Capacity384b
import AllPairs384b

namespace Graffiti384b.ComponentTypes
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Exact local classification by number of retained centers. Boundary
degrees zero, one and at least two are the only distinguishable types. -/
theorem centers_iff (r k : Finset V) (rk : Disjoint r k) (b : ℕ) (size : b ≤ r.card) :
    r.card - b ≤ Capacity.value G r k ↔
    ∃ c ∈ r.powersetCard b, ∀ v ∈ r \ c, 2 - nbr G v k ≤ nbr G v c := by
  have sumN {c : Finset V} (cr : c ⊆ r) (v : V) :
      nbr G v (k ∪ c) = nbr G v k + nbr G v c := by
    unfold nbr
    rw [filter_union,card_union_of_disjoint ((rk.symm.mono_right cr).mono (filter_subset _ _) (filter_subset _ _))]
  constructor
  · intro best
    obtain ⟨o,good,vo⟩ := Capacity.attained G r k
    have card := card_sdiff good.1
    obtain ⟨c,sub,cr,cb⟩ := exists_subsuperset_card_eq (sdiff_subset (t := o) (s := r))
      (by omega : (r \ o).card ≤ b) size
    refine ⟨c,mem_powersetCard.mpr ⟨cr,cb⟩,?_⟩
    intro v hv
    have inO : v ∈ o := by
      by_contra no
      exact (mem_sdiff.mp hv).2 (sub (mem_sdiff.mpr ⟨(mem_sdiff.mp hv).1,no⟩))
    have h := good.2 v inO
    have up : nbr G v (k ∪ (r \ o)) ≤ nbr G v (k ∪ c) :=
      card_le_card (filter_subset_filter _ (union_subset_union Subset.rfl sub))
    rw [sumN cr] at up
    omega
  · rintro ⟨c,cin,cover⟩
    obtain ⟨cr,cb⟩ := mem_powersetCard.mp cin
    have exactC : r \ (r \ c) = c := by ext v; by_cases h : v ∈ c <;> simp [h,fun hh => cr hh]
    have good : Capacity.Feasible G r k (r \ c) := by
      refine ⟨sdiff_subset,?_⟩
      intro v hv
      rw [exactC,sumN cr]
      have := cover v hv
      omega
    simpa [card_sdiff cr,cb] using Capacity.le_value G good

private theorem high_weight {r s : Finset V} (parts : r ∪ s = high G)
    (sep : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w) (v : V) (hv : v ∈ r) :
    3 ≤ nbr G v r + 2*nbr G v (high G)ᶜ := by
  have mem : v ∈ high G := parts ▸ mem_union_left _ hv
  have eq : (high G).filter (G.Adj v) = r.filter (G.Adj v) := by
    rw [← parts,filter_union]
    have empty : s.filter (G.Adj v) = ∅ := filter_eq_empty_iff.mpr (sep v hv)
    simp [empty]
  have card := card_union_of_disjoint (disjoint_compl_right (a := high G) |>.mono
    (filter_subset (G.Adj v) _) (filter_subset (G.Adj v) _))
  rw [← filter_union,union_compl,eq] at card
  have all : univ.filter (G.Adj v) = G.neighborFinset v := by ext; simp
  rw [all,card_neighborFinset_eq_degree] at card
  have h := (mem_filter.mp mem).2
  unfold nbr
  omega

/-- In any counterexample each separated high block attains exactly its
rounded half-size value with the low vertices kept. Two odd blocks already
supply the missing unit. -/
theorem rigidity (failure : bound G < gamma G) (r s : Finset V)
    (parts : r ∪ s = high G) (rs : Disjoint r s) (sep : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w) :
    Capacity.value G r (high G)ᶜ = (r.card+1)/2 ∧
    Capacity.value G s (high G)ᶜ = (s.card+1)/2 ∧ (r.card % 2 = 0 ∨ s.card % 2 = 0) := by
  have hr : r ⊆ high G := parts ▸ subset_union_left
  have hs : s ⊆ high G := parts ▸ subset_union_right
  have left := Capacity.half_le G r (high G)ᶜ (disjoint_compl_right.mono_left hr) (high_weight G parts sep)
  have right := Capacity.half_le G s (high G)ᶜ (disjoint_compl_right.mono_left hs)
    (high_weight G ((union_comm _ _).trans parts) (fun z hz w hw h => sep w hw z hz h.symm))
  have add := Capacity.separated_add G r s (high G)ᶜ rs sep
  rw [parts] at add
  have best := Capacity.seeded_value G ∅ (high G) (high G)ᶜ (by simp) (by simp) disjoint_compl_right (by simp)
  simp only [card_empty,zero_add] at best
  have card := card_union_of_disjoint rs
  rw [parts] at card
  have cap := type_bound G
  unfold bound at failure
  exact ⟨by omega,by omega,by omega⟩

/-- To beat the cut on a block of at most ten vertices, test the single
specified cardinality. At most 210 center sets have that size. -/
theorem small_block_test {r k : Finset V} (rk : Disjoint r k) (lo : 2 ≤ r.card) (hi : r.card ≤ 10) :
    let b := r.card - ((r.card+1)/2 + 1)
    ((r.card+1)/2 < Capacity.value G r k ↔
      ∃ c ∈ r.powersetCard b, ∀ v ∈ r \ c, 2 - nbr G v k ≤ nbr G v c) ∧
      (r.powersetCard b).card ≤ 210 := by
  dsimp only
  have fit : (r.card+1)/2+1 ≤ r.card := by omega
  have h := centers_iff G r k rk (r.card-((r.card+1)/2+1)) (Nat.sub_le ..)
  rw [Nat.sub_sub_self fit] at h
  refine ⟨h,?_⟩
  rw [card_powersetCard]
  have table : ∀ d : Fin 11, d.val.choose (d.val-((d.val+1)/2+1)) ≤ 210 := by decide
  exact table ⟨r.card,by omega⟩

/-- A path ordering is sufficient, so the same lower bound applies on a
cycle and in the presence of extra edges. -/
theorem supported_path (r k : Finset V) (rk : Disjoint r k) (m : ℕ) (f : ℕ → V)
    (list : (range m).image f = r) (order : r.card = m)
    (path : ∀ i, i+1 < m → G.Adj (f i) (f (i+1)))
    (support : ∀ v ∈ r, 1 ≤ nbr G v k) :
    m - (m+2)/3 ≤ Capacity.value G r k := by
  let center (j : ℕ) := min (3*j+1) (m-1)
  let c := (range ((m+2)/3)).image (fun j => f (center j))
  have cr : c ⊆ r := by
    intro z hz
    obtain ⟨j,hj,rfl⟩ := mem_image.mp hz
    apply list ▸ mem_image_of_mem _ (mem_range.mpr ?_)
    have jj := mem_range.mp hj
    dsimp [center]
    omega
  have cb : c.card ≤ (m+2)/3 := card_image_le.trans (by simp)
  have good : Capacity.Feasible G r k (r \ c) := by
    refine ⟨sdiff_subset,?_⟩
    intro z hz
    obtain ⟨zr,zc⟩ := mem_sdiff.mp hz
    obtain ⟨i,hi,rfl⟩ := mem_image.mp (list.symm ▸ zr)
    have im := mem_range.mp hi
    have jc : f (center (i/3)) ∈ c := mem_image_of_mem _ (mem_range.mpr (by omega))
    have diff : i ≠ center (i/3) := fun h => zc (h ▸ jc)
    have next : i+1 = center (i/3) ∨ center (i/3)+1 = i := by dsimp [center] at *; omega
    have cm : center (i/3) < m := by dsimp [center]; omega
    have adj : G.Adj (f i) (f (center (i/3))) := by
      rcases next with e | e
      · rw [← e]
        exact path i (by omega)
      · have a := (path (center (i/3)) (by omega)).symm
        rwa [e] at a
    have eq : r \ (r \ c) = c := by ext w; by_cases h : w ∈ c <;> simp [h,fun hh => cr hh]
    have one : 1 ≤ nbr G (f i) c := card_pos.mpr ⟨_,mem_filter.mpr ⟨jc,adj⟩⟩
    have ext := support _ zr
    rw [eq]
    unfold nbr at *
    rw [filter_union,card_union_of_disjoint ((rk.symm.mono_right cr).mono (filter_subset _ _) (filter_subset _ _))]
    omega
  have h := Capacity.le_value G good
  rw [card_sdiff cr,order] at h
  omega

/-- With exactly one retained neighbor each and internal degree at most two,
every retained center accounts for at most three block vertices. -/
theorem path_upper (r k : Finset V) (support : ∀ z ∈ r, nbr G z k = 1)
    (deg : ∀ z ∈ r, nbr G z r ≤ 2) :
    Capacity.value G r k ≤ r.card - (r.card+2)/3 := by
  obtain ⟨o,ok,vo⟩ := Capacity.attained G r k
  let c := r \ o
  have sub : o ⊆ c.biUnion (fun z => r.filter (G.Adj z)) := by
    intro z hz
    have h := ok.2 z hz
    have size := card_union_le (k.filter (G.Adj z)) (c.filter (G.Adj z))
    have one := support z (ok.1 hz)
    change 2 ≤ ((k ∪ c).filter (G.Adj z)).card at h
    rw [filter_union] at h
    change (k.filter (G.Adj z)).card = 1 at one
    obtain ⟨w,hw⟩ := card_pos.mp (by omega : 0 < (c.filter (G.Adj z)).card)
    exact mem_biUnion.mpr ⟨w,(mem_filter.mp hw).1,mem_filter.mpr ⟨ok.1 hz,(mem_filter.mp hw).2.symm⟩⟩
  have h := (card_le_card sub).trans card_biUnion_le
  have two : (∑ z ∈ c, (r.filter (G.Adj z)).card) ≤ c.card*2 :=
    (sum_le_sum (fun z hz => deg z (mem_sdiff.mp hz).1)).trans_eq (by simp [c])
  have card : c.card + o.card = r.card := card_sdiff_add_card_eq_card ok.1
  omega

end Graffiti384b.ComponentTypes

#print axioms Graffiti384b.ComponentTypes.rigidity
#print axioms Graffiti384b.ComponentTypes.small_block_test
#print axioms Graffiti384b.ComponentTypes.supported_path
#print axioms Graffiti384b.ComponentTypes.path_upper
