import Capacity384b
import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic.Ring

namespace Graffiti384b.CoreSize
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

private def box (b z : Finset V) : Finset (V → Fin 3) :=
  Fintype.piFinset (fun v => if v ∈ b then ({1,2} : Finset (Fin 3))
    else if v ∈ z then {0} else univ)

private theorem box_mem {b z : Finset V} (bz : Disjoint b z) (f : V → Fin 3) :
    f ∈ box b z ↔ (∀ v ∈ b, f v ≠ 0) ∧ (∀ v ∈ z, f v = 0) := by
  have colors : ∀ i : Fin 3, i ∈ ({1,2} : Finset (Fin 3)) ↔ i ≠ 0 := by decide
  rw [box,Fintype.mem_piFinset]
  constructor
  · intro h
    constructor
    · intro v hv
      simpa [hv,colors] using h v
    · intro v hv
      have nb : v ∉ b := fun hb => disjoint_left.mp bz hb hv
      simpa [hv,nb] using h v
  · rintro ⟨hb,hz⟩ v
    by_cases h : v ∈ b
    · simpa only [if_pos h,colors] using hb v h
    by_cases hh : v ∈ z
    · simp [h,hh,hz v hh]
    · simp [h,hh]

private theorem card_box (b z : Finset V) (bz : Disjoint b z) :
    (box b z).card = 2^b.card * 3^(Fintype.card V - (b.card+z.card)) := by
  let choices (v : V) : Finset (Fin 3) := if v ∈ b then {1,2} else if v ∈ z then {0} else univ
  change (Fintype.piFinset choices).card = _
  rw [Fintype.card_piFinset]
  have split : (b ∪ z) ∪ (b ∪ z)ᶜ = univ := union_compl _
  calc
    _ = (∏ v ∈ b, (choices v).card) * (∏ v ∈ z, (choices v).card) *
        (∏ v ∈ (b ∪ z)ᶜ, (choices v).card) := by
      rw [← prod_union bz,← prod_union disjoint_compl_right,split]
    _ = _ := by
      have p : ∏ v ∈ b, (choices v).card = 2^b.card := prod_eq_pow_card (fun v hv => by simp [choices,hv])
      have q : ∏ v ∈ z, (choices v).card = 1^z.card := prod_eq_pow_card (fun v hv => by
        have h : v ∉ b := fun hb => disjoint_left.mp bz hb hv
        simp [choices,h,hv])
      have u : ∏ v ∈ (b ∪ z)ᶜ, (choices v).card = 3^((b ∪ z)ᶜ.card) := prod_eq_pow_card (by
        intro v hv
        have h := mem_compl.mp hv
        have hb : v ∉ b := fun hh => h (mem_union_left _ hh)
        have hz : v ∉ z := fun hh => h (mem_union_right _ hh)
        simp [choices,hb,hz])
      rw [p,q,u,one_pow,mul_one,card_compl,card_union_of_disjoint bz]

private def survivors (r : Finset V) (f : V → Fin 3) :=
  r.filter (fun z => f z ≠ 0 ∧ 2 ≤ ((G.neighborFinset z).filter (fun v => f v = 0)).card)

private theorem survives_le (r : Finset V) (f : V → Fin 3) :
    (survivors G r f).card ≤ Capacity.value G r rᶜ := by
  apply Capacity.le_value G ⟨filter_subset _ _,?_⟩
  intro z hz
  apply (mem_filter.mp hz).2.2.trans
  apply card_le_card
  intro v hv
  obtain ⟨hn,hv⟩ := mem_filter.mp hv
  apply mem_filter.mpr ⟨?_,(G.mem_neighborFinset _ _).mp hn⟩
  by_cases vr : v ∈ r
  · exact mem_union_right _ (mem_sdiff.mpr ⟨vr,fun hh => (mem_filter.mp hh).2.1 hv⟩)
  · exact mem_union_left _ (mem_compl.mpr vr)

/-- The local survivor count for d tested neighbors with two of three labels marked,
normalized to twelve independent labels. -/
def score (d : ℕ) := 2*3^11 - (2^(d+1) + d*2^d) * 3^(11-d)

private theorem local_count (r : Finset V) (v : V) (vr : v ∈ r)
    (s : Finset V) (ns : s ⊆ G.neighborFinset v) (clip : s.card ≤ 11)
    (large : 12 ≤ Fintype.card V) :
    score s.card * 3^(Fintype.card V - 12) ≤
    ((univ : Finset (V → Fin 3)).filter (fun f => v ∈ survivors G r f)).card := by
  let d := s.card
  let n := Fintype.card V
  let candidates := box ({v} : Finset V) ∅
  let good := (univ : Finset (V → Fin 3)).filter (fun f => v ∈ survivors G r f)
  let zero := box (insert v s) ∅
  let one (w : V) := box (insert v (s.erase w)) {w}
  have vs : v ∉ s := fun h => G.not_mem_neighborFinset_self _ (ns h)
  have inc : candidates ⊆ good ∪ (zero ∪ s.biUnion one) := by
    intro f hf
    have marked := ((box_mem (disjoint_empty_right _) f).mp hf).1 v (mem_singleton_self _)
    by_cases ok : 2 ≤ ((G.neighborFinset v).filter (fun w => f w = 0)).card
    · exact mem_union_left _ (mem_filter.mpr ⟨mem_univ _,mem_filter.mpr ⟨vr,marked,ok⟩⟩)
    apply mem_union_right
    let white := s.filter (fun w => f w = 0)
    have wb : white.card ≤ 1 := by
      have h := card_le_card (filter_subset_filter (fun w => f w = 0) ns)
      change white.card ≤ _ at h
      omega
    by_cases e : white.Nonempty
    · obtain ⟨w,hw⟩ := e
      obtain ⟨ws,wzero⟩ := mem_filter.mp hw
      apply mem_union_right
      apply mem_biUnion.mpr ⟨w,ws,?_⟩
      have wv : w ≠ v := fun eq => vs (eq ▸ ws)
      apply (box_mem (show Disjoint (insert v (s.erase w)) {w} by simp [wv,wv.symm]) f).mpr
      refine ⟨?_,by simpa using wzero⟩
      intro y hy
      rcases mem_insert.mp hy with rfl | hy
      · exact marked
      · intro hit
        have yw : y ∈ white := mem_filter.mpr ⟨(mem_erase.mp hy).2,hit⟩
        exact (mem_erase.mp hy).1 ((card_le_one.mp wb) _ yw _ hw)
    · apply mem_union_left
      apply (box_mem (disjoint_empty_right _) f).mpr
      refine ⟨?_,by simp⟩
      intro y hy
      rcases mem_insert.mp hy with rfl | hy
      · exact marked
      · exact fun h => e ⟨y,mem_filter.mpr ⟨hy,h⟩⟩
  have countZ : zero.card = 2^(d+1) * 3^(n-(d+1)) := by
    simp only [zero,card_box _ _ (disjoint_empty_right _),card_empty,add_zero,card_insert_of_not_mem vs,d,n]
  have countO (w : V) (hw : w ∈ s) : (one w).card = 2^d * 3^(n-(d+1)) := by
    have wv : w ≠ v := fun eq => vs (eq ▸ hw)
    have vv : v ∉ s.erase w := fun h => vs (mem_erase.mp h).2
    have pos : 0 < s.card := card_pos.mpr ⟨w,hw⟩
    simp only [one,card_box _ _ (show Disjoint (insert v (s.erase w)) {w} by simp [wv,wv.symm]),
      card_insert_of_not_mem vv,card_erase_of_mem hw,card_singleton,d,n,
      show s.card - 1 + 1 = s.card by omega]
  have boundO : (s.biUnion one).card ≤ d*(2^d * 3^(n-(d+1))) :=
    card_biUnion_le.trans (by simp [sum_congr rfl countO,d])
  have can : candidates.card = 2*3^(n-1) := by simp [candidates,card_box _ _ (disjoint_empty_right _),n]
  have h := (card_le_card inc).trans (card_union_le _ _)
  have h₂ := card_union_le zero (s.biUnion one)
  rw [can] at h
  rw [countZ] at h₂
  have loss : 2*3^(n-1) ≤ good.card + (2^(d+1)+d*2^d)*3^(n-(d+1)) := by
    rw [add_mul,mul_assoc]
    omega
  have exp₁ : n-1 = 11 + (n-12) := by dsimp [n]; omega
  have exp₂ : n-(d+1) = (11-d) + (n-12) := by dsimp [n,d]; omega
  rw [exp₁,exp₂,pow_add (3:ℕ) 11 (n-12),pow_add (3:ℕ) (11-d) (n-12)] at loss
  rw [← Nat.mul_assoc,← Nat.mul_assoc] at loss
  change (2*3^11 - (2^(d+1)+d*2^d)*3^(11-d))*3^(n-12) ≤ good.card
  rw [Nat.sub_mul]
  exact (Nat.sub_le_iff_le_add.mpr (by simpa only [Nat.add_comm] using loss) :
    (2*3^11)*3^(n-12) - ((2^(d+1)+d*2^d)*3^(11-d))*3^(n-12) ≤ good.card)


/-- A finite double count bounds the exact local optimum of each block. Vertices
outside the block are retained, so genuine neighbors there can only help. -/
theorem block_score (r : Finset V) (large : 12 ≤ Fintype.card V) :
    (∑ v ∈ r, score (min (G.degree v) 11)) ≤ 3^12 * Capacity.value G r rᶜ := by
  let scale := 3^(Fintype.card V-12)
  have one (v : V) (hv : v ∈ r) : score (min (G.degree v) 11) * scale ≤
      ((univ : Finset (V → Fin 3)).filter (fun f => v ∈ survivors G r f)).card := by
    have can : min (G.degree v) 11 ≤ (G.neighborFinset v).card := by
      rw [card_neighborFinset_eq_degree]; exact min_le_left _ _
    obtain ⟨s,sub,sc⟩ := exists_subset_card_eq can
    have h := local_count G r v hv s sub (sc ▸ min_le_right _ _) large
    simpa only [sc] using h
  have counts :
      ∑ v ∈ r, ((univ : Finset (V → Fin 3)).filter (fun f => v ∈ survivors G r f)).card =
      ∑ f : V → Fin 3, (survivors G r f).card := by
    calc
      _ = ∑ v ∈ r, ∑ f : V → Fin 3, (if v ∈ survivors G r f then 1 else 0 : ℕ) := by simp
      _ = _ := by
        rw [sum_comm]
        apply sum_congr rfl
        intro f _
        simp only [sum_boole,Nat.cast_id]
        congr 1
        exact filter_mem_eq_inter.trans (inter_eq_right.mpr (filter_subset _ _))
  have ub := sum_le_sum (s := (univ : Finset (V → Fin 3))) (fun f _ => survives_le G r f)
  have ncolors : Fintype.card (V → Fin 3) = 3^Fintype.card V := by simp [Fintype.card_pi]
  simp only [sum_const,card_univ,nsmul_eq_mul,ncolors] at ub
  have mass := sum_le_sum one
  rw [← sum_mul,counts] at mass
  have h := mass.trans ub
  have exp : Fintype.card V = 12 + (Fintype.card V-12) := by omega
  have fac : 3^Fintype.card V = 3^12*scale := by
    change 3^Fintype.card V = 3^12 * 3^(Fintype.card V-12)
    rw [← pow_add,← exp]
  simp only [Nat.cast_id] at h
  rw [fac,mul_right_comm (3^12) scale] at h
  exact Nat.le_of_mul_le_mul_right h (by exact pow_pos (by decide : 0 < (3:ℕ)) _)

private def step (d : ℕ) := if 3 ≤ d then score (d+1) - score d else 0

private theorem profile_score (e : ℕ) (offset : (types G).card = (high G).card + e) :
    (high G).card * score 11 ≤ (∑ z ∈ high G, score (min (G.degree z) 11)) +
    ∑ j ∈ range 11, step j * (j.choose 2 + 1 - e) := by
  have coeff : ∀ d : Fin 12, 3 ≤ d.val → score 11 ≤ score d.val +
      ∑ j ∈ range 11, (if d.val ≤ j then step j else 0) := by decide
  have point (z : V) (hz : z ∈ high G) : score 11 ≤ score (min (G.degree z) 11) +
      ∑ j ∈ range 11, (if G.degree z ≤ j then step j else 0) := by
    by_cases small : G.degree z ≤ 11
    · rw [min_eq_left small]
      exact coeff ⟨G.degree z,by omega⟩ (mem_filter.mp hz).2
    · rw [min_eq_right (by omega)]
      omega
  have boundJ (j : ℕ) :
      (∑ z ∈ high G, if G.degree z ≤ j then step j else 0) ≤ step j * (j.choose 2+1-e) := by
    rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    by_cases j₃ : 3 ≤ j
    · have h := Repair.profile_count G j (by omega)
      apply Nat.mul_le_mul_left
      simp only [Nat.cast_id]
      omega
    · simp [step,j₃]
  have h := sum_le_sum point
  simp only [sum_const,nsmul_eq_mul,sum_add_distrib] at h
  rw [sum_comm (s := high G) (t := range 11)] at h
  exact h.trans (Nat.add_le_add_left (sum_le_sum (fun j _ => boundJ j)) _)

/-- A counterexample contains at most 55 triangle types and at most 81
nonleaves. All degrees, random-label counts and numerical constants in
this reduction are kernel checked. -/
theorem bounded_core (failure : bound G < gamma G) :
    (types G).card ≤ 55 ∧ (nonleaves G).card ≤ 81 := by
  have baseline := high_bound G
  have colors := nonleaf_bound G
  have highCap := type_bound G
  have vCap : (types G).card ≤ Fintype.card V := by
    simpa [types] using (card_image_le (s := (univ : Finset V)) (f := trianglesAt G))
  have more : (high G).card < (types G).card := by
    by_contra! h
    exact (not_le_of_gt failure) (exact_of_high G (by omega))
  unfold bound at failure
  have count : (types G).card ≤ 55 := by
    by_contra! big
    have av := block_score G (high G) (by omega)
    have limit := Capacity.seeded_value G ∅ (high G) (high G)ᶜ
      (by simp) (by simp) disjoint_compl_right (by simp)
    simp only [card_empty,zero_add] at limit
    have peak : score 11 = 2*3^11 - (2^(11+1) + 11*2^11) := by decide
    by_cases eq : (types G).card = (high G).card + 1
    · have h := profile_score G 1 eq
      have num : (∑ j ∈ range 11, step j * (j.choose 2+1-1)) = 3275352 := by decide
      rw [num,peak] at h
      omega
    · have h := profile_score G 2 (by omega)
      have num : (∑ j ∈ range 11, step j * (j.choose 2+1-2)) = 3039536 := by decide
      rw [num,peak] at h
      omega
  exact ⟨count,by omega⟩

end Graffiti384b.CoreSize

#print axioms Graffiti384b.CoreSize.block_score
#print axioms Graffiti384b.CoreSize.bounded_core
