import TriangleBlocks

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem merge_frames {A B C D : Finset V}
    (dis : Disjoint (A∪C) (B∪D))
    (ab : ∀ x∈A, 2≤nbr G x B) (ba : ∀ x∈B, 2≤nbr G x A)
    (cd : ∀ x∈C, 2≤nbr G x D) (dc : ∀ x∈D, 2≤nbr G x C)
    {x y : V} (xx : x∈A∪C ∨ x∈B∪D) (yy : y∈A∪C ∨ y∈B∪D) :
    Covered G (insert x (insert y (high G))) := by
  apply complete G dis
  · intro v vm vp vq
    rcases mem_insert.mp vm with rfl|vm
    · exact (xx.elim vp vq).elim
    rcases mem_insert.mp vm with rfl|vm
    · exact (yy.elim vp vq).elim
    exact (mem_filter.mp vm).2
  · intro v vm
    exact (mem_union.mp vm).elim (fun m => (ab _ m).trans (Repair.nbr_mono G _ subset_union_left))
      (fun m => (cd _ m).trans (Repair.nbr_mono G _ subset_union_right))
  · intro v vm
    exact (mem_union.mp vm).elim (fun m => (ba _ m).trans (Repair.nbr_mono G _ subset_union_left))
      (fun m => (dc _ m).trans (Repair.nbr_mono G _ subset_union_right))

/-- Two degree-two centers on squares can be protected together if they are
nonadjacent and have disjoint neighborhoods. The squares may intersect. -/
theorem paired_squares {x y u v : V} (xy : x≠y) (off : ¬G.Adj x y)
    (dx : G.degree x=2) (dy : G.degree y=2)
    (dis : Disjoint (G.neighborFinset x) (G.neighborFinset y))
    (ux : u≠x) (vy : v≠y)
    (su : ∀a,G.Adj x a → G.Adj u a) (sv : ∀a,G.Adj y a → G.Adj v a) :
    Covered G (insert x (insert y (high G))) := by
  classical
  let A := G.neighborFinset x
  let C := G.neighborFinset y
  let B : Finset V := {x,u}
  let D : Finset V := {y,v}
  have data {k l : V} (kl : k≠l) (deg : G.degree k=2) (sup : ∀a,G.Adj k a → G.Adj l a) :
      (∀a∈G.neighborFinset k,2≤nbr G a {k,l}) ∧
      (∀a∈({k,l}:Finset V),2≤nbr G a (G.neighborFinset k)) ∧
      Disjoint (G.neighborFinset k) ({k,l}:Finset V) := by
    refine ⟨?_,?_,?_⟩
    · intro a am
      have ka := (G.mem_neighborFinset ..).mp am
      exact PinnedColor34.two G kl ka.symm (sup a ka).symm (by simp) (by simp)
    · intro a am
      have alladj : ∀b∈G.neighborFinset k,G.Adj a b := by
        rcases mem_insert.mp am with rfl|am
        · exact fun _ m => (G.mem_neighborFinset ..).mp m
        · obtain rfl := mem_singleton.mp am
          exact fun _ m => sup _ ((G.mem_neighborFinset ..).mp m)
      rw [nbr,filter_true_of_mem alladj,card_neighborFinset_eq_degree,deg]
    · apply disjoint_left.mpr
      intro a am bm
      have adj := (G.mem_neighborFinset ..).mp am
      rcases mem_insert.mp bm with rfl|bm
      · exact adj.ne rfl
      · obtain rfl := mem_singleton.mp bm
        exact (sup _ adj).ne rfl
  obtain ⟨ab,ba,dab⟩ := data ux.symm dx su
  obtain ⟨cd,dc,dcd⟩ := data vy.symm dy sv
  have nx : ∃a,a∈A := card_pos.mp (by simp [A,dx] : 0<(G.neighborFinset x).card)
  have ny : ∃a,a∈C := card_pos.mp (by simp [C,dy] : 0<(G.neighborFinset y).card)
  have uy : u≠y := by
    rintro rfl
    obtain ⟨a,m⟩ := nx
    exact disjoint_left.mp dis m ((G.mem_neighborFinset ..).mpr (su _ ((G.mem_neighborFinset ..).mp m)))
  have vx : v≠x := by
    rintro rfl
    obtain ⟨a,m⟩ := ny
    exact disjoint_left.mp dis ((G.mem_neighborFinset ..).mpr (sv _ ((G.mem_neighborFinset ..).mp m))) m
  by_cases same : u=v
  · subst v
    have ad : Disjoint A D := by
      apply disjoint_left.mpr
      intro a am dm
      have h := (G.mem_neighborFinset ..).mp am
      rcases mem_insert.mp dm with rfl|m
      · exact off h
      · obtain rfl := mem_singleton.mp m; exact (su _ h).ne rfl
    have cb : Disjoint C B := by
      apply disjoint_left.mpr
      intro a cm bm
      have h := (G.mem_neighborFinset ..).mp cm
      rcases mem_insert.mp bm with rfl|m
      · exact off h.symm
      · obtain rfl := mem_singleton.mp m; exact (sv _ h).ne rfl
    have sep : Disjoint (A∪C) (B∪D) := disjoint_union_left.mpr
      ⟨disjoint_union_right.mpr ⟨dab,ad⟩,disjoint_union_right.mpr ⟨cb,dcd⟩⟩
    exact merge_frames G sep ab ba cd dc (Or.inr (mem_union_left _ (mem_insert_self ..)))
      (Or.inr (mem_union_right _ (mem_insert_self ..)))
  · have bd : Disjoint B D := by simp [B,D,xy.symm,uy.symm,vx,Ne.symm same]
    have sep : Disjoint (A∪D) (B∪C) := disjoint_union_left.mpr
      ⟨disjoint_union_right.mpr ⟨dab,dis⟩,disjoint_union_right.mpr ⟨bd.symm,dcd.symm⟩⟩
    exact merge_frames G sep ab ba dc cd (Or.inr (mem_union_left _ (mem_insert_self ..)))
      (Or.inl (mem_union_right _ (mem_insert_self ..)))

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.paired_squares
