import ComponentBalance

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def crossing (A : Finset V) (v : V) := (G.neighborFinset v).filter (fun w => ¬(v∈A ↔ w∈A))

private theorem crossing_compl (A : Finset V) (v : V) : crossing G Aᶜ v=crossing G A v := by
  ext; simp [crossing]; tauto

private theorem translated (A : Finset V) {v : V} :
    (crossing G A v).card=nbr G v (if v∈A then Aᶜ else A) := by
  unfold crossing nbr
  congr 1; ext
  by_cases va : v∈A <;> simp [va, and_comm]

private theorem colored {W : Finset V} : Covered G W ↔
    ∃ A : Finset V,∀v∈W,2≤(crossing G A v).card := by
  constructor
  · rintro ⟨A,l,r⟩
    refine ⟨A,fun v vm => ?_⟩
    rw [translated]
    by_cases va : v∈A
    · simpa [va] using l v vm va
    · simpa [va] using r v vm (mem_compl.mpr va)
  · rintro ⟨A,h⟩
    exact ⟨A,fun v vm va => by simpa only [translated,if_pos va] using h v vm,
      fun v vm va => by simpa only [translated,if_neg (mem_compl.mp va)] using h v vm⟩

/-- Orient a covered cut at c. Flipping a vertex with no crossing neighbors
preserves all previous crossing edges and gives a nonisolated c a neighbor across. -/
private theorem orient {W : Finset V} (cut : Covered G W) (c : V) :
    ∃ A : Finset V,c∈A ∧ (∀v∈W,2≤(crossing G A v).card) ∧
      (0<G.degree c → (crossing G A c).Nonempty) := by
  classical
  obtain ⟨B,h⟩ := (colored G).mp cut
  obtain ⟨A,out,h⟩ : ∃ A : Finset V,c∉A ∧ ∀v∈W,2≤(crossing G A v).card := by
    by_cases cm : c∈B
    · exact ⟨Bᶜ,fun m => mem_compl.mp m cm,fun v vm => by simpa only [crossing_compl] using h v vm⟩
    · exact ⟨B,cm,h⟩
  by_cases has : (crossing G A c).Nonempty
  · exact ⟨Aᶜ,mem_compl.mpr out,fun v vm => by simpa only [crossing_compl] using h v vm,
      fun _ => by simpa only [crossing_compl] using has⟩
  have away {v : V} (edge : G.Adj c v) : v∉A := fun va => has
    ⟨v,mem_filter.mpr ⟨(G.mem_neighborFinset ..).mpr edge,by simp [out,va]⟩⟩
  have grow (v : V) : crossing G A v⊆crossing G (insert c A) v := by
    intro w wm
    obtain ⟨adj,opp⟩ := mem_filter.mp wm
    apply mem_filter.mpr ⟨adj,?_⟩
    have edge := (G.mem_neighborFinset ..).mp adj
    by_cases vc : v=c
    · subst v; exact (opp (iff_of_false out (away edge))).elim
    by_cases wc : w=c
    · subst w; exact (opp (iff_of_false (away edge.symm) out)).elim
    simpa [vc,wc] using opp
  refine ⟨insert c A,mem_insert_self ..,fun v vm => (h v vm).trans (card_le_card (grow v)),?_⟩
  intro pos
  obtain ⟨v,cv⟩ := (G.degree_pos_iff_exists_adj c).mp pos
  exact ⟨v,mem_filter.mpr ⟨(G.mem_neighborFinset ..).mpr cv,by simp [cv.ne.symm,away cv]⟩⟩

/-- The spanning restriction to a vertex set, leaving the exterior isolated. -/
def inside (S : Finset V) : SimpleGraph V where
  Adj v w := G.Adj v w ∧ v∈S ∧ w∈S
  symm := fun _ _ h => ⟨h.1.symm,h.2.2,h.2.1⟩
  loopless := fun _ h => h.1.ne rfl

instance (S : Finset V) : DecidableRel (inside G S).Adj := fun _ _ => inferInstanceAs (Decidable (_ ∧ _ ∧ _))

/-- Glue two cuts across a one-vertex separation. A center that is high in
neither piece can use one crossing edge from each piece. -/
theorem glue {X Y L R : Finset V} {c : V} (only : X∩Y={c})
    (edges : ∀ {x y},G.Adj x y → (x∈X ∧ y∈X) ∨ (x∈Y ∧ y∈Y))
    (left : Covered (inside G X) (L∪high (inside G X)))
    (right : Covered (inside G Y) (R∪high (inside G Y))) :
    Covered G ((L∪R)∪high G) := by
  classical
  let J := inside G X
  let K := inside G Y
  obtain ⟨A,ca,ha,pa⟩ := orient J left c
  obtain ⟨B,cb,hb,pb⟩ := orient K right c
  let C := (X∩A)∪(Y∩B)
  have agree (v : V) (x : v∈X) (y : v∈Y) : v=c := mem_singleton.mp (only ▸ mem_inter.mpr ⟨x,y⟩)
  have xa {v : V} (x : v∈X) : (v∈C ↔ v∈A) := by
    constructor
    · intro vm
      rcases mem_union.mp vm with m|m
      · exact (mem_inter.mp m).2
      · exact agree v x (mem_inter.mp m).1 ▸ ca
    · exact fun va => mem_union_left _ (mem_inter.mpr ⟨x,va⟩)
  have yb {v : V} (y : v∈Y) : (v∈C ↔ v∈B) := by
    constructor
    · intro vm
      rcases mem_union.mp vm with m|m
      · exact agree v (mem_inter.mp m).1 y ▸ cb
      · exact (mem_inter.mp m).2
    · exact fun vb => mem_union_right _ (mem_inter.mpr ⟨y,vb⟩)
  have transfer (H : SimpleGraph V) [DecidableRel H.Adj] (D S : Finset V)
      (edge : ∀{v w}, H.Adj v w → G.Adj v w ∧ v∈S ∧ w∈S)
      (same : ∀{v},v∈S → (v∈C ↔ v∈D)) (v : V) : crossing H D v⊆crossing G C v := by
    intro w wm
    obtain ⟨n,opp⟩ := mem_filter.mp wm
    obtain ⟨vw,vs,ws⟩ := edge ((H.mem_neighborFinset ..).mp n)
    exact mem_filter.mpr ⟨(G.mem_neighborFinset ..).mpr vw,by rwa [same vs,same ws]⟩
  have ja := transfer J A X (fun h => h) (fun x => xa x)
  have kb := transfer K B Y (fun h => h) (fun y => yb y)
  have jl {v : V} (h : v∈L∪high J) : 2≤(crossing G C v).card := (ha v h).trans (card_le_card (ja v))
  have kr {v : V} (h : v∈R∪high K) : 2≤(crossing G C v).card := (hb v h).trans (card_le_card (kb v))
  apply (colored G).mpr
  refine ⟨C,fun v vm => ?_⟩
  rcases mem_union.mp vm with m|hi
  · rcases mem_union.mp m with m|m
    · exact jl (mem_union_left _ m)
    · exact kr (mem_union_left _ m)
  have total := (mem_filter.mp hi).2
  by_cases j : 3≤J.degree v
  · exact jl (mem_union_right _ (mem_filter.mpr ⟨mem_univ _,j⟩))
  by_cases k : 3≤K.degree v
  · exact kr (mem_union_right _ (mem_filter.mpr ⟨mem_univ _,k⟩))
  have un : J.neighborFinset v ∪ K.neighborFinset v=G.neighborFinset v := by
    ext w
    simp only [mem_union,mem_neighborFinset]
    exact ⟨fun h => h.elim (fun t => t.1) (fun t => t.1),fun h =>
      (edges h).elim (fun t => Or.inl ⟨h,t⟩) (fun t => Or.inr ⟨h,t⟩)⟩
  have sum := card_union_le (J.neighborFinset v) (K.neighborFinset v)
  rw [un] at sum
  simp only [card_neighborFinset_eq_degree] at sum
  obtain ⟨x,jx⟩ := (J.degree_pos_iff_exists_adj v).mp (by omega : 0<J.degree v)
  obtain ⟨y,ky⟩ := (K.degree_pos_iff_exists_adj v).mp (by omega : 0<K.degree v)
  have vc := agree v jx.2.1 ky.2.1
  subst v
  obtain ⟨a,am⟩ := pa (by omega)
  obtain ⟨b,bm⟩ := pb (by omega)
  have ac := (J.mem_neighborFinset ..).mp (mem_filter.mp am).1
  have bc := (K.mem_neighborFinset ..).mp (mem_filter.mp bm).1
  have ne : a≠b := by
    rintro rfl
    exact ac.1.ne.symm (agree a ac.2.2 bc.2.2)
  have inc := insert_subset (ja c am) (singleton_subset_iff.mpr (kb c bm))
  simpa only [card_pair ne] using card_le_card inc

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.glue
