import EarCoreReduction
namespace Graffiti384b.OddStars.EarPacking
open Finset SimpleGraph PositivePalette
open private Repair.omit_set Repair.nbr_mono from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def rich : Finset V := univ.filter (fun w => 2≤trianglesAt G w)
def ones : Finset V := univ.filter (fun w => trianglesAt G w=1)
def weight (S : Finset V) : ℕ := (S∩rich G).card + if (S∩ones G).Nonempty then 1 else 0

/-- All rich vertices and any one chosen ear have a common protecting
cut in the graph of triangle edges itself. -/
theorem cover_rich_ear {e : V} (one : trianglesAt G e=1) :
    Covered (patch G ∅) (insert e (rich G)) := by
  classical
  let J := patch G ∅
  have big : rich G⊆high J := fun _ m => rich_high G (mem_filter.mp m).2 ∅
  have cov : Covered J (insert e (high J)) := by
    by_cases eh : e∈high J
    · rw [insert_eq_of_mem eh]; exact covers_high J
    have low : J.degree e≤2 := by
      apply Nat.le_of_not_gt; intro d
      exact eh (mem_filter.mpr ⟨mem_univ _,d⟩)
    have pos : 0<trianglesAt J e := by change 0<trianglesAt (patch G ∅) e; rw [patch_scores,one]; decide
    obtain ⟨a,b,ea,eb,ab⟩ := (TrianglePrune.triangle_iff J e).mp pos
    have d := Prerequisites.deg2 J ab.ne ea eb
    exact cover_two G (c:=e) (S:=∅) (empty_subset _) (by change J.degree e=2; omega)
  obtain ⟨A,l,r⟩ := cov
  have sub := insert_subset_insert e big
  exact ⟨A,fun _ m => l _ (sub m),fun _ m => r _ (sub m)⟩

private theorem local_set (S : Finset V) :
    ∃ W⊆S,W.card=weight G S ∧ Covered (patch G ∅) W := by
  classical
  let R := S∩rich G
  by_cases has : (S∩ones G).Nonempty
  · obtain ⟨e,em⟩ := has
    have one := (mem_filter.mp (mem_inter.mp em).2).2
    have off : e∉R := fun m => by have b := (mem_filter.mp (mem_inter.mp m).2).2; omega
    obtain ⟨A,l,r⟩ := cover_rich_ear G one
    have sub : insert e R⊆insert e (rich G) := insert_subset_insert e inter_subset_right
    refine ⟨insert e R,insert_subset (mem_inter.mp em).1 inter_subset_left,?_,A,fun _ m => l _ (sub m),fun _ m => r _ (sub m)⟩
    rw [card_insert_of_not_mem off,weight,if_pos (show (S∩ones G).Nonempty from ⟨e,em⟩)]
  · obtain ⟨A,l,r⟩ := covers_high (patch G ∅)
    have sub : R⊆high (patch G ∅) := fun _ m => rich_high G (mem_filter.mp (mem_inter.mp m).2).2 ∅
    refine ⟨R,inter_subset_left,?_,A,fun _ m => l _ (sub m),fun _ m => r _ (sub m)⟩
    simp [R,weight,has]

/-- The number of safe omissions guaranteed by an arbitrary disjoint
family of parts with no triangle edge between different parts. -/
theorem packing {I : Type*} [DecidableEq I] (s : Finset I) (B : I→Finset V)
    (ds : ∀i∈s,∀j∈s,i≠j → Disjoint (B i) (B j))
    (sep : ∀i∈s,∀j∈s,i≠j → ∀x∈B i,∀y∈B j,¬(patch G ∅).Adj x y) :
    gamma G+(∑i∈s,(weight G (B i)+1)/2)≤Fintype.card V := by
  classical
  let J := patch G ∅
  let U := s.biUnion B
  let K := Uᶜ
  have piece (i : I) (im : i∈s) : (weight G (B i)+1)/2≤Capacity.value J (B i) K := by
    obtain ⟨W,sub,sz,A,l,r⟩ := local_set G (B i)
    have support {v w : V} (vm : v∈B i) (adj : J.Adj v w) : w∈K ∨ w∈B i := by
      by_cases wu : w∈U
      · obtain ⟨j,jm,wb⟩ := mem_biUnion.mp wu
        by_cases ij : i=j
        · exact Or.inr (ij ▸ wb)
        · exact (sep i im j jm ij v vm w wb adj).elim
      · exact Or.inl (mem_compl.mpr wu)
    have side {P : Finset V} (cross : ∀v∈W,v∈P → 2≤nbr J v Pᶜ) :
        (W∩P).card≤Capacity.value J (B i) K := by
      apply Capacity.le_value J
      refine ⟨inter_subset_left.trans sub,?_⟩
      intro v vm
      obtain ⟨vw,vp⟩ := mem_inter.mp vm
      apply (cross _ vw vp).trans (card_le_card ?_)
      intro w wm
      obtain ⟨wo,edge⟩ := mem_filter.mp wm
      exact mem_filter.mpr ⟨(support (sub vw) edge).elim (fun k => mem_union_left _ k)
        (fun b => mem_union_right _ (mem_sdiff.mpr ⟨b,fun m => mem_compl.mp wo (mem_inter.mp m).2⟩)),edge⟩
    have h := side l
    have k := side (P:=Aᶜ) (by simpa only [compl_compl] using r)
    have eq : W∩Aᶜ=W\A := by ext; simp
    rw [eq] at k
    have part := card_sdiff_add_card_inter W A
    omega
  have add (t : Finset I) (ts : t⊆s) :
      Capacity.value J (t.biUnion B) K=∑i∈t,Capacity.value J (B i) K := by
    induction t using Finset.induction_on with
    | empty =>
      obtain ⟨O,feas,val⟩ := Capacity.attained J ∅ K
      have eq : O=∅ := subset_empty.mp feas.1
      simpa [eq] using val.symm
    | @insert i t out ih =>
      have im := ts (mem_insert_self i t)
      have sub : t⊆s := fun j jm => ts (mem_insert_of_mem jm)
      have dis : Disjoint (B i) (t.biUnion B) := disjoint_left.mpr (by
        intro x xm m; obtain ⟨j,jm,wm⟩ := mem_biUnion.mp m
        exact disjoint_left.mp (ds i im j (sub jm) (fun eq => out (eq ▸ jm))) xm wm)
      have apart : ∀x∈B i,∀y∈t.biUnion B,¬J.Adj x y := by
        intro x xm y ym; obtain ⟨j,jm,n⟩ := mem_biUnion.mp ym
        exact sep i im j (sub jm) (fun eq => out (eq ▸ jm)) x xm y n
      rw [biUnion_insert,sum_insert out,Capacity.separated_add J _ _ _ dis apart,ih sub]
  have cost := sum_le_sum piece
  rw [←add s Subset.rfl] at cost
  obtain ⟨O,feas,val⟩ := Capacity.attained J U K
  have om := Repair.omit_set G O (fun v vm => (feas.2 v vm).trans (card_le_card (fun w wm => by
    obtain ⟨h,e⟩ := mem_filter.mp wm
    exact mem_filter.mpr ⟨mem_compl.mpr (fun o => (mem_union.mp h).elim (fun k => mem_compl.mp k (feas.1 o))
      (fun d => (mem_sdiff.mp d).2 o)),e.1⟩)))
  have lim := card_le_univ O
  change (∑i∈s,(weight G (B i)+1)/2)≤Capacity.value J U K at cost
  omega

/-- When score one occurs in a failure, every rich score occurs exactly
once and accounts for all but two members of the triangle palette. -/
theorem rich_count (bad : bound G<gamma G) (one : 1∈types G) :
    (rich G).card+2=(types G).card := by
  classical
  have zero := (failure_requires_odd_zero G bad).2
  have inj : Set.InjOn (trianglesAt G) (rich G:Set V) :=
    fun _ xm _ _ eq => distinct_rich G bad (mem_filter.mp xm).2 eq
  have sets : (rich G).image (trianglesAt G)=((types G).erase 0).erase 1 := by
    ext k; constructor
    · intro km; obtain ⟨w,wm,rfl⟩ := mem_image.mp km
      have d := (mem_filter.mp wm).2
      exact mem_erase.mpr ⟨by omega,mem_erase.mpr ⟨by omega,mem_image_of_mem _ (mem_univ w)⟩⟩
    · intro km; obtain ⟨o,m⟩ := mem_erase.mp km; obtain ⟨z,m⟩ := mem_erase.mp m
      obtain ⟨w,_,rfl⟩ := mem_image.mp m
      exact mem_image.mpr ⟨w,mem_filter.mpr ⟨mem_univ _,by omega⟩,rfl⟩
  have a := card_erase_add_one (mem_erase.mpr ⟨by decide,one⟩ : 1∈(types G).erase 0)
  have b := card_erase_add_one zero
  rw [←sets,card_image_iff.mpr inj] at a
  omega

end Graffiti384b.OddStars.EarPacking
#print axioms Graffiti384b.OddStars.EarPacking.cover_rich_ear
#print axioms Graffiti384b.OddStars.EarPacking.packing
#print axioms Graffiti384b.OddStars.EarPacking.rich_count
