import Prune384b

namespace Graffiti384b.FiniteRange
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Count retained b-sets missing a designated vertex and containing at most
one of d designated neighbors, in an m-vertex pool. -/
def badCount (m b d : ℕ) := (m-1-d).choose b + d * (m-1-d).choose (b-1)

private def bad (s k : Finset V) :=
  (s \ k).filter (fun v => nbr G v (sᶜ ∪ k) < 2)

private theorem trial (s k : Finset V) (ks : k ⊆ s) :
    s.card - k.card ≤ Capacity.value G s sᶜ + (bad G s k).card := by
  let o := (s \ k) \ bad G s k
  have good : Capacity.Feasible G s sᶜ o := by
    refine ⟨sdiff_subset.trans sdiff_subset,?_⟩
    intro v hv
    have enough : 2 ≤ nbr G v (sᶜ ∪ k) := Nat.le_of_not_gt (fun h =>
      (mem_sdiff.mp hv).2 (mem_filter.mpr ⟨(mem_sdiff.mp hv).1,h⟩))
    apply enough.trans
    apply card_le_card (filter_subset_filter _ (union_subset_union Subset.rfl ?_))
    intro w hw
    exact mem_sdiff.mpr ⟨ks hw,fun ho => (mem_sdiff.mp (mem_sdiff.mp ho).1).2 hw⟩
  have val := Capacity.le_value G good
  have part : o.card + (bad G s k).card = (s \ k).card :=
    card_sdiff_add_card_eq_card (filter_subset _ _)
  rw [card_sdiff ks] at part
  omega

private theorem count_bad (s : Finset V) (b d : ℕ) (v : V) (vs : v ∈ s)
    (enough : d ≤ G.degree v) (room : d < s.card) :
    ((s.powersetCard b).filter (fun k => v ∈ bad G s k)).card ≤ badCount s.card b d := by
  classical
  obtain ⟨g,gn,gd⟩ := exists_subset_card_eq (show d ≤ (G.neighborFinset v).card by simpa using enough)
  have notv : v ∉ g := fun h => G.not_mem_neighborFinset_self _ (gn h)
  have base : g ∩ s ⊆ s.erase v := fun w hw => mem_erase.mpr
    ⟨fun eq => notv (eq ▸ (mem_inter.mp hw).1),(mem_inter.mp hw).2⟩
  obtain ⟨p,gp,ps,pd⟩ := exists_subsuperset_card_eq base ((card_le_card inter_subset_left).trans gd.le)
    (by rw [card_erase_of_mem vs]; omega)
  let outside := s.erase v \ p
  have qsize : outside.card = s.card-1-d := by simp only [outside,card_sdiff ps,card_erase_of_mem vs,pd]
  let zero := outside.powersetCard b
  let one (w : V) := (outside.powersetCard (b-1)).image (insert w)
  have inc : (s.powersetCard b).filter (fun k => v ∈ bad G s k) ⊆ zero ∪ p.biUnion one := by
    intro k hk
    obtain ⟨sample,badv⟩ := mem_filter.mp hk
    obtain ⟨ks,kb⟩ := mem_powersetCard.mp sample
    obtain ⟨vo,deficit⟩ := mem_filter.mp badv
    have vk := (mem_sdiff.mp vo).2
    have ke : k ⊆ s.erase v := fun w hw => mem_erase.mpr ⟨fun eq => vk (eq ▸ hw),ks hw⟩
    have real : g \ (s \ k) ⊆ (sᶜ ∪ k).filter (G.Adj v) := by
      intro w hw
      obtain ⟨wg,notout⟩ := mem_sdiff.mp hw
      apply mem_filter.mpr ⟨?_,(G.mem_neighborFinset _ _).mp (gn wg)⟩
      by_cases ws : w ∈ s
      · exact mem_union_right _ (Classical.byContradiction (fun nk => notout (mem_sdiff.mpr ⟨ws,nk⟩)))
      · exact mem_union_left _ (mem_compl.mpr ws)
    have replace : g ∩ (s \ k) ⊆ p \ k := by
      intro w hw
      obtain ⟨wg,ss⟩ := mem_inter.mp hw
      exact mem_sdiff.mpr ⟨gp (mem_inter.mpr ⟨wg,(mem_sdiff.mp ss).1⟩),(mem_sdiff.mp ss).2⟩
    have h₁ := card_le_card real
    change _ ≤ nbr G v (sᶜ ∪ k) at h₁
    have h₂ := card_le_card replace
    have h₃ := card_sdiff_add_card_inter g (s \ k)
    have h₄ := card_sdiff_add_card_inter p k
    have small : (p ∩ k).card ≤ 1 := by omega
    by_cases ne : (p ∩ k).Nonempty
    · obtain ⟨w,hw⟩ := ne
      obtain ⟨wp,wk⟩ := mem_inter.mp hw
      apply mem_union_right
      refine mem_biUnion.mpr ⟨w,wp,mem_image.mpr ⟨k.erase w,mem_powersetCard.mpr ⟨?_,?_⟩,insert_erase wk⟩⟩
      · intro z hz
        obtain ⟨zw,zk⟩ := mem_erase.mp hz
        exact mem_sdiff.mpr ⟨ke zk,fun zp => zw ((card_le_one.mp small) _ (mem_inter.mpr ⟨zp,zk⟩) _ hw)⟩
      · rw [card_erase_of_mem wk,kb]
    · apply mem_union_left
      exact mem_powersetCard.mpr ⟨fun z hz => mem_sdiff.mpr ⟨ke hz,fun zp => ne ⟨z,mem_inter.mpr ⟨zp,hz⟩⟩⟩,kb⟩
  have first := (card_le_card inc).trans (card_union_le _ _)
  have countOne (w : V) : (one w).card ≤ outside.card.choose (b-1) :=
    card_image_le.trans_eq (card_powersetCard _ _)
  have sumOne : (p.biUnion one).card ≤ p.card * outside.card.choose (b-1) :=
    card_biUnion_le.trans ((sum_le_sum (fun w _ => countOne w)).trans_eq (by simp))
  have zsize : zero.card = outside.card.choose b := card_powersetCard _ _
  rw [zsize] at first
  rw [qsize] at first sumOne
  rw [pd] at sumOne
  unfold badCount
  omega

private def gap (m b j : ℕ) := if 2 ≤ j then badCount m b j - badCount m b (j+1) else 0

def charge (t m b : ℕ) := m * badCount m b 11 + ∑ j ∈ range 11,
  gap m b j * min m (m + j.choose 2 + 1 - t)

private theorem local_profile (s : Finset V) (hs : high G ⊆ s) (j : ℕ) (j₂ : 2 ≤ j) :
    (s.filter (fun z => G.degree z ≤ j)).card + (types G).card ≤ s.card + j.choose 2 + 1 := by
  have prior := Repair.profile_count G j j₂
  have fsub : s.filter (fun z => G.degree z ≤ j) ⊆ (high G).filter (fun z => G.degree z ≤ j) ∪ (s \ high G) := by
    intro z hz
    obtain ⟨zs,deg⟩ := mem_filter.mp hz
    by_cases h : z ∈ high G
    · exact mem_union_left _ (mem_filter.mpr ⟨h,deg⟩)
    · exact mem_union_right _ (mem_sdiff.mpr ⟨zs,h⟩)
  have ineq := (card_le_card fsub).trans (card_union_le _ _)
  have eq := card_sdiff_add_card_eq_card hs
  omega

/-- A finite local sampling certificate. The pool contains all high vertices
and only nonleaves. Outside it all vertices are kept. -/
theorem fixed_pool (s : Finset V) (b : ℕ) (hs : high G ⊆ s) (sn : s ⊆ nonleaves G)
    (large : 12 ≤ s.card) (bs : b ≤ s.card)
    (envelope : ∀ d : Fin 12, 2 ≤ d.val → badCount s.card b d.val ≤ badCount s.card b 11 +
      ∑ j ∈ range 11, if d.val ≤ j then gap s.card b j else 0)
    (certificate : charge (types G).card s.card b <
      (s.card-b+1-((types G).card+1)/2)*s.card.choose b) :
    gamma G ≤ bound G := by
  classical
  let opts := s.powersetCard b
  let fiber (z : V) := (opts.filter (fun k => z ∈ bad G s k)).card
  have point (z : V) (hz : z ∈ s) : fiber z ≤ badCount s.card b 11 +
      ∑ j ∈ range 11, if G.degree z ≤ j then gap s.card b j else 0 := by
    have raw := count_bad G s b (min (G.degree z) 11) z hz (min_le_left _ _) (by omega)
    by_cases low : G.degree z ≤ 11
    · rw [min_eq_left low] at raw
      exact raw.trans (envelope ⟨G.degree z,by omega⟩ (mem_filter.mp (sn hz)).2)
    · rw [min_eq_right (by omega)] at raw
      exact raw.trans (Nat.le_add_right ..)
  have step (j : ℕ) : (∑ z ∈ s, if G.degree z ≤ j then gap s.card b j else 0) ≤
      gap s.card b j * min s.card (s.card+j.choose 2+1-(types G).card) := by
    rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    by_cases j₂ : 2 ≤ j
    · have h := local_profile G s hs j j₂
      apply Nat.mul_le_mul_left
      simp only [Nat.cast_id]
      have := card_filter_le s (fun z => G.degree z ≤ j)
      omega
    · simp [gap,j₂]
  have sumH := sum_le_sum point
  rw [sum_add_distrib,sum_comm (s := s) (t := range 11)] at sumH
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id] at sumH
  have u : (∑ z ∈ s, fiber z) ≤ charge (types G).card s.card b :=
    sumH.trans (Nat.add_le_add_left (sum_le_sum (fun j _ => step j)) _)
  have flip : ∑ k ∈ opts, (bad G s k).card = ∑ z ∈ s, fiber z := by
    calc
      _ = ∑ k ∈ opts, ∑ z ∈ s, (if z ∈ bad G s k then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show bad G s k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
      _ = _ := by rw [sum_comm]; simp [fiber]
  by_contra! fail
  have result := Capacity.seeded_value G ∅ s sᶜ (by simp) (by simp) disjoint_compl_right (by simp)
  simp only [card_empty,zero_add] at result
  unfold bound at fail
  have miss (k : Finset V) (hk : k ∈ opts) :
      s.card-b+1-((types G).card+1)/2 ≤ (bad G s k).card := by
    obtain ⟨sub,kb⟩ := mem_powersetCard.mp hk
    have h := trial G s k sub
    omega
  have m := sum_le_sum miss
  rw [flip] at m
  simp only [opts,sum_const,nsmul_eq_mul,card_powersetCard,Nat.cast_id] at m
  rw [Nat.mul_comm] at certificate
  exact (not_le_of_gt certificate) (m.trans u)

private def poolRow : ℕ → ℕ × ℕ
  | 7 => (14,8)
  | 8 => (12,6)
  | 9 => (17,10)
  | 10 => (15,8)
  | 11 => (21,11)
  | 12 => (18,9)
  | 13 => (24,12)
  | 14 => (21,11)
  | 15 => (27,13)
  | 16 => (24,12)
  | 17 => (30,14)
  | 18 => (27,12)
  | 19 => (32,15)
  | 20 => (29,13)
  | 21 => (35,16)
  | 22 => (31,14)
  | 23 => (37,16)
  | 24 => (33,14)
  | 25 => (38,17)
  | 26 => (34,14)
  | 27 => (40,17)
  | 28 => (35,15)
  | 29 => (41,18)
  | 30 => (36,15)
  | 31 => (42,18)
  | 32 => (37,15)
  | 33 => (43,18)
  | 34 => (38,15)
  | 35 => (44,18)
  | 36 => (38,15)
  | 37 => (45,17)
  | 38 => (38,15)
  | 39 => (45,17)
  | 40 => (39,14)
  | 41 => (45,17)
  | 42 => (41,14)
  | 43 => (45,16)
  | 44 => (43,14)
  | 45 => (44,16)
  | 46 => (45,14)
  | 47 => (46,16)
  | 48 => (47,15)
  | 49 => (48,16)
  | 50 => (49,15)
  | 51 => (50,16)
  | 52 => (51,15)
  | 53 => (52,16)
  | 54 => (53,15)
  | 55 => (54,16)
  | _ => (0,0)

private def Certificate (t m b : ℕ) : Prop :=
  12 ≤ m ∧ t-1 ≤ m ∧ b ≤ m ∧
    (∀ d : Fin 12, 2 ≤ d.val → badCount m b d.val ≤ badCount m b 11 +
      ∑ j ∈ range 11, if d.val ≤ j then gap m b j else 0) ∧
    charge t m b < (m-b+1-(t+1)/2)*m.choose b ∧
    (m ≤ 45 ∨ m = t-1) ∧ ((44 ≤ t ∨ t = 40 ∨ t = 42) → m = t-1)

set_option maxRecDepth 16384 in
set_option maxHeartbeats 5000000 in
private theorem table : ∀ t : Fin 56, 7 ≤ t.val →
    Certificate t (poolRow t).1 (poolRow t).2 := by
  unfold Certificate charge gap badCount
  simp only [Nat.choose_eq_fast_choose]
  decide

/-- Every failure contains a connected induced failure on at most 45
vertices, with identical triangle counts. Its number of types belongs
to 7 through 43, excluding 40 and 42. -/
theorem bounded_induced_failure (hc : G.Connected) (hn : 2 < Fintype.card V)
    (failure : bound G < gamma G) :
    ∃ s : Finset V, 2 < s.card ∧ s.card ≤ 45 ∧ (G.induce (s : Set V)).Connected ∧
      types (G.induce (s : Set V)) = types G ∧
      7 ≤ (types G).card ∧ (types G).card ≤ 43 ∧
      (types G).card ≠ 40 ∧ (types G).card ≠ 42 ∧
      bound (G.induce (s : Set V)) < gamma (G.induce (s : Set V)) := by
  let t := (types G).card
  obtain ⟨r,_,cap,ord,conn,same,fail⟩ := Prune.prune_failure G hc hn failure
  have ntype : (types (G.induce (r : Set V))).card ≤ r.card := by
    simpa [types,Fintype.card_coe] using
      (card_image_le (s := (univ : Finset r)) (f := trianglesAt (G.induce (r : Set V))))
  rw [same] at ntype
  have low : 7 ≤ t := by
    by_contra! few
    exact (not_le_of_gt failure) (Anchor.exact_of_six_types G hc hn (by omega))
  have upper := (CoreSize.bounded_core G failure).1
  let m := (poolRow t).1
  let b := (poolRow t).2
  obtain ⟨large,room,bs,envelope,cert,m45,skip⟩ := table ⟨t,by dsimp [t]; omega⟩ low
  change 12 ≤ m at large
  change t-1 ≤ m at room
  change b ≤ m at bs
  change m ≤ 45 ∨ m = t-1 at m45
  change (44 ≤ t ∨ t = 40 ∨ t = 42) → m = t-1 at skip
  have highSz : (high G).card < t := by
    by_contra! h
    exact (not_le_of_gt failure) (exact_of_high G (by dsimp [t] at h; omega))
  have small : (nonleaves G).card < m := by
    by_contra! enough
    have sub : high G ⊆ nonleaves G := by
      intro v hv
      exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
    obtain ⟨s,hs,sq,sz⟩ := exists_subsuperset_card_eq sub (by omega : (high G).card ≤ m) enough
    exact (not_le_of_gt failure) (fixed_pool G s b hs sq (sz ▸ large) (sz ▸ bs)
      (sz ▸ envelope) (sz ▸ cert))
  change t ≤ r.card at ntype
  have ne : m ≠ t-1 := by omega
  have keep : ¬ (44 ≤ t ∨ t = 40 ∨ t = 42) := fun h => ne (skip h)
  exact ⟨r,ord,by omega,conn,same,low,by change t ≤ 43; omega,
    by change t ≠ 40; omega,by change t ≠ 42; omega,fail⟩

end Graffiti384b.FiniteRange

#print axioms Graffiti384b.FiniteRange.fixed_pool
#print axioms Graffiti384b.FiniteRange.bounded_induced_failure
