import UpperThirteen
import LeafCharacterization
namespace Graffiti384b.OddStars.FiniteUpper
open Finset SimpleGraph PositivePalette ComponentQuota ComponentCenters ComponentPort SingleLeaf
universe u
variable {V : Type u} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- With score one absent, every connected failure yields a one-leaf failure
whose order equals the original diversity and whose palette is identical. -/
theorem canonical (conn : G.Connected) (ord : 2<Fintype.card V) (bad : bound G<gamma G)
    (one : 1∉types G) :
    ∃x : V,let S := component G x
      let K := block G S
      K.Connected ∧ (∀v,0<trianglesAt K v) ∧
      (∀{v w},K.Adj v w → ∃a,K.Adj v a ∧ K.Adj w a) ∧
      ∃r : S,let E := withLeaf K r
        E.Connected ∧ 2<S.card+1 ∧ S.card+1≤13 ∧ S.card+1=(types G).card ∧
        types E=types G ∧ (∀w,trianglesAt E w=0 ↔ w=.inr ()) ∧
        E.degree (.inr ())=1 ∧ bound E<gamma E := by
  classical
  obtain ⟨_,x,_,_,two,_⟩ := PaletteCorollaries.missing_one_failure G conn ord bad one
  let S := component G x
  let K := block G S
  have px : 0<trianglesAt G x := by omega
  obtain ⟨kc,pos,tri,r,ec,lo,_,unique,deg,fail⟩ := canonical_at G conn bad px
  have eqK : types K=S.image (trianglesAt G) := local_scores G S (closed_component G _)
  have nonzero : 0∉types K := by
    intro z
    obtain ⟨v,_,e⟩ := mem_image.mp z
    exact (Nat.ne_of_gt (pos v)) e
  have allPos (v : V) (pv : 0<trianglesAt G v) : v∈S := by
    apply (mem_component ..).mpr
    by_contra no
    exact (not_lt_of_ge (exact_disconnected_no_one G one px pv no)) bad
  have erase : types K=(types G).erase 0 := by
    rw [eqK]; ext k
    constructor
    · intro km
      obtain ⟨v,_,e⟩ := mem_image.mp km
      exact mem_erase.mpr ⟨fun eq => nonzero (eq ▸ (eqK.symm ▸ km)),mem_image.mpr ⟨v,mem_univ _,e⟩⟩
    · intro km
      obtain ⟨nz,real⟩ := mem_erase.mp km
      obtain ⟨v,_,e⟩ := mem_image.mp real
      exact mem_image.mpr ⟨v,allPos _ (by omega),e⟩
  have inj : Set.InjOn (trianglesAt G) (S:Set V) := by
    intro a am b _ same
    have mem : trianglesAt G a∈types K := eqK.symm ▸ mem_image_of_mem _ am
    have off := (mem_erase.mp (erase ▸ mem)).1
    have notOne : trianglesAt G a≠1 := fun e => one (e ▸ mem_image_of_mem _ (mem_univ a))
    exact distinct_rich G bad (by omega) same
  have card := card_erase_add_one (failure_requires_odd_zero G bad).2
  rw [←erase,eqK,card_image_iff.mpr inj] at card
  let E := withLeaf K r
  have scores := leaf_scores K r
  have palette : types E=types G := by
    ext k
    constructor
    · intro km; obtain ⟨v,_,e⟩ := mem_image.mp km
      cases v with
      | inl v =>
        have m : trianglesAt K v∈types K := mem_image_of_mem _ (mem_univ v)
        exact e ▸ (scores.1 v).symm ▸ mem_of_mem_erase (erase ▸ m)
      | inr v =>
        cases v
        have z : k=0 := e.symm.trans scores.2.1
        exact z ▸ (failure_requires_odd_zero G bad).2
    · intro km
      by_cases z : k=0
      · subst k
        exact mem_image.mpr ⟨.inr (),mem_univ _,scores.2.1⟩
      obtain ⟨v,_,eq⟩ := mem_image.mp (show k∈types K from erase.symm ▸ mem_erase.mpr ⟨z,km⟩)
      exact mem_image.mpr ⟨.inl v,mem_univ _,(scores.1 v).trans eq⟩
  have cap := UpperThirteen.diversity_cap G conn ord bad one
  exact ⟨x,kc,pos,@tri,r,ec,lo,card.le.trans cap,card,palette,unique,deg,fail⟩

/-- An exact order-independent reduction to the all-distinct, single-leaf
instances of orders at most thirteen with no score one. -/
theorem exact_of_finite_check
    (check : ∀(U : Type u) [Fintype U] [DecidableEq U] (K : SimpleGraph U) [DecidableRel K.Adj],
      K.Connected → (∀v,0<trianglesAt K v) → (∀{i j},K.Adj i j → ∃a,K.Adj i a ∧ K.Adj j a) →
      ∀r : U,let E := withLeaf K r
        2<Fintype.card U+1 → Fintype.card U+1≤13 → (types E).card=Fintype.card U+1 →
        1∉types E → gamma E≤bound E)
    (conn : G.Connected) (ord : 2<Fintype.card V) (one : 1∉types G) : gamma G≤bound G := by
  apply Nat.le_of_not_gt; intro bad
  obtain ⟨x,kc,pos,tri,r,_,lo,cap,num,eq,_,_,fail⟩ := canonical G conn ord bad one
  have sc : Fintype.card ((component G x):Set V)=(component G x).card := Fintype.card_coe _
  have win := check _ (block G (component G x)) kc pos tri r (by rwa [sc]) (by rwa [sc])
    (by rw [eq,sc,num]) (eq ▸ one)
  exact (not_lt_of_ge win) fail
end Graffiti384b.OddStars.FiniteUpper
#print axioms Graffiti384b.OddStars.FiniteUpper.canonical
#print axioms Graffiti384b.OddStars.FiniteUpper.exact_of_finite_check
