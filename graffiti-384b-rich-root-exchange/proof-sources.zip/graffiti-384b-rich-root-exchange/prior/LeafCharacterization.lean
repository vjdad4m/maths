import SingleLeaf
namespace Graffiti384b.OddStars.LeafCharacterization
open Finset SimpleGraph ComponentQuota ComponentCenters ComponentPort SingleLeaf
open private TrianglePrune.triangle_iff from TrianglePrune384b
universe u

/-- The original connected catalogue problem through order N. -/
def CatalogueThrough (N : ℕ) : Prop :=
  ∀(V : Type u) [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj],
    G.Connected → 2<Fintype.card V → Fintype.card V≤N → gamma G≤bound G

/-- Only single-leaf attachments to connected all-positive triangle-supported
cores. The order budget includes the new leaf. -/
def LeavesThrough (N : ℕ) : Prop :=
  ∀(V : Type u) [Fintype V] [DecidableEq V] (K : SimpleGraph V) [DecidableRel K.Adj],
    K.Connected → (∀v,0<trianglesAt K v) → (∀{i j},K.Adj i j → ∃k,K.Adj i k ∧ K.Adj j k) →
    ∀r : V,Fintype.card V+1≤N → gamma (withLeaf K r)≤bound (withLeaf K r)

/-- The one-leaf supported-core reduction is exact at every order cutoff. -/
theorem catalogue_iff_single_leaf (N : ℕ) : CatalogueThrough.{u} N ↔ LeavesThrough.{u} N := by
  constructor
  · intro all V _ _ K _ conn pos _ r limit
    obtain ⟨a,b,ra,rb,ab⟩ := (TrianglePrune.triangle_iff K r).mp (pos r)
    have two := PositivePalette.Prerequisites.deg2 K ab.ne ra rb
    have small := K.degree_lt_card_verts r
    exact all _ (withLeaf K r) (leaf_connected K conn r)
      (by rw [Fintype.card_sum,Fintype.card_unit]; omega) (by simpa using limit)
  · intro restricted V _ _ G _ conn order upper
    apply Nat.le_of_not_gt
    intro bad
    have somePos : ∃x,0<trianglesAt G x := by
      by_contra! no
      have inc : types G⊆{0} := by
        intro k km
        obtain ⟨x,_,rfl⟩ := mem_image.mp km
        exact mem_singleton.mpr (Nat.eq_zero_of_le_zero (no x))
      have small := card_le_card inc
      rw [card_singleton] at small
      exact (not_lt_of_ge (exact_of_at_most_four G conn order (by omega))) bad
    obtain ⟨x,px⟩ := somePos
    obtain ⟨hc,p,s,r,_,_,le,_,_,failed⟩ := canonical_at G conn bad px
    have sz : Fintype.card ((component G x):Set V)=(component G x).card := Fintype.card_coe _
    have win := restricted _ (block G (component G x)) hc p s r (by rw [sz]; omega)
    exact (not_lt_of_ge win) failed

/-- If two vertices outside the chosen component are available, that
component gives a strictly smaller connected counterexample. -/
theorem strict_reduction {V : Type u} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (conn : G.Connected) (bad : bound G<gamma G) {x : V} (px : 0<trianglesAt G x)
    (other : 2≤(component G x)ᶜ.card) :
    ∃r : component G x,let E := withLeaf (block G (component G x)) r
      E.Connected ∧ 2<(component G x).card+1 ∧ (component G x).card+1<Fintype.card V ∧ bound E<gamma E := by
  obtain ⟨_,_,_,r,hc,lower,_,_,_,fail⟩ := canonical_at G conn bad px
  have size := card_compl (component G x)
  have cap := card_le_univ (component G x)
  exact ⟨r,hc,lower,by omega,fail⟩

end Graffiti384b.OddStars.LeafCharacterization
#print axioms Graffiti384b.OddStars.LeafCharacterization.catalogue_iff_single_leaf
#print axioms Graffiti384b.OddStars.LeafCharacterization.strict_reduction
