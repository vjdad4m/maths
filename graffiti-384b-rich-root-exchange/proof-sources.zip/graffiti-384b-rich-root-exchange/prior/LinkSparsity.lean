import ReservedWheel
namespace Graffiti384b.OddStars.LinkSparsity
open Finset SimpleGraph PositivePalette ReservedWheel ShorePairs
open private Graffiti384b.cut Graffiti384b.cut_symm Graffiti384b.cut_insert from Proof384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- No nonempty bipartite subgraph of minimum degree two is supported in S. -/
def Free (S : Finset V) : Prop := ∀P Q : Finset V,P⊆S → Q⊆S → Frame G P Q → P.Nonempty → False

omit [Fintype V] [DecidableEq V] in
private theorem free_sub {S R : Finset V} (h : Free G S) (sub : R⊆S) : Free G R :=
  fun _ _ p q => h _ _ (p.trans sub) (q.trans sub)

private theorem low_degree {S : Finset V} (free : Free G S) (pos : S.Nonempty) :
    ∃v∈S,nbr G v S≤2 := by
  classical
  by_contra! highD
  let J := inside G S
  have n (v : V) (vm : v∈S) (A : Finset V) : nbr J v A=nbr G v (S∩A) := by
    unfold nbr
    congr 1; ext w; simp [J,inside,vm]; tauto
  have hi {v : V} (vm : v∈S) : v∈high J := by
    have deg : J.neighborFinset v=S.filter (G.Adj v) := by ext; simp [J,inside,vm,and_comm]
    have eq := congrArg card deg
    rw [card_neighborFinset_eq_degree] at eq
    exact mem_filter.mpr ⟨mem_univ _,eq ▸ highD v vm⟩
  obtain ⟨A,l,r⟩ := covers_high J
  let P := S∩A
  let Q := S∩Aᶜ
  have lp (v : V) (vm : v∈P) : 2≤nbr G v Q :=
    (n v (mem_inter.mp vm).1 Aᶜ) ▸ l v (hi (mem_inter.mp vm).1) (mem_inter.mp vm).2
  have rq (v : V) (vm : v∈Q) : 2≤nbr G v P :=
    (n v (mem_inter.mp vm).1 A) ▸ r v (hi (mem_inter.mp vm).1) (mem_inter.mp vm).2
  have frame : Frame G P Q := ⟨disjoint_left.mpr (fun _ pm qm => mem_compl.mp (mem_inter.mp qm).2 (mem_inter.mp pm).2),lp,rq⟩
  obtain ⟨v,vm⟩ := pos
  apply free P Q inter_subset_left inter_subset_left frame
  by_cases va : v∈A
  · exact ⟨v,mem_inter.mpr ⟨vm,va⟩⟩
  · have val := (rq v (mem_inter.mpr ⟨vm,mem_compl.mpr va⟩)).trans (card_filter_le ..)
    exact card_pos.mp (by omega)

private theorem three_color {S : Finset V} (free : Free G S) :
    ∃c : V → Fin 3,∀i∈S,∀j∈S,G.Adj i j → c i≠c j := by
  classical
  induction S using Finset.strongInduction with
  | H S ih =>
    by_cases empty : S=∅
    · exact ⟨fun _ => 0,by simp [empty]⟩
    obtain ⟨v,vm,dv⟩ := low_degree G free (nonempty_iff_ne_empty.mpr empty)
    obtain ⟨f,hf⟩ := ih _ (erase_ssubset vm) (free_sub G free (erase_subset ..))
    let N := S.filter (G.Adj v)
    have cnt := card_image_le (s:=N) (f:=f)
    change N.card≤2 at dv
    obtain ⟨a,_,notUsed⟩ := exists_mem_not_mem_of_card_lt_card (s:=N.image f) (t:=univ) (by
      rw [card_univ,Fintype.card_fin]; omega)
    let c := Function.update f v a
    have apart (i : V) (im : i∈S) (vi : G.Adj v i) : a≠f i :=
      fun eq => notUsed (mem_image.mpr ⟨i,mem_filter.mpr ⟨im,vi⟩,eq.symm⟩)
    refine ⟨c,?_⟩
    intro i im j jm ij
    by_cases iv : i=v
    · subst i; simpa [c,Function.update_of_ne ij.ne.symm] using apart j jm ij
    by_cases jv : j=v
    · subst j; simpa [c,Function.update_of_ne iv] using (apart i im ij.symm).symm
    simpa [c,Function.update_of_ne iv,Function.update_of_ne jv] using
      hf i (mem_erase.mpr ⟨iv,im⟩) j (mem_erase.mpr ⟨jv,jm⟩) ij

omit [Fintype V] in
private theorem sparse_cut (P Q S : Finset V) (free : Free G S) (p : P⊆S) (q : Q⊆S)
    (dis : Disjoint P Q) (pos : (P∪Q).Nonempty) : Graffiti384b.cut G P Q+1≤P.card+Q.card := by
  classical
  by_cases pe : P=∅
  · subst P; have n := card_pos.mpr pos; simpa [Graffiti384b.cut] using n
  by_cases qe : Q=∅
  · subst Q; have n := card_pos.mpr pos; simpa [Graffiti384b.cut] using n
  have pn := nonempty_iff_ne_empty.mpr pe
  have qn := nonempty_iff_ne_empty.mpr qe
  by_cases low : ∃v∈P,nbr G v Q≤1
  · obtain ⟨v,vm,d⟩ := low
    have sub : Disjoint (P.erase v) Q := dis.mono_left (erase_subset ..)
    have h := sparse_cut (P.erase v) Q S free ((erase_subset ..).trans p) q sub
      (qn.mono subset_union_right)
    have e := Graffiti384b.cut_insert G (not_mem_erase v P) Q
    rw [insert_erase vm] at e
    have k := card_erase_add_one vm
    omega
  · push_neg at low
    have next : ∃v∈Q,nbr G v P≤1 := by
      by_contra! no
      exact free P Q p q ⟨dis,low,no⟩ pn
    obtain ⟨v,vm,d⟩ := next
    have sub : Disjoint P (Q.erase v) := dis.mono_right (erase_subset ..)
    have h := sparse_cut P (Q.erase v) S free p ((erase_subset ..).trans q) sub
      (pn.mono subset_union_left)
    have e := Graffiti384b.cut_insert G (not_mem_erase v Q) P
    rw [insert_erase vm,Graffiti384b.cut_symm G Q P,Graffiti384b.cut_symm G (Q.erase v) P] at e
    have k := card_erase_add_one vm
    omega
termination_by P.card+Q.card
decreasing_by all_goals have := card_erase_lt_of_mem vm; omega

/-- A frame-free link with d positive vertices has at most floor(3(d-1)/2)
edges. The proof three-colors the link and counts each edge in two sparse
bipartite cuts. -/
theorem edge_bound {S : Finset V} (free : Free G S) (pos : S.Nonempty) :
    2*(pairs G S).card+3≤3*S.card := by
  classical
  obtain ⟨c,proper⟩ := three_color G free
  let A (k : Fin 3) := S.filter (fun v => c v=k)
  have single (k : Fin 3) : (∑v∈A k,nbr G v S)+1≤S.card := by
    let P := A k
    have sub : P⊆S := filter_subset .. 
    have d : Disjoint P (S\P) := disjoint_left.mpr (fun _ pm qm => (mem_sdiff.mp qm).2 pm)
    have cut := sparse_cut G P (S\P) S free sub sdiff_subset d (by rwa [union_sdiff_of_subset sub])
    have eval : Graffiti384b.cut G P (S\P)=∑v∈P,nbr G v S := by
      unfold Graffiti384b.cut
      apply sum_congr rfl
      intro v vm
      have eq : (S\P).filter (G.Adj v)=S.filter (G.Adj v) := by
        ext w
        simp only [mem_filter,mem_sdiff]
        constructor
        · exact fun ⟨⟨ws,_⟩,ed⟩ => ⟨ws,ed⟩
        · intro ⟨ws,ed⟩
          refine ⟨⟨ws,fun wm => ?_⟩,ed⟩
          exact proper v (sub vm) w ws ed ((mem_filter.mp vm).2.trans (mem_filter.mp wm).2.symm)
      simpa [nbr] using congrArg card eq
    rw [eval,card_sdiff sub] at cut
    have cap := card_le_card sub
    change (∑v∈P,nbr G v S)+1≤S.card
    omega
  have partition : (∑k : Fin 3,∑v∈A k,nbr G v S)=∑v∈S,nbr G v S := by
    simp only [A,sum_filter]
    rw [sum_comm]
    simp
  have sum := sum_le_sum (s:=(univ : Finset (Fin 3))) (fun k _ => single k)
  rw [sum_add_distrib,partition,degree_sum] at sum
  simpa [Nat.mul_comm] using sum

end Graffiti384b.OddStars.LinkSparsity
#print axioms Graffiti384b.OddStars.LinkSparsity.edge_bound
