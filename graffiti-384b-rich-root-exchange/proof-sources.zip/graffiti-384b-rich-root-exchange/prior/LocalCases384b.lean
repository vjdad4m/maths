import ComponentTypes384b
import FiniteRange384b

namespace Graffiti384b.LocalCases
open Finset SimpleGraph ComponentTypes
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- An isolated component of order four or five improves on rounded half
exactly when one retained center can serve the entire component. -/
theorem four_five (r k : Finset V) (rk : Disjoint r k) (size : r.card = 4 ∨ r.card = 5) :
    (r.card+1)/2 < Capacity.value G r k ↔
      ∃ c ∈ r, ∀ v ∈ r, v ≠ c → 2 ≤ nbr G v k ∨ (1 ≤ nbr G v k ∧ G.Adj v c) := by
  have H := centers_iff G r k rk 1 (by omega)
  have arith : (r.card+1)/2 + 1 = r.card - 1 := by omega
  change (r.card+1)/2 + 1 ≤ _ ↔ _
  rw [arith,H]
  constructor
  · rintro ⟨p,hp,ok⟩
    obtain ⟨pr,sz⟩ := mem_powersetCard.mp hp
    obtain ⟨c,rfl⟩ := card_eq_one.mp sz
    refine ⟨c,pr (mem_singleton_self _),?_⟩
    intro v hv ne
    have h := ok v (mem_sdiff.mpr ⟨hv,by simpa using ne⟩)
    by_cases adj : G.Adj v c
    · have one : nbr G v {c} = 1 := by simp [nbr,filter_singleton,adj]
      right
      exact ⟨by omega,adj⟩
    · have zero : nbr G v {c} = 0 := by simp [nbr,filter_singleton,adj]
      exact Or.inl (by omega)
  · rintro ⟨c,cr,h⟩
    refine ⟨{c},mem_powersetCard.mpr ⟨singleton_subset_iff.mpr cr,card_singleton _⟩,?_⟩
    intro v hv
    obtain ⟨vr,vc⟩ := mem_sdiff.mp hv
    obtain hi | ⟨lo,adj⟩ := h v vr (by simpa using vc)
    · omega
    · simp only [nbr,filter_singleton,if_pos adj,card_singleton]
      change 1 ≤ ((k.filter (G.Adj v)).card) at lo
      omega

/-- In a counterexample every center set of the critical cardinality on
a separated medium-degree block has a vertex it fails to cover. -/
theorem medium_obstruction (hc : G.Connected) (hn : 2 < Fintype.card V) (failure : bound G < gamma G)
    (r s : Finset V) (parts : r ∪ s = high G) (rs : Disjoint r s)
    (sep : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w) (medium : ∀ v ∈ r, G.degree v ≤ 5)
    (lo : 2 ≤ r.card) :
    let b := r.card-((r.card+1)/2+1)
    r.card ≤ 10 ∧ (r.powersetCard b).card ≤ 210 ∧
      ∀ c ∈ r.powersetCard b, ∃ v ∈ r \ c, nbr G v c < 2 - nbr G v (high G)ᶜ := by
  dsimp only
  have sub : r ⊆ high G := parts ▸ subset_union_left
  have hi : r.card ≤ 10 := (card_le_card (show r ⊆ (high G).filter (fun v => G.degree v ≤ 5) from
    fun v hv => mem_filter.mpr ⟨sub hv,medium v hv⟩)).trans (Repair.necessary_profile G hc hn failure).2.1
  obtain ⟨test,num⟩ := small_block_test G (disjoint_compl_right.mono_left sub) lo hi
  refine ⟨hi,num,?_⟩
  intro c mem
  by_contra! allOK
  have more := test.mpr ⟨c,mem,allOK⟩
  rw [(rigidity G failure r s parts rs sep).1] at more
  omega

/-- Supported paths and cycles of these sizes cannot be separated high
blocks of a counterexample. Extra edges in the block are permitted. -/
theorem exact_of_supported_path (r s : Finset V) (parts : r ∪ s = high G) (rs : Disjoint r s)
    (sep : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w) (m : ℕ) (f : ℕ → V)
    (list : (range m).image f = r) (order : r.card = m)
    (path : ∀ i, i+1 < m → G.Adj (f i) (f (i+1)))
    (support : ∀ v ∈ r, 1 ≤ nbr G v (high G)ᶜ)
    (large : (6 ≤ m ∧ m % 2 = 0) ∨ 9 ≤ m) : gamma G ≤ bound G := by
  by_contra! failure
  have sub : r ⊆ high G := parts ▸ subset_union_left
  have h := supported_path G r (high G)ᶜ (disjoint_compl_right.mono_left sub) m f list order path support
  rw [(rigidity G failure r s parts rs sep).1,order] at h
  omega

/-- Exact capacity in the eleven-vertex graph that limits the anchor test. -/
theorem eleven_capacity :
    Capacity.value AllPairsExample.graph {1,3,5,9} {0,6,7,10} = 3 := by decide

theorem eleven_repair : gamma AllPairsExample.graph ≤ 5 := by
  have h := Capacity.seeded_value AllPairsExample.graph {2,4,8} {1,3,5,9} {0,6,7,10}
    (by decide) (by decide) (by decide) (by decide)
  rw [eleven_capacity] at h
  exact h

end Graffiti384b.LocalCases

#print axioms Graffiti384b.LocalCases.four_five
#print axioms Graffiti384b.LocalCases.medium_obstruction
#print axioms Graffiti384b.LocalCases.exact_of_supported_path
#print axioms Graffiti384b.LocalCases.eleven_repair
namespace Graffiti384b.LocalCases
open Finset SimpleGraph ComponentTypes
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A high triangle has all three vertices in the degree-at-least-three
set. The predicate below only requires the other two vertices to be high. -/
def highPair (v : V) : Prop :=
  ∃ a ∈ high G, ∃ b ∈ high G, G.Adj v a ∧ G.Adj v b ∧ G.Adj a b

/-- Without a high pair and with at most one low neighbor, all incident
triangles use that same neighbor. It has room for only one further edge. -/
theorem at_most_one_triangle (v : V) (free : ¬highPair G v)
    (weak : nbr G v (high G)ᶜ ≤ 1) : trianglesAt G v ≤ 1 := by
  let links := ((G.neighborFinset v).powersetCard 2).filter
    (fun p => ∀ x ∈ p, ∀ y ∈ p, x ≠ y → G.Adj x y)
  let low := (high G)ᶜ.filter (G.Adj v)
  change low.card ≤ 1 at weak
  have pair (p : Finset V) (hp : p ∈ links) :
      ∃ w ∈ low, ∃ a ∈ (G.neighborFinset w).erase v, p = {w,a} := by
    obtain ⟨inN,k⟩ := mem_powersetCard.mp (mem_filter.mp hp).1
    obtain ⟨a,b,ne,e⟩ := card_eq_two.mp k
    have av : a ∈ p := e ▸ mem_insert_self _ _
    have bv : b ∈ p := e ▸ mem_insert_of_mem (mem_singleton_self _)
    have va := (G.mem_neighborFinset _ _).mp (inN av)
    have vb := (G.mem_neighborFinset _ _).mp (inN bv)
    have ab := (mem_filter.mp hp).2 a av b bv ne
    by_cases ah : a ∈ high G
    · have bh : b ∉ high G := fun bh => free ⟨a,ah,b,bh,va,vb,ab⟩
      exact ⟨b,mem_filter.mpr ⟨mem_compl.mpr bh,vb⟩,a,
        mem_erase.mpr ⟨va.ne.symm,(G.mem_neighborFinset _ _).mpr ab.symm⟩,e.trans (pair_comm _ _)⟩
    · exact ⟨a,mem_filter.mpr ⟨mem_compl.mpr ah,va⟩,b,
        mem_erase.mpr ⟨vb.ne.symm,(G.mem_neighborFinset _ _).mpr ab⟩,e⟩
  change links.card ≤ 1
  apply card_le_one.mpr
  intro p hp q hq
  obtain ⟨w,wlow,a,ha,ep⟩ := pair p hp
  obtain ⟨u,ulow,b,hb,eq⟩ := pair q hq
  have uw : u = w := card_le_one.mp weak _ ulow _ wlow
  subst u
  have wh : w ∉ high G := mem_compl.mp (mem_filter.mp wlow).1
  have small : G.degree w ≤ 2 := Nat.le_of_lt_succ (by simpa [high] using wh)
  have vw : v ∈ G.neighborFinset w := (G.mem_neighborFinset _ _).mpr (mem_filter.mp wlow).2.symm
  have card : ((G.neighborFinset w).erase v).card ≤ 1 := by
    rw [card_erase_of_mem vw,card_neighborFinset_eq_degree]
    omega
  obtain rfl : a = b := card_le_one.mp card _ ha _ hb
  exact ep.trans eq.symm

private theorem few_low_scores (bad : Finset V) (bh : bad ⊆ high G)
    (scores : ∀ v ∈ bad, trianglesAt G v ≤ 1) :
    (types G).card + bad.card ≤ (high G).card+2 := by
  have sub : types G ⊆ ((high G) \ bad).image (trianglesAt G) ∪ range 2 := by
    intro j hj
    obtain ⟨v,_,rfl⟩ := mem_image.mp hj
    by_cases h : v ∈ high G
    · by_cases b : v ∈ bad
      · exact mem_union_right _ (mem_range.mpr (by have := scores v b; omega))
      · exact mem_union_left _ (mem_image.mpr ⟨v,mem_sdiff.mpr ⟨h,b⟩,rfl⟩)
    · have small : G.degree v ≤ 2 := Nat.le_of_lt_succ (by simpa [high] using h)
      have many := card_filter_le ((G.neighborFinset v).powersetCard 2)
        (fun p => ∀ x ∈ p, ∀ y ∈ p, x ≠ y → G.Adj x y)
      rw [card_powersetCard,card_neighborFinset_eq_degree] at many
      change trianglesAt G v ≤ _ at many
      have bound := many.trans (Nat.choose_le_choose 2 small)
      rw [Nat.choose_self] at bound
      exact mem_union_right _ (mem_range.mpr (by omega))
  have inequality := (card_le_card sub).trans (card_union_le _ _)
  rw [card_range] at inequality
  have sz := card_sdiff_add_card_eq_card bh
  have h := card_image_le (s := high G \ bad) (f := trianglesAt G)
  omega

/-- Every separated block of the high subgraph containing at least two
vertices must contain a triangle in any counterexample. -/
theorem exact_of_triangle_free_block (r s : Finset V) (parts : r ∪ s = high G)
    (rs : Disjoint r s) (sep : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w)
    (nontrivial : 2 ≤ r.card)
    (free : ∀ v ∈ r, ∀ a ∈ r, ∀ b ∈ r, G.Adj v a → G.Adj v b → ¬G.Adj a b) :
    gamma G ≤ bound G := by
  by_contra! failure
  let bad := r.filter (fun v => nbr G v (high G)ᶜ ≤ 1)
  have rh : r ⊆ high G := parts ▸ subset_union_left
  have internal {v a : V} (vr : v ∈ r) (ah : a ∈ high G) (va : G.Adj v a) : a ∈ r := by
    obtain ar | as := mem_union.mp (parts.symm ▸ ah)
    · exact ar
    · exact False.elim (sep v vr a as va)
  have badScore (v : V) (h : v ∈ bad) : trianglesAt G v ≤ 1 := by
    obtain ⟨vr,weak⟩ := mem_filter.mp h
    apply at_most_one_triangle G v _ weak
    rintro ⟨a,ah,b,bh,va,vb,ab⟩
    exact free v vr a (internal vr ah va) b (internal vr bh vb) va vb ab
  have scores := few_low_scores G bad ((filter_subset _ _).trans rh) badScore
  have can : Capacity.Feasible G r (high G)ᶜ (r \ bad) := by
    refine ⟨sdiff_subset,?_⟩
    intro v hv
    have enough : 2 ≤ nbr G v (high G)ᶜ := by
      obtain ⟨vr,h⟩ := mem_sdiff.mp hv
      exact Nat.lt_of_not_ge (fun low => h (mem_filter.mpr ⟨vr,low⟩))
    exact enough.trans (card_le_card (filter_subset_filter _ subset_union_left))
  have value := Capacity.le_value G can
  rw [card_sdiff (filter_subset _ _),(rigidity G failure r s parts rs sep).1] at value
  change r.card-bad.card ≤ (r.card+1)/2 at value
  have odd := (rigidity G failure r s parts rs sep).2.2
  have sz := card_union_of_disjoint rs
  rw [parts] at sz
  have cut := high_bound G
  unfold bound at failure
  have two : r.card = 2 := by omega
  have empty : bad = ∅ := by
    apply eq_empty_of_forall_not_mem
    intro v hv
    obtain ⟨vr,weak⟩ := mem_filter.mp hv
    have highdeg := (mem_filter.mp (rh vr)).2
    have sub : (high G).filter (G.Adj v) ⊆ r.erase v := by
      intro a ha
      obtain ⟨ah,va⟩ := mem_filter.mp ha
      exact mem_erase.mpr ⟨va.ne.symm,internal vr ah va⟩
    have bound := card_le_card sub
    rw [card_erase_of_mem vr,two] at bound
    have split := card_union_of_disjoint
      (disjoint_compl_right.mono (filter_subset (G.Adj v) (high G)) (filter_subset (G.Adj v) (high G)ᶜ))
    rw [← filter_union,union_compl] at split
    have full : (univ.filter (G.Adj v)).card = G.degree v := by
      rw [← card_neighborFinset_eq_degree]
      congr 1
      ext z
      simp
    rw [full] at split
    change ((high G)ᶜ.filter (G.Adj v)).card ≤ 1 at weak
    omega
  rw [empty,card_empty,two] at value
  omega

end Graffiti384b.LocalCases

#print axioms Graffiti384b.LocalCases.at_most_one_triangle
#print axioms Graffiti384b.LocalCases.exact_of_triangle_free_block
namespace Graffiti384b.LocalCases
open Finset SimpleGraph ComponentTypes
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- If U contains all vertices on high triangles in a separated block R,
its cardinality obeys a sharper diversity-dependent lower bound. -/
theorem triangle_coverage (failure : bound G < gamma G)
    (r s u : Finset V) (parts : r ∪ s = high G)
    (rs : Disjoint r s) (sep : ∀ v ∈ r, ∀ w ∈ s, ¬G.Adj v w)
    (cover : ∀ v ∈ r, highPair G v → v ∈ u) :
    (types G).card + r.card / 2 ≤ (high G).card + 2 + u.card := by
  let weak := r.filter (fun v => nbr G v (high G)ᶜ ≤ 1)
  let bad := weak \ u
  have rh : r ⊆ high G := parts ▸ subset_union_left
  have wr : weak ⊆ r := filter_subset _ _
  have bh : bad ⊆ high G := sdiff_subset.trans (wr.trans rh)
  have scores := few_low_scores G bad bh (by
    intro v hv
    obtain ⟨vw,vu⟩ := mem_sdiff.mp hv
    obtain ⟨vr,lo⟩ := mem_filter.mp vw
    exact at_most_one_triangle G v (fun p => vu (cover v vr p)) lo)
  have good : Capacity.Feasible G r (high G)ᶜ (r \ weak) := by
    refine ⟨sdiff_subset,?_⟩
    intro v hv
    obtain ⟨vr,vw⟩ := mem_sdiff.mp hv
    have enough : 2 ≤ nbr G v (high G)ᶜ := Nat.lt_of_not_ge
      (fun low => vw (mem_filter.mpr ⟨vr,low⟩))
    exact enough.trans (card_le_card (filter_subset_filter _ subset_union_left))
  have cap := Capacity.le_value G good
  rw [card_sdiff wr,(rigidity G failure r s parts rs sep).1] at cap
  have eq : bad.card + (weak ∩ u).card = weak.card := card_sdiff_add_card_inter weak u
  have small := card_le_card (inter_subset_right (s₁ := weak) (s₂ := u))
  omega

/-- A failure in any finite connected simple graph forces one in the finite
range with the same types, in which every nontrivial separated high block
contains a high triangle. All structural conditions concern that same graph. -/
theorem residual_witness (hc : G.Connected) (hn : 2 < Fintype.card V)
    (failure : bound G < gamma G) :
    ∃ a : Finset V, let J := G.induce (a : Set V)
      2 < a.card ∧ a.card ≤ 45 ∧ J.Connected ∧ types J = types G ∧
      7 ≤ (types J).card ∧ (types J).card ≤ 43 ∧ (types J).card ≠ 40 ∧ (types J).card ≠ 42 ∧
      bound J < gamma J ∧
      ((high J).filter (fun v => J.degree v ≤ 5)).card ≤ 10 ∧
      ((high J).filter (fun v => J.degree v ≤ 3)).card ≤ 3 ∧
      (∀ r s : Finset a, r ∪ s = high J → Disjoint r s →
        (∀ v ∈ r, ∀ w ∈ s, ¬J.Adj v w) → 2 ≤ r.card →
        ∃ v ∈ r, ∃ x ∈ r, ∃ y ∈ r, J.Adj v x ∧ J.Adj v y ∧ J.Adj x y) := by
  obtain ⟨a,ord,cap,conn,same,lo,hi,x40,x42,fail⟩ := FiniteRange.bounded_induced_failure G hc hn failure
  let J := G.induce (a : Set V)
  have size : 2 < Fintype.card a := by simpa using ord
  have profile := Repair.necessary_profile J conn size fail
  refine ⟨a,ord,cap,conn,same,same ▸ lo,same ▸ hi,same ▸ x40,same ▸ x42,fail,
    profile.2.1,profile.2.2.1,?_⟩
  intro r s parts rs sep nontrivial
  by_contra! no
  exact (not_le_of_gt fail) (exact_of_triangle_free_block J r s parts rs sep nontrivial
    (fun v vr x xr y yr vx vy xy => no v vr x xr y yr vx vy xy))

end Graffiti384b.LocalCases

#print axioms Graffiti384b.LocalCases.triangle_coverage
#print axioms Graffiti384b.LocalCases.residual_witness
