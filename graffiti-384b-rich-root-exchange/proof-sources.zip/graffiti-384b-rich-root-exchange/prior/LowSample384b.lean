import LocalCases384b

namespace Graffiti384b.LowSample
open Finset SimpleGraph
open private FiniteRange.bad FiniteRange.count_bad FiniteRange.gap from FiniteRange384b
open private Repair.omit_set Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
/-- An integer-weighted independent set. A maximum-weight pivot removes
only its neighbors, whose weights are bounded by its own. -/
private theorem greedy (r : Finset V) (w : V → ℕ)
    (cap : ∀ v ∈ r, (nbr G v r+1)*w v ≤ 6) :
    ∃ o ⊆ r, (∀ v ∈ o, ∀ y ∈ o, ¬G.Adj v y) ∧ ∑ v ∈ r, w v ≤ 6*o.card := by
  classical
  induction r using Finset.strongInduction with
  | H r ih =>
    by_cases ne : r.Nonempty
    · obtain ⟨v,vr,best⟩ := exists_max_image r w ne
      let p := insert v (r.filter (G.Adj v))
      have sub : p ⊆ r := insert_subset vr (filter_subset _ _)
      have vp : v ∈ p := mem_insert_self _ _
      have small : r \ p ⊂ r := Finset.ssubset_iff_subset_ne.mpr ⟨sdiff_subset,fun eq =>
        (mem_sdiff.mp (eq.symm ▸ vr : v ∈ r \ p)).2 vp⟩
      obtain ⟨o,os,ind,wt⟩ := ih _ small (fun x hx =>
        (Nat.mul_le_mul_right _ (Nat.succ_le_succ (card_le_card (filter_subset_filter _ sdiff_subset)))).trans
          (cap x (mem_sdiff.mp hx).1))
      have nv : v ∉ o := fun hv => (mem_sdiff.mp (os hv)).2 vp
      have no (y : V) (hy : y ∈ o) : ¬G.Adj v y := fun h =>
        (mem_sdiff.mp (os hy)).2 (mem_insert_of_mem (mem_filter.mpr ⟨(mem_sdiff.mp (os hy)).1,h⟩))
      refine ⟨insert v o,insert_subset vr (os.trans sdiff_subset),?_,?_⟩
      · intro a ha b hb ab
        rcases mem_insert.mp ha with ea | oa
        · subst a
          rcases mem_insert.mp hb with eb | ob
          · exact ab.ne eb.symm
          · exact no _ ob ab
        · rcases mem_insert.mp hb with eb | ob
          · subst b
            exact no _ oa ab.symm
          · exact ind _ oa _ ob ab
      · have pc : p.card = nbr G v r+1 := by
          rw [show p = insert v (r.filter (G.Adj v)) from rfl,card_insert_of_not_mem (by simp)]
          rfl
        have pw : ∑ y ∈ p, w y ≤ p.card*w v := (sum_le_sum (fun y hy => best y (sub hy))).trans_eq (by simp)
        have sum := sum_sdiff (f := w) sub
        rw [pc] at pw
        rw [card_insert_of_not_mem nv]
        have := cap v vr
        omega
    · rw [not_nonempty_iff_eq_empty.mp ne]
      exact ⟨∅,Subset.rfl,by simp,by simp⟩

def twos := (nonleaves G) \ high G

private def anchors (v : V) := (high G).filter (G.Adj v)
private def weight (d : ℕ) := if d=2 then 6 else if d=1 then 3 else 2
private def eligible (k : Finset V) := (twos G).filter (fun v => anchors G v ⊆ k)

private theorem two_degree {v : V} (mem : v ∈ twos G) : G.degree v = 2 := by
  obtain ⟨q,h⟩ := mem_sdiff.mp mem
  have lo := (mem_filter.mp q).2
  have hi : ¬3 ≤ G.degree v := fun d => h (mem_filter.mpr ⟨mem_univ _,d⟩)
  omega

private theorem trial (k : Finset V) (kh : k ⊆ high G) (failure : bound G < gamma G) :
    6*((high G).card-k.card) + (∑ v ∈ eligible G k, weight (anchors G v).card) ≤
      6*((((types G).card+1)/2-1) + (FiniteRange.bad G (high G) k).card) := by
  let h := high G
  let e := eligible G k
  let a := (h \ k) \ FiniteRange.bad G h k
  have low : e ⊆ hᶜ := fun v hv => mem_compl.mpr (mem_sdiff.mp (mem_filter.mp hv).1).2
  obtain ⟨o,oe,ind,mass⟩ := greedy G e (fun v => weight (anchors G v).card) (by
    intro v hv
    have deg := two_degree G (mem_filter.mp hv).1
    have count := Repair.full_nbr G v h
    have mono : nbr G v e ≤ nbr G v hᶜ := card_le_card (filter_subset_filter _ low)
    change nbr G v h + nbr G v hᶜ = _ at count
    change (nbr G v e+1) * weight (nbr G v h) ≤ 6
    unfold weight
    split_ifs <;> omega)
  have dis : Disjoint a o := disjoint_left.mpr (fun v va vo => mem_compl.mp (low (oe vo)) (mem_sdiff.mp (mem_sdiff.mp va).1).1)
  have safe : ∀ v ∈ a ∪ o, 2 ≤ nbr G v (a ∪ o)ᶜ := by
    intro v hv
    rcases mem_union.mp hv with va | vo
    · obtain ⟨vk,good⟩ := mem_sdiff.mp va
      have base : 2 ≤ nbr G v (hᶜ ∪ k) := Nat.le_of_not_gt (fun lt => good (mem_filter.mpr ⟨vk,lt⟩))
      apply base.trans (card_le_card ?_)
      intro y hy
      obtain ⟨yk,adj⟩ := mem_filter.mp hy
      refine mem_filter.mpr ⟨mem_compl.mpr ?_,adj⟩
      intro yin
      rcases mem_union.mp yin with ya | yo
      · obtain ⟨yh,yn⟩ := mem_sdiff.mp (mem_sdiff.mp ya).1
        exact (mem_union.mp yk).elim (fun l => mem_compl.mp l yh) yn
      · have aps := (mem_filter.mp (oe yo)).2
        exact (mem_sdiff.mp vk).2 (aps (mem_filter.mpr ⟨(mem_sdiff.mp vk).1,adj.symm⟩))
    · have deg := two_degree G (mem_filter.mp (oe vo)).1
      have sub : G.neighborFinset v ⊆ (a ∪ o)ᶜ.filter (G.Adj v) := by
        intro y hy
        have adj := (G.mem_neighborFinset _ _).mp hy
        apply mem_filter.mpr ⟨mem_compl.mpr ?_,adj⟩
        intro yin
        rcases mem_union.mp yin with ya | yo
        · have hyk := mem_sdiff.mp (mem_sdiff.mp ya).1
          exact hyk.2 ((mem_filter.mp (oe vo)).2 (mem_filter.mpr ⟨hyk.1,adj⟩))
        · exact ind v vo y yo adj
      simpa only [card_neighborFinset_eq_degree,deg,nbr] using card_le_card sub
  have up := Repair.omit_set G _ safe
  rw [card_union_of_disjoint dis] at up
  have partition : a.card + (FiniteRange.bad G h k).card = h.card-k.card := by
    rw [← card_sdiff kh]
    exact card_sdiff_add_card_eq_card (filter_subset _ _)
  unfold bound at failure
  change 6*(h.card-k.card) + _ ≤ 6*(_ + (FiniteRange.bad G h k).card)
  change (∑ v ∈ eligible G k, weight (anchors G v).card) ≤ 6*o.card at mass
  omega

end Graffiti384b.LowSample
namespace Graffiti384b.LowSample
open Finset SimpleGraph
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
/-- Mandatory anchors can be completed freely outside the anchor set. -/
private theorem anchor_samples (s p : Finset V) (b : ℕ) (ps : p ⊆ s) (pb : p.card ≤ b) :
    (s.card-p.card).choose (b-p.card) ≤
    ((s.powersetCard b).filter (fun k => p ⊆ k)).card := by
  let pool := (s \ p).powersetCard (b-p.card)
  let add := fun x : Finset V => p ∪ x
  have sub : pool.image add ⊆ (s.powersetCard b).filter (fun k => p ⊆ k) := by
    intro k hk
    obtain ⟨x,hx,rfl⟩ := mem_image.mp hk
    obtain ⟨xd,xc⟩ := mem_powersetCard.mp hx
    have sep : Disjoint p x := disjoint_left.mpr (fun y yp yx => (mem_sdiff.mp (xd yx)).2 yp)
    exact mem_filter.mpr ⟨mem_powersetCard.mpr ⟨union_subset ps (xd.trans sdiff_subset),by
      dsimp [add]; rw [card_union_of_disjoint sep,xc]; omega⟩,subset_union_left⟩
  have undo (x : Finset V) (hx : x ∈ pool) : add x \ p = x := by
    ext y
    have no (hy : y ∈ x) : y ∉ p := (mem_sdiff.mp ((mem_powersetCard.mp hx).1 hy)).2
    simp only [add,mem_sdiff,mem_union]
    tauto
  have c := card_le_card sub
  rw [card_image_of_injOn (by
    intro x hx y hy h; exact (undo x hx).symm.trans ((congrArg (fun a => a \ p) h).trans (undo y hy)))] at c
  simpa [pool,card_sdiff ps] using c

private def delta (m b j : ℕ) := if 3 ≤ j then
  FiniteRange.badCount m b j - FiniteRange.badCount m b (j+1) else 0

def highCharge (t m b : ℕ) := m * FiniteRange.badCount m b 11 + ∑ j ∈ range 11,
  delta m b j * min m (m + j.choose 2 + 1 - t)

private theorem high_bad (b : ℕ) (large : 12 ≤ (high G).card)
    (envelope : ∀ d : Fin 12, 3 ≤ d.val → FiniteRange.badCount (high G).card b d.val ≤
      FiniteRange.badCount (high G).card b 11 + ∑ j ∈ range 11,
        if d.val ≤ j then delta (high G).card b j else 0) :
    (∑ k ∈ (high G).powersetCard b, (FiniteRange.bad G (high G) k).card) ≤
      highCharge (types G).card (high G).card b := by
  classical
  let s := high G
  let opts := s.powersetCard b
  let fiber (z : V) := (opts.filter (fun k => z ∈ FiniteRange.bad G s k)).card
  have point (z : V) (hz : z ∈ s) : fiber z ≤ FiniteRange.badCount s.card b 11 +
      ∑ j ∈ range 11, if G.degree z ≤ j then delta s.card b j else 0 := by
    change 12 ≤ s.card at large
    have raw := FiniteRange.count_bad G s b (min (G.degree z) 11) z hz (min_le_left _ _) (by omega)
    by_cases le : G.degree z ≤ 11
    · rw [min_eq_left le] at raw
      exact raw.trans (envelope ⟨G.degree z,by omega⟩ (mem_filter.mp hz).2)
    · rw [min_eq_right (by omega)] at raw
      exact raw.trans (Nat.le_add_right ..)
  have step (j : ℕ) : (∑ z ∈ s, if G.degree z ≤ j then delta s.card b j else 0) ≤
      delta s.card b j * min s.card (s.card+j.choose 2+1-(types G).card) := by
    rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    by_cases pos : 3 ≤ j
    · have h := Repair.profile_count G j (by omega)
      change (types G).card + (s.filter _).card ≤ s.card + _ + 1 at h
      apply Nat.mul_le_mul_left
      simp only [Nat.cast_id]
      have := card_filter_le s (fun z => G.degree z ≤ j)
      omega
    · simp [delta,pos]
  have sumH := sum_le_sum point
  rw [sum_add_distrib,sum_comm (s := s) (t := range 11)] at sumH
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id] at sumH
  have ub : (∑ v ∈ s, fiber v) ≤ highCharge (types G).card s.card b :=
    sumH.trans (Nat.add_le_add_left (sum_le_sum (fun j _ => step j)) _)
  apply le_trans (le_of_eq ?_) ub
  calc
    _ = ∑ k ∈ opts, ∑ z ∈ s, (if z ∈ FiniteRange.bad G s k then 1 else 0 : ℕ) := by
      apply sum_congr rfl
      intro k _
      simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
      rw [inter_eq_right.mpr (show FiniteRange.bad G s k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
    _ = _ := by rw [sum_comm]; simp [fiber]

/-- In a counterexample the high vertices and degree-two vertices must obey
this single integer inequality for every admissible high-vertex sample size. -/
theorem sample_obstruction (b : ℕ) (large : 12 ≤ (high G).card) (two : 2 ≤ b)
    (envelope : ∀ d : Fin 12, 3 ≤ d.val → FiniteRange.badCount (high G).card b d.val ≤
      FiniteRange.badCount (high G).card b 11 + ∑ j ∈ range 11,
        if d.val ≤ j then delta (high G).card b j else 0)
    (reward : ∀ d : Fin 3, 6*((high G).card-2).choose (b-2) ≤
      weight d.val * ((high G).card-d.val).choose (b-d.val))
    (failure : bound G < gamma G) :
    let m := (high G).card
    6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) ≤
      6*((((types G).card+1)/2-1)*m.choose b + highCharge (types G).card m b) := by
  let s := high G
  let opts := s.powersetCard b
  let z := twos G
  let W (v : V) := weight (anchors G v).card
  have mass : z.card * (6*(s.card-2).choose (b-2)) ≤ ∑ k ∈ opts, ∑ v ∈ eligible G k, W v := by
    calc
      _ = ∑ _v ∈ z, (6*(s.card-2).choose (b-2)) := by simp
      _ ≤ ∑ v ∈ z, ∑ k ∈ opts, if anchors G v ⊆ k then W v else 0 := by
        apply sum_le_sum
        intro v hv
        have count : (anchors G v).card ≤ 2 := by
          have sub : anchors G v ⊆ G.neighborFinset v := fun x hx =>
            (G.mem_neighborFinset _ _).mpr (mem_filter.mp hx).2
          simpa only [card_neighborFinset_eq_degree,two_degree G hv] using card_le_card sub
        have a := reward ⟨(anchors G v).card,by omega⟩
        have q := anchor_samples s (anchors G v) b (filter_subset _ _) (by omega)
        rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.cast_id]
        simpa only [Nat.mul_comm (W v),W,opts,s] using a.trans (Nat.mul_le_mul_left _ q)
      _ = _ := by rw [sum_comm]; simp [eligible,z,sum_filter]
  have point (k : Finset V) (hk : k ∈ opts) : 6*(s.card-b) + (∑ v ∈ eligible G k, W v) ≤
      6*((((types G).card+1)/2-1) + (FiniteRange.bad G s k).card) := by
    obtain ⟨kh,kb⟩ := mem_powersetCard.mp hk
    have tr := trial G k kh failure
    rwa [kb] at tr
  have sum := sum_le_sum point
  simp only [sum_add_distrib,Nat.mul_add,← mul_sum,sum_const,nsmul_eq_mul,opts,card_powersetCard,Nat.cast_id] at sum
  have bad := high_bad G b large envelope
  change (∑ k ∈ s.powersetCard b, (FiniteRange.bad G s k).card) ≤ _ at bad
  dsimp only [opts] at mass
  dsimp only
  change 6*(s.card-b)*s.card.choose b + _ ≤ _
  rw [Nat.mul_comm (6*(s.card-b)) (s.card.choose b)]
  rw [Nat.mul_comm ((((types G).card+1)/2)-1) (s.card.choose b)]
  rw [Nat.mul_left_comm (s.card.choose b) 6 (s.card-b)]
  change z.card * (6 * (s.card-2).choose (b-2)) ≤ _ at mass
  change 6*(s.card.choose b*(s.card-b)) + z.card*(6*(s.card-2).choose (b-2)) ≤ _
  omega

end Graffiti384b.LowSample
namespace Graffiti384b.LowSample
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- For each type count and diversity offset, the row gives the nonleaf cap
and a number of high vertices to retain. -/
def row : ℕ → ℕ → ℕ × ℕ
  | 14,2 => (15,6)
  | 15,1 => (19,7)
  | 15,2 => (19,6)
  | 16,2 => (18,7)
  | 17,1 => (21,8)
  | 17,2 => (21,8)
  | 18,2 => (20,8)
  | 19,1 => (23,9)
  | 19,2 => (24,8)
  | 20,2 => (22,8)
  | 21,1 => (26,9)
  | 21,2 => (26,9)
  | 22,2 => (24,9)
  | 23,1 => (28,10)
  | 23,2 => (28,9)
  | 24,2 => (26,10)
  | 25,1 => (30,10)
  | 25,2 => (30,10)
  | 26,2 => (28,10)
  | 27,1 => (32,11)
  | 27,2 => (32,11)
  | 28,2 => (30,11)
  | 29,1 => (33,12)
  | 29,2 => (34,11)
  | 30,2 => (32,11)
  | 31,1 => (35,12)
  | 31,2 => (35,12)
  | 32,2 => (33,12)
  | 33,1 => (36,13)
  | 33,2 => (37,12)
  | 34,2 => (34,12)
  | 35,1 => (38,13)
  | 35,2 => (38,13)
  | 36,2 => (35,13)
  | 37,1 => (39,14)
  | 37,2 => (39,14)
  | 38,2 => (36,14)
  | 39,1 => (40,14)
  | 39,2 => (40,14)
  | 40,2 => (37,14)
  | 41,1 => (41,15)
  | 41,2 => (41,15)
  | 42,2 => (39,14)
  | 43,1 => (42,15)
  | 43,2 => (42,15)
  | _,_ => (0,0)

private def Certificate (t e : ℕ) : Prop :=
  let h := t-e
  let (q,b) := row t e
  2 ≤ b ∧ (∀ d : Fin 12, 3 ≤ d.val → FiniteRange.badCount h b d.val ≤
    FiniteRange.badCount h b 11 + ∑ j ∈ range 11, if d.val ≤ j then delta h b j else 0) ∧
    (∀ d : Fin 3, 6*(h-2).choose (b-2) ≤ weight d.val * (h-d.val).choose (b-d.val)) ∧
    6*(((t+1)/2-1)*h.choose b + highCharge t h b) <
      6*(h-b)*h.choose b + (q+1-h)*(6*(h-2).choose (b-2)) ∧
    q ≤ 42 ∧ (t = 38 → q ≤ 36)

set_option maxRecDepth 16384 in
set_option maxHeartbeats 5000000 in
private theorem certificates : ∀ t : Fin 44, ∀ e : Fin 3, 14 ≤ t.val → 1 ≤ e.val →
    (t.val-e.val+1)/2 < (t.val+1)/2 → Certificate t e := by
  unfold Certificate highCharge delta FiniteRange.badCount weight
  simp only [Nat.choose_eq_fast_choose]
  decide

theorem nonleaf_profile (fail : bound G < gamma G) (lo : 14 ≤ (types G).card)
    (hi : (types G).card ≤ 43) :
    let t := (types G).card
    let e := t-(high G).card
    (nonleaves G).card ≤ (row t e).1 ∧ (row t e).1 ≤ 42 ∧ (t = 38 → (row t e).1 ≤ 36) := by
  let t := (types G).card
  let h := (high G).card
  let e := t-h
  let q := (row t e).1
  let b := (row t e).2
  have miss : (h+1)/2 < (t+1)/2 := Nat.lt_of_not_ge (fun le => (not_le_of_gt fail) (exact_of_high G le))
  have limit : t ≤ h+2 := type_bound G
  have ee : 1 ≤ e ∧ e < 3 := by dsimp [e]; omega
  have diff : t-e = h := by dsimp [e]; omega
  have table := certificates ⟨t,by dsimp [t]; omega⟩ ⟨e,ee.2⟩ lo ee.1 (by simpa only [diff] using miss)
  change Certificate t e at table
  unfold Certificate at table
  change 2 ≤ b ∧ _ at table
  obtain ⟨two,env,reward,cert,cap,skip⟩ := table
  change (∀ d : Fin 12, 3 ≤ d.val → FiniteRange.badCount (t-e) b d.val ≤
    FiniteRange.badCount (t-e) b 11 + ∑ j ∈ range 11, if d.val ≤ j then delta (t-e) b j else 0) at env
  change (∀ d : Fin 3, 6*(t-e-2).choose (b-2) ≤ weight d.val*((t-e)-d.val).choose (b-d.val)) at reward
  change 6*(((t+1)/2-1)*(t-e).choose b + highCharge t (t-e) b) <
    6*(t-e-b)*(t-e).choose b + (q+1-(t-e))*(6*(t-e-2).choose (b-2)) at cert
  rw [diff] at env reward cert
  change 14 ≤ t at lo
  have obs := sample_obstruction G b (by change 12 ≤ h; omega) two env reward fail
  change 6*(h-b)*h.choose b + (twos G).card*(6*(h-2).choose (b-2)) ≤
    6*(((t+1)/2-1)*h.choose b + highCharge t h b) at obs
  have sub : high G ⊆ nonleaves G := by
    intro v hv
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have size : (twos G).card + h = (nonleaves G).card := card_sdiff_add_card_eq_card sub
  refine ⟨?_,cap,skip⟩
  change (nonleaves G).card ≤ q
  by_contra! big
  have weightBound := Nat.mul_le_mul_right (6*(h-2).choose (b-2))
    (show q+1-h ≤ (twos G).card by omega)
  omega

/-- The induced counterexample bound improves from 45 to 43 vertices and
38 triangle types are excluded as well. -/
theorem bounded_failure (hc : G.Connected) (ord : 2 < Fintype.card V) (fail : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ r.card ≤ 43 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V)) = types G ∧ 7 ≤ (types G).card ∧ (types G).card ≤ 43 ∧
      (types G).card ≠ 38 ∧ (types G).card ≠ 40 ∧ (types G).card ≠ 42 ∧
      bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨_,_,_,_,_,lo,hi,no40,no42,_⟩ := FiniteRange.bounded_induced_failure G hc ord fail
  obtain ⟨r,_,size,ord,conn,same,fails⟩ := Prune.prune_failure G hc ord fail
  have rank : (types (G.induce (r : Set V))).card ≤ r.card := by
    simpa [types] using (card_image_le (s := (univ : Finset r)) (f := trianglesAt (G.induce (r : Set V))))
  rw [same] at rank
  by_cases highT : 14 ≤ (types G).card
  · obtain ⟨q,cap,skip⟩ := nonleaf_profile G fail highT hi
    exact ⟨r,ord,by omega,conn,same,lo,hi,fun e => by have := skip e; omega,no40,no42,fails⟩
  · have q := nonleaf_bound G
    unfold bound at fail
    exact ⟨r,ord,by omega,conn,same,lo,hi,by omega,no40,no42,fails⟩

end Graffiti384b.LowSample

#print axioms Graffiti384b.LowSample.sample_obstruction
#print axioms Graffiti384b.LowSample.nonleaf_profile
#print axioms Graffiti384b.LowSample.bounded_failure
namespace Graffiti384b.LowSample
open SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

theorem exact_of_38_types (hc : G.Connected) (hn : 2 < Fintype.card V)
    (ht : (types G).card = 38) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨_,_,_,_,_,_,_,no38,_,_,_⟩ := bounded_failure G hc hn fail
  exact no38 ht

end Graffiti384b.LowSample

#print axioms Graffiti384b.LowSample.exact_of_38_types
