import WheelCubic
namespace Graffiti384b.OddStars.Octahedron
open Finset SimpleGraph WheelCut WheelCubic
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The six slots are paired as 01, 23, 45. Different pairs are joined. -/
def apart (i j : Fin 6) : Prop := i.val/2≠j.val/2
instance (i j : Fin 6) : Decidable (apart i j) := inferInstanceAs (Decidable (_≠_))

private theorem frame_slots : ∀i : Fin 6,∃a b c d : Fin 6,a≠b ∧ c≠d ∧
    apart i a ∧ apart i b ∧ apart i c ∧ apart i d ∧
    apart a c ∧ apart a d ∧ apart b c ∧ apart b d := by decide

private theorem parts : ∀S : Finset (Fin 6),S.card=3 →
    (∃i : Fin 6,i∉S ∧ ∀j∈S,apart i j) ∨
    (∀i∈Sᶜ,∀j∈Sᶜ,i≠j → apart i j) := by decide

/-- A possibly noninduced octahedron suffices for the catalogue inequality
at any order when triangle count one is absent. -/
theorem exact_of_octahedron (conn : G.Connected) (order : 2<Fintype.card V)
    (one : 1∉types G) (f : Fin 6 ↪ V) (edge : ∀i j,apart i j → G.Adj (f i) (f j)) :
    gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt
  intro bad
  let J := patch G ∅
  obtain ⟨u,v,su,sv,du,dv,cover⟩ := center_cover G conn order bad one
  have skeleton (i j : Fin 6) (ij : apart i j) : J.Adj (f i) (f j) := by
    have aux : ∀a b : Fin 6,∃c,apart a c ∧ apart b c := by decide
    obtain ⟨c,ac,bc⟩ := aux i j
    exact ⟨edge i j ij,Or.inl ⟨f c,edge _ _ ac,edge _ _ bc⟩⟩
  have high_slot (i : Fin 6) : 4≤J.degree (f i) := by
    let L := univ.filter (apart i)
    have size : ∀j : Fin 6,(univ.filter (apart j)).card=4 := by decide
    have inc : L.map f⊆J.neighborFinset (f i) := by
      intro x xm; obtain ⟨j,jm,rfl⟩ := mem_map.mp xm
      exact (J.mem_neighborFinset ..).mpr (skeleton _ _ (mem_filter.mp jm).2)
    have cnt := card_le_card inc
    rwa [card_map,size,card_neighborFinset_eq_degree] at cnt
  let S := univ.filter (fun i : Fin 6 => J.Adj v (f i))
  have vin : S.map f⊆J.neighborFinset v := by
    intro w wm; obtain ⟨i,im,rfl⟩ := mem_map.mp wm
    exact (J.mem_neighborFinset ..).mpr (mem_filter.mp im).2
  have uin : Sᶜ.map f⊆J.neighborFinset u := by
    intro w wm; obtain ⟨i,im,rfl⟩ := mem_map.mp wm
    obtain ⟨a,b,c,d,ab,cd,ia,ib,ic,id,ac,ad,bc,bd⟩ := frame_slots i
    have r : Rim G (f i) (f a) (f b) (f c) (f d) := ⟨f.injective.ne ab,f.injective.ne cd,
      edge _ _ ia,edge _ _ ib,edge _ _ ic,edge _ _ id,edge _ _ ac,edge _ _ ad,edge _ _ bc,edge _ _ bd⟩
    obtain ⟨z,which,e,_⟩ := cover _ _ _ _ _ r
    have zv : z≠v := fun eq => (mem_compl.mp im) (mem_filter.mpr ⟨mem_univ _,eq ▸ e⟩)
    exact (J.mem_neighborFinset ..).mpr ((which.resolve_right zv) ▸ e)
  have vcap := card_le_card vin
  have ucap := card_le_card uin
  change J.degree v=3 at dv
  change J.degree u=3 at du
  rw [card_map,card_neighborFinset_eq_degree,dv] at vcap
  rw [card_map,card_compl,Fintype.card_fin,card_neighborFinset_eq_degree,du] at ucap
  have sz : S.card=3 := by omega
  have vs := eq_of_subset_of_card_le vin (by rw [card_neighborFinset_eq_degree,dv,card_map,sz])
  have us := eq_of_subset_of_card_le uin (by rw [card_neighborFinset_eq_degree,du,card_map,card_compl,Fintype.card_fin,sz])
  rcases parts S sz with ⟨i,_,allS⟩|clique
  · have eq : f i=v := cubic_triangle_private G conn order bad one dv sv (by
      intro a va
      have am := (J.mem_neighborFinset ..).mpr va
      rw [← vs] at am
      obtain ⟨j,jm,rfl⟩ := mem_map.mp am
      exact edge _ _ (allS _ jm))
    have hi := high_slot i
    rw [eq,dv] at hi
    omega
  · have full {a b : V} (am : a∈J.neighborFinset u) (bm : b∈J.neighborFinset u) (ab : a≠b) : J.Adj a b := by
      rw [← us] at am bm
      obtain ⟨i,im,rfl⟩ := mem_map.mp am
      obtain ⟨j,jm,rfl⟩ := mem_map.mp bm
      exact skeleton _ _ (clique _ im _ jm (fun eq => ab (congrArg f eq)))
    have cnt : trianglesAt J u=3 := by
      unfold trianglesAt
      rw [filter_true_of_mem (by
        intro p pm a am b bm ab
        exact full ((mem_powersetCard.mp pm).1 am) ((mem_powersetCard.mp pm).1 bm) ab),
        card_powersetCard,card_neighborFinset_eq_degree,du]
      decide
    rw [patch_scores,su] at cnt
    contradiction

end Graffiti384b.OddStars.Octahedron
#print axioms Graffiti384b.OddStars.Octahedron.exact_of_octahedron
