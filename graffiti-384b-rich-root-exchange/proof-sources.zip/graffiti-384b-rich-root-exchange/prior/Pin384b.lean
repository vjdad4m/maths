import Anchor384b

namespace Graffiti384b.Pins
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def rows (r k : Finset V) := r.filter (fun v => nbr G v r + 2*nbr G v k < 3)

def clause (r : Finset V) (v : V) : Finset V :=
  if nbr G v r = 2 then insert v (r.filter (G.Adj v)) else {v}

def pinDomain (r k : Finset V) := (rows G r k).biUnion (clause G r)

def admissible (r k p : Finset V) : Prop :=
  ∀ v ∈ r \ p, 3 ≤ nbr G v (r \ p) + 2*nbr G v (k ∪ p)

omit [Fintype V] in
private theorem add_nbr (v : V) {s t : Finset V} (h : Disjoint s t) :
    nbr G v (s ∪ t) = nbr G v s + nbr G v t := by
  unfold nbr
  rw [filter_union]
  exact card_union_of_disjoint (h.mono (filter_subset _ _) (filter_subset _ _))

omit [Fintype V] in
private theorem split_nbr (v : V) {r p : Finset V} (pr : p ⊆ r) :
    nbr G v (r \ p) + nbr G v p = nbr G v r := by
  rw [← add_nbr G v (disjoint_left.mpr (fun _ hs hp => (mem_sdiff.mp hs).2 hp))]
  congr 1
  exact sdiff_union_of_subset pr

omit [Fintype V] in
private theorem hits {r p : Finset V} {v : V} (pr : p ⊆ r) :
    ((clause G r v) ∩ p).Nonempty ↔ v ∈ p ∨ (nbr G v r = 2 ∧ 0 < nbr G v p) := by
  by_cases h : nbr G v r = 2
  · simp only [clause,if_pos h,h,true_and]
    constructor
    · rintro ⟨w,hw⟩
      obtain ⟨hw',wp⟩ := mem_inter.mp hw
      rcases mem_insert.mp hw' with rfl | hh
      · exact Or.inl wp
      · exact Or.inr (card_pos.mpr ⟨w,mem_filter.mpr ⟨wp,(mem_filter.mp hh).2⟩⟩)
    · rintro (hp | hp)
      · exact ⟨v,mem_inter.mpr ⟨mem_insert_self _ _,hp⟩⟩
      · obtain ⟨w,hw⟩ := card_pos.mp hp
        obtain ⟨wp,ha⟩ := mem_filter.mp hw
        exact ⟨w,mem_inter.mpr ⟨mem_insert_of_mem (mem_filter.mpr ⟨pr wp,ha⟩),wp⟩⟩
  · simp only [clause,if_neg h,h,false_and,or_false]
    constructor
    · rintro ⟨w,hw⟩
      obtain ⟨hw,wp⟩ := mem_inter.mp hw
      exact mem_singleton.mp hw ▸ wp
    · exact fun hv => ⟨v,mem_inter.mpr ⟨mem_singleton_self _,hv⟩⟩

omit [Fintype V] in
/-- Complete local characterization for a given pin set. Initially valid
rows stay valid. An invalid row either forces its own pin or is repaired
by pinning one of its two residual neighbors. -/
theorem admissible_iff_hit {r k p : Finset V} (rk : Disjoint r k) (pr : p ⊆ r) :
    admissible G r k p ↔ ∀ v ∈ rows G r k, ((clause G r v) ∩ p).Nonempty := by
  have kp := rk.symm.mono_right pr
  constructor
  · intro h v hv
    apply (hits G pr).mpr
    by_cases vp : v ∈ p
    · exact Or.inl vp
    · obtain ⟨vr,bad⟩ := mem_filter.mp hv
      have hh := h v (mem_sdiff.mpr ⟨vr,vp⟩)
      rw [add_nbr G v kp] at hh
      have split := split_nbr G v pr
      exact Or.inr ⟨by omega,by omega⟩
  · intro h v hv
    obtain ⟨vr,vp⟩ := mem_sdiff.mp hv
    rw [add_nbr G v kp]
    have split := split_nbr G v pr
    by_cases bad : nbr G v r + 2*nbr G v k < 3
    · have hh := (hits G pr).mp (h v (mem_filter.mpr ⟨vr,bad⟩))
      rcases hh with hh | ⟨hr,hp⟩
      · exact (vp hh).elim
      · omega
    · omega

omit [Fintype V] in
theorem pinDomain_sub (r k : Finset V) : pinDomain G r k ⊆ r := by
  intro w hw
  obtain ⟨v,hv,mem⟩ := mem_biUnion.mp hw
  have vr := (mem_filter.mp hv).1
  by_cases h : nbr G v r = 2
  · rw [clause,if_pos h] at mem
    exact (mem_insert.mp mem).elim (fun e => e ▸ vr) (fun hh => (mem_filter.mp hh).1)
  · rw [clause,if_neg h] at mem
    exact mem_singleton.mp mem ▸ vr

omit [Fintype V] in
theorem pinDomain_bound (r k : Finset V) : (pinDomain G r k).card ≤ 3 * (rows G r k).card := by
  calc
    _ ≤ ∑ v ∈ rows G r k, (clause G r v).card := card_biUnion_le
    _ ≤ ∑ _v ∈ rows G r k, 3 := by
      apply sum_le_sum
      intro v _
      by_cases h : nbr G v r = 2
      · rw [clause,if_pos h]
        have := card_insert_le v (r.filter (G.Adj v))
        change (r.filter (G.Adj v)).card = 2 at h
        omega
      · simp [clause,h]
    _ = _ := by simp [Nat.mul_comm]

omit [Fintype V] in
/-- Exhausting subsets of the clause union covers all pin choices, even when
the initial residual graph has arbitrarily many vertices. -/
theorem local_enumeration (r k : Finset V) (rk : Disjoint r k) (budget : ℕ) :
    (∃ p ⊆ r, p.card ≤ budget ∧ admissible G r k p) ↔
    ∃ p ∈ (pinDomain G r k).powerset, p.card ≤ budget ∧
      ∀ v ∈ rows G r k, ((clause G r v) ∩ p).Nonempty := by
  constructor
  · rintro ⟨p,pr,pc,good⟩
    refine ⟨p ∩ pinDomain G r k,mem_powerset.mpr inter_subset_right,
      (card_le_card inter_subset_left).trans pc,?_⟩
    intro v hv
    obtain ⟨w,hw⟩ := (admissible_iff_hit G rk pr).mp good v hv
    obtain ⟨wc,wp⟩ := mem_inter.mp hw
    exact ⟨w,mem_inter.mpr ⟨wc,mem_inter.mpr ⟨wp,mem_biUnion.mpr ⟨v,hv,wc⟩⟩⟩⟩
  · rintro ⟨p,pu,pc,hitsAll⟩
    have pr := (mem_powerset.mp pu).trans (pinDomain_sub G r k)
    exact ⟨p,pr,pc,(admissible_iff_hit G rk pr).mpr hitsAll⟩

/-- A hitting set produces the omitted-set bound by the kernel-checked cut. -/
theorem bound_of_hit (x r k p : Finset V) (xr : Disjoint x r) (xk : Disjoint x k)
    (rk : Disjoint r k) (pr : p ⊆ r) (supports : ∀ v ∈ x, 2 ≤ nbr G v k)
    (hit : ∀ v ∈ rows G r k, ((clause G r v) ∩ p).Nonempty) :
    gamma G ≤ Fintype.card V - (x.card + (r.card - p.card + 1)/2) := by
  have good := (admissible_iff_hit G rk pr).mpr hit
  have h := Repair.seeded_cut G x (k ∪ p) (r \ p) (Finset.disjoint_union_right.mpr ⟨xk,xr.mono_right pr⟩)
    (xr.mono_right sdiff_subset) (Finset.disjoint_union_left.mpr
      ⟨rk.symm.mono_right sdiff_subset,(disjoint_left.mpr (fun _ hp hs => (mem_sdiff.mp hs).2 hp))⟩)
    (fun v hv => (supports v hv).trans (card_le_card (filter_subset_filter _ subset_union_left))) good
  simpa only [card_sdiff pr] using h

theorem initial_rows (a x : Finset V) :
    rows G (Anchor.residual G a x) (Anchor.retained G a x) = Anchor.blocked G a x := by
  ext v
  simp only [rows,Anchor.blocked,mem_filter]
  apply and_congr_right
  intro _
  let r := Anchor.residual G a x
  have dis : Disjoint x r := disjoint_left.mpr (fun _ hx hr => (mem_sdiff.mp hr).2 (mem_union_right _ hx))
  have full : nbr G v x + nbr G v r + nbr G v (Anchor.retained G a x) = G.degree v := by
    unfold Anchor.retained
    rw [← add_nbr G v dis, ← add_nbr G v disjoint_compl_right,union_compl]
    have e : (univ : Finset V).filter (G.Adj v) = G.neighborFinset v := by ext; simp
    simp [nbr,e]
  change nbr G v r + _ < _ ↔ _
  omega

/-- Per fixed triple seed, any counterexample has at most ten local clauses,
each of width at most three. No bound on graph order is required. -/
theorem triple_coverage_size (a x : Finset V) (small : x.card ≤ 3) (failure : bound G < gamma G) :
    let r := Anchor.residual G a x
    let k := Anchor.retained G a x
    (rows G r k).card ≤ 10 ∧ (pinDomain G r k).card ≤ 30 := by
  dsimp only
  have ub := pinDomain_bound G (Anchor.residual G a x) (Anchor.retained G a x)
  have h := Repair.profile_count G 5 (by decide)
  have five : (5:ℕ).choose 2 = 10 := by decide
  rw [five] at h
  have more : (high G).card < (types G).card := by
    by_contra! hh
    exact (not_le_of_gt failure) (exact_of_high G (by omega))
  have inc : Anchor.blocked G a x ⊆ (high G).filter (fun v => G.degree v ≤ 5) := by
    intro z hz
    have deg := (Anchor.blocked_degree G hz).2
    exact mem_filter.mpr ⟨(mem_sdiff.mp (mem_filter.mp hz).1).1,by omega⟩
  rw [initial_rows] at ub ⊢
  have := card_le_card inc
  exact ⟨by omega,by omega⟩

end Graffiti384b.Pins

#print axioms Graffiti384b.Pins.local_enumeration
#print axioms Graffiti384b.Pins.bound_of_hit
#print axioms Graffiti384b.Pins.triple_coverage_size
