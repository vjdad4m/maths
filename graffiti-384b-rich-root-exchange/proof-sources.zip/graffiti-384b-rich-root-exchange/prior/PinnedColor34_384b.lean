import Repair384b

namespace Graffiti384b.PinnedColor34
open Finset SimpleGraph
open private Repair.cross Repair.cross_comm Repair.shift Repair.nbr_mono Repair.full_nbr Repair.omit_set from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem cut (P Q : Finset V) (dis : Disjoint P Q) : ∃ A : Finset V,P⊆A ∧ Q⊆Aᶜ ∧
    (∀ v∈A,v∉P → nbr G v A≤nbr G v Aᶜ) ∧ (∀ v∈Aᶜ,v∉Q → nbr G v Aᶜ<nbr G v A) := by
  classical
  let ok := (univ : Finset (Finset V)).filter (fun a => P⊆a ∧ Q⊆aᶜ)
  let f (a : Finset V) := Repair.cross G a aᶜ
  have start : P∈ok := mem_filter.mpr ⟨mem_univ _,Subset.rfl,fun _ qm => mem_compl.mpr (fun pm => disjoint_left.mp dis pm qm)⟩
  obtain ⟨c,cm,top⟩ := exists_max_image ok f ⟨P,start⟩
  let best := ok.filter (fun a => f a=f c)
  obtain ⟨A,am,size⟩ := exists_max_image best Finset.card ⟨c,mem_filter.mpr ⟨cm,rfl⟩⟩
  obtain ⟨ao,af⟩ := mem_filter.mp am
  obtain ⟨pa,qb⟩ := (mem_filter.mp ao).2
  have large {S : Finset V} (sm : S∈ok) := (top S sm).trans_eq af.symm
  refine ⟨A,pa,qb,?_,?_⟩
  · intro v va vp
    have sm : A.erase v∈ok := mem_filter.mpr ⟨mem_univ _,(fun j jp => mem_erase.mpr ⟨fun e => vp (e ▸ jp),pa jp⟩),
      fun j jq => mem_compl.mpr (fun m => mem_compl.mp (qb jq) (erase_subset _ _ m))⟩
    have le := large sm
    change Repair.cross G (A.erase v) (A.erase v)ᶜ≤Repair.cross G A Aᶜ at le
    rw [compl_erase] at le
    have eq := Repair.shift G va (fun h => mem_compl.mp h va : v∉Aᶜ)
    omega
  · intro v vb vq
    have va := mem_compl.mp vb
    have sm : insert v A∈ok := mem_filter.mpr ⟨mem_univ _,pa.trans (subset_insert ..),fun j jq => mem_compl.mpr (fun m =>
      (mem_insert.mp m).elim (fun e => vq (e ▸ jq)) (mem_compl.mp (qb jq)))⟩
    have strict : f (insert v A)<f A := by
      apply lt_of_le_of_ne (large sm)
      intro eq
      have cap := size (insert v A) (mem_filter.mpr ⟨sm,eq.trans af⟩)
      rw [card_insert_of_not_mem va] at cap; omega
    change Repair.cross G (insert v A) (insert v A)ᶜ<Repair.cross G A Aᶜ at strict
    rw [compl_insert] at strict
    have eq := Repair.shift G vb va
    rw [Repair.cross_comm G (Aᶜ.erase v),Repair.cross_comm G Aᶜ A] at eq
    omega

theorem both (A : Finset V) (q : (types G).card≤(nonleaves G).card)
    (left : ∀ v∈nonleaves G,v∈A → 2≤nbr G v Aᶜ) (right : ∀ v∈nonleaves G,v∈Aᶜ → 2≤nbr G v A) : gamma G≤bound G := by
  let S := nonleaves G
  have first := Repair.omit_set G (S∩A) (fun v vm => (left v (mem_inter.mp vm).1 (mem_inter.mp vm).2).trans (Repair.nbr_mono G _ (fun _ h =>
    mem_compl.mpr (fun m => mem_compl.mp h (mem_inter.mp m).2))))
  have second := Repair.omit_set G (S\A) (fun v vm => (right v (mem_sdiff.mp vm).1 (mem_compl.mpr (mem_sdiff.mp vm).2)).trans (Repair.nbr_mono G _ (fun _ h =>
    mem_compl.mpr (fun m => (mem_sdiff.mp m).2 h))))
  have num := card_sdiff_add_card_inter S A
  change (types G).card≤S.card at q
  unfold bound
  omega

theorem complete {P Q : Finset V} (dis : Disjoint P Q) (q : (types G).card≤(nonleaves G).card)
    (degrees : ∀ v∈nonleaves G,v∉P → v∉Q → 3≤G.degree v)
    (lp : ∀ v∈P,2≤nbr G v Q) (rq : ∀ v∈Q,2≤nbr G v P) : gamma G≤bound G := by
  obtain ⟨A,pa,qb,la,rb⟩ := cut G P Q dis
  apply both G A q
  · intro v vn va
    by_cases vp : v∈P
    · exact (lp v vp).trans (Repair.nbr_mono G v qb)
    · have dg := degrees v vn vp (fun h => mem_compl.mp (qb h) va)
      have ae := la v va vp
      have su := Repair.full_nbr G v A
      omega
  · intro v vn vb
    by_cases vq : v∈Q
    · exact (rq v vq).trans (Repair.nbr_mono G v pa)
    · have dg := degrees v vn (fun h => mem_compl.mp vb (pa h)) vq
      have ae := rb v vb vq
      have su := Repair.full_nbr G v A
      omega

end Graffiti384b.PinnedColor34
#print axioms Graffiti384b.PinnedColor34.complete
