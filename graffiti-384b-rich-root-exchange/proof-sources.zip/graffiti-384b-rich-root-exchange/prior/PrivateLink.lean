import ReservedWheel
import CycleSquareArms
namespace Graffiti384b.OddStars.PrivateLink
open Finset SimpleGraph WheelCut WheelCubic ReservedWheel
open private Repair.isolate Repair.nbr_mono from Repair384b
open private CliquePivot33.isolated_degree from ShoreCliquePivot
open private HallArms.cycle_frame from CycleSquareArms
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem upper_barrier (bad : bound G<gamma G) (one : 1∉types G) {P Q : Finset V}
    (f : Frame (patch G ∅) P Q) {x : V} (outside : x∉P∪Q) (px : 2≤nbr (patch G ∅) x P)
    (qx : 2≤nbr (patch G ∅) x Q) : ∃w,(patch G ∅).degree w=3 ∧ (patch G ∅).Adj w x ∧ w∉P∪Q := by
  classical
  let J := patch G ∅
  by_contra! no
  have val := weighted_pivot J (high J) f.dis (fun m => outside (mem_union_left _ m))
    (fun m => outside (mem_union_right _ m)) px qx f.left f.right (by
      intro w wm wx wp wq
      have dg : 3≤J.degree w := (mem_filter.mp wm).2
      rw [CliquePivot33.isolated_degree J wx]
      by_cases ed : J.Adj w x
      · rw [card_erase_of_mem ((J.mem_neighborFinset ..).mpr ed),card_neighborFinset_eq_degree]
        have ne : J.degree w≠3 := fun eq => (mem_union.mp (no w eq ed)).elim wp wq
        omega
      · rwa [erase_eq_of_not_mem (fun m => ed ((J.mem_neighborFinset ..).mp m)),card_neighborFinset_eq_degree])
  have mono := PositivePalette.Prerequisites.gamma_mono G J (fun _ _ ed => ed.1)
  have sz := (PaletteCorollaries.upper_iff_no_one G bad).mpr one
  change (high J).card+1=(types G).card at sz
  unfold bound at bad
  omega

/-- One particular neighbor of the score-three cubic blocks every supported
pair of color classes that includes the cubic and leaves this neighbor free. -/
theorem blocked_neighbor (conn : G.Connected) (order : 2<Fintype.card V) (bad : bound G<gamma G)
    (one : 1∉types G) {v : V} (dv : (patch G ∅).degree v=3) (sv : trianglesAt G v=3) :
    ∃a,(patch G ∅).Adj v a ∧ ∀P Q : Finset V,Frame (patch G ∅) P Q → v∈P∪Q → a∉P∪Q →
      nbr (patch G ∅) a P≤1 ∨ nbr (patch G ∅) a Q≤1 := by
  classical
  let J := patch G ∅
  obtain ⟨_,u,z,_,su,sz,_,cub,_⟩ := PaletteCorollaries.missing_one_failure G conn order bad one
  have vz := distinct_rich G bad (x:=v) (by omega) (sv.trans sz.symm)
  subst z
  have du := (cub _).mpr (Or.inl (rfl : u=u))
  have gaps : ¬J.neighborFinset v⊆J.neighborFinset u := by
    intro sub
    have eq := eq_of_subset_of_card_le sub (by rw [card_neighborFinset_eq_degree,card_neighborFinset_eq_degree,du,dv])
    have same : trianglesAt J v=trianglesAt J u := by unfold trianglesAt; rw [eq]
    rw [patch_scores,patch_scores,sv,su] at same
    contradiction
  obtain ⟨a,va,ua⟩ := not_subset.mp gaps
  refine ⟨a,(J.mem_neighborFinset ..).mp va,?_⟩
  intro P Q fp vp ap
  by_contra! plenty
  obtain ⟨w,dw,ed,off⟩ := upper_barrier G bad one fp ap plenty.1 plenty.2
  rcases (cub _).mp dw with rfl|rfl
  · exact ua ((J.mem_neighborFinset ..).mpr ed)
  · exact off vp

/-- In the original graph, one neighbor a of the score-three cubic v has
no even cycle through v in its neighborhood. A candidate cycle is given
as a simple even-length path and its two closing edges to v. -/
theorem blocked_even_link (conn : G.Connected) (order : 2<Fintype.card V) (bad : bound G<gamma G)
    (one : 1∉types G) {v : V} (dv : (patch G ∅).degree v=3) (sv : trianglesAt G v=3) :
    ∃a,(patch G ∅).Adj v a ∧ ∀(n : ℕ) (f : ℕ → V),2≤n → n%2=0 →
      (∀i<n,G.Adj (f i) (f (i+1))) → (∀i≤n,∀j≤n,f i=f j → i=j) →
      (∀i≤n,f i≠v) → G.Adj v (f 0) → G.Adj v (f n) → ¬(∀i≤n,G.Adj a (f i)) := by
  classical
  let J := patch G ∅
  obtain ⟨a,va,blocked⟩ := blocked_neighbor G conn order bad one dv sv
  refine ⟨a,va,?_⟩
  intro n f big even step inj avoid first last inside
  have rim {p q : V} (ed : G.Adj p q) (ap : G.Adj a p) (aq : G.Adj a q) : J.Adj p q :=
    ⟨ed,Or.inl ⟨a,ap.symm,aq.symm⟩⟩
  obtain ⟨P,Q,dis,shape,lp,rq⟩ := HallArms.cycle_frame J big even f
    (fun i hi => rim (step i hi) (inside _ (by omega)) (inside _ (by omega))) inj avoid
    (rim first va.1.symm (inside _ (by omega))) (rim last va.1.symm (inside _ le_rfl))
  have vp : v∈P∪Q := shape ▸ mem_insert_self ..
  have sees {b : V} (bm : b∈P∪Q) : J.Adj a b := by
    rw [shape] at bm
    rcases mem_insert.mp bm with rfl|m
    · exact va.symm
    obtain ⟨i,im,rfl⟩ := mem_image.mp m
    have hi : i≤n := Nat.le_of_lt_succ (mem_range.mp im)
    by_cases iz : i=0
    · subst i; exact ⟨inside 0 hi,Or.inl ⟨v,va.1.symm,first.symm⟩⟩
    · have ed := step (i-1) (by omega)
      rw [show i-1+1=i by omega] at ed
      exact ⟨inside i hi,Or.inl ⟨f (i-1),inside _ (by omega),ed.symm⟩⟩
  have out : a∉P∪Q := fun m => (sees m).ne rfl
  have frame : Frame J P Q := ⟨dis,lp,rq⟩
  have pc : 2≤P.card ∧ 2≤Q.card := by
    have left (p : V) (pm : p∈P) : 2≤Q.card := (lp _ pm).trans (card_filter_le ..)
    have right (q : V) (qm : q∈Q) : 2≤P.card := (rq _ qm).trans (card_filter_le ..)
    rcases mem_union.mp vp with m|m
    · have q := left _ m
      obtain ⟨w,wm⟩ := card_pos.mp (show 0<Q.card by omega)
      exact ⟨right _ wm,q⟩
    · have p := right _ m
      obtain ⟨w,wm⟩ := card_pos.mp (show 0<P.card by omega)
      exact ⟨p,left _ wm⟩
  have fail := blocked P Q frame vp out
  unfold nbr at fail
  rw [filter_true_of_mem (fun _ h => sees (mem_union_left _ h)),
      filter_true_of_mem (fun _ h => sees (mem_union_right _ h))] at fail
  omega

end Graffiti384b.OddStars.PrivateLink
#print axioms Graffiti384b.OddStars.PrivateLink.blocked_neighbor
#print axioms Graffiti384b.OddStars.PrivateLink.blocked_even_link
