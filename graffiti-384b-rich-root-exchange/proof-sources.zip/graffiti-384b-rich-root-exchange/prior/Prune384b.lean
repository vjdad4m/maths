import CoreSize384b

namespace Graffiti384b.Prune
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

private def links (v : V) :=
  ((G.neighborFinset v).powersetCard 2).filter
    (fun p => ∀ x ∈ p, ∀ y ∈ p, x ≠ y → G.Adj x y)

private theorem link_in_core {v : V} {p : Finset V} (hp : p ∈ links G v) :
    p ⊆ nonleaves G := by
  obtain ⟨hn,edges⟩ := mem_filter.mp hp
  obtain ⟨sub,two⟩ := mem_powersetCard.mp hn
  intro x hx
  obtain ⟨y,hy,ne⟩ := exists_ne_of_one_lt_card (by omega : 1 < p.card) x
  have vx := (G.mem_neighborFinset _ _).mp (sub hx)
  have vy := (G.mem_neighborFinset _ _).mp (sub hy)
  have xy := edges x hx y hy ne.symm
  apply mem_filter.mpr ⟨mem_univ _,?_⟩
  have h : 1 < (G.neighborFinset x).card := one_lt_card.mpr
    ⟨v,(G.mem_neighborFinset _ _).mpr vx.symm,y,(G.mem_neighborFinset _ _).mpr xy,vy.ne⟩
  simpa only [card_neighborFinset_eq_degree] using h

theorem counts_preserved (s : Finset V) (keep : nonleaves G ⊆ s) (v : s) :
    trianglesAt (G.induce (s : Set V)) v = trianglesAt G v := by
  let H := G.induce (s : Set V)
  let emb : s ↪ V := Function.Embedding.subtype _
  have eq : (links H v).image (map emb) = links G v.val := by
    ext p
    constructor
    · intro hp
      obtain ⟨q,hq,rfl⟩ := mem_image.mp hp
      obtain ⟨qq,edge⟩ := mem_filter.mp hq
      obtain ⟨ns,two⟩ := mem_powersetCard.mp qq
      apply mem_filter.mpr
      refine ⟨mem_powersetCard.mpr ⟨?_,by simpa using two⟩,?_⟩
      · intro x hx
        obtain ⟨y,hy,rfl⟩ := mem_map.mp hx
        exact (G.mem_neighborFinset _ _).mpr ((H.mem_neighborFinset _ _).mp (ns hy))
      · intro x hx y hy ne
        obtain ⟨w,hw,rfl⟩ := mem_map.mp hx
        obtain ⟨z,hz,rfl⟩ := mem_map.mp hy
        exact edge w hw z hz (fun h => ne (congrArg emb h))
    · intro hp
      let q := p.subtype (fun w => w ∈ s)
      have mapped : q.map emb = p := subtype_map_of_mem ((link_in_core G hp).trans keep)
      obtain ⟨qq,edge⟩ := mem_filter.mp hp
      obtain ⟨ns,two⟩ := mem_powersetCard.mp qq
      apply mem_image.mpr ⟨q,?_,mapped⟩
      apply mem_filter.mpr
      refine ⟨mem_powersetCard.mpr ⟨?_,?_⟩,?_⟩
      · intro w hw
        exact (H.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp (ns (mem_subtype.mp hw)))
      · have cm := congrArg Finset.card mapped
        simpa [two] using cm
      · intro w hw z hz nz
        exact edge w.val (mem_subtype.mp hw) z.val (mem_subtype.mp hz) (fun e => nz (Subtype.ext e))
  change (links H v).card = (links G v.val).card
  rw [← eq,card_image_of_injective _ (Finset.map_injective emb)]

private theorem outside_zero {v : V} (hv : v ∉ nonleaves G) : trianglesAt G v = 0 := by
  have deg : G.degree v ≤ 1 := by
    have : ¬2 ≤ G.degree v := fun h => hv (mem_filter.mpr ⟨mem_univ _,h⟩)
    omega
  have bound := card_filter_le ((G.neighborFinset v).powersetCard 2)
    (fun p => ∀ x ∈ p, ∀ y ∈ p, x ≠ y → G.Adj x y)
  rw [card_powersetCard,card_neighborFinset_eq_degree,Nat.choose_eq_zero_of_lt (by omega : G.degree v < 2)] at bound
  exact Nat.eq_zero_of_le_zero bound

/-- A retained nonempty superset of the nonleaves stays connected. -/
theorem connected_core (hc : G.Connected) {s : Finset V} (keep : nonleaves G ⊆ s) (hs : s.Nonempty) :
    (G.induce (s : Set V)).Connected := by
  let H := G.induce (s : Set V)
  obtain ⟨root,hr⟩ := hs
  let root' : s := ⟨root,hr⟩
  apply (connected_iff_exists_forall_reachable H).mpr
  refine ⟨root',?_⟩
  have only {z : V} (out : z ∉ s) {a b : V} (ha : G.Adj z a) (hb : G.Adj z b) : a = b := by
    have deg : (G.neighborFinset z).card ≤ 1 := by
      rw [card_neighborFinset_eq_degree]
      by_contra! large
      exact out (keep (mem_filter.mpr ⟨mem_univ _,large⟩))
    exact card_le_one.mp deg _ ((G.mem_neighborFinset _ _).mpr ha) _ ((G.mem_neighborFinset _ _).mpr hb)
  intro t
  have walk := (G.reachable_iff_reflTransGen root t.val).mp (hc.preconnected _ _)
  let state (z : V) : Prop := (∀ hz : z ∈ s, H.Reachable root' ⟨z,hz⟩) ∧
    (z ∉ s → ∀ w, ∀ hw : w ∈ s, G.Adj z w → H.Reachable root' ⟨w,hw⟩)
  have run {endpt : V} (path : Relation.ReflTransGen G.Adj root endpt) : state endpt := by
    induction path with
    | refl => exact ⟨fun _ => Reachable.refl _,fun h => (h hr).elim⟩
    | @tail z w _ adj ih =>
      constructor
      · intro hw
        by_cases hz : z ∈ s
        · have a : H.Adj (⟨z,hz⟩ : s) ⟨w,hw⟩ := adj
          exact (ih.1 hz).trans a.reachable
        · exact ih.2 hz w hw adj
      · intro hw y hy wy
        have eq := only hw adj.symm wy
        subst y
        exact ih.1 hy
  exact (run walk).1 t.property

/-- A catalogue witness in an induced subgraph with unchanged type count
gives the same number of feasible omissions in the original graph. -/
theorem lift_solution (s : Finset V) (same : (types (G.induce (s : Set V))).card = (types G).card)
    (sol : gamma (G.induce (s : Set V)) ≤ bound (G.induce (s : Set V))) : gamma G ≤ bound G := by
  let H := G.induce (s : Set V)
  let emb : s ↪ V := Function.Embedding.subtype _
  have available : {k : ℕ | ∃ d, TwoDominates H d ∧ d.card = k}.Nonempty :=
    ⟨_,univ,(by simp [TwoDominates]),rfl⟩
  obtain ⟨d,dom,size⟩ := Nat.sInf_mem available
  let x := dᶜ.map emb
  let k := d.map emb
  have dis : Disjoint x k := disjoint_left.mpr (by
    intro w hx hk
    obtain ⟨z,hz,rfl⟩ := mem_map.mp hx
    obtain ⟨y,hy,eq⟩ := mem_map.mp hk
    exact mem_compl.mp hz (emb.injective eq ▸ hy))
  have supports (z : V) (hz : z ∈ x) : 2 ≤ nbr G z k := by
    obtain ⟨w,hw,rfl⟩ := mem_map.mp hz
    have sub : (d.filter (H.Adj w)).map emb ⊆ k.filter (G.Adj (emb w)) := by
      intro v hv
      obtain ⟨i,hi,rfl⟩ := mem_map.mp hv
      exact mem_filter.mpr ⟨mem_map.mpr ⟨i,(mem_filter.mp hi).1,rfl⟩,(mem_filter.mp hi).2⟩
    have h := card_le_card sub
    rw [card_map] at h
    exact (dom w (mem_compl.mp hw)).trans h
  have upper := Repair.seeded_cut G x k ∅ dis (disjoint_empty_right _) (disjoint_empty_right _) supports (by simp)
  change d.card = gamma H at size
  change gamma H ≤ bound H at sol
  unfold bound at sol ⊢
  change (types H).card = _ at same
  have htype : (types H).card ≤ Fintype.card s := by
    simpa [types] using (card_image_le (s := (univ : Finset s)) (f := trianglesAt H))
  simp only [x,card_map,card_compl,card_empty] at upper
  change gamma H ≤ Fintype.card s - ((types H).card+1)/2 at sol
  rw [same] at sol htype
  omega

/-- Every failure contains a connected induced failure, with all triangle
types preserved and at most one vertex in addition to its original nonleaves. -/
theorem prune_failure (hc : G.Connected) (hn : 2 < Fintype.card V) (failure : bound G < gamma G) :
    ∃ s : Finset V, nonleaves G ⊆ s ∧ s.card ≤ (nonleaves G).card+1 ∧
      2 < s.card ∧ (G.induce (s : Set V)).Connected ∧
      types (G.induce (s : Set V)) = types G ∧
      bound (G.induce (s : Set V)) < gamma (G.induce (s : Set V)) := by
  have many : 6 < (types G).card := by
    by_contra! few
    exact (not_le_of_gt failure) (Anchor.exact_of_six_types G hc hn few)
  have select : ∃ s : Finset V, nonleaves G ⊆ s ∧ s.card ≤ (nonleaves G).card+1 ∧
      ∀ v, ∃ w ∈ s, trianglesAt G w = trianglesAt G v := by
    by_cases all : nonleaves G = univ
    · exact ⟨univ,subset_univ _,by simp [all],fun v => ⟨v,mem_univ _,rfl⟩⟩
    · obtain ⟨v,hv⟩ : ∃ v, v ∉ nonleaves G := by
        by_contra! allin
        exact all (eq_univ_of_forall allin)
      refine ⟨insert v (nonleaves G),subset_insert _ _,card_insert_le _ _,?_⟩
      intro w
      by_cases hw : w ∈ nonleaves G
      · exact ⟨w,mem_insert_of_mem hw,rfl⟩
      · exact ⟨v,mem_insert_self _ _,(outside_zero G hv).trans (outside_zero G hw).symm⟩
  obtain ⟨s,keep,cap,reps⟩ := select
  let H := G.induce (s : Set V)
  have same : types H = types G := by
    ext j
    constructor
    · intro hj
      obtain ⟨v,_,eq⟩ := mem_image.mp hj
      exact mem_image.mpr ⟨v.val,mem_univ _,(counts_preserved G s keep v).symm.trans eq⟩
    · intro hj
      obtain ⟨v,_,rfl⟩ := mem_image.mp hj
      obtain ⟨w,hw,eq⟩ := reps v
      exact mem_image.mpr ⟨⟨w,hw⟩,mem_univ _,(counts_preserved G s keep ⟨w,hw⟩).trans eq⟩
  have num : (types H).card ≤ s.card := by
    simpa [types,Fintype.card_coe] using (card_image_le (s := (univ : Finset s)) (f := trianglesAt H))
  rw [same] at num
  have order : 2 < s.card := by omega
  refine ⟨s,keep,cap,order,connected_core G hc keep (card_pos.mp (by omega)),same,?_⟩
  exact Nat.lt_of_not_ge (fun sol => (not_le_of_gt failure) (lift_solution G s (congrArg card same) sol))

theorem bounded_induced_failure (hc : G.Connected) (hn : 2 < Fintype.card V) (failure : bound G < gamma G) :
    ∃ s : Finset V, 2 < s.card ∧ s.card ≤ 82 ∧ (G.induce (s : Set V)).Connected ∧
      types (G.induce (s : Set V)) = types G ∧
      bound (G.induce (s : Set V)) < gamma (G.induce (s : Set V)) := by
  obtain ⟨s,_,cap,order,conn,same,fail⟩ := prune_failure G hc hn failure
  have small := (CoreSize.bounded_core G failure).2
  exact ⟨s,order,by omega,conn,same,fail⟩

end Graffiti384b.Prune

#print axioms Graffiti384b.Prune.prune_failure
#print axioms Graffiti384b.Prune.bounded_induced_failure
