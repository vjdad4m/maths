import PinnedColor34_384b

namespace Graffiti384b.PinnedColor34
open Finset SimpleGraph
open private Repair.nbr_mono Repair.full_nbr Repair.nbr_erase_self from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
theorem two {a b v : V} {S : Finset V} (ab : a≠b) (va : G.Adj v a) (vb : G.Adj v b) (as : a∈S) (bs : b∈S) :
    2≤nbr G v S := by
  have inc : ({a,b}: Finset V)⊆S.filter (G.Adj v) := insert_subset (mem_filter.mpr ⟨as,va⟩) (singleton_subset_iff.mpr (mem_filter.mpr ⟨bs,vb⟩))
  simpa only [card_pair ab] using card_le_card inc

/-- All pins except u are protected. The triangle u,x,m repairs u by
moving x. A cardinality tie-break provides a spare crossing neighbor
to each unpinned vertex on the side receiving x. -/
theorem repair {P Q : Finset V} {u x m : V} (dis : Disjoint P Q) (q : (types G).card≤(nonleaves G).card)
    (degrees : ∀ v∈nonleaves G,v∉P → v∉Q → 4≤G.degree v)
    (lp : ∀ v∈P,v≠u → 2≤nbr G v Q) (rq : ∀ v∈Q,2≤nbr G v P)
    (one : 0<nbr G u Q) (up : u∈P) (xp : x∉P) (xq : x∉Q) (mq : m∉Q)
    (ux : G.Adj u x) (um : G.Adj u m) (xm : G.Adj x m) : gamma G≤bound G := by
  obtain ⟨A,pa,qb,la,rb⟩ := cut G P Q dis
  have left (v : V) (vn : v∈nonleaves G) (va : v∈A) (ne : v≠u) : 2≤nbr G v Aᶜ := by
    by_cases vp : v∈P
    · exact (lp v vp ne).trans (Repair.nbr_mono G v qb)
    · have dg := degrees v vn vp (fun h => mem_compl.mp (qb h) va)
      have bal := la v va vp
      have eq := Repair.full_nbr G v A
      omega
  have right (v : V) (vn : v∈nonleaves G) (vb : v∈Aᶜ) (vq : v∉Q) : 3≤nbr G v A := by
    have dg := degrees v vn (fun h => mem_compl.mp vb (pa h)) vq
    have bal := rb v vb vq
    have eq := Repair.full_nbr G v A
    omega
  by_cases good : 2≤nbr G u Aᶜ
  · apply both G A q
    · intro v vn va
      by_cases eq : v=u
      · exact eq ▸ good
      · exact left v vn va eq
    · intro v vn vb
      by_cases vq : v∈Q
      · exact (rq v vq).trans (Repair.nbr_mono G v pa)
      · exact (show 2≤3 by decide).trans (right v vn vb vq)
  obtain ⟨j,jm⟩ := card_pos.mp one
  obtain ⟨jq,uj⟩ := mem_filter.mp jm
  have same {v : V} (uv : G.Adj u v) (vq : v∉Q) : v∈A := by
    by_contra no
    exact good (two G (a:=v) (b:=j) (fun e => vq (e ▸ jq)) uv uj (mem_compl.mpr no) (qb jq))
  have xa := same ux xq
  have ma := same um mq
  have rest : P⊆A.erase x := fun i ip => mem_erase.mpr ⟨fun e => xp (e ▸ ip),pa ip⟩
  apply both G (A.erase x) q
  · intro v vn va
    rw [compl_erase]
    by_cases eq : v=u
    · subst v
      exact two G (a:=x) (b:=j) (fun e => xq (e ▸ jq)) ux uj (mem_insert_self ..) (mem_insert_of_mem (qb jq))
    · exact (left v vn (mem_erase.mp va).2 eq).trans (Repair.nbr_mono G v (subset_insert ..))
  · intro v vn vb
    rw [compl_erase,mem_insert] at vb
    rcases vb with rfl|vb
    · exact two G um.ne ux.symm xm (rest up) (mem_erase.mpr ⟨xm.ne.symm,ma⟩)
    by_cases vq : v∈Q
    · exact (rq v vq).trans (Repair.nbr_mono G v rest)
    · have big := right v vn vb vq
      have inc : A.filter (G.Adj v)⊆insert x ((A.erase x).filter (G.Adj v)) := by
        intro i im
        by_cases e : i=x
        · exact mem_insert.mpr (Or.inl e)
        · exact mem_insert_of_mem (mem_filter.mpr ⟨mem_erase.mpr ⟨e,(mem_filter.mp im).1⟩,(mem_filter.mp im).2⟩)
      have bd := (card_le_card inc).trans (card_insert_le ..)
      change nbr G v A≤nbr G v (A.erase x)+1 at bd
      omega

end Graffiti384b.PinnedColor34
#print axioms Graffiti384b.PinnedColor34.repair
