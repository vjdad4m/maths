import Proof384b

namespace Graffiti384b.Repair
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

private def cross (a b : Finset V) : ℕ := ∑ x ∈ a, ∑ y ∈ b, if G.Adj x y then 1 else 0

omit [Fintype V] [DecidableEq V] in
private theorem cross_comm (a b : Finset V) : cross G a b = cross G b a := by
  unfold cross
  rw [Finset.sum_comm]
  apply sum_congr rfl
  intro y _
  apply sum_congr rfl
  intro x _
  by_cases ha : G.Adj x y
  · simp [ha, ha.symm]
  · have hb : ¬G.Adj y x := fun h => ha h.symm
    simp [ha, hb]

omit [Fintype V] in
private theorem cross_ins {a : Finset V} {v : V} (hv : v ∉ a) (b : Finset V) :
    cross G (insert v a) b = nbr G v b + cross G a b := by simp [cross, nbr, hv]

omit [Fintype V] in
private theorem nbr_erase_self (v : V) (s : Finset V) : nbr G v (s.erase v) = nbr G v s := by
  unfold nbr
  congr 1
  ext x
  by_cases h : x = v
  · subst x
    simp
  · simp [h]

omit [Fintype V] in
private theorem shift {a b : Finset V} {v : V} (ha : v ∈ a) (hb : v ∉ b) :
    cross G (a.erase v) (insert v b) + nbr G v b = cross G a b + nbr G v a := by
  have h := cross_ins G (not_mem_erase v a) b
  rw [insert_erase ha] at h
  rw [cross_comm G (a.erase v), cross_ins G hb, cross_comm G b, nbr_erase_self]
  omega

omit [Fintype V] in
/-- In a maximum cut of S, choose the first part as large as possible.
Moving a tied vertex from the second to the first part is then impossible. -/
theorem asymmetric_cut (s : Finset V) :
    ∃ a b : Finset V, Disjoint a b ∧ a ∪ b = s ∧
    (∀ v ∈ a, nbr G v a ≤ nbr G v b) ∧ (∀ v ∈ b, nbr G v b < nbr G v a) := by
  classical
  let f (a : Finset V) := cross G a (s \ a)
  obtain ⟨c, hc, top⟩ := exists_max_image s.powerset f ⟨∅, mem_powerset.mpr (empty_subset _)⟩
  let best := s.powerset.filter (fun a => f a = f c)
  obtain ⟨a, ha, size⟩ := exists_max_image best Finset.card ⟨c, mem_filter.mpr ⟨hc, rfl⟩⟩
  obtain ⟨has, hfa⟩ := mem_filter.mp ha
  have hsub := mem_powerset.mp has
  let b := s \ a
  have maxcut {p : Finset V} (hp : p ⊆ s) : f p ≤ f a :=
    (top p (mem_powerset.mpr hp)).trans_eq hfa.symm
  refine ⟨a, b, disjoint_sdiff, union_sdiff_of_subset hsub, ?_, ?_⟩
  · intro v hva
    have hvb : v ∉ b := fun hh => (mem_sdiff.mp hh).2 hva
    have h := maxcut ((erase_subset v a).trans hsub)
    have eq : s \ (a.erase v) = insert v b := by
      ext w
      by_cases e : w = v
      · subst w
        simp [hsub hva]
      · simp [b, e]
    change cross G _ _ ≤ cross G a b at h
    rw [eq] at h
    have hs := shift G hva hvb
    omega
  · intro v hvb
    obtain ⟨hvs, hva⟩ := mem_sdiff.mp hvb
    have hk := maxcut (insert_subset hvs hsub)
    have eq : s \ insert v a = b.erase v := by ext w; simp [b, and_left_comm, and_comm]
    have swap := shift G hvb hva
    rw [cross_comm G (b.erase v), cross_comm G b a] at swap
    have face : f (insert v a) = cross G (insert v a) (b.erase v) := by simp only [f, eq]
    have hlt : f (insert v a) < f a := by
      apply lt_of_le_of_ne hk
      intro same
      have hs := size (insert v a) (mem_filter.mpr ⟨mem_powerset.mpr (insert_subset hvs hsub), same.trans hfa⟩)
      rw [card_insert_of_not_mem hva] at hs
      omega
    rw [face] at hlt
    change _ < cross G a b at hlt
    omega

omit [Fintype V] [DecidableEq V] in
private theorem nbr_mono (v : V) {a b : Finset V} (h : a ⊆ b) :
    nbr G v a ≤ nbr G v b := card_le_card (filter_subset_filter _ h)

omit [Fintype V] in
private theorem nbr_add (v : V) {a b : Finset V} (h : Disjoint a b) :
    nbr G v (a ∪ b) = nbr G v a + nbr G v b := by
  unfold nbr
  rw [filter_union]
  exact card_union_of_disjoint (h.mono (filter_subset _ _) (filter_subset _ _))

private theorem omit_set (o : Finset V) (h : ∀ v ∈ o, 2 ≤ nbr G v oᶜ) :
    gamma G ≤ Fintype.card V - o.card := by
  have hd : TwoDominates G oᶜ := fun v hv => h v (by simpa using hv)
  simpa only [card_compl] using (Nat.sInf_le (s := {k : ℕ | ∃ d, TwoDominates G d ∧ d.card = k})
    (m := oᶜ.card) ⟨oᶜ, hd, rfl⟩)

/-- Reserve K as kept, omit X on both sides, and use a cut on S. One reserved
neighbor is enough when the cut supplies another. -/
theorem seeded_cut (x k s : Finset V) (hxk : Disjoint x k)
    (hxs : Disjoint x s) (hks : Disjoint k s)
    (hx : ∀ v ∈ x, 2 ≤ nbr G v k)
    (hs : ∀ v ∈ s, 3 ≤ nbr G v s + 2 * nbr G v k) :
    gamma G ≤ Fintype.card V - (x.card + (s.card + 1) / 2) := by
  obtain ⟨a, b, hab, hu, ha, hb⟩ := asymmetric_cut G s
  have calcSide {p q : Finset V} (hpq : Disjoint p q) (hU : p ∪ q = s)
      (hcut : ∀ v ∈ p, nbr G v p ≤ nbr G v q) :
      gamma G ≤ Fintype.card V - (x.card + p.card) := by
    have hp : p ⊆ s := hU ▸ subset_union_left
    have hq : q ⊆ s := hU ▸ subset_union_right
    have dxp := hxs.mono_right hp
    have hkq := hks.mono_right hq
    have incl : k ∪ q ⊆ (x ∪ p)ᶜ := by
      intro i hi
      apply mem_compl.mpr
      rcases mem_union.mp hi with hk | hq'
      · exact fun hm => (mem_union.mp hm).elim (fun hh => disjoint_left.mp hxk hh hk)
          (fun hh => disjoint_left.mp hks hk (hp hh))
      · exact fun hm => (mem_union.mp hm).elim (fun hh => disjoint_left.mp hxs hh (hq hq'))
          (fun hh => disjoint_left.mp hpq hh hq')
    have H := omit_set G (x ∪ p) (by
      intro v hv
      apply le_trans _ (nbr_mono G v incl)
      rw [nbr_add G v hkq]
      rcases mem_union.mp hv with h | h
      · have := hx v h
        omega
      · have ht := hs v (hp h)
        rw [← hU, nbr_add G v hpq] at ht
        have := hcut v h
        omega)
    simpa only [card_union_of_disjoint dxp] using H
  have H₁ := calcSide hab hu ha
  have H₂ := calcSide hab.symm ((union_comm b a).trans hu) (fun v hv => (hb v hv).le)
  have parts := card_union_of_disjoint hab
  rw [hu] at parts
  omega

/-- Two permanently kept vertices can support every chosen common neighbor.
Only the residual vertices with two cut-side witnesses need to vary. -/
theorem exact_of_common_seed {u w : V} (huw : u ≠ w) (x s : Finset V)
    (hx : ∀ z ∈ x, G.Adj z u ∧ G.Adj z w)
    (hxs : Disjoint x s) (hus : u ∉ s) (hws : w ∉ s)
    (hs : ∀ z ∈ s, 3 ≤ nbr G z s + 2 * nbr G z ({u,w} : Finset V))
    (ht : (types G).card ≤ 2*x.card + s.card) :
    gamma G ≤ bound G := by
  have H := seeded_cut G x {u,w} s (by
    apply disjoint_left.mpr
    intro z hz hh
    obtain ⟨h₁,h₂⟩ := hx z hz
    rcases mem_insert.mp hh with rfl | h
    · exact h₁.ne rfl
    · exact h₂.ne (mem_singleton.mp h))
    hxs (by simpa [disjoint_insert_left] using And.intro hus hws)
    (by
      intro z hz
      obtain ⟨h₁,h₂⟩ := hx z hz
      have eh : ({u,w} : Finset V).filter (G.Adj z) = {u,w} := by
        apply filter_true_of_mem
        intro i hi
        rcases mem_insert.mp hi with rfl | hi
        · exact h₁
        · simpa only [mem_singleton.mp hi] using h₂
      simp [nbr, eh, huw]) hs
  unfold bound
  omega

/-- A hub can remain kept for cuts with only one opposite neighbor per vertex. -/
theorem hub_bound {v : V} (s : Finset V) (hN : s ⊆ G.neighborFinset v)
    (hd : ∀ z ∈ s, 1 ≤ nbr G z s) :
    gamma G ≤ Fintype.card V - (s.card + 1) / 2 := by
  have hv : v ∉ s := fun h => G.not_mem_neighborFinset_self v (hN h)
  have h := seeded_cut G ∅ {v} s (by simp) (by simp) (by simpa using hv)
    (by simp) (by
      intro z hz
      have ha := ((G.mem_neighborFinset _ _).mp (hN hz)).symm
      have one : nbr G z {v} = 1 := by simp [nbr, filter_singleton, ha]
      have := hd z hz
      omega)
  simpa using h

/-- If the link has minimum degree two, the hub supplies one extra unit
in the sum of the two omission-set sizes. -/
theorem hub_bonus {v : V} (s : Finset V) (hN : s ⊆ G.neighborFinset v)
    (hs : 2 ≤ s.card) (hd : ∀ z ∈ s, 2 ≤ nbr G z s) :
    gamma G ≤ Fintype.card V - (s.card + 2) / 2 := by
  obtain ⟨a,b,hab,hu,ha,hb⟩ := asymmetric_cut G s
  have hA : a ⊆ s := hu ▸ subset_union_left
  have hB : b ⊆ s := hu ▸ subset_union_right
  have hv : v ∉ s := fun h => G.not_mem_neighborFinset_self v (hN h)
  have nd (z : V) (hz : z ∈ s) : 2 ≤ nbr G z a + nbr G z b := by
    simpa only [← hu, nbr_add G z hab] using hd z hz
  have strong (z : V) (hz : z ∈ b) : 2 ≤ nbr G z a := by
    have := nd z (hB hz)
    have := hb z hz
    omega
  have hsize : 2 ≤ a.card := by
    rcases b.eq_empty_or_nonempty with h | ⟨z,hz⟩
    · simpa [← hu, h] using hs
    · exact (strong z hz).trans (card_filter_le _ _)
  have va : v ∉ a := fun h => hv (hA h)
  have vb : v ∉ b := fun h => hv (hB h)
  have dis : Disjoint ({v} : Finset V) b := by simpa using vb
  have oa := omit_set G a (by
    intro z hz
    have hn := nd z (hA hz)
    have cut := ha z hz
    have adj := ((G.mem_neighborFinset _ _).mp (hN (hA hz))).symm
    have one : nbr G z {v} = 1 := by simp [nbr, filter_singleton, adj]
    have incl : {v} ∪ b ⊆ aᶜ := by
      refine union_subset ?_ (fun i hi => mem_compl.mpr (fun hit => disjoint_left.mp hab hit hi))
      simpa using va
    have H := nbr_mono G z incl
    rw [nbr_add G z dis] at H
    omega)
  have ob := omit_set G (insert v b) (by
    intro z hz
    have incl : a ⊆ (insert v b)ᶜ := by
      intro i hi
      exact mem_compl.mpr (fun h => (mem_insert.mp h).elim (fun e => va (e ▸ hi))
        (fun h' => disjoint_left.mp hab hi h'))
    apply le_trans _ (nbr_mono G z incl)
    rcases mem_insert.mp hz with rfl | hz
    · have e : a.filter (G.Adj z) = a := filter_true_of_mem (fun i hi =>
        (G.mem_neighborFinset _ _).mp (hN (hA hi)))
      simpa [nbr, e] using hsize
    · exact strong _ hz)
  rw [card_insert_of_not_mem vb] at ob
  have H := card_union_of_disjoint hab
  rw [hu] at H
  omega

private def linkEdges (v : V) :=
  ((G.neighborFinset v).powersetCard 2).filter
    (fun p => ∀ x ∈ p, ∀ y ∈ p, x ≠ y → G.Adj x y)

/-- The vertices occurring with v in at least one triangle. -/
def linkSupport (v : V) := (linkEdges G v).biUnion id

private theorem edge_info {v : V} {p : Finset V} (hp : p ∈ linkEdges G v) :
    p ⊆ G.neighborFinset v ∧ p.card = 2 ∧ ∀ x ∈ p, ∀ y ∈ p, x ≠ y → G.Adj x y := by
  obtain ⟨hs,h⟩ := mem_filter.mp hp
  exact ⟨(mem_powersetCard.mp hs).1, (mem_powersetCard.mp hs).2,h⟩

private theorem support_sub (v : V) : linkSupport G v ⊆ G.neighborFinset v := by
  intro x hx
  obtain ⟨p, hp, hxp⟩ := mem_biUnion.mp hx
  exact (edge_info G hp).1 hxp

private theorem support_pos {v x : V} (hx : x ∈ linkSupport G v) :
    1 ≤ nbr G x (linkSupport G v) := by
  obtain ⟨p, hp, hxp⟩ := mem_biUnion.mp hx
  obtain ⟨_, hn, complete⟩ := edge_info G hp
  obtain ⟨y, hy, hne⟩ := exists_ne_of_one_lt_card (by omega : 1 < p.card) x
  exact card_pos.mpr ⟨y, mem_filter.mpr ⟨mem_biUnion.mpr ⟨p,hp,hy⟩,complete _ hxp _ hy hne.symm⟩⟩

private theorem edge_fiber {v x : V} (hx : x ∈ linkSupport G v) :
    ((linkEdges G v).filter (fun p => x ∈ p)).card = nbr G x (linkSupport G v) := by
  let n := (linkSupport G v).filter (G.Adj x)
  have hn (y : V) (hy : y ∈ n) := (mem_filter.mp hy).2
  have eq : (linkEdges G v).filter (fun p => x ∈ p) = n.image (fun y => {x,y}) := by
    ext p
    constructor
    · intro h
      obtain ⟨hp,hxp⟩ := mem_filter.mp h
      obtain ⟨_, hc, complete⟩ := edge_info G hp
      obtain ⟨y,hy,hyx⟩ := exists_ne_of_one_lt_card (by omega : 1 < p.card) x
      have hxy := complete _ hxp _ hy hyx.symm
      refine mem_image.mpr ⟨y, mem_filter.mpr ⟨mem_biUnion.mpr ⟨p,hp,hy⟩,hxy⟩, ?_⟩
      exact eq_of_subset_of_card_le (insert_subset hxp (singleton_subset_iff.mpr hy)) (by simp [hc, hyx.symm])
    · intro h
      obtain ⟨y,hy,rfl⟩ := mem_image.mp h
      have hxy := hn y hy
      have hxN := support_sub G v hx
      have hyN := support_sub G v (mem_filter.mp hy).1
      apply mem_filter.mpr
      refine ⟨mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset hxN (singleton_subset_iff.mpr hyN),
        by simp [hxy.ne]⟩, ?_⟩, mem_insert_self _ _⟩
      intro i hi j hj hij
      simp only [mem_insert, mem_singleton] at hi hj
      rcases hi with rfl | rfl <;> rcases hj with rfl | rfl <;> first | exact (hij rfl).elim | exact hxy | exact hxy.symm
  rw [eq]
  apply card_image_of_injOn
  intro y hy z hz e
  have hey := congrArg (fun p : Finset V => p.erase x) e
  simpa [(hn y hy).ne.symm, (hn z hz).ne.symm, (hn y hy).ne, (hn z hz).ne] using hey

private theorem link_sum (v : V) :
    ∑ x ∈ linkSupport G v, nbr G x (linkSupport G v) = 2 * trianglesAt G v := by
  calc
    _ = ∑ x ∈ linkSupport G v, ∑ p ∈ linkEdges G v, (if x ∈ p then 1 else 0 : ℕ) := by
      apply sum_congr rfl
      intro x hx
      simp only [Finset.sum_boole, edge_fiber G hx, Nat.cast_id]
    _ = ∑ p ∈ linkEdges G v, ∑ x ∈ linkSupport G v, (if x ∈ p then 1 else 0 : ℕ) := sum_comm
    _ = ∑ _p ∈ linkEdges G v, 2 := by
      apply sum_congr rfl
      intro p hp
      rw [Finset.sum_boole]
      have eq : (linkSupport G v).filter (fun x => x ∈ p) = p := by
        ext x
        exact ⟨fun h => (mem_filter.mp h).2, fun h => mem_filter.mpr ⟨mem_biUnion.mpr ⟨p,hp,h⟩,h⟩⟩
      simp only [eq, (edge_info G hp).2.1, Nat.cast_id]
    _ = _ := by simp [trianglesAt, linkEdges, Nat.mul_comm]

/-- It suffices that a vertex of maximum triangle count has at most two
triangles on each of its incident edges. There is no restriction elsewhere. -/
theorem exact_of_thin_maximizer (hc : G.Connected) (hn : 2 < Fintype.card V)
    (v : V) (hmax : ∀ u, trianglesAt G u ≤ trianglesAt G v)
    (hthin : ∀ x ∈ G.neighborFinset v, nbr G x (G.neighborFinset v) ≤ 2) :
    gamma G ≤ bound G := by
  by_cases small : (types G).card ≤ 4
  · exact exact_of_at_most_four G hc hn small
  have sub : types G ⊆ range (trianglesAt G v + 1) := by
    intro t ht
    obtain ⟨u,_,rfl⟩ := mem_image.mp ht
    exact mem_range.mpr (Nat.lt_succ_of_le (hmax u))
  have ht := card_le_card sub
  rw [card_range] at ht
  let s := linkSupport G v
  have hN : s ⊆ G.neighborFinset v := support_sub G v
  have upper (x : V) (hx : x ∈ s) : nbr G x s ≤ 2 := (nbr_mono G x hN).trans (hthin x (hN hx))
  have sum := link_sum G v
  change ∑ x ∈ s, nbr G x s = _ at sum
  have hsum := Finset.sum_le_sum (s := s) (g := fun _ => 2) upper
  simp only [sum_const, Nat.nsmul_eq_mul] at hsum
  by_cases plenty : (types G).card ≤ s.card
  · have h := hub_bound G s hN (fun _ hx => support_pos G hx)
    unfold bound
    omega
  · have eqdeg (x : V) (hx : x ∈ s) : 2 ≤ nbr G x s := by
      by_contra! h
      have lt := Finset.sum_lt_sum (s := s) (g := fun _ => 2) upper ⟨x,hx,h⟩
      simp only [sum_const, Nat.nsmul_eq_mul] at lt
      omega
    have h := hub_bonus G s hN (by omega) eqdeg
    unfold bound
    omega

/-- For every adjacent pair, their common neighbors are precisely the third
vertices of triangles on that edge. -/
theorem exact_of_at_most_two_triangles_per_edge (hc : G.Connected) (hn : 2 < Fintype.card V)
    (h : ∀ v x, G.Adj v x → nbr G x (G.neighborFinset v) ≤ 2) :
    gamma G ≤ bound G := by
  obtain ⟨v,_,hv⟩ := exists_max_image univ (trianglesAt G) (univ_nonempty_iff.mpr hc.nonempty)
  exact exact_of_thin_maximizer G hc hn v (fun u => hv u (mem_univ u))
    (fun x hx => h v x ((G.mem_neighborFinset v x).mp hx))

private def Feasible (o : Finset V) := ∀ z ∈ o, 2 ≤ nbr G z oᶜ

private theorem full_nbr (z : V) (a : Finset V) :
    nbr G z a + nbr G z aᶜ = G.degree z := by
  rw [← nbr_add G z disjoint_compl_right, Finset.union_compl]
  have eq : univ.filter (G.Adj z) = G.neighborFinset z := by ext; simp
  simp [nbr, eq]

private theorem augment {o : Finset V} {w : V} (ho : ∀ z ∈ o, 3 ≤ nbr G z oᶜ)
    (hw : 2 ≤ nbr G w oᶜ) : Feasible G (insert w o) := by
  intro z hz
  rw [compl_insert]
  rcases mem_insert.mp hz with rfl | h
  · exact (nbr_erase_self G _ _).ge.trans' hw
  · have inc : oᶜ.filter (G.Adj z) ⊆ insert w ((oᶜ.erase w).filter (G.Adj z)) := by
      intro u hu
      by_cases e : u = w
      · exact mem_insert.mpr (Or.inl e)
      · obtain ⟨ha,hb⟩ := mem_filter.mp hu
        exact mem_insert_of_mem (mem_filter.mpr ⟨mem_erase.mpr ⟨e,ha⟩,hb⟩)
    have h₁ := card_le_card inc
    have h₂ := card_insert_le w ((oᶜ.erase w).filter (G.Adj z))
    have h₃ := ho z h
    unfold nbr at *
    omega

private theorem triangles_le_choose (v : V) :
    trianglesAt G v ≤ (G.degree v).choose 2 := by
  have h := card_filter_le ((G.neighborFinset v).powersetCard 2)
    (fun p => ∀ a ∈ p, ∀ b ∈ p, a ≠ b → G.Adj a b)
  simpa only [card_powersetCard,card_neighborFinset_eq_degree,trianglesAt] using h

/-- If all but at most one neighbor of v are in a matching plus isolated
vertices, count its link degrees on and off that matching. -/
private theorem sparse_triangle_bound (v : V) (b : Finset V) (hv : nbr G v bᶜ ≤ 1)
    (hb : ∀ z ∈ b, nbr G z b ≤ 1) : 2 * trianglesAt G v ≤ 3 * b.card := by
  let s := linkSupport G v
  let p := s \ b
  let q := s ∩ b
  have dq : Disjoint p q := by
    apply disjoint_left.mpr
    intro z hp hq
    exact (mem_sdiff.mp hp).2 (mem_inter.mp hq).2
  have hu : p ∪ q = s := by ext z; simp [p,q]; tauto
  have hq : q ⊆ b := inter_subset_right
  have cp : p.card ≤ 1 := by
    apply le_trans _ hv
    apply card_le_card
    intro z hz
    obtain ⟨h,hh⟩ := mem_sdiff.mp hz
    exact mem_filter.mpr ⟨mem_compl.mpr hh,(G.mem_neighborFinset _ _).mp (support_sub G v h)⟩
  have onp (z : V) (hz : z ∈ p) : nbr G z s ≤ q.card := by
    have none : p.filter (G.Adj z) = ∅ := by
      apply filter_eq_empty_iff.mpr
      intro u h
      have := card_le_one.mp cp z hz u h
      exact fun adj => adj.ne this
    rw [← hu, nbr_add G z dq]
    simp only [nbr, none, card_empty, zero_add]
    exact card_filter_le _ _
  have onq (z : V) (hz : z ∈ q) : nbr G z s ≤ 2 := by
    have h₁ := (nbr_mono G z hq).trans (hb z (hq hz))
    have h₂ : nbr G z p ≤ p.card := card_filter_le _ _
    rw [← hu, nbr_add G z dq]
    omega
  have sp := sum_le_sum (s := p) (g := fun _ => q.card) onp
  have sq := sum_le_sum (s := q) (g := fun _ => 2) onq
  simp only [sum_const, Nat.nsmul_eq_mul] at sp sq
  have small : p.card * q.card ≤ q.card := by simpa using Nat.mul_le_mul_right q.card cp
  have total := link_sum G v
  change ∑ z ∈ s, nbr G z s = _ at total
  conv_lhs at total => enter [1]; rw [← hu]
  rw [sum_union dq] at total
  have hqb := card_le_card hq
  omega

/-- When the high vertices come in an even number, degree four supplies a
unit of slack on the strict side. Failure of both one-vertex augmentations
would force both high color classes to induce matchings. -/
theorem exact_even_high_of_cubic_neighbor (hc : G.Connected) (hn : 2 < Fintype.card V)
    (m : ℕ) (he : (high G).card = 2*m)
    (hcub : ∀ z, G.degree z = 3 → 1 ≤ nbr G z (high G)ᶜ) :
    gamma G ≤ bound G := by
  by_cases small : (types G).card ≤ 4
  · exact exact_of_at_most_four G hc hn small
  have ht := type_bound G
  by_contra! failure
  have limit (o : Finset V) (ho : Feasible G o) : o.card ≤ m := by
    have := omit_set G o ho
    unfold bound at failure
    omega
  obtain ⟨a,b,dis,un,ha,hb⟩ := asymmetric_cut G (high G)
  have hA : a ⊆ high G := un ▸ subset_union_left
  have hB : b ⊆ high G := un ▸ subset_union_right
  have ab : a ⊆ bᶜ := fun z hz => mem_compl.mpr (disjoint_left.mp dis hz)
  have ba : b ⊆ aᶜ := fun z hz => mem_compl.mpr (fun h => disjoint_left.mp dis h hz)
  have lowDisA : Disjoint a (high G)ᶜ := disjoint_left.mpr (fun _ ha' hl => mem_compl.mp hl (hA ha'))
  have eqBA : a ∪ (high G)ᶜ = bᶜ := by
    ext z
    simp only [← un, mem_union, mem_compl]
    have hh : z ∈ a → z ∉ b := fun h => disjoint_left.mp dis h
    tauto
  have splitLow (z : V) : nbr G z bᶜ = nbr G z a + nbr G z (high G)ᶜ := by
    rw [← eqBA, nbr_add G z lowDisA]
  have okA : Feasible G a := by
    intro z hz
    have H := full_nbr G z a
    have := (ha z hz).trans (nbr_mono G z ba)
    have hh : 3 ≤ G.degree z := (mem_filter.mp (hA hz)).2
    omega
  have safeB (z : V) (hz : z ∈ b) : 3 ≤ nbr G z bᶜ := by
    have H := full_nbr G z b
    have := (hb z hz).trans_le (nbr_mono G z ab)
    have h₃ : 3 ≤ G.degree z := (mem_filter.mp (hB hz)).2
    by_cases e : G.degree z = 3
    · have := hcub z e
      have := splitLow z
      have := hb z hz
      omega
    · omega
  have ca := limit a okA
  have cb := limit b (fun z hz => by have := safeB z hz; omega)
  have parts := card_union_of_disjoint dis
  rw [un,he] at parts
  have smallA (w : V) (hw : w ∈ a) : nbr G w bᶜ ≤ 1 := by
    apply Nat.le_of_not_gt
    intro H
    have hh := limit _ (augment G safeB H)
    rw [card_insert_of_not_mem (disjoint_left.mp dis hw)] at hh
    omega
  have safeA (z : V) (hz : z ∈ a) : 3 ≤ nbr G z aᶜ := by
    have := smallA z hz
    have := full_nbr G z b
    have h₃ : 3 ≤ G.degree z := (mem_filter.mp (hA hz)).2
    have := nbr_mono G z ba
    by_cases e : G.degree z = 3
    · have := hcub z e
      have := splitLow z
      have := full_nbr G z a
      omega
    · omega
  have smallB (w : V) (hw : w ∈ b) : nbr G w aᶜ ≤ 1 := by
    apply Nat.le_of_not_gt
    intro H
    have hh := limit _ (augment G safeA H)
    rw [card_insert_of_not_mem (fun h => disjoint_left.mp dis h hw)] at hh
    omega
  have sub : types G ⊆ range (2*m) := by
    intro t ht'
    obtain ⟨v,_,rfl⟩ := mem_image.mp ht'
    apply mem_range.mpr
    by_cases va : v ∈ a
    · have := sparse_triangle_bound G v b (smallA v va)
          (fun z hz => (nbr_mono G z ba).trans (smallB z hz))
      omega
    by_cases vb : v ∈ b
    · have := sparse_triangle_bound G v a (smallB v vb)
          (fun z hz => (nbr_mono G z ab).trans (smallA z hz))
      omega
    have low : ¬3 ≤ G.degree v := fun h => (mem_union.mp (un ▸ (mem_filter.mpr ⟨mem_univ _,h⟩ :
      v ∈ high G))).elim va vb
    have H := (triangles_le_choose G v).trans (Nat.choose_le_choose 2 (show G.degree v ≤ 2 by omega))
    simp only [Nat.choose_self] at H
    omega
  have size := card_le_card sub
  rw [card_range] at size
  have hi := high_bound G
  unfold bound at failure
  omega

/-- The original maximum-cut criterion handles odd h automatically when t is even. -/
theorem exact_even_types_of_cubic_neighbor (hc : G.Connected) (hn : 2 < Fintype.card V)
    (he : (types G).card % 2 = 0)
    (hcub : ∀ z, G.degree z = 3 → 1 ≤ nbr G z (high G)ᶜ) : gamma G ≤ bound G := by
  by_cases even : (high G).card % 2 = 0
  · exact exact_even_high_of_cubic_neighbor G hc hn ((high G).card / 2) (by omega) hcub
  · apply exact_of_high G
    have := type_bound G
    omega

theorem exact_even_high_no_degree_three (hc : G.Connected) (hn : 2 < Fintype.card V)
    (m : ℕ) (he : (high G).card = 2*m) (h₄ : ∀ z ∈ high G, 4 ≤ G.degree z) :
    gamma G ≤ bound G := by
  apply exact_even_high_of_cubic_neighbor G hc hn m he
  intro z hz
  have := h₄ z (mem_filter.mpr ⟨mem_univ z, hz.ge⟩)
  omega

/-- For a set of pairwise nonadjacent low nonleaves, reserve their high
neighbors. Each repeated high neighbor saves one place in the two cuts. -/
theorem exact_of_low_support (x : Finset V) (low : Disjoint x (high G))
    (nonleaf : ∀ v ∈ x, 2 ≤ G.degree v)
    (indep : ∀ v ∈ x, ∀ w ∈ x, ¬G.Adj v w)
    (ht : (types G).card + ((high G).filter (fun z => ∃ v ∈ x, G.Adj v z)).card ≤
      (high G).card + 2*x.card) : gamma G ≤ bound G := by
  let r := (high G).filter (fun z => ∃ v ∈ x, G.Adj v z)
  let s := high G \ r
  let k := (x ∪ s)ᶜ
  have sh : s ⊆ high G := sdiff_subset
  have xs := low.mono_right sh
  have xk : Disjoint x k := disjoint_left.mpr (fun _ h₁ h₂ => mem_compl.mp h₂ (mem_union_left _ h₁))
  have ks : Disjoint k s := disjoint_left.mpr (fun _ h₁ h₂ => mem_compl.mp h₁ (mem_union_right _ h₂))
  have adjxs {v z : V} (hv : v ∈ x) (hz : z ∈ s) : ¬G.Adj v z := by
    intro a
    exact (mem_sdiff.mp hz).2 (mem_filter.mpr ⟨sh hz,v,hv,a⟩)
  have kU : s ∪ k = xᶜ := by
    ext i
    simp only [k,mem_union,mem_compl]
    have hh : i ∈ x → i ∉ s := fun h => disjoint_left.mp xs h
    tauto
  have full (v : V) (h : ∀ z ∈ x, ¬G.Adj v z) : nbr G v xᶜ = G.degree v := by
    have eq : x.filter (G.Adj v) = ∅ := filter_eq_empty_iff.mpr h
    have := full_nbr G v x
    simpa only [nbr,eq,card_empty,zero_add] using this
  have H := seeded_cut G x k s xk xs ks (by
    intro v hv
    have e : s.filter (G.Adj v) = ∅ := filter_eq_empty_iff.mpr (fun _ hz => adjxs hv hz)
    have h := full v (indep v hv)
    rw [← kU, nbr_add G v ks.symm] at h
    simp only [nbr,e,card_empty,zero_add] at h
    exact (nonleaf v hv).trans_eq h.symm)
    (by
      intro v hv
      have h := full v (fun z hz hadj => adjxs hz hv hadj.symm)
      rw [← kU, nbr_add G v ks.symm] at h
      have h₃ := (mem_filter.mp (sh hv)).2
      omega)
  have size : s.card + r.card = (high G).card := card_sdiff_add_card_eq_card (filter_subset _ _)
  change (types G).card + r.card ≤ _ at ht
  unfold bound
  omega

omit [Fintype V] in
private theorem lose (v : V) (s y : Finset V) :
    nbr G v s ≤ nbr G v (s \ y) + y.card := by
  have h : Disjoint (s \ y) (s ∩ y) := disjoint_left.mpr
    (fun _ ha hb => (mem_sdiff.mp ha).2 (mem_inter.mp hb).2)
  have eq : (s \ y) ∪ (s ∩ y) = s := by ext; simp; tauto
  have H := nbr_add G v h
  rw [eq] at H
  have hb : nbr G v (s ∩ y) ≤ y.card := (card_filter_le _ _).trans (card_le_card inter_subset_right)
  omega

omit [Fintype V] in
private theorem lose_one (v w : V) (s : Finset V) : nbr G v s ≤ nbr G v (s.erase w) + 1 := by
  simpa [sdiff_singleton_eq_erase] using lose G v s {w}

private theorem add_many {o y : Finset V} (h : ∀ v ∈ o, 2 + y.card ≤ nbr G v oᶜ)
    (hy : ∀ v ∈ y, 2 ≤ nbr G v (oᶜ \ y)) : Feasible G (o ∪ y) := by
  intro v hv
  have e : (o ∪ y)ᶜ = oᶜ \ y := by ext; simp
  rw [e]
  rcases mem_union.mp hv with ho | ho
  · have := h v ho
    have := lose G v oᶜ y
    omega
  · exact hy _ ho

private theorem room_for_pair {o : Finset V} {x z : V} (ne : x ≠ z)
    (safe : ∀ v ∈ o, 4 ≤ nbr G v oᶜ)
    (hx : 2 ≤ nbr G x (oᶜ.erase z)) (hz : 2 ≤ nbr G z (oᶜ.erase x)) :
    Feasible G (o ∪ {x,z}) := by
  apply add_many G (by simpa [ne] using safe)
  intro v hv
  have e : oᶜ \ {x,z} = (oᶜ.erase z).erase x := by ext; simp [and_comm,and_left_comm,and_assoc]
  rw [e]
  rcases mem_insert.mp hv with rfl | h
  · simpa [nbr_erase_self] using hx
  · obtain rfl := mem_singleton.mp h
    rw [erase_right_comm,nbr_erase_self]
    exact hz

private theorem three_common {o s : Finset V} {a b : V} (ne : a ≠ b) (ds : Disjoint o s)
    (ao : a ∉ o) (bo : b ∉ o) (safe : ∀ z ∈ o, 5 ≤ nbr G z oᶜ)
    (maxO : ∀ u, Feasible G u → u.card ≤ o.card + 2) :
    (s.filter (fun z => G.Adj a z ∧ G.Adj b z)).card ≤ 2 := by
  classical
  apply Nat.le_of_not_gt
  intro hit
  obtain ⟨y, sub, cy⟩ := exists_subset_card_eq (Nat.succ_le_of_lt hit)
  have dy := ds.mono_right (sub.trans (filter_subset _ _))
  have hr {z : V} (hz : z ∈ y) := (mem_filter.mp (sub hz)).2
  have ay : a ∉ y := fun h => (hr h).1.ne rfl
  have by' : b ∉ y := fun h => (hr h).2.ne rfl
  have hmax := maxO _ (add_many G (y := y) (by simpa [cy] using safe) (by
    intro z hz
    have both : ({a,b} : Finset V) ⊆ (oᶜ \ y).filter (G.Adj z) := by
      refine insert_subset (mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_compl.mpr ao,ay⟩,(hr hz).1.symm⟩) ?_
      exact singleton_subset_iff.mpr (mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_compl.mpr bo,by'⟩,(hr hz).2.symm⟩)
    simpa [nbr,ne] using card_le_card both))
  rw [card_union_of_disjoint dy,cy] at hmax
  omega

/-- Remove the edges at a single vertex, keeping the ambient type fixed. -/
private def isolate (x : V) : SimpleGraph V where
  Adj v w := G.Adj v w ∧ v ≠ x ∧ w ≠ x
  symm := by rintro v w ⟨a,b,c⟩; exact ⟨a.symm,c,b⟩
  loopless := fun v h => h.1.ne rfl

private instance (x : V) : DecidableRel (isolate G x).Adj :=
  fun v w => inferInstanceAs (Decidable (G.Adj v w ∧ v ≠ x ∧ w ≠ x))

omit [Fintype V] in
private theorem iso_nbr {v x : V} (ne : v ≠ x) (s : Finset V) :
    nbr (isolate G x) v s = nbr G v (s.erase x) := by
  unfold nbr
  congr 1
  ext z
  simp [isolate,ne,and_comm,and_left_comm,and_assoc]

private theorem prec_triangle {v x : V} (ne : v ≠ x) :
    trianglesAt G v ≤ trianglesAt (isolate G x) v + nbr G v (G.neighborFinset x) := by
  classical
  let e := linkEdges G v
  have rem : e.filter (fun p => x ∉ p) = linkEdges (isolate G x) v := by
    ext p
    simp only [e,linkEdges,mem_filter,mem_powersetCard,subset_iff,mem_neighborFinset]
    change (((∀ a ∈ p, G.Adj v a) ∧ p.card = 2) ∧ _) ∧ x ∉ p ↔
      ((∀ a ∈ p, G.Adj v a ∧ v ≠ x ∧ a ≠ x) ∧ p.card = 2) ∧
        (∀ a ∈ p, ∀ b ∈ p, a ≠ b → G.Adj a b ∧ a ≠ x ∧ b ≠ x)
    constructor
    · rintro ⟨⟨⟨hs,hs₂⟩,hp⟩,hn⟩
      exact ⟨⟨fun a ha => ⟨hs a ha, ne, fun ee => hn (ee ▸ ha)⟩,hs₂⟩,
        fun a ha b hb h => ⟨hp a ha b hb h,fun ee => hn (ee ▸ ha),fun ee => hn (ee ▸ hb)⟩⟩
    · rintro ⟨⟨hs,hs₂⟩,hp⟩
      exact ⟨⟨⟨fun a ha => (hs a ha).1,hs₂⟩, fun a ha b hb h => (hp a ha b hb h).1⟩,
        fun hx => (hs x hx).2.2 rfl⟩
  have split := filter_card_add_filter_neg_card_eq_card (s := e) (fun p => x ∈ p)
  rw [rem] at split
  have contain : (e.filter (fun p => x ∈ p)).card ≤ nbr G v (G.neighborFinset x) := by
    by_cases hs : x ∈ linkSupport G v
    · rw [show (e.filter (fun p => x ∈ p)).card = _ from edge_fiber G hs]
      have eq : nbr G x (G.neighborFinset v) = nbr G v (G.neighborFinset x) := by
        unfold nbr
        congr 1
        ext z
        simp [and_comm]
      exact (nbr_mono G x (support_sub G v)).trans_eq eq
    · have none : e.filter (fun p => x ∈ p) = ∅ := filter_eq_empty_iff.mpr
          (fun p hp hh => hs (mem_biUnion.mpr ⟨p,hp,hh⟩))
      simp [none]
  change e.card ≤ (linkEdges (isolate G x) v).card + _
  omega

omit [Fintype V] in
private theorem small_after_erase {x v : V} (s : Finset V) (hxs : x ∈ s) (h : 2 ≤ nbr G v (s.erase x))
    (hm : nbr G v s ≤ nbr G x s) : 2 ≤ nbr G x (s.erase v) := by
  by_cases he : G.Adj x v ∧ x ∈ s
  · obtain ⟨ha,hx⟩ := he
    have e : s.filter (G.Adj v) = insert x ((s.erase x).filter (G.Adj v)) := by
      ext w
      by_cases hw : w = x
      · subst w; simp [hx,ha.symm]
      · simp [hw]
    have missing : x ∉ (s.erase x).filter (G.Adj v) := by simp
    have inc : nbr G v s = nbr G v (s.erase x) + 1 := by
      unfold nbr
      rw [e,card_insert_of_not_mem missing]
    have := lose_one G x v s
    omega
  · by_cases ha : G.Adj x v
    · have hx : x ∉ s := fun hi => he ⟨ha,hi⟩
      exact (hx hxs).elim
    · have e : (s.erase v).filter (G.Adj x) = s.filter (G.Adj x) := by
        ext w
        by_cases eq : w = v
        · subst w; simp [ha]
        · simp [eq]
      have hh := nbr_mono G v (erase_subset x s)
      simpa only [nbr,e] using (h.trans (hh.trans hm))

private theorem common_split (x v : V) (s : Finset V)
    (h : (s.filter (fun z => G.Adj x z ∧ G.Adj v z)).card ≤ 2)
    (h' : nbr G v (sᶜ.erase x) ≤ 1) : nbr G v (G.neighborFinset x) ≤ 3 := by
  let a := s.filter (fun z => G.Adj x z ∧ G.Adj v z)
  let b := (sᶜ.erase x).filter (G.Adj v)
  have sub : (G.neighborFinset x).filter (G.Adj v) ⊆ a ∪ b := by
    intro z hz
    obtain ⟨hh,hv⟩ := mem_filter.mp hz
    have hx := (G.mem_neighborFinset _ _).mp hh
    by_cases hs : z ∈ s
    · exact mem_union_left _ (mem_filter.mpr ⟨hs,hx,hv⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨mem_erase.mpr ⟨hx.ne.symm,mem_compl.mpr hs⟩,hv⟩)
  have := (card_le_card sub).trans (card_union_le a b)
  change a.card ≤ 2 at h
  change b.card ≤ 1 at h'
  unfold nbr
  omega

private theorem odd_cut_impossible (m : ℕ) (p q : Finset V) (dp : Disjoint p q)
    (hU : p ∪ q = high G) (cp : p.card = m+1) (cq : q.card = m)
    (large : 4 < (types G).card) (many : 2*m+3 ≤ (types G).card)
    (h₆ : ∀ z ∈ high G, 6 ≤ G.degree z) (lim : ∀ o, Feasible G o → o.card ≤ m+1)
    (safeP : ∀ z ∈ p, 3 ≤ nbr G z pᶜ) : False := by
  classical
  have pH : p ⊆ high G := hU ▸ subset_union_left
  have qH : q ⊆ high G := hU ▸ subset_union_right
  have pq : p ⊆ qᶜ := fun z hz => mem_compl.mpr (disjoint_left.mp dp hz)
  have sparseQ (z : V) (hz : z ∈ q) : nbr G z pᶜ ≤ 1 := by
    apply Nat.le_of_not_gt
    intro hh
    have H := lim _ (augment G safeP hh)
    rw [card_insert_of_not_mem (fun h => disjoint_left.mp dp h hz),cp] at H
    omega
  have safeQ (z : V) (hz : z ∈ q) : 5 ≤ nbr G z qᶜ := by
    have := full_nbr G z p
    have := sparseQ z hz
    have := h₆ z (qH hz)
    have := nbr_mono G z pq
    omega
  have hpnon : p.Nonempty := card_pos.mp (by omega)
  obtain ⟨x,hx,hbest⟩ := exists_max_image p (fun z => nbr G z qᶜ) hpnon
  have sparseP (v : V) (hv : v ∈ p.erase x) : nbr G v (qᶜ.erase x) ≤ 1 := by
    obtain ⟨ne,hvp⟩ := mem_erase.mp hv
    apply Nat.le_of_not_gt
    intro hh
    have hs := small_after_erase G qᶜ (pq hx) hh (hbest v hvp)
    have hpq' : Disjoint q ({x,v} : Finset V) := by
      apply disjoint_left.mpr
      intro u hu huv
      rcases mem_insert.mp huv with rfl | h
      · exact disjoint_left.mp dp hx hu
      · obtain rfl := mem_singleton.mp h
        exact disjoint_left.mp dp hvp hu
    have H := lim _ (room_for_pair G ne.symm (fun z hz => by have := safeQ z hz; omega) hs hh)
    rw [card_union_of_disjoint hpq',cq] at H
    simp [ne.symm] at H
  have cp' : (p.erase x).card = m := by rw [card_erase_of_mem hx,cp]; omega
  have sharedQ (w : V) (hw : w ∈ p.erase x) :
      (q.filter (fun z => G.Adj x z ∧ G.Adj w z)).card ≤ 2 := by
    obtain ⟨ne,hwp⟩ := mem_erase.mp hw
    let o := (p.erase x).erase w
    have op : o ⊆ p.erase x := erase_subset _ _
    have os : o ⊆ qᶜ.erase x := fun z hz => mem_erase.mpr
      ⟨(mem_erase.mp (op hz)).1, pq ((erase_subset _ _) (op hz))⟩
    have co : o.card = m-1 := by simp only [o,card_erase_of_mem hw,cp']
    apply three_common G (o := o) ne.symm (dp.mono_left (op.trans (erase_subset _ _)))
      (fun h => not_mem_erase x p (op h)) (not_mem_erase _ _)
    · intro z hz
      have := (nbr_mono G z os).trans (sparseP z (op hz))
      have := full_nbr G z o
      have := h₆ z (pH ((erase_subset _ _) (op hz)))
      omega
    · intro u hu
      have := lim u hu
      omega
  have sharedP (w : V) (hw : w ∈ q) :
      (p.filter (fun z => G.Adj x z ∧ G.Adj w z)).card ≤ 2 := by
    let o := q.erase w
    have oq : o ⊆ q := erase_subset _ _
    have ne : x ≠ w := fun e => disjoint_left.mp dp (e ▸ hx) hw
    apply three_common G (o := o) ne (dp.symm.mono_left oq)
      (fun h => disjoint_left.mp dp hx (oq h)) (not_mem_erase _ _)
    · intro z hz
      exact (safeQ z (oq hz)).trans (nbr_mono G z (fun _ h => mem_compl.mpr
        (fun h' => mem_compl.mp h (oq h'))))
    · intro u hu
      have := lim u hu
      have co : o.card = m-1 := by rw [card_erase_of_mem hw,cq]
      omega
  have mpos : 0 < m := by
    have h := type_bound G
    rw [← hU,card_union_of_disjoint dp,cp,cq] at h
    omega
  have qnon : q.Nonempty := card_pos.mp (cq ▸ mpos)
  obtain ⟨q₀,hq₀⟩ := qnon
  have five (v : V) (hv : v ∈ q) : 5 ≤ nbr G v p := by
    have := full_nbr G v p
    have := sparseQ v hv
    have := h₆ v (qH hv)
    omega
  have bigM : 5 ≤ m := by
    by_contra! mm
    have alladj (v : V) (hv : v ∈ q) (w : V) (hw : w ∈ p) : G.Adj w v := by
      have hh := five v hv
      have eq : p.filter (G.Adj v) = p := eq_of_subset_of_card_le (filter_subset _ _) (by
        change 5 ≤ (p.filter (G.Adj v)).card at hh
        omega)
      exact ((mem_filter.mp (eq ▸ hw)).2).symm
    have m₄ : m = 4 := by
      have := (five q₀ hq₀).trans (card_filter_le _ _)
      omega
    obtain ⟨w,hw⟩ := card_pos.mp (by omega : 0 < (p.erase x).card)
    have eq : q.filter (fun z => G.Adj x z ∧ G.Adj w z) = q :=
      filter_true_of_mem (fun z hz => ⟨alladj z hz x hx,alladj z hz w ((erase_subset _ _) hw)⟩)
    have hh := sharedQ w hw
    rw [eq,cq] at hh
    omega
  have light (v : V) (ne : v ≠ x) (hv : v ∈ high G) :
      2 * trianglesAt G v ≤ 3*m + 6 := by
    have old := prec_triangle G ne
    rw [← hU] at hv
    rcases mem_union.mp hv with hp | hq
    · have he := mem_erase.mpr ⟨ne,hp⟩
      have extra := common_split G x v q (sharedQ v he) (sparseP v he)
      have hh := sparse_triangle_bound (isolate G x) v q (by
        rw [iso_nbr G ne]; exact sparseP v he) (by
        intro z hz
        have nz : z ≠ x := fun e => disjoint_left.mp dp hx (e ▸ hz)
        rw [iso_nbr G nz]
        exact (nbr_mono G z (fun i hi => mem_compl.mpr
          (fun h => disjoint_left.mp dp h ((erase_subset _ _) hi)))).trans (sparseQ z hz))
      omega
    · have extra := common_split G x v p (sharedP v hq)
          ((nbr_mono G v (erase_subset _ _)).trans (sparseQ v hq))
      have hh := sparse_triangle_bound (isolate G x) v (p.erase x) (by
        rw [iso_nbr G ne]
        apply le_trans _ (sparseQ v hq)
        apply nbr_mono
        intro z hz
        obtain ⟨nz,h⟩ := mem_erase.mp hz
        exact mem_compl.mpr (fun h' => mem_compl.mp h (mem_erase.mpr ⟨nz,h'⟩))) (by
        intro z hz
        rw [iso_nbr G (mem_erase.mp hz).1]
        apply le_trans _ (sparseP z hz)
        apply nbr_mono
        intro i hi
        have h := (mem_erase.mp hi).2
        exact mem_erase.mpr ⟨(mem_erase.mp h).1,pq ((mem_erase.mp h).2)⟩)
      omega
  have allT : types G ⊆ insert (trianglesAt G x) (range ((3*m+6)/2 + 1)) := by
    intro j hj
    obtain ⟨v,_,rfl⟩ := mem_image.mp hj
    by_cases ne : v = x
    · subst v; exact mem_insert_self _ _
    apply mem_insert_of_mem
    apply mem_range.mpr
    by_cases hh : v ∈ high G
    · have := light v ne hh
      omega
    have low : G.degree v < 3 := by simpa [high] using hh
    have H := (triangles_le_choose G v).trans (Nat.choose_le_choose 2 (show G.degree v ≤ 2 by omega))
    simp only [Nat.choose_self] at H
    omega
  have H := (card_le_card allT).trans (card_insert_le _ _)
  rw [card_range] at H
  omega

/-- Every finite connected graph whose non-low vertices all have degree at least
six satisfies the exact catalogue inequality, with either parity for h. -/
theorem exact_of_high_degree_six (hc : G.Connected) (hn : 2 < Fintype.card V)
    (h₆ : ∀ v ∈ high G, 6 ≤ G.degree v) : gamma G ≤ bound G := by
  by_cases small : (types G).card ≤ 4
  · exact exact_of_at_most_four G hc hn small
  let m := (high G).card / 2
  by_cases even : (high G).card = 2*m
  · exact exact_even_high_no_degree_three G hc hn m even (fun z hz => by have := h₆ z hz; omega)
  have he : (high G).card = 2*m+1 := by dsimp [m] at *; omega
  by_contra! failure
  have ht := type_bound G
  have base := high_bound G
  unfold bound at failure
  have many : 2*m+3 ≤ (types G).card := by omega
  have lim (o : Finset V) (ho : Feasible G o) : o.card ≤ m+1 := by
    have := omit_set G o ho
    omega
  obtain ⟨a,b,hab,hu,ha,hb⟩ := asymmetric_cut G (high G)
  have safe {p q : Finset V} (dp : Disjoint p q) (hh : p ∪ q = high G)
      (hcut : ∀ v ∈ p, nbr G v p ≤ nbr G v q) (v : V) (hv : v ∈ p) :
      3 ≤ nbr G v pᶜ := by
    have sub : q ⊆ pᶜ := fun _ h => mem_compl.mpr (fun h' => disjoint_left.mp dp h' h)
    have := (hcut v hv).trans (nbr_mono G v sub)
    have := full_nbr G v p
    have := h₆ v (hh ▸ mem_union_left _ hv)
    omega
  have sa := safe hab hu ha
  have hs := (union_comm b a).trans hu
  have sb := safe hab.symm hs (fun v hv => (hb v hv).le)
  have ca := lim a (fun v hv => by have := sa v hv; omega)
  have cb := lim b (fun v hv => by have := sb v hv; omega)
  have parts := card_union_of_disjoint hab
  rw [hu,he] at parts
  by_cases e : a.card = m+1
  · exact odd_cut_impossible G m a b hab hu e (by omega) (by omega) many h₆ lim sa
  · exact odd_cut_impossible G m b a hab.symm hs (by omega) (by omega) (by omega) many h₆ lim sb

/-- For d ≥ 2, the vertices of degree at most d together contribute at most
choose(d,2)+1 counts. This controls the number of possible blocking vertices. -/
theorem profile_count (d : ℕ) (hd : 2 ≤ d) :
    (types G).card + ((high G).filter (fun v => G.degree v ≤ d)).card ≤
    (high G).card + d.choose 2 + 1 := by
  let r := (high G).filter (fun v => G.degree v ≤ d)
  let large := high G \ r
  have sub : types G ⊆ large.image (trianglesAt G) ∪ range (d.choose 2 + 1) := by
    intro t ht
    obtain ⟨v,_,rfl⟩ := mem_image.mp ht
    by_cases h : G.degree v ≤ d
    · exact mem_union_right _ (mem_range.mpr (Nat.lt_succ_of_le
          ((triangles_le_choose G v).trans (Nat.choose_le_choose 2 h))))
    · exact mem_union_left _ (mem_image.mpr ⟨v,mem_sdiff.mpr
          ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,fun hh => h (mem_filter.mp hh).2⟩,rfl⟩)
  have h := (card_le_card sub).trans (card_union_le _ _)
  rw [card_range] at h
  have := card_image_le (s := large) (f := trianglesAt G)
  have size : large.card + r.card = (high G).card := card_sdiff_add_card_eq_card (filter_subset _ _)
  change _ + r.card ≤ _
  omega

theorem maximal_diversity (ht : (types G).card = (high G).card + 2) :
    Set.InjOn (trianglesAt G) (high G) ∧ (∀ v ∈ high G, 2 ≤ trianglesAt G v) ∧
      0 ∈ types G ∧ 1 ∈ types G := by
  let a := (high G).image (trianglesAt G)
  let b : Finset ℕ := {0,1}
  have sub : types G ⊆ a ∪ b := by
    intro t hh
    obtain ⟨v,_,rfl⟩ := mem_image.mp hh
    by_cases hv : v ∈ high G
    · exact mem_union_left _ (mem_image.mpr ⟨_,hv,rfl⟩)
    · have low : G.degree v ≤ 2 := Nat.le_of_lt_succ (by simpa [high] using hv)
      have := (triangles_le_choose G v).trans (Nat.choose_le_choose 2 low)
      simp only [Nat.choose_self] at this
      apply mem_union_right
      simp only [b,mem_insert,mem_singleton]
      omega
  have h := card_le_card sub
  have hb : b.card = 2 := by decide
  have ha : a.card ≤ (high G).card := card_image_le
  have sum := card_union_add_card_inter a b
  have eq : types G = a ∪ b := eq_of_subset_of_card_le sub (by omega)
  have inter : a ∩ b = ∅ := card_eq_zero.mp (by omega)
  refine ⟨card_image_iff.mp (show a.card = (high G).card by omega), ?_,?_,?_⟩
  · intro v hv
    have hn : trianglesAt G v ∉ b := fun hh => by
      have hx : trianglesAt G v ∈ a ∩ b := mem_inter.mpr ⟨mem_image.mpr ⟨v,hv,rfl⟩,hh⟩
      simp [inter] at hx
    simp only [b,mem_insert,mem_singleton,not_or] at hn
    omega
  · rw [eq]; exact mem_union_right _ (by decide)
  · rw [eq]; exact mem_union_right _ (by decide)

/-- A candidate counterexample must have a scarce intermediate degree, and
every triangle-count maximizer must touch an edge in at least three triangles. -/
theorem necessary_profile (hc : G.Connected) (hn : 2 < Fintype.card V) (fail : bound G < gamma G) :
    (∃ v ∈ high G, G.degree v ≤ 5) ∧
    ((high G).filter (fun v => G.degree v ≤ 5)).card ≤ 10 ∧
    ((high G).filter (fun v => G.degree v ≤ 3)).card ≤ 3 ∧
    (∀ v, (∀ u, trianglesAt G u ≤ trianglesAt G v) →
      ∃ x ∈ G.neighborFinset v, 3 ≤ nbr G x (G.neighborFinset v)) ∧
    ((∃ v, G.degree v = 3 ∧ G.neighborFinset v ⊆ high G) ∨
      ((high G).card % 2 = 1 ∧ (types G).card = (high G).card + 2 ∧
        Set.InjOn (trianglesAt G) (high G) ∧ (∀ v ∈ high G, 2 ≤ trianglesAt G v))) := by
  have gap := high_bound G
  have cap := type_bound G
  have ff := fail
  unfold bound at ff
  have h₅ := profile_count G 5 (by decide)
  have h₃ := profile_count G 3 (by decide)
  have c₅ : (5:ℕ).choose 2 = 10 := by decide
  have c₃ : (3:ℕ).choose 2 = 3 := by decide
  rw [c₅] at h₅
  rw [c₃] at h₃
  refine ⟨?_,by omega,by omega,?_,?_⟩
  · apply Classical.byContradiction
    intro h
    apply (not_le_of_gt fail) (exact_of_high_degree_six G hc hn _)
    intro v hv
    exact Nat.lt_of_not_ge (fun hh => h ⟨v,hv,hh⟩)
  · intro v hm
    apply Classical.byContradiction
    intro h
    apply (not_le_of_gt fail) (exact_of_thin_maximizer G hc hn v hm _)
    intro x hx
    exact Nat.le_of_not_gt (fun hh => h ⟨x,hx,hh⟩)
  · by_cases bad : ∃ v, G.degree v = 3 ∧ G.neighborFinset v ⊆ high G
    · exact Or.inl bad
    have hlow (v : V) (hv : G.degree v = 3) : 1 ≤ nbr G v (high G)ᶜ := by
      have ns : ¬G.neighborFinset v ⊆ high G := fun hh => bad ⟨v,hv,hh⟩
      obtain ⟨w,hw,ww⟩ := not_subset.mp ns
      exact card_pos.mpr ⟨w,mem_filter.mpr ⟨mem_compl.mpr ww,(G.mem_neighborFinset _ _).mp hw⟩⟩
    have odd : (high G).card % 2 = 1 := by
      by_contra! e
      exact (not_le_of_gt fail) (exact_even_high_of_cubic_neighbor G hc hn _ (by omega :
        (high G).card = 2*((high G).card/2)) hlow)
    have eq : (types G).card = (high G).card + 2 := by omega
    have exactTypes := maximal_diversity G eq
    exact Or.inr ⟨odd,eq,exactTypes.1,exactTypes.2.1⟩

/-- Two degree-two vertices with the same neighbors give the two missing
units even if the general high-vertex estimate misses the target. -/
theorem exact_of_twin_degree_two {u v : V} (ne : u ≠ v) (du : G.degree u = 2)
    (twins : G.neighborFinset u = G.neighborFinset v) : gamma G ≤ bound G := by
  have dv : G.degree v = 2 := by
    simpa only [card_neighborFinset_eq_degree,du] using (congrArg Finset.card twins).symm
  have nonadj : ¬G.Adj u v := fun h =>
    G.not_mem_neighborFinset_self v (twins ▸ (G.mem_neighborFinset _ _).mpr h)
  let x : Finset V := {u,v}
  have degree (z : V) (hz : z ∈ x) : G.degree z = 2 := by
    rcases mem_insert.mp hz with rfl | h
    · exact du
    · rw [mem_singleton.mp h]
      exact dv
  apply exact_of_low_support G x
  · apply disjoint_left.mpr
    intro z hz hh
    have := degree z hz
    have := (mem_filter.mp hh).2
    omega
  · exact fun z hz => (degree z hz).ge
  · intro i hi j hj
    simp only [x,mem_insert,mem_singleton] at hi hj
    rcases hi with rfl | rfl <;> rcases hj with rfl | rfl <;>
      first | exact G.loopless _ | exact nonadj | exact fun a => nonadj a.symm
  · have sub : (high G).filter (fun z => ∃ w ∈ x, G.Adj w z) ⊆ G.neighborFinset u := by
      intro z hz
      obtain ⟨w,hw,ha⟩ := (mem_filter.mp hz).2
      rcases mem_insert.mp hw with rfl | hw'
      · exact (G.mem_neighborFinset _ _).mpr ha
      · rw [twins,← mem_singleton.mp hw']
        exact (G.mem_neighborFinset _ _).mpr ha
    have H := card_le_card sub
    rw [card_neighborFinset_eq_degree,du] at H
    have cx : x.card = 2 := by simp [x,ne]
    have := type_bound G
    omega

end Graffiti384b.Repair
#print axioms Graffiti384b.Repair.asymmetric_cut
#print axioms Graffiti384b.Repair.seeded_cut
#print axioms Graffiti384b.Repair.exact_of_common_seed

#print axioms Graffiti384b.Repair.exact_of_thin_maximizer
#print axioms Graffiti384b.Repair.exact_of_at_most_two_triangles_per_edge
#print axioms Graffiti384b.Repair.exact_even_high_no_degree_three
#print axioms Graffiti384b.Repair.exact_even_high_of_cubic_neighbor
#print axioms Graffiti384b.Repair.exact_even_types_of_cubic_neighbor
#print axioms Graffiti384b.Repair.exact_of_low_support
#print axioms Graffiti384b.Repair.exact_of_high_degree_six
#print axioms Graffiti384b.Repair.necessary_profile
#print axioms Graffiti384b.Repair.exact_of_twin_degree_two
