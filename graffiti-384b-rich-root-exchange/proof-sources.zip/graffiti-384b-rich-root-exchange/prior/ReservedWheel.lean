import Octahedron
namespace Graffiti384b.OddStars.ReservedWheel
open Finset SimpleGraph WheelCut
open private Repair.nbr_mono Repair.isolate from Repair384b
open private CliquePivot33.isolated_degree from ShoreCliquePivot
open private FixedCubics.cubic_range from FixedCubics
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The two sets give every pinned vertex two neighbors of the other color. -/
structure Frame (P Q : Finset V) : Prop where
  dis : Disjoint P Q
  left : ∀w∈P,2≤nbr G w Q
  right : ∀w∈Q,2≤nbr G w P

omit [Fintype V] in
theorem Frame.join {P Q L R : Finset V} (f : Frame G P Q) (b : Frame G L R)
    (pr : Disjoint P R) (lq : Disjoint L Q) : Frame G (P∪L) (Q∪R) := by
  refine ⟨disjoint_union_left.mpr ⟨disjoint_union_right.mpr ⟨f.dis,pr⟩,
    disjoint_union_right.mpr ⟨lq,b.dis⟩⟩,?_,?_⟩
  · intro w m
    exact (mem_union.mp m).elim (fun h => (f.left _ h).trans (Repair.nbr_mono G _ subset_union_left))
      (fun h => (b.left _ h).trans (Repair.nbr_mono G _ subset_union_right))
  · intro w m
    exact (mem_union.mp m).elim (fun h => (f.right _ h).trans (Repair.nbr_mono G _ subset_union_left))
      (fun h => (b.right _ h).trans (Repair.nbr_mono G _ subset_union_right))

omit [Fintype V] in
private theorem see_pair {z a b : V} (ab : a≠b) (za : G.Adj z a) (zb : G.Adj z b) :
    2≤nbr G z {a,b} := by
  unfold nbr
  rw [filter_true_of_mem (by intro w m; simp only [mem_insert,mem_singleton] at m
                             rcases m with rfl|rfl <;> assumption),card_pair ab]

omit [Fintype V] in
theorem square_frame {a b c d : V} (ab : a≠b) (cd : c≠d)
    (ac : G.Adj a c) (ad : G.Adj a d) (bc : G.Adj b c) (bd : G.Adj b d) :
    Frame G {a,b} {c,d} := by
  refine ⟨?_,?_,?_⟩
  · apply disjoint_left.mpr
    simp only [mem_insert,mem_singleton]
    rintro w (rfl|rfl) (rfl|rfl)
    · exact ac.ne rfl
    · exact ad.ne rfl
    · exact bc.ne rfl
    · exact bd.ne rfl
  · intro w m; simp only [mem_insert,mem_singleton] at m
    rcases m with rfl|rfl
    · exact see_pair G cd ac ad
    · exact see_pair G cd bc bd
  · intro w m; simp only [mem_insert,mem_singleton] at m
    rcases m with rfl|rfl
    · exact see_pair G ab ac.symm bc.symm
    · exact see_pair G ab ad.symm bd.symm

/-- When the pins already protect one vertex below degree three, every
failure needs an unpinned cubic next to the pivot. There is no restriction
on the palette or order. -/
theorem pinned_barrier (bad : bound G<gamma G) {P Q : Finset V} (pins : Frame (patch G ∅) P Q)
    {x e : V} (xe : x∉P∪Q) (ep : e∈P∪Q) (low : (patch G ∅).degree e≤2)
    (xp : 2≤nbr (patch G ∅) x P) (xq : 2≤nbr (patch G ∅) x Q) :
    ∃w,(patch G ∅).degree w=3 ∧ (patch G ∅).Adj w x ∧ w∉P∪Q := by
  classical
  let J := patch G ∅
  by_contra! no
  have eh : e∉high J := fun m => by
    have dg : 3≤J.degree e := (mem_filter.mp m).2
    change J.degree e≤2 at low
    omega
  have val := weighted_pivot J (insert e (high J)) pins.dis (fun m => xe (mem_union_left _ m))
    (fun m => xe (mem_union_right _ m)) xp xq pins.left pins.right (by
      intro w wm wx wp wq
      have wh : w∈high J := (mem_insert.mp wm).resolve_left (by
        rintro rfl; exact (mem_union.mp ep).elim wp wq)
      have dg : 3≤J.degree w := (mem_filter.mp wh).2
      rw [CliquePivot33.isolated_degree J wx]
      by_cases ed : J.Adj w x
      · rw [card_erase_of_mem ((J.mem_neighborFinset ..).mpr ed),card_neighborFinset_eq_degree]
        have ne : J.degree w≠3 := fun eq => (mem_union.mp (no w eq ed)).elim wp wq
        omega
      · rwa [erase_eq_of_not_mem (fun m => ed ((J.mem_neighborFinset ..).mp m)),card_neighborFinset_eq_degree])
  rw [card_insert_of_not_mem eh] at val
  have mono := PositivePalette.Prerequisites.gamma_mono G J (fun _ _ ed => ed.1)
  have scores : types J=types G := by
    have eq : trianglesAt J=trianglesAt G := funext (patch_scores G ∅)
    unfold types; rw [eq]
  have cap := type_bound J
  rw [scores] at cap
  unfold bound at bad
  omega

/-- Count centers covered by a blocked pivot argument. At most two cubics
in the triangle skeleton can cover them, each with three neighbors. -/
theorem exact_seven_reserved (C : Finset V) (large : 7≤C.card)
    (local_pins : ∀x∈C,∃P Q : Finset V,Frame (patch G ∅) P Q ∧ x∉P∪Q ∧
      2≤nbr (patch G ∅) x P ∧ 2≤nbr (patch G ∅) x Q ∧
      ∃e∈P∪Q,(patch G ∅).degree e≤2) : gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt
  intro bad
  let J := patch G ∅
  let B := univ.filter (fun w => J.degree w=3)
  have rich {w : V} (wm : w∈B) : 2≤trianglesAt G w ∧ trianglesAt G w≤3 :=
    FixedCubics.cubic_range G (mem_filter.mp wm).2
  have inj : Set.InjOn (trianglesAt G) (B : Set V) := fun _ vm _ _ eq => distinct_rich G bad (rich vm).1 eq
  have small : B.image (trianglesAt G)⊆{2,3} := by
    intro k m; obtain ⟨w,wm,rfl⟩ := mem_image.mp m
    have r := rich wm
    simp only [mem_insert,mem_singleton]; omega
  have cnt := card_le_card small
  rw [card_image_iff.mpr inj,card_pair (by decide : (2:ℕ)≠3)] at cnt
  have inc : C⊆B.biUnion (fun w => J.neighborFinset w) := by
    intro x xm
    obtain ⟨P,Q,fp,off,px,qx,e,ep,lo⟩ := local_pins _ xm
    obtain ⟨w,dw,ed,_⟩ := pinned_barrier G bad fp off ep lo px qx
    exact mem_biUnion.mpr ⟨w,mem_filter.mpr ⟨mem_univ _,dw⟩,(J.mem_neighborFinset ..).mpr ed⟩
  have sz : C.card≤B.card*3 := calc
    C.card ≤ _ := card_le_card inc
    _ ≤ _ := card_biUnion_le
    _ = ∑ _w ∈ B,3 := sum_congr rfl (fun w wm => (J.card_neighborFinset_eq_degree w).trans (mem_filter.mp wm).2)
    _ = _ := by simp
  omega

/-- A square in the center's neighborhood can be combined with any existing
pinned frame. Only vertices pinned to opposite colors must be disjoint. -/
theorem compatible_wheel {P Q : Finset V} (pins : Frame (patch G ∅) P Q)
    {e x a b c d : V} (ep : e∈P∪Q) (lo : (patch G ∅).degree e≤2)
    (r : Rim G x a b c d) (outside : x∉P∪Q)
    (compatibleP : Disjoint P {c,d}) (compatibleQ : Disjoint {a,b} Q) :
    ∃L R : Finset V,Frame (patch G ∅) L R ∧ x∉L∪R ∧
      2≤nbr (patch G ∅) x L ∧ 2≤nbr (patch G ∅) x R ∧
      ∃z∈L∪R,(patch G ∅).degree z≤2 := by
  let J := patch G ∅
  have w := r.skeleton G
  have wheel := square_frame J r.ab r.cd w.ac w.ad w.bc w.bd
  have f := Frame.join J pins wheel compatibleP compatibleQ
  refine ⟨_,_,f,?_,(see_pair J r.ab w.xa w.xb).trans (Repair.nbr_mono J _ subset_union_right),
    (see_pair J r.cd w.xc w.xd).trans (Repair.nbr_mono J _ subset_union_right),e,?_,lo⟩
  · simp only [mem_union,mem_insert,mem_singleton,not_or] at outside ⊢
    exact ⟨⟨outside.1,r.xa.ne,r.xb.ne⟩,outside.2,r.xc.ne,r.xd.ne⟩
  · exact (mem_union.mp ep).elim (fun h => mem_union_left _ (mem_union_left _ h))
      (fun h => mem_union_right _ (mem_union_left _ h))

end Graffiti384b.OddStars.ReservedWheel
#print axioms Graffiti384b.OddStars.ReservedWheel.square_frame
#print axioms Graffiti384b.OddStars.ReservedWheel.pinned_barrier
#print axioms Graffiti384b.OddStars.ReservedWheel.exact_seven_reserved
#print axioms Graffiti384b.OddStars.ReservedWheel.compatible_wheel
