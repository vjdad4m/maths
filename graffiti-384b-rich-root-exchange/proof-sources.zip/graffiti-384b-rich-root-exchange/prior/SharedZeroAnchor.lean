import TriangleBlocks

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette OneEar
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem protect_ends {e : V}
    {n : ℕ} (big : 2 ≤ n) (even : n % 2 = 0) (f : ℕ → V)
    (step : ∀ i < n, G.Adj (f i) (f (i+1)))
    (inj : ∀ i ≤ n, ∀ j ≤ n, f i = f j → i=j)
    (avoid : ∀ i ≤ n, f i ≠ e) (first : G.Adj e (f 0)) (last : G.Adj e (f n)) :
    Covered G (insert (f 0) (insert (f n) (high G))) := by
  classical
  let side (k : ℕ) := (((range (n+1)).filter (fun i => i%2=k)).image f)
  let P := side 0
  let Q := insert e (side 1)
  have mem (k i : ℕ) (hi : i≤n) (par : i%2=k) : f i∈side k :=
    mem_image.mpr ⟨i,mem_filter.mpr ⟨mem_range.mpr (by omega),par⟩,rfl⟩
  have index {k : ℕ} {v : V} (m : v∈side k) : ∃ i≤n, i%2=k ∧ f i=v := by
    obtain ⟨i,im,fi⟩ := mem_image.mp m
    exact ⟨i,Nat.le_of_lt_succ (mem_range.mp (mem_filter.mp im).1),(mem_filter.mp im).2,fi⟩
  have dis : Disjoint P Q := by
    apply disjoint_left.mpr
    intro v vp vq
    obtain ⟨i,hi,ei,rfl⟩ := index vp
    rcases mem_insert.mp vq with eq | vq
    · exact avoid i hi eq
    · obtain ⟨j,hj,oj,eq⟩ := index vq
      have := inj j hj i hi eq
      omega
  have middle (i : ℕ) (lo : 0 < i) (up : i < n) :
      2 ≤ nbr G (f i) (side (1-i%2)) := by
    have prev := step (i-1) (by omega)
    rw [show i-1+1=i by omega] at prev
    exact PinnedColor34.two G (fun eq => by have := inj (i-1) (by omega) (i+1) (by omega) eq; omega)
      prev.symm (step i up) (mem _ _ (by omega) (by omega)) (mem _ _ (by omega) (by omega))
  have eqm : e∈Q := mem_insert_self ..
  apply complete G dis
  · intro v vm off _
    rcases mem_insert.mp vm with start|vm
    · exact (off (start ▸ mem 0 0 (by omega) rfl)).elim
    rcases mem_insert.mp vm with finish|hi
    · exact (off (finish ▸ mem 0 n le_rfl even)).elim
    exact (mem_filter.mp hi).2
  · intro v vp
    obtain ⟨i,hi,par,rfl⟩ := index vp
    by_cases iz : i=0
    · subst i
      exact PinnedColor34.two G (Ne.symm (avoid 1 (by omega))) first.symm (step 0 (by omega))
        eqm (mem_insert_of_mem (mem 1 1 (by omega) rfl))
    by_cases en : i=n
    · subst i
      have prev := step (n-1) (by omega)
      rw [show n-1+1=n by omega] at prev
      exact PinnedColor34.two G (Ne.symm (avoid (n-1) (by omega))) last.symm prev.symm eqm
        (mem_insert_of_mem (mem 1 _ (by omega) (by omega)))
    have h := middle i (by omega) (by omega)
    rw [par] at h
    exact h.trans (card_le_card (filter_subset_filter _ (subset_insert ..)))
  · intro v vq
    rcases mem_insert.mp vq with rfl | vm
    · exact PinnedColor34.two G (fun eq => by have := inj 0 (by omega) n le_rfl eq; omega)
        first last (mem 0 0 (by omega) rfl) (mem 0 n le_rfl even)
    · obtain ⟨i,hi,par,rfl⟩ := index vm
      have h := middle i (by omega) (by omega)
      simpa only [par,Nat.sub_self] using h


omit [Fintype V] in
private theorem reverse_parity_at_second {J : SimpleGraph V} [DecidableRel J.Adj]
    {c z e w : V} {n : ℕ} (p : Route J c z e n) (odd : n%2=1) (len : 3≤n)
    (wc : w≠c) (wz : w≠z) (dw : J.Adj (p.atIdx 1) w) (uw : J.Adj (p.atIdx 2) w) :
    ∃ m,m%2=0 ∧ Nonempty (Route J c z e m) := by
  classical
  have zd : J.Adj z (p.atIdx 1) := by simpa only [p.start] using p.step 0 (by omega)
  have du : J.Adj (p.atIdx 1) (p.atIdx 2) := p.step 1 (by omega)
  have zc : z≠c := by simpa only [p.start] using p.avoid 0 (by omega)
  have zu : z≠p.atIdx 2 := by
    intro eq; have := p.unique 0 (by omega) 2 (by omega) (p.start.trans eq); omega
  have earlier (i j : ℕ) (ij : i<j) (jn : j≤n) : ∀ k≤n-j,p.atIdx i≠(p.suffix j jn).atIdx k := by
    intro k hk eq
    have := p.unique i (by omega) (j+k) (by omega) eq
    omega
  have tail {j : ℕ} (jp : 0<j) (jn : j≤n) : ∀ k≤n-j,z≠(p.suffix j jn).atIdx k :=
    by simpa only [p.start] using earlier 0 j jp jn
  by_cases hit : ∃ i≤n,p.atIdx i=w
  · obtain ⟨i,hi,eq⟩ := hit
    have far : 2<i := by
      by_contra! bad
      rcases (show i=0 ∨ i=1 ∨ i=2 by omega) with rfl|rfl|rfl
      · exact wz (eq.symm.trans p.start)
      · exact dw.ne eq
      · exact uw.ne eq
    let t := p.suffix i hi
    by_cases par : (n-i)%2=0
    · let d := t.prepend (by rwa [eq]) (p.avoid 1 (by omega)) (earlier 1 i (by omega) hi)
      have fresh (k : ℕ) (hk : k≤n-i+1) : z≠d.atIdx k := by
        cases k with
        | zero => exact zd.ne
        | succ k => exact tail (by omega) hi k (by omega)
      let r := d.prepend zd zc fresh
      exact ⟨_,by omega,⟨r⟩⟩
    · let u := t.prepend (by rwa [eq]) (p.avoid 2 (by omega)) (earlier 2 i far hi)
      have df (k : ℕ) (hk : k≤n-i+1) : p.atIdx 1≠u.atIdx k := by
        cases k with
        | zero => exact du.ne
        | succ k => exact earlier 1 i (by omega) hi k (by omega)
      let d := u.prepend du (p.avoid 1 (by omega)) df
      have zf (k : ℕ) (hk : k≤n-i+1+1) : z≠d.atIdx k := by
        cases k with
        | zero => exact zd.ne
        | succ k =>
          cases k with
          | zero => exact zu
          | succ k => exact tail (by omega) hi k (by omega)
      let r := d.prepend zd zc zf
      exact ⟨_,by omega,⟨r⟩⟩
  · let t := p.suffix 2 (by omega)
    have fresh (k : ℕ) (hk : k≤n-2) : w≠t.atIdx k := fun eq => hit ⟨2+k,by omega,eq.symm⟩
    let u := t.prepend uw.symm wc fresh
    have df (k : ℕ) (hk : k≤n-2+1) : p.atIdx 1≠u.atIdx k := by
      cases k with
      | zero => exact dw.ne
      | succ k => exact earlier 1 2 (by decide) (by omega) k (by omega)
    let d := u.prepend dw (p.avoid 1 (by omega)) df
    have zf (k : ℕ) (hk : k≤n-2+1+1) : z≠d.atIdx k := by
      cases k with
      | zero => exact zd.ne
      | succ k =>
        cases k with
        | zero => exact wz.symm
        | succ k => exact tail (j:=2) (by decide) (by omega) k (by omega)
    let r := d.prepend zd zc zf
    exact ⟨_,by omega,⟨r⟩⟩

open private OddStars.true_ear OddStars.supported_away from TriangleBlocks

/-- No zero-score degree-two vertex and count-one vertex can share a
neighbor in a failure. A parity detour constructs a cycle protecting both. -/
theorem disjoint_zero_ear (bad : bound G<gamma G) {z e c : V} (zz : trianglesAt G z=0)
    (deg : G.degree z=2) (one : trianglesAt G e=1) (zc : G.Adj z c) (ec : G.Adj e c) : False := by
  classical
  let J := patch G {z}
  let K := inside J ({c}ᶜ)
  have eg := (zero_two_forces_ears G bad zz deg).2 e one
  have dJ : J.degree e=G.degree e := (OddStars.true_ear G one eg {z}).trans eg.symm
  have nJ : J.neighborFinset e=G.neighborFinset e := eq_of_subset_of_card_le
    (fun _ m => (G.mem_neighborFinset ..).mpr ((J.mem_neighborFinset ..).mp m).1) (by
      simp only [card_neighborFinset_eq_degree,dJ,le_refl])
  have ce : J.Adj c e := ((J.mem_neighborFinset ..).mp (nJ ▸ (G.mem_neighborFinset ..).mpr ec)).symm
  have cz : J.Adj c z := ⟨zc.symm,Or.inr (Or.inr (mem_singleton_self _))⟩
  have connected : K.Reachable z e := zero_ear_in_block G bad zz deg one zc.ne ec.ne
  obtain ⟨walk,hw⟩ := connected.exists_isPath
  let n := walk.length
  let p : Route J c z e n := {
    atIdx := walk.getVert
    start := walk.getVert_zero
    finish := walk.getVert_length
    step := fun _ hi => (walk.adj_getVert_succ hi).1
    unique := fun i hi j hj eq => hw.getVert_injOn hi hj eq
    avoid := by
      intro i hi
      by_cases lt : i<n
      · have v := (walk.adj_getVert_succ lt).2.1
        simpa using v
      · have en := show i=n by omega
        rw [en,show n=walk.length from rfl,walk.getVert_length]; exact ec.ne
  }
  have ze : z≠e := fun eq => by rw [eq,one] at zz; contradiction
  have noZE : ¬G.Adj z e := by
    intro he
    obtain ⟨a,b,nb,ea,eb,ab⟩ := Prerequisites.ear_pair G eg (by omega : 0<trianglesAt G e)
    have m := (G.mem_neighborFinset ..).mpr he.symm
    rw [nb,mem_insert,mem_singleton] at m
    rcases m with rfl|rfl
    · have := (TrianglePrune.triangle_iff G _).mpr ⟨e,b,he,ab,eb⟩; omega
    · have := (TrianglePrune.triangle_iff G _).mpr ⟨e,a,he,ab.symm,ea⟩; omega
  have len : 2≤n := by
    apply Nat.le_of_not_gt
    intro short
    rcases (show n=0 ∨ n=1 by omega) with h|h
    · exact ze (p.start.symm.trans (h ▸ p.finish))
    · have st := p.step 0 (by omega)
      rw [p.start,show 0+1=n by omega,p.finish] at st; exact noZE st.1
  have getEven : ∃ m,m%2=0 ∧ Nonempty (Route J c z e m) := by
    by_cases par : n%2=0
    · exact ⟨n,par,⟨p⟩⟩
    have long : 3≤n := by omega
    have out (i : ℕ) (lo : 0<i) (up : i≤n) : p.atIdx i≠z := by
      intro h; have := p.unique i up 0 (by omega) (h.trans p.start.symm); omega
    have zd : G.Adj z (p.atIdx 1) := by
      have h := (p.step 0 (by omega)).1
      rw [p.start] at h
      exact h
    have dc : p.atIdx 1≠c := p.avoid 1 (by omega)
    have pair : G.neighborFinset z={c,p.atIdx 1} := (eq_of_subset_of_card_le
      (insert_subset ((G.mem_neighborFinset ..).mpr zc) (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr zd)))
      (by rw [card_pair dc.symm,card_neighborFinset_eq_degree,deg])).symm
    obtain ⟨w,dw,uw⟩ := OddStars.supported_away G (S:={z}) Subset.rfl (out 1 (by decide) (by omega))
      (out 2 (by decide) (by omega)) (p.step 1 (by omega))
    have wc : w≠c := by
      rintro rfl
      have := (TrianglePrune.triangle_iff G z).mpr ⟨_,_,zd,zc,dw.1⟩
      omega
    have wz : w≠z := by
      rintro rfl
      have m := (G.mem_neighborFinset ..).mpr uw.1.symm
      rw [pair,mem_insert,mem_singleton] at m
      exact m.elim (p.avoid 2 (by omega)) (fun eq => by have := p.unique 2 (by omega) 1 (by omega) eq; omega)
    exact reverse_parity_at_second p (by omega) long wc wz dw uw
  obtain ⟨m,even,⟨r⟩⟩ := getEven
  have big : 2≤m := by
    apply Nat.le_of_not_gt
    intro small
    have eq : m=0 := by omega
    exact ze (r.start.symm.trans (eq ▸ r.finish))
  have cut := protect_ends J (e:=c) big even r.atIdx r.step r.unique r.avoid
    (by rwa [r.start]) (by rwa [r.finish])
  rw [r.start,r.finish] at cut
  let W := insert z (insert e (high J))
  have ew : e∈W := mem_insert_of_mem (mem_insert_self ..)
  have rep := represents_of_high G (S:={z}) (W:=W) ((subset_insert ..).trans (subset_insert ..))
    (fun _ => ⟨e,ew,one⟩)
  have img := (rigid G (J:=J) (fun _ _ a => a.1) rep cut bad).1
  have h := mem_image_of_mem (trianglesAt G) (show z∈W from mem_insert_self ..)
  rw [img,zz] at h
  exact not_mem_erase _ _ h

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.disjoint_zero_ear
