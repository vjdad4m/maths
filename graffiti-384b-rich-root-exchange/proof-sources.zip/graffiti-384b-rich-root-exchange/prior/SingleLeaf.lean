import ComponentPort
namespace Graffiti384b.OddStars.SingleLeaf
open Finset SimpleGraph PositivePalette ComponentQuota ComponentCenters ComponentPort
open private TrianglePrune.Closed TrianglePrune.scores_closed TrianglePrune.reach_closed TrianglePrune.triangle_iff from TrianglePrune384b
open private PairAlternative.patch_eq from PairAlternative
open private IsolateBasic.score from IsolateBasic384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem leaf_connected (conn : G.Connected) (r : V) : (withLeaf G r).Connected := by
  let E := withLeaf G r
  let inc : G →g E := ⟨Sum.inl,fun h => h⟩
  apply (connected_iff_exists_forall_reachable E).mpr
  refine ⟨.inl r,?_⟩
  intro w; cases w with
  | inl w => exact (conn r w).map inc
  | inr w => exact (show E.Adj (.inl r) (.inr w) from Or.inl rfl).reachable

theorem leaf_scores (r : V) :
    (∀w : V,trianglesAt (withLeaf G r) (.inl w)=trianglesAt G w) ∧
    trianglesAt (withLeaf G r) (.inr ())=0 ∧ (withLeaf G r).degree (.inr ())=1 := by
  let E := withLeaf G r
  have N : E.neighborFinset (.inr ())={.inl r} := by
    ext w; cases w <;> simp [E,withLeaf,PairAlternative.attach]
  have deg : E.degree (.inr ())=1 := by rw [←card_neighborFinset_eq_degree,N,card_singleton]
  have hi := Repair.triangles_le_choose E (.inr ())
  rw [deg] at hi
  refine ⟨?_,by simpa using hi,deg⟩
  intro w
  calc
    _ = trianglesAt (patch E ∅) (.inl w) := (patch_scores ..).symm
    _ = trianglesAt (IsolateBasic.extend (patch G ∅)) (.inl w) := by congr 1; exact PairAlternative.patch_eq G (G.loopless r)
    _ = _ := (IsolateBasic.score _ w).trans (patch_scores ..)

/-- Every positive triangle-edge component, chosen in advance, gives a
connected one-leaf counterexample at or below the original order. -/
theorem canonical_at (conn : G.Connected) (bad : bound G<gamma G) {x : V} (px : 0<trianglesAt G x) :
    let S := component G x
    let K := block G S
    K.Connected ∧ (∀i,0<trianglesAt K i) ∧
      (∀{i j},K.Adj i j → ∃k,K.Adj i k ∧ K.Adj j k) ∧
      ∃r : S,let E := withLeaf K r
        E.Connected ∧ 2<S.card+1 ∧ S.card+1≤Fintype.card V ∧
        (∀w,trianglesAt E w=0 ↔ w=.inr ()) ∧ E.degree (.inr ())=1 ∧ bound E<gamma E := by
  classical
  let J := patch G ∅
  let S := component G x
  let K := block G S
  have xm : x∈S := (mem_component ..).mpr (Reachable.refl _)
  have cls : region J S := closed_component G x
  have cl : TrianglePrune.Closed J S := fun _ vm _ e => (cls e).mp vm
  have supp : (S:Set V)=(J.connectedComponentMk x).supp := by
    ext w
    change w∈component G x ↔ _
    rw [mem_component,ConnectedComponent.mem_supp_iff]
    exact ⟨fun h => ConnectedComponent.sound h.symm,fun h => (ConnectedComponent.exact h).symm⟩
  have connected : K.Connected := by
    change (J.induce (S:Set V)).Connected
    rw [supp]
    exact ConnectedComponent.connected_induce_supp _
  let P := univ.filter (fun w => 0<trianglesAt G w)
  have closedP : TrianglePrune.Closed J P := by
    intro u _ w uw
    have dp := (J.degree_pos_iff_exists_adj w).mpr ⟨u,uw.symm⟩
    have d := LeafCritical.skeleton_degree_bound G w
    change J.degree w≤_ at d
    exact mem_filter.mpr ⟨mem_univ _,by omega⟩
  have positive {w : V} (wm : w∈S) : 0<trianglesAt G w :=
    (mem_filter.mp (TrianglePrune.reach_closed J P closedP (mem_filter.mpr ⟨mem_univ _,px⟩)
      ((mem_component ..).mp wm))).2
  have cs (w : S) : trianglesAt K w=trianglesAt G w.val :=
    (TrianglePrune.scores_closed J S cl w).trans (patch_scores G ∅ _)
  have posK (w : S) : 0<trianglesAt K w := cs w ▸ positive w.property
  have tr {i j : S} (ij : K.Adj i j) : ∃k : S,K.Adj i k ∧ K.Adj j k := by
    have e : J.Adj i.val j.val := ij
    obtain ⟨k,ik,jk⟩ := e.2.resolve_right (by simp)
    have s1 : J.Adj i.val k := ⟨ik,Or.inl ⟨j.val,e.1,jk.symm⟩⟩
    have s2 : J.Adj j.val k := ⟨jk,Or.inl ⟨i.val,e.1.symm,ik.symm⟩⟩
    exact ⟨⟨k,cl _ i.property _ s1⟩,s1,s2⟩
  obtain ⟨z,_,zz⟩ := mem_image.mp (failure_requires_odd_zero G bad).2
  have zo : z∉S := fun zm => by have := positive zm; omega
  have boundary : ∃r∈S,∃y∉S,G.Adj r y := by
    apply Classical.byContradiction
    intro absent
    have closedG : TrianglePrune.Closed G S := by
      intro r rm y ed
      by_contra no
      exact absent ⟨r,rm,y,no,ed⟩
    exact zo (TrianglePrune.reach_closed G S closedG xm (conn x z))
  obtain ⟨r,rm,y,yo,ry⟩ := boundary
  let root : S := ⟨r,rm⟩
  have failed := rooted_failure G bad S cls root yo ry
  have size : S.card<Fintype.card V := by
    have strict : S⊂univ := Finset.ssubset_iff_subset_ne.mpr ⟨subset_univ _,fun e => zo (e.symm ▸ mem_univ z)⟩
    have less := card_lt_card strict
    rwa [card_univ] at less
  obtain ⟨a,b,ra,rb,ab⟩ := (TrianglePrune.triangle_iff K root).mp (posK root)
  have deg := Prerequisites.deg2 K ab.ne ra rb
  have top := K.degree_lt_card_verts root
  have c : Fintype.card (S:Set V)=S.card := Fintype.card_coe S
  rw [c] at top
  have sc := leaf_scores K root
  refine ⟨connected,posK,@tr,root,leaf_connected K connected root,(show 2<S.card+1 by omega),(show S.card+1≤Fintype.card V by omega),?_,sc.2.2,failed⟩
  intro w
  cases w with
  | inl w =>
    constructor
    · intro eq; exact (Nat.ne_of_gt (posK w) ((sc.1 w).symm.trans eq)).elim
    · intro eq; cases eq
  | inr w =>
    cases w
    exact ⟨fun _ => rfl,fun _ => sc.2.1⟩

end Graffiti384b.OddStars.SingleLeaf
#print axioms Graffiti384b.OddStars.SingleLeaf.leaf_connected
#print axioms Graffiti384b.OddStars.SingleLeaf.leaf_scores
#print axioms Graffiti384b.OddStars.SingleLeaf.canonical_at
