import PositivePalette384b

namespace Graffiti384b.OddStars
open Finset SimpleGraph OneEar PositivePalette
open private Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem opened_route {e a b : V} (ear : G.neighborFinset e={a,b}) (eb : G.Adj e b) (ab : a≠b)
    (reach : (opened G {e,a,b}).Reachable a b) : ∃ n, 2≤n ∧ Nonempty (Route G e a b n) := by
  classical
  let K : Finset V := {e,a,b}
  let H := opened G K
  obtain ⟨p,hp⟩ := reach.exists_isPath
  let f := p.getVert
  have one : 1≤p.length := by
    by_contra! short
    have zero : p.length=0 := by omega
    exact ab (p.getVert_zero.symm.trans (zero ▸ p.getVert_length))
  have two : 2≤p.length := by
    by_contra! short
    have l : p.length=1 := by omega
    have edge := p.adj_getVert_succ (i:=0) (by omega)
    rw [p.getVert_zero,show 0+1=p.length by omega,p.getVert_length] at edge
    exact edge.2 ⟨by simp [K],by simp [K]⟩
  have st (i : ℕ) (hi : i < p.length) : H.Adj (f i) (f (i+1)) := p.adj_getVert_succ hi
  have iso {v : V} (edge : H.Adj e v) : False := by
    have vm := (G.mem_neighborFinset _ _).mpr edge.1
    rw [ear] at vm
    exact edge.2 ⟨by simp [K],mem_insert_of_mem vm⟩
  let r : Route G e a b p.length := {
    atIdx := f
    start := p.getVert_zero
    finish := p.getVert_length
    step := fun i hi => (st i hi).1
    unique := fun i hi j hj eq => hp.getVert_injOn hi hj eq
    avoid := by
      intro i hi eq
      by_cases lt : i < p.length
      · exact iso (eq ▸ st i lt)
      · have endv : f i=b := (show i=p.length by omega) ▸ p.getVert_length
        exact eb.ne (eq.symm.trans endv)
  }
  exact ⟨p.length,two,⟨r⟩⟩

private theorem apart_anchors {e a b : V} 
    (ear : G.neighborFinset e={a,b}) (ab : a≠b)
    (apart : ¬(opened G {e,a,b}).Reachable a b) : Covered G (insert e (high G)) := by
  classical
  let K : Finset V := {e,a,b}
  let H := opened G K
  have ea : G.Adj e a := (G.mem_neighborFinset _ _).mp (ear ▸ mem_insert_self ..)
  have eb : G.Adj e b := (G.mem_neighborFinset _ _).mp (ear ▸ mem_insert_of_mem (mem_singleton_self _))
  have ek : e∈K := mem_insert_self ..
  have ak : a∈K := mem_insert_of_mem (mem_insert_self ..)
  have bk : b∈K := mem_insert_of_mem (mem_insert_of_mem (mem_singleton_self _))
  have iso {v : V} (edge : H.Adj e v) : False := by
    have vm := (G.mem_neighborFinset _ _).mpr edge.1
    rw [ear] at vm
    exact edge.2 ⟨ek,mem_insert_of_mem vm⟩
  obtain ⟨A,_,_,left,right⟩ := PinnedColor34.cut H ∅ ∅ (by simp)
  let opp (v : V) := if v∈A then Aᶜ else A
  have balance (v : V) : H.degree v ≤ 2*nbr H v (opp v) := by
    have total := Repair.full_nbr H v A
    by_cases va : v∈A
    · have h := left v va (by simp)
      simp only [opp,if_pos va]; omega
    · have h := right v (mem_compl.mpr va) (by simp)
      simp only [opp,if_neg va]; omega
  let ref (v : V) := if H.Reachable a v then a else b
  let S := univ.filter (fun v => v≠e ∧ (v∈A ↔ ref v∈A))
  have sm {v : V} : v∈S ↔ v≠e ∧ (v∈A ↔ ref v∈A) := by simp [S]
  have as' : a∈S := sm.mpr ⟨ea.ne.symm,by simp [ref,Reachable.refl]⟩
  have bs' : b∈S := sm.mpr ⟨eb.ne.symm,by simp [ref,apart,H,K]⟩
  have es : e∉S := fun m => (sm.mp m).1 rfl
  have across {u v : V} (adj : H.Adj u v) (ov : v∈opp u) : (v∈S ↔ u∉S) := by
    have ue : u≠e := fun eq => iso (eq ▸ adj)
    have ve : v≠e := fun eq => iso (eq ▸ adj.symm)
    have reach : H.Reachable a u ↔ H.Reachable a v :=
      ⟨fun r => r.trans adj.reachable,fun r => r.trans adj.symm.reachable⟩
    have fixed : ref u=ref v := by simp only [ref,reach]
    rw [sm,sm]
    simp only [ue,ve,true_and,fixed]
    by_cases ua : u∈A
    · have va : v∉A := mem_compl.mp (show v∈Aᶜ by simpa [opp,ua] using ov)
      simp [ua,va,ue,ve]
    · have va : v∈A := by simpa [opp,ua] using ov
      simp [ua,va,ue,ve]
  let outside (v : V) := if v∈S then Sᶜ else S
  have inc (v : V) : (opp v).filter (H.Adj v)⊆(outside v).filter (G.Adj v) := by
    intro i im
    obtain ⟨ic,vi⟩ := mem_filter.mp im
    apply mem_filter.mpr ⟨?_,vi.1⟩
    have h := across vi ic
    by_cases vs : v∈S <;> simp [outside,vs,h]
  have nonEar {v : V} (vn : v∈insert e (high G)) (ve : v≠e) : 3≤G.degree v := by
    exact (mem_filter.mp ((mem_insert.mp vn).resolve_left ve)).2
  have atAnchor (v : V) (vn : v∈insert e (high G)) (vs : v∈S) (ev : G.Adj e v) (vk : v∈K) :
      2≤nbr G v (outside v) := by
    have vd := nonEar vn ev.ne.symm
    have hd : 0<H.degree v := by
      apply Nat.pos_of_ne_zero
      intro zero
      have nc : (H.neighborFinset v).card=0 := by rw [card_neighborFinset_eq_degree]; omega
      have cover : G.neighborFinset v⊆K.erase v := by
        intro i im
        have vi := (G.mem_neighborFinset _ _).mp im
        apply mem_erase.mpr ⟨vi.ne.symm,?_⟩
        apply Classical.byContradiction
        intro out
        have edge : H.Adj v i := ⟨vi,fun both => out both.2⟩
        have bad := (H.mem_neighborFinset _ _).mpr edge
        rw [card_eq_zero.mp nc] at bad
        exact Finset.not_mem_empty _ bad
      have cap := card_le_card cover
      rw [card_neighborFinset_eq_degree,card_erase_of_mem vk] at cap
      have kc : K.card=3 := by simp [K,ea.ne,eb.ne,ab]
      omega
    have bal := balance v
    obtain ⟨i,im⟩ := card_pos.mp (show 0<((opp v).filter (H.Adj v)).card by change 0<nbr H v (opp v); omega)
    have vi := (mem_filter.mp im).2
    have ie : i≠e := fun eq => iso (eq ▸ vi.symm)
    exact PinnedColor34.two G ie vi.1 ev.symm (mem_filter.mp (inc v im)).1 (by simp [outside,vs,es])
  have good (v : V) (vn : v∈insert e (high G)) : 2≤nbr G v (outside v) := by
    by_cases ve : v=e
    · subst v
      simpa [outside,es] using PinnedColor34.two G ab ea eb as' bs'
    by_cases va : v=a
    · subst v; exact atAnchor a vn as' ea ak
    by_cases vb : v=b
    · subst v; exact atAnchor b vn bs' eb bk
    have vk : v∉K := by simp [K,ve,va,vb]
    have eq : H.neighborFinset v = G.neighborFinset v := by
      ext i; simp [H,opened,vk]
    have de : H.degree v=G.degree v := by simpa only [card_neighborFinset_eq_degree] using congrArg Finset.card eq
    have min := nonEar vn ve
    have bal := balance v
    have low : 2 ≤ nbr H v (opp v) := by omega
    exact low.trans (card_le_card (inc v))
  exact ⟨S,fun v vn vs => by simpa [outside,vs] using good v vn,
    fun v vn vs => by simpa [outside,mem_compl.mp vs] using good v vn⟩

/-- The degree-two vertex need not lie in a triangle. Unsupported edges may
meet it or the auxiliary vertex c. All other edges must lie in triangles. -/
theorem protect_two_stars {e : V} (de : G.degree e=2) (c : V)
    (sup : ∀ {x y}, x≠e → y≠e → x≠c → y≠c → G.Adj x y → ∃ z,G.Adj x z ∧ G.Adj y z) :
    Covered G (insert e (high G)) := by
  classical
  obtain ⟨a,b,ab,ear⟩ := card_eq_two.mp (show (G.neighborFinset e).card=2 by
    rw [card_neighborFinset_eq_degree,de])
  have ea : G.Adj e a := (G.mem_neighborFinset ..).mp (ear ▸ mem_insert_self ..)
  have eb : G.Adj e b := (G.mem_neighborFinset ..).mp (ear ▸ mem_insert_of_mem (mem_singleton_self _))
  by_cases reach : (opened G {e,a,b}).Reachable a b
  · obtain ⟨n,two,⟨p⟩⟩ := opened_route G ear eb ab reach
    by_cases even : n%2=0
    · exact close_cycle p ea eb ab even
    have long : 3≤n := by omega
    have finish {a b : V} (r : Route G e a b n) (ea : G.Adj e a) (eb : G.Adj e b)
        (ab : a≠b) (ear : G.neighborFinset e={a,b}) (ac : a≠c) (uc : r.atIdx 1≠c) :
        Covered G (insert e (high G)) := by
      have au := r.step 0 (by omega)
      rw [r.start] at au
      obtain ⟨z,az,uz⟩ := sup ea.ne.symm (r.avoid 1 (by omega)) ac uc au
      have ze : z≠e := by
        intro eq
        have m := (G.mem_neighborFinset ..).mpr (show G.Adj e (r.atIdx 1) from eq ▸ uz.symm)
        rw [ear,mem_insert,mem_singleton] at m
        rcases m with h|h
        · exact au.ne h.symm
        · have idx := r.unique 1 (by omega) n le_rfl (h.trans r.finish.symm)
          omega
      exact parity_detour r two ea eb ab ze az uz
    by_cases head : a≠c ∧ p.atIdx 1≠c
    · exact finish p ea eb ab ear head.1 head.2
    have tail (i : ℕ) (hi : i≤n) (after : 1<i) : p.atIdx i≠c := by
      intro eq
      apply head
      constructor
      · intro ac
        have h := p.unique 0 (by omega) i hi (p.start.trans (ac.trans eq.symm))
        omega
      · intro uc
        have h := p.unique 1 (by omega) i hi (uc.trans eq.symm)
        omega
    exact finish p.reverse eb ea ab.symm (ear.trans (pair_comm ..))
      (by simpa [p.finish] using tail n le_rfl (by omega))
      (tail (n-1) (by omega) (by omega))
  · exact apart_anchors G ear ab reach

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.protect_two_stars
