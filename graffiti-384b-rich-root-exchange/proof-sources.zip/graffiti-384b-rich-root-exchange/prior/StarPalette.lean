import StarEarCut

namespace Graffiti384b.OddStars
open Finset SimpleGraph PositivePalette
open private Prune.links from Prune384b
open private Repair.triangles_le_choose from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Keep every triangle edge and all edges at the selected centers. -/
def patch (S : Finset V) : SimpleGraph V where
  Adj x y := G.Adj x y ∧ ((∃ z,G.Adj x z ∧ G.Adj y z) ∨ x∈S ∨ y∈S)
  symm := fun _ _ h => ⟨h.1.symm,h.2.elim
    (fun ⟨z,xz,yz⟩ => Or.inl ⟨z,yz,xz⟩) (fun j => Or.inr j.symm)⟩
  loopless := fun _ h => h.1.ne rfl

instance (S : Finset V) : DecidableRel (patch G S).Adj := fun _ _ =>
  inferInstanceAs (Decidable (_ ∧ (_ ∨ _ ∨ _)))

theorem patch_scores (S : Finset V) (v : V) : trianglesAt (patch G S) v=trianglesAt G v := by
  let J := patch G S
  change (Prune.links J v).card = (Prune.links G v).card
  congr 1
  ext p
  simp only [Prune.links,mem_filter,mem_powersetCard]
  constructor
  · rintro ⟨⟨sub,two⟩,edge⟩
    exact ⟨⟨fun y hy => (G.mem_neighborFinset ..).mpr ((J.mem_neighborFinset ..).mp (sub hy)).1,two⟩,
      fun y hy z hz ne => (edge y hy z hz ne).1⟩
  · rintro ⟨⟨sub,two⟩,edge⟩
    have adj (y : V) (hy : y∈p) := (G.mem_neighborFinset ..).mp (sub hy)
    refine ⟨⟨?_,two⟩,?_⟩
    · intro y hy
      obtain ⟨z,hz,ne⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) y
      exact (J.mem_neighborFinset ..).mpr ⟨adj y hy,Or.inl ⟨z,adj z hz,edge y hy z hz ne.symm⟩⟩
    · intro y hy z hz ne
      exact ⟨edge y hy z hz ne,Or.inl ⟨v,(adj y hy).symm,(adj z hz).symm⟩⟩

theorem center_degree {S : Finset V} {v : V} (vm : v∈S) : (patch G S).degree v=G.degree v := by
  have eq : (patch G S).neighborFinset v=G.neighborFinset v := by ext y; simp [patch,vm]
  simpa only [card_neighborFinset_eq_degree] using congrArg Finset.card eq

theorem rich_high {v : V} (rich : 2≤trianglesAt G v) (S : Finset V) : v∈high (patch G S) := by
  apply mem_filter.mpr ⟨mem_univ _,?_⟩
  by_contra! low
  have cap := (Repair.triangles_le_choose (patch G S) v).trans (Nat.choose_le_choose 2 (by omega :
    (patch G S).degree v ≤ 2))
  rw [Nat.choose_self,patch_scores] at cap
  omega

theorem covers_high (J : SimpleGraph V) [DecidableRel J.Adj] : Covered J (high J) :=
  complete J (P:=∅) (Q:=∅) (by simp) (fun _ vh _ _ => (mem_filter.mp vh).2) (by simp) (by simp)

theorem cover_two {c e : V} {S : Finset V} (sub : S⊆{c,e}) (de : (patch G S).degree e=2) :
    Covered (patch G S) (insert e (high (patch G S))) := by
  apply protect_two_stars _ de c
  intro x y xe ye xc yc h
  have off {v : V} (vc : v≠c) (ve : v≠e) : v∉S := fun m => by
    have hin := sub m
    simp [vc,ve] at hin
  obtain ⟨z,xz,yz⟩ := h.2.resolve_right (by simp [off xc xe,off yc ye])
  exact ⟨z,⟨xz,Or.inl ⟨y,h.1,yz.symm⟩⟩,⟨yz,Or.inl ⟨x,h.1.symm,xz.symm⟩⟩⟩

/-- Any chosen count-one representative can accompany all the high vertices
after restoring a full star at c. -/
theorem cover_one (c : V) {e : V} (one : trianglesAt G e=1) :
    Covered (patch G {c}) (insert e (high (patch G {c}))) := by
  let J := patch G {c}
  by_cases hi : e∈high J
  · rw [show insert e (high J)=high J from insert_eq_of_mem hi]
    exact covers_high J
  have cap : J.degree e≤2 := by
    by_contra! big; exact hi (mem_filter.mpr ⟨mem_univ _,big⟩)
  have pos : 0<trianglesAt J e := by rw [show trianglesAt J e=trianglesAt G e from patch_scores ..,one]; decide
  obtain ⟨a,b,ea,eb,ab⟩ := (TrianglePrune.triangle_iff J e).mp pos
  have deg := Prerequisites.deg2 J ab.ne ea eb
  exact cover_two G (c:=c) (singleton_subset_iff.mpr (mem_insert_self ..)) (by change J.degree e=2; omega)

def Represents (W : Finset V) : Prop := (types G).erase 0 ⊆ W.image (trianglesAt G)

theorem represents_of_high {S W : Finset V} (inc : high (patch G S)⊆W)
    (ones : 1∈types G → ∃e∈W,trianglesAt G e=1) : Represents G W := by
  intro k km
  obtain ⟨ne,ht⟩ := mem_erase.mp km
  by_cases isOne : k=1
  · subst k; exact mem_image.mpr (ones ht)
  obtain ⟨v,_,rfl⟩ := mem_image.mp ht
  exact mem_image.mpr ⟨v,inc (rich_high G (by omega) S),rfl⟩

theorem representatives (c : V) : ∃W : Finset V,
    high (patch G {c})⊆W ∧ Covered (patch G {c}) W ∧ Represents G W := by
  by_cases one : 1∈types G
  · obtain ⟨e,_,se⟩ := mem_image.mp one
    exact ⟨_,subset_insert ..,cover_one G c se,represents_of_high G (subset_insert ..)
      (fun _ => ⟨e,mem_insert_self ..,se⟩)⟩
  · exact ⟨_,Subset.rfl,covers_high _,represents_of_high G Subset.rfl (fun m => (one m).elim)⟩

/-- Every cut covering representatives at a failure uses each positive type
exactly once. Each side then omits half of the positive spectrum. -/
theorem rigid {J : SimpleGraph V} [DecidableRel J.Adj] (le : J≤G) {W : Finset V}
    (rep : Represents G W) (cut : Covered J W) (fail : bound G<gamma G) :
    W.image (trianglesAt G)=(types G).erase 0 ∧ Set.InjOn (trianglesAt G) (W : Set V) ∧
    2*gamma G+W.card=2*Fintype.card V := by
  have ⟨odd,z⟩ := failure_requires_odd_zero G fail
  have pal := card_le_card rep
  have small := card_image_le (s:=W) (f:=trianglesAt G)
  have both := count_covered J cut
  have mono := Prerequisites.gamma_mono G J le
  have p := card_erase_of_mem z
  have total : (types G).card≤Fintype.card V := card_image_le.trans_eq card_univ
  unfold bound at fail
  exact ⟨(eq_of_subset_of_card_le rep (by omega)).symm,card_image_iff.mp (by omega),by omega⟩

end Graffiti384b.OddStars
#print axioms Graffiti384b.OddStars.patch_scores
#print axioms Graffiti384b.OddStars.cover_two
#print axioms Graffiti384b.OddStars.representatives
#print axioms Graffiti384b.OddStars.rigid
