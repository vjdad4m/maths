import LowSample384b

namespace Graffiti384b.TrianglePrune
open Finset SimpleGraph
open private Prune.links from Prune384b
open private Repair.omit_set from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

private def positive := univ.filter (fun v => 0 < trianglesAt G v)

private theorem triangle_iff (v : V) : 0 < trianglesAt G v ↔
    ∃ a b, G.Adj v a ∧ G.Adj v b ∧ G.Adj a b := by
  change 0 < (Prune.links G v).card ↔ _
  constructor
  · intro h
    obtain ⟨p,hp⟩ := card_pos.mp h
    obtain ⟨n,edge⟩ := mem_filter.mp hp
    obtain ⟨sub,two⟩ := mem_powersetCard.mp n
    obtain ⟨a,b,ne,eq⟩ := card_eq_two.mp two
    have aa : a ∈ p := by simp [eq]
    have bb : b ∈ p := by simp [eq]
    exact ⟨a,b,(G.mem_neighborFinset _ _).mp (sub aa),(G.mem_neighborFinset _ _).mp (sub bb),edge a aa b bb ne⟩
  · rintro ⟨a,b,va,vb,ab⟩
    apply card_pos.mpr
    refine ⟨{a,b},mem_filter.mpr ⟨mem_powersetCard.mpr ⟨?_,by simp [ab.ne]⟩,?_⟩⟩
    · exact insert_subset ((G.mem_neighborFinset _ _).mpr va)
        (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vb))
    · intro x hx y hy ne
      simp only [mem_insert,mem_singleton] at hx hy
      rcases hx with rfl | rfl <;> rcases hy with rfl | rfl <;> first | exact (ne rfl).elim | exact ab | exact ab.symm

private def skeleton (a : V) (x : Finset V) : SimpleGraph V where
  Adj u v := G.Adj u v ∧ ((∃ w, G.Adj u w ∧ G.Adj v w) ∨
    (u ∈ x ∧ v = a) ∨ (v ∈ x ∧ u = a))
  symm := by
    rintro u v ⟨uv,⟨w,uw,vw⟩ | ex | ex⟩
    · exact ⟨uv.symm,Or.inl ⟨w,vw,uw⟩⟩
    · exact ⟨uv.symm,Or.inr (Or.inr ex)⟩
    · exact ⟨uv.symm,Or.inr (Or.inl ex)⟩
  loopless := fun v h => h.1.ne rfl

private instance (a : V) (x : Finset V) : DecidableRel (skeleton G a x).Adj := fun _ _ =>
  inferInstanceAs (Decidable (_ ∧ (_ ∨ _ ∨ _)))

private theorem scores (a : V) (x : Finset V) (v : V) :
    trianglesAt (skeleton G a x) v = trianglesAt G v := by
  let J := skeleton G a x
  change (Prune.links J v).card = (Prune.links G v).card
  congr 1
  ext p
  simp only [Prune.links,mem_filter,mem_powersetCard]
  constructor
  · rintro ⟨⟨sub,two⟩,edge⟩
    exact ⟨⟨fun y hy => (G.mem_neighborFinset _ _).mpr ((J.mem_neighborFinset _ _).mp (sub hy)).1,two⟩,
      fun y hy z hz ne => (edge y hy z hz ne).1⟩
  · rintro ⟨⟨sub,two⟩,edge⟩
    have adj (y : V) (hy : y ∈ p) := (G.mem_neighborFinset _ _).mp (sub hy)
    refine ⟨⟨?_,two⟩,?_⟩
    · intro y hy
      obtain ⟨z,hz,ne⟩ := exists_ne_of_one_lt_card (by omega : 1 < p.card) y
      exact (J.mem_neighborFinset _ _).mpr ⟨adj y hy,Or.inl ⟨z,adj z hz,edge y hy z hz ne.symm⟩⟩
    · intro y hy z hz ne
      exact ⟨edge y hy z hz ne,Or.inl ⟨v,(adj y hy).symm,(adj z hz).symm⟩⟩

private def Closed (s : Finset V) := ∀ v ∈ s, ∀ w, G.Adj v w → w ∈ s

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
private theorem reach_closed (r : Finset V) (closed : Closed G r) {u v : V}
    (ur : u ∈ r) (reach : G.Reachable u v) : v ∈ r := by
  have walk := (G.reachable_iff_reflTransGen u v).mp reach
  clear reach
  induction walk with
  | refl => exact ur
  | tail _ adj h => exact closed _ h _ adj

/-- The triangle types are subadditive and omission capacities are additive
across components. A failing union contains a failing component. -/
private theorem extract (r : Finset V) (closed : Closed G r)
    (fail : 2*Capacity.value G r ∅ < (r.image (trianglesAt G)).card) :
    ∃ s ⊆ r, Closed G s ∧ (G.induce (s : Set V)).Connected ∧
      2*Capacity.value G s ∅ < (s.image (trianglesAt G)).card := by
  classical
  induction r using Finset.strongInduction with
  | H r ih =>
    obtain ⟨v,vr⟩ := card_pos.mp (lt_of_lt_of_le (Nat.zero_lt_of_lt fail) card_image_le)
    let c := G.connectedComponentMk v
    let s := c.supp.toFinset
    have vs : v ∈ s := Set.mem_toFinset.mpr rfl
    have sub : s ⊆ r := fun w hw => reach_closed G r closed vr
      (ConnectedComponent.exact ((c.mem_supp_iff w).mp (Set.mem_toFinset.mp hw)).symm)
    have sc : Closed G s := fun u hu w uw => Set.mem_toFinset.mpr ((c.mem_supp_congr_adj uw).mp (Set.mem_toFinset.mp hu))
    by_cases bad : 2*Capacity.value G s ∅ < (s.image (trianglesAt G)).card
    · have hs : (s : Set V) = c.supp := by ext w; exact Set.mem_toFinset
      exact ⟨s,sub,sc,by rw [hs]; exact c.connected_induce_supp,bad⟩
    · let q := r \ s
      have qs : q ∪ s = r := sdiff_union_of_subset sub
      have sep : ∀ u ∈ q, ∀ w ∈ s, ¬G.Adj u w := fun u hu w hw uw => (mem_sdiff.mp hu).2 (sc w hw u uw.symm)
      have add := Capacity.separated_add G q s ∅ (disjoint_left.mpr (fun _ h => (mem_sdiff.mp h).2)) sep
      rw [qs] at add
      have img := card_union_le (q.image (trianglesAt G)) (s.image (trianglesAt G))
      rw [← image_union,qs] at img
      have smaller : q ⊂ r := Finset.ssubset_iff_subset_ne.mpr ⟨sdiff_subset,fun eq =>
        (mem_sdiff.mp (eq.symm ▸ vr : v ∈ q)).2 vs⟩
      have qc : Closed G q := by
        intro u hu w uw
        exact mem_sdiff.mpr ⟨closed u (mem_sdiff.mp hu).1 w uw,fun ws => sep u hu w ws uw⟩
      obtain ⟨t,ts,co,cn,gap⟩ := ih _ smaller qc (by omega)
      exact ⟨t,ts.trans sdiff_subset,co,cn,gap⟩

end Graffiti384b.TrianglePrune
namespace Graffiti384b.TrianglePrune
open Finset SimpleGraph
open private Prune.links from Prune384b
open private Repair.omit_set from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem scores_closed (s : Finset V) (closed : Closed G s) (v : s) :
    trianglesAt (G.induce (s : Set V)) v = trianglesAt G v := by
  let H := G.induce (s : Set V)
  let emb : s ↪ V := Function.Embedding.subtype _
  have eq : (Prune.links H v).image (map emb) = Prune.links G v.val := by
    ext p
    constructor
    · intro hp
      obtain ⟨q,hq,rfl⟩ := mem_image.mp hp
      obtain ⟨qq,edge⟩ := mem_filter.mp hq
      obtain ⟨ns,two⟩ := mem_powersetCard.mp qq
      apply mem_filter.mpr
      refine ⟨mem_powersetCard.mpr ⟨?_,by simpa using two⟩,?_⟩
      · intro x hx
        obtain ⟨y,hy,rfl⟩ := mem_map.mp hx
        exact (G.mem_neighborFinset _ _).mpr ((H.mem_neighborFinset _ _).mp (ns hy))
      · intro x hx y hy ne
        obtain ⟨w,hw,rfl⟩ := mem_map.mp hx
        obtain ⟨z,hz,rfl⟩ := mem_map.mp hy
        exact edge w hw z hz (fun h => ne (congrArg emb h))
    · intro hp
      let q := p.subtype (fun w => w ∈ s)
      have mapped : q.map emb = p := subtype_map_of_mem (fun w hw => closed v v.property w
        ((G.mem_neighborFinset _ _).mp ((mem_powersetCard.mp (mem_filter.mp hp).1).1 hw)))
      obtain ⟨qq,edge⟩ := mem_filter.mp hp
      obtain ⟨ns,two⟩ := mem_powersetCard.mp qq
      apply mem_image.mpr ⟨q,?_,mapped⟩
      apply mem_filter.mpr
      refine ⟨mem_powersetCard.mpr ⟨?_,?_⟩,?_⟩
      · intro w hw
        exact (H.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp (ns (mem_subtype.mp hw)))
      · have cm := congrArg Finset.card mapped
        simpa [two] using cm
      · intro w hw z hz nz
        exact edge w.val (mem_subtype.mp hw) z.val (mem_subtype.mp hz) (fun e => nz (Subtype.ext e))
  change (Prune.links H v).card = (Prune.links G v.val).card
  rw [← eq,card_image_of_injective _ (Finset.map_injective emb)]


private theorem induced_cost (s : Finset V) :
    s.card ≤ gamma (G.induce (s : Set V)) + Capacity.value G s ∅ := by
  let H := G.induce (s : Set V)
  have available : {k : ℕ | ∃ d, TwoDominates H d ∧ d.card = k}.Nonempty :=
    ⟨_,univ,by simp [TwoDominates],rfl⟩
  obtain ⟨d,dom,sz⟩ := Nat.sInf_mem available
  change d.card = gamma H at sz
  let e : s ↪ V := Function.Embedding.subtype _
  let o := dᶜ.map e
  have good : Capacity.Feasible G s ∅ o := by
    refine ⟨?_,?_⟩
    · intro v hv
      obtain ⟨w,_,rfl⟩ := mem_map.mp hv
      exact w.property
    · intro v hv
      obtain ⟨w,hw,rfl⟩ := mem_map.mp hv
      have sub : (d.filter (H.Adj w)).map e ⊆ (∅ ∪ (s \ o)).filter (G.Adj (e w)) := by
        intro i hi
        obtain ⟨z,hz,rfl⟩ := mem_map.mp hi
        refine mem_filter.mpr ⟨mem_union_right _ (mem_sdiff.mpr ⟨z.property,?_⟩),(mem_filter.mp hz).2⟩
        intro om
        obtain ⟨y,hy,eq⟩ := mem_map.mp om
        exact mem_compl.mp hy (e.injective eq ▸ (mem_filter.mp hz).1)
      have hh := card_le_card sub
      rw [card_map] at hh
      exact (dom w (mem_compl.mp hw)).trans hh
  have om := Capacity.le_value G good
  simp only [o,card_map,card_compl,Fintype.card_coe] at om
  change s.card ≤ gamma H + _
  omega

private theorem select (hc : G.Connected) (many : 2 ≤ (types G).card) :
    ∃ a ∈ positive G, ∃ x : Finset V, x.card ≤ 1 ∧
      (∀ z ∈ x, trianglesAt G z = 0 ∧ G.Adj a z) ∧
      ((types G).card % 2 = 0 → x = ∅) ∧
      ((types G).card % 2 = 1 → 0 ∈ types G → x.Nonempty) := by
  have pn : (positive G).Nonempty := by
    by_contra! no
    have sub : types G ⊆ {0} := by
      intro j hj
      obtain ⟨v,_,rfl⟩ := mem_image.mp hj
      apply mem_singleton.mpr
      exact Nat.eq_zero_of_not_pos (fun p => no ⟨v,mem_filter.mpr ⟨mem_univ _,p⟩⟩)
    have := card_le_card sub
    simp only [card_singleton] at this
    omega
  obtain ⟨u,up⟩ := pn
  by_cases need : (types G).card % 2 = 1 ∧ 0 ∈ types G
  · obtain ⟨z,_,zz⟩ := mem_image.mp need.2
    have edge : ∃ a ∈ positive G, ∃ w, w ∉ positive G ∧ G.Adj a w := by
      by_contra! no
      have cl : Closed G (positive G) := fun v hv w vw => Classical.byContradiction (fun neg => no v hv w neg vw)
      have := (mem_filter.mp (reach_closed G _ cl up (hc u z))).2
      omega
    obtain ⟨a,ap,w,wn,aw⟩ := edge
    have wz : trianglesAt G w = 0 := Nat.eq_zero_of_not_pos (fun p => wn (mem_filter.mpr ⟨mem_univ _,p⟩))
    refine ⟨a,ap,{w},by simp,?_,by intro h; omega,by simp⟩
    intro z hz
    obtain rfl := mem_singleton.mp hz
    exact ⟨wz,aw⟩
  · exact ⟨u,up,∅,by simp,by simp,by simp,fun odd has => (need ⟨odd,has⟩).elim⟩

/-- All edges among positive-score vertices are triangle edges. At most
one zero-score vertex occurs and it has at most one neighbor. -/
def Normal : Prop :=
  (∀ v w, trianglesAt G v = 0 → trianglesAt G w = 0 → v = w) ∧
  (∀ z, trianglesAt G z = 0 → ∀ u v, G.Adj z u → G.Adj z v → u = v) ∧
  (∀ u v, G.Adj u v → 0 < trianglesAt G u → 0 < trianglesAt G v →
    ∃ w, G.Adj u w ∧ G.Adj v w)

/-- Remove zero-score vertices, triangle-free edges, and good connected
components. One pendant zero is available when the rounding requires it. -/
theorem normalize (hc : G.Connected) (ord : 2 < Fintype.card V) (fail : bound G < gamma G) :
    ∃ (s : Finset V) (J : SimpleGraph s) (d : DecidableRel J.Adj), letI := d
      2 < s.card ∧ J.Connected ∧ bound J < gamma J ∧ Normal J ∧
      (∀ u v : s, J.Adj u v → G.Adj u.val v.val) ∧
      (∀ v : s, trianglesAt J v = trianglesAt G v.val) ∧
      ((types G).card % 2 = 0 → ∀ v : s, 0 < trianglesAt J v) := by
  classical
  have many : 6 < (types G).card := by
    by_contra! small
    exact (not_le_of_gt fail) (Anchor.exact_of_six_types G hc ord small)
  obtain ⟨a,ap,x,xsize,xzero,even,odd⟩ := select G hc (by omega)
  let J := skeleton G a x
  let r := positive G ∪ x
  have ps (v : V) : trianglesAt J v = trianglesAt G v := scores G a x v
  have pMem {v : V} (pos : 0 < trianglesAt G v) : v ∈ positive G := mem_filter.mpr ⟨mem_univ _,pos⟩
  have atRoot := (mem_filter.mp ap).2
  have has {v w : V} (vw : J.Adj v w) : w ∈ r := by
    rcases vw.2 with ⟨z,vz,wz⟩ | ⟨_,rfl⟩ | ⟨wx,_⟩
    · exact mem_union_left _ (pMem ((triangle_iff G w).mpr ⟨v,z,vw.1.symm,wz,vz⟩))
    · exact mem_union_left _ ap
    · exact mem_union_right _ wx
  have only {z w : V} (zz : trianglesAt G z = 0) (zw : J.Adj z w) : w = a := by
    rcases zw.2 with ⟨y,zy,wy⟩ | ⟨_,eq⟩ | ⟨_,eq⟩
    · have := (triangle_iff G z).mpr ⟨w,y,zw.1,zy,wy⟩
      omega
    · exact eq
    · subst z
      omega
  have toX {z : V} (zr : z ∈ r) (zz : trianglesAt G z = 0) : z ∈ x := by
    rcases mem_union.mp zr with p | member
    · have := (mem_filter.mp p).2
      omega
    · exact member
  have image : types G ⊆ insert 0 (r.image (trianglesAt J)) := by
    intro j hj
    obtain ⟨v,_,rfl⟩ := mem_image.mp hj
    by_cases zero : trianglesAt G v = 0
    · exact mem_insert.mpr (Or.inl zero)
    · exact mem_insert_of_mem (mem_image.mpr ⟨v,mem_union_left _ (pMem (by omega)),ps v⟩)
  have stronger (par : (types G).card % 2 = 1) : types G ⊆ r.image (trianglesAt J) := by
    intro j hj
    rcases mem_insert.mp (image hj) with zero | inside
    · subst j
      obtain ⟨z,zx⟩ := odd par hj
      exact mem_image.mpr ⟨z,mem_union_right _ zx,(ps z).trans (xzero z zx).1⟩
    · exact inside
  obtain ⟨o,good,value⟩ := Capacity.attained J r ∅
  have omission : ∀ v ∈ o, 2 ≤ nbr G v oᶜ := by
    intro v vo
    apply (good.2 v vo).trans (card_le_card ?_)
    intro w hw
    obtain ⟨wr,edge⟩ := mem_filter.mp hw
    have diff : w ∈ r \ o := by simpa using wr
    exact mem_filter.mpr ⟨mem_compl.mpr (mem_sdiff.mp diff).2,edge.1⟩
  have budget := Repair.omit_set G o omission
  rw [value] at budget
  have deficit : 2*Capacity.value J r ∅ < (r.image (trianglesAt J)).card := by
    unfold bound at fail
    by_cases par : (types G).card % 2 = 1
    · have b := card_le_card (stronger par)
      omega
    · have b := (card_le_card image).trans (card_insert_le _ _)
      omega
  obtain ⟨s,sr,sc,conn,gap⟩ := extract J r (fun _ _ _ vw => has vw) deficit
  let F := J.induce (s : Set V)
  have keep (v : s) : trianglesAt F v = trianglesAt G v.val := (scores_closed J s sc v).trans (ps v)
  have same : types F = s.image (trianglesAt J) := by
    ext i
    constructor
    · intro hi
      obtain ⟨v,_,eq⟩ := mem_image.mp hi
      exact mem_image.mpr ⟨v,v.property,(scores_closed J s sc v).symm.trans eq⟩
    · intro hi
      obtain ⟨v,vs,eq⟩ := mem_image.mp hi
      exact mem_image.mpr ⟨⟨v,vs⟩,mem_univ _,(scores_closed J s sc ⟨v,vs⟩).trans eq⟩
  have big : 2 < s.card := by
    obtain ⟨v,vs⟩ := card_pos.mp (lt_of_lt_of_le (Nat.zero_lt_of_lt gap) card_image_le)
    have pos : ∃ w ∈ s, 0 < trianglesAt J w := by
      by_cases p : 0 < trianglesAt G v
      · exact ⟨v,vs,ps v ▸ p⟩
      · have vx := toX (sr vs) (by omega)
        have edge : J.Adj v a := ⟨(xzero v vx).2.symm,Or.inr (Or.inl ⟨vx,rfl⟩)⟩
        exact ⟨a,sc v vs a edge,ps a ▸ atRoot⟩
    obtain ⟨w,ws,p⟩ := pos
    obtain ⟨y,z,wy,wz,yz⟩ := (triangle_iff J w).mp p
    exact two_lt_card_iff.mpr ⟨w,y,z,ws,sc w ws y wy,sc w ws z wz,wy.ne,wz.ne,yz.ne⟩
  refine ⟨s,F,inferInstance,big,conn,?_,?_,fun _ _ edge => edge.1,keep,?_⟩
  · have dom := induced_cost J s
    change s.card ≤ gamma F + _ at dom
    unfold bound
    rw [Fintype.card_coe,same]
    have := card_image_le (s := s) (f := trianglesAt J)
    omega
  · refine ⟨?_,?_,?_⟩
    · intro u v uz vz
      exact Subtype.ext (card_le_one.mp xsize _ (toX (sr u.property) ((keep u).symm.trans uz))
        _ (toX (sr v.property) ((keep v).symm.trans vz)))
    · intro z zz u v zu zv
      exact Subtype.ext ((only ((keep z).symm.trans zz) zu).trans (only ((keep z).symm.trans zz) zv).symm)
    · intro u v uv pu pv
      have h : J.Adj u.val v.val := uv
      rcases h.2 with ⟨w,uw,vw⟩ | ⟨ux,_⟩ | ⟨vx,_⟩
      · have ju : J.Adj u.val w := ⟨uw,Or.inl ⟨v.val,h.1,vw.symm⟩⟩
        have jv : J.Adj v.val w := ⟨vw,Or.inl ⟨u.val,h.1.symm,uw.symm⟩⟩
        exact ⟨⟨w,sc _ u.property _ ju⟩,ju,jv⟩
      · have := (keep u).trans (xzero _ ux).1
        omega
      · have := (keep v).trans (xzero _ vx).1
        omega
  · intro par v
    rw [keep]
    by_contra! z
    have m := toX (sr v.property) (by omega)
    simp [even par] at m

end Graffiti384b.TrianglePrune

#print axioms Graffiti384b.TrianglePrune.normalize
