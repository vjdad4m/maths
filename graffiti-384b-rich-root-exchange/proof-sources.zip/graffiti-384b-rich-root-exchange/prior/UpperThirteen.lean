import LinkSparsity
import OriginalPins
namespace Graffiti384b.OddStars.UpperThirteen
open Finset SimpleGraph LeafCritical ShorePairs ReservedWheel OriginalPins LinkSparsity
open private ShoreRanks.active_hit from ShoreRanks
open private ShoreCounts.in_high from ShoreCounts
open private LeafCritical.max_compl LeafCritical.balance_max from LeafCritical
open private OriginalPins.upper_hit from OriginalPins
open private Repair.nbr_mono from Repair384b
open private Graffiti384b.cut from Proof384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- At most four vertices can branch. A four-clique-free neighbor set then
has at most one more internal edge than vertices. -/
private theorem four_branches (B R : Finset V) (small : B.card≤4)
    (ordinary : ∀v∈R,v∉B → nbr G v R≤1)
    (no4 : ∀T⊆R,G.IsNClique 4 T → False) : (pairs G R).card≤R.card+1 := by
  classical
  induction R using Finset.strongInduction with
  | H S ih =>
    by_cases subset : S⊆B
    · have n := (card_le_card subset).trans small
      have cap := card_filter_le (s:=S.powersetCard 2) (fun p => ∀x∈p,∀y∈p,x≠y → G.Adj x y)
      change (pairs G S).card≤_ at cap
      rw [card_powersetCard] at cap
      by_cases eq : S.card=4
      · by_contra! excess
        have choose : Nat.choose 4 2=6 := by decide
        have full : pairs G S=S.powersetCard 2 := eq_of_subset_of_card_le (filter_subset ..)
          (by rw [card_powersetCard,eq]; omega)
        apply no4 S Subset.rfl ⟨?_,eq⟩
        intro u um v vm uv
        have pair : ({u,v}:Finset V)∈S.powersetCard 2 :=
          mem_powersetCard.mpr ⟨insert_subset um (singleton_subset_iff.mpr vm),card_pair uv⟩
        have edge := (mem_filter.mp (show ({u,v}:Finset V)∈pairs G S from full ▸ pair)).2
        exact edge u (mem_insert_self ..) v (mem_insert_of_mem (mem_singleton_self _)) uv
      · have lo : S.card≤3 := by omega
        have c := Nat.choose_le_choose 2 lo
        have z : Nat.choose 3 2=3 := by decide
        by_cases s0 : S.card=0
        · rw [s0] at cap ⊢; simp_all
        by_cases s1 : S.card=1
        · rw [s1] at cap ⊢; simp_all
        omega
    · obtain ⟨v,vm,off⟩ := not_subset.mp subset
      let T := S.erase v
      have sub : T⊆S := erase_subset ..
      have val := ih T (erase_ssubset vm) (fun u um out =>
        (Repair.nbr_mono G u sub).trans (ordinary u (sub um) out)) (fun R rs => no4 R (rs.trans sub))
      have degree := (Repair.nbr_mono G v sub).trans (ordinary _ vm off)
      have size : T.card+1=S.card := card_erase_add_one vm
      have step := pairs_insert G (not_mem_erase v S)
      rw [insert_erase vm] at step
      change (pairs G S).card=(pairs G T).card+nbr G v T at step
      omega

private theorem unblocked {x : V} (bad : bound G<gamma G) (one : 1∉types G)
    (clear : ∀w,(patch G ∅).degree w=3 → ¬(patch G ∅).Adj w x) :
    2*trianglesAt G x+3≤3*(patch G ∅).degree x ∨ (patch G ∅).degree x=0 := by
  classical
  let J := patch G ∅
  let N := J.neighborFinset x
  by_cases pos : N.Nonempty
  · left
    have inc {P : Finset V} (p : P⊆N) : nbr G x P=P.card := by
      unfold nbr; rw [filter_true_of_mem (fun _ h => ((J.mem_neighborFinset ..).mp (p h)).1)]
    have free : Free J N := by
      intro P Q pn qn f hp
      have mon {v : V} {S : Finset V} : nbr J v S≤nbr G v S := card_le_card (fun _ h =>
        mem_filter.mpr ⟨(mem_filter.mp h).1,(mem_filter.mp h).2.1⟩)
      obtain ⟨p,pm⟩ := hp
      have largeQ := (f.left p pm).trans (card_filter_le ..)
      obtain ⟨q,qm⟩ := card_pos.mp (show 0<Q.card by omega)
      have largeP := (f.right q qm).trans (card_filter_le ..)
      have fg : Frame G P Q := ⟨f.dis,(fun _ h => (f.left _ h).trans mon),(fun _ h => (f.right _ h).trans mon)⟩
      have usable : Usable G x := ⟨P,Q,fg,(fun m => (J.not_mem_neighborFinset_self x)
        ((mem_union.mp m).elim (fun h => pn h) (fun h => qn h))),(inc pn).symm ▸ largeP,(inc qn).symm ▸ largeQ⟩
      obtain ⟨w,_,dw,e⟩ := OriginalPins.upper_hit G bad one usable
      exact clear w dw e
    have score := edge_bound J free pos
    change 2*trianglesAt J x+3≤3*(J.neighborFinset x).card at score
    rw [patch_scores,card_neighborFinset_eq_degree] at score
    exact score
  · right
    have n := not_nonempty_iff_eq_empty.mp pos
    rw [←card_neighborFinset_eq_degree,show J.neighborFinset x=∅ from n,card_empty]

private theorem ordinary_bound (bad : bound G<gamma G) (one : 1∉types G) {A : Finset V}
    (mx : Maximum (patch G ∅) A) {u v : V}
    (classify : ∀w,(patch G ∅).degree w=3 ↔ w=u ∨ w=v)
    (cover : ∀w∈active (patch G ∅) A,w∈crossed (patch G ∅) A u∪crossed (patch G ∅) A v)
    {x : V} (xh : x∈high (patch G ∅)) (xa : x∈A)
    (off : x∉crossed (patch G ∅) A u∪crossed (patch G ∅) A v) :
    let m := (high (patch G ∅)∩Aᶜ).card
    2*trianglesAt G x≤3*m ∨ trianglesAt G x≤m+3 := by
  classical
  let J := patch G ∅
  let H := high J
  let N := J.neighborFinset x
  let R := N\A
  let L := N∩A
  let m := (H∩Aᶜ).card
  have sz := (PaletteCorollaries.upper_iff_no_one G bad).mpr one
  have small : L.card≤1 := by
    have nx : x∉active J A := fun h => off (cover _ h)
    have eq : nbr J x A=L.card := by unfold nbr; congr 1; ext; simp [L,N,and_comm]
    by_contra! big
    apply nx
    exact mem_filter.mpr ⟨xh,by rw [if_pos xa,eq]; omega⟩
  have subR : R⊆H∩Aᶜ := by
    intro w m
    obtain ⟨wn,wa⟩ := mem_sdiff.mp m
    exact mem_inter.mpr ⟨ShoreCounts.in_high G bad sz ((J.mem_neighborFinset ..).mp wn),mem_compl.mpr wa⟩
  have rcap : R.card≤m := card_le_card subR
  have parts : R.card+L.card=N.card := card_sdiff_add_card_inter .. 
  by_cases hit : ∃w,J.degree w=3 ∧ J.Adj w x
  · right
    obtain ⟨w,dw,wx⟩ := hit
    have no : x∉crossed J A w := by
      rcases (classify _).mp dw with rfl|rfl
      · exact fun h => off (mem_union_left _ h)
      · exact fun h => off (mem_union_right _ h)
    have wa : w∈A := by
      by_contra out
      exact no (mem_filter.mpr ⟨(J.mem_neighborFinset ..).mpr wx,fun eq => out (eq.mpr xa)⟩)
    have wl : w∈L := mem_inter.mpr ⟨(J.mem_neighborFinset ..).mpr wx.symm,wa⟩
    have eqL : L={w} := eq_singleton_iff_unique_mem.mpr ⟨wl,fun y ym => card_le_one.mp small _ ym _ wl⟩
    have whole : N=insert w R := by
      have join := sdiff_union_inter N A
      change R∪L=N at join
      rw [eqL] at join; simpa [union_comm] using join.symm
    have woff : w∉R := fun wr => (mem_sdiff.mp wr).2 wa
    have edges := four_branches J (active J A) R (at_most_four_active G bad sz mx)
      (fun i im notact => by
        have ioff := (mem_sdiff.mp im).2
        have d : nbr J i Aᶜ≤1 := by
          by_contra! plenty
          exact notact (mem_filter.mpr ⟨(mem_inter.mp (subR im)).1,by simpa [ioff] using plenty⟩)
        exact (Repair.nbr_mono J i (fun j jm => mem_compl.mpr (mem_sdiff.mp jm).2)).trans d)
      (by
        intro C cc cl
        have xc : x∉C := fun h => (J.not_mem_neighborFinset_self x) (mem_sdiff.mp (cc h)).1
        apply UpperClique.no_five G bad sz (insert x C)
        refine ⟨?_,by rw [card_insert_of_not_mem xc,cl.2]⟩
        intro a am b bm ab
        by_cases ax : a=x
        · subst a
          have bC := (mem_insert.mp bm).resolve_left ab.symm
          exact ((J.mem_neighborFinset ..).mp (mem_sdiff.mp (cc bC)).1).1
        have aC := (mem_insert.mp am).resolve_left ax
        by_cases bx : b=x
        · subst b
          exact ((J.mem_neighborFinset ..).mp (mem_sdiff.mp (cc aC)).1).1.symm
        exact (cl.1 aC ((mem_insert.mp bm).resolve_left bx) ab).1)
    have csub : R.filter (J.Adj w)⊆(J.neighborFinset w).erase x := fun y ym =>
      mem_erase.mpr ⟨fun eq => (mem_sdiff.mp (mem_filter.mp ym).1).2 (eq ▸ xa),(J.mem_neighborFinset ..).mpr (mem_filter.mp ym).2⟩
    have upper := card_le_card csub
    rw [card_erase_of_mem ((J.mem_neighborFinset ..).mpr wx),card_neighborFinset_eq_degree,dw] at upper
    have score : trianglesAt G x=(pairs J N).card := (patch_scores G ∅ x).symm
    rw [whole,pairs_insert J woff] at score
    change nbr J w R≤3-1 at upper
    change trianglesAt G x≤m+3
    omega
  · left
    have val := unblocked G bad one (x:=x) (fun w d e => hit ⟨w,d,e⟩)
    have dg := (mem_filter.mp xh).2
    rw [←card_neighborFinset_eq_degree] at val
    change 2*trianglesAt G x+3≤3*N.card ∨ N.card=0 at val
    have nz : 3≤N.card := by change 3≤(J.neighborFinset x).card; rw [card_neighborFinset_eq_degree]; exact dg
    change 2*trianglesAt G x≤3*m
    omega

/-- The upper profile has at most thirteen distinct triangle counts,
independently of the number of leaves or of graph order. -/
theorem diversity_cap (conn : G.Connected) (order : 2<Fintype.card V) (bad : bound G<gamma G)
    (one : 1∉types G) : (types G).card≤13 := by
  classical
  let J := patch G ∅
  let H := high J
  obtain ⟨_,u,v,_,_,_,_,char,crit⟩ := PaletteCorollaries.missing_one_failure G conn order bad one
  obtain ⟨A,_,opt⟩ := exists_max_image (univ : Finset (Finset V)) (fun A => Graffiti384b.cut J A Aᶜ) univ_nonempty
  have mx : Maximum J A := fun B => opt B (mem_univ _)
  let Z := crossed J A u∪crossed J A v
  let W := H\Z
  have sz := (PaletteCorollaries.upper_iff_no_one G bad).mpr one
  change H.card+1=(types G).card at sz
  have cover {B : Finset V} (mb : Maximum J B) :
      ∀w∈active J B,w∈crossed J B u∪crossed J B v := by
    intro w wm
    obtain ⟨c,cm,e⟩ := ShoreRanks.active_hit G bad sz mb wm
    rw [crit B mb,mem_insert,mem_singleton] at cm
    rcases cm with rfl|rfl
    · exact mem_union_left _ e
    · exact mem_union_right _ e
  have cU : u∈critical J A := (crit A mx) ▸ mem_insert_self ..
  have cV : v∈critical J A := (crit A mx) ▸ mem_insert_of_mem (mem_singleton_self _)
  have cZ := card_union_le (crossed J A u) (crossed J A v)
  rw [(mem_filter.mp cU).2,(mem_filter.mp cV).2] at cZ
  have cap : Z.card≤4 := cZ
  have mx' := LeafCritical.max_compl J mx
  have bal := LeafCritical.balance_max G bad sz mx
  have bal' := LeafCritical.balance_max G bad sz mx'
  let m := H.card/2
  have a : (H∩A).card=m := by change 2*(H∩A).card=H.card at bal; dsimp [m]; omega
  have b : (H∩Aᶜ).card=m := by change 2*(H∩Aᶜ).card=H.card at bal'; dsimp [m]; omega
  have total : H.card=2*m := by change 2*(H∩A).card=H.card at bal; omega
  by_contra! large
  have big : 7≤m := by omega
  have offbound {x : V} (xm : x∈W) : 2*trianglesAt G x≤3*m := by
    obtain ⟨xh,off⟩ := mem_sdiff.mp xm
    by_cases xa : x∈A
    · have h := ordinary_bound G bad one mx char (cover mx) xh xa off
      change 2*trianglesAt G x≤3*(H∩Aᶜ).card ∨ trianglesAt G x≤(H∩Aᶜ).card+3 at h
      omega
    · have opposite (c : V) : crossed J Aᶜ c=crossed J A c := by
        ext w; simp [crossed]; tauto
      have miss : x∉crossed J Aᶜ u∪crossed J Aᶜ v := by rwa [opposite,opposite]
      have h := ordinary_bound G bad one mx' char (cover mx') xh (mem_compl.mpr xa) miss
      change 2*trianglesAt G x≤3*(H∩Aᶜᶜ).card ∨ trianglesAt G x≤(H∩Aᶜᶜ).card+3 at h
      rw [compl_compl] at h; omega
  have rich {x : V} (xm : x∈W) : 2≤trianglesAt G x := by
    have dg : 3≤J.degree x := (mem_filter.mp (mem_sdiff.mp xm).1).2
    have ub := skeleton_degree_bound G x
    change J.degree x≤_ at ub
    omega
  have inj : Set.InjOn (trianglesAt G) (W:Set V) := fun _ xm _ _ e => distinct_rich G bad (rich xm) e
  have inc : W.image (trianglesAt G)⊆Icc 2 (3*m/2) := by
    intro k km; obtain ⟨x,xm,rfl⟩ := mem_image.mp km
    exact mem_Icc.mpr ⟨rich xm,by have := offbound xm; omega⟩
  have count := card_le_card inc
  rw [card_image_iff.mpr inj,Nat.card_Icc] at count
  have lost := card_le_card (inter_subset_right (s₁:=H) (s₂:=Z))
  have part : W.card+(H∩Z).card=H.card := card_sdiff_add_card_inter .. 
  omega

theorem exact_missing_one_of_fourteen (conn : G.Connected) (order : 2<Fintype.card V)
    (one : 1∉types G) (many : 14≤(types G).card) : gamma G≤bound G := by
  apply Nat.le_of_not_gt; intro bad
  have := diversity_cap G conn order bad one
  omega
end Graffiti384b.OddStars.UpperThirteen
#print axioms Graffiti384b.OddStars.UpperThirteen.diversity_cap
#print axioms Graffiti384b.OddStars.UpperThirteen.exact_missing_one_of_fourteen
