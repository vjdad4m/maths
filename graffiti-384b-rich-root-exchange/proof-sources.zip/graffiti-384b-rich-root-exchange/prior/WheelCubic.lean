import WheelCut
namespace Graffiti384b.OddStars.WheelCubic
open SimpleGraph Finset WheelCut
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def Center (x : V) : Prop := ∃a b c d,Rim G x a b c d

/-- Every neighborhood square needs a neighboring unpinned cubic. The same
two cubics account for all centers, whichever square is chosen at a center. -/
theorem center_cover (conn : G.Connected) (order : 2<Fintype.card V) (bad : bound G<gamma G)
    (one : 1∉types G) : ∃u v : V,trianglesAt G u=2 ∧ trianglesAt G v=3 ∧
      (patch G ∅).degree u=3 ∧ (patch G ∅).degree v=3 ∧
      (∀x a b c d,Rim G x a b c d →
        ∃w,(w=u ∨ w=v) ∧ (patch G ∅).Adj w x ∧ w≠a ∧ w≠b ∧ w≠c ∧ w≠d) := by
  obtain ⟨_,u,v,_,su,sv,_,cub,_⟩ := PaletteCorollaries.missing_one_failure G conn order bad one
  refine ⟨u,v,su,sv,(cub _).mpr (Or.inl rfl),(cub _).mpr (Or.inr rfl),?_⟩
  intro x a b c d rim
  obtain ⟨w,dw,e,out⟩ := exterior_cubic G bad one rim
  exact ⟨w,(cub _).mp dw,e,out⟩

/-- Seven different vertices with squares in their neighborhoods suffice for
the catalogue inequality when count one is absent. -/
theorem exact_of_seven_centers (conn : G.Connected) (order : 2<Fintype.card V)
    (one : 1∉types G) (C : Finset V) (centers : ∀x∈C,Center G x) (large : 7≤C.card) :
    gamma G≤bound G := by
  apply Nat.le_of_not_gt
  intro bad
  let J := patch G ∅
  obtain ⟨u,v,_,_,du,dv,cover⟩ := center_cover G conn order bad one
  have inc : C⊆J.neighborFinset u∪J.neighborFinset v := by
    intro x xm
    obtain ⟨a,b,c,d,r⟩ := centers _ xm
    obtain ⟨w,h,e,_⟩ := cover _ _ _ _ _ r
    rcases h with rfl|rfl
    · exact mem_union_left _ ((J.mem_neighborFinset ..).mpr e)
    · exact mem_union_right _ ((J.mem_neighborFinset ..).mpr e)
  have lo := card_le_card inc
  have hi := card_union_le (J.neighborFinset u) (J.neighborFinset v)
  simp only [card_neighborFinset_eq_degree] at hi
  change J.degree u=3 at du
  change J.degree v=3 at dv
  omega

/-- In a failure the three neighbors of the score-three cubic have no
other common original neighbor. -/
theorem cubic_triangle_private (conn : G.Connected) (order : 2<Fintype.card V) (bad : bound G<gamma G)
    (one : 1∉types G) {v : V} (dv : (patch G ∅).degree v=3) (sv : trianglesAt G v=3)
    {y : V} (sees : ∀a,(patch G ∅).Adj v a → G.Adj y a) : y=v := by
  classical
  by_contra yv
  let J := patch G ∅
  obtain ⟨u,v',su,sv',du,_,cover⟩ := center_cover G conn order bad one
  have eq : v=v' := distinct_rich G bad (by omega) (sv.trans sv'.symm)
  subst v'
  have full {a b : V} (va : J.Adj v a) (vb : J.Adj v b) (ab : a≠b) : G.Adj a b :=
    (FixedCubics.full_neighbors J dv ((patch_scores G ∅ v).trans sv) va vb ab).1
  have inc : J.neighborFinset v⊆J.neighborFinset u := by
    intro a am
    let R := (J.neighborFinset v).erase a
    have sz : R.card=2 := by dsimp only [R]; rw [card_erase_of_mem am,card_neighborFinset_eq_degree,dv]
    obtain ⟨b,c,bc,eqR⟩ := card_eq_two.mp sz
    have bm : b∈R := eqR ▸ mem_insert_self ..
    have cm : c∈R := eqR ▸ mem_insert_of_mem (mem_singleton_self _)
    obtain ⟨ba,bn⟩ := mem_erase.mp bm
    obtain ⟨ca,cn⟩ := mem_erase.mp cm
    have va := (J.mem_neighborFinset ..).mp am
    have vb := (J.mem_neighborFinset ..).mp bn
    have vc := (J.mem_neighborFinset ..).mp cn
    have r : Rim G a v y b c := ⟨Ne.symm yv,bc,va.1.symm,(sees _ va).symm,
      full va vb ba.symm,full va vc ca.symm,vb.1,vc.1,sees _ vb,sees _ vc⟩
    obtain ⟨w,which,edge,out,_⟩ := cover _ _ _ _ _ r
    exact (J.mem_neighborFinset ..).mpr ((which.resolve_right out) ▸ edge)
  have eqN := eq_of_subset_of_card_le inc (by rw [card_neighborFinset_eq_degree,card_neighborFinset_eq_degree,du,dv])
  have same : trianglesAt J v=trianglesAt J u := by unfold trianglesAt; rw [eqN]
  rw [patch_scores,patch_scores,sv,su] at same
  contradiction

end Graffiti384b.OddStars.WheelCubic
#print axioms Graffiti384b.OddStars.WheelCubic.center_cover
#print axioms Graffiti384b.OddStars.WheelCubic.exact_of_seven_centers
#print axioms Graffiti384b.OddStars.WheelCubic.cubic_triangle_private
