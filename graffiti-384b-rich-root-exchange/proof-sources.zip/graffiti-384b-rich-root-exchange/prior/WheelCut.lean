import PaletteCorollaries
namespace Graffiti384b.OddStars.WheelCut
open SimpleGraph Finset
open private Repair.isolate Repair.iso_nbr Repair.full_nbr Repair.nbr_mono Repair.omit_set from Repair384b
open private CliquePivot33.isolated_degree from ShoreCliquePivot
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Omit the pivot on both sides of the pinned cut. Only the selected
vertices need a degree lower bound. -/
theorem weighted_pivot (W : Finset V) {x : V} {P Q : Finset V} (dis : Disjoint P Q)
    (xp : x∉P) (xq : x∉Q) (px : 2≤nbr G x P) (qx : 2≤nbr G x Q)
    (pinP : ∀v∈P,2≤nbr G v Q) (pinQ : ∀v∈Q,2≤nbr G v P)
    (free : ∀v∈W,v≠x → v∉P → v∉Q → 3≤(Repair.isolate G x).degree v) :
    2*gamma G + W.card+1≤2*Fintype.card V := by
  classical
  let J := Repair.isolate G x
  let S := W.erase x
  obtain ⟨A,pa,qb,la,rb⟩ := PinnedColor34.cut J P Q dis
  have side (B D F : Finset V) (dB : D⊆B) (fB : F⊆Bᶜ) (xf : x∉F)
      (nx : 2≤nbr G x F) (pinned : ∀v∈D,2≤nbr G v F)
      (deg : ∀v∈W,v≠x → v∉D → v∉F → 3≤J.degree v)
      (cut : ∀v∈B,v∉D → nbr J v B≤nbr J v Bᶜ) :
      gamma G+(S∩B).card+1≤Fintype.card V := by
    let O := insert x (S∩B)
    have inc : Bᶜ.erase x⊆Oᶜ := by
      intro y m
      obtain ⟨yx,yb⟩ := mem_erase.mp m
      exact mem_compl.mpr (fun h => (mem_insert.mp h).elim yx
        (fun s => mem_compl.mp yb (mem_inter.mp s).2))
    have sub : F⊆Bᶜ.erase x := fun _ m => mem_erase.mpr ⟨fun eq => xf (eq ▸ m),fB m⟩
    have boundO := Repair.omit_set G O (by
      intro v vm
      rcases mem_insert.mp vm with rfl|vs
      · exact nx.trans (Repair.nbr_mono G _ (sub.trans inc))
      obtain ⟨vs,vb⟩ := mem_inter.mp vs
      obtain ⟨vx,vw⟩ := mem_erase.mp vs
      by_cases vd : v∈D
      · exact (pinned _ vd).trans (Repair.nbr_mono G _ (sub.trans inc))
      have lo := deg v vw vx vd (fun fm => mem_compl.mp (fB fm) vb)
      have cross := cut v vb vd
      have total := Repair.full_nbr J v B
      have good : 2≤nbr J v Bᶜ := by omega
      rw [Repair.iso_nbr G vx] at good
      exact good.trans (Repair.nbr_mono G _ inc))
    have noc : x∉S∩B := fun m => not_mem_erase _ _ (mem_inter.mp m).1
    have sz : O.card=(S∩B).card+1 := card_insert_of_not_mem noc
    have cap := card_le_univ O
    omega
  have l := side A P Q pa qb xq qx pinP free la
  have r := side Aᶜ Q P qb (by simpa using pa) xp px pinQ
    (fun v vm vx vq vp => free v vm vx vp vq) (by simpa using fun v vm vq => (rb v vm vq).le)
  have sizes := card_inter_add_card_sdiff S A
  have second : S∩Aᶜ=S\A := by ext; simp
  rw [second] at r
  have old : W.card≤S.card+1 := by
    by_cases m : x∈W
    · exact (card_erase_add_one m).ge
    · simp [S,erase_eq_of_not_mem m]
  omega

/-- Four rim vertices form a square inside the neighborhood of its center.
Neither diagonal is prescribed. -/
structure Rim (x a b c d : V) : Prop where
  ab : a≠b
  cd : c≠d
  xa : G.Adj x a
  xb : G.Adj x b
  xc : G.Adj x c
  xd : G.Adj x d
  ac : G.Adj a c
  ad : G.Adj a d
  bc : G.Adj b c
  bd : G.Adj b d

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem Rim.skeleton {x a b c d : V} (r : Rim G x a b c d) : Rim (patch G ∅) x a b c d :=
  ⟨r.ab,r.cd,⟨r.xa,Or.inl ⟨c,r.xc,r.ac⟩⟩,⟨r.xb,Or.inl ⟨c,r.xc,r.bc⟩⟩,
   ⟨r.xc,Or.inl ⟨a,r.xa,r.ac.symm⟩⟩,⟨r.xd,Or.inl ⟨a,r.xa,r.ad.symm⟩⟩,
   ⟨r.ac,Or.inl ⟨x,r.xa.symm,r.xc.symm⟩⟩,⟨r.ad,Or.inl ⟨x,r.xa.symm,r.xd.symm⟩⟩,
   ⟨r.bc,Or.inl ⟨x,r.xb.symm,r.xc.symm⟩⟩,⟨r.bd,Or.inl ⟨x,r.xb.symm,r.xd.symm⟩⟩⟩

theorem wheel_saving {x a b c d : V} (r : Rim G x a b c d)
    (clear : ∀w,G.degree w=3 → G.Adj w x → w=a ∨ w=b ∨ w=c ∨ w=d) :
    2*gamma G+(high G).card+1≤2*Fintype.card V := by
  classical
  have pair {z p q : V} (ne : p≠q) (zp : G.Adj z p) (zq : G.Adj z q) : 2≤nbr G z {p,q} := by
    unfold nbr
    rw [filter_true_of_mem (by intro w m; simp only [mem_insert,mem_singleton] at m; rcases m with rfl|rfl <;> assumption),card_pair ne]
  apply weighted_pivot G (high G) (x:=x) (P:={a,b}) (Q:={c,d})
  · apply disjoint_left.mpr
    simp only [mem_insert,mem_singleton]
    rintro w (rfl|rfl) (rfl|rfl)
    · exact r.ac.ne rfl
    · exact r.ad.ne rfl
    · exact r.bc.ne rfl
    · exact r.bd.ne rfl
  · simpa using And.intro r.xa.ne r.xb.ne
  · simpa using And.intro r.xc.ne r.xd.ne
  · exact pair r.ab r.xa r.xb
  · exact pair r.cd r.xc r.xd
  · intro w m; simp only [mem_insert,mem_singleton] at m
    rcases m with rfl|rfl
    · exact pair r.cd r.ac r.ad
    · exact pair r.cd r.bc r.bd
  · intro w m; simp only [mem_insert,mem_singleton] at m
    rcases m with rfl|rfl
    · exact pair r.ab r.ac.symm r.bc.symm
    · exact pair r.ab r.ad.symm r.bd.symm
  · intro w wm wx wp wq
    have deg : 3≤G.degree w := (mem_filter.mp wm).2
    rw [CliquePivot33.isolated_degree G wx]
    by_cases n : G.Adj w x
    · rw [card_erase_of_mem ((G.mem_neighborFinset ..).mpr n),card_neighborFinset_eq_degree]
      have ne : G.degree w≠3 := by
        intro eq
        have c := clear w eq n
        simp only [mem_insert,mem_singleton,not_or] at wp wq
        tauto
      omega
    · rwa [erase_eq_of_not_mem (fun m => n ((G.mem_neighborFinset ..).mp m)),card_neighborFinset_eq_degree]

theorem exterior_cubic (bad : bound G<gamma G) (one : 1∉types G) {x a b c d : V}
    (r : Rim G x a b c d) : ∃w,(patch G ∅).degree w=3 ∧ (patch G ∅).Adj w x ∧
      w≠a ∧ w≠b ∧ w≠c ∧ w≠d := by
  classical
  let J := patch G ∅
  have sz := (PaletteCorollaries.upper_iff_no_one G bad).mpr one
  by_contra! no
  have save := wheel_saving J (r.skeleton G) (by
    intro w dw edge
    by_contra! out
    exact out.2.2.2 (no w dw edge out.1 out.2.1 out.2.2.1))
  have mono := PositivePalette.Prerequisites.gamma_mono G J (fun _ _ e => e.1)
  change (high J).card+1=(types G).card at sz
  unfold bound at bad
  omega

end Graffiti384b.OddStars.WheelCut
#print axioms Graffiti384b.OddStars.WheelCut.weighted_pivot
#print axioms Graffiti384b.OddStars.WheelCut.wheel_saving
#print axioms Graffiti384b.OddStars.WheelCut.exterior_cubic
