import AnchorScores
namespace Graffiti384b.Shared29.CapTest
open Finset SimpleGraph Donor LowSample
/-- The same five-vertex adjacency table used in Squares29.Example.sharp_two. -/
def neighbors : Fin 5 → Finset (Fin 5)
  | 0 => {1,2,3,4}
  | 1 => {0,2,3}
  | 2 => {0,1,4}
  | 3 => {0,1}
  | 4 => {0,2}

def graph : SimpleGraph (Fin 5) where
  Adj u v := v∈neighbors u
  symm := by
    have s : ∀ u v : Fin 5,v∈neighbors u → u∈neighbors v := by decide
    exact fun i j => s i j
  loopless := by change ∀ i : Fin 5,i∉neighbors i; decide

instance : DecidableRel graph.Adj := fun i j => inferInstanceAs (Decidable (j∈neighbors i))

set_option maxRecDepth 32768
set_option maxHeartbeats 4000000


private def anchors := graph.neighborFinset 3 ∪ graph.neighborFinset 4

/-- The additive allowance of two incident ears in the anchor cap is attained,
even when the two ear neighborhoods meet at only one vertex. -/
theorem two_ear_allowance :
    twos graph={3,4} ∧ anchors.card=3 ∧
    (graph.neighborFinset 3 ∩ graph.neighborFinset 4)={0} ∧
    (exposed graph (high graph\anchors)).card=0 ∧
    trianglesAt graph 0=3 ∧
    ((exposed graph (high graph\anchors)).card+2).choose 2+1<trianglesAt graph 0 := by
  decide
end Graffiti384b.Shared29.CapTest
#print axioms Graffiti384b.Shared29.CapTest.two_ear_allowance
