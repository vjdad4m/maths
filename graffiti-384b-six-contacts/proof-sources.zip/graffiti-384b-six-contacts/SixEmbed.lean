import SixModel
import ForkClosure
namespace Graffiti384b.SixFront.Model
open Finset SimpleGraph LowSample
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

set_option maxHeartbeats 0 in
private theorem keys : ∀a b x y:Label,a<b → x<y → b.val<10 → y.val<10 →
    position a b=position x y → a=x ∧ b=y := by decide

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem represents (f : Label ↪ V)
    (shape : ∀i j:Label, (10 ≤ i.val ∨ 10 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j))) :
    ∃a:ℕ→Bool,∀i j:Label,edge a i j=true ↔ G.Adj (f i) (f j) := by
  classical
  let a := fun n : ℕ => decide (∃x y:Label,x<y ∧ y.val<10 ∧ position x y=n ∧ G.Adj (f x) (f y))
  have value (i j : Label) (ij : i<j) (j9 : j.val<10) : a (position i j)=true ↔ G.Adj (f i) (f j) := by
    change decide _=true ↔ _
    rw [decide_eq_true_eq]
    constructor
    · rintro ⟨x,y,xy,y9,k,adj⟩
      obtain ⟨rfl,rfl⟩ := keys _ _ _ _ xy ij y9 j9 k
      exact adj
    · exact fun h => ⟨i,j,ij,j9,rfl,h⟩
  refine ⟨a,?_⟩
  intro i j; unfold edge
  by_cases eq : i=j
  · subst j; simp
  rw [if_neg eq]
  split
  · rename_i young
    rcases lt_or_gt_of_ne eq with lt|gt
    · exact value i j lt young.2
    · rw [show position i j=position j i by simp [position,max_comm,min_comm],value j i gt young.1]
      exact G.adj_comm _ _
  · rename_i old; exact shape i j (by omega)

/-- Every link edge has two distinct labels, and their order makes the representation unique. -/
theorem counts (f : Label ↪ V) (a : ℕ→Bool)
    (edges : ∀i j:Label,edge a i j=true ↔ G.Adj (f i) (f j)) (i : Label)
    (locality : ∀z∈Repair.linkSupport G (f i),z∈Set.range f) :
    (triangles a i).card=trianglesAt G (f i) := by
  classical
  let P := triangles a i
  let liftPair (z : Label×Label) : Finset V := {f z.1,f z.2}
  have sm (z : Label×Label) : z∈P ↔ z.1<z.2 ∧ G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2) := by
    simp [P,triangles,pairs,edges,and_assoc]
  have repr : P.image liftPair=Repair.linkEdges G (f i) := by
    ext s
    constructor
    · intro hm
      obtain ⟨⟨a,b⟩,ab,rfl⟩ := mem_image.mp hm
      obtain ⟨lt,ia,ib,adj⟩ := (sm _).mp ab
      have sub : liftPair (a,b)⊆G.neighborFinset (f i) := insert_subset ((G.mem_neighborFinset ..).mpr ia)
        (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr ib))
      refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub,card_pair (f.injective.ne lt.ne)⟩,?_⟩
      intro x xm y ym ne
      simp only [liftPair,mem_insert,mem_singleton] at xm ym
      rcases xm with rfl|rfl <;> rcases ym with rfl|rfl <;> first | exact (ne rfl).elim | exact adj | exact adj.symm
    · intro hm
      obtain ⟨sub,sz,cl⟩ := Repair.edge_info G hm
      obtain ⟨x,y,ne,rfl⟩ := card_eq_two.mp sz
      have xm : x∈({x,y}:Finset V) := mem_insert_self ..
      have ym : y∈({x,y}:Finset V) := mem_insert_of_mem (mem_singleton_self _)
      obtain ⟨a,rfl⟩ := locality x (mem_biUnion.mpr ⟨_,hm,xm⟩)
      obtain ⟨b,rfl⟩ := locality y (mem_biUnion.mpr ⟨_,hm,ym⟩)
      have ia := (G.mem_neighborFinset ..).mp (sub xm)
      have ib := (G.mem_neighborFinset ..).mp (sub ym)
      have adj := cl _ xm _ ym ne
      rcases lt_or_gt_of_ne (fun eq : a=b => ne (congrArg f eq)) with l|l
      · exact mem_image.mpr ⟨(a,b),(sm _).mpr ⟨l,ia,ib,adj⟩,rfl⟩
      · exact mem_image.mpr ⟨(b,a),(sm _).mpr ⟨l,ib,ia,adj.symm⟩,pair_comm ..⟩
  have inj : Set.InjOn liftPair (P : Set (Label×Label)) := by
    rintro ⟨a,b⟩ ap ⟨c,d⟩ cp eq
    have lt := ((sm _).mp ap).1
    have lt' := ((sm _).mp cp).1
    have eq' : ({f a,f b}:Set V)={f c,f d} := by simpa [liftPair] using congrArg (fun s : Finset V => (s:Set V)) eq
    rcases Set.pair_eq_pair_iff.mp eq' with ⟨ac,bd⟩|⟨ad,bc⟩
    · exact Prod.ext (f.injective ac) (f.injective bd)
    · have := f.injective ad
      have := f.injective bc
      change a<b at lt; change c<d at lt'
      subst c; subst d; exact (not_lt_of_ge lt.le lt').elim
  have count := congrArg Finset.card repr
  rw [card_image_of_injOn inj] at count
  exact count


def atContact (i : Fin 6) : Label := ⟨4+i.val,by omega⟩

/-- Exactly the intrinsic information required from a labeled six-contact patch. -/
structure Layout where
  lab : Label ↪ V
  first : G.neighborFinset (lab 10)={lab 0,lab 1}
  second : G.neighborFinset (lab 11)={lab 2,lab 3}
  support : ∀r:Root,∀z∈Repair.linkSupport G (lab (atRoot r)),z∈Set.range lab
  major : 13≤trianglesAt G (lab 0)
  k : Fin 7
  sorted : ∀i:Fin 6,G.Adj (lab 0) (lab (atContact i)) ↔ i.val<k.val

theorem Layout.shape (F : Layout G) (i j : Label) (old : 10 ≤ i.val ∨ 10≤j.val) :
    preset i j=true ↔ G.Adj (F.lab i) (F.lab j) := by
  have star10 (j : Label) : G.Adj (F.lab 10) (F.lab j) ↔ j=0 ∨ j=1 := by
    rw [←G.mem_neighborFinset,F.first,mem_insert,mem_singleton]; simp only [F.lab.injective.eq_iff]
  have star11 (j : Label) : G.Adj (F.lab 11) (F.lab j) ↔ j=2 ∨ j=3 := by
    rw [←G.mem_neighborFinset,F.second,mem_insert,mem_singleton]; simp only [F.lab.injective.eq_iff]
  have pred : (∀s:Label,preset 10 s=true ↔ s=0 ∨ s=1) ∧
      (∀s:Label,preset 11 s=true ↔ s=2 ∨ s=3) ∧ (∀r s:Label,preset r s=preset s r) := by decide
  have last (u : Label) (hu : 10≤u.val) : u=10 ∨ u=11 := (show ∀z:Label,10≤z.val → z=10 ∨ z=11 by decide) u hu
  rcases old with hi|hj
  · rcases last i hi with rfl|rfl
    · exact (pred.1 j).trans (star10 j).symm
    · exact (pred.2.1 j).trans (star11 j).symm
  · rw [pred.2.2 i j,G.adj_comm]
    rcases last j hj with rfl|rfl
    · exact (pred.1 i).trans (star10 i).symm
    · exact (pred.2.1 i).trans (star11 i).symm

omit [Fintype V] [DecidableEq V] in
theorem lift_neighbors (f : Label ↪ V) (a : ℕ→Bool)
    (edges : ∀i j:Label,edge a i j=true ↔ G.Adj (f i) (f j))
    (i : Label) (S : Finset Label) :
    (S.filter (fun j => edge a i j=true)).card≤nbr G (f i) (S.map f) := by
  have sub : (S.filter (fun j => edge a i j=true)).map f⊆(S.map f).filter (G.Adj (f i)) := by
    intro z zm; obtain ⟨j,jm,rfl⟩ := mem_map.mp zm
    obtain ⟨js,adj⟩ := mem_filter.mp jm
    exact mem_filter.mpr ⟨mem_map.mpr ⟨j,js,rfl⟩,(edges i j).mp adj⟩
  simpa only [card_map] using card_le_card sub

end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.represents
#print axioms Graffiti384b.SixFront.Model.counts
#print axioms Graffiti384b.SixFront.Model.Layout.shape
#print axioms Graffiti384b.SixFront.Model.lift_neighbors
