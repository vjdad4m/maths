import SixEmbed
namespace Graffiti384b.SixFront.Model
open Finset SimpleGraph Four29 LowSample
open private Prune.links Prune.link_in_core from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] [DecidableEq V] in
/-- Put the contacts adjacent to the distinguished anchor first. -/
private theorem order_contacts (T : Finset V) (size : T.card=6) (r : V) :
    ∃(C : Fin 6 ≃ ↥T) (k : Fin 7),∀i:Fin 6,G.Adj r (C i) ↔ i.val<k.val := by
  classical
  let U := {v : ↥T // G.Adj r v.val}
  let W := {v : ↥T // ¬G.Adj r v.val}
  let n := Fintype.card U
  let m := Fintype.card W
  let split : U ⊕ W ≃ ↥T := Equiv.sumCompl (fun v : ↥T => G.Adj r v.val)
  have total : n+m=6 := by
    rw [show n+m=Fintype.card (U⊕W) from (Fintype.card_sum ..).symm,Fintype.card_congr split]
    simpa using size
  let dom : Fin n ⊕ Fin m ≃ Fin 6 := finSumFinEquiv.trans (finCongr total)
  let adjPart : Fin n ≃ U := (Fintype.equivFin U).symm
  let otherPart : Fin m ≃ W := (Fintype.equivFin W).symm
  let label := (Equiv.sumCongr adjPart otherPart).trans split
  refine ⟨dom.symm.trans label,⟨n,by omega⟩,?_⟩
  intro i
  obtain ⟨s,rfl⟩ := dom.surjective i
  change G.Adj r (label (dom.symm (dom s))).val ↔ (dom s).val<n
  rw [dom.symm_apply_apply]
  cases s with
  | inl j =>
    change G.Adj r (adjPart j).val.val ↔ j.val<n
    exact iff_of_true (adjPart j).property j.isLt
  | inr j =>
    change G.Adj r (otherPart j).val.val ↔ n+j.val<n
    exact iff_of_false (otherPart j).property (by omega)

private theorem orientation {e f r : V} (D : Data G e f) (ef : e≠f)
    (de : G.degree e=2) (df : G.degree f=2) (re : r∈G.neighborFinset e)
    (major : 13≤trianglesAt G r) (six : (triangleContacts G e f).card=6) : Nonempty (Layout G) := by
  classical
  obtain ⟨u,v,uv,n⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G e).trans de)
  have nb : ∃b,b≠r ∧ G.neighborFinset e={r,b} := by
    rw [n,mem_insert,mem_singleton] at re
    rcases re with rfl|rfl
    · exact ⟨_,uv.symm,n⟩
    · exact ⟨_,uv,n.trans (pair_comm ..)⟩
  obtain ⟨b,_,en⟩ := nb
  obtain ⟨c,d,_,fn'⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G f).trans df)
  let T := triangleContacts G e f
  let W := roots G e f
  let E : Finset V := {e,f}
  let S := W∪T∪E
  obtain ⟨C,k,sorted⟩ := order_contacts G T six r
  let lab : Label→V := ![r,b,c,d,(C 0).val,(C 1).val,(C 2).val,(C 3).val,(C 4).val,(C 5).val,e,f]
  have atC (i : Fin 6) : lab (atContact i)=(C i).val := by fin_cases i <;> rfl
  have wn : W={r,b}∪{c,d} := by change G.neighborFinset e ∪ G.neighborFinset f=_; rw [en,fn']
  have inc : S⊆univ.image lab := by
    intro z zm
    rcases mem_union.mp zm with wt|ear
    · rcases mem_union.mp wt with w|contact
      · rw [wn,mem_union,mem_insert,mem_singleton,mem_insert,mem_singleton] at w
        rcases w with (rfl|rfl)|(rfl|rfl)
        · exact mem_image.mpr ⟨0,mem_univ _,rfl⟩
        · exact mem_image.mpr ⟨1,mem_univ _,rfl⟩
        · exact mem_image.mpr ⟨2,mem_univ _,rfl⟩
        · exact mem_image.mpr ⟨3,mem_univ _,rfl⟩
      · obtain ⟨i,eq⟩ := C.surjective ⟨z,contact⟩
        exact mem_image.mpr ⟨atContact i,mem_univ _,(atC i).trans (congrArg Subtype.val eq)⟩
    · rcases mem_insert.mp ear with rfl|m
      · exact mem_image.mpr ⟨10,mem_univ _,rfl⟩
      · obtain rfl := mem_singleton.mp m; exact mem_image.mpr ⟨11,mem_univ _,rfl⟩
  have tx : T⊆pool G e f := filter_subset ..
  have highE : Disjoint (high G) E := disjoint_left.mpr (fun _ hi em =>
    (mem_sdiff.mp (D.earSet.symm ▸ em : _∈twos G)).2 hi)
  have WT : Disjoint W T := disjoint_left.mpr (fun _ wr ct => (mem_sdiff.mp (tx ct)).2 wr)
  have size : S.card=12 := by
    rw [show S=W∪T∪E from rfl,card_union_of_disjoint (highE.mono_left (union_subset D.highRoots (tx.trans sdiff_subset))),
      card_union_of_disjoint WT,D.rootsSize,show T.card=6 from six,show E.card=2 from card_pair ef]
  have inj := (card_image_iff (s:=univ) (f:=lab)).mp (Nat.le_antisymm card_image_le (by
    have ct := card_le_card inc; rw [size] at ct; simpa using ct))
  let idx : Label ↪ V := ⟨lab,fun _ _ eq => inj (mem_univ _) (mem_univ _) eq⟩
  have wr (i : Root) : idx (atRoot i)∈W := by fin_cases i <;> rw [wn] <;> simp [idx,lab,atRoot]
  refine ⟨⟨idx,en,fn',?_,major,k,?_⟩⟩
  · intro i z mem
    obtain ⟨p,pm,zp⟩ := mem_biUnion.mp mem
    have nz := Prune.link_in_core G (show p∈Prune.links G (idx (atRoot i)) from pm) zp
    have all : z∈S := by
      by_cases hi : z∈high G
      · by_cases root : z∈W
        · exact mem_union_left _ (mem_union_left _ root)
        · exact mem_union_left _ (mem_union_right _ (mem_filter.mpr ⟨mem_sdiff.mpr ⟨hi,root⟩,_,wr i,mem⟩))
      · have ear : z∈twos G := mem_sdiff.mpr ⟨nz,hi⟩
        exact mem_union_right _ (show z∈({e,f}:Finset V) by rwa [←D.earSet])
    obtain ⟨j,_,eq⟩ := mem_image.mp (inc all)
    exact ⟨j,eq⟩
  · intro i
    change G.Adj r (lab (atContact i)) ↔ _
    rw [atC]; exact sorted i

theorem failure_layout (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    (bad : bound G<gamma G) {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f)
    (six : (triangleContacts G e f).card=6) : Nonempty (Layout G) := by
  obtain ⟨r,rr,large⟩ := (five_contact_residual G t h q bad de df ef).1
  rcases mem_union.mp rr with re|rf
  · exact orientation G (data_of_failure G t h q bad de df ef) ef de df re large six
  · have symm : triangleContacts G f e=triangleContacts G e f := by
      unfold triangleContacts pool roots; rw [union_comm (G.neighborFinset f) (G.neighborFinset e)]
    exact orientation G (data_of_failure G t h q bad df de ef.symm) ef.symm df de rf large (symm ▸ six)

end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.failure_layout
