import CubicMove

namespace Graffiti384b.SixFront.Model
open Finset
abbrev Label := Fin 12
abbrev Root := Fin 4
def atRoot (r : Root) : Label := ⟨r.val,by omega⟩
def position (i j : Label) := (max i.val j.val).choose 2+min i.val j.val
def preset (i j : Label) : Bool := decide ((i=10 ∧ j.val<2) ∨ (j=10 ∧ i.val<2) ∨
    (i=11 ∧ 2 ≤ j.val ∧ j.val<4) ∨ (j=11 ∧ 2 ≤ i.val ∧ i.val<4))
/-- Edge bits among the ten high labels. Two prescribed stars supply the ear edges. -/
def edge (a : ℕ→Bool) (i j : Label) : Bool := if i=j then false else
  if i.val<10 ∧ j.val<10 then a (position i j) else preset i j
def pairs : Finset (Label×Label) := univ.filter (fun z => z.1<z.2)
def triangles (a : ℕ→Bool) (i : Label) := pairs.filter (fun z =>
  edge a i z.1=true ∧ edge a i z.2=true ∧ edge a z.1 z.2=true)
def shore (s : ℕ) : Finset Label := univ.filter (fun i => s.testBit i.val=true)
/-- The labels in the two sets are pins, and all other labels remain free. -/
def Good (a : ℕ→Bool) (P Q : Finset Label) :=
  Disjoint P Q ∧ (10:Label)∈P∪Q ∧ (11:Label)∈P∪Q ∧
  (∀i∈P,2≤(Q.filter (fun j => edge a i j=true)).card) ∧
  (∀i∈Q,2≤(P.filter (fun j => edge a i j=true)).card)
instance goodDec (a : ℕ→Bool) (P Q : Finset Label) : Decidable (Good a P Q) := by
  unfold Good; infer_instance

def Below (a b : ℕ→Bool) := ∀i,a i=true → b i=true
theorem edge_mono {a b : ℕ→Bool} (ab : Below a b) (i j : Label) :
    edge a i j=true → edge b i j=true := by
  unfold edge; split
  · exact id
  · split
    · exact ab _
    · exact id
theorem tri_mono {a b : ℕ→Bool} (ab : Below a b) (v : Label) :
    (triangles a v).card≤(triangles b v).card := by
  apply card_le_card
  intro p pm
  obtain ⟨ij,t1,t2,t3⟩ := mem_filter.mp pm
  exact mem_filter.mpr ⟨ij,edge_mono ab _ _ t1,edge_mono ab _ _ t2,edge_mono ab _ _ t3⟩
private theorem good_mono {a b : ℕ→Bool} (ab : Below a b) {P Q : Finset Label} (h : Good a P Q) : Good b P Q := by
  have gain (v : Label) (S : Finset Label) : (S.filter (fun j => edge a v j=true)).card≤
      (S.filter (fun j => edge b v j=true)).card := card_le_card (fun j m =>
    mem_filter.mpr ⟨(mem_filter.mp m).1,edge_mono ab v j (mem_filter.mp m).2⟩)
  exact ⟨h.1,h.2.1,h.2.2.1,fun i h' => (h.2.2.2.1 i h').trans (gain ..),
    fun i h' => (h.2.2.2.2 i h').trans (gain ..)⟩


def farA (r : Root) : Label := if r.val<2 then 2 else 0
def farB (r : Root) : Label := if r.val<2 then 3 else 1
def Fork (a : ℕ→Bool) (r : Root) := edge a (atRoot r) (farA r)=true ∧ edge a (atRoot r) (farB r)=true
instance (a : ℕ→Bool) (r : Root) : Decidable (Fork a r) := by unfold Fork; infer_instance

/-- A single gap with a free triangle. A separate upper graph bounds its score. -/
def Move (a : ℕ→Bool) (P Q : Finset Label) (v x y : Label) :=
  Disjoint P Q ∧ (10:Label)∈P∪Q ∧ (11:Label)∈P∪Q ∧ v∈P ∧
  x∉P∪Q ∧ y∉P∪Q ∧ edge a v x=true ∧ edge a v y=true ∧ edge a x y=true ∧
  (∀i∈P,(if i=v then 1 else 2)≤(Q.filter (fun j => edge a i j=true)).card) ∧
  ∀i∈Q,2≤(P.filter (fun j => edge a i j=true)).card
instance (a : ℕ→Bool) (P Q : Finset Label) (v x y : Label) : Decidable (Move a P Q v x y) := by
  unfold Move; infer_instance
private theorem move_mono {a b : ℕ→Bool} (ab : Below a b) {P Q : Finset Label} {v x y : Label}
    (m : Move a P Q v x y) : Move b P Q v x y := by
  obtain ⟨dis,e,f,vp,xo,yo,vx,vy,xy,lp,rq⟩ := m
  have gain (i : Label) (S : Finset Label) : (S.filter (fun j => edge a i j=true)).card≤
      (S.filter (fun j => edge b i j=true)).card := card_le_card (fun j jm =>
        mem_filter.mpr ⟨(mem_filter.mp jm).1,edge_mono ab _ _ (mem_filter.mp jm).2⟩)
  exact ⟨dis,e,f,vp,xo,yo,edge_mono ab _ _ vx,edge_mono ab _ _ vy,edge_mono ab _ _ xy,
    fun i im => (lp i im).trans (gain ..),fun i im => (rq i im).trans (gain ..)⟩

def Prize (a : ℕ→Bool) :=
  (∃P Q,Good a P Q) ∨ (∃r,Fork a r) ∨
    ∃P Q r x y,Move a P Q (atRoot r) x y ∧ (triangles a (atRoot r)).card≤2

inductive Tree where
  | small (r : Root)
  | cut (l r : ℕ)
  | fork (r : Root)
  | gap (r : Root) (x y : Label) (p q : ℕ)
  | branch (key : ℕ) (yes no : Tree)

def threshold (r : Root) := if r=0 then 13 else 2
def on (n : ℕ) (i : ℕ) := n.testBit i
def allowed (n : ℕ) (i : ℕ) := !(n.testBit i)
def check (lo no : ℕ) : Tree → Bool
  | .small r => decide ((triangles (allowed no) (atRoot r)).card<threshold r)
  | .cut l r => decide (Good (on lo) (shore l) (shore r))
  | .fork r => decide (Fork (on lo) r)
  | .gap r x y l q => decide (Move (on lo) (shore l) (shore q) (atRoot r) x y ∧
      (triangles (allowed no) (atRoot r)).card≤2)
  | .branch i yes neg => check (lo ||| 2^i) no yes && check lo (no ||| 2^i) neg

theorem check_sound (a : ℕ→Bool) (rich : ∀r,threshold r≤(triangles a (atRoot r)).card)
    (t : Tree) (lo no : ℕ) (lb : Below (on lo) a) (ub : Below a (allowed no))
    (tested : check lo no t=true) : Prize a := by
  induction t generalizing lo no with
  | small r => exact (not_lt_of_ge ((rich r).trans (tri_mono ub _)) (of_decide_eq_true tested)).elim
  | cut l r => exact Or.inl ⟨_,_,good_mono lb (of_decide_eq_true tested)⟩
  | fork r =>
    have f : Fork (on lo) r := of_decide_eq_true tested
    exact Or.inr (Or.inl ⟨r,edge_mono lb _ _ f.1,edge_mono lb _ _ f.2⟩)
  | gap r x y p q =>
    obtain ⟨m,c⟩ := of_decide_eq_true tested
    exact Or.inr (Or.inr ⟨_,_,r,x,y,move_mono lb m,(tri_mono ub _).trans c⟩)
  | branch key yes neg goodPos goodNeg =>
    obtain ⟨hp,hn⟩ := Bool.and_eq_true_iff.mp tested
    cases val : a key with
    | true =>
      apply goodPos _ _ ?_ ub hp
      intro i hi
      simp only [on,Nat.testBit_or,Bool.or_eq_true,Nat.testBit_two_pow,decide_eq_true_eq] at hi
      rcases hi with old|same
      · exact lb i old
      · subst i; exact val
    | false =>
      apply goodNeg _ _ lb ?_ hn
      intro i hi
      have was := ub i hi
      have distinct : i≠key := fun eq => by subst i; simp [val] at hi
      simp_all [allowed,Nat.testBit_or,Nat.testBit_two_pow,Ne.symm distinct]

end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.check_sound
