import SixModel
namespace Graffiti384b.SixFront.Model
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] def case0_root : Tree := (.small 0)
theorem case0_root_ok : check 33 68990043200 case0_root=true := by unfold case0_root; decide
end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.case0_root_ok
