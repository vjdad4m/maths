import SixModel
namespace Graffiti384b.SixFront.Model
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] def case1_root : Tree := (.small 0)
theorem case1_root_ok : check 97 68990043136 case1_root=true := by unfold case1_root; decide
end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.case1_root_ok
