import SixModel
namespace Graffiti384b.SixFront.Model
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] def case2_root : Tree := (.small 0)
theorem case2_root_ok : check 1121 68990042112 case2_root=true := by unfold case2_root; decide
end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.case2_root_ok
