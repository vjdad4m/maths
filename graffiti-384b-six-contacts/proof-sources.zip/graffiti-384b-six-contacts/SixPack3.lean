import SixModel
namespace Graffiti384b.SixFront.Model
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] def case3_root : Tree := (.branch 2 (.branch 3 (.cut 2051 1036) (.small 0)) (.branch 4 (.branch 1 (.cut 2051 1036) (.small 0)) (.branch 7 (.branch 1 (.branch 3 (.fork 0) (.small 0)) (.small 0)) (.branch 11 (.branch 1 (.branch 3 (.fork 0) (.small 0)) (.small 0)) (.small 0)))))
theorem case3_root_ok : check 33889 68990009344 case3_root=true := by unfold case3_root; decide
end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.case3_root_ok
