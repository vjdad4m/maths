import SixEmbed
import ZeroLeaf384b
namespace Graffiti384b.SixFront.Model
open Finset SimpleGraph Four29 LowSample Exterior
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A positive degree-two vertex joins its two neighbors by an edge. -/
theorem mate_edge (bad : bound G<gamma G) {e u v : V} (ne : u≠v)
    (ns : G.neighborFinset e={u,v}) : G.Adj u v := by
  have deg : G.degree e=2 := by rw [←card_neighborFinset_eq_degree,ns,card_pair ne]
  have pos : 0<trianglesAt G e := Nat.pos_of_ne_zero (fun eq =>
    (not_lt_of_ge (OddStars.exact_of_zero_nonleaf G eq deg.ge)) bad)
  obtain ⟨x,y,ex,ey,xy⟩ := (TrianglePrune.triangle_iff G e).mp pos
  have xm := (G.mem_neighborFinset ..).mpr ex
  have ym := (G.mem_neighborFinset ..).mpr ey
  rw [ns,mem_insert,mem_singleton] at xm ym
  rcases xm with rfl|rfl <;> rcases ym with rfl|rfl
  all_goals first | exact xy | exact xy.symm | exact (xy.ne rfl).elim

def row (r : Root) : Fin 6 → Label :=
  (![![1,0,2,3,10,11],![0,1,2,3,10,11],![3,2,0,1,11,10],![2,3,0,1,11,10]] : Fin 4 → Fin 6 → Label) r

private theorem from_fork (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    (F : Layout G) (a : ℕ→Bool) (edges : ∀i j,edge a i j=true ↔ G.Adj (F.lab i) (F.lab j))
    (r : Root) (pat : Fork a r) : gamma G≤bound G := by
  let l : Fin 6 ↪ V := (⟨row r,(show ∀s:Root,Function.Injective (row s) by decide) r⟩ : Fin 6 ↪ Label).trans F.lab
  apply SixFront.fork G t q h l
  · fin_cases r <;> first | exact F.first | exact F.second | exact F.first.trans (pair_comm ..) | exact F.second.trans (pair_comm ..)
  · fin_cases r <;> first | exact F.first | exact F.second
  · fin_cases r <;> exact (edges _ _).mp pat.1
  · fin_cases r <;> exact (edges _ _).mp pat.2

/-- Finite proposition, expressed independently of any decision-tree data. -/
def Claim := ∀(k : Fin 7) (a : ℕ→Bool),a (position 0 1)=true → a (position 2 3)=true →
    (∀i:Fin 6,a (position 0 (atContact i))=true ↔ i.val<k.val) →
    (∀r,threshold r≤(triangles a (atRoot r)).card) → Prize a

theorem from_layout (cert : Claim) (t : (types G).card=29) (q : (nonleaves G).card=29)
    (h : (high G).card=27) (F : Layout G) : gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt; intro bad
  let f := F.lab
  have ne {i j : Label} (ij : i≠j) : f i≠f j := f.injective.ne ij
  have d10 : G.degree (f 10)=2 := by rw [←card_neighborFinset_eq_degree,F.first,card_pair (ne (by decide))]
  have d11 : G.degree (f 11)=2 := by rw [←card_neighborFinset_eq_degree,F.second,card_pair (ne (by decide))]
  have D := data_of_failure G t h q bad d10 d11 (ne (by decide))
  have rmem (r : Root) : f (atRoot r)∈roots G (f 10) (f 11) := by
    rw [roots,F.first,F.second]; fin_cases r <;> simp [f,atRoot]
  obtain ⟨a,ed⟩ := represents G f (F.shape G)
  have sc (r : Root) := counts G f a ed (atRoot r) (F.support r)
  have pos (r : Root) := D.rich _ (D.highRoots (rmem r))
  have e01 : a (position 0 1)=true := (ed 0 1).mpr (mate_edge G bad (ne (by decide)) F.first)
  have e23 : a (position 2 3)=true := (ed 2 3).mpr (mate_edge G bad (ne (by decide)) F.second)
  have selected (i : Fin 6) : a (position 0 (atContact i))=true ↔ i.val<F.k.val := by
    have old := (ed 0 (atContact i)).trans (F.sorted i)
    have diff : (0:Label)≠atContact i := by intro eq; have := congrArg Fin.val eq; simp [atContact] at this; omega
    simpa [edge,diff,atContact,show 4+i.val<10 by omega] using old
  have large (r : Root) : threshold r≤(triangles a (atRoot r)).card := by
    rw [sc]; by_cases eq : r=0
    · subst r; exact F.major
    · simpa [threshold,eq] using pos r
  have enough {i : Label} {S : Finset Label} {n : ℕ}
      (num : n≤(S.filter (fun j => edge a i j=true)).card) := num.trans (lift_neighbors G f a ed i S)
  have transfer {S U : Finset Label} {i : Label} (m : i∈S∪U) : f i∈S.map f∪U.map f := by
    rwa [←map_union,mem_map']
  have outside {S U : Finset Label} {i : Label} (m : i∉S∪U) : f i∉S.map f∪U.map f := by
    rwa [←map_union,mem_map']
  have separated {P Q : Finset Label} (dis : Disjoint P Q) : Disjoint (P.map f) (Q.map f) := by
    apply disjoint_left.mpr
    intro z zl zr; obtain ⟨i,im,rfl⟩ := mem_map.mp zl; obtain ⟨j,jm,eq⟩ := mem_map.mp zr
    exact disjoint_left.mp dis im (f.injective eq ▸ jm)
  apply (not_lt_of_ge ?_) bad
  rcases cert F.k a e01 e23 selected large with ⟨P,Q,dis,ep,fp,lp,rq⟩|⟨r,pat⟩|⟨P,Q,r,x,y,mv,cap⟩
  · apply SixFront.extension_bound G D (by omega) (transfer ep) (transfer fp)
    refine ⟨_,_,Subset.rfl,Subset.rfl,separated dis,?_,?_⟩
    · intro z zm; obtain ⟨i,im,rfl⟩ := mem_map.mp zm; exact enough (lp i im)
    · intro z zm; obtain ⟨i,im,rfl⟩ := mem_map.mp zm; exact enough (rq i im)
  · exact from_fork G t q h F a ed r pat
  · obtain ⟨dis,ep,fp,vp,xo,yo,vx,vy,xy,lp,rq⟩ := mv
    have gap : Gap G (P.map f) (Q.map f) (f (atRoot r)) := by
      refine ⟨separated dis,mem_map.mpr ⟨_,vp,rfl⟩,?_,?_,?_⟩
      · exact enough (by simpa using lp (atRoot r) vp)
      · intro z zm nz; obtain ⟨i,im,rfl⟩ := mem_map.mp zm
        exact enough (by simpa [show i≠atRoot r from fun eq => nz (congrArg f eq)] using lp i im)
      · intro z zm; obtain ⟨i,im,rfl⟩ := mem_map.mp zm; exact enough (rq i im)
    rw [sc] at cap
    exact SixFront.score_two_gap G D (by omega) gap (transfer ep) (transfer fp) (D.highRoots (rmem r))
      (cap.antisymm (pos r)) (outside xo) (outside yo) ((ed _ _).mp vx) ((ed _ _).mp vy) ((ed _ _).mp xy)

end Graffiti384b.SixFront.Model
#print axioms Graffiti384b.SixFront.Model.mate_edge
#print axioms Graffiti384b.SixFront.Model.from_layout
