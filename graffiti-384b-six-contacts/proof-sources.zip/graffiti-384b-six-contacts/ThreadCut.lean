import MixedResidual
namespace Graffiti384b.SixFront
open Finset SimpleGraph Exterior
open private Exterior.join from PortFrames
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The extension retains both original shores, including their ears. -/
def Extension (P Q : Finset V) : Prop :=
  ∃L R, P⊆L ∧ Q⊆R ∧ Protected G L R

private theorem grow {P Q A I J : Finset V} {a : V} (H : Gap G P Q a)
    (off : Disjoint (P∪Q) A) (isub : I⊆A) (jsub : J⊆A) (apart : Disjoint I J)
    (fresh : ∃v∈J,G.Adj a v)
    (left : ∀v∈I,2≤nbr G v (Q∪J)) (right : ∀v∈J,2≤nbr G v (P∪I)) : Extension G P Q := by
  obtain ⟨L,R,pl,qr,cut,_⟩ := Exterior.join G H (off.mono_right (union_subset isub jsub))
    apart fresh left right (W:=∅) (k:=0) (by simp)
  exact ⟨L,R,pl,qr,cut⟩

/-- A two-edge path to a different pin on the anchor's side. -/
theorem two_steps {P Q A : Finset V} {a x r : V} (H : Gap G P Q a)
    (off : Disjoint (P∪Q) A) (xm : x∈A) (rp : r∈P) (ar : a≠r)
    (ax : G.Adj a x) (xr : G.Adj x r) : Extension G P Q := by
  apply grow G H off (I:=∅) (J:={x}) (empty_subset _) (singleton_subset_iff.mpr xm)
    (by simp) ⟨x,by simp,ax⟩ (by simp)
  intro v vm
  obtain rfl := mem_singleton.mp vm
  exact PinnedColor34.two G ar ax.symm xr (mem_union_left _ H.pinned) (mem_union_left _ rp)

/-- A three-edge path to the other shore. -/
theorem three_steps {P Q A : Finset V} {a x y r : V} (H : Gap G P Q a)
    (off : Disjoint (P∪Q) A) (xm : x∈A) (ym : y∈A) (rq : r∈Q)
    (ax : G.Adj a x) (xy : G.Adj x y) (yr : G.Adj y r) : Extension G P Q := by
  have ay : a≠y := fun eq => disjoint_left.mp off (mem_union_left _ H.pinned) (eq ▸ ym)
  have rx : r≠x := fun eq => disjoint_left.mp off (mem_union_right _ rq) (eq ▸ xm)
  apply grow G H off (I:={y}) (J:={x}) (singleton_subset_iff.mpr ym) (singleton_subset_iff.mpr xm)
    (by simpa using xy.ne) ⟨x,by simp,ax⟩
  · intro v vm
    obtain rfl := mem_singleton.mp vm
    exact PinnedColor34.two G rx yr xy.symm (mem_union_left _ rq) (mem_union_right _ (by simp))
  · intro v vm
    obtain rfl := mem_singleton.mp vm
    exact PinnedColor34.two G ay ax.symm xy (mem_union_left _ H.pinned) (mem_union_right _ (by simp))

/-- A four-edge path to the original shore. Its endpoints may coincide. -/
theorem four_steps {P Q A : Finset V} {a x y z r : V} (H : Gap G P Q a)
    (off : Disjoint (P∪Q) A) (xm : x∈A) (ym : y∈A) (zm : z∈A) (rp : r∈P)
    (xz : x≠z) (ax : G.Adj a x) (xy : G.Adj x y) (yz : G.Adj y z) (zr : G.Adj z r) :
    Extension G P Q := by
  have ay : a≠y := fun eq => disjoint_left.mp off (mem_union_left _ H.pinned) (eq ▸ ym)
  have ry : r≠y := fun eq => disjoint_left.mp off (mem_union_left _ rp) (eq ▸ ym)
  apply grow G H off (I:={y}) (J:={x,z}) (singleton_subset_iff.mpr ym)
    (insert_subset xm (singleton_subset_iff.mpr zm)) (by simp [xy.ne,yz.ne.symm])
    ⟨x,by simp,ax⟩
  · intro v vm
    obtain rfl := mem_singleton.mp vm
    exact PinnedColor34.two G xz xy.symm yz (mem_union_right _ (by simp)) (mem_union_right _ (by simp))
  · intro v vm
    rcases mem_insert.mp vm with rfl|last
    · exact PinnedColor34.two G ay ax.symm xy (mem_union_left _ H.pinned) (mem_union_right _ (by simp))
    · obtain rfl := mem_singleton.mp last
      exact PinnedColor34.two G ry zr yz.symm (mem_union_left _ rp) (mem_union_right _ (by simp))

end Graffiti384b.SixFront
#print axioms Graffiti384b.SixFront.two_steps
#print axioms Graffiti384b.SixFront.three_steps
#print axioms Graffiti384b.SixFront.four_steps
