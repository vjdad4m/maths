import ThreadCut
namespace Graffiti384b.SixFront
open Finset SimpleGraph Exterior Four29 LowSample
open private Repair.support_sub from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
/-- Every triangle with one vertex at a gap supplies both parities of access
to either of its other vertices. An additional contact consequently gives
a path of exactly the parity needed to reach its incident anchor. -/
theorem triangle_return {P Q A : Finset V} {a x y : V} (H : Gap G P Q a)
    (off : Disjoint (P∪Q) A) (xm : x∈A) (ym : y∈A)
    (ax : G.Adj a x) (ay : G.Adj a y) (xy : G.Adj x y)
    (hit : (∃p∈({x,y}:Finset V),∃r∈P∪Q,G.Adj p r ∧ r≠a) ∨
      (∃p∈({x,y}:Finset V),∃z∈A,G.Adj p z ∧ z∉({x,y}:Finset V) ∧ ∃r∈P∪Q,G.Adj z r)) :
    Extension G P Q := by
  have orient (p : V) (pm : p∈({x,y}:Finset V)) :
      ∃s∈({x,y}:Finset V),s∈A ∧ p∈A ∧ G.Adj a s ∧ G.Adj a p ∧ G.Adj s p := by
    rcases mem_insert.mp pm with rfl|last
    · exact ⟨y,by simp,ym,xm,ay,ax,xy.symm⟩
    · obtain rfl := mem_singleton.mp last
      exact ⟨x,by simp,xm,ym,ax,ay,xy⟩
  rcases hit with ⟨p,pm,r,rm,pr,ra⟩|⟨p,pm,z,zm,pz,zn,r,rm,zr⟩
  · obtain ⟨s,_,sm,pa,as',ap,sp⟩ := orient p pm
    rcases mem_union.mp rm with rp|rq
    · exact two_steps G H off pa rp ra.symm ap pr
    · exact three_steps G H off sm pa rq as' sp pr
  · obtain ⟨s,ss,sm,pa,as',ap,sp⟩ := orient p pm
    rcases mem_union.mp rm with rp|rq
    · exact four_steps G H off sm pa zm rp (fun eq => zn (eq ▸ ss)) as' sp pz zr
    · exact three_steps G H off pa zm rq ap pz zr

theorem extension_bound {P Q : Finset V} {e f : V} (D : Data G e f)
    (quota : (types G).card≤(nonleaves G).card)
    (ep : e∈P∪Q) (fp : f∈P∪Q) (extn : Extension G P Q) : gamma G≤bound G := by
  obtain ⟨L,R,pl,qr,cut⟩ := extn
  apply PinnedColor34.complete G cut.1 quota _ cut.2.1 cut.2.2
  intro v vn vl vr
  by_contra! small
  have tv : v∈twos G := mem_sdiff.mpr ⟨vn,fun hi => (not_le_of_gt small) (mem_filter.mp hi).2⟩
  rw [D.earSet] at tv
  have covered : v∈P∪Q := (mem_insert.mp tv).elim (fun eq => eq ▸ ep) (fun eq => mem_singleton.mp eq ▸ fp)
  exact (mem_union.mp covered).elim (fun m => vl (pl m)) (fun m => vr (qr m))

/-- A pool triangle at the deficient anchor suffices with no privacy hypothesis.
Either its contact supplies a short alternating return, or its two neighbors
meet the hypotheses of the score-free three-pin theorem. -/
theorem pool_triangle (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    {e f a x y : V} (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f)
    (P Q : Finset V) (H : Gap G P Q a) (off : Disjoint (P∪Q) (pool G e f))
    (rootsIn : roots G e f⊆P∪Q) (ar : a∈roots G e f) (ep : e∈P∪Q) (fp : f∈P∪Q)
    (xp : x∈pool G e f) (yp : y∈pool G e f) (ax : G.Adj a x) (ay : G.Adj a y) (xy : G.Adj x y) :
    gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt
  intro bad
  have D := data_of_failure G t h q bad de df ef
  let S : Finset V := {x,y}
  have ports : Ports G P Q S (pool G e f\S) a := by
    refine ⟨H,off.mono_right (union_subset (insert_subset xp (singleton_subset_iff.mpr yp)) sdiff_subset),
      disjoint_sdiff,?_⟩
    intro p pm
    exact (mem_insert.mp pm).elim (fun eq => eq ▸ ax) (fun eq => mem_singleton.mp eq ▸ ay)
  have win := fun E => (not_lt_of_ge (extension_bound G D (by omega) ep fp E)) bad
  by_cases rootOnly : ∀p∈S,∀r∈roots G e f,G.Adj p r → r=a
  · by_cases portOnly : ∀p∈S,∀z∈triangleContacts G e f,G.Adj p z → z∈S
    · exact (not_lt_of_ge (score_free_solution G t q h de df ef P Q xy.ne xp yp ar ports ep fp rootOnly portOnly)) bad
    · push_neg at portOnly
      obtain ⟨p,pm,z,zc,pz,zout⟩ := portOnly
      obtain ⟨zp,r,rr,zr⟩ := mem_filter.mp zc
      exact win (triangle_return G H off xp yp ax ay xy (Or.inr ⟨p,pm,z,zp,pz,zout,r,rootsIn rr,
        ((G.mem_neighborFinset ..).mp (Repair.support_sub G r zr)).symm⟩))
  · push_neg at rootOnly
    obtain ⟨p,pm,r,rr,pr,ra⟩ := rootOnly
    exact win (triangle_return G H off xp yp ax ay xy (Or.inl ⟨p,pm,r,rootsIn rr,pr,ra⟩))
end Graffiti384b.SixFront
#print axioms Graffiti384b.SixFront.triangle_return
#print axioms Graffiti384b.SixFront.extension_bound
#print axioms Graffiti384b.SixFront.pool_triangle
