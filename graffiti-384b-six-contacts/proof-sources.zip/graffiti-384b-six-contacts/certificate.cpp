// Discovery only. SixModel.lean checks every leaf and both children of every split.
#include <algorithm>
#include <array>
#include <bit>
#include <cstdio>
#include <utility>
#include <vector>

using Mask = unsigned;
using Graph = std::array<Mask, 10>;
using Votes = std::array<int, 45>;
using Ends = std::pair<int, int>;

struct Shores {
    Mask left, right;
    Mask opposite(int v) const { return (left & (1u << v)) ? right : left; }
    Mask pins() const { return left | right; }
};

std::vector<Shores> placements;
std::array<Ends, 45> endpoints;
int visited;

int key(int u, int v) {
    if (u < v) std::swap(u, v);
    return u * (u - 1) / 2 + v;
}

void add(Graph& graph, int u, int v) {
    graph[u] |= 1u << v;
    graph[v] |= 1u << u;
}

int pop_first(Mask& mask) {
    int v = std::countr_zero(mask);
    mask &= mask - 1;
    return v;
}

int score(const Graph& graph, int root) {
    int twice = 0;
    for (Mask neighbors = graph[root]; neighbors;) {
        int v = pop_first(neighbors);
        twice += std::popcount(graph[root] & graph[v]);
    }
    // A root's mate is its other ear neighbor. The corresponding triangle
    // is the only triangle at the root that contains an ear.
    return twice / 2 + ((graph[root] >> (root ^ 1)) & 1u);
}

int quota(int v) {
    // Each anchor already has its own opposite-shore ear.
    return v < 4 ? 1 : 2;
}

// The most nearly satisfied placements vote for the next undetermined edge.
// A negative return value means the explicit cut has already been printed.
int seek_cut(const Graph& lower, const Graph& upper, Votes& votes) {
    int best = 99;
    for (auto shores : placements) {
        int missing = 0;
        std::array<int, 10> deficit{};
        for (Mask pending = shores.pins(); pending;) {
            int v = pop_first(pending);
            Mask opposite = shores.opposite(v);
            if (std::popcount(upper[v] & opposite) < quota(v)) {
                missing = 100;
                break;
            }
            deficit[v] = std::max(0, quota(v) - std::popcount(lower[v] & opposite));
            missing += deficit[v];
            if (missing > best) break;
        }
        if (missing > best) continue;
        if (missing == 0) {
            std::printf("c %u %u\n", shores.left, shores.right);
            return -1;
        }
        if (missing < best) {
            best = missing;
            votes.fill(0);
        }
        for (int v = 0; v < 10; ++v) {
            if (!deficit[v]) continue;
            for (Mask pending = upper[v] & ~lower[v] & shores.opposite(v); pending;) {
                int w = pop_first(pending);
                votes[key(v, w)] += 1 + 2 * (deficit[w] > 0);
            }
        }
    }
    return int(std::max_element(votes.begin(), votes.end()) - votes.begin());
}

// A negative result of -1 is a verified-leaf candidate. A value of -2
// means no repair pattern is ready and the caller should split a free edge.
int seek_move(const Graph& lower, const Graph& upper) {
    for (int a = 0; a < 4; ++a) {
        if (score(upper, a) > 2) continue;
        for (auto shores : placements) {
            if (!(shores.left & (1u << a))) std::swap(shores.left, shores.right);
            bool ready = true;
            for (Mask others = shores.pins() & ~(1u << a); others;) {
                int v = pop_first(others);
                if (std::popcount(lower[v] & shores.opposite(v)) < quota(v)) {
                    ready = false;
                    break;
                }
            }
            if (!ready) continue;
            for (int x = 4; x < 10; ++x) {
                for (int y = 4; y < x; ++y) {
                    if (shores.pins() & ((1u << x) | (1u << y))) continue;
                    std::array<Ends, 3> triangle = {{{a, x}, {a, y}, {x, y}}};
                    auto missing = [&](const Graph& g, Ends e) {
                        return !(g[e.first] & (1u << e.second));
                    };
                    if (std::any_of(triangle.begin(), triangle.end(),
                            [&](Ends e) { return missing(upper, e); })) continue;
                    for (auto e : triangle)
                        if (missing(lower, e)) return key(e.first, e.second);
                    std::printf("g %d %d %d %u %u\n", a, x, y, shores.left, shores.right);
                    return -1;
                }
            }
        }
    }
    return -2;
}

bool search(Graph lower, Graph upper) {
    ++visited;
    for (int a = 0; a < 4; ++a) {
        if (score(upper, a) < (a == 0 ? 13 : 2)) {
            std::printf("s %d\n", a);
            return true;
        }
    }
    for (int a = 0; a < 4; ++a) {
        Mask other_pair = a < 2 ? 12 : 3;
        if ((lower[a] & other_pair) == other_pair) {
            std::printf("f %d\n", a);
            return true;
        }
    }
    Votes votes{};
    int next = seek_cut(lower, upper, votes);
    if (next == -1) return true;
    if (!votes[next]) {
        next = seek_move(lower, upper);
        if (next == -1) return true;
        if (next == -2) {
            for (int v = 0; v < 10; ++v) {
                if (upper[v] != lower[v]) {
                    next = key(v, std::countr_zero(upper[v] ^ lower[v]));
                    break;
                }
            }
            if (next == -2) return false;
        }
    }
    auto [v, w] = endpoints[next];
    std::printf("b %d\n", next);
    Graph present = lower;
    add(present, v, w);
    if (!search(present, upper)) return false;
    upper[v] &= ~(1u << w);
    upper[w] &= ~(1u << v);
    return search(lower, upper);
}

int main() {
    for (int i = 0; i < 10; ++i)
        for (int j = 0; j < i; ++j) endpoints[key(i, j)] = {i, j};
    // The ear-neighbor pairs are either on opposite shores or on the same
    // shore. Each of the six contacts may be on either shore or unpinned.
    for (Mask roots : {3u, 15u}) {
        for (int pattern = 0; pattern < 729; ++pattern) {
            Shores shores{roots, roots ^ 15u};
            int rest = pattern;
            for (int x = 4; x < 10; ++x, rest /= 3) {
                if (rest % 3 == 1) shores.left |= 1u << x;
                if (rest % 3 == 2) shores.right |= 1u << x;
            }
            placements.push_back(shores);
        }
    }
    for (int k = 0; k <= 6; ++k) {
        Graph lower{}, upper{};
        for (int i = 1; i < 10; ++i)
            for (int j = 0; j < i; ++j)
                if (j != 0 || i < 4 + k) add(upper, i, j);
        add(lower, 0, 1);
        add(lower, 2, 3);
        for (int i = 4; i < 4 + k; ++i) add(lower, 0, i);
        visited = 0;
        std::printf("k %d\n", k);
        if (!search(lower, upper)) return 1;
        std::fprintf(stderr, "k %d nodes %d\n", k, visited);
    }
}
