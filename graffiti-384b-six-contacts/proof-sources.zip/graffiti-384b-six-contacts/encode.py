from pathlib import Path
p=Path(__file__).resolve().parent
it=iter((p/'certificate.tree').read_text().splitlines())
def shores(l,r):
    for bit,ear in [(0,10),(2,11)]:
        if l>>bit&1:r|=1<<ear
        else:l|=1<<ear
    return l,r
def read():
    kind,*params=next(it).split()
    a=list(map(int,params))
    if kind=='b':
        u=read();v=read()
        return ('branch',a[0],u,v,u[-1]+v[-1]+1)
    if kind=='s':return (f'(.small {a[0]})',1)
    if kind=='f':return (f'(.fork {a[0]})',1)
    if kind=='c':
        l,r=shores(*a);return (f'(.cut {l} {r})',1)
    h,x,y,l,r=a; l,r=shores(l,r)
    return (f'(.gap {h} {x} {y} {l} {r})',1)
def flat(t):
    if t[0]!='branch':return t[0]
    return f'(.branch {t[1]} {flat(t[2])} {flat(t[3])})'
def mask(k):
    xs=[1<<(i*(i-1)//2) for i in range(4,10)]
    return 33+sum(xs[:k]),sum(xs[k:])
ns='namespace Graffiti384b.SixFront.Model\n'
end='end Graffiti384b.SixFront.Model\n'
for k in range(7):
    assert next(it)==f'k {k}'
    tree=read();out=['import SixModel\n'+ns+'set_option maxRecDepth 65536\nset_option maxHeartbeats 0\n']
    def emit(t,lo,no,idx):
        nm=f'case{k}_{idx}'
        if t[-1]<160:
            body=flat(t);proof=f'by unfold {nm}; decide'
        else:
            key=t[1];pos=emit(t[2],lo|1<<key,no,idx+'a');neg=emit(t[3],lo,no|1<<key,idx+'b')
            body=f'.branch {key} {pos} {neg}'
            proof=f'by exact Bool.and_eq_true_iff.mpr ⟨{pos}_ok,{neg}_ok⟩'
        out.append(f'@[irreducible] def {nm} : Tree := {body}\ntheorem {nm}_ok : check {lo} {no} {nm}=true := {proof}\n' if t[-1]<160 else
            f'def {nm} : Tree := {body}\ntheorem {nm}_ok : check {lo} {no} {nm}=true := {proof}\n')
        return nm
    lo,no=mask(k);top=emit(tree,lo,no,'root')
    (p/f'SixPack{k}.lean').write_text(''.join(out)+end+f'#print axioms Graffiti384b.SixFront.Model.{top}_ok\n')
assert next(it,None) is None
