import EarCut34_384b
import Recolor34_384b

namespace Graffiti384b.AnchorLink34
open Finset SimpleGraph LowSample
open private Repair.edge_info Repair.linkEdges Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- If one anchor sees only one ear and no candidate, a fourth triangle
through that anchor supplies an edge between two exterior neighbors. -/
theorem outside {W C L : Finset V} {u : V} (wc : W.card=3) (uw : u∈W)
    (ll : L=twos G) (anc : ∀ a∈L,G.neighborFinset a⊆W)
    (candidate : ∀ v∈high G\W,2≤nbr G v W → v∈C)
    (ear : nbr G u L≤1) (miss : ∀ v∈C,¬G.Adj u v) (four : 4≤trianglesAt G u) :
    ∃ x m,x∉W ∧ x∉L∪C ∧ m∉L∪C ∧ G.Adj u x ∧ G.Adj u m ∧ G.Adj x m := by
  classical
  let B := W.erase u ∪ L.filter (G.Adj u)
  have cap := card_union_le (W.erase u) (L.filter (G.Adj u))
  rw [card_erase_of_mem uw,wc] at cap
  change B.card≤3-1+nbr G u L at cap
  have existsEdge : ∃ e∈Repair.linkEdges G u,¬e⊆B := by
    by_contra! all
    have sub : Repair.linkEdges G u⊆B.powersetCard 2 := fun e em => mem_powersetCard.mpr ⟨all e em,(Repair.edge_info G em).2.1⟩
    have le := card_le_card sub
    rw [card_powersetCard] at le
    have mx := Nat.choose_le_choose 2 (show B.card≤3 by omega)
    change B.card.choose 2≤3 at mx
    change 4≤(Repair.linkEdges G u).card at four
    omega
  obtain ⟨e,em,notSub⟩ := existsEdge
  obtain ⟨x,xe,xb⟩ := not_subset.mp notSub
  obtain ⟨ng,sz,cl⟩ := Repair.edge_info G em
  obtain ⟨m,me,mx⟩ := exists_ne_of_one_lt_card (s:=e) (by omega) x
  have ux := (G.mem_neighborFinset _ _).mp (ng xe)
  have um := (G.mem_neighborFinset _ _).mp (ng me)
  have xm := cl x xe m me mx.symm
  have xw : x∉W := fun xW => xb (mem_union_left _ (mem_erase.mpr ⟨ux.ne.symm,xW⟩))
  have xl : x∉L := fun xm' => xb (mem_union_right _ (mem_filter.mpr ⟨xm',ux⟩))
  have xh : x∈high G := by
    by_contra no
    have sub := insert_subset ((G.mem_neighborFinset _ _).mpr ux.symm) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr xm))
    have d := card_le_card sub
    rw [card_pair um.ne,card_neighborFinset_eq_degree] at d
    exact xl (ll ▸ mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,d⟩,no⟩)
  have mw : m∉W := fun mw => miss x (candidate x (mem_sdiff.mpr ⟨xh,xw⟩) (PinnedColor34.two G um.ne ux.symm xm uw mw)) ux
  have ml : m∉L := fun ml => xw (anc m ml ((G.mem_neighborFinset _ _).mpr xm.symm))
  exact ⟨x,m,xw,fun mm => (mem_union.mp mm).elim xl (fun c => miss x c ux),
    fun mm => (mem_union.mp mm).elim ml (fun c => miss m c um),ux,um,xm⟩

end Graffiti384b.AnchorLink34
#print axioms Graffiti384b.AnchorLink34.outside
