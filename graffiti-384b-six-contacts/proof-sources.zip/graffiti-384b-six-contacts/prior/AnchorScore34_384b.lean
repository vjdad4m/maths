import GuardClique34_384b

namespace Graffiti384b.AnchorScore34
open Finset SimpleGraph LowSample
open private Repair.nbr_mono Repair.support_sub Repair.link_sum from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
theorem no_square {W : Finset V} (cap : W.card≤4) (leaf : ∃ a∈W,nbr G a W≤1)
    {u x : V} (uw : u∈W) (xw : x∈W) (ux : G.Adj u x) : ((W.filter (G.Adj u)).filter (G.Adj x)).card≤1 := by
  classical
  let C := (W.filter (G.Adj u)).filter (G.Adj x)
  by_contra! big
  change 1<C.card at big
  obtain ⟨i,im⟩ := card_pos.mp (show 0<C.card by omega)
  obtain ⟨j,jm,ji⟩ := exists_ne_of_one_lt_card big i
  obtain ⟨⟨iw,ui⟩,xi⟩ : (i∈W ∧ G.Adj u i) ∧ G.Adj x i := ⟨mem_filter.mp (mem_filter.mp im).1,(mem_filter.mp im).2⟩
  obtain ⟨⟨jw,uj⟩,xj⟩ : (j∈W ∧ G.Adj u j) ∧ G.Adj x j := ⟨mem_filter.mp (mem_filter.mp jm).1,(mem_filter.mp jm).2⟩
  let T : Finset V := {u,x,i,j}
  have sz : T.card=4 := by simp [T,ux.ne,ui.ne,uj.ne,xi.ne,xj.ne,ji.symm]
  have sub : T⊆W := insert_subset uw (insert_subset xw (insert_subset iw (singleton_subset_iff.mpr jw)))
  have all := eq_of_subset_of_card_le sub (by omega)
  obtain ⟨a,aw,small⟩ := leaf
  have am : a∈T := all ▸ aw
  simp only [T,mem_insert,mem_singleton] at am
  have two : 2≤nbr G a W := by
    rcases am with rfl|rfl|rfl|rfl
    · exact PinnedColor34.two G ji.symm ui uj iw jw
    · exact PinnedColor34.two G ji.symm xi xj iw jw
    · exact PinnedColor34.two G ux.ne ui.symm xi.symm uw xw
    · exact PinnedColor34.two G ux.ne uj.symm xj.symm uw xw
  omega

/-- At a matching anchor, only its fellow ear anchor can contribute a
second link neighbor. Summing over the link bounds its triangle count. -/
theorem degree {W : Finset V} {u y b : V} (uw : u∈W) (bw : b∈W)
    (ear : G.neighborFinset y={u,b})
    (only : ∀ z∈twos G,G.Adj u z → z=y)
    (common : ∀ x∈W,G.Adj u x → ((W.filter (G.Adj u)).filter (G.Adj x)).card≤1)
    (miss : ∀ v∈ForkGuard34.candidates G W,¬G.Adj u v)
    (matching : ∀ v∈ForkGuard34.row G W u,nbr G v (ForkGuard34.row G W u)≤1) :
    2*trianglesAt G u≤G.degree u+1 := by
  classical
  let N := G.neighborFinset u
  have highOr {v j : V} (uv : G.Adj u v) (uj : G.Adj u j) (vj : G.Adj v j) : v∈high G ∨ v=y := by
    by_cases vh : v∈high G
    · exact Or.inl vh
    have inc := insert_subset ((G.mem_neighborFinset _ _).mpr uv.symm) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vj))
    have val := card_le_card inc
    rw [card_pair uj.ne,card_neighborFinset_eq_degree] at val
    exact Or.inr (only v (mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,val⟩,vh⟩) uv)
  have ylink {x : V} (ux : G.Adj u x) (yx : G.Adj y x) : x=b := by
    have mem := (G.mem_neighborFinset _ _).mpr yx
    rw [ear,mem_insert,mem_singleton] at mem
    exact mem.resolve_left ux.ne.symm
  have point (x : V) (xn : x∈N) : nbr G x N≤1+(if x=b then 1 else 0) := by
    have ux := (G.mem_neighborFinset _ _).mp xn
    by_cases xw : x∈W
    · let C := (W.filter (G.Adj u)).filter (G.Adj x)
      have lim : C.card≤1 := common x xw ux
      have cls {j : V} (jm : j∈N.filter (G.Adj x)) : j∈C ∨ (j=y ∧ x=b) := by
        obtain ⟨jn,xj⟩ := mem_filter.mp jm
        have uj := (G.mem_neighborFinset _ _).mp jn
        by_cases jw : j∈W
        · exact Or.inl (mem_filter.mpr ⟨mem_filter.mpr ⟨jw,uj⟩,xj⟩)
        rcases highOr uj ux xj.symm with jh|rfl
        · exact (miss j (mem_filter.mpr ⟨mem_sdiff.mpr ⟨jh,jw⟩,PinnedColor34.two G ux.ne uj.symm xj.symm uw xw⟩) uj).elim
        · exact Or.inr ⟨rfl,ylink ux xj.symm⟩
      by_cases xb : x=b
      · have sub : N.filter (G.Adj x)⊆insert y C := fun _ m => (cls m).elim mem_insert_of_mem (fun p => mem_insert.mpr (Or.inl p.1))
        have le := (card_le_card sub).trans (card_insert_le ..)
        change nbr G x N≤C.card+1 at le
        rw [if_pos xb]; omega
      · have sub : N.filter (G.Adj x)⊆C := fun _ m => (cls m).resolve_right (fun p => xb p.2)
        have le := (card_le_card sub).trans lim
        rw [if_neg xb]; exact le
    · by_cases xy : x=y
      · have sing : N.filter (G.Adj x)⊆{b} := fun i im => mem_singleton.mpr
          (ylink ((G.mem_neighborFinset _ _).mp (mem_filter.mp im).1) (xy ▸ (mem_filter.mp im).2))
        exact (card_le_card sing).trans ((card_singleton b).le.trans (Nat.le_add_right ..))
      by_cases any : (N.filter (G.Adj x)).Nonempty
      · obtain ⟨j,jm⟩ := any
        have uj := (G.mem_neighborFinset _ _).mp (mem_filter.mp jm).1
        have xh := (highOr ux uj (mem_filter.mp jm).2).resolve_right xy
        have sub : N.filter (G.Adj x)⊆(ForkGuard34.row G W u).filter (G.Adj x) := by
          intro i im
          obtain ⟨inn,xi⟩ := mem_filter.mp im
          have ui := (G.mem_neighborFinset _ _).mp inn
          have iw : i∉W := fun iw => miss x (mem_filter.mpr ⟨mem_sdiff.mpr ⟨xh,xw⟩,PinnedColor34.two G ui.ne ux.symm xi uw iw⟩) ux
          have ih := (highOr ui ux xi.symm).resolve_right (fun iy => xw ((ylink ux (iy ▸ xi.symm)) ▸ bw))
          exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_sdiff.mpr ⟨ih,iw⟩,ui⟩,xi⟩
        have le := (card_le_card sub).trans (matching x (mem_filter.mpr ⟨mem_sdiff.mpr ⟨xh,xw⟩,ux⟩))
        exact le.trans (Nat.le_add_right ..)
      · have eq : nbr G x N=0 := card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp any)
        rw [eq]; omega
  let S := Repair.linkSupport G u
  have sn : S⊆N := Repair.support_sub G u
  have sum := sum_le_sum (s:=S) (fun x xm => (Repair.nbr_mono G x sn).trans (point x (sn xm)))
  rw [Repair.link_sum] at sum
  have extra : (∑ x∈S,(if x=b then 1 else 0 : ℕ))≤1 := by simp [sum_ite_eq']; split <;> omega
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.mul_one,Nat.cast_id] at sum
  have card := card_le_card sn
  change S.card≤(G.neighborFinset u).card at card
  rw [card_neighborFinset_eq_degree] at card
  omega
end Graffiti384b.AnchorScore34
#print axioms Graffiti384b.AnchorScore34.degree
