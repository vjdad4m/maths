import LowMateClose

namespace Graffiti384b.Shared29
open Finset SimpleGraph LowSample Donor JointRank
open private LowSample.two_degree from LowSample384b
open private Repair.linkEdges Repair.edge_info Repair.edge_fiber Repair.support_sub Repair.support_pos Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- If every family of d ears uses at least 2d-1 anchors, a single vertex
can border at most two ears. Erasing the common neighbor leaves one port per ear. -/
theorem ear_multiplicity
    (ports : ∀S⊆twos G,2*S.card≤(S.biUnion (fun v => G.neighborFinset v)).card+1) (w : V) :
    ((twos G).filter (G.Adj w)).card≤2 := by
  classical
  let S := (twos G).filter (G.Adj w)
  let Y := S.biUnion (fun e => (G.neighborFinset e).erase w)
  have subset : S.biUnion (fun e => G.neighborFinset e)⊆insert w Y := by
    intro v vm
    obtain ⟨e,es,ve⟩ := mem_biUnion.mp vm
    by_cases vw : v=w
    · exact mem_insert.mpr (Or.inl vw)
    · exact mem_insert_of_mem (mem_biUnion.mpr ⟨e,es,mem_erase.mpr ⟨vw,ve⟩⟩)
  have one (e : V) (es : e∈S) : ((G.neighborFinset e).erase w).card=1 := by
    obtain ⟨et,we⟩ := mem_filter.mp es
    rw [card_erase_of_mem ((G.mem_neighborFinset ..).mpr we.symm),card_neighborFinset_eq_degree,LowSample.two_degree G et]
  have bound : Y.card≤S.card := (card_biUnion_le ..).trans (by simp only [sum_congr rfl one,sum_const,nsmul_eq_mul,mul_one,Nat.cast_id,le_rfl])
  have ct := card_le_card subset
  have ins := card_insert_le w Y
  have demand := ports S (filter_subset ..)
  change S.card≤2
  omega

/-- At an anchor w, triangles with two high partners are supported on the
other anchors and the exposed pool vertices. Each incident ear accounts for
at most one further triangle. Vertices of degree at most one contribute zero. -/
theorem anchor_cap (W : Finset V) (ws : W.card=3) (w : V) (wm : w∈W)
    (ears : ((twos G).filter (G.Adj w)).card≤2) :
    trianglesAt G w≤((exposed G (high G\W)).card+2).choose 2+2 := by
  classical
  let X := high G\W
  let Y := W.erase w ∪ exposed G X
  let T := Repair.linkSupport G w
  let L := T\high G
  let F := fun x : V => (Repair.linkEdges G w).filter (fun p => x∈p)
  have out : w∉T := fun wm => G.irrefl ((G.mem_neighborFinset ..).mp (Repair.support_sub G w wm))
  have counts (x : V) (xl : x∈L) : x∈(twos G).filter (G.Adj w) ∧ (F x).card≤1 := by
    obtain ⟨xt,nx⟩ := mem_sdiff.mp xl
    have adj := (G.mem_neighborFinset ..).mp (Repair.support_sub G w xt)
    have deg : G.degree x<3 := by simpa [high] using nx
    have off : 0<nbr G x Tᶜ := card_pos.mpr ⟨w,mem_filter.mpr ⟨mem_compl.mpr out,adj.symm⟩⟩
    have on := Repair.support_pos G xt
    change 1≤nbr G x T at on
    have total := Repair.full_nbr G x T
    refine ⟨mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,nx⟩,adj⟩,?_⟩
    change ((Repair.linkEdges G w).filter (fun p => x∈p)).card≤1
    rw [Repair.edge_fiber G xt]
    change nbr G x T≤1
    omega
  have cover : Repair.linkEdges G w ⊆ Y.powersetCard 2 ∪ L.biUnion F := by
    intro p pm
    obtain ⟨pn,sz,_⟩ := Repair.edge_info G pm
    by_cases allH : p⊆high G
    · apply mem_union_left _ (mem_powersetCard.mpr ⟨?_,sz⟩)
      intro x xm
      have wx := (G.mem_neighborFinset ..).mp (pn xm)
      by_cases xw : x∈W
      · exact mem_union_left _ (mem_erase.mpr ⟨wx.ne.symm,xw⟩)
      · exact mem_union_right _ (mem_filter.mpr ⟨mem_sdiff.mpr ⟨allH xm,xw⟩,w,fun h => (mem_sdiff.mp h).2 wm,wx.symm⟩)
    · obtain ⟨x,xm,xl⟩ := not_subset.mp allH
      exact mem_union_right _ (mem_biUnion.mpr ⟨x,mem_sdiff.mpr ⟨mem_biUnion.mpr ⟨p,pm,xm⟩,xl⟩,mem_filter.mpr ⟨pm,xm⟩⟩)
  have ct := (card_le_card cover).trans (card_union_le ..)
  have lsize := (card_le_card (show L⊆(twos G).filter (G.Adj w) from fun x xl => (counts x xl).1)).trans ears
  have pairs := (card_biUnion_le (s:=L) (t:=F)).trans (sum_le_sum (g:=fun _ => 1) (fun x xl => (counts x xl).2))
  simp only [sum_const,nsmul_eq_mul,mul_one,Nat.cast_id] at pairs
  have ysize := card_union_le (W.erase w) (exposed G X)
  rw [card_erase_of_mem wm,ws] at ysize
  have maxY : Y.card≤(exposed G X).card+2 := by change (W.erase w ∪ exposed G X).card≤_; omega
  have choose := Nat.choose_le_choose 2 maxY
  rw [card_powersetCard] at ct
  change (Repair.linkEdges G w).card≤((exposed G X).card+2).choose 2+2
  omega

omit [Fintype V] in
/-- Three reserved, low-scoring anchors create three holes in the ranks
of the remaining high vertices past their common score cap. -/
theorem rank_gap {X W H : Finset V} (score : V→ℕ) (inj : Set.InjOn score (H:Set V))
    (rich : ∀w∈H,2≤score w) (xh : X⊆H) (wh : W⊆H) (dis : Disjoint X W)
    (ws : W.card=3) (cap : ℕ) (bounded : ∀w∈W,score w≤cap)
    {v : V} (vm : v∈X) (threshold : cap≤rank X score v+4) : rank X score v+5≤score v := by
  classical
  let L := X.filter (fun z => score z<score v)
  have lh : L⊆H := (filter_subset ..).trans xh
  have vl : v∉L := fun m => (lt_irrefl _) (mem_filter.mp m).2
  have d : Disjoint (insert v L) W := dis.mono_left (insert_subset vm (filter_subset ..))
  have lower := JointRank.rank_lower H score inj 2 rich (xh vm)
  have large : cap<score v := by
    by_contra! small
    have image : ((insert v L ∪ W).image score)⊆Icc 2 cap := by
      intro z zm
      obtain ⟨x,xm,rfl⟩ := mem_image.mp zm
      rcases mem_union.mp xm with xl|xw
      · rcases mem_insert.mp xl with rfl|xl
        · exact mem_Icc.mpr ⟨rich _ (xh vm),small⟩
        · exact mem_Icc.mpr ⟨rich _ (lh xl),((mem_filter.mp xl).2.le.trans small)⟩
      · exact mem_Icc.mpr ⟨rich _ (wh xw),bounded _ xw⟩
    have ct := card_le_card image
    rw [card_image_of_injOn (inj.mono (union_subset (insert_subset (xh vm) lh) wh)),
      card_union_of_disjoint d,card_insert_of_not_mem vl,ws,Nat.card_Icc] at ct
    change cap≤L.card+4 at threshold
    omega
  have sub : L∪W⊆H.filter (fun z => score z<score v) := by
    intro x xm
    rcases mem_union.mp xm with xl|xw
    · exact mem_filter.mpr ⟨lh xl,(mem_filter.mp xl).2⟩
    · exact mem_filter.mpr ⟨wh xw,(bounded _ xw).trans_lt large⟩
  have ct := card_le_card sub
  rw [card_union_of_disjoint (dis.mono_left (filter_subset ..)),ws] at ct
  change L.card+3≤rank H score v at ct
  change L.card+5≤score v
  omega

end Graffiti384b.Shared29
#print axioms Graffiti384b.Shared29.ear_multiplicity
#print axioms Graffiti384b.Shared29.anchor_cap
#print axioms Graffiti384b.Shared29.rank_gap
