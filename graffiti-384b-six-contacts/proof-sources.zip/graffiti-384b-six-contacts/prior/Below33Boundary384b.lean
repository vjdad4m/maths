import Finish31Boundary384b
import Lower384b

namespace Graffiti384b.Below33
open Finset SimpleGraph CliqueSample CliqueChoice LowSample
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def batch (f : Finset ℕ) := if f=∅ then 12 else 11

private def EvenRow (f : Finset ℕ) :=
  let m := 30-f.card
  let b := batch f
  12 ≤ m ∧ envelope m b ∧ reward m b ∧
    6*(15*m.choose b+charge 32 30 m b f Boundary.levels) <
    6*(m-b)*m.choose b + 6*(m-2).choose (b-2) + 6*(∑ d ∈ f,bonus m b d)

set_option maxRecDepth 32768 in
set_option maxHeartbeats 8000000 in
private theorem even_rows : ∀ f ∈ Boundary.levels.powerset, EvenRow f := by
  unfold EvenRow batch envelope reward charge LowSample.delta LowSample.weight bonus slots FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

theorem exact32 (hc : G.Connected) (hn : 2 < Fintype.card V) (t : (types G).card=32) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨R,_,cap,_,_,same,_⟩ := Prune.prune_failure G hc hn fail
  have num : (types (G.induce (R : Set V))).card ≤ R.card := by
    simpa [types] using (card_image_le (s := (univ : Finset R)) (f := trianglesAt (G.induce (R : Set V))))
  rw [same,t] at num
  have hh := type_bound G
  have miss : ((high G).card+1)/2 < ((types G).card+1)/2 := Nat.lt_of_not_ge (fun le => (not_lt_of_ge (exact_of_high G le)) fail)
  have h : (high G).card=30 := by omega
  letI : Nonempty V := hc.nonempty
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  let f := p.image (G.degree ·)
  let m := 30-f.card
  let b := batch f
  obtain ⟨room,env,rew,win⟩ := even_rows f (mem_powerset.mpr ch.levels)
  have sz : (high G \ p).card=m := by dsimp [m,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub,h]
  have obs := CliqueSample.obstruction G ch b (sz ▸ room) (by dsimp [b,batch]; split_ifs <;> decide) (sz ▸ env) (sz ▸ rew) fail
  dsimp only at obs
  rw [h,t] at obs
  change 6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f,bonus m b d) ≤
    6*(15*m.choose b+charge 32 30 m b f Boundary.levels) at obs
  change 6*(15*m.choose b+charge 32 30 m b f Boundary.levels) <
    6*(m-b)*m.choose b + 6*(m-2).choose (b-2) + 6*(∑ d ∈ f,bonus m b d) at win
  have sub : high G ⊆ nonleaves G := fun v hv => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count : (twos G).card+(high G).card=(nonleaves G).card := card_sdiff_add_card_eq_card sub
  have low := Nat.mul_le_mul_right (6*(m-2).choose (b-2)) (show 1 ≤ (twos G).card by omega)
  rw [Nat.one_mul] at low
  omega

/-- Outside diversity 33, a smaller connected induced witness preserves
every original count. -/
theorem nonleaf_cap (ht : (types G).card<33) (hc : G.Connected) (hn : 2<Fintype.card V) (bad : bound G<gamma G) :
    (nonleaves G).card≤32 := by
  by_contra! q
  by_cases even : (types G).card=32
  · exact (not_lt_of_ge (exact32 G hc hn even)) bad
  by_cases top : (types G).card=31
  · exact (not_lt_of_ge (Finish31.exact31 G top q)) bad
  by_cases t29 : (types G).card=29
  · exact (not_lt_of_ge (Lower.exact_of_quota G hc (by simp [Lower.inputs,t29]) (by simpa [Lower.quota,t29] using q))) bad
  by_cases big : 14≤(types G).card
  · have rows : ∀ a : Fin 31, ∀ e : Fin 3, a.val≠29 → (LowSample.row a e).1≤32 := by decide
    have h := type_bound G
    have cap := (nonleaf_profile G bad big (by omega)).1
    have sm : (types G).card<31 := by omega
    exact (not_lt_of_ge (cap.trans (rows ⟨(types G).card,sm⟩ ⟨(types G).card-(high G).card,by omega⟩ t29))) q
  · have cap := nonleaf_bound G
    unfold bound at bad
    omega

theorem induced_bound (ht : (types G).card<33) (hc : G.Connected) (hn : 2<Fintype.card V) (bad : bound G<gamma G) :
    ∃ r : Finset V, 2<r.card ∧ r.card≤33 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V))=types G ∧ bound (G.induce (r : Set V))<gamma (G.induce (r : Set V)) := by
  obtain ⟨r,_,cap,ord,conn,same,fail⟩ := Prune.prune_failure G hc hn bad
  have q := nonleaf_cap G ht hc hn bad
  exact ⟨r,ord,by omega,conn,same,fail⟩

end Graffiti384b.Below33
#print axioms Graffiti384b.Below33.exact32
#print axioms Graffiti384b.Below33.induced_bound
