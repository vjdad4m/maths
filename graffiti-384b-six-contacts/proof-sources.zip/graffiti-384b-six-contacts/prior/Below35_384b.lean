import Finish33_384b
import Lower384b

namespace Graffiti384b.Below35
open Finset SimpleGraph CliqueSample CliqueChoice LowSample
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def EvenRow (f : Finset ℕ) :=
  let m := 32-f.card
  12 ≤ m ∧ envelope m 12 ∧ reward m 12 ∧
    6*(16*m.choose 12+charge 34 32 m 12 f Boundary.levels) <
    6*(m-12)*m.choose 12 + 6*(m-2).choose 10 + 6*(∑ d ∈ f,bonus m 12 d)

set_option maxRecDepth 32768 in
set_option maxHeartbeats 8000000 in
private theorem even_rows : ∀ f ∈ Boundary.levels.powerset, EvenRow f := by
  unfold EvenRow envelope reward charge LowSample.delta LowSample.weight bonus slots FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

theorem exact34 (hc : G.Connected) (hn : 2 < Fintype.card V) (t : (types G).card=34) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨R,_,cap,_,_,same,_⟩ := Prune.prune_failure G hc hn fail
  have num : (types (G.induce (R : Set V))).card ≤ R.card := by
    simpa [types] using (card_image_le (s := (univ : Finset R)) (f := trianglesAt (G.induce (R : Set V))))
  rw [same,t] at num
  have hh := type_bound G
  have miss : ((high G).card+1)/2 < ((types G).card+1)/2 := Nat.lt_of_not_ge (fun le => (not_lt_of_ge (exact_of_high G le)) fail)
  have h : (high G).card=32 := by omega
  letI : Nonempty V := hc.nonempty
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  let f := p.image (G.degree ·)
  let m := 32-f.card
  obtain ⟨room,env,rew,win⟩ := even_rows f (mem_powerset.mpr ch.levels)
  have sz : (high G \ p).card=m := by dsimp [m,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub,h]
  have obs := CliqueSample.obstruction G ch 12 (sz ▸ room) (by decide) (sz ▸ env) (sz ▸ rew) fail
  dsimp only at obs
  rw [h,t] at obs
  change 6*(m-12)*m.choose 12 + (twos G).card*(6*(m-2).choose 10) + 6*(∑ d ∈ f,bonus m 12 d) ≤
    6*(16*m.choose 12+charge 34 32 m 12 f Boundary.levels) at obs
  change 6*(16*m.choose 12+charge 34 32 m 12 f Boundary.levels) <
    6*(m-12)*m.choose 12 + 6*(m-2).choose 10 + 6*(∑ d ∈ f,bonus m 12 d) at win
  have sub : high G ⊆ nonleaves G := fun v hv => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count : (twos G).card+(high G).card=(nonleaves G).card := card_sdiff_add_card_eq_card sub
  have low := Nat.mul_le_mul_right (6*(m-2).choose 10) (show 1 ≤ (twos G).card by omega)
  rw [Nat.one_mul] at low
  omega

theorem nonleaf_cap (ht : (types G).card < 35) (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    (nonleaves G).card ≤ 33 := by
  by_contra! q
  have hi : (types G).card < 34 := by
    by_contra! big
    exact (not_lt_of_ge (exact34 G hc hn (by omega))) bad
  by_cases top : (types G).card=33
  · exact (not_lt_of_ge (Finish33.exact33 G top q)) bad
  by_cases member : (types G).card ∈ Lower.inputs
  · apply (not_lt_of_ge (Lower.exact_of_quota G hc member ?_)) bad
    simp only [Lower.inputs,mem_insert,mem_singleton] at member
    rcases member with e|e|e|e <;> simp [Lower.quota,e] <;> omega
  · by_cases many : 14 ≤ (types G).card
    · have cap := (nonleaf_profile G bad many (by omega)).1
      have rows : ∀ t : Fin 33, ∀ e : Fin 3, t.val ∉ Lower.inputs → (LowSample.row t e).1 ≤ 33 := by decide
      have lim := type_bound G
      exact (not_le_of_gt q) (cap.trans (rows ⟨(types G).card,by omega⟩ ⟨(types G).card-(high G).card,by omega⟩ member))
    · have n := nonleaf_bound G
      unfold bound at bad
      omega

/-- The full set of triangle counts survives on a connected induced failure
of order at most 34. The statement applies before least-order normalization. -/
theorem bounded_failure (ht : (types G).card < 35) (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ r.card ≤ 34 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V))=types G ∧ bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨r,_,size,ord,conn,same,fail⟩ := Prune.prune_failure G hc hn bad
  have lim := nonleaf_cap G ht hc hn bad
  exact ⟨r,ord,by omega,conn,same,fail⟩

end Graffiti384b.Below35
#print axioms Graffiti384b.Below35.exact34
#print axioms Graffiti384b.Below35.bounded_failure
