import BlockFibers384b
import Boundary384b

namespace Graffiti384b.BlockAccounting
open Finset SimpleGraph CliqueChoice CliqueSample BlockActivation BlockFibers LowSample
open private LowSample.eligible LowSample.weight LowSample.two_degree LowSample.anchors LowSample.anchor_samples from LowSample384b
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Sample outside the center. Its neighbors may count it as permanently
retained, since every one of them is independent of this support whenever
the center itself is activated. -/
theorem balance {p : Finset V} (choice : Choice G p Boundary.levels) (x : V)
    (xh : x ∈ high G) (xp : x ∉ p)
    (nx : G.neighborFinset x ⊆ high G \ insert x p) (b r : ℕ) (two : 2 ≤ b)
    (db : G.degree x ≤ b) (miss : (BlockGeometry.gaps G (G.neighborFinset x)).card ≤ r)
    (rew : reward (high G \ insert x p).card b) (t : (types G).card=35) (fail : bound G < gamma G) :
    let s := high G \ insert x p
    let f := p.image (G.degree ·)
    6*(s.card-b)*s.card.choose b + (twos G).card*(6*(s.card-2).choose (b-2)) +
      6*(∑ d ∈ f, bonus s.card b d) + 6*income s.card b (G.degree x) r ≤
      6*(17*s.card.choose b + ∑ k ∈ s.powersetCard b, (FiniteRange.bad G s k).card) := by
  classical
  let P := insert x p
  let s := high G \ P
  let f := p.image (G.degree ·)
  let opts := s.powersetCard b
  let N := G.neighborFinset x
  let z := twos G
  let W (v : V) := LowSample.weight (LowSample.anchors G v).card
  have ph : P ⊆ high G := insert_subset xh choice.high_sub
  have allN (v : V) (hv : v ∈ P) : G.neighborFinset v ⊆ high G := by
    rcases mem_insert.mp hv with rfl|vp
    · exact nx.trans sdiff_subset
    · exact (neighbors_in_pool G choice vp).trans sdiff_subset
  have np (v : V) (vp : v ∈ p) : G.neighborFinset v ⊆ s := by
    intro w hw
    obtain ⟨wh,wp⟩ := mem_sdiff.mp (neighbors_in_pool G choice vp hw)
    refine mem_sdiff.mpr ⟨wh,fun inc => ?_⟩
    rcases mem_insert.mp inc with rfl|yes
    · exact (mem_sdiff.mp (nx ((G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp hw).symm))).2 (mem_insert_of_mem vp)
    · exact wp yes
  have mass : z.card * (6*(s.card-2).choose (b-2)) ≤ ∑ k ∈ opts, ∑ v ∈ LowSample.eligible G k, W v := by
    calc
      _ = ∑ _v ∈ z, (6*(s.card-2).choose (b-2)) := by simp
      _ ≤ ∑ v ∈ z, ∑ k ∈ opts, if LowSample.anchors G v ⊆ k then W v else 0 := by
        apply sum_le_sum
        intro v hv
        have count : (LowSample.anchors G v).card ≤ 2 := by
          have sub : LowSample.anchors G v ⊆ G.neighborFinset v := fun x hx =>
            (G.mem_neighborFinset _ _).mpr (mem_filter.mp hx).2
          simpa only [card_neighborFinset_eq_degree,LowSample.two_degree G hv] using card_le_card sub
        have a := rew ⟨(LowSample.anchors G v).card,by omega⟩
        have keep : LowSample.anchors G v ⊆ s := by
          intro w hw
          obtain ⟨wh,vw⟩ := mem_filter.mp hw
          exact mem_sdiff.mpr ⟨wh,fun wp => (mem_sdiff.mp hv).2 (allN _ wp ((G.mem_neighborFinset _ _).mpr vw.symm))⟩
        have q := LowSample.anchor_samples s (LowSample.anchors G v) b keep (by omega)
        rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.cast_id]
        simpa only [Nat.mul_comm (W v),W,opts,s] using a.trans (Nat.mul_le_mul_left _ q)
      _ = _ := by rw [sum_comm]; simp [LowSample.eligible,z,sum_filter]

  have credit : ∑ d ∈ f, bonus s.card b d ≤ ∑ k ∈ opts, (active G p k).card := by
    calc
      _ = ∑ v ∈ p, bonus s.card b (G.degree v) := sum_image (fun _ hx _ hy eq => choice.unique hx hy eq)
      _ ≤ ∑ v ∈ p, (opts.filter (fun k => v ∈ active G p k)).card :=
        sum_le_sum (fun v hv => BlockTrial.active_fiber G p s b hv (np _ hv) (fun mem => (mem_sdiff.mp mem).2 (mem_insert_of_mem hv)))
      _ = ∑ v ∈ p, ∑ k ∈ opts, (if v ∈ active G p k then 1 else 0 : ℕ) := by simp
      _ = _ := by
        rw [sum_comm]; apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show active G p k ⊆ p from filter_subset _ _)]

  let ready (k : Finset V) := Ready G N (k ∩ N)
  have point (k : Finset V) (hk : k ∈ opts) : 6*(s.card-b) + (∑ v ∈ LowSample.eligible G k,W v) +
      6*(active G p k).card + 6*(if ready k then 1 else 0) ≤ 6*(17+(FiniteRange.bad G s k).card) := by
    obtain ⟨ks,size⟩ := mem_powersetCard.mp hk
    let A := active G p k
    let c := if ready k then insert x A else A
    have cp : c ⊆ P := by
      dsimp [c]; split_ifs
      · exact insert_subset_insert _ (filter_subset _ _)
      · exact (filter_subset _ _).trans (subset_insert _ _)
    have casesC {w : V} (wc : w ∈ c) : (ready k ∧ w=x) ∨ w ∈ A := by
      dsimp [c] at wc; split_ifs at wc with ok
      · exact (mem_insert.mp wc).elim (fun eq => Or.inl ⟨ok,eq⟩) Or.inr
      · exact Or.inr wc
    have keep (w : V) (wc : w ∈ c) : 2 ≤ nbr G w k := by
      rcases casesC wc with ⟨good,rfl⟩|wa
      · have eq : k.filter (G.Adj w)=k∩N := by ext z; simp [N]
        unfold nbr; rw [eq]; exact good.1
      · exact (mem_filter.mp wa).2
    have prot (w : V) (wc : w ∈ c) (v : V) (edge : G.Adj w v) (out : v ∉ k) : 2 ≤ nbr G v k := by
      rcases casesC wc with ⟨good,rfl⟩|wa
      · exact (good.2 v ((G.mem_neighborFinset _ _).mpr edge) (fun mem => out (mem_inter.mp mem).1)).trans
          (card_le_card (filter_subset_filter _ inter_subset_left))
      · have inc : k.filter (G.Adj w) ⊆ k.filter (G.Adj v) := by
          intro y hy
          obtain ⟨yk,wy⟩ := mem_filter.mp hy
          exact mem_filter.mpr ⟨yk,saturated_clique G (choice.exact_score _ (mem_filter.mp wa).1) v y edge wy
            (fun eq => out (eq ▸ yk))⟩
        exact (mem_filter.mp wa).2.trans (card_le_card inc)
    have bound := BlockTrial.trial G P k c ph ks cp allN keep prot fail
    dsimp only at bound
    rw [t,size] at bound
    have nc : x ∉ A := fun ha => xp (mem_filter.mp ha).1
    have card : c.card=A.card+(if ready k then 1 else 0) := by dsimp [c]; split_ifs <;> simp [nc]
    rw [card,Nat.mul_add] at bound
    simpa only [Nat.add_assoc] using bound
  have tot := sum_le_sum point
  simp only [sum_add_distrib,Nat.mul_add,← mul_sum,sum_const,nsmul_eq_mul,opts,card_powersetCard,Nat.cast_id,sum_boole] at tot
  have xx := center_mass G s N nx b r ((card_neighborFinset_eq_degree _ _).trans_le db) miss
  change income s.card b N.card r ≤ (opts.filter ready).card at xx
  rw [show N.card=G.degree x from card_neighborFinset_eq_degree _ _] at xx
  have indicator : (∑ k ∈ opts, if ready k then (1 : ℕ) else 0) = (opts.filter ready).card := Finset.sum_boole ready opts
  dsimp only [opts] at mass credit xx indicator
  dsimp only
  change 6*(s.card-b)*s.card.choose b + z.card*(6*(s.card-2).choose (b-2)) + 6*(∑ d ∈ f, bonus s.card b d) +
    6*income s.card b (G.degree x) r ≤ 6*(17*s.card.choose b+ ∑ k ∈ s.powersetCard b,(FiniteRange.bad G s k).card)
  rw [Nat.mul_comm (6*(s.card-b)) (s.card.choose b),Nat.mul_left_comm (s.card.choose b) 6 (s.card-b),Nat.mul_comm 17 (s.card.choose b)]
  omega

end Graffiti384b.BlockAccounting
#print axioms Graffiti384b.BlockAccounting.balance
