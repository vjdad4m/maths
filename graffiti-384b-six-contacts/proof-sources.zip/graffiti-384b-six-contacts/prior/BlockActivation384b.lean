import BlockGeometry384b
import RankStrata384b

namespace Graffiti384b.BlockActivation
open Finset SimpleGraph BlockGeometry
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def Ready (N X : Finset V) := 2 ≤ X.card ∧ ∀ v ∈ N, v ∉ X → 2 ≤ nbr G v X
instance (N X : Finset V) : Decidable (Ready G N X) := by unfold Ready; infer_instance

def localCount (d r j : ℕ) := if j<2 then 0 else if j=2 then (d-2*r).choose 2
  else d.choose j - r.choose (j-1)*(d-j)

private def star (v : V) (T : Finset V) := T.image (fun w => ({v,w} : Finset V))

omit [Fintype V] in
private theorem star_inj (v : V) (s : Finset V) (no : v ∉ s) :
    Set.InjOn (fun w => ({v,w} : Finset V)) (s : Set V) := by
  intro a ha b hb eq
  change ({v,a} : Finset V)={v,b} at eq
  have mem : a ∈ ({v,b} : Finset V) := by rw [← eq]; exact mem_insert_of_mem (mem_singleton_self a)
  rcases mem_insert.mp mem with av|ab
  · exact (no (av ▸ ha)).elim
  · exact mem_singleton.mp ab

omit [Fintype V] in
private theorem recover {v w : V} {T U : Finset V} (vt : v ∉ T) (wu : w ∉ U) (big : 2 ≤ T.card)
    (eq : star v T = star w U) : v=w ∧ T=U := by
  have covers (z : V) (hz : z ∈ T) : w ∈ ({v,z} : Finset V) := by
    have ez : ({v,z} : Finset V) ∈ star w U := eq ▸ mem_image_of_mem _ hz
    obtain ⟨u,_,eu⟩ := mem_image.mp ez
    rw [← eu]; exact mem_insert_self _ _
  have h : v=w := by
    by_contra ne
    have sub : T ⊆ {w} := fun z hz => mem_singleton.mpr ((mem_singleton.mp
      ((mem_insert.mp (covers z hz)).resolve_left (Ne.symm ne))).symm)
    have small := card_le_card sub
    simp only [card_singleton] at small
    omega
  subst w
  refine ⟨rfl,?_⟩
  ext z
  constructor
  · intro hz
    have hit : ({v,z} : Finset V) ∈ star v U := eq ▸ mem_image_of_mem _ hz
    obtain ⟨u,hu,same⟩ := mem_image.mp hit
    have mem : u ∈ ({v,z} : Finset V) := same ▸ mem_insert_of_mem (mem_singleton_self u)
    exact mem_singleton.mp ((mem_insert.mp mem).resolve_left (fun e => wu (e ▸ hu))) ▸ hu
  · intro hz
    have hit : ({v,z} : Finset V) ∈ star v T := eq.symm ▸ mem_image_of_mem _ hz
    obtain ⟨u,hu,same⟩ := mem_image.mp hit
    have mem : u ∈ ({v,z} : Finset V) := same ▸ mem_insert_of_mem (mem_singleton_self u)
    exact mem_singleton.mp ((mem_insert.mp mem).resolve_left (fun e => vt (e ▸ hu))) ▸ hu

/-- An unready j-subset for j at least three determines j-1 missing
edges with a common endpoint and one remaining sampled vertex. Two or
more distinct edges uniquely determine their common endpoint. -/
private theorem bad_large (N : Finset V) (j : ℕ) (three : 3 ≤ j) :
    ((N.powersetCard j).filter (fun X => ¬Ready G N X)).card ≤ (gaps G N).card.choose (j-1)*(N.card-j) := by
  classical
  let B := (N.powersetCard j).filter (fun X => ¬Ready G N X)
  have data (X : Finset V) (hx : X ∈ B) :
      ∃ v ∈ N, v ∉ X ∧ ∃ T ⊆ X, T.card=j-1 ∧ (∀ z ∈ T, ¬G.Adj v z) ∧ ∃ w ∈ N, w ∉ insert v T ∧ X=insert w T := by
    obtain ⟨row,no⟩ := mem_filter.mp hx
    obtain ⟨xn,xj⟩ := mem_powersetCard.mp row
    have miss : ∃ v ∈ N, v ∉ X ∧ nbr G v X ≤ 1 := by
      by_contra! clear
      exact no ⟨by omega,fun v hv out => by have := clear v hv out; omega⟩
    obtain ⟨v,vn,out,few⟩ := miss
    let F := X.filter (fun z => ¬G.Adj v z)
    have partition := filter_card_add_filter_neg_card_eq_card (s := X) (G.Adj v)
    change nbr G v X + F.card=X.card at partition
    obtain ⟨T,sub,sz⟩ := exists_subset_card_eq (show j-1 ≤ F.card by omega)
    have tx : T ⊆ X := sub.trans (filter_subset _ _)
    have left : (X \ T).card=1 := by rw [card_sdiff tx,sz,xj]; omega
    obtain ⟨w,hw⟩ := card_eq_one.mp left
    have wm : w ∈ X\T := hw ▸ mem_singleton_self _
    refine ⟨v,vn,out,T,tx,sz,fun z hz => (mem_filter.mp (sub hz)).2,w,xn (mem_sdiff.mp wm).1,?_,?_⟩
    · simp only [mem_insert,not_or]; exact ⟨fun e => out (e ▸ (mem_sdiff.mp wm).1),(mem_sdiff.mp wm).2⟩
    · have join := sdiff_union_of_subset tx
      rw [hw] at join
      simpa using join.symm
  choose v vn vx T tx ts missing w wn wt eq using data
  let I := (gaps G N).powersetCard (j-1)
  let map (x : B) := star (v x x.property) (T x x.property)
  have maps (x : B) : map x ∈ I := by
    have xx : (x : Finset V) ⊆ N := (mem_powersetCard.mp (mem_filter.mp x.property).1).1
    have out : v x x.property ∉ T x x.property := fun ht => vx _ _ (tx _ _ ht)
    refine mem_powersetCard.mpr ⟨?_,?_⟩
    · intro e he
      obtain ⟨z,hz,rfl⟩ := mem_image.mp he
      exact pair_gap G (vn _ _) (xx (tx _ _ hz)) (fun e => out (e ▸ hz)) (missing _ _ z hz)
    · exact (card_image_of_injOn (star_inj _ _ out)).trans (ts _ _)
  let fiber (e : Finset (Finset V)) := B.attach.filter (fun x => map x=e)
  have lim (e : Finset (Finset V)) (_ : e ∈ I) : (fiber e).card ≤ N.card-j := by
    by_cases pos : (fiber e).Nonempty
    · obtain ⟨a,ha⟩ := pos
      let i := v a a.property
      let S := T a a.property
      have nS : i ∉ S := fun ht => vx _ _ (tx _ _ ht)
      have ssub : insert i S ⊆ N := insert_subset (vn _ _) ((tx _ _).trans (mem_powersetCard.mp (mem_filter.mp a.property).1).1)
      have nums : (insert i S).card=j := by rw [card_insert_of_not_mem nS]; dsimp [S]; rw [ts]; omega
      have same (x : B) (hx : x ∈ fiber e) : v x x.property=i ∧ T x x.property=S := by
        exact recover (fun h => vx _ _ (tx _ _ h)) nS (by rw [ts]; omega) ((mem_filter.mp hx).2.trans (mem_filter.mp ha).2.symm)
      let f (x : B) := w x x.property
      have sub : (fiber e).image f ⊆ N \ insert i S := by
        intro z hz
        obtain ⟨x,hx,rfl⟩ := mem_image.mp hz
        obtain ⟨iv,ss⟩ := same x hx
        exact mem_sdiff.mpr ⟨wn _ _,iv ▸ ss ▸ wt _ _⟩
      have inj : Set.InjOn f (fiber e : Set B) := by
        intro x hx y hy sameW
        apply Subtype.ext
        rw [eq x x.property,eq y y.property,(same x hx).2,(same y hy).2]
        change insert (f x) S=insert (f y) S
        rw [sameW]
      have le := card_le_card sub
      rwa [card_image_of_injOn inj,card_sdiff ssub,nums] at le
    · rw [not_nonempty_iff_eq_empty.mp pos,card_empty]; omega
  have count := sum_card_fiberwise_eq_card_filter (s := B.attach) (t := I) map
  change (∑ e ∈ I,(fiber e).card) = _ at count
  rw [filter_eq_self.mpr (fun x _ => maps x),card_attach] at count
  calc
    _ = ∑ e ∈ I,(fiber e).card := count.symm
    _ ≤ ∑ _e ∈ I,(N.card-j) := sum_le_sum lim
    _ = _ := by simp [I]

theorem local_bound (N : Finset V) (r j : ℕ) (miss : (gaps G N).card ≤ r) :
    localCount N.card r j ≤ ((N.powersetCard j).filter (Ready G N)).card := by
  unfold localCount
  split_ifs with small two
  · exact Nat.zero_le _
  · subst j
    let U := N \ (gaps G N).biUnion id
    have sz := (Nat.sub_le_sub_left (footprint G N) N.card).trans (le_card_sdiff _ _)
    have lo : N.card-2*r ≤ U.card := by dsimp [U]; omega
    apply (Nat.choose_le_choose 2 lo).trans
    rw [← card_powersetCard]
    apply card_le_card
    intro X hx
    obtain ⟨sub,szX⟩ := mem_powersetCard.mp hx
    refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub.trans sdiff_subset,szX⟩,szX.ge,?_⟩
    intro v hv out
    have all : X.filter (G.Adj v)=X := filter_eq_self.mpr (by
      intro w hw
      by_contra no
      exact (mem_sdiff.mp (sub hw)).2 (mem_biUnion.mpr ⟨_,pair_gap G hv (mem_sdiff.mp (sub hw)).1
        (fun e => out (e ▸ hw)) no,mem_insert_of_mem (mem_singleton_self _)⟩))
    unfold nbr; rw [all,szX]
  · have bound := bad_large G N j (by omega)
    have count := filter_card_add_filter_neg_card_eq_card (s := N.powersetCard j) (Ready G N)
    rw [card_powersetCard] at count
    have more := Nat.mul_le_mul_right (N.card-j) (Nat.choose_le_choose (j-1) miss)
    omega

end Graffiti384b.BlockActivation
#print axioms Graffiti384b.BlockActivation.local_bound
