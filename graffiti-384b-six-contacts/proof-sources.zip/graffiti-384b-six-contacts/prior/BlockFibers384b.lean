import BlockActivation384b
import BlockTrial384b

namespace Graffiti384b.BlockFibers
open Finset SimpleGraph BlockActivation BlockGeometry CliqueChoice CliqueSample LowSample
open private LowSample.eligible LowSample.weight LowSample.anchors from LowSample384b
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def income (m b d r : ℕ) := ∑ j ∈ range (d+1), localCount d r j * (m-d).choose (b-j)

/-- Extend each ready local j-set independently outside the neighborhood.
All inspected j are at most the sample size. -/
theorem center_mass (s N : Finset V) (ns : N ⊆ s) (b r : ℕ) (db : N.card ≤ b) (miss : (gaps G N).card ≤ r) :
    income s.card b N.card r ≤ ((s.powersetCard b).filter (fun k => Ready G N (k ∩ N))).card := by
  classical
  let F := (s.powersetCard b).filter (fun k => Ready G N (k ∩ N))
  let fiber (j : ℕ) := F.filter (fun k => (k ∩ N).card=j)
  have one (j : ℕ) (hj : j ∈ range (N.card+1)) :
      localCount N.card r j * (s.card-N.card).choose (b-j) ≤ (fiber j).card := by
    let X := (N.powersetCard j).filter (Ready G N)
    let Y := (s\N).powersetCard (b-j)
    let add (z : Finset V × Finset V) := z.1 ∪ z.2
    have row {z : Finset V × Finset V} (hz : z ∈ X ×ˢ Y) :
        z.1 ⊆ N ∧ z.1.card=j ∧ Ready G N z.1 ∧ z.2 ⊆ s\N ∧ z.2.card=b-j := by
      obtain ⟨a,c⟩ := mem_product.mp hz
      obtain ⟨aa,bb⟩ := mem_filter.mp a
      exact ⟨(mem_powersetCard.mp aa).1,(mem_powersetCard.mp aa).2,bb,mem_powersetCard.mp c⟩
    have sep {z : Finset V × Finset V} (hz : z ∈ X ×ˢ Y) : Disjoint z.1 z.2 :=
      disjoint_left.mpr (fun _ x y => (mem_sdiff.mp ((row hz).2.2.2.1 y)).2 ((row hz).1 x))
    have pair {z : Finset V × Finset V} (hz : z ∈ X ×ˢ Y) : add z ∩ N = z.1 ∧ add z \ N = z.2 := by
      obtain ⟨a,_,_,c,_⟩ := row hz
      constructor <;> ext v
      · simp only [add,mem_inter,mem_union]; exact ⟨fun h => h.1.elim id (fun y => False.elim ((mem_sdiff.mp (c y)).2 h.2)),fun x => ⟨Or.inl x,a x⟩⟩
      · simp only [add,mem_sdiff,mem_union]; exact ⟨fun h => h.1.resolve_left (fun x => h.2 (a x)),fun y => ⟨Or.inr y,(mem_sdiff.mp (c y)).2⟩⟩
    have inj : Set.InjOn add (X ×ˢ Y : Finset _ ) := by
      intro z hz y hy eq
      exact Prod.ext ((pair hz).1.symm.trans (eq ▸ (pair hy).1)) ((pair hz).2.symm.trans (eq ▸ (pair hy).2))
    have sub : (X ×ˢ Y).image add ⊆ fiber j := by
      intro k hk
      obtain ⟨z,hz,rfl⟩ := mem_image.mp hk
      obtain ⟨a,aj,ready,c,cb⟩ := row hz
      have jb := mem_range.mp hj
      apply mem_filter.mpr
      rw [(pair hz).1]
      refine ⟨mem_filter.mpr ⟨mem_powersetCard.mpr ⟨union_subset (a.trans ns) (c.trans sdiff_subset),?_⟩,?_⟩,aj⟩
      · unfold add; rw [card_union_of_disjoint (sep hz),aj,cb]; omega
      · rwa [(pair hz).1]
    have bound := card_le_card sub
    rw [card_image_of_injOn inj,card_product,show Y.card=(s.card-N.card).choose (b-j) by simp [Y,card_sdiff ns]] at bound
    exact (Nat.mul_le_mul_right _ (local_bound G N r j miss)).trans bound
  have total := sum_card_fiberwise_eq_card_filter F (range (N.card+1)) (fun k => (k∩N).card)
  rw [filter_eq_self.mpr (fun _ _ => mem_range.mpr (Nat.lt_succ_of_le (card_le_card inter_subset_right)))] at total
  exact (sum_le_sum one).trans_eq total

theorem neighbor_degree (x : V) {y : V} (yn : y ∈ G.neighborFinset x) :
    G.degree x ≤ G.degree y + (gaps G (G.neighborFinset x)).card := by
  let N := G.neighborFinset x
  let A := (N.erase y).filter (fun z => ¬G.Adj y z)
  let f (z : V) : Finset V := {y,z}
  have sub : A.image f ⊆ gaps G N := by
    intro e he; obtain ⟨z,hz,rfl⟩ := mem_image.mp he
    obtain ⟨ze,non⟩ := mem_filter.mp hz
    exact pair_gap G yn (mem_erase.mp ze).2 (mem_erase.mp ze).1.symm non
  have inj : Set.InjOn f (A : Set V) := by
    intro u hu v hv eq
    have mem : u ∈ ({y,v} : Finset V) := by change u ∈ f v; rw [←eq]; exact mem_insert_of_mem (mem_singleton_self _)
    exact mem_singleton.mp ((mem_insert.mp mem).resolve_left (mem_erase.mp (mem_filter.mp hu).1).1)
  have cap := card_le_card sub
  rw [card_image_of_injOn inj] at cap
  let B := (N.erase y).filter (G.Adj y)
  have partition : B.card+A.card=(N.erase y).card := filter_card_add_filter_neg_card_eq_card (s := N.erase y) (G.Adj y)
  have retained : insert x B ⊆ G.neighborFinset y := by
    apply insert_subset ((G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp yn).symm)
    exact fun _ hz => (G.mem_neighborFinset _ _).mpr (mem_filter.mp hz).2
  have out : x ∉ B := fun hx => G.not_mem_neighborFinset_self x (mem_erase.mp (mem_filter.mp hx).1).2
  have deg := card_le_card retained
  rw [card_insert_of_not_mem out,card_neighborFinset_eq_degree] at deg
  rw [card_erase_of_mem yn] at partition
  change G.degree x ≤ G.degree y+(gaps G N).card
  have nn : N.card=G.degree x := card_neighborFinset_eq_degree _ _
  change B.card+A.card=N.card-1 at partition
  omega

end Graffiti384b.BlockFibers
#print axioms Graffiti384b.BlockFibers.center_mass
