import CliqueChoice384b
import Mathlib.Combinatorics.SimpleGraph.Clique

namespace Graffiti384b.BlockGeometry
open SimpleGraph Finset
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def gaps (N : Finset V) := (N.powersetCard 2).filter
  (fun p => ¬∀ a ∈ p, ∀ b ∈ p, a≠b → G.Adj a b)

theorem gap_count (x : V) :
    (gaps G (G.neighborFinset x)).card + trianglesAt G x = (G.degree x).choose 2 := by
  unfold gaps trianglesAt
  rw [Nat.add_comm,filter_card_add_filter_neg_card_eq_card,card_powersetCard,card_neighborFinset_eq_degree]

theorem pair_gap {N : Finset V} {a b : V} (ha : a ∈ N) (hb : b ∈ N) (ab : a≠b) (notEdge : ¬G.Adj a b) :
    {a,b} ∈ gaps G N := mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset ha (singleton_subset_iff.mpr hb),
      card_pair ab⟩, fun cl => notEdge (cl a (mem_insert_self _ _) b (mem_insert_of_mem (mem_singleton_self _)) ab)⟩

theorem two {N : Finset V} {e : Finset V} (he : e ∈ gaps G N) : e.card=2 :=
  (mem_powersetCard.mp (mem_filter.mp he).1).2

theorem footprint (N : Finset V) : ((gaps G N).biUnion id).card ≤ 2*(gaps G N).card := by
  calc
    _ ≤ ∑ e ∈ gaps G N, e.card := card_biUnion_le
    _ = ∑ _e ∈ gaps G N, 2 := sum_congr rfl (fun _ he => two G he)
    _ = _ := by simp [Nat.mul_comm]

/-- A six-clique through the center and the universal neighbors left after
removing the endpoints of every missing edge. -/
theorem shared (x : V) (dense : (gaps G (G.neighborFinset x)).card+5 ≤ G.degree x) :
    let N := G.neighborFinset x
    ∃ C U : Finset V, x ∈ C ∧ C ⊆ insert x N ∧ G.IsClique (C : Set V) ∧ 6 ≤ C.card ∧
      U ⊆ N ∧ N.card - 2*(gaps G N).card ≤ U.card ∧
      ∀ u ∈ U, ∀ v ∈ insert x N, u≠v → G.Adj u v := by
  classical
  let N := G.neighborFinset x
  let E := gaps G N
  let pick (e : Finset V) (he : e ∈ E) := (card_pos.mp (show 0<e.card by have := two G he; omega)).choose
  let H := E.attach.image (fun e => pick e.val e.property)
  have cover (e : Finset V) (he : e ∈ E) : ∃ z ∈ H, z ∈ e :=
    ⟨pick e he,mem_image.mpr ⟨⟨e,he⟩,mem_attach _ _,rfl⟩,(card_pos.mp (show 0<e.card by have := two G he; omega)).choose_spec⟩
  let C := insert x (N \ H)
  let U := N \ E.biUnion id
  have out : x ∉ N := G.not_mem_neighborFinset_self _
  have cardH : H.card ≤ E.card := (card_image_le).trans_eq card_attach
  have rank : (N \ H).card ≥ N.card-H.card := le_card_sdiff _ _
  have size : C.card=(N\H).card+1 := card_insert_of_not_mem (fun h => out (mem_sdiff.mp h).1)
  have nn : N.card=G.degree x := card_neighborFinset_eq_degree _ _
  have cc : 6 ≤ C.card := by change E.card+5 ≤ G.degree x at dense; omega
  refine ⟨C,U,mem_insert_self _ _,insert_subset_insert _ sdiff_subset,?_,cc,sdiff_subset,
    (Nat.sub_le_sub_left (footprint G N) _).trans (le_card_sdiff _ _),?_⟩
  · intro a ha b hb ne
    rcases mem_insert.mp ha with rfl | ha
    · rcases mem_insert.mp hb with rfl | hb
      · exact (ne rfl).elim
      · exact (G.mem_neighborFinset _ _).mp (mem_sdiff.mp hb).1
    · rcases mem_insert.mp hb with rfl | hb
      · exact ((G.mem_neighborFinset _ _).mp (mem_sdiff.mp ha).1).symm
      · by_contra no
        obtain ⟨z,zh,ze⟩ := cover _ (pair_gap G (mem_sdiff.mp ha).1 (mem_sdiff.mp hb).1 ne no)
        rcases mem_insert.mp ze with rfl|same
        · exact (mem_sdiff.mp ha).2 zh
        · exact (mem_sdiff.mp hb).2 (mem_singleton.mp same ▸ zh)
  · intro u hu v hv ne
    rcases mem_insert.mp hv with rfl|hv
    · exact ((G.mem_neighborFinset _ _).mp (mem_sdiff.mp hu).1).symm
    · by_contra no
      exact (mem_sdiff.mp hu).2 (mem_biUnion.mpr ⟨_,pair_gap G (mem_sdiff.mp hu).1 hv ne no,mem_insert_self _ _⟩)

end Graffiti384b.BlockGeometry
#print axioms Graffiti384b.BlockGeometry.shared
