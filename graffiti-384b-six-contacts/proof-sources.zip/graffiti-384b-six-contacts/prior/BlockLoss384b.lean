import CliqueSample384b

namespace Graffiti384b.BlockLoss
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private FiniteRange.bad from FiniteRange384b
open private LowSample.delta LowSample.eligible LowSample.anchors LowSample.weight LowSample.anchor_samples LowSample.two_degree from LowSample384b
open private CliqueSample.trial CliqueSample.active_fiber from CliqueSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Counter-dependent degree distribution bounds can be supplied independently
of the triangle profile used to derive them. -/
def chargeAt (m b : ℕ) (limit : ℕ → ℕ) :=
  m * FiniteRange.badCount m b 9 + ∑ j ∈ range 9, LowSample.delta m b j * limit j

def envelope (m b : ℕ) := ∀ d : Fin 10, 3 ≤ d.val → FiniteRange.badCount m b d.val ≤
  FiniteRange.badCount m b 9 + ∑ j ∈ range 9, if d.val ≤ j then LowSample.delta m b j else 0

theorem pool_loss (s : Finset V) (high_s : s ⊆ high G) (b : ℕ) (limit : ℕ → ℕ)
    (dist : ∀ j ∈ range 9, 3 ≤ j → (s.filter (fun v => G.degree v ≤ j)).card ≤ limit j)
    (extra : V → ℕ)
    (refund : ∀ v ∈ s, ((s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)).card + extra v ≤
      FiniteRange.badCount s.card b (min (G.degree v) 9)) (env : envelope s.card b) :
    (∑ k ∈ s.powersetCard b, (FiniteRange.bad G s k).card) + (∑ v ∈ s, extra v) ≤
      chargeAt s.card b limit := by
  classical
  let opts := s.powersetCard b
  let fiber (z : V) := (opts.filter (fun k => z ∈ FiniteRange.bad G s k)).card
  have point (z : V) (hz : z ∈ s) : fiber z + extra z ≤ FiniteRange.badCount s.card b 9 +
      ∑ j ∈ range 9, if G.degree z ≤ j then LowSample.delta s.card b j else 0 := by
    have raw := refund z hz
    change fiber z + extra z ≤ FiniteRange.badCount s.card b (min (G.degree z) 9) at raw
    by_cases le : G.degree z ≤ 9
    · rw [min_eq_left le] at raw
      exact raw.trans (env ⟨G.degree z,by omega⟩ (mem_filter.mp (high_s hz)).2)
    · rw [min_eq_right (by omega)] at raw
      exact raw.trans (Nat.le_add_right ..)
  have step (j : ℕ) (hj : j ∈ range 9) : (∑ z ∈ s, if G.degree z ≤ j then LowSample.delta s.card b j else 0) ≤
      LowSample.delta s.card b j * limit j := by
    rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    by_cases pos : 3 ≤ j
    · exact Nat.mul_le_mul_left _ (dist j hj pos)
    · simp [LowSample.delta,pos]
  have sumH := sum_le_sum point
  simp only [sum_add_distrib] at sumH
  rw [sum_comm (s := s) (t := range 9)] at sumH
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id] at sumH
  have ub : (∑ v ∈ s, fiber v) + (∑ v ∈ s, extra v) ≤ chargeAt s.card b limit :=
    sumH.trans (Nat.add_le_add_left (sum_le_sum step) _)
  apply le_trans (Nat.add_le_add_right (le_of_eq ?_) _) ub
  calc
    _ = ∑ k ∈ opts, ∑ z ∈ s, (if z ∈ FiniteRange.bad G s k then 1 else 0 : ℕ) := by
      apply sum_congr rfl
      intro k _
      simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
      rw [inter_eq_right.mpr (show FiniteRange.bad G s k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
    _ = _ := by rw [sum_comm]; simp [fiber]


end Graffiti384b.BlockLoss
#print axioms Graffiti384b.BlockLoss.pool_loss
