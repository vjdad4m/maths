import CliqueSample384b

namespace Graffiti384b.BlockTrial
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private LowSample.greedy LowSample.eligible LowSample.weight LowSample.anchors LowSample.two_degree from LowSample384b
open private Repair.full_nbr Repair.omit_set from Repair384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem trial (P k c : Finset V) (ph : P ⊆ high G) (ks : k ⊆ high G \ P)
    (cp : c ⊆ P) (neighbors : ∀ w ∈ P, G.neighborFinset w ⊆ high G)
    (active : ∀ w ∈ c, 2 ≤ nbr G w k)
    (protect : ∀ w ∈ c, ∀ v, G.Adj w v → v ∉ k → 2 ≤ nbr G v k)
    (fail : bound G < gamma G) :
    let s := high G \ P
    6*(s.card-k.card) + (∑ v ∈ LowSample.eligible G k, LowSample.weight (LowSample.anchors G v).card) + 6*c.card ≤
      6*((((types G).card+1)/2-1) + (FiniteRange.bad G s k).card) := by
  let s := high G \ P
  let e := LowSample.eligible G k
  let a := (s \ k) \ FiniteRange.bad G s k
  have low : e ⊆ (high G)ᶜ := fun v hv => mem_compl.mpr (mem_sdiff.mp (mem_filter.mp hv).1).2
  obtain ⟨o,oe,ind,mass⟩ := LowSample.greedy G e (fun v => LowSample.weight (LowSample.anchors G v).card) (by
    intro v hv
    have deg := LowSample.two_degree G (mem_filter.mp hv).1
    have count := Repair.full_nbr G v (high G)
    have mono : nbr G v e ≤ nbr G v (high G)ᶜ := card_le_card (filter_subset_filter _ low)
    change nbr G v (high G) + nbr G v (high G)ᶜ = _ at count
    change (nbr G v e+1) * LowSample.weight (nbr G v (high G)) ≤ 6
    unfold LowSample.weight
    split_ifs <;> omega)

  have ar : a ⊆ s := sdiff_subset.trans sdiff_subset
  have ak : Disjoint a k := disjoint_left.mpr (fun _ va => (mem_sdiff.mp (mem_sdiff.mp va).1).2)
  have ao : Disjoint a o := disjoint_left.mpr (fun _ ha ho => mem_compl.mp (low (oe ho)) (mem_sdiff.mp (ar ha)).1)
  have ac : Disjoint a c := disjoint_left.mpr (fun _ ha hc => (mem_sdiff.mp (ar ha)).2 (cp hc))
  have oc : Disjoint o c := disjoint_left.mpr (fun _ ho hc => mem_compl.mp (low (oe ho)) (ph (cp hc)))
  let omitted := (a ∪ o) ∪ c
  have keep : k ⊆ omittedᶜ := by
    intro v vk
    apply mem_compl.mpr
    intro h
    rcases mem_union.mp h with h | vc
    · rcases mem_union.mp h with va | vo
      · exact disjoint_left.mp ak va vk
      · exact mem_compl.mp (low (oe vo)) (mem_sdiff.mp (ks vk)).1
    · exact (mem_sdiff.mp (ks vk)).2 (cp vc)
  have safe (v : V) (vo : v ∈ omitted) : 2 ≤ nbr G v omittedᶜ := by
    rcases mem_union.mp vo with base | vc
    · rcases mem_union.mp base with va | vl
      · by_cases hit : ∃ w ∈ c, G.Adj w v
        · obtain ⟨w,wc,wv⟩ := hit
          exact (protect w wc v wv (mem_sdiff.mp (sdiff_subset va)).2).trans
            (card_le_card (filter_subset_filter _ keep))
        · obtain ⟨vk,good⟩ := mem_sdiff.mp va
          have enough : 2 ≤ nbr G v (sᶜ ∪ k) := Nat.le_of_not_gt (fun lt => good (mem_filter.mpr ⟨vk,lt⟩))
          apply enough.trans (card_le_card ?_)
          intro y hy
          obtain ⟨yk,adj⟩ := mem_filter.mp hy
          refine mem_filter.mpr ⟨mem_compl.mpr ?_,adj⟩
          intro m
          rcases mem_union.mp m with m | yc
          · rcases mem_union.mp m with ya | yo
            · exact (mem_union.mp yk).elim (fun l => mem_compl.mp l (ar ya)) (fun yy => disjoint_left.mp ak ya yy)
            · have anchored := (mem_filter.mp (oe yo)).2
              exact (mem_sdiff.mp vk).2 (anchored (mem_filter.mpr ⟨(mem_sdiff.mp (ar va)).1,adj.symm⟩))
          · exact hit ⟨y,yc,adj.symm⟩
      · have deg := LowSample.two_degree G (mem_filter.mp (oe vl)).1
        have sub : G.neighborFinset v ⊆ omittedᶜ.filter (G.Adj v) := by
          intro w hw
          have adj := (G.mem_neighborFinset _ _).mp hw
          refine mem_filter.mpr ⟨mem_compl.mpr ?_,adj⟩
          intro m
          rcases mem_union.mp m with m | wc
          · rcases mem_union.mp m with wa | wo
            · exact disjoint_left.mp ak wa ((mem_filter.mp (oe vl)).2 (mem_filter.mpr ⟨(mem_sdiff.mp (ar wa)).1,adj⟩))
            · exact ind v vl w wo adj
          · have vs := neighbors w (cp wc) ((G.mem_neighborFinset _ _).mpr adj.symm)
            exact mem_compl.mp (low (oe vl)) vs
        simpa only [card_neighborFinset_eq_degree,deg,nbr] using card_le_card sub
    · exact (active v vc).trans (card_le_card (filter_subset_filter _ keep))
  have up := Repair.omit_set G _ safe
  have size : omitted.card = a.card + o.card + c.card := by
    rw [show omitted = (a ∪ o) ∪ c from rfl,card_union_of_disjoint (disjoint_union_left.mpr ⟨ac,oc⟩),card_union_of_disjoint ao]
  have part : a.card + (FiniteRange.bad G s k).card = s.card-k.card := by
    rw [← card_sdiff ks]; exact card_sdiff_add_card_eq_card (filter_subset _ _)
  rw [size] at up
  unfold bound at fail
  change 6*(s.card-k.card) + (∑ v ∈ e, LowSample.weight (LowSample.anchors G v).card)+6*c.card ≤ 6*(_+(FiniteRange.bad G s k).card)
  omega

theorem active_fiber (p s : Finset V) (b : ℕ) {v : V} (vp : v ∈ p)
    (ns : G.neighborFinset v ⊆ s) (nv : v ∉ s) :
    bonus s.card b (G.degree v) ≤ ((s.powersetCard b).filter (fun k => v ∈ active G p k)).card := by
  have opt : (s.powersetCard b).filter (fun k => v ∉ active G p k) ⊆
      ((insert v s).powersetCard b).filter (fun k => v ∈ FiniteRange.bad G (insert v s) k) := by
    intro k hk
    obtain ⟨ks,no⟩ := mem_filter.mp hk
    obtain ⟨sub,kb⟩ := mem_powersetCard.mp ks
    have lt : nbr G v k < 2 := Nat.lt_of_not_ge (fun n => no (mem_filter.mpr ⟨vp,n⟩))
    have eq : ((insert v s)ᶜ ∪ k).filter (G.Adj v) = k.filter (G.Adj v) := by
      ext y; simp only [mem_filter,mem_union]; constructor
      · rintro ⟨l | m,vy⟩
        · exact (mem_compl.mp l (mem_insert_of_mem (ns ((G.mem_neighborFinset _ _).mpr vy)))).elim
        · exact ⟨m,vy⟩
      · exact fun h => ⟨Or.inr h.1,h.2⟩
    exact mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub.trans (subset_insert _ _),kb⟩,
      mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_insert_self _ _,fun h => nv (sub h)⟩,by simpa only [nbr,eq] using lt⟩⟩
  have ds : G.degree v ≤ s.card := by simpa only [card_neighborFinset_eq_degree] using card_le_card ns
  have loss := (card_le_card opt).trans (FiniteRange.count_bad G (insert v s) b (G.degree v) v
    (mem_insert_self _ _) le_rfl (by rw [card_insert_of_not_mem nv]; omega))
  rw [card_insert_of_not_mem nv] at loss
  have split := filter_card_add_filter_neg_card_eq_card (s := s.powersetCard b) (fun k => v ∈ active G p k)
  rw [card_powersetCard] at split
  change s.card.choose b - FiniteRange.badCount (s.card+1) b (G.degree v) ≤ ((s.powersetCard b).filter (fun k => v ∈ active G p k)).card
  omega

end Graffiti384b.BlockTrial
#print axioms Graffiti384b.BlockTrial.trial
