import Endpoint384b
import BoundaryFiber384b

namespace Graffiti384b.Boundary
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.delta LowSample.weight LowSample.two_degree from LowSample384b
open private Repair.triangles_le_choose from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def levels : Finset ℕ := Icc 3 9
def screen (t : ℕ) := if t ≤ 35 then degrees else levels
def inputs : Finset ℕ := {33,35,37,39}
def batch (t e : ℕ) := if t ≤ 33 then 12 else if t ≤ 35 ∨ (t=37 ∧ e=2) then 13 else 14
def quota (t : ℕ) := if t=39 then 38 else 37
def saved (m b : ℕ) := 10*(m-12).choose (b-1)

private def Certificate (t e : ℕ) (f : Finset ℕ) : Prop :=
  let h := t-e
  let m := h-f.card
  let b := batch t e
  12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧
    (∀ d : Fin 12, 3 ≤ d.val → (m-d.val).choose b + saved m b ≤ FiniteRange.badCount m b d.val) ∧
    6*(((t+1)/2-1)*m.choose b + charge t h m b f (screen t)) <
    6*(m-b)*m.choose b + (quota t-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) + 6*saved m b

private def exceptional (t e : ℕ) (f : Finset ℕ) := t=37 ∧ e=2 ∧ f=∅

set_option Elab.async false
set_option maxRecDepth 32768
set_option maxHeartbeats 12000000

private def Row (t e : ℕ) := ∀ f ∈ (screen t).powerset, exceptional t e f ∨ Certificate t e f

local macro "verify_row" : tactic => `(tactic|
  (unfold Row exceptional Certificate charge LowSample.delta envelope FiniteRange.badCount reward LowSample.weight bonus slots saved
   simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
   decide))

private theorem row33_1 : Row 33 1 := by verify_row
private theorem row33_2 : Row 33 2 := by verify_row
private theorem row35_1 : Row 35 1 := by verify_row
private theorem row35_2 : Row 35 2 := by verify_row
private theorem row37_1 : Row 37 1 := by verify_row
private theorem row37_2 : Row 37 2 := by verify_row
private theorem row39_1 : Row 39 1 := by verify_row
private theorem row39_2 : Row 39 2 := by verify_row

private theorem table : ∀ t ∈ inputs, ∀ e ∈ ({1,2} : Finset ℕ), Row t e := by
  intro t ht e he
  simp only [inputs,mem_insert,mem_singleton] at ht he
  rcases ht with rfl | rfl | rfl | rfl <;> rcases he with rfl | rfl
  · exact row33_1
  · exact row33_2
  · exact row35_1
  · exact row35_2
  · exact row37_1
  · exact row37_2
  · exact row39_1
  · exact row39_2

private theorem select_reps [Nonempty V] (t : ℕ) : ∃ p, Choice G p (screen t) := by
  apply choose_from
  intro d hd
  unfold screen at hd
  split_ifs at hd
  · simp [degrees] at hd; omega
  · exact (mem_Icc.mp hd).1

theorem top_profile {p : Finset V} (hc : G.Connected) (bad : bound G < gamma G)
    (member : (types G).card ∈ inputs) (nonleavesLarge : quota (types G).card ≤ (nonleaves G).card)
    (ch : Choice G p (screen (types G).card)) :
    (types G).card = 37 ∧ (types G).card-(high G).card=2 ∧ p.image (fun v => G.degree v)=∅ := by
  let t := (types G).card
  let h := (high G).card
  let e := t-h
  let f := p.image (fun v => G.degree v)
  let s := high G \ p
  let m := h-f.card
  let b := batch t e
  have miss : (h+1)/2 < (t+1)/2 := Nat.lt_of_not_ge (fun le => (not_le_of_gt bad) (exact_of_high G le))
  have lim : t ≤ h+2 := type_bound G
  have off : e ∈ ({1,2} : Finset ℕ) := by simp only [mem_insert,mem_singleton]; dsimp [e]; omega
  have diff : t-e = h := by dsimp [e]; omega
  have sz : s.card = m := by dsimp only [m,h,f,s]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  obtain good | tab := table t member e off f (mem_powerset.mpr ch.levels)
  · exact good
  exfalso
  unfold Certificate at tab
  rw [diff] at tab
  change 12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧ _ at tab
  obtain ⟨room,two,env,rew,edgeBound,numeric⟩ := tab
  change ∀ d : Fin 12, 3 ≤ d.val → (m-d.val).choose b + saved m b ≤ FiniteRange.badCount m b d.val at edgeBound
  change 6*(((t+1)/2-1)*m.choose b + charge t h m b f (screen t)) <
    6*(m-b)*m.choose b + (quota t-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) + 6*saved m b at numeric
  change quota t ≤ (nonleaves G).card at nonleavesLarge
  have notall : ∃ y, y ∉ s := by
    by_contra! all
    have eq : s = univ := eq_univ_of_forall all
    have sub : s ⊆ high G := sdiff_subset
    have card := card_le_card sub
    rw [eq,card_univ] at card
    change Fintype.card V ≤ h at card
    have cap : t ≤ Fintype.card V := (card_image_le (s := (univ : Finset V)) (f := trianglesAt G)).trans_eq card_univ
    omega
  obtain ⟨v,vs,w,ws,edge⟩ := BoundaryFiber.crossing G hc (card_pos.mp (show 0 < s.card by omega)) notall
  let extra (z : V) := if v=z then saved m b else 0
  have refund (z : V) (zs : z ∈ s) :
      ((s.powersetCard b).filter (fun k => z ∈ FiniteRange.bad G s k)).card + extra z ≤
        FiniteRange.badCount s.card b (min (G.degree z) 11) := by
    have raw := FiniteRange.count_bad G s b (min (G.degree z) 11) z zs (min_le_left _ _) (by omega)
    by_cases eq : v=z
    · subst z
      have highDeg := (mem_filter.mp (mem_sdiff.mp vs).1).2
      let d := min (G.degree v) 11
      have range : 3 ≤ d ∧ d < 12 := by dsimp [d]; omega
      have support := BoundaryFiber.count G s b d vs ws edge (min_le_left _ _) (by omega)
      have cost := edgeBound ⟨d,range.2⟩ range.1
      simp only [extra,if_pos rfl]
      rw [sz] at support ⊢
      exact (Nat.add_le_add_right support (saved m b)).trans cost
    · simpa only [extra,if_neg eq,Nat.add_zero] using raw
  have obs := extraObstruction G ch b extra refund two (sz ▸ env) (sz ▸ rew) bad
  have sumExtra : (∑ z ∈ s, extra z) = saved m b := by simp [extra,vs]
  change 6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) +
    6*(∑ z ∈ s, extra z) ≤ 6*(((t+1)/2-1)*m.choose b + charge t h m b f (screen t)) at obs
  rw [sumExtra] at obs
  have sub : high G ⊆ nonleaves G := by
    intro z hz
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hz).2; omega⟩
  have count : (twos G).card+h = (nonleaves G).card := card_sdiff_add_card_eq_card sub
  have low := Nat.mul_le_mul_right (6*(m-2).choose (b-2)) (show quota t-h ≤ (twos G).card by omega)
  omega

theorem exact_of_39_types (hc : G.Connected) (hn : 2 < Fintype.card V) (t39 : (types G).card = 39) :
    gamma G ≤ bound G := by
  by_contra! fail
  letI : Nonempty V := hc.nonempty
  obtain ⟨r,_,qcap,_,_,same,_⟩ := Prune.prune_failure G hc hn fail
  have rank : (types (G.induce (r : Set V))).card ≤ r.card := by
    simpa [types] using (card_image_le (s := (univ : Finset r)) (f := trianglesAt (G.induce (r : Set V))))
  rw [same,t39] at rank
  obtain ⟨p,ch⟩ := select_reps G (types G).card
  have bad := top_profile G hc fail (by simp [inputs,t39]) (by rw [t39]; change 38 ≤ _; omega) ch
  omega

/-- A failure preserves every type on a connected induced failure on at
most 38 vertices, and the original graph has at most 37 types. -/
theorem bounded_failure (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ r.card ≤ 38 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V)) = types G ∧ 7 ≤ (types G).card ∧ (types G).card ≤ 37 ∧
      bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨_,_,_,_,_,lo,hi,no38,_⟩ := Endpoint.bounded_failure G hc hn bad
  have no39 : (types G).card ≠ 39 := fun h => (not_le_of_gt bad) (exact_of_39_types G hc hn h)
  obtain ⟨r,_,cap,ord,conn,same,fails⟩ := Prune.prune_failure G hc hn bad
  have top : (types G).card ≤ 37 := by omega
  refine ⟨r,ord,?_,conn,same,lo,top,fails⟩
  suffices small : (nonleaves G).card ≤ 37 by omega
  by_cases pair : (types G).card = 35 ∨ (types G).card = 37
  · letI : Nonempty V := hc.nonempty
    obtain ⟨p,ch⟩ := choose_vertices G
    have mem : (types G).card ∈ Endpoint.targets := by rcases pair with e | e <;> simp [Endpoint.targets,e]
    have bound := Endpoint.profiled G ch bad mem
    rw [Endpoint.cutoff,if_pos (Or.inl top)] at bound
    omega
  · by_cases many : 14 ≤ (types G).card
    · have q := (nonleaf_profile G bad many (by omega)).1
      have rows : ∀ t : Fin 38, ∀ e : Fin 3, t.val ≠ 35 → t.val ≠ 37 → (row t e).1 ≤ 37 := by decide
      have lim := type_bound G
      exact q.trans (rows ⟨(types G).card,by omega⟩ ⟨(types G).card-(high G).card,by omega⟩ (by dsimp; omega) (by dsimp; omega))
    · have q := nonleaf_bound G
      unfold bound at bad
      omega

theorem exact_of_at_least_thirty_eight (hc : G.Connected) (hn : 2 < Fintype.card V)
    (ht : 38 ≤ (types G).card) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨_,_,_,_,_,_,hi,_⟩ := bounded_failure G hc hn fail
  omega

/-- At order 38 a normalized minimum has two score-one ears, a single
leaf, 35 high vertices with distinct scores, and no saturated degree 3–9. -/
theorem minimum_profile (res : Minimal.Residual G) (n38 : Fintype.card V = 38) :
    (types G).card = 37 ∧ (high G).card = 35 ∧ (nonleaves G).card = 37 ∧ (twos G).card = 2 ∧
      Set.InjOn (trianglesAt G) (high G) ∧
      (∀ v, trianglesAt G v = 1 ↔ v ∈ twos G) ∧
      (∀ v ∈ twos G, ∃ a b, G.Adj a b ∧ G.neighborFinset v = {a,b}) ∧
      (∀ v, G.degree v ∈ levels → trianglesAt G v < (G.degree v).choose 2) := by
  obtain ⟨⟨hn,_⟩,hc,bad,normal,odd,_,_,_,least⟩ := res
  obtain ⟨_,_,_,_,_,_,top,_⟩ := bounded_failure G hc hn bad
  obtain ⟨r,_,qcap,ord,conn,_,fail⟩ := Prune.prune_failure G hc hn bad
  have ncap := least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord,conn,fail⟩
  have big : 37 ≤ (nonleaves G).card := by omega
  have lo : 14 ≤ (types G).card := by
    have old := nonleaf_bound G
    unfold bound at bad
    omega
  have q := (nonleaf_profile G bad lo (by omega)).1
  have lim := type_bound G
  have small : ∀ t : Fin 33, ∀ e : Fin 3, (row t e).1 ≤ 36 := by decide
  have lower : 33 ≤ (types G).card := by
    by_contra! lt
    have cap := small ⟨(types G).card,lt⟩ ⟨(types G).card-(high G).card,by omega⟩
    change (row (types G).card ((types G).card-(high G).card)).1 ≤ 36 at cap
    omega
  have target : (types G).card ∈ inputs := by simp only [inputs,mem_insert,mem_singleton]; omega
  letI : Nonempty V := hc.nonempty
  obtain ⟨p,ch⟩ := select_reps G (types G).card
  obtain ⟨t37,offset,empty⟩ := top_profile G hc bad target (by
    unfold quota; rw [if_neg (by omega)]; exact big) ch
  have h35 : (high G).card=35 := by omega
  obtain ⟨inj,highScore,zero,_⟩ := Repair.maximal_diversity G (by omega)
  obtain ⟨z,_,score0⟩ := mem_image.mp zero
  have zeroDeg (u : V) (h : trianglesAt G u=0) : G.degree u ≤ 1 := by
    rw [← card_neighborFinset_eq_degree]
    exact card_le_one.mpr (fun a ha b hb => normal.2.1 u h a b ((G.mem_neighborFinset _ _).mp ha) ((G.mem_neighborFinset _ _).mp hb))
  have zlow : z ∉ nonleaves G := fun m => (by have := (mem_filter.mp m).2; have := zeroDeg z score0; omega)
  have smallQ : (nonleaves G).card < Fintype.card V := by
    rw [← card_univ]
    have proper : nonleaves G ≠ univ := fun eq => zlow (by rw [eq]; exact mem_univ z)
    exact card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨subset_univ _,proper⟩)
  have q37 : (nonleaves G).card = 37 := by omega
  have sub : high G ⊆ nonleaves G := by
    intro v hv
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have size : (twos G).card+(high G).card = (nonleaves G).card := card_sdiff_add_card_eq_card sub
  have one (v : V) : trianglesAt G v = 1 ↔ v ∈ twos G := by
    have cap := Repair.triangles_le_choose G v
    constructor
    · intro sc
      refine mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,?_⟩,fun h => (by have := highScore v h; omega)⟩
      apply Nat.le_of_not_gt
      intro low
      have le : G.degree v ≤ 1 := Nat.le_of_lt_succ low
      have up := cap.trans (Nat.choose_le_choose 2 le)
      rw [sc,show Nat.choose 1 2 = 0 by decide] at up
      exact Nat.not_succ_le_zero _ up
    · intro hv
      have d := LowSample.two_degree G hv
      rw [d,Nat.choose_self] at cap
      apply Nat.le_antisymm cap
      apply Nat.pos_of_ne_zero
      intro hv0
      have hv1 := zeroDeg v hv0
      rw [d] at hv1
      exact (by decide : ¬2 ≤ 1) hv1
  refine ⟨t37,h35,q37,by omega,inj,one,?_,?_⟩
  · intro v hv
    have sc := (one v).mpr hv
    obtain ⟨a,b,va,vb,ab⟩ := (TrianglePrune.triangle_iff G v).mp (by omega)
    have inc : ({a,b} : Finset V) ⊆ G.neighborFinset v := insert_subset
      ((G.mem_neighborFinset _ _).mpr va) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vb))
    exact ⟨a,b,ab,(eq_of_subset_of_card_le inc (by rw [card_pair ab.ne,card_neighborFinset_eq_degree,LowSample.two_degree G hv])).symm⟩
  · intro v level
    have cap := Repair.triangles_le_choose G v
    apply Nat.lt_of_le_of_ne cap
    intro sat
    have tested : G.degree v ∈ screen (types G).card := by simpa [screen,t37] using level
    have mem := ch.covers v tested sat
    rw [empty] at mem
    exact Finset.not_mem_empty _ mem

end Graffiti384b.Boundary
#print axioms Graffiti384b.Boundary.exact_of_39_types
#print axioms Graffiti384b.Boundary.bounded_failure
#print axioms Graffiti384b.Boundary.exact_of_at_least_thirty_eight

#print axioms Graffiti384b.Boundary.minimum_profile


namespace Graffiti384b.Boundary
open Finset SimpleGraph LowSample EarProfile
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

theorem nonadjacent_ears (res : Minimal.Residual G) (n38 : Fintype.card V = 38)
    {x y : V} (sx : trianglesAt G x=1) (sy : trianglesAt G y=1) (ne : x ≠ y) (sep : ¬G.Adj x y) :
    G.neighborFinset x ≠ G.neighborFinset y ∧ ∃ a b, G.Adj a b ∧ G.neighborFinset x = {a,b} ∧
      ((endpoints G a b) ∩ outside G x a b).card < ((lowered G a b) ∩ outside G x a b).card := by
  obtain ⟨_,_,_,_,_,one,ears,_⟩ := minimum_profile G res n38
  have dx := LowSample.two_degree G ((one x).mp sx)
  refine ⟨fun eq => (not_le_of_gt res.2.2.1) (Repair.exact_of_twin_degree_two G ne dx eq),?_⟩
  obtain ⟨a,b,ab,nx⟩ := ears x ((one x).mp sx)
  refine ⟨a,b,ab,nx,repeated_one G res sx ab nx (mem_image.mpr ⟨y,mem_compl.mpr ?_,sy⟩)⟩
  intro mem
  rcases mem_insert.mp mem with same | neighbor
  · exact ne same.symm
  · exact sep ((G.mem_neighborFinset _ _).mp (nx ▸ neighbor))

end Graffiti384b.Boundary
#print axioms Graffiti384b.Boundary.nonadjacent_ears
