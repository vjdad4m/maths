import Minimal384b

namespace Graffiti384b.BoundaryFiber
open Finset SimpleGraph
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A fixed neighbor outside the sample pool leaves a deficient vertex with
no neighbor in the retained sample. -/
theorem count (s : Finset V) (b d : ℕ) {v w : V} (vs : v ∈ s) (ws : w ∉ s)
    (vw : G.Adj v w) (enough : d ≤ G.degree v) (pos : 1 ≤ d) :
    ((s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)).card ≤ (s.card-d).choose b := by
  let opts := (s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)
  by_cases any : opts.Nonempty
  · have only (k : Finset V) (hk : k ∈ opts) {u : V} (edge : G.Adj v u) (mem : u ∈ sᶜ ∪ k) : u = w := by
      have short := (mem_filter.mp (mem_filter.mp hk).2).2
      change ((sᶜ ∪ k).filter (G.Adj v)).card < 2 at short
      exact (card_le_one.mp (by omega : ((sᶜ ∪ k).filter (G.Adj v)).card ≤ 1))
        u (mem_filter.mpr ⟨mem,edge⟩) w (mem_filter.mpr ⟨mem_union_left _ (mem_compl.mpr ws),vw⟩)
    let adj := (G.neighborFinset v).erase w
    have wv := (G.mem_neighborFinset _ _).mpr vw
    have adjs : adj ⊆ s.erase v := by
      intro u hu
      obtain ⟨ne,mem⟩ := mem_erase.mp hu
      refine mem_erase.mpr ⟨fun eq => G.not_mem_neighborFinset_self _ (eq ▸ mem),?_⟩
      by_contra no
      obtain ⟨k,hk⟩ := any
      exact ne (only k hk ((G.mem_neighborFinset _ _).mp mem) (mem_union_left _ (mem_compl.mpr no)))
    have adjCard : adj.card = G.degree v - 1 := by rw [show adj = _ from rfl,card_erase_of_mem wv,card_neighborFinset_eq_degree]
    obtain ⟨a,sub,sz⟩ := exists_subset_card_eq (show d-1 ≤ adj.card by omega)
    have as := sub.trans adjs
    have inc : opts ⊆ ((s.erase v) \ a).powersetCard b := by
      intro k hk
      obtain ⟨ks,kb⟩ := mem_powersetCard.mp (mem_filter.mp hk).1
      have vk := (mem_sdiff.mp (mem_filter.mp (mem_filter.mp hk).2).1).2
      apply mem_powersetCard.mpr ⟨?_,kb⟩
      intro u uk
      refine mem_sdiff.mpr ⟨mem_erase.mpr ⟨fun eq => vk (eq ▸ uk),ks uk⟩,?_⟩
      intro ua
      obtain ⟨ne,mem⟩ := mem_erase.mp (sub ua)
      exact ne (only k hk ((G.mem_neighborFinset _ _).mp mem) (mem_union_right _ uk))
    have cap := card_le_card inc
    rw [card_powersetCard,card_sdiff as,card_erase_of_mem vs,sz,show s.card-1-(d-1) = s.card-d by omega] at cap
    exact cap
  · change opts.card ≤ _
    rw [not_nonempty_iff_eq_empty.mp any,card_empty]
    exact Nat.zero_le _

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem crossing (hc : G.Connected) {s : Finset V} (inside : s.Nonempty) (outside : ∃ w, w ∉ s) :
    ∃ v ∈ s, ∃ w ∉ s, G.Adj v w := by
  by_contra! none
  obtain ⟨v,vs⟩ := inside
  obtain ⟨w,ws⟩ := outside
  apply ws
  clear ws
  have walk := (G.reachable_iff_reflTransGen v w).mp (hc v w)
  induction walk with
  | refl => exact vs
  | tail _ edge ih => exact Classical.byContradiction (fun out => none _ ih _ out edge)

end Graffiti384b.BoundaryFiber
#print axioms Graffiti384b.BoundaryFiber.count
#print axioms Graffiti384b.BoundaryFiber.crossing
