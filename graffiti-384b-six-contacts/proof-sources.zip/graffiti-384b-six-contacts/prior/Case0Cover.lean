import Case0Pack0
import Case0Pack1
import Case0Pack2
import Case0Pack3
import Case0Pack4
import Case0Pack5
import Case0Pack6
import Case0Pack7
namespace Graffiti384b.PairMix.Local
def full0 : Tree := (.branch 0 (.branch 1 (.branch 3 tree0_7 tree0_3) (.branch 3 tree0_5 tree0_1)) (.branch 1 (.branch 3 tree0_6 tree0_2) (.branch 3 tree0_4 tree0_0)))
theorem tested0 : check 0 0 0 full0=true := by
  change ((((check 0 11 0 tree0_7) && (check 0 3 8 tree0_3)) && ((check 0 9 2 tree0_5) && (check 0 1 10 tree0_1))) && (((check 0 10 1 tree0_6) && (check 0 2 9 tree0_2)) && ((check 0 8 3 tree0_4) && (check 0 0 11 tree0_0))))=true
  simp only [tested0_0,tested0_1,tested0_2,tested0_3,tested0_4,tested0_5,tested0_6,tested0_7,Bool.true_and]
end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0
