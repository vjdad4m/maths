import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] def tree0_0 : Tree :=
  (.small 0)
theorem tested0_0 : check 0 0 11 tree0_0=true := by unfold tree0_0; decide

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_0
