import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] private def subtree0_1_6 : Tree :=
  (.branch 4 (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.small 0))))) (.branch 9 (.branch 14 (.cut 1043 556) (.branch 19 (.cut 1043 588) (.branch 25 (.cut 1043 652) (.branch 32 (.cut 1043 780) (.small 0))))) (.branch 13 (.branch 14 (.cut 1059 540) (.branch 20 (.cut 1059 588) (.branch 26 (.cut 1059 652) (.branch 33 (.cut 1059 780) (.small 0))))) (.branch 18 (.branch 19 (.cut 1091 540) (.branch 20 (.cut 1091 556) (.branch 27 (.cut 1091 652) (.branch 34 (.cut 1091 780) (.small 0))))) (.branch 24 (.branch 25 (.cut 1155 540) (.branch 26 (.cut 1155 556) (.branch 27 (.cut 1155 588) (.branch 35 (.cut 1155 780) (.small 0))))) (.branch 31 (.branch 32 (.cut 1283 540) (.branch 33 (.cut 1283 556) (.branch 34 (.cut 1283 588) (.branch 35 (.cut 1283 652) (.small 0))))) (.small 3)))))))
private theorem checked0_1_6 : check 0 270566469 10 subtree0_1_6=true := by unfold subtree0_1_6; decide

@[irreducible] private def subtree0_1_8 : Tree :=
  (.branch 8 (.branch 9 (.cut 15 1552) (.branch 13 (.cut 15 1584) (.branch 18 (.cut 15 1616) (.branch 24 (.cut 15 1680) (.branch 31 (.cut 15 1808) (.small 3)))))) (.branch 12 (.branch 9 (.cut 15 1584) (.branch 13 (.cut 1059 540) (.branch 18 (.cut 15 1648) (.branch 24 (.cut 15 1712) (.branch 31 (.cut 15 1840) (.small 3)))))) (.branch 17 (.branch 9 (.cut 15 1616) (.branch 18 (.cut 1091 540) (.branch 13 (.cut 15 1648) (.branch 24 (.cut 15 1744) (.branch 31 (.cut 15 1872) (.small 3)))))) (.branch 23 (.branch 9 (.cut 15 1680) (.branch 24 (.cut 1155 540) (.branch 13 (.cut 15 1712) (.branch 18 (.cut 15 1744) (.branch 31 (.cut 15 1936) (.small 3)))))) (.branch 30 (.branch 9 (.cut 15 1808) (.branch 31 (.cut 1283 540) (.small 2))) (.small 2))))))
private theorem checked0_1_8 : check 0 270566593 14 subtree0_1_8=true := by unfold subtree0_1_8; decide

@[irreducible] private def subtree0_1_10 : Tree :=
  (.branch 12 (.branch 13 (.cut 15 1568) (.branch 9 (.cut 15 1584) (.branch 18 (.cut 15 1632) (.branch 24 (.cut 15 1696) (.branch 31 (.cut 15 1824) (.small 3)))))) (.branch 8 (.branch 9 (.cut 1043 556) (.branch 13 (.cut 15 1584) (.branch 18 (.cut 15 1648) (.branch 24 (.cut 15 1712) (.branch 31 (.cut 15 1840) (.small 3)))))) (.branch 17 (.branch 13 (.cut 15 1632) (.branch 18 (.cut 1091 556) (.branch 9 (.cut 15 1648) (.branch 24 (.cut 15 1760) (.branch 31 (.cut 15 1888) (.small 3)))))) (.branch 23 (.branch 13 (.cut 15 1696) (.branch 24 (.cut 1155 556) (.branch 9 (.cut 15 1712) (.branch 18 (.cut 15 1760) (.branch 31 (.cut 15 1952) (.small 3)))))) (.branch 30 (.branch 13 (.cut 15 1824) (.branch 31 (.cut 1283 556) (.small 2))) (.small 2))))))
private theorem checked0_1_10 : check 0 270568513 142 subtree0_1_10=true := by unfold subtree0_1_10; decide

@[irreducible] private def subtree0_1_12 : Tree :=
  (.branch 17 (.branch 18 (.cut 15 1600) (.branch 9 (.cut 15 1616) (.branch 13 (.cut 15 1632) (.branch 24 (.cut 15 1728) (.branch 31 (.cut 15 1856) (.small 3)))))) (.branch 8 (.branch 9 (.cut 1043 588) (.branch 18 (.cut 15 1616) (.branch 13 (.cut 15 1648) (.branch 24 (.cut 15 1744) (.branch 31 (.cut 15 1872) (.small 3)))))) (.branch 12 (.branch 13 (.cut 1059 588) (.branch 18 (.cut 15 1632) (.branch 9 (.cut 15 1648) (.branch 24 (.cut 15 1760) (.branch 31 (.cut 15 1888) (.small 3)))))) (.branch 23 (.branch 18 (.cut 15 1728) (.branch 24 (.cut 1155 588) (.branch 9 (.cut 15 1744) (.branch 13 (.cut 15 1760) (.branch 31 (.cut 15 1984) (.small 3)))))) (.branch 30 (.branch 18 (.cut 15 1856) (.branch 31 (.cut 1283 588) (.small 2))) (.small 2))))))
private theorem checked0_1_12 : check 0 270632001 2190 subtree0_1_12=true := by unfold subtree0_1_12; decide

@[irreducible] private def subtree0_1_13 : Tree :=
  (.branch 22 (.branch 23 (.branch 24 (.cut 15 1664) (.branch 9 (.cut 15 1680) (.branch 13 (.cut 15 1696) (.branch 18 (.cut 15 1728) (.branch 31 (.cut 15 1920) (.small 3)))))) (.branch 8 (.branch 9 (.cut 1043 652) (.branch 24 (.cut 15 1680) (.branch 13 (.cut 15 1712) (.branch 18 (.cut 15 1744) (.branch 31 (.cut 15 1936) (.small 3)))))) (.branch 12 (.branch 13 (.cut 1059 652) (.branch 24 (.cut 15 1696) (.branch 9 (.cut 15 1712) (.branch 18 (.cut 15 1760) (.branch 31 (.cut 15 1952) (.small 3)))))) (.branch 17 (.branch 18 (.cut 1091 652) (.branch 24 (.cut 15 1728) (.branch 9 (.cut 15 1744) (.branch 13 (.cut 15 1760) (.branch 31 (.cut 15 1984) (.small 3)))))) (.branch 30 (.branch 24 (.cut 15 1920) (.branch 31 (.cut 1283 652) (.small 2))) (.small 2)))))) (.small 0))
private theorem checked0_1_13 : check 0 270566465 67726 subtree0_1_13=true := by unfold subtree0_1_13; decide

@[irreducible] private def subtree0_1_11 : Tree :=
  .branch 16 subtree0_1_12 subtree0_1_13
private theorem checked0_1_11 : check 0 270566465 2190 subtree0_1_11=true := by
  unfold subtree0_1_11
  change (check 0 270632001 2190 subtree0_1_12 && check 0 270566465 67726 subtree0_1_13)=true
  simp only [checked0_1_12,checked0_1_13,Bool.true_and]

@[irreducible] private def subtree0_1_9 : Tree :=
  .branch 11 subtree0_1_10 subtree0_1_11
private theorem checked0_1_9 : check 0 270566465 142 subtree0_1_9=true := by
  unfold subtree0_1_9
  change (check 0 270568513 142 subtree0_1_10 && check 0 270566465 2190 subtree0_1_11)=true
  simp only [checked0_1_10,checked0_1_11,Bool.true_and]

@[irreducible] private def subtree0_1_7 : Tree :=
  .branch 7 subtree0_1_8 subtree0_1_9
private theorem checked0_1_7 : check 0 270566465 14 subtree0_1_7=true := by
  unfold subtree0_1_7
  change (check 0 270566593 14 subtree0_1_8 && check 0 270566465 142 subtree0_1_9)=true
  simp only [checked0_1_8,checked0_1_9,Bool.true_and]

@[irreducible] private def subtree0_1_5 : Tree :=
  .branch 2 subtree0_1_6 subtree0_1_7
private theorem checked0_1_5 : check 0 270566465 10 subtree0_1_5=true := by
  unfold subtree0_1_5
  change (check 0 270566469 10 subtree0_1_6 && check 0 270566465 14 subtree0_1_7)=true
  simp only [checked0_1_6,checked0_1_7,Bool.true_and]

@[irreducible] private def subtree0_1_14 : Tree :=
  (.small 0)
private theorem checked0_1_14 : check 0 2131009 268435466 subtree0_1_14=true := by unfold subtree0_1_14; decide

@[irreducible] private def subtree0_1_4 : Tree :=
  .branch 28 subtree0_1_5 subtree0_1_14
private theorem checked0_1_4 : check 0 2131009 10 subtree0_1_4=true := by
  unfold subtree0_1_4
  change (check 0 270566465 10 subtree0_1_5 && check 0 2131009 268435466 subtree0_1_14)=true
  simp only [checked0_1_5,checked0_1_14,Bool.true_and]

@[irreducible] private def subtree0_1_15 : Tree :=
  (.small 0)
private theorem checked0_1_15 : check 0 33857 2097162 subtree0_1_15=true := by unfold subtree0_1_15; decide

@[irreducible] private def subtree0_1_3 : Tree :=
  .branch 21 subtree0_1_4 subtree0_1_15
private theorem checked0_1_3 : check 0 33857 10 subtree0_1_3=true := by
  unfold subtree0_1_3
  change (check 0 2131009 10 subtree0_1_4 && check 0 33857 2097162 subtree0_1_15)=true
  simp only [checked0_1_4,checked0_1_15,Bool.true_and]

@[irreducible] private def subtree0_1_16 : Tree :=
  (.small 0)
private theorem checked0_1_16 : check 0 1089 32778 subtree0_1_16=true := by unfold subtree0_1_16; decide

@[irreducible] private def subtree0_1_2 : Tree :=
  .branch 15 subtree0_1_3 subtree0_1_16
private theorem checked0_1_2 : check 0 1089 10 subtree0_1_2=true := by
  unfold subtree0_1_2
  change (check 0 33857 10 subtree0_1_3 && check 0 1089 32778 subtree0_1_16)=true
  simp only [checked0_1_3,checked0_1_16,Bool.true_and]

@[irreducible] private def subtree0_1_17 : Tree :=
  (.small 0)
private theorem checked0_1_17 : check 0 65 1034 subtree0_1_17=true := by unfold subtree0_1_17; decide

@[irreducible] private def subtree0_1_1 : Tree :=
  .branch 10 subtree0_1_2 subtree0_1_17
private theorem checked0_1_1 : check 0 65 10 subtree0_1_1=true := by
  unfold subtree0_1_1
  change (check 0 1089 10 subtree0_1_2 && check 0 65 1034 subtree0_1_17)=true
  simp only [checked0_1_2,checked0_1_17,Bool.true_and]

@[irreducible] private def subtree0_1_18 : Tree :=
  (.small 0)
private theorem checked0_1_18 : check 0 1 74 subtree0_1_18=true := by unfold subtree0_1_18; decide

@[irreducible] def tree0_1 : Tree :=
  .branch 6 subtree0_1_1 subtree0_1_18
theorem tested0_1 : check 0 1 10 tree0_1=true := by
  unfold tree0_1
  change (check 0 65 10 subtree0_1_1 && check 0 1 74 subtree0_1_18)=true
  simp only [checked0_1_1,checked0_1_18,Bool.true_and]

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_1
