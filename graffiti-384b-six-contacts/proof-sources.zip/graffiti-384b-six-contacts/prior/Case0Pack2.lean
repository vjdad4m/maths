import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] private def subtree0_2_6 : Tree :=
  (.cut 1027 524)
private theorem checked0_2_6 : check 0 270566482 9 subtree0_2_6=true := by unfold subtree0_2_6; decide

@[irreducible] private def subtree0_2_8 : Tree :=
  (.branch 8 (.branch 2 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.small 1))))) (.branch 11 (.branch 12 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.small 0))) (.branch 16 (.branch 17 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1808) (.small 1)) (.small 1))))))
private theorem checked0_2_8 : check 0 270566978 25 subtree0_2_8=true := by unfold subtree0_2_8; decide

@[irreducible] private def subtree0_2_10 : Tree :=
  (.branch 12 (.branch 2 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.small 1))))) (.branch 7 (.branch 8 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.small 0))) (.branch 16 (.branch 17 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1824) (.small 1)) (.small 1))))))
private theorem checked0_2_10 : check 0 270574658 537 subtree0_2_10=true := by unfold subtree0_2_10; decide

@[irreducible] private def subtree0_2_12 : Tree :=
  (.branch 17 (.branch 2 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.small 1))))) (.branch 7 (.branch 8 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.small 0))) (.branch 11 (.branch 12 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1856) (.small 1)) (.small 1))))))
private theorem checked0_2_12 : check 0 270828610 8729 subtree0_2_12=true := by unfold subtree0_2_12; decide

@[irreducible] private def subtree0_2_13 : Tree :=
  (.branch 24 (.branch 23 (.branch 2 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.small 1))))) (.branch 7 (.branch 8 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.small 0))) (.branch 11 (.branch 12 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.small 0))) (.branch 16 (.branch 17 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1920) (.small 1)) (.small 1)))))) (.branch 31 (.branch 30 (.branch 2 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.small 1))))) (.small 3)) (.small 3)))
private theorem checked0_2_13 : check 0 270566466 270873 subtree0_2_13=true := by unfold subtree0_2_13; decide

@[irreducible] private def subtree0_2_11 : Tree :=
  .branch 18 subtree0_2_12 subtree0_2_13
private theorem checked0_2_11 : check 0 270566466 8729 subtree0_2_11=true := by
  unfold subtree0_2_11
  change (check 0 270828610 8729 subtree0_2_12 && check 0 270566466 270873 subtree0_2_13)=true
  simp only [checked0_2_12,checked0_2_13,Bool.true_and]

@[irreducible] private def subtree0_2_9 : Tree :=
  .branch 13 subtree0_2_10 subtree0_2_11
private theorem checked0_2_9 : check 0 270566466 537 subtree0_2_9=true := by
  unfold subtree0_2_9
  change (check 0 270574658 537 subtree0_2_10 && check 0 270566466 8729 subtree0_2_11)=true
  simp only [checked0_2_10,checked0_2_11,Bool.true_and]

@[irreducible] private def subtree0_2_7 : Tree :=
  .branch 9 subtree0_2_8 subtree0_2_9
private theorem checked0_2_7 : check 0 270566466 25 subtree0_2_7=true := by
  unfold subtree0_2_7
  change (check 0 270566978 25 subtree0_2_8 && check 0 270566466 537 subtree0_2_9)=true
  simp only [checked0_2_8,checked0_2_9,Bool.true_and]

@[irreducible] private def subtree0_2_5 : Tree :=
  .branch 4 subtree0_2_6 subtree0_2_7
private theorem checked0_2_5 : check 0 270566466 9 subtree0_2_5=true := by
  unfold subtree0_2_5
  change (check 0 270566482 9 subtree0_2_6 && check 0 270566466 25 subtree0_2_7)=true
  simp only [checked0_2_6,checked0_2_7,Bool.true_and]

@[irreducible] private def subtree0_2_14 : Tree :=
  (.small 0)
private theorem checked0_2_14 : check 0 2131010 268435465 subtree0_2_14=true := by unfold subtree0_2_14; decide

@[irreducible] private def subtree0_2_4 : Tree :=
  .branch 28 subtree0_2_5 subtree0_2_14
private theorem checked0_2_4 : check 0 2131010 9 subtree0_2_4=true := by
  unfold subtree0_2_4
  change (check 0 270566466 9 subtree0_2_5 && check 0 2131010 268435465 subtree0_2_14)=true
  simp only [checked0_2_5,checked0_2_14,Bool.true_and]

@[irreducible] private def subtree0_2_15 : Tree :=
  (.small 0)
private theorem checked0_2_15 : check 0 33858 2097161 subtree0_2_15=true := by unfold subtree0_2_15; decide

@[irreducible] private def subtree0_2_3 : Tree :=
  .branch 21 subtree0_2_4 subtree0_2_15
private theorem checked0_2_3 : check 0 33858 9 subtree0_2_3=true := by
  unfold subtree0_2_3
  change (check 0 2131010 9 subtree0_2_4 && check 0 33858 2097161 subtree0_2_15)=true
  simp only [checked0_2_4,checked0_2_15,Bool.true_and]

@[irreducible] private def subtree0_2_16 : Tree :=
  (.small 0)
private theorem checked0_2_16 : check 0 1090 32777 subtree0_2_16=true := by unfold subtree0_2_16; decide

@[irreducible] private def subtree0_2_2 : Tree :=
  .branch 15 subtree0_2_3 subtree0_2_16
private theorem checked0_2_2 : check 0 1090 9 subtree0_2_2=true := by
  unfold subtree0_2_2
  change (check 0 33858 9 subtree0_2_3 && check 0 1090 32777 subtree0_2_16)=true
  simp only [checked0_2_3,checked0_2_16,Bool.true_and]

@[irreducible] private def subtree0_2_17 : Tree :=
  (.small 0)
private theorem checked0_2_17 : check 0 66 1033 subtree0_2_17=true := by unfold subtree0_2_17; decide

@[irreducible] private def subtree0_2_1 : Tree :=
  .branch 10 subtree0_2_2 subtree0_2_17
private theorem checked0_2_1 : check 0 66 9 subtree0_2_1=true := by
  unfold subtree0_2_1
  change (check 0 1090 9 subtree0_2_2 && check 0 66 1033 subtree0_2_17)=true
  simp only [checked0_2_2,checked0_2_17,Bool.true_and]

@[irreducible] private def subtree0_2_18 : Tree :=
  (.small 0)
private theorem checked0_2_18 : check 0 2 73 subtree0_2_18=true := by unfold subtree0_2_18; decide

@[irreducible] def tree0_2 : Tree :=
  .branch 6 subtree0_2_1 subtree0_2_18
theorem tested0_2 : check 0 2 9 tree0_2=true := by
  unfold tree0_2
  change (check 0 66 9 subtree0_2_1 && check 0 2 73 subtree0_2_18)=true
  simp only [checked0_2_1,checked0_2_18,Bool.true_and]

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_2
