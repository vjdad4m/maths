import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] private def subtree0_3_6 : Tree :=
  (.cut 1027 524)
private theorem checked0_3_6 : check 0 270566483 8 subtree0_3_6=true := by unfold subtree0_3_6; decide

@[irreducible] private def subtree0_3_9 : Tree :=
  (.branch 2 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.branch 22 (.cut 1043 652) (.branch 29 (.cut 1043 780) (.small 1)))))))
private theorem checked0_3_9 : check 0 270567235 24 subtree0_3_9=true := by unfold subtree0_3_9; decide

@[irreducible] private def subtree0_3_11 : Tree :=
  (.branch 12 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 17 (.cut 15 1648) (.branch 19 (.cut 1043 620) (.branch 23 (.cut 15 1712) (.branch 25 (.cut 1043 684) (.branch 30 (.cut 15 1840) (.branch 32 (.cut 1043 812) (.branch 18 (.branch 20 (.cut 1091 556) (.small 0)) (.branch 24 (.branch 26 (.cut 1155 556) (.small 0)) (.branch 31 (.branch 33 (.cut 1283 556) (.small 0)) (.small 3))))))))))))
private theorem checked0_3_11 : check 0 270569027 280 subtree0_3_11=true := by unfold subtree0_3_11; decide

@[irreducible] private def subtree0_3_13 : Tree :=
  (.branch 17 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.branch 12 (.cut 15 1648) (.branch 14 (.cut 1043 620) (.branch 23 (.cut 15 1744) (.branch 25 (.cut 1043 716) (.branch 30 (.cut 15 1872) (.branch 32 (.cut 1043 844) (.small 0)))))))))
private theorem checked0_3_13 : check 0 270632515 2328 subtree0_3_13=true := by unfold subtree0_3_13; decide

@[irreducible] private def subtree0_3_15 : Tree :=
  (.branch 23 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.branch 12 (.cut 15 1712) (.branch 14 (.cut 1043 684) (.branch 17 (.cut 15 1744) (.branch 19 (.cut 1043 716) (.branch 30 (.cut 15 1936) (.small 0))))))))
private theorem checked0_3_15 : check 0 274761283 67864 subtree0_3_15=true := by unfold subtree0_3_15; decide

@[irreducible] private def subtree0_3_17 : Tree :=
  (.branch 30 (.cut 15 1808) (.branch 32 (.cut 1043 780) (.branch 12 (.cut 15 1840) (.branch 14 (.cut 1043 812) (.branch 17 (.cut 15 1872) (.branch 19 (.cut 1043 844) (.small 0)))))))
private theorem checked0_3_17 : check 0 807437891 4262168 subtree0_3_17=true := by unfold subtree0_3_17; decide

@[irreducible] private def subtree0_3_19 : Tree :=
  (.branch 7 (.cut 15 1584) (.branch 13 (.branch 2 (.cut 1059 524) (.small 1)) (.branch 14 (.branch 2 (.cut 1043 556) (.small 1)) (.branch 19 (.branch 2 (.cut 1043 588) (.small 1)) (.branch 25 (.branch 2 (.cut 1043 652) (.small 1)) (.branch 32 (.branch 2 (.cut 1043 780) (.small 0)) (.small 0)))))))
private theorem checked0_3_19 : check 0 270571075 541133080 subtree0_3_19=true := by unfold subtree0_3_19; decide

@[irreducible] private def subtree0_3_20 : Tree :=
  (.branch 14 (.branch 2 (.cut 1043 556) (.branch 13 (.branch 7 (.cut 1059 540) (.small 1)) (.branch 17 (.branch 7 (.cut 15 1616) (.small 1)) (.branch 23 (.branch 7 (.cut 15 1680) (.small 1)) (.branch 30 (.branch 7 (.cut 15 1808) (.small 0)) (.small 0)))))) (.branch 17 (.branch 7 (.cut 15 1616) (.branch 18 (.branch 2 (.cut 1091 524) (.small 1)) (.branch 19 (.branch 2 (.cut 1043 588) (.small 1)) (.branch 25 (.branch 2 (.cut 1043 652) (.small 0)) (.small 0))))) (.branch 19 (.branch 2 (.cut 1043 588) (.branch 18 (.branch 7 (.cut 1091 540) (.small 0)) (.branch 23 (.branch 7 (.cut 15 1680) (.small 0)) (.small 0)))) (.branch 23 (.branch 7 (.cut 15 1680) (.small 0)) (.small 0)))))
private theorem checked0_3_20 : check 0 270566979 541137176 subtree0_3_20=true := by unfold subtree0_3_20; decide

@[irreducible] private def subtree0_3_18 : Tree :=
  .branch 12 subtree0_3_19 subtree0_3_20
private theorem checked0_3_18 : check 0 270566979 541133080 subtree0_3_18=true := by
  unfold subtree0_3_18
  change (check 0 270571075 541133080 subtree0_3_19 && check 0 270566979 541137176 subtree0_3_20)=true
  simp only [checked0_3_19,checked0_3_20,Bool.true_and]

@[irreducible] private def subtree0_3_16 : Tree :=
  .branch 29 subtree0_3_17 subtree0_3_18
private theorem checked0_3_16 : check 0 270566979 4262168 subtree0_3_16=true := by
  unfold subtree0_3_16
  change (check 0 807437891 4262168 subtree0_3_17 && check 0 270566979 541133080 subtree0_3_18)=true
  simp only [checked0_3_17,checked0_3_18,Bool.true_and]

@[irreducible] private def subtree0_3_14 : Tree :=
  .branch 22 subtree0_3_15 subtree0_3_16
private theorem checked0_3_14 : check 0 270566979 67864 subtree0_3_14=true := by
  unfold subtree0_3_14
  change (check 0 274761283 67864 subtree0_3_15 && check 0 270566979 4262168 subtree0_3_16)=true
  simp only [checked0_3_15,checked0_3_16,Bool.true_and]

@[irreducible] private def subtree0_3_12 : Tree :=
  .branch 16 subtree0_3_13 subtree0_3_14
private theorem checked0_3_12 : check 0 270566979 2328 subtree0_3_12=true := by
  unfold subtree0_3_12
  change (check 0 270632515 2328 subtree0_3_13 && check 0 270566979 67864 subtree0_3_14)=true
  simp only [checked0_3_13,checked0_3_14,Bool.true_and]

@[irreducible] private def subtree0_3_10 : Tree :=
  .branch 11 subtree0_3_11 subtree0_3_12
private theorem checked0_3_10 : check 0 270566979 280 subtree0_3_10=true := by
  unfold subtree0_3_10
  change (check 0 270569027 280 subtree0_3_11 && check 0 270566979 2328 subtree0_3_12)=true
  simp only [checked0_3_11,checked0_3_12,Bool.true_and]

@[irreducible] private def subtree0_3_8 : Tree :=
  .branch 8 subtree0_3_9 subtree0_3_10
private theorem checked0_3_8 : check 0 270566979 24 subtree0_3_8=true := by
  unfold subtree0_3_8
  change (check 0 270567235 24 subtree0_3_9 && check 0 270566979 280 subtree0_3_10)=true
  simp only [checked0_3_9,checked0_3_10,Bool.true_and]

@[irreducible] private def subtree0_3_23 : Tree :=
  (.branch 2 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.branch 22 (.cut 1059 652) (.branch 29 (.cut 1059 780) (.small 1)))))))
private theorem checked0_3_23 : check 0 270578755 536 subtree0_3_23=true := by unfold subtree0_3_23; decide

@[irreducible] private def subtree0_3_25 : Tree :=
  (.branch 8 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 17 (.cut 15 1648) (.branch 20 (.cut 1059 604) (.branch 23 (.cut 15 1712) (.branch 26 (.cut 1059 668) (.branch 30 (.cut 15 1840) (.branch 33 (.cut 1059 796) (.branch 18 (.branch 19 (.cut 1091 540) (.small 0)) (.branch 24 (.branch 25 (.cut 1155 540) (.small 0)) (.small 3)))))))))))
private theorem checked0_3_25 : check 0 270574787 4632 subtree0_3_25=true := by unfold subtree0_3_25; decide

@[irreducible] private def subtree0_3_27 : Tree :=
  (.branch 17 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.branch 8 (.cut 15 1648) (.branch 14 (.cut 1059 604) (.branch 23 (.cut 15 1760) (.branch 26 (.cut 1059 716) (.branch 30 (.cut 15 1888) (.branch 33 (.cut 1059 844) (.small 0)))))))))
private theorem checked0_3_27 : check 0 270640195 4760 subtree0_3_27=true := by unfold subtree0_3_27; decide

@[irreducible] private def subtree0_3_29 : Tree :=
  (.branch 23 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.branch 8 (.cut 15 1712) (.branch 14 (.cut 1059 668) (.branch 17 (.cut 15 1760) (.branch 20 (.cut 1059 716) (.branch 30 (.cut 15 1952) (.small 0))))))))
private theorem checked0_3_29 : check 0 274768963 70296 subtree0_3_29=true := by unfold subtree0_3_29; decide

@[irreducible] private def subtree0_3_31 : Tree :=
  (.branch 30 (.cut 15 1824) (.branch 33 (.cut 1059 780) (.branch 8 (.cut 15 1840) (.branch 14 (.cut 1059 796) (.branch 17 (.cut 15 1888) (.branch 20 (.cut 1059 844) (.small 0)))))))
private theorem checked0_3_31 : check 0 807445571 4264600 subtree0_3_31=true := by unfold subtree0_3_31; decide

@[irreducible] private def subtree0_3_33 : Tree :=
  (.branch 11 (.cut 15 1584) (.branch 14 (.branch 2 (.cut 1059 540) (.small 1)) (.branch 20 (.branch 2 (.cut 1059 588) (.small 1)) (.branch 26 (.branch 2 (.cut 1059 652) (.small 1)) (.branch 33 (.branch 2 (.cut 1059 780) (.small 0)) (.small 0))))))
private theorem checked0_3_33 : check 0 270574915 541135512 subtree0_3_33=true := by unfold subtree0_3_33; decide

@[irreducible] private def subtree0_3_34 : Tree :=
  (.branch 14 (.branch 2 (.cut 1059 540) (.branch 17 (.branch 11 (.cut 15 1632) (.small 1)) (.branch 23 (.branch 11 (.cut 15 1696) (.small 1)) (.branch 30 (.branch 11 (.cut 15 1824) (.small 0)) (.small 0))))) (.branch 17 (.branch 11 (.cut 15 1632) (.branch 18 (.branch 2 (.cut 1091 524) (.small 1)) (.branch 20 (.branch 2 (.cut 1059 588) (.small 1)) (.branch 26 (.branch 2 (.cut 1059 652) (.small 0)) (.small 0))))) (.branch 20 (.branch 2 (.cut 1059 588) (.branch 18 (.branch 11 (.cut 1091 556) (.small 0)) (.branch 23 (.branch 11 (.cut 15 1696) (.small 0)) (.small 0)))) (.branch 23 (.branch 11 (.cut 15 1696) (.small 0)) (.small 0)))))
private theorem checked0_3_34 : check 0 270574659 541135768 subtree0_3_34=true := by unfold subtree0_3_34; decide

@[irreducible] private def subtree0_3_32 : Tree :=
  .branch 8 subtree0_3_33 subtree0_3_34
private theorem checked0_3_32 : check 0 270574659 541135512 subtree0_3_32=true := by
  unfold subtree0_3_32
  change (check 0 270574915 541135512 subtree0_3_33 && check 0 270574659 541135768 subtree0_3_34)=true
  simp only [checked0_3_33,checked0_3_34,Bool.true_and]

@[irreducible] private def subtree0_3_30 : Tree :=
  .branch 29 subtree0_3_31 subtree0_3_32
private theorem checked0_3_30 : check 0 270574659 4264600 subtree0_3_30=true := by
  unfold subtree0_3_30
  change (check 0 807445571 4264600 subtree0_3_31 && check 0 270574659 541135512 subtree0_3_32)=true
  simp only [checked0_3_31,checked0_3_32,Bool.true_and]

@[irreducible] private def subtree0_3_28 : Tree :=
  .branch 22 subtree0_3_29 subtree0_3_30
private theorem checked0_3_28 : check 0 270574659 70296 subtree0_3_28=true := by
  unfold subtree0_3_28
  change (check 0 274768963 70296 subtree0_3_29 && check 0 270574659 4264600 subtree0_3_30)=true
  simp only [checked0_3_29,checked0_3_30,Bool.true_and]

@[irreducible] private def subtree0_3_26 : Tree :=
  .branch 16 subtree0_3_27 subtree0_3_28
private theorem checked0_3_26 : check 0 270574659 4760 subtree0_3_26=true := by
  unfold subtree0_3_26
  change (check 0 270640195 4760 subtree0_3_27 && check 0 270574659 70296 subtree0_3_28)=true
  simp only [checked0_3_27,checked0_3_28,Bool.true_and]

@[irreducible] private def subtree0_3_24 : Tree :=
  .branch 7 subtree0_3_25 subtree0_3_26
private theorem checked0_3_24 : check 0 270574659 4632 subtree0_3_24=true := by
  unfold subtree0_3_24
  change (check 0 270574787 4632 subtree0_3_25 && check 0 270574659 4760 subtree0_3_26)=true
  simp only [checked0_3_25,checked0_3_26,Bool.true_and]

@[irreducible] private def subtree0_3_22 : Tree :=
  .branch 12 subtree0_3_23 subtree0_3_24
private theorem checked0_3_22 : check 0 270574659 536 subtree0_3_22=true := by
  unfold subtree0_3_22
  change (check 0 270578755 536 subtree0_3_23 && check 0 270574659 4632 subtree0_3_24)=true
  simp only [checked0_3_23,checked0_3_24,Bool.true_and]

@[irreducible] private def subtree0_3_37 : Tree :=
  (.branch 2 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.branch 22 (.cut 1091 652) (.branch 29 (.cut 1091 780) (.small 1)))))))
private theorem checked0_3_37 : check 0 270959683 8728 subtree0_3_37=true := by unfold subtree0_3_37; decide

@[irreducible] private def subtree0_3_39 : Tree :=
  (.branch 8 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 12 (.cut 15 1648) (.branch 20 (.cut 1091 572) (.branch 23 (.cut 15 1744) (.branch 27 (.cut 1091 668) (.branch 30 (.cut 15 1872) (.branch 34 (.cut 1091 796) (.branch 24 (.branch 25 (.cut 1155 540) (.small 0)) (.small 3))))))))))
private theorem checked0_3_39 : check 0 270828739 139800 subtree0_3_39=true := by unfold subtree0_3_39; decide

@[irreducible] private def subtree0_3_41 : Tree :=
  (.branch 12 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.branch 8 (.cut 15 1648) (.branch 19 (.cut 1091 572) (.branch 23 (.cut 15 1760) (.branch 27 (.cut 1091 684) (.branch 30 (.cut 15 1888) (.branch 34 (.cut 1091 812) (.small 0)))))))))
private theorem checked0_3_41 : check 0 270830659 139928 subtree0_3_41=true := by unfold subtree0_3_41; decide

@[irreducible] private def subtree0_3_43 : Tree :=
  (.branch 23 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.branch 8 (.cut 15 1744) (.branch 12 (.cut 15 1760) (.branch 19 (.cut 1091 668) (.branch 20 (.cut 1091 684) (.branch 30 (.cut 15 1984) (.small 0))))))))
private theorem checked0_3_43 : check 0 275022915 141976 subtree0_3_43=true := by unfold subtree0_3_43; decide

@[irreducible] private def subtree0_3_45 : Tree :=
  (.branch 30 (.cut 15 1856) (.branch 34 (.cut 1091 780) (.branch 8 (.cut 15 1872) (.branch 12 (.cut 15 1888) (.branch 19 (.cut 1091 796) (.branch 20 (.cut 1091 812) (.small 0)))))))
private theorem checked0_3_45 : check 0 807699523 4336280 subtree0_3_45=true := by unfold subtree0_3_45; decide

@[irreducible] private def subtree0_3_46 : Tree :=
  (.branch 8 (.branch 16 (.cut 15 1616) (.branch 19 (.branch 2 (.cut 1091 540) (.small 1)) (.branch 20 (.branch 2 (.cut 1091 556) (.small 1)) (.branch 27 (.branch 2 (.cut 1091 652) (.small 1)) (.branch 34 (.branch 2 (.cut 1091 780) (.small 0)) (.small 0)))))) (.branch 12 (.branch 16 (.cut 15 1632) (.branch 19 (.branch 2 (.cut 1091 540) (.small 1)) (.branch 20 (.branch 2 (.cut 1091 556) (.small 1)) (.branch 27 (.branch 2 (.cut 1091 652) (.small 0)) (.small 0))))) (.branch 19 (.branch 2 (.cut 1091 540) (.branch 23 (.branch 16 (.cut 15 1728) (.small 1)) (.branch 30 (.branch 16 (.cut 15 1856) (.small 0)) (.small 0)))) (.branch 20 (.branch 2 (.cut 1091 556) (.branch 23 (.branch 16 (.cut 15 1728) (.small 0)) (.small 0))) (.branch 23 (.branch 16 (.cut 15 1728) (.small 0)) (.small 0))))))
private theorem checked0_3_46 : check 0 270828611 541207192 subtree0_3_46=true := by unfold subtree0_3_46; decide

@[irreducible] private def subtree0_3_44 : Tree :=
  .branch 29 subtree0_3_45 subtree0_3_46
private theorem checked0_3_44 : check 0 270828611 4336280 subtree0_3_44=true := by
  unfold subtree0_3_44
  change (check 0 807699523 4336280 subtree0_3_45 && check 0 270828611 541207192 subtree0_3_46)=true
  simp only [checked0_3_45,checked0_3_46,Bool.true_and]

@[irreducible] private def subtree0_3_42 : Tree :=
  .branch 22 subtree0_3_43 subtree0_3_44
private theorem checked0_3_42 : check 0 270828611 141976 subtree0_3_42=true := by
  unfold subtree0_3_42
  change (check 0 275022915 141976 subtree0_3_43 && check 0 270828611 4336280 subtree0_3_44)=true
  simp only [checked0_3_43,checked0_3_44,Bool.true_and]

@[irreducible] private def subtree0_3_40 : Tree :=
  .branch 11 subtree0_3_41 subtree0_3_42
private theorem checked0_3_40 : check 0 270828611 139928 subtree0_3_40=true := by
  unfold subtree0_3_40
  change (check 0 270830659 139928 subtree0_3_41 && check 0 270828611 141976 subtree0_3_42)=true
  simp only [checked0_3_41,checked0_3_42,Bool.true_and]

@[irreducible] private def subtree0_3_38 : Tree :=
  .branch 7 subtree0_3_39 subtree0_3_40
private theorem checked0_3_38 : check 0 270828611 139800 subtree0_3_38=true := by
  unfold subtree0_3_38
  change (check 0 270828739 139800 subtree0_3_39 && check 0 270828611 139928 subtree0_3_40)=true
  simp only [checked0_3_39,checked0_3_40,Bool.true_and]

@[irreducible] private def subtree0_3_36 : Tree :=
  .branch 17 subtree0_3_37 subtree0_3_38
private theorem checked0_3_36 : check 0 270828611 8728 subtree0_3_36=true := by
  unfold subtree0_3_36
  change (check 0 270959683 8728 subtree0_3_37 && check 0 270828611 139800 subtree0_3_38)=true
  simp only [checked0_3_37,checked0_3_38,Bool.true_and]

@[irreducible] private def subtree0_3_49 : Tree :=
  (.branch 2 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.branch 16 (.cut 1155 588) (.branch 29 (.cut 1155 780) (.small 1)))))))
private theorem checked0_3_49 : check 0 295732291 270872 subtree0_3_49=true := by unfold subtree0_3_49; decide

@[irreducible] private def subtree0_3_51 : Tree :=
  (.branch 8 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 12 (.cut 15 1712) (.branch 17 (.cut 15 1744) (.branch 26 (.cut 1155 572) (.branch 27 (.cut 1155 604) (.branch 30 (.cut 15 1936) (.branch 35 (.cut 1155 796) (.small 3)))))))))
private theorem checked0_3_51 : check 0 287343811 8659480 subtree0_3_51=true := by unfold subtree0_3_51; decide

@[irreducible] private def subtree0_3_53 : Tree :=
  (.branch 12 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.branch 8 (.cut 15 1712) (.branch 17 (.cut 15 1760) (.branch 25 (.cut 1155 572) (.branch 27 (.cut 1155 620) (.branch 30 (.cut 15 1952) (.branch 35 (.cut 1155 812) (.small 0)))))))))
private theorem checked0_3_53 : check 0 287345731 8659608 subtree0_3_53=true := by unfold subtree0_3_53; decide

@[irreducible] private def subtree0_3_55 : Tree :=
  (.branch 17 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.branch 8 (.cut 15 1744) (.branch 12 (.cut 15 1760) (.branch 25 (.cut 1155 604) (.branch 26 (.cut 1155 620) (.branch 30 (.cut 15 1984) (.small 0))))))))
private theorem checked0_3_55 : check 0 287409219 8661656 subtree0_3_55=true := by unfold subtree0_3_55; decide

@[irreducible] private def subtree0_3_57 : Tree :=
  (.branch 30 (.cut 15 1920) (.branch 35 (.cut 1155 780) (.small 3)))
private theorem checked0_3_57 : check 0 824214595 8727192 subtree0_3_57=true := by unfold subtree0_3_57; decide

@[irreducible] private def subtree0_3_58 : Tree :=
  (.branch 8 (.branch 22 (.cut 15 1680) (.branch 25 (.branch 2 (.cut 1155 540) (.small 1)) (.branch 26 (.branch 2 (.cut 1155 556) (.small 1)) (.branch 27 (.branch 2 (.cut 1155 588) (.small 1)) (.branch 35 (.branch 2 (.cut 1155 780) (.small 0)) (.small 0)))))) (.branch 12 (.branch 22 (.cut 15 1696) (.branch 25 (.branch 2 (.cut 1155 540) (.small 1)) (.branch 26 (.branch 2 (.cut 1155 556) (.small 1)) (.branch 27 (.branch 2 (.cut 1155 588) (.small 0)) (.small 0))))) (.branch 17 (.branch 22 (.cut 15 1728) (.branch 25 (.branch 2 (.cut 1155 540) (.small 1)) (.branch 26 (.branch 2 (.cut 1155 556) (.small 0)) (.small 0)))) (.branch 25 (.branch 2 (.cut 1155 540) (.branch 30 (.branch 22 (.cut 15 1920) (.small 0)) (.small 0))) (.branch 26 (.branch 2 (.cut 1155 556) (.small 0)) (.small 0))))))
private theorem checked0_3_58 : check 0 287343683 545598104 subtree0_3_58=true := by unfold subtree0_3_58; decide

@[irreducible] private def subtree0_3_56 : Tree :=
  .branch 29 subtree0_3_57 subtree0_3_58
private theorem checked0_3_56 : check 0 287343683 8727192 subtree0_3_56=true := by
  unfold subtree0_3_56
  change (check 0 824214595 8727192 subtree0_3_57 && check 0 287343683 545598104 subtree0_3_58)=true
  simp only [checked0_3_57,checked0_3_58,Bool.true_and]

@[irreducible] private def subtree0_3_54 : Tree :=
  .branch 16 subtree0_3_55 subtree0_3_56
private theorem checked0_3_54 : check 0 287343683 8661656 subtree0_3_54=true := by
  unfold subtree0_3_54
  change (check 0 287409219 8661656 subtree0_3_55 && check 0 287343683 8727192 subtree0_3_56)=true
  simp only [checked0_3_55,checked0_3_56,Bool.true_and]

@[irreducible] private def subtree0_3_52 : Tree :=
  .branch 11 subtree0_3_53 subtree0_3_54
private theorem checked0_3_52 : check 0 287343683 8659608 subtree0_3_52=true := by
  unfold subtree0_3_52
  change (check 0 287345731 8659608 subtree0_3_53 && check 0 287343683 8661656 subtree0_3_54)=true
  simp only [checked0_3_53,checked0_3_54,Bool.true_and]

@[irreducible] private def subtree0_3_50 : Tree :=
  .branch 7 subtree0_3_51 subtree0_3_52
private theorem checked0_3_50 : check 0 287343683 8659480 subtree0_3_50=true := by
  unfold subtree0_3_50
  change (check 0 287343811 8659480 subtree0_3_51 && check 0 287343683 8659608 subtree0_3_52)=true
  simp only [checked0_3_51,checked0_3_52,Bool.true_and]

@[irreducible] private def subtree0_3_48 : Tree :=
  .branch 23 subtree0_3_49 subtree0_3_50
private theorem checked0_3_48 : check 0 287343683 270872 subtree0_3_48=true := by
  unfold subtree0_3_48
  change (check 0 295732291 270872 subtree0_3_49 && check 0 287343683 8659480 subtree0_3_50)=true
  simp only [checked0_3_49,checked0_3_50,Bool.true_and]

@[irreducible] private def subtree0_3_59 : Tree :=
  (.branch 31 (.branch 30 (.branch 2 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.branch 16 (.cut 1283 588) (.branch 22 (.cut 1283 652) (.small 1))))))) (.small 3)) (.small 3))
private theorem checked0_3_59 : check 0 270566467 17048088 subtree0_3_59=true := by unfold subtree0_3_59; decide

@[irreducible] private def subtree0_3_47 : Tree :=
  .branch 24 subtree0_3_48 subtree0_3_59
private theorem checked0_3_47 : check 0 270566467 270872 subtree0_3_47=true := by
  unfold subtree0_3_47
  change (check 0 287343683 270872 subtree0_3_48 && check 0 270566467 17048088 subtree0_3_59)=true
  simp only [checked0_3_48,checked0_3_59,Bool.true_and]

@[irreducible] private def subtree0_3_35 : Tree :=
  .branch 18 subtree0_3_36 subtree0_3_47
private theorem checked0_3_35 : check 0 270566467 8728 subtree0_3_35=true := by
  unfold subtree0_3_35
  change (check 0 270828611 8728 subtree0_3_36 && check 0 270566467 270872 subtree0_3_47)=true
  simp only [checked0_3_36,checked0_3_47,Bool.true_and]

@[irreducible] private def subtree0_3_21 : Tree :=
  .branch 13 subtree0_3_22 subtree0_3_35
private theorem checked0_3_21 : check 0 270566467 536 subtree0_3_21=true := by
  unfold subtree0_3_21
  change (check 0 270574659 536 subtree0_3_22 && check 0 270566467 8728 subtree0_3_35)=true
  simp only [checked0_3_22,checked0_3_35,Bool.true_and]

@[irreducible] private def subtree0_3_7 : Tree :=
  .branch 9 subtree0_3_8 subtree0_3_21
private theorem checked0_3_7 : check 0 270566467 24 subtree0_3_7=true := by
  unfold subtree0_3_7
  change (check 0 270566979 24 subtree0_3_8 && check 0 270566467 536 subtree0_3_21)=true
  simp only [checked0_3_8,checked0_3_21,Bool.true_and]

@[irreducible] private def subtree0_3_5 : Tree :=
  .branch 4 subtree0_3_6 subtree0_3_7
private theorem checked0_3_5 : check 0 270566467 8 subtree0_3_5=true := by
  unfold subtree0_3_5
  change (check 0 270566483 8 subtree0_3_6 && check 0 270566467 24 subtree0_3_7)=true
  simp only [checked0_3_6,checked0_3_7,Bool.true_and]

@[irreducible] private def subtree0_3_61 : Tree :=
  (.cut 1027 524)
private theorem checked0_3_61 : check 0 2131027 268435464 subtree0_3_61=true := by unfold subtree0_3_61; decide

@[irreducible] private def subtree0_3_63 : Tree :=
  (.branch 8 (.branch 2 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.small 0))))) (.branch 11 (.branch 12 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 17 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1680) (.small 0)) (.small 0)))))
private theorem checked0_3_63 : check 0 2131523 268435480 subtree0_3_63=true := by unfold subtree0_3_63; decide

@[irreducible] private def subtree0_3_65 : Tree :=
  (.branch 12 (.branch 2 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 17 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1696) (.small 0)) (.small 0)))))
private theorem checked0_3_65 : check 0 2139203 268435992 subtree0_3_65=true := by unfold subtree0_3_65; decide

@[irreducible] private def subtree0_3_67 : Tree :=
  (.branch 17 (.branch 2 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 12 (.cut 15 1648) (.small 0)))) (.branch 11 (.branch 12 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1728) (.small 0)) (.small 0)))))
private theorem checked0_3_67 : check 0 2393155 268444184 subtree0_3_67=true := by unfold subtree0_3_67; decide

@[irreducible] private def subtree0_3_68 : Tree :=
  (.branch 24 (.branch 23 (.branch 2 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 12 (.cut 15 1712) (.small 0)))) (.branch 11 (.branch 12 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.small 0))) (.branch 16 (.branch 17 (.cut 15 1728) (.small 0)) (.small 0))))) (.branch 31 (.branch 2 (.branch 30 (.cut 1283 524) (.small 3)) (.branch 7 (.branch 30 (.cut 1283 540) (.small 3)) (.branch 11 (.branch 30 (.cut 1283 556) (.small 3)) (.branch 16 (.branch 30 (.cut 1283 588) (.small 3)) (.small 0))))) (.small 3)))
private theorem checked0_3_68 : check 0 2131011 268706328 subtree0_3_68=true := by unfold subtree0_3_68; decide

@[irreducible] private def subtree0_3_66 : Tree :=
  .branch 18 subtree0_3_67 subtree0_3_68
private theorem checked0_3_66 : check 0 2131011 268444184 subtree0_3_66=true := by
  unfold subtree0_3_66
  change (check 0 2393155 268444184 subtree0_3_67 && check 0 2131011 268706328 subtree0_3_68)=true
  simp only [checked0_3_67,checked0_3_68,Bool.true_and]

@[irreducible] private def subtree0_3_64 : Tree :=
  .branch 13 subtree0_3_65 subtree0_3_66
private theorem checked0_3_64 : check 0 2131011 268435992 subtree0_3_64=true := by
  unfold subtree0_3_64
  change (check 0 2139203 268435992 subtree0_3_65 && check 0 2131011 268444184 subtree0_3_66)=true
  simp only [checked0_3_65,checked0_3_66,Bool.true_and]

@[irreducible] private def subtree0_3_62 : Tree :=
  .branch 9 subtree0_3_63 subtree0_3_64
private theorem checked0_3_62 : check 0 2131011 268435480 subtree0_3_62=true := by
  unfold subtree0_3_62
  change (check 0 2131523 268435480 subtree0_3_63 && check 0 2131011 268435992 subtree0_3_64)=true
  simp only [checked0_3_63,checked0_3_64,Bool.true_and]

@[irreducible] private def subtree0_3_60 : Tree :=
  .branch 4 subtree0_3_61 subtree0_3_62
private theorem checked0_3_60 : check 0 2131011 268435464 subtree0_3_60=true := by
  unfold subtree0_3_60
  change (check 0 2131027 268435464 subtree0_3_61 && check 0 2131011 268435480 subtree0_3_62)=true
  simp only [checked0_3_61,checked0_3_62,Bool.true_and]

@[irreducible] private def subtree0_3_4 : Tree :=
  .branch 28 subtree0_3_5 subtree0_3_60
private theorem checked0_3_4 : check 0 2131011 8 subtree0_3_4=true := by
  unfold subtree0_3_4
  change (check 0 270566467 8 subtree0_3_5 && check 0 2131011 268435464 subtree0_3_60)=true
  simp only [checked0_3_5,checked0_3_60,Bool.true_and]

@[irreducible] private def subtree0_3_71 : Tree :=
  (.cut 1027 524)
private theorem checked0_3_71 : check 0 268469331 2097160 subtree0_3_71=true := by unfold subtree0_3_71; decide

@[irreducible] private def subtree0_3_73 : Tree :=
  (.branch 8 (.branch 2 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.small 0))))) (.branch 11 (.branch 12 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 17 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1808) (.small 0)) (.small 0)))))
private theorem checked0_3_73 : check 0 268469827 2097176 subtree0_3_73=true := by unfold subtree0_3_73; decide

@[irreducible] private def subtree0_3_75 : Tree :=
  (.branch 12 (.branch 2 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 17 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1824) (.small 0)) (.small 0)))))
private theorem checked0_3_75 : check 0 268477507 2097688 subtree0_3_75=true := by unfold subtree0_3_75; decide

@[irreducible] private def subtree0_3_77 : Tree :=
  (.branch 17 (.branch 2 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 12 (.cut 15 1648) (.small 0)))) (.branch 11 (.branch 12 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1856) (.small 0)) (.small 0)))))
private theorem checked0_3_77 : check 0 268731459 2105880 subtree0_3_77=true := by unfold subtree0_3_77; decide

@[irreducible] private def subtree0_3_78 : Tree :=
  (.branch 31 (.branch 30 (.branch 2 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1808) (.branch 32 (.cut 1283 540) (.branch 12 (.cut 15 1840) (.small 0)))) (.branch 11 (.branch 12 (.cut 15 1824) (.branch 33 (.cut 1283 556) (.small 0))) (.branch 16 (.branch 17 (.cut 15 1856) (.small 0)) (.small 0))))) (.branch 24 (.branch 2 (.branch 23 (.cut 1155 524) (.small 3)) (.branch 7 (.branch 23 (.cut 1155 540) (.small 3)) (.branch 11 (.branch 23 (.cut 1155 556) (.small 3)) (.branch 16 (.branch 23 (.cut 1155 588) (.small 3)) (.small 0))))) (.small 3)))
private theorem checked0_3_78 : check 0 268469315 2368024 subtree0_3_78=true := by unfold subtree0_3_78; decide

@[irreducible] private def subtree0_3_76 : Tree :=
  .branch 18 subtree0_3_77 subtree0_3_78
private theorem checked0_3_76 : check 0 268469315 2105880 subtree0_3_76=true := by
  unfold subtree0_3_76
  change (check 0 268731459 2105880 subtree0_3_77 && check 0 268469315 2368024 subtree0_3_78)=true
  simp only [checked0_3_77,checked0_3_78,Bool.true_and]

@[irreducible] private def subtree0_3_74 : Tree :=
  .branch 13 subtree0_3_75 subtree0_3_76
private theorem checked0_3_74 : check 0 268469315 2097688 subtree0_3_74=true := by
  unfold subtree0_3_74
  change (check 0 268477507 2097688 subtree0_3_75 && check 0 268469315 2105880 subtree0_3_76)=true
  simp only [checked0_3_75,checked0_3_76,Bool.true_and]

@[irreducible] private def subtree0_3_72 : Tree :=
  .branch 9 subtree0_3_73 subtree0_3_74
private theorem checked0_3_72 : check 0 268469315 2097176 subtree0_3_72=true := by
  unfold subtree0_3_72
  change (check 0 268469827 2097176 subtree0_3_73 && check 0 268469315 2097688 subtree0_3_74)=true
  simp only [checked0_3_73,checked0_3_74,Bool.true_and]

@[irreducible] private def subtree0_3_70 : Tree :=
  .branch 4 subtree0_3_71 subtree0_3_72
private theorem checked0_3_70 : check 0 268469315 2097160 subtree0_3_70=true := by
  unfold subtree0_3_70
  change (check 0 268469331 2097160 subtree0_3_71 && check 0 268469315 2097176 subtree0_3_72)=true
  simp only [checked0_3_71,checked0_3_72,Bool.true_and]

@[irreducible] private def subtree0_3_79 : Tree :=
  (.small 0)
private theorem checked0_3_79 : check 0 33859 270532616 subtree0_3_79=true := by unfold subtree0_3_79; decide

@[irreducible] private def subtree0_3_69 : Tree :=
  .branch 28 subtree0_3_70 subtree0_3_79
private theorem checked0_3_69 : check 0 33859 2097160 subtree0_3_69=true := by
  unfold subtree0_3_69
  change (check 0 268469315 2097160 subtree0_3_70 && check 0 33859 270532616 subtree0_3_79)=true
  simp only [checked0_3_70,checked0_3_79,Bool.true_and]

@[irreducible] private def subtree0_3_3 : Tree :=
  .branch 21 subtree0_3_4 subtree0_3_69
private theorem checked0_3_3 : check 0 33859 8 subtree0_3_3=true := by
  unfold subtree0_3_3
  change (check 0 2131011 8 subtree0_3_4 && check 0 33859 2097160 subtree0_3_69)=true
  simp only [checked0_3_4,checked0_3_69,Bool.true_and]

@[irreducible] private def subtree0_3_83 : Tree :=
  (.cut 1027 524)
private theorem checked0_3_83 : check 0 270533715 32776 subtree0_3_83=true := by unfold subtree0_3_83; decide

@[irreducible] private def subtree0_3_85 : Tree :=
  (.branch 8 (.branch 2 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 22 (.cut 1043 652) (.small 0))))) (.branch 11 (.branch 12 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 23 (.cut 15 1712) (.small 0)))) (.branch 22 (.branch 23 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1808) (.small 0)) (.small 0)))))
private theorem checked0_3_85 : check 0 270534211 32792 subtree0_3_85=true := by unfold subtree0_3_85; decide

@[irreducible] private def subtree0_3_87 : Tree :=
  (.branch 12 (.branch 2 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 22 (.cut 1059 652) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 23 (.cut 15 1712) (.small 0)))) (.branch 22 (.branch 23 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1824) (.small 0)) (.small 0)))))
private theorem checked0_3_87 : check 0 270541891 33304 subtree0_3_87=true := by unfold subtree0_3_87; decide

@[irreducible] private def subtree0_3_89 : Tree :=
  (.branch 23 (.branch 2 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 12 (.cut 15 1712) (.small 0)))) (.branch 11 (.branch 12 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1920) (.small 0)) (.small 0)))))
private theorem checked0_3_89 : check 0 287310915 41496 subtree0_3_89=true := by unfold subtree0_3_89; decide

@[irreducible] private def subtree0_3_90 : Tree :=
  (.branch 31 (.branch 30 (.branch 2 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1808) (.branch 32 (.cut 1283 540) (.branch 12 (.cut 15 1840) (.small 0)))) (.branch 11 (.branch 12 (.cut 15 1824) (.branch 33 (.cut 1283 556) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1920) (.small 0)) (.small 0))))) (.branch 18 (.branch 2 (.branch 17 (.cut 1091 524) (.small 3)) (.branch 7 (.branch 17 (.cut 1091 540) (.small 3)) (.branch 11 (.branch 17 (.cut 1091 556) (.small 3)) (.branch 22 (.branch 17 (.cut 1091 652) (.small 3)) (.small 0))))) (.small 3)))
private theorem checked0_3_90 : check 0 270533699 16818712 subtree0_3_90=true := by unfold subtree0_3_90; decide

@[irreducible] private def subtree0_3_88 : Tree :=
  .branch 24 subtree0_3_89 subtree0_3_90
private theorem checked0_3_88 : check 0 270533699 41496 subtree0_3_88=true := by
  unfold subtree0_3_88
  change (check 0 287310915 41496 subtree0_3_89 && check 0 270533699 16818712 subtree0_3_90)=true
  simp only [checked0_3_89,checked0_3_90,Bool.true_and]

@[irreducible] private def subtree0_3_86 : Tree :=
  .branch 13 subtree0_3_87 subtree0_3_88
private theorem checked0_3_86 : check 0 270533699 33304 subtree0_3_86=true := by
  unfold subtree0_3_86
  change (check 0 270541891 33304 subtree0_3_87 && check 0 270533699 41496 subtree0_3_88)=true
  simp only [checked0_3_87,checked0_3_88,Bool.true_and]

@[irreducible] private def subtree0_3_84 : Tree :=
  .branch 9 subtree0_3_85 subtree0_3_86
private theorem checked0_3_84 : check 0 270533699 32792 subtree0_3_84=true := by
  unfold subtree0_3_84
  change (check 0 270534211 32792 subtree0_3_85 && check 0 270533699 33304 subtree0_3_86)=true
  simp only [checked0_3_85,checked0_3_86,Bool.true_and]

@[irreducible] private def subtree0_3_82 : Tree :=
  .branch 4 subtree0_3_83 subtree0_3_84
private theorem checked0_3_82 : check 0 270533699 32776 subtree0_3_82=true := by
  unfold subtree0_3_82
  change (check 0 270533715 32776 subtree0_3_83 && check 0 270533699 32792 subtree0_3_84)=true
  simp only [checked0_3_83,checked0_3_84,Bool.true_and]

@[irreducible] private def subtree0_3_91 : Tree :=
  (.small 0)
private theorem checked0_3_91 : check 0 2098243 268468232 subtree0_3_91=true := by unfold subtree0_3_91; decide

@[irreducible] private def subtree0_3_81 : Tree :=
  .branch 28 subtree0_3_82 subtree0_3_91
private theorem checked0_3_81 : check 0 2098243 32776 subtree0_3_81=true := by
  unfold subtree0_3_81
  change (check 0 270533699 32776 subtree0_3_82 && check 0 2098243 268468232 subtree0_3_91)=true
  simp only [checked0_3_82,checked0_3_91,Bool.true_and]

@[irreducible] private def subtree0_3_92 : Tree :=
  (.small 0)
private theorem checked0_3_92 : check 0 1091 2129928 subtree0_3_92=true := by unfold subtree0_3_92; decide

@[irreducible] private def subtree0_3_80 : Tree :=
  .branch 21 subtree0_3_81 subtree0_3_92
private theorem checked0_3_80 : check 0 1091 32776 subtree0_3_80=true := by
  unfold subtree0_3_80
  change (check 0 2098243 32776 subtree0_3_81 && check 0 1091 2129928 subtree0_3_92)=true
  simp only [checked0_3_81,checked0_3_92,Bool.true_and]

@[irreducible] private def subtree0_3_2 : Tree :=
  .branch 15 subtree0_3_3 subtree0_3_80
private theorem checked0_3_2 : check 0 1091 8 subtree0_3_2=true := by
  unfold subtree0_3_2
  change (check 0 33859 8 subtree0_3_3 && check 0 1091 32776 subtree0_3_80)=true
  simp only [checked0_3_3,checked0_3_80,Bool.true_and]

@[irreducible] private def subtree0_3_97 : Tree :=
  (.cut 1027 524)
private theorem checked0_3_97 : check 0 270565459 1032 subtree0_3_97=true := by unfold subtree0_3_97; decide

@[irreducible] private def subtree0_3_99 : Tree :=
  (.branch 8 (.branch 2 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 16 (.cut 1043 588) (.branch 22 (.cut 1043 652) (.small 0))))) (.branch 16 (.branch 17 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.branch 23 (.cut 15 1744) (.small 0)))) (.branch 22 (.branch 23 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1808) (.small 0)) (.small 0)))))
private theorem checked0_3_99 : check 0 270565955 1048 subtree0_3_99=true := by unfold subtree0_3_99; decide

@[irreducible] private def subtree0_3_101 : Tree :=
  (.branch 17 (.branch 2 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 22 (.cut 1091 652) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 23 (.cut 15 1744) (.small 0)))) (.branch 22 (.branch 23 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1856) (.small 0)) (.small 0)))))
private theorem checked0_3_101 : check 0 270827587 1560 subtree0_3_101=true := by unfold subtree0_3_101; decide

@[irreducible] private def subtree0_3_103 : Tree :=
  (.branch 23 (.branch 2 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 16 (.cut 1155 588) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 17 (.cut 15 1744) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1920) (.small 0)) (.small 0)))))
private theorem checked0_3_103 : check 0 287342659 263704 subtree0_3_103=true := by unfold subtree0_3_103; decide

@[irreducible] private def subtree0_3_104 : Tree :=
  (.branch 31 (.branch 30 (.branch 2 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 16 (.cut 1283 588) (.small 0))))) (.branch 7 (.branch 8 (.cut 15 1808) (.branch 32 (.cut 1283 540) (.branch 17 (.cut 15 1872) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1856) (.branch 34 (.cut 1283 588) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1920) (.small 0)) (.small 0))))) (.branch 13 (.branch 2 (.branch 12 (.cut 1059 524) (.small 3)) (.branch 7 (.branch 12 (.cut 1059 540) (.small 3)) (.branch 16 (.branch 12 (.cut 1059 588) (.small 3)) (.branch 22 (.branch 12 (.cut 1059 652) (.small 3)) (.small 0))))) (.small 3)))
private theorem checked0_3_104 : check 0 270565443 17040920 subtree0_3_104=true := by unfold subtree0_3_104; decide

@[irreducible] private def subtree0_3_102 : Tree :=
  .branch 24 subtree0_3_103 subtree0_3_104
private theorem checked0_3_102 : check 0 270565443 263704 subtree0_3_102=true := by
  unfold subtree0_3_102
  change (check 0 287342659 263704 subtree0_3_103 && check 0 270565443 17040920 subtree0_3_104)=true
  simp only [checked0_3_103,checked0_3_104,Bool.true_and]

@[irreducible] private def subtree0_3_100 : Tree :=
  .branch 18 subtree0_3_101 subtree0_3_102
private theorem checked0_3_100 : check 0 270565443 1560 subtree0_3_100=true := by
  unfold subtree0_3_100
  change (check 0 270827587 1560 subtree0_3_101 && check 0 270565443 263704 subtree0_3_102)=true
  simp only [checked0_3_101,checked0_3_102,Bool.true_and]

@[irreducible] private def subtree0_3_98 : Tree :=
  .branch 9 subtree0_3_99 subtree0_3_100
private theorem checked0_3_98 : check 0 270565443 1048 subtree0_3_98=true := by
  unfold subtree0_3_98
  change (check 0 270565955 1048 subtree0_3_99 && check 0 270565443 1560 subtree0_3_100)=true
  simp only [checked0_3_99,checked0_3_100,Bool.true_and]

@[irreducible] private def subtree0_3_96 : Tree :=
  .branch 4 subtree0_3_97 subtree0_3_98
private theorem checked0_3_96 : check 0 270565443 1032 subtree0_3_96=true := by
  unfold subtree0_3_96
  change (check 0 270565459 1032 subtree0_3_97 && check 0 270565443 1048 subtree0_3_98)=true
  simp only [checked0_3_97,checked0_3_98,Bool.true_and]

@[irreducible] private def subtree0_3_105 : Tree :=
  (.small 0)
private theorem checked0_3_105 : check 0 2129987 268436488 subtree0_3_105=true := by unfold subtree0_3_105; decide

@[irreducible] private def subtree0_3_95 : Tree :=
  .branch 28 subtree0_3_96 subtree0_3_105
private theorem checked0_3_95 : check 0 2129987 1032 subtree0_3_95=true := by
  unfold subtree0_3_95
  change (check 0 270565443 1032 subtree0_3_96 && check 0 2129987 268436488 subtree0_3_105)=true
  simp only [checked0_3_96,checked0_3_105,Bool.true_and]

@[irreducible] private def subtree0_3_106 : Tree :=
  (.small 0)
private theorem checked0_3_106 : check 0 32835 2098184 subtree0_3_106=true := by unfold subtree0_3_106; decide

@[irreducible] private def subtree0_3_94 : Tree :=
  .branch 21 subtree0_3_95 subtree0_3_106
private theorem checked0_3_94 : check 0 32835 1032 subtree0_3_94=true := by
  unfold subtree0_3_94
  change (check 0 2129987 1032 subtree0_3_95 && check 0 32835 2098184 subtree0_3_106)=true
  simp only [checked0_3_95,checked0_3_106,Bool.true_and]

@[irreducible] private def subtree0_3_107 : Tree :=
  (.small 0)
private theorem checked0_3_107 : check 0 67 33800 subtree0_3_107=true := by unfold subtree0_3_107; decide

@[irreducible] private def subtree0_3_93 : Tree :=
  .branch 15 subtree0_3_94 subtree0_3_107
private theorem checked0_3_93 : check 0 67 1032 subtree0_3_93=true := by
  unfold subtree0_3_93
  change (check 0 32835 1032 subtree0_3_94 && check 0 67 33800 subtree0_3_107)=true
  simp only [checked0_3_94,checked0_3_107,Bool.true_and]

@[irreducible] private def subtree0_3_1 : Tree :=
  .branch 10 subtree0_3_2 subtree0_3_93
private theorem checked0_3_1 : check 0 67 8 subtree0_3_1=true := by
  unfold subtree0_3_1
  change (check 0 1091 8 subtree0_3_2 && check 0 67 1032 subtree0_3_93)=true
  simp only [checked0_3_2,checked0_3_93,Bool.true_and]

@[irreducible] private def subtree0_3_113 : Tree :=
  (.cut 1027 524)
private theorem checked0_3_113 : check 0 270566419 72 subtree0_3_113=true := by unfold subtree0_3_113; decide

@[irreducible] private def subtree0_3_115 : Tree :=
  (.branch 12 (.branch 2 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 16 (.cut 1059 588) (.branch 22 (.cut 1059 652) (.small 0))))) (.branch 16 (.branch 17 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.branch 23 (.cut 15 1760) (.small 0)))) (.branch 22 (.branch 23 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1824) (.small 0)) (.small 0)))))
private theorem checked0_3_115 : check 0 270574595 88 subtree0_3_115=true := by unfold subtree0_3_115; decide

@[irreducible] private def subtree0_3_117 : Tree :=
  (.branch 17 (.branch 2 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 11 (.cut 1091 556) (.branch 22 (.cut 1091 652) (.small 0))))) (.branch 11 (.branch 12 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.branch 23 (.cut 15 1760) (.small 0)))) (.branch 22 (.branch 23 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1856) (.small 0)) (.small 0)))))
private theorem checked0_3_117 : check 0 270828547 8280 subtree0_3_117=true := by unfold subtree0_3_117; decide

@[irreducible] private def subtree0_3_119 : Tree :=
  (.branch 23 (.branch 2 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 11 (.cut 1155 556) (.branch 16 (.cut 1155 588) (.small 0))))) (.branch 11 (.branch 12 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.branch 17 (.cut 15 1760) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.small 0))) (.branch 29 (.branch 30 (.cut 15 1920) (.small 0)) (.small 0)))))
private theorem checked0_3_119 : check 0 287343619 270424 subtree0_3_119=true := by unfold subtree0_3_119; decide

@[irreducible] private def subtree0_3_120 : Tree :=
  (.branch 31 (.branch 30 (.branch 2 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 11 (.cut 1283 556) (.branch 16 (.cut 1283 588) (.small 0))))) (.branch 11 (.branch 12 (.cut 15 1824) (.branch 33 (.cut 1283 556) (.branch 17 (.cut 15 1888) (.small 0)))) (.branch 16 (.branch 17 (.cut 15 1856) (.branch 34 (.cut 1283 588) (.small 0))) (.branch 22 (.branch 23 (.cut 15 1920) (.small 0)) (.small 0))))) (.branch 9 (.branch 2 (.branch 8 (.cut 1043 524) (.small 3)) (.branch 11 (.branch 8 (.cut 1043 556) (.small 3)) (.branch 16 (.branch 8 (.cut 1043 588) (.small 3)) (.branch 22 (.branch 8 (.cut 1043 652) (.small 3)) (.small 0))))) (.small 3)))
private theorem checked0_3_120 : check 0 270566403 17047640 subtree0_3_120=true := by unfold subtree0_3_120; decide

@[irreducible] private def subtree0_3_118 : Tree :=
  .branch 24 subtree0_3_119 subtree0_3_120
private theorem checked0_3_118 : check 0 270566403 270424 subtree0_3_118=true := by
  unfold subtree0_3_118
  change (check 0 287343619 270424 subtree0_3_119 && check 0 270566403 17047640 subtree0_3_120)=true
  simp only [checked0_3_119,checked0_3_120,Bool.true_and]

@[irreducible] private def subtree0_3_116 : Tree :=
  .branch 18 subtree0_3_117 subtree0_3_118
private theorem checked0_3_116 : check 0 270566403 8280 subtree0_3_116=true := by
  unfold subtree0_3_116
  change (check 0 270828547 8280 subtree0_3_117 && check 0 270566403 270424 subtree0_3_118)=true
  simp only [checked0_3_117,checked0_3_118,Bool.true_and]

@[irreducible] private def subtree0_3_114 : Tree :=
  .branch 13 subtree0_3_115 subtree0_3_116
private theorem checked0_3_114 : check 0 270566403 88 subtree0_3_114=true := by
  unfold subtree0_3_114
  change (check 0 270574595 88 subtree0_3_115 && check 0 270566403 8280 subtree0_3_116)=true
  simp only [checked0_3_115,checked0_3_116,Bool.true_and]

@[irreducible] private def subtree0_3_112 : Tree :=
  .branch 4 subtree0_3_113 subtree0_3_114
private theorem checked0_3_112 : check 0 270566403 72 subtree0_3_112=true := by
  unfold subtree0_3_112
  change (check 0 270566419 72 subtree0_3_113 && check 0 270566403 88 subtree0_3_114)=true
  simp only [checked0_3_113,checked0_3_114,Bool.true_and]

@[irreducible] private def subtree0_3_121 : Tree :=
  (.small 0)
private theorem checked0_3_121 : check 0 2130947 268435528 subtree0_3_121=true := by unfold subtree0_3_121; decide

@[irreducible] private def subtree0_3_111 : Tree :=
  .branch 28 subtree0_3_112 subtree0_3_121
private theorem checked0_3_111 : check 0 2130947 72 subtree0_3_111=true := by
  unfold subtree0_3_111
  change (check 0 270566403 72 subtree0_3_112 && check 0 2130947 268435528 subtree0_3_121)=true
  simp only [checked0_3_112,checked0_3_121,Bool.true_and]

@[irreducible] private def subtree0_3_122 : Tree :=
  (.small 0)
private theorem checked0_3_122 : check 0 33795 2097224 subtree0_3_122=true := by unfold subtree0_3_122; decide

@[irreducible] private def subtree0_3_110 : Tree :=
  .branch 21 subtree0_3_111 subtree0_3_122
private theorem checked0_3_110 : check 0 33795 72 subtree0_3_110=true := by
  unfold subtree0_3_110
  change (check 0 2130947 72 subtree0_3_111 && check 0 33795 2097224 subtree0_3_122)=true
  simp only [checked0_3_111,checked0_3_122,Bool.true_and]

@[irreducible] private def subtree0_3_123 : Tree :=
  (.small 0)
private theorem checked0_3_123 : check 0 1027 32840 subtree0_3_123=true := by unfold subtree0_3_123; decide

@[irreducible] private def subtree0_3_109 : Tree :=
  .branch 15 subtree0_3_110 subtree0_3_123
private theorem checked0_3_109 : check 0 1027 72 subtree0_3_109=true := by
  unfold subtree0_3_109
  change (check 0 33795 72 subtree0_3_110 && check 0 1027 32840 subtree0_3_123)=true
  simp only [checked0_3_110,checked0_3_123,Bool.true_and]

@[irreducible] private def subtree0_3_124 : Tree :=
  (.small 0)
private theorem checked0_3_124 : check 0 3 1096 subtree0_3_124=true := by unfold subtree0_3_124; decide

@[irreducible] private def subtree0_3_108 : Tree :=
  .branch 10 subtree0_3_109 subtree0_3_124
private theorem checked0_3_108 : check 0 3 72 subtree0_3_108=true := by
  unfold subtree0_3_108
  change (check 0 1027 72 subtree0_3_109 && check 0 3 1096 subtree0_3_124)=true
  simp only [checked0_3_109,checked0_3_124,Bool.true_and]

@[irreducible] def tree0_3 : Tree :=
  .branch 6 subtree0_3_1 subtree0_3_108
theorem tested0_3 : check 0 3 8 tree0_3=true := by
  unfold tree0_3
  change (check 0 67 8 subtree0_3_1 && check 0 3 72 subtree0_3_108)=true
  simp only [checked0_3_1,checked0_3_108,Bool.true_and]

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_3
