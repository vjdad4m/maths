import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] private def subtree0_4_6 : Tree :=
  (.cut 1027 524)
private theorem checked0_4_6 : check 0 270566476 3 subtree0_4_6=true := by unfold subtree0_4_6; decide

@[irreducible] private def subtree0_4_8 : Tree :=
  (.branch 9 (.branch 4 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.small 1))))) (.branch 11 (.branch 13 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.small 0))) (.branch 16 (.branch 18 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1808) (.small 1)) (.small 1))))))
private theorem checked0_4_8 : check 0 270566728 7 subtree0_4_8=true := by unfold subtree0_4_8; decide

@[irreducible] private def subtree0_4_10 : Tree :=
  (.branch 13 (.branch 4 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.small 1))))) (.branch 7 (.branch 9 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.small 0))) (.branch 16 (.branch 18 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1824) (.small 1)) (.small 1))))))
private theorem checked0_4_10 : check 0 270570568 263 subtree0_4_10=true := by unfold subtree0_4_10; decide

@[irreducible] private def subtree0_4_12 : Tree :=
  (.branch 18 (.branch 4 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.small 1))))) (.branch 7 (.branch 9 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.small 0))) (.branch 11 (.branch 13 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1856) (.small 1)) (.small 1))))))
private theorem checked0_4_12 : check 0 270697544 4359 subtree0_4_12=true := by unfold subtree0_4_12; decide

@[irreducible] private def subtree0_4_13 : Tree :=
  (.branch 23 (.branch 24 (.branch 4 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.small 1))))) (.branch 7 (.branch 9 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.small 0))) (.branch 11 (.branch 13 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.small 0))) (.branch 16 (.branch 18 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1920) (.small 1)) (.small 1)))))) (.branch 30 (.branch 31 (.branch 4 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.small 1))))) (.small 2)) (.small 2)))
private theorem checked0_4_13 : check 0 270566472 135431 subtree0_4_13=true := by unfold subtree0_4_13; decide

@[irreducible] private def subtree0_4_11 : Tree :=
  .branch 17 subtree0_4_12 subtree0_4_13
private theorem checked0_4_11 : check 0 270566472 4359 subtree0_4_11=true := by
  unfold subtree0_4_11
  change (check 0 270697544 4359 subtree0_4_12 && check 0 270566472 135431 subtree0_4_13)=true
  simp only [checked0_4_12,checked0_4_13,Bool.true_and]

@[irreducible] private def subtree0_4_9 : Tree :=
  .branch 12 subtree0_4_10 subtree0_4_11
private theorem checked0_4_9 : check 0 270566472 263 subtree0_4_9=true := by
  unfold subtree0_4_9
  change (check 0 270570568 263 subtree0_4_10 && check 0 270566472 4359 subtree0_4_11)=true
  simp only [checked0_4_10,checked0_4_11,Bool.true_and]

@[irreducible] private def subtree0_4_7 : Tree :=
  .branch 8 subtree0_4_8 subtree0_4_9
private theorem checked0_4_7 : check 0 270566472 7 subtree0_4_7=true := by
  unfold subtree0_4_7
  change (check 0 270566728 7 subtree0_4_8 && check 0 270566472 263 subtree0_4_9)=true
  simp only [checked0_4_8,checked0_4_9,Bool.true_and]

@[irreducible] private def subtree0_4_5 : Tree :=
  .branch 2 subtree0_4_6 subtree0_4_7
private theorem checked0_4_5 : check 0 270566472 3 subtree0_4_5=true := by
  unfold subtree0_4_5
  change (check 0 270566476 3 subtree0_4_6 && check 0 270566472 7 subtree0_4_7)=true
  simp only [checked0_4_6,checked0_4_7,Bool.true_and]

@[irreducible] private def subtree0_4_14 : Tree :=
  (.small 0)
private theorem checked0_4_14 : check 0 2131016 268435459 subtree0_4_14=true := by unfold subtree0_4_14; decide

@[irreducible] private def subtree0_4_4 : Tree :=
  .branch 28 subtree0_4_5 subtree0_4_14
private theorem checked0_4_4 : check 0 2131016 3 subtree0_4_4=true := by
  unfold subtree0_4_4
  change (check 0 270566472 3 subtree0_4_5 && check 0 2131016 268435459 subtree0_4_14)=true
  simp only [checked0_4_5,checked0_4_14,Bool.true_and]

@[irreducible] private def subtree0_4_15 : Tree :=
  (.small 0)
private theorem checked0_4_15 : check 0 33864 2097155 subtree0_4_15=true := by unfold subtree0_4_15; decide

@[irreducible] private def subtree0_4_3 : Tree :=
  .branch 21 subtree0_4_4 subtree0_4_15
private theorem checked0_4_3 : check 0 33864 3 subtree0_4_3=true := by
  unfold subtree0_4_3
  change (check 0 2131016 3 subtree0_4_4 && check 0 33864 2097155 subtree0_4_15)=true
  simp only [checked0_4_4,checked0_4_15,Bool.true_and]

@[irreducible] private def subtree0_4_16 : Tree :=
  (.small 0)
private theorem checked0_4_16 : check 0 1096 32771 subtree0_4_16=true := by unfold subtree0_4_16; decide

@[irreducible] private def subtree0_4_2 : Tree :=
  .branch 15 subtree0_4_3 subtree0_4_16
private theorem checked0_4_2 : check 0 1096 3 subtree0_4_2=true := by
  unfold subtree0_4_2
  change (check 0 33864 3 subtree0_4_3 && check 0 1096 32771 subtree0_4_16)=true
  simp only [checked0_4_3,checked0_4_16,Bool.true_and]

@[irreducible] private def subtree0_4_17 : Tree :=
  (.small 0)
private theorem checked0_4_17 : check 0 72 1027 subtree0_4_17=true := by unfold subtree0_4_17; decide

@[irreducible] private def subtree0_4_1 : Tree :=
  .branch 10 subtree0_4_2 subtree0_4_17
private theorem checked0_4_1 : check 0 72 3 subtree0_4_1=true := by
  unfold subtree0_4_1
  change (check 0 1096 3 subtree0_4_2 && check 0 72 1027 subtree0_4_17)=true
  simp only [checked0_4_2,checked0_4_17,Bool.true_and]

@[irreducible] private def subtree0_4_18 : Tree :=
  (.small 0)
private theorem checked0_4_18 : check 0 8 67 subtree0_4_18=true := by unfold subtree0_4_18; decide

@[irreducible] def tree0_4 : Tree :=
  .branch 6 subtree0_4_1 subtree0_4_18
theorem tested0_4 : check 0 8 3 tree0_4=true := by
  unfold tree0_4
  change (check 0 72 3 subtree0_4_1 && check 0 8 67 subtree0_4_18)=true
  simp only [checked0_4_1,checked0_4_18,Bool.true_and]

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_4
