import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] private def subtree0_5_6 : Tree :=
  (.cut 1027 524)
private theorem checked0_5_6 : check 0 270566477 2 subtree0_5_6=true := by unfold subtree0_5_6; decide

@[irreducible] private def subtree0_5_9 : Tree :=
  (.branch 4 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.branch 22 (.cut 1043 652) (.branch 29 (.cut 1043 780) (.small 1)))))))
private theorem checked0_5_9 : check 0 270567241 6 subtree0_5_9=true := by unfold subtree0_5_9; decide

@[irreducible] private def subtree0_5_11 : Tree :=
  (.branch 13 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 18 (.cut 15 1648) (.branch 19 (.cut 1043 620) (.branch 24 (.cut 15 1712) (.branch 25 (.cut 1043 684) (.branch 31 (.cut 15 1840) (.branch 32 (.cut 1043 812) (.branch 17 (.branch 20 (.cut 1091 556) (.small 0)) (.branch 23 (.branch 26 (.cut 1155 556) (.small 0)) (.branch 30 (.branch 33 (.cut 1283 556) (.small 0)) (.small 2))))))))))))
private theorem checked0_5_11 : check 0 270568777 518 subtree0_5_11=true := by unfold subtree0_5_11; decide

@[irreducible] private def subtree0_5_13 : Tree :=
  (.branch 18 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.branch 13 (.cut 15 1648) (.branch 14 (.cut 1043 620) (.branch 24 (.cut 15 1744) (.branch 25 (.cut 1043 716) (.branch 31 (.cut 15 1872) (.branch 32 (.cut 1043 844) (.small 0)))))))))
private theorem checked0_5_13 : check 0 270632265 2566 subtree0_5_13=true := by unfold subtree0_5_13; decide

@[irreducible] private def subtree0_5_15 : Tree :=
  (.branch 24 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.branch 13 (.cut 15 1712) (.branch 14 (.cut 1043 684) (.branch 18 (.cut 15 1744) (.branch 19 (.cut 1043 716) (.branch 31 (.cut 15 1936) (.small 0))))))))
private theorem checked0_5_15 : check 0 274761033 68102 subtree0_5_15=true := by unfold subtree0_5_15; decide

@[irreducible] private def subtree0_5_17 : Tree :=
  (.branch 31 (.cut 15 1808) (.branch 32 (.cut 1043 780) (.branch 13 (.cut 15 1840) (.branch 14 (.cut 1043 812) (.branch 18 (.cut 15 1872) (.branch 19 (.cut 1043 844) (.small 0)))))))
private theorem checked0_5_17 : check 0 807437641 4262406 subtree0_5_17=true := by unfold subtree0_5_17; decide

@[irreducible] private def subtree0_5_19 : Tree :=
  (.branch 7 (.cut 15 1584) (.branch 12 (.branch 4 (.cut 1059 524) (.small 1)) (.branch 14 (.branch 4 (.cut 1043 556) (.small 1)) (.branch 19 (.branch 4 (.cut 1043 588) (.small 1)) (.branch 25 (.branch 4 (.cut 1043 652) (.small 1)) (.branch 32 (.branch 4 (.cut 1043 780) (.small 0)) (.small 0)))))))
private theorem checked0_5_19 : check 0 270574921 541133318 subtree0_5_19=true := by unfold subtree0_5_19; decide

@[irreducible] private def subtree0_5_20 : Tree :=
  (.branch 14 (.branch 4 (.cut 1043 556) (.branch 12 (.branch 7 (.cut 1059 540) (.small 1)) (.branch 18 (.branch 7 (.cut 15 1616) (.small 1)) (.branch 24 (.branch 7 (.cut 15 1680) (.small 1)) (.branch 31 (.branch 7 (.cut 15 1808) (.small 0)) (.small 0)))))) (.branch 18 (.branch 7 (.cut 15 1616) (.branch 17 (.branch 4 (.cut 1091 524) (.small 1)) (.branch 19 (.branch 4 (.cut 1043 588) (.small 1)) (.branch 25 (.branch 4 (.cut 1043 652) (.small 0)) (.small 0))))) (.branch 19 (.branch 4 (.cut 1043 588) (.branch 17 (.branch 7 (.cut 1091 540) (.small 0)) (.branch 24 (.branch 7 (.cut 15 1680) (.small 0)) (.small 0)))) (.branch 24 (.branch 7 (.cut 15 1680) (.small 0)) (.small 0)))))
private theorem checked0_5_20 : check 0 270566729 541141510 subtree0_5_20=true := by unfold subtree0_5_20; decide

@[irreducible] private def subtree0_5_18 : Tree :=
  .branch 13 subtree0_5_19 subtree0_5_20
private theorem checked0_5_18 : check 0 270566729 541133318 subtree0_5_18=true := by
  unfold subtree0_5_18
  change (check 0 270574921 541133318 subtree0_5_19 && check 0 270566729 541141510 subtree0_5_20)=true
  simp only [checked0_5_19,checked0_5_20,Bool.true_and]

@[irreducible] private def subtree0_5_16 : Tree :=
  .branch 29 subtree0_5_17 subtree0_5_18
private theorem checked0_5_16 : check 0 270566729 4262406 subtree0_5_16=true := by
  unfold subtree0_5_16
  change (check 0 807437641 4262406 subtree0_5_17 && check 0 270566729 541133318 subtree0_5_18)=true
  simp only [checked0_5_17,checked0_5_18,Bool.true_and]

@[irreducible] private def subtree0_5_14 : Tree :=
  .branch 22 subtree0_5_15 subtree0_5_16
private theorem checked0_5_14 : check 0 270566729 68102 subtree0_5_14=true := by
  unfold subtree0_5_14
  change (check 0 274761033 68102 subtree0_5_15 && check 0 270566729 4262406 subtree0_5_16)=true
  simp only [checked0_5_15,checked0_5_16,Bool.true_and]

@[irreducible] private def subtree0_5_12 : Tree :=
  .branch 16 subtree0_5_13 subtree0_5_14
private theorem checked0_5_12 : check 0 270566729 2566 subtree0_5_12=true := by
  unfold subtree0_5_12
  change (check 0 270632265 2566 subtree0_5_13 && check 0 270566729 68102 subtree0_5_14)=true
  simp only [checked0_5_13,checked0_5_14,Bool.true_and]

@[irreducible] private def subtree0_5_10 : Tree :=
  .branch 11 subtree0_5_11 subtree0_5_12
private theorem checked0_5_10 : check 0 270566729 518 subtree0_5_10=true := by
  unfold subtree0_5_10
  change (check 0 270568777 518 subtree0_5_11 && check 0 270566729 2566 subtree0_5_12)=true
  simp only [checked0_5_11,checked0_5_12,Bool.true_and]

@[irreducible] private def subtree0_5_8 : Tree :=
  .branch 9 subtree0_5_9 subtree0_5_10
private theorem checked0_5_8 : check 0 270566729 6 subtree0_5_8=true := by
  unfold subtree0_5_8
  change (check 0 270567241 6 subtree0_5_9 && check 0 270566729 518 subtree0_5_10)=true
  simp only [checked0_5_9,checked0_5_10,Bool.true_and]

@[irreducible] private def subtree0_5_23 : Tree :=
  (.branch 4 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.branch 22 (.cut 1059 652) (.branch 29 (.cut 1059 780) (.small 1)))))))
private theorem checked0_5_23 : check 0 270578761 262 subtree0_5_23=true := by unfold subtree0_5_23; decide

@[irreducible] private def subtree0_5_25 : Tree :=
  (.branch 9 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 18 (.cut 15 1648) (.branch 20 (.cut 1059 604) (.branch 24 (.cut 15 1712) (.branch 26 (.cut 1059 668) (.branch 31 (.cut 15 1840) (.branch 33 (.cut 1059 796) (.branch 17 (.branch 19 (.cut 1091 540) (.small 0)) (.branch 23 (.branch 25 (.cut 1155 540) (.small 0)) (.small 2)))))))))))
private theorem checked0_5_25 : check 0 270570697 8454 subtree0_5_25=true := by unfold subtree0_5_25; decide

@[irreducible] private def subtree0_5_27 : Tree :=
  (.branch 18 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.branch 9 (.cut 15 1648) (.branch 14 (.cut 1059 604) (.branch 24 (.cut 15 1760) (.branch 26 (.cut 1059 716) (.branch 31 (.cut 15 1888) (.branch 33 (.cut 1059 844) (.small 0)))))))))
private theorem checked0_5_27 : check 0 270636105 8582 subtree0_5_27=true := by unfold subtree0_5_27; decide

@[irreducible] private def subtree0_5_29 : Tree :=
  (.branch 24 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.branch 9 (.cut 15 1712) (.branch 14 (.cut 1059 668) (.branch 18 (.cut 15 1760) (.branch 20 (.cut 1059 716) (.branch 31 (.cut 15 1952) (.small 0))))))))
private theorem checked0_5_29 : check 0 274764873 74118 subtree0_5_29=true := by unfold subtree0_5_29; decide

@[irreducible] private def subtree0_5_31 : Tree :=
  (.branch 31 (.cut 15 1824) (.branch 33 (.cut 1059 780) (.branch 9 (.cut 15 1840) (.branch 14 (.cut 1059 796) (.branch 18 (.cut 15 1888) (.branch 20 (.cut 1059 844) (.small 0)))))))
private theorem checked0_5_31 : check 0 807441481 4268422 subtree0_5_31=true := by unfold subtree0_5_31; decide

@[irreducible] private def subtree0_5_33 : Tree :=
  (.branch 11 (.cut 15 1584) (.branch 14 (.branch 4 (.cut 1059 540) (.small 1)) (.branch 20 (.branch 4 (.cut 1059 588) (.small 1)) (.branch 26 (.branch 4 (.cut 1059 652) (.small 1)) (.branch 33 (.branch 4 (.cut 1059 780) (.small 0)) (.small 0))))))
private theorem checked0_5_33 : check 0 270571081 541139334 subtree0_5_33=true := by unfold subtree0_5_33; decide

@[irreducible] private def subtree0_5_34 : Tree :=
  (.branch 14 (.branch 4 (.cut 1059 540) (.branch 18 (.branch 11 (.cut 15 1632) (.small 1)) (.branch 24 (.branch 11 (.cut 15 1696) (.small 1)) (.branch 31 (.branch 11 (.cut 15 1824) (.small 0)) (.small 0))))) (.branch 18 (.branch 11 (.cut 15 1632) (.branch 17 (.branch 4 (.cut 1091 524) (.small 1)) (.branch 20 (.branch 4 (.cut 1059 588) (.small 1)) (.branch 26 (.branch 4 (.cut 1059 652) (.small 0)) (.small 0))))) (.branch 20 (.branch 4 (.cut 1059 588) (.branch 17 (.branch 11 (.cut 1091 556) (.small 0)) (.branch 24 (.branch 11 (.cut 15 1696) (.small 0)) (.small 0)))) (.branch 24 (.branch 11 (.cut 15 1696) (.small 0)) (.small 0)))))
private theorem checked0_5_34 : check 0 270570569 541139846 subtree0_5_34=true := by unfold subtree0_5_34; decide

@[irreducible] private def subtree0_5_32 : Tree :=
  .branch 9 subtree0_5_33 subtree0_5_34
private theorem checked0_5_32 : check 0 270570569 541139334 subtree0_5_32=true := by
  unfold subtree0_5_32
  change (check 0 270571081 541139334 subtree0_5_33 && check 0 270570569 541139846 subtree0_5_34)=true
  simp only [checked0_5_33,checked0_5_34,Bool.true_and]

@[irreducible] private def subtree0_5_30 : Tree :=
  .branch 29 subtree0_5_31 subtree0_5_32
private theorem checked0_5_30 : check 0 270570569 4268422 subtree0_5_30=true := by
  unfold subtree0_5_30
  change (check 0 807441481 4268422 subtree0_5_31 && check 0 270570569 541139334 subtree0_5_32)=true
  simp only [checked0_5_31,checked0_5_32,Bool.true_and]

@[irreducible] private def subtree0_5_28 : Tree :=
  .branch 22 subtree0_5_29 subtree0_5_30
private theorem checked0_5_28 : check 0 270570569 74118 subtree0_5_28=true := by
  unfold subtree0_5_28
  change (check 0 274764873 74118 subtree0_5_29 && check 0 270570569 4268422 subtree0_5_30)=true
  simp only [checked0_5_29,checked0_5_30,Bool.true_and]

@[irreducible] private def subtree0_5_26 : Tree :=
  .branch 16 subtree0_5_27 subtree0_5_28
private theorem checked0_5_26 : check 0 270570569 8582 subtree0_5_26=true := by
  unfold subtree0_5_26
  change (check 0 270636105 8582 subtree0_5_27 && check 0 270570569 74118 subtree0_5_28)=true
  simp only [checked0_5_27,checked0_5_28,Bool.true_and]

@[irreducible] private def subtree0_5_24 : Tree :=
  .branch 7 subtree0_5_25 subtree0_5_26
private theorem checked0_5_24 : check 0 270570569 8454 subtree0_5_24=true := by
  unfold subtree0_5_24
  change (check 0 270570697 8454 subtree0_5_25 && check 0 270570569 8582 subtree0_5_26)=true
  simp only [checked0_5_25,checked0_5_26,Bool.true_and]

@[irreducible] private def subtree0_5_22 : Tree :=
  .branch 13 subtree0_5_23 subtree0_5_24
private theorem checked0_5_22 : check 0 270570569 262 subtree0_5_22=true := by
  unfold subtree0_5_22
  change (check 0 270578761 262 subtree0_5_23 && check 0 270570569 8454 subtree0_5_24)=true
  simp only [checked0_5_23,checked0_5_24,Bool.true_and]

@[irreducible] private def subtree0_5_37 : Tree :=
  (.branch 4 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.branch 22 (.cut 1091 652) (.branch 29 (.cut 1091 780) (.small 1)))))))
private theorem checked0_5_37 : check 0 270959689 4358 subtree0_5_37=true := by unfold subtree0_5_37; decide

@[irreducible] private def subtree0_5_39 : Tree :=
  (.branch 9 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 13 (.cut 15 1648) (.branch 20 (.cut 1091 572) (.branch 24 (.cut 15 1744) (.branch 27 (.cut 1091 668) (.branch 31 (.cut 15 1872) (.branch 34 (.cut 1091 796) (.branch 23 (.branch 25 (.cut 1155 540) (.small 0)) (.small 2))))))))))
private theorem checked0_5_39 : check 0 270697673 266502 subtree0_5_39=true := by unfold subtree0_5_39; decide

@[irreducible] private def subtree0_5_41 : Tree :=
  (.branch 13 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.branch 9 (.cut 15 1648) (.branch 19 (.cut 1091 572) (.branch 24 (.cut 15 1760) (.branch 27 (.cut 1091 684) (.branch 31 (.cut 15 1888) (.branch 34 (.cut 1091 812) (.small 0)))))))))
private theorem checked0_5_41 : check 0 270699593 266630 subtree0_5_41=true := by unfold subtree0_5_41; decide

@[irreducible] private def subtree0_5_43 : Tree :=
  (.branch 24 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.branch 9 (.cut 15 1744) (.branch 13 (.cut 15 1760) (.branch 19 (.cut 1091 668) (.branch 20 (.cut 1091 684) (.branch 31 (.cut 15 1984) (.small 0))))))))
private theorem checked0_5_43 : check 0 274891849 268678 subtree0_5_43=true := by unfold subtree0_5_43; decide

@[irreducible] private def subtree0_5_45 : Tree :=
  (.branch 31 (.cut 15 1856) (.branch 34 (.cut 1091 780) (.branch 9 (.cut 15 1872) (.branch 13 (.cut 15 1888) (.branch 19 (.cut 1091 796) (.branch 20 (.cut 1091 812) (.small 0)))))))
private theorem checked0_5_45 : check 0 807568457 4462982 subtree0_5_45=true := by unfold subtree0_5_45; decide

@[irreducible] private def subtree0_5_46 : Tree :=
  (.branch 9 (.branch 16 (.cut 15 1616) (.branch 19 (.branch 4 (.cut 1091 540) (.small 1)) (.branch 20 (.branch 4 (.cut 1091 556) (.small 1)) (.branch 27 (.branch 4 (.cut 1091 652) (.small 1)) (.branch 34 (.branch 4 (.cut 1091 780) (.small 0)) (.small 0)))))) (.branch 13 (.branch 16 (.cut 15 1632) (.branch 19 (.branch 4 (.cut 1091 540) (.small 1)) (.branch 20 (.branch 4 (.cut 1091 556) (.small 1)) (.branch 27 (.branch 4 (.cut 1091 652) (.small 0)) (.small 0))))) (.branch 19 (.branch 4 (.cut 1091 540) (.branch 24 (.branch 16 (.cut 15 1728) (.small 1)) (.branch 31 (.branch 16 (.cut 15 1856) (.small 0)) (.small 0)))) (.branch 20 (.branch 4 (.cut 1091 556) (.branch 24 (.branch 16 (.cut 15 1728) (.small 0)) (.small 0))) (.branch 24 (.branch 16 (.cut 15 1728) (.small 0)) (.small 0))))))
private theorem checked0_5_46 : check 0 270697545 541333894 subtree0_5_46=true := by unfold subtree0_5_46; decide

@[irreducible] private def subtree0_5_44 : Tree :=
  .branch 29 subtree0_5_45 subtree0_5_46
private theorem checked0_5_44 : check 0 270697545 4462982 subtree0_5_44=true := by
  unfold subtree0_5_44
  change (check 0 807568457 4462982 subtree0_5_45 && check 0 270697545 541333894 subtree0_5_46)=true
  simp only [checked0_5_45,checked0_5_46,Bool.true_and]

@[irreducible] private def subtree0_5_42 : Tree :=
  .branch 22 subtree0_5_43 subtree0_5_44
private theorem checked0_5_42 : check 0 270697545 268678 subtree0_5_42=true := by
  unfold subtree0_5_42
  change (check 0 274891849 268678 subtree0_5_43 && check 0 270697545 4462982 subtree0_5_44)=true
  simp only [checked0_5_43,checked0_5_44,Bool.true_and]

@[irreducible] private def subtree0_5_40 : Tree :=
  .branch 11 subtree0_5_41 subtree0_5_42
private theorem checked0_5_40 : check 0 270697545 266630 subtree0_5_40=true := by
  unfold subtree0_5_40
  change (check 0 270699593 266630 subtree0_5_41 && check 0 270697545 268678 subtree0_5_42)=true
  simp only [checked0_5_41,checked0_5_42,Bool.true_and]

@[irreducible] private def subtree0_5_38 : Tree :=
  .branch 7 subtree0_5_39 subtree0_5_40
private theorem checked0_5_38 : check 0 270697545 266502 subtree0_5_38=true := by
  unfold subtree0_5_38
  change (check 0 270697673 266502 subtree0_5_39 && check 0 270697545 266630 subtree0_5_40)=true
  simp only [checked0_5_39,checked0_5_40,Bool.true_and]

@[irreducible] private def subtree0_5_36 : Tree :=
  .branch 18 subtree0_5_37 subtree0_5_38
private theorem checked0_5_36 : check 0 270697545 4358 subtree0_5_36=true := by
  unfold subtree0_5_36
  change (check 0 270959689 4358 subtree0_5_37 && check 0 270697545 266502 subtree0_5_38)=true
  simp only [checked0_5_37,checked0_5_38,Bool.true_and]

@[irreducible] private def subtree0_5_49 : Tree :=
  (.branch 4 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.branch 16 (.cut 1155 588) (.branch 29 (.cut 1155 780) (.small 1)))))))
private theorem checked0_5_49 : check 0 295732297 135430 subtree0_5_49=true := by unfold subtree0_5_49; decide

@[irreducible] private def subtree0_5_51 : Tree :=
  (.branch 9 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 13 (.cut 15 1712) (.branch 18 (.cut 15 1744) (.branch 26 (.cut 1155 572) (.branch 27 (.cut 1155 604) (.branch 31 (.cut 15 1936) (.branch 35 (.cut 1155 796) (.small 2)))))))))
private theorem checked0_5_51 : check 0 278955209 16912646 subtree0_5_51=true := by unfold subtree0_5_51; decide

@[irreducible] private def subtree0_5_53 : Tree :=
  (.branch 13 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.branch 9 (.cut 15 1712) (.branch 18 (.cut 15 1760) (.branch 25 (.cut 1155 572) (.branch 27 (.cut 1155 620) (.branch 31 (.cut 15 1952) (.branch 35 (.cut 1155 812) (.small 0)))))))))
private theorem checked0_5_53 : check 0 278957129 16912774 subtree0_5_53=true := by unfold subtree0_5_53; decide

@[irreducible] private def subtree0_5_55 : Tree :=
  (.branch 18 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.branch 9 (.cut 15 1744) (.branch 13 (.cut 15 1760) (.branch 25 (.cut 1155 604) (.branch 26 (.cut 1155 620) (.branch 31 (.cut 15 1984) (.small 0))))))))
private theorem checked0_5_55 : check 0 279020617 16914822 subtree0_5_55=true := by unfold subtree0_5_55; decide

@[irreducible] private def subtree0_5_57 : Tree :=
  (.branch 31 (.cut 15 1920) (.branch 35 (.cut 1155 780) (.small 2)))
private theorem checked0_5_57 : check 0 815825993 16980358 subtree0_5_57=true := by unfold subtree0_5_57; decide

@[irreducible] private def subtree0_5_58 : Tree :=
  (.branch 9 (.branch 22 (.cut 15 1680) (.branch 25 (.branch 4 (.cut 1155 540) (.small 1)) (.branch 26 (.branch 4 (.cut 1155 556) (.small 1)) (.branch 27 (.branch 4 (.cut 1155 588) (.small 1)) (.branch 35 (.branch 4 (.cut 1155 780) (.small 0)) (.small 0)))))) (.branch 13 (.branch 22 (.cut 15 1696) (.branch 25 (.branch 4 (.cut 1155 540) (.small 1)) (.branch 26 (.branch 4 (.cut 1155 556) (.small 1)) (.branch 27 (.branch 4 (.cut 1155 588) (.small 0)) (.small 0))))) (.branch 18 (.branch 22 (.cut 15 1728) (.branch 25 (.branch 4 (.cut 1155 540) (.small 1)) (.branch 26 (.branch 4 (.cut 1155 556) (.small 0)) (.small 0)))) (.branch 25 (.branch 4 (.cut 1155 540) (.branch 31 (.branch 22 (.cut 15 1920) (.small 0)) (.small 0))) (.branch 26 (.branch 4 (.cut 1155 556) (.small 0)) (.small 0))))))
private theorem checked0_5_58 : check 0 278955081 553851270 subtree0_5_58=true := by unfold subtree0_5_58; decide

@[irreducible] private def subtree0_5_56 : Tree :=
  .branch 29 subtree0_5_57 subtree0_5_58
private theorem checked0_5_56 : check 0 278955081 16980358 subtree0_5_56=true := by
  unfold subtree0_5_56
  change (check 0 815825993 16980358 subtree0_5_57 && check 0 278955081 553851270 subtree0_5_58)=true
  simp only [checked0_5_57,checked0_5_58,Bool.true_and]

@[irreducible] private def subtree0_5_54 : Tree :=
  .branch 16 subtree0_5_55 subtree0_5_56
private theorem checked0_5_54 : check 0 278955081 16914822 subtree0_5_54=true := by
  unfold subtree0_5_54
  change (check 0 279020617 16914822 subtree0_5_55 && check 0 278955081 16980358 subtree0_5_56)=true
  simp only [checked0_5_55,checked0_5_56,Bool.true_and]

@[irreducible] private def subtree0_5_52 : Tree :=
  .branch 11 subtree0_5_53 subtree0_5_54
private theorem checked0_5_52 : check 0 278955081 16912774 subtree0_5_52=true := by
  unfold subtree0_5_52
  change (check 0 278957129 16912774 subtree0_5_53 && check 0 278955081 16914822 subtree0_5_54)=true
  simp only [checked0_5_53,checked0_5_54,Bool.true_and]

@[irreducible] private def subtree0_5_50 : Tree :=
  .branch 7 subtree0_5_51 subtree0_5_52
private theorem checked0_5_50 : check 0 278955081 16912646 subtree0_5_50=true := by
  unfold subtree0_5_50
  change (check 0 278955209 16912646 subtree0_5_51 && check 0 278955081 16912774 subtree0_5_52)=true
  simp only [checked0_5_51,checked0_5_52,Bool.true_and]

@[irreducible] private def subtree0_5_48 : Tree :=
  .branch 24 subtree0_5_49 subtree0_5_50
private theorem checked0_5_48 : check 0 278955081 135430 subtree0_5_48=true := by
  unfold subtree0_5_48
  change (check 0 295732297 135430 subtree0_5_49 && check 0 278955081 16912646 subtree0_5_50)=true
  simp only [checked0_5_49,checked0_5_50,Bool.true_and]

@[irreducible] private def subtree0_5_59 : Tree :=
  (.branch 30 (.branch 31 (.branch 4 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.branch 16 (.cut 1283 588) (.branch 22 (.cut 1283 652) (.small 1))))))) (.small 2)) (.small 2))
private theorem checked0_5_59 : check 0 270566473 8524038 subtree0_5_59=true := by unfold subtree0_5_59; decide

@[irreducible] private def subtree0_5_47 : Tree :=
  .branch 23 subtree0_5_48 subtree0_5_59
private theorem checked0_5_47 : check 0 270566473 135430 subtree0_5_47=true := by
  unfold subtree0_5_47
  change (check 0 278955081 135430 subtree0_5_48 && check 0 270566473 8524038 subtree0_5_59)=true
  simp only [checked0_5_48,checked0_5_59,Bool.true_and]

@[irreducible] private def subtree0_5_35 : Tree :=
  .branch 17 subtree0_5_36 subtree0_5_47
private theorem checked0_5_35 : check 0 270566473 4358 subtree0_5_35=true := by
  unfold subtree0_5_35
  change (check 0 270697545 4358 subtree0_5_36 && check 0 270566473 135430 subtree0_5_47)=true
  simp only [checked0_5_36,checked0_5_47,Bool.true_and]

@[irreducible] private def subtree0_5_21 : Tree :=
  .branch 12 subtree0_5_22 subtree0_5_35
private theorem checked0_5_21 : check 0 270566473 262 subtree0_5_21=true := by
  unfold subtree0_5_21
  change (check 0 270570569 262 subtree0_5_22 && check 0 270566473 4358 subtree0_5_35)=true
  simp only [checked0_5_22,checked0_5_35,Bool.true_and]

@[irreducible] private def subtree0_5_7 : Tree :=
  .branch 8 subtree0_5_8 subtree0_5_21
private theorem checked0_5_7 : check 0 270566473 6 subtree0_5_7=true := by
  unfold subtree0_5_7
  change (check 0 270566729 6 subtree0_5_8 && check 0 270566473 262 subtree0_5_21)=true
  simp only [checked0_5_8,checked0_5_21,Bool.true_and]

@[irreducible] private def subtree0_5_5 : Tree :=
  .branch 2 subtree0_5_6 subtree0_5_7
private theorem checked0_5_5 : check 0 270566473 2 subtree0_5_5=true := by
  unfold subtree0_5_5
  change (check 0 270566477 2 subtree0_5_6 && check 0 270566473 6 subtree0_5_7)=true
  simp only [checked0_5_6,checked0_5_7,Bool.true_and]

@[irreducible] private def subtree0_5_61 : Tree :=
  (.cut 1027 524)
private theorem checked0_5_61 : check 0 2131021 268435458 subtree0_5_61=true := by unfold subtree0_5_61; decide

@[irreducible] private def subtree0_5_63 : Tree :=
  (.branch 9 (.branch 4 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.small 0))))) (.branch 11 (.branch 13 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 18 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1680) (.small 0)) (.small 0)))))
private theorem checked0_5_63 : check 0 2131273 268435462 subtree0_5_63=true := by unfold subtree0_5_63; decide

@[irreducible] private def subtree0_5_65 : Tree :=
  (.branch 13 (.branch 4 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 18 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1696) (.small 0)) (.small 0)))))
private theorem checked0_5_65 : check 0 2135113 268435718 subtree0_5_65=true := by unfold subtree0_5_65; decide

@[irreducible] private def subtree0_5_67 : Tree :=
  (.branch 18 (.branch 4 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 13 (.cut 15 1648) (.small 0)))) (.branch 11 (.branch 13 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1728) (.small 0)) (.small 0)))))
private theorem checked0_5_67 : check 0 2262089 268439814 subtree0_5_67=true := by unfold subtree0_5_67; decide

@[irreducible] private def subtree0_5_68 : Tree :=
  (.branch 23 (.branch 24 (.branch 4 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 13 (.cut 15 1712) (.small 0)))) (.branch 11 (.branch 13 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.small 0))) (.branch 16 (.branch 18 (.cut 15 1728) (.small 0)) (.small 0))))) (.branch 30 (.branch 4 (.branch 31 (.cut 1283 524) (.small 2)) (.branch 7 (.branch 31 (.cut 1283 540) (.small 2)) (.branch 11 (.branch 31 (.cut 1283 556) (.small 2)) (.branch 16 (.branch 31 (.cut 1283 588) (.small 2)) (.small 0))))) (.small 2)))
private theorem checked0_5_68 : check 0 2131017 268570886 subtree0_5_68=true := by unfold subtree0_5_68; decide

@[irreducible] private def subtree0_5_66 : Tree :=
  .branch 17 subtree0_5_67 subtree0_5_68
private theorem checked0_5_66 : check 0 2131017 268439814 subtree0_5_66=true := by
  unfold subtree0_5_66
  change (check 0 2262089 268439814 subtree0_5_67 && check 0 2131017 268570886 subtree0_5_68)=true
  simp only [checked0_5_67,checked0_5_68,Bool.true_and]

@[irreducible] private def subtree0_5_64 : Tree :=
  .branch 12 subtree0_5_65 subtree0_5_66
private theorem checked0_5_64 : check 0 2131017 268435718 subtree0_5_64=true := by
  unfold subtree0_5_64
  change (check 0 2135113 268435718 subtree0_5_65 && check 0 2131017 268439814 subtree0_5_66)=true
  simp only [checked0_5_65,checked0_5_66,Bool.true_and]

@[irreducible] private def subtree0_5_62 : Tree :=
  .branch 8 subtree0_5_63 subtree0_5_64
private theorem checked0_5_62 : check 0 2131017 268435462 subtree0_5_62=true := by
  unfold subtree0_5_62
  change (check 0 2131273 268435462 subtree0_5_63 && check 0 2131017 268435718 subtree0_5_64)=true
  simp only [checked0_5_63,checked0_5_64,Bool.true_and]

@[irreducible] private def subtree0_5_60 : Tree :=
  .branch 2 subtree0_5_61 subtree0_5_62
private theorem checked0_5_60 : check 0 2131017 268435458 subtree0_5_60=true := by
  unfold subtree0_5_60
  change (check 0 2131021 268435458 subtree0_5_61 && check 0 2131017 268435462 subtree0_5_62)=true
  simp only [checked0_5_61,checked0_5_62,Bool.true_and]

@[irreducible] private def subtree0_5_4 : Tree :=
  .branch 28 subtree0_5_5 subtree0_5_60
private theorem checked0_5_4 : check 0 2131017 2 subtree0_5_4=true := by
  unfold subtree0_5_4
  change (check 0 270566473 2 subtree0_5_5 && check 0 2131017 268435458 subtree0_5_60)=true
  simp only [checked0_5_5,checked0_5_60,Bool.true_and]

@[irreducible] private def subtree0_5_71 : Tree :=
  (.cut 1027 524)
private theorem checked0_5_71 : check 0 268469325 2097154 subtree0_5_71=true := by unfold subtree0_5_71; decide

@[irreducible] private def subtree0_5_73 : Tree :=
  (.branch 9 (.branch 4 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 16 (.cut 1043 588) (.small 0))))) (.branch 11 (.branch 13 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 18 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1808) (.small 0)) (.small 0)))))
private theorem checked0_5_73 : check 0 268469577 2097158 subtree0_5_73=true := by unfold subtree0_5_73; decide

@[irreducible] private def subtree0_5_75 : Tree :=
  (.branch 13 (.branch 4 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 16 (.cut 1059 588) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 18 (.cut 15 1648) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1824) (.small 0)) (.small 0)))))
private theorem checked0_5_75 : check 0 268473417 2097414 subtree0_5_75=true := by unfold subtree0_5_75; decide

@[irreducible] private def subtree0_5_77 : Tree :=
  (.branch 18 (.branch 4 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 11 (.cut 1091 556) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 13 (.cut 15 1648) (.small 0)))) (.branch 11 (.branch 13 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1856) (.small 0)) (.small 0)))))
private theorem checked0_5_77 : check 0 268600393 2101510 subtree0_5_77=true := by unfold subtree0_5_77; decide

@[irreducible] private def subtree0_5_78 : Tree :=
  (.branch 30 (.branch 31 (.branch 4 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1808) (.branch 32 (.cut 1283 540) (.branch 13 (.cut 15 1840) (.small 0)))) (.branch 11 (.branch 13 (.cut 15 1824) (.branch 33 (.cut 1283 556) (.small 0))) (.branch 16 (.branch 18 (.cut 15 1856) (.small 0)) (.small 0))))) (.branch 23 (.branch 4 (.branch 24 (.cut 1155 524) (.small 2)) (.branch 7 (.branch 24 (.cut 1155 540) (.small 2)) (.branch 11 (.branch 24 (.cut 1155 556) (.small 2)) (.branch 16 (.branch 24 (.cut 1155 588) (.small 2)) (.small 0))))) (.small 2)))
private theorem checked0_5_78 : check 0 268469321 2232582 subtree0_5_78=true := by unfold subtree0_5_78; decide

@[irreducible] private def subtree0_5_76 : Tree :=
  .branch 17 subtree0_5_77 subtree0_5_78
private theorem checked0_5_76 : check 0 268469321 2101510 subtree0_5_76=true := by
  unfold subtree0_5_76
  change (check 0 268600393 2101510 subtree0_5_77 && check 0 268469321 2232582 subtree0_5_78)=true
  simp only [checked0_5_77,checked0_5_78,Bool.true_and]

@[irreducible] private def subtree0_5_74 : Tree :=
  .branch 12 subtree0_5_75 subtree0_5_76
private theorem checked0_5_74 : check 0 268469321 2097414 subtree0_5_74=true := by
  unfold subtree0_5_74
  change (check 0 268473417 2097414 subtree0_5_75 && check 0 268469321 2101510 subtree0_5_76)=true
  simp only [checked0_5_75,checked0_5_76,Bool.true_and]

@[irreducible] private def subtree0_5_72 : Tree :=
  .branch 8 subtree0_5_73 subtree0_5_74
private theorem checked0_5_72 : check 0 268469321 2097158 subtree0_5_72=true := by
  unfold subtree0_5_72
  change (check 0 268469577 2097158 subtree0_5_73 && check 0 268469321 2097414 subtree0_5_74)=true
  simp only [checked0_5_73,checked0_5_74,Bool.true_and]

@[irreducible] private def subtree0_5_70 : Tree :=
  .branch 2 subtree0_5_71 subtree0_5_72
private theorem checked0_5_70 : check 0 268469321 2097154 subtree0_5_70=true := by
  unfold subtree0_5_70
  change (check 0 268469325 2097154 subtree0_5_71 && check 0 268469321 2097158 subtree0_5_72)=true
  simp only [checked0_5_71,checked0_5_72,Bool.true_and]

@[irreducible] private def subtree0_5_79 : Tree :=
  (.small 0)
private theorem checked0_5_79 : check 0 33865 270532610 subtree0_5_79=true := by unfold subtree0_5_79; decide

@[irreducible] private def subtree0_5_69 : Tree :=
  .branch 28 subtree0_5_70 subtree0_5_79
private theorem checked0_5_69 : check 0 33865 2097154 subtree0_5_69=true := by
  unfold subtree0_5_69
  change (check 0 268469321 2097154 subtree0_5_70 && check 0 33865 270532610 subtree0_5_79)=true
  simp only [checked0_5_70,checked0_5_79,Bool.true_and]

@[irreducible] private def subtree0_5_3 : Tree :=
  .branch 21 subtree0_5_4 subtree0_5_69
private theorem checked0_5_3 : check 0 33865 2 subtree0_5_3=true := by
  unfold subtree0_5_3
  change (check 0 2131017 2 subtree0_5_4 && check 0 33865 2097154 subtree0_5_69)=true
  simp only [checked0_5_4,checked0_5_69,Bool.true_and]

@[irreducible] private def subtree0_5_83 : Tree :=
  (.cut 1027 524)
private theorem checked0_5_83 : check 0 270533709 32770 subtree0_5_83=true := by unfold subtree0_5_83; decide

@[irreducible] private def subtree0_5_85 : Tree :=
  (.branch 9 (.branch 4 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 11 (.cut 1043 556) (.branch 22 (.cut 1043 652) (.small 0))))) (.branch 11 (.branch 13 (.cut 15 1584) (.branch 14 (.cut 1043 556) (.branch 24 (.cut 15 1712) (.small 0)))) (.branch 22 (.branch 24 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1808) (.small 0)) (.small 0)))))
private theorem checked0_5_85 : check 0 270533961 32774 subtree0_5_85=true := by unfold subtree0_5_85; decide

@[irreducible] private def subtree0_5_87 : Tree :=
  (.branch 13 (.branch 4 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 7 (.cut 1059 540) (.branch 22 (.cut 1059 652) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1584) (.branch 14 (.cut 1059 540) (.branch 24 (.cut 15 1712) (.small 0)))) (.branch 22 (.branch 24 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1824) (.small 0)) (.small 0)))))
private theorem checked0_5_87 : check 0 270537801 33030 subtree0_5_87=true := by unfold subtree0_5_87; decide

@[irreducible] private def subtree0_5_89 : Tree :=
  (.branch 24 (.branch 4 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 11 (.cut 1155 556) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 13 (.cut 15 1712) (.small 0)))) (.branch 11 (.branch 13 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1920) (.small 0)) (.small 0)))))
private theorem checked0_5_89 : check 0 278922313 37126 subtree0_5_89=true := by unfold subtree0_5_89; decide

@[irreducible] private def subtree0_5_90 : Tree :=
  (.branch 30 (.branch 31 (.branch 4 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 11 (.cut 1283 556) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1808) (.branch 32 (.cut 1283 540) (.branch 13 (.cut 15 1840) (.small 0)))) (.branch 11 (.branch 13 (.cut 15 1824) (.branch 33 (.cut 1283 556) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1920) (.small 0)) (.small 0))))) (.branch 17 (.branch 4 (.branch 18 (.cut 1091 524) (.small 2)) (.branch 7 (.branch 18 (.cut 1091 540) (.small 2)) (.branch 11 (.branch 18 (.cut 1091 556) (.small 2)) (.branch 22 (.branch 18 (.cut 1091 652) (.small 2)) (.small 0))))) (.small 2)))
private theorem checked0_5_90 : check 0 270533705 8425734 subtree0_5_90=true := by unfold subtree0_5_90; decide

@[irreducible] private def subtree0_5_88 : Tree :=
  .branch 23 subtree0_5_89 subtree0_5_90
private theorem checked0_5_88 : check 0 270533705 37126 subtree0_5_88=true := by
  unfold subtree0_5_88
  change (check 0 278922313 37126 subtree0_5_89 && check 0 270533705 8425734 subtree0_5_90)=true
  simp only [checked0_5_89,checked0_5_90,Bool.true_and]

@[irreducible] private def subtree0_5_86 : Tree :=
  .branch 12 subtree0_5_87 subtree0_5_88
private theorem checked0_5_86 : check 0 270533705 33030 subtree0_5_86=true := by
  unfold subtree0_5_86
  change (check 0 270537801 33030 subtree0_5_87 && check 0 270533705 37126 subtree0_5_88)=true
  simp only [checked0_5_87,checked0_5_88,Bool.true_and]

@[irreducible] private def subtree0_5_84 : Tree :=
  .branch 8 subtree0_5_85 subtree0_5_86
private theorem checked0_5_84 : check 0 270533705 32774 subtree0_5_84=true := by
  unfold subtree0_5_84
  change (check 0 270533961 32774 subtree0_5_85 && check 0 270533705 33030 subtree0_5_86)=true
  simp only [checked0_5_85,checked0_5_86,Bool.true_and]

@[irreducible] private def subtree0_5_82 : Tree :=
  .branch 2 subtree0_5_83 subtree0_5_84
private theorem checked0_5_82 : check 0 270533705 32770 subtree0_5_82=true := by
  unfold subtree0_5_82
  change (check 0 270533709 32770 subtree0_5_83 && check 0 270533705 32774 subtree0_5_84)=true
  simp only [checked0_5_83,checked0_5_84,Bool.true_and]

@[irreducible] private def subtree0_5_91 : Tree :=
  (.small 0)
private theorem checked0_5_91 : check 0 2098249 268468226 subtree0_5_91=true := by unfold subtree0_5_91; decide

@[irreducible] private def subtree0_5_81 : Tree :=
  .branch 28 subtree0_5_82 subtree0_5_91
private theorem checked0_5_81 : check 0 2098249 32770 subtree0_5_81=true := by
  unfold subtree0_5_81
  change (check 0 270533705 32770 subtree0_5_82 && check 0 2098249 268468226 subtree0_5_91)=true
  simp only [checked0_5_82,checked0_5_91,Bool.true_and]

@[irreducible] private def subtree0_5_92 : Tree :=
  (.small 0)
private theorem checked0_5_92 : check 0 1097 2129922 subtree0_5_92=true := by unfold subtree0_5_92; decide

@[irreducible] private def subtree0_5_80 : Tree :=
  .branch 21 subtree0_5_81 subtree0_5_92
private theorem checked0_5_80 : check 0 1097 32770 subtree0_5_80=true := by
  unfold subtree0_5_80
  change (check 0 2098249 32770 subtree0_5_81 && check 0 1097 2129922 subtree0_5_92)=true
  simp only [checked0_5_81,checked0_5_92,Bool.true_and]

@[irreducible] private def subtree0_5_2 : Tree :=
  .branch 15 subtree0_5_3 subtree0_5_80
private theorem checked0_5_2 : check 0 1097 2 subtree0_5_2=true := by
  unfold subtree0_5_2
  change (check 0 33865 2 subtree0_5_3 && check 0 1097 32770 subtree0_5_80)=true
  simp only [checked0_5_3,checked0_5_80,Bool.true_and]

@[irreducible] private def subtree0_5_97 : Tree :=
  (.cut 1027 524)
private theorem checked0_5_97 : check 0 270565453 1026 subtree0_5_97=true := by unfold subtree0_5_97; decide

@[irreducible] private def subtree0_5_99 : Tree :=
  (.branch 9 (.branch 4 (.cut 1043 524) (.branch 7 (.cut 15 1552) (.branch 16 (.cut 1043 588) (.branch 22 (.cut 1043 652) (.small 0))))) (.branch 16 (.branch 18 (.cut 15 1616) (.branch 19 (.cut 1043 588) (.branch 24 (.cut 15 1744) (.small 0)))) (.branch 22 (.branch 24 (.cut 15 1680) (.branch 25 (.cut 1043 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1808) (.small 0)) (.small 0)))))
private theorem checked0_5_99 : check 0 270565705 1030 subtree0_5_99=true := by unfold subtree0_5_99; decide

@[irreducible] private def subtree0_5_101 : Tree :=
  (.branch 18 (.branch 4 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 7 (.cut 1091 540) (.branch 22 (.cut 1091 652) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1616) (.branch 19 (.cut 1091 540) (.branch 24 (.cut 15 1744) (.small 0)))) (.branch 22 (.branch 24 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1856) (.small 0)) (.small 0)))))
private theorem checked0_5_101 : check 0 270696521 1286 subtree0_5_101=true := by unfold subtree0_5_101; decide

@[irreducible] private def subtree0_5_103 : Tree :=
  (.branch 24 (.branch 4 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 7 (.cut 1155 540) (.branch 16 (.cut 1155 588) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1680) (.branch 25 (.cut 1155 540) (.branch 18 (.cut 15 1744) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1920) (.small 0)) (.small 0)))))
private theorem checked0_5_103 : check 0 278954057 132358 subtree0_5_103=true := by unfold subtree0_5_103; decide

@[irreducible] private def subtree0_5_104 : Tree :=
  (.branch 30 (.branch 31 (.branch 4 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 7 (.cut 1283 540) (.branch 16 (.cut 1283 588) (.small 0))))) (.branch 7 (.branch 9 (.cut 15 1808) (.branch 32 (.cut 1283 540) (.branch 18 (.cut 15 1872) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1856) (.branch 34 (.cut 1283 588) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1920) (.small 0)) (.small 0))))) (.branch 12 (.branch 4 (.branch 13 (.cut 1059 524) (.small 2)) (.branch 7 (.branch 13 (.cut 1059 540) (.small 2)) (.branch 16 (.branch 13 (.cut 1059 588) (.small 2)) (.branch 22 (.branch 13 (.cut 1059 652) (.small 2)) (.small 0))))) (.small 2)))
private theorem checked0_5_104 : check 0 270565449 8520966 subtree0_5_104=true := by unfold subtree0_5_104; decide

@[irreducible] private def subtree0_5_102 : Tree :=
  .branch 23 subtree0_5_103 subtree0_5_104
private theorem checked0_5_102 : check 0 270565449 132358 subtree0_5_102=true := by
  unfold subtree0_5_102
  change (check 0 278954057 132358 subtree0_5_103 && check 0 270565449 8520966 subtree0_5_104)=true
  simp only [checked0_5_103,checked0_5_104,Bool.true_and]

@[irreducible] private def subtree0_5_100 : Tree :=
  .branch 17 subtree0_5_101 subtree0_5_102
private theorem checked0_5_100 : check 0 270565449 1286 subtree0_5_100=true := by
  unfold subtree0_5_100
  change (check 0 270696521 1286 subtree0_5_101 && check 0 270565449 132358 subtree0_5_102)=true
  simp only [checked0_5_101,checked0_5_102,Bool.true_and]

@[irreducible] private def subtree0_5_98 : Tree :=
  .branch 8 subtree0_5_99 subtree0_5_100
private theorem checked0_5_98 : check 0 270565449 1030 subtree0_5_98=true := by
  unfold subtree0_5_98
  change (check 0 270565705 1030 subtree0_5_99 && check 0 270565449 1286 subtree0_5_100)=true
  simp only [checked0_5_99,checked0_5_100,Bool.true_and]

@[irreducible] private def subtree0_5_96 : Tree :=
  .branch 2 subtree0_5_97 subtree0_5_98
private theorem checked0_5_96 : check 0 270565449 1026 subtree0_5_96=true := by
  unfold subtree0_5_96
  change (check 0 270565453 1026 subtree0_5_97 && check 0 270565449 1030 subtree0_5_98)=true
  simp only [checked0_5_97,checked0_5_98,Bool.true_and]

@[irreducible] private def subtree0_5_105 : Tree :=
  (.small 0)
private theorem checked0_5_105 : check 0 2129993 268436482 subtree0_5_105=true := by unfold subtree0_5_105; decide

@[irreducible] private def subtree0_5_95 : Tree :=
  .branch 28 subtree0_5_96 subtree0_5_105
private theorem checked0_5_95 : check 0 2129993 1026 subtree0_5_95=true := by
  unfold subtree0_5_95
  change (check 0 270565449 1026 subtree0_5_96 && check 0 2129993 268436482 subtree0_5_105)=true
  simp only [checked0_5_96,checked0_5_105,Bool.true_and]

@[irreducible] private def subtree0_5_106 : Tree :=
  (.small 0)
private theorem checked0_5_106 : check 0 32841 2098178 subtree0_5_106=true := by unfold subtree0_5_106; decide

@[irreducible] private def subtree0_5_94 : Tree :=
  .branch 21 subtree0_5_95 subtree0_5_106
private theorem checked0_5_94 : check 0 32841 1026 subtree0_5_94=true := by
  unfold subtree0_5_94
  change (check 0 2129993 1026 subtree0_5_95 && check 0 32841 2098178 subtree0_5_106)=true
  simp only [checked0_5_95,checked0_5_106,Bool.true_and]

@[irreducible] private def subtree0_5_107 : Tree :=
  (.small 0)
private theorem checked0_5_107 : check 0 73 33794 subtree0_5_107=true := by unfold subtree0_5_107; decide

@[irreducible] private def subtree0_5_93 : Tree :=
  .branch 15 subtree0_5_94 subtree0_5_107
private theorem checked0_5_93 : check 0 73 1026 subtree0_5_93=true := by
  unfold subtree0_5_93
  change (check 0 32841 1026 subtree0_5_94 && check 0 73 33794 subtree0_5_107)=true
  simp only [checked0_5_94,checked0_5_107,Bool.true_and]

@[irreducible] private def subtree0_5_1 : Tree :=
  .branch 10 subtree0_5_2 subtree0_5_93
private theorem checked0_5_1 : check 0 73 2 subtree0_5_1=true := by
  unfold subtree0_5_1
  change (check 0 1097 2 subtree0_5_2 && check 0 73 1026 subtree0_5_93)=true
  simp only [checked0_5_2,checked0_5_93,Bool.true_and]

@[irreducible] private def subtree0_5_113 : Tree :=
  (.cut 1027 524)
private theorem checked0_5_113 : check 0 270566413 66 subtree0_5_113=true := by unfold subtree0_5_113; decide

@[irreducible] private def subtree0_5_115 : Tree :=
  (.branch 13 (.branch 4 (.cut 1059 524) (.branch 11 (.cut 15 1568) (.branch 16 (.cut 1059 588) (.branch 22 (.cut 1059 652) (.small 0))))) (.branch 16 (.branch 18 (.cut 15 1632) (.branch 20 (.cut 1059 588) (.branch 24 (.cut 15 1760) (.small 0)))) (.branch 22 (.branch 24 (.cut 15 1696) (.branch 26 (.cut 1059 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1824) (.small 0)) (.small 0)))))
private theorem checked0_5_115 : check 0 270570505 70 subtree0_5_115=true := by unfold subtree0_5_115; decide

@[irreducible] private def subtree0_5_117 : Tree :=
  (.branch 18 (.branch 4 (.cut 1091 524) (.branch 16 (.cut 15 1600) (.branch 11 (.cut 1091 556) (.branch 22 (.cut 1091 652) (.small 0))))) (.branch 11 (.branch 13 (.cut 15 1632) (.branch 20 (.cut 1091 556) (.branch 24 (.cut 15 1760) (.small 0)))) (.branch 22 (.branch 24 (.cut 15 1728) (.branch 27 (.cut 1091 652) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1856) (.small 0)) (.small 0)))))
private theorem checked0_5_117 : check 0 270697481 4166 subtree0_5_117=true := by unfold subtree0_5_117; decide

@[irreducible] private def subtree0_5_119 : Tree :=
  (.branch 24 (.branch 4 (.cut 1155 524) (.branch 22 (.cut 15 1664) (.branch 11 (.cut 1155 556) (.branch 16 (.cut 1155 588) (.small 0))))) (.branch 11 (.branch 13 (.cut 15 1696) (.branch 26 (.cut 1155 556) (.branch 18 (.cut 15 1760) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1728) (.branch 27 (.cut 1155 588) (.small 0))) (.branch 29 (.branch 31 (.cut 15 1920) (.small 0)) (.small 0)))))
private theorem checked0_5_119 : check 0 278955017 135238 subtree0_5_119=true := by unfold subtree0_5_119; decide

@[irreducible] private def subtree0_5_120 : Tree :=
  (.branch 30 (.branch 31 (.branch 4 (.cut 1283 524) (.branch 29 (.cut 15 1792) (.branch 11 (.cut 1283 556) (.branch 16 (.cut 1283 588) (.small 0))))) (.branch 11 (.branch 13 (.cut 15 1824) (.branch 33 (.cut 1283 556) (.branch 18 (.cut 15 1888) (.small 0)))) (.branch 16 (.branch 18 (.cut 15 1856) (.branch 34 (.cut 1283 588) (.small 0))) (.branch 22 (.branch 24 (.cut 15 1920) (.small 0)) (.small 0))))) (.branch 8 (.branch 4 (.branch 9 (.cut 1043 524) (.small 2)) (.branch 11 (.branch 9 (.cut 1043 556) (.small 2)) (.branch 16 (.branch 9 (.cut 1043 588) (.small 2)) (.branch 22 (.branch 9 (.cut 1043 652) (.small 2)) (.small 0))))) (.small 2)))
private theorem checked0_5_120 : check 0 270566409 8523846 subtree0_5_120=true := by unfold subtree0_5_120; decide

@[irreducible] private def subtree0_5_118 : Tree :=
  .branch 23 subtree0_5_119 subtree0_5_120
private theorem checked0_5_118 : check 0 270566409 135238 subtree0_5_118=true := by
  unfold subtree0_5_118
  change (check 0 278955017 135238 subtree0_5_119 && check 0 270566409 8523846 subtree0_5_120)=true
  simp only [checked0_5_119,checked0_5_120,Bool.true_and]

@[irreducible] private def subtree0_5_116 : Tree :=
  .branch 17 subtree0_5_117 subtree0_5_118
private theorem checked0_5_116 : check 0 270566409 4166 subtree0_5_116=true := by
  unfold subtree0_5_116
  change (check 0 270697481 4166 subtree0_5_117 && check 0 270566409 135238 subtree0_5_118)=true
  simp only [checked0_5_117,checked0_5_118,Bool.true_and]

@[irreducible] private def subtree0_5_114 : Tree :=
  .branch 12 subtree0_5_115 subtree0_5_116
private theorem checked0_5_114 : check 0 270566409 70 subtree0_5_114=true := by
  unfold subtree0_5_114
  change (check 0 270570505 70 subtree0_5_115 && check 0 270566409 4166 subtree0_5_116)=true
  simp only [checked0_5_115,checked0_5_116,Bool.true_and]

@[irreducible] private def subtree0_5_112 : Tree :=
  .branch 2 subtree0_5_113 subtree0_5_114
private theorem checked0_5_112 : check 0 270566409 66 subtree0_5_112=true := by
  unfold subtree0_5_112
  change (check 0 270566413 66 subtree0_5_113 && check 0 270566409 70 subtree0_5_114)=true
  simp only [checked0_5_113,checked0_5_114,Bool.true_and]

@[irreducible] private def subtree0_5_121 : Tree :=
  (.small 0)
private theorem checked0_5_121 : check 0 2130953 268435522 subtree0_5_121=true := by unfold subtree0_5_121; decide

@[irreducible] private def subtree0_5_111 : Tree :=
  .branch 28 subtree0_5_112 subtree0_5_121
private theorem checked0_5_111 : check 0 2130953 66 subtree0_5_111=true := by
  unfold subtree0_5_111
  change (check 0 270566409 66 subtree0_5_112 && check 0 2130953 268435522 subtree0_5_121)=true
  simp only [checked0_5_112,checked0_5_121,Bool.true_and]

@[irreducible] private def subtree0_5_122 : Tree :=
  (.small 0)
private theorem checked0_5_122 : check 0 33801 2097218 subtree0_5_122=true := by unfold subtree0_5_122; decide

@[irreducible] private def subtree0_5_110 : Tree :=
  .branch 21 subtree0_5_111 subtree0_5_122
private theorem checked0_5_110 : check 0 33801 66 subtree0_5_110=true := by
  unfold subtree0_5_110
  change (check 0 2130953 66 subtree0_5_111 && check 0 33801 2097218 subtree0_5_122)=true
  simp only [checked0_5_111,checked0_5_122,Bool.true_and]

@[irreducible] private def subtree0_5_123 : Tree :=
  (.small 0)
private theorem checked0_5_123 : check 0 1033 32834 subtree0_5_123=true := by unfold subtree0_5_123; decide

@[irreducible] private def subtree0_5_109 : Tree :=
  .branch 15 subtree0_5_110 subtree0_5_123
private theorem checked0_5_109 : check 0 1033 66 subtree0_5_109=true := by
  unfold subtree0_5_109
  change (check 0 33801 66 subtree0_5_110 && check 0 1033 32834 subtree0_5_123)=true
  simp only [checked0_5_110,checked0_5_123,Bool.true_and]

@[irreducible] private def subtree0_5_124 : Tree :=
  (.small 0)
private theorem checked0_5_124 : check 0 9 1090 subtree0_5_124=true := by unfold subtree0_5_124; decide

@[irreducible] private def subtree0_5_108 : Tree :=
  .branch 10 subtree0_5_109 subtree0_5_124
private theorem checked0_5_108 : check 0 9 66 subtree0_5_108=true := by
  unfold subtree0_5_108
  change (check 0 1033 66 subtree0_5_109 && check 0 9 1090 subtree0_5_124)=true
  simp only [checked0_5_109,checked0_5_124,Bool.true_and]

@[irreducible] def tree0_5 : Tree :=
  .branch 6 subtree0_5_1 subtree0_5_108
theorem tested0_5 : check 0 9 2 tree0_5=true := by
  unfold tree0_5
  change (check 0 73 2 subtree0_5_1 && check 0 9 66 subtree0_5_108)=true
  simp only [checked0_5_1,checked0_5_108,Bool.true_and]

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_5
