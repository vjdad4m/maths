import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] private def subtree0_6_2 : Tree :=
  (.branch 15 (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.small 1)))))) (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.small 1))))))) (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.small 1)))))) (.small 0))) (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 22 (.cut 1027 652) (.small 1)))))) (.small 0)) (.small 0)))
private theorem checked0_6_2 : check 0 1098 1 subtree0_6_2=true := by unfold subtree0_6_2; decide

@[irreducible] private def subtree0_6_3 : Tree :=
  (.branch 15 (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.small 1)))))) (.small 0)) (.small 0)) (.small 0))
private theorem checked0_6_3 : check 0 74 1025 subtree0_6_3=true := by unfold subtree0_6_3; decide

@[irreducible] private def subtree0_6_1 : Tree :=
  .branch 10 subtree0_6_2 subtree0_6_3
private theorem checked0_6_1 : check 0 74 1 subtree0_6_1=true := by
  unfold subtree0_6_1
  change (check 0 1098 1 subtree0_6_2 && check 0 74 1025 subtree0_6_3)=true
  simp only [checked0_6_2,checked0_6_3,Bool.true_and]

@[irreducible] private def subtree0_6_4 : Tree :=
  (.branch 10 (.branch 15 (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.small 1)))))) (.small 0)) (.small 0)) (.small 0)) (.small 0))
private theorem checked0_6_4 : check 0 10 65 subtree0_6_4=true := by unfold subtree0_6_4; decide

@[irreducible] def tree0_6 : Tree :=
  .branch 6 subtree0_6_1 subtree0_6_4
theorem tested0_6 : check 0 10 1 tree0_6=true := by
  unfold tree0_6
  change (check 0 74 1 subtree0_6_1 && check 0 10 65 subtree0_6_4)=true
  simp only [checked0_6_1,checked0_6_4,Bool.true_and]

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_6
