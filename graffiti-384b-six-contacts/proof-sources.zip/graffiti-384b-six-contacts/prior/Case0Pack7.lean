import LocalTree
namespace Graffiti384b.PairMix.Local
set_option maxRecDepth 65536
set_option maxHeartbeats 0
@[irreducible] private def subtree0_7_3 : Tree :=
  (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.branch 29 (.cut 1027 780) (.small 1)))))))) (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.small 1)))))))) (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.branch 29 (.cut 1027 780) (.small 1))))))) (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.small 0)))))))
private theorem checked0_7_3 : check 0 33867 0 subtree0_7_3=true := by unfold subtree0_7_3; decide

@[irreducible] private def subtree0_7_4 : Tree :=
  (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.branch 22 (.cut 1027 652) (.branch 29 (.cut 1027 780) (.small 1))))))) (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.small 0)))))) (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 11 (.cut 1027 556) (.small 0))))) (.small 0)))
private theorem checked0_7_4 : check 0 1099 32768 subtree0_7_4=true := by unfold subtree0_7_4; decide

@[irreducible] private def subtree0_7_2 : Tree :=
  .branch 15 subtree0_7_3 subtree0_7_4
private theorem checked0_7_2 : check 0 1099 0 subtree0_7_2=true := by
  unfold subtree0_7_2
  change (check 0 33867 0 subtree0_7_3 && check 0 1099 32768 subtree0_7_4)=true
  simp only [checked0_7_3,checked0_7_4,Bool.true_and]

@[irreducible] private def subtree0_7_5 : Tree :=
  (.branch 15 (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.branch 29 (.cut 1027 780) (.small 1))))))) (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 16 (.cut 1027 588) (.small 0)))))) (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 16 (.cut 1027 588) (.small 0))))) (.small 0))) (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 7 (.cut 1027 540) (.branch 22 (.cut 1027 652) (.small 0))))) (.small 0)) (.small 0)))
private theorem checked0_7_5 : check 0 75 1024 subtree0_7_5=true := by unfold subtree0_7_5; decide

@[irreducible] private def subtree0_7_1 : Tree :=
  .branch 10 subtree0_7_2 subtree0_7_5
private theorem checked0_7_1 : check 0 75 0 subtree0_7_1=true := by
  unfold subtree0_7_1
  change (check 0 1099 0 subtree0_7_2 && check 0 75 1024 subtree0_7_5)=true
  simp only [checked0_7_2,checked0_7_5,Bool.true_and]

@[irreducible] private def subtree0_7_6 : Tree :=
  (.branch 10 (.branch 15 (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.branch 29 (.cut 1027 780) (.small 1))))))) (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.small 0)))))) (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 11 (.cut 1027 556) (.branch 16 (.cut 1027 588) (.small 0))))) (.small 0))) (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 11 (.cut 1027 556) (.branch 22 (.cut 1027 652) (.small 0))))) (.small 0)) (.small 0))) (.branch 15 (.branch 21 (.branch 28 (.branch 2 (.cut 1027 524) (.branch 4 (.cut 1027 524) (.branch 16 (.cut 1027 588) (.branch 22 (.cut 1027 652) (.small 0))))) (.small 0)) (.small 0)) (.small 0)))
private theorem checked0_7_6 : check 0 11 64 subtree0_7_6=true := by unfold subtree0_7_6; decide

@[irreducible] def tree0_7 : Tree :=
  .branch 6 subtree0_7_1 subtree0_7_6
theorem tested0_7 : check 0 11 0 tree0_7=true := by
  unfold tree0_7
  change (check 0 75 0 subtree0_7_1 && check 0 11 64 subtree0_7_6)=true
  simp only [checked0_7_1,checked0_7_6,Bool.true_and]

end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.tested0_7
