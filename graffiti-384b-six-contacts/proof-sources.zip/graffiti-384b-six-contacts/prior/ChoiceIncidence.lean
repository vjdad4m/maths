import FiveFront

namespace Graffiti384b.FiveChoice
open Finset
variable {V : Type*} [DecidableEq V]

/-- Link edges whose two endpoints are available. -/
def kept (L : Finset (Finset V)) (S : Finset V) := L.filter (· ⊆ S)

theorem kept_mono {L : Finset (Finset V)} {S P : Finset V} (inc : S⊆P) :
    kept L S ⊆ kept L P := fun _ hm => mem_filter.mpr ⟨(mem_filter.mp hm).1,(mem_filter.mp hm).2.trans inc⟩

private def through (L : Finset (Finset V)) (v : V) := L.filter (v ∈ ·)

/-- The degrees of r chosen points in a simple link graph sum to at most
the total edge count plus the number of pairs among those r points. -/
theorem incidence_cap (L : Finset (Finset V)) (two : ∀p∈L,p.card=2) (R : Finset V) :
    (∑v∈R,(through L v).card) ≤ L.card+R.card.choose 2 := by
  classical
  have flip : (∑v∈R,(through L v).card)=∑p∈L,(p∩R).card := by
    calc
      _ = ∑v∈R,∑p∈L,if v∈p then 1 else 0 := by simp [through,sum_boole]
      _ = ∑p∈L,∑v∈R,if v∈p then 1 else 0 := sum_comm
      _ = _ := by simp [sum_boole,filter_mem_eq_inter,inter_comm]
  have each (p : Finset V) (pm : p∈L) : (p∩R).card≤1+(if p⊆R then 1 else 0) := by
    by_cases sub : p⊆R
    · rw [if_pos sub,inter_eq_left.mpr sub,two p pm]
    · rw [if_neg sub]
      have le := card_le_card (inter_subset_left (s₁:=p) (s₂:=R))
      have ne : (p∩R).card≠p.card := fun eq => sub ((eq_of_subset_of_card_le inter_subset_left eq.ge) ▸ inter_subset_right)
      have := two p pm
      omega
  have inside : L.filter (·⊆R) ⊆ R.powersetCard 2 := fun _ pm =>
    mem_powersetCard.mpr ⟨(mem_filter.mp pm).2,two _ (mem_filter.mp pm).1⟩
  have upper := sum_le_sum each
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,mul_one,sum_boole] at upper
  have cap := card_le_card inside
  rw [card_powersetCard] at cap
  rw [flip]; omega

/-- Cost of deleting one point from the variable part of a carrier. -/
private theorem erase_cost (L : Finset (Finset V)) (B X : Finset V) (v : V) :
    (kept L (B∪X)).card ≤ (kept L (B∪X.erase v)).card+(through (kept L (B∪X)) v).card := by
  apply (card_le_card ?_).trans (card_union_le _ _)
  intro p pm
  by_cases vp : v∈p
  · exact mem_union_right _ (mem_filter.mpr ⟨pm,vp⟩)
  · refine mem_union_left _ (mem_filter.mpr ⟨(mem_filter.mp pm).1,?_⟩)
    intro z zm
    rcases mem_union.mp ((mem_filter.mp pm).2 zm) with b|x
    · exact mem_union_left _ b
    · exact mem_union_right _ (mem_erase.mpr ⟨fun eq => vp (eq ▸ zm),x⟩)

/-- At most b points can spoil quota d if even b+1 bad points would
exceed the edge count plus their possible pairwise overlaps. -/
theorem critical_cap (L : Finset (Finset V)) (two : ∀p∈L,p.card=2)
    (B X : Finset V) (d b : ℕ)
    (strict : let s := (kept L (B∪X)).card
      (b+1)*d+s+(b+1).choose 2 < (b+1)*(s+1)) :
    (X.filter (fun v => (kept L (B∪X.erase v)).card<d)).card≤b := by
  classical
  let F := kept L (B∪X)
  let bad := X.filter (fun v => (kept L (B∪X.erase v)).card<d)
  by_contra! many
  obtain ⟨R,sub,size⟩ := exists_subset_card_eq (s:=bad) (n:=b+1) many
  have per (v : V) (vm : v∈R) : F.card+1≤d+(through F v).card := by
    have small := (mem_filter.mp (sub vm)).2
    have cap := erase_cost L B X v
    change F.card≤_+(through F v).card at cap
    omega
  have ex := sum_le_sum per
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id,sum_add_distrib,size] at ex
  have bound := incidence_cap F (fun p pm => two p (mem_filter.mp pm).1) R
  rw [size] at bound
  change (b+1)*d+F.card+(b+1).choose 2<(b+1)*(F.card+1) at strict
  omega

/-- Find a common deletion for all anchors. Distinct anchors may be spoiled
by different deletions. A union bound is sufficient. -/
theorem choose_erase (A B X : Finset V) (L : V→Finset (Finset V)) (need budget : V→ℕ)
    (two : ∀a∈A,∀p∈L a,p.card=2) (room : (∑a∈A,budget a)<X.card)
    (strict : ∀a∈A,let s := (kept (L a) (B∪X)).card; let r := budget a+1
      r*need a+s+r.choose 2<r*(s+1)) :
    ∃v∈X,∀a∈A,need a≤(kept (L a) (B∪X.erase v)).card := by
  classical
  let bad := fun a => X.filter (fun v => (kept (L a) (B∪X.erase v)).card<need a)
  have bound := (card_biUnion_le (s:=A) (t:=bad)).trans
    (sum_le_sum (fun a am => critical_cap (L a) (two a am) B X (need a) (budget a) (strict a am)))
  obtain ⟨v,xv,out⟩ := not_subset.mp (fun sub : X⊆A.biUnion bad => by have := card_le_card sub; omega)
  refine ⟨v,xv,fun a am => Nat.le_of_not_gt (fun low => out ?_)⟩
  exact mem_biUnion.mpr ⟨a,am,mem_filter.mpr ⟨xv,low⟩⟩
end Graffiti384b.FiveChoice
#print axioms Graffiti384b.FiveChoice.incidence_cap
#print axioms Graffiti384b.FiveChoice.critical_cap
#print axioms Graffiti384b.FiveChoice.choose_erase
