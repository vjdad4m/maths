import ChoicePatch
import RankStrata384b

namespace Graffiti384b.FiveChoice
open Finset SimpleGraph Four29
variable {V : Type*} [DecidableEq V]

/-- Number of k-subsets of an n-set extending a specified j-set. -/
def extensions (n k j : ℕ) := if j≤k then (n-j).choose (k-j) else 0

private theorem supersets (U R : Finset V) (sub : R⊆U) (k : ℕ) :
    ((U.powersetCard k).filter (R⊆·)).card=extensions U.card k R.card := by
  classical
  by_cases fit : R.card≤k
  · have eq : (U.powersetCard k).filter (R⊆·)=(U.powersetCard k).filter (fun s => (s∩R).card=R.card) := by
      ext s; simp only [mem_filter]; apply and_congr_right; intro _
      constructor
      · exact fun rs => by rw [inter_eq_right.mpr rs]
      · intro e
        have same := eq_of_subset_of_card_le (inter_subset_right (s₁:=s) (s₂:=R)) e.ge
        exact same ▸ inter_subset_left
    rw [eq,RankStrata.hits U R sub fit,extensions,if_pos fit,Nat.choose_self,one_mul]
  · have empty : (U.powersetCard k).filter (R⊆·)=∅ := eq_empty_of_forall_not_mem (fun s sm => by
      obtain ⟨ss,rs⟩ := mem_filter.mp sm; exact fit ((card_le_card rs).trans_eq (mem_powersetCard.mp ss).2))
    rw [empty,card_empty,extensions,if_neg fit]

/-- A link edge is counted by the number of completions containing its missing endpoints. -/
def mass (L : Finset (Finset V)) (B U : Finset V) (k : ℕ) :=
  ∑p∈kept L (B∪U), extensions U.card k (p\B).card

theorem total_score (L : Finset (Finset V)) (B U : Finset V) (k : ℕ) :
    (∑S∈U.powersetCard k,(kept L (B∪S)).card)=mass L B U k := by
  classical
  let F := kept L (B∪U)
  have row (S : Finset V) (sm : S∈U.powersetCard k) :
      kept L (B∪S)=F.filter (fun p => p\B⊆S) := by
    ext p; simp only [F,kept,mem_filter]
    constructor
    · rintro ⟨pm,sub⟩
      exact ⟨⟨pm,sub.trans (union_subset_union_right (mem_powersetCard.mp sm).1)⟩,fun x xm =>
        (mem_union.mp (sub (mem_sdiff.mp xm).1)).resolve_left (mem_sdiff.mp xm).2⟩
    · rintro ⟨⟨pm,_⟩,sub⟩
      refine ⟨pm,?_⟩; intro x xm
      by_cases xb : x∈B
      · exact mem_union_left _ xb
      · exact mem_union_right _ (sub (mem_sdiff.mpr ⟨xm,xb⟩))
  have col (p : Finset V) (pm : p∈F) : p\B⊆U := fun x xm =>
    (mem_union.mp ((mem_filter.mp pm).2 (mem_sdiff.mp xm).1)).resolve_left (mem_sdiff.mp xm).2
  calc
    _ = ∑S∈U.powersetCard k,∑p∈F,if p\B⊆S then 1 else 0 := by
      apply sum_congr rfl; intro S sm; rw [row S sm]; simp [sum_boole]
    _ = ∑p∈F,∑S∈U.powersetCard k,if p\B⊆S then 1 else 0 := sum_comm
    _ = _ := by
      apply sum_congr rfl; intro p pm; simpa only [sum_boole] using supersets U (p\B) (col p pm) k

theorem select_score (L : Finset (Finset V)) (B U : Finset V) (k d : ℕ)
    (positive : d*U.card.choose k<mass L B U k) :
    ∃S∈U.powersetCard k,d<(kept L (B∪S)).card := by
  classical
  by_contra! no
  have upper := sum_le_sum no
  rw [total_score] at upper
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id,card_powersetCard] at upper
  rw [Nat.mul_comm] at positive; omega

variable [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Reserve vertices that already certify the three ordinary anchors, and sample
the remaining positions from any chosen part of the pool. -/
theorem reserved_selection (t : (types G).card=29) (h : (high G).card=27) (q : (nonleaves G).card=29)
    {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ne : e≠f)
    (F U : Finset V) (fp : F⊆pool G e f) (up : U⊆pool G e f) (k : ℕ) (five : F.card+k≤5)
    {a : V} (anchor : a∈roots G e f) (other : ∀v∈roots G e f,v≠a → 2≤score G e f F v)
    (wins : 12*U.card.choose k<mass (link G a) (base G e f∪F) U k) : gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt; intro bad
  have D := data_of_failure G t h q bad de df ne
  obtain ⟨S,sm,rich⟩ := select_score _ _ U k 12 wins
  obtain ⟨su,sz⟩ := mem_powersetCard.mp sm
  have short := card_union_le F S
  obtain ⟨K,inc,kp,ks⟩ := exists_subsuperset_card_eq (union_subset fp (su.trans up)) (by omega : (F∪S).card≤5)
    (by rw [D.poolSize]; decide)
  have growth {Y : Finset V} (yk : Y⊆K) (v : V) : score G e f Y v≤score G e f K v :=
    card_le_card (kept_mono (union_subset_union_right yk))
  have high : 13≤score G e f K a := by
    rw [union_assoc] at rich
    exact rich.trans_le (growth inc a)
  exact (not_lt_of_ge (five_chosen G t h q de df ne kp ks (fun v vm => by
    by_cases eq : v=a
    · subst v; omega
    · exact (other v vm eq).trans (growth (subset_union_left.trans inc) v)) anchor high)) bad
end Graffiti384b.FiveChoice
#print axioms Graffiti384b.FiveChoice.total_score
#print axioms Graffiti384b.FiveChoice.select_score
#print axioms Graffiti384b.FiveChoice.reserved_selection
