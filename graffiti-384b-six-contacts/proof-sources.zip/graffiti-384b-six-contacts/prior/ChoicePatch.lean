import ChoiceIncidence
namespace Graffiti384b.FiveChoice
open Finset SimpleGraph Four29 LowSample PairMix.Local
open private Repair.linkEdges Repair.edge_info from Repair384b
open private Prune.links Prune.link_in_core from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def link (v : V) := Repair.linkEdges G v
def base (e f : V) := roots G e f ∪ {e,f}
def score (e f : V) (X : Finset V) (v : V) := (kept (link G v) (base G e f∪X)).card

theorem link_two (v : V) (p : Finset V) (m : p∈link G v) : p.card=2 :=
  (Repair.edge_info G m).2.1

private theorem label_score (f : Label ↪ V) (S : Finset V)
    (inside : ∀i,f i∈S) (surj : ∀v∈S,v∈Set.range f) (i : Label) :
    inducedScore G f i=(kept (link G (f i)) S).card := by
  classical
  let P := pairs.filter (fun z => G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2))
  let liftPair (z : Label×Label) : Finset V := {f z.1,f z.2}
  have sm (z : Label×Label) : z∈P ↔ z.1<z.2 ∧ G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2) := by
    simp [P,pairs,and_assoc]
  have repr : P.image liftPair=kept (Repair.linkEdges G (f i)) S := by
    ext s
    constructor
    · intro hm
      obtain ⟨⟨a,b⟩,ab,rfl⟩ := mem_image.mp hm
      obtain ⟨lt,ia,ib,adj⟩ := (sm _).mp ab
      have sub : liftPair (a,b)⊆G.neighborFinset (f i) := insert_subset ((G.mem_neighborFinset ..).mpr ia)
        (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr ib))
      refine mem_filter.mpr ⟨?_,insert_subset (inside a) (singleton_subset_iff.mpr (inside b))⟩
      refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub,card_pair (f.injective.ne lt.ne)⟩,?_⟩
      intro x xm y ym ne
      simp only [liftPair,mem_insert,mem_singleton] at xm ym
      rcases xm with rfl|rfl <;> rcases ym with rfl|rfl <;> first | exact (ne rfl).elim | exact adj | exact adj.symm
    · intro hm
      obtain ⟨isEdge,isIn⟩ := mem_filter.mp hm
      obtain ⟨sub,sz,cl⟩ := Repair.edge_info G isEdge
      obtain ⟨x,y,ne,rfl⟩ := card_eq_two.mp sz
      have xm : x∈({x,y}:Finset V) := mem_insert_self ..
      have ym : y∈({x,y}:Finset V) := mem_insert_of_mem (mem_singleton_self _)
      obtain ⟨a,rfl⟩ := surj x (isIn xm)
      obtain ⟨b,rfl⟩ := surj y (isIn ym)
      have ia := (G.mem_neighborFinset ..).mp (sub xm)
      have ib := (G.mem_neighborFinset ..).mp (sub ym)
      have adj := cl _ xm _ ym ne
      rcases lt_or_gt_of_ne (fun eq : a=b => ne (congrArg f eq)) with l|l
      · exact mem_image.mpr ⟨(a,b),(sm _).mpr ⟨l,ia,ib,adj⟩,rfl⟩
      · exact mem_image.mpr ⟨(b,a),(sm _).mpr ⟨l,ib,ia,adj.symm⟩,pair_comm ..⟩
  have inj : Set.InjOn liftPair (P : Set (Label×Label)) := by
    rintro ⟨a,b⟩ ap ⟨c,d⟩ cp eq
    have lt := ((sm _).mp ap).1
    have lt' := ((sm _).mp cp).1
    have eq' : ({f a,f b}:Set V)={f c,f d} := by simpa [liftPair] using congrArg (fun s : Finset V => (s:Set V)) eq
    rcases Set.pair_eq_pair_iff.mp eq' with ⟨ac,bd⟩|⟨ad,bc⟩
    · exact Prod.ext (f.injective ac) (f.injective bd)
    · have := f.injective ad
      have := f.injective bc
      change a<b at lt; change c<d at lt'
      subst c; subst d; exact (not_lt_of_ge lt.le lt').elim
  have count := congrArg Finset.card repr
  rw [card_image_of_injOn inj] at count
  exact count


theorem five_chosen (t : (types G).card=29) (h : (high G).card=27) (q : (nonleaves G).card=29)
    {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ne : e≠f)
    {T : Finset V} (tx : T⊆pool G e f) (tc : T.card=5)
    (small : ∀v∈roots G e f,2≤score G e f T v) {largeRoot : V}
    (isRoot : largeRoot∈roots G e f) (large : 13≤score G e f T largeRoot) : gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt; intro bad
  have D := data_of_failure G t h q bad de df ne
  let W := roots G e f
  let X := pool G e f
  let E : Finset V := {e,f}
  have highE : Disjoint (high G) E := disjoint_left.mpr (fun _ hi em =>
    (mem_sdiff.mp (D.earSet.symm ▸ em : _∈twos G)).2 hi)
  have ecard : E.card=2 := card_pair ne
  have xw : Disjoint X W := disjoint_left.mpr (fun _ ix => (mem_sdiff.mp ix).2)
  obtain ⟨a,b,ab,en⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G e).trans de)
  obtain ⟨c,d,cd,fn'⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G f).trans df)
  obtain ⟨w,U,_,wu,uc⟩ := (Finset.card_eq_succ (n:=4)).mp tc
  obtain ⟨u,U',_,uU,uc'⟩ := (Finset.card_eq_succ (n:=3)).mp uc
  obtain ⟨x,y,z,_,_,_,Uxyz⟩ := card_eq_three.mp uc'
  have Twxyz : T={w,u,x,y,z} := by rw [←wu,←uU,Uxyz]
  have Wabcd : W={a,b}∪{c,d} := by change G.neighborFinset e ∪ G.neighborFinset f=_; rw [en,fn']
  let lab : Label→V := ![a,b,c,d,w,u,x,y,z,e,f]
  let S := W∪T∪E
  have inc : S⊆univ.image lab := by
    intro v vm
    simp only [S,Wabcd,Twxyz,E,mem_union,mem_insert,mem_singleton] at vm
    rcases vm with (((rfl|rfl)|(rfl|rfl))|(rfl|rfl|rfl|rfl|rfl))|(rfl|rfl)
    · exact mem_image.mpr ⟨0,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨1,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨2,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨3,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨4,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨5,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨6,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨7,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨8,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨9,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨10,mem_univ _,rfl⟩
  have highT := tx.trans (show X⊆high G from sdiff_subset)
  have sz : S.card=11 := by
    have dis := highE.mono_left (union_subset D.highRoots highT)
    rw [show S=W∪T∪E from rfl,card_union_of_disjoint dis,
      card_union_of_disjoint (xw.symm.mono_right tx),D.rootsSize,tc,ecard]
  have inject : Function.Injective lab := by
    have inj := (card_image_iff (s:=univ) (f:=lab)).mp (Nat.le_antisymm card_image_le (by
      have ct' := card_le_card inc; rw [sz] at ct'; simpa using ct'))
    exact fun i j eq => inj (mem_univ i) (mem_univ j) eq
  let idx : Label ↪ V := ⟨lab,inject⟩
  have rangeS {v : V} (vs : v∈S) : v∈Set.range idx := by
    obtain ⟨i,_,rfl⟩ := mem_image.mp (inc vs)
    exact ⟨i,rfl⟩
  have Wmem (r : Root) : idx (atRoot r)∈W := by
    fin_cases r <;> rw [Wabcd] <;> simp [idx,lab,atRoot]
  have largest : ∃r : Root, idx (atRoot r)=largeRoot := by
    change largeRoot∈W at isRoot
    rw [Wabcd,mem_union,mem_insert,mem_singleton,mem_insert,mem_singleton] at isRoot
    rcases isRoot with (rfl|rfl)|(rfl|rfl)
    · exact ⟨0,rfl⟩
    · exact ⟨1,rfl⟩
    · exact ⟨2,rfl⟩
    · exact ⟨3,rfl⟩
  obtain ⟨r,hr⟩ := largest
  have star9 (j : Label) : G.Adj (idx 9) (idx j) ↔ j=0 ∨ j=1 := by
    change G.Adj e (idx j) ↔ _
    rw [←G.mem_neighborFinset,en,mem_insert,mem_singleton]
    change idx j=idx 0 ∨ idx j=idx 1 ↔ _
    simp only [idx.injective.eq_iff]
  have star10 (j : Label) : G.Adj (idx 10) (idx j) ↔ j=2 ∨ j=3 := by
    change G.Adj f (idx j) ↔ _
    rw [←G.mem_neighborFinset,fn',mem_insert,mem_singleton]
    change idx j=idx 2 ∨ idx j=idx 3 ↔ _
    simp only [idx.injective.eq_iff]
  have shape (i j : Label) (old : 9 ≤ i.val ∨ 9 ≤ j.val) : preset i j=true ↔ G.Adj (idx i) (idx j) := by
    have pred : (∀s:Label,preset 9 s=true ↔ s=0 ∨ s=1) ∧
        (∀s:Label,preset 10 s=true ↔ s=2 ∨ s=3) ∧ (∀r s:Label,preset r s=preset s r) := by decide
    have choices (a : Label) (ha : 9 ≤ a.val) : a=9 ∨ a=10 := by
      have tab : ∀b:Label,9 ≤ b.val → b=9 ∨ b=10 := by decide
      exact tab a ha
    rcases old with hi|hj
    · rcases choices i hi with rfl|rfl
      · exact (pred.1 j).trans (star9 j).symm
      · exact (pred.2.1 j).trans (star10 j).symm
    · rw [pred.2.2 i j,G.adj_comm]
      rcases choices j hj with rfl|rfl
      · exact (pred.1 i).trans (star9 i).symm
      · exact (pred.2.1 i).trans (star10 i).symm
  have all : S=univ.image lab := eq_of_subset_of_card_le inc (by simpa [sz] using (card_image_le (f:=lab) (s:=univ)))
  have equal (r : Root) : inducedScore G idx (atRoot r)=score G e f T (idx (atRoot r)) := by
    rw [label_score G idx S (fun i => all ▸ mem_image.mpr ⟨i,mem_univ _,rfl⟩) (fun _ m => rangeS m)]
    have eq : S=base G e f∪T := by simp only [S,base,W,E,union_assoc,union_comm T E]
    rw [eq]; rfl
  have win := protected_patch G idx (by omega) (fun v vm => by
    rw [D.earSet,mem_insert,mem_singleton] at vm; exact vm) shape
    (fun i => (equal i).symm ▸ small _ (Wmem i)) r (by rw [equal,hr]; exact large)
  exact (not_lt_of_ge win) bad

/-- All triangles at an anchor are available when every external triangle contact is present. -/
theorem all_contacts {e f : V} (D : Data G e f) {v : V} (root : v∈roots G e f) :
    score G e f (triangleContacts G e f) v=trianglesAt G v := by
  classical
  change ((link G v).filter _).card=(link G v).card
  congr 1; apply filter_true_of_mem
  intro p pm x xp
  have supp : x∈Repair.linkSupport G v := mem_biUnion.mpr ⟨p,pm,xp⟩
  have nl := Prune.link_in_core G (show p∈Prune.links G v from pm) xp
  by_cases hi : x∈high G
  · by_cases ra : x∈roots G e f
    · exact mem_union_left _ (mem_union_left _ ra)
    · exact mem_union_right _ (mem_filter.mpr ⟨mem_sdiff.mpr ⟨hi,ra⟩,v,root,supp⟩)
  · have ear : x∈twos G := mem_sdiff.mpr ⟨nl,hi⟩
    exact mem_union_left _ (mem_union_right _ (D.earSet ▸ ear))
end Graffiti384b.FiveChoice
#print axioms Graffiti384b.FiveChoice.five_chosen
#print axioms Graffiti384b.FiveChoice.all_contacts
