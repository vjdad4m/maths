import Minimal384b

namespace Graffiti384b.CliqueChoice
open Finset SimpleGraph
open private Repair.linkEdges Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def degrees : Finset ℕ := {3,4,5,6}
def cliqueAt (x : V) := ∀ a b, G.Adj x a → G.Adj x b → a ≠ b → G.Adj a b

theorem saturated_clique {v : V} (sat : trianglesAt G v = (G.degree v).choose 2) : cliqueAt G v := by
  have eq : Repair.linkEdges G v = (G.neighborFinset v).powersetCard 2 :=
    eq_of_subset_of_card_le (filter_subset _ _) (by
      rw [card_powersetCard,card_neighborFinset_eq_degree]; exact sat.ge)
  intro a b va vb ne
  have mem : ({a,b} : Finset V) ∈ Repair.linkEdges G v := eq ▸ mem_powersetCard.mpr
    ⟨insert_subset ((G.mem_neighborFinset _ _).mpr va) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vb)),
     card_pair ne⟩
  exact (mem_filter.mp mem).2 _ (mem_insert_self _ _) _ (mem_insert_of_mem (mem_singleton_self _)) ne

private theorem degree_neighbor {v w : V} (c : cliqueAt G v) (edge : G.Adj v w) : G.degree v ≤ G.degree w := by
  let n := G.neighborFinset v
  have wn : w ∈ n := (G.mem_neighborFinset _ _).mpr edge
  have sub : insert v (n.erase w) ⊆ G.neighborFinset w := by
    apply insert_subset ((G.mem_neighborFinset _ _).mpr edge.symm)
    intro z hz
    obtain ⟨ne,mem⟩ := mem_erase.mp hz
    exact (G.mem_neighborFinset _ _).mpr (c w z edge ((G.mem_neighborFinset _ _).mp mem) ne.symm)
  have cap := card_le_card sub
  have nv : v ∉ n.erase w := fun h => G.not_mem_neighborFinset_self v ((erase_subset _ _) h)
  rw [card_insert_of_not_mem nv,card_erase_of_mem wn,card_neighborFinset_eq_degree] at cap
  have size := card_pos.mpr ⟨w,wn⟩
  have d : n.card = G.degree v := card_neighborFinset_eq_degree _ _
  have dw : (G.neighborFinset w).card = G.degree w := card_neighborFinset_eq_degree _ _
  omega

structure Choice (p : Finset V) (tested : Finset ℕ := degrees) : Prop where
  high_sub : p ⊆ high G
  levels : p.image (fun v => G.degree v) ⊆ tested
  exact_score : ∀ v ∈ p, trianglesAt G v = (G.degree v).choose 2
  unique : Set.InjOn (fun v => G.degree v) (p : Set V)
  covers : ∀ v, G.degree v ∈ tested → trianglesAt G v = (G.degree v).choose 2 → G.degree v ∈ p.image (fun v => G.degree v)

theorem choose_from [Nonempty V] (tested : Finset ℕ) (minDeg : ∀ d ∈ tested, 3 ≤ d) : ∃ p, Choice G p tested := by
  classical
  let f := tested.filter (fun d => ∃ v : V, G.degree v = d ∧ trianglesAt G v = d.choose 2)
  have chooseRep (d : ℕ) : ∃ v : V, d ∈ f → G.degree v = d ∧ trianglesAt G v = d.choose 2 := by
    by_cases h : d ∈ f
    · obtain ⟨v,hv⟩ := (mem_filter.mp h).2
      exact ⟨v,fun _ => hv⟩
    · exact ⟨Classical.arbitrary V,fun m => (h m).elim⟩
  choose rep spec using chooseRep
  let p := f.image rep
  have image : p.image (fun v => G.degree v) = f := by
    ext d
    constructor
    · rintro hd
      obtain ⟨_,vz,rfl⟩ := mem_image.mp hd
      obtain ⟨a,af,rfl⟩ := mem_image.mp vz
      rwa [(spec a af).1]
    · intro hd
      exact mem_image.mpr ⟨rep d,mem_image_of_mem _ hd,(spec d hd).1⟩
  refine ⟨p,⟨?_,image ▸ filter_subset _ _,?_,?_,?_⟩⟩
  · intro v hv
    obtain ⟨d,hd,rfl⟩ := mem_image.mp hv
    apply mem_filter.mpr ⟨mem_univ _,?_⟩
    rw [(spec d hd).1]
    exact minDeg d (mem_filter.mp hd).1
  · intro v hv
    obtain ⟨d,hd,rfl⟩ := mem_image.mp hv
    rw [(spec d hd).1]; exact (spec d hd).2
  · intro v hv w hw eq
    obtain ⟨d,hd,rfl⟩ := mem_image.mp hv
    obtain ⟨j,hj,rfl⟩ := mem_image.mp hw
    exact congrArg rep ((spec d hd).1.symm.trans (eq.trans (spec j hj).1))
  · intro v level sat
    rw [image]; exact mem_filter.mpr ⟨level,v,rfl,sat⟩

theorem choose_vertices [Nonempty V] : ∃ p, Choice G p :=
  choose_from G degrees (by intro d hd; simp [degrees] at hd; omega)

theorem neighbors_in_pool {p : Finset V} {tested : Finset ℕ} (choice : Choice G p tested) {v : V} (vp : v ∈ p) :
    G.neighborFinset v ⊆ high G \ p := by
  intro w hw
  have edge := (G.mem_neighborFinset _ _).mp hw
  have deg := degree_neighbor G (saturated_clique G (choice.exact_score v vp)) edge
  refine mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,(mem_filter.mp (choice.high_sub vp)).2.trans deg⟩,?_⟩
  intro wp
  have back := degree_neighbor G (saturated_clique G (choice.exact_score w wp)) edge.symm
  exact edge.ne (choice.unique vp wp (Nat.le_antisymm deg back))

def slots (f : Finset ℕ) (j : ℕ) (tested : Finset ℕ := degrees) :=
  if j ∈ tested ∧ j ∉ f then j.choose 2 else j.choose 2+1

/-- A missing saturated degree removes its top possible triangle score.
Selected representatives are subtracted at every degree threshold. -/
theorem profile {p : Finset V} {tested : Finset ℕ} (choice : Choice G p tested) (j : ℕ) (big : 3 ≤ j) :
    let f := p.image (fun v => G.degree v)
    let s := high G \ p
    (s.filter (fun v => G.degree v ≤ j)).card + (types G).card + (f.filter (· ≤ j)).card ≤
      (high G).card + slots f j tested := by
  let f := p.image (fun v => G.degree v)
  let a := (high G).filter (fun v => G.degree v ≤ j)
  let c := p.filter (fun v => G.degree v ≤ j)
  have ci : c ⊆ a := fun v hv => mem_filter.mpr ⟨choice.high_sub (mem_filter.mp hv).1,(mem_filter.mp hv).2⟩
  have img : c.image (fun v => G.degree v) = f.filter (· ≤ j) := by
    ext d; simp [c,f]; aesop
  have cc : c.card = (f.filter (· ≤ j)).card := by
    rw [← img,card_image_of_injOn (choice.unique.mono (show (c : Set V) ⊆ p from filter_subset _ _))]
  have eq : (high G \ p).filter (fun v => G.degree v ≤ j) = a \ c := by
    ext v; simp only [a,c,mem_filter,mem_sdiff]; tauto
  have count : (types G).card + a.card ≤ (high G).card + slots f j tested := by
    by_cases no : j ∈ tested ∧ j ∉ f
    · have sub : types G ⊆ ((high G) \ a).image (trianglesAt G) ∪ range (j.choose 2) := by
        intro t ht
        obtain ⟨v,_,rfl⟩ := mem_image.mp ht
        by_cases le : G.degree v ≤ j
        · apply mem_union_right
          apply mem_range.mpr
          have cap := Repair.triangles_le_choose G v
          by_cases same : G.degree v = j
          · have ne : trianglesAt G v ≠ (G.degree v).choose 2 := fun sat => no.2 (same ▸ choice.covers v (same ▸ no.1) sat)
            rw [same] at ne cap
            omega
          · have lt : (G.degree v).choose 2 < j.choose 2 := by
              calc
                _ ≤ (j-1).choose 2 := Nat.choose_le_choose 2 (by omega)
                _ < j.choose 2 := by
                  have rec := Nat.choose_succ_succ' (j-1) 1
                  rw [show j-1+1 = j by omega,Nat.choose_one_right] at rec
                  change j.choose 2 = _ + _ at rec
                  norm_num at rec
                  omega
            omega
        · exact mem_union_left _ (mem_image.mpr ⟨v,mem_sdiff.mpr
            ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,fun mem => le (mem_filter.mp mem).2⟩,rfl⟩)
      have h := (card_le_card sub).trans (card_union_le _ _)
      rw [card_range] at h
      have inc := card_image_le (s := high G \ a) (f := trianglesAt G)
      have sz := card_sdiff_add_card_eq_card (filter_subset (fun v => G.degree v ≤ j) (high G))
      change (high G \ a).card + a.card = _ at sz
      simp only [slots,if_pos no]
      omega
    · simpa only [slots,if_neg no] using Repair.profile_count G j (by omega)
  dsimp only
  rw [eq]
  change _ + _ + (f.filter (· ≤ j)).card ≤ (high G).card + slots f j tested
  have := card_sdiff_add_card_eq_card ci
  omega

end Graffiti384b.CliqueChoice

#print axioms Graffiti384b.CliqueChoice.profile
