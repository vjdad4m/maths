import PinCut34_384b
import Mathlib.Combinatorics.SimpleGraph.Clique

namespace Graffiti384b.CliqueCut34
open Finset SimpleGraph
open private Repair.nbr_add Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A pair of anchors may support any subset of their common neighbors,
including both degree-two ears when possible. -/
theorem pair_obstruction {k x : Finset V} (kc : k.card=2) (kn : k⊆nonleaves G)
    (xn : x⊆nonleaves G) (xk : Disjoint x k) (hit : ∀ v∈x,2≤nbr G v k)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    x.card-1≤(defects G k x).card := by
  have := pin_obstruction G kn xn xk hit same fail
  omega

/-- Every choice of two vertices of a five-clique forces at least two local
defects if the nonleaf count equals the triangle diversity. -/
theorem five_pair {C k : Finset V} (cl : G.IsNClique 5 C) (kc : k.card=2) (ks : k⊆C)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    2≤(((nonleaves G)\C).filter (fun v => G.degree v+nbr G v k<3+nbr G v (C\k))).card := by
  have cn : C⊆nonleaves G := by
    intro v vc
    have inside : C.erase v⊆G.neighborFinset v := fun j jm => (G.mem_neighborFinset _ _).mpr
      (cl.1 vc (mem_erase.mp jm).2 (mem_erase.mp jm).1.symm)
    have num := card_le_card inside
    rw [card_erase_of_mem vc,cl.2,card_neighborFinset_eq_degree] at num
    exact mem_filter.mpr ⟨mem_univ _,by omega⟩
  have hit (v : V) (vm : v∈C\k) : 2≤nbr G v k := by
    have eq : k.filter (G.Adj v)=k := filter_true_of_mem (fun j jk => cl.1 (mem_sdiff.mp vm).1 (ks jk)
      (fun e => (mem_sdiff.mp vm).2 (e ▸ jk)))
    rw [nbr,eq,kc]
  have out := pair_obstruction G kc (ks.trans cn) (sdiff_subset.trans cn)
    (disjoint_left.mpr (fun _ m => (mem_sdiff.mp m).2)) hit same fail
  simpa only [defects,sdiff_union_of_subset ks,card_sdiff ks,cl.2,kc] using out

private theorem choose_pair {C : Finset V} (five : C.card=5) (v : V)
    (repair : 3≤G.degree v ∨ (2≤G.degree v ∧ 0<nbr G v C)) :
    ∃ k⊆C,k.card=2 ∧ 3+nbr G v (C\k)≤G.degree v+nbr G v k := by
  let T := C.filter (G.Adj v)
  by_cases many : 2≤T.card
  · obtain ⟨k,kt,kc⟩ := exists_subset_card_eq many
    have kn := kt.trans (filter_subset _ _)
    have allK : k.filter (G.Adj v)=k := filter_true_of_mem (fun j jk => (mem_filter.mp (kt jk)).2)
    have nk : nbr G v k=2 := by rw [nbr,allK,kc]
    have lim : nbr G v (C\k)+nbr G v k≤G.degree v := by
      have eq := Repair.nbr_add G v (show Disjoint (C\k) k from disjoint_left.mpr (fun _ m => (mem_sdiff.mp m).2))
      rw [sdiff_union_of_subset kn] at eq
      have tot := Repair.full_nbr G v C
      omega
    exact ⟨k,kn,kc,by omega⟩
  · obtain ⟨k,tk,kc,num⟩ := exists_subsuperset_card_eq (show T⊆C from filter_subset _ _) (show T.card≤2 by omega) (show 2≤C.card by omega)
    have none : (C\k).filter (G.Adj v)=∅ := filter_eq_empty_iff.mpr
      (fun j jm edge => (mem_sdiff.mp jm).2 (tk (mem_filter.mpr ⟨(mem_sdiff.mp jm).1,edge⟩)))
    have total := Repair.nbr_add G v (show Disjoint (C\k) k from disjoint_left.mpr (fun _ m => (mem_sdiff.mp m).2))
    rw [sdiff_union_of_subset kc] at total
    have zero : nbr G v (C\k)=0 := by rw [nbr,none,card_empty]
    exact ⟨k,kc,num,by omega⟩

/-- If an exterior degree-two-through-five vertex can be protected by the
pair, at least two *other* such vertices are required. -/
theorem exterior {C : Finset V} (cl : G.IsNClique 5 C) (v : V)
    (repair : 3≤G.degree v ∨ (2≤G.degree v ∧ 0<nbr G v C))
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    2≤((((nonleaves G)\C).filter (fun z => G.degree z≤5)).erase v).card := by
  obtain ⟨k,ks,kc,ok⟩ := choose_pair G cl.2 v repair
  apply (five_pair G cl kc ks same fail).trans (card_le_card ?_)
  intro z zm
  obtain ⟨ext,short⟩ := mem_filter.mp zm
  have lim : nbr G z (C\k)≤3 := (card_filter_le _ _).trans (by rw [card_sdiff ks,cl.2,kc])
  exact mem_erase.mpr ⟨fun eq => by subst z; omega,mem_filter.mpr ⟨ext,by omega⟩⟩

end Graffiti384b.CliqueCut34
#print axioms Graffiti384b.CliqueCut34.pair_obstruction
#print axioms Graffiti384b.CliqueCut34.five_pair
#print axioms Graffiti384b.CliqueCut34.exterior
