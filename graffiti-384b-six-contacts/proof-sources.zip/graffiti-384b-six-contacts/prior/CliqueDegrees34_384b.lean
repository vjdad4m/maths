import CliqueMass34_384b

namespace Graffiti384b.CliqueDegrees34
open Finset SimpleGraph CliqueMass34
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def fee (d : ℕ) := (if d=2 then 10 else 0)+(if d=3 then 6 else 0)+
  (if d=4 then 3 else 0)+(if d=5 then 1 else 0)

private theorem limit {d a : ℕ} (two : 2≤d) (ad : a≤d) (five : a≤5) :
    weight d a ≤ fee d+(if a=d then d.choose 2 else 0) := by
  by_cases big : 8≤d
  · have z : weight d a=0 := sum_eq_zero (fun i _ => if_neg (show ¬d+2*i<3+a by omega))
    rw [z]; exact Nat.zero_le _
  · have table : ∀ j : Fin 8, ∀ s : Fin 6, 2≤j.val → s.val≤j.val →
        weight j.val s.val ≤ fee j.val+(if s.val=j.val then j.val.choose 2 else 0) := by decide
    exact table ⟨d,by omega⟩ ⟨a,by omega⟩ two ad

def count (C : Finset V) (d : ℕ) := ((exterior G C).filter (fun v => G.degree v=d)).card

/-- The incidence test using just the degree counts outside a five-clique.
Fully supported exterior vertices are credited before the coefficients are maximized. -/
theorem degrees {C : Finset V} (cl : G.IsNClique 5 C) (same : (nonleaves G).card=(types G).card)
    (fail : bound G<gamma G) :
    20≤10*count G C 2+6*count G C 3+3*count G C 4+count G C 5 := by
  classical
  let E := exterior G C
  let cred (v : V) := if G.neighborFinset v⊆C then (G.degree v).choose 2 else 0
  have each (v : V) (ve : v∈E) : weight (G.degree v) (nbr G v C) ≤ fee (G.degree v)+cred v := by
    let T := C.filter (G.Adj v)
    have tn : T⊆G.neighborFinset v := fun j hm => (G.mem_neighborFinset _ _).mpr (mem_filter.mp hm).2
    have ad := card_le_card tn
    rw [card_neighborFinset_eq_degree] at ad
    have inc := (card_filter_le C (G.Adj v)).trans_eq cl.2
    have val := limit (mem_filter.mp (mem_sdiff.mp ve).1).2 ad inc
    change weight (G.degree v) (nbr G v C) ≤ fee (G.degree v)+(if T.card=G.degree v then (G.degree v).choose 2 else 0) at val
    by_cases eq : T.card=G.degree v
    · have allT := eq_of_subset_of_card_le tn (by rw [card_neighborFinset_eq_degree,eq])
      have yes : G.neighborFinset v⊆C := allT ▸ filter_subset _ _
      simpa only [cred,if_pos yes,if_pos eq] using val
    · rw [if_neg eq,Nat.add_zero] at val
      exact val.trans (Nat.le_add_right _ _)
  have summed := sum_le_sum each
  rw [sum_add_distrib] at summed
  have bd := budget G cl same fail
  change 20+(∑ v∈E,cred v)≤∑ v∈E,weight (G.degree v) (nbr G v C) at bd
  have sums (i n : ℕ) : (∑ v∈E,(if G.degree v=i then n else 0))=n*count G C i := by
    rw [←sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]; rfl
  have tot : (∑ v∈E,fee (G.degree v))=10*count G C 2+6*count G C 3+3*count G C 4+count G C 5 := by
    simp only [fee,sum_add_distrib,sums,Nat.one_mul]
  omega

/-- With one degree-two vertex, the remaining required incidence
weight must come from degrees three, four and five. -/
theorem one_ear {C : Finset V} (cl : G.IsNClique 5 C) (q : (nonleaves G).card=33)
    (t : (types G).card=33) (h : (high G).card=32) (fail : bound G<gamma G) :
    10≤6*count G C 3+3*count G C 4+count G C 5 := by
  have sub : high G⊆nonleaves G := fun z hz => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hz).2; omega⟩
  have num : (nonleaves G\high G).card=1 := by rw [card_sdiff sub,q,h]
  have inc : (exterior G C).filter (fun v => G.degree v=2)⊆nonleaves G\high G := by
    intro v vm
    obtain ⟨ve,d⟩ := mem_filter.mp vm
    exact mem_sdiff.mpr ⟨(mem_sdiff.mp ve).1,fun vh => by have := (mem_filter.mp vh).2; omega⟩
  have two : count G C 2≤1 := (card_le_card inc).trans_eq num
  have bd := degrees G cl (q.trans t.symm) fail
  omega
end Graffiti384b.CliqueDegrees34
#print axioms Graffiti384b.CliqueDegrees34.degrees
#print axioms Graffiti384b.CliqueDegrees34.one_ear
