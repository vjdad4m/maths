import Diversity35_384b

namespace Graffiti384b.CliqueFrontier34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def upper (p j : ℕ) := if j=3 ∧ p=0 then 3 else RankTable.cap j 3+1
private def limit (h p j : ℕ) := min (h-p) (h+upper p j-33-p)
private theorem monotone : ∀ j d : Fin 11, d.val≤j.val → RankTable.cap d 3≤RankTable.cap j 3 := by decide

private theorem table {h p : ℕ} (hs : h=31 ∨ h=32) (ps : p=0 ∨ p=1) :
    let m := h-p
    12≤m ∧ envelope m 12 ∧ reward m 12 ∧
      6*(16*m.choose 12+UnifiedSample.chargeAt m 12 (limit h p)) <
        6*(m-12)*m.choose 12+(32-h)*(6*(m-2).choose 10)+6*p*bonus m 12 3 := by
  rcases hs with rfl|rfl <;> rcases ps with rfl|rfl <;>
    unfold limit upper RankTable.cap envelope reward UnifiedSample.chargeAt LowSample.delta LowSample.weight bonus FiniteRange.badCount <;>
    simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose] <;> decide

/-- A graph of diversity 33 with at least 32 nonleaves satisfies the
conjecture if it has no five-clique. -/
theorem exact33 (t : (types G).card=33) (q : 32≤(nonleaves G).card) (free : G.CliqueFree 5) :
    gamma G≤bound G := by
  classical
  by_contra! fail
  let h := (high G).card
  have lim := type_bound G
  have miss : ((high G).card+1)/2 < ((types G).card+1)/2 :=
    Nat.lt_of_not_ge (fun le => (not_lt_of_ge (exact_of_high G le)) fail)
  have hs : h=31 ∨ h=32 := by dsimp [h]; omega
  letI : Nonempty V := by obtain ⟨v,_⟩ := card_pos.mp (show 0<(high G).card by change 0<h; omega); exact ⟨v⟩
  obtain ⟨P,ch⟩ := choose_from G ({3} : Finset ℕ) (by simp)
  let f := P.image (G.degree ·)
  have only : f⊆{3} := ch.levels
  have ps : P.card=0 ∨ P.card=1 := by
    have size := card_le_card only
    change (P.image (G.degree ·)).card≤1 at size
    rw [card_image_of_injOn ch.unique] at size; omega
  let m := h-P.card
  let s := high G\P
  have sz : s.card=m := card_sdiff ch.high_sub
  obtain ⟨room,env,rew,strict⟩ := table hs ps
  change 12≤m at room
  have deg (z : V) (hz : z∈P) : G.degree z=3 := mem_singleton.mp (only (mem_image_of_mem _ hz))
  have dist (j : ℕ) (jj : j∈range 11) (pos : 3≤j) : (s.filter (fun z => G.degree z≤j)).card≤limit h P.card j := by
    let H := (high G).filter (fun z => G.degree z≤j)
    have jt := mem_range.mp jj
    have cap (v : V) (vd : G.degree v≤j) : trianglesAt G v<upper P.card j := by
      have td := RankTuran.local_turan G 3 (by decide) free v
      have val := RankTable.cap_table ⟨G.degree v,by omega⟩ ⟨3,by decide⟩ (by decide)
      change (turanGraph (G.degree v) 3).edgeFinset.card=RankTable.cap (G.degree v) 3 at val
      have up := td.trans_eq val
      have mono := monotone ⟨j,jt⟩ ⟨G.degree v,by omega⟩ vd
      change RankTable.cap (G.degree v) 3≤RankTable.cap j 3 at mono
      unfold upper
      split_ifs with special
      · obtain ⟨rfl,empty⟩ := special
        by_cases three : G.degree v=3
        · rw [three] at up
          change trianglesAt G v≤3 at up
          by_contra! big
          have inF := ch.covers v (mem_singleton.mpr three) (by rw [three]; change trianglesAt G v=3; omega)
          rw [card_eq_zero.mp empty] at inF; simp at inF
        · have small := monotone ⟨2,by decide⟩ ⟨G.degree v,by omega⟩ (by change G.degree v≤2; omega)
          change RankTable.cap (G.degree v) 3≤1 at small; omega
      · omega
    have coverage : types G ⊆ ((high G)\H).image (trianglesAt G) ∪ range (upper P.card j) := by
      intro a ha
      obtain ⟨z,_,rfl⟩ := mem_image.mp ha
      by_cases small : G.degree z≤j
      · exact mem_union_right _ (mem_range.mpr (cap z small))
      · exact mem_union_left _ (mem_image.mpr ⟨z,mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,
          fun hz => small (mem_filter.mp hz).2⟩,rfl⟩)
    have card := (card_le_card coverage).trans (card_union_le _ _)
    rw [t,card_range] at card
    have others := card_image_le (s:=high G\H) (f:=trianglesAt G)
    have num : (high G\H).card+H.card=h := card_sdiff_add_card_eq_card (filter_subset _ _)
    have sub : P⊆H := fun z hz => mem_filter.mpr ⟨ch.high_sub hz,(deg z hz) ▸ pos⟩
    have eq : s.filter (fun z => G.degree z≤j)=H\P := by ext z; simp [s,H,and_assoc,and_comm,and_left_comm]
    have count := card_sdiff_add_card_eq_card sub
    exact le_min ((card_filter_le _ _).trans_eq sz) (by rw [eq]; omega)
  have obs := UnifiedSample.extraObstruction G ch 12 (limit h P.card) dist (fun _ => 0)
    (by intro z hz; rw [Nat.add_zero]; exact FiniteRange.count_bad G _ 12 _ z hz (min_le_left _ _) (by change _<s.card; omega))
    (by decide) (sz ▸ env) (sz ▸ rew) fail
  dsimp only at obs
  have cardf : f.card=P.card := card_image_of_injOn ch.unique
  have sum : (∑ d∈f,bonus m 12 d)=P.card*bonus m 12 3 := by
    calc
      _ = ∑ _d∈f,bonus m 12 3 := sum_congr rfl (fun d dm => by rw [mem_singleton.mp (only dm)])
      _ = _ := by simp [cardf]
  have sub : high G⊆nonleaves G := fun z hz => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hz).2; omega⟩
  have total : (twos G).card+h=(nonleaves G).card := card_sdiff_add_card_eq_card sub
  simp only [sum_const_zero,Nat.mul_zero,Nat.add_zero,t] at obs
  change 6*(h-f.card-12)*(h-f.card).choose 12+(twos G).card*(6*(h-f.card-2).choose 10)+6*(∑ d∈f,bonus (h-f.card) 12 d) ≤
    6*(16*(h-f.card).choose 12+UnifiedSample.chargeAt (h-f.card) 12 (limit h P.card)) at obs
  rw [cardf] at obs
  change 6*(m-12)*m.choose 12+(twos G).card*(6*(m-2).choose 10)+6*(∑ d∈f,bonus m 12 d)≤
    6*(16*m.choose 12+UnifiedSample.chargeAt m 12 (limit h P.card)) at obs
  have extra := Nat.mul_le_mul_right (6*(m-2).choose 10) (show 32-h≤(twos G).card by omega)
  rw [sum,←Nat.mul_assoc 6 P.card] at obs
  change 6*(16*m.choose 12+UnifiedSample.chargeAt m 12 (limit h P.card)) <
    6*(m-12)*m.choose 12+(32-h)*(6*(m-2).choose 10)+6*P.card*bonus m 12 3 at strict
  omega

theorem exact_of_five_clique_free (hc : G.Connected) (hn : 2<Fintype.card V) (t : 33≤(types G).card) (free : G.CliqueFree 5) :
    gamma G≤bound G := by
  by_cases large : 34≤(types G).card
  · exact Diversity35.exact_of_at_least_34_types G hc hn large
  by_contra! bad
  obtain ⟨r,_,lim,_,_,same,_⟩ := Prune.prune_failure G hc hn bad
  have count : (types (G.induce (r : Set V))).card≤r.card := by
    simpa only [types,card_univ,Fintype.card_coe] using
      (card_image_le (s:=(univ : Finset r)) (f:=trianglesAt (G.induce (r : Set V))))
  rw [same] at count
  exact (not_lt_of_ge (exact33 G (by omega) (by omega) free)) bad

end Graffiti384b.CliqueFrontier34
#print axioms Graffiti384b.CliqueFrontier34.exact33
#print axioms Graffiti384b.CliqueFrontier34.exact_of_five_clique_free
