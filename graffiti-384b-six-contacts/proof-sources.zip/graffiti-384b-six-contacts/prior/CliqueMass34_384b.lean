import CliqueCut34_384b
import RankStrata384b

namespace Graffiti384b.CliqueMass34
open Finset SimpleGraph
open private Repair.nbr_add Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def exterior (C : Finset V) := nonleaves G\C
def supported (C k : Finset V) := (exterior G C).filter (fun v => G.neighborFinset v⊆C ∧ k⊆G.neighborFinset v)
def blocked (C k : Finset V) := (exterior G C).filter (fun v => G.degree v+nbr G v k<3+nbr G v (C\k))

/-- The two anchors can omit all supported common neighbors, of any degree,
simultaneously with the three other clique vertices. -/
theorem pair {C k : Finset V} (cl : G.IsNClique 5 C) (kc : k.card=2) (ks : k⊆C)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    2+(supported G C k).card≤(blocked G C k).card := by
  let A := supported G C k
  let X := (C\k)∪A
  have cn : C⊆nonleaves G := by
    intro v vc
    have inside : C.erase v⊆G.neighborFinset v := fun j jm => (G.mem_neighborFinset _ _).mpr
      (cl.1 vc (mem_erase.mp jm).2 (mem_erase.mp jm).1.symm)
    have num := card_le_card inside
    rw [card_erase_of_mem vc,cl.2,card_neighborFinset_eq_degree] at num
    exact mem_filter.mpr ⟨mem_univ _,by omega⟩
  have out {v : V} (va : v∈A) : v∉C := (mem_sdiff.mp (mem_filter.mp va).1).2
  have sep : Disjoint (C\k) A := disjoint_left.mpr (fun _ vm va => out va (mem_sdiff.mp vm).1)
  have xk : Disjoint X k := disjoint_left.mpr (fun _ vm vk => (mem_union.mp vm).elim
    (fun hm => (mem_sdiff.mp hm).2 vk) (fun va => out va (ks vk)))
  have xn : X⊆nonleaves G := union_subset (sdiff_subset.trans cn) ((filter_subset _ _).trans sdiff_subset)
  have hits (v : V) (vx : v∈X) : 2≤nbr G v k := by
    have eq : k.filter (G.Adj v)=k := filter_true_of_mem (by
      intro j jk
      rcases mem_union.mp vx with vm|va
      · exact cl.1 (mem_sdiff.mp vm).1 (ks jk) (fun e => (mem_sdiff.mp vm).2 (e ▸ jk))
      · exact (G.mem_neighborFinset _ _).mp ((mem_filter.mp va).2.2 jk))
    rw [nbr,eq,kc]
  have low := CliqueCut34.pair_obstruction G kc (ks.trans cn) xn xk hits same fail
  have inc : CliqueCut34.defects G k X⊆blocked G C k := by
    intro v vm
    obtain ⟨vr,lt⟩ := mem_filter.mp vm
    obtain ⟨vn,rest⟩ := mem_sdiff.mp vr
    have vc : v∉C := by
      intro vC
      by_cases vk : v∈k
      · exact rest (mem_union_right _ vk)
      · exact rest (mem_union_left _ (mem_union_left _ (mem_sdiff.mpr ⟨vC,vk⟩)))
    have na : A.filter (G.Adj v)=∅ := filter_eq_empty_iff.mpr
      (fun a am va => vc ((mem_filter.mp am).2.1 ((G.mem_neighborFinset _ _).mpr va.symm)))
    have eq := Repair.nbr_add G v sep
    have zero : nbr G v A=0 := by rw [nbr,na,card_empty]
    change nbr G v X=_ at eq
    rw [eq,zero,Nat.add_zero] at lt
    exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨vn,vc⟩,lt⟩
  have size : X.card=3+A.card := by rw [show X=(C\k)∪A from rfl,card_union_of_disjoint sep,card_sdiff ks,cl.2,kc]
  have := low.trans (card_le_card inc)
  rw [size] at this
  change 2+A.card≤_
  omega

def weight (d a : ℕ) := ∑ i∈range 3, if d+2*i<3+a then a.choose i*(5-a).choose (2-i) else 0

private theorem mass {C : Finset V} (five : C.card=5) (v : V) :
    ((C.powersetCard 2).filter (fun k => G.degree v+nbr G v k<3+nbr G v (C\k))).card =
      weight (G.degree v) (nbr G v C) := by
  let P := C.powersetCard 2
  let T := C.filter (G.Adj v)
  let a := T.card
  let d := G.degree v
  let b (k : Finset V) := (k∩T).card
  have same {k : Finset V} (kr : k∈P) : (G.degree v+nbr G v k<3+nbr G v (C\k)) ↔ d+2*b k<3+a := by
    have sub := (mem_powersetCard.mp kr).1
    have eq : k∩T=k.filter (G.Adj v) := by
      ext i
      simp only [T,mem_inter,mem_filter]; constructor
      · rintro ⟨ik,_,vi⟩; exact ⟨ik,vi⟩
      · rintro ⟨ik,vi⟩; exact ⟨ik,sub ik,vi⟩
    have tot := Repair.nbr_add G v (show Disjoint (C\k) k from disjoint_left.mpr (fun _ m => (mem_sdiff.mp m).2))
    rw [sdiff_union_of_subset sub] at tot
    change a=nbr G v (C\k)+nbr G v k at tot
    have hits : b k=nbr G v k := congrArg Finset.card eq
    dsimp only [d]
    omega
  have co (k : Finset V) (kr : k∈P) : b k∈range 3 := by
    have bound := card_le_card (show k∩T⊆k from inter_subset_left)
    have card := (mem_powersetCard.mp kr).2
    exact mem_range.mpr (show (k∩T).card<3 by omega)
  have point (k : Finset V) (kr : k∈P) :
      (if G.degree v+nbr G v k<3+nbr G v (C\k) then 1 else 0 : ℕ) =
      ∑ i∈range 3, if d+2*i<3+a ∧ b k=i then 1 else 0 := by
    rw [sum_eq_single (b k)]
    · simp only [same kr,and_true]
    · intro i _ ne
      exact if_neg (fun hh : d+2*i<3+a ∧ b k=i => ne hh.2.symm)
    · exact fun no => (no (co k kr)).elim
  have sums := sum_congr rfl point
  rw [sum_comm] at sums
  simp only [sum_boole,Nat.cast_id] at sums
  change _ = weight d a
  rw [sums]
  apply sum_congr rfl
  intro i ir
  by_cases good : d+2*i<3+a
  · simp only [good,true_and,if_true]
    have hit := RankStrata.hits C T (filter_subset _ _) (show i≤2 by have := mem_range.mp ir; omega)
    simpa only [five] using hit
  · simp [good]

/-- Exact ten-pair incidence budget on a five-clique. The left side includes
every pair able to omit a clique-supported exterior vertex. -/
theorem budget {C : Finset V} (cl : G.IsNClique 5 C)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    20+(∑ v∈exterior G C, if G.neighborFinset v⊆C then (G.degree v).choose 2 else 0) ≤
      ∑ v∈exterior G C,weight (G.degree v) (nbr G v C) := by
  classical
  let P := C.powersetCard 2
  let E := exterior G C
  have rows := sum_le_sum (s:=P) (fun k kr => pair G cl (mem_powersetCard.mp kr).2 (mem_powersetCard.mp kr).1 same fail)
  have pc : P.card=10 := by rw [show P=C.powersetCard 2 from rfl,card_powersetCard,cl.2]; decide
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,pc] at rows
  have left : (∑ k∈P,(supported G C k).card)=∑ v∈E,if G.neighborFinset v⊆C then (G.degree v).choose 2 else 0 := by
    have lift (k : Finset V) : (supported G C k).card=∑ v∈E,(if G.neighborFinset v⊆C ∧ k⊆G.neighborFinset v then 1 else 0 : ℕ) := by simp [supported,E]
    simp only [lift]
    rw [sum_comm]
    apply sum_congr rfl
    intro v _
    by_cases yes : G.neighborFinset v⊆C
    · simp only [yes,true_and,if_true,sum_boole,Nat.cast_id]
      have eq : P.filter (fun k => k⊆G.neighborFinset v)=(G.neighborFinset v).powersetCard 2 := by
        ext k
        simp only [P,mem_filter,mem_powersetCard]
        exact ⟨fun h => ⟨h.2,h.1.2⟩,fun h => ⟨⟨h.1.trans yes,h.2⟩,h.1⟩⟩
      rw [eq,card_powersetCard,card_neighborFinset_eq_degree]
    · simp [yes]
  have right : (∑ k∈P,(blocked G C k).card)=∑ v∈E,weight (G.degree v) (nbr G v C) := by
    have lift (k : Finset V) : (blocked G C k).card=∑ v∈E,(if G.degree v+nbr G v k<3+nbr G v (C\k) then 1 else 0 : ℕ) := by simp [blocked,E]
    simp only [lift]
    rw [sum_comm]
    apply sum_congr rfl
    intro v _
    simpa only [sum_boole,Nat.cast_id] using mass G cl.2 v
  rw [left,right] at rows
  exact rows

end Graffiti384b.CliqueMass34
#print axioms Graffiti384b.CliqueMass34.pair
#print axioms Graffiti384b.CliqueMass34.budget
