import RedundantPivot384b
import SixFinish384b

namespace Graffiti384b.CliquePivot
open Finset SimpleGraph RankStrata
open private FiniteRange.bad from FiniteRange384b
open private Stratum35.ear from StratumFinish35_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def quota (c : ℕ) := if c=4 then 11 else 10
def few (c m b d a : ℕ) :=
  counts a 2 0 c * counts (d-a) b 0 m + counts a 2 1 c * counts (d-a) b 0 m + counts a 2 0 c * counts (d-a) b 1 m
def cost (c d : ℕ) := (if c=4 then [0,0,0,50279472,35570052,23631972,14814072,8767512,4887636,2670564]
  else [0,0,0,37182145,26363260,18404540,12345060,7894120,4803656,2771340] : List ℕ)[d]?.getD 0
def delta (c j : ℕ) := if 3≤j then cost c j-cost c (j+1) else 0
def charge (c : ℕ) (f : Finset ℕ) := (32-c)*cost c 9+∑ j ∈ range 9,delta c j*
  min (32-c) (CliqueChoice.slots f j Boundary.levels-2-(if c≤j then 1 else 0))
def surplus (c : ℕ) := if c=4 then 18747300 else 8436285
def extra (c : ℕ) (f : Finset ℕ) := if c=4 ∧ 3∈f then 6489450 else 0
def applies (c : ℕ) (f : Finset ℕ) := (c=4 ∧ (f={4} ∨ f={3,4})) ∨ (c=5 ∧ (f={5} ∨ f={3,5}))

private theorem numbers {c : ℕ} {f : Finset ℕ} (rule : applies c f) :
    (∀ d : Fin 10, 3≤d.val → ∀ a : Fin 10, a.val≤d.val → a.val≤c →
      few c (32-c-1) (quota c) d a ≤ cost c d) ∧
    (∀ a : Fin 3, few c (32-c) (quota c) 2 a + surplus c ≤ c.choose 2*(32-c).choose (quota c)) ∧
    (∀ d : Fin 10, 3≤d.val → cost c d ≤ cost c 9+∑ j ∈ range 9, if d.val≤j then delta c j else 0) ∧
    charge c f < (14-quota c)*(c.choose 2*(32-c).choose (quota c))+surplus c+extra c f := by
  rcases rule with ⟨rfl,rfl|rfl⟩|⟨rfl,rfl|rfl⟩ <;> unfold extra charge delta cost few counts quota surplus CliqueChoice.slots Boundary.levels <;>
    simp only [Nat.choose_eq_fast_choose] <;> decide

private theorem outside {x : V} {p C M : Finset V} (xh : x ∈ high G)
    (ch : CliqueChoice.Choice G p Boundary.levels) (t : (types G).card=35) (h : (high G).card=33)
    (c : ℕ) (rule : applies c (p.image (G.degree ·))) (dx : G.degree x=c)
    (nc : C.card=c) (nm : M.card=32-c) (dis : Disjoint C M) (cover : C∪M=high G \ {x}) :
    let b := quota c
    let rows := C.powersetCard 2 ×ˢ M.powersetCard b
    ∑ v ∈ M, (rows.filter (fun z => v ∈ FiniteRange.bad G (C∪M) (z.1∪z.2))).card ≤ charge c (p.image (G.degree ·)) := by
  dsimp only
  let b := quota c
  let rows := C.powersetCard 2 ×ˢ M.powersetCard b
  let fiber (v : V) := (rows.filter (fun z => v ∈ FiniteRange.bad G (C∪M) (z.1∪z.2))).card
  let countD (v : V) := min (G.degree v) 9
  have cc : c=4 ∨ c=5 := rule.imp And.left And.left
  have bp : 1≤b := by unfold b quota; split_ifs <;> decide
  have ms : M ⊆ high G \ {x} := cover ▸ subset_union_right
  have nums := numbers rule
  have localCost (v : V) (vm : v ∈ M) : fiber v ≤ cost c 9 +
      ∑ j ∈ range 9, if countD v≤j then delta c j else 0 := by
    let d := countD v
    have dl : 3≤d := le_min (mem_filter.mp (mem_sdiff.mp (ms vm)).1).2 (by decide)
    have du : d≤9 := min_le_right _ _
    obtain ⟨g,ng,gd⟩ := exists_subset_card_eq (show d≤(G.neighborFinset v).card by rw [card_neighborFinset_eq_degree]; exact min_le_left _ _)
    obtain ⟨T,ts,tc,cmp⟩ := RankWitness.surrogate G C M g vm dis ng (by rw [gd,nm]; omega)
    have loss := RankWitness.stratum_loss G C M (g∩C) T vm inter_subset_right ts (by decide : 1≤2) bp cmp
    rw [tc,gd,nc,nm] at loss
    have ac := (card_le_card (show g∩C ⊆ C from inter_subset_right)).trans_eq nc
    have ad := (card_le_card (show g∩C ⊆ g from inter_subset_left)).trans_eq gd
    have le : fiber v ≤ few c (32-c-1) b d (g∩C).card := loss
    exact (le.trans (nums.1 ⟨d,by omega⟩ dl ⟨(g∩C).card,by omega⟩ ad ac)).trans (nums.2.2.1 ⟨d,by omega⟩ dl)
  have step (j : ℕ) (jj : j ∈ range 9) : (∑ v ∈ M, if countD v≤j then delta c j else 0) ≤
      delta c j*min (32-c) (CliqueChoice.slots (p.image (G.degree ·)) j Boundary.levels-2-(if c≤j then 1 else 0)) := by
    by_cases pos : 3≤j
    · rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
      apply Nat.mul_le_mul_left
      have ranks := PivotSample.ranks G ch t h xh ms pos
      rw [nm,dx] at ranks
      apply le_trans (card_le_card ?_) ranks
      intro v hv
      obtain ⟨vm,sm⟩ := mem_filter.mp hv
      have hi := mem_range.mp jj
      change min (G.degree v) 9 ≤ j at sm
      exact mem_filter.mpr ⟨vm,by omega⟩
    · simp [delta,pos]
  have total := sum_le_sum localCost
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,nm] at total
  rw [sum_comm (s := M) (t := range 9)] at total
  exact total.trans (Nat.add_le_add_left (sum_le_sum step) _)

theorem exact {p : Finset V} (ch : CliqueChoice.Choice G p Boundary.levels) (t : (types G).card=35)
    (h : (high G).card=33) (q : (nonleaves G).card=34) (x : V)
    (cl : CliqueChoice.cliqueAt G x) (rule : applies (G.degree x) (p.image (G.degree ·))) : gamma G ≤ bound G := by
  classical
  by_contra! fail
  let c := G.degree x
  let b := quota c
  let C := G.neighborFinset x
  let s := high G \ {x}
  let M := s \ C
  let rows := C.powersetCard 2 ×ˢ M.powersetCard b
  have cc : c=4 ∨ c=5 := rule.imp And.left And.left
  have bp : 1≤b := by unfold b quota; split_ifs <;> decide
  have bb : b≤11 := by unfold b quota; split_ifs <;> decide
  have xc : x ∈ high G := mem_filter.mpr ⟨mem_univ _,by change 3≤c; omega⟩
  have size : s.card=32 := by dsimp [s]; rw [card_sdiff (singleton_subset_iff.mpr xc),h,card_singleton]
  have nc : C.card=c := card_neighborFinset_eq_degree _ _
  have neigh {v : V} (vc : v ∈ C) : c ≤ G.degree v := by
    have edge := (G.mem_neighborFinset _ _).mp vc
    let T := insert x (C.erase v)
    have sub : T ⊆ G.neighborFinset v := insert_subset ((G.mem_neighborFinset _ _).mpr edge.symm) (fun w wh =>
      (G.mem_neighborFinset _ _).mpr (cl v w edge ((G.mem_neighborFinset _ _).mp (mem_erase.mp wh).2) (mem_erase.mp wh).1.symm))
    have le := card_le_card sub
    change (insert x (C.erase v)).card ≤ _ at le
    rw [card_insert_of_not_mem (fun hx => G.not_mem_neighborFinset_self x ((erase_subset _ _) hx)),
      card_erase_of_mem vc,nc,card_neighborFinset_eq_degree] at le
    omega
  have cs : C ⊆ s := fun v vc => mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by have := neigh vc; omega⟩,
    fun m => ((G.mem_neighborFinset _ _).mp vc).ne (mem_singleton.mp m).symm⟩
  have nm : M.card=32-c := by dsimp only [M]; rw [card_sdiff cs,size,nc]
  have dis : Disjoint C M := disjoint_left.mpr (fun _ vc vm => (mem_sdiff.mp vm).2 vc)
  have cover : C∪M=s := union_sdiff_of_subset cs
  obtain ⟨y,yd,yn⟩ := Stratum35.ear G t h q
  have ins : G.neighborFinset y ⊆ s := by
    intro v hv
    refine mem_sdiff.mpr ⟨yn hv,?_⟩
    intro eq
    obtain rfl := mem_singleton.mp eq
    have yc : y ∈ C := (G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp hv).symm
    have := neigh yc
    omega
  let f := p.image (G.degree ·)
  obtain ⟨Q,qr,amount,redeem⟩ : ∃ Q ⊆ rows, extra c f ≤ Q.card ∧ ∀ z∈Q,
      ∃ w ∈ z.2, w ∈ M ∧ ¬G.Adj y w ∧ ∃ A ⊆ G.neighborFinset w,
        A.card=2 ∧ A ⊆ z.1∪z.2 ∧ CliqueChoice.cliqueAt G w := by
    by_cases mix : c=4 ∧ 3∈f
    · obtain ⟨w,wp,wd⟩ := mem_image.mp mix.2
      have sat := CliqueChoice.saturated_clique G (ch.exact_score w wp)
      have wout : w ∉ C := fun wc => by have := neigh wc; omega
      have ws : w ∈ s := mem_sdiff.mpr ⟨ch.high_sub wp,fun wx => by
        have eq := mem_singleton.mp wx
        have dd : G.degree w=c := congrArg (G.degree ·) eq
        omega⟩
      have wm : w ∈ M := mem_sdiff.mpr ⟨ws,wout⟩
      have highN := (CliqueChoice.neighbors_in_pool G ch wp).trans sdiff_subset
      have ynw : ¬G.Adj y w := fun yw => by
        have yes := highN ((G.mem_neighborFinset _ _).mpr yw.symm)
        have := (mem_filter.mp yes).2
        omega
      obtain ⟨A,an,an2⟩ := exists_subset_card_eq (show 2 ≤ (G.neighborFinset w).card by rw [card_neighborFinset_eq_degree,wd]; decide)
      let H := insert w A
      have no : w ∉ A := fun m => G.not_mem_neighborFinset_self w (an m)
      have hs : H ⊆ C∪M := by
        rw [cover]
        apply insert_subset ws
        intro v va
        exact mem_sdiff.mpr ⟨highN (an va),fun e => wout ((G.mem_neighborFinset _ _).mpr
          ((mem_singleton.mp e) ▸ ((G.mem_neighborFinset _ _).mp (an va)).symm))⟩
      have cnt := RedundantPivot.marked C M H (nc.trans mix.1) (by rw [nm,mix.1]) dis hs
        (by dsimp only [H]; rw [card_insert_of_not_mem no,an2]) ⟨w,mem_sdiff.mpr ⟨mem_insert_self _ _,wout⟩⟩
      have qb : b=11 := by unfold b quota; rw [if_pos mix.1]
      refine ⟨rows.filter (fun z => H ⊆ z.1∪z.2),filter_subset _ _,?_,?_⟩
      · simpa only [extra,if_pos mix,rows,qb] using cnt
      · intro z hz
        obtain ⟨row,allH⟩ := mem_filter.mp hz
        have wz := allH (mem_insert_self w A)
        have wy := (mem_union.mp wz).resolve_left (fun m => wout ((mem_powersetCard.mp (mem_product.mp row).1).1 m))
        exact ⟨w,wy,wm,ynw,A,an,an2,(subset_insert _ _).trans allH,sat⟩
    · exact ⟨∅,empty_subset _,by simp [extra,mix],fun _ hm => (not_mem_empty _ hm).elim⟩
  have per (z : Finset V × Finset V) (hz : z ∈ rows) :
      (14-b+(if 2≤nbr G y (z.1∪z.2) then 1 else 0)+(if z∈Q then 1 else 0) ≤ (FiniteRange.bad G s (z.1∪z.2)).card) ∧
      FiniteRange.bad G s (z.1∪z.2) ⊆ M := by
    let k := z.1∪z.2
    obtain ⟨px,py⟩ := mem_product.mp hz
    obtain ⟨xs,xn⟩ := mem_powersetCard.mp px
    obtain ⟨ys,yn'⟩ := mem_powersetCard.mp py
    have ks : k ⊆ s := cover ▸ union_subset_union xs ys
    have sizeK : k.card=2+b := by dsimp [k]; rw [card_union_of_disjoint (dis.mono xs ys),xn,yn']
    have eval (K : Finset V) (sub : K ⊆ s) (inc : z.1 ⊆ K) :
        32-K.card+1+(if 2≤nbr G y K then 1 else 0) ≤ 17+(FiniteRange.bad G s K).card ∧ FiniteRange.bad G s K ⊆ M := by
      have xhit : 2≤nbr G x K := xn ▸ card_le_card (show z.1 ⊆ K.filter (G.Adj x) from fun w wh =>
        mem_filter.mpr ⟨inc wh,(G.mem_neighborFinset _ _).mp (xs wh)⟩)
      have protect (v : V) (vc : v ∈ C) (outK : v ∉ K) : 2≤nbr G v K := by
        have sub' : z.1 ⊆ K.filter (G.Adj v) := fun w wh => mem_filter.mpr ⟨inc wh,
          cl v w ((G.mem_neighborFinset _ _).mp vc) ((G.mem_neighborFinset _ _).mp (xs wh)) (fun e => outK (e ▸ inc wh))⟩
        exact xn ▸ card_le_card sub'
      have tr := PivotSample.trial G xc yd cs ins sub xhit protect t fail
      change s.card-K.card+1+_ ≤ 17+(FiniteRange.bad G s K).card ∧ _ at tr
      rw [size] at tr
      exact tr
    have baseline := eval k ks subset_union_left
    refine ⟨?_,baseline.2⟩
    change 14-b+(if 2≤nbr G y k then 1 else 0)+(if z∈Q then 1 else 0) ≤ (FiniteRange.bad G s k).card
    by_cases zq : z∈Q
    · obtain ⟨w,wy,wm,ynw,A,an,an2,ak,sat⟩ := redeem z zq
      have wk : w ∈ k := mem_union_right _ wy
      have stopped := eval (k.erase w) ((erase_subset _ _).trans ks) (fun v hv => mem_erase.mpr
        ⟨fun eq => (mem_sdiff.mp wm).2 (eq ▸ xs hv),mem_union_left _ hv⟩)
      have le := card_le_card (RedundantPivot.erase_safe G (s:=s) sat an an2 ak)
      change (FiniteRange.bad G s (k.erase w)).card ≤ (FiniteRange.bad G s k).card at le
      have same : nbr G y (k.erase w)=nbr G y k := by
        unfold nbr
        congr 1
        ext v
        simp only [mem_filter,mem_erase]
        exact ⟨fun h => ⟨h.1.2,h.2⟩,fun h => ⟨⟨fun eq => ynw (eq ▸ h.2),h.1⟩,h.2⟩⟩
      rw [same,card_erase_of_mem wk,sizeK] at stopped
      rw [if_pos zq]; omega
    · rw [sizeK] at baseline
      rw [if_neg zq]; omega
  have sum := sum_le_sum (s := rows) (fun z hz => (per z hz).1)
  have swap : (∑ z ∈ rows, (FiniteRange.bad G s (z.1∪z.2)).card) =
      ∑ v ∈ M, (rows.filter (fun z => v ∈ FiniteRange.bad G s (z.1∪z.2))).card := by
    calc
      _ = ∑ z ∈ rows, ∑ v ∈ M, (if v ∈ FiniteRange.bad G s (z.1∪z.2) then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro z hz
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr (per z hz).2]
      _ = _ := by rw [sum_comm]; simp
  have out := outside G xc ch t h c rule rfl nc nm dis cover
  rw [cover] at out
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,swap] at sum
  have den : rows.card=c.choose 2*(32-c).choose b := by simp only [rows,card_product,card_powersetCard,nc,nm]
  have raw := RankAccounting.activation C M (G.neighborFinset y) dis (by decide : 1≤2) bp
  have ny : (G.neighborFinset y∩C).card+(G.neighborFinset y∩M).card=2 := by
    rw [← card_union_of_disjoint (dis.mono inter_subset_right inter_subset_right),← inter_union_distrib_left,
      cover,inter_eq_left.mpr ins,card_neighborFinset_eq_degree,yd]
  let a := (G.neighborFinset y∩C).card
  have le : a≤2 := by change (G.neighborFinset y∩C).card≤2; omega
  have val := (numbers rule).2.1 ⟨a,by omega⟩
  have eq (z : Finset V × Finset V) : (z.1∪z.2)∩G.neighborFinset y=(z.1∪z.2).filter (G.Adj y) := by ext; simp
  simp only [eq,nc,nm,show (G.neighborFinset y∩M).card=2-a by dsimp [a]; omega] at raw
  change (rows.filter (fun z => 2≤nbr G y (z.1∪z.2))).card + few c (32-c) b 2 a = c.choose 2*(32-c).choose b at raw
  change few c (32-c) b 2 a+surplus c≤c.choose 2*(32-c).choose b at val
  simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr qr,den] at sum
  rw [Nat.mul_comm (c.choose 2*(32-c).choose b) (14-b)] at sum
  change (14-b)*(c.choose 2*(32-c).choose b)+(rows.filter (fun z => 2≤nbr G y (z.1∪z.2))).card+Q.card ≤ _ at sum
  have win := (numbers rule).2.2.2
  change charge c _ < (14-b)*(c.choose 2*(32-c).choose b)+surplus c+extra c f at win
  change (∑ v ∈ M, (rows.filter (fun z => v ∈ FiniteRange.bad G s (z.1∪z.2))).card) ≤ charge c _ at out
  change charge c f < _ at win
  change (∑ v ∈ M, (rows.filter (fun z => v ∈ FiniteRange.bad G s (z.1∪z.2))).card) ≤ charge c f at out
  omega

end Graffiti384b.CliquePivot
#print axioms Graffiti384b.CliquePivot.exact
