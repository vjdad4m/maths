import CliqueChoice384b

namespace Graffiti384b.CliqueSample
open Finset SimpleGraph CliqueChoice LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.greedy LowSample.eligible LowSample.weight LowSample.anchors LowSample.two_degree LowSample.anchor_samples LowSample.delta from LowSample384b
open private Repair.omit_set Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def active (p k : Finset V) := p.filter (fun v => 2 ≤ nbr G v k)

private theorem trial {p : Finset V} {tested : Finset ℕ} (choice : Choice G p tested) (k : Finset V) (ks : k ⊆ high G \ p)
    (fail : bound G < gamma G) :
    let s := high G \ p
    6*(s.card-k.card) + (∑ v ∈ LowSample.eligible G k, LowSample.weight (LowSample.anchors G v).card) + 6*(active G p k).card ≤
      6*((((types G).card+1)/2-1) + (FiniteRange.bad G s k).card) := by
  let s := high G \ p
  let e := LowSample.eligible G k
  let a := (s \ k) \ FiniteRange.bad G s k
  let c := active G p k
  have low : e ⊆ (high G)ᶜ := fun v hv => mem_compl.mpr (mem_sdiff.mp (mem_filter.mp hv).1).2
  obtain ⟨o,oe,ind,mass⟩ := LowSample.greedy G e (fun v => LowSample.weight (LowSample.anchors G v).card) (by
    intro v hv
    have deg := LowSample.two_degree G (mem_filter.mp hv).1
    have count := Repair.full_nbr G v (high G)
    have mono : nbr G v e ≤ nbr G v (high G)ᶜ := card_le_card (filter_subset_filter _ low)
    change nbr G v (high G) + nbr G v (high G)ᶜ = _ at count
    change (nbr G v e+1) * LowSample.weight (nbr G v (high G)) ≤ 6
    unfold LowSample.weight
    split_ifs <;> omega)

  have ar : a ⊆ s := sdiff_subset.trans sdiff_subset
  have ak : Disjoint a k := disjoint_left.mpr (fun _ va => (mem_sdiff.mp (mem_sdiff.mp va).1).2)
  have cp : c ⊆ p := filter_subset _ _
  have ao : Disjoint a o := disjoint_left.mpr (fun _ ha ho => mem_compl.mp (low (oe ho)) (mem_sdiff.mp (ar ha)).1)
  have ac : Disjoint a c := disjoint_left.mpr (fun _ ha hc => (mem_sdiff.mp (ar ha)).2 (cp hc))
  have oc : Disjoint o c := disjoint_left.mpr (fun _ ho hc => mem_compl.mp (low (oe ho)) (choice.high_sub (cp hc)))
  let omitted := (a ∪ o) ∪ c
  have keep : k ⊆ omittedᶜ := by
    intro v vk
    apply mem_compl.mpr
    intro h
    rcases mem_union.mp h with h | vc
    · rcases mem_union.mp h with va | vo
      · exact disjoint_left.mp ak va vk
      · exact mem_compl.mp (low (oe vo)) (mem_sdiff.mp (ks vk)).1
    · exact (mem_sdiff.mp (ks vk)).2 (cp vc)
  have safe (v : V) (vo : v ∈ omitted) : 2 ≤ nbr G v omittedᶜ := by
    rcases mem_union.mp vo with base | vc
    · rcases mem_union.mp base with va | vl
      · by_cases hit : ∃ w ∈ c, G.Adj w v
        · obtain ⟨w,wc,wv⟩ := hit
          have sub : k.filter (G.Adj w) ⊆ omittedᶜ.filter (G.Adj v) := by
            intro y hy
            obtain ⟨yk,wy⟩ := mem_filter.mp hy
            have ne : v ≠ y := fun h => disjoint_left.mp ak va (h ▸ yk)
            exact mem_filter.mpr ⟨keep yk,saturated_clique G (choice.exact_score _ (cp wc)) v y wv wy ne⟩
          exact (mem_filter.mp wc).2.trans (card_le_card sub)
        · obtain ⟨vk,good⟩ := mem_sdiff.mp va
          have enough : 2 ≤ nbr G v (sᶜ ∪ k) := Nat.le_of_not_gt (fun lt => good (mem_filter.mpr ⟨vk,lt⟩))
          apply enough.trans (card_le_card ?_)
          intro y hy
          obtain ⟨yk,adj⟩ := mem_filter.mp hy
          refine mem_filter.mpr ⟨mem_compl.mpr ?_,adj⟩
          intro m
          rcases mem_union.mp m with m | yc
          · rcases mem_union.mp m with ya | yo
            · exact (mem_union.mp yk).elim (fun l => mem_compl.mp l (ar ya)) (fun yy => disjoint_left.mp ak ya yy)
            · have anchored := (mem_filter.mp (oe yo)).2
              exact (mem_sdiff.mp vk).2 (anchored (mem_filter.mpr ⟨(mem_sdiff.mp (ar va)).1,adj.symm⟩))
          · exact hit ⟨y,yc,adj.symm⟩
      · have deg := LowSample.two_degree G (mem_filter.mp (oe vl)).1
        have sub : G.neighborFinset v ⊆ omittedᶜ.filter (G.Adj v) := by
          intro w hw
          have adj := (G.mem_neighborFinset _ _).mp hw
          refine mem_filter.mpr ⟨mem_compl.mpr ?_,adj⟩
          intro m
          rcases mem_union.mp m with m | wc
          · rcases mem_union.mp m with wa | wo
            · exact disjoint_left.mp ak wa ((mem_filter.mp (oe vl)).2 (mem_filter.mpr ⟨(mem_sdiff.mp (ar wa)).1,adj⟩))
            · exact ind v vl w wo adj
          · have vs := neighbors_in_pool G choice (cp wc) ((G.mem_neighborFinset _ _).mpr adj.symm)
            exact mem_compl.mp (low (oe vl)) (mem_sdiff.mp vs).1
        simpa only [card_neighborFinset_eq_degree,deg,nbr] using card_le_card sub
    · exact (mem_filter.mp vc).2.trans (card_le_card (filter_subset_filter _ keep))
  have up := Repair.omit_set G _ safe
  have size : omitted.card = a.card + o.card + c.card := by
    rw [show omitted = (a ∪ o) ∪ c from rfl,card_union_of_disjoint (disjoint_union_left.mpr ⟨ac,oc⟩),card_union_of_disjoint ao]
  have part : a.card + (FiniteRange.bad G s k).card = s.card-k.card := by
    rw [← card_sdiff ks]; exact card_sdiff_add_card_eq_card (filter_subset _ _)
  rw [size] at up
  unfold bound at fail
  change 6*(s.card-k.card) + (∑ v ∈ e, LowSample.weight (LowSample.anchors G v).card)+6*c.card ≤ 6*(_+(FiniteRange.bad G s k).card)
  omega

def bonus (m b d : ℕ) := m.choose b - FiniteRange.badCount (m+1) b d

private theorem active_fiber {p : Finset V} {tested : Finset ℕ} (ch : Choice G p tested) (b : ℕ) {v : V} (vp : v ∈ p) :
    let s := high G \ p
    bonus s.card b (G.degree v) ≤ ((s.powersetCard b).filter (fun k => v ∈ active G p k)).card := by
  let s := high G \ p
  have ns := neighbors_in_pool G ch vp
  have nv : v ∉ s := fun h => (mem_sdiff.mp h).2 vp
  have opt : (s.powersetCard b).filter (fun k => v ∉ active G p k) ⊆
      ((insert v s).powersetCard b).filter (fun k => v ∈ FiniteRange.bad G (insert v s) k) := by
    intro k hk
    obtain ⟨ks,no⟩ := mem_filter.mp hk
    obtain ⟨sub,kb⟩ := mem_powersetCard.mp ks
    have lt : nbr G v k < 2 := Nat.lt_of_not_ge (fun n => no (mem_filter.mpr ⟨vp,n⟩))
    have eq : ((insert v s)ᶜ ∪ k).filter (G.Adj v) = k.filter (G.Adj v) := by
      ext y; simp only [mem_filter,mem_union]; constructor
      · rintro ⟨l | m,vy⟩
        · exact (mem_compl.mp l (mem_insert_of_mem (ns ((G.mem_neighborFinset _ _).mpr vy)))).elim
        · exact ⟨m,vy⟩
      · exact fun h => ⟨Or.inr h.1,h.2⟩
    exact mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub.trans (subset_insert _ _),kb⟩,
      mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_insert_self _ _,fun h => nv (sub h)⟩,by simpa only [nbr,eq] using lt⟩⟩
  have ds : G.degree v ≤ s.card := by simpa only [card_neighborFinset_eq_degree] using card_le_card ns
  have loss := (card_le_card opt).trans (FiniteRange.count_bad G (insert v s) b (G.degree v) v
    (mem_insert_self _ _) le_rfl (by rw [card_insert_of_not_mem nv]; omega))
  rw [card_insert_of_not_mem nv] at loss
  have split := filter_card_add_filter_neg_card_eq_card (s := s.powersetCard b) (fun k => v ∈ active G p k)
  rw [card_powersetCard] at split
  change s.card.choose b - FiniteRange.badCount (s.card+1) b (G.degree v) ≤ ((s.powersetCard b).filter (fun k => v ∈ active G p k)).card
  omega

end Graffiti384b.CliqueSample
namespace Graffiti384b.CliqueSample
open Finset SimpleGraph CliqueChoice LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.eligible LowSample.weight LowSample.anchors LowSample.two_degree LowSample.anchor_samples LowSample.delta from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def charge (t h m b : ℕ) (f : Finset ℕ) (tested : Finset ℕ := degrees) := m * FiniteRange.badCount m b 11 + ∑ j ∈ range 11,
  LowSample.delta m b j * min m (h + slots f j tested - t - (f.filter (· ≤ j)).card)

def envelope (m b : ℕ) := ∀ d : Fin 12, 3 ≤ d.val → FiniteRange.badCount m b d.val ≤
  FiniteRange.badCount m b 11 + ∑ j ∈ range 11, if d.val ≤ j then LowSample.delta m b j else 0
def reward (m b : ℕ) := ∀ d : Fin 3, 6*(m-2).choose (b-2) ≤ LowSample.weight d.val * (m-d.val).choose (b-d.val)

private theorem pool_loss {p : Finset V} {tested : Finset ℕ} (choice : Choice G p tested) (b : ℕ)
    (extra : V → ℕ)
    (refund : ∀ v ∈ high G \ p, (((high G \ p).powersetCard b).filter (fun k => v ∈ FiniteRange.bad G (high G \ p) k)).card + extra v ≤
      FiniteRange.badCount (high G \ p).card b (min (G.degree v) 11)) (env : envelope (high G \ p).card b) :
    let s := high G \ p
    (∑ k ∈ s.powersetCard b, (FiniteRange.bad G s k).card) + (∑ v ∈ s, extra v) ≤
      charge (types G).card (high G).card s.card b (p.image (fun v => G.degree v)) tested := by
  classical
  let s := high G \ p
  let f := p.image (fun v => G.degree v)
  let opts := s.powersetCard b
  let fiber (z : V) := (opts.filter (fun k => z ∈ FiniteRange.bad G s k)).card
  have point (z : V) (hz : z ∈ s) : fiber z + extra z ≤ FiniteRange.badCount s.card b 11 +
      ∑ j ∈ range 11, if G.degree z ≤ j then LowSample.delta s.card b j else 0 := by
    have raw := refund z hz
    change fiber z + extra z ≤ FiniteRange.badCount s.card b (min (G.degree z) 11) at raw
    by_cases le : G.degree z ≤ 11
    · rw [min_eq_left le] at raw
      exact raw.trans (env ⟨G.degree z,by omega⟩ (mem_filter.mp (mem_sdiff.mp hz).1).2)
    · rw [min_eq_right (by omega)] at raw
      exact raw.trans (Nat.le_add_right ..)
  have step (j : ℕ) : (∑ z ∈ s, if G.degree z ≤ j then LowSample.delta s.card b j else 0) ≤
      LowSample.delta s.card b j * min s.card ((high G).card + slots f j tested - (types G).card - (f.filter (· ≤ j)).card) := by
    rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    by_cases pos : 3 ≤ j
    · have h := profile G choice j pos
      change (s.filter _).card + (types G).card + (f.filter (· ≤ j)).card ≤ (high G).card + slots f j tested at h
      apply Nat.mul_le_mul_left
      simp only [Nat.cast_id]
      have := card_filter_le s (fun z => G.degree z ≤ j)
      omega
    · simp [LowSample.delta,pos]
  have sumH := sum_le_sum point
  simp only [sum_add_distrib] at sumH
  rw [sum_comm (s := s) (t := range 11)] at sumH
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id] at sumH
  have ub : (∑ v ∈ s, fiber v) + (∑ v ∈ s, extra v) ≤ charge (types G).card (high G).card s.card b f tested :=
    sumH.trans (Nat.add_le_add_left (sum_le_sum (fun j _ => step j)) _)
  apply le_trans (Nat.add_le_add_right (le_of_eq ?_) _) ub
  calc
    _ = ∑ k ∈ opts, ∑ z ∈ s, (if z ∈ FiniteRange.bad G s k then 1 else 0 : ℕ) := by
      apply sum_congr rfl
      intro k _
      simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
      rw [inter_eq_right.mpr (show FiniteRange.bad G s k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
    _ = _ := by rw [sum_comm]; simp [fiber]


theorem extraObstruction {p : Finset V} {tested : Finset ℕ} (choice : Choice G p tested) (b : ℕ)
    (extra : V → ℕ)
    (refund : ∀ v ∈ high G \ p, (((high G \ p).powersetCard b).filter (fun k => v ∈ FiniteRange.bad G (high G \ p) k)).card + extra v ≤
      FiniteRange.badCount (high G \ p).card b (min (G.degree v) 11)) (two : 2 ≤ b)
    (env : envelope (high G \ p).card b) (rew : reward (high G \ p).card b)
    (fail : bound G < gamma G) :
    let f := p.image (fun v => G.degree v)
    let h := (high G).card
    let m := h-f.card
    6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) + 6*(∑ v ∈ high G \ p, extra v) ≤
      6*((((types G).card+1)/2-1)*m.choose b + charge (types G).card h m b f tested) := by
  let s := high G \ p
  let f := p.image (fun v => G.degree v)
  let opts := s.powersetCard b
  let z := twos G
  let W (v : V) := LowSample.weight (LowSample.anchors G v).card
  have mass : z.card * (6*(s.card-2).choose (b-2)) ≤ ∑ k ∈ opts, ∑ v ∈ LowSample.eligible G k, W v := by
    calc
      _ = ∑ _v ∈ z, (6*(s.card-2).choose (b-2)) := by simp
      _ ≤ ∑ v ∈ z, ∑ k ∈ opts, if LowSample.anchors G v ⊆ k then W v else 0 := by
        apply sum_le_sum
        intro v hv
        have count : (LowSample.anchors G v).card ≤ 2 := by
          have sub : LowSample.anchors G v ⊆ G.neighborFinset v := fun x hx =>
            (G.mem_neighborFinset _ _).mpr (mem_filter.mp hx).2
          simpa only [card_neighborFinset_eq_degree,LowSample.two_degree G hv] using card_le_card sub
        have a := rew ⟨(LowSample.anchors G v).card,by omega⟩
        have keep : LowSample.anchors G v ⊆ s := by
          intro w hw
          obtain ⟨wh,vw⟩ := mem_filter.mp hw
          exact mem_sdiff.mpr ⟨wh,fun wp => (mem_sdiff.mp hv).2
            (mem_sdiff.mp (neighbors_in_pool G choice wp ((G.mem_neighborFinset _ _).mpr vw.symm))).1⟩
        have q := LowSample.anchor_samples s (LowSample.anchors G v) b keep (by omega)
        rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.cast_id]
        simpa only [Nat.mul_comm (W v),W,opts,s] using a.trans (Nat.mul_le_mul_left _ q)
      _ = _ := by rw [sum_comm]; simp [LowSample.eligible,z,sum_filter]

  have credit : ∑ d ∈ f, bonus s.card b d ≤ ∑ k ∈ opts, (active G p k).card := by
    calc
      _ = ∑ v ∈ p, bonus s.card b (G.degree v) := sum_image (fun _ hx _ hy eq => choice.unique hx hy eq)
      _ ≤ ∑ v ∈ p, (opts.filter (fun k => v ∈ active G p k)).card :=
        sum_le_sum (fun v hv => active_fiber G choice b hv)
      _ = ∑ v ∈ p, ∑ k ∈ opts, (if v ∈ active G p k then 1 else 0 : ℕ) := by simp
      _ = _ := by
        rw [sum_comm]; apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show active G p k ⊆ p from filter_subset _ _)]
  have point (k : Finset V) (hk : k ∈ opts) : 6*(s.card-b) + (∑ v ∈ LowSample.eligible G k, W v) + 6*(active G p k).card ≤
      6*((((types G).card+1)/2-1) + (FiniteRange.bad G s k).card) := by
    obtain ⟨sub,sz⟩ := mem_powersetCard.mp hk
    have tr := trial G choice k sub fail
    dsimp only at tr
    rwa [sz] at tr
  have tot := sum_le_sum point
  simp only [sum_add_distrib,Nat.mul_add,← mul_sum,sum_const,nsmul_eq_mul,opts,card_powersetCard,Nat.cast_id] at tot
  have bad := pool_loss G choice b extra refund env
  change (∑ k ∈ s.powersetCard b, (FiniteRange.bad G s k).card) + (∑ v ∈ s, extra v) ≤ charge (types G).card (high G).card s.card b f tested at bad
  dsimp only [opts] at mass credit
  have sz : (high G).card - f.card = s.card := by rw [show f.card = p.card from card_image_of_injOn choice.unique]; exact (card_sdiff choice.high_sub).symm
  dsimp only
  change 6*((high G).card-f.card-b)*((high G).card-f.card).choose b + z.card*(6*((high G).card-f.card-2).choose (b-2)) +
    6*(∑ d ∈ f, bonus ((high G).card-f.card) b d) + 6*(∑ v ∈ s, extra v) ≤ 6*(_*((high G).card-f.card).choose b + charge _ _ ((high G).card-f.card) b f tested)
  rw [sz,Nat.mul_comm (6*(s.card-b)) (s.card.choose b),Nat.mul_left_comm (s.card.choose b) 6 (s.card-b),
    Nat.mul_comm (((types G).card+1)/2-1) (s.card.choose b)]
  omega

theorem obstruction {p : Finset V} {tested : Finset ℕ} (choice : Choice G p tested) (b : ℕ)
    (large : 12 ≤ (high G \ p).card) (two : 2 ≤ b)
    (env : envelope (high G \ p).card b) (rew : reward (high G \ p).card b)
    (fail : bound G < gamma G) :
    let f := p.image (fun v => G.degree v)
    let h := (high G).card
    let m := h-f.card
    6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) ≤
      6*((((types G).card+1)/2-1)*m.choose b + charge (types G).card h m b f tested) := by
  have cert := extraObstruction G choice b (fun _ => 0) (by
    intro v hv
    rw [Nat.add_zero]
    exact FiniteRange.count_bad G _ b _ v hv (min_le_left _ _) (by omega)) two env rew fail
  simpa only [sum_const_zero,Nat.mul_zero,Nat.add_zero] using cert

end Graffiti384b.CliqueSample

#print axioms Graffiti384b.CliqueSample.obstruction

