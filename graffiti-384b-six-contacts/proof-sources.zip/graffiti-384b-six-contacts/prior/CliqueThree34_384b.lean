import CliqueMass34_384b
import Overlap34_384b

namespace Graffiti384b.Overlap34
open SimpleGraph Finset LowSample
open private Repair.nbr_add Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A single degree-two exterior vertex can never supplement just two
exterior high vertices of degree at most five to block every clique pair.
The pair is selected to protect both low-degree high vertices together. -/
theorem three {C : Finset V} {y : V} (cl : G.IsNClique 5 C) (ears : twos G⊆insert y C)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    3≤((high G\C).filter (fun v => G.degree v≤5)).card := by
  classical
  let L := (high G\C).filter (fun v => G.degree v≤5)
  by_contra! small
  change L.card<3 at small
  have count {K : Finset V} (ks : K⊆C) (v : V) : nbr G v C=nbr G v (C\K)+nbr G v K := by
    have eq := Repair.nbr_add G v (show Disjoint (C\K) K from disjoint_left.mpr (fun _ vm => (mem_sdiff.mp vm).2))
    rwa [sdiff_union_of_subset ks] at eq
  have cap {K : Finset V} (ks : K⊆C) (kc : K.card=2) : CliqueMass34.blocked G C K⊆insert y L := by
    intro v vb
    obtain ⟨out,lt⟩ := mem_filter.mp vb
    have vn := (mem_sdiff.mp out).1
    have vc := (mem_sdiff.mp out).2
    by_cases vh : v∈high G
    · have mx : nbr G v (C\K)≤3 := (card_filter_le _ _).trans (by rw [card_sdiff ks,cl.2,kc])
      exact mem_insert_of_mem (mem_filter.mpr ⟨mem_sdiff.mpr ⟨vh,vc⟩,by omega⟩)
    · exact mem_insert.mpr (Or.inl ((mem_insert.mp (ears (mem_sdiff.mpr ⟨vn,vh⟩))).resolve_right vc))
  have notFull (v : V) (vl : v∈L) : ¬G.neighborFinset v⊆C := by
    intro supp
    have vh := (mem_sdiff.mp (mem_filter.mp vl).1).1
    have vc := (mem_sdiff.mp (mem_filter.mp vl).1).2
    have d := (mem_filter.mp vh).2
    obtain ⟨K,kn,kc⟩ := exists_subset_card_eq (show 2≤(G.neighborFinset v).card by rw [card_neighborFinset_eq_degree]; omega)
    have ks := kn.trans supp
    have allK : K.filter (G.Adj v)=K := filter_true_of_mem (fun j jm => (G.mem_neighborFinset _ _).mp (kn jm))
    have hits : nbr G v K=2 := by rw [nbr,allK,kc]
    have vs : v∈CliqueMass34.supported G C K := mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,vc⟩,supp,kn⟩
    have pos := card_pos.mpr ⟨v,vs⟩
    have need := CliqueMass34.pair G cl kc ks same fail
    have notBlocked : v∉CliqueMass34.blocked G C K := by
      intro vb
      have lt := (mem_filter.mp vb).2
      have parts := count ks v
      have full := Repair.full_nbr G v C
      omega
    have sub : CliqueMass34.blocked G C K⊆insert y (L.erase v) := by
      intro r rb
      rcases mem_insert.mp (cap ks kc rb) with ry|rl
      · exact mem_insert.mpr (Or.inl ry)
      · exact mem_insert_of_mem (mem_erase.mpr ⟨fun e => notBlocked (e ▸ rb),rl⟩)
    have le := (card_le_card sub).trans (card_insert_le ..)
    rw [card_erase_of_mem vl] at le
    omega
  let T := L.filter (fun v => 0<nbr G v C)
  let pick (v : V) := if pos : 0<nbr G v C then (card_pos.mp pos).choose else y
  have chosen (v : V) (vm : v∈T) : pick v∈C ∧ G.Adj v (pick v) := by
    have pos := (mem_filter.mp vm).2
    change 0<nbr G v C at pos
    simpa only [pick,dif_pos pos] using mem_filter.mp (card_pos.mp pos).choose_spec
  have inC : T.image pick⊆C := by
    rintro v vm
    obtain ⟨r,rr,rfl⟩ := mem_image.mp vm
    exact (chosen r rr).1
  have sz := (card_image_le (s:=T) (f:=pick)).trans (card_filter_le L _)
  obtain ⟨K,protect,ks,kc⟩ := exists_subsuperset_card_eq inC (show (T.image pick).card≤2 by omega)
    (show 2≤C.card by rw [cl.2]; decide)
  have none : CliqueMass34.blocked G C K⊆{y} := by
    intro r rb
    rcases mem_insert.mp (cap ks kc rb) with ry|rl
    · exact mem_singleton.mpr ry
    have parts := count ks r
    have full := Repair.full_nbr G r C
    have dg := (mem_filter.mp (mem_sdiff.mp (mem_filter.mp rl).1).1).2
    have lt := (mem_filter.mp rb).2
    have tot : 0<nbr G r C := by omega
    have rt : r∈T := mem_filter.mpr ⟨rl,tot⟩
    have edge := (chosen r rt).2
    have one : 0<nbr G r K := card_pos.mpr ⟨pick r,mem_filter.mpr ⟨protect (mem_image.mpr ⟨r,rt,rfl⟩),edge⟩⟩
    obtain ⟨j,jn,jc⟩ := not_subset.mp (notFull r rl)
    have ext : 0<nbr G r Cᶜ := card_pos.mpr ⟨j,mem_filter.mpr ⟨mem_compl.mpr jc,(G.mem_neighborFinset _ _).mp jn⟩⟩
    omega
  have need := CliqueMass34.pair G cl kc ks same fail
  have lim := card_le_card none
  rw [card_singleton] at lim
  omega

end Graffiti384b.Overlap34
#print axioms Graffiti384b.Overlap34.three
