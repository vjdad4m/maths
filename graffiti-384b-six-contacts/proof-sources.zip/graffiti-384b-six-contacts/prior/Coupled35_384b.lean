import SwitchRanks384b
import SwitchBalance384b
import SwitchEar384b
import JointDense384b

universe u
namespace Graffiti384b.Coupled35
open Finset SimpleGraph CliqueChoice CliqueSample Switch35
variable {V : Type u} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Conditional omission in the triangle skeleton. Its zero-count
vertex can be isolated and the skeleton can be disconnected. -/
theorem core (n : Fintype.card V=35) (t : (types G).card=35) (q : (nonleaves G).card=34)
    (hc : (high G).card=33) (inj : Function.Injective (trianglesAt G)) (fail : bound G<gamma G)
    {l y x u v : V} (dl : G.degree l=0) (yone : trianglesAt G y=1) (ny : G.neighborFinset y={u,v})
    (uv : G.Adj u v) (uh : u∈high G) (vh : v∈high G) (xscore : trianglesAt G x=2)
    {e f : Finset V} (pairs : TwoLinks35.pairs G x={e,f}) (ec : e.card=2) (fc : f.card=2)
    (links : G.neighborFinset x=e∪f) (degree : G.degree x=(if Disjoint e f then 4 else 3)) : False := by
  classical
  have lout : l∉G.neighborFinset x := fun h => by
    have := (G.degree_pos_iff_exists_adj l).mpr ⟨x,((G.mem_neighborFinset _ _).mp h).symm⟩
    omega
  have dy : G.degree y=2 := by rw [←card_neighborFinset_eq_degree,ny,card_pair uv.ne]
  have xh : x∈high G := mem_filter.mpr ⟨mem_univ _,by split_ifs at degree <;> omega⟩
  have ylow : y∉high G := fun h => by have := (mem_filter.mp h).2; omega
  have llow : l∉high G := fun h => by have := (mem_filter.mp h).2; omega
  have ly : l≠y := fun eq => by subst y; omega
  have low : (high G)ᶜ={l,y} := (eq_of_subset_of_card_le
    (insert_subset (mem_compl.mpr llow) (singleton_subset_iff.mpr (mem_compl.mpr ylow)))
    (by rw [card_compl,n,hc,card_pair ly])).symm
  letI : Nonempty V := ⟨x⟩
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  have deg (z : V) (zp : z∈p) : G.degree z=3 := by
    have level := mem_Icc.mp (ch.levels (mem_image_of_mem (G.degree ·) zp))
    change 3≤G.degree z ∧ G.degree z≤9 at level
    apply Classical.byContradiction
    intro no
    exact (not_lt_of_ge (Pivotal35.exact_saturated G t hc q z (by omega) level.2 (ch.exact_score z zp))) fail
  have sc (z : V) (zp : z∈p) : trianglesAt G z=3 := by
    have eq := ch.exact_score z zp
    rw [deg z zp] at eq
    exact eq
  have oneP : p.card≤1 := card_le_one.mpr (fun a ha b hb => inj ((sc a ha).trans (sc b hb).symm))
  have choices : p.card=0 ∨ p.card=1 := by omega
  have xp : x∉p := fun h => by have := sc x h; omega
  have no_edge (z : V) (zp : z∈p) : ¬G.Adj x z := by
    intro edge
    have cl := saturated_clique G (ch.exact_score z zp)
    have cap := JointDense.score_of_dominating_neighbor G edge.symm (fun w zw diff => cl x w edge.symm zw diff.symm)
    rw [sc z zp,xscore] at cap
    omega
  let s := (high G \ p).erase x
  let N := G.neighborFinset x
  let A := N∩s
  let C := p.biUnion (fun w => G.neighborFinset w)
  have size : s.card=32-p.card := by
    rw [show s=(high G\p).erase x from rfl,card_erase_of_mem (mem_sdiff.mpr ⟨xh,xp⟩),card_sdiff ch.high_sub,hc]; omega
  have xs : x∉s := not_mem_erase _ _
  have hi : s⊆high G := (erase_subset ..).trans sdiff_subset
  have yout : y∉s := fun h => ylow (hi h)
  have ys : y∉p := fun h => ylow (ch.high_sub h)
  have xy : x≠y := fun e => ylow (e ▸ xh)
  have pn (z : V) (zp : z∈p) : G.neighborFinset z ⊆ s := by
    intro b hb
    exact mem_erase.mpr ⟨fun eq => no_edge z zp ((G.mem_neighborFinset _ _).mp (eq ▸ hb)).symm,
        neighbors_in_pool G ch zp hb⟩
  have cs : C⊆s := by intro z zm; obtain ⟨b,bp,bz⟩ := mem_biUnion.mp zm; exact pn b bp bz
  have fixed (z : V) (zm : z∈C) : ∃ w, w∉s ∧ w≠x ∧ ¬G.Adj x w ∧ G.Adj z w := by
    obtain ⟨b,bp,bz⟩ := mem_biUnion.mp zm
    exact ⟨b,fun h => (mem_sdiff.mp (erase_subset _ _ h)).2 bp,fun eq => xp (eq ▸ bp),no_edge b bp,((G.mem_neighborFinset _ _).mp bz).symm⟩
  have csize : C.card=3*p.card := by
    rcases choices with zero|one
    · simp [C,card_eq_zero.mp zero]
    · obtain ⟨b,eq⟩ := card_eq_one.mp one
      have bp : b∈p := eq ▸ mem_singleton_self _
      simp [C,eq,deg b bp]
  have onlyY {z : V} (zn : z∈N) (ns : z∉s) : z=y := by
    have xz := (G.mem_neighborFinset _ _).mp zn
    have noP : z∉p := fun zp => no_edge z zp xz
    have lowZ : z∈(high G)ᶜ := mem_compl.mpr (fun m => ns (mem_erase.mpr ⟨xz.ne.symm,mem_sdiff.mpr ⟨m,noP⟩⟩))
    rw [low,mem_insert,mem_singleton] at lowZ
    exact lowZ.resolve_left (fun eq => lout (eq ▸ zn))
  have outside : N\s ⊆ {y} := fun z hz => mem_singleton.mpr (onlyY (mem_sdiff.mp hz).1 (mem_sdiff.mp hz).2)
  have diff : (N\s).card+A.card=G.degree x := by simpa only [A,N,card_neighborFinset_eq_degree] using card_sdiff_add_card_inter N s
  have atMost := card_le_card outside
  rw [card_singleton] at atMost
  let a := if A=N then A.card else 2
  have aCases : a=2 ∨ a=3 ∨ a=4 := by
    dsimp [a]
    split_ifs with eq
    · rw [eq,show N.card=G.degree x from card_neighborFinset_eq_degree ..,degree]; split_ifs <;> omega
    · exact Or.inl rfl
  have dCases : G.degree x=3 ∨ G.degree x=4 := by split_ifs at degree <;> omega
  have ac : A.card=2 ∨ A.card=3 ∨ A.card=4 := by omega
  have aLe : a≤A.card := by dsimp only [a]; split_ifs <;> omega
  have distinct (_a3 : a=3) : p.card≤(C\A).card := by
    rcases choices with zero|one
    · omega
    · rw [one]
      by_contra! empty
      have sub := sdiff_eq_empty_iff_subset.mp (card_eq_zero.mp (show (C\A).card=0 by omega))
      obtain ⟨z,pe⟩ := card_eq_one.mp one
      have zp : z∈p := pe ▸ mem_singleton_self _
      have cn : C=G.neighborFinset z := by simp [C,pe]
      have incl : G.neighborFinset z⊆G.neighborFinset x := by rw [←cn]; exact sub.trans inter_subset_left
      have le : trianglesAt G z≤trianglesAt G x := card_le_card (filter_subset_filter _ (powersetCard_mono incl))
      rw [sc z zp,xscore] at le
      omega
  have Qear {z : V} (zy : G.Adj y z) (a2 : a≠2) : z∈s := by
    have zn := (G.mem_neighborFinset _ _).mpr zy
    have yz : z∈high G := by rw [ny,mem_insert,mem_singleton] at zn; exact zn.elim (fun e => e ▸ uh) (fun e => e ▸ vh)
    have zp : z∉p := fun h => yout (pn z h ((G.mem_neighborFinset _ _).mpr zy.symm))
    refine mem_erase.mpr ⟨?_,mem_sdiff.mpr ⟨yz,zp⟩⟩
    intro eq
    have yn : y∈N := (G.mem_neighborFinset _ _).mpr (eq ▸ zy).symm
    have neq : A≠N := fun w => yout (mem_inter.mp (show y∈A from w ▸ yn)).2
    exact a2 (if_neg neq)
  let Q := if a=2 then p else insert y p
  have qual {z : V} (zq : z∈Q) : z∈p ∨ (z=y ∧ a≠2) := by
    dsimp only [Q] at zq
    split_ifs at zq with two
    · exact Or.inl zq
    · exact (mem_insert.mp zq).elim (fun e => Or.inr ⟨e,two⟩) Or.inl
  have qout : Q⊆sᶜ := by
    intro z zm
    rcases qual zm with zp|⟨rfl,_⟩
    · exact mem_compl.mpr (fun m => (mem_sdiff.mp (erase_subset _ _ m)).2 zp)
    · exact mem_compl.mpr yout
  have free : x∉Q := fun m => (qual m).elim xp (fun h => xy h.1)
  have qn (z : V) (zm : z∈Q) : G.neighborFinset z⊆s := by
    rcases qual zm with zp|⟨rfl,a2⟩
    · exact pn z zp
    · exact fun _ hz => Qear ((G.mem_neighborFinset _ _).mp hz) a2
  have qc (z : V) (zm : z∈Q) : cliqueAt G z := by
    rcases qual zm with zp|⟨rfl,_⟩
    · exact saturated_clique G (ch.exact_score z zp)
    · apply saturated_clique
      rw [yone,dy]; decide
  have inc : income p.card a ≤ ∑ z∈Q,bonus s.card 12 (G.degree z) := by
    have sumP : (∑ z∈p,bonus s.card 12 (G.degree z))=p.card*bonus s.card 12 3 := by
      calc
        _ = ∑ _z∈p,bonus s.card 12 3 := sum_congr rfl (fun z zp => by rw [deg z zp])
        _ = _ := by simp
    have b2 : bonus s.card 12 2=(s.card-2).choose 10 := by
      rw [size]
      rcases choices with e|e <;> rw [e] <;> unfold bonus FiniteRange.badCount <;>
        simp only [Nat.choose_eq_fast_choose] <;> decide
    dsimp only [Q]
    split_ifs with two
    · rw [sumP,size]; simp [income,earMass,two]
    · rw [sum_insert ys,sumP,dy,b2,size]; simp [income,earMass,two]
  have rules : ∃ on : Finset V → Bool,
      mass s.card a ≤ ((s.powersetCard 12).filter (fun k => on k=true)).card ∧
      (∀ k∈s.powersetCard 12, on k=true → 2≤nbr G x (base s k x (on k))) ∧
      (∀ z∈A, ∃ w, G.Adj z w ∧ G.Adj x w ∧ ∀ k∈s.powersetCard 12, z∉k →
        x∈base s k x (on k) ∨ w∈base s k x (on k)) := by
    by_cases both : Disjoint e f ∧ A≠N
    · have aa : a=2 := if_neg both.2
      rw [aa]
      have notsub : ¬N⊆s := fun h => both.2 (inter_eq_left.mpr h)
      obtain ⟨b,bn,bout⟩ := not_subset.mp notsub
      have yn : y∈e∪f := links ▸ ((onlyY bn bout) ▸ bn)
      have sub {P : Finset V} (pn' : P⊆N) (excluded : y∉P) : P⊆s := fun z zm =>
        Classical.byContradiction (fun no => excluded ((onlyY (pn' zm) no) ▸ zm))
      rcases mem_union.mp yn with ye|yf
      · have fs : f⊆s := sub (by change f⊆G.neighborFinset x; rw [links]; exact subset_union_right)
          (fun m => disjoint_left.mp both.1 ye m)
        exact four_ear G xs yout ye fs ec fc links.symm inter_subset_left inter_subset_right pairs
      · have es : e⊆s := sub (by change e⊆G.neighborFinset x; rw [links]; exact subset_union_left)
          (fun m => disjoint_left.mp both.1 m yf)
        exact four_ear G xs yout yf es fc ec (by rw [union_comm,←links]) inter_subset_left inter_subset_right
          (by rw [pairs,pair_comm e f])
    · have eq : a=A.card := by
        by_cases same : A=N
        · exact if_pos same
        · have nond : ¬Disjoint e f := fun h => both ⟨h,same⟩
          have dg : G.degree x=3 := by simpa [nond] using degree
          have notsub : ¬N⊆s := fun h => same (inter_eq_left.mpr h)
          obtain ⟨b,bn,bo⟩ := not_subset.mp notsub
          have pos := card_pos.mpr (show (N\s).Nonempty from ⟨b,mem_sdiff.mpr ⟨bn,bo⟩⟩)
          rw [show a=2 from if_neg same]; omega
      rw [eq]
      exact ⟨rule A e f,Switch35.shape G (s:=s) (A:=A) rfl xs links.symm ⟨ec,fc⟩ pairs degree
        (fun dis => Classical.byContradiction (fun neq => both ⟨dis,neq⟩)) ac⟩
  obtain ⟨on,active,two,cover⟩ := rules
  have bal := balance G on qout free xs qc qn two t fail
  have bal' := (Nat.add_le_add (Nat.add_le_add_left inc ((s.card-12)*s.card.choose 12)) active).trans bal
  apply estimate G p.card a on choices aCases size aLe csize ?_ hi rfl cs fixed cover
    (ranks G t hc q inj fail ch deg choices rfl size xscore) bal'
  split_ifs with a3
  · exact distinct a3
  · exact Nat.zero_le _

end Graffiti384b.Coupled35
#print axioms Graffiti384b.Coupled35.core
