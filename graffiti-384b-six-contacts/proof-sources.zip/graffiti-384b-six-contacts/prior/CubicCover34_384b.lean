import Recolor34_384b

namespace Graffiti384b.CubicCover34
open Finset SimpleGraph
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def cubes := (high G).filter (fun v => G.degree v=3)

theorem crowded {C W : Finset V} (many : 5≤C.card)
    (t : (types G).card=(high G).card+2)
    (cover : ∀ a∈C,∃ v∈cubes G,nbr G v W=0 ∧ G.Adj v a) :
    (∀ v∈cubes G,nbr G v W=0 ∧ 2≤nbr G v C) ∧
    (∀ u∈high G,u∉cubes G → 4≤trianglesAt G u) := by
  classical
  let H := cubes G
  obtain ⟨inj,lo,_,_⟩ := Repair.maximal_diversity G t
  have rangeSub : H.image (trianglesAt G)⊆{2,3} := by
    intro k km
    obtain ⟨v,vm,rfl⟩ := mem_image.mp km
    obtain ⟨vh,d⟩ := mem_filter.mp vm
    have a := lo v vh
    have b := Repair.triangles_le_choose G v
    rw [d] at b
    change trianglesAt G v≤3 at b
    simp only [mem_insert,mem_singleton]; omega
  have size := card_le_card rangeSub
  have images : (H.image (trianglesAt G)).card=H.card :=
    card_image_of_injOn (inj.mono (fun _ vm => (mem_filter.mp vm).1))
  rw [images,card_pair (by decide : (2:ℕ)≠3)] at size
  have lim (T : Finset V) (sub : T⊆H) : (T.biUnion (fun v => G.neighborFinset v)).card≤T.card*3 := by
    calc
      _ ≤ ∑ v∈T,(G.neighborFinset v).card := card_biUnion_le
      _ = ∑ _v∈T,3 := sum_congr rfl (fun v vm => (card_neighborFinset_eq_degree G v).trans (mem_filter.mp (sub vm)).2)
      _ = _ := by simp
  have all : C⊆H.biUnion (fun v => G.neighborFinset v) := by
    intro a am
    obtain ⟨v,vm,_,va⟩ := cover a am
    exact mem_biUnion.mpr ⟨v,vm,(G.mem_neighborFinset _ _).mpr va⟩
  have lower := (card_le_card all).trans (lim H Subset.rfl)
  have im := eq_of_subset_of_card_le rangeSub (by rw [images,card_pair (by decide : (2:ℕ)≠3)]; omega)
  constructor
  · intro v vm
    let T := (H.erase v).biUnion (fun j => G.neighborFinset j)
    have small := lim (H.erase v) (erase_subset ..)
    rw [card_erase_of_mem vm] at small
    change T.card≤(H.card-1)*3 at small
    have rest : C\T⊆C.filter (G.Adj v) := by
      intro a am
      obtain ⟨j,jm,_,ja⟩ := cover a (mem_sdiff.mp am).1
      by_cases eq : j=v
      · exact mem_filter.mpr ⟨(mem_sdiff.mp am).1,eq ▸ ja⟩
      · exact ((mem_sdiff.mp am).2 (mem_biUnion.mpr ⟨j,mem_erase.mpr ⟨eq,jm⟩,(G.mem_neighborFinset _ _).mpr ja⟩)).elim
    have parts := card_sdiff_add_card_inter C T
    have cap := card_le_card (show C∩T⊆T from inter_subset_right)
    have extra : 2≤(C\T).card := by omega
    obtain ⟨a,am⟩ := card_pos.mp (show 0<(C\T).card by omega)
    obtain ⟨j,jm,jw,ja⟩ := cover a (mem_sdiff.mp am).1
    have eq : j=v := by
      by_cases ne : j=v
      · exact ne
      · exact ((mem_sdiff.mp am).2 (mem_biUnion.mpr ⟨j,mem_erase.mpr ⟨ne,jm⟩,(G.mem_neighborFinset _ _).mpr ja⟩)).elim
    exact ⟨eq ▸ jw,extra.trans (card_le_card rest)⟩
  · intro u uh non
    have low := lo u uh
    by_cases enough : 4≤trianglesAt G u
    · exact enough
    exfalso
    have inside : trianglesAt G u∈H.image (trianglesAt G) := by rw [im,mem_insert,mem_singleton]; omega
    obtain ⟨v,vm,eq⟩ := mem_image.mp inside
    exact non (inj (mem_filter.mp vm).1 uh eq ▸ vm)
end Graffiti384b.CubicCover34
#print axioms Graffiti384b.CubicCover34.crowded
