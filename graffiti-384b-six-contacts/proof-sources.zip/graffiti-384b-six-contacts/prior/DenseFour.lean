import FourTrial
namespace Graffiti384b.Four29
open Finset SimpleGraph Donor JointRank
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private Repair.triangles_le_choose Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def inside (r : ℕ) := if r < 1 then 226746 else if r < 2 then 187986 else if r < 4 then 171054 else if r < 8 then 121550 else if r < 13 then 81510 else if r < 19 then 51480 else if r < 26 then 30459 else 16731
private def outside (r : ℕ) := if r < 1 then 125970 else if r < 2 then 87210 else if r < 4 then 75582 else if r < 8 then 43758 else if r < 13 then 24310 else if r < 19 then 12870 else if r < 26 then 6435 else 3003

private def refund (r d : ℕ) := if r+2=d.choose 2 then (22:ℕ).choose 7-FiniteRange.badCount 23 7 d else 0
def cost (r p q : ℕ) := max (inside r) (max (outside r+p) (p+q))

private theorem prices : ∀r:Fin 27, ∀d:Fin 11, 3≤d.val → r.val+2≤d.val.choose 2 →
    FiniteRange.badCount 23 8 d ≤ inside r+refund r d ∧
    (23-d.val).choose 8 ≤ outside r+refund r d := by
  unfold inside outside refund FiniteRange.badCount
  simp only [Nat.choose_eq_fast_choose]
  decide

private theorem totals :
    (∑ r∈range 23,cost r 57200 0)+3392=3*(23:ℕ).choose 8+15*57200 ∧
    (∑ r∈range 23,cost r 57200 12870)+10542=3*(23:ℕ).choose 8+14*57200+7*12870 ∧
    (∑ r∈range 23,cost r 57200 24310)+16262=3*(23:ℕ).choose 8+13*57200+11*24310 := by
  unfold cost inside outside
  simp only [Nat.choose_eq_fast_choose]
  decide

def twice (X : Finset V) := X.filter (fun v => 2≤nbr G v Xᶜ)

/-- Any lower rank assignment can be used in the sample. This lets the
degree table account for high vertices that are permanently reserved. -/
theorem repair_budget {X E : Finset V} (fr : Pool G X E) (xs : X.card=23) (es : E.card=2)
    (fail : Fintype.card V-15<gamma G) (r : V→ℕ) (p q : ℕ)
    (lower : ∀v∈X,r v<27 ∧ 2+r v≤trianglesAt G v) :
    3*(23:ℕ).choose 8+(exposed G X).card*p+(twice G X).card*q ≤ ∑v∈X,cost (r v) p q := by
  classical
  let K := X.powersetCard 8
  let A (v : V) := (K.filter (fun k => v∈PendantRank.active G X k)).card
  let B (v : V) := (K.filter (fun k => v∈FiniteRange.bad G X k)).card
  let fee (v : V) := (if v∈exposed G X then p else 0)+(if v∈twice G X then q else 0)
  have each (v : V) (vm : v∈X) : B v+fee v≤cost (r v) p q+A v := by
    obtain ⟨rankLt,score⟩ := lower v vm
    have cap := Repair.triangles_le_choose G v
    let d := min (G.degree v) 10
    have sd : d≤G.degree v := min_le_left ..
    have dl : d≤10 := min_le_right ..
    have dc : r v+2≤d.choose 2 := by
      dsimp [d]; rcases le_total (G.degree v) 10 with h|h
      · rw [min_eq_left h,Nat.add_comm]; exact score.trans cap
      · rw [min_eq_right h]; change r v+2≤45; omega
    have deg3 : 3≤d := by
      by_contra! little
      have lo : 2≤r v+2 := by omega
      have small := Nat.choose_le_choose 2 (show d≤2 by omega)
      rw [Nat.choose_self] at small
      omega
    have lim := prices ⟨r v,rankLt⟩ ⟨d,by omega⟩ deg3 dc
    change FiniteRange.badCount 23 8 d ≤ inside (r v)+refund (r v) d ∧ (23-d).choose 8 ≤ outside (r v)+refund (r v) d at lim
    have act : refund (r v) d≤A v := by
      unfold refund
      split
      · rename_i eq
        have exactD : d=G.degree v := by
          by_contra! no
          have ten : d=10 := by dsimp [d] at *; omega
          rw [ten] at eq
          change r v+2=45 at eq
          omega
        have sat : trianglesAt G v=(G.degree v).choose 2 := by rw [←exactD] at cap ⊢; omega
        exact active_fiber G X xs vm sat 7 d sd (by omega)
      · omega
    have ci : inside (r v)≤cost (r v) p q := le_max_left .. 
    have ce : outside (r v)+p≤cost (r v) p q := (le_max_left ..).trans (le_max_right ..)
    have cd : p+q≤cost (r v) p q := (le_max_right ..).trans (le_max_right ..)
    by_cases dbl : v∈twice G X
    · have eq : B v=0 := card_eq_zero.mpr (eq_empty_iff_forall_not_mem.mpr (by
        intro k km
        have low := (mem_filter.mp (mem_filter.mp km).2).2
        have two := (mem_filter.mp dbl).2
        have le := Repair.nbr_mono G v (show Xᶜ⊆Xᶜ∪k from subset_union_left)
        omega))
      dsimp only [fee]; rw [eq,if_pos dbl]; split <;> omega
    · by_cases exposedV : v∈exposed G X
      · obtain ⟨w,wx,vw⟩ := (mem_filter.mp exposedV).2
        have bound := BoundaryFiber.count G X 8 d vm wx vw sd (by omega)
        rw [xs] at bound
        change B v≤(23-d).choose 8 at bound
        simp only [fee,if_neg dbl,if_pos exposedV,Nat.add_zero]
        omega
      · have bound := FiniteRange.count_bad G X 8 d v vm sd (by omega)
        rw [xs] at bound
        change B v≤FiniteRange.badCount 23 8 d at bound
        simp only [fee,if_neg dbl,if_neg exposedV,Nat.add_zero]
        omega
  have swap (f : Finset V→Finset V) (sub : ∀k∈K,f k⊆X) :
      (∑ k∈K,(f k).card)=∑v∈X,(K.filter (fun k => v∈f k)).card := by
    calc
      _ = ∑k∈K,∑v∈X,(if v∈f k then 1 else 0 : ℕ) := by
        apply sum_congr rfl; intro k km
        simp [sum_boole,filter_mem_eq_inter,inter_eq_right.mpr (sub k km)]
      _ = _ := by rw [sum_comm]; simp
  have mass := sum_le_sum each
  have collect (S : Finset V) (sub : S⊆X) (p : ℕ) :
      (∑v∈X,if v∈S then p else 0)=S.card*p := by
    rw [←sum_filter,filter_mem_eq_inter,inter_eq_right.mpr sub,sum_const,nsmul_eq_mul,Nat.cast_id]
  simp only [fee,sum_add_distrib,collect _ (show exposed G X⊆X from filter_subset ..),collect _ (show twice G X⊆X from filter_subset ..)] at mass
  have cb := swap (FiniteRange.bad G X) (fun _ _ => (filter_subset ..).trans sdiff_subset)
  have ca := swap (PendantRank.active G X) (fun _ km => (filter_subset ..).trans (mem_powersetCard.mp km).1)
  change _=∑v∈X,B v at cb
  change _=∑v∈X,A v at ca
  rw [←cb,←ca] at mass
  have lower (k : Finset V) (km : k∈K) : 3+(PendantRank.active G X k).card≤(FiniteRange.bad G X k).card := by
    obtain ⟨sub,kb⟩ := mem_powersetCard.mp km
    have tr := two_trials G fr es k sub
    have h := card_le_univ X
    omega
  have bound := sum_le_sum lower
  have count : K.card=(23:ℕ).choose 8 := by simp [K,xs]
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,count] at bound
  omega
/-- Exposure counts use all fixed vertices. A double contact incurs zero
deficiency in every trial. Prices for the two nested contact sets are additive. -/
theorem dense_pool {X E : Finset V} (fr : Pool G X E) (xs : X.card=23) (es : E.card=2)
    (contacts : 15≤(exposed G X).card ∨
      (14≤(exposed G X).card ∧ 7≤(twice G X).card) ∨ (13≤(exposed G X).card ∧ 11≤(twice G X).card)) :
    gamma G≤Fintype.card V-15 := by
  classical
  by_contra! fail
  obtain ⟨q,paid⟩ : ∃q : ℕ,(∑r∈range 23,cost r 57200 q)<3*(23:ℕ).choose 8+(exposed G X).card*57200+(twice G X).card*q := by
    obtain ⟨a,b,c⟩ := totals
    rcases contacts with h|⟨h,j⟩|⟨h,j⟩
    · exact ⟨0,by omega⟩
    · exact ⟨12870,by omega⟩
    · exact ⟨24310,by omega⟩
  let r := rank X (trianglesAt G)
  have enough := repair_budget G fr xs es fail r 57200 q (fun v vm => ⟨(show r v<27 by
    have small : r v<23 := mem_range.mp (by rw [←xs,←rank_range X (trianglesAt G) fr.distinct]; exact mem_image_of_mem _ vm)
    omega),rank_lower X (trianglesAt G) fr.distinct 2 fr.rich vm⟩)
  rw [sum_by_rank X (trianglesAt G) fr.distinct (fun i => cost i 57200 q),xs] at enough
  omega
end Graffiti384b.Four29
#print axioms Graffiti384b.Four29.repair_budget
#print axioms Graffiti384b.Four29.dense_pool
