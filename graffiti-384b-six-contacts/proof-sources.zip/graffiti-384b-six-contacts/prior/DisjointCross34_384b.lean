import Recolor34_384b
import EarSquares34_384b

namespace Graffiti384b.DisjointCross34
open Finset SimpleGraph LowSample
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem cross {y z : V} (yz : y≠z) (ears : twos G={y,z})
    (adj : ¬G.Adj y z) (sep : Disjoint (G.neighborFinset y) (G.neighborFinset z))
    (ab : ∀ i∈G.neighborFinset y,∃ j∈G.neighborFinset z,G.Adj i j)
    (ba : ∀ i∈G.neighborFinset z,∃ j∈G.neighborFinset y,G.Adj i j)
    (q : (types G).card≤(nonleaves G).card) : gamma G≤bound G := by
  let A := G.neighborFinset y
  let B := G.neighborFinset z
  have yt : y∈twos G := ears ▸ mem_insert_self _ _
  have zt : z∈twos G := ears ▸ mem_insert_of_mem (mem_singleton_self _)
  have dis : Disjoint (insert z A) (insert y B) := disjoint_left.mpr (by
      intro v vp vq
      rcases mem_insert.mp vp with rfl|va <;> rcases mem_insert.mp vq with eq|vb
      · exact yz eq.symm
      · exact G.not_mem_neighborFinset_self _ vb
      · exact G.not_mem_neighborFinset_self _ (eq ▸ va)
      · exact disjoint_left.mp sep va vb)
  apply PinnedColor34.complete G dis q
  · intro v vn np nq
    by_contra! small
    have low : v∈twos G := mem_sdiff.mpr ⟨vn,fun vh => (not_lt_of_ge (mem_filter.mp vh).2) small⟩
    rw [ears,mem_insert,mem_singleton] at low
    exact low.elim (fun e => nq (mem_insert.mpr (Or.inl e))) (fun e => np (mem_insert.mpr (Or.inl e)))
  · intro v vm
    rcases mem_insert.mp vm with rfl|va
    · have sub : B⊆(insert y B).filter (G.Adj v) := fun j jm => mem_filter.mpr ⟨mem_insert_of_mem jm,(G.mem_neighborFinset _ _).mp jm⟩
      have le := card_le_card sub
      change (G.neighborFinset v).card≤_ at le
      rw [card_neighborFinset_eq_degree,LowSample.two_degree G zt] at le
      exact le
    · obtain ⟨j,jb,vj⟩ := ab v va
      have ne : y≠j := fun eq => adj ((G.mem_neighborFinset _ _).mp (eq ▸ jb)).symm
      exact PinnedColor34.two G ne ((G.mem_neighborFinset _ _).mp va).symm vj (mem_insert_self ..) (mem_insert_of_mem jb)
  · intro v vm
    rcases mem_insert.mp vm with rfl|vb
    · have sub : A⊆(insert z A).filter (G.Adj v) := fun j jm => mem_filter.mpr ⟨mem_insert_of_mem jm,(G.mem_neighborFinset _ _).mp jm⟩
      have le := card_le_card sub
      change (G.neighborFinset v).card≤_ at le
      rw [card_neighborFinset_eq_degree,LowSample.two_degree G yt] at le
      exact le
    · obtain ⟨j,ja,vj⟩ := ba v vb
      have ne : z≠j := fun eq => adj ((G.mem_neighborFinset _ _).mp (eq ▸ ja))
      exact PinnedColor34.two G ne ((G.mem_neighborFinset _ _).mp vb).symm vj (mem_insert_self ..) (mem_insert_of_mem ja)

theorem isolated {y z : V} (yz : y≠z) (ears : twos G={y,z}) (adj : ¬G.Adj y z)
    (sep : Disjoint (G.neighborFinset y) (G.neighborFinset z))
    (only : ∀ x,G.neighborFinset y⊆G.neighborFinset x → x=y)
    (q : (types G).card≤(nonleaves G).card) (fail : bound G<gamma G) :
    ∃ a∈G.neighborFinset y,∀ b∈G.neighborFinset z,¬G.Adj a b := by
  classical
  by_contra! every
  apply (not_lt_of_ge (cross G yz ears adj sep every ?_ q)) fail
  intro b bz
  by_contra! none
  have zt : z∈twos G := ears ▸ mem_insert_of_mem (mem_singleton_self _)
  have count : ((G.neighborFinset z).erase b).card=1 := by rw [card_erase_of_mem bz,card_neighborFinset_eq_degree,LowSample.two_degree G zt]
  obtain ⟨j,eq⟩ := card_eq_one.mp count
  have jm : j∈(G.neighborFinset z).erase b := by rw [eq]; exact mem_singleton_self _
  have shared : G.neighborFinset y⊆G.neighborFinset j := by
    intro a ay
    obtain ⟨i,iz,ai⟩ := every a ay
    have im : i∈(G.neighborFinset z).erase b := mem_erase.mpr ⟨fun e => none a ay (e ▸ ai.symm),iz⟩
    rw [eq,mem_singleton] at im
    exact (G.mem_neighborFinset _ _).mpr (im ▸ ai.symm)
  exact adj (((G.mem_neighborFinset _ _).mp ((mem_erase.mp jm).2)).symm |> fun e => (only j shared) ▸ e)

end Graffiti384b.DisjointCross34
#print axioms Graffiti384b.DisjointCross34.isolated

