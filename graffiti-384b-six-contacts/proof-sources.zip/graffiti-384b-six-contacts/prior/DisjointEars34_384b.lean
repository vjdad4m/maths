import EarCut34_384b

namespace Graffiti384b.DisjointEars34
open Finset SimpleGraph LowSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Outside four retained anchors, every pair of extra possible omissions
needs a cubic blocker or a common blocker of degree four. -/
theorem pair {y z : V} (yz : y≠z) (ears : twos G={y,z}) {K U : Finset V} (ks : K.card=4)
    (kh : K⊆high G) (ny : G.neighborFinset y⊆K) (nz : G.neighborFinset z⊆K)
    (us : U.card=2) (uh : U⊆high G\K) (hits : ∀ v∈U,2≤nbr G v K)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    ∃ c∈(high G)\(K∪U),
      (G.degree c=3 ∧ nbr G c K=0 ∧ 1≤nbr G c U) ∨
      ((G.degree c=3 ∧ nbr G c K=1 ∨ G.degree c=4 ∧ nbr G c K=0) ∧ nbr G c U=2) := by
  have obs := EarCut34.joint G yz ears kh ny nz uh hits same fail
  rw [ks,us] at obs
  obtain ⟨c,cm⟩ := card_pos.mp (show 0<(((high G)\(K∪U)).filter (fun v => G.degree v+nbr G v K<3+nbr G v U)).card by omega)
  obtain ⟨out,short⟩ := mem_filter.mp cm
  have lo := (mem_filter.mp (mem_sdiff.mp out).1).2
  have up : nbr G c U≤2 := (card_filter_le _ _).trans_eq us
  exact ⟨c,out,by omega⟩
end Graffiti384b.DisjointEars34
#print axioms Graffiti384b.DisjointEars34.pair
