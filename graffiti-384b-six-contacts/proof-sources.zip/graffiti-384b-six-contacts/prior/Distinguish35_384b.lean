import BlockGeometry384b
import TrianglePrune384b

namespace Graffiti384b.Distinguish35
open Finset SimpleGraph BlockGeometry
open private Repair.linkEdges Repair.edge_info from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem score_mono {a b : V} (sub : ∀ z, 0 < trianglesAt G z → G.Adj a z → G.Adj b z) :
    trianglesAt G a ≤ trianglesAt G b := by
  apply card_le_card (s := Repair.linkEdges G a) (t := Repair.linkEdges G b)
  intro p hp
  obtain ⟨inside,two,cl⟩ := Repair.edge_info G hp
  refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨?_,two⟩,cl⟩
  intro z zp
  obtain ⟨w,wp,ne⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) z
  have az := (G.mem_neighborFinset _ _).mp (inside zp)
  have aw := (G.mem_neighborFinset _ _).mp (inside wp)
  have pos := (TrianglePrune.triangle_iff G z).mpr ⟨a,w,az.symm,cl z zp w wp ne.symm,aw⟩
  exact (G.mem_neighborFinset _ _).mpr (sub z pos az)

/-- The endpoints of the unique missing edge in a neighborhood have distinct
positive-score exterior neighborhoods whenever their own scores differ. -/
theorem exterior_witness {x a b : V} (xa : G.Adj x a) (xb : G.Adj x b)
    (no : ¬G.Adj a b)
    (unique : gaps G (G.neighborFinset x) = {{a,b}}) (diff : trianglesAt G a ≠ trianglesAt G b) :
    ∃ z ∉ insert x (G.neighborFinset x), 0 < trianglesAt G z ∧
      ((G.Adj a z ∧ ¬G.Adj b z) ∨ (G.Adj b z ∧ ¬G.Adj a z)) := by
  classical
  by_contra! none
  apply diff
  have agree (z : V) (pos : 0 < trianglesAt G z) : G.Adj a z ↔ G.Adj b z := by
    by_cases ze : z=x
    · subst z; exact ⟨fun _ => xb.symm,fun _ => xa.symm⟩
    by_cases inner : z ∈ G.neighborFinset x
    · by_cases ea : z=a
      · subst z
        exact ⟨fun e => (e.ne rfl).elim,fun e => (no e.symm).elim⟩
      by_cases eb : z=b
      · subst z
        exact ⟨fun e => (no e).elim,fun e => (e.ne rfl).elim⟩
      have edge {u : V} (xu : G.Adj x u) (zu : z≠u) : G.Adj u z := by
        by_contra missing
        have gap := pair_gap G ((G.mem_neighborFinset _ _).mpr xu) inner zu.symm missing
        rw [unique,mem_singleton] at gap
        have mem : z ∈ ({a,b} : Finset V) := gap ▸ mem_insert_of_mem (mem_singleton_self z)
        simp [ea,eb] at mem
      exact ⟨fun _ => edge xb eb,fun _ => edge xa ea⟩
    · have out : z ∉ insert x (G.neighborFinset x) := fun hit => (mem_insert.mp hit).elim ze inner
      have same := none z out pos
      tauto
  exact le_antisymm (score_mono G (fun z p => (agree z p).mp)) (score_mono G (fun z p => (agree z p).mpr))

end Graffiti384b.Distinguish35
#print axioms Graffiti384b.Distinguish35.exterior_witness
