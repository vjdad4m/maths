import MultiEar34_384b

namespace Graffiti384b.EarAnchor34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private LowSample.eligible LowSample.anchors LowSample.weight from LowSample384b
open private CliqueSample.trial from CliqueSample384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- After permanently retaining w, two adjacent ears with sole high anchor w
pay for one omission in every sample. -/
theorem balance {p : Finset V} (ch : Choice G p Boundary.levels) {w y z : V}
    (wm : w∈high G\p) (yt : y∈twos G) (zt : z∈twos G) (yz : y≠z)
    (ya : LowSample.anchors G y={w}) (za : LowSample.anchors G z={w})
    (t : (types G).card=33) (fail : bound G<gamma G) (b : ℕ)
    (room : 9≤(high G\insert w p).card) :
    let s := high G\insert w p
    (s.card-b+1)*s.card.choose b + (∑ d∈p.image (G.degree ·),bonus s.card b d) ≤
      16*s.card.choose b + ∑ k∈s.powersetCard b,(FiniteRange.bad G s k).card := by
  have eq : (high G\p)\{w}=high G\insert w p := by ext i; simp [and_left_comm,and_comm,and_assoc]
  have val := MultiEar34.weighted G ch (singleton_subset_iff.mpr wm) yt zt yz (ya ▸ Subset.rfl) (za ▸ Subset.rfl) 1
    (by simp [ya,za,LowSample.weight]) t fail b (eq ▸ room)
  simpa only [eq] using val
end Graffiti384b.EarAnchor34
#print axioms Graffiti384b.EarAnchor34.balance
