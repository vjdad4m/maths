import Finish33_384b
import EarAnchor34_384b

namespace Graffiti384b.EarBudget34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private Finish33.active_thresholds from Finish33_384b
open private LowSample.delta LowSample.weight LowSample.anchors from LowSample384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def old (f : Finset ℕ) :=
  let m := 31-f.card
  12≤m ∧ envelope m 11 ∧ reward m 11 ∧
    6*(16*m.choose 11 + charge 33 31 m 11 f Boundary.levels) <
    6*(m-11)*m.choose 11 + 2*(6*(m-2).choose 9) + 6*(∑ a∈f,bonus m 11 a)

private def row (f : Finset ℕ) (d : ℕ) :=
  let m := 30-f.card
  9<m ∧ BlockLoss.envelope m 11 ∧
  (∀ j : Fin 10, 3≤j.val → (m-j.val).choose 11 + Finish33.rebate m 11 ≤ FiniteRange.badCount m 11 j.val) ∧
  16*m.choose 11+BlockLoss.chargeAt m 11 (Finish33.slotsAfter 31 f d) <
    (m-11+1)*m.choose 11 + (∑ a∈f,bonus m 11 a) + (d-2-f.card)*Finish33.rebate m 11

set_option maxRecDepth 32768 in
set_option maxHeartbeats 10000000 in
private theorem table : ∀ f∈Boundary.levels.powerset, old f ∨ ∀ d : Fin 10, 3≤d.val → row f d.val := by
  unfold old row envelope reward charge BlockLoss.envelope BlockLoss.chargeAt Finish33.slotsAfter Finish33.rebate LowSample.delta LowSample.weight slots bonus FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

/-- Both adjacent ears have the same sole high anchor. In this theorem all
other neighbors of that anchor are high, as in the triangle skeleton. -/
theorem exact {w y z : V} (yw : G.Adj y w) (wh : w∈high G) (yt : y∈twos G) (zt : z∈twos G)
    (yz : y≠z) (ya : LowSample.anchors G y={w}) (za : LowSample.anchors G z={w})
    (near : G.neighborFinset w⊆high G∪{y,z}) (h : (high G).card=31) (t : (types G).card=33) :
    gamma G≤bound G := by
  classical
  by_contra! fail
  letI : Nonempty V := ⟨w⟩
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  let f := p.image (G.degree ·)
  have fp : f.card=p.card := card_image_of_injOn ch.unique
  have wp : w∉p := fun inc => (mem_sdiff.mp yt).2 (mem_sdiff.mp (neighbors_in_pool G ch inc ((G.mem_neighborFinset _ _).mpr yw.symm))).1
  have wm := mem_sdiff.mpr ⟨wh,wp⟩
  let s := high G\insert w p
  let m := 30-f.card
  let d := min (G.degree w) 9
  have size : s.card=m := by
    dsimp only [s,m]
    rw [card_sdiff (insert_subset wh ch.high_sub),card_insert_of_not_mem wp,h,fp]; omega
  have tw : 2≤(twos G).card := by
    have := card_le_card (insert_subset yt (singleton_subset_iff.mpr zt))
    rwa [card_pair yz] at this
  rcases table f (mem_powerset.mpr ch.levels) with prev|rows
  · obtain ⟨room,env,rew,win⟩ := prev
    have sz : (high G\p).card=31-f.card := by rw [card_sdiff ch.high_sub,h,fp]
    have obs := CliqueSample.obstruction G ch 11 (sz ▸ room) (by decide) (sz ▸ env) (sz ▸ rew) fail
    dsimp only at obs
    rw [h,t] at obs
    let M := 31-f.card
    change 6*(M-11)*M.choose 11+(twos G).card*(6*(M-2).choose 9)+6*(∑ a∈f,bonus M 11 a) ≤
      6*(16*M.choose 11+charge 33 31 M 11 f Boundary.levels) at obs
    change 6*(16*M.choose 11+charge 33 31 M 11 f Boundary.levels) <
      6*(M-11)*M.choose 11+2*(6*(M-2).choose 9)+6*(∑ a∈f,bonus M 11 a) at win
    have := Nat.mul_le_mul_right (6*(M-2).choose 9) tw
    omega
  have dd : 3≤d ∧ d≤9 := by dsimp [d]; have := (mem_filter.mp wh).2; omega
  obtain ⟨room,env,paid,win⟩ := rows ⟨d,by omega⟩ dd.1
  change 9<m at room
  let N := G.neighborFinset w
  let extra (v : V) := if v∈N then Finish33.rebate m 11 else 0
  have outside : w∉s := fun mem => (mem_sdiff.mp mem).2 (mem_insert_self _ _)
  have refund (v : V) (vs : v∈s) : ((s.powersetCard 11).filter (fun k => v∈FiniteRange.bad G s k)).card + extra v ≤
      FiniteRange.badCount s.card 11 (min (G.degree v) 9) := by
    let a := min (G.degree v) 9
    have cap : 3≤a ∧ a≤9 := by dsimp [a]; have := (mem_filter.mp (mem_sdiff.mp vs).1).2; omega
    by_cases vn : v∈N
    · have raw := BoundaryFiber.count G s 11 a vs outside ((G.mem_neighborFinset _ _).mp vn).symm (min_le_left _ _) (by omega)
      have val := paid ⟨a,by omega⟩ cap.1
      change (m-a).choose 11+Finish33.rebate m 11≤FiniteRange.badCount m 11 a at val
      simp only [extra,if_pos vn]; rw [size] at raw ⊢
      exact (Nat.add_le_add_right raw _).trans val
    · simp only [extra,if_neg vn,Nat.add_zero]
      exact FiniteRange.count_bad G s 11 a v vs (min_le_left _ _) (by omega)
  have dist (j : ℕ) (jr : j∈range 9) (big : 3≤j) :
      (s.filter (fun v => G.degree v≤j)).card ≤ Finish33.slotsAfter 31 f d j := by
    have est := Finish33.active_thresholds G ch wm t j big
    dsimp only at est
    rw [h] at est
    have cond : (d≤j)↔G.degree w≤j := by dsimp [d]; have := mem_range.mp jr; omega
    simpa only [Finish33.slotsAfter,cond] using est
  have loss := BlockLoss.pool_loss G s sdiff_subset 11 _ dist extra refund (size ▸ env)
  have bal := EarAnchor34.balance G ch wm yt zt yz ya za t fail 11 (by change 9≤s.card; omega)
  let F := s∩N
  have cover : N⊆(F∪p)∪{y,z} := by
    intro a aN
    rcases mem_union.mp (near aN) with ah|ae
    · by_cases ap : a∈p
      · exact mem_union_left _ (mem_union_right _ ap)
      · have aw : a≠w := ((G.mem_neighborFinset _ _).mp aN).ne.symm
        exact mem_union_left _ (mem_union_left _ (mem_inter.mpr ⟨mem_sdiff.mpr ⟨ah,by simpa [aw] using ap⟩,aN⟩))
    · exact mem_union_right _ ae
  have cap := (card_le_card cover).trans (card_union_le _ _)
  have cap2 := card_union_le F p
  rw [card_pair yz,card_neighborFinset_eq_degree] at cap
  have enough : d-2-f.card≤F.card := by dsimp [d]; omega
  have sum : (∑ v∈s,extra v)=F.card*Finish33.rebate m 11 := by
    simp only [extra,←sum_filter,filter_mem_eq_inter,sum_const,nsmul_eq_mul,Nat.cast_id]; rfl
  rw [sum,size] at loss
  dsimp only at bal
  change (s.card-11+1)*s.card.choose 11+(∑ a∈f,bonus s.card 11 a)≤16*s.card.choose 11+
    ∑ k∈s.powersetCard 11,(FiniteRange.bad G s k).card at bal
  rw [size] at bal
  change 16*m.choose 11+BlockLoss.chargeAt m 11 (Finish33.slotsAfter 31 f d) <
    (m-11+1)*m.choose 11+(∑ a∈f,bonus m 11 a)+(d-2-f.card)*Finish33.rebate m 11 at win
  have := Nat.mul_le_mul_right (Finish33.rebate m 11) enough
  omega
end Graffiti384b.EarBudget34
#print axioms Graffiti384b.EarBudget34.exact
