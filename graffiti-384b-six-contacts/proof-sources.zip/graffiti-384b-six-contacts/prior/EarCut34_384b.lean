import PinCut34_384b

namespace Graffiti384b.EarCut34
open Finset SimpleGraph LowSample
open private Repair.nbr_add from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Omit both independent ears and any extra high vertices with two retained
anchors. Only edges to the extra high vertices can cause a cut defect. -/
theorem joint {y z : V} (yz : y≠z) (ears : twos G={y,z}) {K U : Finset V}
    (kh : K⊆high G) (ny : G.neighborFinset y⊆K) (nz : G.neighborFinset z⊆K)
    (uh : U⊆high G\K) (hits : ∀ v∈U,2≤nbr G v K)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    3+U.card≤K.card+(((high G)\(K∪U)).filter (fun v => G.degree v+nbr G v K<3+nbr G v U)).card := by
  let L : Finset V := {y,z}
  let X := U∪L
  have eq : L=twos G := ears.symm
  have us : U⊆high G := uh.trans sdiff_subset
  have hn : high G⊆nonleaves G := fun v hm => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hm).2; omega⟩
  have low {v : V} (vm : v∈L) := mem_sdiff.mp (eq ▸ vm : v∈twos G)
  have sep : Disjoint U L := disjoint_left.mpr (fun _ u l => (low l).2 (us u))
  have xk : Disjoint X K := disjoint_left.mpr (fun _ xm km => (mem_union.mp xm).elim
    (fun u => (mem_sdiff.mp (uh u)).2 km) (fun l => (low l).2 (kh km)))
  have allL {v : V} (vl : v∈L) : G.neighborFinset v⊆K := by
    rcases mem_insert.mp vl with rfl|m
    · exact ny
    · exact mem_singleton.mp m ▸ nz
  have good (v : V) (vx : v∈X) : 2≤nbr G v K := by
    rcases mem_union.mp vx with u|l
    · exact hits v u
    · have inc : G.neighborFinset v⊆K.filter (G.Adj v) := fun j jm => mem_filter.mpr ⟨allL l jm,(G.mem_neighborFinset _ _).mp jm⟩
      have deg : 2≤G.degree v := (mem_filter.mp (low l).1).2
      exact deg.trans ((card_neighborFinset_eq_degree G v).symm.le.trans (card_le_card inc))
  have obs := CliqueCut34.pin_obstruction G (kh.trans hn) (union_subset (us.trans hn) (fun _ l => (low l).1)) xk good same fail
  have inc : CliqueCut34.defects G K X⊆(((high G)\(K∪U)).filter (fun v => G.degree v+nbr G v K<3+nbr G v U)) := by
    intro v vm
    obtain ⟨vr,lt⟩ := mem_filter.mp vm
    obtain ⟨vn,out⟩ := mem_sdiff.mp vr
    have vk : v∉K := fun k => out (mem_union_right _ k)
    have vl : v∉L := fun l => out (mem_union_left _ (mem_union_right _ l))
    have vh : v∈high G := by
      by_contra no
      exact vl (eq ▸ mem_sdiff.mpr ⟨vn,no⟩)
    have none : L.filter (G.Adj v)=∅ := filter_eq_empty_iff.mpr (fun j jl vj => vk (allL jl ((G.mem_neighborFinset _ _).mpr vj.symm)))
    have zero : nbr G v L=0 := by rw [nbr,none,card_empty]
    have nx := Repair.nbr_add G v sep
    change nbr G v X=_ at nx
    rw [nx,zero,Nat.add_zero] at lt
    exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨vh,fun m => (mem_union.mp m).elim vk (fun u => out (mem_union_left _ (mem_union_left _ u)))⟩,lt⟩
  have val := obs.trans (Nat.add_le_add_left (card_le_card inc) K.card)
  have sz : X.card=U.card+2 := by rw [show X=U∪L from rfl,card_union_of_disjoint sep,show L.card=2 from card_pair yz]
  change X.card+1≤K.card+_ at val
  rw [sz] at val
  omega

/-- When the ears share an anchor, each exterior candidate supported by
two of the three anchors needs an adjacent cubic vertex missing all three. -/
theorem shared {y z v : V} (yz : y≠z) (ears : twos G={y,z}) {K : Finset V} (kc : K.card=3)
    (kh : K⊆high G) (ny : G.neighborFinset y⊆K) (nz : G.neighborFinset z⊆K)
    (vm : v∈high G\K) (hit : 2≤nbr G v K)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    ∃ c∈(high G)\(insert v K), G.Adj c v ∧ G.degree c=3 ∧ nbr G c K=0 := by
  have obs := joint G yz ears kh ny nz (singleton_subset_iff.mpr vm) (fun j jm => mem_singleton.mp jm ▸ hit) same fail
  rw [kc,card_singleton] at obs
  obtain ⟨c,cm⟩ := card_pos.mp (show 0<(((high G)\(K∪{v})).filter (fun j => G.degree j+nbr G j K<3+nbr G j {v})).card by omega)
  obtain ⟨cr,lt⟩ := mem_filter.mp cm
  have dg := (mem_filter.mp (mem_sdiff.mp cr).1).2
  have cv : G.Adj c v := by
    by_contra no
    have zero : nbr G c {v}=0 := by rw [nbr,filter_eq_empty_iff.mpr (fun j jm => mem_singleton.mp jm ▸ no),card_empty]
    omega
  have one : nbr G c {v}=1 := by rw [nbr,filter_true_of_mem (fun j jm => mem_singleton.mp jm ▸ cv),card_singleton]
  exact ⟨c,by simpa [or_comm] using cr,cv,by omega,by omega⟩

end Graffiti384b.EarCut34
#print axioms Graffiti384b.EarCut34.joint
#print axioms Graffiti384b.EarCut34.shared
