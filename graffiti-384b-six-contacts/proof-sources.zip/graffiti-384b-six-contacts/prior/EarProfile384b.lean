import Minimal384b

namespace Graffiti384b.EarProfile
open Finset SimpleGraph
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def outside (x a b : V) := (({x,a,b} : Finset V)ᶜ).image (trianglesAt G)
def endpoints (a b : V) : Finset ℕ := {trianglesAt G a,trianglesAt G b}
def lowered (a b : V) : Finset ℕ := {trianglesAt G a-1,trianglesAt G b-1}

private theorem type_sets {x a b : V} (score : trianglesAt G x = 1) (xa : x ≠ a) (xb : x ≠ b) :
    types G = (outside G x a b ∪ insert 1 (endpoints G a b)) ∧
    EarPrune.after G x a b = outside G x a b ∪ lowered G a b := by
  let U := outside G x a b
  have out {v : V} (vx : v ≠ x) (va : v ≠ a) (vb : v ≠ b) :
      trianglesAt G v ∈ U := mem_image.mpr ⟨v,by simp [vx,va,vb],rfl⟩
  have oldMem (v : V) : trianglesAt G v ∈ types G := mem_image.mpr ⟨v,mem_univ _,rfl⟩
  have afterMem (v : V) (vx : v ≠ x) : trianglesAt G v - (if v=a ∨ v=b then 1 else 0) ∈
      EarPrune.after G x a b := mem_image.mpr ⟨v,by simpa [EarPrune.rest] using vx,rfl⟩
  constructor
  · ext j
    constructor
    · intro hj
      obtain ⟨v,_,rfl⟩ := mem_image.mp hj
      by_cases h : v=x
      · exact mem_union_right _ (mem_insert.mpr (Or.inl (h ▸ score)))
      by_cases ha : v=a
      · exact mem_union_right _ (mem_insert_of_mem (mem_insert.mpr (Or.inl (congrArg _ ha))))
      by_cases hb : v=b
      · exact mem_union_right _ (mem_insert_of_mem (mem_insert_of_mem (mem_singleton.mpr (congrArg _ hb))))
      exact mem_union_left _ (out h ha hb)
    · intro hj
      rcases mem_union.mp hj with o | z
      · obtain ⟨v,_,rfl⟩ := mem_image.mp o; exact oldMem v
      · rcases mem_insert.mp z with eq | z
        · exact eq ▸ score ▸ oldMem x
        rcases mem_insert.mp z with eq | eq
        · exact eq ▸ oldMem a
        · exact mem_singleton.mp eq ▸ oldMem b
  · ext j
    constructor
    · intro hj
      obtain ⟨v,hv,rfl⟩ := mem_image.mp hj
      have vx : v ≠ x := fun eq => mem_compl.mp hv (mem_singleton.mpr eq)
      by_cases h : v=a ∨ v=b
      · simp only [if_pos h]
        apply mem_union_right
        rcases h with rfl | rfl <;> simp [lowered]
      · simp only [if_neg h,Nat.sub_zero]
        exact mem_union_left _ (out vx (fun eq => h (Or.inl eq)) (fun eq => h (Or.inr eq)))
    · intro hj
      rcases mem_union.mp hj with o | l
      · obtain ⟨v,hv,rfl⟩ := mem_image.mp o
        simp only [mem_compl,mem_insert,mem_singleton,not_or] at hv
        simpa [hv.2.1,hv.2.2] using afterMem v hv.1
      · rcases mem_insert.mp l with eq | eq
        · simpa [eq] using afterMem a xa.symm
        · simpa [mem_singleton.mp eq] using afterMem b xb.symm

/-- The two finite sets count types lost and types newly realized after deletion. -/
theorem endpoint_deficit {x a b : V} (res : Minimal.Residual G) (score : trianglesAt G x = 1)
    (ab : G.Adj a b) (nx : G.neighborFinset x = {a,b}) :
    ((lowered G a b) \ outside G x a b).card <
      ((insert 1 (endpoints G a b)) \ outside G x a b).card := by
  have xa := (G.mem_neighborFinset _ _).mp (nx ▸ mem_insert_self _ _)
  have xb := (G.mem_neighborFinset _ _).mp (nx ▸ mem_insert_of_mem (mem_singleton_self _))
  obtain ⟨old,new⟩ := type_sets G score xa.ne xb.ne
  have drop := res.2.2.2.2.2.2.1 x a b ab nx
  rw [old,new] at drop
  have split (s t : Finset ℕ) : (s ∪ t).card = s.card + (t \ s).card := by
    have eq : s ∪ (t \ s) = s ∪ t := by ext v; simp only [mem_union,mem_sdiff]; tauto
    rw [← eq,card_union_of_disjoint (disjoint_left.mpr (fun _ h m => (mem_sdiff.mp m).2 h))]
  rw [split,split] at drop
  omega

/-- When another score-one witness survives off the ear triangle, lower
endpoint scores must collide with more unaffected types than the old scores. -/
theorem repeated_one {x a b : V} (res : Minimal.Residual G) (score : trianglesAt G x = 1)
    (ab : G.Adj a b) (nx : G.neighborFinset x = {a,b}) (repeatOne : 1 ∈ outside G x a b) :
    ((endpoints G a b) ∩ outside G x a b).card <
      ((lowered G a b) ∩ outside G x a b).card := by
  have xa := (G.mem_neighborFinset _ _).mp (nx ▸ mem_insert_self _ _)
  have xb := (G.mem_neighborFinset _ _).mp (nx ▸ mem_insert_of_mem (mem_singleton_self _))
  have positives : 0 < trianglesAt G a ∧ 0 < trianglesAt G b :=
    ⟨(TrianglePrune.triangle_iff G a).mpr ⟨x,b,xa.symm,ab,xb⟩,
     (TrianglePrune.triangle_iff G b).mpr ⟨x,a,xb.symm,ab.symm,xa⟩⟩
  have sizes : (lowered G a b).card = (endpoints G a b).card := by
    by_cases eq : trianglesAt G a = trianglesAt G b
    · simp [lowered,endpoints,eq]
    · have ne : trianglesAt G a-1 ≠ trianglesAt G b-1 := by omega
      rw [lowered,endpoints,card_pair ne,card_pair eq]
  have delta := endpoint_deficit G res score ab nx
  have eq : insert 1 (endpoints G a b) \ outside G x a b = endpoints G a b \ outside G x a b := by
    ext d; simp only [mem_sdiff,mem_insert]; constructor
    · rintro ⟨eq | e,h⟩
      · exact (h (eq ▸ repeatOne)).elim
      · exact ⟨e,h⟩
    · rintro ⟨e,h⟩; exact ⟨Or.inr e,h⟩
  rw [eq] at delta
  have := card_sdiff_add_card_inter (lowered G a b) (outside G x a b)
  have := card_sdiff_add_card_inter (endpoints G a b) (outside G x a b)
  omega

/-- An injective odd-order profile always loses a unit of rounded quota on
one deletion, independent of which endpoint values collide. -/
theorem injective_odd_drop (inj : Function.Injective (trianglesAt G))
    (odd : Fintype.card V % 2 = 1) (x a b : V) :
    ((EarPrune.after G x a b).card+1)/2 < ((types G).card+1)/2 := by
  have old : (types G).card = Fintype.card V := by
    rw [types,card_image_of_injective _ inj,card_univ]
  have new : (EarPrune.after G x a b).card ≤ (EarPrune.rest x).card := card_image_le
  simp only [EarPrune.rest,card_compl,card_singleton] at new
  omega

end Graffiti384b.EarProfile

#print axioms Graffiti384b.EarProfile.repeated_one
#print axioms Graffiti384b.EarProfile.injective_odd_drop

namespace Graffiti384b.EarProfile
open Finset SimpleGraph
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Away from a zero neighbor, an unaffected repetition of one forces one
old endpoint score to be private to the triangle and one predecessor to
occur at an unaffected vertex. The endpoints witnessing these may differ. -/
theorem score_one_neighbors {x : V} (res : Minimal.Residual G) (score : trianglesAt G x = 1)
    (positive : ∀ w, G.Adj x w → 0 < trianglesAt G w) :
    ∃ a b, G.Adj a b ∧ G.neighborFinset x = {a,b} ∧ (1 ∈ outside G x a b →
      (∃ z ∈ ({a,b} : Finset V), trianglesAt G z ∉ outside G x a b) ∧
      (∃ z ∈ ({a,b} : Finset V), ∃ w ∉ ({x,a,b} : Finset V), trianglesAt G w = trianglesAt G z-1)) := by
  obtain ⟨a,b,ab,nx⟩ := Minimal.score_one_ear G res.2.2.2.1 x score positive
  refine ⟨a,b,ab,nx,fun rep => ?_⟩
  have gap := repeated_one G res score ab nx rep
  let u := outside G x a b
  have pair : (lowered G a b).card ≤ (endpoints G a b).card := by
    by_cases h : trianglesAt G a = trianglesAt G b
    · simp [lowered,endpoints,h]
    · rw [endpoints,card_pair h]; exact card_le_two
  constructor
  · by_contra! all
    have sub : endpoints G a b ⊆ u := by
      intro d hd
      rcases mem_insert.mp hd with ae | be
      · exact ae ▸ all a (mem_insert_self _ _)
      · exact mem_singleton.mp be ▸ all b (mem_insert_of_mem (mem_singleton_self _))
    rw [inter_eq_left.mpr sub] at gap
    exact (not_lt_of_ge ((card_le_card inter_subset_left).trans pair)) gap
  · obtain ⟨d,hd⟩ := card_pos.mp (Nat.zero_lt_of_lt gap)
    obtain ⟨pred,unaffected⟩ := mem_inter.mp hd
    obtain ⟨w,hw,we⟩ := mem_image.mp unaffected
    rcases mem_insert.mp pred with ae | be
    · exact ⟨a,mem_insert_self _ _,w,mem_compl.mp hw,we.trans ae⟩
    · exact ⟨b,mem_insert_of_mem (mem_singleton_self _),w,mem_compl.mp hw,we.trans (mem_singleton.mp be)⟩

end Graffiti384b.EarProfile
#print axioms Graffiti384b.EarProfile.score_one_neighbors
