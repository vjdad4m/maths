import TrianglePrune384b

namespace Graffiti384b.EarPrune
open Finset SimpleGraph
open private Repair.isolate Repair.linkEdges Repair.edge_info from Repair384b
open private TrianglePrune.scores_closed TrianglePrune.induced_cost from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def rest (x : V) : Finset V := ({x} : Finset V)ᶜ

/-- The surviving scores after deleting a vertex with its two adjacent neighbors
a and b. Only the scores at a and b drop by one. -/
def after (x a b : V) := ((rest x)).image
  (fun v => trianglesAt G v - (if v = a ∨ v = b then 1 else 0))

private theorem score_congr (A B : SimpleGraph V) [dA : DecidableRel A.Adj] [dB : DecidableRel B.Adj]
    (eq : A = B) (v : V) : trianglesAt A v = trianglesAt B v := by
  subst B
  have eqDec : dA = dB := Subsingleton.elim _ _
  cases eqDec
  rfl

private theorem lost_score (x : V) (v : (rest x)) :
    trianglesAt (G.induce ((rest x) : Set V)) v +
      ((Repair.linkEdges G v.val).filter (fun p => x ∈ p)).card = trianglesAt G v.val := by
  let s := (rest x)
  let I := Repair.isolate G x
  have ne (w : s) : w.val ≠ x := by exact fun eq => mem_compl.mp w.property (mem_singleton.mpr eq)
  have eq : I.induce (s : Set V) = G.induce (s : Set V) := by
    ext w z
    change (G.Adj w.val z.val ∧ w.val ≠ x ∧ z.val ≠ x) ↔ G.Adj w.val z.val
    simp [ne w,ne z]
  have sc := TrianglePrune.scores_closed I s (fun _ _ _ adj => mem_compl.mpr (fun h => adj.2.2 (mem_singleton.mp h))) v
  rw [score_congr _ _ eq v] at sc
  change trianglesAt (G.induce (s : Set V)) v + _ = _
  rw [sc]
  let e := Repair.linkEdges G v.val
  have rem : e.filter (fun p => x ∉ p) = Repair.linkEdges I v.val := by
    ext p
    simp only [e,Repair.linkEdges,mem_filter,mem_powersetCard,subset_iff,mem_neighborFinset]
    change (((∀ a ∈ p, G.Adj v.val a) ∧ p.card = 2) ∧ _) ∧ x ∉ p ↔
      ((∀ a ∈ p, G.Adj v.val a ∧ v.val ≠ x ∧ a ≠ x) ∧ p.card = 2) ∧
        (∀ a ∈ p, ∀ b ∈ p, a ≠ b → G.Adj a b ∧ a ≠ x ∧ b ≠ x)
    constructor
    · rintro ⟨⟨⟨sub,sz⟩,edge⟩,no⟩
      exact ⟨⟨fun a ha => ⟨sub a ha,ne v,fun eq => no (eq ▸ ha)⟩,sz⟩,
        fun a ha b hb ab => ⟨edge a ha b hb ab,fun eq => no (eq ▸ ha),fun eq => no (eq ▸ hb)⟩⟩
    · rintro ⟨⟨sub,sz⟩,edge⟩
      exact ⟨⟨⟨fun a ha => (sub a ha).1,sz⟩,fun a ha b hb ab => (edge a ha b hb ab).1⟩,
        fun hx => (sub x hx).2.2 rfl⟩
  have h := filter_card_add_filter_neg_card_eq_card (s := e) (fun p => x ∈ p)
  rw [rem] at h
  exact (Nat.add_comm ..).trans h

private theorem one_loss {x a b : V} (adj : G.Adj a b) (nx : G.neighborFinset x = {a,b}) :
    ((Repair.linkEdges G a).filter (fun p => x ∈ p)).card = 1 := by
  have xa : G.Adj x a := (G.mem_neighborFinset _ _).mp (nx ▸ mem_insert_self _ _)
  have xb : G.Adj x b := (G.mem_neighborFinset _ _).mp (nx ▸ mem_insert_of_mem (mem_singleton_self _))
  have eq : (Repair.linkEdges G a).filter (fun p => x ∈ p) = {{x,b}} := by
    ext p
    constructor
    · intro hp
      obtain ⟨link,px⟩ := mem_filter.mp hp
      obtain ⟨sub,two,edge⟩ := Repair.edge_info G link
      obtain ⟨y,py,ne⟩ := exists_ne_of_one_lt_card (by omega : 1 < p.card) x
      have hy := (G.mem_neighborFinset _ _).mpr (edge x px y py ne.symm)
      rw [nx] at hy
      have bmem : b ∈ p := by
        rcases mem_insert.mp hy with ya | yb
        · exact False.elim (((G.mem_neighborFinset a y).mp (sub py)).ne ya.symm)
        · exact mem_singleton.mp yb ▸ py
      exact mem_singleton.mpr (eq_of_subset_of_card_le (insert_subset px (singleton_subset_iff.mpr bmem))
        (by simp [two,xb.ne])).symm
    · intro hp
      obtain rfl := mem_singleton.mp hp
      refine mem_filter.mpr ⟨mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset
        ((G.mem_neighborFinset _ _).mpr xa.symm) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr adj)),
        by simp [xb.ne]⟩,?_⟩,mem_insert_self _ _⟩
      intro i hi j hj ij
      simp only [mem_insert,mem_singleton] at hi hj
      rcases hi with rfl | rfl <;> rcases hj with rfl | rfl <;> first | exact (ij rfl).elim | exact xb | exact xb.symm
  rw [eq,card_singleton]

theorem types_after {x a b : V} (ab : G.Adj a b) (nx : G.neighborFinset x = {a,b}) :
    types (G.induce ((rest x) : Set V)) = after G x a b := by
  let s := (rest x)
  let H := G.induce (s : Set V)
  have formula (v : s) : trianglesAt H v =
      trianglesAt G v.val - (if v.val = a ∨ v.val = b then 1 else 0) := by
    have loss := lost_score G x v
    change trianglesAt H v + _ = _ at loss
    by_cases mem : v.val = a ∨ v.val = b
    · rw [if_pos mem]
      rcases mem with e | e
      · rw [e,one_loss G ab nx] at loss
        rw [e]; omega
      · rw [e,one_loss G ab.symm (nx.trans (pair_comm a b))] at loss
        rw [e]; omega
    · rw [if_neg mem,Nat.sub_zero]
      have none : (Repair.linkEdges G v.val).filter (fun p => x ∈ p) = ∅ := by
        apply filter_eq_empty_iff.mpr
        intro p hp px
        have vx := (G.mem_neighborFinset _ _).mp ((Repair.edge_info G hp).1 px)
        have m := (G.mem_neighborFinset _ _).mpr vx.symm
        rw [nx] at m
        exact mem (by simpa using m)
      rwa [none,card_empty,Nat.add_zero] at loss
  ext j
  constructor
  · intro hj
    obtain ⟨v,_,eq⟩ := mem_image.mp hj
    exact mem_image.mpr ⟨v,v.property,(formula v).symm.trans eq⟩
  · intro hj
    obtain ⟨v,hv,eq⟩ := mem_image.mp hj
    exact mem_image.mpr ⟨⟨v,hv⟩,mem_univ _,(formula ⟨v,hv⟩).trans eq⟩

private theorem connected_delete {x a b : V} (hc : G.Connected) (ab : G.Adj a b) (nx : G.neighborFinset x = {a,b}) :
    (G.induce ((rest x) : Set V)).Connected := by
  let s := (rest x)
  let H := G.induce (s : Set V)
  have xa : G.Adj x a := (G.mem_neighborFinset _ _).mp (nx ▸ mem_insert_self _ _)
  have ar : a ∈ s := by exact mem_compl.mpr (fun h => xa.ne.symm (mem_singleton.mp h))
  let start : s := ⟨a,ar⟩
  have near {w : V} (xw : G.Adj x w) : w = a ∨ w = b := by
    have h := (G.mem_neighborFinset _ _).mpr xw
    simpa [nx] using h
  apply (connected_iff_exists_forall_reachable H).mpr
  refine ⟨start,?_⟩
  intro dest
  let state (v : V) : Prop := ∀ hv : v ∈ s, H.Reachable start ⟨v,hv⟩
  have step (z : V) : ∀ w, G.Adj z w → state z → state w := by
    intro w zw ih hw
    by_cases hz : z ∈ s
    · have adj : H.Adj (⟨z,hz⟩ : s) ⟨w,hw⟩ := zw
      exact (ih hz).trans adj.reachable
    · have zx : z = x := by simpa [s,rest] using hz
      subst z
      rcases near zw with eq | eq
      · subst w; exact Reachable.refl _
      · subst w; exact (show H.Adj start ⟨b,hw⟩ from ab).reachable
  have walk := (G.reachable_iff_reflTransGen a dest.val).mp (hc a dest.val)
  have run {v : V} (h : Relation.ReflTransGen G.Adj a v) : state v := by
    induction h with
    | refl => exact fun _ => Reachable.refl _
    | tail _ adj ih => exact step _ _ adj ih
  exact run walk dest.property

/-- The arithmetic test accounts for counts which collide, disappear or
are created when the endpoints of the triangle lose one incidence each. -/
theorem delete_failure {x a b : V} (hc : G.Connected) (ord : 3 < Fintype.card V)
    (fail : bound G < gamma G) (ab : G.Adj a b) (nx : G.neighborFinset x = {a,b})
    (rank : ((types G).card+1)/2 ≤ ((after G x a b).card+1)/2) :
    let s := (rest x)
    2 < s.card ∧ (G.induce (s : Set V)).Connected ∧
      bound (G.induce (s : Set V)) < gamma (G.induce (s : Set V)) := by
  let s := (rest x)
  let H := G.induce (s : Set V)
  have sz : s.card = Fintype.card V-1 := by simp only [s,rest,card_compl,card_singleton]
  dsimp only
  change 2 < s.card ∧ _
  refine ⟨by omega,connected_delete G hc ab nx,?_⟩
  have up := Capacity.seeded_value G ∅ s ∅ (by simp) (by simp) (by simp) (by simp)
  have cost := TrianglePrune.induced_cost G s
  simp only [card_empty,zero_add] at up
  change s.card ≤ gamma H + _ at cost
  unfold bound at fail ⊢
  change Fintype.card s - ((types H).card+1)/2 < gamma H
  have afterLe : (after G x a b).card ≤ s.card := card_image_le
  rw [Fintype.card_coe,types_after G ab nx]
  omega

end Graffiti384b.EarPrune

#print axioms Graffiti384b.EarPrune.types_after
#print axioms Graffiti384b.EarPrune.delete_failure
namespace Graffiti384b.EarPrune
open Finset AllPairsExample

/-- In the sharp eleven-vertex graph, deleting score-one vertex 9 changes
the two endpoint scores and leaves nine distinct values. -/
theorem sharp_example_after :
    types (graph.induce (rest (9 : V) : Set V)) = {0,2,3,4,5,8,9,10,12} := by
  rw [types_after graph (show graph.Adj (0 : V) 1 by decide)
    (show graph.neighborFinset (9 : V) = {0,1} by decide)]
  decide

end Graffiti384b.EarPrune

#print axioms Graffiti384b.EarPrune.sharp_example_after
