import EarCut34_384b
import PinnedColor34_384b

namespace Graffiti384b.EarSquares34
open Finset SimpleGraph LowSample
open private Repair.nbr_mono from Repair384b
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def opposite (a b : Finset V) : Prop := (∀ v∈a,2≤nbr G v b) ∧ (∀ v∈b,2≤nbr G v a)

theorem glue {a b c d : Finset V} (ab : opposite G a b) (cd : opposite G c d)
    (dis : Disjoint (a∪c) (b∪d)) (low : twos G⊆(a∪c)∪(b∪d)) (q : (types G).card≤(nonleaves G).card) :
    gamma G≤bound G := by
  apply PinnedColor34.complete G dis q
  · intro v vn np nq
    by_contra! small
    have no : v∉high G := fun vh => (not_lt_of_ge (mem_filter.mp vh).2) small
    exact (mem_union.mp (low (mem_sdiff.mpr ⟨vn,no⟩))).elim np nq
  · intro v m
    exact (mem_union.mp m).elim (fun i => (ab.1 v i).trans (Repair.nbr_mono G v subset_union_left))
      (fun i => (cd.1 v i).trans (Repair.nbr_mono G v subset_union_right))
  · intro v m
    exact (mem_union.mp m).elim (fun i => (ab.2 v i).trans (Repair.nbr_mono G v subset_union_left))
      (fun i => (cd.2 v i).trans (Repair.nbr_mono G v subset_union_right))

theorem square {y x : V} (yt : y∈twos G) (ne : y≠x) (common : G.neighborFinset y⊆G.neighborFinset x) :
    opposite G (G.neighborFinset y) {y,x} ∧ Disjoint (G.neighborFinset y) {y,x} := by
  have cardinal := (card_neighborFinset_eq_degree G y).trans (LowSample.two_degree G yt)
  have adj (a : V) (ay : a∈G.neighborFinset y) := ((G.mem_neighborFinset _ _).mp (common ay)).symm
  refine ⟨⟨?_,?_⟩,?_⟩
  · intro a ay
    have allQ : ({y,x} : Finset V).filter (G.Adj a)={y,x} := filter_true_of_mem (fun j jm => by
      rcases mem_insert.mp jm with rfl|eq
      · exact ((G.mem_neighborFinset _ _).mp ay).symm
      · exact (mem_singleton.mp eq) ▸ adj a ay)
    rw [nbr,allQ,card_pair ne]
  · intro a am
    have sub : G.neighborFinset y⊆(G.neighborFinset y).filter (G.Adj a) := fun j jm => mem_filter.mpr ⟨jm,by
      rcases mem_insert.mp am with rfl|eq
      · exact (G.mem_neighborFinset _ _).mp jm
      · exact (mem_singleton.mp eq) ▸ (adj j jm).symm⟩
    exact cardinal ▸ card_le_card sub
  · apply disjoint_left.mpr
    intro a ay ax
    rcases mem_insert.mp ax with rfl|eq
    · exact G.not_mem_neighborFinset_self a ay
    · exact (adj a ay).ne (mem_singleton.mp eq)

/-- When each disjoint ear anchor pair has a second common neighbor, the
two four-cycles can always be oriented compatibly. -/
theorem disjoint_exact {y z x w : V} (yz : y≠z) (ears : twos G={y,z})
    (sep : Disjoint (G.neighborFinset y) (G.neighborFinset z))
    (yx : y≠x) (zw : z≠w) (cx : G.neighborFinset y⊆G.neighborFinset x)
    (cw : G.neighborFinset z⊆G.neighborFinset w) (q : (types G).card≤(nonleaves G).card) :
    gamma G≤bound G := by
  let A := G.neighborFinset y
  let B := G.neighborFinset z
  let X : Finset V := {y,x}
  let Y : Finset V := {z,w}
  have yt : y∈twos G := ears ▸ mem_insert_self _ _
  have zt : z∈twos G := ears ▸ mem_insert_of_mem (mem_singleton_self _)
  obtain ⟨ax,dx⟩ := square G yt yx cx
  obtain ⟨by',dy⟩ := square G zt zw cw
  have an : A.Nonempty := card_pos.mp (by rw [show A=G.neighborFinset y from rfl,card_neighborFinset_eq_degree,LowSample.two_degree G yt]; decide)
  have bn : B.Nonempty := card_pos.mp (by rw [show B=G.neighborFinset z from rfl,card_neighborFinset_eq_degree,LowSample.two_degree G zt]; decide)
  have xz : x≠z := by
    intro eq
    obtain ⟨a,am⟩ := an
    exact disjoint_left.mp sep am (eq ▸ cx am)
  have wy : w≠y := by
    intro eq
    obtain ⟨b,bm⟩ := bn
    exact disjoint_left.mp sep (eq ▸ cw bm) bm
  have lo {S : Finset V} (ys : y∈S) (zs : z∈S) : twos G⊆S := ears ▸ insert_subset ys (singleton_subset_iff.mpr zs)
  by_cases same : x=w
  · subst w
    -- If the second witnesses coincide, an edge y-z would put x next
    -- to both ears and put x in the two disjoint anchor pairs.
    have no : ¬G.Adj y z := by
      intro edge
      have xz' := (G.mem_neighborFinset _ _).mp (cx ((G.mem_neighborFinset _ _).mpr edge))
      have xy' := (G.mem_neighborFinset _ _).mp (cw ((G.mem_neighborFinset _ _).mpr edge.symm))
      exact disjoint_left.mp sep ((G.mem_neighborFinset _ _).mpr xy'.symm) ((G.mem_neighborFinset _ _).mpr xz'.symm)
    apply glue G ax by' _ (lo (mem_union_right _ (mem_union_left _ (mem_insert_self ..)))
      (mem_union_right _ (mem_union_right _ (mem_insert_self ..)))) q
    apply disjoint_left.mpr
    intro a m s
    rcases mem_union.mp m with ay|az <;> rcases mem_union.mp s with yy|zz
    · exact disjoint_left.mp dx ay yy
    · rcases mem_insert.mp zz with rfl|eq
      · exact no ((G.mem_neighborFinset _ _).mp ay)
      · exact disjoint_left.mp dx ay (mem_insert_of_mem eq)
    · rcases mem_insert.mp yy with rfl|eq
      · exact no ((G.mem_neighborFinset _ _).mp az).symm
      · exact disjoint_left.mp dy az (mem_insert_of_mem eq)
    · exact disjoint_left.mp dy az zz
  · have sepQ : Disjoint X Y := disjoint_left.mpr (by
      intro j jx jy
      simp only [X,Y,mem_insert,mem_singleton] at jx jy
      rcases jx with rfl|rfl <;> rcases jy with h|h <;> first | exact yz h | exact wy h.symm | exact xz h | exact same h)
    apply glue G ax (show opposite G Y B from ⟨by'.2,by'.1⟩) _ (lo (mem_union_right _ (mem_union_left _ (mem_insert_self ..)))
      (mem_union_left _ (mem_union_right _ (mem_insert_self ..)))) q
    apply disjoint_left.mpr
    intro a m s
    rcases mem_union.mp m with ay|yy <;> rcases mem_union.mp s with xx|az
    · exact disjoint_left.mp dx ay xx
    · exact disjoint_left.mp sep ay az
    · exact disjoint_left.mp sepQ xx yy
    · exact disjoint_left.mp dy az yy
end Graffiti384b.EarSquares34
#print axioms Graffiti384b.EarSquares34.disjoint_exact
