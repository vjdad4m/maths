import EarBudget34_384b

namespace Graffiti384b.EarTriangle34
open Finset SimpleGraph LowSample
open private LowSample.anchors LowSample.two_degree from LowSample384b
open private TrianglePrune.skeleton TrianglePrune.scores from TrianglePrune384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Two adjacent degree-two vertices on a triangle are impossible in a
failure with 31 high vertices, 33 types and at most two degree-two vertices.
No connectivity or order assumption is required. -/
theorem exact (t : (types G).card=33) (h : (high G).card=31) (nt : (twos G).card≤2)
    {y z w : V} (yt : y∈twos G) (zt : z∈twos G) (yz : G.Adj y z) (yw : G.Adj y w) (zw : G.Adj z w) :
    gamma G≤bound G := by
  classical
  by_contra! fail
  have pairSub := insert_subset yt (singleton_subset_iff.mpr zt)
  have pair : twos G={y,z} := (eq_of_subset_of_card_le pairSub (by rw [card_pair yz.ne]; exact nt)).symm
  let J := TrianglePrune.skeleton G y ∅
  have mono : J≤G := fun _ _ edge => edge.1
  have keep {a b c : V} (ab : G.Adj a b) (ac : G.Adj a c) (bc : G.Adj b c) : J.Adj a b := ⟨ab,Or.inl ⟨c,ac,bc⟩⟩
  have jyz := keep yz yw zw
  have jyw := keep yw yz zw.symm
  have jzw := keep zw yz.symm yw.symm
  have sc (v : V) := TrianglePrune.scores G y ∅ v
  have teq : types J=types G := image_congr (fun v _ => sc v)
  have hi : high J=high G := by
    ext a
    constructor
    · intro mem
      exact mem_filter.mpr ⟨mem_univ _,(mem_filter.mp mem).2.trans (SimpleGraph.degree_le_of_le mono)⟩
    · intro mem
      have big := (Repair.maximal_diversity G (by omega)).2.1 a mem
      have deg : 3≤J.degree a := by
        by_contra! small
        have lim := (Repair.triangles_le_choose J a).trans (Nat.choose_le_choose 2 (show J.degree a≤2 by omega))
        change trianglesAt J a≤1 at lim
        have eq := sc a
        change trianglesAt J a=trianglesAt G a at eq; omega
      exact mem_filter.mpr ⟨mem_univ _,deg⟩
  have two {a b c : V} (ab : J.Adj a b) (ac : J.Adj a c) (ne : b≠c) : 2≤J.degree a := by
    have sub := insert_subset ((J.mem_neighborFinset _ _).mpr ab) (singleton_subset_iff.mpr ((J.mem_neighborFinset _ _).mpr ac))
    simpa only [card_pair ne,card_neighborFinset_eq_degree] using card_le_card sub
  have jtw {v : V} (vt : v∈twos G) (dg : 2≤J.degree v) : v∈twos J :=
    mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,dg⟩,hi ▸ (mem_sdiff.mp vt).2⟩
  have jyt := jtw yt (two jyz jyw zw.ne)
  have jzt := jtw zt (two jyz.symm jzw yw.ne)
  have wh : w∈high J := by
    rw [hi]
    by_contra out
    have low : w∈twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,(two jyw.symm jzw.symm yz.ne).trans (SimpleGraph.degree_le_of_le mono)⟩,out⟩
    simp [pair,yw.ne.symm,zw.ne.symm] at low
  have near : J.neighborFinset w⊆high J∪{y,z} := by
    intro a am
    by_cases ah : a∈high G
    · exact mem_union_left _ (hi ▸ ah)
    · apply mem_union_right
      rw [←pair]
      have edge := (J.mem_neighborFinset _ _).mp am
      change G.Adj w a ∧ ((∃ c,G.Adj w c ∧ G.Adj a c) ∨ _ ∨ _) at edge
      obtain ⟨c,wc,ac⟩ : ∃ c,G.Adj w c ∧ G.Adj a c := by simpa using edge.2
      have d := two (keep edge.1.symm ac wc) (keep ac edge.1.symm wc.symm) wc.ne
      exact mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,d.trans (SimpleGraph.degree_le_of_le mono)⟩,ah⟩
  have anc {a b : V} (atw : a∈twos J) (btw : b∈twos J) (ab : J.Adj a b) (aw : J.Adj a w) (bw : b≠w) :
      LowSample.anchors J a={w} := by
    have sub := insert_subset ((J.mem_neighborFinset _ _).mpr ab) (singleton_subset_iff.mpr ((J.mem_neighborFinset _ _).mpr aw))
    have eq := eq_of_subset_of_card_le sub (by rw [card_pair bw,card_neighborFinset_eq_degree,LowSample.two_degree J atw])
    ext i
    constructor
    · intro mem
      have ai := (J.mem_neighborFinset _ _).mpr (mem_filter.mp mem).2
      rw [←eq,mem_insert,mem_singleton] at ai
      rcases ai with rfl|iw
      · exact ((mem_sdiff.mp btw).2 (mem_filter.mp mem).1).elim
      · exact mem_singleton.mpr iw
    · intro iw; obtain rfl := mem_singleton.mp iw
      exact mem_filter.mpr ⟨wh,aw⟩
  have ok := EarBudget34.exact J jyw wh jyt jzt yz.ne (anc jyt jzt jyz jyw zw.ne)
    (anc jzt jyt jyz.symm jzw yw.ne) near (hi ▸ h) (teq ▸ t)
  have gm : gamma G≤gamma J := by
    have avail : {k : ℕ | ∃ d, TwoDominates J d ∧ d.card=k}.Nonempty := ⟨_,univ,by simp [TwoDominates],rfl⟩
    obtain ⟨D,dom,sz⟩ := Nat.sInf_mem avail
    have good : TwoDominates G D := fun v hv => (dom v hv).trans (card_le_card (show D.filter (J.Adj v)⊆D.filter (G.Adj v) from
      fun _ hm => mem_filter.mpr ⟨(mem_filter.mp hm).1,mono (mem_filter.mp hm).2⟩))
    exact Nat.sInf_le (s:={k | ∃ d,TwoDominates G d ∧ d.card=k}) ⟨D,good,sz⟩
  have same : bound J=bound G := by simp only [bound,teq]
  exact (not_lt_of_ge ((gm.trans ok).trans_eq same)) fail

end Graffiti384b.EarTriangle34
#print axioms Graffiti384b.EarTriangle34.exact
