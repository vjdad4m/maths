import Frontier34_384b
import EarTriangle34_384b
import DisjointEars34_384b
import CliqueDegrees34_384b
import SharedProfile34_384b

namespace Graffiti384b.Ears34
open Finset SimpleGraph LowSample
open private LowSample.anchors LowSample.two_degree from LowSample384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- In the normalized order-34 branch the ears form an independent set. -/
theorem independent (res : Minimal.Residual G) (n : Fintype.card V=34) :
    ∀ y∈twos G, ∀ z∈twos G, ¬G.Adj y z := by
  classical
  intro y yt z zt yz
  obtain ⟨q,t,hs⟩ := Frontier34.boundary G res n
  obtain ⟨tw,scores,_⟩ := Frontier34.ears G res n
  have pairSub := insert_subset yt (singleton_subset_iff.mpr zt)
  have num := card_le_card pairSub
  rw [card_pair yz.ne] at num
  have h : (high G).card=31 := by omega
  have y1 := scores y yt
  have z1 := scores z zt
  obtain ⟨w,yw,zw⟩ := res.2.2.2.1.2.2 y z yz (by omega) (by omega)
  exact (not_lt_of_ge (EarTriangle34.exact G t h (by omega) yt zt yz yw zw)) res.2.2.1

/-- Every ear has an adjacent pair of high anchors. Two distinct ears have
either three or four distinct anchors between them. -/
theorem anchor_sets (res : Minimal.Residual G) (n : Fintype.card V=34) :
    (∀ y∈twos G, G.neighborFinset y⊆high G) ∧
    (∀ y∈twos G, ∀ z∈twos G, y≠z →
      (G.neighborFinset y∪G.neighborFinset z).card=3 ∨ (G.neighborFinset y∪G.neighborFinset z).card=4) := by
  obtain ⟨_,sc,distinct⟩ := Frontier34.ears G res n
  constructor
  · intro y yt j jm
    have pos := sc y yt
    obtain ⟨u,v,yu,yv,uv⟩ := (TrianglePrune.triangle_iff G y).mp (by omega)
    have sub := insert_subset ((G.mem_neighborFinset _ _).mpr yu) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr yv))
    have eq := eq_of_subset_of_card_le sub (by rw [card_pair uv.ne,card_neighborFinset_eq_degree,LowSample.two_degree G yt])
    have atLeast {a b c : V} (ab : G.Adj a b) (ac : G.Adj a c) (ne : b≠c) : 2≤G.degree a := by
      have inc := insert_subset ((G.mem_neighborFinset _ _).mpr ab) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr ac))
      simpa only [card_pair ne,card_neighborFinset_eq_degree] using card_le_card inc
    have dg : 2≤G.degree j := by
      rw [←eq,mem_insert,mem_singleton] at jm
      rcases jm with rfl|rfl
      · exact atLeast yu.symm uv yv.ne
      · exact atLeast yv.symm uv.symm yu.ne
    by_contra no
    exact independent G res n y yt j (mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,dg⟩,no⟩) ((G.mem_neighborFinset _ _).mp jm)
  · intro y yt z zt yz
    let A := G.neighborFinset y
    let B := G.neighborFinset z
    have ca : A.card=2 := (card_neighborFinset_eq_degree _ _).trans (LowSample.two_degree G yt)
    have cb : B.card=2 := (card_neighborFinset_eq_degree _ _).trans (LowSample.two_degree G zt)
    have low : 2<(A∪B).card := by
      by_contra! le
      have eq1 := eq_of_subset_of_card_le (show A⊆A∪B from subset_union_left) (by omega)
      have eq2 := eq_of_subset_of_card_le (show B⊆A∪B from subset_union_right) (by omega)
      exact distinct y yt z zt yz (eq1.trans eq2.symm)
    have up := card_union_le A B
    change (A∪B).card=3 ∨ (A∪B).card=4
    omega

/-- The shared-anchor configuration, stated directly on the normalized
order-34 frontier. A missing edge among the anchors forces both cubic scores. -/
theorem shared (res : Minimal.Residual G) (n : Fintype.card V=34) {y z : V}
    (yt : y∈twos G) (zt : z∈twos G) (yz : y≠z)
    (three : (G.neighborFinset y∪G.neighborFinset z).card=3) :
    let W := G.neighborFinset y∪G.neighborFinset z
    let C := SharedMany34.candidates G W
    3≤C.card ∧ C.card≤6 ∧ ((∃ i∈W,∃ j∈W,i≠j ∧ ¬G.Adj i j) →
      4≤C.card ∧ (∃ v∈C,nbr G v W=3) ∧
      (((high G).filter (fun v => G.degree v=3 ∧ nbr G v W=0)).image (trianglesAt G))={2,3}) := by
  obtain ⟨q,t,hh⟩ := Frontier34.boundary G res n
  have tw := (Frontier34.ears G res n).1
  have sub := insert_subset yt (singleton_subset_iff.mpr zt)
  have num := card_le_card sub
  rw [card_pair yz] at num
  have h : (high G).card=31 := by omega
  have eq : twos G={y,z} := (eq_of_subset_of_card_le sub (by rw [card_pair yz]; omega)).symm
  have al := (anchor_sets G res n).1
  exact SharedProfile34.profile G yz eq n h t q res.2.2.1 _ rfl three (union_subset (al _ yt) (al _ zt))

theorem diversity (hc : G.Connected) (hn : 2<Fintype.card V) (fail : bound G<gamma G) :
    (7≤(types G).card ∧ (types G).card≤31) ∨ (types G).card=33 := by
  have lo : 7≤(types G).card := Nat.le_of_not_gt (fun lt => (not_lt_of_ge (Anchor.exact_of_six_types G hc hn (by omega))) fail)
  have hi : (types G).card<34 := Nat.lt_of_not_ge (fun big => (not_lt_of_ge (Diversity35.exact_of_at_least_34_types G hc hn big)) fail)
  have no : (types G).card≠32 := fun eq => (not_lt_of_ge (Below33.exact32 G hc hn eq)) fail
  omega

theorem least_diversity (res : Minimal.Residual G) : ∃ j : Fin 14, (types G).card = 7 + 2*j.val := by
  have opts := diversity G res.2.1 res.1.1 res.2.2.1
  have odd := res.2.2.2.2.1
  refine ⟨⟨((types G).card-7)/2,by omega⟩,?_⟩
  change (types G).card=7+2*(((types G).card-7)/2)
  omega

/-- Below the 33-type endpoint, the normalized least-order search has
order at most 33 and exactly thirteen candidate diversity values. -/
theorem least_smaller (res : Minimal.Residual G) (below : (types G).card≠33) :
    Fintype.card V≤33 ∧ ∃ j : Fin 13, (types G).card=7+2*j.val := by
  have size := Frontier34.minimum_order G res
  have smaller : Fintype.card V≠34 := fun eq => below (Frontier34.boundary G res eq).2.1
  obtain ⟨j,score⟩ := least_diversity G res
  have cap := j.isLt
  have fits : j.val<13 := by omega
  exact ⟨by omega,⟨⟨j.val,fits⟩,score⟩⟩

end Graffiti384b.Ears34
#print axioms Graffiti384b.EarAnchor34.balance
#print axioms Graffiti384b.EarBudget34.exact
#print axioms Graffiti384b.EarTriangle34.exact
#print axioms Graffiti384b.CliqueCut34.pair_obstruction
#print axioms Graffiti384b.CliqueCut34.exterior
#print axioms Graffiti384b.CliqueMass34.pair
#print axioms Graffiti384b.CliqueMass34.budget
#print axioms Graffiti384b.CliqueDegrees34.degrees
#print axioms Graffiti384b.CliqueDegrees34.one_ear
#print axioms Graffiti384b.EarCut34.joint
#print axioms Graffiti384b.EarCut34.shared
#print axioms Graffiti384b.DisjointEars34.pair
#print axioms Graffiti384b.SharedMany34.overlap
#print axioms Graffiti384b.Ears34.independent
#print axioms Graffiti384b.Ears34.anchor_sets
#print axioms Graffiti384b.Ears34.shared
#print axioms Graffiti384b.Ears34.diversity
#print axioms Graffiti384b.Ears34.least_diversity
#print axioms Graffiti384b.Ears34.least_smaller
