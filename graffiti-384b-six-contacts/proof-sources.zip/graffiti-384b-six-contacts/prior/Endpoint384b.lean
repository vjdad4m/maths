import CliqueSample384b
import EarProfile384b

namespace Graffiti384b.Endpoint
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def targets : Finset ℕ := {35,37,39,41,43}
def quota (t : ℕ) := max 39 (t-1)
def cutoff (t : ℕ) (f : Finset ℕ) :=
  if t ≤ 37 ∨ (t = 39 ∧ ∃ d ∈ f, 4 ≤ d) then 38 else quota t
def batch (t : ℕ) := if t ≤ 39 then 14 else 15

private def Certificate (t e : ℕ) (f : Finset ℕ) : Prop :=
  let h := t-e
  let m := h-f.card
  let b := batch t
  12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧
    6*(((t+1)/2-1)*m.choose b + charge t h m b f) <
    6*(m-b)*m.choose b + (cutoff t f-h)*(6*(m-2).choose (b-2)) + 6*∑ d ∈ f, bonus m b d

set_option maxRecDepth 32768 in
set_option maxHeartbeats 10000000 in
private theorem table : ∀ t ∈ targets, ∀ e ∈ ({1,2} : Finset ℕ), ∀ f ∈ degrees.powerset,
    Certificate t e f := by
  unfold Certificate charge LowSample.delta envelope FiniteRange.badCount reward LowSample.weight bonus slots
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

theorem profiled {p : Finset V} (ch : Choice G p) (fail : bound G < gamma G) (member : (types G).card ∈ targets) :
    (nonleaves G).card < cutoff (types G).card (p.image (fun v => G.degree v)) := by
  let t := (types G).card
  let h := (high G).card
  let e := t-h
  let f := p.image (fun v => G.degree v)
  let m := h-f.card
  let b := batch t
  have sz : (high G \ p).card = m := by
    dsimp only [m,h,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  have miss : (h+1)/2 < (t+1)/2 := Nat.lt_of_not_ge (fun le => (not_le_of_gt fail) (exact_of_high G le))
  have limit : t ≤ h+2 := type_bound G
  have off : e ∈ ({1,2} : Finset ℕ) := by simp only [mem_insert,mem_singleton]; dsimp [e]; omega
  have diff : t-e = h := by dsimp [e]; omega
  have tab := table t member e off f (mem_powerset.mpr ch.levels)
  unfold Certificate at tab
  rw [diff] at tab
  change 12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧ _ at tab
  obtain ⟨large,two,env,rew,cert⟩ := tab
  change 6*(((t+1)/2-1)*m.choose b + charge t h m b f) <
    6*(m-b)*m.choose b + (cutoff t f-h)*(6*(m-2).choose (b-2)) + 6*∑ d ∈ f, bonus m b d at cert
  have obs := obstruction G ch b (sz ▸ large) two (sz ▸ env) (sz ▸ rew) fail
  change 6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*∑ d ∈ f, bonus m b d ≤
    6*(((t+1)/2-1)*m.choose b + charge t h m b f) at obs
  have sub : high G ⊆ nonleaves G := by
    intro v hv
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have size : (twos G).card+h = (nonleaves G).card := card_sdiff_add_card_eq_card sub
  change (nonleaves G).card < cutoff t f
  by_contra! enough
  have wt := Nat.mul_le_mul_right (6*(m-2).choose (b-2)) (show cutoff t f-h ≤ (twos G).card by omega)
  omega

theorem targeted (hc : G.Connected) (fail : bound G < gamma G) (member : (types G).card ∈ targets) :
    (nonleaves G).card < quota (types G).card := by
  letI : Nonempty V := hc.nonempty
  obtain ⟨p,ch⟩ := choose_vertices G
  have k := profiled G ch fail member
  unfold cutoff at k
  split_ifs at k
  · unfold quota; omega
  · exact k

/-- A failure preserves its entire set of triangle counts on a connected induced
failure on at most 39 vertices. The original graph has at most 39 types. -/
theorem bounded_failure (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ r.card ≤ 39 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V)) = types G ∧ 7 ≤ (types G).card ∧ (types G).card ≤ 39 ∧
      (types G).card ≠ 38 ∧ bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨_,_,_,_,_,lo,hi,ne38,ne40,ne42,_⟩ := LowSample.bounded_failure G hc hn bad
  obtain ⟨r,_,cap,ord,conn,same,fails⟩ := Prune.prune_failure G hc hn bad
  have rank : (types (G.induce (r : Set V))).card ≤ r.card := by
    simpa [types] using (card_image_le (s := (univ : Finset r)) (f := trianglesAt (G.induce (r : Set V))))
  rw [same] at rank
  suffices small : (nonleaves G).card ≤ 38 by exact ⟨r,ord,by omega,conn,same,lo,by omega,ne38,fails⟩
  by_cases top : (types G).card ∈ targets
  · have q := targeted G hc bad top
    unfold quota at q
    omega
  · simp only [targets,mem_insert,mem_singleton,not_or] at top
    have low : (types G).card ≤ 36 := by omega
    by_cases many : 14 ≤ (types G).card
    · obtain ⟨q,_,_⟩ := nonleaf_profile G bad many hi
      have capRow : ∀ t : Fin 37, ∀ e : Fin 3, (row t e).1 ≤ 38 := by decide
      have lim := type_bound G
      exact q.trans (capRow ⟨(types G).card,by omega⟩ ⟨(types G).card-(high G).card,by omega⟩)
    · have q := nonleaf_bound G
      unfold bound at bad
      omega

theorem exact_of_at_least_forty (hc : G.Connected) (hn : 2 < Fintype.card V)
    (ht : 40 ≤ (types G).card) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨_,_,_,_,_,_,upper,_,_⟩ := bounded_failure G hc hn fail
  omega

end Graffiti384b.Endpoint

#print axioms Graffiti384b.Endpoint.targeted
#print axioms Graffiti384b.Endpoint.bounded_failure
#print axioms Graffiti384b.Endpoint.exact_of_at_least_forty

namespace Graffiti384b.Endpoint
open Finset SimpleGraph CliqueChoice LowSample
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- At the new order boundary every vertex has its own score, exactly one
vertex is a leaf, and degree four through six vertices have incomplete links. -/
theorem minimum_profile (res : Minimal.Residual G) :
    Fintype.card V ≤ 39 ∧ (Fintype.card V = 39 →
      (types G).card = 39 ∧ Function.Injective (trianglesAt G) ∧ (nonleaves G).card = 38 ∧
      ∀ v, 4 ≤ G.degree v → G.degree v ≤ 6 → trianglesAt G v < (G.degree v).choose 2) := by
  obtain ⟨⟨hn,_⟩,hc,bad,_,odd,_,_,_,least⟩ := res
  obtain ⟨r,ord,cap,conn,_,_,top,_,fails⟩ := bounded_failure G hc hn bad
  have minN := least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord,conn,fails⟩
  refine ⟨by omega,fun n39 => ?_⟩
  obtain ⟨r',_,qcap,ord',rc',_,rf'⟩ := Prune.prune_failure G hc hn bad
  have ncap := least r'.card ⟨r',inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord',rc',rf'⟩
  letI : Nonempty V := hc.nonempty
  obtain ⟨p,ch⟩ := choose_vertices G
  let f := p.image (fun v => G.degree v)
  let t := (types G).card
  have bigQ : 38 ≤ (nonleaves G).card := by omega
  have lower : 14 ≤ t := by
    have old := nonleaf_bound G
    unfold bound at bad
    change 14 ≤ (types G).card
    omega
  have row := (nonleaf_profile G bad lower (by omega)).1
  have tb := type_bound G
  have small : ∀ w : Fin 35, ∀ e : Fin 3, (LowSample.row w e).1 ≤ 37 := by decide
  have gt : 35 ≤ t := by
    by_contra! lt
    have cap := small ⟨(types G).card,lt⟩ ⟨(types G).card-(high G).card,by omega⟩
    change (LowSample.row (types G).card ((types G).card-(high G).card)).1 ≤ 37 at cap
    omega
  have mem : t ∈ targets := by
    change (types G).card ∈ targets
    simp only [targets,mem_insert,mem_singleton]
    change 35 ≤ (types G).card at gt
    omega
  have boundQ := profiled G ch bad mem
  change (nonleaves G).card < cutoff t f at boundQ
  have excl : ¬(t ≤ 37 ∨ t = 39 ∧ ∃ d ∈ f, 4 ≤ d) := by
    intro ex
    rw [cutoff,if_pos ex] at boundQ
    omega
  have t39 : t = 39 := by change (types G).card % 2 = 1 at odd; change t % 2 = 1 at odd; change t ≤ 39 at top; omega
  have inj := card_image_iff.mp (show ((univ : Finset V).image (trianglesAt G)).card = univ.card by
    change t = _; rw [card_univ,t39,n39])
  have q38 : (nonleaves G).card = 38 := by
    rw [cutoff,if_neg excl,t39] at boundQ
    change (nonleaves G).card < 39 at boundQ
    omega
  refine ⟨t39,fun _ _ eq => inj (mem_univ _) (mem_univ _) eq,q38,?_⟩
  intro v low hi
  have up := Repair.triangles_le_choose G v
  by_contra! sat
  have level : G.degree v ∈ degrees := by simp only [degrees,mem_insert,mem_singleton]; omega
  exact excl (Or.inr ⟨t39,G.degree v,ch.covers v level (Nat.le_antisymm up sat),low⟩)

end Graffiti384b.Endpoint
#print axioms Graffiti384b.Endpoint.minimum_profile
