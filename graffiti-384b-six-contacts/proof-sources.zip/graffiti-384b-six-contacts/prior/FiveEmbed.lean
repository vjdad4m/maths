import LocalTree
namespace Graffiti384b.PairMix.Local
open Finset SimpleGraph LowSample
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

set_option maxHeartbeats 0 in
private theorem keys : ∀a b x y:Label,a<b → x<y → b.val<9 → y.val<9 →
    position a b=position x y → a=x ∧ b=y := by decide

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
theorem represents (f : Label ↪ V)
    (shape : ∀i j:Label, (9 ≤ i.val ∨ 9 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j))) :
    ∃a:ℕ→Bool,∀i j:Label,edge a i j=true ↔ G.Adj (f i) (f j) := by
  classical
  let a := fun n : ℕ => decide (∃x y:Label,x<y ∧ y.val<9 ∧ position x y=n ∧ G.Adj (f x) (f y))
  have value (i j : Label) (ij : i<j) (j9 : j.val<9) : a (position i j)=true ↔ G.Adj (f i) (f j) := by
    change decide _=true ↔ _
    rw [decide_eq_true_eq]
    constructor
    · rintro ⟨x,y,xy,y9,k,adj⟩
      obtain ⟨rfl,rfl⟩ := keys _ _ _ _ xy ij y9 j9 k
      exact adj
    · exact fun h => ⟨i,j,ij,j9,rfl,h⟩
  refine ⟨a,?_⟩
  intro i j; unfold edge
  by_cases eq : i=j
  · subst j; simp
  rw [if_neg eq]
  split
  · rename_i young
    rcases lt_or_gt_of_ne eq with lt|gt
    · exact value i j lt young.2
    · rw [show position i j=position j i by simp [position,max_comm,min_comm],value j i gt young.1]
      exact G.adj_comm _ _
  · rename_i old; exact shape i j (by omega)

/-- Every link edge has two distinct labels, and their order makes the representation unique. -/
theorem counts (f : Label ↪ V) (a : ℕ→Bool)
    (edges : ∀i j:Label,edge a i j=true ↔ G.Adj (f i) (f j)) (i : Label)
    (locality : ∀z∈Repair.linkSupport G (f i),z∈Set.range f) :
    (triangles a i).card=trianglesAt G (f i) := by
  classical
  let P := triangles a i
  let liftPair (z : Label×Label) : Finset V := {f z.1,f z.2}
  have sm (z : Label×Label) : z∈P ↔ z.1<z.2 ∧ G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2) := by
    simp [P,triangles,pairs,edges,and_assoc]
  have repr : P.image liftPair=Repair.linkEdges G (f i) := by
    ext s
    constructor
    · intro hm
      obtain ⟨⟨a,b⟩,ab,rfl⟩ := mem_image.mp hm
      obtain ⟨lt,ia,ib,adj⟩ := (sm _).mp ab
      have sub : liftPair (a,b)⊆G.neighborFinset (f i) := insert_subset ((G.mem_neighborFinset ..).mpr ia)
        (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr ib))
      refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub,card_pair (f.injective.ne lt.ne)⟩,?_⟩
      intro x xm y ym ne
      simp only [liftPair,mem_insert,mem_singleton] at xm ym
      rcases xm with rfl|rfl <;> rcases ym with rfl|rfl <;> first | exact (ne rfl).elim | exact adj | exact adj.symm
    · intro hm
      obtain ⟨sub,sz,cl⟩ := Repair.edge_info G hm
      obtain ⟨x,y,ne,rfl⟩ := card_eq_two.mp sz
      have xm : x∈({x,y}:Finset V) := mem_insert_self ..
      have ym : y∈({x,y}:Finset V) := mem_insert_of_mem (mem_singleton_self _)
      obtain ⟨a,rfl⟩ := locality x (mem_biUnion.mpr ⟨_,hm,xm⟩)
      obtain ⟨b,rfl⟩ := locality y (mem_biUnion.mpr ⟨_,hm,ym⟩)
      have ia := (G.mem_neighborFinset ..).mp (sub xm)
      have ib := (G.mem_neighborFinset ..).mp (sub ym)
      have adj := cl _ xm _ ym ne
      rcases lt_or_gt_of_ne (fun eq : a=b => ne (congrArg f eq)) with l|l
      · exact mem_image.mpr ⟨(a,b),(sm _).mpr ⟨l,ia,ib,adj⟩,rfl⟩
      · exact mem_image.mpr ⟨(b,a),(sm _).mpr ⟨l,ib,ia,adj.symm⟩,pair_comm ..⟩
  have inj : Set.InjOn liftPair (P : Set (Label×Label)) := by
    rintro ⟨a,b⟩ ap ⟨c,d⟩ cp eq
    have lt := ((sm _).mp ap).1
    have lt' := ((sm _).mp cp).1
    have eq' : ({f a,f b}:Set V)={f c,f d} := by simpa [liftPair] using congrArg (fun s : Finset V => (s:Set V)) eq
    rcases Set.pair_eq_pair_iff.mp eq' with ⟨ac,bd⟩|⟨ad,bc⟩
    · exact Prod.ext (f.injective ac) (f.injective bd)
    · have := f.injective ad
      have := f.injective bc
      change a<b at lt; change c<d at lt'
      subst c; subst d; exact (not_lt_of_ge lt.le lt').elim
  have count := congrArg Finset.card repr
  rw [card_image_of_injOn inj] at count
  exact count

def FiniteClaim := ∀ (h : Root) (a : ℕ→Bool),
  (∀r,threshold h r≤(triangles a (atRoot r)).card) → ∃P Q,Good a P Q

/-- Number of triangles at a label inside the eleven-vertex induced subgraph. -/
def inducedScore (f : Label ↪ V) (i : Label) : ℕ :=
  (pairs.filter (fun z => G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2))).card

omit [Fintype V] [DecidableEq V] in
theorem score_agrees (f : Label ↪ V) (a : ℕ→Bool)
    (edges : ∀i j:Label,edge a i j=true ↔ G.Adj (f i) (f j)) (i : Label) :
    (triangles a i).card=inducedScore G f i := by
  unfold triangles inducedScore
  congr 1
  ext p; simp only [mem_filter,edges]

/-- Transport an eleven-label protected cut to the graph and complete it by the pinned cut theorem. -/
theorem labels_induced (cert : FiniteClaim) (f : Label ↪ V) (quota : (types G).card≤(nonleaves G).card)
    (ears : ∀z∈twos G,z=f 9 ∨ z=f 10)
    (shape : ∀i j:Label, (9 ≤ i.val ∨ 9 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j)))
    (pos : ∀r:Root,2≤ inducedScore G f (atRoot r)) (h : Root)
    (large : 13≤ inducedScore G f (atRoot h)) : gamma G≤bound G := by
  classical
  obtain ⟨a,edges⟩ := represents G f shape
  obtain ⟨P,Q,dis,firstEar,secondEar,lp,rq⟩ := cert h a (fun r => by
    rw [score_agrees G f a edges]
    by_cases eq : r=h
    · subst r; simpa only [threshold,if_pos rfl] using large
    · simpa only [threshold,if_neg eq] using pos r)
  have enough (U S : Finset Label) (valid : ∀i∈U,2≤(S.filter (fun j => edge a i j=true)).card) :
      ∀v∈U.map f,2≤nbr G v (S.map f) := by
    intro v vm; obtain ⟨i,im,rfl⟩ := mem_map.mp vm
    have sub : (S.filter (fun j => edge a i j=true)).map f⊆(S.map f).filter (G.Adj (f i)) := by
      intro z zm; obtain ⟨j,jm,rfl⟩ := mem_map.mp zm
      obtain ⟨js,adj⟩ := mem_filter.mp jm
      exact mem_filter.mpr ⟨mem_map.mpr ⟨j,js,rfl⟩,(edges i j).mp adj⟩
    exact (valid i im).trans (by simpa only [card_map] using card_le_card sub)
  have either {i : Label} (m : i∈P∪Q) : f i∈P.map f ∨ f i∈Q.map f :=
    (mem_union.mp m).imp (fun x => mem_map.mpr ⟨_,x,rfl⟩) (fun x => mem_map.mpr ⟨_,x,rfl⟩)
  apply PinnedColor34.complete G (P:=P.map f) (Q:=Q.map f) ?_ quota ?_ (enough _ _ lp) (enough _ _ rq)
  · apply disjoint_left.mpr
    intro z zl zr; obtain ⟨i,im,rfl⟩ := mem_map.mp zl; obtain ⟨j,jm,eq⟩ := mem_map.mp zr
    exact disjoint_left.mp dis im (f.injective eq ▸ jm)
  · intro z zn zl zr; by_contra! low
    have low' : z∈twos G := mem_sdiff.mpr ⟨zn,fun m => (not_le_of_gt low) (mem_filter.mp m).2⟩
    rcases ears z low' with rfl|rfl
    · exact (either firstEar).elim zl zr
    · exact (either secondEar).elim zl zr
/-- Transport an eleven-label protected cut to the graph and complete it by the pinned cut theorem. -/
theorem five_labels (cert : FiniteClaim) (f : Label ↪ V) (quota : (types G).card≤(nonleaves G).card)
    (ears : ∀z∈twos G,z=f 9 ∨ z=f 10)
    (shape : ∀i j:Label, (9 ≤ i.val ∨ 9 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j)))
    (loc : ∀r:Root,∀z∈Repair.linkSupport G (f (atRoot r)),z∈Set.range f)
    (pos : ∀r:Root,2≤trianglesAt G (f (atRoot r))) (h : Root)
    (large : 13≤trianglesAt G (f (atRoot h))) : gamma G≤bound G := by
  classical
  obtain ⟨a,edges⟩ := represents G f shape
  have all (r : Root) : inducedScore G f (atRoot r)=trianglesAt G (f (atRoot r)) :=
    (score_agrees G f a edges _).symm.trans (counts G f a edges _ (loc r))
  exact labels_induced G cert f quota ears shape (fun r => (all r).symm ▸ pos r) h ((all h).symm ▸ large)
end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.counts
#print axioms Graffiti384b.PairMix.Local.labels_induced
#print axioms Graffiti384b.PairMix.Local.five_labels
