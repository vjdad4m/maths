import FourFront
import LowPairAnchors
import FiveEmbed
import Mathlib.Tactic.FinCases

namespace Graffiti384b.Four29
open Finset SimpleGraph Donor LowSample PairMix.Local
open private Repair.support_sub from Repair384b
open private Prune.links Prune.link_in_core from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Build the eleven distinct labels from five arbitrary carriers of the anchor triangles. -/
theorem five_from_local (cert : FiniteClaim) (t : (types G).card=29) (h : (high G).card=27)
    (q : (nonleaves G).card=29) {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ne : e≠f)
    (few : (triangleContacts G e f).card≤5) : gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt
  intro bad
  have D := data_of_failure G t h q bad de df ne
  by_cases cap : ∀v∈roots G e f,trianglesAt G v≤12
  · exact (not_lt_of_ge (PairMix.low_anchors G t q h de df ne cap)) bad
  push_neg at cap
  obtain ⟨largeRoot,isRoot,large⟩ := cap
  let W := roots G e f
  let X := pool G e f
  let E : Finset V := {e,f}
  have highE : Disjoint (high G) E := disjoint_left.mpr (fun _ hi em =>
    (mem_sdiff.mp (D.earSet.symm ▸ em : _∈twos G)).2 hi)
  have ecard : E.card=2 := card_pair ne
  have xw : Disjoint X W := disjoint_left.mpr (fun _ ix => (mem_sdiff.mp ix).2)
  obtain ⟨T,ct,tx,tc⟩ := exists_subsuperset_card_eq (show triangleContacts G e f⊆X from filter_subset ..)
    few (show 5 ≤ X.card by have := D.poolSize; change X.card=23 at this; omega)
  obtain ⟨a,b,ab,en⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G e).trans de)
  obtain ⟨c,d,cd,fn'⟩ := card_eq_two.mp ((card_neighborFinset_eq_degree G f).trans df)
  obtain ⟨w,U,_,wu,uc⟩ := (Finset.card_eq_succ (n:=4)).mp tc
  obtain ⟨u,U',_,uU,uc'⟩ := (Finset.card_eq_succ (n:=3)).mp uc
  obtain ⟨x,y,z,_,_,_,Uxyz⟩ := card_eq_three.mp uc'
  have Twxyz : T={w,u,x,y,z} := by rw [←wu,←uU,Uxyz]
  have Wabcd : W={a,b}∪{c,d} := by change G.neighborFinset e ∪ G.neighborFinset f=_; rw [en,fn']
  let lab : Label→V := ![a,b,c,d,w,u,x,y,z,e,f]
  let S := W∪T∪E
  have inc : S⊆univ.image lab := by
    intro v vm
    simp only [S,Wabcd,Twxyz,E,mem_union,mem_insert,mem_singleton] at vm
    rcases vm with (((rfl|rfl)|(rfl|rfl))|(rfl|rfl|rfl|rfl|rfl))|(rfl|rfl)
    · exact mem_image.mpr ⟨0,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨1,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨2,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨3,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨4,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨5,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨6,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨7,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨8,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨9,mem_univ _,rfl⟩
    · exact mem_image.mpr ⟨10,mem_univ _,rfl⟩
  have highT := tx.trans (show X⊆high G from sdiff_subset)
  have sz : S.card=11 := by
    have dis := highE.mono_left (union_subset D.highRoots highT)
    rw [show S=W∪T∪E from rfl,card_union_of_disjoint dis,
      card_union_of_disjoint (xw.symm.mono_right tx),D.rootsSize,tc,ecard]
  have inject : Function.Injective lab := by
    have inj := (card_image_iff (s:=univ) (f:=lab)).mp (Nat.le_antisymm card_image_le (by
      have ct' := card_le_card inc; rw [sz] at ct'; simpa using ct'))
    exact fun i j eq => inj (mem_univ i) (mem_univ j) eq
  let idx : Label ↪ V := ⟨lab,inject⟩
  have rangeS {v : V} (vs : v∈S) : v∈Set.range idx := by
    obtain ⟨i,_,rfl⟩ := mem_image.mp (inc vs)
    exact ⟨i,rfl⟩
  have Wmem (r : Root) : idx (atRoot r)∈W := by
    fin_cases r <;> rw [Wabcd] <;> simp [idx,lab,atRoot]
  have largest : ∃r : Root, idx (atRoot r)=largeRoot := by
    change largeRoot∈W at isRoot
    rw [Wabcd,mem_union,mem_insert,mem_singleton,mem_insert,mem_singleton] at isRoot
    rcases isRoot with (rfl|rfl)|(rfl|rfl)
    · exact ⟨0,rfl⟩
    · exact ⟨1,rfl⟩
    · exact ⟨2,rfl⟩
    · exact ⟨3,rfl⟩
  obtain ⟨r,hr⟩ := largest
  have star9 (j : Label) : G.Adj (idx 9) (idx j) ↔ j=0 ∨ j=1 := by
    change G.Adj e (idx j) ↔ _
    rw [←G.mem_neighborFinset,en,mem_insert,mem_singleton]
    change idx j=idx 0 ∨ idx j=idx 1 ↔ _
    simp only [idx.injective.eq_iff]
  have star10 (j : Label) : G.Adj (idx 10) (idx j) ↔ j=2 ∨ j=3 := by
    change G.Adj f (idx j) ↔ _
    rw [←G.mem_neighborFinset,fn',mem_insert,mem_singleton]
    change idx j=idx 2 ∨ idx j=idx 3 ↔ _
    simp only [idx.injective.eq_iff]
  have shape (i j : Label) (old : 9 ≤ i.val ∨ 9 ≤ j.val) : preset i j=true ↔ G.Adj (idx i) (idx j) := by
    have pred : (∀s:Label,preset 9 s=true ↔ s=0 ∨ s=1) ∧
        (∀s:Label,preset 10 s=true ↔ s=2 ∨ s=3) ∧ (∀r s:Label,preset r s=preset s r) := by decide
    have choices (a : Label) (ha : 9 ≤ a.val) : a=9 ∨ a=10 := by
      have tab : ∀b:Label,9 ≤ b.val → b=9 ∨ b=10 := by decide
      exact tab a ha
    rcases old with hi|hj
    · rcases choices i hi with rfl|rfl
      · exact (pred.1 j).trans (star9 j).symm
      · exact (pred.2.1 j).trans (star10 j).symm
    · rw [pred.2.2 i j,G.adj_comm]
      rcases choices j hj with rfl|rfl
      · exact (pred.1 i).trans (star9 i).symm
      · exact (pred.2.1 i).trans (star10 i).symm
  have win := five_labels G cert idx (by omega) (fun v vm => by
    rw [D.earSet,mem_insert,mem_singleton] at vm; exact vm) shape (by
    intro i v vm
    obtain ⟨p,pm,vp⟩ := mem_biUnion.mp vm
    have vn : v∈nonleaves G := Prune.link_in_core G (show p∈Prune.links G (idx (atRoot i)) from pm) vp
    apply rangeS
    by_cases vh : v∈high G
    · by_cases vw : v∈W
      · exact mem_union_left _ (mem_union_left _ vw)
      · exact mem_union_left _ (mem_union_right _ (ct (mem_filter.mpr
          ⟨mem_sdiff.mpr ⟨vh,vw⟩,idx (atRoot i),Wmem i,vm⟩)))
    · have ve : v∈twos G := mem_sdiff.mpr ⟨vn,vh⟩
      exact mem_union_right _ (show v∈E by change v∈({e,f}:Finset V); rwa [←D.earSet])) (fun i => D.rich _ (D.highRoots (Wmem i)))
      r (by rw [hr]; omega)
  exact (not_lt_of_ge win) bad

end Graffiti384b.Four29
#print axioms Graffiti384b.Four29.five_from_local
