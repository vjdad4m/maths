import FiveEmbed
namespace Graffiti384b.PairMix.Local
open Finset SimpleGraph

/-- Permute the two pairs and their ears so the distinguished anchor becomes label zero. -/
def perm (h : Root) (i : Label) : Label :=
  if i.val<4 then ⟨(i.val ^^^ h.val)%4,Nat.lt_trans (Nat.mod_lt _ (by decide)) (by decide)⟩
  else if 2≤h.val ∧ i=9 then 10 else if 2≤h.val ∧ i=10 then 9 else i

def rootPerm (h r : Root) : Root := ⟨(r.val ^^^ h.val)%4,Nat.mod_lt _ (by decide)⟩
private theorem perm_data : ∀h : Root,
    (∀i,perm h (perm h i)=i) ∧ (∀i j,preset (perm h i) (perm h j)=preset i j) ∧
    (∀i : Label,((9:ℕ) ≤ (perm h i).val) ↔ ((9:ℕ) ≤ i.val)) ∧
    (∀r,perm h (atRoot r)=atRoot (rootPerm h r)) ∧
    rootPerm h 0=h ∧ (∀r,rootPerm h r=h ↔ r=0) ∧
    (perm h 9=9 ∧ perm h 10=10 ∨ perm h 9=10 ∧ perm h 10=9) := by decide

theorem up_to_symmetry
    (zero : ∀a:ℕ→Bool,(∀r,threshold 0 r≤(triangles a (atRoot r)).card) → ∃P Q,Good a P Q) :
    FiniteClaim := by
  classical
  intro h a rich
  let G : SimpleGraph Label := {
    Adj := fun i j => edge a i j=true
    symm := by
      intro i j adj
      by_cases eq : i=j
      · subst j; exact adj
      have pp : ∀x y:Label,preset x y=preset y x := by decide
      unfold edge at adj ⊢
      rw [if_neg (Ne.symm eq)]; rw [if_neg eq] at adj
      by_cases young : i.val<9 ∧ j.val<9
      · rw [if_pos young] at adj
        rw [if_pos young.symm,show position j i=position i j by simp [position,max_comm,min_comm]]
        exact adj
      · rw [if_neg young] at adj
        rw [if_neg (fun m => young (And.symm m)),pp j i]
        exact adj
    loopless := fun i => by simp [edge] }
  obtain ⟨inv,presetEq,big,roots,root0,at0,ears⟩ := perm_data h
  let f : Label ↪ Label := ⟨perm h,fun {i j} eq => (inv i).symm.trans ((congrArg (perm h) eq).trans (inv j))⟩
  have surj (i : Label) : i∈Set.range f := ⟨perm h i,inv i⟩
  obtain ⟨b,edges⟩ := represents G f (by
    intro i j old
    change preset i j=true ↔ edge a (perm h i) (perm h j)=true
    by_cases eq : perm h i=perm h j
    · have inj := f.injective eq; subst j; simp only [edge,if_pos rfl]
      have pp : ∀x:Label,preset x x=false := by decide
      simp [pp]
    · have ge := old.imp ((big i).mpr) ((big j).mpr)
      rw [edge,if_neg eq,if_neg (by omega),presetEq])
  have agrees (r : Root) : (triangles b (atRoot r)).card=(triangles a (atRoot (rootPerm h r))).card := by
    have mapped := counts G f b edges (atRoot r) (fun z _ => surj z)
    have actual := counts G (Function.Embedding.refl Label) a (fun _ _ => Iff.rfl) (atRoot (rootPerm h r))
      (fun z _ => ⟨z,rfl⟩)
    change _=trianglesAt G (perm h (atRoot r)) at mapped
    rw [roots] at mapped
    exact mapped.trans actual.symm
  obtain ⟨P,Q,dis,e9,e10,lp,rq⟩ := zero b (by
    intro r; rw [agrees]
    simpa only [threshold,at0] using rich (rootPerm h r))
  refine ⟨P.map f,Q.map f,?_,?_,?_,?_,?_⟩
  · apply disjoint_left.mpr
    intro z zl zr; obtain ⟨i,im,rfl⟩ := mem_map.mp zl; obtain ⟨j,jm,eq⟩ := mem_map.mp zr
    exact disjoint_left.mp dis im (f.injective eq ▸ jm)
  · have transport {i : Label} (src : i∈P∪Q) : perm h i∈P.map f∪Q.map f :=
      mem_union.mpr ((mem_union.mp src).imp (fun m => mem_map.mpr ⟨i,m,rfl⟩) (fun m => mem_map.mpr ⟨i,m,rfl⟩))
    rcases ears with ⟨eq,_⟩|⟨_,eq⟩
    · exact eq ▸ transport e9
    · exact eq ▸ transport e10
  · have transport {i : Label} (src : i∈P∪Q) : perm h i∈P.map f∪Q.map f :=
      mem_union.mpr ((mem_union.mp src).imp (fun m => mem_map.mpr ⟨i,m,rfl⟩) (fun m => mem_map.mpr ⟨i,m,rfl⟩))
    rcases ears with ⟨_,eq⟩|⟨eq,_⟩
    · exact eq ▸ transport e10
    · exact eq ▸ transport e9
  all_goals
    intro v vm; obtain ⟨i,im,rfl⟩ := mem_map.mp vm
    have grow (S : Finset Label) : (S.filter (fun j => edge b i j=true)).map f⊆
        (S.map f).filter (fun j => edge a (f i) j=true) := by
      intro z zm; obtain ⟨j,jm,rfl⟩ := mem_map.mp zm
      obtain ⟨js,adj⟩ := mem_filter.mp jm
      exact mem_filter.mpr ⟨mem_map.mpr ⟨j,js,rfl⟩,(edges i j).mp adj⟩
    first
    | exact (lp i im).trans (by simpa only [card_map] using card_le_card (grow Q))
    | exact (rq i im).trans (by simpa only [card_map] using card_le_card (grow P))
end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.up_to_symmetry
