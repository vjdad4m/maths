import EarSquares34_384b
import Recolor34_384b

namespace Graffiti384b.ForkGuard34
open Finset SimpleGraph LowSample
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def row (W : Finset V) (w : V) := (high G\W).filter (G.Adj w)
def candidates (W : Finset V) := (high G\W).filter (fun v => 2≤nbr G v W)

/-- A failed completion leaves an anchor with no candidate neighbor
and with maximum induced degree one among its exterior high neighbors. -/
theorem matching {W : Finset V} (wh : W⊆high G) (ears : ∀ v∈twos G,G.neighborFinset v⊆W)
    (anchor : ∀ w∈W,∃ e∈twos G,G.Adj w e) (q : (types G).card≤(nonleaves G).card)
    (fail : bound G<gamma G) :
    ∃ w∈W,(∀ v∈candidates G W,¬G.Adj w v) ∧ (∀ m∈row G W w,nbr G m (row G W w)≤1) := by
  classical
  let C := candidates G W
  let Q := twos G∪C
  let B := W.filter (fun w => nbr G w Q<2)
  have base (v : V) (vq : v∈Q) : 2≤nbr G v W := by
    rcases mem_union.mp vq with ve|vc
    · have inc : G.neighborFinset v⊆W.filter (G.Adj v) := fun i im => mem_filter.mpr ⟨ears v ve im,(G.mem_neighborFinset _ _).mp im⟩
      have le := card_le_card inc
      rw [card_neighborFinset_eq_degree] at le
      exact (mem_filter.mp (mem_sdiff.mp ve).1).2.trans le
    · exact (mem_filter.mp vc).2
  have blind (w : V) (wb : w∈B) {j : V} (jc : j∈C) : ¬G.Adj w j := by
    intro edge
    obtain ⟨e,el,we⟩ := anchor w (mem_filter.mp wb).1
    have ne : e≠j := fun eq => (mem_sdiff.mp el).2 (eq ▸ (mem_sdiff.mp (mem_filter.mp jc).1).1)
    have two := PinnedColor34.two G ne we edge (mem_union_left C el) (mem_union_right (twos G) jc)
    exact (not_lt_of_ge two) (mem_filter.mp wb).2
  have rowOut {w v : V} (wb : w∈B) (vm : v∈row G W w) : v∉W ∧ v∉Q := by
    obtain ⟨outside,wv⟩ := mem_filter.mp vm
    exact ⟨(mem_sdiff.mp outside).2,fun vq => (mem_union.mp vq).elim (fun ve => (mem_sdiff.mp ve).2 (mem_sdiff.mp outside).1)
      (fun vc => blind w wb vc wv)⟩
  have own {u v j : V} (ub : u∈B) (vb : v∈B) (ju : j∈row G W u) (jv : j∈row G W v) : u=v := by
    by_contra ne
    obtain ⟨out,uj⟩ := mem_filter.mp ju
    have vj := (mem_filter.mp jv).2
    have hit := PinnedColor34.two G ne uj.symm vj.symm (mem_filter.mp ub).1 (mem_filter.mp vb).1
    exact blind u ub (mem_filter.mpr ⟨out,hit⟩) uj
  by_contra! none
  have existsM (w : V) (wb : w∈B) : ∃ m∈row G W w,2≤nbr G m (row G W w) := by
    by_contra! missing
    have reject := none w (mem_filter.mp wb).1 (fun v vc => blind w wb vc)
    obtain ⟨m,vm,big⟩ := reject
    have small := missing m vm
    omega
  let mid (w : V) := if wb : w∈B then (existsM w wb).choose else w
  have prop (w : V) (wb : w∈B) : mid w∈row G W w ∧ 2≤nbr G (mid w) (row G W w) := by
    simpa only [mid,dif_pos wb] using (existsM w wb).choose_spec
  let ends (w : V) := (row G W w).filter (G.Adj (mid w))
  let M := B.image mid
  let X := B.biUnion ends
  let P := W∪M
  let S := Q∪X
  have pq : Disjoint P S := disjoint_left.mpr (by
    intro v vp vs
    rcases mem_union.mp vp with vw|vm <;> rcases mem_union.mp vs with vq|vx
    · rcases mem_union.mp vq with vl|vc
      · exact (mem_sdiff.mp vl).2 (wh vw)
      · exact (mem_sdiff.mp (mem_filter.mp vc).1).2 vw
    · obtain ⟨w,wb,ve⟩ := mem_biUnion.mp vx
      exact (rowOut wb (mem_filter.mp ve).1).1 vw
    · obtain ⟨w,wb,rfl⟩ := mem_image.mp vm
      exact (rowOut wb (prop w wb).1).2 vq
    · obtain ⟨w,wb,rfl⟩ := mem_image.mp vm
      obtain ⟨u,ub,ve⟩ := mem_biUnion.mp vx
      have eq := own wb ub (prop w wb).1 (mem_filter.mp ve).1
      subst u
      exact (mem_filter.mp ve).2.ne rfl)
  apply (not_lt_of_ge (PinnedColor34.complete G pq q ?_ ?_ ?_)) fail
  · intro v vn _ ns
    by_contra! small
    have ve : v∈twos G := mem_sdiff.mpr ⟨vn,fun vm => (not_lt_of_ge (mem_filter.mp vm).2) small⟩
    exact ns (mem_union_left _ (mem_union_left _ ve))
  · have endS (w : V) (wb : w∈B) : ends w⊆S := fun v ve => mem_union_right _ (mem_biUnion.mpr ⟨w,wb,ve⟩)
    intro v vp
    rcases mem_union.mp vp with vw|vm
    · by_cases wb : v∈B
      · have inc : ends v⊆S.filter (G.Adj v) := fun i im => mem_filter.mpr ⟨endS v wb im,(mem_filter.mp (mem_filter.mp im).1).2⟩
        exact (prop v wb).2.trans (card_le_card inc)
      · exact (show 2≤nbr G v Q from Nat.le_of_not_gt (fun small => wb (mem_filter.mpr ⟨vw,small⟩))).trans (Repair.nbr_mono G v subset_union_left)
    · obtain ⟨w,wb,rfl⟩ := mem_image.mp vm
      have inc : ends w⊆S.filter (G.Adj (mid w)) := fun i im => mem_filter.mpr ⟨endS w wb im,(mem_filter.mp im).2⟩
      exact (prop w wb).2.trans (card_le_card inc)
  · intro v vs
    rcases mem_union.mp vs with vq|vx
    · exact (base v vq).trans (Repair.nbr_mono G v subset_union_left)
    · obtain ⟨w,wb,ve⟩ := mem_biUnion.mp vx
      have vw := (mem_filter.mp (mem_filter.mp ve).1).2.symm
      have vm := (mem_filter.mp ve).2.symm
      have ne := (mem_filter.mp (prop w wb).1).2.ne
      exact PinnedColor34.two G ne vw vm (mem_union_left M (mem_filter.mp wb).1) (mem_union_right W (mem_image.mpr ⟨w,wb,rfl⟩))

end Graffiti384b.ForkGuard34
#print axioms Graffiti384b.ForkGuard34.matching
