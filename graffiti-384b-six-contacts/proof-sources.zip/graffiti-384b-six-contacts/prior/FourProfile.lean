import DenseFour
namespace Graffiti384b.Four29
open Finset SimpleGraph Donor LowSample
open private LowSample.two_degree from LowSample384b
open private Remaining29.account from Remaining29
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def roots (e f : V) := G.neighborFinset e ∪ G.neighborFinset f
def pool (e f : V) := high G \ roots G e f

/-- The disjoint neighborhoods of the two ears use four high anchors.
Its complement among all high vertices supports the fixed-omission sample. -/
structure Data (e f : V) : Prop where
  earSet : twos G={e,f}
  highRoots : roots G e f⊆high G
  rootsSize : (roots G e f).card=4
  poolSize : (pool G e f).card=23
  scoreInj : Set.InjOn (trianglesAt G) (high G : Set V)
  rich : ∀v∈high G,2≤trianglesAt G v
  trial : Pool G (pool G e f) {e,f}

theorem data_of_failure (t : (types G).card=29) (h : (high G).card=27)
    (q : (nonleaves G).card=29) (bad : bound G<gamma G)
    {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ne : e≠f) :
    Data G e f := by
  classical
  obtain ⟨_,highN,disj,_⟩ := Shared29.residual_distinct G t q.ge bad
  have ear {x : V} (d : G.degree x=2) : x∈twos G := by simp [twos,nonleaves,high,d]
  have sub : ({e,f}:Finset V)⊆twos G := insert_subset (ear de) (singleton_subset_iff.mpr (ear df))
  have ec := Remaining29.account G
  have eset := eq_of_subset_of_card_le sub (by rw [card_pair ne]; omega)
  have wh : roots G e f⊆high G := union_subset (highN e (ear de)) (highN f (ear df))
  have size : (roots G e f).card=4 := by
    rw [roots,card_union_of_disjoint (disj e (ear de) f (ear df) ne),card_neighborFinset_eq_degree,
      card_neighborFinset_eq_degree,de,df]
  have xs : (pool G e f).card=23 := by rw [pool,card_sdiff wh,h,size]
  have xh : pool G e f⊆high G := sdiff_subset
  obtain ⟨inj,rich,_,_⟩ := Repair.maximal_diversity G (by omega)
  have ns (z : V) (ze : z∈({e,f}:Finset V)) : G.neighborFinset z⊆roots G e f := by
    rcases mem_insert.mp ze with rfl|zf
    · exact subset_union_left
    · rw [mem_singleton.mp zf]; exact subset_union_right
  refine ⟨eset.symm,wh,size,xs,inj,rich,inj.mono xh,fun _ vm => rich _ (xh vm),
    disjoint_left.mpr (fun _ ze zx => (mem_sdiff.mp (sub ze)).2 (xh zx)),
    fun z ze _ vx zv => (mem_sdiff.mp vx).2 (ns z ze ((G.mem_neighborFinset ..).mpr zv)),?_,
    fun _ ze => (LowSample.two_degree G (sub ze)).ge⟩
  intro z ze u ue zu
  exact (mem_sdiff.mp (sub ue)).2 (wh (ns z ze ((G.mem_neighborFinset ..).mpr zu)))

/-- Graph-level large-exposure result. External neighbors may be anchors
or vertices of smaller degree. -/
theorem dense_disjoint (t : (types G).card=29) (h : (high G).card=27)
    (q : (nonleaves G).card=29) {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ne : e≠f)
    (hits : let X := pool G e f; 15≤(exposed G X).card ∨
      (14≤(exposed G X).card ∧ 7≤(twice G X).card) ∨ (13≤(exposed G X).card ∧ 11≤(twice G X).card)) :
    gamma G≤bound G := by
  apply Nat.le_of_not_gt
  intro bad
  have data := data_of_failure G t h q bad de df ne
  have win := dense_pool G data.trial data.poolSize (card_pair ne) hits
  exact (not_lt_of_ge (show gamma G≤bound G by simpa only [bound,t] using win)) bad

end Graffiti384b.Four29
#print axioms Graffiti384b.Four29.data_of_failure
#print axioms Graffiti384b.Four29.dense_disjoint
