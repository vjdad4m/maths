import ForkGuard34_384b

namespace Graffiti384b.ForkGuard34
open Finset SimpleGraph LowSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A four-clique through an unsupported anchor with a matching exterior
neighborhood is contained entirely among the anchors. -/
theorem inside {W K : Finset V} {w : V} (ww : w∈W)
    (blind : ∀ v∈candidates G W,¬G.Adj w v)
    (small : ∀ v∈row G W w,nbr G v (row G W w)≤1)
    (cl : G.IsNClique 4 K) (wk : w∈K) : K⊆W := by
  have highK (v : V) (vk : v∈K) : v∈high G := by
    have inc : K.erase v⊆G.neighborFinset v := fun j jm => (G.mem_neighborFinset _ _).mpr (cl.1 vk (mem_erase.mp jm).2 (mem_erase.mp jm).1.symm)
    have le := card_le_card inc
    rw [card_erase_of_mem vk,cl.2,card_neighborFinset_eq_degree] at le
    exact mem_filter.mpr ⟨mem_univ _,le⟩
  intro v vk
  by_contra out
  have wv : w≠v := fun eq => out (eq ▸ ww)
  have edge := cl.1 wk vk wv
  have vr : v∈row G W w := mem_filter.mpr ⟨mem_sdiff.mpr ⟨highK v vk,out⟩,edge⟩
  have only {j : V} (jk : j∈K) (jw : j≠w) : j∉W := by
    intro insideW
    have vj : v≠j := fun eq => out (eq ▸ insideW)
    have two := PinnedColor34.two G jw.symm edge.symm (cl.1 vk jk vj) ww insideW
    exact blind v (mem_filter.mpr ⟨mem_sdiff.mpr ⟨highK v vk,out⟩,two⟩) edge
  let T := (K.erase w).erase v
  have sz : T.card=2 := by
    rw [show T=(K.erase w).erase v from rfl,card_erase_of_mem (mem_erase.mpr ⟨wv.symm,vk⟩),card_erase_of_mem wk,cl.2]
  have inc : T⊆(row G W w).filter (G.Adj v) := by
    intro i im
    obtain ⟨iv,iw'⟩ := mem_erase.mp im
    obtain ⟨iw,ik⟩ := mem_erase.mp iw'
    exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_sdiff.mpr ⟨highK i ik,only ik iw⟩,cl.1 wk ik iw.symm⟩,cl.1 vk ik iv.symm⟩
  have two : 2≤nbr G v (row G W w) := sz ▸ card_le_card inc
  have lim := small v vr
  omega

end Graffiti384b.ForkGuard34
#print axioms Graffiti384b.ForkGuard34.inside
