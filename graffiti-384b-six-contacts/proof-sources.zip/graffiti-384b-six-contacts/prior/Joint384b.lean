import Boundary384b
import JointRank384b

namespace Graffiti384b.Joint
open Finset SimpleGraph LowSample JointRank JointSample
open private LowSample.anchors LowSample.weight from LowSample384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

private def floorDegree (i : ℕ) := if i<1 then 3 else if i<4 then 4 else if i<8 then 5 else
  if i<13 then 6 else if i<19 then 7 else if i<26 then 8 else if i<34 then 9 else 10
private def baseLoss := ∑ i ∈ range 35, FiniteRange.badCount 35 13 (floorDegree i)
private def ordinary := income 35 13 2
private def low := min (income 35 13 0) (income 35 13 1)
private def pairCredit := rebate 35 13 9 + rebate 35 13 10

set_option maxRecDepth 16384 in
private theorem numbers :
    (∀ i : Fin 35, 1 ≤ floorDegree i ∧ floorDegree i < 35) ∧
    (∀ i : Fin 35, ∀ j : Fin 10, 3 ≤ j.val → j.val < floorDegree i → j.val.choose 2 ≤ i.val+2) ∧
    (∀ i j : Fin 35, i ≠ j → pairCredit ≤ rebate 35 13 (floorDegree i) + rebate 35 13 (floorDegree j)) ∧
    (∀ d : Fin 3, ordinary ≤ income 35 13 d) ∧ (∀ d : Fin 2, low ≤ income 35 13 d) ∧
    (6*(18*((35:ℕ).choose 13)+baseLoss) < 6*22*((35:ℕ).choose 13) + low + ordinary) ∧
    (6*(18*((35:ℕ).choose 13)+baseLoss) < 6*22*((35:ℕ).choose 13) + 2*ordinary + 6*pairCredit) := by
  unfold baseLoss pairCredit ordinary low income rebate FiniteRange.badCount LowSample.weight
  simp only [Nat.choose_eq_fast_choose]
  decide

omit [Fintype V] in
private theorem pair_le (s : Finset V) {x y : V} (xs : x ∈ s) (ys : y ∈ s) (ne : x ≠ y) (cost : V → ℕ) :
    cost x + cost y ≤ ∑ z ∈ s, cost z := by
  rw [← sum_pair ne]
  exact sum_le_sum_of_subset_of_nonneg (insert_subset xs (singleton_subset_iff.mpr ys)) (fun _ _ _ => Nat.zero_le _)

/-- Two degree-two vertices already rule out the last high-diversity row.
The argument also covers graphs before the leaf and ear normalization. -/
theorem exclude_exception (t37 : (types G).card = 37) (h35 : (high G).card = 35)
    (q37 : 37 ≤ (nonleaves G).card)
    (unsat : ∀ v, G.degree v ∈ Boundary.levels → trianglesAt G v < (G.degree v).choose 2) :
    gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨inj,highScore,_,_⟩ := Repair.maximal_diversity G (by omega)
  let r := rank (high G) (trianglesAt G)
  let d (v : V) := floorDegree (r v)
  have rr := rank_range (high G) (trianglesAt G) inj
  have valid {v : V} (hv : v ∈ high G) : r v < 35 := by
    have mem := mem_image_of_mem (rank (high G) (trianglesAt G)) hv
    rw [rr,h35] at mem
    exact mem_range.mp mem
  obtain ⟨limits,rankBound,pairBound,weightBound,lowBound,lowWin,pairWin⟩ := numbers
  have certDeg (v : V) (hv : v ∈ high G) : 1 ≤ d v ∧ d v ≤ G.degree v ∧ d v < (high G).card := by
    have lim := limits ⟨r v,valid hv⟩
    change 1 ≤ d v ∧ d v < 35 at lim
    refine ⟨lim.1,?_,h35 ▸ lim.2⟩
    apply Nat.le_of_not_gt
    intro small
    have maxD : d v ≤ 10 := by simp [d,floorDegree]; split_ifs <;> omega
    have hi : G.degree v < 10 := by omega
    have lo := (mem_filter.mp hv).2
    have level : G.degree v ∈ Boundary.levels := mem_Icc.mpr ⟨lo,by omega⟩
    have cap := unsat v level
    have z := rankBound ⟨r v,valid hv⟩ ⟨G.degree v,hi⟩ lo small
    change (G.degree v).choose 2 ≤ r v+2 at z
    have minScore := rank_lower (high G) (trianglesAt G) inj 2 highScore hv
    change 2+r v ≤ trianglesAt G v at minScore
    omega
  have loss : (∑ v ∈ high G, FiniteRange.badCount 35 13 (d v)) = baseLoss := by
    have eq := sum_by_rank (high G) (trianglesAt G) inj (fun i => FiniteRange.badCount 35 13 (floorDegree i))
    rwa [h35] at eq
  have obstruction (ex : Finset V) (sub : ex ⊆ high G) (cross : ∀ v ∈ ex, ∃ w ∉ high G, G.Adj v w) :
      6*22*((35:ℕ).choose 13) + (∑ v ∈ twos G, income 35 13 (anchorCount G v)) +
        6*(∑ v ∈ ex, rebate 35 13 (d v)) ≤ 6*(18*((35:ℕ).choose 13)+baseLoss) := by
    have obs := JointSample.obstruction G 13 (by decide) d ex sub cross certDeg fail
    dsimp only at obs
    rw [h35,t37,loss] at obs
    exact obs
  have sub : high G ⊆ nonleaves G := by
    intro v hv
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count : (twos G).card+(high G).card = (nonleaves G).card := card_sdiff_add_card_eq_card sub
  obtain ⟨x,xt,y,yt,xy⟩ := one_lt_card.mp (show 1 < (twos G).card by omega)
  have ax := at_most_two G xt
  have ay := at_most_two G yt
  let I (v : V) := income 35 13 (anchorCount G v)
  have minX : ordinary ≤ I x := weightBound ⟨anchorCount G x,by omega⟩
  have minY : ordinary ≤ I y := weightBound ⟨anchorCount G y,by omega⟩
  have incomes := pair_le (twos G) xt yt xy I
  by_cases few : anchorCount G x < 2
  · have gain : low ≤ I x := lowBound ⟨_,few⟩
    have bound := obstruction ∅ (empty_subset _) (by simp)
    simp only [sum_empty,Nat.mul_zero,Nat.add_zero] at bound
    change 6*22*((35:ℕ).choose 13) + (∑ v ∈ twos G, I v) ≤ _ at bound
    omega
  · obtain ⟨a,ha,b,hb,ab⟩ := one_lt_card.mp (show 1 < (LowSample.anchors G x).card by change 1 < anchorCount G x; omega)
    have sa := (mem_filter.mp ha).1
    have sb := (mem_filter.mp hb).1
    have bs := obstruction {a,b} (insert_subset sa (singleton_subset_iff.mpr sb)) (by
      intro z hz
      refine ⟨x,(mem_sdiff.mp xt).2,?_⟩
      rcases mem_insert.mp hz with eq | hz
      · exact eq ▸ (mem_filter.mp ha).2.symm
      · exact mem_singleton.mp hz ▸ (mem_filter.mp hb).2.symm)
    have distinct : r a ≠ r b := fun eq => ab (rank_inj (high G) (trianglesAt G) inj sa sb eq)
    have credit := pairBound ⟨r a,valid sa⟩ ⟨r b,valid sb⟩ (fun eq => distinct (congrArg Fin.val eq))
    change pairCredit ≤ rebate 35 13 (d a) + rebate 35 13 (d b) at credit
    rw [sum_pair ab] at bs
    change 6*22*((35:ℕ).choose 13) + (∑ v ∈ twos G, I v) + 6*(rebate 35 13 (d a)+rebate 35 13 (d b)) ≤ _ at bs
    omega

theorem nonleaf_cap (hc : G.Connected) (hn : 2 < Fintype.card V) (fail : bound G < gamma G) :
    (nonleaves G).card ≤ 36 := by
  obtain ⟨_,_,_,_,_,_,hi,_⟩ := Boundary.bounded_failure G hc hn fail
  by_contra! q
  by_cases mem : (types G).card ∈ Boundary.inputs
  · letI : Nonempty V := hc.nonempty
    obtain ⟨p,ch⟩ := CliqueChoice.choose_from G (Boundary.screen (types G).card) (by
      intro d hd
      unfold Boundary.screen at hd
      split_ifs at hd
      · simp [CliqueChoice.degrees] at hd; omega
      · exact (mem_Icc.mp hd).1)
    obtain ⟨t,offset,empty⟩ := Boundary.top_profile G hc fail mem (by unfold Boundary.quota; rw [if_neg (by omega)]; omega) ch
    apply (not_le_of_gt fail) (exclude_exception G t (by omega) (by omega) ?_)
    intro v level
    apply Nat.lt_of_le_of_ne (Repair.triangles_le_choose G v)
    intro sat
    have tested : G.degree v ∈ Boundary.screen (types G).card := by simpa [Boundary.screen,t] using level
    have h := ch.covers v tested sat
    rw [empty] at h
    exact not_mem_empty _ h
  · by_cases many : 14 ≤ (types G).card
    · have row := (nonleaf_profile G fail many (by omega)).1
      have rows : ∀ t : Fin 38, ∀ e : Fin 3, t.val ∉ Boundary.inputs → (LowSample.row t e).1 ≤ 36 := by decide
      have lim := type_bound G
      exact (not_le_of_gt q) (row.trans (rows ⟨(types G).card,by omega⟩ ⟨(types G).card-(high G).card,by omega⟩ mem))
    · have h := nonleaf_bound G
      unfold bound at fail
      omega


theorem exact_of_many_nonleaves (hc : G.Connected) (hn : 2 < Fintype.card V) (many : 37 ≤ (nonleaves G).card) :
    gamma G ≤ bound G := by
  by_contra! fail
  have := nonleaf_cap G hc hn fail
  omega

theorem bounded_failure (hc : G.Connected) (hn : 2 < Fintype.card V) (fail : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ r.card ≤ 37 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V)) = types G ∧ 7 ≤ (types G).card ∧ (types G).card ≤ 37 ∧
      bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨_,_,_,_,_,lo,hi,_⟩ := Boundary.bounded_failure G hc hn fail
  obtain ⟨r,_,cap,ord,conn,same,bad⟩ := Prune.prune_failure G hc hn fail
  refine ⟨r,ord,?_,conn,same,lo,hi,bad⟩
  have := nonleaf_cap G hc hn fail
  omega

theorem all_distinct_induced (hc : G.Connected) (hn : 2 < Fintype.card V)
    (fail : bound G < gamma G) (t37 : (types G).card = 37) :
    ∃ r : Finset V, r.card = 37 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V)) = types G ∧ Function.Injective (trianglesAt (G.induce (r : Set V))) ∧
      bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨r,_,cap,conn,same,_,_,bad⟩ := bounded_failure G hc hn fail
  let J := G.induce (r : Set V)
  have rank : (types J).card ≤ r.card := by
    simpa [types] using (card_image_le (s := (univ : Finset r)) (f := trianglesAt J))
  have size : (types J).card = 37 := by change (types (G.induce (r : Set V))).card = 37; rw [same,t37]
  have card : r.card = 37 := by omega
  have inj := card_image_iff.mp (show ((univ : Finset r).image (trianglesAt J)).card = univ.card by
    change (types J).card = _; rw [card_univ]; exact size.trans (card.symm.trans (Fintype.card_coe r).symm))
  exact ⟨r,card,conn,same,fun _ _ eq => inj (mem_univ _) (mem_univ _) eq,bad⟩

theorem minimum_order (res : Minimal.Residual G) : Fintype.card V ≤ 37 := by
  obtain ⟨⟨hn,_⟩,hc,fail,_,_,_,_,_,least⟩ := res
  obtain ⟨r,ord,cap,conn,_,_,_,bad⟩ := bounded_failure G hc hn fail
  exact (least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord,conn,bad⟩).trans cap

end Graffiti384b.Joint
#print axioms Graffiti384b.Joint.exclude_exception
#print axioms Graffiti384b.Joint.bounded_failure
#print axioms Graffiti384b.Joint.minimum_order
#print axioms Graffiti384b.Joint.exact_of_many_nonleaves
#print axioms Graffiti384b.Joint.all_distinct_induced

namespace Graffiti384b.Joint
open Finset SimpleGraph JointSample LowSample
/-- Six times the total conservative omission score over the samples of the
checked eleven-vertex equality graph. Division by six and by C(9,b) gives
the average used in the local loss test. -/
private def witnessTotal (b : ℕ) :=
  let G := AllPairsExample.graph
  6*(9-b)*(9:ℕ).choose b + (∑ v ∈ twos G, income 9 b (anchorCount G v)) -
    6*(∑ v ∈ high G, localLoss 9 b (G.degree v) (nbr G v (high G)ᶜ))

set_option maxRecDepth 32768 in
set_option maxHeartbeats 3000000 in
theorem witness_ceiling :
    gamma AllPairsExample.graph = 5 ∧ bound AllPairsExample.graph = 5 ∧
    (high AllPairsExample.graph).card = 9 ∧ (types AllPairsExample.graph).card = 11 ∧
    (∀ b : Fin 10, 2 ≤ b.val → 84 * witnessTotal b ≤ 6 * 377 * (9:ℕ).choose b) ∧
    84 * witnessTotal 3 = 6 * 377 * (9:ℕ).choose 3 := by
  refine ⟨AllPairsExample.sharp.1,AllPairsExample.sharp.2,?_,?_,?_,?_⟩ <;> decide

end Graffiti384b.Joint
#print axioms Graffiti384b.Joint.witness_ceiling
