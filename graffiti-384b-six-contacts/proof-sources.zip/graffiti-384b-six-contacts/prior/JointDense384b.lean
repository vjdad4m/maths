import JointRank384b

namespace Graffiti384b.JointDense
open Finset SimpleGraph
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A neighbor joined to all the other neighbors has at least as many triangles
as the center. Swap the two vertices inside the closed neighborhood. -/
theorem score_of_dominating_neighbor {v w : V} (vw : G.Adj v w)
    (all : ∀ x, G.Adj v x → x ≠ w → G.Adj w x) : trianglesAt G v ≤ trianglesAt G w := by
  let s := (Equiv.swap v w).toEmbedding
  have mapped (x : V) (hx : G.Adj v x) (ne : x ≠ w) : s x = x :=
    Equiv.swap_apply_of_ne_of_ne hx.ne.symm ne
  have sw : s w = v := Equiv.swap_apply_right _ _
  have inc : (Repair.linkEdges G v).image (Finset.map s) ⊆ Repair.linkEdges G w := by
    intro q hq
    obtain ⟨p,hp,rfl⟩ := mem_image.mp hq
    obtain ⟨sub,size,cl⟩ := Repair.edge_info G hp
    have adj {x} (xp : x ∈ p) : G.Adj v x := (G.mem_neighborFinset _ _).mp (sub xp)
    refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨?_,by rw [card_map,size]⟩,?_⟩
    · intro y hy
      obtain ⟨x,hx,rfl⟩ := mem_map.mp hy
      apply (G.mem_neighborFinset _ _).mpr
      by_cases xw : x=w
      · simpa only [xw,sw] using vw.symm
      · rw [mapped x (adj hx) xw]
        exact all x (adj hx) xw
    · intro a ha b hb ne
      obtain ⟨x,hx,rfl⟩ := mem_map.mp ha
      obtain ⟨y,hy,rfl⟩ := mem_map.mp hb
      have xy : x ≠ y := fun eq => ne (congrArg s eq)
      by_cases xw : x=w
      · have yw : y ≠ w := fun eq => xy (xw.trans eq.symm)
        rw [xw,sw,mapped y (adj hy) yw]
        exact adj hy
      · by_cases yw : y=w
        · rw [yw,sw,mapped x (adj hx) xw]
          exact (adj hx).symm
        · rw [mapped x (adj hx) xw,mapped y (adj hy) yw]
          exact cl _ hx _ hy xy
  have h := card_le_card inc
  rwa [card_image_of_injective _ (Finset.map_injective s)] at h

/-- At most twice the neighborhood edge deficit can be incident to its missing
edges. Every other neighbor has triangle score at least that of the center. -/
theorem dense_neighbor_bound (v : V) :
    G.degree v ≤ ((G.neighborFinset v).filter (fun w => trianglesAt G v ≤ trianglesAt G w)).card +
      2*((G.degree v).choose 2 - trianglesAt G v) := by
  let N := G.neighborFinset v
  let missing := N.powersetCard 2 \ Repair.linkEdges G v
  let U := missing.biUnion id
  have size : missing.card = (G.degree v).choose 2 - trianglesAt G v := by
    have sub : Repair.linkEdges G v ⊆ N.powersetCard 2 := filter_subset _ _
    change (N.powersetCard 2 \ Repair.linkEdges G v).card = _
    rw [card_sdiff sub,card_powersetCard]
    rfl
  have pairs : ∀ p ∈ missing, p.card=2 := fun p hp => (mem_powersetCard.mp (mem_sdiff.mp hp).1).2
  have small : U.card ≤ 2*missing.card := calc
    U.card ≤ ∑ p ∈ missing, p.card := card_biUnion_le
    _ = _ := by rw [sum_congr rfl pairs]; simp [Nat.mul_comm]
  let ok := N.filter (fun w => trianglesAt G v ≤ trianglesAt G w)
  have cover : N ⊆ ok ∪ U := by
    intro w hw
    by_cases wu : w ∈ U
    · exact mem_union_right _ wu
    apply mem_union_left
    apply mem_filter.mpr
    refine ⟨hw,score_of_dominating_neighbor G ((G.mem_neighborFinset _ _).mp hw) ?_⟩
    intro x vx xw
    apply Classical.byContradiction
    intro absent
    let e : Finset V := {w,x}
    have first : e ∈ N.powersetCard 2 := mem_powersetCard.mpr
      ⟨insert_subset hw (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vx)),card_pair xw.symm⟩
    have no : e ∉ Repair.linkEdges G v := fun yes => absent ((Repair.edge_info G yes).2.2 w
      (mem_insert_self _ _) x (mem_insert_of_mem (mem_singleton_self _)) xw.symm)
    exact wu (mem_biUnion.mpr ⟨e,mem_sdiff.mpr ⟨first,no⟩,mem_insert_self _ _⟩)
  have h := (card_le_card cover).trans (card_union_le ok U)
  rw [size] at small
  change N.card ≤ ok.card + _
  omega

/-- Distinct ambient scores may exceed the induced scores. Only the center's
gap is charged, so an ear contribution can be handled without changing the ranks. -/
theorem ranked_bound (f : V → ℕ) (inj : Function.Injective f)
    (dominates : ∀ w, trianglesAt G w ≤ f w) (v : V) (a : ℕ) (loss : f v ≤ trianglesAt G v+a) :
    G.degree v + JointRank.rank univ f v + 1 ≤ Fintype.card V + a +
      2*((G.degree v).choose 2 - trianglesAt G v) := by
  classical
  let L := univ.filter (fun w => f w < f v)
  let near := L.filter (fun w => f v ≤ f w + a)
  let top := (insert v L)ᶜ
  let ok := (G.neighborFinset v).filter (fun w => trianglesAt G v ≤ trianglesAt G w)
  have sub : ok ⊆ top ∪ near := by
    intro w hw
    obtain ⟨wn,score⟩ := mem_filter.mp hw
    by_cases lt : f w < f v
    · apply mem_union_right
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_univ _,lt⟩,loss.trans (Nat.add_le_add_right (score.trans (dominates w)) _)⟩
    · apply mem_union_left
      apply mem_compl.mpr
      intro mem
      rcases mem_insert.mp mem with rfl | wl
      · exact G.not_mem_neighborFinset_self _ wn
      · exact lt (mem_filter.mp wl).2
  have near_le : near.card ≤ a := by
    have subset : near.image f ⊆ Ico (f v-a) (f v) := by
      intro k hk
      obtain ⟨w,hw,rfl⟩ := mem_image.mp hk
      obtain ⟨wl,low⟩ := mem_filter.mp hw
      have hi := (mem_filter.mp wl).2
      exact mem_Ico.mpr ⟨by omega,hi⟩
    have q := card_le_card subset
    rw [card_image_of_injective _ inj,Nat.card_Ico] at q
    omega
  have vl : v ∉ L := fun hv => (lt_irrefl _) (mem_filter.mp hv).2
  have cnt := card_compl_add_card (insert v L)
  rw [card_insert_of_not_mem vl] at cnt
  have lim := (card_le_card sub).trans (card_union_le top near)
  have d := dense_neighbor_bound G v
  change G.degree v ≤ ok.card + _ at d
  change top.card+(L.card+1) = Fintype.card V at cnt
  change G.degree v + L.card + 1 ≤ _
  omega

end Graffiti384b.JointDense
#print axioms Graffiti384b.JointDense.dense_neighbor_bound
#print axioms Graffiti384b.JointDense.ranked_bound
