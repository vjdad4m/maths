import JointSample384b

namespace Graffiti384b.JointRank
open Finset
variable {V : Type*}

/-- The zero-based rank of a score among a specified set of vertices. -/
def rank (s : Finset V) (score : V → ℕ) (v : V) := (s.filter (fun w => score w < score v)).card

theorem rank_strict (s : Finset V) (score : V → ℕ) {v w : V} (vs : v ∈ s)
    (lt : score v < score w) : rank s score v < rank s score w := by
  apply card_lt_card
  refine Finset.ssubset_iff_subset_ne.mpr ⟨?_,?_⟩
  · intro z hz
    exact mem_filter.mpr ⟨(mem_filter.mp hz).1,lt_trans (mem_filter.mp hz).2 lt⟩
  · intro eq
    have vm : v ∈ s.filter (fun z => score z < score w) := mem_filter.mpr ⟨vs,lt⟩
    rw [← eq] at vm
    exact (lt_irrefl _) (mem_filter.mp vm).2

theorem rank_inj (s : Finset V) (score : V → ℕ) (inj : Set.InjOn score (s : Set V)) :
    Set.InjOn (rank s score) (s : Set V) := by
  intro v vs w ws eq
  apply inj vs ws
  rcases lt_trichotomy (score v) (score w) with lt | same | gt
  · exact False.elim ((rank_strict s score vs lt).ne eq)
  · exact same
  · exact False.elim ((rank_strict s score ws gt).ne eq.symm)

theorem rank_range (s : Finset V) (score : V → ℕ) (inj : Set.InjOn score (s : Set V)) :
    s.image (rank s score) = range s.card := by
  apply eq_of_subset_of_card_le
  · intro j hj
    obtain ⟨v,vs,rfl⟩ := mem_image.mp hj
    apply mem_range.mpr
    apply card_lt_card
    refine Finset.ssubset_iff_subset_ne.mpr ⟨filter_subset _ _,fun eq => ?_⟩
    have vm : v ∈ s.filter (fun z => score z < score v) := eq.symm ▸ vs
    exact (lt_irrefl _) (mem_filter.mp vm).2
  · rw [card_range,card_image_of_injOn (rank_inj s score inj)]

theorem rank_lower (s : Finset V) (score : V → ℕ) (inj : Set.InjOn score (s : Set V))
    (base : ℕ) (lower : ∀ w ∈ s, base ≤ score w) {v : V} (vs : v ∈ s) :
    base + rank s score v ≤ score v := by
  let r := s.filter (fun z => score z < score v)
  have imageIn : r.image (fun z => score z-base) ⊆ range (score v-base) := by
    intro k hk
    obtain ⟨z,zr,rfl⟩ := mem_image.mp hk
    have lo := lower z (mem_filter.mp zr).1
    have lt := (mem_filter.mp zr).2
    apply mem_range.mpr
    omega
  have i : Set.InjOn (fun z => score z-base) (r : Set V) := by
    intro u hu w hw eq
    have us := (mem_filter.mp hu).1
    have ws := (mem_filter.mp hw).1
    change score u - base = score w - base at eq
    apply inj us ws
    have := lower u us
    have := lower w ws
    omega
  have h := card_le_card imageIn
  rw [card_image_of_injOn i,card_range] at h
  change base+r.card ≤ score v
  have := lower v vs
  omega

theorem sum_by_rank (s : Finset V) (score : V → ℕ) (inj : Set.InjOn score (s : Set V)) (cost : ℕ → ℕ) :
    (∑ v ∈ s, cost (rank s score v)) = ∑ j ∈ range s.card, cost j := by
  rw [← rank_range s score inj,sum_image (rank_inj s score inj)]

end Graffiti384b.JointRank
#print axioms Graffiti384b.JointRank.rank_lower
#print axioms Graffiti384b.JointRank.sum_by_rank
