import BoundaryFiber384b

namespace Graffiti384b.JointSample
open Finset SimpleGraph LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.weight LowSample.anchors LowSample.trial LowSample.eligible LowSample.two_degree LowSample.anchor_samples from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def anchorCount (v : V) := (LowSample.anchors G v).card
def income (h b a : ℕ) := LowSample.weight a * (h-a).choose (b-a)
def rebate (h b d : ℕ) := FiniteRange.badCount h b d - (h-d).choose b

theorem at_most_two {v : V} (hv : v ∈ twos G) : anchorCount G v ≤ 2 := by
  have sub : LowSample.anchors G v ⊆ G.neighborFinset v := fun _ hx => (G.mem_neighborFinset _ _).mpr (mem_filter.mp hx).2
  simpa only [anchorCount,card_neighborFinset_eq_degree,LowSample.two_degree G hv] using card_le_card sub

/-- Summation principle for variable upper bounds and guaranteed savings
in the number of deficient samples. -/
theorem aggregate (b : ℕ) (two : 2 ≤ b) (cost credit : V → ℕ)
    (losses : ∀ v ∈ high G, (((high G).powersetCard b).filter (fun k => v ∈ FiniteRange.bad G (high G) k)).card + credit v ≤ cost v)
    (fail : bound G < gamma G) :
    let h := (high G).card
    6*(h-b)*h.choose b + (∑ v ∈ twos G, income h b (anchorCount G v)) + 6*(∑ v ∈ high G, credit v) ≤
      6*((((types G).card+1)/2-1)*h.choose b + ∑ v ∈ high G, cost v) := by
  classical
  let s := high G
  let h := s.card
  let ks := s.powersetCard b
  let fiber (v : V) := (ks.filter (fun k => v ∈ FiniteRange.bad G s k)).card
  let W (v : V) := LowSample.weight (anchorCount G v)
  have mass : (∑ v ∈ twos G, income h b (anchorCount G v)) ≤ ∑ k ∈ ks, ∑ v ∈ LowSample.eligible G k, W v := by
    calc
      _ ≤ ∑ v ∈ twos G, ∑ k ∈ ks, if LowSample.anchors G v ⊆ k then W v else 0 := by
        apply sum_le_sum
        intro v hv
        have cnt := at_most_two G hv
        have q := LowSample.anchor_samples s (LowSample.anchors G v) b (filter_subset _ _)
          (show (LowSample.anchors G v).card ≤ b from cnt.trans two)
        rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.cast_id]
        simpa only [income,W,Nat.mul_comm (LowSample.weight _),anchorCount,h,ks] using Nat.mul_le_mul_left (W v) q
      _ = _ := by rw [sum_comm]; simp [LowSample.eligible,sum_filter]
  change ∀ v ∈ s, fiber v + credit v ≤ cost v at losses
  have sumL := sum_le_sum losses
  rw [sum_add_distrib] at sumL
  have flip : (∑ k ∈ ks, (FiniteRange.bad G s k).card) = ∑ v ∈ s, fiber v := by
    calc
      _ = ∑ k ∈ ks, ∑ v ∈ s, (if v ∈ FiniteRange.bad G s k then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show FiniteRange.bad G s k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
      _ = _ := by rw [sum_comm]; simp [fiber]
  have point (k : Finset V) (hk : k ∈ ks) :
      6*(h-b) + (∑ v ∈ LowSample.eligible G k, W v) ≤ 6*((((types G).card+1)/2-1) + (FiniteRange.bad G s k).card) := by
    obtain ⟨sub,eq⟩ := mem_powersetCard.mp hk
    simpa only [eq] using LowSample.trial G k sub fail
  have tot := sum_le_sum point
  simp only [sum_add_distrib,Nat.mul_add,← mul_sum,sum_const,nsmul_eq_mul,Nat.cast_id] at tot
  have sz : ks.card = h.choose b := card_powersetCard _ _
  rw [sz,flip] at tot
  change 6*(h-b)*h.choose b + (∑ v ∈ twos G, income h b (anchorCount G v)) + 6*(∑ v ∈ s, credit v) ≤ 6*((((types G).card+1)/2-1)*h.choose b +
    ∑ v ∈ s, cost v)
  rw [Nat.mul_comm (6*(h-b)),Nat.mul_left_comm (h.choose b) 6 (h-b),Nat.mul_comm (((types G).card+1)/2-1)]
  omega

/-- The certified degree can vary by vertex. Count each specified boundary
vertex separately, and retain the actual number of anchors of every degree-two vertex. -/
theorem obstruction (b : ℕ) (two : 2 ≤ b) (d : V → ℕ) (exposed : Finset V)
    (sub : exposed ⊆ high G)
    (cross : ∀ v ∈ exposed, ∃ w ∉ high G, G.Adj v w)
    (degree : ∀ v ∈ high G, 1 ≤ d v ∧ d v ≤ G.degree v ∧ d v < (high G).card)
    (fail : bound G < gamma G) :
    let h := (high G).card
    6*(h-b)*h.choose b + (∑ v ∈ twos G, income h b (anchorCount G v)) +
      6*(∑ v ∈ exposed, rebate h b (d v)) ≤
      6*((((types G).card+1)/2-1)*h.choose b + ∑ v ∈ high G, FiniteRange.badCount h b (d v)) := by
  classical
  let s := high G
  let h := s.card
  let ks := s.powersetCard b
  let fiber (v : V) := (ks.filter (fun k => v ∈ FiniteRange.bad G s k)).card
  have losses (v : V) (hv : v ∈ s) :
      fiber v + (if v ∈ exposed then rebate h b (d v) else 0) ≤ FiniteRange.badCount h b (d v) := by
    obtain ⟨pos,le,room⟩ := degree v hv
    have raw := FiniteRange.count_bad G s b (d v) v hv le room
    change fiber v ≤ FiniteRange.badCount h b (d v) at raw
    by_cases ex : v ∈ exposed
    · obtain ⟨w,ws,e⟩ := cross v ex
      have credit := BoundaryFiber.count G s b (d v) hv ws e le pos
      change fiber v ≤ (h-d v).choose b at credit
      rw [if_pos ex,rebate]
      omega
    · simpa [ex] using raw
  have bound := aggregate G b two (fun v => FiniteRange.badCount h b (d v))
    (fun v => if v ∈ exposed then rebate h b (d v) else 0) losses fail
  dsimp only at bound ⊢
  rwa [← sum_filter,filter_mem_eq_inter,inter_eq_right.mpr sub] at bound

end Graffiti384b.JointSample
#print axioms Graffiti384b.JointSample.obstruction

namespace Graffiti384b.JointSample
open Finset SimpleGraph
open private FiniteRange.bad from FiniteRange384b
open private Repair.nbr_add Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Exact deficit for an endpoint with exterior support, valid for an arbitrary
pool and sample size. Two exterior neighbors eliminate its deficit entirely. -/
theorem endpoint_loss (s : Finset V) (b : ℕ) {v : V} (vs : v ∈ s) (ext : 0 < nbr G v sᶜ) :
    ((s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)).card =
      if nbr G v sᶜ = 1 then (s.card - G.degree v).choose b else 0 := by
  let free := (s.erase v) \ (s.filter (G.Adj v))
  have inside : s.filter (G.Adj v) ⊆ s.erase v := by
    intro u hu
    exact mem_erase.mpr ⟨(mem_filter.mp hu).2.ne.symm,(mem_filter.mp hu).1⟩
  have split {k : Finset V} (ks : k ⊆ s) : nbr G v (sᶜ ∪ k) = nbr G v sᶜ + nbr G v k :=
    Repair.nbr_add G v (disjoint_left.mpr (fun _ hc hk => mem_compl.mp hc (ks hk)))
  split_ifs with one
  · have eq : (s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k) = free.powersetCard b := by
      ext k
      constructor
      · intro hk
        obtain ⟨sample,miss⟩ := mem_filter.mp hk
        obtain ⟨ks,kb⟩ := mem_powersetCard.mp sample
        obtain ⟨vo,lt⟩ := mem_filter.mp miss
        rw [split ks,one] at lt
        have zero : k.filter (G.Adj v) = ∅ := card_eq_zero.mp (show nbr G v k = 0 by omega)
        refine mem_powersetCard.mpr ⟨?_,kb⟩
        intro u uk
        refine mem_sdiff.mpr ⟨mem_erase.mpr ⟨fun eq => (mem_sdiff.mp vo).2 (eq ▸ uk),ks uk⟩,?_⟩
        intro a
        have f : u ∈ k.filter (G.Adj v) := mem_filter.mpr ⟨uk,(mem_filter.mp a).2⟩
        rw [zero] at f
        exact not_mem_empty _ f
      · intro hk
        obtain ⟨kf,sz⟩ := mem_powersetCard.mp hk
        have ks : k ⊆ s := (kf.trans sdiff_subset).trans (erase_subset _ _)
        have zero : k.filter (G.Adj v) = ∅ := filter_eq_empty_iff.mpr (fun u uk adj =>
          (mem_sdiff.mp (kf uk)).2 (mem_filter.mpr ⟨ks uk,adj⟩))
        have nv : v ∉ k := fun v₀ => (mem_erase.mp (mem_sdiff.mp (kf v₀)).1).1 rfl
        refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨ks,sz⟩,mem_filter.mpr ⟨mem_sdiff.mpr ⟨vs,nv⟩,?_⟩⟩
        rw [split ks,one,show nbr G v k=0 from card_eq_zero.mpr zero]
        decide
    rw [eq,card_powersetCard]
    have sz : free.card = s.card - G.degree v := by
      dsimp only [free]
      rw [card_sdiff inside,card_erase_of_mem vs]
      change s.card-1-nbr G v s = s.card-G.degree v
      have total := Repair.full_nbr G v s
      rw [one] at total
      omega
    rw [sz]
  · apply card_eq_zero.mpr
    apply filter_eq_empty_iff.mpr
    intro k hk miss
    have lt := (mem_filter.mp miss).2
    rw [split (mem_powersetCard.mp hk).1] at lt
    omega

end Graffiti384b.JointSample
#print axioms Graffiti384b.JointSample.endpoint_loss

namespace Graffiti384b.JointSample
open Finset SimpleGraph LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

def localLoss (h b d exterior : ℕ) := if exterior=0 then FiniteRange.badCount h b d
  else if exterior=1 then (h-d).choose b else 0

/-- A graph-wide sufficient test with no degree cap and no restriction on
the number or placement of boundary endpoints. -/
theorem exact_of_local_losses (b : ℕ) (two : 2 ≤ b)
    (test : let h := (high G).card
      6*((((types G).card+1)/2-1)*h.choose b +
        ∑ v ∈ high G, localLoss h b (G.degree v) (nbr G v (high G)ᶜ)) <
      6*(h-b)*h.choose b + ∑ v ∈ twos G, income h b (anchorCount G v)) :
    gamma G ≤ bound G := by
  by_contra! fail
  let s := high G
  let h := s.card
  let cost (v : V) := localLoss h b (G.degree v) (nbr G v sᶜ)
  have bound := aggregate G b two cost (fun _ => 0) (by
    intro v hv
    rw [Nat.add_zero]
    change ((s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)).card ≤ localLoss h b (G.degree v) (nbr G v sᶜ)
    by_cases z : nbr G v sᶜ = 0
    · rw [localLoss,if_pos z]
      have total := Repair.full_nbr G v s
      rw [z,Nat.add_zero] at total
      have sub : s.filter (G.Adj v) ⊆ s.erase v := fun w hw =>
        mem_erase.mpr ⟨(mem_filter.mp hw).2.ne.symm,(mem_filter.mp hw).1⟩
      have limit := card_le_card sub
      rw [card_erase_of_mem hv] at limit
      change nbr G v s ≤ h-1 at limit
      have pos : 0 < h := card_pos.mpr ⟨v,hv⟩
      exact FiniteRange.count_bad G s b (G.degree v) v hv le_rfl (by change G.degree v < h; omega)
    · rw [localLoss,if_neg z,endpoint_loss G s b hv (Nat.pos_of_ne_zero z)]
  ) fail
  simp only [sum_const_zero,Nat.mul_zero,Nat.add_zero] at bound
  exact (not_lt_of_ge bound) test

end Graffiti384b.JointSample
#print axioms Graffiti384b.JointSample.exact_of_local_losses

namespace Graffiti384b.JointSample
open Finset SimpleGraph
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private Repair.nbr_add Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- For positive sample sizes the loss formula also counts interior vertices
exactly. This gives the complete three-case formula for any retained pool. -/
theorem localLoss_exact (s : Finset V) (b : ℕ) (pos : 1 ≤ b) {v : V} (vs : v ∈ s) :
    ((s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)).card =
      localLoss s.card b (G.degree v) (nbr G v sᶜ) := by
  by_cases ext : nbr G v sᶜ = 0
  · rw [localLoss,if_pos ext]
    let n := s.filter (G.Adj v)
    let free := s.erase v \ n
    let zero := free.powersetCard b
    let one (w : V) := (free.powersetCard (b-1)).image (insert w)
    let opts := (s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)
    have deg : n.card = G.degree v := by simpa only [ext,Nat.add_zero] using Repair.full_nbr G v s
    have inside : n ⊆ s.erase v := fun _ hw => mem_erase.mpr ⟨(mem_filter.mp hw).2.ne.symm,(mem_filter.mp hw).1⟩
    have room := card_le_card inside
    rw [deg,card_erase_of_mem vs] at room
    have hp := card_pos.mpr ⟨v,vs⟩
    apply Nat.le_antisymm (FiniteRange.count_bad G s b (G.degree v) v vs le_rfl (by omega))
    have F : free.card = s.card-1-G.degree v := by rw [show free = _ from rfl,card_sdiff inside,card_erase_of_mem vs,deg]
    have disj {c : Finset V} (cf : c ⊆ free) {w : V} (wn : w ∈ n) : w ∉ c :=
      fun wc => (mem_sdiff.mp (cf wc)).2 wn
    have clear {c : Finset V} (cf : c ⊆ free) : c.filter (G.Adj v) = ∅ := by
      apply filter_eq_empty_iff.mpr
      intro u uc adj
      have h := mem_sdiff.mp (cf uc)
      exact h.2 (mem_filter.mpr ⟨(mem_erase.mp h.1).2,adj⟩)
    have pack {k : Finset V} (ks : k ⊆ s.erase v) (sz : k.card=b) (few : nbr G v k ≤ 1) : k ∈ opts := by
      have ss := ks.trans (erase_subset _ _)
      refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨ss,sz⟩,mem_filter.mpr ⟨mem_sdiff.mpr ⟨vs,
        fun vk => (mem_erase.mp (ks vk)).1 rfl⟩,?_⟩⟩
      rw [Repair.nbr_add G v (disjoint_left.mpr (fun _ u w => mem_compl.mp u (ss w))),ext]
      omega
    have inc : zero ∪ n.biUnion one ⊆ opts := by
      intro k hk
      rcases mem_union.mp hk with z | e
      · obtain ⟨kf,sz⟩ := mem_powersetCard.mp z
        exact pack (kf.trans sdiff_subset) sz (by rw [nbr,clear kf,card_empty]; decide)
      · obtain ⟨w,wn,wo⟩ := mem_biUnion.mp e
        obtain ⟨c,cc,rfl⟩ := mem_image.mp wo
        obtain ⟨cf,sz⟩ := mem_powersetCard.mp cc
        apply pack (insert_subset (inside wn) (cf.trans sdiff_subset))
        · rw [card_insert_of_not_mem (disj cf wn),sz]; omega
        · simp [nbr,filter_insert,clear cf,(mem_filter.mp wn).2]
    have separate : Disjoint zero (n.biUnion one) := by
      apply disjoint_left.mpr
      intro k kz ko
      obtain ⟨w,wn,wo⟩ := mem_biUnion.mp ko
      obtain ⟨c,_,eq⟩ := mem_image.mp wo
      exact disj (mem_powersetCard.mp kz).1 wn (eq ▸ mem_insert_self _ _)
    have each {w : V} (wn : w ∈ n) : (one w).card = free.card.choose (b-1) := by
      dsimp [one]
      rw [card_image_of_injOn ?_,card_powersetCard]
      intro c hc e he eq
      have h := congrArg (fun u : Finset V => u.erase w) eq
      simpa only [erase_insert (disj (mem_powersetCard.mp hc).1 wn),erase_insert (disj (mem_powersetCard.mp he).1 wn)] using h
    have distinct : (n : Set V).PairwiseDisjoint one := by
      intro u un w wn ne
      apply disjoint_left.mpr
      intro k ku kw
      obtain ⟨c,cc,eq⟩ := mem_image.mp ku
      obtain ⟨e,ee,eq'⟩ := mem_image.mp kw
      have hit : u ∈ insert w e := eq'.symm ▸ (eq ▸ mem_insert_self _ _ : u ∈ k)
      exact (mem_insert.mp hit).elim ne (disj (mem_powersetCard.mp ee).1 un)
    have bound := card_le_card inc
    rw [card_union_of_disjoint separate,card_biUnion distinct,
      sum_congr rfl (fun w hw => each hw),sum_const,nsmul_eq_mul,Nat.cast_id,
      show zero.card = free.card.choose b from card_powersetCard _ _,F,deg] at bound
    exact bound
  · rw [localLoss,if_neg ext]
    exact endpoint_loss G s b vs (Nat.pos_of_ne_zero ext)

end Graffiti384b.JointSample
#print axioms Graffiti384b.JointSample.localLoss_exact
