import Distinguish35_384b
import Below35_384b
import SmallScores35_384b
import StratumFinish35_384b

namespace Graffiti384b.Least35
open Finset SimpleGraph BlockGeometry TrianglePrune
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Any failure preserves its whole count set on at most 34 vertices or on
an injective 35-vertex induced subgraph with one leaf and counts 0, 1, 2. -/
theorem induced_alternative (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V))=types G ∧ bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) ∧
      (r.card ≤ 34 ∨ (r.card=35 ∧ (types G).card=35 ∧
        Function.Injective (trianglesAt (G.induce (r : Set V))) ∧
        (nonleaves (G.induce (r : Set V))).card=34 ∧ range 3 ⊆ types G)) := by
  by_cases small : (types G).card<35
  · obtain ⟨r,ord,cap,conn,same,fail⟩ := Below35.bounded_failure G small hc hn bad
    exact ⟨r,ord,conn,same,fail,Or.inl cap⟩
  have hi : (types G).card<36 := Nat.lt_of_not_ge (fun big =>
    (not_lt_of_ge (Order36.exact_of_at_least_36_types G hc hn big)) bad)
  have t : (types G).card=35 := by omega
  obtain ⟨r,sz,conn,same,inj,fail⟩ := Order36.all_distinct_induced G hc hn bad t
  let J := G.induce (r : Set V)
  have ord : 2 < Fintype.card r := by rw [Fintype.card_coe,sz]; decide
  have cap := Order36.nonleaf_cap J conn ord fail
  obtain ⟨u,_,size,_,_,pres,_⟩ := Prune.prune_failure J conn ord fail
  have num : (types (J.induce (u : Set (r : Set V)))).card ≤ u.card := by
    simpa [types] using (card_image_le (s := (univ : Finset u)) (f := trianglesAt (J.induce (u : Set (r : Set V)))))
  rw [pres] at num
  have tj : (types J).card=35 := by change (types (G.induce (r : Set V))).card=35; rw [same,t]
  refine ⟨r,by omega,conn,same,fail,Or.inr ⟨sz,t,inj,by change (nonleaves J).card=34; omega,?_⟩⟩
  intro z hz
  apply Classical.byContradiction
  intro absent
  have smallZ : z ≤ 2 := by have := mem_range.mp hz; omega
  exact (not_lt_of_ge (SmallScores35.exact_of_missing G hc hn t (z := z) smallZ absent)) bad

/-- The order-35 branch has a single possible diversity. -/
theorem boundary (res : Minimal.Residual G) (n : Fintype.card V=35) :
    (nonleaves G).card=34 ∧ (types G).card=35 ∧ Function.Injective (trianglesAt G) := by
  obtain ⟨q,lo|t⟩ := Order36.order35_profile G res n
  · exact ((not_lt_of_ge (Finish33.exact33 G lo q.ge)) res.2.2.1).elim
  · have eq : (univ.image (trianglesAt G)).card = (univ : Finset V).card := by
      change (types G).card=_
      rw [card_univ,t,n]
    have inj := card_image_iff.mp eq
    exact ⟨q,t,fun a b e => inj (mem_univ a) (mem_univ b) e⟩

/-- For normalized least failures the small-score witnesses occupy very few
edges. In the 34-high case the score-one vertex is incident to the sole leaf. -/
theorem small_witnesses (res : Minimal.Residual G) (n : Fintype.card V=35) :
    ∃ u v, trianglesAt G u=1 ∧ trianglesAt G v=2 ∧ u≠v ∧
      G.degree u ≤ 3 ∧ G.degree v ≤ 5 ∧
      ((high G).card=34 → G.degree u=3 ∧ G.degree v ≤ 4 ∧
        ∃ l, trianglesAt G l=0 ∧ G.Adj u l) := by
  obtain ⟨q,t,_⟩ := boundary G res n
  have bad := res.2.2.1
  have normal := res.2.2.2.1
  have top : 2 ≤ SmallScores35.top (high G).card := by unfold SmallScores35.top; split_ifs <;> decide
  obtain ⟨u,_,us⟩ := SmallScores35.realized G t q.ge bad 1 (by omega)
  obtain ⟨v,_,vs⟩ := SmallScores35.realized G t q.ge bad 2 top
  have ne : u≠v := fun eq => by rw [eq,vs] at us; contradiction
  obtain ⟨ud,ux⟩ := Minimal.degree_score G normal u (by omega)
  obtain ⟨vd,vx⟩ := Minimal.degree_score G normal v (by omega)
  refine ⟨u,v,us,vs,ne,by omega,by omega,?_⟩
  intro h
  have sub : high G ⊆ nonleaves G := fun z hz => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hz).2; omega⟩
  have eq := eq_of_subset_of_card_le sub (q.trans h.symm).le
  have two : 2 ≤ G.degree u := by
    have raw := Repair.triangles_le_choose G u
    by_contra! small
    have du : G.degree u=0 ∨ G.degree u=1 := by omega
    rcases du with e|e <;> simp [e,us] at raw
  have highU : u ∈ high G := eq ▸ mem_filter.mpr ⟨mem_univ _,two⟩
  have three := (mem_filter.mp highU).2
  obtain ⟨l,hl⟩ := card_pos.mp (show 0 < ((G.neighborFinset u).filter (fun z => trianglesAt G z=0)).card by omega)
  obtain ⟨ul,lz⟩ := mem_filter.mp hl
  have adj := (G.mem_neighborFinset _ _).mp ul
  have no : (G.neighborFinset v).filter (fun z => trianglesAt G z=0) = ∅ := by
    apply filter_eq_empty_iff.mpr
    intro z zv zero
    obtain rfl := normal.1 z l zero lz
    exact ne (normal.2.1 z lz u v adj.symm ((G.mem_neighborFinset _ _).mp zv).symm)
  rw [no,card_empty] at vd
  exact ⟨by omega,by omega,l,lz,adj⟩

/-- On the 34-high branch a second cubic avoids the leaf and carries
score two or three. Without a saturated cubic it must be the score-two witness. -/
theorem second_cubic (res : Minimal.Residual G) (n : Fintype.card V=35) (h : (high G).card=34) :
    ∃ w, G.degree w=3 ∧ nbr G w (high G)ᶜ=0 ∧ (trianglesAt G w=2 ∨ trianglesAt G w=3) := by
  obtain ⟨_,_,inj⟩ := boundary G res n
  obtain ⟨u,_,us,_,_,_,_,caseH⟩ := small_witnesses G res n
  obtain ⟨_,_,l,lz,ul⟩ := caseH h
  have norm := res.2.2.2.1
  have dl : G.degree l ≤ 1 := by
    rw [← card_neighborFinset_eq_degree]
    exact card_le_one.mpr (fun a ha b hb => norm.2.1 l lz a b
      ((G.mem_neighborFinset _ _).mp ha) ((G.mem_neighborFinset _ _).mp hb))
  have low : l ∉ high G := fun mem => by have := (mem_filter.mp mem).2; omega
  have hit : 1 ≤ nbr G u (high G)ᶜ := card_pos.mpr ⟨l,mem_filter.mpr ⟨mem_compl.mpr low,ul⟩⟩
  have ex : ∃ w, G.degree w=3 ∧ nbr G w (high G)ᶜ=0 := by
    by_contra! none
    apply (not_lt_of_ge (Repair.exact_even_high_of_cubic_neighbor G res.2.1 res.1.1 17 (by omega) ?_)) res.2.2.1
    intro z dz
    have := none z dz
    omega
  obtain ⟨w,dw,out⟩ := ex
  have wz : trianglesAt G w ≠ 0 := fun e => by have eq := inj (e.trans lz.symm); subst w; omega
  have wo : trianglesAt G w ≠ 1 := fun e => by have eq := inj (e.trans us.symm); subst w; omega
  have cap := Repair.triangles_le_choose G w
  rw [dw] at cap
  change trianglesAt G w ≤ 3 at cap
  exact ⟨w,dw,out,by omega⟩

/-- The catalogue conditions plus the neighborhood and degree profile alone
suffice for the positive fixed-stratum inequality. -/
theorem exact_degree_seven (t : (types G).card=35) (h : (high G).card=33) (q : (nonleaves G).card=34)
    (unsaturated : ∀ v, G.degree v ∈ Boundary.levels → trianglesAt G v ≠ (G.degree v).choose 2)
    (x : V) (d : G.degree x=7) (miss : (gaps G (G.neighborFinset x)).card ≤ 2) :
    gamma G ≤ bound G := by
  have ch : CliqueChoice.Choice G ∅ Boundary.levels := {
    high_sub := empty_subset _
    levels := by simp
    exact_score := by simp
    unique := by simp
    covers := fun v level eq => False.elim (unsaturated v level eq) }
  exact Stratum35.exact_seven G ch t h q x d miss

end Graffiti384b.Least35
#print axioms Graffiti384b.Least35.boundary
#print axioms Graffiti384b.Least35.small_witnesses
#print axioms Graffiti384b.Least35.exact_degree_seven
#print axioms Graffiti384b.Least35.induced_alternative
#print axioms Graffiti384b.Least35.second_cubic
