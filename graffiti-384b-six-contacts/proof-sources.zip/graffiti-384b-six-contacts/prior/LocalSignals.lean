import TruthWords
namespace Graffiti384b.Four29.LocalTest
open Words
abbrev Label := Fin 9
abbrev Pattern := List Label × List Label

def labels := List.finRange 9
def pairs := (labels.product labels).filter (fun z => z.1<z.2)
def position (i j : Label) := (max i.val j.val).choose 2+min i.val j.val

/-- The seven high labels use 21 independent edge bits. The last two
labels are ears with neighbors {0,1} and {2,3}. -/
def preset (i j : Label) : Bool :=
  decide ((i = 7 ∧ j.val < 2) ∨ (j = 7 ∧ i.val < 2) ∨
    (i = 8 ∧ 2 ≤ j.val ∧ j.val < 4) ∨ (j = 8 ∧ 2 ≤ i.val ∧ i.val < 4))
def edge (i j : Label) : ℕ :=
  if i=j then 0 else if i.val<7 ∧ j.val<7 then column 21 (position i j)
  else if preset i j then ones 21 else 0

/-- A signal for each unordered pair of other labels. -/
def triangles (i : Label) := pairs.map fun (a,b) => edge i a &&& edge i b &&& edge a b
def score (i : Label) := binary (triangles i)
def anchors : List Label := [0,1,2,3]
def anchorPairs := (anchors.product anchors).filter (fun z => z.1<z.2)
def rich := all (ones 21) (anchors.map (fun i => any (score i).tail))
def distinct := all (ones 21) (anchorPairs.map (fun (a,b) => differ (score a) (score b)))

/-- Put each anchor pair opposite its ear. Each of the three extra labels
can be pinned on either side or left free. Global exchange of sides is redundant. -/
def patterns : List Pattern := [
  ([0,1,2,3],[7,8]),
  ([0,1,2,3,4],[7,8]),
  ([0,1,2,3],[7,8,4]),
  ([0,1,2,3,5],[7,8]),
  ([0,1,2,3,4,5],[7,8]),
  ([0,1,2,3,5],[7,8,4]),
  ([0,1,2,3],[7,8,5]),
  ([0,1,2,3,4],[7,8,5]),
  ([0,1,2,3],[7,8,4,5]),
  ([0,1,2,3,6],[7,8]),
  ([0,1,2,3,4,6],[7,8]),
  ([0,1,2,3,6],[7,8,4]),
  ([0,1,2,3,5,6],[7,8]),
  ([0,1,2,3,4,5,6],[7,8]),
  ([0,1,2,3,5,6],[7,8,4]),
  ([0,1,2,3,6],[7,8,5]),
  ([0,1,2,3,4,6],[7,8,5]),
  ([0,1,2,3,6],[7,8,4,5]),
  ([0,1,2,3],[7,8,6]),
  ([0,1,2,3,4],[7,8,6]),
  ([0,1,2,3],[7,8,4,6]),
  ([0,1,2,3,5],[7,8,6]),
  ([0,1,2,3,4,5],[7,8,6]),
  ([0,1,2,3,5],[7,8,4,6]),
  ([0,1,2,3],[7,8,5,6]),
  ([0,1,2,3,4],[7,8,5,6]),
  ([0,1,2,3],[7,8,4,5,6]),
  ([0,1,8],[2,3,7]),
  ([0,1,8,4],[2,3,7]),
  ([0,1,8],[2,3,7,4]),
  ([0,1,8,5],[2,3,7]),
  ([0,1,8,4,5],[2,3,7]),
  ([0,1,8,5],[2,3,7,4]),
  ([0,1,8],[2,3,7,5]),
  ([0,1,8,4],[2,3,7,5]),
  ([0,1,8],[2,3,7,4,5]),
  ([0,1,8,6],[2,3,7]),
  ([0,1,8,4,6],[2,3,7]),
  ([0,1,8,6],[2,3,7,4]),
  ([0,1,8,5,6],[2,3,7]),
  ([0,1,8,4,5,6],[2,3,7]),
  ([0,1,8,5,6],[2,3,7,4]),
  ([0,1,8,6],[2,3,7,5]),
  ([0,1,8,4,6],[2,3,7,5]),
  ([0,1,8,6],[2,3,7,4,5]),
  ([0,1,8],[2,3,7,6]),
  ([0,1,8,4],[2,3,7,6]),
  ([0,1,8],[2,3,7,4,6]),
  ([0,1,8,5],[2,3,7,6]),
  ([0,1,8,4,5],[2,3,7,6]),
  ([0,1,8,5],[2,3,7,4,6]),
  ([0,1,8],[2,3,7,5,6]),
  ([0,1,8,4],[2,3,7,5,6]),
  ([0,1,8],[2,3,7,4,5,6])]
def supported (P Q : List Label) := all (ones 21) (P.map (fun i => atTwo (Q.map (edge i))))
def works (a : Pattern) := supported a.1 a.2 &&& supported a.2 a.1
def available := any (patterns.map works)

theorem pattern_data : ∀a∈patterns,(∀i∈a.1,i∉a.2) ∧ a.1.Nodup ∧ a.2.Nodup ∧
    (7∈a.1 ∨ 7∈a.2) ∧ (8∈a.1 ∨ 8∈a.2) := by decide
end Graffiti384b.Four29.LocalTest
#print axioms Graffiti384b.Four29.LocalTest.pattern_data
