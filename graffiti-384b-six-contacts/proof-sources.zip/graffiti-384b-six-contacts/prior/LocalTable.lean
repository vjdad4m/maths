import LocalSignals
namespace Graffiti384b.Four29.LocalTest
set_option maxRecDepth 65536 in
set_option maxHeartbeats 0 in
set_option exponentiation.threshold 4194304 in
/-- Bit-for-bit table identity over all 2^21 assignments. -/
theorem table : rich &&& distinct &&& available = rich &&& distinct := by rfl
end Graffiti384b.Four29.LocalTest
#print axioms Graffiti384b.Four29.LocalTest.table
