import FourFront

namespace Graffiti384b.PairMix.Local
open Finset
abbrev Label := Fin 11
abbrev Root := Fin 4
def atRoot (r : Root) : Label := ⟨r.val,by omega⟩
def position (i j : Label) := (max i.val j.val).choose 2+min i.val j.val
def preset (i j : Label) : Bool := decide ((i=9 ∧ j.val<2) ∨ (j=9 ∧ i.val<2) ∨
    (i=10 ∧ 2 ≤ j.val ∧ j.val<4) ∨ (j=10 ∧ 2 ≤ i.val ∧ i.val<4))
/-- Edge bits among the nine high labels. Two prescribed stars supply the ear edges. -/
def edge (a : ℕ→Bool) (i j : Label) : Bool := if i=j then false else
  if i.val<9 ∧ j.val<9 then a (position i j) else preset i j
def pairs : Finset (Label×Label) := univ.filter (fun z => z.1<z.2)
def triangles (a : ℕ→Bool) (i : Label) := pairs.filter (fun z =>
  edge a i z.1=true ∧ edge a i z.2=true ∧ edge a z.1 z.2=true)
def shore (s : ℕ) : Finset Label := univ.filter (fun i => s.testBit i.val=true)
/-- The labels in the two sets are pins, and all other labels remain free. -/
def Good (a : ℕ→Bool) (P Q : Finset Label) :=
  Disjoint P Q ∧ (9:Label)∈P∪Q ∧ (10:Label)∈P∪Q ∧
  (∀i∈P,2≤(Q.filter (fun j => edge a i j=true)).card) ∧
  (∀i∈Q,2≤(P.filter (fun j => edge a i j=true)).card)
instance goodDec (a : ℕ→Bool) (P Q : Finset Label) : Decidable (Good a P Q) := by
  unfold Good; infer_instance

def Below (a b : ℕ→Bool) := ∀i,a i=true → b i=true
private theorem edge_mono {a b : ℕ→Bool} (ab : Below a b) (i j : Label) :
    edge a i j=true → edge b i j=true := by
  unfold edge; split
  · exact id
  · split
    · exact ab _
    · exact id
private theorem tri_mono {a b : ℕ→Bool} (ab : Below a b) (v : Label) :
    (triangles a v).card≤(triangles b v).card := by
  apply card_le_card
  intro p pm
  obtain ⟨ij,t1,t2,t3⟩ := mem_filter.mp pm
  exact mem_filter.mpr ⟨ij,edge_mono ab _ _ t1,edge_mono ab _ _ t2,edge_mono ab _ _ t3⟩
private theorem good_mono {a b : ℕ→Bool} (ab : Below a b) {P Q : Finset Label} (h : Good a P Q) : Good b P Q := by
  have gain (v : Label) (S : Finset Label) : (S.filter (fun j => edge a v j=true)).card≤
      (S.filter (fun j => edge b v j=true)).card := card_le_card (fun j m =>
    mem_filter.mpr ⟨(mem_filter.mp m).1,edge_mono ab v j (mem_filter.mp m).2⟩)
  exact ⟨h.1,h.2.1,h.2.2.1,fun i h' => (h.2.2.2.1 i h').trans (gain ..),
    fun i h' => (h.2.2.2.2 i h').trans (gain ..)⟩

inductive Tree where
  | small (r : Root)
  | cut (l r : ℕ)
  | branch (key : ℕ) (yes no : Tree)

def threshold (h r : Root) := if r=h then 13 else 2
def on (n : ℕ) (i : ℕ) := n.testBit i
def allowed (n : ℕ) (i : ℕ) := !(n.testBit i)
/-- At one leaf the upper graph has too few triangles. At the other kind of
leaf an explicit placement is already valid in the lower graph. -/
def check (h : Root) (lo no : ℕ) : Tree → Bool
  | .small r => decide ((triangles (allowed no) (atRoot r)).card<threshold h r)
  | .cut l r => decide (Good (on lo) (shore l) (shore r))
  | .branch i yes neg => check h (lo ||| 2^i) no yes && check h lo (no ||| 2^i) neg

theorem check_sound (h : Root) (a : ℕ→Bool)
    (rich : ∀r,threshold h r≤(triangles a (atRoot r)).card) (t : Tree) (lo no : ℕ)
    (lb : Below (on lo) a) (ub : Below a (allowed no)) (tested : check h lo no t=true) :
    ∃P Q,Good a P Q := by
  induction t generalizing lo no with
  | small r =>
    have little := of_decide_eq_true tested
    have large := (rich r).trans (tri_mono ub (atRoot r))
    exact (not_lt_of_ge large little).elim
  | cut l r => exact ⟨_,_,good_mono lb (of_decide_eq_true tested)⟩
  | branch key yes neg goodPos goodNeg =>
    obtain ⟨hp,hn⟩ := Bool.and_eq_true_iff.mp tested
    cases val : a key with
    | true =>
      apply goodPos _ _ ?_ ub hp
      intro i hi
      simp only [on,Nat.testBit_or,Bool.or_eq_true,Nat.testBit_two_pow,decide_eq_true_eq] at hi
      rcases hi with old|same
      · exact lb i old
      · subst i; exact val
    | false =>
      apply goodNeg _ _ lb ?_ hn
      intro i hi
      have was := ub i hi
      have distinct : i≠key := fun eq => by subst i; simp [val] at hi
      simp_all [allowed,Nat.testBit_or,Nat.testBit_two_pow,Ne.symm distinct]

/-- An unrestricted certificate starts with no fixed present or absent edge. -/
theorem from_tree (h : Root) (a : ℕ→Bool)
    (rich : ∀r,threshold h r≤(triangles a (atRoot r)).card) (t : Tree) (tested : check h 0 0 t=true) :
    ∃P Q,Good a P Q := check_sound h a rich t 0 0 (by simp [Below,on]) (by simp [Below,allowed]) tested
end Graffiti384b.PairMix.Local
#print axioms Graffiti384b.PairMix.Local.from_tree
