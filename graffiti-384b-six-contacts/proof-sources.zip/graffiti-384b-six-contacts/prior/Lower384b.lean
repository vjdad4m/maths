import Order37_384b
import LowerTable384b

namespace Graffiti384b.Lower
open Finset SimpleGraph CliqueChoice CliqueSample LowSample JointRank JointSample
open private LowSample.delta LowSample.weight from LowSample384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

set_option maxRecDepth 32768

private def floorDegree (i : ℕ) := if i<1 then 3 else if i<4 then 4 else if i<8 then 5 else
  if i<13 then 6 else if i<19 then 7 else if i<26 then 8 else 9
private def baseLoss := ∑ i ∈ range 33, FiniteRange.badCount 33 13 (floorDegree i)
private def ordinary := income 33 13 2
private def credit := 10816624

private theorem numbers :
    (∀ i : Fin 33, 1 ≤ floorDegree i ∧ floorDegree i < 33) ∧
    (∀ i : Fin 33, ∀ j : Fin 9, 3 ≤ j.val → j.val < floorDegree i → j.val.choose 2 ≤ i.val+2) ∧
    (∀ i : Fin 33, credit ≤ rebate 33 13 (floorDegree i)) ∧
    (∀ d : Fin 3, ordinary ≤ income 33 13 d) ∧
    (6*(17*((33:ℕ).choose 13)+baseLoss) < 6*20*((33:ℕ).choose 13) + 3*ordinary + 6*credit) := by
  unfold baseLoss ordinary credit income rebate FiniteRange.badCount LowSample.weight
  simp only [Nat.choose_eq_fast_choose]
  decide

omit [DecidableEq V] in
private theorem high_sub : high G ⊆ nonleaves G := by
  intro v hv
  exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩

private theorem exceptional (hc : G.Connected) (t35 : (types G).card = 35) (h33 : (high G).card = 33)
    (q36 : 36 ≤ (nonleaves G).card)
    (unsat : ∀ v, G.degree v ∈ levels → trianglesAt G v < (G.degree v).choose 2) :
    gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨inj,highScore,_,_⟩ := Repair.maximal_diversity G (by omega)
  let r := rank (high G) (trianglesAt G)
  let d (v : V) := floorDegree (r v)
  have rr := rank_range (high G) (trianglesAt G) inj
  have valid {v : V} (hv : v ∈ high G) : r v < 33 := by
    have mem := mem_image_of_mem (rank (high G) (trianglesAt G)) hv
    rw [rr,h33] at mem
    exact mem_range.mp mem
  obtain ⟨limits,rankBound,creditBound,weightBound,win⟩ := numbers
  have certDeg (v : V) (hv : v ∈ high G) : 1 ≤ d v ∧ d v ≤ G.degree v ∧ d v < (high G).card := by
    have lim := limits ⟨r v,valid hv⟩
    change 1 ≤ d v ∧ d v < 33 at lim
    refine ⟨lim.1,?_,h33 ▸ lim.2⟩
    apply Nat.le_of_not_gt
    intro small
    have maxD : d v ≤ 9 := by simp [d,floorDegree]; split_ifs <;> omega
    have hi : G.degree v < 9 := by omega
    have lo := (mem_filter.mp hv).2
    have cap := unsat v (mem_Icc.mpr ⟨lo,by omega⟩)
    have z := rankBound ⟨r v,valid hv⟩ ⟨G.degree v,hi⟩ lo small
    change (G.degree v).choose 2 ≤ r v+2 at z
    have minScore := rank_lower (high G) (trianglesAt G) inj 2 highScore hv
    change 2+r v ≤ trianglesAt G v at minScore
    omega
  have loss : (∑ v ∈ high G, FiniteRange.badCount 33 13 (d v)) = baseLoss := by
    have eq := sum_by_rank (high G) (trianglesAt G) inj (fun i => FiniteRange.badCount 33 13 (floorDegree i))
    rwa [h33] at eq
  have count : (twos G).card+(high G).card = (nonleaves G).card := card_sdiff_add_card_eq_card (high_sub G)
  obtain ⟨x,xt⟩ := card_pos.mp (show 0 < (twos G).card by omega)
  obtain ⟨v,hv,w,hw,edge⟩ := BoundaryFiber.crossing G hc
    (card_pos.mp (show 0 < (high G).card by omega)) ⟨x,(mem_sdiff.mp xt).2⟩
  have obs := JointSample.obstruction G 13 (by decide) d {v} (singleton_subset_iff.mpr hv)
    (by intro z hz; exact (mem_singleton.mp hz) ▸ ⟨w,hw,edge⟩) certDeg fail
  dsimp only at obs
  rw [h33,t35,loss,sum_singleton] at obs
  have extra := creditBound ⟨r v,valid hv⟩
  change credit ≤ rebate 33 13 (d v) at extra
  have agg : ∑ z ∈ twos G, ordinary ≤ ∑ z ∈ twos G, income 33 13 (anchorCount G z) := by
    apply sum_le_sum
    intro z hz
    exact weightBound ⟨anchorCount G z,by have := at_most_two G hz; omega⟩
  simp only [sum_const,smul_eq_mul] at agg
  have lower := Nat.mul_le_mul_right ordinary (show 3 ≤ (twos G).card by omega)
  change 6*20*((33:ℕ).choose 13) + _ + 6*rebate 33 13 (d v) ≤ 6*(17*((33:ℕ).choose 13)+baseLoss) at obs
  omega

/-- At each of these four diversities, the corresponding number of nonleaves suffices. -/
theorem exact_of_quota (hc : G.Connected) (member : (types G).card ∈ inputs)
    (large : quota (types G).card ≤ (nonleaves G).card) : gamma G ≤ bound G := by
  by_contra! bad
  letI : Nonempty V := hc.nonempty
  obtain ⟨p,ch⟩ := choose_from G levels (fun _ hd => (mem_Icc.mp hd).1)
  let t := (types G).card
  let h := (high G).card
  let e := t-h
  let f := p.image (fun v => G.degree v)
  let s := high G \ p
  let m := h-f.card
  let b := batch t
  have miss : (h+1)/2 < (t+1)/2 := Nat.lt_of_not_ge (fun le => (not_le_of_gt bad) (exact_of_high G le))
  have lim : t ≤ h+2 := type_bound G
  have off : e ∈ ({1,2} : Finset ℕ) := by simp only [mem_insert,mem_singleton]; dsimp [e]; omega
  have diff : t-e = h := by dsimp [e]; omega
  have sz : s.card = m := by dsimp only [m,h,f,s]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  obtain ⟨t35,e2,empty⟩ | tab := table t member e off f (mem_powerset.mpr ch.levels)
  · change t=35 at t35
    have hh : (high G).card=33 := by change h=33; omega
    have qq : 36 ≤ (nonleaves G).card := by change quota t ≤ _ at large; simpa [quota,t35] using large
    apply (not_le_of_gt bad) (exceptional G hc t35 hh qq ?_)
    intro v level
    apply Nat.lt_of_le_of_ne (Repair.triangles_le_choose G v)
    intro sat
    have hit := ch.covers v level sat
    change G.degree v ∈ f at hit
    rw [empty] at hit
    exact not_mem_empty _ hit
  · unfold Certificate at tab
    rw [diff] at tab
    change 12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧ _ at tab
    obtain ⟨room,two,env,rew,numeric⟩ := tab
    have obs := CliqueSample.obstruction G ch b (sz ▸ room) two (sz ▸ env) (sz ▸ rew) bad
    change 6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) ≤
      6*(((t+1)/2-1)*m.choose b + charge t h m b f levels) at obs
    change 6*(((t+1)/2-1)*m.choose b + charge t h m b f levels) <
      6*(m-b)*m.choose b + (quota t-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) at numeric
    have count : (twos G).card+h = (nonleaves G).card := card_sdiff_add_card_eq_card (high_sub G)
    change quota t ≤ (nonleaves G).card at large
    have low := Nat.mul_le_mul_right (6*(m-2).choose (b-2)) (show quota t-h ≤ (twos G).card by omega)
    omega

theorem nonleaf_cap (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    (nonleaves G).card ≤ 35 := by
  by_contra! q
  have small : (types G).card < 37 := Nat.lt_of_not_ge (fun ht =>
    (not_lt_of_ge (Order37.exact_of_at_least_37_types G hc hn ht)) bad)
  by_cases member : (types G).card ∈ inputs
  · apply (not_lt_of_ge (exact_of_quota G hc member ?_)) bad
    unfold quota
    split_ifs <;> omega
  · by_cases many : 14 ≤ (types G).card
    · have cap := (nonleaf_profile G bad many (by omega)).1
      have rows : ∀ t : Fin 37, ∀ e : Fin 3, t.val ∉ inputs → (LowSample.row t e).1 ≤ 35 := by decide
      have lim := type_bound G
      exact (not_le_of_gt q) (cap.trans (rows ⟨(types G).card,small⟩ ⟨(types G).card-(high G).card,by omega⟩ member))
    · have lim := nonleaf_bound G
      unfold bound at bad
      omega

theorem bounded_failure (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ r.card ≤ 36 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V)) = types G ∧ bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨r,_,cap,ord,conn,same,fail⟩ := Prune.prune_failure G hc hn bad
  have := nonleaf_cap G hc hn bad
  exact ⟨r,ord,by omega,conn,same,fail⟩

theorem residual_range (res : Minimal.Residual G) :
    Fintype.card V ≤ 36 ∧ 7 ≤ (types G).card ∧ (types G).card ≤ 35 ∧ (types G).card%2=1 ∧
    (Fintype.card V=36 → (types G).card=35 ∧ (nonleaves G).card=35 ∧
      ((high G).card=33 ∨ (high G).card=34)) := by
  obtain ⟨_,lo,hi,odd⟩ := Order37.residual_range G res
  obtain ⟨⟨hn,_⟩,hc,bad,_,_,_,_,_,least⟩ := res
  obtain ⟨r,_,cap,ord,conn,_,fail⟩ := Prune.prune_failure G hc hn bad
  have le := least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord,conn,fail⟩
  have q := nonleaf_cap G hc hn bad
  refine ⟨by omega,lo,hi,odd,?_⟩
  intro n
  have qeq : (nonleaves G).card=35 := by omega
  have t35 : (types G).card=35 := by
    by_contra ne
    by_cases member : (types G).card ∈ inputs
    · apply (not_lt_of_ge (exact_of_quota G hc member ?_)) bad
      simp only [inputs,mem_insert,mem_singleton] at member
      rcases member with h | h | h | h <;> simp [quota,h,qeq]
      omega
    · by_cases many : 14 ≤ (types G).card
      · have bound' := (nonleaf_profile G bad many (by omega)).1
        have rows : ∀ t : Fin 36, ∀ e : Fin 3, t.val ∉ inputs → (LowSample.row t e).1 ≤ 34 := by decide
        have slim := type_bound G
        have zz := bound'.trans (rows ⟨(types G).card,by omega⟩ ⟨(types G).card-(high G).card,by omega⟩ member)
        omega
      · have slim := nonleaf_bound G
        unfold bound at bad
        omega
  have lim := type_bound G
  have upper : ((high G).card+1)/2 < ((types G).card+1)/2 :=
    Nat.lt_of_not_ge (fun h => (not_lt_of_ge (exact_of_high G h)) bad)
  exact ⟨t35,qeq,by omega⟩

end Graffiti384b.Lower
#print axioms Graffiti384b.Lower.exact_of_quota
#print axioms Graffiti384b.Lower.nonleaf_cap
#print axioms Graffiti384b.Lower.bounded_failure
#print axioms Graffiti384b.Lower.residual_range
