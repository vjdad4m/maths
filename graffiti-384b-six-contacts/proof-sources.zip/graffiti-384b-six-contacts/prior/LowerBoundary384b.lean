import Lower384b
import LowerClique384b
import LowerProfiles384b

namespace Graffiti384b.LowerBoundary
open Finset SimpleGraph CliqueChoice
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem exact_of_many_nonleaves (hc : G.Connected) (hn : 2 < Fintype.card V)
    (large : 36 ≤ (nonleaves G).card) : gamma G ≤ bound G := by
  by_contra! bad
  have := Lower.nonleaf_cap G hc hn bad
  omega

/-- A failure at diversity 35 has an induced counterexample at order 35 or 36.
The reduced graph has a five-clique and one of the certified saturated-degree profiles. -/
theorem reduced_failure (hc : G.Connected) (hn : 2 < Fintype.card V)
    (bad : bound G < gamma G) (t : (types G).card=35) :
    ∃ R : Finset V, (R.card=35 ∨ R.card=36) ∧ (G.induce (R : Set V)).Connected ∧
      types (G.induce (R : Set V))=types G ∧
      (let J := G.induce (R : Set V)
       bound J < gamma J ∧ ¬J.CliqueFree 5 ∧ (nonleaves J).card ∈ ({34,35} : Finset ℕ) ∧
       (high J).card ∈ ({33,34} : Finset ℕ) ∧
       ∃ p, Choice J p Boundary.levels ∧ LowerProfiles.residual (nonleaves J).card (high J).card (p.image (J.degree ·))) := by
  obtain ⟨R,ord,size,conn,same,fail⟩ := Lower.bounded_failure G hc hn bad
  let J := G.induce (R : Set V)
  have tj : (types J).card=35 := by change (types (G.induce (R : Set V))).card=35; rw [same,t]
  have div : (types J).card ≤ R.card := by
    simpa [types] using (card_image_le (s := (univ : Finset R)) (f := trianglesAt J))
  have nJ : 2 < Fintype.card (R : Set V) := by simpa using ord
  have free : ¬J.CliqueFree 5 := fun f => (not_lt_of_ge (LowerClique.exact_of_five_clique_free J conn nJ tj.ge f)) fail
  have upper := Lower.nonleaf_cap J conn nJ fail
  have lower : 34 ≤ (nonleaves J).card := by
    obtain ⟨r,_,cap,_,_,eq,_⟩ := Prune.prune_failure J conn nJ fail
    have div2 : (types (J.induce (r : Set (R : Set V)))).card ≤ r.card := by
      simpa [types] using (card_image_le (s := (univ : Finset r)) (f := trianglesAt (J.induce (r : Set (R : Set V)))))
    rw [eq,tj] at div2
    omega
  have q : (nonleaves J).card ∈ ({34,35} : Finset ℕ) := by simp only [mem_insert,mem_singleton]; omega
  have hi := type_bound J
  have miss : ((high J).card+1)/2 < ((types J).card+1)/2 :=
    Nat.lt_of_not_ge (fun le => (not_lt_of_ge (exact_of_high J le)) fail)
  have h : (high J).card ∈ ({33,34} : Finset ℕ) := by simp only [mem_insert,mem_singleton]; omega
  letI : Nonempty (R : Set V) := conn.nonempty
  obtain ⟨p,ch⟩ := choose_from J Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  exact ⟨R,by omega,conn,same,fail,free,q,h,p,ch,LowerProfiles.saturated_profiles J ch tj h _ q le_rfl fail⟩

end Graffiti384b.LowerBoundary
#print axioms Graffiti384b.LowerBoundary.exact_of_many_nonleaves
#print axioms Graffiti384b.LowerBoundary.reduced_failure
