import Order37_384b

namespace Graffiti384b.LowerClique
open Finset SimpleGraph JointRank
open private FiniteRange.bad FiniteRange.trial FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Pick one representative of each of m different counts greater than one. -/
private theorem representatives (m : ℕ) (enough : m+2 ≤ (types G).card) :
    ∃ s : Finset V, s.card=m ∧ Set.InjOn (trianglesAt G) (s : Set V) ∧ ∀ v ∈ s, 2 ≤ trianglesAt G v := by
  classical
  let Q := types G \ {0,1}
  have n : m ≤ Q.card := by
    have h := card_le_card (show types G ⊆ Q ∪ {0,1} by
      intro i hi; by_cases small : i ∈ ({0,1} : Finset ℕ)
      · exact mem_union_right _ small
      · exact mem_union_left _ (mem_sdiff.mpr ⟨hi,small⟩))
    have u := card_union_le Q ({0,1} : Finset ℕ)
    have size : ({0,1} : Finset ℕ).card = 2 := by decide
    omega
  obtain ⟨T,sub,card⟩ := exists_subset_card_eq n
  have has (i : T) : ∃ v, trianglesAt G v = i := by
    obtain ⟨v,_,h⟩ := mem_image.mp (mem_sdiff.mp (sub i.property)).1
    exact ⟨v,h⟩
  choose f hf using has
  have fi : Function.Injective f := fun x y e => Subtype.ext ((hf x).symm.trans ((congrArg _ e).trans (hf y)))
  refine ⟨(univ : Finset T).image f,by rw [card_image_of_injective _ fi,card_univ,Fintype.card_coe,card],?_,?_⟩
  · intro x hx y hy eq
    obtain ⟨a,_,rfl⟩ := mem_image.mp hx
    obtain ⟨b,_,rfl⟩ := mem_image.mp hy
    rw [hf,hf] at eq
    exact congrArg f (Subtype.ext eq)
  · intro v hv
    obtain ⟨a,_,rfl⟩ := mem_image.mp hv
    rw [hf]
    have no := (mem_sdiff.mp (sub a.property)).2
    simp only [mem_insert,mem_singleton,not_or] at no
    omega

private def floorD (r i : ℕ) :=
  ((List.range 13).find? (fun d => decide (i+2 ≤ RankTable.cap d r))).getD 13
private def batch (m r : ℕ) := if r=3 then 12 else if m=23 then 8 else if m≤27 then 9 else if m≤31 then 10 else 11
private def Row (m r : ℕ) :=
  let b := batch m r
  let goal := (m+3)/2
  (∀ i : Fin m, floorD r i < m ∧ floorD r i ≤ 12) ∧
  (∀ i : Fin m, ∀ d : Fin 12, d.val < floorD r i → RankTable.cap d r < i.val+2) ∧
  (∑ i ∈ range m, FiniteRange.badCount m b (floorD r i)) < (m-b+1-goal)*m.choose b

private def admissible (m r : ℕ) : Prop := (r=3 ∧ m=33) ∨ (r=2 ∧ m ∈ ({23,25,27,29,31,33} : Finset ℕ))

set_option maxRecDepth 32768 in
set_option maxHeartbeats 4000000 in
private theorem table {m r : ℕ} (good : admissible m r) : Row m r := by
  rcases good with ⟨rfl,rfl⟩ | ⟨rfl,h⟩
  · unfold Row FiniteRange.badCount
    simp only [Nat.choose_eq_fast_choose]
    decide
  · simp only [mem_insert,mem_singleton] at h
    rcases h with rfl|rfl|rfl|rfl|rfl|rfl <;>
      unfold Row FiniteRange.badCount <;> simp only [Nat.choose_eq_fast_choose] <;> decide

/-- Use the neighborhood Turán bound at every distinct-score rank, then
double count the vertices deficient in a uniformly sampled retained set. -/
private theorem sampled (m r : ℕ) (good : admissible m r) (enough : m+2 ≤ (types G).card)
    (target : ((types G).card+1)/2 ≤ (m+3)/2) (free : G.CliqueFree (r+2)) : gamma G ≤ bound G := by
  classical
  obtain ⟨s,sz,inj,lo⟩ := representatives G m enough
  obtain ⟨lim,checked,strict⟩ := table good
  have rr : r=2 ∨ r=3 := by rcases good with ⟨h,_⟩|⟨h,_⟩ <;> omega
  let R := rank s (trianglesAt G)
  let b := batch m r
  have valid (v : V) (hv : v ∈ s) : R v < m := by
    have h := mem_image_of_mem (rank s (trianglesAt G)) hv
    rwa [rank_range s (trianglesAt G) inj,sz,mem_range] at h
  have degree (v : V) (hv : v ∈ s) : floorD r (R v) ≤ G.degree v := by
    by_contra! small
    have mx := (lim ⟨_,valid v hv⟩).2
    change floorD r (R v) ≤ 12 at mx
    have d12 : G.degree v < 12 := by omega
    have h := checked ⟨_,valid v hv⟩ ⟨_,d12⟩ small
    change RankTable.cap (G.degree v) r < R v+2 at h
    have l := rank_lower s (trianglesAt G) inj 2 lo hv
    change 2+R v ≤ trianglesAt G v at l
    have cap := RankTuran.local_turan G r (by omega) free v
    have val := RankTable.cap_table ⟨G.degree v,d12⟩ ⟨r,by omega⟩ (by change 0<r; omega)
    change (turanGraph (G.degree v) r).edgeFinset.card = _ at val
    have vc : trianglesAt G v ≤ RankTable.cap (G.degree v) r := cap.trans_eq val
    omega
  let opts := s.powersetCard b
  let fiber (v : V) := (opts.filter (fun k => v ∈ FiniteRange.bad G s k)).card
  have total : (∑ k ∈ opts, (FiniteRange.bad G s k).card) = ∑ v ∈ s, fiber v := by
    calc
      _ = ∑ k ∈ opts, ∑ v ∈ s, (if v ∈ FiniteRange.bad G s k then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show FiniteRange.bad G s k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
      _ = _ := by rw [sum_comm]; simp [fiber]
  have per (v : V) (hv : v ∈ s) : fiber v ≤ FiniteRange.badCount m b (floorD r (R v)) := by
    rw [← sz]
    exact FiniteRange.count_bad G s b _ v hv (degree v hv) (by rw [sz]; exact (lim ⟨_,valid v hv⟩).1)
  have sumBound := sum_le_sum per
  rw [sum_by_rank s (trianglesAt G) inj (fun i => FiniteRange.badCount m b (floorD r i)),sz] at sumBound
  have capEnough : (m+3)/2 ≤ Capacity.value G s sᶜ := by
    by_contra! small
    have low (k : Finset V) (hk : k ∈ opts) : m-b+1-(m+3)/2 ≤ (FiniteRange.bad G s k).card := by
      obtain ⟨sub,card⟩ := mem_powersetCard.mp hk
      have h := FiniteRange.trial G s k sub
      change k.card=b at card
      rw [sz,card] at h
      omega
    have too := sum_le_sum low
    rw [total] at too
    have count : opts.card = m.choose b := by rw [show opts = s.powersetCard b from rfl,card_powersetCard,sz]
    simp only [sum_const,nsmul_eq_mul,Nat.cast_id,count] at too
    change (∑ i ∈ range m, FiniteRange.badCount m b (floorD r i)) < (m-b+1-(m+3)/2)*m.choose b at strict
    rw [Nat.mul_comm] at too
    exact (not_lt_of_ge (too.trans sumBound)) strict
  have result := Capacity.seeded_value G ∅ s sᶜ (by simp) (by simp) disjoint_compl_right (by simp)
  simp only [card_empty,zero_add] at result
  unfold bound
  omega

theorem exact_of_five_clique_free (hc : G.Connected) (hn : 2 < Fintype.card V)
    (many : 35 ≤ (types G).card) (free : G.CliqueFree 5) : gamma G ≤ bound G := by
  by_cases hi : 37 ≤ (types G).card
  · exact Order37.exact_of_at_least_37_types G hc hn hi
  · exact sampled G 33 3 (Or.inl ⟨rfl,rfl⟩) (by omega) (by omega) free

theorem exact_of_four_clique_free (hc : G.Connected) (hn : 2 < Fintype.card V)
    (many : 25 ≤ (types G).card) (free : G.CliqueFree 4) : gamma G ≤ bound G := by
  by_cases hi : 37 ≤ (types G).card
  · exact Order37.exact_of_at_least_37_types G hc hn hi
  · let m := 2*(((types G).card-1)/2)-1
    have ok : m ∈ ({23,25,27,29,31,33} : Finset ℕ) := by
      simp only [mem_insert,mem_singleton]; dsimp [m]; omega
    exact sampled G m 2 (Or.inr ⟨rfl,ok⟩) (by dsimp [m]; omega) (by dsimp [m]; omega) free

end Graffiti384b.LowerClique
#print axioms Graffiti384b.LowerClique.exact_of_five_clique_free
#print axioms Graffiti384b.LowerClique.exact_of_four_clique_free
