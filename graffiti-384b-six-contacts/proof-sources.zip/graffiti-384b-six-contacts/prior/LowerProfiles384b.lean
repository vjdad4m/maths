import Boundary384b

namespace Graffiti384b.LowerProfiles
open Finset SimpleGraph CliqueChoice CliqueSample Boundary LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Saturated degrees of the selected representatives in a 35-type failure.
At 35 nonleaves only five high-size / degree-set combinations survive. -/
def residual (q h : ℕ) (f : Finset ℕ) : Prop :=
  f=∅ ∨ f={3} ∨ ((h=33 ∨ q=34) ∧ f={4}) ∨
    (q=34 ∧ (f={5} ∨ (h=33 ∧ f={6}) ∨ f={3,4} ∨ f={3,5}))

private def batch (h : ℕ) := if h=33 then 12 else 13
private def numeric (q h : ℕ) (f : Finset ℕ) : Prop :=
  let m := h-f.card
  let b := batch h
  12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧
  (∀ d : Fin 12, 3 ≤ d.val → (m-d.val).choose b + saved m b ≤ FiniteRange.badCount m b d.val) ∧
  6*(17*m.choose b + charge 35 h m b f levels) <
    6*(m-b)*m.choose b + (q-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) +
    6*(f.sup id * saved m b)

set_option maxRecDepth 32768 in
set_option maxHeartbeats 12000000 in
private theorem table : ∀ q ∈ ({34,35} : Finset ℕ), ∀ h ∈ ({33,34} : Finset ℕ),
    ∀ f ∈ levels.powerset, residual q h f ∨ numeric q h f := by
  unfold residual numeric levels envelope reward charge slots LowSample.delta LowSample.weight bonus FiniteRange.badCount saved
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

theorem saturated_profiles {p : Finset V} (ch : Choice G p levels)
    (t : (types G).card=35) (hc : (high G).card ∈ ({33,34} : Finset ℕ))
    (q : ℕ) (tested : q ∈ ({34,35} : Finset ℕ)) (large : q ≤ (nonleaves G).card)
    (fail : bound G < gamma G) :
    residual q (high G).card (p.image (G.degree ·)) := by
  classical
  let f := p.image (G.degree ·)
  let h := (high G).card
  let b := batch h
  let m := h-f.card
  let s := high G \ p
  have sz : s.card = m := by
    dsimp only [s,m,f,h]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  obtain good | tab := table q tested h hc f (mem_powerset.mpr ch.levels)
  · exact good
  by_cases empty : f=∅
  · exact Or.inl empty
  obtain ⟨d,df,eq⟩ := exists_mem_eq_sup f (nonempty_iff_ne_empty.mpr empty) id
  obtain ⟨x,xp,dx⟩ := mem_image.mp df
  let N := G.neighborFinset x
  have ns : N ⊆ s := neighbors_in_pool G ch xp
  let credit (v : V) := if v ∈ N then saved m b else 0
  obtain ⟨room,two,env,rew,pay,win⟩ := tab
  have refund (v : V) (vs : v ∈ s) :
      ((s.powersetCard b).filter (fun k => v ∈ FiniteRange.bad G s k)).card + credit v ≤
      FiniteRange.badCount s.card b (min (G.degree v) 11) := by
    by_cases vn : v ∈ N
    · have edge := (G.mem_neighborFinset _ _).mp vn
      have outside : x ∉ s := fun hx => (mem_sdiff.mp hx).2 xp
      have d3 := (mem_filter.mp (mem_sdiff.mp vs).1).2
      let dv := min (G.degree v) 11
      have lim : 3 ≤ dv ∧ dv < 12 := by dsimp [dv]; omega
      have raw := BoundaryFiber.count G s b dv vs outside edge.symm (min_le_left _ _) (by omega)
      simp only [credit,if_pos vn]
      rw [sz] at raw ⊢
      exact (Nat.add_le_add_right raw _).trans (pay ⟨dv,lim.2⟩ lim.1)
    · simp only [credit,if_neg vn,Nat.add_zero]
      exact FiniteRange.count_bad G s b _ _ vs (min_le_left _ _) (by omega)
  have obs := extraObstruction G ch b credit refund two (sz ▸ env) (sz ▸ rew) fail
  change 6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) +
    6*(∑ v ∈ s, credit v) ≤ 6*((((types G).card+1)/2-1)*m.choose b + charge (types G).card h m b f levels) at obs
  have sumCredit : (∑ v ∈ s, credit v) = f.sup id * saved m b := by
    simp only [credit,← sum_filter,filter_mem_eq_inter,inter_eq_right.mpr ns,sum_const,nsmul_eq_mul,Nat.cast_id]
    rw [show N.card = G.degree x from card_neighborFinset_eq_degree _ _,dx,eq]
    rfl
  have sub : high G ⊆ nonleaves G := by
    intro v hv
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count : (twos G).card+h = (nonleaves G).card := card_sdiff_add_card_eq_card sub
  have extra := Nat.mul_le_mul_right (6*(m-2).choose (b-2)) (show q-h ≤ (twos G).card by omega)
  rw [t,sumCredit] at obs
  change 6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) +
    6*(f.sup id * saved m b) ≤ 6*(17*m.choose b + charge 35 h m b f levels) at obs
  change 6*(17*m.choose b + charge 35 h m b f levels) < 6*(m-b)*m.choose b +
    (q-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) + 6*(f.sup id * saved m b) at win
  omega

end Graffiti384b.LowerProfiles
#print axioms Graffiti384b.LowerProfiles.saturated_profiles
