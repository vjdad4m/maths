import CliqueSample384b

namespace Graffiti384b.Lower
open Finset CliqueChoice CliqueSample
open private LowSample.delta LowSample.weight from LowSample384b

def levels : Finset ℕ := Icc 3 8
def inputs : Finset ℕ := {29,31,33,35}
def quota (t : ℕ) := if t=29 then 33 else if t=31 then 34 else if t=33 then 35 else 36
def batch (t : ℕ) := if t=29 then 11 else if t=35 then 13 else 12

def Certificate (t e : ℕ) (f : Finset ℕ) : Prop :=
  let h := t-e
  let m := h-f.card
  let b := batch t
  12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧
    6*(((t+1)/2-1)*m.choose b + charge t h m b f levels) <
    6*(m-b)*m.choose b + (quota t-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d)

def Row (t e : ℕ) := ∀ f ∈ levels.powerset, (t=35 ∧ e=2 ∧ f=∅) ∨ Certificate t e f

set_option Elab.async false
set_option maxRecDepth 32768
set_option maxHeartbeats 12000000

local macro "verify_row" : tactic => `(tactic|
  (unfold Row Certificate charge LowSample.delta envelope FiniteRange.badCount reward LowSample.weight bonus slots
   simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
   decide))

private theorem row29_1 : Row 29 1 := by verify_row
private theorem row29_2 : Row 29 2 := by verify_row
private theorem row31_1 : Row 31 1 := by verify_row
private theorem row31_2 : Row 31 2 := by verify_row
private theorem row33_1 : Row 33 1 := by verify_row
private theorem row33_2 : Row 33 2 := by verify_row
private theorem row35_1 : Row 35 1 := by verify_row
private theorem row35_2 : Row 35 2 := by verify_row

theorem table : ∀ t ∈ inputs, ∀ e ∈ ({1,2} : Finset ℕ), Row t e := by
  intro t ht e he
  simp only [inputs,mem_insert,mem_singleton] at ht he
  rcases ht with rfl | rfl | rfl | rfl <;> rcases he with rfl | rfl
  · exact row29_1
  · exact row29_2
  · exact row31_1
  · exact row31_2
  · exact row33_1
  · exact row33_2
  · exact row35_1
  · exact row35_2

end Graffiti384b.Lower
#print axioms Graffiti384b.Lower.table
