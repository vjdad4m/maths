import EarPrune384b

universe u
namespace Graffiti384b.Minimal
open Finset SimpleGraph TrianglePrune
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type u} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Existence at a specified order, over all finite graphs in this universe. -/
def FailingOrder (n : ℕ) : Prop :=
  ∃ (W : Type u) (fw : Fintype W) (ew : DecidableEq W) (J : SimpleGraph W) (dj : DecidableRel J.Adj),
    letI := fw
    letI := ew
    letI := dj
    Fintype.card W = n ∧ 2 < n ∧ J.Connected ∧ bound J < gamma J

private theorem original (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    FailingOrder.{u} (Fintype.card V) :=
  ⟨V,inferInstance,inferInstance,G,inferInstance,rfl,hn,hc,bad⟩

/-- Every least-order counterexample has odd diversity. With even diversity
the removed zero-score witness costs no required omission. -/
theorem least_odd (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G)
    (least : ∀ m, FailingOrder.{u} m → Fintype.card V ≤ m) : (types G).card % 2 = 1 := by
  by_contra! wrong
  have par : (types G).card % 2 = 0 := by omega
  have ub := type_bound G
  have cut := high_bound G
  have f := bad
  unfold bound at f
  have maxT : (types G).card = (high G).card+2 := by omega
  have has := (Repair.maximal_diversity G maxT).2.2.1
  obtain ⟨v,_,zero⟩ := mem_image.mp has
  obtain ⟨s,J,d,order,conn,fail,_,_,same,positive⟩ := normalize G hc hn bad
  letI := d
  have small := least s.card ⟨s,inferInstance,inferInstance,J,d,Fintype.card_coe _,order,conn,fail⟩
  have all : s = univ := eq_of_subset_of_card_le (subset_univ _) (by simpa using small)
  have vs : v ∈ s := all ▸ mem_univ _
  have h := positive par ⟨v,vs⟩
  rw [same,zero] at h
  omega

/-- Each triangle through a vertex accounts for at most two of its
neighbors. In a normalized graph all other neighbors must have score zero. -/
theorem degree_score (normal : Normal G) (v : V) (pv : 0 < trianglesAt G v) :
    G.degree v ≤ 2*trianglesAt G v + ((G.neighborFinset v).filter (fun z => trianglesAt G z = 0)).card ∧
    ((G.neighborFinset v).filter (fun z => trianglesAt G z = 0)).card ≤ 1 := by
  let extra := (G.neighborFinset v).filter (fun z => trianglesAt G z = 0)
  have sub : G.neighborFinset v ⊆ Repair.linkSupport G v ∪ extra := by
    intro w hw
    by_cases zero : trianglesAt G w = 0
    · exact mem_union_right _ (mem_filter.mpr ⟨hw,zero⟩)
    · have vw := (G.mem_neighborFinset _ _).mp hw
      obtain ⟨a,va,wa⟩ := normal.2.2 v w vw pv (by omega)
      apply mem_union_left
      refine mem_biUnion.mpr ⟨{w,a},mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset hw
        (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr va)),by simp [wa.ne]⟩,?_⟩,mem_insert_self _ _⟩
      intro i hi j hj ne
      simp only [mem_insert,mem_singleton] at hi hj
      rcases hi with rfl | rfl <;> rcases hj with rfl | rfl <;> first | exact (ne rfl).elim | exact wa | exact wa.symm
  have cap := (card_le_card sub).trans (card_union_le _ _)
  rw [card_neighborFinset_eq_degree] at cap
  have support : (Repair.linkSupport G v).card ≤ 2*trianglesAt G v := by
    have sum : ∑ p ∈ Repair.linkEdges G v, p.card = 2*trianglesAt G v := by
      calc
        _ = ∑ _p ∈ Repair.linkEdges G v, 2 := sum_congr rfl (fun p hp => (Repair.edge_info G hp).2.1)
        _ = _ := by simp [trianglesAt,Repair.linkEdges,Nat.mul_comm]
    exact card_biUnion_le.trans_eq sum
  exact ⟨by change G.degree v ≤ 2*trianglesAt G v + extra.card; omega,card_le_one.mpr (fun z hz w hw =>
    normal.1 z w (mem_filter.mp hz).2 (mem_filter.mp hw).2)⟩

private theorem top_case (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G)
    (least : ∀ m, FailingOrder.{u} m → Fintype.card V ≤ m) (n43 : Fintype.card V = 43) :
    (types G).card = 43 ∧ Function.Injective (trianglesAt G) ∧ (nonleaves G).card = 42 := by
  obtain ⟨r,_,cap,ord,conn,_,fail⟩ := Prune.prune_failure G hc hn bad
  have sm := least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord,conn,fail⟩
  obtain ⟨_,_,_,_,_,_,hi,_,_,_,_⟩ := LowSample.bounded_failure G hc hn bad
  have lo : 14 ≤ (types G).card := by
    have cut := nonleaf_bound G
    unfold bound at bad
    omega
  obtain ⟨q,upper,_⟩ := LowSample.nonleaf_profile G bad lo hi
  have t43 : (types G).card = 43 := by
    by_contra! few
    have small : ∀ t : Fin 43, ∀ e : Fin 3, (LowSample.row t e).1 ≤ 41 := by decide
    have growth := type_bound G
    have tab := small ⟨(types G).card,by omega⟩ ⟨(types G).card-(high G).card,by omega⟩
    change (LowSample.row (types G).card ((types G).card-(high G).card)).1 ≤ 41 at tab
    omega
  have inj := card_image_iff.mp (show ((univ : Finset V).image (trianglesAt G)).card = univ.card by
    change (types G).card = _; rw [card_univ,t43,n43])
  exact ⟨t43,fun _ _ eq => inj (mem_univ _) (mem_univ _) eq,by omega⟩

/-- Restrictions on the same graph of smallest failing order. -/
def Residual : Prop :=
  (2 < Fintype.card V ∧ Fintype.card V ≤ 43) ∧ G.Connected ∧ bound G < gamma G ∧
  Normal G ∧ (types G).card % 2 = 1 ∧ 7 ≤ (types G).card ∧
  (∀ x a b, G.Adj a b → G.neighborFinset x = {a,b} →
    ((EarPrune.after G x a b).card+1)/2 < ((types G).card+1)/2) ∧
  (Fintype.card V = 43 → (types G).card = 43 ∧ Function.Injective (trianglesAt G) ∧
    (nonleaves G).card = 42) ∧ (∀ m, FailingOrder.{u} m → Fintype.card V ≤ m)

/-- A counterexample at any order yields a least-order triangle-supported
counterexample satisfying all the local pruning and counting restrictions. -/
theorem residual_witness (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    ∃ (W : Type u) (fw : Fintype W) (ew : DecidableEq W) (J : SimpleGraph W) (dj : DecidableRel J.Adj),
      letI := fw
      letI := ew
      letI := dj
      Residual J := by
  classical
  have ex : ∃ n, FailingOrder.{u} n := ⟨_,original G hc hn bad⟩
  let n := Nat.find ex
  obtain ⟨W,fw,ew,B,db,card,ord,cn,bf⟩ := Nat.find_spec ex
  letI := fw
  letI := ew
  letI := db
  change Fintype.card W = n at card
  change 2 < n at ord
  obtain ⟨s,J,d,large,conn,fail,norm,_,_⟩ := normalize B cn (card ▸ ord) bf
  letI := d
  have min (m : ℕ) (hm : FailingOrder.{u} m) : n ≤ m := Nat.find_min' ex hm
  have low := min s.card ⟨s,inferInstance,inferInstance,J,d,Fintype.card_coe _,large,conn,fail⟩
  have small : s.card ≤ Fintype.card W := card_le_univ _
  have sz : Fintype.card s = n := by rw [Fintype.card_coe]; omega
  have least (m : ℕ) (hm : FailingOrder.{u} m) : Fintype.card s ≤ m := sz ▸ min m hm
  have hs : 2 < Fintype.card s := sz ▸ ord
  obtain ⟨r,ro,nn,rc,_,typesLo,_,_,_,_,rf⟩ := LowSample.bounded_failure J conn hs fail
  have smaller := least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ro,rc,rf⟩
  refine ⟨s,inferInstance,inferInstance,J,d,⟨hs,by omega⟩,conn,fail,norm,
    least_odd J conn hs fail least,typesLo,?_,top_case J conn hs fail least,least⟩
  intro x a b ab nx
  by_contra! retain
  have typesLe : (types J).card ≤ Fintype.card s := by
    simpa [types] using (card_image_le (s := (univ : Finset s)) (f := trianglesAt J))
  obtain ⟨er,ec,ef⟩ := EarPrune.delete_failure J conn (by omega) fail ab nx retain
  let p := EarPrune.rest x
  have lc := least p.card ⟨p,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,er,ec,ef⟩
  have pc : p.card = Fintype.card s-1 := by simp only [p,EarPrune.rest,card_compl,card_singleton]
  omega

end Graffiti384b.Minimal

#print axioms Graffiti384b.Minimal.degree_score
#print axioms Graffiti384b.Minimal.least_odd
#print axioms Graffiti384b.Minimal.residual_witness
namespace Graffiti384b.Minimal
open Finset SimpleGraph TrianglePrune
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V]
variable (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Every score-one vertex away from the possible pendant is covered by the
two-endpoint deletion test. -/
theorem score_one_ear (normal : Normal G) (v : V) (score : trianglesAt G v = 1)
    (noZero : ∀ w, G.Adj v w → 0 < trianglesAt G w) :
    ∃ a b, G.Adj a b ∧ G.neighborFinset v = {a,b} := by
  have empty : (G.neighborFinset v).filter (fun z => trianglesAt G z = 0) = ∅ :=
    filter_eq_empty_iff.mpr (fun w hw zero => (noZero w ((G.mem_neighborFinset _ _).mp hw)).ne' zero)
  have d := (degree_score G normal v (by omega)).1
  rw [empty,card_empty,score] at d
  obtain ⟨a,b,va,vb,ab⟩ := (TrianglePrune.triangle_iff G v).mp (by omega)
  have sub : ({a,b} : Finset V) ⊆ G.neighborFinset v := insert_subset
    ((G.mem_neighborFinset _ _).mpr va) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vb))
  refine ⟨a,b,ab,(eq_of_subset_of_card_le sub ?_).symm⟩
  rw [card_neighborFinset_eq_degree,card_pair ab.ne]
  omega

end Graffiti384b.Minimal

#print axioms Graffiti384b.Minimal.score_one_ear
