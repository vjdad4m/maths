import Finish33_384b

namespace Graffiti384b.MultiEar34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private LowSample.eligible LowSample.anchors LowSample.weight from LowSample384b
open private CliqueSample.trial from CliqueSample384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem fiber {p s W : Finset V} {v : V} (vp : v∈p) (vs : v∉s)
    (small : G.degree v≤s.card) (ns : G.neighborFinset v⊆W∪s) (b : ℕ) :
    bonus s.card b (G.degree v) ≤ ((s.powersetCard b).filter (fun k => v∈active G p (W∪k))).card := by
  let rows := s.powersetCard b
  have inc : rows.filter (fun k => v∉active G p (W∪k)) ⊆
      ((insert v s).powersetCard b).filter (fun k => v∈FiniteRange.bad G (insert v s) k) := by
    intro k km
    obtain ⟨kr,no⟩ := mem_filter.mp km
    obtain ⟨ks,kb⟩ := mem_powersetCard.mp kr
    have lt : nbr G v (W∪k)<2 := Nat.lt_of_not_ge (fun hh => no (mem_filter.mpr ⟨vp,hh⟩))
    have sub : ((insert v s)ᶜ∪k).filter (G.Adj v)⊆(W∪k).filter (G.Adj v) := by
      intro i hi
      obtain ⟨h,vi⟩ := mem_filter.mp hi
      refine mem_filter.mpr ⟨?_,vi⟩
      rcases mem_union.mp h with out|ik
      · rcases mem_union.mp (ns ((G.mem_neighborFinset _ _).mpr vi)) with iw|ins
        · exact mem_union_left _ iw
        · exact (mem_compl.mp out (mem_insert_of_mem ins)).elim
      · exact mem_union_right _ ik
    exact mem_filter.mpr ⟨mem_powersetCard.mpr ⟨ks.trans (subset_insert _ _),kb⟩,
      mem_filter.mpr ⟨mem_sdiff.mpr ⟨mem_insert_self _ _,fun h => vs (ks h)⟩,lt_of_le_of_lt (card_le_card sub) lt⟩⟩
  have loss := (card_le_card inc).trans (FiniteRange.count_bad G (insert v s) b (G.degree v) v
    (mem_insert_self _ _) le_rfl (by rw [card_insert_of_not_mem vs]; omega))
  rw [card_insert_of_not_mem vs] at loss
  have spl := filter_card_add_filter_neg_card_eq_card (s:=rows) (fun k => v∈active G p (W∪k))
  change _ + _ = (s.powersetCard b).card at spl
  rw [card_powersetCard] at spl
  dsimp only [rows] at loss spl
  unfold bonus
  omega

/-- The two ears can pay for one or two omissions according to the number of high anchors each has. -/
theorem weighted {p W : Finset V} (ch : Choice G p Boundary.levels) {y z : V}
    (wm : W⊆high G\p) (yt : y∈twos G) (zt : z∈twos G) (yz : y≠z)
    (ya : LowSample.anchors G y⊆W) (za : LowSample.anchors G z⊆W)
    (gain : ℕ) (gain_le : 6*gain≤LowSample.weight (LowSample.anchors G y).card+LowSample.weight (LowSample.anchors G z).card)
    (t : (types G).card=33) (fail : bound G<gamma G) (b : ℕ)
    (room : 9≤((high G\p)\W).card) :
    let s := (high G\p)\W
    (s.card-b+gain)*s.card.choose b + (∑ d∈p.image (G.degree ·),bonus s.card b d) ≤
      16*s.card.choose b + ∑ k∈s.powersetCard b,(FiniteRange.bad G s k).card := by
  classical
  let U := high G\p
  let s := U\W
  have ws : Disjoint W s := disjoint_left.mpr (fun _ vw vs => (mem_sdiff.mp vs).2 vw)
  have eq : W∪s=U := by rw [union_comm]; exact sdiff_union_of_subset wm
  let opts := s.powersetCard b
  have point (k : Finset V) (kr : k∈opts) : s.card-b+gain+(active G p (W∪k)).card ≤
      16+(FiniteRange.bad G s k).card := by
    obtain ⟨ks,sz⟩ := mem_powersetCard.mp kr
    have wk : Disjoint W k := ws.mono_right ks
    have ks' : W∪k⊆U := eq ▸ union_subset subset_union_left (ks.trans subset_union_right)
    have num := CliqueSample.trial G ch (W∪k) ks' fail
    let weightAt (i : V) := LowSample.weight (LowSample.anchors G i).card
    have sub : ({y,z} : Finset V) ⊆ LowSample.eligible G (W∪k) := by
      apply insert_subset (mem_filter.mpr ⟨yt,ya.trans subset_union_left⟩)
      exact singleton_subset_iff.mpr (mem_filter.mpr ⟨zt,za.trans subset_union_left⟩)
    have inc := sum_le_sum_of_subset_of_nonneg sub (f:=weightAt) (fun _ _ _ => Nat.zero_le _)
    have pair : (∑ i∈({y,z} : Finset V),weightAt i)=weightAt y+weightAt z := by simp [yz]
    rw [pair] at inc
    have earned := gain_le.trans inc
    have left : U\(W∪k)=s\k := by ext i; simp [s]; tauto
    have right : Uᶜ∪(W∪k)=sᶜ∪k := by ext i; simp [s,or_assoc]; tauto
    have bad : FiniteRange.bad G U (W∪k)=FiniteRange.bad G s k := by
      unfold FiniteRange.bad; rw [left,right]
    dsimp only at num
    change 6*(U.card-(W∪k).card)+ (∑ i∈LowSample.eligible G (W∪k),weightAt i) + _ ≤ 6*(_+(FiniteRange.bad G U (W∪k)).card) at num
    rw [t,bad,←eq,card_union_of_disjoint ws,card_union_of_disjoint wk,sz] at num
    omega
  have credit : (∑ d∈p.image (G.degree ·),bonus s.card b d) ≤ ∑ k∈opts,(active G p (W∪k)).card := by
    calc
      _ = ∑ v∈p,bonus s.card b (G.degree v) := sum_image (fun _ hx _ hy e => ch.unique hx hy e)
      _ ≤ ∑ v∈p,(opts.filter (fun k => v∈active G p (W∪k))).card := by
        apply sum_le_sum
        intro v vp
        have small := (mem_Icc.mp (ch.levels (mem_image_of_mem (G.degree ·) vp))).2
        apply fiber G vp (fun mem => (mem_sdiff.mp (mem_sdiff.mp mem).1).2 vp) (by change G.degree v≤9 at small; omega)
        rw [eq]; exact neighbors_in_pool G ch vp
      _ = ∑ v∈p,∑ k∈opts,(if v∈active G p (W∪k) then 1 else 0 : ℕ) := by simp
      _ = _ := by
        rw [sum_comm]; apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show active G p (W∪k)⊆p from filter_subset _ _)]
  have summed := sum_le_sum point
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,opts,card_powersetCard,Nat.cast_id] at summed
  dsimp only [opts] at credit
  change (s.card-b+gain)*s.card.choose b + _ ≤ 16*s.card.choose b + ∑ k∈s.powersetCard b,(FiniteRange.bad G s k).card
  rw [Nat.mul_comm (s.card-b+gain),Nat.mul_comm 16,Nat.mul_add]
  change (s.card.choose b)*(s.card-b)+s.card.choose b*gain+(∑ d∈p.image (G.degree ·),bonus s.card b d)≤_
  omega
/-- Retain all high anchors of two independent ears before sampling. -/
theorem balance {p W : Finset V} (ch : Choice G p Boundary.levels) {y z : V}
    (wm : W⊆high G\p) (yt : y∈twos G) (zt : z∈twos G) (yz : y≠z)
    (ya : LowSample.anchors G y⊆W) (za : LowSample.anchors G z⊆W)
    (yc : (LowSample.anchors G y).card=2) (zc : (LowSample.anchors G z).card=2)
    (t : (types G).card=33) (fail : bound G<gamma G) (b : ℕ)
    (room : 9≤((high G\p)\W).card) :
    let s := (high G\p)\W
    (s.card-b+2)*s.card.choose b + (∑ d∈p.image (G.degree ·),bonus s.card b d) ≤
      16*s.card.choose b + ∑ k∈s.powersetCard b,(FiniteRange.bad G s k).card := by
  exact weighted G ch wm yt zt yz ya za 2 (by simp [yc,zc,LowSample.weight]) t fail b room

end Graffiti384b.MultiEar34
#print axioms Graffiti384b.MultiEar34.balance
