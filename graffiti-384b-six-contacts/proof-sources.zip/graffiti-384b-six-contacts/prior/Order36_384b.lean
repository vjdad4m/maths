import BlockFinish384b

namespace Graffiti384b.Order36
open Finset SimpleGraph CliqueSample CliqueChoice LowSample
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def EvenRow (f : Finset ℕ) :=
  let m := 34-f.card
  12 ≤ m ∧ envelope m 12 ∧ reward m 12 ∧
    6*(17*m.choose 12+charge 36 34 m 12 f Boundary.levels) <
    6*(m-12)*m.choose 12 + 6*(m-2).choose 10 + 6*(∑ d ∈ f,bonus m 12 d)

set_option maxRecDepth 32768 in
set_option maxHeartbeats 8000000 in
private theorem even_rows : ∀ f ∈ Boundary.levels.powerset, EvenRow f := by
  unfold EvenRow envelope reward charge LowSample.delta LowSample.weight bonus slots FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

theorem exact36 (hc : G.Connected) (hn : 2 < Fintype.card V) (t : (types G).card=36) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨R,_,cap,_,_,same,_⟩ := Prune.prune_failure G hc hn fail
  have num : (types (G.induce (R : Set V))).card ≤ R.card := by
    simpa [types] using (card_image_le (s := (univ : Finset R)) (f := trianglesAt (G.induce (R : Set V))))
  rw [same,t] at num
  have hh := type_bound G
  have miss : ((high G).card+1)/2 < ((types G).card+1)/2 := Nat.lt_of_not_ge (fun le => (not_lt_of_ge (exact_of_high G le)) fail)
  have h : (high G).card=34 := by omega
  letI : Nonempty V := hc.nonempty
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  let f := p.image (G.degree ·)
  let m := 34-f.card
  obtain ⟨room,env,rew,win⟩ := even_rows f (mem_powerset.mpr ch.levels)
  have sz : (high G \ p).card=m := by dsimp [m,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub,h]
  have obs := CliqueSample.obstruction G ch 12 (sz ▸ room) (by decide) (sz ▸ env) (sz ▸ rew) fail
  dsimp only at obs
  rw [h,t] at obs
  change 6*(m-12)*m.choose 12 + (twos G).card*(6*(m-2).choose 10) + 6*(∑ d ∈ f,bonus m 12 d) ≤
    6*(17*m.choose 12+charge 36 34 m 12 f Boundary.levels) at obs
  change 6*(17*m.choose 12+charge 36 34 m 12 f Boundary.levels) <
    6*(m-12)*m.choose 12 + 6*(m-2).choose 10 + 6*(∑ d ∈ f,bonus m 12 d) at win
  have sub : high G ⊆ nonleaves G := fun v hv => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count : (twos G).card+(high G).card=(nonleaves G).card := card_sdiff_add_card_eq_card sub
  have low := Nat.mul_le_mul_right (6*(m-2).choose 10) (show 1 ≤ (twos G).card by omega)
  rw [Nat.one_mul] at low
  omega

theorem exact_of_at_least_36_types (hc : G.Connected) (hn : 2 < Fintype.card V) (t : 36 ≤ (types G).card) :
    gamma G ≤ bound G := by
  rcases t.eq_or_lt with e|hi
  · exact exact36 G hc hn e.symm
  · exact Order37.exact_of_at_least_37_types G hc hn hi

theorem nonleaf_cap (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    (nonleaves G).card ≤ 34 := by
  by_contra! q
  have hi : (types G).card < 36 := Nat.lt_of_not_ge (fun e => (not_lt_of_ge (exact_of_at_least_36_types G hc hn e)) bad)
  by_cases top : (types G).card=35
  · exact (not_lt_of_ge (BlockFinish.exact35 G top q)) bad
  by_cases member : (types G).card ∈ Lower.inputs
  · apply (not_lt_of_ge (Lower.exact_of_quota G hc member ?_)) bad
    simp only [Lower.inputs,mem_insert,mem_singleton] at member
    rcases member with e|e|e|e <;> simp [Lower.quota,e] <;> omega
  · by_cases many : 14 ≤ (types G).card
    · have cap := (nonleaf_profile G bad many (by omega)).1
      have rows : ∀ t : Fin 36, ∀ e : Fin 3, t.val ∉ Lower.inputs → (LowSample.row t e).1 ≤ 34 := by decide
      have lim := type_bound G
      exact (not_le_of_gt q) (cap.trans (rows ⟨(types G).card,hi⟩ ⟨(types G).card-(high G).card,by omega⟩ member))
    · have n := nonleaf_bound G
      unfold bound at bad
      omega

/-- The full set of triangle counts survives on a connected induced failure
of order at most 35. The statement applies before least-order normalization. -/
theorem bounded_failure (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) :
    ∃ r : Finset V, 2 < r.card ∧ r.card ≤ 35 ∧ (G.induce (r : Set V)).Connected ∧
      types (G.induce (r : Set V))=types G ∧ bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨r,_,size,ord,conn,same,fail⟩ := Prune.prune_failure G hc hn bad
  have lim := nonleaf_cap G hc hn bad
  exact ⟨r,ord,by omega,conn,same,fail⟩

theorem all_distinct_induced (hc : G.Connected) (hn : 2 < Fintype.card V) (bad : bound G < gamma G) (t : (types G).card=35) :
    ∃ r : Finset V, r.card=35 ∧ (G.induce (r : Set V)).Connected ∧ types (G.induce (r : Set V))=types G ∧
      Function.Injective (trianglesAt (G.induce (r : Set V))) ∧ bound (G.induce (r : Set V)) < gamma (G.induce (r : Set V)) := by
  obtain ⟨r,_,cap,conn,same,fail⟩ := bounded_failure G hc hn bad
  let J := G.induce (r : Set V)
  have size : (types J).card=35 := by change (types (G.induce (r : Set V))).card=35; rw [same,t]
  have num : (types J).card ≤ r.card := by simpa [types] using (card_image_le (s := (univ : Finset r)) (f := trianglesAt J))
  have order : r.card=35 := by omega
  have inj := card_image_iff.mp (show ((univ : Finset r).image (trianglesAt J)).card=univ.card by
    change (types J).card = _; rw [card_univ]; exact size.trans (order.symm.trans (Fintype.card_coe r).symm))
  exact ⟨r,order,conn,same,fun _ _ eq => inj (mem_univ _) (mem_univ _) eq,fail⟩

theorem minimum_order (res : Minimal.Residual G) : Fintype.card V ≤ 35 := by
  obtain ⟨⟨hn,_⟩,hc,fail,_,_,_,_,_,least⟩ := res
  obtain ⟨r,ord,cap,conn,_,bad⟩ := bounded_failure G hc hn fail
  exact (least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord,conn,bad⟩).trans cap

/-- The top remaining order has one leaf and only two possible diversities. -/
theorem order35_profile (res : Minimal.Residual G) (n : Fintype.card V=35) :
    (nonleaves G).card=34 ∧ ((types G).card=33 ∨ (types G).card=35) := by
  obtain ⟨_,_,hi,odd,_⟩ := Lower.residual_range G res
  obtain ⟨⟨hn,_⟩,hc,bad,_,_,_,_,_,least⟩ := res
  obtain ⟨r,_,cap,ord,conn,_,fail⟩ := Prune.prune_failure G hc hn bad
  have le := least r.card ⟨r,inferInstance,inferInstance,_,inferInstance,Fintype.card_coe _,ord,conn,fail⟩
  have q := nonleaf_cap G hc hn bad
  have qeq : (nonleaves G).card=34 := by omega
  refine ⟨qeq,?_⟩
  by_contra! rest
  have small : (types G).card < 33 := by omega
  by_cases member : (types G).card ∈ Lower.inputs
  · apply (not_lt_of_ge (Lower.exact_of_quota G hc member ?_)) bad
    simp only [Lower.inputs,mem_insert,mem_singleton] at member
    rcases member with e|e|e|e <;> simp [Lower.quota,e,qeq] <;> omega
  · by_cases many : 14 ≤ (types G).card
    · have cap' := (nonleaf_profile G bad many (by omega)).1
      have rows : ∀ t : Fin 33, ∀ e : Fin 3, t.val ∉ Lower.inputs → (LowSample.row t e).1 ≤ 33 := by decide
      have lim := type_bound G
      have num := cap'.trans (rows ⟨(types G).card,small⟩ ⟨(types G).card-(high G).card,by omega⟩ member)
      omega
    · have num := nonleaf_bound G
      unfold bound at bad
      omega

/-- Exact ceiling of the second sampling estimate on the h=33, d=7 row
with one degree-two vertex, for every supported sample size. -/
theorem one_ear_ceiling : ∀ k : Fin 33, 7 ≤ k.val →
    let b := k.val
    let den := Nat.choose 32 b
    let credited := (32-b)*den + Nat.choose 30 (b-2) +
      BlockFibers.income 32 b 7 2 + 7*BlockFinish.rebate 32 b
    let charged := 17*den + BlockLoss.chargeAt 32 b (BlockFinish.slotsAfter 33 ∅ 7)
    490854*credited + 47945*den ≤ 490854*charged ∧
      (b=12 → 490854*credited + 47945*den = 490854*charged) := by
  unfold BlockFibers.income BlockFinish.rebate BlockLoss.chargeAt BlockFinish.slotsAfter
    BlockActivation.localCount slots LowSample.delta FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  set_option maxRecDepth 32768 in
    set_option maxHeartbeats 8000000 in decide

end Graffiti384b.Order36
#print axioms Graffiti384b.Order36.exact_of_at_least_36_types
#print axioms Graffiti384b.Order36.nonleaf_cap
#print axioms Graffiti384b.Order36.bounded_failure
#print axioms Graffiti384b.Order36.all_distinct_induced
#print axioms Graffiti384b.Order36.minimum_order
#print axioms Graffiti384b.Order36.order35_profile
#print axioms Graffiti384b.Order36.one_ear_ceiling
