import RankMixed384b
import RankUniform384b

namespace Graffiti384b.Order37
open Finset SimpleGraph CliqueChoice LowSample RankTable
open private LowSample.two_degree from LowSample384b
open private Prune.links Prune.link_in_core Prune.outside_zero from Prune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem ear_geometry {p : Finset V} (ch : Choice G p Boundary.levels)
    (n : Fintype.card V=37) (q : (nonleaves G).card=36) (h : 35 ≤ (high G).card)
    (inj : Function.Injective (trianglesAt G)) :
    (twos G).card=36-(high G).card ∧ ∀ v ∈ twos G, G.neighborFinset v ⊆ high G \ p := by
  have hs : high G ⊆ nonleaves G := by
    intro z hz
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hz).2; omega⟩
  have sz : (twos G).card=36-(high G).card := (card_sdiff hs).trans (by rw [q])
  refine ⟨sz,?_⟩
  intro v vt
  have vdeg := LowSample.two_degree G vt
  have out : (nonleaves G)ᶜ.Nonempty := by apply card_pos.mp; rw [card_compl,n,q]; decide
  obtain ⟨z,zo⟩ := out
  have pos : 0 < trianglesAt G v := by
    apply Nat.pos_of_ne_zero
    intro zc
    have uz := inj (zc.trans (Prune.outside_zero G (mem_compl.mp zo)).symm)
    exact mem_compl.mp zo (uz ▸ (mem_sdiff.mp vt).1)
  obtain ⟨e,he⟩ := card_pos.mp (show 0 < (Prune.links G v).card from pos)
  have pair := mem_powersetCard.mp (mem_filter.mp he).1
  have all : e=G.neighborFinset v := eq_of_subset_of_card_le pair.1 (by rw [pair.2,card_neighborFinset_eq_degree,vdeg])
  intro u uv
  have non := Prune.link_in_core G he (show u ∈ e from all ▸ uv)
  have edge := (G.mem_neighborFinset _ _).mp uv
  have hu : u ∈ high G := by
    by_contra nu
    have ut : u ∈ twos G := mem_sdiff.mpr ⟨non,nu⟩
    exact edge.ne (card_le_one.mp (show (twos G).card≤1 by omega) v vt u ut)
  exact mem_sdiff.mpr ⟨hu,fun up =>
    (mem_sdiff.mp vt).2 (mem_sdiff.mp (neighbors_in_pool G ch up ((G.mem_neighborFinset _ _).mpr edge.symm))).1⟩

/-- The 42 verified numerical rows cover all normalized graphs surviving
the six-profile reduction. -/
theorem normalized {p : Finset V} (ch : Choice G p Boundary.levels) (n : Fintype.card V=37)
    (t : (types G).card=37) (q : (nonleaves G).card=36) (hs : (high G).card=35 ∨ (high G).card=36)
    (ij : Function.Injective (trianglesAt G)) (five : ¬G.CliqueFree 5)
    (rem : RankProfiles.residual (high G).card (p.image (G.degree ·))) : gamma G ≤ bound G := by
  let h := (high G).card
  let f := p.image (G.degree ·)
  let s := high G \ p
  obtain ⟨ears,inner⟩ := ear_geometry G ch n q (by omega) ij
  obtain ⟨size,allowed,high,limited⟩ := RankStructure.pool_data G ch n t q hs ij
  obtain ⟨C,cs,cl,cc,maximal,free⟩ := RankStructure.choose_clique G ch five
  let c := C.card
  have inj : Set.InjOn (trianglesAt G) (s : Set V) := fun _ _ _ _ eq => ij eq
  have degs (v : V) (vs : v ∈ s) := RankDegrees.valid G h c s f hs rem cc size inj allowed high limited free vs
  have table := RankTable.coverage h c f hs rem cc
  have smallF : f.card ≤ 7 := (card_le_card ch.levels).trans_eq (by decide : Boundary.levels.card=7)
  have lo := (mem_Icc.mp cc).1
  have hi := (mem_Icc.mp cc).2
  have big : 11 < (s \ C).card := by
    rw [card_sdiff cs,size]
    change h=35 ∨ h=36 at hs
    change 11 < h-f.card-c
    change c ≤ 10 at hi
    omega
  by_cases special : c=4 ∧ 4 ∈ f
  · rw [certificate,if_pos special] at table
    exact RankUniform.apply_row G ch t ears inner ij ⟨4,special.2⟩
      (big.trans_le (card_le_card sdiff_subset)) c _ degs table
  · rw [certificate,if_neg special] at table
    exact RankMixed.apply_row G ch hs t ears inner cs cl hi maximal ij limited big degs _ table

/-- Graffiti.pc #384b holds at diversity 37 at every order. -/
theorem exact_of_37_types (connected : G.Connected) (n : 2 < Fintype.card V)
    (t : (types G).card=37) : gamma G ≤ bound G := by
  by_contra! fail
  obtain ⟨R,num,_,same,inj,bad,five,q,h,p,ch,rem⟩ := RankBoundary.reduced_failure G connected n fail t
  let J := G.induce (R : Set V)
  have nJ : Fintype.card (R : Set V)=37 := by simpa using num
  have tJ : (types J).card=37 := by change (types (G.induce (R : Set V))).card=37; rw [same,t]
  have hh : (high J).card=35 ∨ (high J).card=36 := by simpa only [mem_insert,mem_singleton] using h
  exact (not_lt_of_ge (normalized J ch nJ tJ q hh inj five rem)) bad

/-- Combining the boundary theorem with the previous 38-and-up cutoff. -/
theorem exact_of_at_least_37_types (connected : G.Connected) (n : 2 < Fintype.card V)
    (t : 37 ≤ (types G).card) : gamma G ≤ bound G := by
  rcases t.eq_or_lt with eq | larger
  · exact exact_of_37_types G connected n eq.symm
  · exact Boundary.exact_of_at_least_thirty_eight G connected n larger

/-- A normalized least-order counterexample has odd diversity from 7
through 35 and order at most 37. -/
theorem residual_range (res : Minimal.Residual G) :
    Fintype.card V ≤ 37 ∧ 7 ≤ (types G).card ∧ (types G).card ≤ 35 ∧ (types G).card%2=1 := by
  have order := Joint.minimum_order G res
  obtain ⟨⟨n,_⟩,connected,fail,_,odd,low,_⟩ := res
  have upper : ¬ 37 ≤ (types G).card := fun h => (not_lt_of_ge (exact_of_at_least_37_types G connected n h)) fail
  exact ⟨order,low,by omega,odd⟩

end Graffiti384b.Order37
#print axioms Graffiti384b.Order37.normalized
#print axioms Graffiti384b.Order37.exact_of_37_types
#print axioms Graffiti384b.Order37.exact_of_at_least_37_types
#print axioms Graffiti384b.Order37.residual_range
