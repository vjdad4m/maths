import CliqueCut34_384b

namespace Graffiti384b.Overlap34
open Finset SimpleGraph LowSample
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem clique_deg {C : Finset V} (cl : G.IsNClique 5 C) {v : V} (vc : v∈C) : 4≤G.degree v := by
  have inc : C.erase v⊆G.neighborFinset v := fun j jm => (G.mem_neighborFinset _ _).mpr
    (cl.1 vc (mem_erase.mp jm).2 (mem_erase.mp jm).1.symm)
  have num := card_le_card inc
  rwa [card_erase_of_mem vc,cl.2,card_neighborFinset_eq_degree] at num

def forwardSet (C A K : Finset V) :=
  (high G\(C∪A)).filter (fun v => G.degree v+nbr G v (K∪A)<3+nbr G v (C\K))

/-- Keep both ear anchors and a clique pair covering their overlap. The
complementary clique triple and the ear can all be omitted. -/
theorem forward {C A K : Finset V} {y : V} (cl : G.IsNClique 5 C) (ears : twos G={y})
    (anc : A=G.neighborFinset y) (ah : A⊆high G) (ks : K⊆C) (kc : K.card=2)
    (over : C∩A⊆K) (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    1+(C∩A).card≤(forwardSet G C A K).card := by
  let X := insert y (C\K)
  let P := K∪A
  have yt : y∈twos G := ears ▸ mem_singleton_self _
  have yn := (mem_sdiff.mp yt).1
  have yh := (mem_sdiff.mp yt).2
  have ch : C⊆high G := fun v vm => mem_filter.mpr ⟨mem_univ _,by have := clique_deg G cl vm; omega⟩
  have hn : high G⊆nonleaves G := fun v vm => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp vm).2; omega⟩
  have ac : A.card=2 := by rw [anc,card_neighborFinset_eq_degree,LowSample.two_degree G yt]
  have ph : P⊆high G := union_subset (ks.trans ch) ah
  have xn : X⊆nonleaves G := insert_subset yn (sdiff_subset.trans (ch.trans hn))
  have dis : Disjoint X P := disjoint_left.mpr (by
    intro v vx vp
    rcases mem_insert.mp vx with rfl|outside
    · exact yh (ph vp)
    obtain ⟨vc,vk⟩ := mem_sdiff.mp outside
    exact (mem_union.mp vp).elim vk (fun va => vk (over (mem_inter.mpr ⟨vc,va⟩))))
  have hit (v : V) (vx : v∈X) : 2≤nbr G v P := by
    rcases mem_insert.mp vx with rfl|dif
    · have sub : A⊆P.filter (G.Adj v) := fun j jm => mem_filter.mpr ⟨mem_union_right _ jm,(G.mem_neighborFinset _ _).mp (anc ▸ jm)⟩
      exact ac ▸ card_le_card sub
    · have sub : K⊆P.filter (G.Adj v) := fun j jm => mem_filter.mpr ⟨mem_union_left _ jm,cl.1 (mem_sdiff.mp dif).1 (ks jm)
        (fun e => (mem_sdiff.mp dif).2 (e ▸ jm))⟩
      exact kc ▸ card_le_card sub
  have obs := CliqueCut34.pin_obstruction G (ph.trans hn) xn dis hit same fail
  have xc : X.card=4 := by
    rw [show X=insert y (C\K) from rfl,card_insert_of_not_mem (fun vm => yh (ch (mem_sdiff.mp vm).1)),card_sdiff ks,cl.2,kc]
  have inter : K∩A=C∩A := Subset.antisymm (fun j jm => mem_inter.mpr ⟨ks (mem_inter.mp jm).1,(mem_inter.mp jm).2⟩)
    (fun j jm => mem_inter.mpr ⟨over jm,(mem_inter.mp jm).2⟩)
  have pc := card_union_add_card_inter K A
  change P.card+(K∩A).card=_ at pc
  rw [inter,kc,ac] at pc
  have sub : CliqueCut34.defects G P X⊆forwardSet G C A K := by
    intro v vm
    obtain ⟨out,lt⟩ := mem_filter.mp vm
    obtain ⟨vn,far⟩ := mem_sdiff.mp out
    have vx : v∉X := fun m => far (mem_union_left _ m)
    have vp : v∉P := fun m => far (mem_union_right _ m)
    have va : v∉A := fun m => vp (mem_union_right _ m)
    have vc : v∉C := by
      intro inside
      by_cases k : v∈K
      · exact vp (mem_union_left _ k)
      · exact vx (mem_insert_of_mem (mem_sdiff.mpr ⟨inside,k⟩))
    have vh : v∈high G := by
      by_contra no
      have ee : v∈twos G := mem_sdiff.mpr ⟨vn,no⟩
      rw [ears,mem_singleton] at ee
      exact vx (ee ▸ mem_insert_self ..)
    have no : ¬G.Adj v y := fun edge => va (anc ▸ (G.mem_neighborFinset _ _).mpr edge.symm)
    have row : X.filter (G.Adj v)=(C\K).filter (G.Adj v) := by simp only [X,filter_insert,if_neg no]
    have nx : nbr G v X=nbr G v (C\K) := congrArg card row
    exact mem_filter.mpr ⟨mem_sdiff.mpr ⟨vh,fun m => (mem_union.mp m).elim vc va⟩,by rw [←nx]; exact lt⟩
  have le := card_le_card sub
  omega
end Graffiti384b.Overlap34
#print axioms Graffiti384b.Overlap34.forward
