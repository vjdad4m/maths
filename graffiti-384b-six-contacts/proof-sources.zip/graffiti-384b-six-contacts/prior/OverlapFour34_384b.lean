import OverlapReverse34_384b

namespace Graffiti384b.Overlap34
open Finset SimpleGraph LowSample
open private Repair.nbr_add Repair.full_nbr from Repair384b
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- If both anchors of the sole ear are in a five-clique, at least four
exterior vertices have degree three, four or five. -/
theorem four {C : Finset V} {y : V} (cl : G.IsNClique 5 C) (ears : twos G={y})
    (inc : G.neighborFinset y⊆C) (n : Fintype.card V=34) (t : (types G).card=33)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    4≤((high G\C).filter (fun v => G.degree v≤5)).card := by
  let A := G.neighborFinset y
  let B := C\A
  let L := (high G\C).filter (fun v => G.degree v≤5)
  let F := forwardSet G C A A
  have yt : y∈twos G := ears ▸ mem_singleton_self _
  have ac : A.card=2 := (card_neighborFinset_eq_degree _ _).trans (LowSample.two_degree G yt)
  have bc : B.card=3 := by rw [show B=C\A from rfl,card_sdiff inc,cl.2,ac]
  have ah : A⊆high G := fun v va => mem_filter.mpr ⟨mem_univ _,by have := clique_deg G cl (inc va); omega⟩
  have need := forward G cl ears (A:=A) rfl ah inc ac inter_subset_right same fail
  rw [inter_eq_right.mpr inc,ac] at need
  change 1+2≤F.card at need
  have form (v : V) (vf : v∈F) : v∈high G\C ∧ G.degree v+nbr G v A<3+nbr G v B := by
    obtain ⟨outside,lt⟩ := mem_filter.mp vf
    rw [union_self] at lt
    exact ⟨mem_sdiff.mpr ⟨(mem_sdiff.mp outside).1,fun m => (mem_sdiff.mp outside).2 (mem_union_left _ m)⟩,lt⟩
  have fl : F⊆L := by
    intro v vf
    obtain ⟨vh,lt⟩ := form v vf
    have cap : nbr G v B≤3 := (card_filter_le _ _).trans_eq bc
    exact mem_filter.mpr ⟨vh,by omega⟩
  by_contra! few
  change L.card<4 at few
  have eq := eq_of_subset_of_card_le fl (by omega)
  let S := L.filter (fun r => G.degree r=3 ∧ G.neighborFinset r⊆C ∧ nbr G r B=2)
  have sameS (r : V) (rs : r∈S) : trianglesAt G r=3 := by
    obtain ⟨_,d,sub,_⟩ := mem_filter.mp rs
    unfold trianglesAt
    rw [filter_true_of_mem (fun e em i ie j je ne => cl.1 (sub ((mem_powersetCard.mp em).1 ie)) (sub ((mem_powersetCard.mp em).1 je)) ne),
      card_powersetCard,card_neighborFinset_eq_degree,d]
    decide
  have sc := fibre G n t sameS
  let miss (r : V) := B.filter (fun i => ¬G.Adj r i)
  have cover : B⊆S.biUnion miss := by
    intro i ib
    obtain ⟨r,rh,lt⟩ := reverse G cl ears rfl ac inc ib same fail
    change G.degree r+(if G.Adj r i then 1 else 0)<3+nbr G r A at lt
    have low := (mem_filter.mp (mem_sdiff.mp rh).1).2
    have aa : nbr G r A≤2 := (card_filter_le _ _).trans_eq ac
    have bb : nbr G r B≤3 := (card_filter_le _ _).trans_eq bc
    have add := Repair.nbr_add G r (show Disjoint B A from disjoint_left.mpr (fun _ m => (mem_sdiff.mp m).2))
    rw [sdiff_union_of_subset inc] at add
    have total := Repair.full_nbr G r C
    have rl : r∈L := mem_filter.mpr ⟨rh,by split at lt <;> omega⟩
    have rf : r∈F := by rw [eq]; exact rl
    have fwd := (form r rf).2
    have data : G.degree r=3 ∧ nbr G r A=1 ∧ nbr G r B=2 ∧ ¬G.Adj r i := by
      by_cases edge : G.Adj r i
      · rw [if_pos edge] at lt
        omega
      · rw [if_neg edge] at lt
        exact ⟨by omega,by omega,by omega,edge⟩
    obtain ⟨d,a,b,no⟩ := data
    have empty : Cᶜ.filter (G.Adj r)=∅ := card_eq_zero.mp (show nbr G r Cᶜ=0 by omega)
    have sub : G.neighborFinset r⊆C := by
      intro j jm
      by_contra jc
      exact filter_eq_empty_iff.mp empty (mem_compl.mpr jc) ((G.mem_neighborFinset _ _).mp jm)
    exact mem_biUnion.mpr ⟨r,mem_filter.mpr ⟨rl,d,sub,b⟩,mem_filter.mpr ⟨ib,no⟩⟩
  have size (r : V) (rs : r∈S) : (miss r).card=1 := by
    have two := (mem_filter.mp rs).2.2.2
    have count := filter_card_add_filter_neg_card_eq_card (s:=B) (G.Adj r)
    change nbr G r B+(miss r).card=B.card at count
    omega
  have cap := (card_le_card cover).trans card_biUnion_le
  have sum : (∑ r∈S,(miss r).card)=S.card := by
    rw [sum_congr rfl size]; simp
  omega

end Graffiti384b.Overlap34
#print axioms Graffiti384b.Overlap34.four
