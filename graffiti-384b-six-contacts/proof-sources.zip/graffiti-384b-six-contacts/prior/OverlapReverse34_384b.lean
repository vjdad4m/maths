import Overlap34_384b

namespace Graffiti384b.Overlap34
open Finset SimpleGraph LowSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- With both anchors inside the clique, keeping the ear and one of the
other three clique vertices allows us to omit both ear anchors. -/
theorem reverse {C A : Finset V} {y t : V} (cl : G.IsNClique 5 C) (ears : twos G={y})
    (anc : A=G.neighborFinset y) (ac : A.card=2) (inc : A⊆C) (tm : t∈C\A)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    ∃ r∈high G\C, G.degree r+(if G.Adj r t then 1 else 0)<3+nbr G r A := by
  let P : Finset V := {y,t}
  have yt : y∈twos G := ears ▸ mem_singleton_self _
  have tc := (mem_sdiff.mp tm).1
  have ta := (mem_sdiff.mp tm).2
  have ch : C⊆high G := fun v vm => mem_filter.mpr ⟨mem_univ _,by have := clique_deg G cl vm; omega⟩
  have hn : high G⊆nonleaves G := fun v vm => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp vm).2; omega⟩
  have yc : y∉C := fun m => (mem_sdiff.mp yt).2 (ch m)
  have ne : y≠t := fun h => yc (h ▸ tc)
  have pn : P⊆nonleaves G := insert_subset (mem_sdiff.mp yt).1 (singleton_subset_iff.mpr (hn (ch tc)))
  have dis : Disjoint A P := disjoint_left.mpr (by
    intro v va vp
    rcases mem_insert.mp vp with rfl|eq
    · exact yc (inc va)
    · exact ta ((mem_singleton.mp eq) ▸ va))
  have hit (v : V) (va : v∈A) : 2≤nbr G v P := by
    have vy := ((G.mem_neighborFinset _ _).mp (anc ▸ va)).symm
    have vt := cl.1 (inc va) tc (fun e => ta (e ▸ va))
    have allP : P.filter (G.Adj v)=P := filter_true_of_mem (fun j jm => by
      rcases mem_insert.mp jm with rfl|eq
      · exact vy
      · exact mem_singleton.mp eq ▸ vt)
    rw [nbr,allP,show P.card=2 from card_pair ne]
  have obs := CliqueCut34.pin_obstruction G pn (inc.trans (ch.trans hn)) dis hit same fail
  rw [ac,show P.card=2 from card_pair ne] at obs
  obtain ⟨r,rm⟩ := card_pos.mp (show 0<(CliqueCut34.defects G P A).card by omega)
  obtain ⟨rr,short⟩ := mem_filter.mp rm
  obtain ⟨rn,out⟩ := mem_sdiff.mp rr
  have ra : r∉A := fun k => out (mem_union_left _ k)
  have rp : r∉P := fun k => out (mem_union_right _ k)
  have rt : r≠t := fun eq => rp (eq ▸ mem_insert_of_mem (mem_singleton_self _))
  have rh : r∈high G := by
    by_contra low
    have re : r∈twos G := mem_sdiff.mpr ⟨rn,low⟩
    rw [ears,mem_singleton] at re
    exact rp (re ▸ mem_insert_self ..)
  have ry : ¬G.Adj r y := fun e => ra (anc ▸ (G.mem_neighborFinset _ _).mpr e.symm)
  have count : nbr G r P=(if G.Adj r t then 1 else 0) := by
    by_cases edge : G.Adj r t <;> simp [nbr,P,filter_insert,filter_singleton,ry,edge]
  rw [count] at short
  have aa : nbr G r A≤2 := (card_filter_le _ _).trans_eq ac
  refine ⟨r,mem_sdiff.mpr ⟨rh,?_⟩,short⟩
  intro rc
  rw [if_pos (cl.1 rc tc rt)] at short
  have := clique_deg G cl rc
  omega

/-- For 34 vertices with 33 triangle-count values, a level set has size
at most two. -/
theorem fibre {S : Finset V} {k : ℕ} (n : Fintype.card V=34) (t : (types G).card=33)
    (same : ∀ v∈S,trianglesAt G v=k) : S.card≤2 := by
  let T := univ\S
  have cov : types G⊆insert k (T.image (trianglesAt G)) := by
    intro j jm
    obtain ⟨v,_,rfl⟩ := mem_image.mp jm
    by_cases vs : v∈S
    · exact mem_insert.mpr (Or.inl (same v vs))
    · exact mem_insert_of_mem (mem_image.mpr ⟨v,mem_sdiff.mpr ⟨mem_univ _,vs⟩,rfl⟩)
  have le := (card_le_card cov).trans (card_insert_le ..)
  have sl : (T.image (trianglesAt G)).card≤T.card := card_image_le
  have num : T.card+S.card=34 := by
    rw [show T=univ\S from rfl,card_sdiff_add_card_eq_card (subset_univ S),card_univ,n]
  omega
end Graffiti384b.Overlap34
#print axioms Graffiti384b.Overlap34.reverse
#print axioms Graffiti384b.Overlap34.fibre
