import PairLayout
namespace Graffiti384b.PairMix.Layout
open Finset SimpleGraph Thin28 HighSquare28 EarMix
open private Repair.nbr_add from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj] (M : Layout G)

theorem pool_cost {w : V} (wm : w∈M.W) (s : ℕ) :
    M.total (hit G M.W) s w≤exterior (nbr G w M.W) (nbr G w M.A) (nbr G w M.B) s := by
  have ne := M.nowhere wm
  have nf := M.flip.nowhere wm
  change ¬G.Adj w M.f at nf
  have hp : nbr G w M.P=0 := by simp [P,nbr,filter_insert,filter_singleton,ne,nf]
  have hq : nbr G w M.Q=nbr G w M.A := by simp [Q,nbr,filter_union,filter_singleton,nf]
  have hq' : nbr G w M.flip.Q=nbr G w M.B := by simp [Q,flip,nbr,filter_union,filter_singleton,ne]
  have hr : nbr G w M.R=nbr G w M.A+nbr G w M.B := Repair.nbr_add G w M.ab
  have p := bill_bound G M.across.1 wm (10-s)
  have q := bill_bound G M.across.2.1 wm (9-s)
  have q' := bill_bound G M.flip.across.2.1 (show w∈M.flip.W from wm) (9-s)
  have r := bill_bound G M.across.2.2 wm (8-s)
  change hit G M.W M.flip.Q _ w ≤ bill M.W.card _ (nbr G w M.W) (nbr G w M.flip.Q) at q'
  rw [M.ws,hp] at p; rw [M.ws,hq] at q; rw [M.ws,hq'] at q'; rw [M.ws,hr] at r
  unfold total exterior; omega

theorem activation {w : V} (wm : w∈M.W) (sat : trianglesAt G w=(G.degree w).choose 2) :
    allSelected≤M.total (gain G M.W) 0 w+M.total (hit G M.W) 1 w := by
  have a := active_fiber G wm (fun h => disjoint_left.mp M.across.1 h wm) sat 9
  have b := active_fiber G wm (fun h => disjoint_left.mp M.across.2.1 h wm) sat 8
  have c := active_fiber G wm (fun h => disjoint_left.mp M.flip.across.2.1 h wm) sat 8
  have d := active_fiber G wm (fun h => disjoint_left.mp M.across.2.2 h wm) sat 7
  rw [M.ws] at a b c d
  unfold allSelected total
  simp only [Nat.reduceSub,Nat.sub_zero,Nat.reduceAdd] at *
  omega

theorem side_cost {w : V} (wm : w∈M.A) : M.total (hit G M.W) 0 w≤side (nbr G w M.W) (nbr G w M.B) := by
  have out : w∉M.W := fun m => disjoint_left.mp M.wa m wm
  have ew : M.e∉M.W := fun m => M.ew (M.wh m)
  have we := (M.edge_facts wm).1
  have p := credited G (W:=M.W) (b:=10) (P:=M.P) (mem_insert_self M.e {M.f}) ew we
  rw [M.ws,if_neg out] at p
  have kq := kept G (W:=M.W) (b:=9) (show w∈M.Q from mem_union_left _ wm)
  have kr := kept G (W:=M.W) (b:=8) (show w∈M.R from mem_union_left _ wm)
  have ep : M.e∈M.flip.Q := mem_union_right _ (mem_singleton_self _)
  have mB : M.B⊆M.flip.Q := subset_union_left
  have q : hit G M.W M.flip.Q 9 w≤(if nbr G w M.B=0 then (23-nbr G w M.W).choose 9 else 0) := by
    split
    · simpa [M.ws,out] using (credited G (W:=M.W) (b:=9) ep ew we)
    · rename_i non
      obtain ⟨x,xm⟩ := card_pos.mp (Nat.pos_of_ne_zero non)
      obtain ⟨xb,wx⟩ := mem_filter.mp xm
      have et : M.e∉M.B := fun b => M.ew (M.flip.ah b)
      exact (covered G (W:=M.W) (b:=9) (fun h : M.e=x => et (h ▸ xb)) we wx ep (mB xb)).le
  unfold total side
  simp only [Nat.sub_zero] at *
  omega
end Graffiti384b.PairMix.Layout
#print axioms Graffiti384b.PairMix.Layout.pool_cost
#print axioms Graffiti384b.PairMix.Layout.side_cost
#print axioms Graffiti384b.PairMix.Layout.activation
