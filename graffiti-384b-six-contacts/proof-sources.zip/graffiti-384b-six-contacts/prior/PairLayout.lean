import SimplicialCredit30
import PairRows
namespace Graffiti384b.PairMix
open Finset SimpleGraph Thin28 HighSquare28
open private Repair.nbr_add Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

structure Layout where
  H : Finset V
  W : Finset V
  A : Finset V
  B : Finset V
  e : V
  f : V
  full : (univ : Finset V)=insert e (insert f H)
  part : H=W∪(A∪B)
  ws : W.card=23
  asz : A.card=2
  bsz : B.card=2
  ew : e∉H
  fw : f∉H
  ef : e≠f
  wa : Disjoint W A
  wb : Disjoint W B
  ab : Disjoint A B
  ea : G.neighborFinset e=A
  fb : G.neighborFinset f=B
  inj : Set.InjOn (trianglesAt G) (H:Set V)
  rich : ∀v∈H,2≤trianglesAt G v
  cap : ∀v∈A∪B,trianglesAt G v≤12

namespace Layout
variable {G} (M : Layout G)

def flip : Layout G where
  H:=M.H; W:=M.W; A:=M.B; B:=M.A; e:=M.f; f:=M.e
  full:=M.full.trans (by rw [insert_comm])
  part:=M.part.trans (by rw [union_comm M.A M.B])
  ws:=M.ws; asz:=M.bsz; bsz:=M.asz; ew:=M.fw; fw:=M.ew; ef:=M.ef.symm
  wa:=M.wb; wb:=M.wa; ab:=M.ab.symm; ea:=M.fb; fb:=M.ea; inj:=M.inj; rich:=M.rich
  cap:=by rw [union_comm M.B M.A]; exact M.cap

def P : Finset V := {M.e,M.f}
def Q := M.A ∪ {M.f}
def R := M.A ∪ M.B
def total (F : Finset V→ℕ→V→ℕ) (s : ℕ) (v : V) :=
  F M.P (10-s) v+3*(F M.Q (9-s) v+F M.flip.Q (9-s) v)+5*F M.R (8-s) v

theorem rotate (F : Finset V→ℕ→V→ℕ) (s : ℕ) (v : V) : M.total F s v=M.flip.total F s v := by
  simp only [total,P,Q,R,flip,add_comm (F (M.A∪{M.f}) (9-s) v) _,
    union_comm M.A M.B,pair_comm M.e M.f]

theorem wh : M.W⊆M.H := M.part ▸ subset_union_left
theorem ah : M.A⊆M.H := M.part ▸ (subset_union_left.trans subset_union_right)
theorem size : M.H.card=27 := by
  rw [M.part,card_union_of_disjoint (disjoint_union_right.mpr ⟨M.wa,M.wb⟩),
    card_union_of_disjoint M.ab,M.ws,M.asz,M.bsz]
theorem across : Disjoint M.P M.W ∧ Disjoint M.Q M.W ∧ Disjoint M.R M.W := by
  have out {x : V} (h : x∉M.H) : x∉M.W := fun m => h (M.wh m)
  exact ⟨disjoint_insert_left.mpr ⟨out M.ew,disjoint_singleton_left.mpr (out M.fw)⟩,
    disjoint_union_left.mpr ⟨M.wa.symm,disjoint_singleton_left.mpr (out M.fw)⟩,
    disjoint_union_left.mpr ⟨M.wa.symm,M.wb.symm⟩⟩
theorem whigh (v : V) : nbr G v M.H=nbr G v M.W+(nbr G v M.A+nbr G v M.B) := by
  rw [M.part,Repair.nbr_add G v (disjoint_union_right.mpr ⟨M.wa,M.wb⟩),Repair.nbr_add G v M.ab]
theorem nowhere {w : V} (wm : w∈M.W) : ¬G.Adj w M.e := fun h => disjoint_left.mp M.wa wm
  (M.ea ▸ (G.mem_neighborFinset ..).mpr h.symm)
theorem edge_facts {w : V} (wa : w∈M.A) : G.Adj w M.e ∧ ¬G.Adj w M.f := by
  exact ⟨((G.mem_neighborFinset ..).mp (M.ea.symm ▸ wa)).symm,
    fun h => disjoint_left.mp M.ab wa (M.fb ▸ (G.mem_neighborFinset ..).mpr h.symm)⟩
theorem exterior_degree {w : V} (wm : w∈M.W) : G.degree w=nbr G w M.H := by
  have eq : G.neighborFinset w=M.H.filter (G.Adj w) := by
    ext z; simp only [mem_neighborFinset,mem_filter]
    constructor
    · intro edge
      have m := mem_univ z; rw [M.full] at m
      rcases mem_insert.mp m with rfl|m
      · exact (M.nowhere wm edge).elim
      rcases mem_insert.mp m with rfl|m
      · exact (M.flip.nowhere wm edge).elim
      exact ⟨m,edge⟩
    · exact And.right
  simpa only [card_neighborFinset_eq_degree,nbr] using congrArg card eq

theorem side_score {w : V} (wa : w∈M.A) : trianglesAt G w≤(nbr G w M.H).choose 2+1 := by
  classical
  obtain ⟨we,wf⟩ := M.edge_facts wa
  let D := M.H.filter (G.Adj w)
  have ne : M.e∉D := fun m => M.ew (mem_filter.mp m).1
  have eq : G.neighborFinset w=insert M.e D := by
    ext z; simp only [mem_neighborFinset,mem_insert,mem_filter,D]
    constructor
    · intro edge
      have m := mem_univ z; rw [M.full] at m
      rcases mem_insert.mp m with he|m
      · exact Or.inl he
      rcases mem_insert.mp m with rfl|m
      · exact (wf edge).elim
      exact Or.inr ⟨m,edge⟩
    · rintro (rfl|⟨_,edge⟩)
      · exact we
      · exact edge
  have cut : D.filter (G.Adj M.e)⊆M.A.erase w := by
    intro x xm; obtain ⟨xd,ex⟩ := mem_filter.mp xm
    exact mem_erase.mpr ⟨(mem_filter.mp xd).2.ne.symm,M.ea ▸ (G.mem_neighborFinset ..).mpr ex⟩
  have small := card_le_card cut; rw [card_erase_of_mem wa,M.asz] at small
  have cap := card_le_card (show HighEar.pairs G D ⊆D.powersetCard 2 from filter_subset ..)
  rw [card_powersetCard] at cap
  change (HighEar.pairs G (G.neighborFinset w)).card≤D.card.choose 2+1
  rw [eq,HighEar.pairs_insert G ne]
  change nbr G M.e D≤2-1 at small
  omega
end Layout
end Graffiti384b.PairMix
#print axioms Graffiti384b.PairMix.Layout.exterior_degree
#print axioms Graffiti384b.PairMix.Layout.side_score
