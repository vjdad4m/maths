import PairCost
namespace Graffiti384b.PairMix.Layout
open Finset SimpleGraph Thin28 HighSquare28 EarMix
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] {G : SimpleGraph V} [DecidableRel G.Adj] (M : Layout G)

theorem lower (large : 15≤gamma G) :
    25496328+(∑v,M.total (gain G M.W) 0 v)≤∑v,M.total (hit G M.W) 0 v := by
  have p : M.P.card≤2 := Finset.card_le_two
  have q (N : Layout G) : N.Q.card≤3 := by
    have le := card_union_le N.A ({N.f}:Finset V); rw [card_singleton,N.asz] at le; exact le
  have r : M.R.card≤4 := by
    change (M.A∪M.B).card≤4; rw [card_union_of_disjoint M.ab,M.asz,M.bsz]
  have w := M.inj.mono M.wh
  have a := mass G M.W M.P 10 w (by omega)
  have b := mass G M.W M.Q 9 w (by have := q M; omega)
  have c := mass G M.W M.flip.Q 9 w (by have := q M.flip; omega)
  have d := mass G M.W M.R 8 w (by omega)
  rw [M.ws] at a b c d
  simp only [show (23:ℕ).choose 10=1144066 by decide,show (23:ℕ).choose 9=817190 by decide,show (23:ℕ).choose 8=490314 by decide] at a b c d
  simp only [total,Nat.sub_zero,sum_add_distrib,←mul_sum]
  omega

theorem ear_zero {v : V} (out : v∉M.H) : M.total (hit G M.W) 0 v=0 := by
  have m := mem_univ v; rw [M.full] at m
  have one (N : Layout G) : N.total (hit G N.W) 0 N.e=0 := by
    have low : 2≤nbr G N.e N.A := by
      have s : N.A.filter (G.Adj N.e)=N.A := filter_true_of_mem (fun x xm =>
        (G.mem_neighborFinset ..).mp (N.ea.symm ▸ xm))
      rw [nbr,s,N.asz]
    have p := kept G (W:=N.W) (b:=10) (show N.e∈N.P from mem_insert_self ..)
    have q := supported_zero G (W:=N.W) (b:=9) (P:=N.Q) (low.trans (Repair.nbr_mono G _ subset_union_left))
    have q' := kept G (W:=N.W) (b:=9) (show N.e∈N.flip.Q from mem_union_right _ (mem_singleton_self _))
    have r := supported_zero G (W:=N.W) (b:=8) (P:=N.R) (low.trans (Repair.nbr_mono G _ subset_union_left))
    simp only [total,Nat.sub_zero,p,q,q',r]
  rcases mem_insert.mp m with rfl|m
  · exact one M
  rcases mem_insert.mp m with rfl|m
  · rw [M.rotate]; exact one M.flip
  · exact (out m).elim
end Graffiti384b.PairMix.Layout
#print axioms Graffiti384b.PairMix.Layout.lower
#print axioms Graffiti384b.PairMix.Layout.ear_zero
