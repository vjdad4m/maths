import Ears34_384b
import PathExact34_384b
import OverlapFour34_384b
import CliqueThree34_384b

namespace Graffiti384b.Path34
open Finset SimpleGraph LowSample
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- In a normalized least-order failure of order 34, two ears sharing an
anchor force the three anchors to form a triangle. -/
theorem anchors_complete (res : Minimal.Residual G) (n : Fintype.card V=34) {y z : V}
    (yt : y∈twos G) (zt : z∈twos G) (yz : y≠z)
    (three : (G.neighborFinset y∪G.neighborFinset z).card=3) :
    G.IsClique ((G.neighborFinset y∪G.neighborFinset z : Finset V) : Set V) := by
  by_contra gap
  have t := (Frontier34.boundary G res n).2.1
  have pos := (Frontier34.ears G res n).2.1
  have exactBound := exact_of_path G n t yz (LowSample.two_degree G yt) (LowSample.two_degree G zt)
    (by have := pos y yt; omega) (by have := pos z zt; omega) three gap
  exact (not_lt_of_ge exactBound) res.2.2.1

/-- On the one-ear frontier each clique pair containing the ear's clique
neighbors has its own required exterior defects. Full overlap needs four
exterior vertices of degree at most five. -/
theorem one_ear (res : Minimal.Residual G) (n : Fintype.card V=34) {y : V} (ears : twos G={y})
    {C : Finset V} (cl : G.IsNClique 5 C) :
    let A := G.neighborFinset y
    (∀ K⊆C,K.card=2 → C∩A⊆K → 1+(C∩A).card≤(Overlap34.forwardSet G C A K).card) ∧
      3≤((high G\C).filter (fun v => G.degree v≤5)).card ∧ (A⊆C → 4≤((high G\C).filter (fun v => G.degree v≤5)).card) := by
  obtain ⟨q,t,_⟩ := Frontier34.boundary G res n
  have yt : y∈twos G := ears ▸ mem_singleton_self _
  have ah := (Ears34.anchor_sets G res n).1 y yt
  exact ⟨fun _ ks kc ii => Overlap34.forward G cl ears rfl ah ks kc ii (q.trans t.symm) res.2.2.1,
    Overlap34.three G (y:=y) cl (fun v vm => by rw [ears,mem_singleton] at vm; exact mem_insert.mpr (Or.inl vm)) (q.trans t.symm) res.2.2.1,
    fun sub => Overlap34.four G cl ears sub n t (q.trans t.symm) res.2.2.1⟩

end Graffiti384b.Path34
#print axioms Graffiti384b.Overlap34.forward
#print axioms Graffiti384b.Overlap34.reverse
#print axioms Graffiti384b.Overlap34.fibre
#print axioms Graffiti384b.Overlap34.three
#print axioms Graffiti384b.Overlap34.four
#print axioms Graffiti384b.Path34.one_ear
#print axioms Graffiti384b.Path34.mate
#print axioms Graffiti384b.Path34.reverse_cut
#print axioms Graffiti384b.Path34.other
#print axioms Graffiti384b.Path34.finish
#print axioms Graffiti384b.Path34.anchors_complete

#print axioms Graffiti384b.Path34.exact_of_path
