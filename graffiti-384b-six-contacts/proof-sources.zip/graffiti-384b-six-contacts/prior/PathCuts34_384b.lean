import PathGeometry34_384b

namespace Graffiti384b.Path34
open Finset SimpleGraph LowSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Keep the ears and a triple neighbor, and omit the three former anchors.
A failure now needs a fragile high vertex with no edge to the retained triple. -/
theorem reverse_cut {W : Finset V} {y z p b u : V} (D : Frame G W y z p b)
    (uc : u∈can G W) (three : nbr G u W=3) :
    ∃ r∈fragile G W,r≠u ∧ ¬G.Adj r u := by
  let K : Finset V := {u,y,z}
  have yt : y∈twos G := D.ears ▸ mem_insert_self _ _
  have zt : z∈twos G := D.ears ▸ mem_insert_of_mem (mem_singleton_self _)
  have uh := (mem_sdiff.mp (mem_filter.mp uc).1).1
  have uw := (mem_sdiff.mp (mem_filter.mp uc).1).2
  have uy : u≠y := fun e => (mem_sdiff.mp yt).2 (e ▸ uh)
  have uz : u≠z := fun e => (mem_sdiff.mp zt).2 (e ▸ uh)
  have hn : high G⊆nonleaves G := fun _ h => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp h).2; omega⟩
  have kn : K⊆nonleaves G := insert_subset (hn uh) (insert_subset (mem_sdiff.mp yt).1 (singleton_subset_iff.mpr (mem_sdiff.mp zt).1))
  have dis : Disjoint W K := disjoint_left.mpr (by
    intro w ww wk
    rcases mem_insert.mp wk with rfl|k
    · exact uw ww
    rcases mem_insert.mp k with rfl|l
    · exact (mem_sdiff.mp yt).2 (D.wh ww)
    · exact (mem_sdiff.mp zt).2 ((mem_singleton.mp l) ▸ D.wh ww))
  have hit (w : V) (ww : w∈W) : 2≤nbr G w K := by
    have wu := (seen G D.wc three ww).symm
    obtain ⟨e,ek,ew,eu⟩ : ∃ e∈K,G.Adj w e ∧ u≠e := by
      rcases mem_union.mp (D.anchors ▸ ww) with yw|zw
      · exact ⟨y,by simp [K],((G.mem_neighborFinset _ _).mp yw).symm,uy⟩
      · exact ⟨z,by simp [K],((G.mem_neighborFinset _ _).mp zw).symm,uz⟩
    have sub : ({u,e} : Finset V)⊆K.filter (G.Adj w) := insert_subset (mem_filter.mpr ⟨mem_insert_self ..,wu⟩)
      (singleton_subset_iff.mpr (mem_filter.mpr ⟨ek,ew⟩))
    simpa only [card_pair eu,nbr] using card_le_card sub
  have obs := CliqueCut34.pin_obstruction G kn (D.wh.trans hn) dis hit D.same D.fail
  have kc : K.card=3 := by simp [K,uy,uz,D.yz]
  rw [D.wc,kc] at obs
  obtain ⟨r,rm⟩ := card_pos.mp (show 0<(CliqueCut34.defects G K W).card by omega)
  obtain ⟨rr,short⟩ := mem_filter.mp rm
  obtain ⟨rn,out⟩ := mem_sdiff.mp rr
  have rk : r∉K := fun k => out (mem_union_right _ k)
  have rw' : r∉W := fun k => out (mem_union_left _ k)
  have rh : r∈high G := by
    by_contra no
    have low : r∈twos G := mem_sdiff.mpr ⟨rn,no⟩
    rw [D.ears] at low
    exact rk (mem_insert_of_mem low)
  have val := part G W r
  have rf : r∈fragile G W := mem_filter.mpr ⟨mem_sdiff.mpr ⟨rh,rw'⟩,by omega⟩
  obtain ⟨m,_,mp,_,eq,_,_⟩ := mate G D rf
  rw [eq,card_pair mp.symm] at val
  refine ⟨r,rf,fun e => rk (e ▸ mem_insert_self ..),fun ru => ?_⟩
  have pos : 0<nbr G r K := card_pos.mpr ⟨u,mem_filter.mpr ⟨mem_insert_self ..,ru⟩⟩
  omega

/-- Reverse the roles again. Omit both ears, a fragile vertex and any
second candidate. Unless the second candidate sees the saturated cubic,
only the count-two cubic can block the cut. -/
theorem other {W : Finset V} {y z p b r u : V} (D : Frame G W y z p b)
    (rf : r∈fragile G W) (uc : u∈can G W) (ur : u≠r) : G.Adj u b := by
  obtain ⟨m,_,_,_,shape,mw,_⟩ := mate G D rf
  have rc := candidate G D rf
  let U : Finset V := {r,u}
  have us : U⊆high G\W := insert_subset (mem_filter.mp rc).1 (singleton_subset_iff.mpr (mem_filter.mp uc).1)
  have hit (v : V) (vu : v∈U) : 2≤nbr G v W := by
    rcases mem_insert.mp vu with rfl|h
    · exact (mem_filter.mp rc).2
    · exact mem_singleton.mp h ▸ (mem_filter.mp uc).2
  have obs := EarCut34.joint G D.yz D.ears D.wh (D.anchors ▸ subset_union_left) (D.anchors ▸ subset_union_right) us hit D.same D.fail
  have sz : U.card=2 := card_pair ur.symm
  rw [sz,D.wc] at obs
  by_contra ub
  let B := ((high G)\(W∪U)).filter (fun v => G.degree v+nbr G v W<3+nbr G v U)
  have sub : B⊆{p} := by
    intro c cm
    obtain ⟨out,short⟩ := mem_filter.mp cm
    obtain ⟨ch,far⟩ := mem_sdiff.mp out
    have cw : c∉W := fun a => far (mem_union_left _ a)
    have dg := (mem_filter.mp ch).2
    have up : nbr G c U≤2 := (card_filter_le _ _).trans_eq sz
    by_cases cube : G.degree c=3
    · rcases D.cubes c cube with cp|rfl
      · exact mem_singleton.mpr cp
      · have none : U.filter (G.Adj c)=∅ := filter_eq_empty_iff.mpr (by
          intro j jm cj
          rcases mem_insert.mp jm with rfl|jm
          · exact avoid G D rf cj.symm
          · exact ub ((mem_singleton.mp jm) ▸ cj.symm))
        have zero : nbr G c U=0 := by rw [nbr,none,card_empty]
        omega
    · have two : nbr G c U=2 := by omega
      have all := eq_of_subset_of_card_le (filter_subset (G.Adj c) U) (show U.card≤nbr G c U by omega)
      have inside : r∈U.filter (G.Adj c) := by rw [all]; exact mem_insert_self ..
      have cr := (mem_filter.mp inside).2
      have cmem : c∈extN G W r := mem_sdiff.mpr ⟨(G.mem_neighborFinset _ _).mpr cr.symm,cw⟩
      rw [shape,mem_insert,mem_singleton] at cmem
      rcases cmem with cp|rfl
      · exact mem_singleton.mpr cp
      · omega
  have cap := card_le_card sub
  rw [card_singleton] at cap
  change 3+2≤3+B.card at obs
  omega

end Graffiti384b.Path34
#print axioms Graffiti384b.Path34.reverse_cut
#print axioms Graffiti384b.Path34.other
