import PathSupport34_384b
import EarTriangle34_384b
import Finish33_384b

namespace Graffiti384b.Path34
open Finset SimpleGraph LowSample
open private TrianglePrune.skeleton TrianglePrune.scores TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Every graph with 34 vertices and 33 triangle-count types obeys the
catalogue inequality if two ears have three anchors missing an edge.
There is no minimality or connectivity assumption. -/
theorem exact_of_path (n : Fintype.card V=34) (t : (types G).card=33) {y z : V} (yz : y≠z)
    (dy : G.degree y=2) (dz : G.degree z=2) (py : 0<trianglesAt G y) (pz : 0<trianglesAt G z)
    (three : (G.neighborFinset y∪G.neighborFinset z).card=3)
    (gap : ¬G.IsClique ((G.neighborFinset y∪G.neighborFinset z : Finset V) : Set V)) :
    gamma G≤bound G := by
  classical
  by_contra! fail
  let J := TrianglePrune.skeleton G y ∅
  have eq (v : V) : trianglesAt J v=trianglesAt G v := TrianglePrune.scores G y ∅ v
  have te : types J=types G := image_congr (fun v _ => eq v)
  have tj : (types J).card=33 := te ▸ t
  have mono : J≤G := fun _ _ e => e.1
  have gm : gamma G≤gamma J := by
    have av : {k : ℕ | ∃ d,TwoDominates J d ∧ d.card=k}.Nonempty := ⟨_,univ,by simp [TwoDominates],rfl⟩
    obtain ⟨d,ok,sz⟩ := Nat.sInf_mem av
    have gd : TwoDominates G d := fun v hv => (ok v hv).trans (card_le_card (show d.filter (J.Adj v)⊆d.filter (G.Adj v) from
      fun _ jm => mem_filter.mpr ⟨(mem_filter.mp jm).1,mono (mem_filter.mp jm).2⟩))
    exact Nat.sInf_le (s:={k | ∃ d,TwoDominates G d ∧ d.card=k}) ⟨d,gd,sz⟩
  have jf : bound J<gamma J := by
    have same : bound J=bound G := by simp only [bound,te]
    rw [same]; exact fail.trans_le gm
  have keep {a b c : V} (ab : G.Adj a b) (ac : G.Adj a c) (bc : G.Adj b c) : J.Adj a b := ⟨ab,Or.inl ⟨c,ac,bc⟩⟩
  have link {a b : V} (edge : J.Adj a b) : ∃ j,J.Adj a j ∧ J.Adj b j := by
    obtain ⟨j,aj,bj⟩ : ∃ j,G.Adj a j ∧ G.Adj b j := by simpa using edge.2
    exact ⟨j,keep aj edge.1 bj.symm,keep bj edge.1.symm aj.symm⟩
  have two {a b c : V} (ab : J.Adj a b) (ac : J.Adj a c) (ne : b≠c) : 2≤J.degree a := by
    have sub := insert_subset ((J.mem_neighborFinset _ _).mpr ab) (singleton_subset_iff.mpr ((J.mem_neighborFinset _ _).mpr ac))
    simpa only [card_pair ne,card_neighborFinset_eq_degree] using card_le_card sub
  have ear (a : V) (d : G.degree a=2) (pos : 0<trianglesAt G a) :
      a∈twos J ∧ J.neighborFinset a=G.neighborFinset a := by
    obtain ⟨b,c,ab,ac,bc⟩ := (TrianglePrune.triangle_iff G a).mp pos
    have low := two (keep ab ac bc) (keep ac ab bc.symm) bc.ne
    have up : J.degree a≤G.degree a := SimpleGraph.degree_le_of_le mono
    have dg : J.degree a=2 := by omega
    refine ⟨mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,low⟩,fun hh => by have := (mem_filter.mp hh).2; omega⟩,?_⟩
    exact eq_of_subset_of_card_le (fun j jm => (G.mem_neighborFinset _ _).mpr (mono ((J.mem_neighborFinset _ _).mp jm)))
      (by rw [card_neighborFinset_eq_degree,card_neighborFinset_eq_degree,dg,d])
  obtain ⟨yt,ny⟩ := ear y dy py
  obtain ⟨zt,nz⟩ := ear z dz pz
  have cap : (nonleaves J).card≤33 := by
    by_contra! big
    exact (not_lt_of_ge (Finish33.exact33 J tj big)) jf
  have hn : high J⊆nonleaves J := fun v vm => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp vm).2; omega⟩
  have size : (twos J).card+(high J).card=(nonleaves J).card := card_sdiff_add_card_eq_card hn
  have ps := insert_subset yt (singleton_subset_iff.mpr zt)
  have le := card_le_card ps
  rw [card_pair yz] at le
  have minH := type_bound J
  have h : (high J).card=31 := by omega
  have q : (nonleaves J).card=33 := by omega
  have ears := (eq_of_subset_of_card_le ps (by rw [card_pair yz]; omega)).symm
  have apart : ¬J.Adj y z := by
    intro e
    obtain ⟨w,yw,zw⟩ := link e
    exact (not_lt_of_ge (EarTriangle34.exact J tj h (by omega) yt zt e yw zw)) jf
  let W := G.neighborFinset y∪G.neighborFinset z
  have we : W=J.neighborFinset y∪J.neighborFinset z := by rw [ny,nz]
  have wh : W⊆high J := by
    intro a aw
    by_contra ah
    obtain ⟨v,va,vlo⟩ : ∃ v,J.Adj v a ∧ (v=y ∨ v=z) := by
      rcases mem_union.mp (we ▸ aw) with yn|zn
      · exact ⟨y,(J.mem_neighborFinset _ _).mp yn,Or.inl rfl⟩
      · exact ⟨z,(J.mem_neighborFinset _ _).mp zn,Or.inr rfl⟩
    obtain ⟨k,vk,ak⟩ := link va
    have atw : a∈twos J := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,two va.symm ak vk.ne⟩,ah⟩
    rw [ears,mem_insert,mem_singleton] at atw
    rcases vlo with rfl|rfl <;> rcases atw with rfl|rfl <;> first | exact va.ne rfl | exact apart va | exact apart va.symm
  have clique := complete_of_support J yz ears n tj q h jf W we three wh (fun _ _ _ _ e => link e)
  exact gap (fun i iw j jw diff => mono (clique iw jw diff))

end Graffiti384b.Path34
#print axioms Graffiti384b.Path34.exact_of_path
