import PathCuts34_384b

namespace Graffiti384b.Path34
open Finset SimpleGraph LowSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The forward and reverse cuts contradict seven excess incidences in a
three-anchor path. The triple neighbor is guaranteed by the previous sampler. -/
theorem finish {W : Finset V} {y z p b : V} (D : Frame G W y z p b)
    (triple : ∃ v∈can G W,nbr G v W=3)
    (excess : 7≤∑ v∈high G\W,(nbr G v W-1)) : False := by
  let C := can G W
  obtain ⟨v,vc,vt⟩ := triple
  obtain ⟨r,rf,_,_⟩ := reverse_cut G D vc vt
  have rc := candidate G D rf
  obtain ⟨m,mw,_,rm,_,_,extra⟩ := mate G D rf
  have uniq {a : V} (af : a∈fragile G W) : a=r := by
    by_contra ar
    exact avoid G D af (other G D rf (candidate G D af) ar)
  have safeTriple {a : V} (ac : a∈C) (three : nbr G a W=3) : r≠a ∧ ¬G.Adj r a := by
    obtain ⟨f,ff,fa,no⟩ := reverse_cut G D ac three
    exact uniq ff ▸ And.intro fa no
  have rcap : nbr G r W≤3 := (card_filter_le _ _).trans_eq D.wc
  have rtwo : nbr G r W=2 := by
    have small := (mem_filter.mp rc).2
    have no : nbr G r W≠3 := fun h => (safeTriple rc h).1 rfl
    change 2≤nbr G r W at small
    omega
  have mtwo := extra rtwo
  have mhi : m∈high G := by
    have ext : r∈extN G W m := mem_sdiff.mpr ⟨(G.mem_neighborFinset _ _).mpr rm.symm,(mem_sdiff.mp (mem_filter.mp rf).1).2⟩
    have pos := card_pos.mpr ⟨r,ext⟩
    have num := part G W m
    exact mem_filter.mpr ⟨mem_univ _,by omega⟩
  have mc : m∈C := mem_filter.mpr ⟨mem_sdiff.mpr ⟨mhi,mw⟩,mtwo⟩
  have mcap : nbr G m W≤3 := (card_filter_le _ _).trans_eq D.wc
  have m2 : nbr G m W=2 := by
    have no : nbr G m W≠3 := fun h => (safeTriple mc h).2 rm
    omega
  have cover : C⊆insert r (G.neighborFinset b) := by
    intro u uc
    by_cases ur : u=r
    · exact mem_insert.mpr (Or.inl ur)
    · exact mem_insert_of_mem ((G.mem_neighborFinset _ _).mpr (other G D rf uc ur).symm)
  have card := (card_le_card cover).trans (card_insert_le ..)
  rw [card_neighborFinset_eq_degree,D.bd] at card
  have sum : (∑ a∈C,(nbr G a W-1))=∑ a∈high G\W,(nbr G a W-1) := by
    apply sum_subset (filter_subset _ _)
    intro a am out
    have sm : nbr G a W<2 := Nat.lt_of_not_ge (fun hi => out (mem_filter.mpr ⟨am,hi⟩))
    omega
  let L : Finset V := {r,m}
  have sub : L⊆C := insert_subset rc (singleton_subset_iff.mpr mc)
  have point (a : V) (_ : a∈C) : (nbr G a W-1)+(if a∈L then 1 else 0) ≤ 2 := by
    by_cases inside : a∈L
    · rw [if_pos inside]
      rcases mem_insert.mp inside with rfl|eq
      · omega
      · obtain rfl := mem_singleton.mp eq; omega
    · rw [if_neg inside,Nat.add_zero]
      have cap : nbr G a W≤3 := (card_filter_le _ _).trans_eq D.wc
      omega
  have bound := sum_le_sum point
  simp only [sum_add_distrib,sum_boole,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr sub,sum_const,nsmul_eq_mul] at bound
  change (∑ a∈C,(nbr G a W-1))+L.card≤C.card*2 at bound
  have lc : L.card=2 := card_pair rm.ne
  rw [←sum] at excess
  omega
end Graffiti384b.Path34
#print axioms Graffiti384b.Path34.finish
