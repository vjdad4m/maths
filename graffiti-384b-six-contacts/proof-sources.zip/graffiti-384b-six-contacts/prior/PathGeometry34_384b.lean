import EarCut34_384b
import CliqueChoice384b

namespace Graffiti384b.Path34
open Finset SimpleGraph LowSample
open private Repair.edge_info Repair.linkEdges from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def can (W : Finset V) := (high G\W).filter (fun v => 2≤nbr G v W)
def extN (W : Finset V) (v : V) := G.neighborFinset v\W
def fragile (W : Finset V) := (high G\W).filter (fun v => (extN G W v).card≤2)

/-- p and b are the two cubic vertices, of counts two and three. -/
structure Frame (W : Finset V) (y z p b : V) : Prop where
  yz : y≠z
  ears : twos G={y,z}
  anchors : W=G.neighborFinset y∪G.neighborFinset z
  wc : W.card=3
  wh : W⊆high G
  gap : ∃ i∈W,∃ j∈W,i≠j ∧ ¬G.Adj i j
  pd : G.degree p=3
  bd : G.degree b=3
  p0 : nbr G p W=0
  b0 : nbr G b W=0
  cubes : ∀ v, G.degree v=3 → v=p ∨ v=b
  full : CliqueChoice.cliqueAt G b
  score : ∀ v∈high G, v≠p → v≠b → 4≤trianglesAt G v
  link : ∀ i∈high G, ∀ j∈high G, G.Adj i j → ∃ k,G.Adj i k ∧ G.Adj j k
  same : (nonleaves G).card=(types G).card
  fail : bound G<gamma G

theorem part (W : Finset V) (v : V) : (extN G W v).card+nbr G v W=G.degree v := by
  have c := card_sdiff_add_card_inter (G.neighborFinset v) W
  have e : G.neighborFinset v∩W=W.filter (G.Adj v) := by ext i; simp [and_comm]
  simpa only [extN,nbr,e,card_neighborFinset_eq_degree] using c

omit [Fintype V] [DecidableEq V] in
theorem blind {W : Finset V} {v j : V} (zero : nbr G v W=0) (vj : G.Adj v j) : j∉W := by
  intro jw
  have pos : 0<nbr G v W := card_pos.mpr ⟨j,mem_filter.mpr ⟨jw,vj⟩⟩
  omega

omit [Fintype V] [DecidableEq V] in
theorem seen {W : Finset V} {v : V} (wc : W.card=3) (num : nbr G v W=3) {j : V} (jw : j∈W) : G.Adj v j := by
  have eq := eq_of_subset_of_card_le (filter_subset (G.Adj v) W) (show W.card≤nbr G v W by omega)
  have mem : j∈W.filter (G.Adj v) := by rw [eq]; exact jw
  exact (mem_filter.mp mem).2

theorem candidate {W : Finset V} {y z p b v : V} (D : Frame G W y z p b) (vf : v∈fragile G W) : v∈can G W := by
  obtain ⟨outside,small⟩ := mem_filter.mp vf
  have dh := (mem_filter.mp (mem_sdiff.mp outside).1).2
  have eq := part G W v
  refine mem_filter.mpr ⟨outside,?_⟩
  by_contra! lo
  have cub : G.degree v=3 := by omega
  rcases D.cubes v cub with rfl|rfl <;> first | have := D.p0; omega | have := D.b0; omega

theorem avoid {W : Finset V} {y z p b v : V} (D : Frame G W y z p b) (vf : v∈fragile G W) : ¬G.Adj v b := by
  intro vb
  have vn := (G.mem_neighborFinset _ _).mpr vb.symm
  have large : insert b ((G.neighborFinset b).erase v)⊆extN G W v := by
    apply insert_subset (mem_sdiff.mpr ⟨(G.mem_neighborFinset _ _).mpr vb,?_⟩)
    · intro i im
      obtain ⟨ne,im⟩ := mem_erase.mp im
      have bi := (G.mem_neighborFinset _ _).mp im
      exact mem_sdiff.mpr ⟨(G.mem_neighborFinset _ _).mpr (D.full v i vb.symm bi ne.symm),blind G D.b0 bi⟩
    · intro bw
      -- The blind cubic cannot itself be an anchor, since every anchor has an ear neighbor
      -- and both incident triangle edges of an ear have high endpoints.
      rcases mem_union.mp (D.anchors ▸ bw) with byN|bzN
      · have yes := (G.mem_neighborFinset _ _).mp byN
        obtain ⟨a,am,ab⟩ := exists_ne_of_one_lt_card (s:=G.neighborFinset b)
          (by rw [card_neighborFinset_eq_degree,D.bd]; decide) y
        have adj := D.full y a yes.symm ((G.mem_neighborFinset _ _).mp am) ab.symm
        exact blind G D.b0 ((G.mem_neighborFinset _ _).mp am) (D.anchors ▸ mem_union_left _ ((G.mem_neighborFinset _ _).mpr adj))
      · have yes := (G.mem_neighborFinset _ _).mp bzN
        obtain ⟨a,am,ab⟩ := exists_ne_of_one_lt_card (s:=G.neighborFinset b)
          (by rw [card_neighborFinset_eq_degree,D.bd]; decide) z
        have adj := D.full z a yes.symm ((G.mem_neighborFinset _ _).mp am) ab.symm
        exact blind G D.b0 ((G.mem_neighborFinset _ _).mp am) (D.anchors ▸ mem_union_right _ ((G.mem_neighborFinset _ _).mpr adj))
  have cap := card_le_card large
  rw [card_insert_of_not_mem (fun m => G.not_mem_neighborFinset_self b (erase_subset _ _ m)),card_erase_of_mem vn,card_neighborFinset_eq_degree,D.bd] at cap
  have := (mem_filter.mp vf).2
  omega

private def links (s : Finset V) := (s.powersetCard 2).filter (fun a => ∀ x∈a,∀ y∈a,x≠y → G.Adj x y)

private theorem split {W : Finset V} {r p m : V} (out : extN G W r={p,m}) (p0 : nbr G p W=0) :
    trianglesAt G r≤(links G (W.filter (G.Adj r))).card+1+nbr G m W := by
  let A := W.filter (G.Adj r)
  let B := (W.filter (G.Adj m)).image (fun j => ({m,j} : Finset V))
  have cover : Repair.linkEdges G r ⊆ (links G A∪{{p,m}})∪B := by
    intro e em
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info G em
    obtain ⟨i,j,ne,eq⟩ := card_eq_two.mp sz
    have ie : i∈e := eq ▸ mem_insert_self _ _
    have je : j∈e := eq ▸ mem_insert_of_mem (mem_singleton_self _)
    have ij := cl i ie j je ne
    have inside {a : V} (ae : a∈e) (aw : a∉W) : a=p ∨ a=m := by
      have mem : a∈extN G W r := mem_sdiff.mpr ⟨sub ae,aw⟩
      simpa [out] using mem
    by_cases iw : i∈W
    · by_cases jw : j∈W
      · refine mem_union_left _ (mem_union_left _ (mem_filter.mpr ⟨mem_powersetCard.mpr ⟨?_,sz⟩,cl⟩))
        intro a ae
        have ah : a=i ∨ a=j := by simpa [eq] using ae
        exact mem_filter.mpr ⟨ah.elim (fun h => h ▸ iw) (fun h => h ▸ jw),(G.mem_neighborFinset _ _).mp (sub ae)⟩
      · rcases inside je jw with rfl|rfl
        · exact (blind G p0 ij.symm iw).elim
        · exact mem_union_right _ (mem_image.mpr ⟨i,mem_filter.mpr ⟨iw,ij.symm⟩,by rw [eq,pair_comm]⟩)
    · by_cases jw : j∈W
      · rcases inside ie iw with rfl|rfl
        · exact (blind G p0 ij jw).elim
        · exact mem_union_right _ (mem_image.mpr ⟨j,mem_filter.mpr ⟨jw,ij⟩,eq.symm⟩)
      · have a := inside ie iw
        have b := inside je jw
        exact mem_union_left _ (mem_union_right _ (mem_singleton.mpr (by
          rcases a with rfl|rfl <;> rcases b with rfl|rfl <;> first | exact (ne rfl).elim | exact eq | exact eq.trans (pair_comm ..))))
  have cap := (card_le_card cover).trans (card_union_le _ _)
  have left := card_union_le (links G A) ({{p,m}} : Finset (Finset V))
  rw [card_singleton] at left
  have mass : B.card≤nbr G m W := card_image_le
  change (Repair.linkEdges G r).card≤_
  change _≤(links G A).card+1+nbr G m W
  omega

theorem mate {W : Finset V} {y z p b r : V} (D : Frame G W y z p b) (rf : r∈fragile G W) :
    ∃ m, m∉W ∧ m≠p ∧ G.Adj r m ∧ extN G W r={p,m} ∧
      1≤nbr G m W ∧ (nbr G r W=2 → 2≤nbr G m W) := by
  have canR := candidate G D rf
  obtain ⟨rr,two⟩ := mem_filter.mp canR
  have rh := (mem_sdiff.mp rr).1
  obtain ⟨c,cs,cr,dc,c0⟩ := EarCut34.shared G D.yz D.ears D.wc D.wh (D.anchors ▸ subset_union_left)
    (D.anchors ▸ subset_union_right) rr two D.same D.fail
  have cp : c=p := (D.cubes c dc).resolve_right (fun e => avoid G D rf (e ▸ cr.symm))
  subst c
  obtain ⟨m,rm,pm⟩ := D.link r rh p (mem_filter.mpr ⟨mem_univ _,D.pd.ge⟩) cr.symm
  have mw := blind G D.p0 pm
  have pw : p∉W := (mem_sdiff.mp cs).2 ∘ mem_insert_of_mem
  have inc : ({p,m} : Finset V)⊆extN G W r := insert_subset (mem_sdiff.mpr ⟨(G.mem_neighborFinset _ _).mpr cr.symm,pw⟩)
    (singleton_subset_iff.mpr (mem_sdiff.mpr ⟨(G.mem_neighborFinset _ _).mpr rm,mw⟩))
  have eq := (eq_of_subset_of_card_le inc (by rw [card_pair pm.ne]; exact (mem_filter.mp rf).2)).symm
  have sc := D.score r rh (fun e => by rw [e,D.p0] at two; omega) (fun e => by rw [e,D.b0] at two; omega)
  let A := W.filter (G.Adj r)
  have lcap := split G eq D.p0
  change trianglesAt G r≤(links G A).card+1+nbr G m W at lcap
  have sub : links G A⊆W.powersetCard 2 := fun e em =>
    mem_powersetCard.mpr ⟨(mem_powersetCard.mp (mem_filter.mp em).1).1.trans (filter_subset _ _),(mem_powersetCard.mp (mem_filter.mp em).1).2⟩
  obtain ⟨i,iw,j,jw,ne,no⟩ := D.gap
  have ij : ({i,j} : Finset V)∈W.powersetCard 2 := mem_powersetCard.mpr ⟨insert_subset iw (singleton_subset_iff.mpr jw),card_pair ne⟩
  have notLink : ({i,j} : Finset V)∉links G A := fun mem => no ((mem_filter.mp mem).2 i (mem_insert_self ..) j (mem_insert_of_mem (mem_singleton_self _)) ne)
  have left := card_le_card (show links G A⊆(W.powersetCard 2).erase {i,j} from fun e em => mem_erase.mpr ⟨fun ee => notLink (ee ▸ em),sub em⟩)
  rw [card_erase_of_mem ij,card_powersetCard,D.wc] at left
  change (links G A).card≤2 at left
  refine ⟨m,mw,pm.ne.symm,rm,eq,by omega,?_⟩
  intro n
  have upper := card_filter_le (A.powersetCard 2) (fun a => ∀ x∈a,∀ y∈a,x≠y → G.Adj x y)
  rw [card_powersetCard,show A.card=2 from n] at upper
  change (links G A).card≤1 at upper
  omega

end Graffiti384b.Path34
#print axioms Graffiti384b.Path34.mate
