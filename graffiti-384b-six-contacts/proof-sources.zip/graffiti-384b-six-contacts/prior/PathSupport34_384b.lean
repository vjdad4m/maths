import PathFinish34_384b
import SharedProfile34_384b

namespace Graffiti384b.Path34
open Finset SimpleGraph LowSample
open private Repair.triangles_le_choose from Repair384b
open private SharedProfile34.missing from SharedProfile34_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem complete_of_support {y z : V} (yz : y≠z) (ears : twos G={y,z})
    (n : Fintype.card V=34) (t : (types G).card=33) (q : (nonleaves G).card=33) (h : (high G).card=31)
    (fail : bound G<gamma G) (W : Finset V) (we : W=G.neighborFinset y∪G.neighborFinset z)
    (three : W.card=3) (wh : W⊆high G)
    (link : ∀ a∈high G,∀ c∈high G,G.Adj a c → ∃ j,G.Adj a j ∧ G.Adj c j) :
    G.IsClique (W : Set V) := by
  intro i iw j jw ne
  change i∈W at iw
  change j∈W at jw
  by_contra no
  have gap : ∃ i∈W,∃ j∈W,i≠j ∧ ¬G.Adj i j := ⟨i,iw,j,jw,ne,no⟩
  obtain ⟨_,_,path⟩ := SharedProfile34.profile G yz ears n h t q fail W we three wh
  obtain ⟨_,triple,im⟩ := path gap
  let H := (high G).filter (fun v => G.degree v=3 ∧ nbr G v W=0)
  change H.image (trianglesAt G)={2,3} at im
  have twoIn : 2∈H.image (trianglesAt G) := by rw [im]; decide
  have threeIn : 3∈H.image (trianglesAt G) := by rw [im]; decide
  obtain ⟨p,pm,sp⟩ := mem_image.mp twoIn
  obtain ⟨b,bm,sb⟩ := mem_image.mp threeIn
  obtain ⟨ph,pd,p0⟩ := mem_filter.mp pm
  obtain ⟨bh,bd,b0⟩ := mem_filter.mp bm
  obtain ⟨inj,lo,_,_⟩ := Repair.maximal_diversity G (by omega)
  have cubes (v : V) (d : G.degree v=3) : v=p ∨ v=b := by
    have vh : v∈high G := mem_filter.mpr ⟨mem_univ _,d.ge⟩
    have low := lo v vh
    have cap := Repair.triangles_le_choose G v
    rw [d] at cap
    change trianglesAt G v≤3 at cap
    rcases (show trianglesAt G v=2 ∨ trianglesAt G v=3 by omega) with a|a
    · exact Or.inl (inj vh ph (a.trans sp.symm))
    · exact Or.inr (inj vh bh (a.trans sb.symm))
  have full := CliqueChoice.saturated_clique G (v:=b) (by simpa only [bd] using sb)
  have score (v : V) (vh : v∈high G) (vp : v≠p) (vb : v≠b) : 4≤trianglesAt G v := by
    have low := lo v vh
    have nt : trianglesAt G v≠2 := fun eq => vp (inj vh ph (eq.trans sp.symm))
    have nb : trianglesAt G v≠3 := fun eq => vb (inj vh bh (eq.trans sb.symm))
    omega
  let D : Frame G W y z p b := ⟨yz,ears,we,three,wh,gap,pd,bd,p0,b0,cubes,full,score,link,q.trans t.symm,fail⟩
  obtain ⟨over,_⟩ := SharedMany34.overlap G yz ears n h t q fail W we three wh
  have miss := SharedProfile34.missing G (W:=W) three iw jw ne no
  exact finish G D triple (by omega)

end Graffiti384b.Path34
#print axioms Graffiti384b.Path34.complete_of_support
