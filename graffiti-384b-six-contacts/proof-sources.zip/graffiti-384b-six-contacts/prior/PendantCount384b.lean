import PendantTrial384b
import SmallScores35_384b
import BlockLoss384b

namespace Graffiti384b.Pendant
open Finset SimpleGraph CliqueChoice
open private SmallScores35.allowed from SmallScores35_384b
open private LowSample.delta from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def limit (f : Finset ℕ) (j : ℕ) := slots f j Boundary.levels - 2
def profiles : Finset (Finset ℕ) := {∅,{3},{4},{5},{3,4},{3,5}}

private theorem arithmetic : BlockLoss.envelope 33 13 ∧
    (∀ d : Fin 10, 3 ≤ d.val → (34-d.val).choose 13 + 8112468 ≤ FiniteRange.badCount 33 13 d.val) ∧
    (∀ f ∈ profiles, BlockLoss.chargeAt 33 13 (limit f) ≤ 2098867300) := by
  unfold BlockLoss.envelope BlockLoss.chargeAt limit profiles slots Boundary.levels LowSample.delta FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

private theorem distribution {p s : Finset V} (ch : Choice G p Boundary.levels)
    (inj : Function.Injective (trianglesAt G)) (pos : ∀ v ∈ s, 2 ≤ trianglesAt G v) (j : ℕ) (big : 3 ≤ j) :
    (s.filter (fun v => G.degree v ≤ j)).card ≤ limit (p.image (G.degree ·)) j := by
  have sub : (s.filter (fun v => G.degree v ≤ j)).image (trianglesAt G) ⊆ Ico 2 (slots (p.image (G.degree ·)) j Boundary.levels) := by
    intro z mem
    obtain ⟨v,vm,rfl⟩ := mem_image.mp mem
    exact mem_Ico.mpr ⟨pos v (mem_filter.mp vm).1,SmallScores35.allowed G ch big (mem_filter.mp vm).2⟩
  have n := card_le_card sub
  rwa [card_image_of_injective _ inj,Nat.card_Ico] at n

omit [Fintype V] in
/-- Every sample that misses both triangle endpoints is contained in the
31-vertex complement of the pair. -/
private theorem income (s P : Finset V) (sz : s.card=33) (ps : P ⊆ s) (two : P.card=2) :
    366913365 ≤ ∑ k ∈ s.powersetCard 13, (if Disjoint k P then 0 else 1 : ℕ) := by
  let rows := s.powersetCard 13
  have per (k : Finset V) : (if Disjoint k P then 0 else 1 : ℕ) + (if Disjoint k P then 1 else 0 : ℕ) = 1 := by split_ifs <;> decide
  have add := sum_congr (rfl : rows=rows) (fun k _ => per k)
  simp only [sum_add_distrib,sum_boole,sum_const,nsmul_eq_mul,Nat.cast_id,Nat.mul_one] at add
  have setEq : rows.filter (fun k => Disjoint k P) = (s \ P).powersetCard 13 := by
    ext k
    simp only [rows,mem_filter,mem_powersetCard,subset_sdiff]
    tauto
  have den : rows.card=573166440 := by simp only [rows,card_powersetCard,sz,Nat.choose_eq_fast_choose]; decide
  have miss : (rows.filter (fun k => Disjoint k P)).card=206253075 := by
    simp only [setEq,card_powersetCard,card_sdiff ps,sz,two,Nat.choose_eq_fast_choose]
    decide
  rw [miss,den] at add
  change _ ≤ ∑ k ∈ rows, _
  omega

/-- The pendant triangle clears every remaining saturated-degree row on the
34-high branch. Its two positive endpoints each refund at least 8,112,468 losses. -/
theorem exact {l u a b : V} (D : Geometry G l u a b) (n : Fintype.card V=35)
    (t : (types G).card=35) (inj : Function.Injective (trianglesAt G))
    (active : ∀ v ∈ core l u, 3 ≤ G.degree v)
    (pos : ∀ v ∈ core l u, 2 ≤ trianglesAt G v)
    {p : Finset V} (ch : Choice G p Boundary.levels) (prof : p.image (G.degree ·) ∈ profiles) :
    gamma G ≤ bound G := by
  classical
  by_contra! fail
  let s := core l u
  let P : Finset V := {a,b}
  let rows := s.powersetCard 13
  let f := p.image (G.degree ·)
  let fiber (v : V) := (rows.filter (fun k => v ∈ loss G l u P k)).card
  let rebate (v : V) := if v ∈ P then 8112468 else 0
  have sz : s.card=33 := by simp only [s,core,card_compl,card_pair D.ul.ne.symm,n]
  have al : a≠l := fun eq => D.ub.ne.symm (D.leaf b (eq ▸ D.ab))
  have bl : b≠l := fun eq => D.ua.ne.symm (D.leaf a (eq ▸ D.ab.symm))
  have as : a ∈ s := by simp [s,core,al,D.ua.ne.symm]
  have bs : b ∈ s := by simp [s,core,bl,D.ub.ne.symm]
  have ps : P ⊆ s := insert_subset as (singleton_subset_iff.mpr bs)
  have two : P.card=2 := card_pair D.ab.ne
  have point (v : V) (vs : v ∈ s) : fiber v+rebate v ≤ FiniteRange.badCount 33 13 9 +
      ∑ j ∈ range 9, if G.degree v ≤ j then LowSample.delta 33 13 j else 0 := by
    let d := min (G.degree v) 9
    have dl : 3≤d := le_min (active v vs) (by decide)
    have du : d≤9 := min_le_right _ _
    have cap : d≤G.degree v := min_le_left _ _
    have raw : fiber v+rebate v ≤ FiniteRange.badCount 33 13 d := by
      by_cases vp : v ∈ P
      · have ep (w : V) (pair : P={v,w}) (uv : G.Adj u v) (edge : G.Adj v w) (nw : u≠w) :=
          endpoint G D pair uv edge vs nw sz d dl cap
        have le : fiber v ≤ (34-d).choose 13 := by
          rcases mem_insert.mp vp with e|e
          · subst v; exact ep b rfl D.ua D.ab D.ub.ne
          · obtain rfl := mem_singleton.mp e
            exact ep a (pair_comm _ _) D.ub D.ab.symm D.ua.ne
        rw [show rebate v=8112468 from if_pos vp]
        exact (Nat.add_le_add_right le 8112468).trans (arithmetic.2.1 ⟨d,by omega⟩ dl)
      · have le := ordinary G D vs vp cap (by change d<s.card; omega)
        rw [show rebate v=0 from if_neg vp,Nat.add_zero]
        change fiber v ≤ FiniteRange.badCount s.card 13 d at le
        rwa [sz] at le
    by_cases small : G.degree v ≤ 9
    · rw [show d=G.degree v from min_eq_left small] at raw
      exact raw.trans (arithmetic.1 ⟨G.degree v,by omega⟩ (active v vs))
    · rw [show d=9 from min_eq_right (by omega)] at raw
      exact raw.trans (Nat.le_add_right ..)
  have step (j : ℕ) (_hj : j ∈ range 9) : (∑ v ∈ s, if G.degree v ≤ j then LowSample.delta 33 13 j else 0) ≤
      LowSample.delta 33 13 j * limit f j := by
    rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    by_cases big : 3 ≤ j
    · exact Nat.mul_le_mul_left _ (distribution G ch inj pos j big)
    · simp [LowSample.delta,big]
  have sumH := sum_le_sum point
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,sz] at sumH
  rw [sum_comm (s := s) (t := range 9)] at sumH
  have total : (∑ v ∈ s, fiber v)+(∑ v ∈ s, rebate v) ≤ BlockLoss.chargeAt 33 13 (limit f) :=
    sumH.trans (Nat.add_le_add_left (sum_le_sum step) _)
  have credit : (∑ v ∈ s, rebate v)=2*8112468 := by
    simp only [rebate,← sum_filter,sum_const,nsmul_eq_mul,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr ps,two]
  have swap : (∑ k ∈ rows, (loss G l u P k).card) = ∑ v ∈ s, fiber v := by
    calc
      _ = ∑ k ∈ rows, ∑ v ∈ s, (if v ∈ loss G l u P k then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show loss G l u P k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
      _ = _ := by rw [sum_comm]; simp [fiber]
  have tr := sum_le_sum (s := rows) (fun k hk => trial G D n t fail (mem_powersetCard.mp hk).1 (mem_powersetCard.mp hk).2)
  have den : rows.card=573166440 := by simp only [rows,card_powersetCard,sz,Nat.choose_eq_fast_choose]; decide
  change (∑ k ∈ rows, (20+(if Disjoint k P then 0 else 1))) ≤ ∑ k ∈ rows, (17+(loss G l u P k).card) at tr
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,den,swap] at tr
  have inc := income s P sz ps two
  change 366913365 ≤ ∑ k ∈ rows, _ at inc
  have cap := total.trans (arithmetic.2.2 f prof)
  rw [credit] at cap
  omega

end Graffiti384b.Pendant
#print axioms Graffiti384b.Pendant.exact
