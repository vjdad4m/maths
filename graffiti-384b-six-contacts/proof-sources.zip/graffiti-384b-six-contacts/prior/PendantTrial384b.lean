import FiniteRange384b
import Distinguish35_384b

namespace Graffiti384b.Pendant
open Finset SimpleGraph
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

structure Geometry (l u a b : V) : Prop where
  ul : G.Adj u l
  ua : G.Adj u a
  ub : G.Adj u b
  ab : G.Adj a b
  leaf : ∀ z, G.Adj l z → z=u
  near : ∀ z, G.Adj u z → z=l ∨ z=a ∨ z=b

variable {l u a b : V}
def core [DecidableEq V] [Fintype V] (l u : V) : Finset V := ({l,u} : Finset V)ᶜ
def kept (l u : V) (p k : Finset V) := if Disjoint k p then insert u (insert l k) else insert l k
def loss (l u : V) (p k : Finset V) := (core l u \ k).filter (fun z => nbr G z (kept l u p k) < 2)

omit [Fintype V] in
private theorem two {v x y : V} {s : Finset V} (xk : x ∈ s) (yk : y ∈ s)
    (vx : G.Adj v x) (vy : G.Adj v y) (ne : x≠y) : 2 ≤ nbr G v s := by
  have sub : ({x,y} : Finset V) ⊆ s.filter (G.Adj v) := insert_subset
    (mem_filter.mpr ⟨xk,vx⟩) (singleton_subset_iff.mpr (mem_filter.mpr ⟨yk,vy⟩))
  simpa only [nbr,card_pair ne] using card_le_card sub

omit [Fintype V] in
private theorem kept_sub (l u : V) (p k : Finset V) : insert l k ⊆ kept l u p k := by
  unfold kept
  split_ifs
  · exact subset_insert _ _
  · exact Subset.rfl

theorem trial (D : Geometry G l u a b) (order : Fintype.card V=35) (t : (types G).card=35)
    (fail : bound G<gamma G) {k : Finset V} (ks : k ⊆ core l u) (sz : k.card=13) :
    20+(if Disjoint k {a,b} then 0 else 1 : ℕ) ≤ 17+(loss G l u {a,b} k).card := by
  let P : Finset V := {a,b}
  let K := kept l u P k
  let L := loss G l u P k
  have base : insert l k ⊆ K := kept_sub l u P k
  have lk : l ∉ k := fun m => mem_compl.mp (ks m) (mem_insert_self _ _)
  have ul : u ≠ l := D.ul.ne
  have uk : u ∉ k := fun m => mem_compl.mp (ks m) (mem_insert_of_mem (mem_singleton_self _))
  have good : TwoDominates G (K ∪ L) := by
    intro v out
    have vk : v ∉ K := fun m => out (mem_union_left _ m)
    have lift : nbr G v K ≤ nbr G v (K ∪ L) := card_le_card (filter_subset_filter _ subset_union_left)
    apply le_trans _ lift
    by_cases vu : v=u
    · subst v
      by_cases sep : Disjoint k P
      · exact (vk (by simp [K,kept,sep])).elim
      · obtain ⟨z,zk,zp⟩ := not_disjoint_iff.mp sep
        have vz : G.Adj u z := by
          rcases mem_insert.mp zp with e|e
          · exact e ▸ D.ua
          · exact mem_singleton.mp e ▸ D.ub
        exact two G (base (mem_insert_self _ _)) (base (mem_insert_of_mem zk)) D.ul vz
          (fun eq => lk (eq ▸ zk))
    · have vl : v≠l := fun eq => vk (eq ▸ base (mem_insert_self _ _))
      have vs : v ∈ core l u := by simp [core,vl,vu]
      have no : v ∉ k := fun m => vk (base (mem_insert_of_mem m))
      exact Nat.le_of_not_gt (fun small => out (mem_union_right _ (mem_filter.mpr ⟨mem_sdiff.mpr ⟨vs,no⟩,small⟩)))
  have upper : gamma G ≤ (K ∪ L).card := Nat.sInf_le (s := {n : ℕ | ∃ d, TwoDominates G d ∧ d.card=n}) ⟨_,good,rfl⟩
  have cap := card_union_le K L
  unfold bound at fail
  rw [order,t] at fail
  change 20+(if Disjoint k P then 0 else 1 : ℕ) ≤ 17+L.card
  by_cases sep : Disjoint k P
  · have size : K.card=15 := by
      rw [show K=insert u (insert l k) by simp [K,kept,sep],card_insert_of_not_mem (by simp [ul,uk]),
        card_insert_of_not_mem lk,sz]
    rw [if_pos sep]; omega
  · have size : K.card=14 := by rw [show K=insert l k by simp [K,kept,sep],card_insert_of_not_mem lk,sz]
    rw [if_neg sep]; omega

theorem ordinary (D : Geometry G l u a b) {v : V} (vs : v ∈ core l u) (np : v ∉ ({a,b} : Finset V))
    {d : ℕ} (deg : d ≤ G.degree v) (room : d < (core l u).card) :
    (((core l u).powersetCard 13).filter (fun k => v ∈ loss G l u {a,b} k)).card ≤
      FiniteRange.badCount (core l u).card 13 d := by
  apply le_trans (card_le_card ?_) (FiniteRange.count_bad G (core l u) 13 d v vs deg room)
  intro k hk
  obtain ⟨sample,mem⟩ := mem_filter.mp hk
  obtain ⟨out,few⟩ := mem_filter.mp mem
  refine mem_filter.mpr ⟨sample,mem_filter.mpr ⟨out,lt_of_le_of_lt (card_le_card ?_) few⟩⟩
  intro z hz
  obtain ⟨zk,edge⟩ := mem_filter.mp hz
  apply mem_filter.mpr
  refine ⟨kept_sub l u {a,b} k ?_,edge⟩
  rcases mem_union.mp zk with fixed|samp
  · have low : z=l ∨ z=u := by simpa [core] using fixed
    rcases low with rfl|rfl
    · exact mem_insert_self _ _
    · rcases D.near v edge.symm with e|e|e
      · exact (mem_compl.mp vs (mem_insert.mpr (Or.inl e))).elim
      · exact (np (mem_insert.mpr (Or.inl e))).elim
      · exact (np (mem_insert_of_mem (mem_singleton.mpr e))).elim
  · exact mem_insert_of_mem samp

theorem endpoint (D : Geometry G l u a b) {v w : V} (pair : ({a,b} : Finset V)={v,w})
    (uv : G.Adj u v) (vw : G.Adj v w) (vs : v ∈ core l u) (uw : u≠w)
    (size : (core l u).card=33) (d : ℕ) (low : 3 ≤ d) (cap : d ≤ G.degree v) :
    (((core l u).powersetCard 13).filter (fun k => v ∈ loss G l u {a,b} k)).card ≤ (34-d).choose 13 := by
  let A := G.neighborFinset v \ {u,w}
  have sub : ({u,w} : Finset V) ⊆ G.neighborFinset v := insert_subset
    ((G.mem_neighborFinset _ _).mpr uv.symm) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vw))
  have sz : A.card=G.degree v-2 := by rw [show A=G.neighborFinset v \ {u,w} from rfl,card_sdiff sub,card_pair uw,card_neighborFinset_eq_degree]
  have pool : A ⊆ (core l u).erase v := by
    intro z hz
    obtain ⟨zn,rest⟩ := mem_sdiff.mp hz
    have vz := (G.mem_neighborFinset _ _).mp zn
    have vl : v≠u := fun eq => uv.ne eq.symm
    have zl : z≠l := fun eq => vl (D.leaf v (eq ▸ vz.symm))
    have zu : z≠u := fun eq => rest (mem_insert.mpr (Or.inl eq))
    exact mem_erase.mpr ⟨vz.ne.symm,by simp [core,zl,zu]⟩
  have inc : (((core l u).powersetCard 13).filter (fun k => v ∈ loss G l u {a,b} k)) ⊆
      (((core l u).erase v) \ A).powersetCard 13 := by
    intro k hk
    obtain ⟨samp,bad⟩ := mem_filter.mp hk
    obtain ⟨ks,szk⟩ := mem_powersetCard.mp samp
    obtain ⟨out,few⟩ := mem_filter.mp bad
    have vk := (mem_sdiff.mp out).2
    refine mem_powersetCard.mpr ⟨?_,szk⟩
    intro z zk
    refine mem_sdiff.mpr ⟨mem_erase.mpr ⟨fun e => vk (e ▸ zk),ks zk⟩,?_⟩
    intro za
    obtain ⟨zn,rest⟩ := mem_sdiff.mp za
    have vz := (G.mem_neighborFinset _ _).mp zn
    have keptZ := kept_sub l u ({a,b} : Finset V) k (mem_insert_of_mem zk)
    apply (not_le_of_gt few)
    by_cases dis : Disjoint k ({a,b} : Finset V)
    · exact two G keptZ (by simp [kept,dis]) vz uv.symm (fun eq => rest (mem_insert.mpr (Or.inl eq)))
    · obtain ⟨j,jk,jp⟩ := not_disjoint_iff.mp dis
      rw [pair] at jp
      have jw : j=w := (mem_insert.mp jp).resolve_left (fun eq => vk (eq ▸ jk)) |> mem_singleton.mp
      have wk := kept_sub l u ({a,b} : Finset V) k (mem_insert_of_mem (jw ▸ jk : w ∈ k))
      exact two G keptZ wk vz vw (fun eq => rest (mem_insert_of_mem (mem_singleton.mpr eq)))
  have up := card_le_card inc
  rw [card_powersetCard,card_sdiff pool,card_erase_of_mem vs,size,sz] at up
  exact up.trans (Nat.choose_le_choose 13 (by omega))

end Graffiti384b.Pendant
#print axioms Graffiti384b.Pendant.trial
#print axioms Graffiti384b.Pendant.endpoint
