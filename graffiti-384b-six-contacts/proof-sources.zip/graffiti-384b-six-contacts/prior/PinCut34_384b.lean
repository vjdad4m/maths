import LowSample384b
import Mathlib.Combinatorics.SimpleGraph.Clique

namespace Graffiti384b.CliqueCut34
open Finset SimpleGraph
open private Repair.nbr_add Repair.full_nbr from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Vertices left outside both the two anchors and the proposed omissions
whose degree test fails. They can be kept through the subsequent cut. -/
def defects (k x : Finset V) := ((nonleaves G)\(x∪k)).filter (fun v => G.degree v+nbr G v k<3+nbr G v x)

/-- Any retained anchor set can support multiple simultaneous omissions. -/
theorem pin_obstruction {k x : Finset V} (kn : k⊆nonleaves G)
    (xn : x⊆nonleaves G) (xk : Disjoint x k) (hit : ∀ v∈x,2≤nbr G v k)
    (same : (nonleaves G).card=(types G).card) (fail : bound G<gamma G) :
    x.card+1≤k.card+(defects G k x).card := by
  let R := nonleaves G\(x∪k)
  let S := R\defects G k x
  let B := (x∪S)ᶜ
  have xs : Disjoint x S := disjoint_left.mpr (fun _ vx vs => (mem_sdiff.mp (mem_sdiff.mp vs).1).2 (mem_union_left _ vx))
  have xb : Disjoint x B := disjoint_left.mpr (fun _ vx vb => mem_compl.mp vb (mem_union_left _ vx))
  have bs : Disjoint B S := disjoint_left.mpr (fun _ vb vs => mem_compl.mp vb (mem_union_right _ vs))
  have kb : k⊆B := fun _ vk => mem_compl.mpr (fun m => (mem_union.mp m).elim (fun vx => disjoint_left.mp xk vx vk)
    (fun vs => (mem_sdiff.mp (mem_sdiff.mp vs).1).2 (mem_union_right _ vk)))
  have hxb (v : V) (vm : v∈x) := (hit v vm).trans (card_le_card (filter_subset_filter (G.Adj v) kb))
  have cap := Repair.seeded_cut G x B S xb xs bs hxb (by
    intro v vs
    have nr := mem_sdiff.mp vs
    have enough : 3+nbr G v x≤G.degree v+nbr G v k := Nat.le_of_not_gt (fun lt => nr.2 (mem_filter.mpr ⟨nr.1,lt⟩))
    have eq : S∪B=xᶜ := by
      ext i; simp only [B,mem_union,mem_compl]
      have sep : i∈x → i∈S → False := fun a b => disjoint_left.mp xs a b
      tauto
    have total := Repair.full_nbr G v x
    rw [←eq,Repair.nbr_add G v bs.symm] at total
    have inc : nbr G v k≤nbr G v B := card_le_card (filter_subset_filter _ kb)
    omega)
  have count : S.card+(defects G k x).card=R.card := card_sdiff_add_card_eq_card (filter_subset _ _)
  have count2 : R.card+(x∪k).card=(nonleaves G).card := card_sdiff_add_card_eq_card (union_subset xn kn)
  rw [card_union_of_disjoint xk,same] at count2
  unfold bound at fail
  omega

end Graffiti384b.CliqueCut34
#print axioms Graffiti384b.CliqueCut34.pin_obstruction
