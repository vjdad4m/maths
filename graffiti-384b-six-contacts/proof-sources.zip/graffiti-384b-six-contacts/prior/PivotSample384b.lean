import StratumTrial35_384b
import SmallScores35_384b

namespace Graffiti384b.PivotSample
open Finset SimpleGraph BlockActivation LowSample
open private FiniteRange.bad from FiniteRange384b
open private LowSample.eligible LowSample.anchors LowSample.weight from LowSample384b
open private SmallScores35.allowed from SmallScores35_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem trial {x y : V} {k : Finset V} (xh : x ∈ high G) (yd : G.degree y=2)
    (inside : G.neighborFinset x ⊆ high G \ {x}) (yn : G.neighborFinset y ⊆ high G \ {x})
    (ks : k ⊆ high G \ {x}) (hit : 2 ≤ nbr G x k)
    (protect : ∀ v ∈ G.neighborFinset x, v ∉ k → 2 ≤ nbr G v k)
    (t : (types G).card=35) (fail : bound G<gamma G) :
    let s := high G \ {x}
    s.card-k.card+1+(if 2 ≤ nbr G y k then 1 else 0) ≤ 17+(FiniteRange.bad G s k).card ∧
    FiniteRange.bad G s k ⊆ s \ G.neighborFinset x := by
  let s := high G \ {x}
  have bound := BlockTrial.trial G {x} k {x} (singleton_subset_iff.mpr xh) ks Subset.rfl
    (fun w hw => (mem_singleton.mp hw) ▸ inside.trans sdiff_subset)
    (fun w hw => (mem_singleton.mp hw) ▸ hit) (fun w hw v edge out =>
      protect v ((G.mem_neighborFinset _ _).mpr ((mem_singleton.mp hw) ▸ edge)) out) fail
  dsimp only at bound ⊢
  rw [t,card_singleton] at bound
  have yl : y ∈ twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,yd.ge⟩,
    fun mem => by have := (mem_filter.mp mem).2; omega⟩
  have anchorsEq : LowSample.anchors G y=G.neighborFinset y := by
    ext w
    exact ⟨fun h => (G.mem_neighborFinset _ _).mpr (mem_filter.mp h).2,fun h =>
      mem_filter.mpr ⟨(mem_sdiff.mp (yn h)).1,(G.mem_neighborFinset _ _).mp h⟩⟩
  have earned : 6*(if 2 ≤ nbr G y k then 1 else 0) ≤ ∑ v ∈ LowSample.eligible G k, LowSample.weight (LowSample.anchors G v).card := by
    split_ifs with yes
    · have sub : k.filter (G.Adj y) ⊆ G.neighborFinset y := fun w hw => (G.mem_neighborFinset _ _).mpr (mem_filter.mp hw).2
      have eq := eq_of_subset_of_card_le sub (by rw [card_neighborFinset_eq_degree,yd]; exact yes)
      have mem : y ∈ LowSample.eligible G k := mem_filter.mpr ⟨yl,by rw [anchorsEq,← eq]; exact filter_subset _ _⟩
      have val := single_le_sum (f := fun v => LowSample.weight (LowSample.anchors G v).card) (fun _ _ => Nat.zero_le _) mem
      change LowSample.weight (LowSample.anchors G y).card ≤ _ at val
      rw [anchorsEq,card_neighborFinset_eq_degree,yd] at val
      exact val
    · simp
  constructor
  · change 6*((high G \ {x}).card-k.card)+_+6*1 ≤ 6*(17+_) at bound
    omega
  · intro v vb
    obtain ⟨out,few⟩ := mem_filter.mp vb
    exact mem_sdiff.mpr ⟨(mem_sdiff.mp out).1,fun vn => (not_le_of_gt few)
      ((protect v vn (mem_sdiff.mp out).2).trans (card_le_card (filter_subset_filter _ subset_union_right)))⟩

theorem ranks {p M : Finset V} {x : V} (ch : CliqueChoice.Choice G p Boundary.levels)
    (t : (types G).card=35) (h : (high G).card=33) (xh : x ∈ high G)
    (ms : M ⊆ high G \ {x}) {j : ℕ} (big : 3≤j) :
    (M.filter (fun v => G.degree v≤j)).card ≤ min M.card
      (CliqueChoice.slots (p.image (G.degree ·)) j Boundary.levels-2-(if G.degree x≤j then 1 else 0)) := by
  obtain ⟨inj,pos,_,_⟩ := Repair.maximal_diversity G (by omega)
  let low := M.filter (fun v => G.degree v≤j)
  let cand := (high G).filter (fun v => G.degree v≤j)
  have sub : low ⊆ cand := fun v hv => mem_filter.mpr ⟨(mem_sdiff.mp (ms (mem_filter.mp hv).1)).1,(mem_filter.mp hv).2⟩
  have ss : cand.image (trianglesAt G) ⊆ Ico 2 (CliqueChoice.slots (p.image (G.degree ·)) j Boundary.levels) := by
    intro z mem
    obtain ⟨v,vm,rfl⟩ := mem_image.mp mem
    exact mem_Ico.mpr ⟨pos _ (mem_filter.mp vm).1,SmallScores35.allowed G ch big (mem_filter.mp vm).2⟩
  have num := card_le_card ss
  rw [card_image_of_injOn (inj.mono (filter_subset _ _)),Nat.card_Ico] at num
  change cand.card ≤ CliqueChoice.slots (p.image (G.degree ·)) j Boundary.levels-2 at num
  apply le_min (card_filter_le _ _)
  by_cases yes : G.degree x≤j
  · have inc : insert x low ⊆ cand := insert_subset (mem_filter.mpr ⟨xh,yes⟩) sub
    have le := card_le_card inc
    have out : x ∉ low := fun v => (mem_sdiff.mp (ms (mem_filter.mp v).1)).2 (mem_singleton_self _)
    rw [card_insert_of_not_mem out] at le
    change low.card ≤ _-2-(if G.degree x≤j then 1 else 0)
    rw [if_pos yes]; omega
  · rw [if_neg yes,Nat.sub_zero]
    exact (card_le_card sub).trans num

end Graffiti384b.PivotSample
#print axioms Graffiti384b.PivotSample.trial
