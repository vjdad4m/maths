import PivotalProfile384b

namespace Graffiti384b.Pivotal35
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private Repair.triangles_le_choose from Repair384b
open private SmallScores35.allowed from SmallScores35_384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def upper (f : Finset ℕ) (j : ℕ) :=
  if j=6 then 14 else if j=7 ∧ f=∅ then 19 else slots f j Boundary.levels
private def available (f : Finset ℕ) (d j : ℕ) := Ico (if j<d then 3 else 2) (upper f j) \ (if 3∈f then {3} else ∅)
private def cap (f : Finset ℕ) (d j : ℕ) := min (33-f.card) (available f d j).card
private def credit (m d : ℕ) := FiniteRange.badCount m 12 d-(m-d).choose 12
private def Test (f : Finset ℕ) (d : ℕ) :=
  let m := 33-f.card
  envelope m 12 ∧ reward m 12 ∧ (m-d).choose 12 ≤ FiniteRange.badCount m 12 d ∧
  6*(17*m.choose 12+UnifiedSample.chargeAt m 12 (cap f d)) <
    6*(m-12)*m.choose 12+6*(m-2).choose 10+6*(∑ k ∈ f,bonus m 12 k)+6*credit m d

private theorem tests {f : Finset ℕ} {d : ℕ} (fs : f=∅ ∨ f={3}) (ds : d=4 ∨ d=5) : Test f d := by
  rcases fs with rfl|rfl <;> rcases ds with rfl|rfl <;>
    unfold Test cap available upper credit envelope reward UnifiedSample.chargeAt LowSample.delta LowSample.weight
      bonus slots Boundary.levels FiniteRange.badCount <;> simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose] <;> decide

/-- A count-two vertex of degree four or five cannot touch either low vertex
in a normalized least-order failure on 35 vertices. -/
theorem all_neighbors_high (res : Minimal.Residual G) (n : Fintype.card V=35) {v : V}
    (score : trianglesAt G v=2) (dv : G.degree v=4 ∨ G.degree v=5) : G.neighborFinset v ⊆ high G := by
  classical
  obtain ⟨q,t,inj⟩ := Least35.boundary G res n
  have h := high_count G res n
  have fail := res.2.2.1
  obtain ⟨_,pos,_,_⟩ := Repair.maximal_diversity G (show (types G).card=(high G).card+2 by omega)
  letI : Nonempty V := ⟨v⟩
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  let f := p.image (G.degree ·)
  let s := high G \ p
  let m := 33-f.card
  let d := G.degree v
  have sub : f ⊆ {3} := by
    intro k hk
    obtain ⟨w,wp,rfl⟩ := mem_image.mp hk
    have lev := mem_Icc.mp (ch.levels (mem_image_of_mem (G.degree ·) wp))
    change 3≤G.degree w ∧ G.degree w≤9 at lev
    change G.degree w ∈ ({3} : Finset ℕ)
    apply mem_singleton.mpr
    by_contra ne
    exact unsaturated G res n w (by omega) lev.2 (ch.exact_score w wp)
  have fs : f=∅ ∨ f={3} := by
    by_cases empty : f=∅
    · exact Or.inl empty
    · obtain ⟨k,hk⟩ := nonempty_iff_ne_empty.mpr empty
      exact Or.inr (Subset.antisymm sub (singleton_subset_iff.mpr ((mem_singleton.mp (sub hk)) ▸ hk)))
  have vs : v ∈ s := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,fun mem => by
    have ex : G.degree v=3 := mem_singleton.mp (sub (mem_image_of_mem (G.degree ·) mem))
    omega⟩
  have sz : s.card=m := by dsimp only [s,m,f]; rw [card_sdiff ch.high_sub,card_image_of_injOn ch.unique,h]
  have room : 31≤s.card := by rw [sz]; dsimp [m]; rcases fs with ef|ef <;> simp [ef]
  have dist (j : ℕ) (_jj : j ∈ range 11) (big : 3≤j) : (s.filter (fun w => G.degree w≤j)).card ≤ cap f d j := by
    let r := s.filter (fun w => G.degree w≤j)
    have inc : r.image (trianglesAt G) ⊆ available f d j := by
      intro z hz
      obtain ⟨w,wr,rfl⟩ := mem_image.mp hz
      obtain ⟨ws,small⟩ := mem_filter.mp wr
      have base := pos w (mem_sdiff.mp ws).1
      have up : trianglesAt G w < upper f j := by
        unfold upper
        split_ifs with six seven
        · subst j
          by_cases de : G.degree w=6
          · have := six_ceiling G res n w de; omega
          · have lim := (Repair.triangles_le_choose G w).trans (Nat.choose_le_choose 2 (show G.degree w≤5 by omega))
            change trianglesAt G w ≤ 10 at lim
            omega
        · obtain ⟨rfl,ef⟩ := seven
          by_cases de : G.degree w=7
          · have cub (z : V) (dz : G.degree z=3) : trianglesAt G z≠3 := by
              intro hit
              have cl := ch.covers z (by rw [dz]; decide) (by rw [dz,hit]; decide)
              change G.degree z ∈ f at cl
              rw [ef] at cl
              exact not_mem_empty _ cl
            have := seven_ceiling G res n cub w de; omega
          · have lim := (Repair.triangles_le_choose G w).trans (Nat.choose_le_choose 2 (show G.degree w≤6 by omega))
            change trianglesAt G w ≤ 15 at lim
            omega
        · exact SmallScores35.allowed G ch big small
      apply mem_sdiff.mpr
      constructor
      · apply mem_Ico.mpr
        refine ⟨?_,up⟩
        split_ifs with less
        · have ne : trianglesAt G w≠2 := fun eq => by
            have same := inj (eq.trans score.symm)
            subst w
            exact (not_lt_of_ge small) less
          omega
        · exact base
      · split_ifs with three
        · intro mem
          obtain ⟨b,bp,bd⟩ := mem_image.mp three
          have sc := ch.exact_score b bp
          rw [bd] at sc
          change trianglesAt G b=3 at sc
          exact (mem_sdiff.mp ws).2 ((inj ((mem_singleton.mp mem).trans sc.symm)) ▸ bp)
        · exact not_mem_empty _
    have count := card_le_card inc
    rw [card_image_of_injective _ inj] at count
    exact le_min ((card_filter_le _ _).trans_eq sz) count
  intro w vw
  apply Classical.byContradiction
  intro notHigh
  have outside : w ∉ s := fun m => notHigh (mem_sdiff.mp m).1
  let extra (z : V) := if z=v then credit m d else 0
  obtain ⟨env,rew,pay,win⟩ := tests fs dv
  have refund (z : V) (zs : z ∈ s) :
      ((s.powersetCard 12).filter (fun k => z ∈ FiniteRange.bad G s k)).card+extra z ≤
        FiniteRange.badCount s.card 12 (min (G.degree z) 11) := by
    by_cases eq : z=v
    · subst z
      have bound := BoundaryFiber.count G s 12 d vs outside ((G.mem_neighborFinset _ _).mp vw) (le_refl _) (by dsimp [d]; omega)
      have small : G.degree v≤11 := by omega
      rw [min_eq_left small,sz]
      rw [sz] at bound
      change _ + (if v=v then _ else 0) ≤ FiniteRange.badCount m 12 d
      rw [if_pos rfl]
      unfold credit
      change (m-d).choose 12 ≤ FiniteRange.badCount m 12 d at pay
      omega
    · rw [show extra z=0 from if_neg eq,Nat.add_zero]
      exact FiniteRange.count_bad G s 12 _ z zs (min_le_left _ _) (lt_of_le_of_lt (min_le_right _ _) (by omega))
  have obs := UnifiedSample.extraObstruction G ch 12 (cap f d) dist extra refund (by decide) (sz ▸ env) (sz ▸ rew) fail
  dsimp only at obs
  rw [t,h] at obs
  have extraSum : (∑ z ∈ s, extra z)=credit m d := by simp [extra,vs]
  have nh : high G ⊆ nonleaves G := fun _ hh => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hh).2; omega⟩
  have two := card_sdiff_add_card_eq_card nh
  change (twos G).card+(high G).card=(nonleaves G).card at two
  change 6*(m-12)*m.choose 12+(twos G).card*(6*(m-2).choose 10)+6*(∑ k ∈ f, bonus m 12 k)+6*(∑ z ∈ s, extra z)
    ≤ 6*(17*m.choose 12+UnifiedSample.chargeAt m 12 (cap f d)) at obs
  rw [extraSum,show (twos G).card=1 by omega,Nat.one_mul] at obs
  exact (not_lt_of_ge obs) win

/-- The unique count-two vertex avoids the leaf and has degree three or
four; if it meets the unique degree-two vertex it must be cubic. -/
theorem two_separation (res : Minimal.Residual G) (n : Fintype.card V=35) {v l : V}
    (score : trianglesAt G v=2) (lz : trianglesAt G l=0) (dl : G.degree l=1) :
    ¬G.Adj v l ∧ (G.degree v=3 ∨ G.degree v=4) ∧
    (∀ u, G.degree u=2 → G.Adj v u → G.degree v=3) := by
  obtain ⟨e,f,_,_,_,_,_,shape⟩ := TwoLinks35.shape G res.2.2.2.1 lz score
  have no : ¬G.Adj v l := by
    intro adj
    rw [if_pos adj] at shape
    have dv : G.degree v=4 ∨ G.degree v=5 := by split_ifs at shape <;> omega
    have high := all_neighbors_high G res n score dv ((G.mem_neighborFinset _ _).mpr adj)
    have := (mem_filter.mp high).2
    omega
  rw [if_neg no,Nat.add_zero] at shape
  have dv : G.degree v=3 ∨ G.degree v=4 := by split_ifs at shape <;> omega
  refine ⟨no,dv,?_⟩
  intro u du edge
  rcases dv with three|four
  · exact three
  · have high := all_neighbors_high G res n score (Or.inl four) ((G.mem_neighborFinset _ _).mpr edge)
    have := (mem_filter.mp high).2
    omega

end Graffiti384b.Pivotal35
#print axioms Graffiti384b.Pivotal35.all_neighbors_high
#print axioms Graffiti384b.Pivotal35.two_separation
