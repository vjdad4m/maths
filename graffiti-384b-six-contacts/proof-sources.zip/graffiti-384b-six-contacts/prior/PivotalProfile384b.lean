import Least35_384b
import PendantCount384b
import CliquePivot384b
import TwoLinks35_384b

namespace Graffiti384b.Pivotal35
open Finset SimpleGraph CliqueChoice Pendant
open private TrianglePrune.triangle_iff from TrianglePrune384b
open private Repair.triangles_le_choose from Repair384b
open private Stratum35.ear from StratumFinish35_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem profiles34 {f : Finset ℕ} (old : LowerProfiles.residual 34 34 f) : f ∈ Pendant.profiles := by
  simp [LowerProfiles.residual] at old
  simp only [Pendant.profiles,mem_insert,mem_singleton]
  tauto

/-- An actual order-35 graph with pairwise distinct counts and 34 high
vertices satisfies the inequality if its leaf meets the cubic count-one vertex. -/
theorem exact_cubic_leaf (n : Fintype.card V=35) (t : (types G).card=35) (h : (high G).card=34)
    {l u : V} (dl : G.degree l=1) (du : G.degree u=3) (ul : G.Adj u l) (us : trianglesAt G u=1) :
    gamma G ≤ bound G := by
  by_contra! fail
  have eqCard : (univ.image (trianglesAt G)).card=(univ : Finset V).card := by change (types G).card=_; rw [card_univ,t,n]
  have inject := card_image_iff.mp eqCard
  have inj : Function.Injective (trianglesAt G) := fun i j e => inject (mem_univ i) (mem_univ j) e
  have cap := Repair.triangles_le_choose G l
  rw [dl] at cap
  have lz : trianglesAt G l=0 := Nat.eq_zero_of_le_zero cap
  have leaf (z : V) (lz' : G.Adj l z) : z=u := by
    have num : (G.neighborFinset l).card≤1 := ((card_neighborFinset_eq_degree _ _).trans dl).le
    exact card_le_one.mp num z ((G.mem_neighborFinset _ _).mpr lz') u ((G.mem_neighborFinset _ _).mpr ul.symm)
  have subH : high G ⊆ nonleaves G := fun v hv => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have q : 34≤(nonleaves G).card := h ▸ card_le_card subH
  obtain ⟨a,b,ua,ub,ab⟩ := (TrianglePrune.triangle_iff G u).mp (by omega)
  have al : a≠l := fun eq => ub.ne.symm (leaf b (eq ▸ ab))
  have bl : b≠l := fun eq => ua.ne.symm (leaf a (eq ▸ ab.symm))
  have sub : ({l,a,b} : Finset V) ⊆ G.neighborFinset u := insert_subset
    ((G.mem_neighborFinset _ _).mpr ul) (insert_subset ((G.mem_neighborFinset _ _).mpr ua)
      (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr ub)))
  have nearEq := eq_of_subset_of_card_le sub (by rw [card_neighborFinset_eq_degree,du]; simp [al.symm,bl.symm,ab.ne])
  have geom : Geometry G l u a b := ⟨ul,ua,ub,ab,leaf,fun z edge => by
    have mem := (G.mem_neighborFinset _ _).mpr edge
    rwa [← nearEq,mem_insert,mem_insert,mem_singleton] at mem⟩
  have low : l ∉ high G := by
    intro mem
    have le : (G.neighborFinset l).card ≤ 1 := card_le_one.mpr (fun x hx y hy =>
      (leaf x ((G.mem_neighborFinset _ _).mp hx)).trans (leaf y ((G.mem_neighborFinset _ _).mp hy)).symm)
    rw [card_neighborFinset_eq_degree] at le
    have := (mem_filter.mp mem).2
    omega
  have eq : high G = ({l} : Finset V)ᶜ := eq_of_subset_of_card_le
    (fun v hv => mem_compl.mpr (fun mem => low ((mem_singleton.mp mem) ▸ hv)))
    (by rw [card_compl,card_singleton,n,h])
  have active (v : V) (hv : v ∈ core l u) : 3 ≤ G.degree v := by
    have mem : v ∈ high G := by
      rw [eq]
      exact mem_compl.mpr (fun m => mem_compl.mp hv (mem_insert.mpr (Or.inl (mem_singleton.mp m))))
    exact (mem_filter.mp mem).2
  have pos (v : V) (hv : v ∈ core l u) : 2 ≤ trianglesAt G v := by
    have zero : trianglesAt G v≠0 := fun e => mem_compl.mp hv (mem_insert.mpr (Or.inl (inj (e.trans lz.symm))))
    have one : trianglesAt G v≠1 := fun e => mem_compl.mp hv (mem_insert_of_mem (mem_singleton.mpr (inj (e.trans us.symm))))
    omega
  letI : Nonempty V := ⟨u⟩
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  have old := LowerProfiles.saturated_profiles G ch t (by simp [h]) 34 (by decide) q fail
  rw [h] at old
  have prof := profiles34 old
  exact (not_lt_of_ge (Pendant.exact G geom n t inj active pos ch prof)) fail

/-- In a normalized least-order failure with 35 vertices exactly
33 vertices have degree at least three. -/
theorem high_count (res : Minimal.Residual G) (n : Fintype.card V=35) : (high G).card=33 := by
  obtain ⟨_,t,_⟩ := Least35.boundary G res n
  have cap := type_bound G
  have miss : ((high G).card+1)/2 < ((types G).card+1)/2 :=
    Nat.lt_of_not_ge (fun le => (not_lt_of_ge (exact_of_high G le)) res.2.2.1)
  by_contra! wrong
  have h : (high G).card=34 := by omega
  obtain ⟨u,_,us,_,_,_,_,caseH⟩ := Least35.small_witnesses G res n
  obtain ⟨du,_,l,lz,ul⟩ := caseH h
  have normal := res.2.2.2.1
  have le : (G.neighborFinset l).card≤1 := card_le_one.mpr (fun i hi j hj =>
    normal.2.1 l lz i j ((G.mem_neighborFinset _ _).mp hi) ((G.mem_neighborFinset _ _).mp hj))
  rw [card_neighborFinset_eq_degree] at le
  have pos := (G.degree_pos_iff_exists_adj l).mpr ⟨u,ul.symm⟩
  exact (not_lt_of_ge (exact_cubic_leaf G n t h (by omega : G.degree l=1) du ul us)) res.2.2.1

/-- A degree-six center in the surviving least-order case has at most
thirteen incident triangles, two below the complete neighborhood. -/
theorem six_ceiling (res : Minimal.Residual G) (n : Fintype.card V=35) (x : V) (deg : G.degree x=6) : trianglesAt G x ≤ 13 := by
  obtain ⟨q,t,_⟩ := Least35.boundary G res n
  have hc := high_count G res n
  by_contra! more
  have num := BlockGeometry.gap_count G x
  rw [deg] at num
  change _ + trianglesAt G x=15 at num
  exact (not_lt_of_ge (Six.exact_six G t hc q x deg (by omega))) res.2.2.1

private theorem choices {f : Finset ℕ} {d : ℕ} (row : LowerProfiles.residual 34 33 f)
    (df : d∈f) (lo : 4≤d) : d=6 ∨ CliquePivot.applies d f := by
  simp [LowerProfiles.residual] at row
  rcases row with rfl|rfl|rfl|rfl|rfl|rfl|rfl <;> simp_all [CliquePivot.applies] <;> omega

/-- Across all orders, a 35-type graph with precisely 33 high vertices and
34 nonleaves satisfies the conjecture if a degree-four-through-nine vertex
has a complete neighborhood. -/
theorem exact_saturated (t : (types G).card=35) (h : (high G).card=33) (q : (nonleaves G).card=34)
    (x : V) (lo : 4≤G.degree x) (up : G.degree x≤9) (sat : trianglesAt G x=(G.degree x).choose 2) :
    gamma G ≤ bound G := by
  by_contra! fail
  letI : Nonempty V := ⟨x⟩
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  have row := LowerProfiles.saturated_profiles G ch t (by simp [h]) 34 (by decide) q.ge fail
  rw [h] at row
  have df := ch.covers x (mem_Icc.mpr ⟨by omega,up⟩) sat
  rcases choices row df lo with dx|case
  · have num := BlockGeometry.gap_count G x
    rw [sat,dx] at num
    exact (not_lt_of_ge (Six.exact_six G t h q x dx (by omega))) fail
  · exact (not_lt_of_ge (CliquePivot.exact G ch t h q x (saturated_clique G sat) case)) fail

theorem unsaturated (res : Minimal.Residual G) (n : Fintype.card V=35)
    (x : V) (lo : 4≤G.degree x) (up : G.degree x≤9) : trianglesAt G x ≠ (G.degree x).choose 2 := by
  obtain ⟨q,t,_⟩ := Least35.boundary G res n
  exact fun sat => (not_lt_of_ge (exact_saturated G t (high_count G res n) q x lo up sat)) res.2.2.1

/-- In the absence of a saturated cubic, the earlier degree-seven theorem
excludes scores 19 through 21; all its other unsaturation hypotheses now follow. -/
theorem seven_ceiling (res : Minimal.Residual G) (n : Fintype.card V=35)
    (cub : ∀ z, G.degree z=3 → trianglesAt G z≠3) (x : V) (dx : G.degree x=7) : trianglesAt G x≤18 := by
  obtain ⟨q,t,_⟩ := Least35.boundary G res n
  by_contra! more
  have sc := BlockGeometry.gap_count G x
  rw [dx] at sc
  change _+trianglesAt G x=21 at sc
  apply (not_lt_of_ge (Least35.exact_degree_seven G t (high_count G res n) q ?_ x dx (by omega))) res.2.2.1
  intro v tested
  obtain ⟨lower,upper⟩ := mem_Icc.mp tested
  by_cases d : G.degree v=3
  · rw [d]; exact cub v d
  · exact unsaturated G res n v (by omega) upper

/-- The zero, one and two witnesses in the remaining normalized case, together
with the two exact neighborhood shapes for the count-two vertex. -/
theorem witnesses (res : Minimal.Residual G) (n : Fintype.card V=35) :
    ∃ l u v a b, trianglesAt G l=0 ∧ G.degree l=1 ∧ trianglesAt G u=1 ∧
      G.neighborFinset u={a,b} ∧ G.Adj a b ∧ a∈high G ∧ b∈high G ∧ trianglesAt G v=2 ∧
      ∃ e f : Finset V, e≠f ∧ TwoLinks35.pairs G v={e,f} ∧ e.card=2 ∧ f.card=2 ∧
        (G.neighborFinset v).erase l=e∪f ∧ G.degree v=(if Disjoint e f then 4 else 3)+(if G.Adj v l then 1 else 0) := by
  obtain ⟨q,t,inj⟩ := Least35.boundary G res n
  have h := high_count G res n
  have diversity := Repair.maximal_diversity G (show (types G).card=(high G).card+2 by omega)
  obtain ⟨l,_,lz⟩ := mem_image.mp diversity.2.2.1
  obtain ⟨u,v,us,vs,_,_,_,_⟩ := Least35.small_witnesses G res n
  have ul : u≠l := fun eq => by rw [eq,lz] at us; contradiction
  have normal := res.2.2.2.1
  have dl : G.degree l≤1 := by
    rw [← card_neighborFinset_eq_degree]
    exact card_le_one.mpr (fun i hi j hj => normal.2.1 l lz i j ((G.mem_neighborFinset _ _).mp hi) ((G.mem_neighborFinset _ _).mp hj))
  obtain ⟨z,zl,w,_,zw⟩ := BoundaryFiber.crossing G res.2.1 (s:={l}) ⟨l,mem_singleton_self _⟩ ⟨u,fun m => ul (mem_singleton.mp m)⟩
  obtain rfl := mem_singleton.mp zl
  have lp := (G.degree_pos_iff_exists_adj z).mpr ⟨w,zw⟩
  have du : G.degree u≤2 := Nat.le_of_not_gt (fun big => by
    have pos := diversity.2.1 u (mem_filter.mpr ⟨mem_univ _,big⟩)
    omega)
  obtain ⟨a,b,ua,ub,ab⟩ := (TrianglePrune.triangle_iff G u).mp (by omega)
  have pair := eq_of_subset_of_card_le (insert_subset ((G.mem_neighborFinset _ _).mpr ua)
    (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr ub))) (by rw [card_pair ab.ne,card_neighborFinset_eq_degree]; exact du)
  have endpoint {w : V} (uw : G.Adj u w) (pos : 0<trianglesAt G w) : w∈high G := by
    have one : trianglesAt G w ≠ 1 := fun e => uw.ne (inj (us.trans e.symm))
    by_contra no
    have low : G.degree w ≤ 2 := Nat.le_of_not_gt (fun big => no (mem_filter.mpr ⟨mem_univ _,big⟩))
    have cap := (Repair.triangles_le_choose G w).trans (Nat.choose_le_choose 2 low)
    rw [Nat.choose_self] at cap
    omega
  exact ⟨z,u,v,a,b,lz,by omega,us,pair.symm,ab,endpoint ua ((TrianglePrune.triangle_iff G a).mpr ⟨u,b,ua.symm,ab,ub⟩),
    endpoint ub ((TrianglePrune.triangle_iff G b).mpr ⟨u,a,ub.symm,ab.symm,ua⟩),vs,TwoLinks35.shape G normal lz vs⟩

end Graffiti384b.Pivotal35
#print axioms Graffiti384b.Pivotal35.high_count
#print axioms Graffiti384b.Pivotal35.six_ceiling
#print axioms Graffiti384b.Pivotal35.unsaturated
#print axioms Graffiti384b.Pivotal35.witnesses
#print axioms Graffiti384b.Pivotal35.exact_cubic_leaf
#print axioms Graffiti384b.Pivotal35.exact_saturated
#print axioms Graffiti384b.Pivotal35.seven_ceiling
