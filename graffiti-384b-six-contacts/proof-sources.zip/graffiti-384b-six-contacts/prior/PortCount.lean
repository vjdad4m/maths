import PortFrames
import ChoicePatch
namespace Graffiti384b.Exterior
open Finset SimpleGraph FiveChoice
open private Repair.edge_info from Repair384b
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def boundary (S W : Finset V) := W.filter (fun u => ∃x∈S,G.Adj u x)

omit [DecidableEq V] in
/-- Count the incidences in both directions. The sets may overlap. -/
theorem transpose (U W : Finset V) : (∑u∈U,nbr G u W)=∑w∈W,nbr G w U := by
  classical
  have eq (v : V) (T : Finset V) : nbr G v T=∑t∈T,if G.Adj v t then 1 else 0 := by simp [nbr]
  simp only [eq]; rw [sum_comm]
  apply sum_congr rfl
  intro w _
  apply sum_congr rfl
  intro u _
  by_cases h : G.Adj u w
  · simp [h,h.symm]
  · simp [h,show ¬G.Adj w u from fun e => h e.symm]

theorem local_limits {P Q S W : Finset V} {a : V} (H : Ports G P Q S W a)
    (no : ¬Closes G P Q W 3) :
    (∀u∈W,nbr G u S≤1) ∧ (∀z∈W,nbr G z (boundary G S W)≤1) := by
  constructor
  · intro u uw; by_contra! many
    obtain ⟨x,xm,y,ym,xy⟩ := one_lt_card.mp many
    obtain ⟨L,R,pl,qr,f,size⟩ := one_port G H uw (mem_filter.mp xm).1 (mem_filter.mp ym).1 xy (mem_filter.mp xm).2 (mem_filter.mp ym).2
    exact no ⟨L,R,pl,qr,f,by omega⟩
  · intro z zw; by_contra! many
    obtain ⟨u,um,v,vm,uv⟩ := one_lt_card.mp many
    obtain ⟨hu,zu⟩ := mem_filter.mp um
    obtain ⟨hv,zv⟩ := mem_filter.mp vm
    obtain ⟨uw,x,xs,ux⟩ := mem_filter.mp hu
    obtain ⟨vw,y,ys,vy⟩ := mem_filter.mp hv
    exact no (shared_second_neighbor G H uw vw zw uv xs ys ux vy zu zv)

/-- If the boundary sends more incidences back into W than W has vertices,
a common second neighbor completes the cut with at most three W-pins. -/
theorem incidence_solution {P Q S W : Finset V} {a : V} (H : Ports G P Q S W a)
    (many : W.card<∑u∈boundary G S W,nbr G u W) : Closes G P Q W 3 := by
  by_contra no
  have lim := sum_le_sum (local_limits G H no).2
  rw [←transpose G, sum_const,nsmul_eq_mul,Nat.cast_id,mul_one] at lim
  omega

private theorem rem_pair {p : Finset V} {u : V} (two : p.card=2) (um : u∈p) :
    ∃v,u≠v ∧ p={u,v} := by
  obtain ⟨v,w,vw,rfl⟩ := card_eq_two.mp two
  rcases mem_insert.mp um with rfl|uw
  · exact ⟨w,vw,rfl⟩
  · obtain rfl := mem_singleton.mp uw
    exact ⟨v,vw.symm,pair_comm ..⟩

variable [Fintype V]

/-- In the absence of a three-pin repair, the surviving link edges at each
port form a matching. -/
theorem port_matching {P Q S W : Finset V} {a p : V} (H : Ports G P Q S W a)
    (no : ¬Closes G P Q W 3) (ps : p∈S) :
    2*(kept (link G p) W).card≤nbr G p W := by
  let L := kept (link G p) W
  have info {s : Finset V} (sm : s∈L) := Repair.edge_info G (mem_filter.mp sm).1
  have inside {s : Finset V} (sm : s∈L) {v : V} (vm : v∈s) : v∈boundary G S W :=
    mem_filter.mpr ⟨(mem_filter.mp sm).2 vm,p,ps,((G.mem_neighborFinset ..).mp ((info sm).1 vm)).symm⟩
  have apart : L.toSet.PairwiseDisjoint id := by
    intro s sm t tm ne
    apply disjoint_left.mpr
    intro u us ut
    obtain ⟨v,uv,sv⟩ := rem_pair (info sm).2.1 us
    obtain ⟨w,uw,tw⟩ := rem_pair (info tm).2.1 ut
    have vs : v∈s := sv ▸ mem_insert_of_mem (mem_singleton_self _)
    have wt : w∈t := tw ▸ mem_insert_of_mem (mem_singleton_self _)
    have vu := (info sm).2.2 u us v vs uv
    have wu := (info tm).2.2 u ut w wt uw
    have cap := (local_limits G H no).2 u ((mem_filter.mp sm).2 us)
    have eq := card_le_one.mp cap v (mem_filter.mpr ⟨inside sm vs,vu⟩) w (mem_filter.mpr ⟨inside tm wt,wu⟩)
    exact ne (sv.trans (eq ▸ tw.symm))
  have unionIn : L.biUnion id ⊆ W.filter (G.Adj p) := by
    intro u um
    obtain ⟨s,sm,us⟩ := mem_biUnion.mp um
    exact mem_filter.mpr ⟨(mem_filter.mp sm).2 us,(G.mem_neighborFinset ..).mp ((info sm).1 us)⟩
  have cap := card_le_card unionIn
  rw [card_biUnion apart] at cap
  have eq : (∑s∈L,(id s).card)=∑_s∈L,2 := sum_congr rfl (fun s sm => (info sm).2.1)
  rw [eq,sum_const,nsmul_eq_mul,Nat.cast_id,Nat.mul_comm] at cap
  exact cap

theorem boundary_size {P Q S W : Finset V} {a : V} (H : Ports G P Q S W a)
    (no : ¬Closes G P Q W 3) :
    2*(∑p∈S,(kept (link G p) W).card)≤(boundary G S W).card := by
  have lower := sum_le_sum (s:=S) (fun p hp => port_matching G H no hp)
  rw [←Finset.mul_sum,transpose G] at lower
  have cap : (∑u∈W,nbr G u S)≤∑u∈W,if u∈boundary G S W then 1 else 0 := by
    apply sum_le_sum
    intro u um
    by_cases mem : u∈boundary G S W
    · simpa [mem] using (local_limits G H no).1 u um
    · rw [if_neg mem]
      have empty : S.filter (G.Adj u)=∅ := eq_empty_of_forall_not_mem (fun v vm => mem (mem_filter.mpr ⟨um,v,(mem_filter.mp vm).1,(mem_filter.mp vm).2⟩))
      simp [nbr,empty]
  have inc : boundary G S W⊆W := filter_subset ..
  rw [sum_boole,filter_mem_eq_inter,inter_eq_right.mpr inc] at cap
  exact lower.trans cap
end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.local_limits
#print axioms Graffiti384b.Exterior.incidence_solution
#print axioms Graffiti384b.Exterior.port_matching
#print axioms Graffiti384b.Exterior.boundary_size
