import Recolor34_384b
namespace Graffiti384b.Exterior
open Finset SimpleGraph
open private Repair.nbr_mono Repair.nbr_add from Repair384b
variable {V : Type*} [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Both shores protect every pin except for a single missing neighbor of a. -/
structure Gap (P Q : Finset V) (a : V) : Prop where
  apart : Disjoint P Q
  pinned : a∈P
  one : 1≤nbr G a Q
  left : ∀v∈P,v≠a → 2≤nbr G v Q
  right : ∀v∈Q,2≤nbr G v P

def Protected (P Q : Finset V) : Prop :=
  Disjoint P Q ∧ (∀v∈P,2≤nbr G v Q) ∧ ∀v∈Q,2≤nbr G v P

/-- Add opposite-shore neighbors to repair a gap, counting only the new pins in W. -/
def Closes (P Q W : Finset V) (k : ℕ) : Prop :=
  ∃ L R : Finset V, P⊆L ∧ Q⊆R ∧ Protected G L R ∧ ((L∪R)∩W).card≤k

private theorem join {P Q I J W : Finset V} {a : V} (partialCut : Gap G P Q a)
    (outside : Disjoint (P∪Q) (I∪J)) (apart : Disjoint I J)
    (fresh : ∃v∈J,G.Adj a v)
    (left : ∀v∈I,2≤nbr G v (Q∪J)) (right : ∀v∈J,2≤nbr G v (P∪I))
    {k : ℕ} (size : ((P∪I∪(Q∪J))∩W).card≤k) : Closes G P Q W k := by
  have pj : Disjoint P J := outside.mono subset_union_left subset_union_right
  have qi : Disjoint Q I := outside.mono subset_union_right subset_union_left
  have qj : Disjoint Q J := outside.mono subset_union_right subset_union_right
  refine ⟨P∪I,Q∪J,subset_union_left,subset_union_left,⟨?_,?_,?_⟩,size⟩
  · simp only [disjoint_union_left,disjoint_union_right]
    exact ⟨⟨partialCut.apart,qi.symm⟩,pj,apart⟩
  · intro v vm
    rcases mem_union.mp vm with vp|vi
    · by_cases eq : v=a
      · subst v
        obtain ⟨u,um,au⟩ := fresh
        have pos := Finset.card_pos.mpr ⟨u,mem_filter.mpr ⟨um,au⟩⟩
        rw [Repair.nbr_add G _ qj]
        have one := partialCut.one
        change 0<nbr G a J at pos
        omega
      · exact (partialCut.left v vp eq).trans (Repair.nbr_mono G v subset_union_left)
    · exact left v vi
  · intro v vm
    exact (mem_union.mp vm).elim (fun h => (partialCut.right v h).trans (Repair.nbr_mono G v subset_union_left)) (right v)

/-- Admissible ports lie outside the local cut and all see its deficient anchor.
W is the further region from which at most three vertices will be pinned. -/
structure Ports (P Q S W : Finset V) (a : V) : Prop extends Gap G P Q a where
  fresh : Disjoint (P∪Q) (S∪W)
  apartRegions : Disjoint S W
  touch : ∀x∈S,G.Adj a x

private theorem extra_size {P Q I J S W A : Finset V} (H : Disjoint (P∪Q) (S∪W))
    (D : Disjoint S W) (inc : I∪J⊆S∪A) : ((P∪I∪(Q∪J))∩W).card≤A.card := by
  apply card_le_card
  intro v vm
  obtain ⟨vm,vw⟩ := mem_inter.mp vm
  have old : v∉P∪Q := fun h => disjoint_left.mp H h (mem_union_right _ vw)
  have newmem : v∈I∪J := by
    rcases mem_union.mp vm with l|r
    · exact mem_union_left _ ((mem_union.mp l).resolve_left (fun m => old (mem_union_left _ m)))
    · exact mem_union_right _ ((mem_union.mp r).resolve_left (fun m => old (mem_union_right _ m)))
  exact (mem_union.mp (inc newmem)).resolve_left (fun m => disjoint_left.mp D m vw)

theorem one_port {P Q S W : Finset V} {a z x y : V} (H : Ports G P Q S W a)
    (zw : z∈W) (xs : x∈S) (ys : y∈S) (xy : x≠y) (zx : G.Adj z x) (zy : G.Adj z y) :
    Closes G P Q W 1 := by
  let I : Finset V := {z}
  let J : Finset V := {x,y}
  have iw : I⊆W := singleton_subset_iff.mpr zw
  have js : J⊆S := insert_subset xs (singleton_subset_iff.mpr ys)
  have az : a≠z := fun eq => disjoint_left.mp H.fresh (mem_union_left _ H.pinned) (mem_union_right _ (eq ▸ zw))
  apply join G H.toGap (H.fresh.mono_right (union_subset (iw.trans subset_union_right) (js.trans subset_union_left)))
    (H.apartRegions.symm.mono iw js) ⟨x,mem_insert_self ..,H.touch x xs⟩
  · intro v vm
    have eq := mem_singleton.mp (show v∈({z}:Finset V) from vm)
    subst v
    exact PinnedColor34.two G xy zx zy (mem_union_right _ (mem_insert_self ..)) (mem_union_right _ (mem_insert_of_mem (mem_singleton_self _)))
  · intro v vm
    have m : G.Adj v z := (mem_insert.mp vm).elim (fun e => e ▸ zx.symm) (fun e => mem_singleton.mp e ▸ zy.symm)
    exact PinnedColor34.two G az (H.touch v (js vm)).symm m (mem_union_left _ H.pinned) (mem_union_right _ (mem_singleton_self z))
  · exact (extra_size H.fresh H.apartRegions (A:=I) (union_subset subset_union_right (js.trans subset_union_left))).trans (by simp [I])

theorem shared_second_neighbor {P Q S W : Finset V} {a u v z x y : V} (H : Ports G P Q S W a)
    (uw : u∈W) (vw : v∈W) (zw : z∈W) (uv : u≠v)
    (xs : x∈S) (ys : y∈S) (ux : G.Adj u x) (vy : G.Adj v y) (zu : G.Adj z u) (zv : G.Adj z v) :
    Closes G P Q W 3 := by
  let I : Finset V := {u,v}
  let J : Finset V := {x,y,z}
  let A : Finset V := {u,v,z}
  have iw : I⊆W := insert_subset uw (singleton_subset_iff.mpr vw)
  have xa : x≠z := fun e => disjoint_left.mp H.apartRegions xs (e ▸ zw)
  have ya : y≠z := fun e => disjoint_left.mp H.apartRegions ys (e ▸ zw)
  have au : a≠u := fun e => disjoint_left.mp H.fresh (mem_union_left _ H.pinned) (mem_union_right _ (e ▸ uw))
  have av : a≠v := fun e => disjoint_left.mp H.fresh (mem_union_left _ H.pinned) (mem_union_right _ (e ▸ vw))
  have jsub : J⊆S∪{z} := insert_subset (mem_union_left _ xs)
    (insert_subset (mem_union_left _ ys) (singleton_subset_iff.mpr (mem_union_right _ (mem_singleton_self _))))
  have jbig : J⊆S∪W := jsub.trans (union_subset_union_right (singleton_subset_iff.mpr zw))
  have apart : Disjoint I J := disjoint_left.mpr (by
    intro k ki kj
    rcases mem_union.mp (jsub kj) with ks|kz
    · exact disjoint_left.mp H.apartRegions ks (iw ki)
    · have eq := mem_singleton.mp kz
      subst k
      exact (mem_insert.mp ki).elim zu.ne (fun m => zv.ne (mem_singleton.mp m)))
  have um : u∈P∪I := mem_union_right _ (mem_insert_self ..)
  have vm : v∈P∪I := mem_union_right _ (mem_insert_of_mem (mem_singleton_self _))
  have xm : x∈Q∪J := mem_union_right _ (mem_insert_self ..)
  have ym : y∈Q∪J := mem_union_right _ (mem_insert_of_mem (mem_insert_self ..))
  have zm : z∈Q∪J := mem_union_right _ (by simp [J])
  apply join G H.toGap (H.fresh.mono_right (union_subset (iw.trans subset_union_right) jbig)) apart
    ⟨x,mem_insert_self ..,H.touch x xs⟩
  · intro k km
    rcases mem_insert.mp km with rfl|rest
    · exact PinnedColor34.two G xa ux zu.symm xm zm
    · obtain rfl := mem_singleton.mp rest
      exact PinnedColor34.two G ya vy zv.symm ym zm
  · intro k km
    rcases mem_insert.mp km with rfl|rest
    · exact PinnedColor34.two G au (H.touch _ xs).symm ux.symm (mem_union_left _ H.pinned) um
    rcases mem_insert.mp rest with rfl|last
    · exact PinnedColor34.two G av (H.touch _ ys).symm vy.symm (mem_union_left _ H.pinned) vm
    obtain rfl := mem_singleton.mp last
    exact PinnedColor34.two G uv zu zv um vm
  · have ia : I⊆A := insert_subset (mem_insert_self ..) (singleton_subset_iff.mpr (mem_insert_of_mem (mem_insert_self ..)))
    have za : ({z}:Finset V)⊆A := by simp [A]
    exact (extra_size H.fresh H.apartRegions (A:=A) (union_subset (ia.trans subset_union_right)
      (jsub.trans (union_subset_union_right za)))).trans (by
        have h := card_insert_le u ({v,z}:Finset V)
        have i := card_le_two (a:=v) (b:=z)
        change (insert u ({v,z}:Finset V)).card≤3
        omega)

end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.one_port
#print axioms Graffiti384b.Exterior.shared_second_neighbor
