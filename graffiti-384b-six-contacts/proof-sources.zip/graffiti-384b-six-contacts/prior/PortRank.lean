import PortCount
namespace Graffiti384b.Exterior
open Finset SimpleGraph FiveChoice
open private Repair.nbr_add Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Distinct triangle scores force a lower bound on the return incidences
from the boundary. This applies without an order restriction. -/
theorem rank_obstruction {P Q S W : Finset V} {a : V} (H : Ports G P Q S W a)
    (no : ¬Closes G P Q W 3)
    (rich : ∀u∈boundary G S W,2≤trianglesAt G u)
    (inj : Set.InjOn (trianglesAt G) (boundary G S W : Set V))
    (cap : ∀u∈boundary G S W,trianglesAt G u≤(nbr G u (S∪W)).choose 2) :
    6*(∑p∈S,(kept (link G p) W).card)≤W.card+2 := by
  classical
  let U := boundary G S W
  let low := U.filter (fun u => nbr G u W≤2)
  have bounds (u : V) (um : u∈U) := (local_limits G H no).1 u (mem_filter.mp um).1
  have two (u : V) (um : u∈U) : 2≤nbr G u W := by
    by_contra! small
    have card := cap u um
    rw [Repair.nbr_add G u H.apartRegions] at card
    have limit := Nat.choose_le_choose 2 (by have := bounds u um; omega : nbr G u S+nbr G u W≤2)
    have one : (2:ℕ).choose 2=1 := by decide
    have := rich u um
    omega
  have slow : low.image (trianglesAt G)⊆{2,3} := by
    intro k km
    obtain ⟨u,ul,rfl⟩ := mem_image.mp km
    obtain ⟨um,small⟩ := mem_filter.mp ul
    have max := cap u um
    rw [Repair.nbr_add G u H.apartRegions] at max
    have limit := Nat.choose_le_choose 2 (by have := bounds u um; omega : nbr G u S+nbr G u W≤3)
    have three : (3:ℕ).choose 2=3 := by decide
    have := rich u um
    simp only [mem_insert,mem_singleton]; omega
  have few := (card_le_card slow).trans (card_le_two (a:=2) (b:=3))
  rw [card_image_of_injOn (inj.mono (show (low:Set V)⊆(U:Set V) from fun _ m => (mem_filter.mp m).1))] at few
  have each : ∀u∈U,3≤nbr G u W+(if u∈low then 1 else 0) := by
    intro u um
    by_cases m : u∈low
    · rw [if_pos m]; have := two u um; omega
    · rw [if_neg m]; have n : ¬nbr G u W≤2 := fun h => m (mem_filter.mpr ⟨um,h⟩); omega
  have total := sum_le_sum each
  have sub : low⊆U := filter_subset ..
  rw [sum_const,nsmul_eq_mul,Nat.cast_id,sum_add_distrib,sum_boole,filter_mem_eq_inter,inter_eq_right.mpr sub] at total
  simp only [Nat.cast_id] at total
  have small : (∑u∈U,nbr G u W)≤W.card := Nat.le_of_not_gt (fun many => no (incidence_solution G H many))
  have size := boundary_size G H no
  change 2*_≤U.card at size
  omega

/-- Two port vertices cannot occur in the same retained link edge unless a
single W-vertex sees both ports or all three lie in a set of size two. -/
theorem trim_two {P Q S W : Finset V} {a p : V} (H : Ports G P Q S W a)
    (no : ¬Closes G P Q W 3) (small : S.card≤2) (ps : p∈S) :
    kept (link G p) (S∪W)=kept (link G p) W := by
  apply Finset.Subset.antisymm _ (kept_mono subset_union_right)
  intro edge em
  obtain ⟨el,inc⟩ := mem_filter.mp em
  refine mem_filter.mpr ⟨el,?_⟩
  obtain ⟨n,two,cl⟩ := Repair.edge_info G el
  intro x xm
  by_contra xw
  have xs := (mem_union.mp (inc xm)).resolve_right xw
  obtain ⟨y,ym,yx⟩ := exists_ne_of_one_lt_card (by omega : 1<edge.card) x
  have px := (G.mem_neighborFinset ..).mp (n xm)
  have py := (G.mem_neighborFinset ..).mp (n ym)
  have xy := cl x xm y ym yx.symm
  rcases mem_union.mp (inc ym) with ys|yw
  · have sub : ({p,x,y}:Finset V)⊆S := insert_subset ps (insert_subset xs (singleton_subset_iff.mpr ys))
    have count := card_le_card sub
    have three : ({p,x,y}:Finset V).card=3 := by simp [px.ne,py.ne,yx.symm]
    omega
  · have lim := (local_limits G H no).1 y yw
    have many := PinnedColor34.two G px.ne py.symm xy.symm ps xs
    omega

theorem score_cap_of_support (v : V) (K : Finset V) (keep : Repair.linkSupport G v⊆K) :
    trianglesAt G v≤(nbr G v K).choose 2 := by
  have sub : link G v⊆(K.filter (G.Adj v)).powersetCard 2 := by
    intro p pm
    obtain ⟨pn,two,_⟩ := Repair.edge_info G pm
    exact mem_powersetCard.mpr ⟨fun u um => mem_filter.mpr
      ⟨keep (mem_biUnion.mpr ⟨p,pm,um⟩),(G.mem_neighborFinset ..).mp (pn um)⟩,two⟩
  have h := card_le_card sub
  rwa [card_powersetCard] at h

end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.rank_obstruction
#print axioms Graffiti384b.Exterior.trim_two
