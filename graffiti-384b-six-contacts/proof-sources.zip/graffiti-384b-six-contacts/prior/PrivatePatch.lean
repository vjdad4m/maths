import PrivatePorts
namespace Graffiti384b.Exterior
open Finset SimpleGraph Four29 LowSample FiveChoice
open private Repair.edge_info from Repair384b
open private Prune.link_in_core from Prune384b
open private TwoEdge34.support_of_common from TwoEdgeLink34_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem root_or_pool {e f p u : V} (D : Data G e f) (hp : p∈pool G e f)
    {edge : Finset V} (em : edge∈link G p) (um : u∈edge) : u∈roots G e f ∨ u∈pool G e f := by
  by_cases r : u∈roots G e f
  · exact Or.inl r
  apply Or.inr; apply mem_sdiff.mpr ⟨?_,r⟩
  by_contra low
  have tv : u∈twos G := mem_sdiff.mpr ⟨Prune.link_in_core G em um,low⟩
  rw [D.earSet] at tv
  have pu := (G.mem_neighborFinset ..).mp ((Repair.edge_info G em).1 um)
  have np := (mem_sdiff.mp hp).2
  rcases mem_insert.mp tv with rfl|uf
  · exact np (mem_union_left _ ((G.mem_neighborFinset ..).mpr pu.symm))
  · obtain rfl := mem_singleton.mp uf
    exact np (mem_union_right _ ((G.mem_neighborFinset ..).mpr pu.symm))

private theorem private_loss {e f p o a : V} (D : Data G e f) (hp : p∈pool G e f)
    (ar : a∈roots G e f) (root : ∀r∈roots G e f,G.Adj p r → r=a)
    (priv : ∀r∈triangleContacts G e f,G.Adj p r → r=p ∨ r=o) :
    trianglesAt G p≤(kept (link G p) (pool G e f)).card+1 := by
  let poolEdges := kept (link G p) (pool G e f)
  have sub : link G p⊆insert {a,o} poolEdges := by
    intro edge em
    by_cases inc : edge⊆pool G e f
    · exact mem_insert_of_mem (mem_filter.mpr ⟨em,inc⟩)
    obtain ⟨r,rm,out⟩ := not_subset.mp inc
    have rr := (root_or_pool G D hp em rm).resolve_right out
    obtain ⟨neighbors,two,cl⟩ := Repair.edge_info G em
    obtain rfl := root r rr ((G.mem_neighborFinset ..).mp (neighbors rm))
    obtain ⟨w,wm,wr⟩ := exists_ne_of_one_lt_card (by omega : 1<edge.card) r
    have pw := (G.mem_neighborFinset ..).mp (neighbors wm)
    have pr := (G.mem_neighborFinset ..).mp (neighbors rm)
    have rw' := cl r rm w wm wr.symm
    have wp : w∈pool G e f := (root_or_pool G D hp em wm).resolve_left (fun m => wr (root w m pw))
    have wc : w∈triangleContacts G e f := mem_filter.mpr ⟨wp,r,ar,TwoEdge34.support_of_common G rw' pr.symm pw.symm⟩
    obtain rfl := (priv w wc pw).resolve_left pw.ne.symm
    have both : ({r,w}:Finset V)⊆edge := insert_subset rm (singleton_subset_iff.mpr wm)
    have same := (eq_of_subset_of_card_le both (by rw [card_pair wr.symm,two])).symm
    exact mem_insert.mpr (Or.inl same)
  exact (card_le_card sub).trans (card_insert_le ..)

theorem local_conditions {e f a x y : V} (D : Data G e f)
    (xp : x∈pool G e f) (yp : y∈pool G e f) (ar : a∈roots G e f)
    (rootsOnly : ∀p∈({x,y}:Finset V),∀r∈roots G e f,G.Adj p r → r=a)
    (contactsOnly : ∀p∈({x,y}:Finset V),∀r∈triangleContacts G e f,G.Adj p r → r∈({x,y}:Finset V)) :
    (∀p∈({x,y}:Finset V),trianglesAt G p≤(kept (link G p) (pool G e f)).card+1) ∧
    Disjoint (boundary G {x,y} (pool G e f\{x,y})) (triangleContacts G e f) := by
  constructor
  · intro p pm
    have other : ∀r∈triangleContacts G e f,G.Adj p r → r=x ∨ r=y := fun r rc z => by
      simpa only [mem_insert,mem_singleton] using contactsOnly p pm r rc z
    rcases mem_insert.mp pm with rfl|py
    · exact private_loss G D xp ar (rootsOnly _ (mem_insert_self ..)) other
    · obtain rfl := mem_singleton.mp py
      exact private_loss G D yp ar (rootsOnly _ (mem_insert_of_mem (mem_singleton_self _))) (fun r rc z => (other r rc z).symm)
  · apply disjoint_left.mpr
    intro u um uc
    obtain ⟨uw,p,ps,adj⟩ := mem_filter.mp um
    exact (mem_sdiff.mp uw).2 (contactsOnly p ps u uc adj.symm)

/-- A test of the two ports entirely on the anchor/contact patch. Each of
them sees only a among the four anchors and only its mate among all contacts.
All other edges, and the number of contacts, may vary. -/
theorem patch_solution (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f)
    (P Q : Finset V) {a x y : V} (xy : x≠y)
    (xp : x∈pool G e f) (yp : y∈pool G e f) (ar : a∈roots G e f) (tight : trianglesAt G a=2)
    (H : Ports G P Q {x,y} (pool G e f\{x,y}) a) (ep : e∈P∪Q) (fp : f∈P∪Q)
    (rootsOnly : ∀p∈({x,y}:Finset V),∀r∈roots G e f,G.Adj p r → r=a)
    (contactsOnly : ∀p∈({x,y}:Finset V),∀r∈triangleContacts G e f,G.Adj p r → r∈({x,y}:Finset V)) :
    gamma G≤bound G := by
  apply Nat.le_of_not_gt; intro bad
  have D := data_of_failure G t h q bad de df ef
  obtain ⟨loss,off⟩ := local_conditions G D xp yp ar rootsOnly contactsOnly
  exact (not_lt_of_ge (private_branch G t q h de df ef P Q xy xp yp (D.highRoots ar) tight H ep fp loss off)) bad
end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.patch_solution
