import PortRank
import TwoEdgeLink34_384b
namespace Graffiti384b.Exterior
open Finset SimpleGraph Four29 LowSample FiveChoice
open private Repair.edge_info from Repair384b
open private Prune.link_in_core from Prune384b
open private TwoEdge34.support_of_common from TwoEdgeLink34_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem noncontact_support {e f u : V} (D : Data G e f) (up : u∈pool G e f)
    (off : u∉triangleContacts G e f) : Repair.linkSupport G u⊆pool G e f := by
  intro v vm
  obtain ⟨edge,em,ve⟩ := mem_biUnion.mp vm
  obtain ⟨sub,two,cl⟩ := Repair.edge_info G em
  obtain ⟨w,wm,wv⟩ := exists_ne_of_one_lt_card (by omega : 1<edge.card) v
  have uv := (G.mem_neighborFinset ..).mp (sub ve)
  have uw := (G.mem_neighborFinset ..).mp (sub wm)
  have vw := cl v ve w wm wv.symm
  have vr : v∉roots G e f := fun m => off (mem_filter.mpr ⟨up,v,m,TwoEdge34.support_of_common G uv.symm vw uw⟩)
  apply mem_sdiff.mpr ⟨?_,vr⟩
  by_contra low
  have twoV : v∈twos G := mem_sdiff.mpr ⟨Prune.link_in_core G em ve,low⟩
  rw [D.earSet] at twoV
  have ur : u∉roots G e f := (mem_sdiff.mp up).2
  rcases mem_insert.mp twoV with rfl|vf
  · exact ur (mem_union_left _ ((G.mem_neighborFinset ..).mpr uv.symm))
  · obtain rfl := mem_singleton.mp vf
    exact ur (mem_union_right _ ((G.mem_neighborFinset ..).mpr uv.symm))

/-- A rank obstruction for an arbitrary number of possible extra points.
Five full-port triangles suffice for a further region of up to 27 points. -/
theorem private_cut {P Q S W : Finset V} {a x y : V} (H : Ports G P Q S W a)
    (pair : S={x,y}) (xy : x≠y) (room : W.card≤27)
    (sumScores : 7≤trianglesAt G x+trianglesAt G y)
    (loss : ∀p∈S,trianglesAt G p≤(kept (link G p) (S∪W)).card+1)
    (positive : ∀u∈boundary G S W,2≤trianglesAt G u)
    (inj : Set.InjOn (trianglesAt G) (boundary G S W : Set V))
    (support : ∀u∈boundary G S W,Repair.linkSupport G u⊆S∪W) :
    Closes G P Q W 3 := by
  classical
  by_contra no
  have cap := rank_obstruction G H no positive inj (fun u um => score_cap_of_support G u _ (support u um))
  have xs : x∈S := pair ▸ mem_insert_self ..
  have ys : y∈S := pair ▸ mem_insert_of_mem (mem_singleton_self _)
  have two : S.card≤2 := pair ▸ card_le_two
  have first := loss x xs
  have second := loss y ys
  rw [trim_two G H no two xs] at first
  rw [trim_two G H no two ys] at second
  rw [pair,sum_pair xy] at cap
  omega

/-- Construct the three-pin repair directly from the four-anchor profile data. -/
theorem cut_from_data {e f : V} (D : Data G e f)
    (P Q : Finset V) {a x y : V} (xy : x≠y)
    (xp : x∈pool G e f) (yp : y∈pool G e f) (ah : a∈high G) (tight : trianglesAt G a=2)
    (H : Ports G P Q {x,y} (pool G e f\{x,y}) a)
    (loss : ∀p∈({x,y}:Finset V),trianglesAt G p≤(kept (link G p) (pool G e f)).card+1)
    (off : Disjoint (boundary G {x,y} (pool G e f\{x,y})) (triangleContacts G e f)) :
    Closes G P Q (pool G e f\{x,y}) 3 := by
  classical
  let S : Finset V := {x,y}
  let W := pool G e f\S
  have sp : S⊆pool G e f := insert_subset xp (singleton_subset_iff.mpr yp)
  have total : S∪W=pool G e f := union_sdiff_of_subset sp
  have wp : W⊆pool G e f := sdiff_subset
  have wh : boundary G S W⊆high G := (filter_subset ..).trans (wp.trans sdiff_subset)
  have xa : a≠x := fun eq => disjoint_left.mp H.fresh (mem_union_left _ H.pinned) (mem_union_left _ (eq ▸ mem_insert_self ..))
  have ya : a≠y := fun eq => disjoint_left.mp H.fresh (mem_union_left _ H.pinned) (mem_union_left _ (eq ▸ mem_insert_of_mem (mem_singleton_self _)))
  have xh : x∈high G := (mem_sdiff.mp xp).1
  have yh : y∈high G := (mem_sdiff.mp yp).1
  have sx := D.rich x xh
  have sy := D.rich y yh
  have nx : trianglesAt G x≠2 := fun eq => xa (D.scoreInj ah xh (tight.trans eq.symm))
  have ny : trianglesAt G y≠2 := fun eq => ya (D.scoreInj ah yh (tight.trans eq.symm))
  have diff : trianglesAt G x≠trianglesAt G y := fun eq => xy (D.scoreInj xh yh eq)
  have room : W.card≤27 := (card_le_card wp).trans (by rw [D.poolSize]; decide)
  have localLoss : ∀p∈S,trianglesAt G p≤(kept (link G p) (S∪W)).card+1 := by
    rw [total]; exact loss
  have localSupport : ∀u∈boundary G S W,Repair.linkSupport G u⊆S∪W := by
    intro u m
    rw [total]
    exact noncontact_support G D (wp (mem_filter.mp m).1) (fun hc => disjoint_left.mp off m hc)
  have H' : Ports G P Q S W a := H
  exact private_cut G H' rfl xy room (by omega)
    localLoss (fun u m => D.rich u (wh m)) (D.scoreInj.mono wh) localSupport

/-- In the exact 29/29/27 profile, each of two ports of a score-two anchor
may lose one triangle on restricting to the pool. No neighbor in the
remaining pool may be an anchor-triangle contact. No bound on T is needed. -/
theorem private_branch (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f)
    (P Q : Finset V) {a x y : V} (xy : x≠y)
    (xp : x∈pool G e f) (yp : y∈pool G e f) (ah : a∈high G) (tight : trianglesAt G a=2)
    (H : Ports G P Q {x,y} (pool G e f\{x,y}) a) (ep : e∈P∪Q) (fp : f∈P∪Q)
    (loss : ∀p∈({x,y}:Finset V),trianglesAt G p≤(kept (link G p) (pool G e f)).card+1)
    (off : Disjoint (boundary G {x,y} (pool G e f\{x,y})) (triangleContacts G e f)) :
    gamma G≤bound G := by
  classical
  apply Nat.le_of_not_gt
  intro bad
  have D := data_of_failure G t h q bad de df ef
  obtain ⟨L,R,pl,qr,good,_⟩ := cut_from_data G D P Q xy xp yp ah tight H loss off
  have deg (v : V) (vn : v∈nonleaves G) (vl : v∉L) (vr : v∉R) : 3≤G.degree v := by
    by_contra! small
    have tv : v∈twos G := mem_sdiff.mpr ⟨vn,fun hi => (not_le_of_gt small) (mem_filter.mp hi).2⟩
    rw [D.earSet] at tv
    have cover : v∈P∪Q := (mem_insert.mp tv).elim (fun eq => eq ▸ ep) (fun eq => mem_singleton.mp eq ▸ fp)
    exact (mem_union.mp cover).elim (fun z => vl (pl z)) (fun z => vr (qr z))
  exact (not_lt_of_ge (PinnedColor34.complete G good.1 (by omega) deg good.2.1 good.2.2)) bad
end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.noncontact_support
#print axioms Graffiti384b.Exterior.private_cut
#print axioms Graffiti384b.Exterior.private_branch
