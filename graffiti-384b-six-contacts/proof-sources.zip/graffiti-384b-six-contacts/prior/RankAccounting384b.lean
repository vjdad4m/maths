import RankWitness384b
import JointRank384b

namespace Graffiti384b.RankAccounting
open Finset SimpleGraph JointRank RankStrata
variable {V : Type*} [DecidableEq V]

/-- The number of admissible scores up to the vertex's own score controls
its rank after saturated-score representatives have been removed. -/
theorem rank_with_holes (s : Finset V) (score : V → ℕ) (inj : Set.InjOn score (s : Set V))
    (lo : ℕ) (holes : Finset ℕ) (allowed : ∀ v ∈ s, lo ≤ score v ∧ score v ∉ holes)
    {v : V} (vs : v ∈ s) {u : ℕ} (up : score v ≤ u) :
    rank s score v + 1 ≤ ((Icc lo u) \ holes).card := by
  let r := s.filter (fun w => score w < score v)
  let t := insert v r
  have inside : t ⊆ s := insert_subset vs (filter_subset _ _)
  have cover : t.image score ⊆ Icc lo u \ holes := by
    intro x hx
    obtain ⟨w,wt,rfl⟩ := mem_image.mp hx
    obtain ⟨low,clear⟩ := allowed w (inside wt)
    refine mem_sdiff.mpr ⟨mem_Icc.mpr ⟨low,?_⟩,clear⟩
    rcases mem_insert.mp wt with rfl | wr
    · exact up
    · exact (mem_filter.mp wr).2.le.trans up
  have cap := card_le_card cover
  rw [card_image_of_injOn (fun a ha b hb => inj (inside ha) (inside hb))] at cap
  have nv : v ∉ r := fun hv => (lt_irrefl _) (mem_filter.mp hv).2
  simpa only [t,card_insert_of_not_mem nv,rank,r] using cap

omit [DecidableEq V] in
/-- A cost threshold charges at most one baseline unit per outer rank.
Only positive excess above the threshold has to be counted in the full pool. -/
theorem outer_loss (s M : Finset V) (sub : M ⊆ s) (score : V → ℕ)
    (inj : Set.InjOn score (s : Set V)) (cost : ℕ → ℕ) (base : ℕ) :
    (∑ v ∈ M, cost (rank s score v)) ≤
      M.card*base + ∑ i ∈ range s.card, (cost i-base) := by
  have localBound : (∑ v ∈ M, cost (rank s score v)) ≤
      ∑ v ∈ M, (base+(cost (rank s score v)-base)) := sum_le_sum (fun _ _ => by omega)
  rw [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id] at localBound
  have mono := sum_le_sum_of_subset_of_nonneg (f := fun v => cost (rank s score v)-base) sub
    (fun _ _ _ => Nat.zero_le _)
  rw [sum_by_rank s score inj (fun i => cost i-base)] at mono
  exact localBound.trans (Nat.add_le_add_left mono _)

/-- A neighborhood is active if two vertices were selected in the union
of the strata. Its inactive fiber is the complementary zero-or-one count. -/
theorem activation (C M N : Finset V) (split : Disjoint C M)
    {j b : ℕ} (jp : 1 ≤ j) (bp : 1 ≤ b) :
    (((C.powersetCard j) ×ˢ (M.powersetCard b)).filter
      (fun p => 2 ≤ ((p.1 ∪ p.2) ∩ N).card)).card +
    (counts (N ∩ C).card j 0 C.card * counts (N ∩ M).card b 0 M.card +
    counts (N ∩ C).card j 1 C.card * counts (N ∩ M).card b 0 M.card +
    counts (N ∩ C).card j 0 C.card * counts (N ∩ M).card b 1 M.card) =
    C.card.choose j * M.card.choose b := by
  let opts := C.powersetCard j ×ˢ M.powersetCard b
  let yes (p : Finset V × Finset V) := 2 ≤ ((p.1 ∪ p.2) ∩ N).card
  have eq : opts.filter (fun p => ¬yes p) = opts.filter (fun p =>
      (p.1 ∩ (N ∩ C)).card + (p.2 ∩ (N ∩ M)).card ≤ 1) := by
    apply filter_congr
    intro p hp
    obtain ⟨hc,hm⟩ := mem_product.mp hp
    have xc := (mem_powersetCard.mp hc).1
    have ym := (mem_powersetCard.mp hm).1
    have d : Disjoint (p.1 ∩ (N ∩ C)) (p.2 ∩ (N ∩ M)) := disjoint_left.mpr (fun _ a z =>
      disjoint_left.mp split (xc (mem_inter.mp a).1) (ym (mem_inter.mp z).1))
    have share : (p.1 ∪ p.2) ∩ N = (p.1 ∩ (N ∩ C)) ∪ (p.2 ∩ (N ∩ M)) := by
      ext x
      simp only [mem_inter,mem_union]
      constructor
      · rintro ⟨h | h,hn⟩
        · exact Or.inl ⟨h,hn,xc h⟩
        · exact Or.inr ⟨h,hn,ym h⟩
      · rintro (⟨hx,hn,_⟩|⟨hy,hn,_⟩)
        · exact ⟨Or.inl hx,hn⟩
        · exact ⟨Or.inr hy,hn⟩
    dsimp [yes]
    rw [share,card_union_of_disjoint d]
    omega
  have splitCount := filter_card_add_filter_neg_card_eq_card (s := opts) yes
  rw [eq,show opts = C.powersetCard j ×ˢ M.powersetCard b from rfl,
    few_hits C M (N ∩ C) (N ∩ M) inter_subset_right inter_subset_right jp bp,
    card_product,card_powersetCard,card_powersetCard] at splitCount
  exact splitCount

end Graffiti384b.RankAccounting
#print axioms Graffiti384b.RankAccounting.rank_with_holes
#print axioms Graffiti384b.RankAccounting.outer_loss
#print axioms Graffiti384b.RankAccounting.activation
