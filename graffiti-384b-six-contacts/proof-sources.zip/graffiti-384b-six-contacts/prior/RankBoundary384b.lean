import Joint384b
import RankProfiles384b
import RankTuran384b

namespace Graffiti384b.RankBoundary
open Finset SimpleGraph CliqueChoice
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A graph with 37 types failing the catalogue inequality has an induced
all-distinct failure with a five-clique, 36 nonleaves and one of six
saturated-neighborhood profiles. -/
theorem reduced_failure (conn : G.Connected) (n : 2 < Fintype.card V)
    (failure : bound G < gamma G) (types37 : (types G).card=37) :
    ∃ R : Finset V, R.card=37 ∧
      let J := G.induce (R : Set V)
      J.Connected ∧ types J = types G ∧ Function.Injective (trianglesAt J) ∧
        bound J < gamma J ∧ ¬ J.CliqueFree 5 ∧ (nonleaves J).card=36 ∧
        (high J).card ∈ ({35,36} : Finset ℕ) ∧
        ∃ p, Choice J p Boundary.levels ∧ RankProfiles.residual (high J).card (p.image (J.degree ·)) := by
  classical
  obtain ⟨R,size,connected,same,inj,bad⟩ := Joint.all_distinct_induced G conn n failure types37
  let J := G.induce (R : Set V)
  have t : (types J).card=37 := by change (types (G.induce (R : Set V))).card=37; rw [same,types37]
  have nn : 2 < Fintype.card R := by rw [Fintype.card_coe,size]; decide
  have ub := Joint.nonleaf_cap J connected nn bad
  obtain ⟨s,_,lim,_,_,unchanged,_⟩ := Prune.prune_failure J connected nn bad
  have card : (types (J.induce (s : Set _))).card ≤ s.card := by
    simpa [types] using (card_image_le (s := (univ : Finset s)) (f := trianglesAt (J.induce (s : Set _))))
  rw [unchanged,t] at card
  have q : (nonleaves J).card=36 := by omega
  have sub : high J ⊆ nonleaves J := by
    intro z hz
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hz).2; omega⟩
  have lb := type_bound J
  have cap := card_le_card sub
  have h : (high J).card ∈ ({35,36} : Finset ℕ) := by simp only [mem_insert,mem_singleton]; omega
  letI : Nonempty (R : Set V) := connected.nonempty
  obtain ⟨p,ch⟩ := choose_from J Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  exact ⟨R,size,connected,same,inj,bad,fun free => (not_lt_of_ge (RankTuran.exact_of_five_clique_free J t free)) bad,
    q,h,p,ch,RankProfiles.saturated_profiles J ch t h q.ge bad⟩
end Graffiti384b.RankBoundary
#print axioms Graffiti384b.RankBoundary.reduced_failure
