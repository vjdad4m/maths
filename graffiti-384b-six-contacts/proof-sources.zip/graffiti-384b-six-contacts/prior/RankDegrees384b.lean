import RankTable384b
import RankAccounting384b

namespace Graffiti384b.RankDegrees
open Finset SimpleGraph RankTable RankProfiles JointRank
open private Repair.triangles_le_choose from Repair384b

def ceiling (c d : ℕ) (f : Finset ℕ) :=
  let plain := d.choose 2 - if d≤9 then 1 else 0
  if c=10 then plain else min plain (cap d (max c (f.sup id+1)-1))

def floorAt (h c : ℕ) (f : Finset ℕ) (i : ℕ) := degree c f ((scores h f)[i]?.getD 0)

private def row (h : ℕ) (f : Finset ℕ) : Prop :=
  ∀ c ∈ Icc 4 10,
    (∀ i ∈ range (h-f.card), floorAt h c f i ≤ 11) ∧
    ∀ d ∈ Icc 3 10, ∀ i ∈ range (min (h-f.card)
      ((Icc (37-h) (ceiling c d f)) \ f.image (fun e => e.choose 2)).card),
      floorAt h c f i ≤ d

set_option maxRecDepth 65536
set_option maxHeartbeats 20000000
local macro "degree_row" : tactic => `(tactic|
  (unfold row floorAt scores RankTable.degree ceiling cap
   simp only [Nat.choose_eq_fast_choose]
   decide))

private theorem a35 : row 35 ∅ := by degree_row
private theorem b35 : row 35 {3} := by degree_row
private theorem c35 : row 35 {4} := by degree_row
private theorem d35 : row 35 {3,4} := by degree_row
private theorem a36 : row 36 ∅ := by degree_row
private theorem b36 : row 36 {3} := by degree_row

private theorem rows (h : ℕ) (f : Finset ℕ) (size : h=35 ∨ h=36) (res : residual h f) : row h f := by
  rcases size with rfl | rfl
  · rcases res with rfl | rfl | ⟨_,rfl | rfl⟩
    · exact a35
    · exact b35
    · exact c35
    · exact d35
  · rcases res with rfl | rfl | ⟨no,_⟩
    · exact a36
    · exact b36
    · omega

variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The computed rank floors bound the actual degrees of any pool with the
specified scores and clique restriction. The ten-clique column requires
no upper bound on clique size. -/
theorem valid (h c : ℕ) (s : Finset V) (f : Finset ℕ)
    (size : h=35 ∨ h=36) (res : residual h f) (cc : c ∈ Icc 4 10)
    (sc : s.card=h-f.card) (inj : Set.InjOn (trianglesAt G) (s : Set V))
    (allowed : ∀ v ∈ s, 37-h ≤ trianglesAt G v ∧ trianglesAt G v ∉ f.image (fun e => e.choose 2))
    (high : ∀ v ∈ s, 3 ≤ G.degree v)
    (unsat : ∀ v ∈ s, G.degree v ≤ 9 → trianglesAt G v < (G.degree v).choose 2)
    (free : c≠10 → G.CliqueFree ((max c (f.sup id+1)-1)+2)) {v : V} (vs : v ∈ s) :
    floorAt h c f (rank s (trianglesAt G) v) ≤ G.degree v := by
  let i := rank s (trianglesAt G) v
  have ir : i ∈ range (h-f.card) := by
    rw [← sc,← rank_range s (trianglesAt G) inj]
    exact mem_image_of_mem _ vs
  obtain ⟨top,table⟩ := rows h f size res c cc
  have capD := top _ ir
  change floorAt h c f i ≤ _
  by_contra! small
  have d10 : G.degree v ≤ 10 := by omega
  have d3 := high v vs
  have plain : trianglesAt G v ≤ (G.degree v).choose 2 - (if G.degree v ≤ 9 then 1 else 0) := by
    split_ifs with yes
    · have := unsat v vs yes; omega
    · simpa using Repair.triangles_le_choose G v
  have up : trianglesAt G v ≤ ceiling c (G.degree v) f := by
    by_cases huge : c=10
    · simpa only [ceiling,if_pos huge] using plain
    rw [ceiling,if_neg huge]
    refine le_min plain ?_
    have rng := mem_Icc.mp cc
    have F : f.sup id ≤ 9 := by
      rcases res with rfl | rfl | ⟨_,rfl | rfl⟩ <;> decide
    let r := max c (f.sup id+1)-1
    have pos : 0<r := by dsimp [r]; omega
    have ub : r<10 := by dsimp [r]; omega
    have g := RankTuran.local_turan G r pos (free huge) v
    exact g.trans_eq (cap_table ⟨G.degree v,by omega⟩ ⟨_,ub⟩ pos)
  have count := RankAccounting.rank_with_holes s (trianglesAt G) inj (37-h) _ allowed vs up
  have idn := mem_range.mp ir
  have ind : i ∈ range (min (h-f.card) ((Icc (37-h) (ceiling c (G.degree v) f)) \ f.image (fun e => e.choose 2)).card) := by
    apply mem_range.mpr
    apply lt_min idn
    change rank s (trianglesAt G) v < _
    omega
  exact (Nat.not_lt_of_ge (table _ (mem_Icc.mpr ⟨d3,d10⟩) _ ind)) small

end Graffiti384b.RankDegrees
#print axioms Graffiti384b.RankDegrees.valid
