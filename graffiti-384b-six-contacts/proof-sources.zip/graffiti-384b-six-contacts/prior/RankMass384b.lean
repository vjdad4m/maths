import RankVertex384b

namespace Graffiti384b.RankMass
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private CliqueSample.trial from CliqueSample384b
open private FiniteRange.bad from FiniteRange384b
open private LowSample.eligible LowSample.anchors LowSample.weight LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem trial {p E k : Finset V} (ch : Choice G p Boundary.levels) (low : E ⊆ twos G)
    (inner : ∀ x ∈ E, G.neighborFinset x ⊆ high G) (ks : k ⊆ high G \ p)
    (t : (types G).card=37) (fail : bound G < gamma G) :
    (high G \ p).card-k.card+(active G p k).card+(active G E k).card ≤ 18+(FiniteRange.bad G (high G \ p) k).card := by
  let A := active G E k
  have anchors (x : V) (xe : x ∈ E) : LowSample.anchors G x = G.neighborFinset x := by
    ext v
    constructor
    · exact fun h => (G.mem_neighborFinset _ _).mpr (mem_filter.mp h).2
    · exact fun h => mem_filter.mpr ⟨inner x xe h,(G.mem_neighborFinset _ _).mp h⟩
  have support : A ⊆ LowSample.eligible G k := by
    intro x xa
    obtain ⟨xe,enough⟩ := mem_filter.mp xa
    have sub : k.filter (G.Adj x) ⊆ G.neighborFinset x := fun v hv => (G.mem_neighborFinset _ _).mpr (mem_filter.mp hv).2
    have all : k.filter (G.Adj x) = G.neighborFinset x := eq_of_subset_of_card_le sub
      (by rw [card_neighborFinset_eq_degree,LowSample.two_degree G (low xe)]; exact enough)
    exact mem_filter.mpr ⟨low xe,by rw [anchors _ xe,← all]; exact filter_subset _ _⟩
  have up := sum_le_sum_of_subset_of_nonneg (f := fun v => LowSample.weight (LowSample.anchors G v).card)
    support (fun _ _ _ => Nat.zero_le _)
  have eq : (∑ v ∈ A, LowSample.weight (LowSample.anchors G v).card) = 6*A.card := by
    calc
      _ = ∑ _v ∈ A, 6 := by
        apply sum_congr rfl
        intro v hv
        rw [anchors _ (mem_filter.mp hv).1,card_neighborFinset_eq_degree,LowSample.two_degree G (low (mem_filter.mp hv).1)]
        rfl
      _ = _ := by simp [Nat.mul_comm]
  rw [eq] at up
  dsimp only at up
  have obs := CliqueSample.trial G ch k ks fail
  dsimp only at obs
  rw [t] at obs
  change 6*((high G \ p).card-k.card) + _ + 6*(active G p k).card ≤ 6*(18+(FiniteRange.bad G (high G \ p) k).card) at obs
  change _ + A.card ≤ _
  omega

def actFiber {I : Type*} (rows : Finset I) (samp : I → Finset V) (v : V) :=
  (rows.filter (fun i => 2 ≤ nbr G v (samp i))).card

def defFiber {I : Type*} (rows : Finset I) (samp : I → Finset V) (s : Finset V) (v : V) :=
  (rows.filter (fun i => v ∈ FiniteRange.bad G s (samp i))).card

/-- Sum the per-sample omission inequality and transpose its activation and
deficiency fibers. This covers both the ordinary sample and each stratum. -/
theorem accounting {p E : Finset V} (ch : Choice G p Boundary.levels) (low : E ⊆ twos G)
    (inner : ∀ x ∈ E, G.neighborFinset x ⊆ high G)
    {I : Type*} (rows : Finset I) (samp : I → Finset V) (M : Finset V) (b : ℕ)
    (sample : ∀ i ∈ rows, samp i ⊆ high G \ p ∧ (samp i).card=b)
    (outside : ∀ i ∈ rows, FiniteRange.bad G (high G \ p) (samp i) ⊆ M)
    (t : (types G).card=37) (fail : bound G < gamma G) :
    ((high G \ p).card-b)*rows.card + (∑ v ∈ p, actFiber G rows samp v) +
    (∑ v ∈ E, actFiber G rows samp v) ≤ 18*rows.card + ∑ v ∈ M, defFiber G rows samp (high G \ p) v := by
  classical
  have eqA (P : Finset V) : (∑ i ∈ rows, (active G P (samp i)).card) = ∑ v ∈ P, actFiber G rows samp v := by
    calc
      _ = ∑ i ∈ rows, ∑ v ∈ P, (if 2 ≤ nbr G v (samp i) then 1 else 0 : ℕ) := by simp [active]
      _ = _ := by rw [sum_comm]; simp [actFiber]
  have eqD : (∑ i ∈ rows, (FiniteRange.bad G (high G \ p) (samp i)).card) =
      ∑ v ∈ M, defFiber G rows samp (high G \ p) v := by
    calc
      _ = ∑ i ∈ rows, ∑ v ∈ M, (if v ∈ FiniteRange.bad G (high G \ p) (samp i) then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro i hi
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr (outside _ hi)]
      _ = _ := by rw [sum_comm]; simp [defFiber]
  have point (i : I) (hi : i ∈ rows) := trial G ch low inner (sample i hi).1 t fail
  have sum := sum_le_sum (fun i hi => (sample i hi).2 ▸ point i hi)
  simp only [sum_add_distrib,eqA,eqD,sum_const,nsmul_eq_mul,Nat.cast_id] at sum
  simpa only [Nat.mul_comm rows.card] using sum

/-- No unretained member of a clique can be deficient when at least two
clique members have been selected. -/
theorem outsiders (C s X Y : Finset V) (cl : G.IsClique (C : Set V))
    (xc : X ⊆ C) (two : 2 ≤ X.card) : FiniteRange.bad G s (X ∪ Y) ⊆ s \ C := by
  intro v vb
  obtain ⟨out,few⟩ := mem_filter.mp vb
  refine mem_sdiff.mpr ⟨(mem_sdiff.mp out).1,?_⟩
  intro vc
  have sub : X ⊆ (sᶜ ∪ (X ∪ Y)).filter (G.Adj v) := by
    intro w wx
    exact mem_filter.mpr ⟨mem_union_right _ (mem_union_left _ wx),
      cl vc (xc wx) (fun eq => (mem_sdiff.mp out).2 (mem_union_left _ (eq ▸ wx)))⟩
  have got := two.trans (card_le_card sub)
  exact (not_lt_of_ge got) few

end Graffiti384b.RankMass
#print axioms Graffiti384b.RankMass.trial
#print axioms Graffiti384b.RankMass.accounting
#print axioms Graffiti384b.RankMass.outsiders
