import RankPair384b

namespace Graffiti384b.RankMixed
open Finset SimpleGraph CliqueChoice LowSample RankTable RankPair RankVertex JointRank
open private LowSample.two_degree from LowSample384b

private theorem combine {s a b x y u v e g w z : ℕ}
    (left : s*a+x+u ≤ 18*a+e) (right : s*b+y+v ≤ 18*b+g) :
    s*(w*a+z*b)+(w*x+z*y)+(w*u+z*v) ≤ 18*(w*a+z*b)+(w*e+z*g) := by
  calc
    _ = w*(s*a+x+u)+z*(s*b+y+v) := by ring
    _ ≤ w*(18*a+e)+z*(18*b+g) := Nat.add_le_add (Nat.mul_le_mul_left _ left) (Nat.mul_le_mul_left _ right)
    _ = _ := by ring

private theorem cols {α : Type*} (S : Finset α) (a b : α → ℕ) (w z : ℕ) :
    (∑ v ∈ S, (w*a v+z*b v)) = w*(∑ v ∈ S, a v)+z*(∑ v ∈ S, b v) := by
  rw [sum_add_distrib,mul_sum,mul_sum]

variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A positive mixed row gives the actual catalogue inequality under the
rank-by-rank degree bounds, including the optional ear and the saturated
representatives. -/
theorem apply_row {p C : Finset V} (ch : Choice G p Boundary.levels)
    (hc : (high G).card=35 ∨ (high G).card=36) (t : (types G).card=37)
    (ears : (twos G).card=36-(high G).card)
    (inside : ∀ v ∈ twos G, G.neighborFinset v ⊆ high G \ p)
    (cs : C ⊆ high G \ p) (cl : G.IsClique (C : Set V)) (small : C.card ≤ 10)
    (largest : C.card<10 → ∀ X ⊆ high G \ p, G.IsClique (X : Set V) → X.card ≤ C.card)
    (ij : Function.Injective (trianglesAt G))
    (limited : ∀ v ∈ high G \ p, G.degree v ≤ 9 → trianglesAt G v < (G.degree v).choose 2)
    (room : 11 < ((high G \ p) \ C).card)
    (degrees : ∀ v ∈ high G \ p, atRank (high G).card C.card (p.image (G.degree ·))
        (rank (high G \ p) (trianglesAt G) v) ≤ G.degree v)
    (r : ℕ) (tab : mixed (high G).card C.card r (p.image (G.degree ·))) : gamma G ≤ bound G := by
  by_contra! fail
  let h := (high G).card
  let f := p.image (G.degree ·)
  let s := high G \ p
  let M := s \ C
  let c := C.card
  let m := M.card
  let D := atRank h c f
  let R := rank s (trianglesAt G)
  let A := mass c m 2
  let B := mass c m 4
  let w := (20-r)*B
  let z := r*A
  let den := 20*A*B
  let bonus d := den-inactive c m r d
  let cost i := loss c m r (D i)
  let base := cost (m-1)
  let ear := if h=35 then bonus 2 else 0
  have size : s.card=h-f.card := by dsimp only [s,h,f]; rw [card_sdiff ch.high_sub,card_image_of_injOn ch.unique]
  have width : m=h-f.card-c := by dsimp only [m,M]; rw [card_sdiff cs,size]
  have sij : Set.InjOn (trianglesAt G) (s : Set V) := fun _ _ _ _ eq => ij eq
  have ir {v : V} (vs : v ∈ s) : R v ∈ range s.card := by rw [← rank_range s (trianglesAt G) sij]; exact mem_image_of_mem _ vs
  change mixed h c r f at tab
  unfold mixed at tab
  dsimp only at tab
  rw [← width,← size] at tab
  change r ≤ 20 ∧ (∀ i ∈ range s.card, 3 ≤ D i ∧ D i ≤ 11) ∧ 0<den ∧
    18*den+(m*base+∑ i ∈ range s.card, (cost i-base)) < (s.card-13)*den+((∑ d ∈ f, bonus d)+ear) at tab
  obtain ⟨rmax,db,_,win⟩ := tab
  have inn (v : V) (vt : v ∈ twos G) : G.neighborFinset v ⊆ high G := (inside v vt).trans sdiff_subset
  have left := stratum G ch (Subset.rfl : twos G ⊆ twos G) inn cs cl 2 (by decide) (by decide) t fail
  have right := stratum G ch (Subset.rfl : twos G ⊆ twos G) inn cs cl 4 (by decide) (by decide) t fail
  let I (j : ℕ) (v : V) := RankPair.income G C M j v
  let J (j : ℕ) (v : V) := badFiber G C M j v
  have mix := combine (w := w) (z := z) left right
  have sumWeights : w*A+z*B=den := by
    dsimp only [w,z,den]
    rw [show (20-r)*B*A = (20-r)*A*B by ring,← Nat.add_mul,← Nat.add_mul,Nat.sub_add_cancel rmax]
  change (s.card-13)*(w*A+z*B)+(w*(∑ v ∈ p,I 2 v)+z*(∑ v ∈ p,I 4 v))+
      (w*(∑ v ∈ twos G,I 2 v)+z*(∑ v ∈ twos G,I 4 v)) ≤
      18*(w*A+z*B)+(w*(∑ v ∈ M,J 2 v)+z*(∑ v ∈ M,J 4 v)) at mix
  rw [sumWeights,← cols,← cols,← cols] at mix
  have dis : Disjoint C M := disjoint_left.mpr (fun _ a b => (mem_sdiff.mp b).2 a)
  have cov : s ⊆ C ∪ M := by
    intro x hx; by_cases xc : x ∈ C
    · exact mem_union_left _ xc
    · exact mem_union_right _ (mem_sdiff.mpr ⟨hx,xc⟩)
  have gain (v : V) (ns : G.neighborFinset v ⊆ s) : bonus (G.degree v) ≤ w*I 2 v+z*I 4 v :=
    mixed_income G C M dis (ns.trans cov) r rmax
  have rep := sum_le_sum (s := p) (fun v hv => gain v (neighbors_in_pool G ch hv))
  have repEq : (∑ d ∈ f, bonus d) = ∑ v ∈ p, bonus (G.degree v) := sum_image ch.unique
  rw [← repEq] at rep
  have low := sum_le_sum (s := twos G) (fun v hv => gain v (inside v hv))
  have earEq : (∑ v ∈ twos G, bonus (G.degree v)) = ear := by
    calc
      _ = ∑ _v ∈ twos G, bonus 2 := sum_congr rfl (fun v hv => congrArg bonus (LowSample.two_degree G hv))
      _ = _ := by
        rw [sum_const,nsmul_eq_mul,Nat.cast_id,ears]
        change (36-h)*bonus 2 = if h=35 then bonus 2 else 0
        change h=35 ∨ h=36 at hc
        rcases hc with H | H <;> simp [H]
  rw [earEq] at low
  have vertex (v : V) (vm : v ∈ M) : w*J 2 v+z*J 4 v ≤ cost (R v) := by
    have vs := (mem_sdiff.mp vm).1
    have d := db _ (ir vs)
    exact mixed_loss G C s cs cl vm (d := D (R v)) ((by decide : 1 ≤ 3).trans d.1) (degrees v vs) (show D (R v)<M.card by change 11 < M.card at room; omega)
      small largest (limited v vs) r
  have lossBound := (sum_le_sum vertex).trans (RankAccounting.outer_loss s M sdiff_subset (trianglesAt G) sij cost base)
  change (∑ v ∈ M, (w*J 2 v+z*J 4 v)) ≤ m*base+∑ i ∈ range s.card, (cost i-base) at lossBound
  omega

end Graffiti384b.RankMixed
#print axioms Graffiti384b.RankMixed.apply_row
