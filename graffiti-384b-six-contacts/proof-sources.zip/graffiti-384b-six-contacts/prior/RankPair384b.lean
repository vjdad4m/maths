import RankMass384b

namespace Graffiti384b.RankPair
set_option maxHeartbeats 2000000
open Finset SimpleGraph CliqueChoice LowSample RankMass RankVertex RankTable
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def opts (C M : Finset V) (j : ℕ) := C.powersetCard j ×ˢ M.powersetCard (13-j)
def draw (z : Finset V × Finset V) := z.1 ∪ z.2
def income (C M : Finset V) (j : ℕ) (v : V) := actFiber G (opts C M j) draw v

theorem stratum {p E C : Finset V} (ch : Choice G p Boundary.levels) (low : E ⊆ twos G)
    (inside : ∀ x ∈ E, G.neighborFinset x ⊆ high G) (cs : C ⊆ high G \ p)
    (cl : G.IsClique (C : Set V)) (j : ℕ) (two : 2 ≤ j) (ub : j < 13)
    (t : (types G).card=37) (fail : bound G < gamma G) :
    let s := high G \ p
    let M := s \ C
    (s.card-13)*mass C.card M.card j + (∑ x ∈ p, income G C M j x) +
      (∑ x ∈ E, income G C M j x) ≤ 18*mass C.card M.card j + ∑ v ∈ M, badFiber G C M j v := by
  let s := high G \ p
  let M := s \ C
  have cover : C ∪ M = s := by ext x; simp only [M,mem_union,mem_sdiff]; exact ⟨fun h => h.elim (fun u => cs u) (·.1),fun xs => by by_cases xc : x ∈ C <;> tauto⟩
  have dis : Disjoint C M := disjoint_left.mpr (fun _ a b => (mem_sdiff.mp b).2 a)
  have data (z : Finset V × Finset V) (hz : z ∈ opts C M j) :=
    And.intro (mem_powersetCard.mp (mem_product.mp hz).1) (mem_powersetCard.mp (mem_product.mp hz).2)
  have sample (z : Finset V × Finset V) (hz : z ∈ opts C M j) : draw z ⊆ s ∧ (draw z).card=13 := by
    obtain ⟨⟨xc,xcj⟩,⟨ym,ymb⟩⟩ := data z hz
    refine ⟨union_subset (xc.trans cs) (ym.trans sdiff_subset),?_⟩
    unfold draw
    rw [card_union_of_disjoint (dis.mono xc ym),xcj,ymb]; omega
  have out (z : Finset V × Finset V) (hz : z ∈ opts C M j) : FiniteRange.bad G s (draw z) ⊆ M := by
    have a := (data z hz).1
    exact outsiders G C s z.1 z.2 cl a.1 (by omega)
  have bound := accounting G ch low inside (opts C M j) draw M 13 sample out t fail
  have den : (opts C M j).card = mass C.card M.card j := by simp [opts,mass]
  rw [den] at bound
  have fiber (v : V) : defFiber G (opts C M j) draw s v = badFiber G C M j v := by
    unfold defFiber badFiber; rw [cover]; rfl
  have eqSum : (∑ v ∈ M, defFiber G (opts C M j) draw (high G \ p) v) = ∑ v ∈ M, badFiber G C M j v :=
    sum_congr rfl (fun v _ => fiber v)
  rw [eqSum] at bound
  exact bound

theorem income_eq (C M : Finset V) (dis : Disjoint C M) {v : V}
    (ns : G.neighborFinset v ⊆ C ∪ M) (j : ℕ) (jp : 1 ≤ j) (ub : j<13) :
    income G C M j v + few C.card M.card j (G.degree v) ((G.neighborFinset v ∩ C).card) =
      mass C.card M.card j := by
  let N := G.neighborFinset v
  have a := RankAccounting.activation C M N dis jp (show 1 ≤ 13-j by omega)
  have eqF (z : Finset V × Finset V) : nbr G v (draw z) = ((z.1 ∪ z.2) ∩ N).card := by
    unfold nbr draw
    congr 1; ext w
    simp only [mem_filter,mem_inter,N,mem_neighborFinset]
  have incomeDef : income G C M j v = ((opts C M j).filter (fun p => 2 ≤ ((p.1 ∪ p.2) ∩ N).card)).card := by
    unfold income actFiber
    simp only [eqF]
  have join : (N ∩ C) ∪ (N ∩ M) = N := by
    ext w
    simp only [mem_union,mem_inter]
    constructor
    · exact fun h => h.elim (·.1) (·.1)
    · intro h; exact (mem_union.mp (ns h)).elim (fun c => Or.inl ⟨h,c⟩) (fun m => Or.inr ⟨h,m⟩)
  have sep : Disjoint (N ∩ C) (N ∩ M) := disjoint_left.mpr (fun _ h k => disjoint_left.mp dis (mem_inter.mp h).2 (mem_inter.mp k).2)
  have sum := congrArg card join
  rw [card_union_of_disjoint sep] at sum
  have degrees : N.card=G.degree v := card_neighborFinset_eq_degree _ _
  have num : (N ∩ M).card=G.degree v-(N ∩ C).card := by omega
  rw [incomeDef]; unfold few mass
  simpa only [num] using a

/-- The table's worst-case activation lower bound holds simultaneously
for the same neighborhood in both strata. -/
theorem mixed_income (C M : Finset V) (dis : Disjoint C M) {v : V}
    (ns : G.neighborFinset v ⊆ C ∪ M) (r : ℕ) (rmax : r≤20) :
    20*mass C.card M.card 2*mass C.card M.card 4 - inactive C.card M.card r (G.degree v) ≤
    (20-r)*mass C.card M.card 4*income G C M 2 v + r*mass C.card M.card 2*income G C M 4 v := by
  let k := (G.neighborFinset v ∩ C).card
  have limit : k ≤ min C.card (G.degree v) := le_min (card_le_card inter_subset_right)
    ((card_le_card inter_subset_left).trans_eq (card_neighborFinset_eq_degree _ _))
  have up := le_sup (f := fun a => (20-r)*mass C.card M.card 4*few C.card M.card 2 (G.degree v) a +
    r*mass C.card M.card 2*few C.card M.card 4 (G.degree v) a) (mem_range.mpr (show k<min C.card (G.degree v)+1 by omega))
  change _ ≤ inactive C.card M.card r (G.degree v) at up
  have A := income_eq G C M dis ns 2 (by decide) (by decide)
  have B := income_eq G C M dis ns 4 (by decide) (by decide)
  change income G C M 2 v + few C.card M.card 2 (G.degree v) k = _ at A
  change income G C M 4 v + few C.card M.card 4 (G.degree v) k = _ at B
  have w := congrArg₂ (fun x y : ℕ => x+y) (congrArg (fun z => (20-r)*mass C.card M.card 4*z) A)
    (congrArg (fun z => r*mass C.card M.card 2*z) B)
  dsimp only at up w
  simp only [Nat.mul_add] at w
  have total : (20-r)*mass C.card M.card 4*mass C.card M.card 2 + r*mass C.card M.card 2*mass C.card M.card 4 =
      20*mass C.card M.card 2*mass C.card M.card 4 := by
    rw [show (20-r)*mass C.card M.card 4*mass C.card M.card 2 = (20-r)*mass C.card M.card 2*mass C.card M.card 4 by ring,
      ← Nat.add_mul,← Nat.add_mul,Nat.sub_add_cancel rmax]
  rw [total] at w
  omega
end Graffiti384b.RankPair
#print axioms Graffiti384b.RankPair.stratum
#print axioms Graffiti384b.RankPair.mixed_income
