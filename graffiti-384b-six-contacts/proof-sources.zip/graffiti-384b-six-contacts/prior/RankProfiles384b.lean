import Boundary384b

namespace Graffiti384b.RankProfiles
open Finset SimpleGraph CliqueChoice CliqueSample Boundary LowSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def residual (h : ℕ) (f : Finset ℕ) : Prop :=
  f=∅ ∨ f={3} ∨ (h=35 ∧ (f={4} ∨ f={3,4}))

private def numeric (h : ℕ) (f : Finset ℕ) : Prop :=
  let m := h-f.card
  12 ≤ m ∧ envelope m 13 ∧ reward m 13 ∧
  (∀ d : Fin 12, 3 ≤ d.val → (m-d.val).choose 13 + saved m 13 ≤ FiniteRange.badCount m 13 d.val) ∧
  6*(18*m.choose 13 + charge 37 h m 13 f levels) <
    6*(m-13)*m.choose 13 + (36-h)*(6*(m-2).choose 11) + 6*(∑ d ∈ f, bonus m 13 d) +
    6*(f.sup id * saved m 13)

set_option maxRecDepth 32768 in
set_option maxHeartbeats 12000000 in
private theorem table : ∀ h ∈ ({35,36} : Finset ℕ), ∀ f ∈ levels.powerset, residual h f ∨ numeric h f := by
  unfold residual numeric levels envelope reward charge slots LowSample.delta LowSample.weight bonus FiniteRange.badCount saved
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

/-- Among the two possible high-pool sizes, the saturated representatives
of every counterexample have one of six size/degree-set combinations. -/
theorem saturated_profiles {p : Finset V} (ch : Choice G p levels)
    (t : (types G).card=37) (hc : (high G).card ∈ ({35,36} : Finset ℕ))
    (q : 36 ≤ (nonleaves G).card) (fail : bound G < gamma G) :
    residual (high G).card (p.image (G.degree ·)) := by
  classical
  let f := p.image (G.degree ·)
  let h := (high G).card
  let m := h-f.card
  let s := high G \ p
  have sz : s.card = m := by
    dsimp only [s,m,f,h]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  obtain good | tab := table h hc f (mem_powerset.mpr ch.levels)
  · exact good
  by_cases empty : f=∅
  · exact Or.inl empty
  obtain ⟨d,df,eq⟩ := exists_mem_eq_sup f (nonempty_iff_ne_empty.mpr empty) id
  obtain ⟨x,xp,dx⟩ := mem_image.mp df
  let N := G.neighborFinset x
  have ns : N ⊆ s := neighbors_in_pool G ch xp
  let credit (v : V) := if v ∈ N then saved m 13 else 0
  obtain ⟨room,env,rew,pay,win⟩ := tab
  have refund (v : V) (vs : v ∈ s) :
      ((s.powersetCard 13).filter (fun k => v ∈ FiniteRange.bad G s k)).card + credit v ≤
      FiniteRange.badCount s.card 13 (min (G.degree v) 11) := by
    by_cases vn : v ∈ N
    · have edge := (G.mem_neighborFinset _ _).mp vn
      have outside : x ∉ s := fun hx => (mem_sdiff.mp hx).2 xp
      have d3 := (mem_filter.mp (mem_sdiff.mp vs).1).2
      let dv := min (G.degree v) 11
      have lim : 3 ≤ dv ∧ dv < 12 := by dsimp [dv]; omega
      have raw := BoundaryFiber.count G s 13 dv vs outside edge.symm (min_le_left _ _) (by omega)
      simp only [credit,if_pos vn]
      rw [sz] at raw ⊢
      exact (Nat.add_le_add_right raw _).trans (pay ⟨dv,lim.2⟩ lim.1)
    · simp only [credit,if_neg vn,Nat.add_zero]
      exact FiniteRange.count_bad G s 13 _ _ vs (min_le_left _ _) (by omega)
  have obs := extraObstruction G ch 13 credit refund (by decide) (sz ▸ env) (sz ▸ rew) fail
  change 6*(m-13)*m.choose 13 + (twos G).card*(6*(m-2).choose 11) + 6*(∑ d ∈ f, bonus m 13 d) +
    6*(∑ v ∈ s, credit v) ≤ 6*((((types G).card+1)/2-1)*m.choose 13 + charge (types G).card h m 13 f levels) at obs
  have sumCredit : (∑ v ∈ s, credit v) = f.sup id * saved m 13 := by
    simp only [credit,← sum_filter,filter_mem_eq_inter,inter_eq_right.mpr ns,sum_const,nsmul_eq_mul,Nat.cast_id]
    rw [show N.card = G.degree x from card_neighborFinset_eq_degree _ _,dx,eq]
    rfl
  have sub : high G ⊆ nonleaves G := by
    intro v hv
    exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count : (twos G).card+h = (nonleaves G).card := card_sdiff_add_card_eq_card sub
  have extra := Nat.mul_le_mul_right (6*(m-2).choose 11) (show 36-h ≤ (twos G).card by omega)
  rw [t,sumCredit] at obs
  change 6*(m-13)*m.choose 13 + (twos G).card*(6*(m-2).choose 11) + 6*(∑ d ∈ f, bonus m 13 d) +
    6*(f.sup id * saved m 13) ≤ 6*(18*m.choose 13 + charge 37 h m 13 f levels) at obs
  change 6*(18*m.choose 13 + charge 37 h m 13 f levels) < 6*(m-13)*m.choose 13 +
    (36-h)*(6*(m-2).choose 11) + 6*(∑ d ∈ f, bonus m 13 d) + 6*(f.sup id * saved m 13) at win
  omega

end Graffiti384b.RankProfiles
#print axioms Graffiti384b.RankProfiles.saturated_profiles
