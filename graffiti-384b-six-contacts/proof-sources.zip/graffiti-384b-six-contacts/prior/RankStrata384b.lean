import CliqueSample384b

namespace Graffiti384b.RankStrata
open Finset SimpleGraph CliqueChoice CliqueSample
open private FiniteRange.bad from FiniteRange384b
open private CliqueSample.trial from CliqueSample384b
open private LowSample.eligible LowSample.weight LowSample.anchors from LowSample384b

variable {V : Type*} [DecidableEq V]

/-- Hypergeometric fiber for one region of a fixed-size sample. -/
theorem hits (s a : Finset V) (sub : a ⊆ s) {b i : ℕ} (le : i ≤ b) :
    ((s.powersetCard b).filter (fun k => (k ∩ a).card=i)).card =
      a.card.choose i * (s.card-a.card).choose (b-i) := by
  let F := (s.powersetCard b).filter (fun k => (k ∩ a).card=i)
  let D := a.powersetCard i ×ˢ (s \ a).powersetCard (b-i)
  have eq : F.card = D.card := by
    apply card_bij (fun k _ => (k ∩ a,k \ a))
    · intro k hk
      obtain ⟨mem,num⟩ := mem_filter.mp hk
      obtain ⟨ks,sz⟩ := mem_powersetCard.mp mem
      have count := card_sdiff_add_card_inter k a
      exact mem_product.mpr ⟨mem_powersetCard.mpr ⟨inter_subset_right,num⟩,
        mem_powersetCard.mpr ⟨(fun v hv => mem_sdiff.mpr ⟨ks (mem_sdiff.mp hv).1,(mem_sdiff.mp hv).2⟩),by change (k \ a).card = b-i; omega⟩⟩
    · intro x _ y _ eq
      have h := congrArg (fun p : Finset V × Finset V => p.1 ∪ p.2) eq
      have join (z : Finset V) : z ∩ a ∪ z \ a = z := by ext; simp only [mem_union,mem_inter,mem_sdiff]; tauto
      simpa only [join] using h
    · intro pair hp
      obtain ⟨x,y⟩ := pair
      obtain ⟨hx,hy⟩ := mem_product.mp hp
      obtain ⟨xa,sz⟩ := mem_powersetCard.mp hx
      obtain ⟨yc,ny⟩ := mem_powersetCard.mp hy
      have dis : Disjoint x y := disjoint_left.mpr (fun _ a b => (mem_sdiff.mp (yc b)).2 (xa a))
      have cut : (x ∪ y) ∩ a = x := by
        ext v
        constructor
        · intro hv
          obtain ⟨h,va⟩ := mem_inter.mp hv
          exact (mem_union.mp h).elim id (fun vy => ((mem_sdiff.mp (yc vy)).2 va).elim)
        · exact fun h => mem_inter.mpr ⟨mem_union_left _ h,xa h⟩
      have rest : (x ∪ y) \ a = y := by
        ext v
        constructor
        · intro hv
          obtain ⟨h,va⟩ := mem_sdiff.mp hv
          exact (mem_union.mp h).elim (fun vx => (va (xa vx)).elim) id
        · exact fun h => mem_sdiff.mpr ⟨mem_union_right _ h,(mem_sdiff.mp (yc h)).2⟩
      refine ⟨x ∪ y,mem_filter.mpr ⟨mem_powersetCard.mpr ⟨union_subset (xa.trans sub) (yc.trans sdiff_subset),?_⟩,
        by rw [cut]; exact sz⟩,Prod.ext cut rest⟩
      rw [card_union_of_disjoint dis,sz,ny]; omega
  rw [show D = _ from rfl,card_product,card_powersetCard,card_powersetCard,card_sdiff sub] at eq
  exact eq

def counts (a b i : ℕ) (n : ℕ) := a.choose i * (n-a).choose (b-i)

/-- Count pairs of independent fixed-size samples with at most one selected
witness across the two regions. Excluding an outside vertex before applying
this lemma gives its deficiency count. Applying it to a removed vertex's
neighborhood instead gives the complement of its activation count. -/
theorem few_hits (s t a d : Finset V) (asub : a ⊆ s) (dsub : d ⊆ t)
    {j b : ℕ} (jp : 1 ≤ j) (bp : 1 ≤ b) :
    (((s.powersetCard j) ×ˢ (t.powersetCard b)).filter (fun p =>
      (p.1 ∩ a).card + (p.2 ∩ d).card ≤ 1)).card =
    counts a.card j 0 s.card * counts d.card b 0 t.card +
    counts a.card j 1 s.card * counts d.card b 0 t.card +
    counts a.card j 0 s.card * counts d.card b 1 t.card := by
  let A (i : ℕ) := (s.powersetCard j).filter (fun k => (k ∩ a).card=i)
  let B (i : ℕ) := (t.powersetCard b).filter (fun k => (k ∩ d).card=i)
  have key : (((s.powersetCard j) ×ˢ (t.powersetCard b)).filter (fun p =>
      (p.1 ∩ a).card + (p.2 ∩ d).card ≤ 1)) =
    ((A 0 ×ˢ B 0) ∪ (A 1 ×ˢ B 0)) ∪ (A 0 ×ˢ B 1) := by
    ext p
    simp only [A,B,mem_filter,mem_product,mem_union]
    constructor
    · rintro ⟨⟨x,y⟩,h⟩
      by_cases z : (p.1 ∩ a).card = 0
      · by_cases z' : (p.2 ∩ d).card = 0
        · exact Or.inl (Or.inl ⟨⟨x,z⟩,y,z'⟩)
        · exact Or.inr ⟨⟨x,z⟩,y,by omega⟩
      · exact Or.inl (Or.inr ⟨⟨x,by omega⟩,y,by omega⟩)
    · rintro ((⟨⟨x,u⟩,y,v⟩ | ⟨⟨x,u⟩,y,v⟩) | ⟨⟨x,u⟩,y,v⟩) <;> exact ⟨⟨x,y⟩,by omega⟩
  have d1 : Disjoint (A 0 ×ˢ B 0) (A 1 ×ˢ B 0) := by
    apply disjoint_left.mpr
    intro p x y
    have x' := (mem_filter.mp (mem_product.mp x).1).2
    have y' := (mem_filter.mp (mem_product.mp y).1).2
    omega
  have d2 (i : ℕ) : Disjoint (A i ×ˢ B 0) (A 0 ×ˢ B 1) := by
    apply disjoint_left.mpr
    intro p x y
    have x' := (mem_filter.mp (mem_product.mp x).2).2
    have y' := (mem_filter.mp (mem_product.mp y).2).2
    omega
  rw [key,card_union_of_disjoint (disjoint_union_left.mpr ⟨d2 0,d2 1⟩),card_union_of_disjoint d1]
  simp only [A,B,card_product,hits _ _ asub (Nat.zero_le j),hits _ _ asub jp,
    hits _ _ dsub (Nat.zero_le b),hits _ _ dsub bp,counts]

variable [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The earlier per-sample omission inequality applies to any weighted
collection of samples, including a mixture of different clique quotas. -/
theorem weighted_obstruction {p : Finset V} {tested : Finset ℕ} (ch : Choice G p tested)
    {I : Type*} (rows : Finset I) (sample : I → Finset V) (w : I → ℕ)
    (valid : ∀ i ∈ rows, sample i ⊆ high G \ p) (fail : bound G < gamma G) :
    (∑ i ∈ rows, w i * (6*((high G \ p).card-(sample i).card) +
      (∑ v ∈ LowSample.eligible G (sample i), LowSample.weight (LowSample.anchors G v).card) +
      6*(active G p (sample i)).card)) ≤
    ∑ i ∈ rows, w i * (6*((((types G).card+1)/2-1)+(FiniteRange.bad G (high G \ p) (sample i)).card)) := by
  apply sum_le_sum
  intro i hi
  exact Nat.mul_le_mul_left _ (CliqueSample.trial G ch (sample i) (valid i hi) fail)

end Graffiti384b.RankStrata
#print axioms Graffiti384b.RankStrata.hits
#print axioms Graffiti384b.RankStrata.few_hits
#print axioms Graffiti384b.RankStrata.weighted_obstruction
