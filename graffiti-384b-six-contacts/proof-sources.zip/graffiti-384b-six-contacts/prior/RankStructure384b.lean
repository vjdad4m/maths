import RankBoundary384b

namespace Graffiti384b.RankStructure
open Finset SimpleGraph CliqueChoice
open private Prune.outside_zero from Prune384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Removing all saturated representatives deletes exactly the forbidden
triangular-number scores. Every remaining vertex is unsaturated through
degree nine, and the low score offset is valid throughout the pool. -/
theorem pool_data {p : Finset V} (ch : Choice G p Boundary.levels)
    (n : Fintype.card V=37) (t : (types G).card=37) (q : (nonleaves G).card=36)
    (highSize : (high G).card=35 ∨ (high G).card=36) (inj : Function.Injective (trianglesAt G)) :
    let s := high G \ p
    let f := p.image (G.degree ·)
    s.card=(high G).card-f.card ∧
      (∀ v ∈ s, 37-(high G).card ≤ trianglesAt G v ∧ trianglesAt G v ∉ f.image (fun e => e.choose 2)) ∧
      (∀ v ∈ s, 3 ≤ G.degree v) ∧
      (∀ v ∈ s, G.degree v ≤ 9 → trianglesAt G v < (G.degree v).choose 2) := by
  let s := high G \ p
  let f := p.image (G.degree ·)
  have high (v : V) (vs : v ∈ s) := (mem_filter.mp (mem_sdiff.mp vs).1).2
  have excluded (v : V) (vs : v ∈ s) : trianglesAt G v ∉ f.image (fun e => e.choose 2) := by
    intro h
    obtain ⟨d,df,eq⟩ := mem_image.mp h
    obtain ⟨x,xp,deg⟩ := mem_image.mp df
    exact (mem_sdiff.mp vs).2 ((inj ((ch.exact_score x xp).trans (by rw [deg]; exact eq))) ▸ xp)
  refine ⟨?_,?_,high,?_⟩
  · rw [card_sdiff ch.high_sub,card_image_of_injOn ch.unique]
  · intro v vs
    refine ⟨?_,excluded v vs⟩
    rcases highSize with h | h
    · have data := Repair.maximal_diversity G (by omega)
      have l := data.2.1 v (mem_sdiff.mp vs).1
      omega
    · have out : (nonleaves G)ᶜ.Nonempty := by
        apply card_pos.mp; rw [card_compl,n,q]; decide
      obtain ⟨w,wo⟩ := out
      have zero := Prune.outside_zero G (mem_compl.mp wo)
      have ne : trianglesAt G v ≠ 0 := by
        intro zv
        have eq := inj (zv.trans zero.symm)
        have d := high v vs
        exact mem_compl.mp wo (mem_filter.mpr ⟨mem_univ _,by subst w; omega⟩)
      omega
  · intro v vs d9
    apply lt_of_le_of_ne (Repair.triangles_le_choose G v)
    intro eq
    exact excluded v vs (mem_image.mpr ⟨G.degree v,ch.covers v (mem_Icc.mpr ⟨high v vs,d9⟩) eq,eq.symm⟩)

/-- All other vertices of a clique are neighbors of any designated member. -/
theorem clique_degree {X : Finset V} (C : G.IsClique (X : Set V)) {x : V} (xx : x ∈ X) :
    X.card ≤ G.degree x + 1 := by
  have sub : X.erase x ⊆ G.neighborFinset x := by
    intro w hw
    obtain ⟨ne,xw⟩ := mem_erase.mp hw
    exact (G.mem_neighborFinset _ _).mpr (C xx xw ne.symm)
  have h := card_le_card sub
  rw [card_erase_of_mem xx,card_neighborFinset_eq_degree] at h
  omega

/-- Select a pool clique of size 4--10, maximal below ten. Below ten the
ambient clique number is bounded by the pool clique and the degrees of
removed representatives. -/
theorem choose_clique {p : Finset V} (ch : Choice G p Boundary.levels) (five : ¬G.CliqueFree 5) :
    let s := high G \ p
    let f := p.image (G.degree ·)
    ∃ C ⊆ s, G.IsClique (C : Set V) ∧ C.card ∈ Icc 4 10 ∧
      (C.card<10 → ∀ D ⊆ s, G.IsClique (D : Set V) → D.card ≤ C.card) ∧
      (C.card≠10 → G.CliqueFree ((max C.card (f.sup id+1)-1)+2)) := by
  classical
  let s := high G \ p
  let f := p.image (G.degree ·)
  let opts := s.powerset.filter (fun D : Finset V => G.IsClique (D : Set V))
  have opt {D : Finset V} (ds : D ⊆ s) (dc : G.IsClique (D : Set V)) : D ∈ opts :=
    mem_filter.mpr ⟨mem_powerset.mpr ds,dc⟩
  have ne : opts.Nonempty := ⟨∅,opt (empty_subset _) (by simp)⟩
  obtain ⟨L,mem,large⟩ := exists_max_image opts card ne
  obtain ⟨ls,lc⟩ := mem_filter.mp mem
  have sub := mem_powerset.mp ls
  have lower : 4 ≤ L.card := by
    obtain ⟨D,cl⟩ : ∃ D, G.IsNClique 5 D := by simpa only [CliqueFree,not_forall,Classical.not_not] using five
    by_cases rep : ∃ x ∈ D, x ∈ p
    · obtain ⟨x,xd,xp⟩ := rep
      have near : D.erase x ⊆ s := by
        intro w hw
        obtain ⟨wn,wd⟩ := mem_erase.mp hw
        exact neighbors_in_pool G ch xp ((G.mem_neighborFinset _ _).mpr (cl.1 xd wd wn.symm))
      have k := large _ (opt near (cl.1.subset (erase_subset _ _)))
      rwa [card_erase_of_mem xd,cl.2] at k
    · have ds : D ⊆ s := by
        intro w wd
        have d := clique_degree G cl.1 wd
        have z := cl.2
        exact mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,fun wp => rep ⟨w,wd,wp⟩⟩
      have k := large D (opt ds cl.1)
      have z := cl.2
      omega
  by_cases big : 10 ≤ L.card
  · obtain ⟨C,subC,sz⟩ := exists_subset_card_eq big
    exact ⟨C,subC.trans sub,lc.subset subC,mem_Icc.mpr ⟨by omega,by omega⟩,by omega,by simp [sz]⟩
  refine ⟨L,sub,lc,mem_Icc.mpr ⟨lower,by omega⟩,fun _ D ds dc => large _ (opt ds dc),?_⟩
  intro _ D cl
  have sz := cl.2
  change D.card=max L.card (f.sup id+1)-1+2 at sz
  have upper (x : V) (xd : x ∈ D) := clique_degree G cl.1 xd
  by_cases rep : ∃ x ∈ D, x ∈ p
  · obtain ⟨x,xd,xp⟩ := rep
    have de : G.degree x ≤ f.sup id := le_sup (f := id) (mem_image_of_mem _ xp)
    have dx := upper x xd
    omega
  · have ds : D ⊆ s := by
      intro w wd
      have dx := upper w wd
      exact mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,fun wp => rep ⟨w,wd,wp⟩⟩
    have d := large D (opt ds cl.1)
    omega

end Graffiti384b.RankStructure
#print axioms Graffiti384b.RankStructure.pool_data
#print axioms Graffiti384b.RankStructure.choose_clique
