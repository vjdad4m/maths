import RankTuran384b
import RankStrata384b
import RankProfiles384b

namespace Graffiti384b.RankTable
open Finset SimpleGraph RankProfiles RankStrata

/-- Integer size of a complete balanced multipartite graph. -/
def cap (n r : ℕ) := n.choose 2 - (n%r)*(n/r+1).choose 2 - (r-n%r)*(n/r).choose 2

set_option maxRecDepth 65536 in
set_option maxHeartbeats 10000000 in
theorem cap_table : ∀ d : Fin 12, ∀ r : Fin 10, 0<r.val →
    (turanGraph d.val r.val).edgeFinset.card = cap d.val r.val := by
  decide

def scores (h : ℕ) (f : Finset ℕ) :=
  (((List.range 60).filter (fun v => 37-h ≤ v && decide (v ∉ f.image (fun d => d.choose 2)))).take (h-f.card))

def degree (c : ℕ) (f : Finset ℕ) (v : ℕ) :=
  ((List.range 12).find? (fun d => 3 ≤ d && v ≤ d.choose 2 - (if d≤9 then 1 else 0) &&
    (c=10 || v ≤ cap d (max c (f.sup id+1)-1)))).getD 12

def atRank (h c : ℕ) (f : Finset ℕ) (i : ℕ) := degree c f ((scores h f)[i]?.getD 0)

def mass (c m j : ℕ) := c.choose j * m.choose (13-j)

/-- Exactly zero or one selected witness among k inner and d-k outer
witnesses. Here m is the number of available outer vertices. -/
def few (c m j d k : ℕ) :=
  counts k j 0 c * counts (d-k) (13-j) 0 m +
  counts k j 1 c * counts (d-k) (13-j) 0 m +
  counts k j 0 c * counts (d-k) (13-j) 1 m

/-- Numerators use a mixture with probability r/20 for four clique vertices
and (20-r)/20 for two clique vertices. Both choices retain 13 vertices. -/
def loss (c m r d : ℕ) :=
  let kmax := if c=10 then min c d else min (c-1) (d-1)
  (range (kmax+1)).sup (fun k =>
    (20-r)*mass c m 4*few c (m-1) 2 d k + r*mass c m 2*few c (m-1) 4 d k)

def inactive (c m r d : ℕ) :=
  (range (min c d+1)).sup (fun k =>
    (20-r)*mass c m 4*few c m 2 d k + r*mass c m 2*few c m 4 d k)

def mixed (h c r : ℕ) (f : Finset ℕ) : Prop :=
  let s := h-f.card
  let m := s-c
  let den := 20*mass c m 2*mass c m 4
  let D := atRank h c f
  let threshold := loss c m r (D (m-1))
  let cost := m*threshold + ∑ i ∈ range s, (loss c m r (D i) - threshold)
  let gain := (∑ d ∈ f, (den-inactive c m r d)) + if h=35 then den-inactive c m r 2 else 0
  r ≤ 20 ∧ (∀ i ∈ range s, 3 ≤ D i ∧ D i ≤ 11) ∧ 0<den ∧ 18*den+cost < (s-13)*den+gain

/-- Ordinary sampling when the remaining clique has size four and there
is a saturated degree-four representative. -/
def uniform (h c b : ℕ) (f : Finset ℕ) : Prop :=
  let s := h-f.card
  let D := atRank h c f
  let total := ∑ i ∈ range s, FiniteRange.badCount s b (D i)
  let rebate := Boundary.saved s b
  let bonus := (∑ d ∈ f, CliqueSample.bonus s b d) + (36-h)*(s-2).choose (b-2)
  2 ≤ b ∧ (∀ i ∈ range s, 3 ≤ D i ∧ D i ≤ 11) ∧
    (∀ d : Fin 12, 3 ≤ d.val → (s-d.val).choose b + rebate ≤ FiniteRange.badCount s b d.val) ∧
    18*s.choose b + total < (s-b)*s.choose b + bonus + f.sup id*rebate

def weight (h : ℕ) (f : Finset ℕ) (c : ℕ) :=
  let data := if h=35 then
    if f=∅ then [0,0,3,6,10,13,16]
    else if f={3} then [0,0,4,7,11,14,18]
    else if f={4} then [0,0,3,6,10,13,17]
    else [0,0,4,7,11,15,18]
  else if f=∅ then [0,0,1,5,8,11,15]
  else [0,0,2,6,9,12,16]
  data[c-4]?.getD 0

def certificate (h : ℕ) (f : Finset ℕ) (c : ℕ) : Prop :=
  if c=4 ∧ 4 ∈ f then uniform h c (if f={4} then 12 else 11) f
  else mixed h c (weight h f c) f

private def Row (h : ℕ) (f : Finset ℕ) := ∀ c ∈ Icc 4 10, certificate h f c

set_option maxRecDepth 65536
set_option maxHeartbeats 16000000
local macro "check_row" : tactic => `(tactic|
  (unfold Row certificate uniform mixed weight atRank scores degree loss inactive mass few counts cap
    CliqueSample.bonus FiniteRange.badCount Boundary.saved
   simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
   decide))

private theorem row35a : Row 35 ∅ := by check_row
private theorem row35b : Row 35 {3} := by check_row
private theorem row35c : Row 35 {4} := by check_row
private theorem row35d : Row 35 {3,4} := by check_row
private theorem row36a : Row 36 ∅ := by check_row
private theorem row36b : Row 36 {3} := by check_row

/-- All forty-two numerical rows. Clique size ten represents an arbitrary
ten-clique, so there is no maximality restriction in that column. -/
theorem coverage (h c : ℕ) (f : Finset ℕ) (size : h=35 ∨ h=36)
    (rem : residual h f) (clique : c ∈ Icc 4 10) : certificate h f c := by
  rcases size with rfl | rfl
  · rcases rem with rfl | rfl | ⟨_,rfl | rfl⟩
    · exact row35a _ clique
    · exact row35b _ clique
    · exact row35c _ clique
    · exact row35d _ clique
  · rcases rem with rfl | rfl | ⟨no,_⟩
    · exact row36a _ clique
    · exact row36b _ clique
    · omega
end Graffiti384b.RankTable

#print axioms Graffiti384b.RankTable.cap_table
#print axioms Graffiti384b.RankTable.coverage
