import JointRank384b
import Mathlib.Combinatorics.SimpleGraph.Turan

namespace Graffiti384b.RankTuran
open Finset SimpleGraph JointRank
open private Repair.linkEdges Repair.edge_info Repair.triangles_le_choose from Repair384b
open private FiniteRange.bad FiniteRange.trial FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Turán's theorem inside the neighborhood of a vertex. -/
theorem local_turan (r : ℕ) (pos : 0<r) (free : G.CliqueFree (r+2)) (v : V) :
    trianglesAt G v ≤ (turanGraph (G.degree v) r).edgeFinset.card := by
  classical
  let N := G.neighborFinset v
  let J := G.induce (N : Set V)
  let emb : N ↪ V := Function.Embedding.subtype _
  have cf : J.CliqueFree (r+1) := by
    intro q cl
    have lifted : G.IsNClique (r+1) (q.map emb) :=
      cl.map.mono (G.spanningCoe_induce_le (s := (N : Set V)))
    apply free (insert v (q.map emb))
    apply lifted.insert
    intro w hw
    obtain ⟨x,_,rfl⟩ := mem_map.mp hw
    exact (G.mem_neighborFinset _ _).mp x.property
  let f : Sym2 N → Finset V := Sym2.lift ⟨fun a b => {a.val,b.val},fun a b => pair_comm _ _⟩
  have cover : Repair.linkEdges G v ⊆ J.edgeFinset.image f := by
    intro p hp
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info G hp
    obtain ⟨x,y,ne,rfl⟩ := card_eq_two.mp sz
    have hx : x ∈ ({x,y} : Finset V) := mem_insert_self _ _
    have hy : y ∈ ({x,y} : Finset V) := mem_insert_of_mem (mem_singleton_self _)
    let a : N := ⟨x,sub hx⟩
    let b : N := ⟨y,sub hy⟩
    exact mem_image.mpr ⟨s(a,b),mem_edgeFinset.mpr (show J.Adj a b from cl x hx y hy ne),rfl⟩
  obtain ⟨M,dM,maximal⟩ := exists_isTuranMaximal (V := N) pos
  letI := dM
  have cap := maximal.2 J cf
  obtain ⟨iso⟩ := maximal.nonempty_iso_turanGraph
  have t : trianglesAt G v ≤ M.edgeFinset.card := (card_le_card cover).trans (card_image_le.trans cap)
  rw [iso.card_edgeFinset_eq,Fintype.card_coe] at t
  exact t

private def floorD (i : ℕ) : ℕ := if i<2 then 3 else if i<4 then 4 else if i<7 then 5 else
  if i<11 then 6 else if i<15 then 7 else if i<20 then 8 else if i<26 then 9 else if i<32 then 10 else 11

private theorem floor_ok : (∀ i : Fin 35, floorD i < 35) ∧
    (∀ i : Fin 35, ∀ d : Fin 11, 3 ≤ d.val → d.val < floorD i →
      (turanGraph d.val 3).edgeFinset.card < i.val+2) := by decide

private theorem sum_ok :
    (∑ i ∈ range 35, FiniteRange.badCount 35 12 (floorD i)) < 5*(35:ℕ).choose 12 := by
  unfold FiniteRange.badCount floorD
  simp only [Nat.choose_eq_fast_choose]
  decide

/-- A pool of 35 score representatives with scores at least two suffices.
All vertices outside the pool remain available to support omitted vertices. -/
theorem capacity_of_pool (s : Finset V) (sz : s.card=35) (inj : Set.InjOn (trianglesAt G) (s : Set V))
    (lo : ∀ v ∈ s, 2 ≤ trianglesAt G v)
    (cap : ∀ v ∈ s, trianglesAt G v ≤ (turanGraph (G.degree v) 3).edgeFinset.card) :
    19 ≤ Capacity.value G s sᶜ := by
  classical
  let R := rank s (trianglesAt G)
  have valid (v : V) (hv : v ∈ s) : R v < 35 := by
    have h := mem_image_of_mem (rank s (trianglesAt G)) hv
    rwa [rank_range s (trianglesAt G) inj,sz,mem_range] at h
  have degree (v : V) (hv : v ∈ s) : floorD (R v) ≤ G.degree v := by
    have hv3 : 3 ≤ G.degree v := by
      by_contra! small
      have ub := Repair.triangles_le_choose G v
      have z := Nat.choose_le_choose 2 (show G.degree v ≤ 2 by omega)
      have l := lo v hv
      rw [Nat.choose_self] at z
      omega
    by_contra! small
    have top : floorD (R v) ≤ 11 := by unfold floorD; split_ifs <;> omega
    have D : G.degree v < 11 := by omega
    have q := floor_ok.2 ⟨R v,valid _ hv⟩ ⟨_,D⟩ hv3 small
    have l := rank_lower s (trianglesAt G) inj 2 lo hv
    change 2+R v ≤ trianglesAt G v at l
    have c := cap v hv
    change (turanGraph (G.degree v) 3).edgeFinset.card < R v+2 at q
    omega
  let opts := s.powersetCard 12
  let fiber (v : V) := (opts.filter (fun k => v ∈ FiniteRange.bad G s k)).card
  have total : (∑ k ∈ opts, (FiniteRange.bad G s k).card) = ∑ v ∈ s, fiber v := by
    calc
      _ = ∑ k ∈ opts, ∑ v ∈ s, (if v ∈ FiniteRange.bad G s k then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show FiniteRange.bad G s k ⊆ s from (filter_subset _ _).trans sdiff_subset)]
      _ = _ := by rw [sum_comm]; simp [fiber]
  have per (v : V) (hv : v ∈ s) : fiber v ≤ FiniteRange.badCount 35 12 (floorD (R v)) := by
    rw [← sz]
    exact FiniteRange.count_bad G s 12 _ v hv (degree v hv) (by rw [sz]; exact floor_ok.1 ⟨_,valid v hv⟩)
  have lim := sum_le_sum per
  rw [sum_by_rank s (trianglesAt G) inj (fun i => FiniteRange.badCount 35 12 (floorD i)),sz] at lim
  by_contra! small
  have low (k : Finset V) (hk : k ∈ opts) : 5 ≤ (FiniteRange.bad G s k).card := by
    obtain ⟨sub,card⟩ := mem_powersetCard.mp hk
    have h := FiniteRange.trial G s k sub
    omega
  have too := sum_le_sum low
  rw [total] at too
  have count : opts.card = (35:ℕ).choose 12 := by rw [show opts = s.powersetCard 12 from rfl,card_powersetCard,sz]
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id,count] at too
  have strict := sum_ok
  omega

/-- All graphs with 37 distinct incident triangle counts and no five-clique
satisfy the catalogue bound, at every order. -/
theorem exact_of_five_clique_free (t : (types G).card=37) (free : G.CliqueFree 5) :
    gamma G ≤ bound G := by
  classical
  let Q := types G \ {0,1}
  have n : 35 ≤ Q.card := by
    have h := card_le_card (show types G ⊆ Q ∪ {0,1} by
      intro i hi; by_cases small : i ∈ ({0,1} : Finset ℕ)
      · exact mem_union_right _ small
      · exact mem_union_left _ (mem_sdiff.mpr ⟨hi,small⟩))
    have u := card_union_le Q ({0,1} : Finset ℕ)
    have size : ({0,1} : Finset ℕ).card = 2 := by decide
    omega
  obtain ⟨T,sub,card⟩ := exists_subset_card_eq n
  have has (i : T) : ∃ v, trianglesAt G v = i := by
    obtain ⟨v,_,h⟩ := mem_image.mp (mem_sdiff.mp (sub i.property)).1
    exact ⟨v,h⟩
  choose f hf using has
  have fi : Function.Injective f := fun x y e => Subtype.ext ((hf x).symm.trans ((congrArg _ e).trans (hf y)))
  let s := (univ : Finset T).image f
  have ss : s.card = 35 := by rw [show s = _ from rfl,card_image_of_injective _ fi,card_univ,Fintype.card_coe,card]
  have inj : Set.InjOn (trianglesAt G) (s : Set V) := by
    intro x hx y hy eq
    obtain ⟨a,_,rfl⟩ := mem_image.mp hx
    obtain ⟨b,_,rfl⟩ := mem_image.mp hy
    rw [hf,hf] at eq
    exact congrArg f (Subtype.ext eq)
  have lo (v : V) (hv : v ∈ s) : 2 ≤ trianglesAt G v := by
    obtain ⟨a,_,rfl⟩ := mem_image.mp hv
    rw [hf]
    have no := (mem_sdiff.mp (sub a.property)).2
    simp only [mem_insert,mem_singleton,not_or] at no
    omega
  have val := capacity_of_pool G s ss inj lo (fun v _ => local_turan G 3 (by decide) free v)
  have result := Capacity.seeded_value G ∅ s sᶜ (by simp) (by simp) disjoint_compl_right (by simp)
  simp only [card_empty,zero_add] at result
  unfold bound
  rw [t]; omega
end Graffiti384b.RankTuran
#print axioms Graffiti384b.RankTuran.local_turan
#print axioms Graffiti384b.RankTuran.capacity_of_pool
#print axioms Graffiti384b.RankTuran.exact_of_five_clique_free
namespace Graffiti384b.RankTuran
open Finset SimpleGraph JointRank JointSample LowSample
open private LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def floorSix (i : ℕ) := if i<1 then 3 else if i<4 then 4 else if i<8 then 5 else
  if i<12 then 6 else if i<17 then 7 else if i<23 then 8 else if i<29 then 9 else 10

private theorem sixTable :
    (∀ i : Fin 35, 1 ≤ floorSix i ∧ floorSix i ≤ 10) ∧
    (∀ i : Fin 35, ∀ d : Fin 10, 3 ≤ d.val → d.val < floorSix i →
      (turanGraph d.val 4).edgeFinset.card < i.val+2 ∨ d.val.choose 2 ≤ i.val+2) ∧
    (∀ a : Fin 3, 6*(33:ℕ).choose 11 ≤ income 35 13 a) ∧
    6*(18*(35:ℕ).choose 13 + ∑ i ∈ range 35, FiniteRange.badCount 35 13 (floorSix i)) <
      6*22*(35:ℕ).choose 13 + 6*(33:ℕ).choose 11 := by
  unfold FiniteRange.badCount floorSix income LowSample.weight
  simp only [Nat.choose_eq_fast_choose]
  decide

/-- In the unsaturated residual profile, a single degree-two vertex suffices
to rule out every six-clique-free graph, independent of either endpoint rank. -/
theorem exact_of_six_clique_free (t : (types G).card=37) (high35 : (high G).card=35)
    (two : (twos G).Nonempty)
    (unsat : ∀ v, 3 ≤ G.degree v → G.degree v ≤ 9 → trianglesAt G v < (G.degree v).choose 2)
    (free : G.CliqueFree 6) : gamma G ≤ bound G := by
  classical
  by_contra! fail
  obtain ⟨inj,lo,_,_⟩ := Repair.maximal_diversity G (by omega)
  let R := rank (high G) (trianglesAt G)
  let D (v : V) := floorSix (R v)
  have rangeR (v : V) (hv : v ∈ high G) : R v < 35 := by
    have h := mem_image_of_mem (rank (high G) (trianglesAt G)) hv
    rwa [rank_range _ _ inj,high35,mem_range] at h
  obtain ⟨bounds,table,incomes,win⟩ := sixTable
  have degree (v : V) (hv : v ∈ high G) : 1 ≤ D v ∧ D v ≤ G.degree v ∧ D v < (high G).card := by
    have row := bounds ⟨_,rangeR v hv⟩
    change 1 ≤ D v ∧ D v ≤ 10 at row
    refine ⟨row.1,?_,by omega⟩
    apply Nat.le_of_not_gt
    intro small
    have d : G.degree v < 10 := by omega
    have hi := (mem_filter.mp hv).2
    have low := rank_lower (high G) (trianglesAt G) inj 2 lo hv
    change 2+R v ≤ trianglesAt G v at low
    have tur := local_turan G 4 (by decide) free v
    have strict := unsat v hi (by omega)
    have either := table ⟨_,rangeR v hv⟩ ⟨_,d⟩ hi small
    change (turanGraph (G.degree v) 4).edgeFinset.card < R v+2 ∨ (G.degree v).choose 2 ≤ R v+2 at either
    omega
  have obs := JointSample.obstruction G 13 (by decide) D ∅ (empty_subset _) (by simp) degree fail
  dsimp only at obs
  simp only [high35,t,sum_empty,Nat.mul_zero,Nat.add_zero] at obs
  have sums := sum_by_rank (high G) (trianglesAt G) inj
    (fun i => FiniteRange.badCount 35 13 (floorSix i))
  rw [high35] at sums
  change (∑ v ∈ high G, FiniteRange.badCount 35 13 (D v)) = _ at sums
  rw [sums] at obs
  obtain ⟨x,hx⟩ := two
  have small := at_most_two G hx
  have inc := incomes ⟨anchorCount G x,by omega⟩
  have covered := single_le_sum (f := fun v => income 35 13 (anchorCount G v)) (fun _ _ => Nat.zero_le _) hx
  change 6*(33:ℕ).choose 11 ≤ income 35 13 (anchorCount G x) at inc
  exact (not_lt_of_ge ((Nat.add_le_add_left (inc.trans covered) _).trans obs)) win

end Graffiti384b.RankTuran
#print axioms Graffiti384b.RankTuran.exact_of_six_clique_free
