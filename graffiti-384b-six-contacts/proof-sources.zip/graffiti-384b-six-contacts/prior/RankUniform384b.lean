import RankPair384b

namespace Graffiti384b.RankUniform
open Finset SimpleGraph CliqueChoice LowSample RankMass RankTable JointRank
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.two_degree LowSample.anchor_samples from LowSample384b
open private CliqueSample.active_fiber from CliqueSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem apply_row {p : Finset V} (ch : Choice G p Boundary.levels)
    (t : (types G).card=37) (ears : (twos G).card=36-(high G).card)
    (inside : ∀ v ∈ twos G, G.neighborFinset v ⊆ high G \ p)
    (ij : Function.Injective (trianglesAt G)) (present : (p.image (G.degree ·)).Nonempty)
    (room : 11 < (high G \ p).card) (c b : ℕ)
    (degrees : ∀ v ∈ high G \ p, atRank (high G).card c (p.image (G.degree ·))
        (rank (high G \ p) (trianglesAt G) v) ≤ G.degree v)
    (tab : uniform (high G).card c b (p.image (G.degree ·))) : gamma G ≤ bound G := by
  by_contra! fail
  let h := (high G).card
  let f := p.image (G.degree ·)
  let s := high G \ p
  let rows := s.powersetCard b
  let D := atRank h c f
  let R := rank s (trianglesAt G)
  let save := Boundary.saved s.card b
  have size : s.card=h-f.card := by dsimp only [s,h,f]; rw [card_sdiff ch.high_sub,card_image_of_injOn ch.unique]
  have sij : Set.InjOn (trianglesAt G) (s : Set V) := fun _ _ _ _ eq => ij eq
  have ir {v : V} (vs : v ∈ s) : R v ∈ range s.card := by rw [← rank_range s (trianglesAt G) sij]; exact mem_image_of_mem _ vs
  change uniform h c b f at tab
  unfold uniform at tab; rw [← size] at tab
  change 2 ≤ b ∧ (∀ i ∈ range s.card, 3 ≤ D i ∧ D i ≤ 11) ∧
    (∀ d : Fin 12, 3 ≤ d.val → (s.card-d.val).choose b + save ≤ FiniteRange.badCount s.card b d.val) ∧
    18*s.card.choose b + (∑ i ∈ range s.card, FiniteRange.badCount s.card b (D i)) <
     (s.card-b)*s.card.choose b + ((∑ d ∈ f, CliqueSample.bonus s.card b d)+(36-h)*(s.card-2).choose (b-2)) + f.sup id*save at tab
  obtain ⟨two,db,refund,win⟩ := tab
  have inn (v : V) (hv : v ∈ twos G) : G.neighborFinset v ⊆ high G := (inside v hv).trans sdiff_subset
  have obs := accounting G ch (Subset.rfl : twos G ⊆ twos G) inn rows id s b (fun _ hi => mem_powersetCard.mp hi)
    (fun _ _ => (filter_subset _ _).trans sdiff_subset) t fail
  let A := actFiber G rows id
  let B := defFiber G rows id s
  change (s.card-b)*rows.card+(∑ v ∈ p, A v)+(∑ v ∈ twos G, A v) ≤ 18*rows.card+∑ v ∈ s, B v at obs
  have den : rows.card=s.card.choose b := card_powersetCard _ _
  rw [den] at obs
  have rp (v : V) (vp : v ∈ p) : CliqueSample.bonus s.card b (G.degree v) ≤ A v := by
    have h := CliqueSample.active_fiber G ch b vp
    exact h.trans (card_le_card (fun k hk => mem_filter.mpr ⟨(mem_filter.mp hk).1,(mem_filter.mp (mem_filter.mp hk).2).2⟩))
  have reps := sum_le_sum rp
  have eqf : (∑ d ∈ f, CliqueSample.bonus s.card b d) = ∑ v ∈ p, CliqueSample.bonus s.card b (G.degree v) := sum_image ch.unique
  rw [← eqf] at reps
  have ep (v : V) (ve : v ∈ twos G) : (s.card-2).choose (b-2) ≤ A v := by
    let N := G.neighborFinset v
    have nc : N.card=2 := (card_neighborFinset_eq_degree G v).trans (LowSample.two_degree G ve)
    have T := LowSample.anchor_samples s N b (inside v ve) (by omega)
    rw [nc] at T
    apply T.trans
    apply card_le_card
    intro k hk
    obtain ⟨row,sub⟩ := mem_filter.mp hk
    refine mem_filter.mpr ⟨row,?_⟩
    have cap := card_le_card (show N ⊆ k.filter (G.Adj v) from
      fun w hw => mem_filter.mpr ⟨sub hw,(G.mem_neighborFinset _ _).mp hw⟩)
    exact nc ▸ cap
  have earn := sum_le_sum ep
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id,ears] at earn
  change (36-h)*(s.card-2).choose (b-2) ≤ ∑ v ∈ twos G, A v at earn
  obtain ⟨d,df,eq⟩ := exists_mem_eq_sup f present id
  obtain ⟨x,xp,dx⟩ := mem_image.mp df
  let N := G.neighborFinset x
  have ns : N ⊆ s := neighbors_in_pool G ch xp
  let delta (v : V) := if v ∈ N then save else 0
  have pay (v : V) (vs : v ∈ s) : B v+delta v ≤ FiniteRange.badCount s.card b (D (R v)) := by
    have lim := db _ (ir vs)
    have yes := degrees v vs
    by_cases vn : v ∈ N
    · have raw := BoundaryFiber.count G s b (D (R v)) vs (show x ∉ s from fun hx => (mem_sdiff.mp hx).2 xp)
        ((G.mem_neighborFinset _ _).mp vn).symm yes (by omega)
      simpa only [delta,if_pos vn] using (Nat.add_le_add_right raw save).trans (refund ⟨D (R v),by omega⟩ lim.1)
    · simp only [delta,if_neg vn,Nat.add_zero]
      exact FiniteRange.count_bad G s b _ _ vs yes (by change 11<s.card at room; omega)
  have losses := sum_le_sum pay
  rw [sum_add_distrib,sum_by_rank s (trianglesAt G) sij (fun i => FiniteRange.badCount s.card b (D i))] at losses
  have eqD : (∑ v ∈ s, delta v) = f.sup id*save := by
    simp only [delta,← sum_filter,filter_mem_eq_inter,inter_eq_right.mpr ns,sum_const,nsmul_eq_mul,Nat.cast_id]
    rw [show N.card=G.degree x from card_neighborFinset_eq_degree _ _,dx,eq]
    rfl
  rw [eqD] at losses
  omega

end Graffiti384b.RankUniform
#print axioms Graffiti384b.RankUniform.apply_row
