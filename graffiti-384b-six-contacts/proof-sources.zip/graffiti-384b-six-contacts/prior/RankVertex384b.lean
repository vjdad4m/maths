import RankStructure384b
import RankDegrees384b

namespace Graffiti384b.RankVertex
open Finset SimpleGraph RankStrata RankWitness RankTable
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem saturated_of_clique {v : V} {C : Finset V} (cl : G.IsClique (C : Set V))
    (all : G.neighborFinset v ⊆ C) : trianglesAt G v = (G.degree v).choose 2 := by
  unfold trianglesAt
  rw [filter_eq_self.mpr ?_,card_powersetCard,card_neighborFinset_eq_degree]
  intro X hx a ha b hb ne
  have sub := (mem_powersetCard.mp hx).1
  exact cl (all (sub ha)) (all (sub hb)) ne

/-- A genuine non-clique neighbor can always be chosen among the witnesses
when the clique is maximal below ten. -/
theorem select_neighbors (C s : Finset V) (cs : C ⊆ s) (cl : G.IsClique (C : Set V))
    {v : V} (vm : v ∈ s \ C) {d : ℕ} (pos : 1 ≤ d) (degree : d ≤ G.degree v)
    (small : C.card < 10) (largest : ∀ X ⊆ s, G.IsClique (X : Set V) → X.card ≤ C.card)
    (unsat : G.degree v ≤ 9 → trianglesAt G v < (G.degree v).choose 2) :
    ∃ g ⊆ G.neighborFinset v, g.card=d ∧ (g ∩ C).card ≤ min (C.card-1) (d-1) := by
  let N := G.neighborFinset v
  obtain ⟨z,zn,zc⟩ : ∃ z ∈ N, z ∉ C := by
    by_contra! no
    have cap := card_le_card no
    change (G.neighborFinset v).card ≤ C.card at cap
    rw [card_neighborFinset_eq_degree] at cap
    exact (unsat (by omega)).ne (saturated_of_clique G cl no)
  have missing : ¬ C ⊆ N := by
    intro bad
    have ext : G.IsClique (↑(insert v C) : Set V) := by
      intro a ha b hb ne
      rcases mem_insert.mp ha with rfl | ac
      · rcases mem_insert.mp hb with rfl | bc
        · exact (ne rfl).elim
        · exact (G.mem_neighborFinset _ _).mp (bad bc)
      · rcases mem_insert.mp hb with rfl | bc
        · exact ((G.mem_neighborFinset _ _).mp (bad ac)).symm
        · exact cl ac bc ne
    have cap := largest (insert v C) (insert_subset (mem_sdiff.mp vm).1 cs) ext
    rw [card_insert_of_not_mem (mem_sdiff.mp vm).2] at cap
    omega
  obtain ⟨g,zg,gn,sz⟩ := exists_subsuperset_card_eq (singleton_subset_iff.mpr zn)
    (show ({z} : Finset V).card ≤ d by simpa) (show d ≤ N.card by simpa [N] using degree)
  have ltC : (g ∩ C).card < C.card := card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨inter_subset_right,
    fun eq => missing (fun w wc => gn (mem_inter.mp (show w ∈ g ∩ C by rw [eq]; exact wc)).1)⟩)
  have ltD : (g ∩ C).card < g.card := card_lt_card (Finset.ssubset_iff_subset_ne.mpr ⟨inter_subset_left,
    fun eq => zc (mem_inter.mp (show z ∈ g ∩ C by rw [eq]; exact singleton_subset_iff.mp zg)).2⟩)
  exact ⟨g,gn,sz,le_min (by omega) (by omega)⟩

def badFiber (C M : Finset V) (j : ℕ) (v : V) := (((C.powersetCard j) ×ˢ (M.powersetCard (13-j))).filter
    (fun p => v ∈ FiniteRange.bad G (C ∪ M) (p.1 ∪ p.2))).card

/-- The finite table's mixed loss bounds the actual two-quota weighted
loss of each individual outer vertex. -/
theorem mixed_loss (C s : Finset V) (cs : C ⊆ s) (cl : G.IsClique (C : Set V))
    {v : V} (vm : v ∈ s \ C) {d : ℕ} (pos : 1 ≤ d) (deg : d ≤ G.degree v)
    (room : d < (s \ C).card) (sz : C.card ≤ 10)
    (largest : C.card<10 → ∀ X ⊆ s, G.IsClique (X : Set V) → X.card ≤ C.card)
    (unsat : G.degree v ≤ 9 → trianglesAt G v < (G.degree v).choose 2) (r : ℕ) :
    let M := s \ C
    (20-r)*mass C.card M.card 4*badFiber G C M 2 v + r*mass C.card M.card 2*badFiber G C M 4 v ≤
      loss C.card M.card r d := by
  let M := s \ C
  have selected : ∃ g ⊆ G.neighborFinset v, g.card=d ∧
      (g ∩ C).card ≤ (if C.card=10 then min C.card d else min (C.card-1) (d-1)) := by
    split_ifs with yes
    · obtain ⟨g,gn,gd⟩ := exists_subset_card_eq (show d ≤ (G.neighborFinset v).card by simpa using deg)
      exact ⟨g,gn,gd,le_min (card_le_card inter_subset_right) ((card_le_card inter_subset_left).trans gd.le)⟩
    · exact select_neighbors G C s cs cl vm pos deg (by omega) (largest (by omega)) unsat
  obtain ⟨g,gn,gd,lim⟩ := selected
  have dis : Disjoint C M := disjoint_left.mpr (fun _ a b => (mem_sdiff.mp b).2 a)
  obtain ⟨T,ts,tc,holds⟩ := surrogate G C M g vm dis gn (gd ▸ room)
  let k := (g ∩ C).card
  have counted (j : ℕ) (jp : 1 ≤ j) (ub : j < 13) :
      badFiber G C M j v ≤ few C.card (M.card-1) j d k := by
    have got := stratum_loss G C M (g ∩ C) T vm inter_subset_right ts jp
      (show 1 ≤ 13-j by omega) holds
    rw [tc,gd] at got
    exact got
  have twoC := counted 2 (by decide) (by decide)
  have fourC := counted 4 (by decide) (by decide)
  have add := Nat.add_le_add (Nat.mul_le_mul_left ((20-r)*mass C.card M.card 4) twoC)
    (Nat.mul_le_mul_left (r*mass C.card M.card 2) fourC)
  apply add.trans
  exact le_sup (f := fun a => (20-r)*mass C.card M.card 4*few C.card (M.card-1) 2 d a +
    r*mass C.card M.card 2*few C.card (M.card-1) 4 d a) (mem_range.mpr (show k<_+1 by omega))

end Graffiti384b.RankVertex
#print axioms Graffiti384b.RankVertex.select_neighbors
#print axioms Graffiti384b.RankVertex.mixed_loss
