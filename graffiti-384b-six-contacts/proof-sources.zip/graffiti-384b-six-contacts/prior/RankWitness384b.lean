import RankStrata384b

namespace Graffiti384b.RankWitness
open Finset SimpleGraph RankStrata
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Replace exterior neighbors by distinct available outer vertices. The
same padded witness set works for every sample, preserving exactly the
original clique witnesses in all parts of a mixture. -/
theorem surrogate (C M g : Finset V) {v : V} (vm : v ∈ M) (dis : Disjoint C M)
    (ng : g ⊆ G.neighborFinset v) (room : g.card < M.card) :
    ∃ T ⊆ M.erase v, T.card = g.card-(g ∩ C).card ∧
      ∀ X ⊆ C, ∀ Y ⊆ M,
        (X ∩ (g ∩ C)).card + (Y ∩ T).card ≤ nbr G v ((C ∪ M)ᶜ ∪ (X ∪ Y)) := by
  let a := g ∩ C
  have inM : g ∩ M ⊆ M.erase v := fun z hz => mem_erase.mpr
    ⟨fun eq => G.not_mem_neighborFinset_self v (eq ▸ ng (mem_inter.mp hz).1),(mem_inter.mp hz).2⟩
  have apart : Disjoint a (g ∩ M) := disjoint_left.mpr
    (fun _ h k => disjoint_left.mp dis (mem_inter.mp h).2 (mem_inter.mp k).2)
  have total := card_le_card (show a ∪ (g ∩ M) ⊆ g from union_subset inter_subset_left inter_subset_left)
  rw [card_union_of_disjoint apart] at total
  obtain ⟨T,inT,lim,sz⟩ := exists_subsuperset_card_eq inM
    (show (g ∩ M).card ≤ g.card-a.card by omega)
    (show g.card-a.card ≤ (M.erase v).card by rw [card_erase_of_mem vm]; omega)
  refine ⟨T,lim,sz,?_⟩
  intro X xc Y ym
  let P := a ∪ T
  let S := C ∪ M
  let K := X ∪ Y
  have tM : T ⊆ M := lim.trans (erase_subset _ _)
  have disAT : Disjoint a T := disjoint_left.mpr (fun _ h k => disjoint_left.mp dis (mem_inter.mp h).2 (tM k))
  have asize := card_le_card (show a ⊆ g from inter_subset_left)
  have equal : P.card = g.card := by
    rw [show P = _ from rfl,card_union_of_disjoint disAT,sz]; omega
  have inc : g ∩ (S \ K) ⊆ P \ K := by
    intro z hz
    obtain ⟨zg,zk⟩ := mem_inter.mp hz
    obtain ⟨zs,nk⟩ := mem_sdiff.mp zk
    refine mem_sdiff.mpr ⟨?_,nk⟩
    rcases mem_union.mp zs with c | m
    · exact mem_union_left _ (mem_inter.mpr ⟨zg,c⟩)
    · exact mem_union_right _ (inT (mem_inter.mpr ⟨zg,m⟩))
  have real : g \ (S \ K) ⊆ (Sᶜ ∪ K).filter (G.Adj v) := by
    intro z hz
    obtain ⟨zg,no⟩ := mem_sdiff.mp hz
    refine mem_filter.mpr ⟨?_,(G.mem_neighborFinset _ _).mp (ng zg)⟩
    by_cases zs : z ∈ S
    · exact mem_union_right _ (Classical.byContradiction (fun nk => no (mem_sdiff.mpr ⟨zs,nk⟩)))
    · exact mem_union_left _ (mem_compl.mpr zs)
  have covered : (X ∩ a) ∪ (Y ∩ T) ⊆ P ∩ K := by
    intro z hz
    rcases mem_union.mp hz with h | h
    · exact mem_inter.mpr ⟨mem_union_left _ (mem_inter.mp h).2,mem_union_left _ (mem_inter.mp h).1⟩
    · exact mem_inter.mpr ⟨mem_union_right _ (mem_inter.mp h).2,mem_union_right _ (mem_inter.mp h).1⟩
  have apart' : Disjoint (X ∩ a) (Y ∩ T) := disjoint_left.mpr (fun _ h k =>
    disjoint_left.mp dis (xc (mem_inter.mp h).1) (ym (mem_inter.mp k).1))
  have h₁ := card_le_card real
  have h₂ := card_le_card inc
  have h₃ := card_sdiff_add_card_inter g (S \ K)
  have h₄ := card_sdiff_add_card_inter P K
  have h₅ := card_le_card covered
  rw [card_union_of_disjoint apart'] at h₅
  change _ ≤ nbr G v (Sᶜ ∪ K) at h₁
  change (X ∩ a).card+(Y ∩ T).card ≤ nbr G v (Sᶜ ∪ K)
  omega

/-- A fixed vertex's bad samples in a stratum are bounded by the
hypergeometric count with that vertex removed from the outer block. -/
theorem stratum_loss (C M A T : Finset V) {v : V} (vm : v ∈ M)
    (ac : A ⊆ C) (tm : T ⊆ M.erase v) {j b : ℕ} (jp : 1 ≤ j) (bp : 1 ≤ b)
    (compare : ∀ X ⊆ C, ∀ Y ⊆ M,
        (X ∩ A).card + (Y ∩ T).card ≤ nbr G v ((C ∪ M)ᶜ ∪ (X ∪ Y))) :
    (((C.powersetCard j) ×ˢ (M.powersetCard b)).filter
      (fun p => v ∈ FiniteRange.bad G (C ∪ M) (p.1 ∪ p.2))).card ≤
    counts A.card j 0 C.card * counts T.card b 0 (M.card-1) +
    counts A.card j 1 C.card * counts T.card b 0 (M.card-1) +
    counts A.card j 0 C.card * counts T.card b 1 (M.card-1) := by
  rw [← card_erase_of_mem vm,← few_hits C (M.erase v) A T ac tm jp bp]
  apply card_le_card
  intro p hp
  obtain ⟨row,bad⟩ := mem_filter.mp hp
  obtain ⟨xc,ym⟩ := mem_product.mp row
  have xs := (mem_powersetCard.mp xc).1
  obtain ⟨ys,sz⟩ := mem_powersetCard.mp ym
  obtain ⟨out,few⟩ := mem_filter.mp bad
  have notv := (mem_sdiff.mp out).2
  have ye : p.2 ⊆ M.erase v := fun z hz => mem_erase.mpr
    ⟨fun eq => notv (mem_union_right _ (eq ▸ hz)),ys hz⟩
  exact mem_filter.mpr ⟨mem_product.mpr ⟨xc,mem_powersetCard.mpr ⟨ye,sz⟩⟩,
    (compare _ xs _ ys).trans (by omega)⟩

end Graffiti384b.RankWitness
#print axioms Graffiti384b.RankWitness.surrogate
#print axioms Graffiti384b.RankWitness.stratum_loss
