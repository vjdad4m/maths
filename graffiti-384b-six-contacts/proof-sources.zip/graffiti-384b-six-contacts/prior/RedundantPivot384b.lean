import PivotSample384b
import RankAccounting384b

namespace Graffiti384b.RedundantPivot
open Finset SimpleGraph
open private FiniteRange.bad from FiniteRange384b
open private LowSample.anchor_samples from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A sampled clique-neighborhood vertex can be removed from a sample whenever
two specified neighbors remain. No formerly safe omitted vertex becomes deficient. -/
theorem erase_safe {w : V} {A k s : Finset V} (cl : CliqueChoice.cliqueAt G w)
    (adj : A ⊆ G.neighborFinset w) (sz : A.card=2) (ak : A ⊆ k) :
    FiniteRange.bad G s (k.erase w) ⊆ FiniteRange.bad G s k := by
  have inner (z : V) (za : z ∈ A) : z ∈ sᶜ ∪ k.erase w := mem_union_right _ (mem_erase.mpr
    ⟨((G.mem_neighborFinset _ _).mp (adj za)).ne.symm,ak za⟩)
  intro v hv
  obtain ⟨out,few⟩ := mem_filter.mp hv
  have vk' := (mem_sdiff.mp out).2
  have vw : v≠w := by
    intro eq
    subst v
    have sub : A ⊆ (sᶜ∪k.erase w).filter (G.Adj w) := fun z za =>
      mem_filter.mpr ⟨inner z za,(G.mem_neighborFinset _ _).mp (adj za)⟩
    exact (not_le_of_gt few) (sz ▸ card_le_card sub)
  have vk : v ∉ k := fun m => vk' (mem_erase.mpr ⟨vw,m⟩)
  have no : ¬G.Adj w v := by
    intro edge
    have sub : A ⊆ (sᶜ∪k.erase w).filter (G.Adj v) := fun z za =>
      mem_filter.mpr ⟨inner z za,cl v z edge ((G.mem_neighborFinset _ _).mp (adj za)) (fun eq => vk (eq ▸ ak za))⟩
    exact (not_le_of_gt few) (sz ▸ card_le_card sub)
  refine mem_filter.mpr ⟨mem_sdiff.mpr ⟨(mem_sdiff.mp out).1,vk⟩,lt_of_le_of_lt (card_le_card ?_) few⟩
  intro z hz
  obtain ⟨m,edge⟩ := mem_filter.mp hz
  exact mem_filter.mpr ⟨(mem_union.mp m).elim (mem_union_left _) (fun m => mem_union_right _
    (mem_erase.mpr ⟨fun eq => no (eq ▸ edge.symm),m⟩)),edge⟩

omit [Fintype V] in
/-- Requiring a sampled cubic vertex and two of its neighbors costs at most
three prescribed draws. In a 2+11 sample at least 6,489,450 rows contain them. -/
theorem marked (C M H : Finset V) (nc : C.card=4) (nm : M.card=28) (dis : Disjoint C M)
    (sub : H ⊆ C∪M) (three : H.card=3) (wc : (H\C).Nonempty) :
    6489450 ≤ (((C.powersetCard 2) ×ˢ M.powersetCard 11).filter (fun z => H ⊆ z.1∪z.2)).card := by
  let A := H∩C
  let B := H∩M
  have join : A∪B=H := by rw [show A∪B=H∩(C∪M) from (inter_union_distrib_left ..).symm,inter_eq_left.mpr sub]
  have sep := dis.mono (show A ⊆ C from inter_subset_right) (show B ⊆ M from inter_subset_right)
  have eq := congrArg card join
  rw [card_union_of_disjoint sep,three] at eq
  have bp : 0<B.card := by
    obtain ⟨w,wm⟩ := wc
    obtain ⟨wh,notC⟩ := mem_sdiff.mp wm
    exact card_pos.mpr ⟨w,mem_inter.mpr ⟨wh,(mem_union.mp (sub wh)).resolve_left notC⟩⟩
  let L := (C.powersetCard 2).filter (fun X => A ⊆ X)
  let R := (M.powersetCard 11).filter (fun Y => B ⊆ Y)
  have inc : L ×ˢ R ⊆ (((C.powersetCard 2) ×ˢ M.powersetCard 11).filter (fun z => H ⊆ z.1∪z.2)) := by
    intro z zz
    obtain ⟨left,right⟩ := mem_product.mp zz
    obtain ⟨xs,ax⟩ := mem_filter.mp left
    obtain ⟨ys,by'⟩ := mem_filter.mp right
    exact mem_filter.mpr ⟨mem_product.mpr ⟨xs,ys⟩,join ▸ union_subset_union ax by'⟩
  have l := LowSample.anchor_samples C A 2 inter_subset_right (by omega)
  have r := LowSample.anchor_samples M B 11 inter_subset_right (by omega)
  have size := card_le_card inc
  rw [card_product] at size
  have bound := (Nat.mul_le_mul l r).trans size
  rw [nc,nm,show B.card=3-A.card by omega] at bound
  have table : ∀ d : Fin 3, 6489450 ≤ (4-d.val).choose (2-d.val)*(28-(3-d.val)).choose (11-(3-d.val)) := by
    simp only [Nat.choose_eq_fast_choose]; decide
  exact (table ⟨A.card,by omega⟩).trans bound

end Graffiti384b.RedundantPivot
#print axioms Graffiti384b.RedundantPivot.erase_safe
#print axioms Graffiti384b.RedundantPivot.marked
