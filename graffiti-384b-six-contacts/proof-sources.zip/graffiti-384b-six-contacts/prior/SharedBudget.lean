import SharedTrial
import AnchorScores

namespace Graffiti384b.Shared29
open Finset SimpleGraph Donor JointRank
open private Repair.triangles_le_choose from Repair384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private Donor.rankDegree from PendantBudget
open private RankTuran.floorD RankTuran.floor_ok from RankTuran384b
open private PendantClose.inner_turan from PoolRank
open private Shared29.fiber from SharedTrial
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private def offset := (23:ℕ).choose 8
private def bonus := offset-FiniteRange.badCount 24 8 3
private def price (m : ℕ) := if m=0 then 0 else if m=1 then 2145 else if m<6 then 17589 else 32175
private def adjusted (m i : ℕ) :=
  if m < 6 ∧ ((m + 2).choose 2) + 2 ≤ i + 4 then i+3 else i

private def charge (m i : ℕ) :=
  let j := adjusted m i
  let raw := FiniteRange.badCount 24 9
  let inside := if j=1 then max (offset+raw 4) (offset+raw 3-bonus)
    else offset+raw (RankTuran.floorD j)
  max (offset+(24-Donor.rankDegree j).choose 9+price m) inside

/-- The seven exposure cases use the same nine-seed sampling model. The
last row covers any exposure count of six or more. -/
private theorem table : ∀m : Fin 7, (∑i∈range 24,charge m i) <
    3*(24:ℕ).choose 9+24*offset+m.val*price m := by
  unfold charge adjusted price offset bonus Donor.rankDegree RankTuran.floorD FiniteRange.badCount
  simp only [Nat.choose_eq_fast_choose]
  decide

/-- Without the anchor score gaps and without charging any exposure, the
envelope exceeds the repair budget by 114427. -/
theorem uncorrected_count :
    (∑i∈range 24, (let raw := FiniteRange.badCount 24 9
      let inside := if i=1 then max (offset+raw 4) (offset+raw 3-bonus) else offset+raw (RankTuran.floorD i)
      max (offset+(24-Donor.rankDegree i).choose 9) inside)) =
      24*offset+3*(24:ℕ).choose 9+114427 := by
  unfold offset bonus Donor.rankDegree RankTuran.floorD FiniteRange.badCount
  simp only [Nat.choose_eq_fast_choose]
  decide

/-- Three reserved high anchors are enough to omit two independent ears
outside the pool. The input bound is a score inequality for every pool rank. -/
theorem pool_budget {X E : Finset V} (fr : Frame G X E) (xs : X.card=24) (two : E.card=2)
    (strength : ∀v∈X,2+adjusted (min (exposed G X).card 6) (rank X (trianglesAt G) v)≤trianglesAt G v) :
    gamma G≤Fintype.card V-15 := by
  classical
  by_contra! fail
  let m := min (exposed G X).card 6
  have ms : m<7 := by dsimp [m]; omega
  let rank' := rank X (trianglesAt G)
  let A (v : V) := ((X.powersetCard 9).filter (fun k => v∈PendantRank.active G X k)).card
  let B (v : V) := ((X.powersetCard 9).filter (fun k => v∈FiniteRange.bad G X k)).card
  let paid (v : V) := if v∈exposed G X then price m else 0
  have free := five_free G fr fail
  have each (v : V) (vm : v∈X) : offset+B v+paid v≤charge m (rank' v)+A v := by
    have ri : rank' v<24 := mem_range.mp (by rw [←xs,←rank_range X (trianglesAt G) fr.distinct]; exact mem_image_of_mem _ vm)
    let r := adjusted m (rank' v)
    have hi : r<27 := by dsimp [r,adjusted]; split <;> omega
    have score : 2+r≤trianglesAt G v := strength v vm
    have deg3 : 3≤G.degree v := (mem_filter.mp (fr.high_sub vm)).2
    have cap := Repair.triangles_le_choose G v
    let inside := if r=1 then max (offset+FiniteRange.badCount 24 9 4) (offset+FiniteRange.badCount 24 9 3-bonus)
        else offset+FiniteRange.badCount 24 9 (RankTuran.floorD r)
    change _ ≤ max (offset+(24-Donor.rankDegree r).choose 9+price m) inside+A v
    by_cases ext : v∈exposed G X
    · obtain ⟨w,wx,vw⟩ := (mem_filter.mp ext).2
      let d := Donor.rankDegree r
      have ds : d≤8 := by dsimp [d]; unfold Donor.rankDegree; split_ifs <;> decide
      have lo : 1≤d := by dsimp [d]; unfold Donor.rankDegree; split_ifs <;> decide
      have dd : d≤G.degree v := by
        by_cases big : 8≤G.degree v
        · exact ds.trans big
        have tab : ∀a : Fin 8,∀i : Fin 27,2+i.val≤a.val.choose 2 → Donor.rankDegree i≤a := by decide
        exact tab ⟨_,Nat.lt_of_not_ge big⟩ ⟨_,hi⟩ (score.trans cap)
      have ct := BoundaryFiber.count G X 9 d vm wx vw dd lo
      rw [xs] at ct
      change B v≤(24-d).choose 9 at ct
      simp only [paid,if_pos ext]
      exact (Nat.add_le_add_right (Nat.add_le_add_left ct offset) _).trans ((le_max_left ..).trans (Nat.le_add_right ..))
    · simp only [paid,if_neg ext,Nat.add_zero]
      have ns : G.neighborFinset v⊆X := by
        intro a am
        by_contra na
        exact ext (mem_filter.mpr ⟨vm,a,na,(G.mem_neighborFinset ..).mp am⟩)
      have tu := PendantClose.inner_turan G vm ns free
      let j := RankTuran.floorD r
      have js : j≤10 := by
        have tab : ∀i : Fin 27,RankTuran.floorD i≤10 := by decide
        exact tab ⟨_,hi⟩
      have jd : j≤G.degree v := by
        by_contra! short
        have cut := RankTuran.floor_ok.2 ⟨r,by omega⟩ ⟨G.degree v,by omega⟩ deg3 short
        change (turanGraph (G.degree v) 3).edgeFinset.card<r+2 at cut
        omega
      have raw (d : ℕ) (up : d<24) (dd : d≤G.degree v) : B v≤FiniteRange.badCount 24 9 d := by
        have ct := FiniteRange.count_bad G X 9 d v vm dd (by rw [xs]; exact up)
        rwa [xs] at ct
      apply le_trans _ (Nat.add_le_add_right (le_max_right ..) _)
      dsimp only [inside]
      by_cases top : r=1
      · rw [if_pos top]
        by_cases low : G.degree v=3
        · have sat : trianglesAt G v=(G.degree v).choose 2 := by
            rw [top] at score; rw [low] at cap ⊢; change trianglesAt G v≤3 at cap; change trianglesAt G v=3; omega
          have act : bonus≤A v := Shared29.fiber G X xs vm sat 8 3 low.ge (by decide)
          have cb := raw 3 (by decide) low.ge
          have rb : bonus≤offset := Nat.sub_le ..
          have mx := le_max_right (offset+FiniteRange.badCount 24 9 4)
            (offset+FiniteRange.badCount 24 9 3-bonus)
          omega
        · have cb := raw 4 (by decide) (by omega)
          exact (Nat.add_le_add_left cb offset).trans ((le_max_left ..).trans (Nat.le_add_right ..))
      · rw [if_neg top]
        exact (Nat.add_le_add_left (raw j (by omega) jd) offset).trans (Nat.le_add_right ..)
  have swap (f : Finset V→Finset V) (sub : ∀k∈X.powersetCard 9,f k⊆X) :
      (∑ k∈X.powersetCard 9,(f k).card)=∑v∈X,((X.powersetCard 9).filter (fun k => v∈f k)).card := by
    calc
      _ = ∑k∈X.powersetCard 9,∑v∈X,(if v∈f k then 1 else 0 : ℕ) := by
        apply sum_congr rfl; intro k km
        simp [sum_boole,filter_mem_eq_inter,inter_eq_right.mpr (sub k km)]
      _ = _ := by rw [sum_comm]; simp
  have mass := sum_le_sum each
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,xs] at mass
  rw [sum_by_rank X (trianglesAt G) fr.distinct,xs] at mass
  have cb := swap (FiniteRange.bad G X) (fun _ _ => (filter_subset ..).trans sdiff_subset)
  have ca := swap (PendantRank.active G X) (fun _ km => (filter_subset ..).trans (mem_powersetCard.mp km).1)
  change _=∑v∈X,B v at cb
  change _=∑v∈X,A v at ca
  rw [←cb,←ca] at mass

  have credit : (∑v∈X,paid v)=(exposed G X).card*price m := by
    simp only [paid,←sum_filter,filter_mem_eq_inter,inter_eq_right.mpr (show exposed G X⊆X from filter_subset ..),sum_const,nsmul_eq_mul,Nat.cast_id]
  rw [credit] at mass
  have num := table ⟨m,ms⟩
  change (∑i∈range 24,charge m i)<3*(24:ℕ).choose 9+24*offset+m*price m at num
  have lower (k : Finset V) (km : k∈X.powersetCard 9) : 3+(PendantRank.active G X k).card≤(FiniteRange.bad G X k).card := by
    obtain ⟨sub,kb⟩ := mem_powersetCard.mp km
    have tr := two_trials G fr two k sub
    have up := card_le_univ X
    omega
  have bound := sum_le_sum lower
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,card_powersetCard,xs,Nat.cast_id] at bound
  have cmp := Nat.mul_le_mul_right (price m) (min_le_left (exposed G X).card 6)
  change m*price m≤(exposed G X).card*price m at cmp
  omega

end Graffiti384b.Shared29
#print axioms Graffiti384b.Shared29.uncorrected_count
#print axioms Graffiti384b.Shared29.pool_budget
