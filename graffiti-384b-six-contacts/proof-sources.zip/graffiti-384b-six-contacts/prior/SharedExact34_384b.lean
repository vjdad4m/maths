import SharedRepair34_384b
import EarTriangle34_384b
import Finish33_384b

namespace Graffiti384b.SharedExact34
open Finset SimpleGraph LowSample
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem ear_pair {y : V} (d : G.degree y=2) (p : 0<trianglesAt G y) :
    ∃ a b,G.neighborFinset y={a,b} ∧ G.Adj y a ∧ G.Adj y b ∧ G.Adj a b := by
  obtain ⟨a,b,ya,yb,ab⟩ := (TrianglePrune.triangle_iff G y).mp p
  have sub := insert_subset ((G.mem_neighborFinset _ _).mpr ya) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr yb))
  exact ⟨a,b,(eq_of_subset_of_card_le sub (by rw [card_pair ab.ne,card_neighborFinset_eq_degree,d])).symm,ya,yb,ab⟩

theorem failure_profile (t : (types G).card=33) {y z : V} (yz : y≠z)
    (dy : G.degree y=2) (dz : G.degree z=2) (py : 0<trianglesAt G y) (pz : 0<trianglesAt G z)
    (fail : bound G<gamma G) : (nonleaves G).card=33 ∧ (high G).card=31 ∧ twos G={y,z} ∧
      ¬G.Adj y z ∧ G.neighborFinset y∪G.neighborFinset z⊆high G := by
  have cap : (nonleaves G).card≤33 := by
    by_contra! big
    exact (not_lt_of_ge (Finish33.exact33 G t big)) fail
  have hn : high G⊆nonleaves G := fun v vm => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp vm).2; omega⟩
  have size : (twos G).card+(high G).card=(nonleaves G).card := card_sdiff_add_card_eq_card hn
  have isTwo (a : V) (d : G.degree a=2) : a∈twos G :=
    mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,d.ge⟩,fun ah => by have := (mem_filter.mp ah).2; omega⟩
  have yt := isTwo y dy
  have zt := isTwo z dz
  have ps := insert_subset yt (singleton_subset_iff.mpr zt)
  have low := card_le_card ps
  rw [card_pair yz] at low
  have lower := type_bound G
  have h : (high G).card=31 := by omega
  have q : (nonleaves G).card=33 := by omega
  have ears : twos G={y,z} := (eq_of_subset_of_card_le ps (by rw [card_pair yz]; omega)).symm
  have support (v : V) (d : G.degree v=2) (p : 0<trianglesAt G v) {i : V} (vi : G.Adj v i) :
      ∃ j,G.Adj v j ∧ G.Adj i j := by
    obtain ⟨a,b,val,va,vb,ab⟩ := ear_pair G d p
    have mem := (G.mem_neighborFinset _ _).mpr vi
    rw [val,mem_insert,mem_singleton] at mem
    rcases mem with rfl|rfl
    · exact ⟨b,vb,ab⟩
    · exact ⟨a,va,ab.symm⟩
  have apart : ¬G.Adj y z := by
    intro e
    obtain ⟨w,yw,zw⟩ := support y dy py e
    exact (not_lt_of_ge (EarTriangle34.exact G t h (by omega) yt zt e yw zw)) fail
  let W := G.neighborFinset y∪G.neighborFinset z
  have wh : W⊆high G := by
    intro i iw
    by_contra no
    obtain ⟨v,vi,d,p,which⟩ : ∃ v,G.Adj v i ∧ G.degree v=2 ∧ 0<trianglesAt G v ∧ (v=y ∨ v=z) := by
      rcases mem_union.mp iw with yi|zi
      · exact ⟨y,(G.mem_neighborFinset _ _).mp yi,dy,py,Or.inl rfl⟩
      · exact ⟨z,(G.mem_neighborFinset _ _).mp zi,dz,pz,Or.inr rfl⟩
    obtain ⟨j,vj,ij⟩ := support v d p vi
    have inc := insert_subset ((G.mem_neighborFinset _ _).mpr vi.symm) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr ij))
    have le := card_le_card inc
    rw [card_pair vj.ne,card_neighborFinset_eq_degree] at le
    have itw : i∈twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,le⟩,no⟩
    rw [ears,mem_insert,mem_singleton] at itw
    rcases which with rfl|rfl <;> rcases itw with rfl|rfl <;> first | exact vi.ne rfl | exact apart vi | exact apart vi.symm
  exact ⟨q,h,ears,apart,wh⟩

/-- Two ears with three distinct anchors always suffice at order 34
and diversity 33. The statement also applies to disconnected graphs. -/
theorem shared (n : Fintype.card V=34) (t : (types G).card=33) {y z : V} (yz : y≠z)
    (dy : G.degree y=2) (dz : G.degree z=2) (py : 0<trianglesAt G y) (pz : 0<trianglesAt G z)
    (three : (G.neighborFinset y∪G.neighborFinset z).card=3) : gamma G≤bound G := by
  by_contra! fail
  obtain ⟨q,h,ears,_,wh⟩ := failure_profile G t yz dy dz py pz fail
  exact (not_lt_of_ge (SharedRepair34.exact G yz ears n h t q _ rfl three wh)) fail

theorem separate (n : Fintype.card V=34) (t : (types G).card=33) {y z : V} (yz : y≠z)
    (dy : G.degree y=2) (dz : G.degree z=2) (py : 0<trianglesAt G y) (pz : 0<trianglesAt G z)
    (fail : bound G<gamma G) : Disjoint (G.neighborFinset y) (G.neighborFinset z) := by
  let A := G.neighborFinset y
  let B := G.neighborFinset z
  have ca : A.card=2 := (card_neighborFinset_eq_degree _ _).trans dy
  have cb : B.card=2 := (card_neighborFinset_eq_degree _ _).trans dz
  have num := card_union_add_card_inter A B
  have three : (A∪B).card≠3 := fun eq => (not_lt_of_ge (shared G n t yz dy dz py pz eq)) fail
  have min : 2<(A∪B).card := by
    by_contra! le
    have ea := eq_of_subset_of_card_le (show A⊆A∪B from subset_union_left) (by omega)
    have eb := eq_of_subset_of_card_le (show B⊆A∪B from subset_union_right) (by omega)
    exact (not_lt_of_ge (Repair.exact_of_twin_degree_two G yz dy (ea.trans eb.symm))) fail
  exact disjoint_iff_inter_eq_empty.mpr (card_eq_zero.mp (by change (A∩B).card=0; omega))

end Graffiti384b.SharedExact34
#print axioms Graffiti384b.SharedExact34.shared
#print axioms Graffiti384b.SharedExact34.separate
