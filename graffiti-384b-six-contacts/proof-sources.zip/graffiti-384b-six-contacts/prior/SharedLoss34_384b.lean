import SharedRanks34_384b

namespace Graffiti384b.SharedLoss34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample SharedRanks34
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Each anchor incidence earns a rebate. Only vertices adjacent to two or
three anchors need the overlap deduction. -/
theorem loss {s W : Finset V} (sw : Disjoint s W) (sh : s⊆high G) (wc : W.card=3)
    (m : ℕ) (sz : s.card=m) (room : 9<m) (env : BlockLoss.envelope m 10)
    (paid : ∀ j : Fin 10,3≤j.val → (m-j.val).choose 10+Finish33.rebate m 10≤FiniteRange.badCount m 10 j.val ∧
      FiniteRange.badCount m 10 9≤FiniteRange.badCount m 10 j.val)
    (BR : Finish33.rebate m 10≤FiniteRange.badCount m 10 9) :
    (∑ k∈s.powersetCard 10,(FiniteRange.bad G s k).card)+(∑ v∈s,nbr G v W)*Finish33.rebate m 10 ≤
      BlockLoss.chargeAt m 10 (fun j => (s.filter (fun v => G.degree v≤j)).card)+(∑ v∈s,(nbr G v W-1))*unit m := by
  let R := Finish33.rebate m 10
  let B := FiniteRange.badCount m 10 9
  let extra (v : V) := if 2≤nbr G v W then B else nbr G v W*R
  have ref (v : V) (vs : v∈s) : ((s.powersetCard 10).filter (fun k => v∈FiniteRange.bad G s k)).card+extra v ≤
      FiniteRange.badCount s.card 10 (min (G.degree v) 9) := by
    let a := min (G.degree v) 9
    have cap : 3≤a ∧ a≤9 := by dsimp [a]; have := (mem_filter.mp (sh vs)).2; omega
    obtain ⟨one,two⟩ := paid ⟨a,by omega⟩ cap.1
    change (m-a).choose 10+R≤FiniteRange.badCount m 10 a at one
    change B≤FiniteRange.badCount m 10 a at two
    by_cases many : 2≤nbr G v W
    · have none : ((s.powersetCard 10).filter (fun k => v∈FiniteRange.bad G s k))=∅ := by
        apply filter_eq_empty_iff.mpr
        intro k _ bad
        have enough : nbr G v W≤nbr G v (sᶜ∪k) := card_le_card (filter_subset_filter _ (show W⊆sᶜ∪k from
          fun j jw => mem_union_left _ (mem_compl.mpr (fun js => disjoint_left.mp sw js jw))))
        have short := (mem_filter.mp bad).2
        omega
      simp only [none,card_empty,extra,if_pos many,zero_add,sz]; exact two
    · by_cases nonzero : 0<nbr G v W
      · obtain ⟨w,wm⟩ := card_pos.mp nonzero
        obtain ⟨ww,vw⟩ := mem_filter.mp wm
        have raw := BoundaryFiber.count G s 10 a vs (fun ws => disjoint_left.mp sw ws ww) vw (min_le_left _ _) (by omega)
        rw [sz] at raw
        have num : nbr G v W=1 := by omega
        simp only [extra,if_neg many,num,Nat.one_mul,sz]
        exact (Nat.add_le_add_right raw R).trans one
      · have num : nbr G v W=0 := by omega
        simp only [extra,if_neg many,num,Nat.zero_mul,Nat.add_zero]
        exact FiniteRange.count_bad G s 10 a v vs (min_le_left _ _) (by omega)
  have res := BlockLoss.pool_loss G s sh 10 _ (fun _ _ _ => le_rfl) extra ref (sz ▸ env)
  rw [sz] at res
  have costs (v : V) (_ : v∈s) : nbr G v W*R≤extra v+(nbr G v W-1)*unit m := by
    have le : nbr G v W≤3 := (card_filter_le _ _).trans_eq wc
    by_cases many : 2≤nbr G v W
    · simp only [extra,if_pos many]
      change R≤B at BR
      change nbr G v W*R≤B+(nbr G v W-1)*((3*R-B+1)/2)
      rcases (show nbr G v W=2 ∨ nbr G v W=3 by omega) with eq|eq <;> rw [eq] <;> omega
    · simp [extra,many]
  have sum := sum_le_sum costs
  rw [sum_add_distrib,←sum_mul,←sum_mul] at sum
  change (∑ k∈s.powersetCard 10,(FiniteRange.bad G s k).card)+(∑ v∈s,nbr G v W)*R≤_
  omega

end Graffiti384b.SharedLoss34
#print axioms Graffiti384b.SharedLoss34.loss
