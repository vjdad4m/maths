import MultiEar34_384b
import SharedLoss34_384b
import EarCut34_384b

namespace Graffiti384b.SharedMany34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample SharedRanks34
open private LowSample.anchors LowSample.two_degree from LowSample384b
open private FiniteRange.bad from FiniteRange384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def candidates (W : Finset V) := (high G\W).filter (fun v => 2≤nbr G v W)

/-- Shared-anchor ears force between three and six exterior high vertices
with two neighbors among the three anchors. -/
theorem overlap {y z : V} (yz : y≠z) (ears : twos G={y,z})
    (n : Fintype.card V=34) (h : (high G).card=31) (t : (types G).card=33)
    (q : (nonleaves G).card=33) (fail : bound G<gamma G)
    (W : Finset V) (we : W=G.neighborFinset y∪G.neighborFinset z) (wc : W.card=3) (wh : W⊆high G) :
    11≤(∑ v∈high G\W,(nbr G v W-1))+(∑ v∈W,nbr G v W) ∧ (candidates G W).card≤6 := by
  classical
  let C := candidates G W
  have yt : y∈twos G := ears ▸ mem_insert_self _ _
  have zt : z∈twos G := ears ▸ mem_insert_of_mem (mem_singleton_self _)
  have ny : G.neighborFinset y⊆W := we ▸ subset_union_left
  have nz : G.neighborFinset z⊆W := we ▸ subset_union_right
  have anchor {a : V} (sub : G.neighborFinset a⊆W) : LowSample.anchors G a=G.neighborFinset a := by
    ext x
    exact ⟨fun m => (G.mem_neighborFinset _ _).mpr (mem_filter.mp m).2,
      fun m => mem_filter.mpr ⟨wh (sub m),(G.mem_neighborFinset _ _).mp m⟩⟩
  have cub {v : V} (vm : v∈C) := EarCut34.shared G yz ears wc wh ny nz (mem_filter.mp vm).1 (mem_filter.mp vm).2 (q.trans t.symm) fail
  have upper : C.card≤6 := by
    let H := (high G).filter (fun v => G.degree v=3)
    obtain ⟨inj,pos,_,_⟩ := Repair.maximal_diversity G (by omega)
    have sub : H.image (trianglesAt G)⊆{2,3} := by
      intro k km
      obtain ⟨v,vm,rfl⟩ := mem_image.mp km
      obtain ⟨hi,d⟩ := mem_filter.mp vm
      have lo := pos v hi
      have up := Repair.triangles_le_choose G v
      rw [d] at up
      change trianglesAt G v≤3 at up
      simp only [mem_insert,mem_singleton]; omega
    have num := card_le_card sub
    rw [card_image_of_injOn (inj.mono (show (H : Set V)⊆high G from fun _ hh => (mem_filter.mp hh).1)),card_pair (by decide : (2:ℕ)≠3)] at num
    have cover : C⊆H.biUnion (fun c => G.neighborFinset c) := by
      intro v vm
      obtain ⟨c,cs,cv,d,_⟩ := cub vm
      exact mem_biUnion.mpr ⟨c,mem_filter.mpr ⟨(mem_sdiff.mp cs).1,d⟩,(G.mem_neighborFinset _ _).mpr cv⟩
    have size := (card_le_card cover).trans card_biUnion_le
    have mass : (∑ c∈H,(G.neighborFinset c).card)=H.card*3 := by
      calc
        _ = ∑ _c∈H,3 := sum_congr rfl (fun c cm => (card_neighborFinset_eq_degree G c).trans (mem_filter.mp cm).2)
        _ = _ := by simp
    rw [mass] at size
    omega
  refine ⟨?_,upper⟩
  by_contra! few
  letI : Nonempty V := ⟨y⟩
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  let f := p.image (G.degree ·)
  let s := (high G\p)\W
  let m := 28-f.card
  let R := Finish33.rebate m 10
  have wm : W⊆high G\p := by
    intro a aw
    refine mem_sdiff.mpr ⟨wh aw,fun ap => ?_⟩
    rcases mem_union.mp (we ▸ aw) with ay|az
    · exact (mem_sdiff.mp yt).2 ((mem_sdiff.mp (neighbors_in_pool G ch ap ((G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp ay).symm))).1)
    · exact (mem_sdiff.mp zt).2 ((mem_sdiff.mp (neighbors_in_pool G ch ap ((G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp az).symm))).1)
  have thin (v : V) (vp : v∈p) : nbr G v W≤1 := by
    by_contra! many
    have vw : v∉W := fun inW => (mem_sdiff.mp (wm inW)).2 vp
    have vC : v∈C := mem_filter.mpr ⟨mem_sdiff.mpr ⟨ch.high_sub vp,vw⟩,many⟩
    obtain ⟨c,cs,cv,_,zero⟩ := cub vC
    obtain ⟨a,am⟩ := card_pos.mp (show 0<nbr G v W by omega)
    obtain ⟨aw,va⟩ := mem_filter.mp am
    have ne : c≠a := fun e => (mem_sdiff.mp cs).2 (mem_insert_of_mem (e ▸ aw))
    have ca := saturated_clique G (ch.exact_score v vp) c a cv.symm va ne
    have pos : 0<nbr G c W := card_pos.mpr ⟨a,mem_filter.mpr ⟨aw,ca⟩⟩
    omega
  have fc : f.card=p.card := card_image_of_injOn ch.unique
  have size : s.card=m := by dsimp only [s,m]; rw [card_sdiff wm,card_sdiff ch.high_sub,wc,h,fc]; omega
  obtain ⟨room,cheap,BR,env,paid,win⟩ := SharedRanks34.table f (mem_powerset.mpr ch.levels)
  change 9<m at room
  have sh : s⊆high G := sdiff_subset.trans sdiff_subset
  let I := ∑ w∈W,nbr G w W
  let O := ∑ v∈s,(nbr G v W-1)
  have oi : O+I≤10 := by
    have sub : s⊆high G\W := fun _ vm => mem_sdiff.mpr ⟨sh vm,(mem_sdiff.mp vm).2⟩
    have le := sum_le_sum_of_subset_of_nonneg sub (f:=fun v => nbr G v W-1) (fun _ _ _ => Nat.zero_le _)
    change O≤∑ v∈high G\W,(nbr G v W-1) at le
    change (∑ v∈high G\W,(nbr G v W-1))+I<11 at few
    omega
  have ii : I≤6 := by
    have each (v : V) (vw : v∈W) : nbr G v W≤2 := by
      have sub : W.filter (G.Adj v)⊆W.erase v := fun _ hm => mem_erase.mpr ⟨(mem_filter.mp hm).2.ne.symm,(mem_filter.mp hm).1⟩
      have le := card_le_card sub
      rwa [card_erase_of_mem vw,wc] at le
    have le := sum_le_sum each
    simpa only [sum_const,nsmul_eq_mul,Nat.cast_id,wc] using le
  have budget : O*unit m+I*R≤4*unit m+6*R := by
    change unit m≤R at cheap
    have le1 := Nat.mul_le_mul_right (unit m) (show O≤4+(6-I) by omega)
    have le2 := Nat.mul_le_mul_left (6-I) cheap
    have eq : (6-I)*R+I*R=6*R := by rw [←Nat.add_mul]; congr 1; omega
    rw [Nat.add_mul] at le1
    omega
  have loss := SharedLoss34.loss G (show Disjoint s W from disjoint_left.mpr (fun _ vs => (mem_sdiff.mp vs).2))
    sh wc m size room env (fun j hj => ⟨(paid j hj).1,(paid j hj).2.1⟩) BR
  have bal := MultiEar34.balance G ch wm yt zt yz (anchor ny ▸ ny) (anchor nz ▸ nz)
    (by rw [anchor ny,card_neighborFinset_eq_degree,LowSample.two_degree G yt])
    (by rw [anchor nz,card_neighborFinset_eq_degree,LowSample.two_degree G zt])
    t fail 10 (by change 9≤s.card; omega)
  dsimp only at bal
  change (s.card-10+2)*s.card.choose 10+(∑ a∈f,bonus s.card 10 a)≤16*s.card.choose 10+
    ∑ k∈s.powersetCard 10,(FiniteRange.bad G s k).card at bal
  rw [size] at bal
  let limitS (j : ℕ) := (s.filter (fun v => G.degree v≤j)).card
  change (∑ k∈s.powersetCard 10,(FiniteRange.bad G s k).card)+(∑ v∈s,nbr G v W)*R≤BlockLoss.chargeAt m 10 limitS+O*unit m at loss
  have acc := account G ch wm h t m
  change BlockLoss.chargeAt m 10 limitS+(∑ v∈W,rank m (G.degree v))≤BlockLoss.chargeAt m 10 (limit f) at acc
  have ind := incidence G n h q thin
  change (∑ w∈W,G.degree w)≤(∑ v∈s,nbr G v W)+I+5+p.card at ind
  rw [←fc] at ind
  have rel := Nat.mul_le_mul_right R ind
  rw [Nat.add_mul,Nat.add_mul,Nat.add_mul] at rel
  have earn (w : V) (ww : w∈W) : income m≤rank m (G.degree w)+G.degree w*R := by
    let d := min (G.degree w) 9
    have dd : 3≤d ∧ d≤9 := by dsimp [d]; have := (mem_filter.mp (wh ww)).2; omega
    have val := (paid ⟨d,by omega⟩ dd.1).2.2
    change income m≤rank m d+d*R at val
    have eq : rank m d=rank m (G.degree w) := by
      unfold rank
      apply sum_congr rfl
      intro j jr
      have iff : d≤j ↔ G.degree w≤j := by dsimp [d]; have := mem_range.mp jr; omega
      simp only [iff]
    rw [eq] at val
    exact val.trans (Nat.add_le_add_left (Nat.mul_le_mul_right R (min_le_left _ _)) _)
  have allW := sum_le_sum earn
  rw [sum_const,nsmul_eq_mul,wc,sum_add_distrib,←sum_mul] at allW
  change 16*m.choose 10+BlockLoss.chargeAt m 10 (limit f)+(11+f.card)*R+4*unit m <
    (m-10+2)*m.choose 10+(∑ a∈f,bonus m 10 a)+3*income m at win
  rw [Nat.add_mul] at win
  omega
end Graffiti384b.SharedMany34
#print axioms Graffiti384b.SharedMany34.overlap
