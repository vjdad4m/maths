import SharedMany34_384b

namespace Graffiti384b.SharedProfile34
open Finset SimpleGraph LowSample SharedMany34
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

omit [Fintype V] in
private theorem in_degree {W : Finset V} (wc : W.card=3) {v : V} (vw : v∈W) : nbr G v W≤2 := by
  have sub : W.filter (G.Adj v)⊆W.erase v := fun _ hm => mem_erase.mpr ⟨(mem_filter.mp hm).2.ne.symm,(mem_filter.mp hm).1⟩
  have le := card_le_card sub
  rwa [card_erase_of_mem vw,wc] at le

omit [Fintype V] in
/-- The internal degree sum of three vertices drops by at least two
when one edge is absent. -/
private theorem missing {W : Finset V} (wc : W.card=3) {i j : V} (iw : i∈W) (jw : j∈W)
    (ne : i≠j) (gap : ¬G.Adj i j) : (∑ v∈W,nbr G v W)≤4 := by
  have low {v w : V} (vw : v∈W) (ww : w∈W) (diff : v≠w) (no : ¬G.Adj v w) : nbr G v W≤1 := by
    have sub : W.filter (G.Adj v)⊆(W.erase v).erase w := fun a hm =>
      mem_erase.mpr ⟨fun eq => no (eq ▸ (mem_filter.mp hm).2),mem_erase.mpr ⟨(mem_filter.mp hm).2.ne.symm,(mem_filter.mp hm).1⟩⟩
    have le := card_le_card sub
    rwa [card_erase_of_mem (mem_erase.mpr ⟨diff.symm,ww⟩),card_erase_of_mem vw,wc] at le
  let A : Finset V := {i,j}
  have sub : A⊆W := insert_subset iw (singleton_subset_iff.mpr jw)
  have point (v : V) (vw : v∈W) : nbr G v W+(if v∈A then 1 else 0)≤2 := by
    by_cases va : v∈A
    · rw [if_pos va]; rcases mem_insert.mp va with rfl|m
      · have := low iw jw ne gap; omega
      · obtain rfl := mem_singleton.mp m
        have := low jw iw ne.symm (fun e => gap e.symm); omega
    · rw [if_neg va,Nat.add_zero]; exact in_degree G wc vw
  have res := sum_le_sum point
  simp only [sum_add_distrib,sum_boole,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr sub,sum_const,nsmul_eq_mul,wc] at res
  change (∑ v∈W,nbr G v W)+A.card≤3*2 at res
  have sz : A.card=2 := card_pair ne
  omega

theorem profile {y z : V} (yz : y≠z) (ears : twos G={y,z}) (n : Fintype.card V=34)
    (h : (high G).card=31) (t : (types G).card=33) (q : (nonleaves G).card=33) (fail : bound G<gamma G)
    (W : Finset V) (we : W=G.neighborFinset y∪G.neighborFinset z) (wc : W.card=3) (wh : W⊆high G) :
    3≤(candidates G W).card ∧ (candidates G W).card≤6 ∧
    ((∃ i∈W,∃ j∈W,i≠j ∧ ¬G.Adj i j) →
      4≤(candidates G W).card ∧ (∃ v∈candidates G W,nbr G v W=3) ∧
      (((high G).filter (fun v => G.degree v=3 ∧ nbr G v W=0)).image (trianglesAt G))={2,3}) := by
  let C := candidates G W
  let I := ∑ v∈W,nbr G v W
  obtain ⟨need,cap⟩ := overlap G yz ears n h t q fail W we wc wh
  have eq : (∑ v∈C,(nbr G v W-1))=∑ v∈high G\W,(nbr G v W-1) := by
    apply sum_subset (filter_subset _ _)
    intro v vm out
    have small : nbr G v W<2 := Nat.lt_of_not_ge (fun hi => out (mem_filter.mpr ⟨vm,hi⟩))
    omega
  rw [←eq] at need
  change 11≤(∑ v∈C,(nbr G v W-1))+I at need
  have deg (v : V) : nbr G v W≤3 := (card_filter_le _ _).trans_eq wc
  have total := sum_le_sum (s:=C) (fun v _ => show nbr G v W-1≤2 by have := deg v; omega)
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id] at total
  have maxI := sum_le_sum (s:=W) (fun _ wm => in_degree G wc wm)
  rw [sum_const,nsmul_eq_mul,wc] at maxI
  change I≤3*2 at maxI
  refine ⟨by change 3≤C.card; omega,cap,?_⟩
  rintro ⟨i,iw,j,jw,ne,no⟩
  have small : I≤4 := missing G wc iw jw ne no
  have cm : 4≤C.card := by omega
  refine ⟨cm,?_,?_⟩
  · by_contra miss
    have two (v : V) (vm : v∈C) : nbr G v W-1≤1 := by
      have ne : nbr G v W≠3 := fun e => miss ⟨v,vm,e⟩
      have := deg v
      omega
    have le := sum_le_sum two
    simp only [sum_const,nsmul_eq_mul,Nat.mul_one,Nat.cast_id] at le
    change C.card≤6 at cap
    omega
  · let H := (high G).filter (fun v => G.degree v=3 ∧ nbr G v W=0)
    have sub : C⊆H.biUnion (fun v => G.neighborFinset v) := by
      intro v vm
      obtain ⟨c,cw,cv,d,zero⟩ := EarCut34.shared G yz ears wc wh (we ▸ subset_union_left) (we ▸ subset_union_right)
        (mem_filter.mp vm).1 (mem_filter.mp vm).2 (q.trans t.symm) fail
      exact mem_biUnion.mpr ⟨c,mem_filter.mpr ⟨(mem_sdiff.mp cw).1,d,zero⟩,(G.mem_neighborFinset _ _).mpr cv⟩
    have bound := (card_le_card sub).trans card_biUnion_le
    have eq : (∑ v∈H,(G.neighborFinset v).card)=H.card*3 := by
      calc
        _ = ∑ _v∈H,3 := sum_congr rfl (fun v vm => (card_neighborFinset_eq_degree G v).trans (mem_filter.mp vm).2.1)
        _ = _ := by simp
    rw [eq] at bound
    have many : 2≤H.card := by omega
    obtain ⟨inj,pos,_,_⟩ := Repair.maximal_diversity G (by omega)
    have inc : H.image (trianglesAt G)⊆{2,3} := by
      intro k hk
      obtain ⟨v,vm,rfl⟩ := mem_image.mp hk
      have lo := pos v (mem_filter.mp vm).1
      have up := Repair.triangles_le_choose G v
      rw [(mem_filter.mp vm).2.1] at up
      change trianglesAt G v≤3 at up
      simp only [mem_insert,mem_singleton]; omega
    apply eq_of_subset_of_card_le inc
    rw [card_image_of_injOn (inj.mono (show (H : Set V)⊆high G from fun _ vm => (mem_filter.mp vm).1)),card_pair (by decide : (2:ℕ)≠3)]
    exact many
end Graffiti384b.SharedProfile34
#print axioms Graffiti384b.SharedProfile34.profile
