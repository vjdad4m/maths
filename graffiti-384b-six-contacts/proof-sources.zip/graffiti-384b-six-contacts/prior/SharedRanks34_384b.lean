import Finish33_384b

namespace Graffiti384b.SharedRanks34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private LowSample.delta from LowSample384b
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def rank (m d : ℕ) := ∑ j∈range 9,if d≤j then LowSample.delta m 10 j else 0
def income (m : ℕ) := min (rank m 8+8*Finish33.rebate m 10) (9*Finish33.rebate m 10)
def penalty (m : ℕ) := 3*Finish33.rebate m 10-FiniteRange.badCount m 10 9
def unit (m : ℕ) := (penalty m+1)/2
def limit (f : Finset ℕ) (j : ℕ) := 31+slots f j Boundary.levels-33-(f.filter (·≤j)).card

private def Row (f : Finset ℕ) :=
  let m := 28-f.card
  9<m ∧ unit m≤Finish33.rebate m 10 ∧ Finish33.rebate m 10≤FiniteRange.badCount m 10 9 ∧ BlockLoss.envelope m 10 ∧ (∀ j : Fin 10,3≤j.val →
    (m-j.val).choose 10+Finish33.rebate m 10≤FiniteRange.badCount m 10 j.val ∧
    FiniteRange.badCount m 10 9≤FiniteRange.badCount m 10 j.val ∧
    income m≤rank m j.val+j.val*Finish33.rebate m 10) ∧
  16*m.choose 10+BlockLoss.chargeAt m 10 (limit f)+(11+f.card)*Finish33.rebate m 10+4*unit m <
    (m-10+2)*m.choose 10+(∑ a∈f,bonus m 10 a)+3*income m

set_option maxRecDepth 32768 in
set_option maxHeartbeats 10000000 in
theorem table : ∀ f∈Boundary.levels.powerset, Row f := by
  unfold Row income rank unit penalty limit BlockLoss.envelope BlockLoss.chargeAt Finish33.rebate slots LowSample.delta bonus FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

/-- Each permanently retained anchor contributes its own removed degree rank
in every lower degree threshold. -/
theorem account {p W : Finset V} (ch : Choice G p Boundary.levels) (wm : W⊆high G\p)
    (h : (high G).card=31) (t : (types G).card=33) (m : ℕ) :
    let s := (high G\p)\W
    BlockLoss.chargeAt m 10 (fun j => (s.filter (fun v => G.degree v≤j)).card) +
        (∑ w∈W, rank m (G.degree w)) ≤ BlockLoss.chargeAt m 10 (limit (p.image (G.degree ·))) := by
  let U := high G\p
  let s := U\W
  let f := p.image (G.degree ·)
  let thresh (j : ℕ) (v : V) := G.degree v≤j
  have each (j : ℕ) (jr : j∈range 9) : LowSample.delta m 10 j*(s.filter (thresh j)).card+
      LowSample.delta m 10 j*(W.filter (thresh j)).card≤LowSample.delta m 10 j*limit f j := by
    by_cases big : 3≤j
    · have eq : U=s∪W := (sdiff_union_of_subset wm).symm
      have dis : Disjoint s W := disjoint_left.mpr (fun _ sm => (mem_sdiff.mp sm).2)
      have count := CliqueChoice.profile G ch j big
      dsimp only at count
      rw [h,t] at count
      change (U.filter (thresh j)).card+33+(f.filter (·≤j)).card≤31+slots f j Boundary.levels at count
      rw [eq,filter_union,card_union_of_disjoint (dis.mono (filter_subset _ _) (filter_subset _ _))] at count
      rw [←Nat.mul_add]
      apply Nat.mul_le_mul_left
      unfold limit
      omega
    · simp [LowSample.delta,big]
  have eq : (∑ v∈W,rank m (G.degree v))=∑ j∈range 9,LowSample.delta m 10 j*(W.filter (thresh j)).card := by
    unfold rank
    rw [sum_comm]; apply sum_congr rfl
    intro j _
    rw [←sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]; rfl
  have sum := sum_le_sum each
  rw [sum_add_distrib] at sum
  dsimp only
  change BlockLoss.chargeAt m 10 (fun j => (s.filter (thresh j)).card)+_≤_
  rw [eq]; unfold BlockLoss.chargeAt
  rw [Nat.add_assoc]
  exact Nat.add_le_add_left sum _

omit [DecidableEq V] in
theorem degree_sum (W : Finset V) : (∑ w∈W,G.degree w)=∑ v : V,nbr G v W := by
  have eq (w : V) : G.degree w=∑ v : V,if G.Adj v w then 1 else 0 := by
    simp only [sum_boole,Nat.cast_id]
    rw [←card_neighborFinset_eq_degree]
    congr 1
    ext v; simp [G.adj_comm]
  simp only [eq]
  rw [sum_comm]
  simp only [sum_boole,Nat.cast_id,nbr]

/-- The three anchors have at most six internal directed incidences. An
order-34 graph with two ears and one leaf has at most five further low incidences. -/
theorem incidence {p W : Finset V}
    (n : Fintype.card V=34) (h : (high G).card=31) (q : (nonleaves G).card=33)
    (thin : ∀ v∈p,nbr G v W≤1) :
    (∑ w∈W,G.degree w) ≤ (∑ v∈((high G\p)\W),nbr G v W)+(∑ v∈W,nbr G v W)+5+p.card := by
  let s := (high G\p)\W
  let l := (nonleaves G)ᶜ
  let low := twos G
  have hn : high G⊆nonleaves G := fun v vm => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp vm).2; omega⟩
  have two : low.card=2 := by dsimp [low,twos]; rw [card_sdiff hn,h,q]
  have lc : l.card=1 := by dsimp [l]; rw [card_compl,n,q]
  have all (v : V) (_ : v∈(univ : Finset V)) : nbr G v W≤
      (if v∈s then nbr G v W else 0)+(if v∈W then nbr G v W else 0)+(if v∈p then 1 else 0)+
      (if v∈low then 2 else 0)+(if v∈l then 1 else 0) := by
    have nd : nbr G v W≤G.degree v := by
      have sub : W.filter (G.Adj v)⊆G.neighborFinset v := fun _ m => (G.mem_neighborFinset _ _).mpr (mem_filter.mp m).2
      exact (card_le_card sub).trans_eq (card_neighborFinset_eq_degree _ _)
    by_cases vs : v∈s
    · rw [if_pos vs]; omega
    by_cases vw : v∈W
    · rw [if_pos vw]; omega
    by_cases pp : v∈p
    · have := thin v pp; rw [if_pos pp]; omega
    by_cases vh : v∈high G
    · exact (vs (mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨vh,pp⟩,vw⟩)).elim
    by_cases vn : v∈nonleaves G
    · have vl : v∈low := mem_sdiff.mpr ⟨vn,vh⟩
      have small : G.degree v≤2 := by by_contra! big; exact vh (mem_filter.mpr ⟨mem_univ _,big⟩)
      rw [if_pos vl]; omega
    · have vl : v∈l := mem_compl.mpr vn
      have small : G.degree v≤1 := by by_contra! big; exact vn (mem_filter.mpr ⟨mem_univ _,big⟩)
      rw [if_pos vl]; omega
  have inc := sum_le_sum all
  simp only [sum_add_distrib,←sum_filter,filter_mem_eq_inter,univ_inter,sum_const,nsmul_eq_mul,Nat.cast_id,lc,two,Nat.mul_one] at inc
  rw [degree_sum G]; change (∑ v : V,nbr G v W)≤(∑ v∈s,nbr G v W)+(∑ v∈W,nbr G v W)+5+p.card
  omega
end Graffiti384b.SharedRanks34
#print axioms Graffiti384b.SharedRanks34.account
#print axioms Graffiti384b.SharedRanks34.incidence
