import CubicCover34_384b
import AnchorLink34_384b
import SharedMany34_384b

namespace Graffiti384b.SharedRepair34
open Finset SimpleGraph LowSample
open private Repair.nbr_mono from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem exact {y z : V} (yz : y≠z) (ears : twos G={y,z})
    (n : Fintype.card V=34) (h : (high G).card=31) (t : (types G).card=33)
    (q : (nonleaves G).card=33) (W : Finset V) (we : W=G.neighborFinset y∪G.neighborFinset z)
    (wc : W.card=3) (wh : W⊆high G) : gamma G≤bound G := by
  classical
  by_contra! fail
  let C := SharedMany34.candidates G W
  let L := twos G
  let Q := L∪C
  have ly : y∈L := by change y∈twos G; rw [ears]; exact mem_insert_self ..
  have lz : z∈L := by change z∈twos G; rw [ears]; exact mem_insert_of_mem (mem_singleton_self _)
  have lc (e : V) (em : e∈L) : G.neighborFinset e⊆W := by
    rw [show L={y,z} from ears,mem_insert,mem_singleton] at em
    rcases em with rfl|rfl
    · exact we ▸ subset_union_left
    · exact we ▸ subset_union_right
  have low (v : V) (vm : v∈L) := (mem_sdiff.mp vm).2
  have cand (v : V) (vm : v∈C) : v∈high G\W ∧ 2≤nbr G v W := mem_filter.mp vm
  have freeHigh {v : V} (vn : v∈nonleaves G) (vq : v∉Q) : v∈high G := by
    by_cases vh : v∈high G
    · exact vh
    · exact (vq (mem_union_left _ (show v∈L from mem_sdiff.mpr ⟨vn,vh⟩))).elim
  have dis : Disjoint W Q := disjoint_left.mpr (fun v vw vq => (mem_union.mp vq).elim
    (fun vl => low v vl (wh vw)) (fun vc => (mem_sdiff.mp (cand v vc).1).2 vw))
  have hit (v : V) (vq : v∈Q) : 2≤nbr G v W := by
    rcases mem_union.mp vq with vl|vc
    · have inc : G.neighborFinset v⊆W.filter (G.Adj v) := fun j jm => mem_filter.mpr ⟨lc v vl jm,(G.mem_neighborFinset _ _).mp jm⟩
      have le := card_le_card inc
      rw [card_neighborFinset_eq_degree] at le
      exact (mem_filter.mp (mem_sdiff.mp vl).1).2.trans le
    · exact (cand v vc).2
  have ear (u : V) (uw : u∈W) : ∃ e∈L,G.Adj u e := by
    rcases mem_union.mp (we ▸ uw) with m|m
    · exact ⟨y,ly,((G.mem_neighborFinset _ _).mp m).symm⟩
    · exact ⟨z,lz,((G.mem_neighborFinset _ _).mp m).symm⟩
  by_cases good : ∀ u∈W,2≤nbr G u Q
  · exact (not_lt_of_ge (PinnedColor34.complete G dis (by omega)
      (fun v vn _ vq => (mem_filter.mp (freeHigh vn vq)).2) good hit)) fail
  push_neg at good
  obtain ⟨u,uw,bad⟩ := good
  obtain ⟨e,el,ue⟩ := ear u uw
  have one : 0<nbr G u Q := card_pos.mpr ⟨e,mem_filter.mpr ⟨mem_union_left _ el,ue⟩⟩
  have miss (a : V) (ac : a∈C) : ¬G.Adj u a := by
    intro ua
    have ne : e≠a := fun eq => low e el (eq ▸ (mem_sdiff.mp (cand a ac).1).1)
    have two := PinnedColor34.two G ne ue ua (mem_union_left C el) (mem_union_right L ac)
    change 2≤nbr G u Q at two
    omega
  have sees {a : V} (ac : a∈C) : W.filter (G.Adj a)=W.erase u := by
    have sub : W.filter (G.Adj a)⊆W.erase u := fun j jm => mem_erase.mpr
      ⟨fun eq => miss a ac (eq ▸ (mem_filter.mp jm).2.symm),(mem_filter.mp jm).1⟩
    exact eq_of_subset_of_card_le sub (by rw [card_erase_of_mem uw,wc]; exact (cand a ac).2)
  have mass : (∑ a∈high G\W,(nbr G a W-1))=C.card := by
    have restrict : (∑ a∈C,(nbr G a W-1))=∑ a∈high G\W,(nbr G a W-1) := by
      apply sum_subset (filter_subset _ _)
      intro a am no
      have sm : ¬2≤nbr G a W := fun ge => no (mem_filter.mpr ⟨am,ge⟩)
      omega
    rw [←restrict]
    calc
      _ = ∑ _a∈C,1 := sum_congr rfl (fun a ac => by rw [nbr,sees ac,card_erase_of_mem uw,wc])
      _ = _ := by simp
  have inside (a : V) (aw : a∈W) : nbr G a W≤2 := by
    have inc : W.filter (G.Adj a)⊆W.erase a := fun j jm => mem_erase.mpr ⟨(mem_filter.mp jm).2.ne.symm,(mem_filter.mp jm).1⟩
    have le := card_le_card inc
    rwa [card_erase_of_mem aw,wc] at le
  have upper := sum_le_sum inside
  rw [sum_const,nsmul_eq_mul,wc] at upper
  have over := (SharedMany34.overlap G yz ears n h t q fail W we wc wh).1
  rw [mass] at over
  have many : 5≤C.card := by omega
  let H := CubicCover34.cubes G
  have cover (a : V) (ac : a∈C) : ∃ j∈H,nbr G j W=0 ∧ G.Adj j a := by
    obtain ⟨j,jo,ja,d,zero⟩ := EarCut34.shared G yz ears wc wh (lc y ly) (lc z lz) (cand a ac).1 (cand a ac).2 (q.trans t.symm) fail
    exact ⟨j,mem_filter.mpr ⟨(mem_sdiff.mp jo).1,d⟩,zero,ja⟩
  obtain ⟨cube,score⟩ := CubicCover34.crowded G many (by omega) cover
  have zero {v j : V} (vh : v∈H) (jw : j∈W) : ¬G.Adj v j := by
    intro vj
    have pos : 0<nbr G v W := card_pos.mpr ⟨j,mem_filter.mpr ⟨jw,vj⟩⟩
    have eq := (cube v vh).1
    omega
  have un : u∉H := by
    intro uh
    have big := (cube u uh).2
    obtain ⟨a,am⟩ := card_pos.mp (show 0<nbr G u C by omega)
    exact miss a (mem_filter.mp am).1 (mem_filter.mp am).2
  have earsFew : nbr G u L≤1 := by
    have mono := Repair.nbr_mono G u (show L⊆Q from subset_union_left)
    omega
  obtain ⟨x,m,xw,xq,mq,ux,um,xm⟩ := AnchorLink34.outside G wc uw (L:=L) rfl lc
    (fun v vm ge => show v∈C from mem_filter.mpr ⟨vm,ge⟩) earsFew miss (score u (wh uw) un)
  let P := W∪H
  have pp : Disjoint P Q := disjoint_left.mpr (by
    intro v vp vq
    rcases mem_union.mp vp with vw|vh
    · exact disjoint_left.mp dis vw vq
    rcases mem_union.mp vq with vl|vc
    · exact low v vl (mem_filter.mp vh).1
    · have two := (cand v vc).2
      have eq := (cube v vh).1
      omega)
  have safe (v : V) (vp : v∈P) (ne : v≠u) : 2≤nbr G v Q := by
    apply le_trans _ (Repair.nbr_mono G v (show C⊆Q from subset_union_right))
    rcases mem_union.mp vp with vw|vh
    · have allC : C.filter (G.Adj v)=C := filter_true_of_mem (fun a ac => by
        have rw' : v∈W.filter (G.Adj a) := by rw [sees ac]; exact mem_erase.mpr ⟨ne,vw⟩
        exact (mem_filter.mp rw').2.symm)
      rw [nbr,allC]; omega
    · exact (cube v vh).2
  have free (v : V) (vn : v∈nonleaves G) (vp : v∉P) (vq : v∉Q) : 4≤G.degree v := by
    have hi := freeHigh vn vq
    have d := (mem_filter.mp hi).2
    have ne : G.degree v≠3 := fun eq => vp (mem_union_right W (show v∈H from mem_filter.mpr ⟨hi,eq⟩))
    omega
  have xp : x∉P := fun m' => (mem_union.mp m').elim xw (fun xh => zero xh uw ux.symm)
  exact (not_lt_of_ge (PinnedColor34.repair G pp (by omega) free safe
    (fun v vq => (hit v vq).trans (Repair.nbr_mono G v (show W⊆P from subset_union_left)))
    one (mem_union_left _ uw) xp xq mq ux um xm)) fail

end Graffiti384b.SharedRepair34
#print axioms Graffiti384b.SharedRepair34.exact
