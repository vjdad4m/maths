import SharedFive
import PoolRank
namespace Graffiti384b.Shared29
open Finset SimpleGraph Donor
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private PendantRank.remove_kept from ThirdEar
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem fiber (X : Finset V) (xs : X.card=24) {v : V} (vx : v∈X) (sat : trianglesAt G v=(G.degree v).choose 2)
    (k d : ℕ) (di : d≤G.degree v) (dr : d<24) :
    (23:ℕ).choose k-FiniteRange.badCount 24 k d≤((X.powersetCard (k+1)).filter (fun s => v∈PendantRank.active G X s)).card := by
  classical
  let K := (X.erase v).powersetCard k
  let ok := fun s : Finset V => 2≤nbr G v (Xᶜ∪s)
  have total := filter_card_add_filter_neg_card_eq_card (s:=K) ok
  have ks : K.card=(23:ℕ).choose k := by dsimp [K]; rw [card_powersetCard,card_erase_of_mem vx,xs]
  have fail : K.filter (fun s => ¬ok s)⊆(X.powersetCard k).filter (fun s => v∈FiniteRange.bad G X s) := by
    intro s sm
    obtain ⟨sk,no⟩ := mem_filter.mp sm
    obtain ⟨se,sc⟩ := mem_powersetCard.mp sk
    exact mem_filter.mpr ⟨mem_powersetCard.mpr ⟨se.trans (erase_subset ..),sc⟩,
      mem_filter.mpr ⟨mem_sdiff.mpr ⟨vx,fun vs => (mem_erase.mp (se vs)).1 rfl⟩,Nat.lt_of_not_ge no⟩⟩
  have bound := FiniteRange.count_bad G X k d v vx di (xs ▸ dr)
  rw [xs] at bound
  have small := (card_le_card fail).trans bound
  let good := K.filter ok
  have off {s : Finset V} (sm : s∈good) : v∉s := fun vs =>
    (mem_erase.mp ((mem_powersetCard.mp (mem_filter.mp sm).1).1 vs)).1 rfl
  have inj : Set.InjOn (insert v) (good:Set (Finset V)) := by
    intro s sm t tm eq
    simpa [erase_insert (off sm),erase_insert (off tm)] using congrArg (fun S : Finset V => S.erase v) eq
  have inc : good.image (insert v)⊆(X.powersetCard (k+1)).filter (fun s => v∈PendantRank.active G X s) := by
    intro t tm
    obtain ⟨s,sm,rfl⟩ := mem_image.mp tm
    obtain ⟨ks',yes⟩ := mem_filter.mp sm
    obtain ⟨se,sc⟩ := mem_powersetCard.mp ks'
    have sub := insert_subset vx (se.trans (erase_subset ..))
    have ct := card_insert_of_not_mem (off sm)
    refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub,by omega⟩,mem_filter.mpr ⟨mem_insert_self ..,sat,?_⟩⟩
    exact yes.trans (card_le_card (filter_subset_filter _ (union_subset_union Subset.rfl (subset_insert ..))))
  have count := card_le_card inc
  rw [card_image_of_injOn inj] at count
  change good.card+_=K.card at total
  omega


/-- Sample inside the pool with both exterior ears omitted. Removing the
second ear leaves the deficient set unchanged, since every neighbor is retained. -/
theorem two_trials {X E : Finset V} (fr : Frame G X E) (two : E.card=2)
    (k : Finset V) (sub : k⊆X) :
    gamma G+X.card+(PendantRank.active G X k).card+2≤Fintype.card V+k.card+(FiniteRange.bad G X k).card := by
  classical
  obtain ⟨e,f,ne,eq⟩ := card_eq_two.mp two
  have ee : e∈E := eq ▸ mem_insert_self _ _
  have fe : f∈E := eq ▸ mem_insert_of_mem (mem_singleton_self _)
  have fx := disjoint_left.mp fr.exterior fe
  obtain ⟨s,desc,size,small,_⟩ := PendantRank.clean G X k sub fr.distinct
    (disjoint_left.mp fr.exterior ee) (fr.separate e ee) (fr.degree e ee)
  have keep : G.neighborFinset f⊆s := by
    intro y ym
    have fy := (G.mem_neighborFinset ..).mp ym
    have yx : y∉X := fun m => fr.separate f fe y m fy
    rw [desc]
    exact mem_sdiff.mpr ⟨mem_union_left _ (mem_compl.mpr yx),fun m =>
      (mem_insert.mp m).elim (fun ye => fr.independent f fe e ee (ye ▸ fy))
        (fun ya => yx (sub (mem_filter.mp ya).1))⟩
  have fs : f∈s := by
    rw [desc]
    exact mem_sdiff.mpr ⟨mem_union_left _ (mem_compl.mpr fx),fun m =>
      (mem_insert.mp m).elim ne.symm (fun fa => fx (sub (mem_filter.mp fa).1))⟩
  have drop := card_erase_add_one fs
  obtain ⟨same,_⟩ := PendantRank.remove_kept G s (fr.degree f fe) keep
  have win := batch_repair_saves G (s.erase f) ∅ (empty_subset _) (by simp)
  change gamma G≤(s.erase f).card+(deficient G (s.erase f)).card-(∅ : Finset V).card at win
  simp only [card_empty,Nat.sub_zero,same] at win
  have upper := card_le_card small
  omega
end Graffiti384b.Shared29
#print axioms Graffiti384b.Shared29.two_trials
