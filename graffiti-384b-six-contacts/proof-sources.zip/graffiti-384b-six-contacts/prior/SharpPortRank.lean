import PrivatePorts
namespace Graffiti384b.Exterior
open Finset SimpleGraph FiveChoice
open private Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Without a short repair, at most one triangle at a boundary vertex can
use a port. Its two partners must be unique in two different neighbor sets. -/
theorem boundary_triangle_cap {P Q S W : Finset V} {a u : V} (H : Ports G P Q S W a)
    (no : ¬Closes G P Q W 3) (um : u∈boundary G S W) (support : Repair.linkSupport G u⊆S∪W) :
    trianglesAt G u≤(nbr G u W).choose 2+1 := by
  classical
  let U := boundary G S W
  let B := (link G u).filter (fun edge => ¬edge⊆W)
  have lim := local_limits G H no
  have uw := (mem_filter.mp um).1
  have repr (edge : Finset V) (m : edge∈B) : ∃s∈S.filter (G.Adj u),∃w∈U.filter (G.Adj u),edge={s,w} := by
    obtain ⟨el,out⟩ := mem_filter.mp m
    obtain ⟨s,sm,sw⟩ := not_subset.mp out
    obtain ⟨sub,two,cl⟩ := Repair.edge_info G el
    have all {v : V} (vm : v∈edge) : v∈S∪W := support (mem_biUnion.mpr ⟨edge,el,vm⟩)
    have ss := (mem_union.mp (all sm)).resolve_right sw
    have us := (G.mem_neighborFinset ..).mp (sub sm)
    obtain ⟨w,wm,ws⟩ := exists_ne_of_one_lt_card (by omega : 1<edge.card) s
    have adj := (G.mem_neighborFinset ..).mp (sub wm)
    have ww := (mem_union.mp (all wm)).resolve_left (fun h => ws (card_le_one.mp (lim.1 u uw) w
      (mem_filter.mpr ⟨h,adj⟩) s (mem_filter.mpr ⟨ss,us⟩)))
    have fromS : w∈U := mem_filter.mpr ⟨ww,s,ss,cl w wm s sm ws⟩
    refine ⟨s,mem_filter.mpr ⟨ss,us⟩,w,mem_filter.mpr ⟨fromS,adj⟩,?_⟩
    exact (eq_of_subset_of_card_le (insert_subset sm (singleton_subset_iff.mpr wm)) (by rw [two,card_pair ws.symm])).symm
  have one : B.card≤1 := card_le_one.mpr (by
    intro p pm q qm
    obtain ⟨s,sm,w,wm,rfl⟩ := repr p pm
    obtain ⟨t,tm,z,zm,rfl⟩ := repr q qm
    have eq := card_le_one.mp (lim.1 u uw) s sm t tm
    have eq' := card_le_one.mp (lim.2 u uw) w wm z zm
    rw [eq,eq'])
  have sub : link G u⊆(W.filter (G.Adj u)).powersetCard 2 ∪ B := by
    intro edge el
    by_cases inc : edge⊆W
    · obtain ⟨ns,two,_⟩ := Repair.edge_info G el
      exact mem_union_left _ (mem_powersetCard.mpr ⟨fun v vm => mem_filter.mpr
        ⟨inc vm,(G.mem_neighborFinset ..).mp (ns vm)⟩,two⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨el,inc⟩)
  have cap := (card_le_card sub).trans (card_union_le _ _)
  rw [card_powersetCard] at cap
  exact cap.trans (Nat.add_le_add_left one _)

private theorem four_return {P Q S W : Finset V} {a : V} (H : Ports G P Q S W a)
    (no : ¬Closes G P Q W 3) (rich : ∀u∈boundary G S W,4≤trianglesAt G u)
    (inj : Set.InjOn (trianglesAt G) (boundary G S W : Set V))
    (support : ∀u∈boundary G S W,Repair.linkSupport G u⊆S∪W) :
    4*(boundary G S W).card≤W.card+1 := by
  classical
  let U := boundary G S W
  let low := U.filter (fun u => nbr G u W≤3)
  have three (u : V) (um : u∈U) : 3≤nbr G u W := by
    by_contra! small
    have bound := boundary_triangle_cap G H no um (support u um)
    have k := Nat.choose_le_choose 2 (by omega : nbr G u W≤2)
    have num : (2:ℕ).choose 2=1 := by decide
    have := rich u um
    omega
  have score (u : V) (ul : u∈low) : trianglesAt G u=4 := by
    obtain ⟨um,small⟩ := mem_filter.mp ul
    have cap := boundary_triangle_cap G H no um (support u um)
    have k := Nat.choose_le_choose 2 small
    have num : (3:ℕ).choose 2=3 := by decide
    have := rich u um
    omega
  have one : low.card≤1 := card_le_one.mpr (fun u um v vm => inj (mem_filter.mp um).1 (mem_filter.mp vm).1 ((score u um).trans (score v vm).symm))
  have each (u : V) (um : u∈U) : 4≤nbr G u W + (if u∈low then 1 else 0) := by
    by_cases l : u∈low
    · rw [if_pos l]; have := three u um; omega
    · rw [if_neg l]; have n : ¬nbr G u W≤3 := fun s => l (mem_filter.mpr ⟨um,s⟩); omega
  have total := sum_le_sum each
  have inc : low⊆U := filter_subset ..
  rw [sum_const,nsmul_eq_mul,Nat.cast_id,sum_add_distrib,sum_boole,filter_mem_eq_inter,inter_eq_right.mpr inc] at total
  simp only [Nat.cast_id] at total
  have small : (∑u∈U,nbr G u W)≤W.card := Nat.le_of_not_gt (fun many => no (incidence_solution G H many))
  change 4*U.card≤_
  omega

/-- No triangle-score condition on the deficient anchor. Distinct positive
high scores on the two ports and the boundary suffice when |W| is at most 21. -/
theorem score_free_cut {P Q S W : Finset V} {a x y : V} (H : Ports G P Q S W a)
    (pair : S={x,y}) (xy : x≠y) (room : W.card≤21)
    (loss : ∀p∈S,trianglesAt G p≤(kept (link G p) (S∪W)).card+1)
    (rich : ∀u∈S∪boundary G S W,2≤trianglesAt G u)
    (inj : Set.InjOn (trianglesAt G) ((S∪boundary G S W : Finset V):Set V))
    (support : ∀u∈boundary G S W,Repair.linkSupport G u⊆S∪W) :
    Closes G P Q W 3 := by
  classical
  by_contra no
  let U := boundary G S W
  have xs : x∈S := pair ▸ mem_insert_self ..
  have ys : y∈S := pair ▸ mem_insert_of_mem (mem_singleton_self _)
  have small : S.card≤2 := pair ▸ card_le_two
  have sx := loss x xs
  have sy := loss y ys
  rw [trim_two G H no small xs] at sx
  rw [trim_two G H no small ys] at sy
  have positive (u : V) (um : u∈U) := rich u (mem_union_right _ um)
  have unique : Set.InjOn (trianglesAt G) (U:Set V) := inj.mono (show U⊆S∪U from subset_union_right)
  have cap := rank_obstruction G H no positive unique (fun u m => score_cap_of_support G u _ (support u m))
  rw [pair,sum_pair xy] at cap
  have xall : x∈S∪U := mem_union_left _ xs
  have yall : y∈S∪U := mem_union_left _ ys
  have x2 := rich x xall
  have y2 := rich y yall
  have diff : trianglesAt G x≠trianglesAt G y := fun eq => xy (inj xall yall eq)
  have total : trianglesAt G x+trianglesAt G y=5 := by omega
  have four (u : V) (um : u∈U) : 4≤trianglesAt G u := by
    have uw := (mem_filter.mp um).1
    have ux : trianglesAt G x≠trianglesAt G u := fun eq => disjoint_left.mp H.apartRegions xs ((inj xall (mem_union_right _ um) eq) ▸ uw)
    have uy : trianglesAt G y≠trianglesAt G u := fun eq => disjoint_left.mp H.apartRegions ys ((inj yall (mem_union_right _ um) eq) ▸ uw)
    have := positive u um
    omega
  have last := four_return G H no four unique support
  have many := boundary_size G H no
  rw [pair,sum_pair xy] at many
  rw [pair] at last
  omega
end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.boundary_triangle_cap
#print axioms Graffiti384b.Exterior.score_free_cut
