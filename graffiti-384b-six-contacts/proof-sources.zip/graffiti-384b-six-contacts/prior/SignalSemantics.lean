import LocalSignals
namespace Graffiti384b.Four29.LocalTest
open Finset SimpleGraph Words
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem order_pair : ∀z:Label×Label, z∈pairs ↔ z.1<z.2 := by decide
private theorem key_table : ∀a b x y:Label, a<b → x<y → b.val<7 → y.val<7 →
    position a b=position x y → a=x ∧ b=y := by decide

omit [Fintype V] [DecidableEq V] [DecidableRel G.Adj] in
/-- Supply the row of the truth table that encodes all edges among the seven
high labels. Edges touching an ear are prescribed by its actual neighborhood. -/
theorem represents (f : Label ↪ V)
    (ear : ∀i j:Label, (7 ≤ i.val ∨ 7 ≤ j.val) → (preset i j=true ↔ G.Adj (f i) (f j))) :
    ∃p<2^21,∀i j:Label,(edge i j).testBit p=true ↔ G.Adj (f i) (f j) := by
  classical
  let v := fun n : ℕ => decide (∃a b:Label, a<b ∧ b.val<7 ∧ position a b=n ∧ G.Adj (f a) (f b))
  let p := assignment v 21
  have young (i j : Label) (ij : i<j) (j7 : j.val<7) : (column 21 (position i j)).testBit p=true ↔ G.Adj (f i) (f j) := by
    have tab : ∀a b:Label,a<b → b.val<7 → position a b<21 := by decide
    rw [column_at v (tab i j ij j7)]
    change decide _=true ↔ _
    rw [decide_eq_true_eq]
    constructor
    · rintro ⟨a,b,ab,b7,key,adj⟩
      obtain ⟨rfl,rfl⟩ := key_table a b i j ab ij b7 j7 key
      exact adj
    · exact fun h => ⟨i,j,ij,j7,rfl,h⟩
  have top : (ones 21).testBit p=true := by
    rw [ones,Nat.testBit_two_pow_sub_one,decide_eq_true_eq]; exact assignment_bound v 21
  refine ⟨p,assignment_bound v 21,?_⟩
  intro i j
  unfold edge
  by_cases ij : i=j
  · subst j; simp
  rw [if_neg ij]
  split
  · rename_i small
    rcases lt_or_gt_of_ne ij with lt|gt
    · exact young i j lt small.2
    · have eq : position i j=position j i := by simp [position,max_comm,min_comm]
      rw [eq,young j i gt small.1]; exact G.adj_comm _ _
  · rename_i old
    have out : 7 ≤ i.val ∨ 7 ≤ j.val := by omega
    have same := ear i j out
    cases b : preset i j <;> simp only [b,Bool.false_eq_true,if_false,Nat.zero_testBit,Bool.true_eq,if_true,top] at same ⊢ <;> exact same

theorem counts (f : Label ↪ V) (p : ℕ)
    (edges : ∀a b:Label,(edge a b).testBit p=true ↔ G.Adj (f a) (f b))
    (i : Label) (locality : ∀z∈Repair.linkSupport G (f i),z∈Set.range f) :
    number p (score i)=trianglesAt G (f i) := by
  classical
  let tag (z : Label×Label) := edge i z.1 &&& edge i z.2 &&& edge z.1 z.2
  let selected := pairs.filter (fun z => (tag z).testBit p)
  let P := selected.toFinset
  let liftPair (z : Label×Label) : Finset V := {f z.1,f z.2}
  have sm (z : Label×Label) : z∈P ↔ z.1<z.2 ∧ G.Adj (f i) (f z.1) ∧ G.Adj (f i) (f z.2) ∧ G.Adj (f z.1) (f z.2) := by
    simp only [P,selected,List.mem_toFinset,List.mem_filter,order_pair,tag,Nat.testBit_and,Bool.and_eq_true,edges,and_assoc]
  have repr : P.image liftPair=Repair.linkEdges G (f i) := by
    ext s
    constructor
    · intro hm
      obtain ⟨⟨a,b⟩,ab,rfl⟩ := mem_image.mp hm
      obtain ⟨lt,ia,ib,adj⟩ := (sm _).mp ab
      have sub : liftPair (a,b)⊆G.neighborFinset (f i) := insert_subset ((G.mem_neighborFinset ..).mpr ia)
        (singleton_subset_iff.mpr ((G.mem_neighborFinset ..).mpr ib))
      refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨sub,card_pair (f.injective.ne lt.ne)⟩,?_⟩
      intro x xm y ym ne
      simp only [liftPair,mem_insert,mem_singleton] at xm ym
      rcases xm with rfl|rfl <;> rcases ym with rfl|rfl <;> first | exact (ne rfl).elim | exact adj | exact adj.symm
    · intro hm
      obtain ⟨sub,sz,cl⟩ := Repair.edge_info G hm
      obtain ⟨x,y,ne,rfl⟩ := card_eq_two.mp sz
      have xm : x∈({x,y}:Finset V) := mem_insert_self ..
      have ym : y∈({x,y}:Finset V) := mem_insert_of_mem (mem_singleton_self _)
      obtain ⟨a,rfl⟩ := locality x (mem_biUnion.mpr ⟨_,hm,xm⟩)
      obtain ⟨b,rfl⟩ := locality y (mem_biUnion.mpr ⟨_,hm,ym⟩)
      have ia := (G.mem_neighborFinset ..).mp (sub xm)
      have ib := (G.mem_neighborFinset ..).mp (sub ym)
      have adj := cl _ xm _ ym ne
      rcases lt_or_gt_of_ne (fun eq : a=b => ne (congrArg f eq)) with l|l
      · exact mem_image.mpr ⟨(a,b),(sm _).mpr ⟨l,ia,ib,adj⟩,rfl⟩
      · exact mem_image.mpr ⟨(b,a),(sm _).mpr ⟨l,ib,ia,adj.symm⟩,pair_comm ..⟩
  have inj : Set.InjOn liftPair (P : Set (Label×Label)) := by
    rintro ⟨a,b⟩ ap ⟨c,d⟩ cp eq
    have lt := ((sm _).mp ap).1
    have lt' := ((sm _).mp cp).1
    have eq' : ({f a,f b}:Set V)={f c,f d} := by simpa [liftPair] using congrArg (fun s : Finset V => (s:Set V)) eq
    rcases Set.pair_eq_pair_iff.mp eq' with ⟨ac,bd⟩|⟨ad,bc⟩
    · exact Prod.ext (f.injective ac) (f.injective bd)
    · have := f.injective ad
      have := f.injective bc
      change a<b at lt; change c<d at lt'
      subst c; subst d; exact (not_lt_of_ge lt.le lt').elim
  have ord : pairs.Nodup := by decide
  have count := congrArg Finset.card repr
  rw [card_image_of_injOn inj] at count
  have sz := List.toFinset_card_of_nodup (ord.filter _ : selected.Nodup)
  change number p (binary (pairs.map tag))=(Repair.linkEdges G (f i)).card
  rw [binary_at,List.filter_map,List.length_map]
  change selected.length=_
  exact sz.symm.trans count

omit [Fintype V] [DecidableEq V] in
/-- Translate a tested placement back to actual neighbor counts. Only
distinct pinned labels are counted. -/
theorem support_lift (f : Label ↪ V) {p : ℕ} (pt : (ones 21).testBit p=true)
    (edges : ∀a b:Label,(edge a b).testBit p=true ↔ G.Adj (f a) (f b))
    {P Q : List Label} (nodup : Q.Nodup) (ok : (supported P Q).testBit p=true) :
    ∀v∈P.toFinset.map f,2≤nbr G v (Q.toFinset.map f) := by
  intro v vm; obtain ⟨i,ip,rfl⟩ := mem_map.mp vm
  have ys := (all_at pt _).mp ok _ (List.mem_map.mpr ⟨i,List.mem_toFinset.mp ip,rfl⟩)
  have two := (atTwo_at p _).mp ys
  rw [List.filter_map,List.length_map] at two
  let good := Q.filter (fun j => (edge i j).testBit p)
  have sz := List.toFinset_card_of_nodup (nodup.filter _ : good.Nodup)
  have sub : good.toFinset.map f⊆(Q.toFinset.map f).filter (G.Adj (f i)) := by
    intro z zm
    obtain ⟨j,jm,rfl⟩ := mem_map.mp zm
    obtain ⟨jq,adj⟩ := List.mem_filter.mp (List.mem_toFinset.mp jm)
    exact mem_filter.mpr ⟨mem_map.mpr ⟨j,List.mem_toFinset.mpr jq,rfl⟩,(edges i j).mp adj⟩
  have le := card_le_card sub
  rw [card_map,sz] at le
  exact two.trans le
end Graffiti384b.Four29.LocalTest
#print axioms Graffiti384b.Four29.LocalTest.represents
#print axioms Graffiti384b.Four29.LocalTest.counts
#print axioms Graffiti384b.Four29.LocalTest.support_lift
