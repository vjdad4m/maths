import SixTrial384b
import PendantCount384b
import LowerProfiles384b

namespace Graffiti384b.Six
open Finset SimpleGraph ThreeRegion
open private SmallScores35.allowed from SmallScores35_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def weighted (n d a b : ℕ) :=
  few 2 4 n a b (d-a-b) 0 2 + few 2 4 n a b (d-a-b) 1 2 + 3*few 2 4 n a b (d-a-b) 2 0
def cost (d : ℕ) := ([0,0,0,45762640,32097156,21515676,13957476,8591154,5002998,3073668] : List ℕ)[d]?.getD 0
def delta (j : ℕ) := if 3 ≤ j then cost j-cost (j+1) else 0

def profiles : Finset (Finset ℕ) := {∅,{3},{4},{5},{6},{3,4},{3,5}}
def threshold (f : Finset ℕ) (j : ℕ) := min 26 (CliqueChoice.slots f j Boundary.levels-2-(if 6≤j then 1 else 0))

set_option maxRecDepth 8192 in
private theorem table :
    (∀ d : Fin 10, 3 ≤ d.val → ∀ a : Fin 3, ∀ b : Fin 5, a.val+b.val≤d.val → weighted 25 d a b ≤ cost d) ∧
    (∀ a : Fin 3, ∀ b : Fin 5, a.val+b.val≤2 → weighted 26 2 a b ≤ 96101544) ∧
    (∀ d : Fin 10, 3 ≤ d.val → cost d ≤ cost 9 + ∑ j ∈ range 9, if d.val≤j then delta j else 0) ∧
    (∀ f ∈ profiles, 26*cost 9 + ∑ j ∈ range 9, delta j * threshold f j ≤ 397835258) := by
  unfold weighted few count cost delta threshold profiles CliqueChoice.slots Boundary.levels
  simp only [Nat.choose_eq_fast_choose]
  decide

omit [Fintype V] in
private theorem parts (P R g : Finset V) (split : Disjoint P R) :
    (g∩P).card+(g∩R).card≤g.card := by
  rw [← card_union_of_disjoint (split.mono inter_subset_right inter_subset_right)]
  exact card_le_card (union_subset inter_subset_left inter_subset_left)

def charge (P R M s : Finset V) (v : V) := badMass G P R M s v 0 2 + badMass G P R M s v 1 2 + 3*badMass G P R M s v 2 0

private theorem local_bound {x y : V} {P R M : Finset V} (D : Configuration G x y P R M)
    {v : V} (vm : v ∈ M) : charge G P R M (high G \ {x}) v ≤ cost (min (G.degree v) 9) := by
  let d := min (G.degree v) 9
  have vs := mem_sdiff.mp (show v ∈ high G \ {x} from D.cover ▸ mem_union_right _ vm)
  have low : 3 ≤ d := le_min (mem_filter.mp vs.1).2 (by decide)
  have highD : d ≤ 9 := min_le_right _ _
  obtain ⟨g,ng,gd⟩ := exists_subset_card_eq (show d ≤ (G.neighborFinset v).card by rw [card_neighborFinset_eq_degree]; exact min_le_left _ _)
  have room : g.card<M.card := by rw [gd,D.mcard]; omega
  have raw (i j : ℕ) := bad_bound G D.split D.dis D.cover vm ng room i j
  have combined := Nat.add_le_add (Nat.add_le_add (raw 0 2) (raw 1 2)) (Nat.mul_le_mul_left 3 (raw 2 0))
  simp only [D.pcard,D.rcard,D.mcard,gd] at combined
  have a := (card_le_card (show g∩P ⊆ P from inter_subset_right)).trans_eq D.pcard
  have b := (card_le_card (show g∩R ⊆ R from inter_subset_right)).trans_eq D.rcard
  have sizes := parts P R g D.split
  rw [gd] at sizes
  exact combined.trans (table.1 ⟨d,by omega⟩ low ⟨(g∩P).card,by omega⟩ ⟨(g∩R).card,by omega⟩ sizes)

private theorem ear_bound {x y : V} {P R M : Finset V} (D : Configuration G x y P R M) :
    missed G P R M y 0 2 + missed G P R M y 1 2 + 3*missed G P R M y 2 0 ≤ 96101544 := by
  let N := G.neighborFinset y
  have raw (i j : ℕ) := missed_bound G D.split D.dis D.inside i j
  have combined := Nat.add_le_add (Nat.add_le_add (raw 0 2) (raw 1 2)) (Nat.mul_le_mul_left 3 (raw 2 0))
  simp only [D.pcard,D.rcard,D.mcard,D.ear] at combined
  have a := (card_le_card (show N∩P ⊆ P from inter_subset_right)).trans_eq D.pcard
  have b := (card_le_card (show N∩R ⊆ R from inter_subset_right)).trans_eq D.rcard
  have sizes := parts P R N D.split
  rw [show N.card=2 from (card_neighborFinset_eq_degree _ _).trans D.ear] at sizes
  exact combined.trans (table.2.1 ⟨(N∩P).card,by omega⟩ ⟨(N∩R).card,by omega⟩ sizes)

private theorem ranks {p M : Finset V} {x : V} (ch : CliqueChoice.Choice G p Boundary.levels)
    (t : (types G).card=35) (h : (high G).card=33) (xh : x ∈ high G) (deg : G.degree x=6)
    (ms : M ⊆ high G \ {x}) (size : M.card=26) {j : ℕ} (big : 3≤j) :
    (M.filter (fun v => G.degree v≤j)).card ≤ threshold (p.image (G.degree ·)) j := by
  obtain ⟨inj,pos,_,_⟩ := Repair.maximal_diversity G (by omega)
  let low := M.filter (fun v => G.degree v≤j)
  let cand := (high G).filter (fun v => G.degree v≤j)
  have sub : low ⊆ cand := fun v hv => mem_filter.mpr ⟨(mem_sdiff.mp (ms (mem_filter.mp hv).1)).1,(mem_filter.mp hv).2⟩
  have ss : cand.image (trianglesAt G) ⊆ Ico 2 (CliqueChoice.slots (p.image (G.degree ·)) j Boundary.levels) := by
    intro z mem
    obtain ⟨v,vm,rfl⟩ := mem_image.mp mem
    exact mem_Ico.mpr ⟨pos _ (mem_filter.mp vm).1,SmallScores35.allowed G ch big (mem_filter.mp vm).2⟩
  have num := card_le_card ss
  rw [card_image_of_injOn (inj.mono (filter_subset _ _)),Nat.card_Ico] at num
  change cand.card ≤ CliqueChoice.slots (p.image (G.degree ·)) j Boundary.levels-2 at num
  apply le_min ((card_filter_le _ _).trans_eq size)
  by_cases yes : 6≤j
  · have inc : insert x low ⊆ cand := insert_subset (mem_filter.mpr ⟨xh,deg ▸ yes⟩) sub
    have le := card_le_card inc
    have out : x ∉ low := fun v => (mem_sdiff.mp (ms (mem_filter.mp v).1)).2 (mem_singleton_self _)
    rw [card_insert_of_not_mem out] at le
    change low.card ≤ _-2-(if 6≤j then 1 else 0)
    rw [if_pos yes]; omega
  · rw [if_neg yes,Nat.sub_zero]
    exact (card_le_card sub).trans num

private theorem exterior {x y : V} {P R M : Finset V} (D : Configuration G x y P R M)
    {p : Finset V} (ch : CliqueChoice.Choice G p Boundary.levels) (prof : p.image (G.degree ·) ∈ profiles)
    (t : (types G).card=35) (h : (high G).card=33) :
    ∑ v ∈ M, charge G P R M (high G \ {x}) v ≤ 397835258 := by
  let s := high G \ {x}
  have cover : P∪R∪M=s := D.cover
  have outside : M ⊆ s := cover ▸ subset_union_right
  let a (v : V) := min (G.degree v) 9
  have row (v : V) (vm : v ∈ M) : charge G P R M s v ≤ cost 9+∑ j ∈ range 9, if a v≤j then delta j else 0 := by
    have hi : a v ≤ 9 := min_le_right _ _
    have lo : 3 ≤ a v := le_min (mem_filter.mp (mem_sdiff.mp (outside vm)).1).2 (by decide)
    exact (local_bound G D vm).trans (table.2.2.1 ⟨a v,by omega⟩ lo)
  have step (j : ℕ) (jj : j ∈ range 9) : (∑ v ∈ M, if a v≤j then delta j else 0) ≤
      delta j * threshold (p.image (G.degree ·)) j := by
    by_cases pos : 3≤j
    · rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
      apply Nat.mul_le_mul_left
      have count := ranks G ch t h D.center D.deg outside D.mcard pos
      apply le_trans (card_le_card ?_) count
      intro v hv
      obtain ⟨vm,sm⟩ := mem_filter.mp hv
      have hi := mem_range.mp jj
      change min (G.degree v) 9≤j at sm
      exact mem_filter.mpr ⟨vm,by omega⟩
    · simp [delta,pos]
  have total := sum_le_sum row
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,D.mcard] at total
  rw [sum_comm (s := M) (t := range 9)] at total
  apply le_trans _ (table.2.2.2 _ prof)
  exact total.trans (Nat.add_le_add_left (sum_le_sum step) _)

private theorem row_size {x y : V} {P R M : Finset V} (D : Configuration G x y P R M) (i j : ℕ) :
    (box P R M i j).card=(2 : ℕ).choose i * ((4 : ℕ).choose j * 5311735) := by
  have ways : Nat.choose 26 10=5311735 := by rw [Nat.choose_eq_fast_choose]; decide
  simp only [box,card_product,card_powersetCard,D.pcard,D.rcard,D.mcard,ways]

theorem exact_block {x y : V} {P R M : Finset V} (D : Configuration G x y P R M)
    {p : Finset V} (ch : CliqueChoice.Choice G p Boundary.levels) (prof : p.image (G.degree ·) ∈ profiles)
    (t : (types G).card=35) (h : (high G).card=33) : gamma G ≤ bound G := by
  by_contra! fail
  have a := balance G D t fail (Or.inl ⟨rfl,rfl⟩ : (0=0 ∧ 2=2) ∨ (0=1 ∧ 2=2) ∨ (0=2 ∧ 2=0))
  have b := balance G D t fail (i:=1) (j:=2) (by decide)
  have c := balance G D t fail (i:=2) (j:=0) (by decide)
  rw [row_size G D] at a b c
  change 159352050 ≤ _ at a
  change 254963280 ≤ _ at b
  change 26558675 ≤ _ at c
  have ext := exterior G D ch prof t h
  simp only [charge,sum_add_distrib,← mul_sum] at ext
  have ear := ear_bound G D
  omega

end Graffiti384b.Six
#print axioms Graffiti384b.Six.exact_block
