import SixCount384b
import StratumFinish35_384b

namespace Graffiti384b.Six
open Finset SimpleGraph BlockGeometry
open private Stratum35.ear from StratumFinish35_384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The 35-type, 33-high, one-ear case also satisfies the catalogue bound
when the pivotal center has degree six and at most one missing neighbor pair. -/
theorem exact_six (t : (types G).card=35)
    (h : (high G).card=33) (q : (nonleaves G).card=34) (x : V) (degree : G.degree x=6)
    (gap : (gaps G (G.neighborFinset x)).card≤1) : gamma G ≤ bound G := by
  classical
  by_contra! fail
  let C := G.neighborFinset x
  let s := high G \ {x}
  have xh : x ∈ high G := mem_filter.mpr ⟨mem_univ _,by omega⟩
  have sz : s.card=32 := by dsimp [s]; rw [card_sdiff (singleton_subset_iff.mpr xh),h,card_singleton]
  have nc : C.card=6 := (card_neighborFinset_eq_degree _ _).trans degree
  have cs : C ⊆ s := by
    intro v vc
    have nd := BlockFibers.neighbor_degree G x vc
    exact mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,
      fun eq => ((G.mem_neighborFinset _ _).mp vc).ne (mem_singleton.mp eq).symm⟩
  let F := (gaps G C).biUnion id
  have fs : F ⊆ C := by
    intro v hv
    obtain ⟨e,eg,ve⟩ := mem_biUnion.mp hv
    exact (mem_powersetCard.mp (mem_filter.mp eg).1).1 ve
  have two : F.card≤2 := by
    have := footprint G C
    change (gaps G C).card≤1 at gap
    change F.card ≤ 2*(gaps G C).card at this
    omega
  obtain ⟨P,fp,pc,pn⟩ := exists_subsuperset_card_eq fs two (by omega : 2≤C.card)
  let R := C \ P
  let M := s \ C
  have cover : P∪R=C := union_sdiff_of_subset pc
  have pm : C∪M=s := union_sdiff_of_subset cs
  obtain ⟨y,yd,yn⟩ := Stratum35.ear G t h q
  have ys : G.neighborFinset y ⊆ s := by
    intro v hv
    refine mem_sdiff.mpr ⟨yn hv,?_⟩
    intro mem
    obtain rfl := mem_singleton.mp mem
    have yc := (G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp hv).symm
    have := BlockFibers.neighbor_degree G v yc
    omega
  letI : Nonempty V := ⟨x⟩
  obtain ⟨p,ch⟩ := CliqueChoice.choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  have old := LowerProfiles.saturated_profiles G ch t (by simp [h]) 34 (by decide) q.ge fail
  rw [h] at old
  have prof : p.image (G.degree ·) ∈ profiles := by
    unfold LowerProfiles.residual at old
    simp only [profiles,mem_insert,mem_singleton]
    tauto
  apply (not_lt_of_ge (exact_block G (x:=x) (y:=y) (P:=P) (R:=R) (M:=M) ?_ ch prof t h)) fail
  refine ⟨xh,degree,yd,cover,cover ▸ pm,disjoint_left.mpr (fun _ hp hr => (mem_sdiff.mp hr).2 hp),
    cover ▸ disjoint_left.mpr (fun _ hc hm => (mem_sdiff.mp hm).2 hc),pn,?_,?_,?_,?_⟩
  · dsimp only [R]; rw [card_sdiff pc,nc,pn]
  · dsimp only [M]; rw [card_sdiff cs,sz,nc]
  · rw [cover,pm]; exact ys
  · intro z zr w wc ne
    by_contra no
    have missing := pair_gap G (cover ▸ wc) (mem_sdiff.mp zr).1 ne no
    have zf : z ∈ F := mem_biUnion.mpr ⟨{w,z},missing,mem_insert_of_mem (mem_singleton_self _)⟩
    exact (mem_sdiff.mp zr).2 (fp zf)

end Graffiti384b.Six
#print axioms Graffiti384b.Six.exact_six
