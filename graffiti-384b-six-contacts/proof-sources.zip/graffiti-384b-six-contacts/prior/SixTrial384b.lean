import ThreeRegion384b
import StratumTrial35_384b

namespace Graffiti384b.Six
open Finset SimpleGraph ThreeRegion BlockActivation LowSample
open private FiniteRange.bad from FiniteRange384b
open private LowSample.eligible LowSample.anchors LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The two possibly nonadjacent endpoints form P. Each vertex of R sees
every other vertex of the center's neighborhood. -/
structure Configuration (x y : V) (P R M : Finset V) : Prop where
  center : x ∈ high G
  deg : G.degree x=6
  ear : G.degree y=2
  inner : P ∪ R=G.neighborFinset x
  cover : P ∪ R ∪ M=high G \ {x}
  split : Disjoint P R
  dis : Disjoint (P∪R) M
  pcard : P.card=2
  rcard : R.card=4
  mcard : M.card=26
  inside : G.neighborFinset y ⊆ P∪R∪M
  edges : ∀ z ∈ R, ∀ w ∈ P∪R, w≠z → G.Adj w z

private theorem ready {x y : V} {P R M : Finset V} (D : Configuration G x y P R M)
    {i j : ℕ} (shape : j=2 ∨ (i=2 ∧ j=0)) {z : Trial V} (row : z ∈ box P R M i j) :
    Ready G (P∪R) (z.1∪z.2.1) := by
  obtain ⟨px,rr⟩ := mem_product.mp row
  obtain ⟨ry,_⟩ := mem_product.mp rr
  obtain ⟨xp,sx⟩ := mem_powersetCard.mp px
  obtain ⟨yr,sy⟩ := mem_powersetCard.mp ry
  have size := card_union_of_disjoint (D.split.mono xp yr)
  rw [sx,sy] at size
  constructor
  · omega
  intro v vc out
  rcases shape with jr | ⟨ip,_⟩
  · have inc : z.2.1 ⊆ (z.1∪z.2.1).filter (G.Adj v) := fun w wh =>
      mem_filter.mpr ⟨mem_union_right _ wh,D.edges w (yr wh) v vc (fun eq => out (eq ▸ mem_union_right _ wh))⟩
    have := card_le_card inc
    change 2 ≤ ((z.1∪z.2.1).filter (G.Adj v)).card
    omega
  · have eq := eq_of_subset_of_card_le xp (by rw [D.pcard,sx,ip])
    have vr : v ∈ R := (mem_union.mp vc).resolve_left (fun vp => out (mem_union_left _ (eq ▸ vp)))
    have inc : z.1 ⊆ (z.1∪z.2.1).filter (G.Adj v) := fun w wh => mem_filter.mpr
      ⟨mem_union_left _ wh,(D.edges v vr w (mem_union_left _ (xp wh)) (fun e => out (e ▸ mem_union_left _ wh))).symm⟩
    have := card_le_card inc
    change 2 ≤ ((z.1∪z.2.1).filter (G.Adj v)).card
    omega

theorem balance {x y : V} {P R M : Finset V} (D : Configuration G x y P R M)
    (t : (types G).card=35) (fail : bound G<gamma G)
    {i j : ℕ} (shape : (i=0 ∧ j=2) ∨ (i=1 ∧ j=2) ∨ (i=2 ∧ j=0)) :
    (7-(i+j))*(box P R M i j).card ≤ missed G P R M y i j +
      ∑ v ∈ M, badMass G P R M (high G \ {x}) v i j := by
  classical
  let s := high G \ {x}
  have cover : P∪R∪M=s := D.cover
  let rows := box P R M i j
  have inner : P∪R ⊆ s := cover ▸ subset_union_left
  have sizeS : s.card=32 := by rw [← cover,card_union_of_disjoint D.dis,card_union_of_disjoint D.split,D.pcard,D.rcard,D.mcard]
  have Ylow : y ∈ twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,D.ear.ge⟩,
    fun mem => by have := (mem_filter.mp mem).2; have := D.ear; omega⟩
  have yn : G.neighborFinset y ⊆ s := cover ▸ D.inside
  have anchorsEq : LowSample.anchors G y=G.neighborFinset y := by
    ext w
    exact ⟨fun h => (G.mem_neighborFinset _ _).mpr (mem_filter.mp h).2,fun h =>
      mem_filter.mpr ⟨(mem_sdiff.mp (yn h)).1,(G.mem_neighborFinset _ _).mp h⟩⟩
  have per (z : Trial V) (row : z ∈ rows) :
      (7-(i+j) ≤ (if nbr G y (pick z)<2 then 1 else 0)+(FiniteRange.bad G s (pick z)).card) ∧
       FiniteRange.bad G s (pick z) ⊆ M := by
    let k := pick z
    obtain ⟨px,rr⟩ := mem_product.mp row
    obtain ⟨ry,my⟩ := mem_product.mp rr
    obtain ⟨xp,sx⟩ := mem_powersetCard.mp px
    obtain ⟨yr,sy⟩ := mem_powersetCard.mp ry
    obtain ⟨wm,sw⟩ := mem_powersetCard.mp my
    have KS : k ⊆ s := by rw [← cover,union_assoc]; exact union_subset_union xp (union_subset_union yr wm)
    have part := union_subset_union xp yr
    have keep : z.1∪z.2.1 ⊆ k := by dsimp [k,pick]; rw [← union_assoc]; exact subset_union_left
    have sz : k.card=i+j+10 := by
      dsimp [k,pick]; rw [← union_assoc,card_union_of_disjoint (D.dis.mono part wm),
        card_union_of_disjoint (D.split.mono xp yr),sx,sy,sw]
    have active := ready G D (by omega : j=2 ∨ i=2 ∧ j=0) row
    have protect (v : V) (vc : v ∈ P∪R) (out : v ∉ k) : 2 ≤ nbr G v k :=
      (active.2 v vc (fun mem => out (keep mem))).trans (card_le_card (filter_subset_filter _ keep))
    have xhit : 2 ≤ nbr G x k := active.1.trans (card_le_card (fun w wh =>
      mem_filter.mpr ⟨keep wh,(G.mem_neighborFinset _ _).mp (D.inner ▸ part wh)⟩))
    have bound := BlockTrial.trial G {x} k {x} (singleton_subset_iff.mpr D.center) KS Subset.rfl
      (fun w hw => (mem_singleton.mp hw) ▸ (D.inner ▸ inner.trans sdiff_subset))
      (fun w hw => (mem_singleton.mp hw) ▸ xhit) (fun w hw v edge out =>
        protect v (D.inner ▸ (G.mem_neighborFinset _ _).mpr ((mem_singleton.mp hw) ▸ edge)) out) fail
    dsimp only at bound
    rw [t,sz,card_singleton,sizeS] at bound
    have earned : 6*(if 2 ≤ nbr G y k then 1 else 0) ≤ ∑ v ∈ LowSample.eligible G k, LowSample.weight (LowSample.anchors G v).card := by
      split_ifs with hit
      · have sub : k.filter (G.Adj y) ⊆ G.neighborFinset y := fun w hw => (G.mem_neighborFinset _ _).mpr (mem_filter.mp hw).2
        have eq := eq_of_subset_of_card_le sub (by rw [card_neighborFinset_eq_degree,D.ear]; exact hit)
        have mem : y ∈ LowSample.eligible G k := mem_filter.mpr ⟨Ylow,by rw [anchorsEq,← eq]; exact filter_subset _ _⟩
        have val := single_le_sum (f := fun v => LowSample.weight (LowSample.anchors G v).card) (fun _ _ => Nat.zero_le _) mem
        change LowSample.weight (LowSample.anchors G y).card ≤ _ at val
        rw [anchorsEq,card_neighborFinset_eq_degree,D.ear] at val
        exact val
      · simp
    constructor
    · change 7-(i+j) ≤ (if nbr G y k<2 then 1 else 0)+(FiniteRange.bad G s k).card
      change 6*(32-(i+j+10))+_+6*1 ≤ 6*(17+(FiniteRange.bad G s k).card) at bound
      split_ifs at earned ⊢ <;> omega
    · intro v vb
      obtain ⟨outside,few⟩ := mem_filter.mp vb
      have vs := (mem_sdiff.mp outside).1
      rw [← cover] at vs
      exact (mem_union.mp vs).resolve_left (fun vc => (not_le_of_gt few)
        ((protect v vc (mem_sdiff.mp outside).2).trans (card_le_card (filter_subset_filter _ subset_union_right))))
  have tr := sum_le_sum (s := rows) (fun z hz => (per z hz).1)
  have swap : (∑ z ∈ rows, (FiniteRange.bad G s (pick z)).card) = ∑ v ∈ M, badMass G P R M s v i j := by
    calc
      _ = ∑ z ∈ rows, ∑ v ∈ M, (if v ∈ FiniteRange.bad G s (pick z) then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro z hz
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr (per z hz).2]
      _ = _ := by rw [sum_comm]; simp [badMass,rows]
  simp only [sum_const,nsmul_eq_mul,Nat.cast_id,sum_add_distrib,sum_boole,swap,Nat.mul_comm (rows.card)] at tr
  exact tr

end Graffiti384b.Six
#print axioms Graffiti384b.Six.balance
