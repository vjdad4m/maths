import UnifiedSample384b
import Boundary384b

namespace Graffiti384b.SmallScores35
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private Repair.triangles_le_choose from Repair384b
open private LowSample.delta LowSample.weight from LowSample384b
open private FiniteRange.count_bad FiniteRange.bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def top (h : ℕ) := if h=33 then 2 else 5
def deadline (h : ℕ) := if h=33 then 6 else 8
def size (h : ℕ) (f : Finset ℕ) := if h=33 ∧ f={3} then 12 else 13
def limit (h : ℕ) (f : Finset ℕ) (j : ℕ) :=
  let n := slots f j Boundary.levels
  min (h-f.card) (h+n-(if j≤deadline h ∧ top h<n then 1 else 0)-35-(f.filter (·≤j)).card)

private def Row (h : ℕ) (f : Finset ℕ) : Prop :=
  let m := h-f.card
  let b := size h f
  12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧
    6*(17*m.choose b+UnifiedSample.chargeAt m b (limit h f)) <
      6*(m-b)*m.choose b+(34-h)*(6*(m-2).choose (b-2))+6*(∑ d ∈ f,bonus m b d)

set_option maxRecDepth 32768 in
set_option maxHeartbeats 12000000 in
private theorem rows : ∀ h ∈ ({33,34} : Finset ℕ), ∀ f ∈ Boundary.levels.powerset, Row h f := by
  unfold Row size limit deadline top UnifiedSample.chargeAt envelope reward LowSample.delta LowSample.weight bonus slots Boundary.levels FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

private theorem allowed {p : Finset V} (ch : Choice G p Boundary.levels) {v : V} {j : ℕ}
    (big : 3 ≤ j) (small : G.degree v ≤ j) :
    trianglesAt G v < slots (p.image (G.degree ·)) j Boundary.levels := by
  have cap := Repair.triangles_le_choose G v
  have mono := Nat.choose_le_choose 2 small
  unfold slots
  split_ifs with no
  · by_cases eq : G.degree v=j
    · have gap : trianglesAt G v ≠ (G.degree v).choose 2 :=
        fun sat => no.2 (eq ▸ ch.covers v (eq ▸ no.1) sat)
      omega
    · have mono' := Nat.choose_le_choose 2 (show G.degree v ≤ j-1 by omega)
      have rec := Nat.choose_succ_succ' (j-1) 1
      rw [show j-1+1=j by omega,Nat.choose_one_right] at rec
      change j.choose 2 = _ + _ at rec
      norm_num at rec
      omega
  · omega

private theorem distribution {p : Finset V} (ch : Choice G p Boundary.levels) (t : (types G).card=35)
    {z : ℕ} (small : z ≤ top (high G).card)
    (hole : ∀ v, G.degree v ≤ deadline (high G).card → trianglesAt G v ≠ z) (j : ℕ) (big : 3 ≤ j) :
    ((high G \ p).filter (fun v => G.degree v ≤ j)).card ≤ limit (high G).card (p.image (G.degree ·)) j := by
  let h := (high G).card
  let f := p.image (G.degree ·)
  let s := high G \ p
  let a := (high G).filter (fun v => G.degree v ≤ j)
  let c := p.filter (fun v => G.degree v ≤ j)
  let n := slots f j Boundary.levels
  have sz : s.card=h-f.card := by dsimp [s,h,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  have prof := CliqueChoice.profile G ch j big
  dsimp only at prof
  rw [t] at prof
  change (s.filter _).card+35+(f.filter (·≤j)).card ≤ h+n at prof
  apply le_min ((card_filter_le _ _).trans_eq sz)
  change (s.filter (fun v => G.degree v ≤ j)).card ≤ h+n-(if j≤deadline h ∧ top h<n then 1 else 0)-35-(f.filter (·≤j)).card
  split_ifs with cut
  · have sub : types G ⊆ ((high G \ a).image (trianglesAt G)) ∪ (range n).erase z := by
      intro u hu
      obtain ⟨v,_,rfl⟩ := mem_image.mp hu
      by_cases dv : G.degree v ≤ j
      · exact mem_union_right _ (mem_erase.mpr ⟨hole v (dv.trans cut.1),mem_range.mpr (allowed G ch big dv)⟩)
      · exact mem_union_left _ (mem_image.mpr ⟨v,mem_sdiff.mpr
          ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,fun mem => dv (mem_filter.mp mem).2⟩,rfl⟩)
    have count := (card_le_card sub).trans (card_union_le _ _)
    rw [card_erase_of_mem (mem_range.mpr (small.trans_lt cut.2)),card_range,t] at count
    have total := card_sdiff_add_card_eq_card (filter_subset (fun v => G.degree v ≤ j) (high G))
    have img := card_image_le (s := high G \ a) (f := trianglesAt G)
    have ci : c ⊆ a := fun v hv => mem_filter.mpr ⟨ch.high_sub (mem_filter.mp hv).1,(mem_filter.mp hv).2⟩
    have eq : s.filter (fun v => G.degree v ≤ j) = a \ c := by ext v; simp only [s,a,c,mem_filter,mem_sdiff]; tauto
    have im : c.image (G.degree ·)=f.filter (·≤j) := by ext d; simp [c,f]; aesop
    have cc : c.card=(f.filter (·≤j)).card := by
      rw [← im,card_image_of_injOn (ch.unique.mono (show (c : Set V) ⊆ p from filter_subset _ _))]
    have diff := card_sdiff_add_card_eq_card ci
    change (high G \ a).card+a.card=h at total
    rw [eq]; omega
  · omega

/-- Every count in the small prefix must have a low-degree representative. -/
theorem realized (t : (types G).card=35) (q : 34 ≤ (nonleaves G).card) (fail : bound G < gamma G)
    (z : ℕ) (lo : z ≤ top (high G).card) : ∃ v, G.degree v ≤ deadline (high G).card ∧ trianglesAt G v=z := by
  let h := (high G).card
  have base := type_bound G
  have miss : ((high G).card+1)/2 < ((types G).card+1)/2 :=
    Nat.lt_of_not_ge (fun le => (not_lt_of_ge (exact_of_high G le)) fail)
  have hh : h ∈ ({33,34} : Finset ℕ) := by simp only [mem_insert,mem_singleton]; dsimp [h]; omega
  letI : Nonempty V := by obtain ⟨v,_⟩ := card_pos.mp (show 0<(high G).card by omega); exact ⟨v⟩
  obtain ⟨p,ch⟩ := choose_from G Boundary.levels (fun _ hd => (mem_Icc.mp hd).1)
  let f := p.image (G.degree ·)
  let m := h-f.card
  let b := size h f
  have sz : (high G \ p).card=m := by dsimp [m,h,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  obtain ⟨room,two,env,rew,win⟩ := rows h hh f (mem_powerset.mpr ch.levels)
  change 12 ≤ m at room
  by_contra! hole
  have obs := UnifiedSample.extraObstruction G ch b (limit h f) (fun j _ pos => distribution G ch t lo hole j pos)
    (fun _ => 0) (by intro v hv; rw [Nat.add_zero]; exact FiniteRange.count_bad G _ b _ v hv (min_le_left _ _) (by omega))
    two (sz ▸ env) (sz ▸ rew) fail
  dsimp only at obs
  simp only [sum_const_zero,Nat.mul_zero,Nat.add_zero,t] at obs
  change 6*(m-b)*m.choose b+(twos G).card*(6*(m-2).choose (b-2))+6*(∑ d ∈ f,bonus m b d) ≤
    6*(17*m.choose b+UnifiedSample.chargeAt m b (limit h f)) at obs
  change 6*(17*m.choose b+UnifiedSample.chargeAt m b (limit h f)) <
    6*(m-b)*m.choose b+(34-h)*(6*(m-2).choose (b-2))+6*(∑ d ∈ f,bonus m b d) at win
  have sub : high G ⊆ nonleaves G := fun v hv => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count : (twos G).card+h=(nonleaves G).card := card_sdiff_add_card_eq_card sub
  have le := Nat.mul_le_mul_right (6*(m-2).choose (b-2)) (show 34-h ≤ (twos G).card by omega)
  omega

/-- At every original order, a missing count among zero, one and two
settles the 35-type case outright. -/
theorem exact_of_missing (hc : G.Connected) (hn : 2 < Fintype.card V) (t : (types G).card=35)
    {z : ℕ} (small : z ≤ 2) (absent : z ∉ types G) : gamma G ≤ bound G := by
  by_contra! bad
  obtain ⟨r,_,cap,_,_,same,_⟩ := Prune.prune_failure G hc hn bad
  have num : (types (G.induce (r : Set V))).card ≤ r.card := by
    simpa [types] using (card_image_le (s := (univ : Finset r)) (f := trianglesAt (G.induce (r : Set V))))
  rw [same,t] at num
  have top2 : 2 ≤ top (high G).card := by unfold top; split_ifs <;> decide
  obtain ⟨v,_,score⟩ := realized G t (by omega) bad z (small.trans top2)
  exact absent (mem_image.mpr ⟨v,mem_univ _,score⟩)

end Graffiti384b.SmallScores35
#print axioms Graffiti384b.SmallScores35.realized
#print axioms Graffiti384b.SmallScores35.exact_of_missing
