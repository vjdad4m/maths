import StratumTrial35_384b
import StratumLoss35_384b

namespace Graffiti384b.Stratum35
set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
open Finset SimpleGraph BlockGeometry BlockActivation RankTable RankPair RankMass RankVertex LowSample
open private FiniteRange.bad from FiniteRange384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem ear (t : (types G).card=35) (h : (high G).card=33) (q : (nonleaves G).card=34) :
    ∃ y, G.degree y=2 ∧ G.neighborFinset y ⊆ high G := by
  obtain ⟨_,highScores,_,one⟩ := Repair.maximal_diversity G (by omega)
  obtain ⟨y,_,ey⟩ := mem_image.mp one
  obtain ⟨a,b,ya,yb,ab⟩ := (TrianglePrune.triangle_iff G y).mp (by omega)
  have two {v a b : V} (va : G.Adj v a) (vb : G.Adj v b) (ne : a≠b) : 2 ≤ G.degree v := by
    have sub : ({a,b} : Finset V) ⊆ G.neighborFinset v := insert_subset ((G.mem_neighborFinset _ _).mpr va)
      (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr vb))
    simpa only [card_pair ne,card_neighborFinset_eq_degree] using card_le_card sub
  have low : y ∉ high G := fun mem => by have := highScores y mem; omega
  have dy : G.degree y=2 := by
    have := two ya yb ab.ne
    have lt : ¬3 ≤ G.degree y := fun d => low (mem_filter.mpr ⟨mem_univ _,d⟩)
    omega
  have sub : high G ⊆ nonleaves G := fun v hv => mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have count := card_sdiff_add_card_eq_card sub
  have singleton : (twos G).card=1 := by unfold twos; omega
  have yl : y ∈ twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,dy.ge⟩,low⟩
  have highN {v : V} (ne : v≠y) (d : 2 ≤ G.degree v) : v ∈ high G := by
    by_contra out
    have vl : v ∈ twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,d⟩,out⟩
    exact ne ((card_le_one.mp singleton.le) v vl y yl)
  have pair : ({a,b} : Finset V) = G.neighborFinset y := eq_of_subset_of_card_le
    (insert_subset ((G.mem_neighborFinset _ _).mpr ya) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr yb)))
    (by rw [card_neighborFinset_eq_degree,dy,card_pair ab.ne])
  refine ⟨y,dy,?_⟩
  rw [← pair]
  exact insert_subset (highN ya.ne.symm (two ya.symm ab yb.ne)) (singleton_subset_iff.mpr (highN yb.ne.symm (two yb.symm ab.symm ya.ne)))

private theorem enough_income {i f d : ℕ} (total : i+f=d) (cap : f+16343800 ≤ d) : 16343800 ≤ i := by omega

private theorem finish_numbers {center ear loss : ℕ}
    (c : 101331560 ≤ center) (e : 16343800 ≤ ear) (l : loss ≤ 341679260)
    (bound : 114406600*19 + center + ear ≤ 114406600*17 + loss) : False := by omega

omit [Fintype V] [DecidableEq V] in
private theorem count_rows (C M : Finset V) (nC : C.card=7) (nM : M.card=25) :
    (opts C M 3).card=114406600 := by
  change (C.powersetCard 3 ×ˢ M.powersetCard 10).card=_
  simp only [card_product,card_powersetCard,nC,nM,Nat.choose_eq_fast_choose]
  decide

private theorem center_income (C M : Finset V) (nC : C.card=7) (nM : M.card=25)
    (gap : (gaps G C).card ≤ 2) :
    101331560 ≤ ∑ z ∈ opts C M 3, (if Ready G C z.1 then 1 else 0 : ℕ) := by
  let rows := opts C M 3
  have cnt := local_bound G C 2 3 gap
  rw [nC] at cnt
  change 31 ≤ _ at cnt
  rw [Finset.sum_boole]
  have eq : rows.filter (fun z => Ready G C z.1) = ((C.powersetCard 3).filter (Ready G C)) ×ˢ M.powersetCard 10 := by
    ext z
    simp [rows,opts,and_assoc,and_left_comm]
    tauto
  rw [eq,card_product,card_powersetCard,nM]
  have ways : Nat.choose 25 10 = 3268760 := by rw [Nat.choose_eq_fast_choose]; decide
  rw [ways]
  exact Nat.mul_le_mul_right 3268760 cnt

private theorem ear_income (C M : Finset V) (nC : C.card=7) (nM : M.card=25)
    (dis : Disjoint C M) {y : V} (yn : G.neighborFinset y ⊆ C ∪ M) (y2 : G.degree y=2) :
    16343800 ≤ ∑ z ∈ opts C M 3, (if 2 ≤ nbr G y (draw z) then 1 else 0 : ℕ) := by
  rw [Finset.sum_boole]
  change _ ≤ RankPair.income G C M 3 y
  have val := income_eq G C M dis yn 3 (by decide) (by decide)
  rw [nC,nM,y2] at val
  have k := card_le_card (show G.neighborFinset y ∩ C ⊆ G.neighborFinset y from inter_subset_left)
  rw [card_neighborFinset_eq_degree,y2] at k
  have tab : ∀ i : Fin 3, few 7 25 3 2 i+16343800 ≤ mass 7 25 3 := by
    unfold mass few RankStrata.counts
    simp only [Nat.choose_eq_fast_choose]
    decide
  have z := tab ⟨(G.neighborFinset y ∩ C).card,by omega⟩
  change few 7 25 3 2 (G.neighborFinset y ∩ C).card + 16343800 ≤ mass 7 25 3 at z
  exact enough_income val z

/-- A fixed 3+10 split clears the degree-seven row on which every supported
uniform sample size misses the omission threshold. -/
theorem exact_seven (ch : CliqueChoice.Choice G ∅ Boundary.levels) (t : (types G).card=35)
    (h : (high G).card=33) (q : (nonleaves G).card=34) (x : V) (d : G.degree x=7)
    (gap : (gaps G (G.neighborFinset x)).card ≤ 2) : gamma G ≤ bound G := by
  classical
  by_contra! fail
  let C := G.neighborFinset x
  let s := high G \ {x}
  let M := s \ C
  have xh : x ∈ high G := mem_filter.mpr ⟨mem_univ _,by omega⟩
  have nC : C.card=7 := (card_neighborFinset_eq_degree _ _).trans d
  have cs : C ⊆ s := by
    intro z zc
    have g := BlockFibers.neighbor_degree G x zc
    exact mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,
      fun mem => ((G.mem_neighborFinset x z).mp zc).ne (mem_singleton.mp mem).symm⟩
  have nM : M.card=25 := by
    dsimp only [M,s]
    rw [card_sdiff cs,card_sdiff (singleton_subset_iff.mpr xh),card_singleton,h,nC]
  have cover : C ∪ M=s := union_sdiff_of_subset cs
  have dis : Disjoint C M := disjoint_left.mpr (fun _ hc hm => (mem_sdiff.mp hm).2 hc)
  obtain ⟨y,y2,highN⟩ := ear G t h q
  have yn : G.neighborFinset y ⊆ s := by
    intro z zn
    refine mem_sdiff.mpr ⟨highN zn,?_⟩
    intro hx
    obtain rfl := mem_singleton.mp hx
    have yc := (G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp zn).symm
    have := BlockFibers.neighbor_degree G z yc
    omega
  let rows := opts C M 3
  have den := count_rows C M nC nM
  change rows.card=114406600 at den
  have both (z) (hz : z ∈ rows) := point G xh y2 C M rfl cs gap rfl yn nC nM t fail z hz
  have add := sum_le_sum (fun z hz => (both z hz).1)
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,den] at add
  have ctr := center_income G C M nC nM gap
  have earIncome := ear_income G C M nC nM dis (cover ▸ yn) y2
  have eq : (∑ z ∈ rows, (FiniteRange.bad G (C ∪ M) (draw z)).card) = ∑ v ∈ M, badFiber G C M 3 v := by
    calc
      _ = ∑ z ∈ rows, ∑ v ∈ M, (if v ∈ FiniteRange.bad G (C ∪ M) (draw z) then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro z hz
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter,inter_eq_right.mpr (both z hz).2]
      _ = _ := by rw [sum_comm]; simp [rows,opts,badFiber,draw]
  have upper := exterior G ch t h d C M nC nM dis sdiff_subset
  rw [eq] at add
  exact finish_numbers ctr earIncome upper add

end Graffiti384b.Stratum35
#print axioms Graffiti384b.Stratum35.exact_seven
