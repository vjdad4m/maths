import Order36_384b

namespace Graffiti384b.Stratum35
set_option maxRecDepth 32768
set_option maxHeartbeats 2000000
open Finset SimpleGraph RankStrata RankWitness RankVertex RankTable BlockGeometry
open private FiniteRange.bad from FiniteRange384b
open private BlockFinish.active_thresholds from BlockFinish384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Exact maxima over the possible inner-neighbor counts at degrees 3 to 9. -/
def cost (d : ℕ) := ([0,0,0,43207710,29980860,19903260,12471030,7390240,4229940,2285140] : List ℕ)[d]?.getD 0
private theorem cost_bound : ∀ d : Fin 10, 3 ≤ d.val → ∀ k : Fin 8, k.val ≤ d.val →
    few 7 24 3 d k ≤ cost d := by
  unfold few counts cost
  simp only [Nat.choose_eq_fast_choose]
  decide
def delta (j : ℕ) := if 3 ≤ j then cost j-cost (j+1) else 0

private theorem numbers :
    (∀ a : Fin 10, 3 ≤ a.val → cost a ≤ cost 9 +
      ∑ j ∈ range 9, if a.val ≤ j then delta j else 0) ∧
    25*cost 9 + ∑ j ∈ range 9, delta j * min 25 (BlockFinish.slotsAfter 33 ∅ 7 j) = 341679260 := by
  unfold delta cost BlockFinish.slotsAfter CliqueChoice.slots Boundary.levels
  simp only [Nat.choose_eq_fast_choose]
  decide

private theorem one_loss (C M : Finset V) (cs : C.card=7) (ms : M.card=25)
    (dis : Disjoint C M) {x : V} (outside : M ⊆ high G \ {x}) :
    ∀ v ∈ M, badFiber G C M 3 v ≤ cost (min (G.degree v) 9) := by
  let a (v : V) := min (G.degree v) 9
  have limits (v : V) (vm : v ∈ M) : 3 ≤ a v ∧ a v ≤ 9 := by
    have := (mem_filter.mp (mem_sdiff.mp (outside vm)).1).2
    dsimp [a]; omega
  have loss (v : V) (vm : v ∈ M) : badFiber G C M 3 v ≤ cost (a v) := by
    obtain ⟨g,ng,gd⟩ := exists_subset_card_eq (show a v ≤ (G.neighborFinset v).card by
      rw [card_neighborFinset_eq_degree]; exact min_le_left _ _)
    have room : g.card < M.card := by rw [gd,ms]; have := limits v vm; omega
    obtain ⟨T,ts,tc,cmp⟩ := surrogate G C M g vm dis ng room
    have raw := stratum_loss G C M (g ∩ C) T vm inter_subset_right ts (by decide : 1 ≤ 3) (by decide : 1 ≤ 10) cmp
    rw [tc,gd,cs,ms] at raw
    have k1 := card_le_card (show g ∩ C ⊆ g from inter_subset_left)
    have k2 := card_le_card (show g ∩ C ⊆ C from inter_subset_right)
    have lim := limits v vm
    have kD : (g ∩ C).card ≤ a v := k1.trans_eq gd
    have kC : (g ∩ C).card < 8 := Nat.lt_succ_of_le (k2.trans_eq cs)
    exact raw.trans (cost_bound ⟨a v,Nat.lt_succ_of_le lim.2⟩ lim.1 ⟨(g ∩ C).card,kC⟩ kD)
  exact loss

private theorem degree_counts {x : V} (ch : CliqueChoice.Choice G ∅ Boundary.levels) (t : (types G).card=35)
    (h : (high G).card=33) (deg : G.degree x=7) (M : Finset V) (ms : M.card=25)
    (outside : M ⊆ high G \ {x}) (j : ℕ) (jj : j ∈ range 9) :
      (∑ v ∈ M, if min (G.degree v) 9 ≤ j then delta j else 0) ≤
        delta j * min 25 (BlockFinish.slotsAfter 33 ∅ 7 j) := by
  by_cases pos : 3 ≤ j
  · rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    apply Nat.mul_le_mul_left
    apply le_min ((card_filter_le _ _).trans_eq ms)
    have xh : x ∈ high G := mem_filter.mpr ⟨mem_univ _,by omega⟩
    have profile := BlockFinish.active_thresholds G ch (mem_sdiff.mpr ⟨xh,by simp⟩) t j pos
    simp only [image_empty,insert_empty_eq,h,deg] at profile
    apply le_trans (card_le_card ?_) profile
    intro v hv
    obtain ⟨vm,small⟩ := mem_filter.mp hv
    have : j < 9 := mem_range.mp jj
    refine mem_filter.mpr ⟨outside vm,?_⟩
    change min (G.degree v) 9 ≤ j at small
    omega
  · simp [delta,pos]

theorem exterior {x : V} (ch : CliqueChoice.Choice G ∅ Boundary.levels) (t : (types G).card=35)
    (h : (high G).card=33) (deg : G.degree x=7) (C M : Finset V)
    (cs : C.card=7) (ms : M.card=25) (dis : Disjoint C M) (outside : M ⊆ high G \ {x}) :
    ∑ v ∈ M, badFiber G C M 3 v ≤ 341679260 := by
  let a (v : V) := min (G.degree v) 9
  have loss := one_loss G C M cs ms dis outside
  obtain ⟨env,tab⟩ := numbers
  have row (v : V) (vm : v ∈ M) : badFiber G C M 3 v ≤ cost 9 +
      ∑ j ∈ range 9, if a v ≤ j then delta j else 0 := by
    have hi : a v ≤ 9 := min_le_right _ _
    have lo : 3 ≤ a v := le_min (mem_filter.mp (mem_sdiff.mp (outside vm)).1).2 (by decide)
    exact (loss v vm).trans (env ⟨a v,Nat.lt_succ_of_le hi⟩ lo)
  have charges := degree_counts G ch t h deg M ms outside
  have total := sum_le_sum row
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,ms] at total
  rw [sum_comm (s := M) (t := range 9)] at total
  rw [← tab]
  apply total.trans
  apply Nat.add_le_add_left
  exact sum_le_sum charges

end Graffiti384b.Stratum35
#print axioms Graffiti384b.Stratum35.exterior
