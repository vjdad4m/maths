import RankPair384b
import BlockFibers384b

namespace Graffiti384b.Stratum35
open Finset SimpleGraph BlockGeometry BlockActivation RankPair LowSample
open private BlockActivation.star_inj from BlockActivation384b
open private FiniteRange.bad from FiniteRange384b
open private LowSample.eligible LowSample.anchors LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

private theorem one_hit {C X : Finset V} (xs : X ⊆ C) (big : (gaps G C).card < X.card)
    {v : V} (vc : v ∈ C) (out : v ∉ X) : ∃ w ∈ X, G.Adj v w := by
  by_contra! no
  have sub : X.image (fun w => ({v,w} : Finset V)) ⊆ gaps G C := by
    intro e he
    obtain ⟨w,wx,rfl⟩ := mem_image.mp he
    exact pair_gap G vc (xs wx) (fun eq => out (eq ▸ wx)) (no w wx)
  have size := card_le_card sub
  rw [card_image_of_injOn (BlockActivation.star_inj v X out)] at size
  omega

/-- Three retained neighbors suffice to clear the entire inner stratum
with the center retained. On a ready triple we can omit the center as well. -/
theorem point {x y : V} (xh : x ∈ high G) (y2 : G.degree y=2)
    (C M : Finset V) (Ceq : C=G.neighborFinset x) (cs : C ⊆ high G \ {x})
    (miss : (gaps G C).card ≤ 2) (Meq : M=(high G \ {x}) \ C)
    (yn : G.neighborFinset y ⊆ high G \ {x}) (xs : C.card=7) (ms : M.card=25)
    (t : (types G).card=35) (fail : bound G < gamma G)
    (z : Finset V × Finset V) (hz : z ∈ opts C M 3) :
    let k := draw z
    19 + (if Ready G C z.1 then 1 else 0) + (if 2 ≤ nbr G y k then 1 else 0) ≤
      17 + (FiniteRange.bad G (C ∪ M) k).card ∧ FiniteRange.bad G (C ∪ M) k ⊆ M := by
  classical
  let s := high G \ {x}
  let k := draw z
  have cover : C ∪ M = s := by rw [Meq]; exact union_sdiff_of_subset cs
  have dis : Disjoint C M := by rw [Meq]; exact disjoint_left.mpr (fun _ hc hm => (mem_sdiff.mp hm).2 hc)
  obtain ⟨xc,xj⟩ := mem_powersetCard.mp (mem_product.mp hz).1
  obtain ⟨ym,ymb⟩ := mem_powersetCard.mp (mem_product.mp hz).2
  have ks : k ⊆ s := cover ▸ union_subset_union xc ym
  have kc : k.card=13 := by
    dsimp [k,draw]; rw [card_union_of_disjoint (dis.mono xc ym),xj,ymb]
  have sc : s.card=32 := by rw [← cover,card_union_of_disjoint dis,xs,ms]
  have inner : z.1 ⊆ k := subset_union_left
  let A : Finset V := if Ready G C z.1 then {x} else ∅
  have pin : A ⊆ {x} := by dsimp [A]; split_ifs <;> simp
  have ac : A.card = (if Ready G C z.1 then 1 else 0) := by dsimp [A]; split_ifs <;> simp
  have check {w : V} (wa : w ∈ A) : Ready G C z.1 ∧ w=x := by
    dsimp [A] at wa
    split_ifs at wa with good
    · exact ⟨good,mem_singleton.mp wa⟩
    · simp at wa
  have xhit : 2 ≤ nbr G x k := by
    have sub : z.1 ⊆ k.filter (G.Adj x) := fun w hw => mem_filter.mpr
      ⟨inner hw,(G.mem_neighborFinset _ _).mp (Ceq ▸ xc hw)⟩
    exact (show 2 ≤ z.1.card by omega).trans (card_le_card sub)
  have bound := BlockTrial.trial G {x} k A (singleton_subset_iff.mpr xh) ks pin
    (fun w hw => (mem_singleton.mp hw) ▸ (Ceq ▸ cs.trans sdiff_subset))
    (fun w hw => (check hw).2 ▸ xhit) (by
      intro w wa v adj out
      obtain ⟨ready,rfl⟩ := check wa
      exact (ready.2 v (Ceq ▸ (G.mem_neighborFinset _ _).mpr adj) (fun mem => out (inner mem))).trans
        (card_le_card (filter_subset_filter _ inner))) fail
  dsimp only at bound
  rw [t,kc,ac,show (high G \ {x}).card=32 from sc] at bound
  have ylow : y ∈ twos G := mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,
    fun mem => by have := (mem_filter.mp mem).2; omega⟩
  have anchorsEq : LowSample.anchors G y=G.neighborFinset y := by
    ext v
    exact ⟨fun mem => (G.mem_neighborFinset _ _).mpr (mem_filter.mp mem).2,fun mem =>
      mem_filter.mpr ⟨(mem_sdiff.mp (yn mem)).1,(G.mem_neighborFinset _ _).mp mem⟩⟩
  have low : 6*(if 2 ≤ nbr G y k then 1 else 0) ≤ ∑ v ∈ LowSample.eligible G k, LowSample.weight (LowSample.anchors G v).card := by
    split_ifs with hit
    · have sub : k.filter (G.Adj y) ⊆ G.neighborFinset y := fun v hv => (G.mem_neighborFinset _ _).mpr (mem_filter.mp hv).2
      have eq := eq_of_subset_of_card_le sub (by rw [card_neighborFinset_eq_degree,y2]; exact hit)
      have mem : y ∈ LowSample.eligible G k := mem_filter.mpr ⟨ylow, by rw [anchorsEq,← eq]; exact filter_subset _ _⟩
      have val := single_le_sum (f := fun v => LowSample.weight (LowSample.anchors G v).card) (fun _ _ => Nat.zero_le _) mem
      change LowSample.weight (LowSample.anchors G y).card ≤ _ at val
      rw [anchorsEq,card_neighborFinset_eq_degree,y2] at val
      exact val
    · simp
  change _ ∧ _
  constructor
  · rw [cover]
    change 19+(if Ready G C z.1 then 1 else 0)+(if 2 ≤ nbr G y k then 1 else 0) ≤ 17+(FiniteRange.bad G s k).card
    change 6*19 + _ + 6*_ ≤ 6*(17+(FiniteRange.bad G s k).card) at bound
    omega
  · intro v vb
    rw [cover] at vb
    obtain ⟨out,few⟩ := mem_filter.mp vb
    rw [Meq]
    refine mem_sdiff.mpr ⟨(mem_sdiff.mp out).1,?_⟩
    intro vc
    obtain ⟨w,wx,edge⟩ := one_hit G xc (by omega) vc (fun mem => (mem_sdiff.mp out).2 (inner mem))
    have xout : x ∉ s := fun mem => (mem_sdiff.mp mem).2 (mem_singleton_self _)
    have vx : G.Adj v x := ((G.mem_neighborFinset _ _).mp (Ceq ▸ vc)).symm
    have sub : ({x,w} : Finset V) ⊆ (sᶜ ∪ k).filter (G.Adj v) := insert_subset
      (mem_filter.mpr ⟨mem_union_left _ (mem_compl.mpr xout),vx⟩)
      (singleton_subset_iff.mpr (mem_filter.mpr ⟨mem_union_right _ (inner wx),edge⟩))
    have le := card_le_card sub
    have ne : x ≠ w := fun e => xout (e.symm ▸ ks (inner wx))
    rw [card_pair ne] at le
    exact (not_lt_of_ge le) few

end Graffiti384b.Stratum35
#print axioms Graffiti384b.Stratum35.point
