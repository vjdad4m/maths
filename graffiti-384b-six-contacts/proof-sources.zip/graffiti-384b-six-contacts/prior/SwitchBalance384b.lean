import SwitchEstimate384b
import BlockTrial384b

namespace Graffiti384b.Switch35
open Finset SimpleGraph CliqueChoice CliqueSample
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem balance {Q s : Finset V} {x : V} (on : Finset V → Bool)
    (outside : Q⊆sᶜ) (free : x∉Q) (xs : x∉s)
    (cl : ∀ z∈Q, cliqueAt G z) (near : ∀ z∈Q, G.neighborFinset z ⊆ s)
    (activation : ∀ k∈s.powersetCard 12, on k=true → 2≤nbr G x (base s k x (on k)))
    (t : (types G).card=35) (fail : bound G<gamma G) :
    (s.card-12)*s.card.choose 12+(∑ z∈Q,bonus s.card 12 (G.degree z))+
       ((s.powersetCard 12).filter (fun k => on k=true)).card ≤
      17*s.card.choose 12+∑ k∈s.powersetCard 12,(loss G s k x (on k)).card := by
  let rows := s.powersetCard 12
  have each (k : Finset V) (hk : k∈rows) :
      s.card-12+(active G Q k).card+(if on k then 1 else 0) ≤ 17+(loss G s k x (on k)).card := by
    obtain ⟨ks,sz⟩ := mem_powersetCard.mp hk
    rw [←sz]
    apply trial G (on k) ks xs ((filter_subset _ _).trans outside) (fun hm => free (filter_subset _ _ hm))
      (activation k hk) (fun _ hm => (mem_filter.mp hm).2) ?_ t fail
    intro z za v edge vk
    obtain ⟨zQ,n⟩ := mem_filter.mp za
    apply n.trans (card_le_card ?_)
    intro w hw
    obtain ⟨wk,zw⟩ := mem_filter.mp hw
    exact mem_filter.mpr ⟨wk,cl z zQ v w edge zw (fun eq => vk (eq ▸ wk))⟩
  have credit : (∑ z∈Q,bonus s.card 12 (G.degree z)) ≤ ∑ k∈rows,(active G Q k).card := by
    have per (z : V) (hz : z∈Q) := BlockTrial.active_fiber G Q s 12 hz (near z hz) (mem_compl.mp (outside hz))
    calc
      _ ≤ ∑ z∈Q,(rows.filter (fun k => z∈active G Q k)).card := sum_le_sum per
      _ = ∑ z∈Q,∑ k∈rows,(if z∈active G Q k then 1 else 0 : ℕ) := by simp
      _ = _ := by
        rw [sum_comm]
        apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show active G Q k⊆Q from filter_subset _ _)]
  have total := sum_le_sum each
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id,sum_boole] at total
  have den : rows.card=s.card.choose 12 := card_powersetCard _ _
  rw [den,Nat.mul_comm (s.card.choose 12) (s.card-12),Nat.mul_comm (s.card.choose 12) 17] at total
  change (s.card-12)*s.card.choose 12+_+(rows.filter (fun k => on k=true)).card ≤
    17*s.card.choose 12+∑ k∈rows,(loss G s k x (on k)).card
  omega

end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.balance
