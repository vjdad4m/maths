import SwitchShape384b

namespace Graffiti384b.Switch35
open Finset SimpleGraph
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- One edge of a four-neighbor link already contains an outside witness.
Hitting the opposite edge activates the center. -/
theorem four_ear {s A E F : Finset V} {x y : V} (xs : x∉s) (ys : y∉s) (yE : y∈E) (fs : F⊆s)
    (ec : E.card=2) (fc : F.card=2) (near : E∪F=G.neighborFinset x) (an : A⊆G.neighborFinset x) (Asub : A⊆s)
    (pairs : TwoLinks35.pairs G x={E,F}) :
    ∃ on : Finset V → Bool,
      mass s.card 2 ≤ ((s.powersetCard 12).filter (fun k => on k=true)).card ∧
      (∀ k∈s.powersetCard 12, on k=true → 2≤nbr G x (base s k x (on k))) ∧
      (∀ z∈A, ∃ w, G.Adj z w ∧ G.Adj x w ∧ ∀ k∈s.powersetCard 12, z∉k →
        x∈base s k x (on k) ∨ w∈base s k x (on k)) := by
  classical
  let on (k : Finset V) := decide (¬Disjoint k F)
  have eN : E⊆G.neighborFinset x := by rw [←near]; exact subset_union_left
  have fN : F⊆G.neighborFinset x := by rw [←near]; exact subset_union_right
  have xy := (G.mem_neighborFinset _ _).mp (eN yE)
  have yh (k : Finset V) : y∈base s k x (on k) := stays (mem_union_left _ (mem_compl.mpr ys)) xy.ne.symm
  have hit {k : Finset V} (ok : on k=true) := not_disjoint_iff.mp (of_decide_eq_true ok : ¬Disjoint k F)
  refine ⟨on,?_,?_,?_⟩
  · let rows := s.powersetCard 12
    have miss : rows.filter (fun k => ¬on k=true)=rows.filter (fun k => Disjoint k F) := by ext k; simp [on]
    have spl := filter_card_add_filter_neg_card_eq_card (s:=rows) (fun k => on k=true)
    rw [miss] at spl
    have num := empty_hits s F fs
    rw [fc] at num
    change (rows.filter _).card=(s.card-2).choose 12 at num
    rw [num,show rows.card=s.card.choose 12 from card_powersetCard _ _] at spl
    change s.card.choose 12-(s.card-2).choose 12≤(rows.filter _).card
    omega
  · intro k _kr ok
    obtain ⟨w,wk,wF⟩ := hit ok
    have xw := (G.mem_neighborFinset _ _).mp (fN wF)
    exact pair_nbr G xy xw (fun eq => ys (eq ▸ fs wF)) (yh k) (stays (mem_union_right _ wk) xw.ne.symm)
  · intro z za
    have zn : z∈E∪F := near ▸ an za
    obtain ⟨P,zm,pc,pN,pi⟩ : ∃ P : Finset V, z∈P ∧ P.card=2 ∧ P⊆G.neighborFinset x ∧ (P=E ∨ P=F) := by
      rcases mem_union.mp zn with h|h
      · exact ⟨E,h,ec,eN,Or.inl rfl⟩
      · exact ⟨F,h,fc,fN,Or.inr rfl⟩
    obtain ⟨w,wm,wz⟩ := exists_ne_of_one_lt_card (by omega : 1<P.card) z
    have link : P∈Repair.linkEdges G x := by change P∈TwoLinks35.pairs G x; rw [pairs,mem_insert,mem_singleton]; exact pi
    have xw := (G.mem_neighborFinset _ _).mp (pN wm)
    have peq : ({z,w} : Finset V)=P := eq_of_subset_of_card_le (insert_subset zm (singleton_subset_iff.mpr wm))
      (by rw [card_pair wz.symm,pc])
    refine ⟨w,(Repair.edge_info G link).2.2 z zm w wm wz.symm,xw,?_⟩
    intro k _kr zk
    by_cases ok : on k=true
    · right
      obtain ⟨t,tm,tb⟩ : ∃ t∈P, t∈base s k x (on k) := by
        rcases pi with h|h
        · exact ⟨y,h ▸ yE,yh k⟩
        · obtain ⟨a,ak,aF⟩ := hit ok
          have xa := (G.mem_neighborFinset _ _).mp (fN aF)
          exact ⟨a,h ▸ aF,stays (mem_union_right _ ak) xa.ne.symm⟩
      have which : t=z ∨ t=w := by simpa [←peq] using tm
      rcases which with tz|tw
      · have no : t∉sᶜ∪k := by rw [tz]; simpa using And.intro (Asub za) zk
        have hb : t∈sᶜ∪k := by
          change t∈base s k x (on k) at tb
          rw [show on k=true from ok] at tb
          exact erase_subset _ _ tb
        exact (no hb).elim
      · exact tw ▸ tb
    · left
      rw [show on k=false from Bool.eq_false_iff.mpr ok]
      simp [base,xs]
end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.four_ear
