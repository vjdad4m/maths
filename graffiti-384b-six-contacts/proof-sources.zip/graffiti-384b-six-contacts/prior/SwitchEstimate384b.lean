import SwitchTrial384b
import SwitchHits384b
import BlockLoss384b
import BoundaryFiber384b

namespace Graffiti384b.Switch35
open Finset SimpleGraph CliqueChoice CliqueSample
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.delta from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def upper (p j : ℕ) :=
  if j=6 then 14 else if j=7 ∧ p=0 then 19 else j.choose 2+(if j=3 ∧ p=1 then 1 else 0)

def cap (p j : ℕ) := min (32-p) (((Ico 3 (upper p j)) \ (if p=1 then {3} else ∅)).card)
def alpha (m : ℕ) := if m=31 then 2116296 else 4291378
def eta (m : ℕ) := if m=31 then 1352078 else 2704156
def theta (m : ℕ) := if m=31 then 1469650 else 2939300

private theorem local_table {m : ℕ} (ok : m=31 ∨ m=32) : BlockLoss.envelope m 12 ∧
    ∀ j : Fin 10, 3≤j.val →
      (m+1-j.val).choose 12+alpha m≤FiniteRange.badCount m 12 j.val ∧
      (m-j.val).choose 12+eta m+theta m≤FiniteRange.badCount m 12 j.val ∧
      alpha m+eta m≤FiniteRange.badCount m 12 j.val := by
  rcases ok with rfl|rfl <;> unfold BlockLoss.envelope LowSample.delta FiniteRange.badCount alpha eta theta <;>
    simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose] <;> decide

def earMass (m a : ℕ) := if a=2 then 0 else (m-2).choose 10
def income (p a : ℕ) := earMass (32-p) a + p*(bonus (32-p) 12 3)

theorem table {p a : ℕ} (hp : p=0 ∨ p=1) (ha : a=2 ∨ a=3 ∨ a=4) :
    let m := 32-p
    17*m.choose 12 + BlockLoss.chargeAt m 12 (cap p) <
      (m-12)*m.choose 12 + income p a + mass m a + a*alpha m + 3*p*eta m+
      (if a=3 then p else 0)*theta m := by
  rcases hp with rfl|rfl <;> rcases ha with rfl|rfl|rfl <;>
    unfold income earMass bonus mass cap upper BlockLoss.chargeAt LowSample.delta alpha eta theta FiniteRange.badCount <;>
    simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose] <;> decide

/-- Supplying the graph's two local groups, their activation count and its
rank bounds suffices to contradict failure. -/
theorem estimate {s A C : Finset V} {x : V} (p a : ℕ) (on : Finset V → Bool)
    (ps : p=0 ∨ p=1) (acases : a=2 ∨ a=3 ∨ a=4)
    (size : s.card=32-p) (asize : a≤A.card) (csize : C.card=3*p)
    (separate : (if a=3 then p else 0)≤(C\A).card)
    (hi : s⊆high G) (near : A=G.neighborFinset x ∩ s) (cs : C⊆s)
    (fixed : ∀ z ∈ C, ∃ y, y∉s ∧ y≠x ∧ ¬G.Adj x y ∧ G.Adj z y)
    (partners : ∀ z ∈ A, ∃ w, G.Adj z w ∧ G.Adj x w ∧ ∀ k ∈ s.powersetCard 12, z∉k →
      x∈base s k x (on k) ∨ w∈base s k x (on k))
    (dist : ∀ j ∈ range 9, 3≤j → (s.filter (fun v => G.degree v≤j)).card ≤ cap p j)
    (balance : (s.card-12)*s.card.choose 12+income p a+mass s.card a ≤
      17*s.card.choose 12+∑ k ∈ s.powersetCard 12,(loss G s k x (on k)).card) : False := by
  classical
  let m := s.card
  have ms : m=31 ∨ m=32 := by dsimp [m]; omega
  let rows := s.powersetCard 12
  let fiber (z : V) := (rows.filter (fun k => z∈loss G s k x (on k))).card
  let credit (z : V) := (if z∈A then alpha m else 0)+(if z∈C then eta m else 0)+(if z∈C\A then theta m else 0)
  have subA : A⊆s := near ▸ inter_subset_right
  have data := local_table ms
  have refund (z : V) (zs : z ∈ s) : fiber z+credit z≤FiniteRange.badCount m 12 (min (G.degree z) 9) := by
    let d := min (G.degree z) 9
    have h3 := (mem_filter.mp (hi zs)).2
    have dl : 3≤d := le_min h3 (by decide)
    have du : d≤9 := min_le_right _ _
    have deg : d≤G.degree z := min_le_left _ _
    have nums := data.2 ⟨d,by omega⟩ dl
    dsimp only at nums
    by_cases za : z∈A
    · have zx := ((G.mem_neighborFinset _ _).mp (mem_inter.mp (near ▸ za)).1).symm
      obtain ⟨w,zw,xw,g⟩ := partners z za
      by_cases zc : z∈C
      · obtain ⟨y,ys,yx,no,zy⟩ := fixed z zc
        have zero : fiber z=0 := by
          apply card_eq_zero.mpr (filter_eq_empty_iff.mpr ?_)
          intro k kr bad
          obtain ⟨zk,sm⟩ := mem_filter.mp bad
          have ky := stays (on:=on k) (mem_union_left k (mem_compl.mpr ys)) yx
          rcases g k kr (mem_sdiff.mp zk).2 with h|h
          · exact (not_lt_of_ge (pair_nbr G zy zx yx ky h)) sm
          · exact (not_lt_of_ge (pair_nbr G zy zw (fun e => no (e ▸ xw)) ky h)) sm
        rw [zero,Nat.zero_add]
        simpa [credit,za,zc] using nums.2.2
      · have cut := partner_loss G on zs zx zw xw.ne.symm deg (by omega) g
        change fiber z≤(m+1-d).choose 12 at cut
        simpa [credit,za,zc] using (Nat.add_le_add_right cut (alpha m)).trans nums.1
    · have no : ¬G.Adj z x := fun e => za (near ▸ mem_inter.mpr ⟨(G.mem_neighborFinset _ _).mpr e.symm,zs⟩)
      by_cases zc : z∈C
      · obtain ⟨y,ys,_,_,zy⟩ := fixed z zc
        have sub : rows.filter (fun k => z∈loss G s k x (on k)) ⊆ rows.filter (fun k => z∈FiniteRange.bad G s k) := by
          intro k h
          obtain ⟨r,b⟩ := mem_filter.mp h
          obtain ⟨zk,sm⟩ := mem_filter.mp b
          refine mem_filter.mpr ⟨r,mem_filter.mpr ⟨zk,lt_of_le_of_lt (card_le_card ?_) sm⟩⟩
          intro y ym
          obtain ⟨yb,zy⟩ := mem_filter.mp ym
          exact mem_filter.mpr ⟨stays yb (fun eq => no (eq ▸ zy)),zy⟩
        have bound := (card_le_card sub).trans (BoundaryFiber.count G s 12 d zs ys zy deg (by omega))
        change fiber z ≤ (m-d).choose 12 at bound
        change fiber z+credit z≤FiniteRange.badCount m 12 d
        simp [credit,za,zc]
        omega
      · simpa [credit,za,zc,fiber,rows,m] using ordinary G on no zs deg (by change d<m; omega)
  have point (z : V) (zs : z∈s) : fiber z+credit z ≤ FiniteRange.badCount m 12 9 +
      ∑ j ∈ range 9, if G.degree z≤j then LowSample.delta m 12 j else 0 := by
    have raw := refund z zs
    by_cases small : G.degree z≤9
    · rw [min_eq_left small] at raw
      exact raw.trans (data.1 ⟨G.degree z,by omega⟩ (mem_filter.mp (hi zs)).2)
    · rw [min_eq_right (by omega)] at raw
      exact raw.trans (Nat.le_add_right ..)
  have step (j : ℕ) (jj : j∈range 9) : (∑ z∈s,if G.degree z≤j then LowSample.delta m 12 j else 0) ≤
      LowSample.delta m 12 j*cap p j := by
    rw [← sum_filter,sum_const,nsmul_eq_mul,Nat.mul_comm]
    by_cases h : 3≤j
    · exact Nat.mul_le_mul_left _ (dist j jj h)
    · simp [LowSample.delta,h]
  have sumH := sum_le_sum point
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,Nat.cast_id] at sumH
  rw [sum_comm (s:=s) (t:=range 9)] at sumH
  have total : (∑ z∈s,fiber z)+(∑ z∈s,credit z) ≤ BlockLoss.chargeAt m 12 (cap p) :=
    sumH.trans (Nat.add_le_add_left (sum_le_sum step) _)
  have swap : (∑ k∈rows,(loss G s k x (on k)).card)=∑ z∈s,fiber z := by
    calc
      _ = ∑ k∈rows,∑ z∈s,(if z∈loss G s k x (on k) then 1 else 0 : ℕ) := by
        apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show loss G s k x (on k)⊆s from (filter_subset _ _).trans sdiff_subset)]
      _ = _ := by rw [sum_comm]; simp [fiber]
  have amount : (∑ z∈s,credit z)=A.card*alpha m+(3*p)*eta m+(C\A).card*theta m := by
    simp only [credit,sum_add_distrib,←sum_filter,sum_const,nsmul_eq_mul,Nat.cast_id,filter_mem_eq_inter]
    rw [inter_eq_right.mpr subA,inter_eq_right.mpr cs,inter_eq_right.mpr (sdiff_subset.trans cs),csize]
  have da := Nat.mul_le_mul_right (alpha m) asize
  have ex := Nat.mul_le_mul_right (theta m) separate
  have win := table ps acases
  dsimp only at win
  rw [←size] at win
  change (m-12)*m.choose 12+income p a+mass m a ≤ 17*m.choose 12+∑ k∈rows,(loss G s k x (on k)).card at balance
  rw [swap] at balance
  rw [amount] at total
  change 17*m.choose 12+BlockLoss.chargeAt m 12 (cap p)<(m-12)*m.choose 12+income p a+mass m a+a*alpha m+3*p*eta m+
    (if a=3 then p else 0)*theta m at win
  omega

end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.table
#print axioms Graffiti384b.Switch35.estimate
