import RankStrata384b

namespace Graffiti384b.Switch35
open Finset
variable {V : Type*} [DecidableEq V]

def cube (A k : Finset V) : Bool := decide (2≤(k∩A).card+(3-A.card))
def four (e f k : Finset V) : Bool := decide (¬Disjoint k e ∧ ¬Disjoint k f)
def mass (m a : ℕ) :=
  if a=2 then m.choose 12-(m-2).choose 12
  else if a=3 then m.choose 12-((m-3).choose 12+3*(m-3).choose 11)
  else m.choose 12+(m-4).choose 12-2*(m-2).choose 12

theorem empty_hits (s A : Finset V) (sub : A⊆s) :
    ((s.powersetCard 12).filter (fun k => Disjoint k A)).card=(s.card-A.card).choose 12 := by
  have eq : (s.powersetCard 12).filter (fun k => Disjoint k A)=(s\A).powersetCard 12 := by
    ext k; simp only [mem_filter,mem_powersetCard,subset_sdiff]; tauto
  rw [eq,card_powersetCard,card_sdiff sub]

theorem cube_mass (s A : Finset V) (sa : A⊆s) (size : A.card=2 ∨ A.card=3) :
    mass s.card A.card ≤ ((s.powersetCard 12).filter (fun k => cube A k=true)).card := by
  let rows := s.powersetCard 12
  let miss := rows.filter (fun k => ¬cube A k=true)
  have spl := filter_card_add_filter_neg_card_eq_card (s:=rows) (fun k => cube A k=true)
  change _+miss.card=rows.card at spl
  have den : rows.card=s.card.choose 12 := card_powersetCard _ _
  have zero := RankStrata.hits s A sa (by decide : 0≤12)
  have one := RankStrata.hits s A sa (by decide : 1≤12)
  rcases size with a|a
  · have eq : miss = rows.filter (fun k => (k∩A).card=0) := by
      ext k; simp [miss,cube,a]
    rw [a] at zero ⊢
    simp only [show (2:ℕ).choose 0=1 by decide, show (3:ℕ).choose 0=1 by decide, one_mul,Nat.sub_zero] at zero
    change (rows.filter _).card=_ at zero
    rw [eq,zero] at spl
    change s.card.choose 12-(s.card-2).choose 12 ≤ (rows.filter (fun k => cube A k=true)).card
    omega
  · let E := rows.filter fun k => (k∩A).card=0
    let F := rows.filter fun k => (k∩A).card=1
    have sub : miss ⊆ E∪F := by
      intro k hk
      obtain ⟨r,no⟩ := mem_filter.mp hk
      have le : (k∩A).card<2 := by simpa [cube,a] using no
      rcases (show (k∩A).card=0 ∨ (k∩A).card=1 by omega) with z|z
      · exact mem_union_left _ (mem_filter.mpr ⟨r,z⟩)
      · exact mem_union_right _ (mem_filter.mpr ⟨r,z⟩)
    have num := (card_le_card sub).trans (card_union_le E F)
    rw [a] at zero one ⊢
    simp only [show (2:ℕ).choose 0=1 by decide, show (3:ℕ).choose 0=1 by decide, one_mul,Nat.sub_zero] at zero
    change E.card=(s.card-3).choose 12 at zero
    simp only [show (3:ℕ).choose 1=3 by decide] at one
    change F.card=3*(s.card-3).choose 11 at one
    rw [zero,one] at num
    change s.card.choose 12-((s.card-3).choose 12+3*(s.card-3).choose 11)≤(rows.filter (fun k => cube A k=true)).card
    omega

theorem four_mass (s e f : Finset V) (es : e ⊆ s) (fs : f⊆s) (ec : e.card=2) (fc : f.card=2)
    (dis : Disjoint e f) : mass s.card 4 ≤ ((s.powersetCard 12).filter (fun k => four e f k=true)).card := by
  let rows := s.powersetCard 12
  let E := rows.filter fun k => Disjoint k e
  let F := rows.filter fun k => Disjoint k f
  have eq : E∩F=rows.filter (fun k => Disjoint k (e∪f)) := by
    ext k; simp only [E,F,mem_filter,mem_inter,disjoint_union_right]; tauto
  have miss : rows.filter (fun k => ¬four e f k=true)=E∪F := by
    ext k; simp only [E,F,mem_filter,mem_union,four,decide_eq_true_eq]; tauto
  have num := card_union_add_card_inter E F
  have cs := card_union_of_disjoint dis
  rw [ec,fc] at cs
  have a := empty_hits s e es
  have b := empty_hits s f fs
  have c := empty_hits s (e∪f) (union_subset es fs)
  rw [ec] at a
  rw [fc] at b
  rw [cs] at c
  change E.card=_ at a
  change F.card=_ at b
  rw [a,b,eq,c] at num
  have spl := filter_card_add_filter_neg_card_eq_card (s:=rows) (fun k => four e f k=true)
  rw [miss] at spl
  change (E∪F).card+(s.card-4).choose 12=(s.card-2).choose 12+(s.card-2).choose 12 at num
  have den : rows.card=s.card.choose 12 := card_powersetCard _ _
  change s.card.choose 12+(s.card-4).choose 12-2*(s.card-2).choose 12 ≤ (rows.filter (fun k => four e f k=true)).card
  rw [den] at spl
  omega

end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.cube_mass
#print axioms Graffiti384b.Switch35.four_mass
