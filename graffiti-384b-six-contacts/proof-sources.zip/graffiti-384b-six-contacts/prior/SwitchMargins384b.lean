import SwitchEstimate384b

namespace Graffiti384b.Switch35

/-- Summed excess over seventeen omissions with the weakest neighborhood
and rank credits permitted in the corresponding branch. -/
def margin (p a : ℕ) :=
  let m := 32-p
  (m-12)*m.choose 12+income p a+mass m a+a*alpha m+3*p*eta m+(if a=3 then p else 0)*theta m-
    (17*m.choose 12+BlockLoss.chargeAt m 12 (cap p))

open private LowSample.delta from LowSample384b
theorem margins :
    [margin 0 2,margin 0 3,margin 0 4,margin 1 2,margin 1 3,margin 1 4]=
      [36348895,1490708,18905196,20207036,874632,9957563] := by
  unfold margin income earMass CliqueSample.bonus mass cap upper BlockLoss.chargeAt LowSample.delta alpha eta theta FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.margins
