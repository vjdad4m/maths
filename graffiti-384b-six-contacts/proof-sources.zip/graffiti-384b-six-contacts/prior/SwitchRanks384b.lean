import SwitchEstimate384b
import Pivotal35_384b

namespace Graffiti384b.Switch35
open Finset SimpleGraph CliqueChoice
open private SmallScores35.allowed from SmallScores35_384b
open private Repair.triangles_le_choose from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem ranks {p s : Finset V} {x : V} (t : (types G).card=35) (h : (high G).card=33) (q : (nonleaves G).card=34)
    (inj : Function.Injective (trianglesAt G)) (fail : bound G<gamma G)
    (ch : Choice G p Boundary.levels) (deg : ∀ z∈p,G.degree z=3) (zeroOne : p.card=0 ∨ p.card=1)
    (pool : s=(high G \ p).erase x) (sz : s.card=32-p.card) (sx : trianglesAt G x=2) :
    ∀ j∈range 9, 3≤j → (s.filter (fun v => G.degree v≤j)).card ≤ cap p.card j := by
  obtain ⟨_,pos,_,_⟩ := Repair.maximal_diversity G (show (types G).card=(high G).card+2 by omega)
  intro j jj lo
  have top := mem_range.mp jj
  let r := s.filter (fun v => G.degree v≤j)
  have inc : r.image (trianglesAt G) ⊆ Ico 3 (upper p.card j) \ (if p.card=1 then {3} else ∅) := by
    intro z hz
    obtain ⟨v,vr,rfl⟩ := mem_image.mp hz
    obtain ⟨vs,vd⟩ := mem_filter.mp vr
    have vm := mem_erase.mp (pool ▸ vs)
    have vp := mem_sdiff.mp vm.2
    have lower := pos v vp.1
    have strict : trianglesAt G v≠2 := fun eq => vm.1 (inj (eq.trans sx.symm))
    refine mem_sdiff.mpr ⟨mem_Ico.mpr ⟨by omega,?_⟩,?_⟩
    · unfold upper
      split_ifs with six seven three
      · subst j
        by_cases d : G.degree v=6
        · have gaps := BlockGeometry.gap_count G v
          rw [d] at gaps
          change _+trianglesAt G v=15 at gaps
          by_contra! large
          exact (not_lt_of_ge (Six.exact_six G t h q v d (by omega))) fail
        · have cap := (Repair.triangles_le_choose G v).trans (Nat.choose_le_choose 2 (show G.degree v≤5 by omega))
          change trianglesAt G v≤10 at cap; omega
      · obtain ⟨rfl,empty⟩ := seven
        by_cases d : G.degree v=7
        · have uns (z : V) (mem : G.degree z∈Boundary.levels) : trianglesAt G z≠(G.degree z).choose 2 := by
            intro sat
            have hit := ch.covers z mem sat
            rw [card_eq_zero.mp empty] at hit
            simp at hit
          have gaps := BlockGeometry.gap_count G v
          rw [d] at gaps
          change _+trianglesAt G v=21 at gaps
          by_contra! large
          exact (not_lt_of_ge (Least35.exact_degree_seven G t h q uns v d (by omega))) fail
        · have cap := (Repair.triangles_le_choose G v).trans (Nat.choose_le_choose 2 (show G.degree v≤6 by omega))
          change trianglesAt G v≤15 at cap; omega
      · exact Nat.lt_succ_of_le ((Repair.triangles_le_choose G v).trans (Nat.choose_le_choose 2 vd))
      · have old := SmallScores35.allowed G ch lo vd
        have not_in : j ∉ p.image (G.degree ·) := by
          intro mem
          obtain ⟨u,up,uj⟩ := mem_image.mp mem
          have eq := deg u up
          have pos := card_pos.mpr (show p.Nonempty from ⟨u,up⟩)
          exact three ⟨by omega,by omega⟩
        have test : j∈Boundary.levels := mem_Icc.mpr ⟨lo,by omega⟩
        simpa [slots,test,not_in] using old
    · split_ifs with one
      · obtain ⟨u,up⟩ := card_pos.mp (by omega : 0<p.card)
        have ex := ch.exact_score _ up
        rw [deg _ up] at ex
        change trianglesAt G u=3 at ex
        intro three
        exact vp.2 ((inj ((mem_singleton.mp three).trans ex.symm)) ▸ up)
      · exact not_mem_empty _
  have num := card_le_card inc
  rw [card_image_of_injective _ inj] at num
  exact le_min ((card_filter_le _ _).trans_eq sz) num

end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.ranks
