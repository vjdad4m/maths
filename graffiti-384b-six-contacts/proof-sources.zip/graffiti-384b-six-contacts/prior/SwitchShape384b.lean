import SwitchTrial384b
import SwitchHits384b
import TwoLinks35_384b

namespace Graffiti384b.Switch35
open Finset SimpleGraph
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def rule (A e f k : Finset V) : Bool := if Disjoint e f then four e f k else cube A k

theorem shape {s A e f : Finset V} {x : V} (near : A=G.neighborFinset x ∩ s)
    (xs : x∉s) (neigh : e∪f=G.neighborFinset x) (tw : e.card=2 ∧ f.card=2)
    (pairs : TwoLinks35.pairs G x={e,f}) (deg : G.degree x=(if Disjoint e f then 4 else 3))
    (casesA : Disjoint e f → A=G.neighborFinset x) (ac : A.card=2 ∨ A.card=3 ∨ A.card=4) :
    let on := rule A e f
    (mass s.card A.card ≤ ((s.powersetCard 12).filter (fun k => on k=true)).card) ∧
    (∀ k ∈ s.powersetCard 12, on k=true → 2≤nbr G x (base s k x (on k))) ∧
    (∀ z ∈ A, ∃ w, G.Adj z w ∧ G.Adj x w ∧ ∀ k ∈ s.powersetCard 12, z∉k →
      x∈base s k x (on k) ∨ w∈base s k x (on k)) := by
  classical
  let N := G.neighborFinset x
  let on := rule A e f
  have an : A⊆N := near ▸ inter_subset_left
  have as' : A⊆s := near ▸ inter_subset_right
  have en : e⊆N := by change e⊆G.neighborFinset x; rw [←neigh]; exact subset_union_left
  have fn' : f⊆N := by change f⊆G.neighborFinset x; rw [←neigh]; exact subset_union_right
  have ec := tw.1
  have fc := tw.2
  have nc : N.card=(if Disjoint e f then 4 else 3) := (card_neighborFinset_eq_degree ..).trans deg
  have acap := card_le_card an
  have ns : N\s=N\A := by rw [near]; ext z; simp only [N,mem_sdiff,mem_inter]; tauto
  have diff : (N\s).card=N.card-A.card := by rw [ns,card_sdiff an]
  have es (dis : Disjoint e f) : e⊆s := en.trans (show N⊆s from by change G.neighborFinset x⊆s; rw [←casesA dis]; exact as')
  have fs (dis : Disjoint e f) : f⊆s := fn'.trans (show N⊆s from by change G.neighborFinset x⊆s; rw [←casesA dis]; exact as')
  have both (dis : Disjoint e f) {k : Finset V} (yes : on k=true) :
      ¬Disjoint k e ∧ ¬Disjoint k f := by simpa [on,rule,four,dis] using yes
  have base_vertices {k : Finset V} (_kr : k∈s.powersetCard 12) :
      (k∩A)∪(N\s) ⊆ (base s k x (on k)).filter (G.Adj x) := by
    intro z h
    obtain ⟨zn,inB⟩ : z∈N ∧ z∈sᶜ∪k := by
      rcases mem_union.mp h with h|h
      · exact ⟨an (mem_inter.mp h).2,mem_union_right _ (mem_inter.mp h).1⟩
      · exact ⟨(mem_sdiff.mp h).1,mem_union_left _ (mem_compl.mpr (mem_sdiff.mp h).2)⟩
    have edge := (G.mem_neighborFinset _ _).mp zn
    exact mem_filter.mpr ⟨stays inB edge.ne.symm,edge⟩
  have enough (dis : ¬Disjoint e f) {k : Finset V} (_kr : k∈s.powersetCard 12) (yes : on k=true) :
      2≤((k∩A)∪(N\s)).card := by
    have n3 : N.card=3 := by simpa [dis] using nc
    have sep : Disjoint (k∩A) (N\s) := disjoint_left.mpr (fun _ h g =>
      (mem_sdiff.mp g).2 (as' (mem_inter.mp h).2))
    rw [card_union_of_disjoint sep,diff,n3]
    simpa [on,rule,cube,dis] using yes
  refine ⟨?_,?_,?_⟩
  · by_cases dis : Disjoint e f
    · have a4 : A.card=4 := by rw [casesA dis,card_neighborFinset_eq_degree,deg,if_pos dis]
      simpa only [on,rule,if_pos dis,a4] using four_mass s e f (es dis) (fs dis) ec fc dis
    · have d3 : N.card=3 := by simpa [dis] using nc
      simpa only [on,rule,if_neg dis] using cube_mass s A as' (by omega)
  · intro k kr yes
    by_cases dis : Disjoint e f
    · obtain ⟨le,lf⟩ := both dis yes
      obtain ⟨u,uk,ue⟩ := not_disjoint_iff.mp le
      obtain ⟨v,vk,vf⟩ := not_disjoint_iff.mp lf
      have xu := (G.mem_neighborFinset _ _).mp (en ue)
      have xv := (G.mem_neighborFinset _ _).mp (fn' vf)
      exact pair_nbr G xu xv (fun eq => disjoint_left.mp dis (eq ▸ ue) vf)
        (stays (mem_union_right _ uk) xu.ne.symm) (stays (mem_union_right _ vk) xv.ne.symm)
    · exact (enough dis kr yes).trans (card_le_card (base_vertices kr))
  · intro z za
    have zn : z∈e∪f := neigh ▸ an za
    obtain ⟨P,zP,pc,pn,pi⟩ : ∃ P : Finset V, z∈P ∧ P.card=2 ∧ P⊆N ∧ (P=e ∨ P=f) := by
      rcases mem_union.mp zn with h|h
      · exact ⟨e,h,ec,en,Or.inl rfl⟩
      · exact ⟨f,h,fc,fn',Or.inr rfl⟩
    obtain ⟨w,wP,wz⟩ := exists_ne_of_one_lt_card (by omega : 1<P.card) z
    have pair : P∈Repair.linkEdges G x := by
      change P∈TwoLinks35.pairs G x
      rw [pairs,mem_insert,mem_singleton]
      exact pi
    have zw := (Repair.edge_info G pair).2.2 z zP w wP wz.symm
    have xw := (G.mem_neighborFinset _ _).mp (pn wP)
    refine ⟨w,zw,xw,?_⟩
    intro k kr nk
    by_cases yes : on k=true
    · right
      by_cases dis : Disjoint e f
      · have hit : ¬Disjoint k P := pi.elim (fun eq => eq ▸ (both dis yes).1) (fun eq => eq ▸ (both dis yes).2)
        obtain ⟨u,uk,up⟩ := not_disjoint_iff.mp hit
        have Peq := eq_of_subset_of_card_le (show ({z,w} : Finset V)⊆P from insert_subset zP (singleton_subset_iff.mpr wP))
          (by rw [card_pair wz.symm,pc])
        have uu : u=z ∨ u=w := by simpa [←Peq] using up
        exact stays (mem_union_right _ ((uu.resolve_left (fun eq => nk (eq ▸ uk))) ▸ uk)) xw.ne.symm
      · have h := enough dis kr yes
        have d3 : N.card=3 := by simpa [dis] using nc
        let B := (k∩A)∪(N\s)
        have inside : B⊆N := union_subset (inter_subset_right.trans an) sdiff_subset
        have zout : z∉B := by
          intro zm
          exact (mem_union.mp zm).elim (fun inK => nk (mem_inter.mp inK).1) (fun no => (mem_sdiff.mp no).2 (as' za))
        have wm : w∈B := by
          apply Classical.byContradiction
          intro out
          have sub : insert w (insert z B) ⊆ N := insert_subset (pn wP) (insert_subset (an za) inside)
          have cap := card_le_card sub
          rw [card_insert_of_not_mem (show w∉insert z B by simp [wz,out]),card_insert_of_not_mem zout] at cap
          change 2≤B.card at h
          omega
        exact (mem_filter.mp (base_vertices kr wm)).1
    · left
      have off : on k=false := Bool.eq_false_iff.mpr yes
      change x∈base s k x (on k)
      rw [off]
      simp [base,xs]
end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.shape
