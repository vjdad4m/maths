import FiniteRange384b

namespace Graffiti384b.Switch35
open Finset SimpleGraph
open private Repair.omit_set from Repair384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def base (s k : Finset V) (x : V) (on : Bool) :=
  if on then (sᶜ ∪ k).erase x else sᶜ ∪ k

def loss (s k : Finset V) (x : V) (on : Bool) :=
  (s \ k).filter fun v => nbr G v (base s k x on) < 2

theorem stays {s k : Finset V} {x z : V} {on : Bool} (h : z ∈ sᶜ ∪ k) (ne : z ≠ x) :
    z ∈ base s k x on := by cases on <;> simp [base,h,ne]

omit [Fintype V] in
theorem pair_nbr {s : Finset V} {z a b : V} (za : G.Adj z a) (zb : G.Adj z b)
    (ne : a≠b) (ha : a∈s) (hb : b∈s) : 2≤nbr G z s := by
  have sub : ({a,b} : Finset V) ⊆ s.filter (G.Adj z) :=
    insert_subset (mem_filter.mpr ⟨ha,za⟩) (singleton_subset_iff.mpr (mem_filter.mpr ⟨hb,zb⟩))
  simpa only [nbr,card_pair ne] using card_le_card sub

theorem trial {s k c : Finset V} {x : V} (on : Bool) (ks : k ⊆ s) (xs : x∉s)
    (cs : c ⊆ sᶜ) (xc : x∉c) (active : on=true → 2≤nbr G x (base s k x on))
    (safe : ∀ v ∈ c, 2≤nbr G v k) (protect : ∀ z ∈ c, ∀ v, G.Adj z v → v ∉ k → 2≤nbr G v k)
    (t : (types G).card=35) (fail : bound G < gamma G) :
    s.card-k.card+c.card+(if on then 1 else 0) ≤ 17+(loss G s k x on).card := by
  classical
  let L := loss G s k x on
  let U := (s \ k) \ L
  let X : Finset V := if on then {x} else ∅
  let O := U∪c∪X
  have us : U ⊆ s := sdiff_subset.trans sdiff_subset
  have uk {z : V} (zu : z∈U) : z∉k := (mem_sdiff.mp (sdiff_subset zu)).2
  have only {z : V} (h : z∈X) : on=true ∧ z=x := by
    cases on
    · simp [X] at h
    · simpa [X] using h
  have keep : k ⊆ Oᶜ := by
    intro z zk
    apply mem_compl.mpr
    intro h
    rcases mem_union.mp h with h|h
    · exact (mem_union.mp h).elim (fun u => uk u zk) (fun m => mem_compl.mp (cs m) (ks zk))
    · exact xs ((only h).2 ▸ ks zk)
  have lift {v : V} (out : v ∉ k) (low : 2≤nbr G v (base s k x on)) : 2≤nbr G v Oᶜ := by
    by_cases h : ∃ z ∈ c, G.Adj z v
    · obtain ⟨z,zc,adj⟩ := h
      exact (protect z zc v adj out).trans (card_le_card (filter_subset_filter _ keep))
    · apply low.trans (card_le_card ?_)
      intro y ym
      obtain ⟨yb,vy⟩ := mem_filter.mp ym
      refine mem_filter.mpr ⟨mem_compl.mpr ?_,vy⟩
      intro yo
      rcases mem_union.mp yo with m|m
      · rcases mem_union.mp m with yu|yc
        · have both : y∈sᶜ ∪ k := by cases on <;> simpa [base] using (show y∈sᶜ∪k from by
                                                    first | exact yb | exact erase_subset _ _ yb)
          exact (mem_union.mp both).elim (fun no => mem_compl.mp no (us yu)) (uk yu)
        · exact h ⟨y,yc,vy.symm⟩
      · obtain ⟨eq,rfl⟩ := only m
        simp [base,eq] at yb
  have good (v : V) (vo : v∈O) : 2≤nbr G v Oᶜ := by
    rcases mem_union.mp vo with m|m
    · rcases mem_union.mp m with u|z
      · apply lift (uk u)
        exact Nat.le_of_not_gt (fun sm => (mem_sdiff.mp u).2 (mem_filter.mpr ⟨sdiff_subset u,sm⟩))
      · exact (safe v z).trans (card_le_card (filter_subset_filter _ keep))
    · obtain ⟨eq,rfl⟩ := only m
      exact lift (fun h => xs (ks h)) (active eq)
  have up := Repair.omit_set G O good
  have sep : Disjoint U c := disjoint_left.mpr (fun _ u z => mem_compl.mp (cs z) (us u))
  have sep' : Disjoint (U∪c) X := by
    apply disjoint_left.mpr
    intro z m q
    obtain ⟨_,rfl⟩ := only q
    exact (mem_union.mp m).elim (fun u => xs (us u)) xc
  have count : O.card=U.card+c.card+X.card := by dsimp only [O]; rw [card_union_of_disjoint sep',card_union_of_disjoint sep]
  have xcount : X.card=(if on then 1 else 0) := by cases on <;> simp [X]
  have split := card_sdiff_add_card_eq_card (show L ⊆ s \ k from filter_subset _ _)
  change U.card+L.card=(s \ k).card at split
  rw [card_sdiff ks] at split
  unfold bound at fail
  rw [t] at fail
  change _ - 18 < _ at fail
  change _ ≤ 17+L.card
  have sz : 35≤Fintype.card V := t ▸ (show (types G).card≤Fintype.card V from card_image_le.trans_eq card_univ)
  omega

theorem ordinary {s : Finset V} {v x : V} (on : Finset V → Bool) (no : ¬G.Adj v x)
    {d : ℕ} (vs : v ∈ s) (de : d≤G.degree v) (room : d<s.card) :
    ((s.powersetCard 12).filter (fun k => v ∈ loss G s k x (on k))).card ≤ FiniteRange.badCount s.card 12 d := by
  apply (card_le_card (t := (s.powersetCard 12).filter (fun k => v∈FiniteRange.bad G s k)) ?_).trans
    (FiniteRange.count_bad G s 12 d v vs de room)
  intro k hk
  obtain ⟨r,b⟩ := mem_filter.mp hk
  obtain ⟨vk,sm⟩ := mem_filter.mp b
  refine mem_filter.mpr ⟨r,mem_filter.mpr ⟨vk,lt_of_le_of_lt (card_le_card ?_) sm⟩⟩
  intro y h
  obtain ⟨yb,vy⟩ := mem_filter.mp h
  exact mem_filter.mpr ⟨stays yb (fun e => no (e ▸ vy)),vy⟩

/-- When a neighbor of the switch is deficient, one of x and its designated
partner is retained. Every other neighbor is absent from the sample base. -/
theorem partner_loss {s : Finset V} {v x w : V} (on : Finset V → Bool) (vs : v∈s)
    (vx : G.Adj v x) (vw : G.Adj v w) (diff : w≠x) {d : ℕ} (de : d≤G.degree v) (two : 2≤d)
    (guarded : ∀ k ∈ s.powersetCard 12, v∉k → x∈base s k x (on k) ∨ w∈base s k x (on k)) :
    ((s.powersetCard 12).filter (fun k => v∈loss G s k x (on k))).card ≤ (s.card+1-d).choose 12 := by
  let rows := (s.powersetCard 12).filter fun k => v∈loss G s k x (on k)
  by_cases ex : rows.Nonempty
  · have avoid {k : Finset V} (rk : k∈rows) {z : V} (vz : G.Adj v z) (zx : z≠x) (zw : z≠w) : z∉sᶜ∪k := by
      obtain ⟨row,h⟩ := mem_filter.mp rk
      obtain ⟨vk,short⟩ := mem_filter.mp h
      intro m
      have keep := stays (on:=on k) m zx
      rcases guarded k row (mem_sdiff.mp vk).2 with h|h
      · exact (not_lt_of_ge (pair_nbr G vz vx zx keep h)) short
      · exact (not_lt_of_ge (pair_nbr G vz vw zw keep h)) short
    let N := (G.neighborFinset v).erase x |>.erase w
    have nmem {z : V} (h : z∈N) : z≠w ∧ z≠x ∧ G.Adj v z := by
      obtain ⟨zw,a⟩ := mem_erase.mp h
      obtain ⟨zx,m⟩ := mem_erase.mp a
      exact ⟨zw,zx,(G.mem_neighborFinset _ _).mp m⟩
    have subN : N ⊆ s.erase v := by
      obtain ⟨k,rk⟩ := ex
      intro z m
      obtain ⟨zw,zx,vz⟩ := nmem m
      refine mem_erase.mpr ⟨vz.ne.symm,Classical.byContradiction (fun no => avoid rk vz zx zw (mem_union_left _ (mem_compl.mpr no)))⟩
    have size : N.card=G.degree v-2 := by
      dsimp only [N]
      rw [card_erase_of_mem (mem_erase.mpr ⟨diff,(G.mem_neighborFinset _ _).mpr vw⟩),card_erase_of_mem ((G.mem_neighborFinset _ _).mpr vx),card_neighborFinset_eq_degree]
      omega
    obtain ⟨A,an,ac⟩ := exists_subset_card_eq (show d-2≤N.card by omega)
    have inc : rows ⊆ ((s.erase v) \ A).powersetCard 12 := by
      intro k rk
      obtain ⟨row,h⟩ := mem_filter.mp rk
      obtain ⟨ks,sz⟩ := mem_powersetCard.mp row
      have no := (mem_sdiff.mp (mem_filter.mp h).1).2
      refine mem_powersetCard.mpr ⟨?_,sz⟩
      intro z zk
      refine mem_sdiff.mpr ⟨mem_erase.mpr ⟨fun eq => no (eq ▸ zk),ks zk⟩,?_⟩
      intro za
      obtain ⟨zw,zx,vz⟩ := nmem (an za)
      exact avoid rk vz zx zw (mem_union_right _ zk)
    have cap := card_le_card inc
    have enough := (card_le_card (an.trans subN))
    rw [card_erase_of_mem vs,ac] at enough
    have pos := card_pos.mpr (show s.Nonempty from ⟨v,vs⟩)
    rw [card_powersetCard,card_sdiff (an.trans subN),card_erase_of_mem vs,ac,show s.card-1-(d-2)=s.card+1-d by omega] at cap
    exact cap
  · exact (show rows.card=0 from card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp ex)) ▸ Nat.zero_le _

end Graffiti384b.Switch35
#print axioms Graffiti384b.Switch35.trial
#print axioms Graffiti384b.Switch35.partner_loss
