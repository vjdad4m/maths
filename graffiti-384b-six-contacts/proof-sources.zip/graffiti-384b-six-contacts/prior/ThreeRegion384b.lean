import RankWitness384b

namespace Graffiti384b.ThreeRegion
open Finset SimpleGraph
open private FiniteRange.bad from FiniteRange384b
variable {V : Type*} [DecidableEq V]

abbrev Trial (V : Type*) := Finset V × (Finset V × Finset V)
def box (P R M : Finset V) (i j : ℕ) : Finset (Trial V) := P.powersetCard i ×ˢ (R.powersetCard j ×ˢ M.powersetCard 10)
def pick (z : Trial V) := z.1 ∪ (z.2.1 ∪ z.2.2)
def count (n a q k : ℕ) := if k≤q then a.choose k*(n-a).choose (q-k) else 0
def few (p r n a b c i j : ℕ) :=
  let x := count p a i 0
  let y := count r b j 0
  let z := count n c 10 0
  x*(y*z) + count p a i 1*(y*z) + x*(count r b j 1*z) + x*(y*count n c 10 1)

private theorem witness_count (s A : Finset V) (as : A ⊆ s) (q k : ℕ) :
    ((s.powersetCard q).filter (fun X => (X ∩ A).card=k)).card = count s.card A.card q k := by
  by_cases le : k≤q
  · simpa only [count,if_pos le] using RankStrata.hits s A as le
  · rw [count,if_neg le,filter_eq_empty_iff.mpr ?_,card_empty]
    intro X x eq
    have a := card_le_card (show X∩A ⊆ X from inter_subset_left)
    have b := (mem_powersetCard.mp x).2
    omega

/-- Upper bound on samples meeting at most one of the marked vertices
across three disjoint regions. This also permits a quota of zero. -/
theorem count_few (P R M A B T : Finset V) (ap : A ⊆ P) (br : B ⊆ R) (tm : T ⊆ M) (i j : ℕ) :
    ((box P R M i j).filter (fun z => (z.1 ∩ A).card+(z.2.1 ∩ B).card+(z.2.2 ∩ T).card ≤ 1)).card ≤
      few P.card R.card M.card A.card B.card T.card i j := by
  let F (s a : Finset V) (q k : ℕ) := (s.powersetCard q).filter (fun X => (X ∩ a).card=k)
  let K (h k l : ℕ) := F P A i h ×ˢ (F R B j k ×ˢ F M T 10 l)
  have inc : (box P R M i j).filter (fun z => (z.1 ∩ A).card+(z.2.1 ∩ B).card+(z.2.2 ∩ T).card ≤ 1) ⊆
      K 0 0 0 ∪ K 1 0 0 ∪ K 0 1 0 ∪ K 0 0 1 := by
    intro z mem
    obtain ⟨hz,num⟩ := mem_filter.mp mem
    obtain ⟨hp,hz'⟩ := mem_product.mp hz
    obtain ⟨hr,hm⟩ := mem_product.mp hz'
    simp only [K,F,mem_union,mem_product,mem_filter,hp,hr,hm,true_and]
    omega
  have bound := (card_le_card inc).trans (card_union_le _ _)
  have add := card_union_le (K 0 0 0 ∪ K 1 0 0) (K 0 1 0)
  have first := card_union_le (K 0 0 0) (K 1 0 0)
  have size (h k l : ℕ) : (K h k l).card=count P.card A.card i h * (count R.card B.card j k * count M.card T.card 10 l) := by
    simp only [K,F,card_product,witness_count P A ap,witness_count R B br,witness_count M T tm]
  dsimp only [few]
  rw [← size 0 0 0,← size 1 0 0,← size 0 1 0,← size 0 0 1]
  omega

variable [Fintype V] (G : SimpleGraph V) [DecidableRel G.Adj]
def badMass (P R M : Finset V) (s : Finset V) (v : V) (i j : ℕ) :=
  ((box P R M i j).filter (fun z => v ∈ FiniteRange.bad G s (pick z))).card
def missed (P R M : Finset V) (y : V) (i j : ℕ) :=
  ((box P R M i j).filter (fun z => nbr G y (pick z)<2)).card

omit [Fintype V] in
private theorem split_hits {P R g X Y : Finset V} (split : Disjoint P R) (xp : X ⊆ P) (yr : Y ⊆ R) :
    (X ∩ (g ∩ P)).card+(Y ∩ (g ∩ R)).card = ((X∪Y) ∩ (g ∩ (P∪R))).card := by
  have subX : X ∩ (g ∩ P) ⊆ P := fun w h => xp (mem_inter.mp h).1
  have subY : Y ∩ (g ∩ R) ⊆ R := fun w h => yr (mem_inter.mp h).1
  rw [← card_union_of_disjoint (split.mono subX subY)]
  congr 1
  ext v
  simp only [mem_union,mem_inter]
  specialize @xp v
  specialize @yr v
  tauto

/-- One marked neighborhood works for every choice of the two inner quotas.
The exterior vertex itself is unavailable in its deficient samples. -/
theorem bad_bound {P R M s g : Finset V} {v : V} (split : Disjoint P R) (dis : Disjoint (P∪R) M)
    (cover : P∪R∪M=s) (vm : v ∈ M) (ng : g ⊆ G.neighborFinset v) (room : g.card<M.card) (i j : ℕ) :
    badMass G P R M s v i j ≤ few P.card R.card (M.card-1) (g∩P).card (g∩R).card
      (g.card-(g∩P).card-(g∩R).card) i j := by
  obtain ⟨T,ts,sz,cmp⟩ := RankWitness.surrogate G (P∪R) M g vm dis ng room
  have count := count_few P R (M.erase v) (g∩P) (g∩R) T inter_subset_right inter_subset_right ts i j
  have cap : (g∩P).card+(g∩R).card=(g∩(P∪R)).card := by
    rw [inter_union_distrib_left,card_union_of_disjoint (split.mono inter_subset_right inter_subset_right)]
  rw [card_erase_of_mem vm,sz,← cap,Nat.sub_add_eq] at count
  apply le_trans (card_le_card ?_) count
  intro z hz
  obtain ⟨row,fail⟩ := mem_filter.mp hz
  obtain ⟨px,other⟩ := mem_product.mp row
  obtain ⟨ry,my⟩ := mem_product.mp other
  obtain ⟨mm,mn⟩ := mem_powersetCard.mp my
  obtain ⟨out,few'⟩ := mem_filter.mp fail
  have ne : v ∉ z.2.2 := fun mem => (mem_sdiff.mp out).2 (mem_union_right _ (mem_union_right _ mem))
  have keep : z.2.2 ⊆ M.erase v := fun w wm => mem_erase.mpr ⟨fun eq => ne (eq ▸ wm),mm wm⟩
  refine mem_filter.mpr ⟨mem_product.mpr ⟨px,mem_product.mpr ⟨ry,mem_powersetCard.mpr ⟨keep,mn⟩⟩⟩,?_⟩
  rw [split_hits split (mem_powersetCard.mp px).1 (mem_powersetCard.mp ry).1]
  have joint := cmp (z.1∪z.2.1) (union_subset_union (mem_powersetCard.mp px).1 (mem_powersetCard.mp ry).1) z.2.2 mm
  rw [cover,union_assoc z.1 z.2.1 z.2.2] at joint
  exact joint.trans (Nat.le_of_lt_succ few')

theorem missed_bound {P R M : Finset V} {y : V} (split : Disjoint P R) (dis : Disjoint (P∪R) M)
    (inside : G.neighborFinset y ⊆ P∪R∪M) (i j : ℕ) :
    let N := G.neighborFinset y
    missed G P R M y i j ≤ few P.card R.card M.card (N∩P).card (N∩R).card
      (G.degree y-(N∩P).card-(N∩R).card) i j := by
  let N := G.neighborFinset y
  have equiv {X Y Z : Finset V} (xp : X ⊆ P) (yr : Y ⊆ R) (zm : Z ⊆ M) :
      (X∩(N∩P)).card+(Y∩(N∩R)).card+(Z∩(N∩M)).card = nbr G y (X∪(Y∪Z)) := by
    rw [split_hits split xp yr]
    have XY := union_subset_union xp yr
    rw [split_hits dis XY zm,union_assoc]
    have eq : (X∪(Y∪Z)) ∩ (N∩(P∪R∪M)) = (X∪(Y∪Z)).filter (G.Adj y) := by
      ext w
      simp only [mem_inter,mem_filter,N,mem_neighborFinset]
      constructor
      · exact fun m => ⟨m.1,m.2.1⟩
      · exact fun m => ⟨m.1,m.2,inside ((G.mem_neighborFinset _ _).mpr m.2)⟩
    rw [eq]; rfl
  have whole : P∪(R∪M)=P∪R∪M := (union_assoc ..).symm
  have sz := equiv (Subset.rfl : P ⊆ P) (Subset.rfl : R ⊆ R) (Subset.rfl : M ⊆ M)
  have full : (P∪(R∪M)).filter (G.Adj y)=N := by
    ext w
    exact ⟨fun h => (G.mem_neighborFinset _ _).mpr (mem_filter.mp h).2,fun h =>
      mem_filter.mpr ⟨whole ▸ inside h,(G.mem_neighborFinset _ _).mp h⟩⟩
  have redo (A : Finset V) : A∩(N∩A)=N∩A := inter_eq_right.mpr inter_subset_right
  simp only [redo,nbr,full,N,card_neighborFinset_eq_degree] at sz
  change (N∩P).card+(N∩R).card+(N∩M).card=G.degree y at sz
  have count := count_few P R M (N∩P) (N∩R) (N∩M) inter_subset_right inter_subset_right inter_subset_right i j
  dsimp only
  rw [show G.degree y-(N∩P).card-(N∩R).card=(N∩M).card by omega]
  apply le_trans (card_le_card ?_) count
  intro z hz
  obtain ⟨row,fail⟩ := mem_filter.mp hz
  have h := mem_product.mp row
  have k := mem_product.mp h.2
  refine mem_filter.mpr ⟨row,?_⟩
  rw [equiv (mem_powersetCard.mp h.1).1 (mem_powersetCard.mp k.1).1 (mem_powersetCard.mp k.2).1]
  exact Nat.le_of_lt_succ fail

end Graffiti384b.ThreeRegion
#print axioms Graffiti384b.ThreeRegion.bad_bound
#print axioms Graffiti384b.ThreeRegion.missed_bound
