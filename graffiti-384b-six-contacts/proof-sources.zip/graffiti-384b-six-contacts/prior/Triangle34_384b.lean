import Path34_384b
import SharedExact34_384b
import EarSquares34_384b
import DisjointCross34_384b
import AnchorScore34_384b

namespace Graffiti384b.Triangle34
open Finset SimpleGraph LowSample
open private LowSample.two_degree from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The two anchors of v have no common neighbor other than v. -/
def uniqueWitness (v : V) : Prop :=
  ∀ x,G.neighborFinset v⊆G.neighborFinset x → x=v

theorem unique_edge {v : V} (d : G.degree v=2) (pos : 0<trianglesAt G v) (only : uniqueWitness G v) :
    ∃ a b,G.neighborFinset v={a,b} ∧ G.Adj a b ∧ G.neighborFinset a∩G.neighborFinset b={v} := by
  obtain ⟨a,b,eq,va,vb,ab⟩ := SharedExact34.ear_pair G d pos
  refine ⟨a,b,eq,ab,Subset.antisymm ?_ (singleton_subset_iff.mpr (mem_inter.mpr
    ⟨(G.mem_neighborFinset _ _).mpr va.symm,(G.mem_neighborFinset _ _).mpr vb.symm⟩))⟩
  intro x xm
  obtain ⟨ax,bx⟩ := mem_inter.mp xm
  apply mem_singleton.mpr (only x ?_)
  rw [eq]
  exact insert_subset ((G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp ax).symm)
    (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr ((G.mem_neighborFinset _ _).mp bx).symm))

theorem one {y : V} (ears : twos G={y}) (q : (types G).card≤(nonleaves G).card)
    (fail : bound G<gamma G) : uniqueWitness G y := by
  intro x sub
  by_contra ne
  have yt : y∈twos G := ears ▸ mem_singleton_self _
  obtain ⟨ok,dis⟩ := EarSquares34.square G yt (fun p => ne p.symm) sub
  apply (not_lt_of_ge (PinnedColor34.complete G dis q ?_ ok.1 ok.2)) fail
  intro v vn _ nq
  by_cases ok : 3≤G.degree v
  · exact ok
  exfalso
  have no : v∉high G := fun vh => ok (mem_filter.mp vh).2
  have vm : v∈twos G := mem_sdiff.mpr ⟨vn,no⟩
  rw [ears,mem_singleton] at vm
  exact nq (mem_insert.mpr (Or.inl vm))

theorem disjoint_of_counts (n : Fintype.card V=34) (t : (types G).card=33) {y z : V} (yz : y≠z)
    (dy : G.degree y=2) (dz : G.degree z=2) (py : 0<trianglesAt G y) (pz : 0<trianglesAt G z)
    (fail : bound G<gamma G) : Disjoint (G.neighborFinset y) (G.neighborFinset z) ∧
      (uniqueWitness G y ∨ uniqueWitness G z) := by
  obtain ⟨q,_,ears,_,_⟩ := SharedExact34.failure_profile G t yz dy dz py pz fail
  have sep := SharedExact34.separate G n t yz dy dz py pz fail
  refine ⟨sep,?_⟩
  by_cases first : uniqueWitness G y
  · exact Or.inl first
  right
  intro w cw
  by_contra wz
  change ¬∀ x,G.neighborFinset y⊆G.neighborFinset x → x=y at first
  push_neg at first
  obtain ⟨x,cx,xy⟩ := first
  exact (not_lt_of_ge (EarSquares34.disjoint_exact G yz ears sep xy.symm (fun p => wz p.symm) cx cw (by omega))) fail

theorem disjoint (res : Minimal.Residual G) (n : Fintype.card V=34) {y z : V}
    (yt : y∈twos G) (zt : z∈twos G) (yz : y≠z) :
    Disjoint (G.neighborFinset y) (G.neighborFinset z) ∧
      (uniqueWitness G y ∨ uniqueWitness G z) := by
  have t := (Frontier34.boundary G res n).2.1
  have pos := (Frontier34.ears G res n).2.1
  exact disjoint_of_counts G n t yz (LowSample.two_degree G yt) (LowSample.two_degree G zt)
    (by have := pos y yt; omega) (by have := pos z zt; omega) res.2.2.1

/-- After choosing one of the two ears, an endpoint a of its anchor edge
ab sees no anchor of the other ear; ab has the ear as its sole common
neighbor. Thus a is a degree-one vertex of the four-anchor subgraph. -/
theorem end_anchor (n : Fintype.card V=34) (t : (types G).card=33) {y z : V} (yz : y≠z)
    (dy : G.degree y=2) (dz : G.degree z=2) (py : 0<trianglesAt G y) (pz : 0<trianglesAt G z)
    (fail : bound G<gamma G) :
    ∃ e f a b,((e=y ∧ f=z) ∨ (e=z ∧ f=y)) ∧ G.neighborFinset e={a,b} ∧
      G.Adj a b ∧ G.neighborFinset a∩G.neighborFinset b={e} ∧
      (∀ j∈G.neighborFinset f,¬G.Adj a j) := by
  obtain ⟨q,_,ears,no,_⟩ := SharedExact34.failure_profile G t yz dy dz py pz fail
  obtain ⟨sep,weak⟩ := disjoint_of_counts G n t yz dy dz py pz fail
  have yt : y∈twos G := ears ▸ mem_insert_self _ _
  have zt : z∈twos G := ears ▸ mem_insert_of_mem (mem_singleton_self _)
  have take (e f : V) (et : e∈twos G) (p : 0<trianglesAt G e) (ef : e≠f)
      (pair : twos G={e,f}) (no : ¬G.Adj e f)
      (apart : Disjoint (G.neighborFinset e) (G.neighborFinset f)) (only : uniqueWitness G e) :
      ∃ a b,G.neighborFinset e={a,b} ∧ G.Adj a b ∧ G.neighborFinset a∩G.neighborFinset b={e} ∧
        (∀ j∈G.neighborFinset f,¬G.Adj a j) := by
    obtain ⟨a,ae,out⟩ := DisjointCross34.isolated G ef pair no apart only (by omega) fail
    obtain ⟨i,j,eq,ij,unique⟩ := unique_edge G (LowSample.two_degree G et) p only
    rw [eq,mem_insert,mem_singleton] at ae
    rcases ae with rfl|rfl
    · exact ⟨_,_,eq,ij,unique,out⟩
    · exact ⟨_,_,eq.trans (pair_comm ..),ij.symm,(inter_comm ..).trans unique,out⟩
  rcases weak with wy|wz
  · obtain ⟨a,b,p⟩ := take y z yt py yz ears no sep wy
    exact ⟨y,z,a,b,Or.inl ⟨rfl,rfl⟩,p⟩
  · obtain ⟨a,b,p⟩ := take z y zt pz yz.symm (ears.trans (pair_comm ..)) (fun h => no h.symm) sep.symm wz
    exact ⟨z,y,a,b,Or.inr ⟨rfl,rfl⟩,p⟩

theorem necessary (res : Minimal.Residual G) (n : Fintype.card V=34) :
    ∃ v∈twos G,∃ a b,G.neighborFinset v={a,b} ∧ G.Adj a b ∧ G.neighborFinset a∩G.neighborFinset b={v} := by
  obtain ⟨q,t,h⟩ := Frontier34.boundary G res n
  obtain ⟨card,pos,_⟩ := Frontier34.ears G res n
  obtain ⟨y,yt⟩ := card_pos.mp (show 0<(twos G).card by omega)
  have applyOne (v : V) (vm : v∈twos G) (only : uniqueWitness G v) :=
    unique_edge G (LowSample.two_degree G vm) (by have := pos v vm; omega) only
  by_cases eq : twos G={y}
  · exact ⟨y,yt,applyOne y yt (one G eq (by omega) res.2.2.1)⟩
  · have many : 1<(twos G).card := by
      by_contra! sm
      exact eq (eq_of_subset_of_card_le (singleton_subset_iff.mpr yt) (by rw [card_singleton]; omega)).symm
    obtain ⟨z,zt,zy⟩ := exists_ne_of_one_lt_card many y
    rcases (disjoint G res n yt zt zy.symm).2 with lo|lo
    · exact ⟨y,yt,applyOne y yt lo⟩
    · exact ⟨z,zt,applyOne z zt lo⟩

/-- A normalized order-34 failure has an ear anchor on no four-clique.
Its exterior high neighbors induce a matching and isolated vertices. -/
theorem anchor_outside_cliques (res : Minimal.Residual G) (n : Fintype.card V=34) :
    let W := (twos G).biUnion (G.neighborFinset ·)
    ∃ w∈W,(∀ K : Finset V,G.IsNClique 4 K → w∉K) ∧
      (∀ v∈ForkGuard34.candidates G W,¬G.Adj w v) ∧
      (∀ v∈ForkGuard34.row G W w,nbr G v (ForkGuard34.row G W w)≤1) := by
  let W := (twos G).biUnion (G.neighborFinset ·)
  obtain ⟨q,t,h⟩ := Frontier34.boundary G res n
  have num := (Frontier34.ears G res n).1
  have A := (Ears34.anchor_sets G res n).1
  have wh : W⊆high G := by
    intro w wm
    obtain ⟨e,et,we⟩ := mem_biUnion.mp wm
    exact A e et we
  have all (e : V) (et : e∈twos G) : G.neighborFinset e⊆W := fun _ m => mem_biUnion.mpr ⟨e,et,m⟩
  have inc (w : V) (wm : w∈W) : ∃ e∈twos G,G.Adj w e := by
    obtain ⟨e,et,ew⟩ := mem_biUnion.mp wm
    exact ⟨e,et,((G.mem_neighborFinset _ _).mp ew).symm⟩
  obtain ⟨w,ww,blind,matchG⟩ := ForkGuard34.matching G wh all inc (by omega) res.2.2.1
  refine ⟨w,ww,?_,blind,matchG⟩
  intro K cl wk
  have kw := ForkGuard34.inside G ww blind matchG cl wk
  have sum : (∑ e∈twos G,(G.neighborFinset e).card)=(twos G).card*2 := by
    calc
      _ = ∑ _e∈twos G,2 := sum_congr rfl (fun e et => (card_neighborFinset_eq_degree _ _).trans (LowSample.two_degree G et))
      _ = _ := by simp
  have cap : W.card≤(twos G).card*2 := card_biUnion_le.trans_eq sum
  have eq := eq_of_subset_of_card_le kw (by rw [cl.2]; omega)
  obtain ⟨e,et,a,b,ab,edge,unique⟩ := necessary G res n
  have aw : a∈W := all e et (ab ▸ mem_insert_self ..)
  have bw : b∈W := all e et (ab ▸ mem_insert_of_mem (mem_singleton_self _))
  have ak : a∈K := eq ▸ aw
  have bk : b∈K := eq ▸ bw
  have rest := card_sdiff_add_card_inter K ({a,b} : Finset V)
  have smaller := card_le_card (show K∩({a,b} : Finset V)⊆{a,b} from inter_subset_right)
  rw [card_pair edge.ne] at smaller
  obtain ⟨j,jm⟩ := card_pos.mp (show 0<(K\{a,b}).card by rw [cl.2] at rest; omega)
  obtain ⟨jk,out⟩ := mem_sdiff.mp jm
  have ja : j≠a := fun p => out (mem_insert.mpr (Or.inl p))
  have jb : j≠b := fun p => out (mem_insert_of_mem (mem_singleton.mpr p))
  have common := mem_inter.mpr ⟨(G.mem_neighborFinset _ _).mpr (cl.1 ak jk ja.symm),(G.mem_neighborFinset _ _).mpr (cl.1 bk jk jb.symm)⟩
  rw [unique,mem_singleton] at common
  exact (mem_sdiff.mp et).2 (common ▸ wh (kw jk))

/-- The same four-clique-free ear anchor has at most (d+1)/2 incident
triangles. The two bounds hold on the very same vertex. -/
theorem scored_anchor (res : Minimal.Residual G) (n : Fintype.card V=34) :
    let W := (twos G).biUnion (G.neighborFinset ·)
    ∃ w∈W,2*trianglesAt G w≤G.degree w+1 ∧ (∀ K : Finset V,G.IsNClique 4 K → w∉K) ∧
      (∀ v∈ForkGuard34.candidates G W,¬G.Adj w v) ∧
      (∀ v∈ForkGuard34.row G W w,nbr G v (ForkGuard34.row G W w)≤1) := by
  let W := (twos G).biUnion (G.neighborFinset ·)
  obtain ⟨_,t,h⟩ := Frontier34.boundary G res n
  obtain ⟨num,pos,_⟩ := Frontier34.ears G res n
  obtain ⟨w,ww,no4,blind,small⟩ := anchor_outside_cliques G res n
  obtain ⟨y,yt,wy⟩ := mem_biUnion.mp ww
  have all (e : V) (et : e∈twos G) : G.neighborFinset e⊆W := fun _ m => mem_biUnion.mpr ⟨e,et,m⟩
  have sum : (∑ e∈twos G,(G.neighborFinset e).card)=(twos G).card*2 := by
    calc
      _ = ∑ _e∈twos G,2 := sum_congr rfl (fun e et => (card_neighborFinset_eq_degree _ _).trans (LowSample.two_degree G et))
      _ = _ := by simp
  have card : W.card≤(twos G).card*2 := card_biUnion_le.trans_eq sum
  have cap : W.card≤4 := by omega
  have leaf : ∃ a∈W,nbr G a W≤1 := by
    by_cases eq : twos G={y}
    · have we : W=G.neighborFinset y := by simp only [W,eq,singleton_biUnion]
      have wc : W.card=2 := by rw [we,card_neighborFinset_eq_degree,LowSample.two_degree G yt]
      have inc : W.filter (G.Adj w)⊆W.erase w := fun _ m => mem_erase.mpr ⟨(mem_filter.mp m).2.ne.symm,(mem_filter.mp m).1⟩
      have le := card_le_card inc
      rw [card_erase_of_mem ww,wc] at le
      exact ⟨w,ww,le⟩
    · have many : 1<(twos G).card := by
        by_contra! sm
        exact eq (eq_of_subset_of_card_le (singleton_subset_iff.mpr yt) (by rw [card_singleton]; omega)).symm
      obtain ⟨z,zt,zy⟩ := exists_ne_of_one_lt_card many y
      obtain ⟨e,f,a,b,which,ab,_,_,out⟩ := end_anchor G n t zy.symm (LowSample.two_degree G yt) (LowSample.two_degree G zt)
        (by have := pos y yt; omega) (by have := pos z zt; omega) res.2.2.1
      have ef : twos G={e,f} := by
        obtain ⟨rfl,rfl⟩|⟨rfl,rfl⟩ := which
        · exact (eq_of_subset_of_card_le (insert_subset yt (singleton_subset_iff.mpr zt)) (by rw [card_pair zy.symm]; omega)).symm
        · exact (eq_of_subset_of_card_le (insert_subset zt (singleton_subset_iff.mpr yt)) (by rw [card_pair zy]; omega)).symm
      have et : e∈twos G := ef ▸ mem_insert_self .. 
      have aw : a∈W := all e et (ab ▸ mem_insert_self ..)
      have inc : W.filter (G.Adj a)⊆{b} := by
        intro j jm
        obtain ⟨jw,aj⟩ := mem_filter.mp jm
        obtain ⟨v,vm,jv⟩ := mem_biUnion.mp jw
        rw [ef,mem_insert,mem_singleton] at vm
        rcases vm with rfl|rfl
        · rw [ab,mem_insert,mem_singleton] at jv
          exact mem_singleton.mpr (jv.resolve_left aj.ne.symm)
        · exact (out j jv aj).elim
      exact ⟨a,aw,(card_le_card inc).trans_eq (card_singleton _)⟩
  have only (z : V) (zt : z∈twos G) (wz : G.Adj w z) : z=y := by
    by_contra ne
    exact disjoint_left.mp (disjoint G res n yt zt (fun p => ne p.symm)).1 wy ((G.mem_neighborFinset _ _).mpr wz.symm)
  obtain ⟨i,j,eq,_,_,_⟩ := SharedExact34.ear_pair G (LowSample.two_degree G yt) (by have := pos y yt; omega)
  have pair : ∃ b∈W,G.neighborFinset y={w,b} := by
    rw [eq,mem_insert,mem_singleton] at wy
    rcases wy with rfl|rfl
    · exact ⟨j,all y yt (eq ▸ mem_insert_of_mem (mem_singleton_self _)),eq⟩
    · exact ⟨i,all y yt (eq ▸ mem_insert_self ..),eq.trans (pair_comm ..)⟩
  obtain ⟨b,bw,row⟩ := pair
  exact ⟨w,ww,AnchorScore34.degree G ww bw row only (fun _ xw ux => AnchorScore34.no_square G cap leaf ww xw ux) blind small,no4,blind,small⟩

end Graffiti384b.Triangle34
#print axioms Graffiti384b.AnchorScore34.degree
#print axioms Graffiti384b.Triangle34.scored_anchor
#print axioms Graffiti384b.ForkGuard34.matching
#print axioms Graffiti384b.ForkGuard34.inside
#print axioms Graffiti384b.Triangle34.anchor_outside_cliques
#print axioms Graffiti384b.PinnedColor34.complete
#print axioms Graffiti384b.PinnedColor34.repair
#print axioms Graffiti384b.CubicCover34.crowded
#print axioms Graffiti384b.AnchorLink34.outside
#print axioms Graffiti384b.SharedRepair34.exact
#print axioms Graffiti384b.SharedExact34.shared
#print axioms Graffiti384b.EarSquares34.disjoint_exact
#print axioms Graffiti384b.DisjointCross34.isolated
#print axioms Graffiti384b.Triangle34.end_anchor
#print axioms Graffiti384b.Triangle34.disjoint
#print axioms Graffiti384b.Triangle34.unique_edge
#print axioms Graffiti384b.Triangle34.one
#print axioms Graffiti384b.Triangle34.necessary

