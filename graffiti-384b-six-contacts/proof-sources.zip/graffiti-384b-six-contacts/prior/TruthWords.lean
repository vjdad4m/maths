import FourTrial
import Mathlib.Tactic.Linarith

namespace Graffiti384b.Four29.Words

/-- Bit p of a truth-table word is the value of the signal on assignment p. -/
def ones (n : ℕ) := 2^(2^n)-1
def column : ℕ→ℕ→ℕ
  | 0,_ => 0
  | n+1,i => if i=n then (2^(2^n)-1) <<< (2^n)
    else (2^(2^n)+1)*column n i

private theorem column_bound (n i : ℕ) : column n i < 2^(2^n) := by
  induction n with
  | zero => simp [column]
  | succ n ih =>
    have pos := Nat.two_pow_pos (2^n)
    rw [Nat.pow_succ 2 n,Nat.mul_two,Nat.pow_add]
    simp only [column,Nat.shiftLeft_eq]
    split <;> nlinarith [Nat.sub_add_cancel (show 1≤2^(2^n) from pos),
      Nat.mul_le_mul_right (2^(2^n)+1) (show column n i+1≤2^(2^n) from ih)]

def assignment (v : ℕ→Bool) : ℕ→ℕ
  | 0 => 0
  | n+1 => if v n then 2^n+assignment v n else assignment v n

theorem assignment_bound (v : ℕ→Bool) (n : ℕ) : assignment v n<2^n := by
  induction n with
  | zero => simp [assignment]
  | succ n ih => rw [Nat.pow_succ]; simp only [assignment]; split <;> omega

theorem column_at (v : ℕ→Bool) {n i : ℕ} (hi : i<n) :
    (column n i).testBit (assignment v n)=v i := by
  induction n with
  | zero => omega
  | succ n ih =>
    have small := assignment_bound v n
    have w := Nat.two_pow_pos n
    simp only [column,assignment]
    by_cases eq : i=n
    · subst i
      cases b : v n <;> simp [b,Nat.testBit_shiftLeft,Nat.testBit_two_pow_sub_one,show ¬assignment v n ≥ 2^n by omega,small]
    · rw [if_neg eq,Nat.add_mul,Nat.one_mul]
      rw [Nat.testBit_two_pow_mul_add _ (column_bound n i)]
      have prev := ih (by omega)
      cases b : v n <;> simp [b,small,prev,show ¬2^n+assignment v n<2^n by omega]

def any : List ℕ→ℕ | [] => 0 | a::s => a ||| any s
def all (top : ℕ) : List ℕ→ℕ | [] => top | a::s => a &&& all top s

theorem any_at (p : ℕ) (s : List ℕ) : (any s).testBit p=true ↔ ∃w∈s,w.testBit p=true := by
  induction s with
  | nil => simp [any]
  | cons a s ih => simp [any,ih]
theorem all_at {p top : ℕ} (yes : top.testBit p=true) (s : List ℕ) :
    (all top s).testBit p=true ↔ ∀w∈s,w.testBit p=true := by
  induction s with
  | nil => simp [all,yes]
  | cons a s ih => simp [all,ih]

/-- Pointwise binary addition of one input bit with carry. -/
def increment (b : ℕ) : List ℕ→List ℕ
  | [] => [b]
  | h::t => (h ^^^ b)::increment (h &&& b) t
def number (p : ℕ) : List ℕ→ℕ
  | [] => 0
  | h::t => (h.testBit p).toNat+2*number p t

theorem increment_at (p b : ℕ) (s : List ℕ) :
    number p (increment b s)=(b.testBit p).toNat+number p s := by
  induction s generalizing b with
  | nil => simp [increment,number]
  | cons h t ih =>
    simp only [increment,number,ih,Nat.testBit_xor,Nat.testBit_and]
    cases h.testBit p <;> cases b.testBit p
    all_goals simp_all [Bool.toNat]
    omega

/-- Sum indicator words, storing binary digits in increasing order. -/
def binary : List ℕ→List ℕ
  | [] => []
  | w::s => increment w (binary s)
theorem binary_at (p : ℕ) (s : List ℕ) :
    number p (binary s)=(s.filter (fun w => w.testBit p)).length := by
  induction s with
  | nil => rfl
  | cons w s ih =>
    simp only [binary,increment_at,ih,List.filter_cons]
    cases w.testBit p <;> simp [Bool.toNat,Nat.add_comm]

theorem any_of_pos {p : ℕ} {s : List ℕ} (h : 0<number p s) : (any s).testBit p=true := by
  induction s with
  | nil => simp [number] at h
  | cons a s ih =>
    simp only [any,Nat.testBit_or,Bool.or_eq_true]
    cases ha : a.testBit p
    · exact Or.inr (ih (by simpa [number,ha] using h))
    · exact Or.inl rfl

theorem at_least_two {p : ℕ} {s : List ℕ} (h : 2≤number p s) :
    (any s.tail).testBit p=true := by
  cases s with
  | nil => simp [number] at h
  | cons a s =>
    apply any_of_pos
    change 0<number p s
    simp only [number] at h
    cases ha : a.testBit p <;> simp [ha] at h <;> omega

def differ : List ℕ→List ℕ→ℕ
  | [],b => any b
  | a,[] => any a
  | x::a,y::b => (x ^^^ y) ||| differ a b
theorem differ_at (p : ℕ) (a b : List ℕ) (ne : number p a≠number p b) :
    (differ a b).testBit p=true := by
  induction a generalizing b with
  | nil => simpa only [differ] using (any_of_pos (p:=p) (s:=b) (by change 0≠number p b at ne; omega))
  | cons x a ih =>
    cases b with
    | nil => exact any_of_pos (by change number p (x::a)≠0 at ne; omega)
    | cons y b =>
      simp only [differ,Nat.testBit_or,Nat.testBit_xor,Bool.or_eq_true]
      by_cases eq : x.testBit p=y.testBit p
      · apply Or.inr; apply ih; intro h; exact ne (by simp [number,eq,h])
      · exact Or.inl (by cases h : x.testBit p <;> cases j : y.testBit p <;> simp_all)

def atTwo : List ℕ→ℕ
  | [] => 0
  | a::s => (a &&& any s) ||| atTwo s
theorem atTwo_at (p : ℕ) (s : List ℕ) :
    (atTwo s).testBit p=true ↔ 2≤(s.filter (fun w => w.testBit p)).length := by
  induction s with
  | nil => simp [atTwo]
  | cons a s ih =>
    have non : (any s).testBit p=true ↔ 0<(s.filter (fun w => w.testBit p)).length := by
      rw [any_at,List.length_pos_iff]
      constructor
      · rintro ⟨w,ws,v⟩ empty
        have hm : w∈s.filter (fun w => w.testBit p) := List.mem_filter.mpr ⟨ws,v⟩
        rw [empty] at hm
        exact List.not_mem_nil hm
      · intro ne
        obtain ⟨w,ws⟩ := List.exists_mem_of_ne_nil _ ne
        exact ⟨w,(List.mem_filter.mp ws).1,(List.mem_filter.mp ws).2⟩
    simp only [atTwo,Nat.testBit_or,Nat.testBit_and,Bool.or_eq_true,Bool.and_eq_true,non,ih,List.filter_cons]
    cases h : a.testBit p <;> simp only [h,Bool.false_eq_true,Bool.true_eq,true_and,false_and,false_or,List.length_cons,if_true,if_false]
    all_goals first | rfl | omega
end Graffiti384b.Four29.Words
#print axioms Graffiti384b.Four29.Words.column_at
#print axioms Graffiti384b.Four29.Words.binary_at
