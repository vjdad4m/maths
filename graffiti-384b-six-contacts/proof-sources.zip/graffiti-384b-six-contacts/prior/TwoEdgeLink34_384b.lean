import ForkGuard34_384b
import TrianglePrune384b

namespace Graffiti384b.TwoEdge34
open Finset SimpleGraph LowSample
open private LowSample.two_degree from LowSample384b
open private Repair.nbr_mono Repair.linkEdges Repair.support_pos Repair.support_sub Repair.link_sum from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- A private ear edge and a matching in the entire link of the same anchor. -/
theorem link {W : Finset V} {w e b : V} (ww : w∈W) (bw : b∈W) (wb : G.Adj w b)
    (ew : G.Adj e w) (eb : G.Adj e b) (ear : G.neighborFinset e={w,b})
    (inside : ∀ x∈W,G.Adj w x → x=b) (only : ∀ x∈twos G,G.Adj w x → x=e)
    (blind : ∀ x∈ForkGuard34.candidates G W,¬G.Adj w x)
    (small : ∀ x∈ForkGuard34.row G W w,nbr G x (ForkGuard34.row G W w)≤1) :
    G.neighborFinset w∩G.neighborFinset b={e} ∧
    ∀ x∈G.neighborFinset w,nbr G x (G.neighborFinset w)≤1 := by
  classical
  have highOr {x j : V} (wx : G.Adj w x) (wj : G.Adj w j) (xj : G.Adj x j) : x∈high G ∨ x=e := by
    by_cases xh : x∈high G
    · exact Or.inl xh
    have sub := insert_subset ((G.mem_neighborFinset _ _).mpr wx.symm)
      (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr xj))
    have le := card_le_card sub
    rw [card_pair wj.ne,card_neighborFinset_eq_degree] at le
    exact Or.inr (only x (mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,le⟩,xh⟩) wx)
  have fromB {j : V} (wj : G.Adj w j) (bj : G.Adj b j) : j=e := by
    by_cases jw : j∈W
    · exact (bj.ne (inside j jw wj).symm).elim
    rcases highOr wj wb bj.symm with jh|eq
    · exact (blind j (mem_filter.mpr ⟨mem_sdiff.mpr ⟨jh,jw⟩,
        PinnedColor34.two G wb.ne wj.symm bj.symm ww bw⟩) wj).elim
    · exact eq
  have fromE {j : V} (wj : G.Adj w j) (ej : G.Adj e j) : j=b := by
    have m := (G.mem_neighborFinset _ _).mpr ej
    rw [ear,mem_insert,mem_singleton] at m
    exact m.resolve_left wj.ne.symm
  refine ⟨Subset.antisymm (fun j jm => mem_singleton.mpr (fromB
    ((G.mem_neighborFinset _ _).mp (mem_inter.mp jm).1) ((G.mem_neighborFinset _ _).mp (mem_inter.mp jm).2)))
    (singleton_subset_iff.mpr (mem_inter.mpr ⟨(G.mem_neighborFinset _ _).mpr ew.symm,(G.mem_neighborFinset _ _).mpr eb.symm⟩)),?_⟩
  intro x xn
  have wx := (G.mem_neighborFinset _ _).mp xn
  by_cases xb : x=b
  · subst x
    exact (card_le_card (show (G.neighborFinset w).filter (G.Adj b)⊆{e} from fun _ m =>
      mem_singleton.mpr (fromB ((G.mem_neighborFinset _ _).mp (mem_filter.mp m).1) (mem_filter.mp m).2))).trans_eq (card_singleton _)
  by_cases xe : x=e
  · subst x
    exact (card_le_card (show (G.neighborFinset w).filter (G.Adj e)⊆{b} from fun _ m =>
      mem_singleton.mpr (fromE ((G.mem_neighborFinset _ _).mp (mem_filter.mp m).1) (mem_filter.mp m).2))).trans_eq (card_singleton _)
  let L := (G.neighborFinset w).filter (G.Adj x)
  by_cases non : L.Nonempty
  · obtain ⟨j,jm⟩ := non
    have xh := (highOr wx ((G.mem_neighborFinset _ _).mp (mem_filter.mp jm).1) (mem_filter.mp jm).2).resolve_right xe
    have xr : x∈ForkGuard34.row G W w :=
      mem_filter.mpr ⟨mem_sdiff.mpr ⟨xh,fun xw => xb (inside x xw wx)⟩,wx⟩
    have sub : L⊆(ForkGuard34.row G W w).filter (G.Adj x) := by
      intro i im
      obtain ⟨inn,xi⟩ := mem_filter.mp im
      have wi := (G.mem_neighborFinset _ _).mp inn
      have ih := (highOr wi wx xi.symm).resolve_right (fun ie => xb (fromE wx (ie ▸ xi.symm)))
      have iw : i∉W := fun iw => xe (fromB wx (inside i iw wi ▸ xi.symm))
      exact mem_filter.mpr ⟨mem_filter.mpr ⟨mem_sdiff.mpr ⟨ih,iw⟩,wi⟩,xi⟩
    exact (card_le_card sub).trans (small x xr)
  · exact (card_eq_zero.mpr (not_nonempty_iff_eq_empty.mp non)).le.trans (Nat.zero_le 1)

theorem half_degree {w : V} (thin : ∀ x∈G.neighborFinset w,nbr G x (G.neighborFinset w)≤1) :
    2*trianglesAt G w≤G.degree w := by
  have sub := Repair.support_sub G w
  have sum := sum_le_sum (s:=Repair.linkSupport G w) (fun x xm => (Repair.nbr_mono G x sub).trans (thin x (sub xm)))
  rw [Repair.link_sum] at sum
  simp only [sum_const,nsmul_eq_mul,Nat.mul_one,Nat.cast_id] at sum
  exact sum.trans ((card_le_card sub).trans_eq (card_neighborFinset_eq_degree G w))

private theorem support_of_common {w x j : V} (wx : G.Adj w x) (wj : G.Adj w j) (xj : G.Adj x j) :
    x∈Repair.linkSupport G w := by
  have m : ({x,j} : Finset V)∈Repair.linkEdges G w := by
    refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset ((G.mem_neighborFinset _ _).mpr wx)
      (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr wj)),card_pair xj.ne⟩,?_⟩
    intro a am b bm ne
    simp only [mem_insert,mem_singleton] at am bm
    rcases am with rfl|rfl <;> rcases bm with rfl|rfl <;> first | exact (ne rfl).elim | exact xj | exact xj.symm
  exact mem_biUnion.mpr ⟨_,m,mem_insert_self ..⟩

/-- Normality identifies all the isolated vertices of this matching link.
There is at most one, and it is exactly a neighbor of triangle count zero. -/
theorem degree_formula (norm : TrianglePrune.Normal G) {w : V} (wp : 0<trianglesAt G w)
    (thin : ∀ x∈G.neighborFinset w,nbr G x (G.neighborFinset w)≤1) :
    G.degree w=2*trianglesAt G w + (if ∃ x∈G.neighborFinset w,trianglesAt G x=0 then 1 else 0) := by
  classical
  let N := G.neighborFinset w
  let S := Repair.linkSupport G w
  have sn : S⊆N := Repair.support_sub G w
  have val (x : V) (xm : x∈S) : nbr G x S=1 :=
    le_antisymm ((Repair.nbr_mono G x sn).trans (thin x (sn xm))) (Repair.support_pos G xm)
  have size : S.card=2*trianglesAt G w := by
    calc
      _ = ∑ _x∈S,1 := by simp
      _ = ∑ x∈S,nbr G x S := sum_congr rfl (fun x xm => (val x xm).symm)
      _ = _ := Repair.link_sum G w
  have isolated (x : V) (xm : x∈N) : x∉S ↔ trianglesAt G x=0 := by
    have wx := (G.mem_neighborFinset _ _).mp xm
    constructor
    · intro out
      by_contra ne
      obtain ⟨j,wj,xj⟩ := norm.2.2 w x wx wp (Nat.pos_of_ne_zero ne)
      exact out (support_of_common G wx wj xj)
    · intro zero xs
      obtain ⟨j,jm⟩ := card_pos.mp (Repair.support_pos G xs)
      obtain ⟨js,xj⟩ := mem_filter.mp jm
      have pos := (TrianglePrune.triangle_iff G x).mpr ⟨w,j,wx.symm,xj,(G.mem_neighborFinset _ _).mp (sn js)⟩
      omega
  have total := card_sdiff_add_card_eq_card sn
  change (N\S).card + S.card = G.degree w at total
  split
  · rename_i ex
    obtain ⟨x,xn,zero⟩ := ex
    have eq : N\S={x} := Subset.antisymm (fun j jm => mem_singleton.mpr
      (norm.1 j x ((isolated j (mem_sdiff.mp jm).1).mp (mem_sdiff.mp jm).2) zero))
      (singleton_subset_iff.mpr (mem_sdiff.mpr ⟨xn,(isolated x xn).mpr zero⟩))
    rw [eq,card_singleton] at total
    omega
  · rename_i no
    have eq : N\S=∅ := not_nonempty_iff_eq_empty.mp (fun ⟨j,jm⟩ => no
      ⟨j,(mem_sdiff.mp jm).1,(isolated j (mem_sdiff.mp jm).1).mp (mem_sdiff.mp jm).2⟩)
    rw [eq,card_empty] at total
    omega

end Graffiti384b.TwoEdge34
#print axioms Graffiti384b.TwoEdge34.half_degree
#print axioms Graffiti384b.TwoEdge34.link
#print axioms Graffiti384b.TwoEdge34.degree_formula
