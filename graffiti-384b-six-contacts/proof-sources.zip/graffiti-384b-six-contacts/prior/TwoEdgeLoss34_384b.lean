import BlockLoss384b
import BoundaryFiber384b

namespace Graffiti384b.TwoEdge34
open Finset SimpleGraph
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private Repair.linkEdges Repair.edge_info from Repair384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The two neighbors w and e form an isolated edge in the link of b. -/
theorem fellow_score {w b e : V} (wb : G.Adj w b) (ew : G.Adj e w) (eb : G.Adj e b)
    (ear : G.neighborFinset e={w,b}) (priv : G.neighborFinset w∩G.neighborFinset b={e}) :
    trianglesAt G b≤1+(G.degree b-2).choose 2 := by
  let D := G.neighborFinset b\{w,e}
  have mate {i j : V} (bi : G.Adj b i) (bj : G.Adj b j) (ij : G.Adj i j) (ins : i∈({w,e} : Finset V)) :
      ({i,j} : Finset V)={w,e} := by
    rcases mem_insert.mp ins with rfl|m
    · have jm : j∈G.neighborFinset i∩G.neighborFinset b := mem_inter.mpr
        ⟨(G.mem_neighborFinset _ _).mpr ij,(G.mem_neighborFinset _ _).mpr bj⟩
      rw [priv,mem_singleton] at jm
      rw [jm]
    · obtain rfl := mem_singleton.mp m
      have jm := (G.mem_neighborFinset _ _).mpr ij
      rw [ear,mem_insert,mem_singleton] at jm
      rw [jm.resolve_right bj.ne.symm,pair_comm]
  have cover : Repair.linkEdges G b⊆insert {w,e} (D.powersetCard 2) := by
    intro a am
    obtain ⟨sub,sz,cl⟩ := Repair.edge_info G am
    obtain ⟨i,j,ne,eq⟩ := card_eq_two.mp sz
    have im : i∈a := eq ▸ mem_insert_self .. 
    have jm : j∈a := eq ▸ mem_insert_of_mem (mem_singleton_self _)
    have bi := (G.mem_neighborFinset _ _).mp (sub im)
    have bj := (G.mem_neighborFinset _ _).mp (sub jm)
    have ij := cl _ im _ jm ne
    by_cases hi : i∈({w,e} : Finset V)
    · exact mem_insert.mpr (Or.inl (eq.trans (mate bi bj ij hi)))
    by_cases hj : j∈({w,e} : Finset V)
    · exact mem_insert.mpr (Or.inl (eq.trans ((pair_comm ..).trans (mate bj bi ij.symm hj))))
    exact mem_insert_of_mem (mem_powersetCard.mpr ⟨fun x xm => mem_sdiff.mpr ⟨sub xm,by
      rw [eq,mem_insert,mem_singleton] at xm
      exact xm.elim (fun v => v ▸ hi) (fun v => v ▸ hj)⟩,sz⟩)
  have lim := (card_le_card cover).trans (card_insert_le ..)
  have incl := insert_subset ((G.mem_neighborFinset _ _).mpr wb.symm) (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr eb.symm))
  have dc : D.card=G.degree b-2 := by rw [show D=_ from rfl,card_sdiff incl,card_pair ew.ne.symm,card_neighborFinset_eq_degree]
  rw [card_powersetCard,dc] at lim
  exact lim.trans_eq (Nat.add_comm ..)

/-- Vertices adjacent to either retained endpoint or to the other ear have
a guaranteed neighbor outside the random pool. The disjoint-edge hypothesis
makes their multiplicities exactly countable. -/
theorem boundary_count (n : Fintype.card V=34) {s : Finset V} {w b e z : V}
    (priv : G.neighborFinset w∩G.neighborFinset b={e}) (dz : G.degree z=2)
    (dis : Disjoint (G.neighborFinset w∪G.neighborFinset b) (G.neighborFinset z))
    (wz : ¬G.Adj w z) (bz : ¬G.Adj b z) (ws : w∉s) (bs : b∉s) (zs : z∉s) {k : ℕ}
    (sk : s.card+k=29) :
    G.degree w+G.degree b≤(s.filter (fun v => ∃ x∉s,G.Adj v x)).card+3+k := by
  classical
  let U := (G.neighborFinset w∪G.neighborFinset b)∪G.neighborFinset z
  have sz : U.card=G.degree w+G.degree b+1 := by
    have add := card_union_add_card_inter (G.neighborFinset w) (G.neighborFinset b)
    rw [priv,card_singleton,card_neighborFinset_eq_degree,card_neighborFinset_eq_degree] at add
    rw [show U=_ from rfl,card_union_of_disjoint dis,card_neighborFinset_eq_degree,dz]; omega
  have zu : z∉U := by
    simp [U,wz,bz]
  have small : U\s⊆sᶜ.erase z := fun _ vm => mem_erase.mpr
    ⟨fun eq => zu (eq ▸ (mem_sdiff.mp vm).1),mem_compl.mpr (mem_sdiff.mp vm).2⟩
  have limit := card_le_card small
  rw [card_erase_of_mem (mem_compl.mpr zs),card_compl,n] at limit
  have share : U∩s⊆s.filter (fun v => ∃ x∉s,G.Adj v x) := by
    intro v vm
    obtain ⟨inU,vs⟩ := mem_inter.mp vm
    apply mem_filter.mpr ⟨vs,?_⟩
    rcases mem_union.mp inU with h|h
    · rcases mem_union.mp h with h|h
      · exact ⟨w,ws,((G.mem_neighborFinset _ _).mp h).symm⟩
      · exact ⟨b,bs,((G.mem_neighborFinset _ _).mp h).symm⟩
    · exact ⟨z,zs,((G.mem_neighborFinset _ _).mp h).symm⟩
  have parts := card_sdiff_add_card_inter U s
  have le := card_le_card share
  omega

theorem refund (s : Finset V) (sh : s⊆high G) (m R : ℕ) (sz : s.card=m) (room : 9<m)
    (env : BlockLoss.envelope m 10)
    (paid : ∀ j : Fin 10,3≤j.val → (m-j.val).choose 10+R≤FiniteRange.badCount m 10 j.val) :
    (∑ k∈s.powersetCard 10,(FiniteRange.bad G s k).card)+(s.filter (fun v => ∃ x∉s,G.Adj v x)).card*R ≤
      BlockLoss.chargeAt m 10 (fun j => (s.filter (fun v => G.degree v≤j)).card) := by
  classical
  let pay (v : V) := if ∃ x∉s,G.Adj v x then R else 0
  have each (v : V) (vs : v∈s) : ((s.powersetCard 10).filter (fun k => v∈FiniteRange.bad G s k)).card+pay v≤
      FiniteRange.badCount s.card 10 (min (G.degree v) 9) := by
    let a := min (G.degree v) 9
    have num : 3≤a ∧ a≤9 := by dsimp [a]; have := (mem_filter.mp (sh vs)).2; omega
    by_cases hit : ∃ x∉s,G.Adj v x
    · obtain ⟨x,xs,vx⟩ := hit
      have yes : ∃ j∉s,G.Adj v j := ⟨x,xs,vx⟩
      simp only [pay,if_pos yes,sz]
      have raw := BoundaryFiber.count G s 10 a vs xs vx (min_le_left ..) (by omega)
      rw [sz] at raw
      exact (Nat.add_le_add_right raw R).trans (paid ⟨a,by omega⟩ num.1)
    · simp only [pay,if_neg hit,Nat.add_zero]
      exact FiniteRange.count_bad G s 10 a v vs (min_le_left ..) (by omega)
  have res := BlockLoss.pool_loss G s sh 10 _ (fun _ _ _ => le_rfl) pay each (sz ▸ env)
  have sum : (∑ v∈s,pay v)=(s.filter (fun v => ∃ x∉s,G.Adj v x)).card*R := by
    simp [pay,←sum_filter]
  rwa [sz,sum] at res

end Graffiti384b.TwoEdge34
#print axioms Graffiti384b.TwoEdge34.fellow_score
#print axioms Graffiti384b.TwoEdge34.boundary_count
#print axioms Graffiti384b.TwoEdge34.refund
