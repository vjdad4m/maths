import SharedRanks34_384b

namespace Graffiti384b.TwoEdge34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private LowSample.delta from LowSample384b
def ceiling (h : Bool) (j : ℕ) := j.choose 2 + (if j=3 ∧ h=true then 1 else 0)
def scoreRank (m : ℕ) (h : Bool) (score : ℕ) :=
  ∑ j∈range 9,if score<ceiling h j then LowSample.delta m 10 j else 0

def thinPay : ℕ → Bool → ℕ
  | 29, h => if h then 10690977 else 10690977
  | 28, h => if h then 6569310 else 6265248
  | 27, h => if h then 3917888 else 3564968
  | 26, h => if h then 2011828 else 1966588
  | 25, h => if h then 986700 else 986700
  | 24, h => if h then 460031 else 460031
  | 23, h => if h then 184327 else 184327
  | 22, h => if h then 65769 else 65769
  | _, _ => 0

def fellowPay : ℕ → Bool → ℕ
  | 29, h => if h then 7255872 else 7255872
  | 28, h => if h then 3850704 else 3850704
  | 27, h => if h then 1944800 else 1944800
  | 26, h => if h then 915200 else 915200
  | 25, h => if h then 400400 else 400400
  | 24, h => if h then 160160 else 160160
  | 23, h => if h then 57200 else 57200
  | 22, h => if h then 17600 else 17600
  | _, _ => 0

set_option maxRecDepth 32768 in
set_option maxHeartbeats 12000000 in
theorem payments : ∀ k : Fin 8,∀ h : Bool,∀ d : Fin 34,3≤d.val →
    let m := 29-k.val
    thinPay m h≤scoreRank m h (d.val/2)+d.val*Finish33.rebate m 10 ∧
    fellowPay m h≤scoreRank m h (1+(d.val-2).choose 2)+d.val*Finish33.rebate m 10 := by
  unfold thinPay fellowPay scoreRank ceiling LowSample.delta Finish33.rebate FiniteRange.badCount
  simp only [Nat.choose_eq_fast_choose]
  decide

private def Budget (f : Finset ℕ) :=
  let m := 29-f.card
  let h := decide (3∈f)
  let R := Finish33.rebate m 10
  f.card≤7 ∧ 9<m ∧ BlockLoss.envelope m 10 ∧
  (∀ j : Fin 10,3≤j.val → (m-j.val).choose 10+R≤FiniteRange.badCount m 10 j.val) ∧
  16*m.choose 10 + BlockLoss.chargeAt m 10 (SharedRanks34.limit f) + (3+f.card)*R <
    (m-10+1)*m.choose 10+(m-2).choose 8+(∑ d∈f,bonus m 10 d)+thinPay m h+fellowPay m h

set_option maxRecDepth 32768 in
set_option maxHeartbeats 12000000 in
theorem budget : ∀ f∈Boundary.levels.powerset, Budget f := by
  unfold Budget thinPay fellowPay BlockLoss.envelope BlockLoss.chargeAt SharedRanks34.limit Finish33.rebate slots LowSample.delta bonus FiniteRange.badCount
  simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose]
  decide

end Graffiti384b.TwoEdge34
#print axioms Graffiti384b.TwoEdge34.payments
#print axioms Graffiti384b.TwoEdge34.budget
