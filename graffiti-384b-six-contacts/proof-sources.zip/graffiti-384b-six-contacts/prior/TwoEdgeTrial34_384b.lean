import MultiEar34_384b

namespace Graffiti384b.TwoEdge34
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private LowSample.eligible LowSample.anchors LowSample.weight from LowSample384b
open private CliqueSample.trial from CliqueSample384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private MultiEar34.fiber from MultiEar34_384b
open private LowSample.anchor_samples from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The first ear is always omitted. The second ear is also omitted whenever
both of its high anchors occur in the retained sample. -/
theorem conditional_trial {p W : Finset V} (ch : Choice G p Boundary.levels) {y z : V}
    (wm : W⊆high G\p) (yt : y∈twos G) (zt : z∈twos G) (yz : y≠z)
    (ya : LowSample.anchors G y⊆W) (za : LowSample.anchors G z⊆((high G\p)\W))
    (yc : (LowSample.anchors G y).card=2) (zc : (LowSample.anchors G z).card=2)
    (t : (types G).card=33) (fail : bound G<gamma G) (b : ℕ) (two : 2≤b)
    (room : 9≤((high G\p)\W).card) :
    let s := (high G\p)\W
    (s.card-b+1)*s.card.choose b+(s.card-2).choose (b-2)+(∑ d∈p.image (G.degree ·),bonus s.card b d) ≤
      16*s.card.choose b + ∑ k∈s.powersetCard b,(FiniteRange.bad G s k).card := by
  classical
  let U := high G\p
  let s := U\W
  have ws : Disjoint W s := disjoint_left.mpr (fun _ vw vs => (mem_sdiff.mp vs).2 vw)
  have eq : W∪s=U := by rw [union_comm]; exact sdiff_union_of_subset wm
  let opts := s.powersetCard b
  let A := LowSample.anchors G z
  let earned (k : Finset V) := if A⊆k then 1 else 0
  have point (k : Finset V) (kr : k∈opts) : s.card-b+1+earned k+(active G p (W∪k)).card ≤
      16+(FiniteRange.bad G s k).card := by
    obtain ⟨ks,sz⟩ := mem_powersetCard.mp kr
    have wk : Disjoint W k := ws.mono_right ks
    have ks' : W∪k⊆U := eq ▸ union_subset subset_union_left (ks.trans subset_union_right)
    have num := CliqueSample.trial G ch (W∪k) ks' fail
    let weightAt (i : V) := LowSample.weight (LowSample.anchors G i).card
    have ymem : y∈LowSample.eligible G (W∪k) := mem_filter.mpr ⟨yt,ya.trans subset_union_left⟩
    have pay : 6*(1+earned k)≤∑ i∈LowSample.eligible G (W∪k),weightAt i := by
      by_cases hit : A⊆k
      · have zm : z∈LowSample.eligible G (W∪k) := mem_filter.mpr ⟨zt,hit.trans subset_union_right⟩
        have sub := insert_subset ymem (singleton_subset_iff.mpr zm)
        have le := sum_le_sum_of_subset_of_nonneg sub (f:=weightAt) (fun _ _ _ => Nat.zero_le _)
        simpa [earned,hit,yz,weightAt,yc,zc,LowSample.weight] using le
      · have le := single_le_sum (f:=weightAt) (fun _ _ => Nat.zero_le _) ymem
        simpa [earned,hit,weightAt,yc,LowSample.weight] using le
    have left : U\(W∪k)=s\k := by ext i; simp [s]; tauto
    have right : Uᶜ∪(W∪k)=sᶜ∪k := by ext i; simp [s,or_assoc]; tauto
    have bad : FiniteRange.bad G U (W∪k)=FiniteRange.bad G s k := by
      unfold FiniteRange.bad; rw [left,right]
    dsimp only at num
    change 6*(U.card-(W∪k).card)+ (∑ i∈LowSample.eligible G (W∪k),weightAt i) + _ ≤ 6*(_+(FiniteRange.bad G U (W∪k)).card) at num
    rw [t,bad,←eq,card_union_of_disjoint ws,card_union_of_disjoint wk,sz] at num
    omega
  have credit : (∑ d∈p.image (G.degree ·),bonus s.card b d) ≤ ∑ k∈opts,(active G p (W∪k)).card := by
    calc
      _ = ∑ v∈p,bonus s.card b (G.degree v) := sum_image (fun _ hx _ hy e => ch.unique hx hy e)
      _ ≤ ∑ v∈p,(opts.filter (fun k => v∈active G p (W∪k))).card := by
        apply sum_le_sum
        intro v vp
        have small := (mem_Icc.mp (ch.levels (mem_image_of_mem (G.degree ·) vp))).2
        apply MultiEar34.fiber G vp (fun mem => (mem_sdiff.mp (mem_sdiff.mp mem).1).2 vp) (by change G.degree v≤9 at small; omega)
        rw [eq]; exact neighbors_in_pool G ch vp
      _ = ∑ v∈p,∑ k∈opts,(if v∈active G p (W∪k) then 1 else 0 : ℕ) := by simp
      _ = _ := by
        rw [sum_comm]; apply sum_congr rfl
        intro k _
        simp only [sum_boole,Nat.cast_id,filter_mem_eq_inter]
        rw [inter_eq_right.mpr (show active G p (W∪k)⊆p from filter_subset _ _)]
  have gain : (s.card-2).choose (b-2)≤∑ k∈opts,earned k := by
    have v := LowSample.anchor_samples s A b za (show A.card≤b by rw [show A.card=2 from zc]; omega)
    rw [show A.card=2 from zc] at v
    simpa [earned,opts] using v
  have summed := sum_le_sum point
  simp only [sum_add_distrib,sum_const,nsmul_eq_mul,opts,card_powersetCard,Nat.cast_id] at summed
  dsimp only [opts] at credit
  dsimp only [opts] at gain
  change (s.card-b+1)*s.card.choose b+(s.card-2).choose (b-2)+(∑ d∈p.image (G.degree ·),bonus s.card b d)≤16*s.card.choose b+ ∑ k∈s.powersetCard b,(FiniteRange.bad G s k).card
  rw [Nat.mul_comm (s.card-b+1),Nat.mul_comm 16,Nat.mul_add]
  omega

end Graffiti384b.TwoEdge34
#print axioms Graffiti384b.TwoEdge34.conditional_trial
