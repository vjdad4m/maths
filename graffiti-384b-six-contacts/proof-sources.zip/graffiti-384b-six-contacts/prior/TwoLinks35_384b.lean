import Minimal384b

namespace Graffiti384b.TwoLinks35
open Finset SimpleGraph
open private Repair.linkEdges Repair.edge_info from Repair384b
open private TrianglePrune.triangle_iff from TrianglePrune384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- The unordered pairs of neighbors that complete triangles through v. -/
def pairs (v : V) := Repair.linkEdges G v

/-- A count-two vertex in a normalized graph has either two triangles
meeting only there, or a diamond. Its only possible extra neighbor is the
zero-count leaf. -/
theorem shape (normal : TrianglePrune.Normal G) {l v : V} (lz : trianglesAt G l=0) (vs : trianglesAt G v=2) :
    ∃ e f : Finset V, e≠f ∧ pairs G v={e,f} ∧ e.card=2 ∧ f.card=2 ∧
      (G.neighborFinset v).erase l=e∪f ∧
      G.degree v=(if Disjoint e f then 4 else 3)+(if G.Adj v l then 1 else 0) := by
  obtain ⟨e,f,ne,eq⟩ := card_eq_two.mp (show (Repair.linkEdges G v).card=2 from vs)
  have ee := Repair.edge_info G (show e ∈ Repair.linkEdges G v by rw [eq]; exact mem_insert_self _ _)
  have ff := Repair.edge_info G (show f ∈ Repair.linkEdges G v by rw [eq]; exact mem_insert_of_mem (mem_singleton_self _))
  have positive {p : Finset V} (pe : p ∈ Repair.linkEdges G v) {w : V} (wp : w ∈ p) : 0 < trianglesAt G w := by
    obtain ⟨inside,sz,cl⟩ := Repair.edge_info G pe
    obtain ⟨a,ap,aw⟩ := exists_ne_of_one_lt_card (by omega : 1<p.card) w
    exact (TrianglePrune.triangle_iff G w).mpr ⟨v,a,((G.mem_neighborFinset _ _).mp (inside wp)).symm,
      cl w wp a ap aw.symm,(G.mem_neighborFinset _ _).mp (inside ap)⟩
  have support : (G.neighborFinset v).erase l=e∪f := by
    ext w
    constructor
    · intro m
      obtain ⟨wl,vw⟩ := mem_erase.mp m
      have pos : 0 < trianglesAt G w := Nat.pos_of_ne_zero (fun z => wl (normal.1 w l z lz))
      obtain ⟨a,va,wa⟩ := normal.2.2 v w ((G.mem_neighborFinset _ _).mp vw) (by omega) pos
      have link : ({w,a} : Finset V) ∈ Repair.linkEdges G v := by
        refine mem_filter.mpr ⟨mem_powersetCard.mpr ⟨insert_subset vw (singleton_subset_iff.mpr ((G.mem_neighborFinset _ _).mpr va)),card_pair wa.ne⟩,?_⟩
        intro z hz z' hz' diff
        simp only [mem_insert,mem_singleton] at hz hz'
        rcases hz with rfl|rfl <;> rcases hz' with rfl|rfl <;> first | exact (diff rfl).elim | exact wa | exact wa.symm
      rw [eq,mem_insert,mem_singleton] at link
      rcases link with h|h
      · exact mem_union_left _ (h ▸ mem_insert_self _ _)
      · exact mem_union_right _ (h ▸ mem_insert_self _ _)
    · intro m
      have occ : ∃ p ∈ Repair.linkEdges G v, w ∈ p := by
        rw [eq]
        rcases mem_union.mp m with m|m
        · exact ⟨e,mem_insert_self _ _,m⟩
        · exact ⟨f,mem_insert_of_mem (mem_singleton_self _),m⟩
      obtain ⟨p,pe,wp⟩ := occ
      exact mem_erase.mpr ⟨fun eq => by have := positive pe wp; rw [eq,lz] at this; omega,(Repair.edge_info G pe).1 wp⟩
  have ec := ee.2.1
  have fc := ff.2.1
  have icap : (e∩f).card ≤ 1 := by
    by_contra! big
    have sub := eq_of_subset_of_card_le (show e∩f ⊆ e from inter_subset_left) (by omega : e.card≤(e∩f).card)
    have inc : e ⊆ f := sub ▸ inter_subset_right
    exact ne (eq_of_subset_of_card_le inc (by omega))
  have un : (e∪f).card=(if Disjoint e f then 4 else 3) := by
    have sum := card_union_add_card_inter e f
    split_ifs with dis
    · rw [disjoint_iff_inter_eq_empty.mp dis,card_empty] at sum; omega
    · obtain ⟨w,we,wf⟩ := not_disjoint_iff.mp dis
      have pos := card_pos.mpr (show (e∩f).Nonempty from ⟨w,mem_inter.mpr ⟨we,wf⟩⟩)
      omega
  refine ⟨e,f,ne,eq,ee.2.1,ff.2.1,support,?_⟩
  have sz := congrArg card support
  rw [un] at sz
  rw [← card_neighborFinset_eq_degree]
  by_cases adj : G.Adj v l
  · rw [card_erase_of_mem ((G.mem_neighborFinset _ _).mpr adj)] at sz
    have pos := card_pos.mpr (show (G.neighborFinset v).Nonempty from ⟨l,(G.mem_neighborFinset _ _).mpr adj⟩)
    rw [if_pos adj]; omega
  · rw [erase_eq_of_not_mem (fun mem => adj ((G.mem_neighborFinset _ _).mp mem))] at sz
    simpa only [if_neg adj,Nat.add_zero] using sz

end Graffiti384b.TwoLinks35
#print axioms Graffiti384b.TwoLinks35.shape
