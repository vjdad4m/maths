import PrivatePatch
namespace Graffiti384b.Exterior
open Finset SimpleGraph Four29 LowSample FiveChoice
open private LowSample.two_degree from LowSample384b
open private Remaining29.account from Remaining29
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

/-- Once the four roots are specified as distinct high vertices, all the
sampling and triangle-rank data hold in the profile unconditionally. -/
private theorem profile_data (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ne : e≠f)
    (wh : roots G e f⊆high G) (size : (roots G e f).card=4) : Data G e f := by
  classical
  have ear {x : V} (d : G.degree x=2) : x∈twos G := by simp [twos,nonleaves,high,d]
  have sub : ({e,f}:Finset V)⊆twos G := insert_subset (ear de) (singleton_subset_iff.mpr (ear df))
  have ec := Remaining29.account G
  have eset := eq_of_subset_of_card_le sub (by rw [card_pair ne]; omega)
  have xs : (pool G e f).card=23 := by rw [pool,card_sdiff wh,h,size]
  have xh : pool G e f⊆high G := sdiff_subset
  obtain ⟨inj,rich,_,_⟩ := Repair.maximal_diversity G (by omega)
  have ns (z : V) (ze : z∈({e,f}:Finset V)) : G.neighborFinset z⊆roots G e f := by
    rcases mem_insert.mp ze with rfl|zf
    · exact subset_union_left
    · rw [mem_singleton.mp zf]; exact subset_union_right
  refine ⟨eset.symm,wh,size,xs,inj,rich,inj.mono xh,fun _ vm => rich _ (xh vm),
    disjoint_left.mpr (fun _ ze zx => (mem_sdiff.mp (sub ze)).2 (xh zx)),
    fun z ze _ vx zv => (mem_sdiff.mp vx).2 (ns z ze ((G.mem_neighborFinset ..).mpr zv)),?_,
    fun _ ze => (LowSample.two_degree G (sub ze)).ge⟩
  intro z ze u ue zu
  exact (mem_sdiff.mp (sub ue)).2 (wh (ns z ze ((G.mem_neighborFinset ..).mpr zu)))

/-- Every protected pin has degree at least two. Outside the roots, the two
ears, and the private ports, all pins therefore belong to the further pool. -/
private theorem outside_in_pool {e f : V} (D : Data G e f) (L R S : Finset V)
    (cut : Protected G L R) :
    (L∪R)\(roots G e f∪{e,f}∪S)⊆(L∪R)∩(pool G e f\S) := by
  intro v vm
  obtain ⟨m,o⟩ := mem_sdiff.mp vm
  have highV : v∈high G := by
    have two (A : Finset V) (ok : 2≤nbr G v A) : 2≤G.degree v := by
      have inc : A.filter (G.Adj v)⊆G.neighborFinset v := fun _ i => (G.mem_neighborFinset ..).mpr (mem_filter.mp i).2
      exact (ok.trans (card_le_card inc)).trans_eq (card_neighborFinset_eq_degree ..)
    have vn : v∈nonleaves G := mem_filter.mpr ⟨mem_univ _,(mem_union.mp m).elim (fun z => two _ (cut.2.1 _ z)) (fun z => two _ (cut.2.2 _ z))⟩
    by_contra no
    have tv : v∈twos G := mem_sdiff.mpr ⟨vn,no⟩
    exact o (mem_union_left _ (mem_union_right _ (D.earSet ▸ tv)))
  exact mem_inter.mpr ⟨m,mem_sdiff.mpr ⟨mem_sdiff.mpr ⟨highV,fun r => o (mem_union_left _ (mem_union_left _ r))⟩,fun z => o (mem_union_right _ z)⟩⟩

/-- Unconditional three-pin existence in the exact four-high-anchor profile.
The region counted here is the full complement of the roots, ears, and ports. -/
theorem three_pin_cut (t : (types G).card=29) (q : (nonleaves G).card=29) (h : (high G).card=27)
    {e f : V} (de : G.degree e=2) (df : G.degree f=2) (ef : e≠f)
    (rh : roots G e f⊆high G) (rs : (roots G e f).card=4)
    (P Q : Finset V) {a x y : V} (xy : x≠y) (xp : x∈pool G e f) (yp : y∈pool G e f)
    (ar : a∈roots G e f) (tight : trianglesAt G a=2)
    (H : Ports G P Q {x,y} (pool G e f\{x,y}) a)
    (rootOnly : ∀p∈({x,y}:Finset V),∀r∈roots G e f,G.Adj p r → r=a)
    (privatePort : ∀p∈({x,y}:Finset V),∀r∈triangleContacts G e f,G.Adj p r → r∈({x,y}:Finset V)) :
    ∃L R : Finset V,P⊆L ∧ Q⊆R ∧ Protected G L R ∧ ((L∪R)\(roots G e f∪{e,f}∪{x,y})).card≤3 := by
  classical
  have D := profile_data G t q h de df ef rh rs
  obtain ⟨loss,off⟩ := local_conditions G D xp yp ar rootOnly privatePort
  obtain ⟨L,R,pl,qr,good,budget⟩ := cut_from_data G D P Q xy xp yp (rh ar) tight H loss off
  exact ⟨L,R,pl,qr,good,(card_le_card (outside_in_pool G D L R {x,y} good)).trans budget⟩
end Graffiti384b.Exterior
#print axioms Graffiti384b.Exterior.three_pin_cut
