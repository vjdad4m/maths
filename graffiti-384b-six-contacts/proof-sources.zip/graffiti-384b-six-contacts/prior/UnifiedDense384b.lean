import LowerBoundary384b
import UnifiedSample384b

namespace Graffiti384b.UnifiedDense
open Finset SimpleGraph CliqueChoice CliqueSample LowSample
open private Repair.triangles_le_choose from Repair384b
open private FiniteRange.bad FiniteRange.count_bad from FiniteRange384b
open private LowSample.delta LowSample.weight from LowSample384b
variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

def cutoff (h : ℕ) (f : Finset ℕ) := if h=34 ∨ 4∈f then 7 else 8
def cap (d : ℕ) := if d=6 then 13 else if d=7 then 18 else if d=8 then 24 else d.choose 2
def limit (h : ℕ) (f : Finset ℕ) (j : ℕ) :=
  let a := slots f j Boundary.levels
  let n := if j≤cutoff h f then min a (cap j+1) else a
  min (h-f.card) (h+n-35-(f.filter (· ≤ j)).card)

private def batch (h : ℕ) (f : Finset ℕ) := if h=34 ∨ f=∅ then 13 else 12
private def Row (h : ℕ) (f : Finset ℕ) :=
  let m := h-f.card
  let b := batch h f
  12 ≤ m ∧ 2 ≤ b ∧ envelope m b ∧ reward m b ∧
    6*(17*m.choose b + UnifiedSample.chargeAt m b (limit h f)) <
    6*(m-b)*m.choose b + (35-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d)

set_option maxRecDepth 32768 in
private theorem rows {h : ℕ} {f : Finset ℕ} (hh : h=33 ∨ h=34) (rem : LowerProfiles.residual 35 h f) :
    Row h f := by
  rcases hh with rfl|rfl <;>
    simp [LowerProfiles.residual] at rem <;>
    rcases rem with rfl|rfl|rfl <;>
    unfold Row UnifiedSample.chargeAt envelope reward LowSample.delta LowSample.weight bonus FiniteRange.badCount <;>
    simp only [FiniteRange.badCount,Nat.choose_eq_fast_choose] <;> decide

private theorem mono : ∀ d j : Fin 9, d.val ≤ j.val → cap d ≤ cap j := by decide

private theorem distribution {p : Finset V} (ch : Choice G p Boundary.levels) (t : (types G).card=35)
    (localBound : ∀ v, G.degree v ≤ cutoff (high G).card (p.image (G.degree ·)) → trianglesAt G v ≤ cap (G.degree v))
    (j : ℕ) (hj : 3 ≤ j) :
    ((high G \ p).filter (fun v => G.degree v ≤ j)).card ≤ limit (high G).card (p.image (G.degree ·)) j := by
  let h := (high G).card
  let f := p.image (G.degree ·)
  let s := high G \ p
  let a := (high G).filter (fun v => G.degree v ≤ j)
  let b := p.filter (fun v => G.degree v ≤ j)
  have size : s.card=h-f.card := by dsimp [s,h,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  have prof := CliqueChoice.profile G ch j hj
  dsimp only at prof
  rw [t] at prof
  change (s.filter _).card+35+(f.filter (· ≤ j)).card ≤ h+slots f j Boundary.levels at prof
  have count := card_filter_le s (fun v => G.degree v ≤ j)
  change (s.filter _).card ≤ _
  unfold limit
  change (s.filter (fun v => G.degree v ≤ j)).card ≤ min (h-f.card) (h+(if j≤cutoff h f then min (slots f j Boundary.levels) (cap j+1) else slots f j Boundary.levels) -35-(f.filter (· ≤ j)).card)
  apply le_min (count.trans_eq size)
  split_ifs with small
  · have j9 : j<9 := by unfold cutoff at small; split_ifs at small <;> omega
    have cover : types G ⊆ ((high G)\a).image (trianglesAt G) ∪ range (cap j+1) := by
      intro z hz
      obtain ⟨v,_,rfl⟩ := mem_image.mp hz
      by_cases vd : G.degree v ≤ j
      · apply mem_union_right
        apply mem_range.mpr
        have bounded := localBound v (vd.trans small)
        have step := mono ⟨G.degree v,by omega⟩ ⟨j,j9⟩ vd
        exact Nat.lt_succ_of_le (bounded.trans step)
      · apply mem_union_left
        exact mem_image.mpr ⟨v,mem_sdiff.mpr ⟨mem_filter.mpr ⟨mem_univ _,by omega⟩,
          fun eq => vd (mem_filter.mp eq).2⟩,rfl⟩
    have possible := (card_le_card cover).trans (card_union_le _ _)
    rw [t,card_range] at possible
    have distinct := card_image_le (s := high G \ a) (f := trianglesAt G)
    have total : (high G \ a).card+a.card=h := card_sdiff_add_card_eq_card (filter_subset _ _)
    have sub : b ⊆ a := fun w hw => mem_filter.mpr ⟨ch.high_sub (mem_filter.mp hw).1,(mem_filter.mp hw).2⟩
    have eq : s.filter (fun v => G.degree v ≤ j) = a\b := by ext v; simp only [s,a,b,mem_filter,mem_sdiff]; tauto
    have im : b.image (G.degree ·) = f.filter (· ≤ j) := by ext d; simp [b,f]; aesop
    have bs : b.card=(f.filter (· ≤ j)).card := by
      rw [← im,card_image_of_injOn (ch.unique.mono (show (b : Set V) ⊆ p from filter_subset _ _))]
    have join := card_sdiff_add_card_eq_card sub
    rw [← eq,bs] at join
    omega
  · omega

/-- At order 36 the five profiles uniformly force a nearly complete closed
neighborhood. The degree cutoff improves to seven in three profiles. -/
theorem dense_vertex {p : Finset V} (ch : Choice G p Boundary.levels)
    (t : (types G).card=35) (q : 35 ≤ (nonleaves G).card)
    (hh : (high G).card=33 ∨ (high G).card=34) (fail : bound G < gamma G) :
    ∃ v, 6 ≤ G.degree v ∧ G.degree v ≤ cutoff (high G).card (p.image (G.degree ·)) ∧
      cap (G.degree v) < trianglesAt G v := by
  let h := (high G).card
  let f := p.image (G.degree ·)
  let m := h-f.card
  let b := batch h f
  have mem : (high G).card ∈ ({33,34} : Finset ℕ) := by simpa using hh
  have rem := LowerProfiles.saturated_profiles G ch t mem 35 (by decide) q fail
  obtain ⟨room,two,env,rew,win⟩ := rows hh rem
  change 12 ≤ m at room
  by_contra! no
  have localBound (v : V) (deg : G.degree v ≤ cutoff h f) : trianglesAt G v ≤ cap (G.degree v) := by
    by_cases six : 6 ≤ G.degree v
    · exact no v six deg
    · simpa [cap,show G.degree v≠6 by omega,show G.degree v≠7 by omega,show G.degree v≠8 by omega] using
        Repair.triangles_le_choose G v
  have size : (high G \ p).card=m := by dsimp [m,h,f]; rw [card_image_of_injOn ch.unique,card_sdiff ch.high_sub]
  have obs := UnifiedSample.extraObstruction G ch b (limit h f) (fun j _ pos => distribution G ch t localBound j pos)
    (fun _ => 0) (by intro v hv; rw [Nat.add_zero]; exact FiniteRange.count_bad G _ b _ v hv (min_le_left _ _) (by omega))
    two (size ▸ env) (size ▸ rew) fail
  dsimp only at obs
  simp only [sum_const_zero,Nat.mul_zero,Nat.add_zero,t] at obs
  change 6*(m-b)*m.choose b + (twos G).card*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) ≤
    6*(17*m.choose b+UnifiedSample.chargeAt m b (limit h f)) at obs
  change 6*(17*m.choose b+UnifiedSample.chargeAt m b (limit h f)) <
    6*(m-b)*m.choose b + (35-h)*(6*(m-2).choose (b-2)) + 6*(∑ d ∈ f, bonus m b d) at win
  have sub : high G ⊆ nonleaves G := by
    intro v hv; exact mem_filter.mpr ⟨mem_univ _,by have := (mem_filter.mp hv).2; omega⟩
  have sum : (twos G).card+h=(nonleaves G).card := card_sdiff_add_card_eq_card sub
  have val := Nat.mul_le_mul_right (6*(m-2).choose (b-2)) (show 35-h ≤ (twos G).card by omega)
  omega

end Graffiti384b.UnifiedDense
#print axioms Graffiti384b.UnifiedDense.dense_vertex
