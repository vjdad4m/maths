import Q10MaskKernel384b
namespace Graffiti384b.Q10
open Finset

def forced2 (E : Rel) (v a b : Label) : Bool :=
  decide (a≠b) && E v a && E v b

def onPentad (E : Rel) (v a b c d e : Label) : Bool :=
  forced2 E v a b || forced2 E v a c || forced2 E v a d ||
  forced2 E v b c || forced2 E v b d || forced2 E v c d || forced2 E v a e ||
  forced2 E v b e || forced2 E v c e || forced2 E v d e

def fastEffective (lo hi : Rel) (a b c d e : Label) : Prop :=
  ∀ v : Label,v∉D5 a b c d e→ onPentad lo v a b c d e=true ∨
    (∀ w : Label,w∉D5 a b c d e→hi v w=false)

instance (lo hi : Rel) (a b c d e : Label) : Decidable (fastEffective lo hi a b c d e) := by
  unfold fastEffective
  infer_instance

theorem fastEffective_sound {lo hi : Rel} {a b c d e : Label} (f : fastEffective lo hi a b c d e) :
    Effective lo hi a b c d e := by
  intro v hv
  rcases f v hv with h|h
  · left
    have mem (x : Label) (hx : x=a ∨ x=b ∨ x=c ∨ x=d ∨ x=e) : x∈D5 a b c d e := by
      simpa [D5] using hx
    have get (x y : Label) (ok : forced2 lo v x y=true)
        (hx : x∈D5 a b c d e) (hy : y∈D5 a b c d e) :
        ∃ i j : Label,i∈D5 a b c d e ∧ j∈D5 a b c d e ∧ i≠j ∧ lo v i=true ∧ lo v j=true := by
      simp only [forced2,Bool.and_eq_true,decide_eq_true_eq] at ok
      exact ⟨x,y,hx,hy,ok.1.1,ok.1.2,ok.2⟩
    unfold onPentad at h
    simp only [Bool.or_eq_true,or_assoc] at h
    have am := mem a (Or.inl rfl)
    have bm := mem b (Or.inr (Or.inl rfl))
    have cm := mem c (Or.inr (Or.inr (Or.inl rfl)))
    have dm := mem d (Or.inr (Or.inr (Or.inr (Or.inl rfl))))
    have em := mem e (Or.inr (Or.inr (Or.inr (Or.inr rfl))))
    rcases h with k|k|k|k|k|k|k|k|k|k
    · exact get a b k am bm
    · exact get a c k am cm
    · exact get a d k am dm
    · exact get b c k bm cm
    · exact get b d k bm dm
    · exact get c d k cm dm
    · exact get a e k am em
    · exact get b e k bm em
    · exact get c e k cm em
    · exact get d e k dm em
  · exact Or.inr h

def fastReason (lo hi : Rel) : Reason→Bool
  | .cover a b c d e => decide (fastEffective lo hi a b c d e)
  | other => decide (validReason lo hi other)

theorem fastReason_sound {lo hi : Rel} (r : Reason) (h : fastReason lo hi r=true) :
    validReason lo hi r := by
  cases r with
  | cover a b c d e => exact fastEffective_sound (of_decide_eq_true h)
  | small | unordered | drop | interval => exact of_decide_eq_true h

def fastTreeOK (s : Shape) (on off : Nat) : Tree→Bool
  | .tip r => fastReason (lo s on) (hi s off) r
  | .split i no yes => fastTreeOK s on (off ||| 2^i) no && fastTreeOK s (on ||| 2^i) off yes

theorem fastTree_sound (s : Shape) (on off : Nat) (T : Tree) (h : fastTreeOK s on off T=true) :
    treeOK s on off T=true := by
  induction T generalizing on off with
  | tip r => exact decide_eq_true (fastReason_sound r h)
  | split i N Y ihN ihY =>
    simp only [fastTreeOK,Bool.and_eq_true] at h
    simp only [treeOK,Bool.and_eq_true]
    exact ⟨ihN _ _ h.1,ihY _ _ h.2⟩

theorem checked_fastTree (s : Shape) (b : Nat→Bool) (H : Ranked (adj s b)) (T : Tree)
    (valid : fastTreeOK s 0 0 T=true) : ∃ a c d e f,Effective (adj s b) (adj s b) a c d e f :=
  checked_tree s b H T (fastTree_sound s 0 0 T valid)

#print axioms checked_fastTree
end Graffiti384b.Q10
