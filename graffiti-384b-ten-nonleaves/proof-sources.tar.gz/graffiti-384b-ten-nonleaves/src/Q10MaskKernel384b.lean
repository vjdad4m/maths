import Proof384b
import Mathlib.Data.Fin.VecNotation

namespace Graffiti384b.Q10
open Finset
set_option linter.unusedSectionVars false
set_option maxRecDepth 100000
set_option maxHeartbeats 4000000

structure Shape where
  edge01 : Bool
  d0 : ℕ
  d1 : ℕ
  common : ℕ

def forms : Fin 29 → Shape :=
  ![⟨false,5,5,2⟩,⟨false,5,5,3⟩,⟨false,5,5,4⟩,⟨false,6,5,3⟩,⟨false,6,5,4⟩,⟨false,6,6,4⟩,⟨false,7,5,4⟩,⟨true,5,5,0⟩,⟨true,5,5,1⟩,⟨true,5,5,2⟩,⟨true,5,5,3⟩,⟨true,5,5,4⟩,⟨true,6,5,1⟩,⟨true,6,5,2⟩,⟨true,6,5,3⟩,⟨true,6,5,4⟩,⟨true,6,6,2⟩,⟨true,6,6,3⟩,⟨true,6,6,4⟩,⟨true,7,5,2⟩,⟨true,7,5,3⟩,⟨true,7,5,4⟩,⟨true,7,6,3⟩,⟨true,7,6,4⟩,⟨true,7,7,4⟩,⟨true,8,5,3⟩,⟨true,8,5,4⟩,⟨true,8,6,4⟩,⟨true,9,5,4⟩]

def slot (i j : Nat) : Nat := ((i-2)*(17-i))/2 + (j-i-1)

def anchorZero (s : Shape) (r : Nat) : Bool :=
  decide (r<s.d0-(if s.edge01 then 1 else 0))

def anchorOne (s : Shape) (r : Nat) : Bool :=
  let a := s.d0-(if s.edge01 then 1 else 0)
  let b := s.d1-(if s.edge01 then 1 else 0)
  decide (r<s.common ∨ (a≤r ∧ r<a+b-s.common))

def adj (s : Shape) (b : Nat→Bool) (u v : Fin 10) : Bool :=
  let i := min u.val v.val
  let j := max u.val v.val
  if i=j then false else
  if i=0 then if j=1 then s.edge01 else anchorZero s (j-2)
  else if i=1 then anchorOne s (j-2)
  else b (slot i j)

theorem adj_mono {s : Shape} {a b : Nat→Bool}
    (h : ∀ j,a j=true→b j=true) (i j : Fin 10) :
    adj s a i j=true→adj s b i j=true := by
  dsimp [adj]
  split <;> (try exact id)
  split <;> (try exact id)
  split
  · exact id
  · exact h _

abbrev Label := Fin 10
abbrev Rel := Label→Label→Bool

def orderedPairs : List (Label × Label) :=
  (List.ofFn (fun i : Label=>i)).flatMap fun i =>
    ((List.ofFn (fun j : Label=>j)).filter (fun j=>decide (i<j))).map fun j=>(i,j)

def score (E : Rel) (v : Label) : Nat :=
  (orderedPairs.filter fun ij=>E v ij.1 && E v ij.2 && E ij.1 ij.2).length

private theorem length_filter_mono {α : Type} (a b : α→Bool) (l : List α)
    (inc : ∀ x,a x=true→b x=true) : (l.filter a).length≤(l.filter b).length := by
  induction l with
  | nil => simp
  | cons x xs ih =>
    by_cases h : a x=true
    · simp [List.filter_cons,h,inc _ h,ih]
    · have z : a x=false := Bool.eq_false_iff.mpr h
      cases e : b x <;> simp [List.filter_cons,z,e] <;> omega

theorem score_mono {E F : Rel} (h : ∀ i j,E i j=true→F i j=true) (v : Label) :
    score E v≤score F v := by
  unfold score
  apply length_filter_mono
  intro z hz
  simp only [Bool.and_eq_true] at hz ⊢
  exact ⟨⟨h _ _ hz.1.1,h _ _ hz.1.2⟩,h _ _ hz.2⟩

def palette (E : Rel) : Finset Nat := (univ.filter fun i=>0<score E i).image (score E)

theorem palette_drop {E : Rel} (S : Finset Label)
    (redundant : ∀ v∈S, 0<score E v→∃ w∉S, score E w=score E v) :
    (palette E).card≤10-S.card := by
  let T : Finset Label := univ \ S
  have sub : palette E ⊆ T.image (score E) := by
    intro n hn
    obtain ⟨v,hv,rfl⟩ := mem_image.mp hn
    by_cases hs : v ∈ S
    · obtain ⟨w,hw,he⟩ := redundant v hs (mem_filter.mp hv).2
      exact mem_image.mpr ⟨w,by simp [T,hw],he⟩
    · exact mem_image.mpr ⟨v,by simp [T,hs],rfl⟩
  exact (card_le_card sub).trans (card_image_le.trans_eq (card_sdiff (subset_univ _)))

def band (lo hi : Rel) (l u : Nat) : Finset Label :=
  univ.filter fun i=>l≤score lo i ∧ score hi i<l+u

theorem palette_interval {lo E hi : Rel} (L : ∀ i j,lo i j=true→E i j=true)
    (U : ∀ i j,E i j=true→hi i j=true) (l u : Nat)
    (hv : u+2<(band lo hi l u).card) : (palette E).card ≤ 7 := by
    let S := band lo hi l u
    let T : Finset Label := univ \ S
    let I := Ico l (l+u)
    have sub : palette E ⊆ I ∪ (T.image (score E)) := by
      intro k hk
      obtain ⟨v,hv,rfl⟩ := Finset.mem_image.mp hk
      by_cases hs : v ∈ S
      · apply mem_union_left
        obtain ⟨hl,hh⟩ := (mem_filter.mp hs).2
        exact mem_Ico.mpr ⟨hl.trans (score_mono L v),lt_of_le_of_lt (score_mono U v) hh⟩
      · exact mem_union_right _ (mem_image.mpr ⟨v, by simp [T,hs], rfl⟩)
    have cardT : T.card = 10-S.card := by
      simpa [T] using Finset.card_sdiff (Finset.subset_univ S)
    have cardI : I.card = u := by simp [I,Nat.card_Ico]
    have all : (palette E).card ≤ I.card + T.card := (card_le_card sub).trans
      ((card_union_le _ _).trans (Nat.add_le_add_left card_image_le _))
    have hS : S.card≤10 := card_le_univ _
    change u+2<S.card at hv
    omega

def D5 (a b c d e : Label) : Finset Label := {a,b,c,d,e}

def Effective (lo hi : Rel) (a b c d e : Label) : Prop :=
  ∀ v : Label, v ∉ D5 a b c d e →
    (∃ x y : Label, x ∈ D5 a b c d e ∧ y ∈ D5 a b c d e ∧ x≠y ∧
      lo v x=true ∧ lo v y=true) ∨
    (∀ w : Label, w ∉ D5 a b c d e → hi v w=false)

instance (lo hi : Rel) (a b c d e : Label) : Decidable (Effective lo hi a b c d e) := by
  unfold Effective
  infer_instance

def anchor (r : Fin 2) : Label := ⟨r.val,by have := r.isLt; omega⟩

structure Ranked (E : Rel) : Prop where
  palette_large : 8≤(palette E).card
  large : ∀ r : Fin 2, 7≤score E (anchor r)
  top : ∀ (a b c : Label), 2≤a.val→2≤b.val→2≤c.val→a≠b→a≠c→b≠c→∀ (r : Fin 2),
    ¬ (score E (anchor r)≤score E a ∧ score E (anchor r)≤score E b ∧ score E (anchor r)≤score E c)

def dropOK (lo hi : Rel) (S : Finset Label) (v : Label) : Option Label→Prop
  | none => score hi v=0
  | some w => w∉S ∧ score lo v=score hi v ∧ score lo w=score hi w ∧ score lo v=score lo w

instance (lo hi : Rel) (S : Finset Label) (v : Label) (o : Option Label) : Decidable (dropOK lo hi S v o) := by
  cases o <;> unfold dropOK <;> infer_instance

inductive Reason
  | small (r : Fin 2)
  | unordered (a b c : Label) (r : Fin 2)
  | drop (a b c : Label) (v w z : Option Label)
  | cover (a b c d e : Label)
  | interval (l u : Nat)

def validReason (lo hi : Rel) : Reason→Prop
  | .small r => score hi (anchor r)<7
  | .unordered a b c r => 2≤a.val ∧ 2≤b.val ∧ 2≤c.val ∧ a≠b ∧ a≠c ∧ b≠c ∧
      score hi (anchor r)≤score lo a ∧ score hi (anchor r)≤score lo b ∧ score hi (anchor r)≤score lo c
  | .drop a b c v w z => let S : Finset Label := {a,b,c}
    a≠b ∧ a≠c ∧ b≠c ∧ dropOK lo hi S a v ∧ dropOK lo hi S b w ∧ dropOK lo hi S c z
  | .cover a b c d e => Effective lo hi a b c d e
  | .interval l u => u+2<(band lo hi l u).card

instance (lo hi : Rel) (r : Reason) : Decidable (validReason lo hi r) := by
  cases r <;> unfold validReason <;> infer_instance

theorem reason_sound {lo E hi : Rel} (H : Ranked E)
    (L : ∀ i j,lo i j=true→E i j=true) (U : ∀ i j,E i j=true→hi i j=true)
    (r : Reason) (valid : validReason lo hi r) : ∃ a b c d e, Effective E E a b c d e := by
  have low := score_mono L
  have high := score_mono U
  cases r with
  | small j =>
    have x := H.large j
    have y := high (anchor j)
    unfold validReason at valid
    omega
  | unordered a b c j =>
    obtain ⟨ha,hb,hc,ab,ac,bc,ha',hb',hc'⟩ := valid
    exact (H.top a b c ha hb hc ab ac bc j ⟨(high _).trans (ha'.trans (low _)),
      (high _).trans (hb'.trans (low _)),(high _).trans (hc'.trans (low _))⟩).elim
  | drop a b c v w z =>
    obtain ⟨ab,ac,bc,av,bw,cz⟩ := valid
    let S : Finset Label := {a,b,c}
    have transfer : ∀ u o, dropOK lo hi S u o → 0<score E u →
        ∃ q, q∉S ∧ score E q=score E u := by
      intro u o ok pos
      cases o with
      | none =>
        have hu := high u
        unfold dropOK at ok
        omega
      | some q =>
        obtain ⟨notS,uu,qq,uq⟩ := ok
        have h₁ := low u
        have h₂ := high u
        have h₃ := low q
        have h₄ := high q
        exact ⟨q,notS,by omega⟩
    have h := palette_drop (E:=E) S (by
      intro u hu hp
      simp only [S,mem_insert,mem_singleton] at hu
      rcases hu with rfl|rfl|rfl
      · exact transfer _ _ av hp
      · exact transfer _ _ bw hp
      · exact transfer _ _ cz hp)
    have sz : S.card=3 := by simp [S,ab,ac,bc]
    have := H.palette_large
    omega
  | cover a b c d e =>
    refine ⟨a,b,c,d,e,?_⟩
    intro v hv
    rcases valid v hv with ⟨x,y,hx,hy,hn,ex,ey⟩ | off
    · exact Or.inl ⟨x,y,hx,hy,hn,L _ _ ex,L _ _ ey⟩
    · exact Or.inr (fun w hw=>Bool.eq_false_iff.mpr (fun et=>by
        have et' := U _ _ et
        simp [off w hw] at et'))
  | interval l u =>
    have h := palette_interval L U l u valid
    have := H.palette_large
    omega

inductive Tree
  | tip (r : Reason)
  | split (i : Nat) (no yes : Tree)

def lo (s : Shape) (on : Nat) : Rel := adj s (fun j=>on.testBit j)
def hi (s : Shape) (off : Nat) : Rel := adj s (fun j=>!off.testBit j)

def treeOK (s : Shape) (on off : Nat) : Tree→Bool
  | .tip r => decide (validReason (lo s on) (hi s off) r)
  | .split i no yes => treeOK s on (off ||| 2^i) no && treeOK s (on ||| 2^i) off yes

theorem tree_sound (s : Shape) (b : Nat→Bool) (H : Ranked (adj s b))
    (T : Tree) (on off : Nat)
    (O : ∀ j,on.testBit j=true→b j=true)
    (Z : ∀ j,off.testBit j=true→b j=false)
    (valid : treeOK s on off T=true) : ∃ a c d e f,Effective (adj s b) (adj s b) a c d e f := by
  induction T generalizing on off with
  | tip r =>
    apply reason_sound H (adj_mono O) (adj_mono ?_) r (of_decide_eq_true valid)
    intro i bi
    change (!off.testBit i)=true
    cases e : off.testBit i
    · rfl
    · exact Bool.noConfusion (bi.symm.trans (Z i e))
  | split i no yes ihN ihY =>
    change (treeOK s on (off|||2^i) no && treeOK s (on|||2^i) off yes)=true at valid
    have both : treeOK s on (off|||2^i) no=true ∧ treeOK s (on|||2^i) off yes=true := by
      simpa only [Bool.and_eq_true] using valid
    obtain ⟨hn,hy⟩ := both
    cases v : b i
    · apply ihN on (off|||2^i) O ?_ hn
      intro j h
      rw [Nat.testBit_or,Bool.or_eq_true,Nat.testBit_two_pow,decide_eq_true_eq] at h
      rcases h with h|rfl
      · exact Z j h
      · exact v
    · apply ihY (on|||2^i) off ?_ Z hy
      intro j h
      rw [Nat.testBit_or,Bool.or_eq_true,Nat.testBit_two_pow,decide_eq_true_eq] at h
      rcases h with h|rfl
      · exact O j h
      · exact v

theorem checked_tree (s : Shape) (b : Nat→Bool) (H : Ranked (adj s b)) (T : Tree)
    (valid : treeOK s 0 0 T=true) : ∃ a c d e f,Effective (adj s b) (adj s b) a c d e f :=
  tree_sound s b H T 0 0 (by simp) (by simp) valid

#print axioms checked_tree
end Graffiti384b.Q10
