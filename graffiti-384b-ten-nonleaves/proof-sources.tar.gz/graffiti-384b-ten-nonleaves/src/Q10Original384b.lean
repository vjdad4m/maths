import Q9Original384b

namespace Graffiti384b.Q10Original
open Finset SimpleGraph Q9Original
open private Prune.outside_zero from Prune384b
open private Q8Original.triangle_comap from Q8Original384b

/-- A retained pentad closes the ten-core case for nine or ten triangle-count
types; an adaptive stronger quota also covers eleven types. -/
private theorem lift_retained_quota
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (ten : (nonleaves G).card = 10) (diverse : 9 ≤ (types G).card)
    (quota : ∀ (K : SimpleGraph (Fin 10)) (dk : DecidableRel K.Adj),
      letI := dk
      (types G).card ≤ (PositiveScores K).card+1 →
      8 ≤ (PositiveScores K).card →
        ∃ D : Finset (Fin 10), (types G).card+1 ≤ 2*(10-D.card)+1 ∧ Effective K D) :
    gamma G ≤ bound G := by
  classical
  let P := nonleaves G
  let H := G.induce (P : Set V)
  let e : Fin 10 ≃ P := (Fintype.equivFinOfCardEq ((Fintype.card_coe P).trans ten)).symm
  let K := H.comap (e : Fin 10→P)
  let dk : DecidableRel K.Adj := inferInstanceAs (DecidableRel (H.comap (e : Fin 10→P)).Adj)
  let f : Fin 10 ↪ V := e.toEmbedding.trans (Function.Embedding.subtype _)
  have finP (i : Fin 10) : f i ∈ P := (e i).property
  have allP (v : V) (hv : v∈P) : ∃ j, f j=v := by
    exact ⟨e.symm ⟨v,hv⟩,congrArg Subtype.val (e.apply_symm_apply ⟨v,hv⟩)⟩
  have score (i : Fin 10) : trianglesAt K i = trianglesAt G (f i) :=
    (Q8Original.triangle_comap H e i).trans (Prune.counts_preserved G P Subset.rfl (e i))
  have cover : types G ⊆ insert 0 (PositiveScores K) := by
    intro s hs
    obtain ⟨v,_,rfl⟩ := mem_image.mp hs
    by_cases z : trianglesAt G v = 0
    · rw [z]; exact mem_insert_self _ _
    have vp : v∈P := Classical.byContradiction fun no =>
      z (Prune.outside_zero G no)
    obtain ⟨i,hi⟩ := allP v vp
    have t : trianglesAt K i = trianglesAt G v := (score i).trans (congrArg (trianglesAt G) hi)
    apply mem_insert_of_mem
    exact mem_erase.mpr ⟨z,mem_image.mpr ⟨i,mem_univ _,t⟩⟩
  have cc := card_le_card cover
  have inc := card_insert_le 0 (PositiveScores K)
  have up : (PositiveScores K).card ≤ 10 :=
    (card_le_card (erase_subset _ _)).trans (card_image_le.trans_eq (by decide))
  obtain ⟨D,dcard,eff⟩ := quota K dk (by omega) (by omega)
  let O := Dᶜ.map f
  have ocard : (types G).card+1 ≤ 2*O.card+1 := by
    have eqn := card_compl D
    rw [Fintype.card_fin] at eqn
    change (types G).card+1 ≤ 2*(Dᶜ.map f).card+1
    rw [card_map,eqn]
    omega
  have sub : O ⊆ P := by
    intro v hv
    obtain ⟨i,_,rfl⟩ := mem_map.mp hv
    exact finP i
  have ambient_eff (v : V) (vo : v∈O) : 2 ≤ EffectiveSupport.capacity G P O v := by
    obtain ⟨i,hi,rfl⟩ := mem_map.mp vo
    have noD := mem_compl.mp hi
    rcases eff i noD with ⟨x,y,hx,hy,hxy,hix,hiy⟩ | none
    · have retain (j : Fin 10) (hj : j∈D) : f j∈P\O := by
        refine mem_sdiff.mpr ⟨finP j,?_⟩
        intro hm
        obtain ⟨k,km,eq⟩ := mem_map.mp hm
        exact mem_compl.mp km ((f.injective eq).symm ▸ hj)
      have card : 1 < ((P\O).filter (G.Adj (f i))).card :=
        one_lt_card.mpr ⟨f x,mem_filter.mpr ⟨retain x hx,hix⟩,
          f y,mem_filter.mpr ⟨retain y hy,hiy⟩,fun eq => hxy (f.injective eq)⟩
      unfold EffectiveSupport.capacity nbr
      omega
    · have zero : nbr G (f i) O = 0 := by
        unfold nbr
        rw [card_eq_zero]
        apply subset_empty.mp
        intro w hw
        obtain ⟨ho,ad⟩ := mem_filter.mp hw
        obtain ⟨j,hj,rfl⟩ := mem_map.mp ho
        exact False.elim (none j (mem_compl.mp hj) ad)
      have crit := EffectiveSupport.capacity_failure G P O sub (f i)
      omega
  have nonleaf (v : V) (vo : v∈O) : 2 ≤ G.degree v := (mem_filter.mp (sub vo)).2
  have g := EffectiveSupport.gamma_le_from_effective G P O sub nonleaf ambient_eff
  unfold bound
  omega

/-- A pentad gives five omissions, enough for nine or ten distinct types. -/
theorem nonleaf_ten_of_fin10_effective
    (quota : ∀ (K : SimpleGraph (Fin 10)) (dk : DecidableRel K.Adj),
      letI := dk
      8 ≤ (PositiveScores K).card →
        ∃ D : Finset (Fin 10), D.card ≤ 5 ∧ Effective K D)
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (ten : (nonleaves G).card = 10) (diverse : 9 ≤ (types G).card)
    (cap : (types G).card ≤ 10) :
    gamma G ≤ bound G := by
  apply lift_retained_quota G ten diverse
  intro K dk _ high
  obtain ⟨D,d,eff⟩ := quota K dk high
  exact ⟨D,by omega,eff⟩

/-- If all ten core scores are positive and distinct, allow a stronger finite
quota of four retained vertices to cover the eleven-type boundary as well. -/
theorem nonleaf_ten_of_fin10_adaptive
    (quota : ∀ (K : SimpleGraph (Fin 10)) (dk : DecidableRel K.Adj),
      letI := dk
      8 ≤ (PositiveScores K).card →
        ∃ D : Finset (Fin 10), D.card ≤ (if 10 ≤ (PositiveScores K).card then 4 else 5) ∧ Effective K D)
    {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]
    (ten : (nonleaves G).card = 10) (diverse : 9 ≤ (types G).card) :
    gamma G ≤ bound G := by
  apply lift_retained_quota G ten diverse
  intro K dk h high
  have kp : (PositiveScores K).card ≤ 10 :=
    (card_le_card (erase_subset _ _)).trans (card_image_le.trans_eq (by decide))
  obtain ⟨D,d,eff⟩ := quota K dk high
  refine ⟨D,?_,eff⟩
  by_cases large : 10 ≤ (PositiveScores K).card
  · rw [if_pos large] at d; omega
  · rw [if_neg large] at d; omega

end Graffiti384b.Q10Original

#print axioms Graffiti384b.Q10Original.nonleaf_ten_of_fin10_effective
#print axioms Graffiti384b.Q10Original.nonleaf_ten_of_fin10_adaptive
