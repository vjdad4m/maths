import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape0T3 : Tree := (.split 6 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))))))))
private theorem q10Shape0T3OK : fastTreeOK (forms 0) 0 49 q10Shape0T3=true := by decide

private def q10Shape0T5 : Tree := (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 8)))))))
private theorem q10Shape0T5OK : fastTreeOK (forms 0) 32 81 q10Shape0T5=true := by decide

private def q10Shape0T6 : Tree := (.split 10 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 4 5 6 8 9)))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))))) (.split 12 (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 8)))) (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6))))))
private theorem q10Shape0T6OK : fastTreeOK (forms 0) 96 17 q10Shape0T6=true := by decide

private def q10Shape0T4 : Tree := .split 6 q10Shape0T5 q10Shape0T6
private theorem q10Shape0T4OK : fastTreeOK (forms 0) 32 17 q10Shape0T4=true := by
  change (fastTreeOK (forms 0) 32 (17 ||| 2^6) q10Shape0T5 &&
    fastTreeOK (forms 0) (32 ||| 2^6) 17 q10Shape0T6)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T5OK,q10Shape0T6OK⟩

private def q10Shape0T2 : Tree := .split 5 q10Shape0T3 q10Shape0T4
private theorem q10Shape0T2OK : fastTreeOK (forms 0) 0 17 q10Shape0T2=true := by
  change (fastTreeOK (forms 0) 0 (17 ||| 2^5) q10Shape0T3 &&
    fastTreeOK (forms 0) (0 ||| 2^5) 17 q10Shape0T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T3OK,q10Shape0T4OK⟩

private def q10Shape0T9 : Tree := (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7)))))))
private theorem q10Shape0T9OK : fastTreeOK (forms 0) 16 97 q10Shape0T9=true := by decide

private def q10Shape0T10 : Tree := (.split 10 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9))))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7))))) (.split 12 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7)))) (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6))))))
private theorem q10Shape0T10OK : fastTreeOK (forms 0) 80 33 q10Shape0T10=true := by decide

private def q10Shape0T8 : Tree := .split 6 q10Shape0T9 q10Shape0T10
private theorem q10Shape0T8OK : fastTreeOK (forms 0) 16 33 q10Shape0T8=true := by
  change (fastTreeOK (forms 0) 16 (33 ||| 2^6) q10Shape0T9 &&
    fastTreeOK (forms 0) (16 ||| 2^6) 33 q10Shape0T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T9OK,q10Shape0T10OK⟩

private def q10Shape0T12 : Tree := (.split 10 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 8)))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7))))) (.split 12 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7)))) (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6))) (.tip (.cover 1 3 4 5 6))))))
private theorem q10Shape0T12OK : fastTreeOK (forms 0) 48 65 q10Shape0T12=true := by decide

private def q10Shape0T13 : Tree := (.split 1 (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 4 5))) (.tip (.cover 0 1 2 4 6))) (.tip (.cover 0 1 2 5 6)))
private theorem q10Shape0T13OK : fastTreeOK (forms 0) 112 1 q10Shape0T13=true := by decide

private def q10Shape0T11 : Tree := .split 6 q10Shape0T12 q10Shape0T13
private theorem q10Shape0T11OK : fastTreeOK (forms 0) 48 1 q10Shape0T11=true := by
  change (fastTreeOK (forms 0) 48 (1 ||| 2^6) q10Shape0T12 &&
    fastTreeOK (forms 0) (48 ||| 2^6) 1 q10Shape0T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T12OK,q10Shape0T13OK⟩

private def q10Shape0T7 : Tree := .split 5 q10Shape0T8 q10Shape0T11
private theorem q10Shape0T7OK : fastTreeOK (forms 0) 16 1 q10Shape0T7=true := by
  change (fastTreeOK (forms 0) 16 (1 ||| 2^5) q10Shape0T8 &&
    fastTreeOK (forms 0) (16 ||| 2^5) 1 q10Shape0T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T8OK,q10Shape0T11OK⟩

private def q10Shape0T1 : Tree := .split 4 q10Shape0T2 q10Shape0T7
private theorem q10Shape0T1OK : fastTreeOK (forms 0) 0 1 q10Shape0T1=true := by
  change (fastTreeOK (forms 0) 0 (1 ||| 2^4) q10Shape0T2 &&
    fastTreeOK (forms 0) (0 ||| 2^4) 1 q10Shape0T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T2OK,q10Shape0T7OK⟩

private def q10Shape0T17 : Tree := (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.tip (.cover 1 3 4 5 6)))))
private theorem q10Shape0T17OK : fastTreeOK (forms 0) 1 112 q10Shape0T17=true := by decide

private def q10Shape0T18 : Tree := (.split 10 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9))))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))))) (.split 12 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 3 4 5 6 9))))) (.tip (.cover 1 3 4 5 6)))))
private theorem q10Shape0T18OK : fastTreeOK (forms 0) 65 48 q10Shape0T18=true := by decide

private def q10Shape0T16 : Tree := .split 6 q10Shape0T17 q10Shape0T18
private theorem q10Shape0T16OK : fastTreeOK (forms 0) 1 48 q10Shape0T16=true := by
  change (fastTreeOK (forms 0) 1 (48 ||| 2^6) q10Shape0T17 &&
    fastTreeOK (forms 0) (1 ||| 2^6) 48 q10Shape0T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T17OK,q10Shape0T18OK⟩

private def q10Shape0T20 : Tree := (.split 10 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 8)))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 3 4 5 6 8))))) (.split 12 (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 8)))) (.tip (.cover 1 3 4 5 6)))))
private theorem q10Shape0T20OK : fastTreeOK (forms 0) 33 80 q10Shape0T20=true := by decide

private def q10Shape0T23 : Tree := (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9))))))
private theorem q10Shape0T23OK : fastTreeOK (forms 0) 97 3088 q10Shape0T23=true := by decide

private def q10Shape0T24 : Tree := (.split 12 (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 8)))) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 7)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 5 7)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 0 2 3 6 7))) (.tip (.cover 0 1 2 4 7)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 2 3 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 7)))))
private theorem q10Shape0T24OK : fastTreeOK (forms 0) 2145 1040 q10Shape0T24=true := by decide

private def q10Shape0T22 : Tree := .split 11 q10Shape0T23 q10Shape0T24
private theorem q10Shape0T22OK : fastTreeOK (forms 0) 97 1040 q10Shape0T22=true := by
  change (fastTreeOK (forms 0) 97 (1040 ||| 2^11) q10Shape0T23 &&
    fastTreeOK (forms 0) (97 ||| 2^11) 1040 q10Shape0T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T23OK,q10Shape0T24OK⟩

private def q10Shape0T26 : Tree := (.split 12 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 2 4 5 6 7)))) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 8)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 4 7)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 7)))))
private theorem q10Shape0T26OK : fastTreeOK (forms 0) 1121 2064 q10Shape0T26=true := by decide

private def q10Shape0T27 : Tree := (.split 12 (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 9)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 4 7)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 2 5 7))) (.tip (.cover 0 1 2 6 7)))) (.tip (.cover 1 3 4 5 6)))
private theorem q10Shape0T27OK : fastTreeOK (forms 0) 3169 16 q10Shape0T27=true := by decide

private def q10Shape0T25 : Tree := .split 11 q10Shape0T26 q10Shape0T27
private theorem q10Shape0T25OK : fastTreeOK (forms 0) 1121 16 q10Shape0T25=true := by
  change (fastTreeOK (forms 0) 1121 (16 ||| 2^11) q10Shape0T26 &&
    fastTreeOK (forms 0) (1121 ||| 2^11) 16 q10Shape0T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T26OK,q10Shape0T27OK⟩

private def q10Shape0T21 : Tree := .split 10 q10Shape0T22 q10Shape0T25
private theorem q10Shape0T21OK : fastTreeOK (forms 0) 97 16 q10Shape0T21=true := by
  change (fastTreeOK (forms 0) 97 (16 ||| 2^10) q10Shape0T22 &&
    fastTreeOK (forms 0) (97 ||| 2^10) 16 q10Shape0T25)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T22OK,q10Shape0T25OK⟩

private def q10Shape0T19 : Tree := .split 6 q10Shape0T20 q10Shape0T21
private theorem q10Shape0T19OK : fastTreeOK (forms 0) 33 16 q10Shape0T19=true := by
  change (fastTreeOK (forms 0) 33 (16 ||| 2^6) q10Shape0T20 &&
    fastTreeOK (forms 0) (33 ||| 2^6) 16 q10Shape0T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T20OK,q10Shape0T21OK⟩

private def q10Shape0T15 : Tree := .split 5 q10Shape0T16 q10Shape0T19
private theorem q10Shape0T15OK : fastTreeOK (forms 0) 1 16 q10Shape0T15=true := by
  change (fastTreeOK (forms 0) 1 (16 ||| 2^5) q10Shape0T16 &&
    fastTreeOK (forms 0) (1 ||| 2^5) 16 q10Shape0T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T16OK,q10Shape0T19OK⟩

private def q10Shape0T30 : Tree := (.split 10 (.split 11 (.tip (.small 1)) (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 3 4 5 6 7)))))) (.split 11 (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7))))) (.split 12 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7)))) (.tip (.cover 1 3 4 5 6)))))
private theorem q10Shape0T30OK : fastTreeOK (forms 0) 17 96 q10Shape0T30=true := by decide

private def q10Shape0T33 : Tree := (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9))))))
private theorem q10Shape0T33OK : fastTreeOK (forms 0) 81 3104 q10Shape0T33=true := by decide

private def q10Shape0T34 : Tree := (.split 12 (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 2 4 5 6 8)))) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 7)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 4 8)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 1 2 6 8)))))
private theorem q10Shape0T34OK : fastTreeOK (forms 0) 2129 1056 q10Shape0T34=true := by decide

private def q10Shape0T32 : Tree := .split 11 q10Shape0T33 q10Shape0T34
private theorem q10Shape0T32OK : fastTreeOK (forms 0) 81 1056 q10Shape0T32=true := by
  change (fastTreeOK (forms 0) 81 (1056 ||| 2^11) q10Shape0T33 &&
    fastTreeOK (forms 0) (81 ||| 2^11) 1056 q10Shape0T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T33OK,q10Shape0T34OK⟩

private def q10Shape0T36 : Tree := (.split 12 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7)))) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 8)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 5 8)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 0 1 2 4 8)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 2 3 6 8))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 1 2 6 8)))))
private theorem q10Shape0T36OK : fastTreeOK (forms 0) 1105 2080 q10Shape0T36=true := by decide

private def q10Shape0T37 : Tree := (.split 12 (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 9)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 4 8)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 1 2 6 8)))) (.tip (.cover 1 3 4 5 6)))
private theorem q10Shape0T37OK : fastTreeOK (forms 0) 3153 32 q10Shape0T37=true := by decide

private def q10Shape0T35 : Tree := .split 11 q10Shape0T36 q10Shape0T37
private theorem q10Shape0T35OK : fastTreeOK (forms 0) 1105 32 q10Shape0T35=true := by
  change (fastTreeOK (forms 0) 1105 (32 ||| 2^11) q10Shape0T36 &&
    fastTreeOK (forms 0) (1105 ||| 2^11) 32 q10Shape0T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T36OK,q10Shape0T37OK⟩

private def q10Shape0T31 : Tree := .split 10 q10Shape0T32 q10Shape0T35
private theorem q10Shape0T31OK : fastTreeOK (forms 0) 81 32 q10Shape0T31=true := by
  change (fastTreeOK (forms 0) 81 (32 ||| 2^10) q10Shape0T32 &&
    fastTreeOK (forms 0) (81 ||| 2^10) 32 q10Shape0T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T32OK,q10Shape0T35OK⟩

private def q10Shape0T29 : Tree := .split 6 q10Shape0T30 q10Shape0T31
private theorem q10Shape0T29OK : fastTreeOK (forms 0) 17 32 q10Shape0T29=true := by
  change (fastTreeOK (forms 0) 17 (32 ||| 2^6) q10Shape0T30 &&
    fastTreeOK (forms 0) (17 ||| 2^6) 32 q10Shape0T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T30OK,q10Shape0T31OK⟩

private def q10Shape0T41 : Tree := (.split 12 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 2 4 5 6 9))))))
private theorem q10Shape0T41OK : fastTreeOK (forms 0) 49 3136 q10Shape0T41=true := by decide

private def q10Shape0T42 : Tree := (.split 12 (.split 25 (.tip (.small 1)) (.split 27 (.tip (.small 1)) (.tip (.cover 1 4 5 6 8)))) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 7)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 4 9)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))))
private theorem q10Shape0T42OK : fastTreeOK (forms 0) 2097 1088 q10Shape0T42=true := by decide

private def q10Shape0T40 : Tree := .split 11 q10Shape0T41 q10Shape0T42
private theorem q10Shape0T40OK : fastTreeOK (forms 0) 49 1088 q10Shape0T40=true := by
  change (fastTreeOK (forms 0) 49 (1088 ||| 2^11) q10Shape0T41 &&
    fastTreeOK (forms 0) (49 ||| 2^11) 1088 q10Shape0T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T41OK,q10Shape0T42OK⟩

private def q10Shape0T44 : Tree := (.split 12 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 1 4 5 6 7)))) (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 8)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 4))) (.tip (.cover 0 1 2 3 5)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 3 4 6))) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 0 1 2 4 9)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 2 3 6))) (.tip (.cover 1 2 3 5 6))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))))
private theorem q10Shape0T44OK : fastTreeOK (forms 0) 1073 2112 q10Shape0T44=true := by decide

private def q10Shape0T45 : Tree := (.split 12 (.split 1 (.split 2 (.split 3 (.split 7 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 9)))) (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 5 9)))) (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 1 2 4 9)))) (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 2 3 5 6 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))) (.tip (.cover 1 3 4 5 6)))
private theorem q10Shape0T45OK : fastTreeOK (forms 0) 3121 64 q10Shape0T45=true := by decide

private def q10Shape0T43 : Tree := .split 11 q10Shape0T44 q10Shape0T45
private theorem q10Shape0T43OK : fastTreeOK (forms 0) 1073 64 q10Shape0T43=true := by
  change (fastTreeOK (forms 0) 1073 (64 ||| 2^11) q10Shape0T44 &&
    fastTreeOK (forms 0) (1073 ||| 2^11) 64 q10Shape0T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T44OK,q10Shape0T45OK⟩

private def q10Shape0T39 : Tree := .split 10 q10Shape0T40 q10Shape0T43
private theorem q10Shape0T39OK : fastTreeOK (forms 0) 49 64 q10Shape0T39=true := by
  change (fastTreeOK (forms 0) 49 (64 ||| 2^10) q10Shape0T40 &&
    fastTreeOK (forms 0) (49 ||| 2^10) 64 q10Shape0T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T40OK,q10Shape0T43OK⟩

private def q10Shape0T46 : Tree := (.tip (.cover 1 2 4 5 6))
private theorem q10Shape0T46OK : fastTreeOK (forms 0) 113 0 q10Shape0T46=true := by decide

private def q10Shape0T38 : Tree := .split 6 q10Shape0T39 q10Shape0T46
private theorem q10Shape0T38OK : fastTreeOK (forms 0) 49 0 q10Shape0T38=true := by
  change (fastTreeOK (forms 0) 49 (0 ||| 2^6) q10Shape0T39 &&
    fastTreeOK (forms 0) (49 ||| 2^6) 0 q10Shape0T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T39OK,q10Shape0T46OK⟩

private def q10Shape0T28 : Tree := .split 5 q10Shape0T29 q10Shape0T38
private theorem q10Shape0T28OK : fastTreeOK (forms 0) 17 0 q10Shape0T28=true := by
  change (fastTreeOK (forms 0) 17 (0 ||| 2^5) q10Shape0T29 &&
    fastTreeOK (forms 0) (17 ||| 2^5) 0 q10Shape0T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T29OK,q10Shape0T38OK⟩

private def q10Shape0T14 : Tree := .split 4 q10Shape0T15 q10Shape0T28
private theorem q10Shape0T14OK : fastTreeOK (forms 0) 1 0 q10Shape0T14=true := by
  change (fastTreeOK (forms 0) 1 (0 ||| 2^4) q10Shape0T15 &&
    fastTreeOK (forms 0) (1 ||| 2^4) 0 q10Shape0T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T15OK,q10Shape0T28OK⟩

private def q10Shape0T0 : Tree := .split 0 q10Shape0T1 q10Shape0T14
private theorem q10Shape0T0OK : fastTreeOK (forms 0) 0 0 q10Shape0T0=true := by
  change (fastTreeOK (forms 0) 0 (0 ||| 2^0) q10Shape0T1 &&
    fastTreeOK (forms 0) (0 ||| 2^0) 0 q10Shape0T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape0T1OK,q10Shape0T14OK⟩


theorem q10Shape0_cover (b : Nat→Bool) (H : Ranked (adj (forms 0) b)) :
    ∃ u v w z t,Effective (adj (forms 0) b) (adj (forms 0) b) u v w z t :=
  checked_fastTree (forms 0) b H q10Shape0T0 q10Shape0T0OK

#print axioms q10Shape0_cover
end Graffiti384b.Q10
