import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape1T3 : Tree := (.split 4 (.tip (.small 1)) (.split 5 (.tip (.small 1)) (.split 2 (.tip (.small 0)) (.tip (.cover 0 1 2 6 9)))))
private theorem q10Shape1T3OK : fastTreeOK (forms 1) 0 131 q10Shape1T3=true := by decide

private def q10Shape1T4 : Tree := (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.unordered 3 4 8 1)))))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 7 9)))))) (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))))
private theorem q10Shape1T4OK : fastTreeOK (forms 1) 128 3 q10Shape1T4=true := by decide

private def q10Shape1T2 : Tree := .split 7 q10Shape1T3 q10Shape1T4
private theorem q10Shape1T2OK : fastTreeOK (forms 1) 0 3 q10Shape1T2=true := by
  change (fastTreeOK (forms 1) 0 (3 ||| 2^7) q10Shape1T3 &&
    fastTreeOK (forms 1) (0 ||| 2^7) 3 q10Shape1T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T3OK,q10Shape1T4OK⟩

private def q10Shape1T6 : Tree := (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 8 9)))))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 7 9)))))) (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))))
private theorem q10Shape1T6OK : fastTreeOK (forms 1) 2 129 q10Shape1T6=true := by decide

private def q10Shape1T8 : Tree := (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))))) (.split 10 (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9))))) (.split 11 (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))) (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 1 3 5 6 9))) (.tip (.cover 1 3 5 6 9))))))
private theorem q10Shape1T8OK : fastTreeOK (forms 1) 130 17 q10Shape1T8=true := by decide

private def q10Shape1T9 : Tree := (.split 5 (.split 10 (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9))))) (.split 11 (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))) (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 0 1 3 6 9))) (.tip (.cover 1 3 5 6 9))) (.tip (.cover 1 3 5 6 9))))) (.split 2 (.split 3 (.split 8 (.tip (.small 0)) (.tip (.cover 1 2 5 6 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))))
private theorem q10Shape1T9OK : fastTreeOK (forms 1) 146 1 q10Shape1T9=true := by decide

private def q10Shape1T7 : Tree := .split 4 q10Shape1T8 q10Shape1T9
private theorem q10Shape1T7OK : fastTreeOK (forms 1) 130 1 q10Shape1T7=true := by
  change (fastTreeOK (forms 1) 130 (1 ||| 2^4) q10Shape1T8 &&
    fastTreeOK (forms 1) (130 ||| 2^4) 1 q10Shape1T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T8OK,q10Shape1T9OK⟩

private def q10Shape1T5 : Tree := .split 7 q10Shape1T6 q10Shape1T7
private theorem q10Shape1T5OK : fastTreeOK (forms 1) 2 1 q10Shape1T5=true := by
  change (fastTreeOK (forms 1) 2 (1 ||| 2^7) q10Shape1T6 &&
    fastTreeOK (forms 1) (2 ||| 2^7) 1 q10Shape1T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T6OK,q10Shape1T7OK⟩

private def q10Shape1T1 : Tree := .split 1 q10Shape1T2 q10Shape1T5
private theorem q10Shape1T1OK : fastTreeOK (forms 1) 0 1 q10Shape1T1=true := by
  change (fastTreeOK (forms 1) 0 (1 ||| 2^1) q10Shape1T2 &&
    fastTreeOK (forms 1) (0 ||| 2^1) 1 q10Shape1T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T2OK,q10Shape1T5OK⟩

private def q10Shape1T12 : Tree := (.split 4 (.split 5 (.tip (.small 1)) (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 8 9)))))))) (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 7 9)))))) (.split 2 (.split 3 (.tip (.small 0)) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))))
private theorem q10Shape1T12OK : fastTreeOK (forms 1) 1 130 q10Shape1T12=true := by decide

private def q10Shape1T14 : Tree := (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.tip (.cover 1 3 5 6 9)))) (.split 10 (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 8 9)))))) (.split 11 (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 3 5 6 8 9))))) (.tip (.cover 1 3 5 6 9)))))
private theorem q10Shape1T14OK : fastTreeOK (forms 1) 129 18 q10Shape1T14=true := by decide

private def q10Shape1T15 : Tree := (.split 5 (.split 10 (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 3 5 6 7 9))))) (.split 11 (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 7 9)))) (.tip (.cover 1 3 5 6 9)))) (.split 2 (.split 3 (.split 13 (.tip (.small 0)) (.tip (.cover 1 2 5 6 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9))))
private theorem q10Shape1T15OK : fastTreeOK (forms 1) 145 2 q10Shape1T15=true := by decide

private def q10Shape1T13 : Tree := .split 4 q10Shape1T14 q10Shape1T15
private theorem q10Shape1T13OK : fastTreeOK (forms 1) 129 2 q10Shape1T13=true := by
  change (fastTreeOK (forms 1) 129 (2 ||| 2^4) q10Shape1T14 &&
    fastTreeOK (forms 1) (129 ||| 2^4) 2 q10Shape1T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T14OK,q10Shape1T15OK⟩

private def q10Shape1T11 : Tree := .split 7 q10Shape1T12 q10Shape1T13
private theorem q10Shape1T11OK : fastTreeOK (forms 1) 1 2 q10Shape1T11=true := by
  change (fastTreeOK (forms 1) 1 (2 ||| 2^7) q10Shape1T12 &&
    fastTreeOK (forms 1) (1 ||| 2^7) 2 q10Shape1T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T12OK,q10Shape1T13OK⟩

private def q10Shape1T18 : Tree := (.split 5 (.split 10 (.tip (.small 1)) (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 3 4 5 6 9)))))) (.split 10 (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 8 9)))))) (.split 11 (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 2 5 6 7 9)))) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 1 3 5 6 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))))))
private theorem q10Shape1T18OK : fastTreeOK (forms 1) 3 144 q10Shape1T18=true := by decide

private def q10Shape1T19 : Tree := (.split 5 (.split 10 (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 2 5 6 8 9)))))) (.split 11 (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 1 5 6 7 9)))) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 1 3 5 6 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9))))) (.tip (.cover 1 2 5 6 9)))
private theorem q10Shape1T19OK : fastTreeOK (forms 1) 19 128 q10Shape1T19=true := by decide

private def q10Shape1T17 : Tree := .split 4 q10Shape1T18 q10Shape1T19
private theorem q10Shape1T17OK : fastTreeOK (forms 1) 3 128 q10Shape1T17=true := by
  change (fastTreeOK (forms 1) 3 (128 ||| 2^4) q10Shape1T18 &&
    fastTreeOK (forms 1) (3 ||| 2^4) 128 q10Shape1T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T18OK,q10Shape1T19OK⟩

private def q10Shape1T22 : Tree := (.split 10 (.split 11 (.tip (.small 1)) (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9))))) (.split 11 (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))) (.tip (.cover 1 3 5 6 9))))
private theorem q10Shape1T22OK : fastTreeOK (forms 1) 131 48 q10Shape1T22=true := by decide

private def q10Shape1T23 : Tree := (.split 10 (.split 11 (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))) (.split 16 (.split 15 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 4 5 6 8 9)))) (.tip (.unordered 2 3 4 1)))) (.split 11 (.split 15 (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 3 5 6 8 9)))) (.split 16 (.split 25 (.tip (.small 1)) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 1 4 5 6 9)))) (.tip (.cover 1 3 5 6 9))))
private theorem q10Shape1T23OK : fastTreeOK (forms 1) 163 16 q10Shape1T23=true := by decide

private def q10Shape1T21 : Tree := .split 5 q10Shape1T22 q10Shape1T23
private theorem q10Shape1T21OK : fastTreeOK (forms 1) 131 16 q10Shape1T21=true := by
  change (fastTreeOK (forms 1) 131 (16 ||| 2^5) q10Shape1T22 &&
    fastTreeOK (forms 1) (131 ||| 2^5) 16 q10Shape1T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T22OK,q10Shape1T23OK⟩

private def q10Shape1T24 : Tree := (.split 5 (.split 10 (.split 11 (.split 15 (.tip (.small 1)) (.split 16 (.tip (.small 1)) (.tip (.cover 1 4 5 6 9)))) (.split 15 (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 2 5 6 8 9)))) (.split 16 (.split 25 (.tip (.small 1)) (.tip (.cover 3 5 6 7 9))) (.tip (.cover 1 4 5 6 9))))) (.split 11 (.split 15 (.split 16 (.tip (.small 1)) (.split 25 (.tip (.small 1)) (.tip (.cover 4 5 6 7 9)))) (.tip (.unordered 2 3 4 1))) (.tip (.cover 1 3 5 6 9)))) (.tip (.cover 1 2 5 6 9)))
private theorem q10Shape1T24OK : fastTreeOK (forms 1) 147 0 q10Shape1T24=true := by decide

private def q10Shape1T20 : Tree := .split 4 q10Shape1T21 q10Shape1T24
private theorem q10Shape1T20OK : fastTreeOK (forms 1) 131 0 q10Shape1T20=true := by
  change (fastTreeOK (forms 1) 131 (0 ||| 2^4) q10Shape1T21 &&
    fastTreeOK (forms 1) (131 ||| 2^4) 0 q10Shape1T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T21OK,q10Shape1T24OK⟩

private def q10Shape1T16 : Tree := .split 7 q10Shape1T17 q10Shape1T20
private theorem q10Shape1T16OK : fastTreeOK (forms 1) 3 0 q10Shape1T16=true := by
  change (fastTreeOK (forms 1) 3 (0 ||| 2^7) q10Shape1T17 &&
    fastTreeOK (forms 1) (3 ||| 2^7) 0 q10Shape1T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T17OK,q10Shape1T20OK⟩

private def q10Shape1T10 : Tree := .split 1 q10Shape1T11 q10Shape1T16
private theorem q10Shape1T10OK : fastTreeOK (forms 1) 1 0 q10Shape1T10=true := by
  change (fastTreeOK (forms 1) 1 (0 ||| 2^1) q10Shape1T11 &&
    fastTreeOK (forms 1) (1 ||| 2^1) 0 q10Shape1T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T11OK,q10Shape1T16OK⟩

private def q10Shape1T0 : Tree := .split 0 q10Shape1T1 q10Shape1T10
private theorem q10Shape1T0OK : fastTreeOK (forms 1) 0 0 q10Shape1T0=true := by
  change (fastTreeOK (forms 1) 0 (0 ||| 2^0) q10Shape1T1 &&
    fastTreeOK (forms 1) (0 ||| 2^0) 0 q10Shape1T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape1T1OK,q10Shape1T10OK⟩


theorem q10Shape1_cover (b : Nat→Bool) (H : Ranked (adj (forms 1) b)) :
    ∃ u v w z t,Effective (adj (forms 1) b) (adj (forms 1) b) u v w z t :=
  checked_fastTree (forms 1) b H q10Shape1T0 q10Shape1T0OK

#print axioms q10Shape1_cover
end Graffiti384b.Q10
