import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape10T2 : Tree := (.split 7 (.tip (.small 0)) (.split 3 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.unordered 3 4 5 0))))))))))
private theorem q10Shape10T2OK : fastTreeOK (forms 10) 0 3 q10Shape10T2=true := by decide

private def q10Shape10T4 : Tree := (.split 3 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.unordered 2 4 5 0)))))))))
private theorem q10Shape10T4OK : fastTreeOK (forms 10) 2 129 q10Shape10T4=true := by decide

private def q10Shape10T7 : Tree := (.tip (.small 1))
private theorem q10Shape10T7OK : fastTreeOK (forms 10) 130 521 q10Shape10T7=true := by decide

private def q10Shape10T9 : Tree := (.tip (.small 1))
private theorem q10Shape10T9OK : fastTreeOK (forms 10) 642 16393 q10Shape10T9=true := by decide

private def q10Shape10T11 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 4 (.split 5 (.split 6 (.split 22 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 1 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9)))))
private theorem q10Shape10T11OK : fastTreeOK (forms 10) 17026 13 q10Shape10T11=true := by decide

private def q10Shape10T13 : Tree := (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 0 4 7 8 9))) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.cover 1 5 7 8 9))) (.tip (.cover 0 6 7 8 9)))))
private theorem q10Shape10T13OK : fastTreeOK (forms 10) 17030 265 q10Shape10T13=true := by decide

private def q10Shape10T14 : Tree := (.split 13 (.split 18 (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 2 3 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 18 (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.unordered 3 4 5 1))))
private theorem q10Shape10T14OK : fastTreeOK (forms 10) 17286 9 q10Shape10T14=true := by decide

private def q10Shape10T12 : Tree := .split 8 q10Shape10T13 q10Shape10T14
private theorem q10Shape10T12OK : fastTreeOK (forms 10) 17030 9 q10Shape10T12=true := by
  change (fastTreeOK (forms 10) 17030 (9 ||| 2^8) q10Shape10T13 &&
    fastTreeOK (forms 10) (17030 ||| 2^8) 9 q10Shape10T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T13OK,q10Shape10T14OK⟩

private def q10Shape10T10 : Tree := .split 2 q10Shape10T11 q10Shape10T12
private theorem q10Shape10T10OK : fastTreeOK (forms 10) 17026 9 q10Shape10T10=true := by
  change (fastTreeOK (forms 10) 17026 (9 ||| 2^2) q10Shape10T11 &&
    fastTreeOK (forms 10) (17026 ||| 2^2) 9 q10Shape10T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T11OK,q10Shape10T12OK⟩

private def q10Shape10T8 : Tree := .split 14 q10Shape10T9 q10Shape10T10
private theorem q10Shape10T8OK : fastTreeOK (forms 10) 642 9 q10Shape10T8=true := by
  change (fastTreeOK (forms 10) 642 (9 ||| 2^14) q10Shape10T9 &&
    fastTreeOK (forms 10) (642 ||| 2^14) 9 q10Shape10T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T9OK,q10Shape10T10OK⟩

private def q10Shape10T6 : Tree := .split 9 q10Shape10T7 q10Shape10T8
private theorem q10Shape10T6OK : fastTreeOK (forms 10) 130 9 q10Shape10T6=true := by
  change (fastTreeOK (forms 10) 130 (9 ||| 2^9) q10Shape10T7 &&
    fastTreeOK (forms 10) (130 ||| 2^9) 9 q10Shape10T8)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T7OK,q10Shape10T8OK⟩

private def q10Shape10T17 : Tree := (.tip (.small 1))
private theorem q10Shape10T17OK : fastTreeOK (forms 10) 138 16897 q10Shape10T17=true := by decide

private def q10Shape10T19 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 10 (.tip (.cover 2 4 5 8 9)) (.split 4 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 0 4 7 8 9))) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 1 5 7 8 9))))))
private theorem q10Shape10T19OK : fastTreeOK (forms 10) 16522 517 q10Shape10T19=true := by decide

private def q10Shape10T21 : Tree := (.split 13 (.tip (.small 0)) (.split 10 (.split 11 (.split 12 (.split 22 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 1 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))))
private theorem q10Shape10T21OK : fastTreeOK (forms 10) 16526 769 q10Shape10T21=true := by decide

private def q10Shape10T22 : Tree := (.split 13 (.split 18 (.split 22 (.split 10 (.tip (.cover 2 4 5 8 9)) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 2 3 7 8 9))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 18 (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.unordered 2 4 5 1))))
private theorem q10Shape10T22OK : fastTreeOK (forms 10) 16782 513 q10Shape10T22=true := by decide

private def q10Shape10T20 : Tree := .split 8 q10Shape10T21 q10Shape10T22
private theorem q10Shape10T20OK : fastTreeOK (forms 10) 16526 513 q10Shape10T20=true := by
  change (fastTreeOK (forms 10) 16526 (513 ||| 2^8) q10Shape10T21 &&
    fastTreeOK (forms 10) (16526 ||| 2^8) 513 q10Shape10T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T21OK,q10Shape10T22OK⟩

private def q10Shape10T18 : Tree := .split 2 q10Shape10T19 q10Shape10T20
private theorem q10Shape10T18OK : fastTreeOK (forms 10) 16522 513 q10Shape10T18=true := by
  change (fastTreeOK (forms 10) 16522 (513 ||| 2^2) q10Shape10T19 &&
    fastTreeOK (forms 10) (16522 ||| 2^2) 513 q10Shape10T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T19OK,q10Shape10T20OK⟩

private def q10Shape10T16 : Tree := .split 14 q10Shape10T17 q10Shape10T18
private theorem q10Shape10T16OK : fastTreeOK (forms 10) 138 513 q10Shape10T16=true := by
  change (fastTreeOK (forms 10) 138 (513 ||| 2^14) q10Shape10T17 &&
    fastTreeOK (forms 10) (138 ||| 2^14) 513 q10Shape10T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T17OK,q10Shape10T18OK⟩

private def q10Shape10T25 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 3 4 6 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 4 (.split 5 (.split 6 (.split 19 (.tip (.cover 3 4 6 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 1 5 7 8 9))) (.tip (.cover 1 5 7 8 9))) (.tip (.cover 1 5 7 8 9))))))
private theorem q10Shape10T25OK : fastTreeOK (forms 10) 650 16389 q10Shape10T25=true := by decide

private def q10Shape10T26 : Tree := (.split 8 (.split 13 (.tip (.small 0)) (.split 18 (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.cover 2 3 4 8 9)))) (.split 10 (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 10 (.split 4 (.tip (.cover 4 5 6 8 9)) (.split 11 (.split 19 (.tip (.cover 2 4 6 8 9)) (.tip (.cover 2 3 5 8 9))) (.tip (.cover 1 5 7 8 9)))) (.tip (.cover 1 5 7 8 9))))) (.tip (.cover 2 3 7 8 9)))
private theorem q10Shape10T26OK : fastTreeOK (forms 10) 654 16385 q10Shape10T26=true := by decide

private def q10Shape10T24 : Tree := .split 2 q10Shape10T25 q10Shape10T26
private theorem q10Shape10T24OK : fastTreeOK (forms 10) 650 16385 q10Shape10T24=true := by
  change (fastTreeOK (forms 10) 650 (16385 ||| 2^2) q10Shape10T25 &&
    fastTreeOK (forms 10) (650 ||| 2^2) 16385 q10Shape10T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T25OK,q10Shape10T26OK⟩

private def q10Shape10T27 : Tree := (.split 18 (.split 2 (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 4 (.split 5 (.split 6 (.split 19 (.tip (.cover 3 4 6 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))))) (.split 8 (.split 13 (.tip (.small 0)) (.split 10 (.split 4 (.tip (.cover 4 5 6 8 9)) (.split 11 (.split 19 (.tip (.cover 2 4 6 8 9)) (.tip (.cover 2 3 5 8 9))) (.tip (.cover 2 4 7 8 9)))) (.tip (.cover 2 4 7 8 9)))) (.tip (.cover 2 3 7 8 9)))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape10T27OK : fastTreeOK (forms 10) 17034 1 q10Shape10T27=true := by decide

private def q10Shape10T23 : Tree := .split 14 q10Shape10T24 q10Shape10T27
private theorem q10Shape10T23OK : fastTreeOK (forms 10) 650 1 q10Shape10T23=true := by
  change (fastTreeOK (forms 10) 650 (1 ||| 2^14) q10Shape10T24 &&
    fastTreeOK (forms 10) (650 ||| 2^14) 1 q10Shape10T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T24OK,q10Shape10T27OK⟩

private def q10Shape10T15 : Tree := .split 9 q10Shape10T16 q10Shape10T23
private theorem q10Shape10T15OK : fastTreeOK (forms 10) 138 1 q10Shape10T15=true := by
  change (fastTreeOK (forms 10) 138 (1 ||| 2^9) q10Shape10T16 &&
    fastTreeOK (forms 10) (138 ||| 2^9) 1 q10Shape10T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T16OK,q10Shape10T23OK⟩

private def q10Shape10T5 : Tree := .split 3 q10Shape10T6 q10Shape10T15
private theorem q10Shape10T5OK : fastTreeOK (forms 10) 130 1 q10Shape10T5=true := by
  change (fastTreeOK (forms 10) 130 (1 ||| 2^3) q10Shape10T6 &&
    fastTreeOK (forms 10) (130 ||| 2^3) 1 q10Shape10T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T6OK,q10Shape10T15OK⟩

private def q10Shape10T3 : Tree := .split 7 q10Shape10T4 q10Shape10T5
private theorem q10Shape10T3OK : fastTreeOK (forms 10) 2 1 q10Shape10T3=true := by
  change (fastTreeOK (forms 10) 2 (1 ||| 2^7) q10Shape10T4 &&
    fastTreeOK (forms 10) (2 ||| 2^7) 1 q10Shape10T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T4OK,q10Shape10T5OK⟩

private def q10Shape10T1 : Tree := .split 1 q10Shape10T2 q10Shape10T3
private theorem q10Shape10T1OK : fastTreeOK (forms 10) 0 1 q10Shape10T1=true := by
  change (fastTreeOK (forms 10) 0 (1 ||| 2^1) q10Shape10T2 &&
    fastTreeOK (forms 10) (0 ||| 2^1) 1 q10Shape10T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T2OK,q10Shape10T3OK⟩

private def q10Shape10T30 : Tree := (.split 3 (.tip (.small 1)) (.split 9 (.tip (.small 1)) (.split 14 (.tip (.small 1)) (.split 2 (.tip (.small 0)) (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.unordered 2 3 5 0)))))))))
private theorem q10Shape10T30OK : fastTreeOK (forms 10) 1 130 q10Shape10T30=true := by decide

private def q10Shape10T33 : Tree := (.tip (.small 1))
private theorem q10Shape10T33OK : fastTreeOK (forms 10) 129 522 q10Shape10T33=true := by decide

private def q10Shape10T35 : Tree := (.tip (.small 1))
private theorem q10Shape10T35OK : fastTreeOK (forms 10) 641 16394 q10Shape10T35=true := by decide

private def q10Shape10T37 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 4 (.split 5 (.split 6 (.split 22 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 1 3 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9)))))
private theorem q10Shape10T37OK : fastTreeOK (forms 10) 17025 14 q10Shape10T37=true := by decide

private def q10Shape10T39 : Tree := (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 2 4 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 0 6 7 8 9)))))
private theorem q10Shape10T39OK : fastTreeOK (forms 10) 17029 266 q10Shape10T39=true := by decide

private def q10Shape10T40 : Tree := (.split 13 (.split 18 (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 0 3 7 8 9))) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.cover 1 5 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 18 (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.unordered 3 4 5 1))))
private theorem q10Shape10T40OK : fastTreeOK (forms 10) 17285 10 q10Shape10T40=true := by decide

private def q10Shape10T38 : Tree := .split 8 q10Shape10T39 q10Shape10T40
private theorem q10Shape10T38OK : fastTreeOK (forms 10) 17029 10 q10Shape10T38=true := by
  change (fastTreeOK (forms 10) 17029 (10 ||| 2^8) q10Shape10T39 &&
    fastTreeOK (forms 10) (17029 ||| 2^8) 10 q10Shape10T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T39OK,q10Shape10T40OK⟩

private def q10Shape10T36 : Tree := .split 2 q10Shape10T37 q10Shape10T38
private theorem q10Shape10T36OK : fastTreeOK (forms 10) 17025 10 q10Shape10T36=true := by
  change (fastTreeOK (forms 10) 17025 (10 ||| 2^2) q10Shape10T37 &&
    fastTreeOK (forms 10) (17025 ||| 2^2) 10 q10Shape10T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T37OK,q10Shape10T38OK⟩

private def q10Shape10T34 : Tree := .split 14 q10Shape10T35 q10Shape10T36
private theorem q10Shape10T34OK : fastTreeOK (forms 10) 641 10 q10Shape10T34=true := by
  change (fastTreeOK (forms 10) 641 (10 ||| 2^14) q10Shape10T35 &&
    fastTreeOK (forms 10) (641 ||| 2^14) 10 q10Shape10T36)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T35OK,q10Shape10T36OK⟩

private def q10Shape10T32 : Tree := .split 9 q10Shape10T33 q10Shape10T34
private theorem q10Shape10T32OK : fastTreeOK (forms 10) 129 10 q10Shape10T32=true := by
  change (fastTreeOK (forms 10) 129 (10 ||| 2^9) q10Shape10T33 &&
    fastTreeOK (forms 10) (129 ||| 2^9) 10 q10Shape10T34)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T33OK,q10Shape10T34OK⟩

private def q10Shape10T43 : Tree := (.tip (.small 1))
private theorem q10Shape10T43OK : fastTreeOK (forms 10) 137 16898 q10Shape10T43=true := by decide

private def q10Shape10T45 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 3 4 6 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 4 (.split 5 (.split 6 (.split 19 (.tip (.cover 3 4 6 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 1 5 7 8 9))) (.tip (.cover 1 5 7 8 9))) (.tip (.cover 1 5 7 8 9))))))
private theorem q10Shape10T45OK : fastTreeOK (forms 10) 16521 518 q10Shape10T45=true := by decide

private def q10Shape10T46 : Tree := (.split 13 (.split 8 (.tip (.small 0)) (.split 18 (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.cover 2 3 4 8 9)))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 3 6 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 10 (.split 4 (.tip (.cover 4 5 6 8 9)) (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 3 6 8 9)))) (.tip (.cover 0 6 7 8 9))))) (.tip (.cover 2 4 7 8 9)))
private theorem q10Shape10T46OK : fastTreeOK (forms 10) 16525 514 q10Shape10T46=true := by decide

private def q10Shape10T44 : Tree := .split 2 q10Shape10T45 q10Shape10T46
private theorem q10Shape10T44OK : fastTreeOK (forms 10) 16521 514 q10Shape10T44=true := by
  change (fastTreeOK (forms 10) 16521 (514 ||| 2^2) q10Shape10T45 &&
    fastTreeOK (forms 10) (16521 ||| 2^2) 514 q10Shape10T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T45OK,q10Shape10T46OK⟩

private def q10Shape10T42 : Tree := .split 14 q10Shape10T43 q10Shape10T44
private theorem q10Shape10T42OK : fastTreeOK (forms 10) 137 514 q10Shape10T42=true := by
  change (fastTreeOK (forms 10) 137 (514 ||| 2^14) q10Shape10T43 &&
    fastTreeOK (forms 10) (137 ||| 2^14) 514 q10Shape10T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T43OK,q10Shape10T44OK⟩

private def q10Shape10T49 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 15 (.tip (.cover 2 3 5 8 9)) (.split 4 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 0 3 7 8 9))) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 1 5 7 8 9))))))
private theorem q10Shape10T49OK : fastTreeOK (forms 10) 649 16390 q10Shape10T49=true := by decide

private def q10Shape10T50 : Tree := (.split 8 (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 15 (.tip (.cover 2 3 5 8 9)) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 2 4 7 8 9))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 1 5 7 8 9))))) (.split 15 (.split 16 (.split 17 (.split 22 (.split 13 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 1 3 7 8 9))) (.tip (.cover 2 3 5 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))))
private theorem q10Shape10T50OK : fastTreeOK (forms 10) 653 16386 q10Shape10T50=true := by decide

private def q10Shape10T48 : Tree := .split 2 q10Shape10T49 q10Shape10T50
private theorem q10Shape10T48OK : fastTreeOK (forms 10) 649 16386 q10Shape10T48=true := by
  change (fastTreeOK (forms 10) 649 (16386 ||| 2^2) q10Shape10T49 &&
    fastTreeOK (forms 10) (649 ||| 2^2) 16386 q10Shape10T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T49OK,q10Shape10T50OK⟩

private def q10Shape10T51 : Tree := (.split 18 (.split 2 (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 4 (.split 5 (.split 6 (.split 19 (.tip (.cover 3 4 6 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))))) (.split 13 (.split 8 (.tip (.small 0)) (.split 15 (.split 4 (.tip (.cover 3 5 6 8 9)) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 3 6 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 2 3 7 8 9)))) (.tip (.cover 2 4 7 8 9)))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape10T51OK : fastTreeOK (forms 10) 17033 2 q10Shape10T51=true := by decide

private def q10Shape10T47 : Tree := .split 14 q10Shape10T48 q10Shape10T51
private theorem q10Shape10T47OK : fastTreeOK (forms 10) 649 2 q10Shape10T47=true := by
  change (fastTreeOK (forms 10) 649 (2 ||| 2^14) q10Shape10T48 &&
    fastTreeOK (forms 10) (649 ||| 2^14) 2 q10Shape10T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T48OK,q10Shape10T51OK⟩

private def q10Shape10T41 : Tree := .split 9 q10Shape10T42 q10Shape10T47
private theorem q10Shape10T41OK : fastTreeOK (forms 10) 137 2 q10Shape10T41=true := by
  change (fastTreeOK (forms 10) 137 (2 ||| 2^9) q10Shape10T42 &&
    fastTreeOK (forms 10) (137 ||| 2^9) 2 q10Shape10T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T42OK,q10Shape10T47OK⟩

private def q10Shape10T31 : Tree := .split 3 q10Shape10T32 q10Shape10T41
private theorem q10Shape10T31OK : fastTreeOK (forms 10) 129 2 q10Shape10T31=true := by
  change (fastTreeOK (forms 10) 129 (2 ||| 2^3) q10Shape10T32 &&
    fastTreeOK (forms 10) (129 ||| 2^3) 2 q10Shape10T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T32OK,q10Shape10T41OK⟩

private def q10Shape10T29 : Tree := .split 7 q10Shape10T30 q10Shape10T31
private theorem q10Shape10T29OK : fastTreeOK (forms 10) 1 2 q10Shape10T29=true := by
  change (fastTreeOK (forms 10) 1 (2 ||| 2^7) q10Shape10T30 &&
    fastTreeOK (forms 10) (1 ||| 2^7) 2 q10Shape10T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T30OK,q10Shape10T31OK⟩

private def q10Shape10T55 : Tree := (.tip (.small 1))
private theorem q10Shape10T55OK : fastTreeOK (forms 10) 3 648 q10Shape10T55=true := by decide

private def q10Shape10T57 : Tree := (.tip (.small 1))
private theorem q10Shape10T57OK : fastTreeOK (forms 10) 515 16520 q10Shape10T57=true := by decide

private def q10Shape10T59 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 3 4 7 8 9))))
private theorem q10Shape10T59OK : fastTreeOK (forms 10) 16899 140 q10Shape10T59=true := by decide

private def q10Shape10T61 : Tree := (.split 13 (.tip (.small 0)) (.split 18 (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 4 6 8 9)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 4 (.split 5 (.split 6 (.split 19 (.tip (.cover 3 4 6 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))))
private theorem q10Shape10T61OK : fastTreeOK (forms 10) 16903 392 q10Shape10T61=true := by decide

private def q10Shape10T62 : Tree := (.split 13 (.split 18 (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 3 6 8 9)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.split 4 (.split 5 (.split 6 (.split 19 (.tip (.cover 3 4 6 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 3 4 7 8 9)))
private theorem q10Shape10T62OK : fastTreeOK (forms 10) 17159 136 q10Shape10T62=true := by decide

private def q10Shape10T60 : Tree := .split 8 q10Shape10T61 q10Shape10T62
private theorem q10Shape10T60OK : fastTreeOK (forms 10) 16903 136 q10Shape10T60=true := by
  change (fastTreeOK (forms 10) 16903 (136 ||| 2^8) q10Shape10T61 &&
    fastTreeOK (forms 10) (16903 ||| 2^8) 136 q10Shape10T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T61OK,q10Shape10T62OK⟩

private def q10Shape10T58 : Tree := .split 2 q10Shape10T59 q10Shape10T60
private theorem q10Shape10T58OK : fastTreeOK (forms 10) 16899 136 q10Shape10T58=true := by
  change (fastTreeOK (forms 10) 16899 (136 ||| 2^2) q10Shape10T59 &&
    fastTreeOK (forms 10) (16899 ||| 2^2) 136 q10Shape10T60)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T59OK,q10Shape10T60OK⟩

private def q10Shape10T56 : Tree := .split 14 q10Shape10T57 q10Shape10T58
private theorem q10Shape10T56OK : fastTreeOK (forms 10) 515 136 q10Shape10T56=true := by
  change (fastTreeOK (forms 10) 515 (136 ||| 2^14) q10Shape10T57 &&
    fastTreeOK (forms 10) (515 ||| 2^14) 136 q10Shape10T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T57OK,q10Shape10T58OK⟩

private def q10Shape10T54 : Tree := .split 9 q10Shape10T55 q10Shape10T56
private theorem q10Shape10T54OK : fastTreeOK (forms 10) 3 136 q10Shape10T54=true := by
  change (fastTreeOK (forms 10) 3 (136 ||| 2^9) q10Shape10T55 &&
    fastTreeOK (forms 10) (3 ||| 2^9) 136 q10Shape10T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T55OK,q10Shape10T56OK⟩

private def q10Shape10T65 : Tree := (.tip (.small 1))
private theorem q10Shape10T65OK : fastTreeOK (forms 10) 11 17024 q10Shape10T65=true := by decide

private def q10Shape10T67 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 10 (.tip (.cover 2 4 5 8 9)) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 3 4 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 1 5 7 8 9))))))
private theorem q10Shape10T67OK : fastTreeOK (forms 10) 16395 644 q10Shape10T67=true := by decide

private def q10Shape10T69 : Tree := (.split 13 (.tip (.small 0)) (.split 10 (.split 11 (.split 12 (.split 22 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 1 2 7 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))))
private theorem q10Shape10T69OK : fastTreeOK (forms 10) 16399 896 q10Shape10T69=true := by decide

private def q10Shape10T70 : Tree := (.split 13 (.split 18 (.split 22 (.split 10 (.tip (.cover 2 4 5 8 9)) (.split 4 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 0 2 7 8 9))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 1 5 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.split 18 (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.unordered 2 4 5 1))))
private theorem q10Shape10T70OK : fastTreeOK (forms 10) 16655 640 q10Shape10T70=true := by decide

private def q10Shape10T68 : Tree := .split 8 q10Shape10T69 q10Shape10T70
private theorem q10Shape10T68OK : fastTreeOK (forms 10) 16399 640 q10Shape10T68=true := by
  change (fastTreeOK (forms 10) 16399 (640 ||| 2^8) q10Shape10T69 &&
    fastTreeOK (forms 10) (16399 ||| 2^8) 640 q10Shape10T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T69OK,q10Shape10T70OK⟩

private def q10Shape10T66 : Tree := .split 2 q10Shape10T67 q10Shape10T68
private theorem q10Shape10T66OK : fastTreeOK (forms 10) 16395 640 q10Shape10T66=true := by
  change (fastTreeOK (forms 10) 16395 (640 ||| 2^2) q10Shape10T67 &&
    fastTreeOK (forms 10) (16395 ||| 2^2) 640 q10Shape10T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T67OK,q10Shape10T68OK⟩

private def q10Shape10T64 : Tree := .split 14 q10Shape10T65 q10Shape10T66
private theorem q10Shape10T64OK : fastTreeOK (forms 10) 11 640 q10Shape10T64=true := by
  change (fastTreeOK (forms 10) 11 (640 ||| 2^14) q10Shape10T65 &&
    fastTreeOK (forms 10) (11 ||| 2^14) 640 q10Shape10T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T65OK,q10Shape10T66OK⟩

private def q10Shape10T73 : Tree := (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 15 (.tip (.cover 2 3 5 8 9)) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.cover 2 3 4 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 3 4 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 1 5 7 8 9))))))
private theorem q10Shape10T73OK : fastTreeOK (forms 10) 523 16516 q10Shape10T73=true := by decide

private def q10Shape10T74 : Tree := (.split 8 (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 15 (.tip (.cover 2 3 5 8 9)) (.split 4 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 0 2 7 8 9))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 1 5 7 8 9))))) (.split 15 (.split 16 (.split 17 (.split 22 (.split 13 (.split 19 (.tip (.cover 2 3 4 8 9)) (.tip (.cover 1 2 7 8 9))) (.tip (.cover 2 3 5 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))))
private theorem q10Shape10T74OK : fastTreeOK (forms 10) 527 16512 q10Shape10T74=true := by decide

private def q10Shape10T72 : Tree := .split 2 q10Shape10T73 q10Shape10T74
private theorem q10Shape10T72OK : fastTreeOK (forms 10) 523 16512 q10Shape10T72=true := by
  change (fastTreeOK (forms 10) 523 (16512 ||| 2^2) q10Shape10T73 &&
    fastTreeOK (forms 10) (523 ||| 2^2) 16512 q10Shape10T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T73OK,q10Shape10T74OK⟩

private def q10Shape10T75 : Tree := (.split 18 (.split 2 (.split 8 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 3 4 7 8 9)))) (.split 8 (.split 13 (.tip (.small 0)) (.split 10 (.split 11 (.split 12 (.split 19 (.tip (.cover 2 4 6 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9)))) (.split 13 (.split 15 (.split 10 (.tip (.cover 2 5 6 8 9)) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 3 6 8 9))) (.tip (.cover 2 3 4 8 9)))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 3 4 7 8 9))))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape10T75OK : fastTreeOK (forms 10) 16907 128 q10Shape10T75=true := by decide

private def q10Shape10T71 : Tree := .split 14 q10Shape10T72 q10Shape10T75
private theorem q10Shape10T71OK : fastTreeOK (forms 10) 523 128 q10Shape10T71=true := by
  change (fastTreeOK (forms 10) 523 (128 ||| 2^14) q10Shape10T72 &&
    fastTreeOK (forms 10) (523 ||| 2^14) 128 q10Shape10T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T72OK,q10Shape10T75OK⟩

private def q10Shape10T63 : Tree := .split 9 q10Shape10T64 q10Shape10T71
private theorem q10Shape10T63OK : fastTreeOK (forms 10) 11 128 q10Shape10T63=true := by
  change (fastTreeOK (forms 10) 11 (128 ||| 2^9) q10Shape10T64 &&
    fastTreeOK (forms 10) (11 ||| 2^9) 128 q10Shape10T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T64OK,q10Shape10T71OK⟩

private def q10Shape10T53 : Tree := .split 3 q10Shape10T54 q10Shape10T63
private theorem q10Shape10T53OK : fastTreeOK (forms 10) 3 128 q10Shape10T53=true := by
  change (fastTreeOK (forms 10) 3 (128 ||| 2^3) q10Shape10T54 &&
    fastTreeOK (forms 10) (3 ||| 2^3) 128 q10Shape10T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T54OK,q10Shape10T63OK⟩

private def q10Shape10T79 : Tree := (.tip (.small 1))
private theorem q10Shape10T79OK : fastTreeOK (forms 10) 131 16904 q10Shape10T79=true := by decide

private def q10Shape10T83 : Tree := (.tip (.small 0))
private theorem q10Shape10T83OK : fastTreeOK (forms 10) 16515 8972 q10Shape10T83=true := by decide

private def q10Shape10T92 : Tree := (.split 10 (.tip (.cover 0 1 4 8 9)) (.split 5 (.split 11 (.tip (.cover 0 1 4 7 9)) (.split 25 (.tip (.cover 3 4 5 6 9)) (.split 6 (.split 26 (.tip (.cover 3 4 5 6 8)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 3 5 6 7 9))))) (.split 11 (.split 15 (.tip (.cover 3 5 6 8 9)) (.split 16 (.tip (.cover 2 5 6 7 9)) (.tip (.unordered 2 3 4 0)))) (.tip (.unordered 2 3 4 0)))))
private theorem q10Shape10T92OK : fastTreeOK (forms 10) 24707 33293084 q10Shape10T92=true := by decide

private def q10Shape10T93 : Tree := (.split 10 (.split 5 (.split 11 (.tip (.cover 0 1 4 7 9)) (.split 15 (.tip (.cover 2 5 6 8 9)) (.split 16 (.tip (.cover 3 5 6 7 9)) (.tip (.unordered 2 3 4 0))))) (.split 11 (.split 25 (.tip (.cover 2 4 5 6 9)) (.split 12 (.split 26 (.tip (.cover 2 4 5 6 8)) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 2 5 6 7 9)))) (.tip (.unordered 2 3 4 0)))) (.tip (.unordered 2 3 4 0)))
private theorem q10Shape10T93OK : fastTreeOK (forms 10) 24723 33293068 q10Shape10T93=true := by decide

private def q10Shape10T91 : Tree := .split 4 q10Shape10T92 q10Shape10T93
private theorem q10Shape10T91OK : fastTreeOK (forms 10) 24707 33293068 q10Shape10T91=true := by
  change (fastTreeOK (forms 10) 24707 (33293068 ||| 2^4) q10Shape10T92 &&
    fastTreeOK (forms 10) (24707 ||| 2^4) 33293068 q10Shape10T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T92OK,q10Shape10T93OK⟩

private def q10Shape10T94 : Tree := (.tip (.cover 1 4 7 8 9))
private theorem q10Shape10T94OK : fastTreeOK (forms 10) 2121859 31195916 q10Shape10T94=true := by decide

private def q10Shape10T90 : Tree := .split 21 q10Shape10T91 q10Shape10T94
private theorem q10Shape10T90OK : fastTreeOK (forms 10) 24707 31195916 q10Shape10T90=true := by
  change (fastTreeOK (forms 10) 24707 (31195916 ||| 2^21) q10Shape10T91 &&
    fastTreeOK (forms 10) (24707 ||| 2^21) 31195916 q10Shape10T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T91OK,q10Shape10T94OK⟩

private def q10Shape10T95 : Tree := (.tip (.cover 1 4 7 8 9))
private theorem q10Shape10T95OK : fastTreeOK (forms 10) 1073283 30147340 q10Shape10T95=true := by decide

private def q10Shape10T89 : Tree := .split 20 q10Shape10T90 q10Shape10T95
private theorem q10Shape10T89OK : fastTreeOK (forms 10) 24707 30147340 q10Shape10T89=true := by
  change (fastTreeOK (forms 10) 24707 (30147340 ||| 2^20) q10Shape10T90 &&
    fastTreeOK (forms 10) (24707 ||| 2^20) 30147340 q10Shape10T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T90OK,q10Shape10T95OK⟩

private def q10Shape10T96 : Tree := (.tip (.cover 1 4 7 8 9))
private theorem q10Shape10T96OK : fastTreeOK (forms 10) 548995 29623052 q10Shape10T96=true := by decide

private def q10Shape10T88 : Tree := .split 19 q10Shape10T89 q10Shape10T96
private theorem q10Shape10T88OK : fastTreeOK (forms 10) 24707 29623052 q10Shape10T88=true := by
  change (fastTreeOK (forms 10) 24707 (29623052 ||| 2^19) q10Shape10T89 &&
    fastTreeOK (forms 10) (24707 ||| 2^19) 29623052 q10Shape10T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T89OK,q10Shape10T96OK⟩

private def q10Shape10T97 : Tree := (.tip (.cover 0 4 7 8 9))
private theorem q10Shape10T97OK : fastTreeOK (forms 10) 16801923 12845836 q10Shape10T97=true := by decide

private def q10Shape10T87 : Tree := .split 24 q10Shape10T88 q10Shape10T97
private theorem q10Shape10T87OK : fastTreeOK (forms 10) 24707 12845836 q10Shape10T87=true := by
  change (fastTreeOK (forms 10) 24707 (12845836 ||| 2^24) q10Shape10T88 &&
    fastTreeOK (forms 10) (24707 ||| 2^24) 12845836 q10Shape10T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T88OK,q10Shape10T97OK⟩

private def q10Shape10T98 : Tree := (.tip (.cover 0 4 7 8 9))
private theorem q10Shape10T98OK : fastTreeOK (forms 10) 8413315 4457228 q10Shape10T98=true := by decide

private def q10Shape10T86 : Tree := .split 23 q10Shape10T87 q10Shape10T98
private theorem q10Shape10T86OK : fastTreeOK (forms 10) 24707 4457228 q10Shape10T86=true := by
  change (fastTreeOK (forms 10) 24707 (4457228 ||| 2^23) q10Shape10T87 &&
    fastTreeOK (forms 10) (24707 ||| 2^23) 4457228 q10Shape10T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T87OK,q10Shape10T98OK⟩

private def q10Shape10T99 : Tree := (.tip (.cover 0 4 7 8 9))
private theorem q10Shape10T99OK : fastTreeOK (forms 10) 4219011 262924 q10Shape10T99=true := by decide

private def q10Shape10T85 : Tree := .split 22 q10Shape10T86 q10Shape10T99
private theorem q10Shape10T85OK : fastTreeOK (forms 10) 24707 262924 q10Shape10T85=true := by
  change (fastTreeOK (forms 10) 24707 (262924 ||| 2^22) q10Shape10T86 &&
    fastTreeOK (forms 10) (24707 ||| 2^22) 262924 q10Shape10T99)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T86OK,q10Shape10T99OK⟩

private def q10Shape10T100 : Tree := (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 10 (.tip (.cover 2 4 5 8 9)) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 4 7 8 9)))
private theorem q10Shape10T100OK : fastTreeOK (forms 10) 286851 780 q10Shape10T100=true := by decide

private def q10Shape10T84 : Tree := .split 18 q10Shape10T85 q10Shape10T100
private theorem q10Shape10T84OK : fastTreeOK (forms 10) 24707 780 q10Shape10T84=true := by
  change (fastTreeOK (forms 10) 24707 (780 ||| 2^18) q10Shape10T85 &&
    fastTreeOK (forms 10) (24707 ||| 2^18) 780 q10Shape10T100)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T85OK,q10Shape10T100OK⟩

private def q10Shape10T82 : Tree := .split 13 q10Shape10T83 q10Shape10T84
private theorem q10Shape10T82OK : fastTreeOK (forms 10) 16515 780 q10Shape10T82=true := by
  change (fastTreeOK (forms 10) 16515 (780 ||| 2^13) q10Shape10T83 &&
    fastTreeOK (forms 10) (16515 ||| 2^13) 780 q10Shape10T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T83OK,q10Shape10T84OK⟩

private def q10Shape10T103 : Tree := (.split 4 (.split 5 (.split 6 (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.split 22 (.tip (.cover 1 4 5 8 9)) (.split 23 (.tip (.cover 3 4 5 7 9)) (.tip (.cover 0 3 7 8 9))))) (.split 22 (.split 23 (.split 25 (.tip (.cover 3 4 5 6 9)) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 3 4 5 8 9))) (.tip (.cover 0 3 6 8 9)))) (.split 12 (.split 17 (.tip (.cover 2 5 6 7 8)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.split 11 (.split 16 (.tip (.cover 2 5 6 7 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T103OK : fastTreeOK (forms 10) 16771 270860 q10Shape10T103=true := by decide

private def q10Shape10T104 : Tree := (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 3 4 6 8 9))) (.tip (.cover 2 3 6 8 9)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T104OK : fastTreeOK (forms 10) 278915 8716 q10Shape10T104=true := by decide

private def q10Shape10T102 : Tree := .split 18 q10Shape10T103 q10Shape10T104
private theorem q10Shape10T102OK : fastTreeOK (forms 10) 16771 8716 q10Shape10T102=true := by
  change (fastTreeOK (forms 10) 16771 (8716 ||| 2^18) q10Shape10T103 &&
    fastTreeOK (forms 10) (16771 ||| 2^18) 8716 q10Shape10T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T103OK,q10Shape10T104OK⟩

private def q10Shape10T105 : Tree := (.split 18 (.split 22 (.split 23 (.split 24 (.split 19 (.split 4 (.tip (.cover 3 4 6 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))) (.tip (.cover 1 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 1 5 7 8 9))))
private theorem q10Shape10T105OK : fastTreeOK (forms 10) 24963 524 q10Shape10T105=true := by decide

private def q10Shape10T101 : Tree := .split 13 q10Shape10T102 q10Shape10T105
private theorem q10Shape10T101OK : fastTreeOK (forms 10) 16771 524 q10Shape10T101=true := by
  change (fastTreeOK (forms 10) 16771 (524 ||| 2^13) q10Shape10T102 &&
    fastTreeOK (forms 10) (16771 ||| 2^13) 524 q10Shape10T105)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T102OK,q10Shape10T105OK⟩

private def q10Shape10T81 : Tree := .split 8 q10Shape10T82 q10Shape10T101
private theorem q10Shape10T81OK : fastTreeOK (forms 10) 16515 524 q10Shape10T81=true := by
  change (fastTreeOK (forms 10) 16515 (524 ||| 2^8) q10Shape10T82 &&
    fastTreeOK (forms 10) (16515 ||| 2^8) 524 q10Shape10T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T82OK,q10Shape10T101OK⟩

private def q10Shape10T109 : Tree := (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.split 10 (.split 11 (.split 12 (.split 22 (.tip (.cover 1 4 5 8 9)) (.split 23 (.tip (.cover 2 4 5 7 9)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 4 5 6 8 9))) (.tip (.cover 4 5 6 8 9))) (.tip (.unordered 2 3 4 0)))) (.split 10 (.split 22 (.split 23 (.split 24 (.split 5 (.split 11 (.tip (.cover 1 4 5 7 9)) (.split 16 (.tip (.cover 3 5 6 7 9)) (.tip (.unordered 2 3 4 0)))) (.split 11 (.split 25 (.tip (.cover 2 4 5 6 9)) (.tip (.cover 0 2 6 7 9))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 2 4 5 8 9))) (.tip (.cover 2 4 5 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T109OK : fastTreeOK (forms 10) 16519 271112 q10Shape10T109=true := by decide

private def q10Shape10T110 : Tree := (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 4 6 8 9)))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 3 6 8 9))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T110OK : fastTreeOK (forms 10) 278663 8968 q10Shape10T110=true := by decide

private def q10Shape10T108 : Tree := .split 18 q10Shape10T109 q10Shape10T110
private theorem q10Shape10T108OK : fastTreeOK (forms 10) 16519 8968 q10Shape10T108=true := by
  change (fastTreeOK (forms 10) 16519 (8968 ||| 2^18) q10Shape10T109 &&
    fastTreeOK (forms 10) (16519 ||| 2^18) 8968 q10Shape10T110)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T109OK,q10Shape10T110OK⟩

private def q10Shape10T111 : Tree := (.split 18 (.split 22 (.split 23 (.split 24 (.split 19 (.split 10 (.tip (.cover 2 4 6 8 9)) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))) (.tip (.cover 1 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 1 5 7 8 9))))
private theorem q10Shape10T111OK : fastTreeOK (forms 10) 24711 776 q10Shape10T111=true := by decide

private def q10Shape10T107 : Tree := .split 13 q10Shape10T108 q10Shape10T111
private theorem q10Shape10T107OK : fastTreeOK (forms 10) 16519 776 q10Shape10T107=true := by
  change (fastTreeOK (forms 10) 16519 (776 ||| 2^13) q10Shape10T108 &&
    fastTreeOK (forms 10) (16519 ||| 2^13) 776 q10Shape10T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T108OK,q10Shape10T111OK⟩

private def q10Shape10T112 : Tree := (.tip (.unordered 2 3 4 1))
private theorem q10Shape10T112OK : fastTreeOK (forms 10) 16775 520 q10Shape10T112=true := by decide

private def q10Shape10T106 : Tree := .split 8 q10Shape10T107 q10Shape10T112
private theorem q10Shape10T106OK : fastTreeOK (forms 10) 16519 520 q10Shape10T106=true := by
  change (fastTreeOK (forms 10) 16519 (520 ||| 2^8) q10Shape10T107 &&
    fastTreeOK (forms 10) (16519 ||| 2^8) 520 q10Shape10T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T107OK,q10Shape10T112OK⟩

private def q10Shape10T80 : Tree := .split 2 q10Shape10T81 q10Shape10T106
private theorem q10Shape10T80OK : fastTreeOK (forms 10) 16515 520 q10Shape10T80=true := by
  change (fastTreeOK (forms 10) 16515 (520 ||| 2^2) q10Shape10T81 &&
    fastTreeOK (forms 10) (16515 ||| 2^2) 520 q10Shape10T106)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T81OK,q10Shape10T106OK⟩

private def q10Shape10T78 : Tree := .split 14 q10Shape10T79 q10Shape10T80
private theorem q10Shape10T78OK : fastTreeOK (forms 10) 131 520 q10Shape10T78=true := by
  change (fastTreeOK (forms 10) 131 (520 ||| 2^14) q10Shape10T79 &&
    fastTreeOK (forms 10) (131 ||| 2^14) 520 q10Shape10T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T79OK,q10Shape10T80OK⟩

private def q10Shape10T117 : Tree := (.tip (.small 0))
private theorem q10Shape10T117OK : fastTreeOK (forms 10) 643 24844 q10Shape10T117=true := by decide

private def q10Shape10T119 : Tree := (.split 4 (.split 5 (.split 6 (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.split 22 (.split 25 (.tip (.cover 3 4 5 6 9)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 4 6 8 9)))) (.split 19 (.split 20 (.split 25 (.tip (.cover 3 4 5 6 9)) (.tip (.cover 1 3 5 8 9))) (.tip (.cover 3 4 6 8 9))) (.tip (.cover 1 3 5 8 9)))) (.split 12 (.split 17 (.tip (.cover 2 5 6 7 8)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.split 11 (.split 16 (.tip (.cover 2 5 6 7 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T119OK : fastTreeOK (forms 10) 8835 278796 q10Shape10T119=true := by decide

private def q10Shape10T120 : Tree := (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 3 4 6 8 9)))) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T120OK : fastTreeOK (forms 10) 270979 16652 q10Shape10T120=true := by decide

private def q10Shape10T118 : Tree := .split 18 q10Shape10T119 q10Shape10T120
private theorem q10Shape10T118OK : fastTreeOK (forms 10) 8835 16652 q10Shape10T118=true := by
  change (fastTreeOK (forms 10) 8835 (16652 ||| 2^18) q10Shape10T119 &&
    fastTreeOK (forms 10) (8835 ||| 2^18) 16652 q10Shape10T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T119OK,q10Shape10T120OK⟩

private def q10Shape10T116 : Tree := .split 13 q10Shape10T117 q10Shape10T118
private theorem q10Shape10T116OK : fastTreeOK (forms 10) 643 16652 q10Shape10T116=true := by
  change (fastTreeOK (forms 10) 643 (16652 ||| 2^13) q10Shape10T117 &&
    fastTreeOK (forms 10) (643 ||| 2^13) 16652 q10Shape10T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T117OK,q10Shape10T118OK⟩

private def q10Shape10T130 : Tree := (.split 15 (.tip (.cover 0 1 3 8 9)) (.split 5 (.split 16 (.tip (.cover 0 1 3 7 9)) (.split 25 (.tip (.cover 3 4 5 6 9)) (.split 6 (.split 26 (.tip (.cover 3 4 5 6 8)) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 4 5 6 7 9))))) (.split 16 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 11 (.tip (.cover 2 5 6 7 9)) (.tip (.unordered 2 3 4 0)))) (.tip (.unordered 2 3 4 0)))))
private theorem q10Shape10T130OK : fastTreeOK (forms 10) 899 33316892 q10Shape10T130=true := by decide

private def q10Shape10T131 : Tree := (.split 15 (.split 5 (.split 11 (.tip (.cover 4 5 6 7 9)) (.split 16 (.tip (.cover 0 1 3 7 9)) (.split 10 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 0))))) (.split 16 (.split 25 (.tip (.cover 2 3 5 6 9)) (.split 10 (.split 11 (.split 17 (.split 26 (.tip (.drop 1 6 7 (some 0) (some 5) (some 5))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 0 1 3 7 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.unordered 2 3 4 0)))) (.tip (.unordered 2 3 4 0)))
private theorem q10Shape10T131OK : fastTreeOK (forms 10) 915 33316876 q10Shape10T131=true := by decide

private def q10Shape10T129 : Tree := .split 4 q10Shape10T130 q10Shape10T131
private theorem q10Shape10T129OK : fastTreeOK (forms 10) 899 33316876 q10Shape10T129=true := by
  change (fastTreeOK (forms 10) 899 (33316876 ||| 2^4) q10Shape10T130 &&
    fastTreeOK (forms 10) (899 ||| 2^4) 33316876 q10Shape10T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T130OK,q10Shape10T131OK⟩

private def q10Shape10T132 : Tree := (.tip (.cover 1 3 7 8 9))
private theorem q10Shape10T132OK : fastTreeOK (forms 10) 2098051 31219724 q10Shape10T132=true := by decide

private def q10Shape10T128 : Tree := .split 21 q10Shape10T129 q10Shape10T132
private theorem q10Shape10T128OK : fastTreeOK (forms 10) 899 31219724 q10Shape10T128=true := by
  change (fastTreeOK (forms 10) 899 (31219724 ||| 2^21) q10Shape10T129 &&
    fastTreeOK (forms 10) (899 ||| 2^21) 31219724 q10Shape10T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T129OK,q10Shape10T132OK⟩

private def q10Shape10T133 : Tree := (.tip (.cover 1 3 7 8 9))
private theorem q10Shape10T133OK : fastTreeOK (forms 10) 1049475 30171148 q10Shape10T133=true := by decide

private def q10Shape10T127 : Tree := .split 20 q10Shape10T128 q10Shape10T133
private theorem q10Shape10T127OK : fastTreeOK (forms 10) 899 30171148 q10Shape10T127=true := by
  change (fastTreeOK (forms 10) 899 (30171148 ||| 2^20) q10Shape10T128 &&
    fastTreeOK (forms 10) (899 ||| 2^20) 30171148 q10Shape10T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T128OK,q10Shape10T133OK⟩

private def q10Shape10T134 : Tree := (.tip (.cover 1 3 7 8 9))
private theorem q10Shape10T134OK : fastTreeOK (forms 10) 525187 29646860 q10Shape10T134=true := by decide

private def q10Shape10T126 : Tree := .split 19 q10Shape10T127 q10Shape10T134
private theorem q10Shape10T126OK : fastTreeOK (forms 10) 899 29646860 q10Shape10T126=true := by
  change (fastTreeOK (forms 10) 899 (29646860 ||| 2^19) q10Shape10T127 &&
    fastTreeOK (forms 10) (899 ||| 2^19) 29646860 q10Shape10T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T127OK,q10Shape10T134OK⟩

private def q10Shape10T135 : Tree := (.tip (.cover 0 3 7 8 9))
private theorem q10Shape10T135OK : fastTreeOK (forms 10) 16778115 12869644 q10Shape10T135=true := by decide

private def q10Shape10T125 : Tree := .split 24 q10Shape10T126 q10Shape10T135
private theorem q10Shape10T125OK : fastTreeOK (forms 10) 899 12869644 q10Shape10T125=true := by
  change (fastTreeOK (forms 10) 899 (12869644 ||| 2^24) q10Shape10T126 &&
    fastTreeOK (forms 10) (899 ||| 2^24) 12869644 q10Shape10T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T126OK,q10Shape10T135OK⟩

private def q10Shape10T136 : Tree := (.tip (.cover 0 3 7 8 9))
private theorem q10Shape10T136OK : fastTreeOK (forms 10) 8389507 4481036 q10Shape10T136=true := by decide

private def q10Shape10T124 : Tree := .split 23 q10Shape10T125 q10Shape10T136
private theorem q10Shape10T124OK : fastTreeOK (forms 10) 899 4481036 q10Shape10T124=true := by
  change (fastTreeOK (forms 10) 899 (4481036 ||| 2^23) q10Shape10T125 &&
    fastTreeOK (forms 10) (899 ||| 2^23) 4481036 q10Shape10T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T125OK,q10Shape10T136OK⟩

private def q10Shape10T137 : Tree := (.tip (.cover 0 3 7 8 9))
private theorem q10Shape10T137OK : fastTreeOK (forms 10) 4195203 286732 q10Shape10T137=true := by decide

private def q10Shape10T123 : Tree := .split 22 q10Shape10T124 q10Shape10T137
private theorem q10Shape10T123OK : fastTreeOK (forms 10) 899 286732 q10Shape10T123=true := by
  change (fastTreeOK (forms 10) 899 (286732 ||| 2^22) q10Shape10T124 &&
    fastTreeOK (forms 10) (899 ||| 2^22) 286732 q10Shape10T137)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T124OK,q10Shape10T137OK⟩

private def q10Shape10T138 : Tree := (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 15 (.tip (.cover 2 3 5 8 9)) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 3 7 8 9)))
private theorem q10Shape10T138OK : fastTreeOK (forms 10) 263043 24588 q10Shape10T138=true := by decide

private def q10Shape10T122 : Tree := .split 18 q10Shape10T123 q10Shape10T138
private theorem q10Shape10T122OK : fastTreeOK (forms 10) 899 24588 q10Shape10T122=true := by
  change (fastTreeOK (forms 10) 899 (24588 ||| 2^18) q10Shape10T123 &&
    fastTreeOK (forms 10) (899 ||| 2^18) 24588 q10Shape10T138)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T123OK,q10Shape10T138OK⟩

private def q10Shape10T139 : Tree := (.split 18 (.split 22 (.split 23 (.split 24 (.split 19 (.split 4 (.tip (.cover 3 4 6 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))) (.tip (.cover 1 3 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 3 4 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 3 4 7 8 9))) (.tip (.cover 1 5 7 8 9))))
private theorem q10Shape10T139OK : fastTreeOK (forms 10) 9091 16396 q10Shape10T139=true := by decide

private def q10Shape10T121 : Tree := .split 13 q10Shape10T122 q10Shape10T139
private theorem q10Shape10T121OK : fastTreeOK (forms 10) 899 16396 q10Shape10T121=true := by
  change (fastTreeOK (forms 10) 899 (16396 ||| 2^13) q10Shape10T122 &&
    fastTreeOK (forms 10) (899 ||| 2^13) 16396 q10Shape10T139)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T122OK,q10Shape10T139OK⟩

private def q10Shape10T115 : Tree := .split 8 q10Shape10T116 q10Shape10T121
private theorem q10Shape10T115OK : fastTreeOK (forms 10) 643 16396 q10Shape10T115=true := by
  change (fastTreeOK (forms 10) 643 (16396 ||| 2^8) q10Shape10T116 &&
    fastTreeOK (forms 10) (643 ||| 2^8) 16396 q10Shape10T121)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T116OK,q10Shape10T121OK⟩

private def q10Shape10T143 : Tree := (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 15 (.split 16 (.split 17 (.split 22 (.tip (.cover 1 3 5 8 9)) (.split 23 (.tip (.cover 2 3 5 7 9)) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 3 5 6 8 9))) (.tip (.cover 3 5 6 8 9))) (.tip (.unordered 2 3 4 0)))) (.split 15 (.split 22 (.split 23 (.split 24 (.split 5 (.split 11 (.tip (.cover 4 5 6 7 9)) (.split 16 (.tip (.cover 1 3 5 7 9)) (.tip (.unordered 2 3 4 0)))) (.split 16 (.split 25 (.tip (.cover 2 3 5 6 9)) (.tip (.cover 0 2 6 7 9))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 2 3 5 8 9))) (.tip (.cover 2 3 5 8 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T143OK : fastTreeOK (forms 10) 647 286984 q10Shape10T143=true := by decide

private def q10Shape10T144 : Tree := (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 2 3 6 8 9)))) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 2 3 6 8 9))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T144OK : fastTreeOK (forms 10) 262791 24840 q10Shape10T144=true := by decide

private def q10Shape10T142 : Tree := .split 18 q10Shape10T143 q10Shape10T144
private theorem q10Shape10T142OK : fastTreeOK (forms 10) 647 24840 q10Shape10T142=true := by
  change (fastTreeOK (forms 10) 647 (24840 ||| 2^18) q10Shape10T143 &&
    fastTreeOK (forms 10) (647 ||| 2^18) 24840 q10Shape10T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T143OK,q10Shape10T144OK⟩

private def q10Shape10T145 : Tree := (.split 18 (.split 22 (.split 23 (.split 24 (.split 19 (.split 15 (.tip (.cover 2 3 6 8 9)) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))) (.tip (.cover 1 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 1 5 7 8 9))))
private theorem q10Shape10T145OK : fastTreeOK (forms 10) 903 24584 q10Shape10T145=true := by decide

private def q10Shape10T141 : Tree := .split 8 q10Shape10T142 q10Shape10T145
private theorem q10Shape10T141OK : fastTreeOK (forms 10) 647 24584 q10Shape10T141=true := by
  change (fastTreeOK (forms 10) 647 (24584 ||| 2^8) q10Shape10T142 &&
    fastTreeOK (forms 10) (647 ||| 2^8) 24584 q10Shape10T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T142OK,q10Shape10T145OK⟩

private def q10Shape10T146 : Tree := (.tip (.unordered 2 3 4 1))
private theorem q10Shape10T146OK : fastTreeOK (forms 10) 8839 16392 q10Shape10T146=true := by decide

private def q10Shape10T140 : Tree := .split 13 q10Shape10T141 q10Shape10T146
private theorem q10Shape10T140OK : fastTreeOK (forms 10) 647 16392 q10Shape10T140=true := by
  change (fastTreeOK (forms 10) 647 (16392 ||| 2^13) q10Shape10T141 &&
    fastTreeOK (forms 10) (647 ||| 2^13) 16392 q10Shape10T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T141OK,q10Shape10T146OK⟩

private def q10Shape10T114 : Tree := .split 2 q10Shape10T115 q10Shape10T140
private theorem q10Shape10T114OK : fastTreeOK (forms 10) 643 16392 q10Shape10T114=true := by
  change (fastTreeOK (forms 10) 643 (16392 ||| 2^2) q10Shape10T115 &&
    fastTreeOK (forms 10) (643 ||| 2^2) 16392 q10Shape10T140)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T115OK,q10Shape10T140OK⟩

private def q10Shape10T148 : Tree := (.split 8 (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 4 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 6 7 8 9))))) (.split 13 (.split 18 (.split 22 (.split 4 (.tip (.cover 3 4 5 8 9)) (.split 10 (.split 15 (.tip (.cover 2 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 3 7 8 9))) (.split 4 (.split 22 (.tip (.cover 3 4 5 8 9)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 3 4 7 8 9))))
private theorem q10Shape10T148OK : fastTreeOK (forms 10) 17027 12 q10Shape10T148=true := by decide

private def q10Shape10T149 : Tree := (.split 8 (.split 13 (.tip (.unordered 2 3 4 0)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape10T149OK : fastTreeOK (forms 10) 17031 8 q10Shape10T149=true := by decide

private def q10Shape10T147 : Tree := .split 2 q10Shape10T148 q10Shape10T149
private theorem q10Shape10T147OK : fastTreeOK (forms 10) 17027 8 q10Shape10T147=true := by
  change (fastTreeOK (forms 10) 17027 (8 ||| 2^2) q10Shape10T148 &&
    fastTreeOK (forms 10) (17027 ||| 2^2) 8 q10Shape10T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T148OK,q10Shape10T149OK⟩

private def q10Shape10T113 : Tree := .split 14 q10Shape10T114 q10Shape10T147
private theorem q10Shape10T113OK : fastTreeOK (forms 10) 643 8 q10Shape10T113=true := by
  change (fastTreeOK (forms 10) 643 (8 ||| 2^14) q10Shape10T114 &&
    fastTreeOK (forms 10) (643 ||| 2^14) 8 q10Shape10T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T114OK,q10Shape10T147OK⟩

private def q10Shape10T77 : Tree := .split 9 q10Shape10T78 q10Shape10T113
private theorem q10Shape10T77OK : fastTreeOK (forms 10) 131 8 q10Shape10T77=true := by
  change (fastTreeOK (forms 10) 131 (8 ||| 2^9) q10Shape10T78 &&
    fastTreeOK (forms 10) (131 ||| 2^9) 8 q10Shape10T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T78OK,q10Shape10T113OK⟩

private def q10Shape10T155 : Tree := (.tip (.small 0))
private theorem q10Shape10T155OK : fastTreeOK (forms 10) 139 25348 q10Shape10T155=true := by decide

private def q10Shape10T157 : Tree := (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.split 10 (.split 11 (.split 12 (.split 22 (.split 25 (.tip (.cover 2 4 5 6 9)) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 4 5 6 8 9))) (.tip (.cover 4 5 6 8 9))) (.tip (.unordered 2 3 4 0)))) (.split 10 (.split 5 (.split 16 (.tip (.cover 3 5 6 7 9)) (.split 11 (.split 12 (.split 25 (.tip (.cover 2 4 5 6 9)) (.tip (.cover 0 4 6 7 9))) (.tip (.cover 4 5 6 7 9))) (.tip (.unordered 2 3 4 0)))) (.split 11 (.split 19 (.split 20 (.split 25 (.tip (.cover 2 4 5 6 9)) (.tip (.cover 1 2 5 7 9))) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 1 2 5 8 9))) (.tip (.unordered 2 3 4 0)))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T157OK : fastTreeOK (forms 10) 8331 279300 q10Shape10T157=true := by decide

private def q10Shape10T158 : Tree := (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 4 6 8 9))) (.tip (.unordered 2 3 4 0)))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 4 6 8 9))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T158OK : fastTreeOK (forms 10) 270475 17156 q10Shape10T158=true := by decide

private def q10Shape10T156 : Tree := .split 18 q10Shape10T157 q10Shape10T158
private theorem q10Shape10T156OK : fastTreeOK (forms 10) 8331 17156 q10Shape10T156=true := by
  change (fastTreeOK (forms 10) 8331 (17156 ||| 2^18) q10Shape10T157 &&
    fastTreeOK (forms 10) (8331 ||| 2^18) 17156 q10Shape10T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T157OK,q10Shape10T158OK⟩

private def q10Shape10T154 : Tree := .split 13 q10Shape10T155 q10Shape10T156
private theorem q10Shape10T154OK : fastTreeOK (forms 10) 139 17156 q10Shape10T154=true := by
  change (fastTreeOK (forms 10) 139 (17156 ||| 2^13) q10Shape10T155 &&
    fastTreeOK (forms 10) (139 ||| 2^13) 17156 q10Shape10T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T155OK,q10Shape10T156OK⟩

private def q10Shape10T161 : Tree := (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 15 (.split 16 (.split 17 (.split 22 (.split 25 (.tip (.cover 2 3 5 6 9)) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 3 5 6 8 9))) (.tip (.cover 3 5 6 8 9))) (.tip (.unordered 2 3 4 0)))) (.split 15 (.split 5 (.split 11 (.tip (.cover 4 5 6 7 9)) (.split 16 (.split 17 (.split 25 (.tip (.cover 2 3 5 6 9)) (.tip (.cover 0 3 6 7 9))) (.tip (.cover 3 5 6 7 9))) (.tip (.unordered 2 3 4 0)))) (.split 16 (.split 19 (.split 20 (.split 25 (.tip (.cover 2 3 5 6 9)) (.tip (.cover 1 2 5 7 9))) (.tip (.cover 2 3 6 8 9))) (.tip (.cover 1 2 5 8 9))) (.tip (.unordered 2 3 4 0)))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T161OK : fastTreeOK (forms 10) 395 287236 q10Shape10T161=true := by decide

private def q10Shape10T162 : Tree := (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 2 3 6 8 9))) (.tip (.unordered 2 3 4 0)))) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 2 3 6 8 9))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T162OK : fastTreeOK (forms 10) 262539 25092 q10Shape10T162=true := by decide

private def q10Shape10T160 : Tree := .split 18 q10Shape10T161 q10Shape10T162
private theorem q10Shape10T160OK : fastTreeOK (forms 10) 395 25092 q10Shape10T160=true := by
  change (fastTreeOK (forms 10) 395 (25092 ||| 2^18) q10Shape10T161 &&
    fastTreeOK (forms 10) (395 ||| 2^18) 25092 q10Shape10T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T161OK,q10Shape10T162OK⟩

private def q10Shape10T163 : Tree := (.tip (.unordered 2 3 4 1))
private theorem q10Shape10T163OK : fastTreeOK (forms 10) 8587 16900 q10Shape10T163=true := by decide

private def q10Shape10T159 : Tree := .split 13 q10Shape10T160 q10Shape10T163
private theorem q10Shape10T159OK : fastTreeOK (forms 10) 395 16900 q10Shape10T159=true := by
  change (fastTreeOK (forms 10) 395 (16900 ||| 2^13) q10Shape10T160 &&
    fastTreeOK (forms 10) (395 ||| 2^13) 16900 q10Shape10T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T160OK,q10Shape10T163OK⟩

private def q10Shape10T153 : Tree := .split 8 q10Shape10T154 q10Shape10T159
private theorem q10Shape10T153OK : fastTreeOK (forms 10) 139 16900 q10Shape10T153=true := by
  change (fastTreeOK (forms 10) 139 (16900 ||| 2^8) q10Shape10T154 &&
    fastTreeOK (forms 10) (139 ||| 2^8) 16900 q10Shape10T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T154OK,q10Shape10T159OK⟩

private def q10Shape10T174 : Tree := (.split 5 (.split 25 (.tip (.cover 3 4 5 6 9)) (.split 26 (.split 6 (.tip (.cover 3 4 5 6 8)) (.split 27 (.split 10 (.split 12 (.tip (.cover 2 4 5 6 8)) (.tip (.cover 4 5 6 8 9))) (.split 17 (.tip (.cover 2 3 5 6 8)) (.tip (.cover 3 5 6 8 9)))) (.tip (.cover 0 1 2 7 8)))) (.tip (.cover 0 1 2 8 9)))) (.split 25 (.split 27 (.split 26 (.tip (.cover 2 3 4 5 6)) (.split 6 (.split 10 (.split 11 (.tip (.cover 2 4 5 6 9)) (.tip (.cover 4 5 6 8 9))) (.split 16 (.tip (.cover 2 3 5 6 9)) (.tip (.cover 3 5 6 8 9)))) (.tip (.cover 0 1 2 7 8)))) (.tip (.cover 0 1 2 7 9))) (.tip (.cover 0 1 2 7 9))))
private theorem q10Shape10T174OK : fastTreeOK (forms 10) 143 33317648 q10Shape10T174=true := by decide

private def q10Shape10T175 : Tree := (.split 25 (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.split 5 (.split 6 (.split 10 (.split 11 (.tip (.cover 2 4 5 6 9)) (.split 15 (.tip (.drop 1 6 7 (some 0) (some 5) none)) (.tip (.drop 1 6 7 (some 0) (some 5) (some 5))))) (.split 11 (.tip (.cover 4 5 6 7 9)) (.tip (.cover 2 3 5 6 9)))) (.tip (.cover 0 1 2 7 8))) (.tip (.cover 0 1 2 7 9)))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape10T175OK : fastTreeOK (forms 10) 159 33317632 q10Shape10T175=true := by decide

private def q10Shape10T173 : Tree := .split 4 q10Shape10T174 q10Shape10T175
private theorem q10Shape10T173OK : fastTreeOK (forms 10) 143 33317632 q10Shape10T173=true := by
  change (fastTreeOK (forms 10) 143 (33317632 ||| 2^4) q10Shape10T174 &&
    fastTreeOK (forms 10) (143 ||| 2^4) 33317632 q10Shape10T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T174OK,q10Shape10T175OK⟩

private def q10Shape10T176 : Tree := (.tip (.cover 1 2 7 8 9))
private theorem q10Shape10T176OK : fastTreeOK (forms 10) 2097295 31220480 q10Shape10T176=true := by decide

private def q10Shape10T172 : Tree := .split 21 q10Shape10T173 q10Shape10T176
private theorem q10Shape10T172OK : fastTreeOK (forms 10) 143 31220480 q10Shape10T172=true := by
  change (fastTreeOK (forms 10) 143 (31220480 ||| 2^21) q10Shape10T173 &&
    fastTreeOK (forms 10) (143 ||| 2^21) 31220480 q10Shape10T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T173OK,q10Shape10T176OK⟩

private def q10Shape10T177 : Tree := (.tip (.cover 1 2 7 8 9))
private theorem q10Shape10T177OK : fastTreeOK (forms 10) 1048719 30171904 q10Shape10T177=true := by decide

private def q10Shape10T171 : Tree := .split 20 q10Shape10T172 q10Shape10T177
private theorem q10Shape10T171OK : fastTreeOK (forms 10) 143 30171904 q10Shape10T171=true := by
  change (fastTreeOK (forms 10) 143 (30171904 ||| 2^20) q10Shape10T172 &&
    fastTreeOK (forms 10) (143 ||| 2^20) 30171904 q10Shape10T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T172OK,q10Shape10T177OK⟩

private def q10Shape10T178 : Tree := (.tip (.cover 1 2 7 8 9))
private theorem q10Shape10T178OK : fastTreeOK (forms 10) 524431 29647616 q10Shape10T178=true := by decide

private def q10Shape10T170 : Tree := .split 19 q10Shape10T171 q10Shape10T178
private theorem q10Shape10T170OK : fastTreeOK (forms 10) 143 29647616 q10Shape10T170=true := by
  change (fastTreeOK (forms 10) 143 (29647616 ||| 2^19) q10Shape10T171 &&
    fastTreeOK (forms 10) (143 ||| 2^19) 29647616 q10Shape10T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T171OK,q10Shape10T178OK⟩

private def q10Shape10T179 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape10T179OK : fastTreeOK (forms 10) 16777359 12870400 q10Shape10T179=true := by decide

private def q10Shape10T169 : Tree := .split 24 q10Shape10T170 q10Shape10T179
private theorem q10Shape10T169OK : fastTreeOK (forms 10) 143 12870400 q10Shape10T169=true := by
  change (fastTreeOK (forms 10) 143 (12870400 ||| 2^24) q10Shape10T170 &&
    fastTreeOK (forms 10) (143 ||| 2^24) 12870400 q10Shape10T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T170OK,q10Shape10T179OK⟩

private def q10Shape10T180 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape10T180OK : fastTreeOK (forms 10) 8388751 4481792 q10Shape10T180=true := by decide

private def q10Shape10T168 : Tree := .split 23 q10Shape10T169 q10Shape10T180
private theorem q10Shape10T168OK : fastTreeOK (forms 10) 143 4481792 q10Shape10T168=true := by
  change (fastTreeOK (forms 10) 143 (4481792 ||| 2^23) q10Shape10T169 &&
    fastTreeOK (forms 10) (143 ||| 2^23) 4481792 q10Shape10T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T169OK,q10Shape10T180OK⟩

private def q10Shape10T181 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape10T181OK : fastTreeOK (forms 10) 4194447 287488 q10Shape10T181=true := by decide

private def q10Shape10T167 : Tree := .split 22 q10Shape10T168 q10Shape10T181
private theorem q10Shape10T167OK : fastTreeOK (forms 10) 143 287488 q10Shape10T167=true := by
  change (fastTreeOK (forms 10) 143 (287488 ||| 2^22) q10Shape10T168 &&
    fastTreeOK (forms 10) (143 ||| 2^22) 287488 q10Shape10T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T168OK,q10Shape10T181OK⟩

private def q10Shape10T182 : Tree := (.split 22 (.split 10 (.tip (.cover 2 4 5 8 9)) (.split 15 (.tip (.cover 2 3 5 8 9)) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 2 7 8 9)))
private theorem q10Shape10T182OK : fastTreeOK (forms 10) 262287 25344 q10Shape10T182=true := by decide

private def q10Shape10T166 : Tree := .split 18 q10Shape10T167 q10Shape10T182
private theorem q10Shape10T166OK : fastTreeOK (forms 10) 143 25344 q10Shape10T166=true := by
  change (fastTreeOK (forms 10) 143 (25344 ||| 2^18) q10Shape10T167 &&
    fastTreeOK (forms 10) (143 ||| 2^18) 25344 q10Shape10T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T167OK,q10Shape10T182OK⟩

private def q10Shape10T183 : Tree := (.split 18 (.split 22 (.split 23 (.split 24 (.split 19 (.split 10 (.tip (.cover 2 4 6 8 9)) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))) (.tip (.cover 1 2 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 2 4 7 8 9))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 2 4 7 8 9))) (.tip (.cover 1 5 7 8 9))))
private theorem q10Shape10T183OK : fastTreeOK (forms 10) 8335 17152 q10Shape10T183=true := by decide

private def q10Shape10T165 : Tree := .split 13 q10Shape10T166 q10Shape10T183
private theorem q10Shape10T165OK : fastTreeOK (forms 10) 143 17152 q10Shape10T165=true := by
  change (fastTreeOK (forms 10) 143 (17152 ||| 2^13) q10Shape10T166 &&
    fastTreeOK (forms 10) (143 ||| 2^13) 17152 q10Shape10T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T166OK,q10Shape10T183OK⟩

private def q10Shape10T184 : Tree := (.split 13 (.split 18 (.split 22 (.split 23 (.split 24 (.split 19 (.split 15 (.tip (.cover 2 3 6 8 9)) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))) (.tip (.cover 1 2 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 2 3 7 8 9))) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 2 3 7 8 9))) (.tip (.cover 1 5 7 8 9)))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape10T184OK : fastTreeOK (forms 10) 399 16896 q10Shape10T184=true := by decide

private def q10Shape10T164 : Tree := .split 8 q10Shape10T165 q10Shape10T184
private theorem q10Shape10T164OK : fastTreeOK (forms 10) 143 16896 q10Shape10T164=true := by
  change (fastTreeOK (forms 10) 143 (16896 ||| 2^8) q10Shape10T165 &&
    fastTreeOK (forms 10) (143 ||| 2^8) 16896 q10Shape10T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T165OK,q10Shape10T184OK⟩

private def q10Shape10T152 : Tree := .split 2 q10Shape10T153 q10Shape10T164
private theorem q10Shape10T152OK : fastTreeOK (forms 10) 139 16896 q10Shape10T152=true := by
  change (fastTreeOK (forms 10) 139 (16896 ||| 2^2) q10Shape10T153 &&
    fastTreeOK (forms 10) (139 ||| 2^2) 16896 q10Shape10T164)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T153OK,q10Shape10T164OK⟩

private def q10Shape10T186 : Tree := (.split 8 (.split 13 (.tip (.small 0)) (.split 18 (.split 22 (.split 10 (.tip (.cover 2 4 5 8 9)) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 4 7 8 9))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 6 7 8 9))))) (.split 13 (.tip (.unordered 2 3 4 0)) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T186OK : fastTreeOK (forms 10) 16523 516 q10Shape10T186=true := by decide

private def q10Shape10T187 : Tree := (.split 8 (.split 13 (.split 18 (.split 22 (.split 10 (.tip (.cover 2 4 5 8 9)) (.split 4 (.split 15 (.tip (.cover 3 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 2 7 8 9))) (.split 10 (.split 22 (.tip (.cover 2 4 5 8 9)) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 2 4 7 8 9))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape10T187OK : fastTreeOK (forms 10) 16527 512 q10Shape10T187=true := by decide

private def q10Shape10T185 : Tree := .split 2 q10Shape10T186 q10Shape10T187
private theorem q10Shape10T185OK : fastTreeOK (forms 10) 16523 512 q10Shape10T185=true := by
  change (fastTreeOK (forms 10) 16523 (512 ||| 2^2) q10Shape10T186 &&
    fastTreeOK (forms 10) (16523 ||| 2^2) 512 q10Shape10T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T186OK,q10Shape10T187OK⟩

private def q10Shape10T151 : Tree := .split 14 q10Shape10T152 q10Shape10T185
private theorem q10Shape10T151OK : fastTreeOK (forms 10) 139 512 q10Shape10T151=true := by
  change (fastTreeOK (forms 10) 139 (512 ||| 2^14) q10Shape10T152 &&
    fastTreeOK (forms 10) (139 ||| 2^14) 512 q10Shape10T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T152OK,q10Shape10T185OK⟩

private def q10Shape10T190 : Tree := (.split 8 (.split 13 (.tip (.small 0)) (.tip (.unordered 2 3 4 0))) (.split 13 (.split 18 (.split 22 (.split 15 (.tip (.cover 2 3 5 8 9)) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 3 7 8 9))) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.tip (.unordered 2 3 4 0))))
private theorem q10Shape10T190OK : fastTreeOK (forms 10) 651 16388 q10Shape10T190=true := by decide

private def q10Shape10T191 : Tree := (.split 13 (.split 8 (.split 18 (.split 22 (.split 15 (.tip (.cover 2 3 5 8 9)) (.split 4 (.split 10 (.tip (.cover 4 5 6 8 9)) (.tip (.unordered 2 3 4 0))) (.tip (.unordered 2 3 4 0)))) (.tip (.cover 0 2 7 8 9))) (.split 15 (.split 22 (.tip (.cover 2 3 5 8 9)) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 6 7 8 9)))) (.tip (.cover 2 3 7 8 9))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape10T191OK : fastTreeOK (forms 10) 655 16384 q10Shape10T191=true := by decide

private def q10Shape10T189 : Tree := .split 2 q10Shape10T190 q10Shape10T191
private theorem q10Shape10T189OK : fastTreeOK (forms 10) 651 16384 q10Shape10T189=true := by
  change (fastTreeOK (forms 10) 651 (16384 ||| 2^2) q10Shape10T190 &&
    fastTreeOK (forms 10) (651 ||| 2^2) 16384 q10Shape10T191)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T190OK,q10Shape10T191OK⟩

private def q10Shape10T192 : Tree := (.tip (.unordered 2 3 4 0))
private theorem q10Shape10T192OK : fastTreeOK (forms 10) 17035 0 q10Shape10T192=true := by decide

private def q10Shape10T188 : Tree := .split 14 q10Shape10T189 q10Shape10T192
private theorem q10Shape10T188OK : fastTreeOK (forms 10) 651 0 q10Shape10T188=true := by
  change (fastTreeOK (forms 10) 651 (0 ||| 2^14) q10Shape10T189 &&
    fastTreeOK (forms 10) (651 ||| 2^14) 0 q10Shape10T192)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T189OK,q10Shape10T192OK⟩

private def q10Shape10T150 : Tree := .split 9 q10Shape10T151 q10Shape10T188
private theorem q10Shape10T150OK : fastTreeOK (forms 10) 139 0 q10Shape10T150=true := by
  change (fastTreeOK (forms 10) 139 (0 ||| 2^9) q10Shape10T151 &&
    fastTreeOK (forms 10) (139 ||| 2^9) 0 q10Shape10T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T151OK,q10Shape10T188OK⟩

private def q10Shape10T76 : Tree := .split 3 q10Shape10T77 q10Shape10T150
private theorem q10Shape10T76OK : fastTreeOK (forms 10) 131 0 q10Shape10T76=true := by
  change (fastTreeOK (forms 10) 131 (0 ||| 2^3) q10Shape10T77 &&
    fastTreeOK (forms 10) (131 ||| 2^3) 0 q10Shape10T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T77OK,q10Shape10T150OK⟩

private def q10Shape10T52 : Tree := .split 7 q10Shape10T53 q10Shape10T76
private theorem q10Shape10T52OK : fastTreeOK (forms 10) 3 0 q10Shape10T52=true := by
  change (fastTreeOK (forms 10) 3 (0 ||| 2^7) q10Shape10T53 &&
    fastTreeOK (forms 10) (3 ||| 2^7) 0 q10Shape10T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T53OK,q10Shape10T76OK⟩

private def q10Shape10T28 : Tree := .split 1 q10Shape10T29 q10Shape10T52
private theorem q10Shape10T28OK : fastTreeOK (forms 10) 1 0 q10Shape10T28=true := by
  change (fastTreeOK (forms 10) 1 (0 ||| 2^1) q10Shape10T29 &&
    fastTreeOK (forms 10) (1 ||| 2^1) 0 q10Shape10T52)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T29OK,q10Shape10T52OK⟩

private def q10Shape10T0 : Tree := .split 0 q10Shape10T1 q10Shape10T28
private theorem q10Shape10T0OK : fastTreeOK (forms 10) 0 0 q10Shape10T0=true := by
  change (fastTreeOK (forms 10) 0 (0 ||| 2^0) q10Shape10T1 &&
    fastTreeOK (forms 10) (0 ||| 2^0) 0 q10Shape10T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape10T1OK,q10Shape10T28OK⟩


theorem q10Shape10_cover (b : Nat→Bool) (H : Ranked (adj (forms 10) b)) :
    ∃ u v w z t,Effective (adj (forms 10) b) (adj (forms 10) b) u v w z t :=
  checked_fastTree (forms 10) b H q10Shape10T0 q10Shape10T0OK

#print axioms q10Shape10_cover
end Graffiti384b.Q10
