import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape12T3 : Tree := (.split 13 (.split 14 (.tip (.small 0)) (.split 18 (.tip (.small 0)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 6 7)))))) (.split 14 (.split 18 (.tip (.small 0)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))))))
private theorem q10Shape12T3OK : fastTreeOK (forms 12) 0 896 q10Shape12T3=true := by decide

private def q10Shape12T4 : Tree := (.split 13 (.split 14 (.split 18 (.tip (.small 0)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 4 6 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 5 6 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 6 7 9))))) (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 6 7 9))))))
private theorem q10Shape12T4OK : fastTreeOK (forms 12) 512 384 q10Shape12T4=true := by decide

private def q10Shape12T2 : Tree := .split 9 q10Shape12T3 q10Shape12T4
private theorem q10Shape12T2OK : fastTreeOK (forms 12) 0 384 q10Shape12T2=true := by
  change (fastTreeOK (forms 12) 0 (384 ||| 2^9) q10Shape12T3 &&
    fastTreeOK (forms 12) (0 ||| 2^9) 384 q10Shape12T4)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T3OK,q10Shape12T4OK⟩

private def q10Shape12T6 : Tree := (.split 13 (.split 14 (.split 18 (.tip (.small 0)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 4 5 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))))) (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 5 6 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 5 7 9)))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 5 7 9))))))
private theorem q10Shape12T6OK : fastTreeOK (forms 12) 256 640 q10Shape12T6=true := by decide

private def q10Shape12T8 : Tree := (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 6 7 9)))))
private theorem q10Shape12T8OK : fastTreeOK (forms 12) 768 8320 q10Shape12T8=true := by decide

private def q10Shape12T9 : Tree := (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 5 7 9)))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 2 3 4 8 9)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 5 7 9)))))
private theorem q10Shape12T9OK : fastTreeOK (forms 12) 8960 128 q10Shape12T9=true := by decide

private def q10Shape12T7 : Tree := .split 13 q10Shape12T8 q10Shape12T9
private theorem q10Shape12T7OK : fastTreeOK (forms 12) 768 128 q10Shape12T7=true := by
  change (fastTreeOK (forms 12) 768 (128 ||| 2^13) q10Shape12T8 &&
    fastTreeOK (forms 12) (768 ||| 2^13) 128 q10Shape12T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T8OK,q10Shape12T9OK⟩

private def q10Shape12T5 : Tree := .split 9 q10Shape12T6 q10Shape12T7
private theorem q10Shape12T5OK : fastTreeOK (forms 12) 256 128 q10Shape12T5=true := by
  change (fastTreeOK (forms 12) 256 (128 ||| 2^9) q10Shape12T6 &&
    fastTreeOK (forms 12) (256 ||| 2^9) 128 q10Shape12T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T6OK,q10Shape12T7OK⟩

private def q10Shape12T1 : Tree := .split 8 q10Shape12T2 q10Shape12T5
private theorem q10Shape12T1OK : fastTreeOK (forms 12) 0 128 q10Shape12T1=true := by
  change (fastTreeOK (forms 12) 0 (128 ||| 2^8) q10Shape12T2 &&
    fastTreeOK (forms 12) (0 ||| 2^8) 128 q10Shape12T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T2OK,q10Shape12T5OK⟩

private def q10Shape12T12 : Tree := (.split 13 (.split 14 (.split 18 (.tip (.small 0)) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 4 5 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7)))))) (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 4 6 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 4 7 9))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 4 7 9))))))
private theorem q10Shape12T12OK : fastTreeOK (forms 12) 128 768 q10Shape12T12=true := by decide

private def q10Shape12T14 : Tree := (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 6 7 9)))))
private theorem q10Shape12T14OK : fastTreeOK (forms 12) 640 8448 q10Shape12T14=true := by decide

private def q10Shape12T15 : Tree := (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 2 3 5 8 9))))) (.split 18 (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 4 7 9))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 4 7 9)))))
private theorem q10Shape12T15OK : fastTreeOK (forms 12) 8832 256 q10Shape12T15=true := by decide

private def q10Shape12T13 : Tree := .split 13 q10Shape12T14 q10Shape12T15
private theorem q10Shape12T13OK : fastTreeOK (forms 12) 640 256 q10Shape12T13=true := by
  change (fastTreeOK (forms 12) 640 (256 ||| 2^13) q10Shape12T14 &&
    fastTreeOK (forms 12) (640 ||| 2^13) 256 q10Shape12T15)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T14OK,q10Shape12T15OK⟩

private def q10Shape12T11 : Tree := .split 9 q10Shape12T12 q10Shape12T13
private theorem q10Shape12T11OK : fastTreeOK (forms 12) 128 256 q10Shape12T11=true := by
  change (fastTreeOK (forms 12) 128 (256 ||| 2^9) q10Shape12T12 &&
    fastTreeOK (forms 12) (128 ||| 2^9) 256 q10Shape12T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T12OK,q10Shape12T13OK⟩

private def q10Shape12T18 : Tree := (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 6 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 5 7))))) (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 4 7)))) (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 2 3 6 8 9))))))
private theorem q10Shape12T18OK : fastTreeOK (forms 12) 384 8704 q10Shape12T18=true := by decide

private def q10Shape12T19 : Tree := (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.split 26 (.tip (.small 1)) (.tip (.cover 0 1 3 6 7)))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 5 7 9)))) (.split 18 (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 4 7 9))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 4 7 9)))))
private theorem q10Shape12T19OK : fastTreeOK (forms 12) 8576 512 q10Shape12T19=true := by decide

private def q10Shape12T17 : Tree := .split 13 q10Shape12T18 q10Shape12T19
private theorem q10Shape12T17OK : fastTreeOK (forms 12) 384 512 q10Shape12T17=true := by
  change (fastTreeOK (forms 12) 384 (512 ||| 2^13) q10Shape12T18 &&
    fastTreeOK (forms 12) (384 ||| 2^13) 512 q10Shape12T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T18OK,q10Shape12T19OK⟩

private def q10Shape12T20 : Tree := (.split 13 (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9)))) (.split 18 (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9))))) (.split 14 (.split 18 (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9)))) (.split 18 (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9))) (.split 25 (.tip (.small 1)) (.tip (.cover 0 1 3 7 9))))))
private theorem q10Shape12T20OK : fastTreeOK (forms 12) 896 0 q10Shape12T20=true := by decide

private def q10Shape12T16 : Tree := .split 9 q10Shape12T17 q10Shape12T20
private theorem q10Shape12T16OK : fastTreeOK (forms 12) 384 0 q10Shape12T16=true := by
  change (fastTreeOK (forms 12) 384 (0 ||| 2^9) q10Shape12T17 &&
    fastTreeOK (forms 12) (384 ||| 2^9) 0 q10Shape12T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T17OK,q10Shape12T20OK⟩

private def q10Shape12T10 : Tree := .split 8 q10Shape12T11 q10Shape12T16
private theorem q10Shape12T10OK : fastTreeOK (forms 12) 128 0 q10Shape12T10=true := by
  change (fastTreeOK (forms 12) 128 (0 ||| 2^8) q10Shape12T11 &&
    fastTreeOK (forms 12) (128 ||| 2^8) 0 q10Shape12T16)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T11OK,q10Shape12T16OK⟩

private def q10Shape12T0 : Tree := .split 7 q10Shape12T1 q10Shape12T10
private theorem q10Shape12T0OK : fastTreeOK (forms 12) 0 0 q10Shape12T0=true := by
  change (fastTreeOK (forms 12) 0 (0 ||| 2^7) q10Shape12T1 &&
    fastTreeOK (forms 12) (0 ||| 2^7) 0 q10Shape12T10)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape12T1OK,q10Shape12T10OK⟩


theorem q10Shape12_cover (b : Nat→Bool) (H : Ranked (adj (forms 12) b)) :
    ∃ u v w z t,Effective (adj (forms 12) b) (adj (forms 12) b) u v w z t :=
  checked_fastTree (forms 12) b H q10Shape12T0 q10Shape12T0OK

#print axioms q10Shape12_cover
end Graffiti384b.Q10
