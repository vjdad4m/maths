import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape13T2 : Tree := (.tip (.small 1))
private theorem q10Shape13T2OK : fastTreeOK (forms 13) 0 17 q10Shape13T2=true := by decide

private def q10Shape13T4 : Tree := (.tip (.small 1))
private theorem q10Shape13T4OK : fastTreeOK (forms 13) 16 33 q10Shape13T4=true := by decide

private def q10Shape13T6 : Tree := (.tip (.small 1))
private theorem q10Shape13T6OK : fastTreeOK (forms 13) 48 1025 q10Shape13T6=true := by decide

private def q10Shape13T8 : Tree := (.tip (.small 1))
private theorem q10Shape13T8OK : fastTreeOK (forms 13) 1072 2049 q10Shape13T8=true := by decide

private def q10Shape13T10 : Tree := (.tip (.small 1))
private theorem q10Shape13T10OK : fastTreeOK (forms 13) 3120 33554433 q10Shape13T10=true := by decide

private def q10Shape13T12 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.tip (.small 0)) (.split 9 (.tip (.small 0)) (.tip (.cover 0 1 3 4 9)))) (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9)))) (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover 2 3 4 5 9))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 5 9)))) (.split 3 (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 1 2 4 9))))
private theorem q10Shape13T12OK : fastTreeOK (forms 13) 33557552 3 q10Shape13T12=true := by decide

private def q10Shape13T13 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 2 3 5 6 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape13T13OK : fastTreeOK (forms 13) 33557554 1 q10Shape13T13=true := by decide

private def q10Shape13T11 : Tree := .split 1 q10Shape13T12 q10Shape13T13
private theorem q10Shape13T11OK : fastTreeOK (forms 13) 33557552 1 q10Shape13T11=true := by
  change (fastTreeOK (forms 13) 33557552 (1 ||| 2^1) q10Shape13T12 &&
    fastTreeOK (forms 13) (33557552 ||| 2^1) 1 q10Shape13T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T12OK,q10Shape13T13OK⟩

private def q10Shape13T9 : Tree := .split 25 q10Shape13T10 q10Shape13T11
private theorem q10Shape13T9OK : fastTreeOK (forms 13) 3120 1 q10Shape13T9=true := by
  change (fastTreeOK (forms 13) 3120 (1 ||| 2^25) q10Shape13T10 &&
    fastTreeOK (forms 13) (3120 ||| 2^25) 1 q10Shape13T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T10OK,q10Shape13T11OK⟩

private def q10Shape13T7 : Tree := .split 11 q10Shape13T8 q10Shape13T9
private theorem q10Shape13T7OK : fastTreeOK (forms 13) 1072 1 q10Shape13T7=true := by
  change (fastTreeOK (forms 13) 1072 (1 ||| 2^11) q10Shape13T8 &&
    fastTreeOK (forms 13) (1072 ||| 2^11) 1 q10Shape13T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T8OK,q10Shape13T9OK⟩

private def q10Shape13T5 : Tree := .split 10 q10Shape13T6 q10Shape13T7
private theorem q10Shape13T5OK : fastTreeOK (forms 13) 48 1 q10Shape13T5=true := by
  change (fastTreeOK (forms 13) 48 (1 ||| 2^10) q10Shape13T6 &&
    fastTreeOK (forms 13) (48 ||| 2^10) 1 q10Shape13T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T6OK,q10Shape13T7OK⟩

private def q10Shape13T3 : Tree := .split 5 q10Shape13T4 q10Shape13T5
private theorem q10Shape13T3OK : fastTreeOK (forms 13) 16 1 q10Shape13T3=true := by
  change (fastTreeOK (forms 13) 16 (1 ||| 2^5) q10Shape13T4 &&
    fastTreeOK (forms 13) (16 ||| 2^5) 1 q10Shape13T5)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T4OK,q10Shape13T5OK⟩

private def q10Shape13T1 : Tree := .split 4 q10Shape13T2 q10Shape13T3
private theorem q10Shape13T1OK : fastTreeOK (forms 13) 0 1 q10Shape13T1=true := by
  change (fastTreeOK (forms 13) 0 (1 ||| 2^4) q10Shape13T2 &&
    fastTreeOK (forms 13) (0 ||| 2^4) 1 q10Shape13T3)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T2OK,q10Shape13T3OK⟩

private def q10Shape13T16 : Tree := (.tip (.small 1))
private theorem q10Shape13T16OK : fastTreeOK (forms 13) 1 48 q10Shape13T16=true := by decide

private def q10Shape13T18 : Tree := (.tip (.small 1))
private theorem q10Shape13T18OK : fastTreeOK (forms 13) 33 1040 q10Shape13T18=true := by decide

private def q10Shape13T20 : Tree := (.tip (.small 1))
private theorem q10Shape13T20OK : fastTreeOK (forms 13) 1057 2064 q10Shape13T20=true := by decide

private def q10Shape13T22 : Tree := (.tip (.small 1))
private theorem q10Shape13T22OK : fastTreeOK (forms 13) 3105 33554448 q10Shape13T22=true := by decide

private def q10Shape13T25 : Tree := (.split 3 (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 0 1 3 4 9)))) (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 4 6 8 9))) (.tip (.cover 0 1 3 4 9)))) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 5 6 8 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9)))) (.split 13 (.split 14 (.split 18 (.split 9 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 5 7 9))) (.tip (.cover 2 4 5 7 9))) (.tip (.cover 0 2 4 7 9))))
private theorem q10Shape13T25OK : fastTreeOK (forms 13) 33557537 22 q10Shape13T25=true := by decide

private def q10Shape13T26 : Tree := (.split 3 (.split 13 (.split 14 (.split 18 (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 6 7 9))) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 2 4 6 7 9))) (.tip (.cover 0 2 4 7 9)))
private theorem q10Shape13T26OK : fastTreeOK (forms 13) 33557541 18 q10Shape13T26=true := by decide

private def q10Shape13T24 : Tree := .split 2 q10Shape13T25 q10Shape13T26
private theorem q10Shape13T24OK : fastTreeOK (forms 13) 33557537 18 q10Shape13T24=true := by
  change (fastTreeOK (forms 13) 33557537 (18 ||| 2^2) q10Shape13T25 &&
    fastTreeOK (forms 13) (33557537 ||| 2^2) 18 q10Shape13T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T25OK,q10Shape13T26OK⟩

private def q10Shape13T27 : Tree := (.split 2 (.split 3 (.split 13 (.split 14 (.split 18 (.split 7 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 2 6 7 9)))
private theorem q10Shape13T27OK : fastTreeOK (forms 13) 33557539 16 q10Shape13T27=true := by decide

private def q10Shape13T23 : Tree := .split 1 q10Shape13T24 q10Shape13T27
private theorem q10Shape13T23OK : fastTreeOK (forms 13) 33557537 16 q10Shape13T23=true := by
  change (fastTreeOK (forms 13) 33557537 (16 ||| 2^1) q10Shape13T24 &&
    fastTreeOK (forms 13) (33557537 ||| 2^1) 16 q10Shape13T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T24OK,q10Shape13T27OK⟩

private def q10Shape13T21 : Tree := .split 25 q10Shape13T22 q10Shape13T23
private theorem q10Shape13T21OK : fastTreeOK (forms 13) 3105 16 q10Shape13T21=true := by
  change (fastTreeOK (forms 13) 3105 (16 ||| 2^25) q10Shape13T22 &&
    fastTreeOK (forms 13) (3105 ||| 2^25) 16 q10Shape13T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T22OK,q10Shape13T23OK⟩

private def q10Shape13T19 : Tree := .split 11 q10Shape13T20 q10Shape13T21
private theorem q10Shape13T19OK : fastTreeOK (forms 13) 1057 16 q10Shape13T19=true := by
  change (fastTreeOK (forms 13) 1057 (16 ||| 2^11) q10Shape13T20 &&
    fastTreeOK (forms 13) (1057 ||| 2^11) 16 q10Shape13T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T20OK,q10Shape13T21OK⟩

private def q10Shape13T17 : Tree := .split 10 q10Shape13T18 q10Shape13T19
private theorem q10Shape13T17OK : fastTreeOK (forms 13) 33 16 q10Shape13T17=true := by
  change (fastTreeOK (forms 13) 33 (16 ||| 2^10) q10Shape13T18 &&
    fastTreeOK (forms 13) (33 ||| 2^10) 16 q10Shape13T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T18OK,q10Shape13T19OK⟩

private def q10Shape13T15 : Tree := .split 5 q10Shape13T16 q10Shape13T17
private theorem q10Shape13T15OK : fastTreeOK (forms 13) 1 16 q10Shape13T15=true := by
  change (fastTreeOK (forms 13) 1 (16 ||| 2^5) q10Shape13T16 &&
    fastTreeOK (forms 13) (1 ||| 2^5) 16 q10Shape13T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T16OK,q10Shape13T17OK⟩

private def q10Shape13T30 : Tree := (.tip (.small 1))
private theorem q10Shape13T30OK : fastTreeOK (forms 13) 17 1056 q10Shape13T30=true := by decide

private def q10Shape13T32 : Tree := (.tip (.small 1))
private theorem q10Shape13T32OK : fastTreeOK (forms 13) 1041 2080 q10Shape13T32=true := by decide

private def q10Shape13T34 : Tree := (.tip (.small 1))
private theorem q10Shape13T34OK : fastTreeOK (forms 13) 3089 33554464 q10Shape13T34=true := by decide

private def q10Shape13T37 : Tree := (.split 3 (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 0 1 3 4 9)))) (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 4 6 7 9))) (.tip (.cover 0 1 3 4 9)))) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 5 6 7 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9)))) (.split 13 (.split 14 (.split 18 (.split 9 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 5 8 9))) (.tip (.cover 2 4 5 8 9))) (.tip (.cover 0 2 4 8 9))))
private theorem q10Shape13T37OK : fastTreeOK (forms 13) 33557521 38 q10Shape13T37=true := by decide

private def q10Shape13T38 : Tree := (.split 3 (.split 13 (.split 14 (.split 18 (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 0 2 4 8 9)))
private theorem q10Shape13T38OK : fastTreeOK (forms 13) 33557525 34 q10Shape13T38=true := by decide

private def q10Shape13T36 : Tree := .split 2 q10Shape13T37 q10Shape13T38
private theorem q10Shape13T36OK : fastTreeOK (forms 13) 33557521 34 q10Shape13T36=true := by
  change (fastTreeOK (forms 13) 33557521 (34 ||| 2^2) q10Shape13T37 &&
    fastTreeOK (forms 13) (33557521 ||| 2^2) 34 q10Shape13T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T37OK,q10Shape13T38OK⟩

private def q10Shape13T39 : Tree := (.split 2 (.split 3 (.split 13 (.split 14 (.split 18 (.split 7 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 5 8 9))) (.tip (.cover 2 5 6 8 9))) (.tip (.cover 2 5 6 8 9))) (.tip (.cover 0 2 5 8 9))) (.tip (.cover 0 2 6 8 9)))
private theorem q10Shape13T39OK : fastTreeOK (forms 13) 33557523 32 q10Shape13T39=true := by decide

private def q10Shape13T35 : Tree := .split 1 q10Shape13T36 q10Shape13T39
private theorem q10Shape13T35OK : fastTreeOK (forms 13) 33557521 32 q10Shape13T35=true := by
  change (fastTreeOK (forms 13) 33557521 (32 ||| 2^1) q10Shape13T36 &&
    fastTreeOK (forms 13) (33557521 ||| 2^1) 32 q10Shape13T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T36OK,q10Shape13T39OK⟩

private def q10Shape13T33 : Tree := .split 25 q10Shape13T34 q10Shape13T35
private theorem q10Shape13T33OK : fastTreeOK (forms 13) 3089 32 q10Shape13T33=true := by
  change (fastTreeOK (forms 13) 3089 (32 ||| 2^25) q10Shape13T34 &&
    fastTreeOK (forms 13) (3089 ||| 2^25) 32 q10Shape13T35)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T34OK,q10Shape13T35OK⟩

private def q10Shape13T31 : Tree := .split 11 q10Shape13T32 q10Shape13T33
private theorem q10Shape13T31OK : fastTreeOK (forms 13) 1041 32 q10Shape13T31=true := by
  change (fastTreeOK (forms 13) 1041 (32 ||| 2^11) q10Shape13T32 &&
    fastTreeOK (forms 13) (1041 ||| 2^11) 32 q10Shape13T33)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T32OK,q10Shape13T33OK⟩

private def q10Shape13T29 : Tree := .split 10 q10Shape13T30 q10Shape13T31
private theorem q10Shape13T29OK : fastTreeOK (forms 13) 17 32 q10Shape13T29=true := by
  change (fastTreeOK (forms 13) 17 (32 ||| 2^10) q10Shape13T30 &&
    fastTreeOK (forms 13) (17 ||| 2^10) 32 q10Shape13T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T30OK,q10Shape13T31OK⟩

private def q10Shape13T42 : Tree := (.tip (.small 1))
private theorem q10Shape13T42OK : fastTreeOK (forms 13) 49 3072 q10Shape13T42=true := by decide

private def q10Shape13T44 : Tree := (.tip (.small 1))
private theorem q10Shape13T44OK : fastTreeOK (forms 13) 2097 33555456 q10Shape13T44=true := by decide

private def q10Shape13T47 : Tree := (.split 3 (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 0 3 4 7 9)))) (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 4 6 7 9))) (.tip (.cover 0 3 4 7 9)))) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 5 6 7 9))) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 3 6 7 9)))) (.split 13 (.split 14 (.split 18 (.split 9 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 5 8 9))) (.tip (.cover 2 4 5 8 9))) (.tip (.cover 0 1 2 4 9))))
private theorem q10Shape13T47OK : fastTreeOK (forms 13) 33556529 1030 q10Shape13T47=true := by decide

private def q10Shape13T48 : Tree := (.split 3 (.split 13 (.split 14 (.split 18 (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 0 1 2 4 9))) (.tip (.cover 2 4 6 8 9))) (.tip (.cover 0 1 2 4 9)))
private theorem q10Shape13T48OK : fastTreeOK (forms 13) 33556533 1026 q10Shape13T48=true := by decide

private def q10Shape13T46 : Tree := .split 2 q10Shape13T47 q10Shape13T48
private theorem q10Shape13T46OK : fastTreeOK (forms 13) 33556529 1026 q10Shape13T46=true := by
  change (fastTreeOK (forms 13) 33556529 (1026 ||| 2^2) q10Shape13T47 &&
    fastTreeOK (forms 13) (33556529 ||| 2^2) 1026 q10Shape13T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T47OK,q10Shape13T48OK⟩

private def q10Shape13T49 : Tree := (.split 2 (.split 3 (.split 13 (.split 14 (.split 18 (.split 7 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 2 5 6 8 9))) (.tip (.cover 2 5 6 8 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape13T49OK : fastTreeOK (forms 13) 33556531 1024 q10Shape13T49=true := by decide

private def q10Shape13T45 : Tree := .split 1 q10Shape13T46 q10Shape13T49
private theorem q10Shape13T45OK : fastTreeOK (forms 13) 33556529 1024 q10Shape13T45=true := by
  change (fastTreeOK (forms 13) 33556529 (1024 ||| 2^1) q10Shape13T46 &&
    fastTreeOK (forms 13) (33556529 ||| 2^1) 1024 q10Shape13T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T46OK,q10Shape13T49OK⟩

private def q10Shape13T43 : Tree := .split 25 q10Shape13T44 q10Shape13T45
private theorem q10Shape13T43OK : fastTreeOK (forms 13) 2097 1024 q10Shape13T43=true := by
  change (fastTreeOK (forms 13) 2097 (1024 ||| 2^25) q10Shape13T44 &&
    fastTreeOK (forms 13) (2097 ||| 2^25) 1024 q10Shape13T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T44OK,q10Shape13T45OK⟩

private def q10Shape13T41 : Tree := .split 11 q10Shape13T42 q10Shape13T43
private theorem q10Shape13T41OK : fastTreeOK (forms 13) 49 1024 q10Shape13T41=true := by
  change (fastTreeOK (forms 13) 49 (1024 ||| 2^11) q10Shape13T42 &&
    fastTreeOK (forms 13) (49 ||| 2^11) 1024 q10Shape13T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T42OK,q10Shape13T43OK⟩

private def q10Shape13T52 : Tree := (.tip (.small 1))
private theorem q10Shape13T52OK : fastTreeOK (forms 13) 1073 33556480 q10Shape13T52=true := by decide

private def q10Shape13T55 : Tree := (.split 3 (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 0 3 4 8 9)))) (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 4 6 8 9))) (.tip (.cover 0 3 4 8 9)))) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 3 5 6 8 9))) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 3 6 8 9)))) (.split 13 (.split 14 (.split 18 (.split 9 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 5 7 9))) (.tip (.cover 2 4 5 7 9))) (.tip (.cover 0 1 2 4 9))))
private theorem q10Shape13T55OK : fastTreeOK (forms 13) 33555505 2054 q10Shape13T55=true := by decide

private def q10Shape13T56 : Tree := (.split 3 (.split 13 (.split 14 (.split 18 (.split 8 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 4 6 7 9))) (.tip (.cover 0 1 2 4 9))) (.tip (.cover 2 4 6 7 9))) (.tip (.cover 0 1 2 4 9)))
private theorem q10Shape13T56OK : fastTreeOK (forms 13) 33555509 2050 q10Shape13T56=true := by decide

private def q10Shape13T54 : Tree := .split 2 q10Shape13T55 q10Shape13T56
private theorem q10Shape13T54OK : fastTreeOK (forms 13) 33555505 2050 q10Shape13T54=true := by
  change (fastTreeOK (forms 13) 33555505 (2050 ||| 2^2) q10Shape13T55 &&
    fastTreeOK (forms 13) (33555505 ||| 2^2) 2050 q10Shape13T56)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T55OK,q10Shape13T56OK⟩

private def q10Shape13T57 : Tree := (.split 2 (.split 3 (.split 13 (.split 14 (.split 18 (.split 7 (.tip (.small 0)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape13T57OK : fastTreeOK (forms 13) 33555507 2048 q10Shape13T57=true := by decide

private def q10Shape13T53 : Tree := .split 1 q10Shape13T54 q10Shape13T57
private theorem q10Shape13T53OK : fastTreeOK (forms 13) 33555505 2048 q10Shape13T53=true := by
  change (fastTreeOK (forms 13) 33555505 (2048 ||| 2^1) q10Shape13T54 &&
    fastTreeOK (forms 13) (33555505 ||| 2^1) 2048 q10Shape13T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T54OK,q10Shape13T57OK⟩

private def q10Shape13T51 : Tree := .split 25 q10Shape13T52 q10Shape13T53
private theorem q10Shape13T51OK : fastTreeOK (forms 13) 1073 2048 q10Shape13T51=true := by
  change (fastTreeOK (forms 13) 1073 (2048 ||| 2^25) q10Shape13T52 &&
    fastTreeOK (forms 13) (1073 ||| 2^25) 2048 q10Shape13T53)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T52OK,q10Shape13T53OK⟩

private def q10Shape13T60 : Tree := (.split 3 (.split 7 (.split 8 (.split 9 (.tip (.small 0)) (.split 13 (.tip (.small 0)) (.tip (.cover 0 1 3 4 9)))) (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 1 3 4 9)))) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 2 3 5 6 9))) (.tip (.cover 0 1 3 5 9))) (.tip (.cover 0 1 3 6 9)))) (.split 7 (.split 8 (.split 13 (.tip (.cover 0 6 7 8 9)) (.tip (.cover 0 1 2 4 9))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 5 9))))
private theorem q10Shape13T60OK : fastTreeOK (forms 13) 3121 6 q10Shape13T60=true := by decide

private def q10Shape13T61 : Tree := (.split 3 (.split 7 (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 0 1 2 4 9)))
private theorem q10Shape13T61OK : fastTreeOK (forms 13) 3125 2 q10Shape13T61=true := by decide

private def q10Shape13T59 : Tree := .split 2 q10Shape13T60 q10Shape13T61
private theorem q10Shape13T59OK : fastTreeOK (forms 13) 3121 2 q10Shape13T59=true := by
  change (fastTreeOK (forms 13) 3121 (2 ||| 2^2) q10Shape13T60 &&
    fastTreeOK (forms 13) (3121 ||| 2^2) 2 q10Shape13T61)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T60OK,q10Shape13T61OK⟩

private def q10Shape13T62 : Tree := (.split 2 (.split 3 (.split 7 (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 2 3 5 6 9))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 6 9))) (.tip (.cover 2 3 5 6 9))) (.tip (.cover 0 1 2 5 9))) (.tip (.cover 0 1 2 6 9)))
private theorem q10Shape13T62OK : fastTreeOK (forms 13) 3123 0 q10Shape13T62=true := by decide

private def q10Shape13T58 : Tree := .split 1 q10Shape13T59 q10Shape13T62
private theorem q10Shape13T58OK : fastTreeOK (forms 13) 3121 0 q10Shape13T58=true := by
  change (fastTreeOK (forms 13) 3121 (0 ||| 2^1) q10Shape13T59 &&
    fastTreeOK (forms 13) (3121 ||| 2^1) 0 q10Shape13T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T59OK,q10Shape13T62OK⟩

private def q10Shape13T50 : Tree := .split 11 q10Shape13T51 q10Shape13T58
private theorem q10Shape13T50OK : fastTreeOK (forms 13) 1073 0 q10Shape13T50=true := by
  change (fastTreeOK (forms 13) 1073 (0 ||| 2^11) q10Shape13T51 &&
    fastTreeOK (forms 13) (1073 ||| 2^11) 0 q10Shape13T58)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T51OK,q10Shape13T58OK⟩

private def q10Shape13T40 : Tree := .split 10 q10Shape13T41 q10Shape13T50
private theorem q10Shape13T40OK : fastTreeOK (forms 13) 49 0 q10Shape13T40=true := by
  change (fastTreeOK (forms 13) 49 (0 ||| 2^10) q10Shape13T41 &&
    fastTreeOK (forms 13) (49 ||| 2^10) 0 q10Shape13T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T41OK,q10Shape13T50OK⟩

private def q10Shape13T28 : Tree := .split 5 q10Shape13T29 q10Shape13T40
private theorem q10Shape13T28OK : fastTreeOK (forms 13) 17 0 q10Shape13T28=true := by
  change (fastTreeOK (forms 13) 17 (0 ||| 2^5) q10Shape13T29 &&
    fastTreeOK (forms 13) (17 ||| 2^5) 0 q10Shape13T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T29OK,q10Shape13T40OK⟩

private def q10Shape13T14 : Tree := .split 4 q10Shape13T15 q10Shape13T28
private theorem q10Shape13T14OK : fastTreeOK (forms 13) 1 0 q10Shape13T14=true := by
  change (fastTreeOK (forms 13) 1 (0 ||| 2^4) q10Shape13T15 &&
    fastTreeOK (forms 13) (1 ||| 2^4) 0 q10Shape13T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T15OK,q10Shape13T28OK⟩

private def q10Shape13T0 : Tree := .split 0 q10Shape13T1 q10Shape13T14
private theorem q10Shape13T0OK : fastTreeOK (forms 13) 0 0 q10Shape13T0=true := by
  change (fastTreeOK (forms 13) 0 (0 ||| 2^0) q10Shape13T1 &&
    fastTreeOK (forms 13) (0 ||| 2^0) 0 q10Shape13T14)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape13T1OK,q10Shape13T14OK⟩


theorem q10Shape13_cover (b : Nat→Bool) (H : Ranked (adj (forms 13) b)) :
    ∃ u v w z t,Effective (adj (forms 13) b) (adj (forms 13) b) u v w z t :=
  checked_fastTree (forms 13) b H q10Shape13T0 q10Shape13T0OK

#print axioms q10Shape13_cover
end Graffiti384b.Q10
