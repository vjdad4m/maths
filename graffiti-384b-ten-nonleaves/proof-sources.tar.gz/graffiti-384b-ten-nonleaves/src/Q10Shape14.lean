import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape14T6 : Tree := (.tip (.small 1))
private theorem q10Shape14T6OK : fastTreeOK (forms 14) 0 5014544 q10Shape14T6=true := by decide

private def q10Shape14T8 : Tree := (.tip (.small 1))
private theorem q10Shape14T8OK : fastTreeOK (forms 14) 32768 4981777 q10Shape14T8=true := by decide

private def q10Shape14T10 : Tree := (.tip (.small 1))
private theorem q10Shape14T10OK : fastTreeOK (forms 14) 32769 4981778 q10Shape14T10=true := by decide

private def q10Shape14T12 : Tree := (.tip (.small 1))
private theorem q10Shape14T12OK : fastTreeOK (forms 14) 32771 4981904 q10Shape14T12=true := by decide

private def q10Shape14T18 : Tree := (.split 9 (.tip (.cover 0 1 4 8 9)) (.split 13 (.tip (.cover 0 3 7 8 9)) (.split 14 (.split 20 (.split 21 (.split 23 (.split 24 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 5 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 2 5 6 7 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 4 8 9)))))
private theorem q10Shape14T18OK : fastTreeOK (forms 14) 32899 105645340 q10Shape14T18=true := by decide

private def q10Shape14T19 : Tree := (.split 9 (.split 13 (.split 14 (.tip (.cover 0 3 7 8 9)) (.split 20 (.split 21 (.split 23 (.split 24 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 5 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 2 5 6 7 9)))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 3 7 8 9)))
private theorem q10Shape14T19OK : fastTreeOK (forms 14) 33155 105645084 q10Shape14T19=true := by decide

private def q10Shape14T17 : Tree := .split 8 q10Shape14T18 q10Shape14T19
private theorem q10Shape14T17OK : fastTreeOK (forms 14) 32899 105645084 q10Shape14T17=true := by
  change (fastTreeOK (forms 14) 32899 (105645084 ||| 2^8) q10Shape14T18 &&
    fastTreeOK (forms 14) (32899 ||| 2^8) 105645084 q10Shape14T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T18OK,q10Shape14T19OK⟩

private def q10Shape14T20 : Tree := (.tip (.cover 0 3 4 8 9))
private theorem q10Shape14T20OK : fastTreeOK (forms 14) 67141763 38536220 q10Shape14T20=true := by decide

private def q10Shape14T16 : Tree := .split 26 q10Shape14T17 q10Shape14T20
private theorem q10Shape14T16OK : fastTreeOK (forms 14) 32899 38536220 q10Shape14T16=true := by
  change (fastTreeOK (forms 14) 32899 (38536220 ||| 2^26) q10Shape14T17 &&
    fastTreeOK (forms 14) (32899 ||| 2^26) 38536220 q10Shape14T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T17OK,q10Shape14T20OK⟩

private def q10Shape14T21 : Tree := (.tip (.cover 0 3 4 8 9))
private theorem q10Shape14T21OK : fastTreeOK (forms 14) 33587331 4981788 q10Shape14T21=true := by decide

private def q10Shape14T15 : Tree := .split 25 q10Shape14T16 q10Shape14T21
private theorem q10Shape14T15OK : fastTreeOK (forms 14) 32899 4981788 q10Shape14T15=true := by
  change (fastTreeOK (forms 14) 32899 (4981788 ||| 2^25) q10Shape14T16 &&
    fastTreeOK (forms 14) (32899 ||| 2^25) 4981788 q10Shape14T21)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T16OK,q10Shape14T21OK⟩

private def q10Shape14T22 : Tree := (.split 8 (.split 9 (.split 13 (.tip (.cover 0 2 7 8 9)) (.split 14 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 11 (.tip (.cover 0 1 2 4 9)) (.tip (.cover 3 5 6 7 9)))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape14T22OK : fastTreeOK (forms 14) 32907 4981780 q10Shape14T22=true := by decide

private def q10Shape14T14 : Tree := .split 3 q10Shape14T15 q10Shape14T22
private theorem q10Shape14T14OK : fastTreeOK (forms 14) 32899 4981780 q10Shape14T14=true := by
  change (fastTreeOK (forms 14) 32899 (4981780 ||| 2^3) q10Shape14T15 &&
    fastTreeOK (forms 14) (32899 ||| 2^3) 4981780 q10Shape14T22)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T15OK,q10Shape14T22OK⟩

private def q10Shape14T23 : Tree := (.split 8 (.split 9 (.split 3 (.split 13 (.split 14 (.tip (.cover 0 2 7 8 9)) (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 11 (.tip (.cover 0 1 2 4 9)) (.tip (.cover 3 5 6 7 9)))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape14T23OK : fastTreeOK (forms 14) 32903 4981776 q10Shape14T23=true := by decide

private def q10Shape14T13 : Tree := .split 2 q10Shape14T14 q10Shape14T23
private theorem q10Shape14T13OK : fastTreeOK (forms 14) 32899 4981776 q10Shape14T13=true := by
  change (fastTreeOK (forms 14) 32899 (4981776 ||| 2^2) q10Shape14T14 &&
    fastTreeOK (forms 14) (32899 ||| 2^2) 4981776 q10Shape14T23)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T14OK,q10Shape14T23OK⟩

private def q10Shape14T11 : Tree := .split 7 q10Shape14T12 q10Shape14T13
private theorem q10Shape14T11OK : fastTreeOK (forms 14) 32771 4981776 q10Shape14T11=true := by
  change (fastTreeOK (forms 14) 32771 (4981776 ||| 2^7) q10Shape14T12 &&
    fastTreeOK (forms 14) (32771 ||| 2^7) 4981776 q10Shape14T13)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T12OK,q10Shape14T13OK⟩

private def q10Shape14T9 : Tree := .split 1 q10Shape14T10 q10Shape14T11
private theorem q10Shape14T9OK : fastTreeOK (forms 14) 32769 4981776 q10Shape14T9=true := by
  change (fastTreeOK (forms 14) 32769 (4981776 ||| 2^1) q10Shape14T10 &&
    fastTreeOK (forms 14) (32769 ||| 2^1) 4981776 q10Shape14T11)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T10OK,q10Shape14T11OK⟩

private def q10Shape14T7 : Tree := .split 0 q10Shape14T8 q10Shape14T9
private theorem q10Shape14T7OK : fastTreeOK (forms 14) 32768 4981776 q10Shape14T7=true := by
  change (fastTreeOK (forms 14) 32768 (4981776 ||| 2^0) q10Shape14T8 &&
    fastTreeOK (forms 14) (32768 ||| 2^0) 4981776 q10Shape14T9)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T8OK,q10Shape14T9OK⟩

private def q10Shape14T5 : Tree := .split 15 q10Shape14T6 q10Shape14T7
private theorem q10Shape14T5OK : fastTreeOK (forms 14) 0 4981776 q10Shape14T5=true := by
  change (fastTreeOK (forms 14) 0 (4981776 ||| 2^15) q10Shape14T6 &&
    fastTreeOK (forms 14) (0 ||| 2^15) 4981776 q10Shape14T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T6OK,q10Shape14T7OK⟩

private def q10Shape14T26 : Tree := (.tip (.small 1))
private theorem q10Shape14T26OK : fastTreeOK (forms 14) 1024 5013521 q10Shape14T26=true := by decide

private def q10Shape14T28 : Tree := (.tip (.small 1))
private theorem q10Shape14T28OK : fastTreeOK (forms 14) 1025 5013522 q10Shape14T28=true := by decide

private def q10Shape14T30 : Tree := (.tip (.small 1))
private theorem q10Shape14T30OK : fastTreeOK (forms 14) 1027 5013648 q10Shape14T30=true := by decide

private def q10Shape14T36 : Tree := (.split 9 (.tip (.cover 0 4 7 8 9)) (.split 13 (.tip (.cover 0 1 3 8 9)) (.split 14 (.split 20 (.split 21 (.split 23 (.split 24 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 5 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 2 5 6 7 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 4 7 8 9)))))
private theorem q10Shape14T36OK : fastTreeOK (forms 14) 1155 105677084 q10Shape14T36=true := by decide

private def q10Shape14T37 : Tree := (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 3 8 9)) (.split 20 (.split 21 (.split 23 (.split 24 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 5 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 2 5 6 7 9)))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape14T37OK : fastTreeOK (forms 14) 1411 105676828 q10Shape14T37=true := by decide

private def q10Shape14T35 : Tree := .split 8 q10Shape14T36 q10Shape14T37
private theorem q10Shape14T35OK : fastTreeOK (forms 14) 1155 105676828 q10Shape14T35=true := by
  change (fastTreeOK (forms 14) 1155 (105676828 ||| 2^8) q10Shape14T36 &&
    fastTreeOK (forms 14) (1155 ||| 2^8) 105676828 q10Shape14T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T36OK,q10Shape14T37OK⟩

private def q10Shape14T38 : Tree := (.tip (.cover 0 3 4 8 9))
private theorem q10Shape14T38OK : fastTreeOK (forms 14) 67110019 38567964 q10Shape14T38=true := by decide

private def q10Shape14T34 : Tree := .split 26 q10Shape14T35 q10Shape14T38
private theorem q10Shape14T34OK : fastTreeOK (forms 14) 1155 38567964 q10Shape14T34=true := by
  change (fastTreeOK (forms 14) 1155 (38567964 ||| 2^26) q10Shape14T35 &&
    fastTreeOK (forms 14) (1155 ||| 2^26) 38567964 q10Shape14T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T35OK,q10Shape14T38OK⟩

private def q10Shape14T39 : Tree := (.tip (.cover 0 3 4 8 9))
private theorem q10Shape14T39OK : fastTreeOK (forms 14) 33555587 5013532 q10Shape14T39=true := by decide

private def q10Shape14T33 : Tree := .split 25 q10Shape14T34 q10Shape14T39
private theorem q10Shape14T33OK : fastTreeOK (forms 14) 1155 5013532 q10Shape14T33=true := by
  change (fastTreeOK (forms 14) 1155 (5013532 ||| 2^25) q10Shape14T34 &&
    fastTreeOK (forms 14) (1155 ||| 2^25) 5013532 q10Shape14T39)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T34OK,q10Shape14T39OK⟩

private def q10Shape14T40 : Tree := (.split 13 (.split 14 (.split 8 (.tip (.cover 0 2 7 8 9)) (.split 9 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 16 (.tip (.cover 0 1 2 3 9)) (.tip (.cover 4 5 6 7 9)))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape14T40OK : fastTreeOK (forms 14) 1163 5013524 q10Shape14T40=true := by decide

private def q10Shape14T32 : Tree := .split 3 q10Shape14T33 q10Shape14T40
private theorem q10Shape14T32OK : fastTreeOK (forms 14) 1155 5013524 q10Shape14T32=true := by
  change (fastTreeOK (forms 14) 1155 (5013524 ||| 2^3) q10Shape14T33 &&
    fastTreeOK (forms 14) (1155 ||| 2^3) 5013524 q10Shape14T40)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T33OK,q10Shape14T40OK⟩

private def q10Shape14T41 : Tree := (.split 13 (.split 14 (.split 3 (.split 8 (.split 9 (.tip (.cover 0 2 7 8 9)) (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 16 (.tip (.cover 0 1 2 3 9)) (.tip (.cover 4 5 6 7 9)))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 2 7 8 9))) (.tip (.unordered 2 3 4 1))) (.tip (.unordered 2 3 4 1)))
private theorem q10Shape14T41OK : fastTreeOK (forms 14) 1159 5013520 q10Shape14T41=true := by decide

private def q10Shape14T31 : Tree := .split 2 q10Shape14T32 q10Shape14T41
private theorem q10Shape14T31OK : fastTreeOK (forms 14) 1155 5013520 q10Shape14T31=true := by
  change (fastTreeOK (forms 14) 1155 (5013520 ||| 2^2) q10Shape14T32 &&
    fastTreeOK (forms 14) (1155 ||| 2^2) 5013520 q10Shape14T41)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T32OK,q10Shape14T41OK⟩

private def q10Shape14T29 : Tree := .split 7 q10Shape14T30 q10Shape14T31
private theorem q10Shape14T29OK : fastTreeOK (forms 14) 1027 5013520 q10Shape14T29=true := by
  change (fastTreeOK (forms 14) 1027 (5013520 ||| 2^7) q10Shape14T30 &&
    fastTreeOK (forms 14) (1027 ||| 2^7) 5013520 q10Shape14T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T30OK,q10Shape14T31OK⟩

private def q10Shape14T27 : Tree := .split 1 q10Shape14T28 q10Shape14T29
private theorem q10Shape14T27OK : fastTreeOK (forms 14) 1025 5013520 q10Shape14T27=true := by
  change (fastTreeOK (forms 14) 1025 (5013520 ||| 2^1) q10Shape14T28 &&
    fastTreeOK (forms 14) (1025 ||| 2^1) 5013520 q10Shape14T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T28OK,q10Shape14T29OK⟩

private def q10Shape14T25 : Tree := .split 0 q10Shape14T26 q10Shape14T27
private theorem q10Shape14T25OK : fastTreeOK (forms 14) 1024 5013520 q10Shape14T25=true := by
  change (fastTreeOK (forms 14) 1024 (5013520 ||| 2^0) q10Shape14T26 &&
    fastTreeOK (forms 14) (1024 ||| 2^0) 5013520 q10Shape14T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T26OK,q10Shape14T27OK⟩

private def q10Shape14T43 : Tree := (.split 3 (.split 0 (.split 1 (.tip (.small 1)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 3 4 8 9))) (.split 20 (.split 21 (.split 8 (.split 13 (.tip (.cover 0 2 7 8 9)) (.split 14 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9)))) (.split 9 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 2 7 8 9))))
private theorem q10Shape14T43OK : fastTreeOK (forms 14) 33792 4980756 q10Shape14T43=true := by decide

private def q10Shape14T47 : Tree := (.split 8 (.split 9 (.split 13 (.split 14 (.tip (.cover 0 2 7 8 9)) (.split 20 (.split 21 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.split 20 (.split 21 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9)))) (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 3 8 9)) (.split 0 (.split 1 (.tip (.small 1)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 3 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape14T47OK : fastTreeOK (forms 14) 33796 30146584 q10Shape14T47=true := by decide

private def q10Shape14T48 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape14T48OK : fastTreeOK (forms 14) 16811012 13369368 q10Shape14T48=true := by decide

private def q10Shape14T46 : Tree := .split 24 q10Shape14T47 q10Shape14T48
private theorem q10Shape14T46OK : fastTreeOK (forms 14) 33796 13369368 q10Shape14T46=true := by
  change (fastTreeOK (forms 14) 33796 (13369368 ||| 2^24) q10Shape14T47 &&
    fastTreeOK (forms 14) (33796 ||| 2^24) 13369368 q10Shape14T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T47OK,q10Shape14T48OK⟩

private def q10Shape14T49 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape14T49OK : fastTreeOK (forms 14) 8422404 4980760 q10Shape14T49=true := by decide

private def q10Shape14T45 : Tree := .split 23 q10Shape14T46 q10Shape14T49
private theorem q10Shape14T45OK : fastTreeOK (forms 14) 33796 4980760 q10Shape14T45=true := by
  change (fastTreeOK (forms 14) 33796 (4980760 ||| 2^23) q10Shape14T46 &&
    fastTreeOK (forms 14) (33796 ||| 2^23) 4980760 q10Shape14T49)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T46OK,q10Shape14T49OK⟩

private def q10Shape14T50 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape14T50OK : fastTreeOK (forms 14) 33804 4980752 q10Shape14T50=true := by decide

private def q10Shape14T44 : Tree := .split 3 q10Shape14T45 q10Shape14T50
private theorem q10Shape14T44OK : fastTreeOK (forms 14) 33796 4980752 q10Shape14T44=true := by
  change (fastTreeOK (forms 14) 33796 (4980752 ||| 2^3) q10Shape14T45 &&
    fastTreeOK (forms 14) (33796 ||| 2^3) 4980752 q10Shape14T50)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T45OK,q10Shape14T50OK⟩

private def q10Shape14T42 : Tree := .split 2 q10Shape14T43 q10Shape14T44
private theorem q10Shape14T42OK : fastTreeOK (forms 14) 33792 4980752 q10Shape14T42=true := by
  change (fastTreeOK (forms 14) 33792 (4980752 ||| 2^2) q10Shape14T43 &&
    fastTreeOK (forms 14) (33792 ||| 2^2) 4980752 q10Shape14T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T43OK,q10Shape14T44OK⟩

private def q10Shape14T24 : Tree := .split 15 q10Shape14T25 q10Shape14T42
private theorem q10Shape14T24OK : fastTreeOK (forms 14) 1024 4980752 q10Shape14T24=true := by
  change (fastTreeOK (forms 14) 1024 (4980752 ||| 2^15) q10Shape14T25 &&
    fastTreeOK (forms 14) (1024 ||| 2^15) 4980752 q10Shape14T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T25OK,q10Shape14T42OK⟩

private def q10Shape14T4 : Tree := .split 10 q10Shape14T5 q10Shape14T24
private theorem q10Shape14T4OK : fastTreeOK (forms 14) 0 4980752 q10Shape14T4=true := by
  change (fastTreeOK (forms 14) 0 (4980752 ||| 2^10) q10Shape14T5 &&
    fastTreeOK (forms 14) (0 ||| 2^10) 4980752 q10Shape14T24)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T5OK,q10Shape14T24OK⟩

private def q10Shape14T54 : Tree := (.tip (.small 1))
private theorem q10Shape14T54OK : fastTreeOK (forms 14) 16 5014529 q10Shape14T54=true := by decide

private def q10Shape14T56 : Tree := (.tip (.small 1))
private theorem q10Shape14T56OK : fastTreeOK (forms 14) 17 5014530 q10Shape14T56=true := by decide

private def q10Shape14T58 : Tree := (.tip (.small 1))
private theorem q10Shape14T58OK : fastTreeOK (forms 14) 19 5014656 q10Shape14T58=true := by decide

private def q10Shape14T61 : Tree := (.split 8 (.split 9 (.tip (.cover 0 4 7 8 9)) (.split 13 (.tip (.cover 0 3 7 8 9)) (.tip (.unordered 2 3 4 1)))) (.split 14 (.tip (.cover 0 3 7 8 9)) (.tip (.unordered 2 3 4 1))))
private theorem q10Shape14T61OK : fastTreeOK (forms 14) 147 5014540 q10Shape14T61=true := by decide

private def q10Shape14T62 : Tree := (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 5 (.split 9 (.split 14 (.split 6 (.split 8 (.split 13 (.tip (.drop 1 5 7 (some 0) none (some 6))) (.tip (.drop 2 6 7 (some 0) (some 5) (some 5)))) (.split 11 (.tip (.cover 4 5 6 7 9)) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 2 5 9)))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 5 8 9))) (.tip (.cover 1 2 5 8 9))) (.tip (.cover 1 2 5 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T62OK : fastTreeOK (forms 14) 155 5014532 q10Shape14T62=true := by decide

private def q10Shape14T60 : Tree := .split 3 q10Shape14T61 q10Shape14T62
private theorem q10Shape14T60OK : fastTreeOK (forms 14) 147 5014532 q10Shape14T60=true := by
  change (fastTreeOK (forms 14) 147 (5014532 ||| 2^3) q10Shape14T61 &&
    fastTreeOK (forms 14) (147 ||| 2^3) 5014532 q10Shape14T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T61OK,q10Shape14T62OK⟩

private def q10Shape14T63 : Tree := (.split 3 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 27 (.tip (.cover 0 2 3 4 7)) (.split 5 (.split 8 (.split 13 (.split 6 (.split 9 (.split 14 (.tip (.drop 1 6 7 (some 0) none (some 5))) (.tip (.drop 2 6 7 (some 0) (some 5) (some 5)))) (.split 11 (.tip (.cover 4 5 6 7 9)) (.tip (.cover 0 1 2 3 9)))) (.tip (.cover 0 1 2 6 8))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 1 2 6 9)))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 6 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 1 2 6 8 9))) (.tip (.cover 1 2 6 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T63OK : fastTreeOK (forms 14) 151 5014528 q10Shape14T63=true := by decide

private def q10Shape14T59 : Tree := .split 2 q10Shape14T60 q10Shape14T63
private theorem q10Shape14T59OK : fastTreeOK (forms 14) 147 5014528 q10Shape14T59=true := by
  change (fastTreeOK (forms 14) 147 (5014528 ||| 2^2) q10Shape14T60 &&
    fastTreeOK (forms 14) (147 ||| 2^2) 5014528 q10Shape14T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T60OK,q10Shape14T63OK⟩

private def q10Shape14T57 : Tree := .split 7 q10Shape14T58 q10Shape14T59
private theorem q10Shape14T57OK : fastTreeOK (forms 14) 19 5014528 q10Shape14T57=true := by
  change (fastTreeOK (forms 14) 19 (5014528 ||| 2^7) q10Shape14T58 &&
    fastTreeOK (forms 14) (19 ||| 2^7) 5014528 q10Shape14T59)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T58OK,q10Shape14T59OK⟩

private def q10Shape14T55 : Tree := .split 1 q10Shape14T56 q10Shape14T57
private theorem q10Shape14T55OK : fastTreeOK (forms 14) 17 5014528 q10Shape14T55=true := by
  change (fastTreeOK (forms 14) 17 (5014528 ||| 2^1) q10Shape14T56 &&
    fastTreeOK (forms 14) (17 ||| 2^1) 5014528 q10Shape14T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T56OK,q10Shape14T57OK⟩

private def q10Shape14T53 : Tree := .split 0 q10Shape14T54 q10Shape14T55
private theorem q10Shape14T53OK : fastTreeOK (forms 14) 16 5014528 q10Shape14T53=true := by
  change (fastTreeOK (forms 14) 16 (5014528 ||| 2^0) q10Shape14T54 &&
    fastTreeOK (forms 14) (16 ||| 2^0) 5014528 q10Shape14T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T54OK,q10Shape14T55OK⟩

private def q10Shape14T67 : Tree := (.split 9 (.tip (.cover 0 1 4 8 9)) (.split 13 (.tip (.cover 0 3 7 8 9)) (.split 14 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 3 4 7 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 4 8 9)))))
private theorem q10Shape14T67OK : fastTreeOK (forms 14) 32784 4982028 q10Shape14T67=true := by decide

private def q10Shape14T68 : Tree := (.split 9 (.split 13 (.split 14 (.tip (.cover 0 3 7 8 9)) (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 3 4 7 9)))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 3 7 8 9)))
private theorem q10Shape14T68OK : fastTreeOK (forms 14) 33040 4981772 q10Shape14T68=true := by decide

private def q10Shape14T66 : Tree := .split 8 q10Shape14T67 q10Shape14T68
private theorem q10Shape14T66OK : fastTreeOK (forms 14) 32784 4981772 q10Shape14T66=true := by
  change (fastTreeOK (forms 14) 32784 (4981772 ||| 2^8) q10Shape14T67 &&
    fastTreeOK (forms 14) (32784 ||| 2^8) 4981772 q10Shape14T68)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T67OK,q10Shape14T68OK⟩

private def q10Shape14T69 : Tree := (.split 20 (.split 21 (.split 8 (.split 13 (.tip (.cover 0 1 2 8 9)) (.split 14 (.split 0 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 1 4 8 9)))) (.split 9 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 7 8 9)))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T69OK : fastTreeOK (forms 14) 32792 4981764 q10Shape14T69=true := by decide

private def q10Shape14T65 : Tree := .split 3 q10Shape14T66 q10Shape14T69
private theorem q10Shape14T65OK : fastTreeOK (forms 14) 32784 4981764 q10Shape14T65=true := by
  change (fastTreeOK (forms 14) 32784 (4981764 ||| 2^3) q10Shape14T66 &&
    fastTreeOK (forms 14) (32784 ||| 2^3) 4981764 q10Shape14T69)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T66OK,q10Shape14T69OK⟩

private def q10Shape14T71 : Tree := (.split 23 (.split 24 (.split 8 (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 2 8 9)) (.split 0 (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 2 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.split 20 (.split 21 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 7 8 9)))) (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 2 8 9)) (.split 0 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 2 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 3 7 8 9)))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T71OK : fastTreeOK (forms 14) 32788 4981768 q10Shape14T71=true := by decide

private def q10Shape14T72 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape14T72OK : fastTreeOK (forms 14) 32796 4981760 q10Shape14T72=true := by decide

private def q10Shape14T70 : Tree := .split 3 q10Shape14T71 q10Shape14T72
private theorem q10Shape14T70OK : fastTreeOK (forms 14) 32788 4981760 q10Shape14T70=true := by
  change (fastTreeOK (forms 14) 32788 (4981760 ||| 2^3) q10Shape14T71 &&
    fastTreeOK (forms 14) (32788 ||| 2^3) 4981760 q10Shape14T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T71OK,q10Shape14T72OK⟩

private def q10Shape14T64 : Tree := .split 2 q10Shape14T65 q10Shape14T70
private theorem q10Shape14T64OK : fastTreeOK (forms 14) 32784 4981760 q10Shape14T64=true := by
  change (fastTreeOK (forms 14) 32784 (4981760 ||| 2^2) q10Shape14T65 &&
    fastTreeOK (forms 14) (32784 ||| 2^2) 4981760 q10Shape14T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T65OK,q10Shape14T70OK⟩

private def q10Shape14T52 : Tree := .split 15 q10Shape14T53 q10Shape14T64
private theorem q10Shape14T52OK : fastTreeOK (forms 14) 16 4981760 q10Shape14T52=true := by
  change (fastTreeOK (forms 14) 16 (4981760 ||| 2^15) q10Shape14T53 &&
    fastTreeOK (forms 14) (16 ||| 2^15) 4981760 q10Shape14T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T53OK,q10Shape14T64OK⟩

private def q10Shape14T77 : Tree := (.split 9 (.tip (.cover 0 4 7 8 9)) (.split 13 (.tip (.cover 0 1 3 8 9)) (.split 14 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 3 4 7 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 4 7 8 9)))))
private theorem q10Shape14T77OK : fastTreeOK (forms 14) 1040 5013772 q10Shape14T77=true := by decide

private def q10Shape14T78 : Tree := (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 3 8 9)) (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 3 4 7 9)))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape14T78OK : fastTreeOK (forms 14) 1296 5013516 q10Shape14T78=true := by decide

private def q10Shape14T76 : Tree := .split 8 q10Shape14T77 q10Shape14T78
private theorem q10Shape14T76OK : fastTreeOK (forms 14) 1040 5013516 q10Shape14T76=true := by
  change (fastTreeOK (forms 14) 1040 (5013516 ||| 2^8) q10Shape14T77 &&
    fastTreeOK (forms 14) (1040 ||| 2^8) 5013516 q10Shape14T78)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T77OK,q10Shape14T78OK⟩

private def q10Shape14T79 : Tree := (.split 20 (.split 21 (.split 8 (.split 13 (.tip (.cover 0 1 2 8 9)) (.split 14 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.split 9 (.split 1 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T79OK : fastTreeOK (forms 14) 1048 5013508 q10Shape14T79=true := by decide

private def q10Shape14T75 : Tree := .split 3 q10Shape14T76 q10Shape14T79
private theorem q10Shape14T75OK : fastTreeOK (forms 14) 1040 5013508 q10Shape14T75=true := by
  change (fastTreeOK (forms 14) 1040 (5013508 ||| 2^3) q10Shape14T76 &&
    fastTreeOK (forms 14) (1040 ||| 2^3) 5013508 q10Shape14T79)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T76OK,q10Shape14T79OK⟩

private def q10Shape14T81 : Tree := (.split 23 (.split 24 (.split 8 (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 2 8 9)) (.split 20 (.split 21 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 4 7 8 9))) (.split 1 (.split 7 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 8 9)))) (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 2 8 9)) (.split 1 (.split 7 (.tip (.small 1)) (.tip (.cover 2 3 6 8 9))) (.tip (.cover 2 3 6 8 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T81OK : fastTreeOK (forms 14) 1044 5013512 q10Shape14T81=true := by decide

private def q10Shape14T82 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape14T82OK : fastTreeOK (forms 14) 1052 5013504 q10Shape14T82=true := by decide

private def q10Shape14T80 : Tree := .split 3 q10Shape14T81 q10Shape14T82
private theorem q10Shape14T80OK : fastTreeOK (forms 14) 1044 5013504 q10Shape14T80=true := by
  change (fastTreeOK (forms 14) 1044 (5013504 ||| 2^3) q10Shape14T81 &&
    fastTreeOK (forms 14) (1044 ||| 2^3) 5013504 q10Shape14T82)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T81OK,q10Shape14T82OK⟩

private def q10Shape14T74 : Tree := .split 2 q10Shape14T75 q10Shape14T80
private theorem q10Shape14T74OK : fastTreeOK (forms 14) 1040 5013504 q10Shape14T74=true := by
  change (fastTreeOK (forms 14) 1040 (5013504 ||| 2^2) q10Shape14T75 &&
    fastTreeOK (forms 14) (1040 ||| 2^2) 5013504 q10Shape14T80)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T75OK,q10Shape14T80OK⟩

private def q10Shape14T83 : Tree := (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.tip (.cover 0 2 3 4 9)) (.split 26 (.tip (.cover 0 2 3 4 8)) (.split 27 (.tip (.cover 0 2 3 4 7)) (.tip (.cover 0 5 6 7 8))))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 5 7 8 9))) (.tip (.cover 0 6 7 8 9))) (.tip (.cover 0 6 7 8 9)))
private theorem q10Shape14T83OK : fastTreeOK (forms 14) 33808 4980736 q10Shape14T83=true := by decide

private def q10Shape14T73 : Tree := .split 15 q10Shape14T74 q10Shape14T83
private theorem q10Shape14T73OK : fastTreeOK (forms 14) 1040 4980736 q10Shape14T73=true := by
  change (fastTreeOK (forms 14) 1040 (4980736 ||| 2^15) q10Shape14T74 &&
    fastTreeOK (forms 14) (1040 ||| 2^15) 4980736 q10Shape14T83)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T74OK,q10Shape14T83OK⟩

private def q10Shape14T51 : Tree := .split 10 q10Shape14T52 q10Shape14T73
private theorem q10Shape14T51OK : fastTreeOK (forms 14) 16 4980736 q10Shape14T51=true := by
  change (fastTreeOK (forms 14) 16 (4980736 ||| 2^10) q10Shape14T52 &&
    fastTreeOK (forms 14) (16 ||| 2^10) 4980736 q10Shape14T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T52OK,q10Shape14T73OK⟩

private def q10Shape14T3 : Tree := .split 4 q10Shape14T4 q10Shape14T51
private theorem q10Shape14T3OK : fastTreeOK (forms 14) 0 4980736 q10Shape14T3=true := by
  change (fastTreeOK (forms 14) 0 (4980736 ||| 2^4) q10Shape14T4 &&
    fastTreeOK (forms 14) (0 ||| 2^4) 4980736 q10Shape14T51)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T4OK,q10Shape14T51OK⟩

private def q10Shape14T86 : Tree := (.split 15 (.tip (.small 1)) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 2 (.split 8 (.tip (.cover 0 4 6 8 9)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 7 8 9)))))))
private theorem q10Shape14T86OK : fastTreeOK (forms 14) 4194304 787472 q10Shape14T86=true := by decide

private def q10Shape14T88 : Tree := (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 2 (.split 8 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 0 2 7 8 9))))))
private theorem q10Shape14T88OK : fastTreeOK (forms 14) 4195328 819216 q10Shape14T88=true := by decide

private def q10Shape14T93 : Tree := (.split 8 (.split 13 (.tip (.cover 0 1 6 8 9)) (.split 14 (.split 1 (.split 9 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.tip (.cover 0 3 4 8 9)))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 4 8 9)))) (.split 9 (.split 0 (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.split 14 (.tip (.small 0)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 4 6 8 9))))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape14T93OK : fastTreeOK (forms 14) 4228096 3932188 q10Shape14T93=true := by decide

private def q10Shape14T94 : Tree := (.split 8 (.split 9 (.split 13 (.tip (.cover 0 1 6 8 9)) (.split 14 (.split 0 (.split 1 (.tip (.small 0)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 2 5 7 8 9))) (.tip (.cover 0 1 4 8 9)))) (.tip (.cover 0 4 6 8 9))) (.split 9 (.split 13 (.split 14 (.split 0 (.split 1 (.tip (.small 0)) (.tip (.cover 2 5 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 3 6 8 9))) (.tip (.cover 2 5 7 8 9))) (.tip (.cover 0 1 3 8 9))))
private theorem q10Shape14T94OK : fastTreeOK (forms 14) 4228104 3932180 q10Shape14T94=true := by decide

private def q10Shape14T92 : Tree := .split 3 q10Shape14T93 q10Shape14T94
private theorem q10Shape14T92OK : fastTreeOK (forms 14) 4228096 3932180 q10Shape14T92=true := by
  change (fastTreeOK (forms 14) 4228096 (3932180 ||| 2^3) q10Shape14T93 &&
    fastTreeOK (forms 14) (4228096 ||| 2^3) 3932180 q10Shape14T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T93OK,q10Shape14T94OK⟩

private def q10Shape14T95 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape14T95OK : fastTreeOK (forms 14) 6325248 1835028 q10Shape14T95=true := by decide

private def q10Shape14T91 : Tree := .split 21 q10Shape14T92 q10Shape14T95
private theorem q10Shape14T91OK : fastTreeOK (forms 14) 4228096 1835028 q10Shape14T91=true := by
  change (fastTreeOK (forms 14) 4228096 (1835028 ||| 2^21) q10Shape14T92 &&
    fastTreeOK (forms 14) (4228096 ||| 2^21) 1835028 q10Shape14T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T92OK,q10Shape14T95OK⟩

private def q10Shape14T96 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape14T96OK : fastTreeOK (forms 14) 5276672 786452 q10Shape14T96=true := by decide

private def q10Shape14T90 : Tree := .split 20 q10Shape14T91 q10Shape14T96
private theorem q10Shape14T90OK : fastTreeOK (forms 14) 4228096 786452 q10Shape14T90=true := by
  change (fastTreeOK (forms 14) 4228096 (786452 ||| 2^20) q10Shape14T91 &&
    fastTreeOK (forms 14) (4228096 ||| 2^20) 786452 q10Shape14T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T91OK,q10Shape14T96OK⟩

private def q10Shape14T97 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape14T97OK : fastTreeOK (forms 14) 4228100 786448 q10Shape14T97=true := by decide

private def q10Shape14T89 : Tree := .split 2 q10Shape14T90 q10Shape14T97
private theorem q10Shape14T89OK : fastTreeOK (forms 14) 4228096 786448 q10Shape14T89=true := by
  change (fastTreeOK (forms 14) 4228096 (786448 ||| 2^2) q10Shape14T90 &&
    fastTreeOK (forms 14) (4228096 ||| 2^2) 786448 q10Shape14T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T90OK,q10Shape14T97OK⟩

private def q10Shape14T87 : Tree := .split 15 q10Shape14T88 q10Shape14T89
private theorem q10Shape14T87OK : fastTreeOK (forms 14) 4195328 786448 q10Shape14T87=true := by
  change (fastTreeOK (forms 14) 4195328 (786448 ||| 2^15) q10Shape14T88 &&
    fastTreeOK (forms 14) (4195328 ||| 2^15) 786448 q10Shape14T89)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T88OK,q10Shape14T89OK⟩

private def q10Shape14T85 : Tree := .split 10 q10Shape14T86 q10Shape14T87
private theorem q10Shape14T85OK : fastTreeOK (forms 14) 4194304 786448 q10Shape14T85=true := by
  change (fastTreeOK (forms 14) 4194304 (786448 ||| 2^10) q10Shape14T86 &&
    fastTreeOK (forms 14) (4194304 ||| 2^10) 786448 q10Shape14T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T86OK,q10Shape14T87OK⟩

private def q10Shape14T100 : Tree := (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 2 (.split 8 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 6 8 9))))))
private theorem q10Shape14T100OK : fastTreeOK (forms 14) 4194320 820224 q10Shape14T100=true := by decide

private def q10Shape14T102 : Tree := (.split 20 (.split 21 (.split 2 (.split 13 (.tip (.cover 0 1 6 8 9)) (.split 14 (.split 7 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 3 (.split 9 (.tip (.small 0)) (.tip (.cover 3 5 7 8 9))) (.tip (.cover 0 2 4 8 9))))) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 4 8 9)))) (.split 3 (.split 0 (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 9 (.split 13 (.split 14 (.tip (.small 0)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 4 6 8 9))) (.tip (.cover 3 5 7 8 9))))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 2 8 9)))) (.tip (.cover 0 1 6 8 9))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape14T102OK : fastTreeOK (forms 14) 4227088 787712 q10Shape14T102=true := by decide

private def q10Shape14T103 : Tree := (.tip (.cover 0 3 7 8 9))
private theorem q10Shape14T103OK : fastTreeOK (forms 14) 4227344 787456 q10Shape14T103=true := by decide

private def q10Shape14T101 : Tree := .split 8 q10Shape14T102 q10Shape14T103
private theorem q10Shape14T101OK : fastTreeOK (forms 14) 4227088 787456 q10Shape14T101=true := by
  change (fastTreeOK (forms 14) 4227088 (787456 ||| 2^8) q10Shape14T102 &&
    fastTreeOK (forms 14) (4227088 ||| 2^8) 787456 q10Shape14T103)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T102OK,q10Shape14T103OK⟩

private def q10Shape14T99 : Tree := .split 15 q10Shape14T100 q10Shape14T101
private theorem q10Shape14T99OK : fastTreeOK (forms 14) 4194320 787456 q10Shape14T99=true := by
  change (fastTreeOK (forms 14) 4194320 (787456 ||| 2^15) q10Shape14T100 &&
    fastTreeOK (forms 14) (4194320 ||| 2^15) 787456 q10Shape14T101)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T100OK,q10Shape14T101OK⟩

private def q10Shape14T106 : Tree := (.split 20 (.split 21 (.split 2 (.split 8 (.tip (.cover 0 1 6 8 9)) (.split 9 (.split 7 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 3 (.split 14 (.tip (.small 0)) (.tip (.cover 4 5 7 8 9))) (.tip (.cover 0 2 3 8 9))))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 1 3 8 9)))) (.split 3 (.split 1 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 8 (.split 9 (.split 14 (.tip (.small 0)) (.tip (.cover 4 5 7 8 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 3 6 8 9))))) (.tip (.cover 0 2 7 8 9))) (.tip (.cover 0 1 2 8 9)))) (.tip (.cover 0 1 6 8 9))) (.tip (.cover 0 1 6 8 9)))
private theorem q10Shape14T106OK : fastTreeOK (forms 14) 4195344 827392 q10Shape14T106=true := by decide

private def q10Shape14T107 : Tree := (.tip (.cover 0 4 7 8 9))
private theorem q10Shape14T107OK : fastTreeOK (forms 14) 4203536 819200 q10Shape14T107=true := by decide

private def q10Shape14T105 : Tree := .split 13 q10Shape14T106 q10Shape14T107
private theorem q10Shape14T105OK : fastTreeOK (forms 14) 4195344 819200 q10Shape14T105=true := by
  change (fastTreeOK (forms 14) 4195344 (819200 ||| 2^13) q10Shape14T106 &&
    fastTreeOK (forms 14) (4195344 ||| 2^13) 819200 q10Shape14T107)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T106OK,q10Shape14T107OK⟩

private def q10Shape14T108 : Tree := (.tip (.cover 0 5 7 8 9))
private theorem q10Shape14T108OK : fastTreeOK (forms 14) 4228112 786432 q10Shape14T108=true := by decide

private def q10Shape14T104 : Tree := .split 15 q10Shape14T105 q10Shape14T108
private theorem q10Shape14T104OK : fastTreeOK (forms 14) 4195344 786432 q10Shape14T104=true := by
  change (fastTreeOK (forms 14) 4195344 (786432 ||| 2^15) q10Shape14T105 &&
    fastTreeOK (forms 14) (4195344 ||| 2^15) 786432 q10Shape14T108)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T105OK,q10Shape14T108OK⟩

private def q10Shape14T98 : Tree := .split 10 q10Shape14T99 q10Shape14T104
private theorem q10Shape14T98OK : fastTreeOK (forms 14) 4194320 786432 q10Shape14T98=true := by
  change (fastTreeOK (forms 14) 4194320 (786432 ||| 2^10) q10Shape14T99 &&
    fastTreeOK (forms 14) (4194320 ||| 2^10) 786432 q10Shape14T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T99OK,q10Shape14T104OK⟩

private def q10Shape14T84 : Tree := .split 4 q10Shape14T85 q10Shape14T98
private theorem q10Shape14T84OK : fastTreeOK (forms 14) 4194304 786432 q10Shape14T84=true := by
  change (fastTreeOK (forms 14) 4194304 (786432 ||| 2^4) q10Shape14T85 &&
    fastTreeOK (forms 14) (4194304 ||| 2^4) 786432 q10Shape14T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T85OK,q10Shape14T98OK⟩

private def q10Shape14T2 : Tree := .split 22 q10Shape14T3 q10Shape14T84
private theorem q10Shape14T2OK : fastTreeOK (forms 14) 0 786432 q10Shape14T2=true := by
  change (fastTreeOK (forms 14) 0 (786432 ||| 2^22) q10Shape14T3 &&
    fastTreeOK (forms 14) (0 ||| 2^22) 786432 q10Shape14T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T3OK,q10Shape14T84OK⟩

private def q10Shape14T112 : Tree := (.split 15 (.tip (.small 1)) (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 3 (.split 9 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 7 8 9)))))))
private theorem q10Shape14T112OK : fastTreeOK (forms 14) 524288 4457488 q10Shape14T112=true := by decide

private def q10Shape14T114 : Tree := (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 3 (.split 9 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 2 7 8 9))))))
private theorem q10Shape14T114OK : fastTreeOK (forms 14) 525312 4489232 q10Shape14T114=true := by decide

private def q10Shape14T117 : Tree := (.split 23 (.split 24 (.split 8 (.split 9 (.split 13 (.split 1 (.tip (.small 0)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 0 1 4 8 9))) (.split 0 (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 13 (.split 14 (.tip (.small 0)) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 3 4 8 9))))) (.tip (.cover 0 3 7 8 9)))) (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 0 (.split 1 (.tip (.small 0)) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 3 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape14T117OK : fastTreeOK (forms 14) 558080 4456476 q10Shape14T117=true := by decide

private def q10Shape14T118 : Tree := (.split 23 (.split 24 (.split 8 (.split 9 (.split 13 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 0 (.split 1 (.tip (.small 0)) (.tip (.cover 0 4 7 8 9))) (.tip (.cover 2 6 7 8 9)))) (.tip (.cover 0 1 4 8 9))) (.split 13 (.split 14 (.split 0 (.split 1 (.tip (.small 0)) (.tip (.cover 2 6 7 8 9))) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 2 6 7 8 9))) (.tip (.cover 0 3 5 8 9)))) (.split 9 (.tip (.cover 0 4 5 8 9)) (.tip (.cover 0 1 3 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape14T118OK : fastTreeOK (forms 14) 558084 4456472 q10Shape14T118=true := by decide

private def q10Shape14T116 : Tree := .split 2 q10Shape14T117 q10Shape14T118
private theorem q10Shape14T116OK : fastTreeOK (forms 14) 558080 4456472 q10Shape14T116=true := by
  change (fastTreeOK (forms 14) 558080 (4456472 ||| 2^2) q10Shape14T117 &&
    fastTreeOK (forms 14) (558080 ||| 2^2) 4456472 q10Shape14T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T117OK,q10Shape14T118OK⟩

private def q10Shape14T119 : Tree := (.tip (.cover 0 2 7 8 9))
private theorem q10Shape14T119OK : fastTreeOK (forms 14) 558088 4456464 q10Shape14T119=true := by decide

private def q10Shape14T115 : Tree := .split 3 q10Shape14T116 q10Shape14T119
private theorem q10Shape14T115OK : fastTreeOK (forms 14) 558080 4456464 q10Shape14T115=true := by
  change (fastTreeOK (forms 14) 558080 (4456464 ||| 2^3) q10Shape14T116 &&
    fastTreeOK (forms 14) (558080 ||| 2^3) 4456464 q10Shape14T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T116OK,q10Shape14T119OK⟩

private def q10Shape14T113 : Tree := .split 15 q10Shape14T114 q10Shape14T115
private theorem q10Shape14T113OK : fastTreeOK (forms 14) 525312 4456464 q10Shape14T113=true := by
  change (fastTreeOK (forms 14) 525312 (4456464 ||| 2^15) q10Shape14T114 &&
    fastTreeOK (forms 14) (525312 ||| 2^15) 4456464 q10Shape14T115)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T114OK,q10Shape14T115OK⟩

private def q10Shape14T111 : Tree := .split 10 q10Shape14T112 q10Shape14T113
private theorem q10Shape14T111OK : fastTreeOK (forms 14) 524288 4456464 q10Shape14T111=true := by
  change (fastTreeOK (forms 14) 524288 (4456464 ||| 2^10) q10Shape14T112 &&
    fastTreeOK (forms 14) (524288 ||| 2^10) 4456464 q10Shape14T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T112OK,q10Shape14T113OK⟩

private def q10Shape14T122 : Tree := (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 3 (.split 9 (.tip (.cover 0 4 7 8 9)) (.tip (.cover 0 3 7 8 9))) (.tip (.cover 0 2 5 8 9))))))
private theorem q10Shape14T122OK : fastTreeOK (forms 14) 524304 4490240 q10Shape14T122=true := by decide

private def q10Shape14T125 : Tree := (.split 23 (.split 24 (.split 3 (.split 13 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 7 (.split 8 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.tip (.cover 3 6 7 8 9)))) (.tip (.cover 0 4 7 8 9)))) (.tip (.cover 0 1 4 8 9))) (.split 0 (.split 1 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 8 (.split 13 (.split 14 (.tip (.small 0)) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 3 6 7 8 9))))) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape14T125OK : fastTreeOK (forms 14) 557072 4457988 q10Shape14T125=true := by decide

private def q10Shape14T126 : Tree := (.split 3 (.split 8 (.split 13 (.split 14 (.tip (.cover 0 1 5 8 9)) (.split 0 (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 2 4 8 9)))) (.tip (.cover 0 1 4 8 9))) (.tip (.cover 0 4 5 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T126OK : fastTreeOK (forms 14) 557076 4457984 q10Shape14T126=true := by decide

private def q10Shape14T124 : Tree := .split 2 q10Shape14T125 q10Shape14T126
private theorem q10Shape14T124OK : fastTreeOK (forms 14) 557072 4457984 q10Shape14T124=true := by
  change (fastTreeOK (forms 14) 557072 (4457984 ||| 2^2) q10Shape14T125 &&
    fastTreeOK (forms 14) (557072 ||| 2^2) 4457984 q10Shape14T126)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T125OK,q10Shape14T126OK⟩

private def q10Shape14T127 : Tree := (.tip (.cover 0 3 7 8 9))
private theorem q10Shape14T127OK : fastTreeOK (forms 14) 557584 4457472 q10Shape14T127=true := by decide

private def q10Shape14T123 : Tree := .split 9 q10Shape14T124 q10Shape14T127
private theorem q10Shape14T123OK : fastTreeOK (forms 14) 557072 4457472 q10Shape14T123=true := by
  change (fastTreeOK (forms 14) 557072 (4457472 ||| 2^9) q10Shape14T124 &&
    fastTreeOK (forms 14) (557072 ||| 2^9) 4457472 q10Shape14T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T124OK,q10Shape14T127OK⟩

private def q10Shape14T121 : Tree := .split 15 q10Shape14T122 q10Shape14T123
private theorem q10Shape14T121OK : fastTreeOK (forms 14) 524304 4457472 q10Shape14T121=true := by
  change (fastTreeOK (forms 14) 524304 (4457472 ||| 2^15) q10Shape14T122 &&
    fastTreeOK (forms 14) (524304 ||| 2^15) 4457472 q10Shape14T123)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T122OK,q10Shape14T123OK⟩

private def q10Shape14T131 : Tree := (.split 23 (.split 24 (.split 3 (.split 8 (.split 9 (.tip (.cover 0 1 5 8 9)) (.split 7 (.split 13 (.tip (.small 0)) (.split 0 (.tip (.small 0)) (.tip (.cover 0 3 5 8 9)))) (.tip (.cover 0 3 7 8 9)))) (.tip (.cover 0 1 3 8 9))) (.split 1 (.split 0 (.tip (.small 1)) (.split 7 (.tip (.small 1)) (.split 8 (.split 9 (.split 13 (.tip (.small 0)) (.tip (.cover 4 6 7 8 9))) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 2 3 8 9))))) (.tip (.cover 0 2 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape14T131OK : fastTreeOK (forms 14) 525328 4505604 q10Shape14T131=true := by decide

private def q10Shape14T132 : Tree := (.split 3 (.split 8 (.split 9 (.tip (.cover 0 1 5 8 9)) (.split 13 (.split 1 (.split 7 (.tip (.small 0)) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 2 3 8 9))) (.tip (.cover 0 3 5 8 9)))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T132OK : fastTreeOK (forms 14) 525332 4505600 q10Shape14T132=true := by decide

private def q10Shape14T130 : Tree := .split 2 q10Shape14T131 q10Shape14T132
private theorem q10Shape14T130OK : fastTreeOK (forms 14) 525328 4505600 q10Shape14T130=true := by
  change (fastTreeOK (forms 14) 525328 (4505600 ||| 2^2) q10Shape14T131 &&
    fastTreeOK (forms 14) (525328 ||| 2^2) 4505600 q10Shape14T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T131OK,q10Shape14T132OK⟩

private def q10Shape14T133 : Tree := (.tip (.cover 0 4 7 8 9))
private theorem q10Shape14T133OK : fastTreeOK (forms 14) 541712 4489216 q10Shape14T133=true := by decide

private def q10Shape14T129 : Tree := .split 14 q10Shape14T130 q10Shape14T133
private theorem q10Shape14T129OK : fastTreeOK (forms 14) 525328 4489216 q10Shape14T129=true := by
  change (fastTreeOK (forms 14) 525328 (4489216 ||| 2^14) q10Shape14T130 &&
    fastTreeOK (forms 14) (525328 ||| 2^14) 4489216 q10Shape14T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T130OK,q10Shape14T133OK⟩

private def q10Shape14T134 : Tree := (.tip (.cover 0 6 7 8 9))
private theorem q10Shape14T134OK : fastTreeOK (forms 14) 558096 4456448 q10Shape14T134=true := by decide

private def q10Shape14T128 : Tree := .split 15 q10Shape14T129 q10Shape14T134
private theorem q10Shape14T128OK : fastTreeOK (forms 14) 525328 4456448 q10Shape14T128=true := by
  change (fastTreeOK (forms 14) 525328 (4456448 ||| 2^15) q10Shape14T129 &&
    fastTreeOK (forms 14) (525328 ||| 2^15) 4456448 q10Shape14T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T129OK,q10Shape14T134OK⟩

private def q10Shape14T120 : Tree := .split 10 q10Shape14T121 q10Shape14T128
private theorem q10Shape14T120OK : fastTreeOK (forms 14) 524304 4456448 q10Shape14T120=true := by
  change (fastTreeOK (forms 14) 524304 (4456448 ||| 2^10) q10Shape14T121 &&
    fastTreeOK (forms 14) (524304 ||| 2^10) 4456448 q10Shape14T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T121OK,q10Shape14T128OK⟩

private def q10Shape14T110 : Tree := .split 4 q10Shape14T111 q10Shape14T120
private theorem q10Shape14T110OK : fastTreeOK (forms 14) 524288 4456448 q10Shape14T110=true := by
  change (fastTreeOK (forms 14) 524288 (4456448 ||| 2^4) q10Shape14T111 &&
    fastTreeOK (forms 14) (524288 ||| 2^4) 4456448 q10Shape14T120)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T111OK,q10Shape14T120OK⟩

private def q10Shape14T135 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape14T135OK : fastTreeOK (forms 14) 4718592 262144 q10Shape14T135=true := by decide

private def q10Shape14T109 : Tree := .split 22 q10Shape14T110 q10Shape14T135
private theorem q10Shape14T109OK : fastTreeOK (forms 14) 524288 262144 q10Shape14T109=true := by
  change (fastTreeOK (forms 14) 524288 (262144 ||| 2^22) q10Shape14T110 &&
    fastTreeOK (forms 14) (524288 ||| 2^22) 262144 q10Shape14T135)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T110OK,q10Shape14T135OK⟩

private def q10Shape14T1 : Tree := .split 19 q10Shape14T2 q10Shape14T109
private theorem q10Shape14T1OK : fastTreeOK (forms 14) 0 262144 q10Shape14T1=true := by
  change (fastTreeOK (forms 14) 0 (262144 ||| 2^19) q10Shape14T2 &&
    fastTreeOK (forms 14) (0 ||| 2^19) 262144 q10Shape14T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T2OK,q10Shape14T109OK⟩

private def q10Shape14T141 : Tree := (.tip (.small 1))
private theorem q10Shape14T141OK : fastTreeOK (forms 14) 262144 4752400 q10Shape14T141=true := by decide

private def q10Shape14T143 : Tree := (.tip (.small 1))
private theorem q10Shape14T143OK : fastTreeOK (forms 14) 294912 4719633 q10Shape14T143=true := by decide

private def q10Shape14T145 : Tree := (.tip (.small 1))
private theorem q10Shape14T145OK : fastTreeOK (forms 14) 294913 4719634 q10Shape14T145=true := by decide

private def q10Shape14T146 : Tree := (.split 7 (.tip (.small 1)) (.split 13 (.split 14 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 2 (.split 3 (.split 8 (.split 9 (.tip (.drop 1 6 7 (some 0) (some 5) (some 5))) (.split 5 (.tip (.cover 3 4 5 7 9)) (.tip (.cover 3 5 7 8 9)))) (.split 5 (.tip (.cover 3 4 6 7 9)) (.tip (.cover 3 6 7 8 9)))) (.split 11 (.tip (.cover 2 4 5 7 9)) (.tip (.cover 2 5 7 8 9)))) (.split 11 (.tip (.cover 2 4 6 7 9)) (.tip (.cover 2 6 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 1 4 5 8 9))) (.tip (.cover 1 4 5 8 9))) (.tip (.cover 1 4 6 8 9))) (.tip (.cover 1 4 6 8 9))) (.tip (.cover 1 4 5 8 9))) (.tip (.cover 1 4 6 8 9))))
private theorem q10Shape14T146OK : fastTreeOK (forms 14) 294915 4719632 q10Shape14T146=true := by decide

private def q10Shape14T144 : Tree := .split 1 q10Shape14T145 q10Shape14T146
private theorem q10Shape14T144OK : fastTreeOK (forms 14) 294913 4719632 q10Shape14T144=true := by
  change (fastTreeOK (forms 14) 294913 (4719632 ||| 2^1) q10Shape14T145 &&
    fastTreeOK (forms 14) (294913 ||| 2^1) 4719632 q10Shape14T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T145OK,q10Shape14T146OK⟩

private def q10Shape14T142 : Tree := .split 0 q10Shape14T143 q10Shape14T144
private theorem q10Shape14T142OK : fastTreeOK (forms 14) 294912 4719632 q10Shape14T142=true := by
  change (fastTreeOK (forms 14) 294912 (4719632 ||| 2^0) q10Shape14T143 &&
    fastTreeOK (forms 14) (294912 ||| 2^0) 4719632 q10Shape14T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T143OK,q10Shape14T144OK⟩

private def q10Shape14T140 : Tree := .split 15 q10Shape14T141 q10Shape14T142
private theorem q10Shape14T140OK : fastTreeOK (forms 14) 262144 4719632 q10Shape14T140=true := by
  change (fastTreeOK (forms 14) 262144 (4719632 ||| 2^15) q10Shape14T141 &&
    fastTreeOK (forms 14) (262144 ||| 2^15) 4719632 q10Shape14T142)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T141OK,q10Shape14T142OK⟩

private def q10Shape14T149 : Tree := (.tip (.small 1))
private theorem q10Shape14T149OK : fastTreeOK (forms 14) 263168 4751377 q10Shape14T149=true := by decide

private def q10Shape14T151 : Tree := (.tip (.small 1))
private theorem q10Shape14T151OK : fastTreeOK (forms 14) 263169 4751378 q10Shape14T151=true := by decide

private def q10Shape14T152 : Tree := (.split 7 (.tip (.small 1)) (.split 8 (.split 9 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 2 (.split 3 (.split 13 (.split 14 (.tip (.drop 1 6 7 (some 0) (some 5) (some 5))) (.split 5 (.tip (.cover 3 4 5 7 9)) (.tip (.cover 4 5 7 8 9)))) (.split 5 (.tip (.cover 3 4 6 7 9)) (.tip (.cover 4 6 7 8 9)))) (.split 16 (.tip (.cover 2 3 5 7 9)) (.tip (.cover 2 5 7 8 9)))) (.split 16 (.tip (.cover 2 3 6 7 9)) (.tip (.cover 2 6 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 1 3 5 8 9))) (.tip (.cover 1 3 5 8 9))) (.tip (.cover 1 3 6 8 9))) (.tip (.cover 1 3 6 8 9))) (.tip (.cover 1 3 5 8 9))) (.tip (.cover 1 3 6 8 9))))
private theorem q10Shape14T152OK : fastTreeOK (forms 14) 263171 4751376 q10Shape14T152=true := by decide

private def q10Shape14T150 : Tree := .split 1 q10Shape14T151 q10Shape14T152
private theorem q10Shape14T150OK : fastTreeOK (forms 14) 263169 4751376 q10Shape14T150=true := by
  change (fastTreeOK (forms 14) 263169 (4751376 ||| 2^1) q10Shape14T151 &&
    fastTreeOK (forms 14) (263169 ||| 2^1) 4751376 q10Shape14T152)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T151OK,q10Shape14T152OK⟩

private def q10Shape14T148 : Tree := .split 0 q10Shape14T149 q10Shape14T150
private theorem q10Shape14T148OK : fastTreeOK (forms 14) 263168 4751376 q10Shape14T148=true := by
  change (fastTreeOK (forms 14) 263168 (4751376 ||| 2^0) q10Shape14T149 &&
    fastTreeOK (forms 14) (263168 ||| 2^0) 4751376 q10Shape14T150)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T149OK,q10Shape14T150OK⟩

private def q10Shape14T157 : Tree := (.split 25 (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.split 20 (.split 13 (.split 21 (.split 23 (.split 14 (.split 0 (.tip (.small 0)) (.split 5 (.tip (.cover 0 3 4 5 9)) (.tip (.cover 0 2 5 7 9)))) (.tip (.cover 2 3 4 5 9))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape14T157OK : fastTreeOK (forms 14) 295936 4719388 q10Shape14T157=true := by decide

private def q10Shape14T158 : Tree := (.split 20 (.split 21 (.split 25 (.split 13 (.split 23 (.tip (.cover 2 3 4 5 9)) (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape14T158OK : fastTreeOK (forms 14) 296448 4718876 q10Shape14T158=true := by decide

private def q10Shape14T156 : Tree := .split 9 q10Shape14T157 q10Shape14T158
private theorem q10Shape14T156OK : fastTreeOK (forms 14) 295936 4718876 q10Shape14T156=true := by
  change (fastTreeOK (forms 14) 295936 (4718876 ||| 2^9) q10Shape14T157 &&
    fastTreeOK (forms 14) (295936 ||| 2^9) 4718876 q10Shape14T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T157OK,q10Shape14T158OK⟩

private def q10Shape14T159 : Tree := (.split 9 (.split 23 (.split 24 (.split 25 (.split 14 (.split 20 (.tip (.cover 2 3 4 6 9)) (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 2 3 4 5 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9))) (.tip (.cover 0 1 3 8 9)))
private theorem q10Shape14T159OK : fastTreeOK (forms 14) 296192 4718620 q10Shape14T159=true := by decide

private def q10Shape14T155 : Tree := .split 8 q10Shape14T156 q10Shape14T159
private theorem q10Shape14T155OK : fastTreeOK (forms 14) 295936 4718620 q10Shape14T155=true := by
  change (fastTreeOK (forms 14) 295936 (4718620 ||| 2^8) q10Shape14T156 &&
    fastTreeOK (forms 14) (295936 ||| 2^8) 4718620 q10Shape14T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T156OK,q10Shape14T159OK⟩

private def q10Shape14T160 : Tree := (.tip (.cover 0 6 7 8 9))
private theorem q10Shape14T160OK : fastTreeOK (forms 14) 295944 4718612 q10Shape14T160=true := by decide

private def q10Shape14T154 : Tree := .split 3 q10Shape14T155 q10Shape14T160
private theorem q10Shape14T154OK : fastTreeOK (forms 14) 295936 4718612 q10Shape14T154=true := by
  change (fastTreeOK (forms 14) 295936 (4718612 ||| 2^3) q10Shape14T155 &&
    fastTreeOK (forms 14) (295936 ||| 2^3) 4718612 q10Shape14T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T155OK,q10Shape14T160OK⟩

private def q10Shape14T161 : Tree := (.tip (.cover 0 5 7 8 9))
private theorem q10Shape14T161OK : fastTreeOK (forms 14) 295940 4718608 q10Shape14T161=true := by decide

private def q10Shape14T153 : Tree := .split 2 q10Shape14T154 q10Shape14T161
private theorem q10Shape14T153OK : fastTreeOK (forms 14) 295936 4718608 q10Shape14T153=true := by
  change (fastTreeOK (forms 14) 295936 (4718608 ||| 2^2) q10Shape14T154 &&
    fastTreeOK (forms 14) (295936 ||| 2^2) 4718608 q10Shape14T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T154OK,q10Shape14T161OK⟩

private def q10Shape14T147 : Tree := .split 15 q10Shape14T148 q10Shape14T153
private theorem q10Shape14T147OK : fastTreeOK (forms 14) 263168 4718608 q10Shape14T147=true := by
  change (fastTreeOK (forms 14) 263168 (4718608 ||| 2^15) q10Shape14T148 &&
    fastTreeOK (forms 14) (263168 ||| 2^15) 4718608 q10Shape14T153)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T148OK,q10Shape14T153OK⟩

private def q10Shape14T139 : Tree := .split 10 q10Shape14T140 q10Shape14T147
private theorem q10Shape14T139OK : fastTreeOK (forms 14) 262144 4718608 q10Shape14T139=true := by
  change (fastTreeOK (forms 14) 262144 (4718608 ||| 2^10) q10Shape14T140 &&
    fastTreeOK (forms 14) (262144 ||| 2^10) 4718608 q10Shape14T147)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T140OK,q10Shape14T147OK⟩

private def q10Shape14T165 : Tree := (.tip (.small 1))
private theorem q10Shape14T165OK : fastTreeOK (forms 14) 262160 4752385 q10Shape14T165=true := by decide

private def q10Shape14T167 : Tree := (.tip (.small 1))
private theorem q10Shape14T167OK : fastTreeOK (forms 14) 262161 4752386 q10Shape14T167=true := by decide

private def q10Shape14T168 : Tree := (.split 7 (.tip (.small 1)) (.split 2 (.split 3 (.split 20 (.split 21 (.split 23 (.split 24 (.split 25 (.split 26 (.split 8 (.split 9 (.split 13 (.split 14 (.tip (.drop 1 6 7 (some 0) (some 5) (some 5))) (.split 11 (.tip (.cover 2 4 5 7 9)) (.tip (.cover 4 5 7 8 9)))) (.split 11 (.tip (.cover 2 4 6 7 9)) (.tip (.cover 4 6 7 8 9)))) (.split 16 (.tip (.cover 2 3 5 7 9)) (.tip (.cover 3 5 7 8 9)))) (.split 16 (.tip (.cover 2 3 6 7 9)) (.tip (.cover 3 6 7 8 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 1 2 5 8 9))) (.tip (.cover 1 2 5 8 9))) (.tip (.cover 1 2 6 8 9))) (.tip (.cover 1 2 6 8 9))) (.tip (.cover 1 2 5 8 9))) (.tip (.cover 1 2 6 8 9))))
private theorem q10Shape14T168OK : fastTreeOK (forms 14) 262163 4752384 q10Shape14T168=true := by decide

private def q10Shape14T166 : Tree := .split 1 q10Shape14T167 q10Shape14T168
private theorem q10Shape14T166OK : fastTreeOK (forms 14) 262161 4752384 q10Shape14T166=true := by
  change (fastTreeOK (forms 14) 262161 (4752384 ||| 2^1) q10Shape14T167 &&
    fastTreeOK (forms 14) (262161 ||| 2^1) 4752384 q10Shape14T168)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T167OK,q10Shape14T168OK⟩

private def q10Shape14T164 : Tree := .split 0 q10Shape14T165 q10Shape14T166
private theorem q10Shape14T164OK : fastTreeOK (forms 14) 262160 4752384 q10Shape14T164=true := by
  change (fastTreeOK (forms 14) 262160 (4752384 ||| 2^0) q10Shape14T165 &&
    fastTreeOK (forms 14) (262160 ||| 2^0) 4752384 q10Shape14T166)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T165OK,q10Shape14T166OK⟩

private def q10Shape14T173 : Tree := (.split 25 (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.split 20 (.split 13 (.split 21 (.split 23 (.split 14 (.split 0 (.tip (.small 0)) (.split 11 (.tip (.cover 0 2 4 5 9)) (.tip (.cover 0 3 5 7 9)))) (.tip (.cover 2 3 4 5 9))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape14T173OK : fastTreeOK (forms 14) 294928 4720396 q10Shape14T173=true := by decide

private def q10Shape14T174 : Tree := (.split 20 (.split 21 (.split 25 (.split 13 (.split 23 (.tip (.cover 2 3 4 5 9)) (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T174OK : fastTreeOK (forms 14) 294936 4720388 q10Shape14T174=true := by decide

private def q10Shape14T172 : Tree := .split 3 q10Shape14T173 q10Shape14T174
private theorem q10Shape14T172OK : fastTreeOK (forms 14) 294928 4720388 q10Shape14T172=true := by
  change (fastTreeOK (forms 14) 294928 (4720388 ||| 2^3) q10Shape14T173 &&
    fastTreeOK (forms 14) (294928 ||| 2^3) 4720388 q10Shape14T174)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T173OK,q10Shape14T174OK⟩

private def q10Shape14T175 : Tree := (.split 3 (.split 23 (.split 24 (.split 25 (.split 14 (.split 20 (.tip (.cover 2 3 4 6 9)) (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 2 3 4 5 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T175OK : fastTreeOK (forms 14) 294932 4720384 q10Shape14T175=true := by decide

private def q10Shape14T171 : Tree := .split 2 q10Shape14T172 q10Shape14T175
private theorem q10Shape14T171OK : fastTreeOK (forms 14) 294928 4720384 q10Shape14T171=true := by
  change (fastTreeOK (forms 14) 294928 (4720384 ||| 2^2) q10Shape14T172 &&
    fastTreeOK (forms 14) (294928 ||| 2^2) 4720384 q10Shape14T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T172OK,q10Shape14T175OK⟩

private def q10Shape14T176 : Tree := (.tip (.cover 0 6 7 8 9))
private theorem q10Shape14T176OK : fastTreeOK (forms 14) 295440 4719872 q10Shape14T176=true := by decide

private def q10Shape14T170 : Tree := .split 9 q10Shape14T171 q10Shape14T176
private theorem q10Shape14T170OK : fastTreeOK (forms 14) 294928 4719872 q10Shape14T170=true := by
  change (fastTreeOK (forms 14) 294928 (4719872 ||| 2^9) q10Shape14T171 &&
    fastTreeOK (forms 14) (294928 ||| 2^9) 4719872 q10Shape14T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T171OK,q10Shape14T176OK⟩

private def q10Shape14T177 : Tree := (.tip (.cover 0 5 7 8 9))
private theorem q10Shape14T177OK : fastTreeOK (forms 14) 295184 4719616 q10Shape14T177=true := by decide

private def q10Shape14T169 : Tree := .split 8 q10Shape14T170 q10Shape14T177
private theorem q10Shape14T169OK : fastTreeOK (forms 14) 294928 4719616 q10Shape14T169=true := by
  change (fastTreeOK (forms 14) 294928 (4719616 ||| 2^8) q10Shape14T170 &&
    fastTreeOK (forms 14) (294928 ||| 2^8) 4719616 q10Shape14T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T170OK,q10Shape14T177OK⟩

private def q10Shape14T163 : Tree := .split 15 q10Shape14T164 q10Shape14T169
private theorem q10Shape14T163OK : fastTreeOK (forms 14) 262160 4719616 q10Shape14T163=true := by
  change (fastTreeOK (forms 14) 262160 (4719616 ||| 2^15) q10Shape14T164 &&
    fastTreeOK (forms 14) (262160 ||| 2^15) 4719616 q10Shape14T169)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T164OK,q10Shape14T169OK⟩

private def q10Shape14T183 : Tree := (.split 25 (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.split 20 (.split 8 (.split 21 (.split 23 (.split 9 (.split 0 (.tip (.small 0)) (.split 1 (.tip (.small 0)) (.split 16 (.tip (.cover 0 2 3 5 9)) (.tip (.cover 0 4 5 7 9))))) (.tip (.cover 2 3 4 5 9))) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 7 8))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 1 5 7 9)))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 5 8 9)))
private theorem q10Shape14T183OK : fastTreeOK (forms 14) 263184 4775948 q10Shape14T183=true := by decide

private def q10Shape14T184 : Tree := (.split 20 (.split 21 (.split 25 (.split 8 (.split 23 (.tip (.cover 2 3 4 5 9)) (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.tip (.cover 0 1 6 7 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 2 3 4 6 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T184OK : fastTreeOK (forms 14) 263192 4775940 q10Shape14T184=true := by decide

private def q10Shape14T182 : Tree := .split 3 q10Shape14T183 q10Shape14T184
private theorem q10Shape14T182OK : fastTreeOK (forms 14) 263184 4775940 q10Shape14T182=true := by
  change (fastTreeOK (forms 14) 263184 (4775940 ||| 2^3) q10Shape14T183 &&
    fastTreeOK (forms 14) (263184 ||| 2^3) 4775940 q10Shape14T184)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T183OK,q10Shape14T184OK⟩

private def q10Shape14T185 : Tree := (.split 3 (.split 23 (.split 24 (.split 25 (.split 9 (.split 20 (.tip (.cover 2 3 4 6 9)) (.split 26 (.split 27 (.tip (.cover 2 3 4 5 6)) (.tip (.cover 0 1 5 7 9))) (.tip (.cover 0 1 5 8 9)))) (.tip (.cover 2 3 4 5 9))) (.tip (.cover 0 1 5 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9))) (.tip (.cover 0 1 2 8 9)))
private theorem q10Shape14T185OK : fastTreeOK (forms 14) 263188 4775936 q10Shape14T185=true := by decide

private def q10Shape14T181 : Tree := .split 2 q10Shape14T182 q10Shape14T185
private theorem q10Shape14T181OK : fastTreeOK (forms 14) 263184 4775936 q10Shape14T181=true := by
  change (fastTreeOK (forms 14) 263184 (4775936 ||| 2^2) q10Shape14T182 &&
    fastTreeOK (forms 14) (263184 ||| 2^2) 4775936 q10Shape14T185)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T182OK,q10Shape14T185OK⟩

private def q10Shape14T186 : Tree := (.tip (.cover 0 6 7 8 9))
private theorem q10Shape14T186OK : fastTreeOK (forms 14) 279568 4759552 q10Shape14T186=true := by decide

private def q10Shape14T180 : Tree := .split 14 q10Shape14T181 q10Shape14T186
private theorem q10Shape14T180OK : fastTreeOK (forms 14) 263184 4759552 q10Shape14T180=true := by
  change (fastTreeOK (forms 14) 263184 (4759552 ||| 2^14) q10Shape14T181 &&
    fastTreeOK (forms 14) (263184 ||| 2^14) 4759552 q10Shape14T186)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T181OK,q10Shape14T186OK⟩

private def q10Shape14T187 : Tree := (.tip (.cover 0 5 7 8 9))
private theorem q10Shape14T187OK : fastTreeOK (forms 14) 271376 4751360 q10Shape14T187=true := by decide

private def q10Shape14T179 : Tree := .split 13 q10Shape14T180 q10Shape14T187
private theorem q10Shape14T179OK : fastTreeOK (forms 14) 263184 4751360 q10Shape14T179=true := by
  change (fastTreeOK (forms 14) 263184 (4751360 ||| 2^13) q10Shape14T180 &&
    fastTreeOK (forms 14) (263184 ||| 2^13) 4751360 q10Shape14T187)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T180OK,q10Shape14T187OK⟩

private def q10Shape14T188 : Tree := (.tip (.cover 0 5 7 8 9))
private theorem q10Shape14T188OK : fastTreeOK (forms 14) 295952 4718592 q10Shape14T188=true := by decide

private def q10Shape14T178 : Tree := .split 15 q10Shape14T179 q10Shape14T188
private theorem q10Shape14T178OK : fastTreeOK (forms 14) 263184 4718592 q10Shape14T178=true := by
  change (fastTreeOK (forms 14) 263184 (4718592 ||| 2^15) q10Shape14T179 &&
    fastTreeOK (forms 14) (263184 ||| 2^15) 4718592 q10Shape14T188)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T179OK,q10Shape14T188OK⟩

private def q10Shape14T162 : Tree := .split 10 q10Shape14T163 q10Shape14T178
private theorem q10Shape14T162OK : fastTreeOK (forms 14) 262160 4718592 q10Shape14T162=true := by
  change (fastTreeOK (forms 14) 262160 (4718592 ||| 2^10) q10Shape14T163 &&
    fastTreeOK (forms 14) (262160 ||| 2^10) 4718592 q10Shape14T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T163OK,q10Shape14T178OK⟩

private def q10Shape14T138 : Tree := .split 4 q10Shape14T139 q10Shape14T162
private theorem q10Shape14T138OK : fastTreeOK (forms 14) 262144 4718592 q10Shape14T138=true := by
  change (fastTreeOK (forms 14) 262144 (4718592 ||| 2^4) q10Shape14T139 &&
    fastTreeOK (forms 14) (262144 ||| 2^4) 4718592 q10Shape14T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T139OK,q10Shape14T162OK⟩

private def q10Shape14T189 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape14T189OK : fastTreeOK (forms 14) 4456448 524288 q10Shape14T189=true := by decide

private def q10Shape14T137 : Tree := .split 22 q10Shape14T138 q10Shape14T189
private theorem q10Shape14T137OK : fastTreeOK (forms 14) 262144 524288 q10Shape14T137=true := by
  change (fastTreeOK (forms 14) 262144 (524288 ||| 2^22) q10Shape14T138 &&
    fastTreeOK (forms 14) (262144 ||| 2^22) 524288 q10Shape14T189)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T138OK,q10Shape14T189OK⟩

private def q10Shape14T190 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape14T190OK : fastTreeOK (forms 14) 786432 0 q10Shape14T190=true := by decide

private def q10Shape14T136 : Tree := .split 19 q10Shape14T137 q10Shape14T190
private theorem q10Shape14T136OK : fastTreeOK (forms 14) 262144 0 q10Shape14T136=true := by
  change (fastTreeOK (forms 14) 262144 (0 ||| 2^19) q10Shape14T137 &&
    fastTreeOK (forms 14) (262144 ||| 2^19) 0 q10Shape14T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T137OK,q10Shape14T190OK⟩

private def q10Shape14T0 : Tree := .split 18 q10Shape14T1 q10Shape14T136
private theorem q10Shape14T0OK : fastTreeOK (forms 14) 0 0 q10Shape14T0=true := by
  change (fastTreeOK (forms 14) 0 (0 ||| 2^18) q10Shape14T1 &&
    fastTreeOK (forms 14) (0 ||| 2^18) 0 q10Shape14T136)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape14T1OK,q10Shape14T136OK⟩


theorem q10Shape14_cover (b : Nat→Bool) (H : Ranked (adj (forms 14) b)) :
    ∃ u v w z t,Effective (adj (forms 14) b) (adj (forms 14) b) u v w z t :=
  checked_fastTree (forms 14) b H q10Shape14T0 q10Shape14T0OK

#print axioms q10Shape14_cover
end Graffiti384b.Q10
