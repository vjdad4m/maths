import Q10FastKernel384b

namespace Graffiti384b.Q10
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000
private def q10Shape15T6 : Tree := (.tip (.cover 2 3 4 5 6))
private theorem q10Shape15T6OK : fastTreeOK (forms 15) 0 264241152 q10Shape15T6=true := by decide

private def q10Shape15T11 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape15T11OK : fastTreeOK (forms 15) 134217728 130302472 q10Shape15T11=true := by decide

private def q10Shape15T16 : Tree := (.split 6 (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 19 (.tip (.cover 2 3 4 6 8)) (.split 10 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 15 (.tip (.drop 5 6 7 (some 1) (some 2) none)) (.tip (.drop 5 6 7 (some 0) (some 2) (some 2))))) (.split 11 (.tip (.cover 2 4 6 7 9)) (.tip (.cover 0 1 3 5 9)))))))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 9)))
private theorem q10Shape15T16OK : fastTreeOK (forms 15) 134479872 133186104 q10Shape15T16=true := by decide

private def q10Shape15T17 : Tree := (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 16 (.split 17 (.split 10 (.split 15 (.tip (.drop 7 8 9 none (some 6) (some 6))) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 8 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8)))) (.split 15 (.split 1 (.split 7 (.split 13 (.tip (.drop 6 8 9 (some 4) (some 4) (some 4))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 5 7 8)))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 9))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 9))))
private theorem q10Shape15T17OK : fastTreeOK (forms 15) 134479904 133186072 q10Shape15T17=true := by decide

private def q10Shape15T15 : Tree := .split 5 q10Shape15T16 q10Shape15T17
private theorem q10Shape15T15OK : fastTreeOK (forms 15) 134479872 133186072 q10Shape15T15=true := by
  change (fastTreeOK (forms 15) 134479872 (133186072 ||| 2^5) q10Shape15T16 &&
    fastTreeOK (forms 15) (134479872 ||| 2^5) 133186072 q10Shape15T17)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T16OK,q10Shape15T17OK⟩

private def q10Shape15T18 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape15T18OK : fastTreeOK (forms 15) 136577024 131088920 q10Shape15T18=true := by decide

private def q10Shape15T14 : Tree := .split 21 q10Shape15T15 q10Shape15T18
private theorem q10Shape15T14OK : fastTreeOK (forms 15) 134479872 131088920 q10Shape15T14=true := by
  change (fastTreeOK (forms 15) 134479872 (131088920 ||| 2^21) q10Shape15T15 &&
    fastTreeOK (forms 15) (134479872 ||| 2^21) 131088920 q10Shape15T18)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T15OK,q10Shape15T18OK⟩

private def q10Shape15T19 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape15T19OK : fastTreeOK (forms 15) 135528448 130040344 q10Shape15T19=true := by decide

private def q10Shape15T13 : Tree := .split 20 q10Shape15T14 q10Shape15T19
private theorem q10Shape15T13OK : fastTreeOK (forms 15) 134479872 130040344 q10Shape15T13=true := by
  change (fastTreeOK (forms 15) 134479872 (130040344 ||| 2^20) q10Shape15T14 &&
    fastTreeOK (forms 15) (134479872 ||| 2^20) 130040344 q10Shape15T19)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T14OK,q10Shape15T19OK⟩

private def q10Shape15T25 : Tree := (.split 11 (.split 12 (.split 16 (.tip (.cover 0 1 6 7 9)) (.split 17 (.tip (.cover 0 1 6 7 8)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 8 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))))) (.tip (.cover 0 2 4 5 9))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 15 (.split 16 (.split 17 (.split 1 (.split 7 (.split 13 (.tip (.drop 6 8 9 (some 4) (some 4) (some 4))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 3 5 7 8)))))
private theorem q10Shape15T25OK : fastTreeOK (forms 15) 134479888 133187176 q10Shape15T25=true := by decide

private def q10Shape15T26 : Tree := (.split 11 (.tip (.cover 0 4 5 7 9)) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 15 (.split 16 (.split 17 (.split 19 (.split 1 (.split 2 (.split 7 (.split 8 (.tip (.small 1)) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 1 3 5 8))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 3 5 7 8)))))
private theorem q10Shape15T26OK : fastTreeOK (forms 15) 134480912 133186152 q10Shape15T26=true := by decide

private def q10Shape15T24 : Tree := .split 10 q10Shape15T25 q10Shape15T26
private theorem q10Shape15T24OK : fastTreeOK (forms 15) 134479888 133186152 q10Shape15T24=true := by
  change (fastTreeOK (forms 15) 134479888 (133186152 ||| 2^10) q10Shape15T25 &&
    fastTreeOK (forms 15) (134479888 ||| 2^10) 133186152 q10Shape15T26)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T25OK,q10Shape15T26OK⟩

private def q10Shape15T27 : Tree := (.split 19 (.split 2 (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 7 8)))) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 0 1 2 5 8)))
private theorem q10Shape15T27OK : fastTreeOK (forms 15) 134479952 133186088 q10Shape15T27=true := by decide

private def q10Shape15T23 : Tree := .split 6 q10Shape15T24 q10Shape15T27
private theorem q10Shape15T23OK : fastTreeOK (forms 15) 134479888 133186088 q10Shape15T23=true := by
  change (fastTreeOK (forms 15) 134479888 (133186088 ||| 2^6) q10Shape15T24 &&
    fastTreeOK (forms 15) (134479888 ||| 2^6) 133186088 q10Shape15T27)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T24OK,q10Shape15T27OK⟩

private def q10Shape15T28 : Tree := (.split 19 (.split 2 (.split 6 (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 7 9)))) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 2 3 4 6 8))) (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 7 8)))) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 2 3 4 6 8)))) (.tip (.cover 2 3 4 6 8))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape15T28OK : fastTreeOK (forms 15) 134479920 133186056 q10Shape15T28=true := by decide

private def q10Shape15T22 : Tree := .split 5 q10Shape15T23 q10Shape15T28
private theorem q10Shape15T22OK : fastTreeOK (forms 15) 134479888 133186056 q10Shape15T22=true := by
  change (fastTreeOK (forms 15) 134479888 (133186056 ||| 2^5) q10Shape15T23 &&
    fastTreeOK (forms 15) (134479888 ||| 2^5) 133186056 q10Shape15T28)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T23OK,q10Shape15T28OK⟩

private def q10Shape15T29 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape15T29OK : fastTreeOK (forms 15) 136577040 131088904 q10Shape15T29=true := by decide

private def q10Shape15T21 : Tree := .split 21 q10Shape15T22 q10Shape15T29
private theorem q10Shape15T21OK : fastTreeOK (forms 15) 134479888 131088904 q10Shape15T21=true := by
  change (fastTreeOK (forms 15) 134479888 (131088904 ||| 2^21) q10Shape15T22 &&
    fastTreeOK (forms 15) (134479888 ||| 2^21) 131088904 q10Shape15T29)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T22OK,q10Shape15T29OK⟩

private def q10Shape15T30 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape15T30OK : fastTreeOK (forms 15) 135528464 130040328 q10Shape15T30=true := by decide

private def q10Shape15T20 : Tree := .split 20 q10Shape15T21 q10Shape15T30
private theorem q10Shape15T20OK : fastTreeOK (forms 15) 134479888 130040328 q10Shape15T20=true := by
  change (fastTreeOK (forms 15) 134479888 (130040328 ||| 2^20) q10Shape15T21 &&
    fastTreeOK (forms 15) (134479888 ||| 2^20) 130040328 q10Shape15T30)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T21OK,q10Shape15T30OK⟩

private def q10Shape15T12 : Tree := .split 4 q10Shape15T13 q10Shape15T20
private theorem q10Shape15T12OK : fastTreeOK (forms 15) 134479872 130040328 q10Shape15T12=true := by
  change (fastTreeOK (forms 15) 134479872 (130040328 ||| 2^4) q10Shape15T13 &&
    fastTreeOK (forms 15) (134479872 ||| 2^4) 130040328 q10Shape15T20)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T13OK,q10Shape15T20OK⟩

private def q10Shape15T10 : Tree := .split 18 q10Shape15T11 q10Shape15T12
private theorem q10Shape15T10OK : fastTreeOK (forms 15) 134217728 130040328 q10Shape15T10=true := by
  change (fastTreeOK (forms 15) 134217728 (130040328 ||| 2^18) q10Shape15T11 &&
    fastTreeOK (forms 15) (134217728 ||| 2^18) 130040328 q10Shape15T12)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T11OK,q10Shape15T12OK⟩

private def q10Shape15T36 : Tree := (.split 6 (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 15 (.tip (.cover 2 3 5 6 8)) (.split 10 (.split 11 (.tip (.cover 0 1 4 5 9)) (.split 19 (.tip (.drop 4 6 7 (some 1) (some 2) none)) (.tip (.drop 4 6 7 (some 0) (some 2) (some 2))))) (.split 11 (.tip (.cover 2 5 6 7 9)) (.tip (.cover 0 1 3 4 9)))))))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 9)))
private theorem q10Shape15T36OK : fastTreeOK (forms 15) 134234112 130482744 q10Shape15T36=true := by decide

private def q10Shape15T37 : Tree := (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 11 (.split 12 (.split 20 (.split 21 (.split 10 (.split 19 (.tip (.drop 7 8 9 none (some 6) (some 6))) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 8 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8)))) (.split 19 (.split 2 (.split 8 (.split 13 (.tip (.drop 6 8 9 (some 5) (some 5) (some 5))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 9))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 9))))
private theorem q10Shape15T37OK : fastTreeOK (forms 15) 134234144 130482712 q10Shape15T37=true := by decide

private def q10Shape15T35 : Tree := .split 5 q10Shape15T36 q10Shape15T37
private theorem q10Shape15T35OK : fastTreeOK (forms 15) 134234112 130482712 q10Shape15T35=true := by
  change (fastTreeOK (forms 15) 134234112 (130482712 ||| 2^5) q10Shape15T36 &&
    fastTreeOK (forms 15) (134234112 ||| 2^5) 130482712 q10Shape15T37)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T36OK,q10Shape15T37OK⟩

private def q10Shape15T41 : Tree := (.split 11 (.split 12 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 8 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))))) (.tip (.cover 0 2 4 5 9))) (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 19 (.split 20 (.split 21 (.split 2 (.split 8 (.split 13 (.tip (.drop 6 8 9 (some 5) (some 5) (some 5))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 3 4 7 8)))))
private theorem q10Shape15T41OK : fastTreeOK (forms 15) 134234128 130483816 q10Shape15T41=true := by decide

private def q10Shape15T42 : Tree := (.split 11 (.tip (.cover 0 4 5 7 9)) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 15 (.split 19 (.split 20 (.split 21 (.split 1 (.split 2 (.split 7 (.split 8 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 1 3 4 8)))))
private theorem q10Shape15T42OK : fastTreeOK (forms 15) 134235152 130482792 q10Shape15T42=true := by decide

private def q10Shape15T40 : Tree := .split 10 q10Shape15T41 q10Shape15T42
private theorem q10Shape15T40OK : fastTreeOK (forms 15) 134234128 130482792 q10Shape15T40=true := by
  change (fastTreeOK (forms 15) 134234128 (130482792 ||| 2^10) q10Shape15T41 &&
    fastTreeOK (forms 15) (134234128 ||| 2^10) 130482792 q10Shape15T42)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T41OK,q10Shape15T42OK⟩

private def q10Shape15T43 : Tree := (.split 15 (.split 1 (.split 7 (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 0 1 2 4 8)))
private theorem q10Shape15T43OK : fastTreeOK (forms 15) 134234192 130482728 q10Shape15T43=true := by decide

private def q10Shape15T39 : Tree := .split 6 q10Shape15T40 q10Shape15T43
private theorem q10Shape15T39OK : fastTreeOK (forms 15) 134234128 130482728 q10Shape15T39=true := by
  change (fastTreeOK (forms 15) 134234128 (130482728 ||| 2^6) q10Shape15T40 &&
    fastTreeOK (forms 15) (134234128 ||| 2^6) 130482728 q10Shape15T43)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T40OK,q10Shape15T43OK⟩

private def q10Shape15T44 : Tree := (.split 15 (.split 1 (.split 7 (.split 6 (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 2 3 5 6 8))) (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 2 3 5 6 8)))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 2 3 5 6 8))) (.tip (.cover 0 1 2 4 9)))
private theorem q10Shape15T44OK : fastTreeOK (forms 15) 134234160 130482696 q10Shape15T44=true := by decide

private def q10Shape15T38 : Tree := .split 5 q10Shape15T39 q10Shape15T44
private theorem q10Shape15T38OK : fastTreeOK (forms 15) 134234128 130482696 q10Shape15T38=true := by
  change (fastTreeOK (forms 15) 134234128 (130482696 ||| 2^5) q10Shape15T39 &&
    fastTreeOK (forms 15) (134234128 ||| 2^5) 130482696 q10Shape15T44)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T39OK,q10Shape15T44OK⟩

private def q10Shape15T34 : Tree := .split 4 q10Shape15T35 q10Shape15T38
private theorem q10Shape15T34OK : fastTreeOK (forms 15) 134234112 130482696 q10Shape15T34=true := by
  change (fastTreeOK (forms 15) 134234112 (130482696 ||| 2^4) q10Shape15T35 &&
    fastTreeOK (forms 15) (134234112 ||| 2^4) 130482696 q10Shape15T38)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T35OK,q10Shape15T38OK⟩

private def q10Shape15T45 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape15T45OK : fastTreeOK (forms 15) 134365184 130351624 q10Shape15T45=true := by decide

private def q10Shape15T33 : Tree := .split 17 q10Shape15T34 q10Shape15T45
private theorem q10Shape15T33OK : fastTreeOK (forms 15) 134234112 130351624 q10Shape15T33=true := by
  change (fastTreeOK (forms 15) 134234112 (130351624 ||| 2^17) q10Shape15T34 &&
    fastTreeOK (forms 15) (134234112 ||| 2^17) 130351624 q10Shape15T45)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T34OK,q10Shape15T45OK⟩

private def q10Shape15T46 : Tree := (.tip (.cover 0 1 4 7 9))
private theorem q10Shape15T46OK : fastTreeOK (forms 15) 134299648 130286088 q10Shape15T46=true := by decide

private def q10Shape15T32 : Tree := .split 16 q10Shape15T33 q10Shape15T46
private theorem q10Shape15T32OK : fastTreeOK (forms 15) 134234112 130286088 q10Shape15T32=true := by
  change (fastTreeOK (forms 15) 134234112 (130286088 ||| 2^16) q10Shape15T33 &&
    fastTreeOK (forms 15) (134234112 ||| 2^16) 130286088 q10Shape15T46)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T33OK,q10Shape15T46OK⟩

private def q10Shape15T47 : Tree := (.tip (.cover 2 3 4 5 8))
private theorem q10Shape15T47OK : fastTreeOK (forms 15) 134496256 130023944 q10Shape15T47=true := by decide

private def q10Shape15T31 : Tree := .split 18 q10Shape15T32 q10Shape15T47
private theorem q10Shape15T31OK : fastTreeOK (forms 15) 134234112 130023944 q10Shape15T31=true := by
  change (fastTreeOK (forms 15) 134234112 (130023944 ||| 2^18) q10Shape15T32 &&
    fastTreeOK (forms 15) (134234112 ||| 2^18) 130023944 q10Shape15T47)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T32OK,q10Shape15T47OK⟩

private def q10Shape15T9 : Tree := .split 14 q10Shape15T10 q10Shape15T31
private theorem q10Shape15T9OK : fastTreeOK (forms 15) 134217728 130023944 q10Shape15T9=true := by
  change (fastTreeOK (forms 15) 134217728 (130023944 ||| 2^14) q10Shape15T10 &&
    fastTreeOK (forms 15) (134217728 ||| 2^14) 130023944 q10Shape15T31)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T10OK,q10Shape15T31OK⟩

private def q10Shape15T54 : Tree := (.split 6 (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 10 (.tip (.cover 2 4 5 6 8)) (.split 15 (.split 16 (.tip (.cover 0 1 3 5 9)) (.split 19 (.tip (.drop 3 6 7 (some 1) (some 2) none)) (.tip (.drop 3 6 7 (some 0) (some 2) (some 2))))) (.split 16 (.tip (.cover 2 5 6 7 9)) (.tip (.cover 0 1 3 4 9)))))))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 9)))
private theorem q10Shape15T54OK : fastTreeOK (forms 15) 134218240 130308152 q10Shape15T54=true := by decide

private def q10Shape15T56 : Tree := (.tip (.cover 0 3 4 5 8))
private theorem q10Shape15T56OK : fastTreeOK (forms 15) 134218272 130308184 q10Shape15T56=true := by decide

private def q10Shape15T61 : Tree := (.split 10 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8)))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8))) (.split 15 (.split 19 (.tip (.drop 7 8 9 none (some 6) (some 6))) (.split 1 (.split 2 (.split 7 (.split 13 (.tip (.small 1)) (.tip (.cover 2 4 6 7 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 2 4 6 7 8))) (.tip (.cover 0 2 3 5 8)))) (.split 19 (.split 1 (.split 2 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 2 5 6 7 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 2 5 6 7 8))) (.tip (.cover 0 2 3 7 8)))))
private theorem q10Shape15T61OK : fastTreeOK (forms 15) 134218336 133650456 q10Shape15T61=true := by decide

private def q10Shape15T62 : Tree := (.tip (.cover 0 3 4 5 8))
private theorem q10Shape15T62OK : fastTreeOK (forms 15) 136315488 131553304 q10Shape15T62=true := by decide

private def q10Shape15T60 : Tree := .split 21 q10Shape15T61 q10Shape15T62
private theorem q10Shape15T60OK : fastTreeOK (forms 15) 134218336 131553304 q10Shape15T60=true := by
  change (fastTreeOK (forms 15) 134218336 (131553304 ||| 2^21) q10Shape15T61 &&
    fastTreeOK (forms 15) (134218336 ||| 2^21) 131553304 q10Shape15T62)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T61OK,q10Shape15T62OK⟩

private def q10Shape15T63 : Tree := (.tip (.cover 0 3 4 5 9))
private theorem q10Shape15T63OK : fastTreeOK (forms 15) 135266912 130504728 q10Shape15T63=true := by decide

private def q10Shape15T59 : Tree := .split 20 q10Shape15T60 q10Shape15T63
private theorem q10Shape15T59OK : fastTreeOK (forms 15) 134218336 130504728 q10Shape15T59=true := by
  change (fastTreeOK (forms 15) 134218336 (130504728 ||| 2^20) q10Shape15T60 &&
    fastTreeOK (forms 15) (134218336 ||| 2^20) 130504728 q10Shape15T63)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T60OK,q10Shape15T63OK⟩

private def q10Shape15T64 : Tree := (.tip (.cover 0 3 4 5 8))
private theorem q10Shape15T64OK : fastTreeOK (forms 15) 134349408 130373656 q10Shape15T64=true := by decide

private def q10Shape15T58 : Tree := .split 17 q10Shape15T59 q10Shape15T64
private theorem q10Shape15T58OK : fastTreeOK (forms 15) 134218336 130373656 q10Shape15T58=true := by
  change (fastTreeOK (forms 15) 134218336 (130373656 ||| 2^17) q10Shape15T59 &&
    fastTreeOK (forms 15) (134218336 ||| 2^17) 130373656 q10Shape15T64)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T59OK,q10Shape15T64OK⟩

private def q10Shape15T65 : Tree := (.tip (.cover 0 3 4 5 9))
private theorem q10Shape15T65OK : fastTreeOK (forms 15) 134283872 130308120 q10Shape15T65=true := by decide

private def q10Shape15T57 : Tree := .split 16 q10Shape15T58 q10Shape15T65
private theorem q10Shape15T57OK : fastTreeOK (forms 15) 134218336 130308120 q10Shape15T57=true := by
  change (fastTreeOK (forms 15) 134218336 (130308120 ||| 2^16) q10Shape15T58 &&
    fastTreeOK (forms 15) (134218336 ||| 2^16) 130308120 q10Shape15T65)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T58OK,q10Shape15T65OK⟩

private def q10Shape15T55 : Tree := .split 6 q10Shape15T56 q10Shape15T57
private theorem q10Shape15T55OK : fastTreeOK (forms 15) 134218272 130308120 q10Shape15T55=true := by
  change (fastTreeOK (forms 15) 134218272 (130308120 ||| 2^6) q10Shape15T56 &&
    fastTreeOK (forms 15) (134218272 ||| 2^6) 130308120 q10Shape15T57)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T56OK,q10Shape15T57OK⟩

private def q10Shape15T53 : Tree := .split 5 q10Shape15T54 q10Shape15T55
private theorem q10Shape15T53OK : fastTreeOK (forms 15) 134218240 130308120 q10Shape15T53=true := by
  change (fastTreeOK (forms 15) 134218240 (130308120 ||| 2^5) q10Shape15T54 &&
    fastTreeOK (forms 15) (134218240 ||| 2^5) 130308120 q10Shape15T55)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T54OK,q10Shape15T55OK⟩

private def q10Shape15T69 : Tree := (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 16 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 3 4 7 9)))))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8)))
private theorem q10Shape15T69OK : fastTreeOK (forms 15) 134218256 130309224 q10Shape15T69=true := by decide

private def q10Shape15T70 : Tree := (.split 1 (.split 2 (.split 15 (.split 16 (.split 17 (.split 19 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 7 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 8))))) (.tip (.cover 0 1 3 5 8))) (.tip (.cover 0 2 3 5 9))) (.split 17 (.tip (.cover 0 2 3 5 8)) (.split 19 (.split 20 (.split 21 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 3 4 7 8))))) (.split 16 (.tip (.cover 0 3 5 7 9)) (.tip (.cover 0 1 3 4 9)))) (.tip (.cover 4 5 6 7 8))) (.tip (.cover 4 5 6 7 8)))
private theorem q10Shape15T70OK : fastTreeOK (forms 15) 134219280 130308200 q10Shape15T70=true := by decide

private def q10Shape15T68 : Tree := .split 10 q10Shape15T69 q10Shape15T70
private theorem q10Shape15T68OK : fastTreeOK (forms 15) 134218256 130308200 q10Shape15T68=true := by
  change (fastTreeOK (forms 15) 134218256 (130308200 ||| 2^10) q10Shape15T69 &&
    fastTreeOK (forms 15) (134218256 ||| 2^10) 130308200 q10Shape15T70)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T69OK,q10Shape15T70OK⟩

private def q10Shape15T71 : Tree := (.split 10 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8)))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 0 1 2 3 8)))
private theorem q10Shape15T71OK : fastTreeOK (forms 15) 134218320 130308136 q10Shape15T71=true := by decide

private def q10Shape15T67 : Tree := .split 6 q10Shape15T68 q10Shape15T71
private theorem q10Shape15T67OK : fastTreeOK (forms 15) 134218256 130308136 q10Shape15T67=true := by
  change (fastTreeOK (forms 15) 134218256 (130308136 ||| 2^6) q10Shape15T68 &&
    fastTreeOK (forms 15) (134218256 ||| 2^6) 130308136 q10Shape15T71)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T68OK,q10Shape15T71OK⟩

private def q10Shape15T72 : Tree := (.split 10 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 2 4 5 6 8))) (.tip (.cover 0 1 2 3 9)))
private theorem q10Shape15T72OK : fastTreeOK (forms 15) 134218288 130308104 q10Shape15T72=true := by decide

private def q10Shape15T66 : Tree := .split 5 q10Shape15T67 q10Shape15T72
private theorem q10Shape15T66OK : fastTreeOK (forms 15) 134218256 130308104 q10Shape15T66=true := by
  change (fastTreeOK (forms 15) 134218256 (130308104 ||| 2^5) q10Shape15T67 &&
    fastTreeOK (forms 15) (134218256 ||| 2^5) 130308104 q10Shape15T72)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T67OK,q10Shape15T72OK⟩

private def q10Shape15T52 : Tree := .split 4 q10Shape15T53 q10Shape15T66
private theorem q10Shape15T52OK : fastTreeOK (forms 15) 134218240 130308104 q10Shape15T52=true := by
  change (fastTreeOK (forms 15) 134218240 (130308104 ||| 2^4) q10Shape15T53 &&
    fastTreeOK (forms 15) (134218240 ||| 2^4) 130308104 q10Shape15T66)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T53OK,q10Shape15T66OK⟩

private def q10Shape15T73 : Tree := (.tip (.cover 0 1 3 7 8))
private theorem q10Shape15T73OK : fastTreeOK (forms 15) 134222336 130304008 q10Shape15T73=true := by decide

private def q10Shape15T51 : Tree := .split 12 q10Shape15T52 q10Shape15T73
private theorem q10Shape15T51OK : fastTreeOK (forms 15) 134218240 130304008 q10Shape15T51=true := by
  change (fastTreeOK (forms 15) 134218240 (130304008 ||| 2^12) q10Shape15T52 &&
    fastTreeOK (forms 15) (134218240 ||| 2^12) 130304008 q10Shape15T73)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T52OK,q10Shape15T73OK⟩

private def q10Shape15T74 : Tree := (.tip (.cover 0 1 3 7 9))
private theorem q10Shape15T74OK : fastTreeOK (forms 15) 134220288 130301960 q10Shape15T74=true := by decide

private def q10Shape15T50 : Tree := .split 11 q10Shape15T51 q10Shape15T74
private theorem q10Shape15T50OK : fastTreeOK (forms 15) 134218240 130301960 q10Shape15T50=true := by
  change (fastTreeOK (forms 15) 134218240 (130301960 ||| 2^11) q10Shape15T51 &&
    fastTreeOK (forms 15) (134218240 ||| 2^11) 130301960 q10Shape15T74)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T51OK,q10Shape15T74OK⟩

private def q10Shape15T75 : Tree := (.tip (.cover 2 3 4 5 8))
private theorem q10Shape15T75OK : fastTreeOK (forms 15) 134480384 130039816 q10Shape15T75=true := by decide

private def q10Shape15T49 : Tree := .split 18 q10Shape15T50 q10Shape15T75
private theorem q10Shape15T49OK : fastTreeOK (forms 15) 134218240 130039816 q10Shape15T49=true := by
  change (fastTreeOK (forms 15) 134218240 (130039816 ||| 2^18) q10Shape15T50 &&
    fastTreeOK (forms 15) (134218240 ||| 2^18) 130039816 q10Shape15T75)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T50OK,q10Shape15T75OK⟩

private def q10Shape15T76 : Tree := (.tip (.cover 2 3 4 5 8))
private theorem q10Shape15T76OK : fastTreeOK (forms 15) 134234624 130023432 q10Shape15T76=true := by decide

private def q10Shape15T48 : Tree := .split 14 q10Shape15T49 q10Shape15T76
private theorem q10Shape15T48OK : fastTreeOK (forms 15) 134218240 130023432 q10Shape15T48=true := by
  change (fastTreeOK (forms 15) 134218240 (130023432 ||| 2^14) q10Shape15T49 &&
    fastTreeOK (forms 15) (134218240 ||| 2^14) 130023432 q10Shape15T76)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T49OK,q10Shape15T76OK⟩

private def q10Shape15T8 : Tree := .split 9 q10Shape15T9 q10Shape15T48
private theorem q10Shape15T8OK : fastTreeOK (forms 15) 134217728 130023432 q10Shape15T8=true := by
  change (fastTreeOK (forms 15) 134217728 (130023432 ||| 2^9) q10Shape15T9 &&
    fastTreeOK (forms 15) (134217728 ||| 2^9) 130023432 q10Shape15T48)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T9OK,q10Shape15T48OK⟩

private def q10Shape15T83 : Tree := (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 11 (.split 16 (.tip (.cover 0 2 5 7 9)) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 2 3 7 9)))))) (.tip (.cover 3 4 5 6 8))) (.tip (.cover 3 4 5 6 8))) (.tip (.cover 3 4 5 6 8)))
private theorem q10Shape15T83OK : fastTreeOK (forms 15) 134217736 130302576 q10Shape15T83=true := by decide

private def q10Shape15T86 : Tree := (.split 12 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 15 (.split 16 (.tip (.cover 0 1 2 5 9)) (.split 19 (.tip (.drop 2 6 7 (some 1) (some 3) none)) (.tip (.drop 2 6 7 (some 0) (some 3) (some 3))))) (.split 16 (.tip (.cover 3 5 6 7 9)) (.tip (.cover 0 1 2 4 9))))))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 9)))
private theorem q10Shape15T86OK : fastTreeOK (forms 15) 134217752 130305632 q10Shape15T86=true := by decide

private def q10Shape15T87 : Tree := (.split 12 (.tip (.cover 0 2 4 5 8)) (.split 16 (.split 17 (.split 20 (.split 21 (.split 15 (.split 19 (.tip (.drop 7 8 9 none (some 6) (some 6))) (.split 1 (.split 7 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 3 4 6 7 8))) (.tip (.cover 3 4 6 7 8))) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 8)))) (.split 19 (.split 2 (.split 7 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 3 5 6 7 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 3 5 6 7 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 7 8)))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 9))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 9))))
private theorem q10Shape15T87OK : fastTreeOK (forms 15) 134219800 130303584 q10Shape15T87=true := by decide

private def q10Shape15T85 : Tree := .split 11 q10Shape15T86 q10Shape15T87
private theorem q10Shape15T85OK : fastTreeOK (forms 15) 134217752 130303584 q10Shape15T85=true := by
  change (fastTreeOK (forms 15) 134217752 (130303584 ||| 2^11) q10Shape15T86 &&
    fastTreeOK (forms 15) (134217752 ||| 2^11) 130303584 q10Shape15T87)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T86OK,q10Shape15T87OK⟩

private def q10Shape15T90 : Tree := (.split 7 (.split 8 (.split 15 (.split 16 (.split 17 (.split 19 (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 1 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 5 8))) (.tip (.cover 0 2 3 5 8))))) (.tip (.cover 0 1 2 5 8))) (.tip (.cover 0 2 3 5 9))) (.split 17 (.tip (.cover 0 2 3 5 8)) (.split 19 (.split 20 (.split 21 (.split 2 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 4 7 8))))) (.split 16 (.tip (.cover 0 2 5 7 9)) (.tip (.cover 0 1 2 4 9)))) (.tip (.cover 4 5 6 7 8))) (.tip (.cover 4 5 6 7 8)))
private theorem q10Shape15T90OK : fastTreeOK (forms 15) 134218776 130308704 q10Shape15T90=true := by decide

private def q10Shape15T91 : Tree := (.tip (.cover 0 1 2 3 8))
private theorem q10Shape15T91OK : fastTreeOK (forms 15) 134222872 130304608 q10Shape15T91=true := by decide

private def q10Shape15T89 : Tree := .split 12 q10Shape15T90 q10Shape15T91
private theorem q10Shape15T89OK : fastTreeOK (forms 15) 134218776 130304608 q10Shape15T89=true := by
  change (fastTreeOK (forms 15) 134218776 (130304608 ||| 2^12) q10Shape15T90 &&
    fastTreeOK (forms 15) (134218776 ||| 2^12) 130304608 q10Shape15T91)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T90OK,q10Shape15T91OK⟩

private def q10Shape15T92 : Tree := (.tip (.cover 0 1 2 3 9))
private theorem q10Shape15T92OK : fastTreeOK (forms 15) 134220824 130302560 q10Shape15T92=true := by decide

private def q10Shape15T88 : Tree := .split 11 q10Shape15T89 q10Shape15T92
private theorem q10Shape15T88OK : fastTreeOK (forms 15) 134218776 130302560 q10Shape15T88=true := by
  change (fastTreeOK (forms 15) 134218776 (130302560 ||| 2^11) q10Shape15T89 &&
    fastTreeOK (forms 15) (134218776 ||| 2^11) 130302560 q10Shape15T92)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T89OK,q10Shape15T92OK⟩

private def q10Shape15T84 : Tree := .split 10 q10Shape15T85 q10Shape15T88
private theorem q10Shape15T84OK : fastTreeOK (forms 15) 134217752 130302560 q10Shape15T84=true := by
  change (fastTreeOK (forms 15) 134217752 (130302560 ||| 2^10) q10Shape15T85 &&
    fastTreeOK (forms 15) (134217752 ||| 2^10) 130302560 q10Shape15T88)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T85OK,q10Shape15T88OK⟩

private def q10Shape15T82 : Tree := .split 4 q10Shape15T83 q10Shape15T84
private theorem q10Shape15T82OK : fastTreeOK (forms 15) 134217736 130302560 q10Shape15T82=true := by
  change (fastTreeOK (forms 15) 134217736 (130302560 ||| 2^4) q10Shape15T83 &&
    fastTreeOK (forms 15) (134217736 ||| 2^4) 130302560 q10Shape15T84)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T83OK,q10Shape15T84OK⟩

private def q10Shape15T93 : Tree := (.tip (.cover 0 1 2 7 8))
private theorem q10Shape15T93OK : fastTreeOK (forms 15) 134217800 130302496 q10Shape15T93=true := by decide

private def q10Shape15T81 : Tree := .split 6 q10Shape15T82 q10Shape15T93
private theorem q10Shape15T81OK : fastTreeOK (forms 15) 134217736 130302496 q10Shape15T81=true := by
  change (fastTreeOK (forms 15) 134217736 (130302496 ||| 2^6) q10Shape15T82 &&
    fastTreeOK (forms 15) (134217736 ||| 2^6) 130302496 q10Shape15T93)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T82OK,q10Shape15T93OK⟩

private def q10Shape15T94 : Tree := (.tip (.cover 0 1 2 7 9))
private theorem q10Shape15T94OK : fastTreeOK (forms 15) 134217768 130302464 q10Shape15T94=true := by decide

private def q10Shape15T80 : Tree := .split 5 q10Shape15T81 q10Shape15T94
private theorem q10Shape15T80OK : fastTreeOK (forms 15) 134217736 130302464 q10Shape15T80=true := by
  change (fastTreeOK (forms 15) 134217736 (130302464 ||| 2^5) q10Shape15T81 &&
    fastTreeOK (forms 15) (134217736 ||| 2^5) 130302464 q10Shape15T94)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T81OK,q10Shape15T94OK⟩

private def q10Shape15T95 : Tree := (.tip (.cover 2 3 4 5 8))
private theorem q10Shape15T95OK : fastTreeOK (forms 15) 134479880 130040320 q10Shape15T95=true := by decide

private def q10Shape15T79 : Tree := .split 18 q10Shape15T80 q10Shape15T95
private theorem q10Shape15T79OK : fastTreeOK (forms 15) 134217736 130040320 q10Shape15T79=true := by
  change (fastTreeOK (forms 15) 134217736 (130040320 ||| 2^18) q10Shape15T80 &&
    fastTreeOK (forms 15) (134217736 ||| 2^18) 130040320 q10Shape15T95)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T80OK,q10Shape15T95OK⟩

private def q10Shape15T96 : Tree := (.tip (.cover 2 3 4 5 8))
private theorem q10Shape15T96OK : fastTreeOK (forms 15) 134234120 130023936 q10Shape15T96=true := by decide

private def q10Shape15T78 : Tree := .split 14 q10Shape15T79 q10Shape15T96
private theorem q10Shape15T78OK : fastTreeOK (forms 15) 134217736 130023936 q10Shape15T78=true := by
  change (fastTreeOK (forms 15) 134217736 (130023936 ||| 2^14) q10Shape15T79 &&
    fastTreeOK (forms 15) (134217736 ||| 2^14) 130023936 q10Shape15T96)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T79OK,q10Shape15T96OK⟩

private def q10Shape15T97 : Tree := (.tip (.cover 2 3 4 5 8))
private theorem q10Shape15T97OK : fastTreeOK (forms 15) 134218248 130023424 q10Shape15T97=true := by decide

private def q10Shape15T77 : Tree := .split 9 q10Shape15T78 q10Shape15T97
private theorem q10Shape15T77OK : fastTreeOK (forms 15) 134217736 130023424 q10Shape15T77=true := by
  change (fastTreeOK (forms 15) 134217736 (130023424 ||| 2^9) q10Shape15T78 &&
    fastTreeOK (forms 15) (134217736 ||| 2^9) 130023424 q10Shape15T97)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T78OK,q10Shape15T97OK⟩

private def q10Shape15T7 : Tree := .split 3 q10Shape15T8 q10Shape15T77
private theorem q10Shape15T7OK : fastTreeOK (forms 15) 134217728 130023424 q10Shape15T7=true := by
  change (fastTreeOK (forms 15) 134217728 (130023424 ||| 2^3) q10Shape15T8 &&
    fastTreeOK (forms 15) (134217728 ||| 2^3) 130023424 q10Shape15T77)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T8OK,q10Shape15T77OK⟩

private def q10Shape15T5 : Tree := .split 27 q10Shape15T6 q10Shape15T7
private theorem q10Shape15T5OK : fastTreeOK (forms 15) 0 130023424 q10Shape15T5=true := by
  change (fastTreeOK (forms 15) 0 (130023424 ||| 2^27) q10Shape15T6 &&
    fastTreeOK (forms 15) (0 ||| 2^27) 130023424 q10Shape15T7)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T6OK,q10Shape15T7OK⟩

private def q10Shape15T103 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape15T103OK : fastTreeOK (forms 15) 67108864 197411336 q10Shape15T103=true := by decide

private def q10Shape15T108 : Tree := (.split 6 (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 20 (.tip (.cover 2 3 4 6 7)) (.split 10 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 2 4 6 8 9))) (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 2 3 6 8 9)))))))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 9)))
private theorem q10Shape15T108OK : fastTreeOK (forms 15) 67371008 199770680 q10Shape15T108=true := by decide

private def q10Shape15T110 : Tree := (.split 10 (.split 11 (.split 12 (.split 15 (.tip (.cover 0 1 6 8 9)) (.split 17 (.tip (.cover 0 1 6 7 8)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))))) (.tip (.cover 0 2 4 5 9))) (.tip (.cover 0 4 5 8 9))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 15 (.split 16 (.split 17 (.split 1 (.split 7 (.split 13 (.tip (.drop 6 7 9 (some 4) (some 4) (some 4))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 3 5 7 8))) (.tip (.cover 0 3 5 7 8)))))
private theorem q10Shape15T110OK : fastTreeOK (forms 15) 67371040 199770712 q10Shape15T110=true := by decide

private def q10Shape15T111 : Tree := (.split 20 (.split 2 (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 7 8)))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 0 1 2 5 7)))
private theorem q10Shape15T111OK : fastTreeOK (forms 15) 67371104 199770648 q10Shape15T111=true := by decide

private def q10Shape15T109 : Tree := .split 6 q10Shape15T110 q10Shape15T111
private theorem q10Shape15T109OK : fastTreeOK (forms 15) 67371040 199770648 q10Shape15T109=true := by
  change (fastTreeOK (forms 15) 67371040 (199770648 ||| 2^6) q10Shape15T110 &&
    fastTreeOK (forms 15) (67371040 ||| 2^6) 199770648 q10Shape15T111)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T110OK,q10Shape15T111OK⟩

private def q10Shape15T107 : Tree := .split 5 q10Shape15T108 q10Shape15T109
private theorem q10Shape15T107OK : fastTreeOK (forms 15) 67371008 199770648 q10Shape15T107=true := by
  change (fastTreeOK (forms 15) 67371008 (199770648 ||| 2^5) q10Shape15T108 &&
    fastTreeOK (forms 15) (67371008 ||| 2^5) 199770648 q10Shape15T109)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T108OK,q10Shape15T109OK⟩

private def q10Shape15T112 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape15T112OK : fastTreeOK (forms 15) 69468160 197673496 q10Shape15T112=true := by decide

private def q10Shape15T106 : Tree := .split 21 q10Shape15T107 q10Shape15T112
private theorem q10Shape15T106OK : fastTreeOK (forms 15) 67371008 197673496 q10Shape15T106=true := by
  change (fastTreeOK (forms 15) 67371008 (197673496 ||| 2^21) q10Shape15T107 &&
    fastTreeOK (forms 15) (67371008 ||| 2^21) 197673496 q10Shape15T112)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T107OK,q10Shape15T112OK⟩

private def q10Shape15T115 : Tree := (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 10 (.split 12 (.split 15 (.split 17 (.split 11 (.split 16 (.tip (.drop 7 8 9 (some 6) none (some 6))) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7)))) (.split 16 (.split 1 (.split 7 (.split 13 (.tip (.drop 6 7 9 (some 4) (some 4) (some 4))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 5 7 8)))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 9))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 9))))
private theorem q10Shape15T115OK : fastTreeOK (forms 15) 67371024 199770664 q10Shape15T115=true := by decide

private def q10Shape15T116 : Tree := (.split 20 (.split 2 (.split 6 (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 7 8)))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7)))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 0 1 2 5 9)))
private theorem q10Shape15T116OK : fastTreeOK (forms 15) 67371056 199770632 q10Shape15T116=true := by decide

private def q10Shape15T114 : Tree := .split 5 q10Shape15T115 q10Shape15T116
private theorem q10Shape15T114OK : fastTreeOK (forms 15) 67371024 199770632 q10Shape15T114=true := by
  change (fastTreeOK (forms 15) 67371024 (199770632 ||| 2^5) q10Shape15T115 &&
    fastTreeOK (forms 15) (67371024 ||| 2^5) 199770632 q10Shape15T116)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T115OK,q10Shape15T116OK⟩

private def q10Shape15T117 : Tree := (.tip (.cover 0 1 5 7 8))
private theorem q10Shape15T117OK : fastTreeOK (forms 15) 69468176 197673480 q10Shape15T117=true := by decide

private def q10Shape15T113 : Tree := .split 21 q10Shape15T114 q10Shape15T117
private theorem q10Shape15T113OK : fastTreeOK (forms 15) 67371024 197673480 q10Shape15T113=true := by
  change (fastTreeOK (forms 15) 67371024 (197673480 ||| 2^21) q10Shape15T114 &&
    fastTreeOK (forms 15) (67371024 ||| 2^21) 197673480 q10Shape15T117)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T114OK,q10Shape15T117OK⟩

private def q10Shape15T105 : Tree := .split 4 q10Shape15T106 q10Shape15T113
private theorem q10Shape15T105OK : fastTreeOK (forms 15) 67371008 197673480 q10Shape15T105=true := by
  change (fastTreeOK (forms 15) 67371008 (197673480 ||| 2^4) q10Shape15T106 &&
    fastTreeOK (forms 15) (67371008 ||| 2^4) 197673480 q10Shape15T113)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T106OK,q10Shape15T113OK⟩

private def q10Shape15T118 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape15T118OK : fastTreeOK (forms 15) 67895296 197149192 q10Shape15T118=true := by decide

private def q10Shape15T104 : Tree := .split 19 q10Shape15T105 q10Shape15T118
private theorem q10Shape15T104OK : fastTreeOK (forms 15) 67371008 197149192 q10Shape15T104=true := by
  change (fastTreeOK (forms 15) 67371008 (197149192 ||| 2^19) q10Shape15T105 &&
    fastTreeOK (forms 15) (67371008 ||| 2^19) 197149192 q10Shape15T118)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T105OK,q10Shape15T118OK⟩

private def q10Shape15T102 : Tree := .split 18 q10Shape15T103 q10Shape15T104
private theorem q10Shape15T102OK : fastTreeOK (forms 15) 67108864 197149192 q10Shape15T102=true := by
  change (fastTreeOK (forms 15) 67108864 (197149192 ||| 2^18) q10Shape15T103 &&
    fastTreeOK (forms 15) (67108864 ||| 2^18) 197149192 q10Shape15T104)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T103OK,q10Shape15T104OK⟩

private def q10Shape15T124 : Tree := (.split 6 (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 16 (.tip (.cover 2 3 5 6 7)) (.split 10 (.split 11 (.tip (.cover 0 1 4 5 9)) (.tip (.cover 2 5 6 8 9))) (.split 20 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 2 3 6 8 9)))))))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 9)))
private theorem q10Shape15T124OK : fastTreeOK (forms 15) 67125248 197558840 q10Shape15T124=true := by decide

private def q10Shape15T126 : Tree := (.split 10 (.split 11 (.split 12 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))))) (.tip (.cover 0 2 4 5 9))) (.tip (.cover 0 4 5 8 9))) (.split 12 (.tip (.cover 0 4 5 7 8)) (.split 19 (.split 20 (.split 21 (.split 2 (.split 8 (.split 13 (.tip (.drop 6 7 9 (some 5) (some 5) (some 5))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 3 4 7 8)))))
private theorem q10Shape15T126OK : fastTreeOK (forms 15) 67125280 197558872 q10Shape15T126=true := by decide

private def q10Shape15T127 : Tree := (.split 16 (.split 1 (.split 7 (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 0 1 2 4 7)))
private theorem q10Shape15T127OK : fastTreeOK (forms 15) 67125344 197558808 q10Shape15T127=true := by decide

private def q10Shape15T125 : Tree := .split 6 q10Shape15T126 q10Shape15T127
private theorem q10Shape15T125OK : fastTreeOK (forms 15) 67125280 197558808 q10Shape15T125=true := by
  change (fastTreeOK (forms 15) 67125280 (197558808 ||| 2^6) q10Shape15T126 &&
    fastTreeOK (forms 15) (67125280 ||| 2^6) 197558808 q10Shape15T127)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T126OK,q10Shape15T127OK⟩

private def q10Shape15T123 : Tree := .split 5 q10Shape15T124 q10Shape15T125
private theorem q10Shape15T123OK : fastTreeOK (forms 15) 67125248 197558808 q10Shape15T123=true := by
  change (fastTreeOK (forms 15) 67125248 (197558808 ||| 2^5) q10Shape15T124 &&
    fastTreeOK (forms 15) (67125248 ||| 2^5) 197558808 q10Shape15T125)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T124OK,q10Shape15T125OK⟩

private def q10Shape15T129 : Tree := (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 10 (.split 12 (.split 19 (.split 21 (.split 11 (.split 20 (.tip (.drop 7 8 9 (some 6) none (some 6))) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 9 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7)))) (.split 20 (.split 2 (.split 8 (.split 13 (.tip (.drop 6 7 9 (some 5) (some 5) (some 5))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 9))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 9))))
private theorem q10Shape15T129OK : fastTreeOK (forms 15) 67125264 197558824 q10Shape15T129=true := by decide

private def q10Shape15T130 : Tree := (.split 16 (.split 1 (.split 7 (.split 6 (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9)))) (.tip (.cover 2 3 5 6 7))) (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 7 8)))) (.tip (.cover 2 3 5 6 7)))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 0 1 2 4 9)))
private theorem q10Shape15T130OK : fastTreeOK (forms 15) 67125296 197558792 q10Shape15T130=true := by decide

private def q10Shape15T128 : Tree := .split 5 q10Shape15T129 q10Shape15T130
private theorem q10Shape15T128OK : fastTreeOK (forms 15) 67125264 197558792 q10Shape15T128=true := by
  change (fastTreeOK (forms 15) 67125264 (197558792 ||| 2^5) q10Shape15T129 &&
    fastTreeOK (forms 15) (67125264 ||| 2^5) 197558792 q10Shape15T130)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T129OK,q10Shape15T130OK⟩

private def q10Shape15T122 : Tree := .split 4 q10Shape15T123 q10Shape15T128
private theorem q10Shape15T122OK : fastTreeOK (forms 15) 67125248 197558792 q10Shape15T122=true := by
  change (fastTreeOK (forms 15) 67125248 (197558792 ||| 2^4) q10Shape15T123 &&
    fastTreeOK (forms 15) (67125248 ||| 2^4) 197558792 q10Shape15T128)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T123OK,q10Shape15T128OK⟩

private def q10Shape15T131 : Tree := (.tip (.cover 0 1 4 7 8))
private theorem q10Shape15T131OK : fastTreeOK (forms 15) 67256320 197427720 q10Shape15T131=true := by decide

private def q10Shape15T121 : Tree := .split 17 q10Shape15T122 q10Shape15T131
private theorem q10Shape15T121OK : fastTreeOK (forms 15) 67125248 197427720 q10Shape15T121=true := by
  change (fastTreeOK (forms 15) 67125248 (197427720 ||| 2^17) q10Shape15T122 &&
    fastTreeOK (forms 15) (67125248 ||| 2^17) 197427720 q10Shape15T131)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T122OK,q10Shape15T131OK⟩

private def q10Shape15T132 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape15T132OK : fastTreeOK (forms 15) 67158016 197394952 q10Shape15T132=true := by decide

private def q10Shape15T120 : Tree := .split 15 q10Shape15T121 q10Shape15T132
private theorem q10Shape15T120OK : fastTreeOK (forms 15) 67125248 197394952 q10Shape15T120=true := by
  change (fastTreeOK (forms 15) 67125248 (197394952 ||| 2^15) q10Shape15T121 &&
    fastTreeOK (forms 15) (67125248 ||| 2^15) 197394952 q10Shape15T132)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T121OK,q10Shape15T132OK⟩

private def q10Shape15T133 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T133OK : fastTreeOK (forms 15) 67387392 197132808 q10Shape15T133=true := by decide

private def q10Shape15T119 : Tree := .split 18 q10Shape15T120 q10Shape15T133
private theorem q10Shape15T119OK : fastTreeOK (forms 15) 67125248 197132808 q10Shape15T119=true := by
  change (fastTreeOK (forms 15) 67125248 (197132808 ||| 2^18) q10Shape15T120 &&
    fastTreeOK (forms 15) (67125248 ||| 2^18) 197132808 q10Shape15T133)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T120OK,q10Shape15T133OK⟩

private def q10Shape15T101 : Tree := .split 14 q10Shape15T102 q10Shape15T119
private theorem q10Shape15T101OK : fastTreeOK (forms 15) 67108864 197132808 q10Shape15T101=true := by
  change (fastTreeOK (forms 15) 67108864 (197132808 ||| 2^14) q10Shape15T102 &&
    fastTreeOK (forms 15) (67108864 ||| 2^14) 197132808 q10Shape15T119)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T102OK,q10Shape15T119OK⟩

private def q10Shape15T140 : Tree := (.split 6 (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 11 (.tip (.cover 2 4 5 6 7)) (.split 15 (.split 16 (.tip (.cover 0 1 3 5 9)) (.tip (.cover 2 5 6 8 9))) (.split 20 (.tip (.cover 0 1 3 4 9)) (.tip (.cover 2 4 6 8 9)))))))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 9)))
private theorem q10Shape15T140OK : fastTreeOK (forms 15) 67109376 197415992 q10Shape15T140=true := by decide

private def q10Shape15T143 : Tree := (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 15 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 3 4 8 9)))))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7)))
private theorem q10Shape15T143OK : fastTreeOK (forms 15) 67109408 197418072 q10Shape15T143=true := by decide

private def q10Shape15T144 : Tree := (.split 1 (.split 2 (.split 15 (.split 16 (.split 17 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 7 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7)))) (.tip (.cover 0 1 3 5 7)))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 3 5 8 9))) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.split 19 (.split 20 (.split 21 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 3 4 7 8))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 3 4 9)))) (.tip (.cover 4 5 6 7 8))) (.tip (.cover 4 5 6 7 8)))
private theorem q10Shape15T144OK : fastTreeOK (forms 15) 67111456 197416024 q10Shape15T144=true := by decide

private def q10Shape15T142 : Tree := .split 11 q10Shape15T143 q10Shape15T144
private theorem q10Shape15T142OK : fastTreeOK (forms 15) 67109408 197416024 q10Shape15T142=true := by
  change (fastTreeOK (forms 15) 67109408 (197416024 ||| 2^11) q10Shape15T143 &&
    fastTreeOK (forms 15) (67109408 ||| 2^11) 197416024 q10Shape15T144)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T143OK,q10Shape15T144OK⟩

private def q10Shape15T145 : Tree := (.split 11 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8)))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 0 1 2 3 7)))
private theorem q10Shape15T145OK : fastTreeOK (forms 15) 67109472 197415960 q10Shape15T145=true := by decide

private def q10Shape15T141 : Tree := .split 6 q10Shape15T142 q10Shape15T145
private theorem q10Shape15T141OK : fastTreeOK (forms 15) 67109408 197415960 q10Shape15T141=true := by
  change (fastTreeOK (forms 15) 67109408 (197415960 ||| 2^6) q10Shape15T142 &&
    fastTreeOK (forms 15) (67109408 ||| 2^6) 197415960 q10Shape15T145)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T142OK,q10Shape15T145OK⟩

private def q10Shape15T139 : Tree := .split 5 q10Shape15T140 q10Shape15T141
private theorem q10Shape15T139OK : fastTreeOK (forms 15) 67109376 197415960 q10Shape15T139=true := by
  change (fastTreeOK (forms 15) 67109376 (197415960 ||| 2^5) q10Shape15T140 &&
    fastTreeOK (forms 15) (67109376 ||| 2^5) 197415960 q10Shape15T141)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T140OK,q10Shape15T141OK⟩

private def q10Shape15T148 : Tree := (.tip (.cover 0 3 4 5 7))
private theorem q10Shape15T148OK : fastTreeOK (forms 15) 67109392 197416040 q10Shape15T148=true := by decide

private def q10Shape15T153 : Tree := (.split 11 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 8)))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.split 16 (.split 20 (.tip (.drop 7 8 9 (some 6) none (some 6))) (.split 1 (.split 2 (.split 7 (.split 13 (.tip (.small 1)) (.tip (.cover 2 4 6 7 8))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 2 4 6 7 8))) (.tip (.cover 0 2 3 5 7)))) (.split 20 (.split 1 (.split 2 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 2 5 6 7 8))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 2 5 6 7 8))) (.tip (.cover 0 2 3 7 8)))))
private theorem q10Shape15T153OK : fastTreeOK (forms 15) 67109456 200201256 q10Shape15T153=true := by decide

private def q10Shape15T154 : Tree := (.tip (.cover 0 3 4 5 7))
private theorem q10Shape15T154OK : fastTreeOK (forms 15) 69206608 198104104 q10Shape15T154=true := by decide

private def q10Shape15T152 : Tree := .split 21 q10Shape15T153 q10Shape15T154
private theorem q10Shape15T152OK : fastTreeOK (forms 15) 67109456 198104104 q10Shape15T152=true := by
  change (fastTreeOK (forms 15) 67109456 (198104104 ||| 2^21) q10Shape15T153 &&
    fastTreeOK (forms 15) (67109456 ||| 2^21) 198104104 q10Shape15T154)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T153OK,q10Shape15T154OK⟩

private def q10Shape15T155 : Tree := (.tip (.cover 0 3 4 5 9))
private theorem q10Shape15T155OK : fastTreeOK (forms 15) 67633744 197579816 q10Shape15T155=true := by decide

private def q10Shape15T151 : Tree := .split 19 q10Shape15T152 q10Shape15T155
private theorem q10Shape15T151OK : fastTreeOK (forms 15) 67109456 197579816 q10Shape15T151=true := by
  change (fastTreeOK (forms 15) 67109456 (197579816 ||| 2^19) q10Shape15T152 &&
    fastTreeOK (forms 15) (67109456 ||| 2^19) 197579816 q10Shape15T155)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T152OK,q10Shape15T155OK⟩

private def q10Shape15T156 : Tree := (.tip (.cover 0 3 4 5 7))
private theorem q10Shape15T156OK : fastTreeOK (forms 15) 67240528 197448744 q10Shape15T156=true := by decide

private def q10Shape15T150 : Tree := .split 17 q10Shape15T151 q10Shape15T156
private theorem q10Shape15T150OK : fastTreeOK (forms 15) 67109456 197448744 q10Shape15T150=true := by
  change (fastTreeOK (forms 15) 67109456 (197448744 ||| 2^17) q10Shape15T151 &&
    fastTreeOK (forms 15) (67109456 ||| 2^17) 197448744 q10Shape15T156)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T151OK,q10Shape15T156OK⟩

private def q10Shape15T157 : Tree := (.tip (.cover 0 3 4 5 9))
private theorem q10Shape15T157OK : fastTreeOK (forms 15) 67142224 197415976 q10Shape15T157=true := by decide

private def q10Shape15T149 : Tree := .split 15 q10Shape15T150 q10Shape15T157
private theorem q10Shape15T149OK : fastTreeOK (forms 15) 67109456 197415976 q10Shape15T149=true := by
  change (fastTreeOK (forms 15) 67109456 (197415976 ||| 2^15) q10Shape15T150 &&
    fastTreeOK (forms 15) (67109456 ||| 2^15) 197415976 q10Shape15T157)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T150OK,q10Shape15T157OK⟩

private def q10Shape15T147 : Tree := .split 6 q10Shape15T148 q10Shape15T149
private theorem q10Shape15T147OK : fastTreeOK (forms 15) 67109392 197415976 q10Shape15T147=true := by
  change (fastTreeOK (forms 15) 67109392 (197415976 ||| 2^6) q10Shape15T148 &&
    fastTreeOK (forms 15) (67109392 ||| 2^6) 197415976 q10Shape15T149)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T148OK,q10Shape15T149OK⟩

private def q10Shape15T158 : Tree := (.split 11 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 0 1 2 3 9)))
private theorem q10Shape15T158OK : fastTreeOK (forms 15) 67109424 197415944 q10Shape15T158=true := by decide

private def q10Shape15T146 : Tree := .split 5 q10Shape15T147 q10Shape15T158
private theorem q10Shape15T146OK : fastTreeOK (forms 15) 67109392 197415944 q10Shape15T146=true := by
  change (fastTreeOK (forms 15) 67109392 (197415944 ||| 2^5) q10Shape15T147 &&
    fastTreeOK (forms 15) (67109392 ||| 2^5) 197415944 q10Shape15T158)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T147OK,q10Shape15T158OK⟩

private def q10Shape15T138 : Tree := .split 4 q10Shape15T139 q10Shape15T146
private theorem q10Shape15T138OK : fastTreeOK (forms 15) 67109376 197415944 q10Shape15T138=true := by
  change (fastTreeOK (forms 15) 67109376 (197415944 ||| 2^4) q10Shape15T139 &&
    fastTreeOK (forms 15) (67109376 ||| 2^4) 197415944 q10Shape15T146)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T139OK,q10Shape15T146OK⟩

private def q10Shape15T159 : Tree := (.tip (.cover 0 1 3 7 8))
private theorem q10Shape15T159OK : fastTreeOK (forms 15) 67113472 197411848 q10Shape15T159=true := by decide

private def q10Shape15T137 : Tree := .split 12 q10Shape15T138 q10Shape15T159
private theorem q10Shape15T137OK : fastTreeOK (forms 15) 67109376 197411848 q10Shape15T137=true := by
  change (fastTreeOK (forms 15) 67109376 (197411848 ||| 2^12) q10Shape15T138 &&
    fastTreeOK (forms 15) (67109376 ||| 2^12) 197411848 q10Shape15T159)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T138OK,q10Shape15T159OK⟩

private def q10Shape15T160 : Tree := (.tip (.cover 0 1 3 8 9))
private theorem q10Shape15T160OK : fastTreeOK (forms 15) 67110400 197410824 q10Shape15T160=true := by decide

private def q10Shape15T136 : Tree := .split 10 q10Shape15T137 q10Shape15T160
private theorem q10Shape15T136OK : fastTreeOK (forms 15) 67109376 197410824 q10Shape15T136=true := by
  change (fastTreeOK (forms 15) 67109376 (197410824 ||| 2^10) q10Shape15T137 &&
    fastTreeOK (forms 15) (67109376 ||| 2^10) 197410824 q10Shape15T160)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T137OK,q10Shape15T160OK⟩

private def q10Shape15T161 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T161OK : fastTreeOK (forms 15) 67371520 197148680 q10Shape15T161=true := by decide

private def q10Shape15T135 : Tree := .split 18 q10Shape15T136 q10Shape15T161
private theorem q10Shape15T135OK : fastTreeOK (forms 15) 67109376 197148680 q10Shape15T135=true := by
  change (fastTreeOK (forms 15) 67109376 (197148680 ||| 2^18) q10Shape15T136 &&
    fastTreeOK (forms 15) (67109376 ||| 2^18) 197148680 q10Shape15T161)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T136OK,q10Shape15T161OK⟩

private def q10Shape15T162 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T162OK : fastTreeOK (forms 15) 67125760 197132296 q10Shape15T162=true := by decide

private def q10Shape15T134 : Tree := .split 14 q10Shape15T135 q10Shape15T162
private theorem q10Shape15T134OK : fastTreeOK (forms 15) 67109376 197132296 q10Shape15T134=true := by
  change (fastTreeOK (forms 15) 67109376 (197132296 ||| 2^14) q10Shape15T135 &&
    fastTreeOK (forms 15) (67109376 ||| 2^14) 197132296 q10Shape15T162)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T135OK,q10Shape15T162OK⟩

private def q10Shape15T100 : Tree := .split 9 q10Shape15T101 q10Shape15T134
private theorem q10Shape15T100OK : fastTreeOK (forms 15) 67108864 197132296 q10Shape15T100=true := by
  change (fastTreeOK (forms 15) 67108864 (197132296 ||| 2^9) q10Shape15T101 &&
    fastTreeOK (forms 15) (67108864 ||| 2^9) 197132296 q10Shape15T134)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T101OK,q10Shape15T134OK⟩

private def q10Shape15T169 : Tree := (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 10 (.split 15 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 2 3 8 9)))))) (.tip (.cover 3 4 5 6 7))) (.tip (.cover 3 4 5 6 7))) (.tip (.cover 3 4 5 6 7)))
private theorem q10Shape15T169OK : fastTreeOK (forms 15) 67108872 197411440 q10Shape15T169=true := by decide

private def q10Shape15T172 : Tree := (.split 12 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 15 (.split 16 (.tip (.cover 0 1 2 5 9)) (.tip (.cover 3 5 6 8 9))) (.split 20 (.tip (.cover 0 1 2 4 9)) (.tip (.cover 3 4 6 8 9))))))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 9)))
private theorem q10Shape15T172OK : fastTreeOK (forms 15) 67108904 197414480 q10Shape15T172=true := by decide

private def q10Shape15T174 : Tree := (.split 7 (.split 8 (.split 15 (.split 16 (.split 17 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 20 (.split 21 (.tip (.cover 0 1 6 7 8)) (.split 1 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7)))) (.tip (.cover 0 1 2 5 7)))) (.tip (.cover 0 2 3 5 9))) (.tip (.cover 0 2 5 8 9))) (.split 16 (.split 17 (.tip (.cover 0 2 3 5 7)) (.split 19 (.split 20 (.split 21 (.split 2 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 9))) (.tip (.cover 0 2 4 7 8))) (.tip (.cover 0 2 3 4 7)))) (.tip (.cover 0 1 2 4 9)))) (.tip (.cover 4 5 6 7 8))) (.tip (.cover 4 5 6 7 8)))
private theorem q10Shape15T174OK : fastTreeOK (forms 15) 67110952 197416528 q10Shape15T174=true := by decide

private def q10Shape15T175 : Tree := (.tip (.cover 0 1 2 3 7))
private theorem q10Shape15T175OK : fastTreeOK (forms 15) 67115048 197412432 q10Shape15T175=true := by decide

private def q10Shape15T173 : Tree := .split 12 q10Shape15T174 q10Shape15T175
private theorem q10Shape15T173OK : fastTreeOK (forms 15) 67110952 197412432 q10Shape15T173=true := by
  change (fastTreeOK (forms 15) 67110952 (197412432 ||| 2^12) q10Shape15T174 &&
    fastTreeOK (forms 15) (67110952 ||| 2^12) 197412432 q10Shape15T175)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T174OK,q10Shape15T175OK⟩

private def q10Shape15T171 : Tree := .split 11 q10Shape15T172 q10Shape15T173
private theorem q10Shape15T171OK : fastTreeOK (forms 15) 67108904 197412432 q10Shape15T171=true := by
  change (fastTreeOK (forms 15) 67108904 (197412432 ||| 2^11) q10Shape15T172 &&
    fastTreeOK (forms 15) (67108904 ||| 2^11) 197412432 q10Shape15T173)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T172OK,q10Shape15T173OK⟩

private def q10Shape15T176 : Tree := (.split 11 (.split 12 (.tip (.cover 0 2 4 5 7)) (.split 15 (.split 17 (.split 19 (.split 21 (.split 16 (.split 20 (.tip (.drop 7 8 9 (some 6) none (some 6))) (.split 1 (.split 7 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 3 4 6 7 8))) (.tip (.cover 3 4 6 7 8))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7)))) (.split 20 (.split 2 (.split 7 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 3 5 6 7 8))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 3 5 6 7 8))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 7 8)))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 9))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 9)))) (.tip (.cover 0 1 2 3 9)))
private theorem q10Shape15T176OK : fastTreeOK (forms 15) 67109928 197411408 q10Shape15T176=true := by decide

private def q10Shape15T170 : Tree := .split 10 q10Shape15T171 q10Shape15T176
private theorem q10Shape15T170OK : fastTreeOK (forms 15) 67108904 197411408 q10Shape15T170=true := by
  change (fastTreeOK (forms 15) 67108904 (197411408 ||| 2^10) q10Shape15T171 &&
    fastTreeOK (forms 15) (67108904 ||| 2^10) 197411408 q10Shape15T176)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T171OK,q10Shape15T176OK⟩

private def q10Shape15T168 : Tree := .split 5 q10Shape15T169 q10Shape15T170
private theorem q10Shape15T168OK : fastTreeOK (forms 15) 67108872 197411408 q10Shape15T168=true := by
  change (fastTreeOK (forms 15) 67108872 (197411408 ||| 2^5) q10Shape15T169 &&
    fastTreeOK (forms 15) (67108872 ||| 2^5) 197411408 q10Shape15T170)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T169OK,q10Shape15T170OK⟩

private def q10Shape15T177 : Tree := (.tip (.cover 0 1 2 7 8))
private theorem q10Shape15T177OK : fastTreeOK (forms 15) 67108936 197411344 q10Shape15T177=true := by decide

private def q10Shape15T167 : Tree := .split 6 q10Shape15T168 q10Shape15T177
private theorem q10Shape15T167OK : fastTreeOK (forms 15) 67108872 197411344 q10Shape15T167=true := by
  change (fastTreeOK (forms 15) 67108872 (197411344 ||| 2^6) q10Shape15T168 &&
    fastTreeOK (forms 15) (67108872 ||| 2^6) 197411344 q10Shape15T177)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T168OK,q10Shape15T177OK⟩

private def q10Shape15T178 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape15T178OK : fastTreeOK (forms 15) 67108888 197411328 q10Shape15T178=true := by decide

private def q10Shape15T166 : Tree := .split 4 q10Shape15T167 q10Shape15T178
private theorem q10Shape15T166OK : fastTreeOK (forms 15) 67108872 197411328 q10Shape15T166=true := by
  change (fastTreeOK (forms 15) 67108872 (197411328 ||| 2^4) q10Shape15T167 &&
    fastTreeOK (forms 15) (67108872 ||| 2^4) 197411328 q10Shape15T178)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T167OK,q10Shape15T178OK⟩

private def q10Shape15T179 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T179OK : fastTreeOK (forms 15) 67371016 197149184 q10Shape15T179=true := by decide

private def q10Shape15T165 : Tree := .split 18 q10Shape15T166 q10Shape15T179
private theorem q10Shape15T165OK : fastTreeOK (forms 15) 67108872 197149184 q10Shape15T165=true := by
  change (fastTreeOK (forms 15) 67108872 (197149184 ||| 2^18) q10Shape15T166 &&
    fastTreeOK (forms 15) (67108872 ||| 2^18) 197149184 q10Shape15T179)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T166OK,q10Shape15T179OK⟩

private def q10Shape15T180 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T180OK : fastTreeOK (forms 15) 67125256 197132800 q10Shape15T180=true := by decide

private def q10Shape15T164 : Tree := .split 14 q10Shape15T165 q10Shape15T180
private theorem q10Shape15T164OK : fastTreeOK (forms 15) 67108872 197132800 q10Shape15T164=true := by
  change (fastTreeOK (forms 15) 67108872 (197132800 ||| 2^14) q10Shape15T165 &&
    fastTreeOK (forms 15) (67108872 ||| 2^14) 197132800 q10Shape15T180)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T165OK,q10Shape15T180OK⟩

private def q10Shape15T181 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T181OK : fastTreeOK (forms 15) 67109384 197132288 q10Shape15T181=true := by decide

private def q10Shape15T163 : Tree := .split 9 q10Shape15T164 q10Shape15T181
private theorem q10Shape15T163OK : fastTreeOK (forms 15) 67108872 197132288 q10Shape15T163=true := by
  change (fastTreeOK (forms 15) 67108872 (197132288 ||| 2^9) q10Shape15T164 &&
    fastTreeOK (forms 15) (67108872 ||| 2^9) 197132288 q10Shape15T181)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T164OK,q10Shape15T181OK⟩

private def q10Shape15T99 : Tree := .split 3 q10Shape15T100 q10Shape15T163
private theorem q10Shape15T99OK : fastTreeOK (forms 15) 67108864 197132288 q10Shape15T99=true := by
  change (fastTreeOK (forms 15) 67108864 (197132288 ||| 2^3) q10Shape15T100 &&
    fastTreeOK (forms 15) (67108864 ||| 2^3) 197132288 q10Shape15T163)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T100OK,q10Shape15T163OK⟩

private def q10Shape15T182 : Tree := (.tip (.cover 0 1 6 7 8))
private theorem q10Shape15T182OK : fastTreeOK (forms 15) 201326592 62914560 q10Shape15T182=true := by decide

private def q10Shape15T98 : Tree := .split 27 q10Shape15T99 q10Shape15T182
private theorem q10Shape15T98OK : fastTreeOK (forms 15) 67108864 62914560 q10Shape15T98=true := by
  change (fastTreeOK (forms 15) 67108864 (62914560 ||| 2^27) q10Shape15T99 &&
    fastTreeOK (forms 15) (67108864 ||| 2^27) 62914560 q10Shape15T182)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T99OK,q10Shape15T182OK⟩

private def q10Shape15T4 : Tree := .split 26 q10Shape15T5 q10Shape15T98
private theorem q10Shape15T4OK : fastTreeOK (forms 15) 0 62914560 q10Shape15T4=true := by
  change (fastTreeOK (forms 15) 0 (62914560 ||| 2^26) q10Shape15T5 &&
    fastTreeOK (forms 15) (0 ||| 2^26) 62914560 q10Shape15T98)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T5OK,q10Shape15T98OK⟩

private def q10Shape15T189 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape15T189OK : fastTreeOK (forms 15) 33554432 230965768 q10Shape15T189=true := by decide

private def q10Shape15T195 : Tree := (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 21 (.tip (.cover 2 3 4 6 7)) (.split 10 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 2 4 6 8 9))) (.split 17 (.tip (.cover 0 1 3 5 8)) (.tip (.cover 2 3 6 8 9)))))))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7)))
private theorem q10Shape15T195OK : fastTreeOK (forms 15) 33816576 232276600 q10Shape15T195=true := by decide

private def q10Shape15T196 : Tree := (.split 10 (.split 11 (.split 12 (.split 15 (.tip (.cover 0 1 6 8 9)) (.split 16 (.tip (.cover 0 1 6 7 9)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 8 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))))) (.tip (.cover 0 4 5 7 9))) (.tip (.cover 0 4 5 8 9))) (.split 11 (.tip (.cover 0 4 5 7 9)) (.split 15 (.split 16 (.split 17 (.split 1 (.split 7 (.split 13 (.tip (.drop 6 7 8 (some 4) (some 4) (some 4))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 3 5 8 9))) (.tip (.cover 0 3 5 7 9)))))
private theorem q10Shape15T196OK : fastTreeOK (forms 15) 33816640 232276536 q10Shape15T196=true := by decide

private def q10Shape15T194 : Tree := .split 6 q10Shape15T195 q10Shape15T196
private theorem q10Shape15T194OK : fastTreeOK (forms 15) 33816576 232276536 q10Shape15T194=true := by
  change (fastTreeOK (forms 15) 33816576 (232276536 ||| 2^6) q10Shape15T195 &&
    fastTreeOK (forms 15) (33816576 ||| 2^6) 232276536 q10Shape15T196)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T195OK,q10Shape15T196OK⟩

private def q10Shape15T197 : Tree := (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 21 (.split 2 (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 7 9)))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 0 1 2 5 7))))
private theorem q10Shape15T197OK : fastTreeOK (forms 15) 33816608 232276504 q10Shape15T197=true := by decide

private def q10Shape15T193 : Tree := .split 5 q10Shape15T194 q10Shape15T197
private theorem q10Shape15T193OK : fastTreeOK (forms 15) 33816576 232276504 q10Shape15T193=true := by
  change (fastTreeOK (forms 15) 33816576 (232276504 ||| 2^5) q10Shape15T194 &&
    fastTreeOK (forms 15) (33816576 ||| 2^5) 232276504 q10Shape15T197)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T194OK,q10Shape15T197OK⟩

private def q10Shape15T199 : Tree := (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 21 (.split 2 (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 8 9)))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 0 1 2 5 8))))
private theorem q10Shape15T199OK : fastTreeOK (forms 15) 33816592 232276520 q10Shape15T199=true := by decide

private def q10Shape15T201 : Tree := (.split 10 (.split 11 (.split 15 (.split 16 (.split 12 (.split 17 (.tip (.drop 7 8 9 (some 6) (some 6) none)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 8 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7)))) (.split 17 (.split 1 (.split 7 (.split 13 (.tip (.drop 6 7 8 (some 4) (some 4) (some 4))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 5 7 9)))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 8)))
private theorem q10Shape15T201OK : fastTreeOK (forms 15) 33816624 232276552 q10Shape15T201=true := by decide

private def q10Shape15T202 : Tree := (.split 21 (.split 2 (.split 8 (.split 13 (.split 0 (.tip (.small 1)) (.split 1 (.tip (.small 1)) (.tip (.cover 0 2 5 7 9)))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 2 3 4 6 7))) (.tip (.cover 0 1 2 5 7)))
private theorem q10Shape15T202OK : fastTreeOK (forms 15) 33816688 232276488 q10Shape15T202=true := by decide

private def q10Shape15T200 : Tree := .split 6 q10Shape15T201 q10Shape15T202
private theorem q10Shape15T200OK : fastTreeOK (forms 15) 33816624 232276488 q10Shape15T200=true := by
  change (fastTreeOK (forms 15) 33816624 (232276488 ||| 2^6) q10Shape15T201 &&
    fastTreeOK (forms 15) (33816624 ||| 2^6) 232276488 q10Shape15T202)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T201OK,q10Shape15T202OK⟩

private def q10Shape15T198 : Tree := .split 5 q10Shape15T199 q10Shape15T200
private theorem q10Shape15T198OK : fastTreeOK (forms 15) 33816592 232276488 q10Shape15T198=true := by
  change (fastTreeOK (forms 15) 33816592 (232276488 ||| 2^5) q10Shape15T199 &&
    fastTreeOK (forms 15) (33816592 ||| 2^5) 232276488 q10Shape15T200)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T199OK,q10Shape15T200OK⟩

private def q10Shape15T192 : Tree := .split 4 q10Shape15T193 q10Shape15T198
private theorem q10Shape15T192OK : fastTreeOK (forms 15) 33816576 232276488 q10Shape15T192=true := by
  change (fastTreeOK (forms 15) 33816576 (232276488 ||| 2^4) q10Shape15T193 &&
    fastTreeOK (forms 15) (33816576 ||| 2^4) 232276488 q10Shape15T198)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T193OK,q10Shape15T198OK⟩

private def q10Shape15T203 : Tree := (.tip (.cover 0 1 5 7 9))
private theorem q10Shape15T203OK : fastTreeOK (forms 15) 34865152 231227912 q10Shape15T203=true := by decide

private def q10Shape15T191 : Tree := .split 20 q10Shape15T192 q10Shape15T203
private theorem q10Shape15T191OK : fastTreeOK (forms 15) 33816576 231227912 q10Shape15T191=true := by
  change (fastTreeOK (forms 15) 33816576 (231227912 ||| 2^20) q10Shape15T192 &&
    fastTreeOK (forms 15) (33816576 ||| 2^20) 231227912 q10Shape15T203)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T192OK,q10Shape15T203OK⟩

private def q10Shape15T204 : Tree := (.tip (.cover 0 1 5 8 9))
private theorem q10Shape15T204OK : fastTreeOK (forms 15) 34340864 230703624 q10Shape15T204=true := by decide

private def q10Shape15T190 : Tree := .split 19 q10Shape15T191 q10Shape15T204
private theorem q10Shape15T190OK : fastTreeOK (forms 15) 33816576 230703624 q10Shape15T190=true := by
  change (fastTreeOK (forms 15) 33816576 (230703624 ||| 2^19) q10Shape15T191 &&
    fastTreeOK (forms 15) (33816576 ||| 2^19) 230703624 q10Shape15T204)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T191OK,q10Shape15T204OK⟩

private def q10Shape15T188 : Tree := .split 18 q10Shape15T189 q10Shape15T190
private theorem q10Shape15T188OK : fastTreeOK (forms 15) 33554432 230703624 q10Shape15T188=true := by
  change (fastTreeOK (forms 15) 33554432 (230703624 ||| 2^18) q10Shape15T189 &&
    fastTreeOK (forms 15) (33554432 ||| 2^18) 230703624 q10Shape15T190)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T189OK,q10Shape15T190OK⟩

private def q10Shape15T211 : Tree := (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 17 (.tip (.cover 2 3 5 6 7)) (.split 10 (.split 12 (.tip (.cover 0 1 4 5 8)) (.tip (.cover 2 5 6 8 9))) (.split 21 (.tip (.cover 0 1 3 4 8)) (.tip (.cover 2 3 6 8 9)))))))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7)))
private theorem q10Shape15T211OK : fastTreeOK (forms 15) 33570816 231047800 q10Shape15T211=true := by decide

private def q10Shape15T212 : Tree := (.split 10 (.split 11 (.split 12 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 8 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))))) (.tip (.cover 0 4 5 7 9))) (.tip (.cover 0 4 5 8 9))) (.split 11 (.tip (.cover 0 4 5 7 9)) (.split 19 (.split 20 (.split 21 (.split 2 (.split 8 (.split 13 (.tip (.drop 6 7 8 (some 5) (some 5) (some 5))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 3 4 8 9))) (.tip (.cover 0 3 4 7 9)))))
private theorem q10Shape15T212OK : fastTreeOK (forms 15) 33570880 231047736 q10Shape15T212=true := by decide

private def q10Shape15T210 : Tree := .split 6 q10Shape15T211 q10Shape15T212
private theorem q10Shape15T210OK : fastTreeOK (forms 15) 33570816 231047736 q10Shape15T210=true := by
  change (fastTreeOK (forms 15) 33570816 (231047736 ||| 2^6) q10Shape15T211 &&
    fastTreeOK (forms 15) (33570816 ||| 2^6) 231047736 q10Shape15T212)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T211OK,q10Shape15T212OK⟩

private def q10Shape15T213 : Tree := (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 17 (.split 1 (.split 7 (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 0 1 2 4 7))))
private theorem q10Shape15T213OK : fastTreeOK (forms 15) 33570848 231047704 q10Shape15T213=true := by decide

private def q10Shape15T209 : Tree := .split 5 q10Shape15T210 q10Shape15T213
private theorem q10Shape15T209OK : fastTreeOK (forms 15) 33570816 231047704 q10Shape15T209=true := by
  change (fastTreeOK (forms 15) 33570816 (231047704 ||| 2^5) q10Shape15T210 &&
    fastTreeOK (forms 15) (33570816 ||| 2^5) 231047704 q10Shape15T213)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T210OK,q10Shape15T213OK⟩

private def q10Shape15T215 : Tree := (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 17 (.split 1 (.split 7 (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 8 9)))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 0 1 2 4 8))))
private theorem q10Shape15T215OK : fastTreeOK (forms 15) 33570832 231047720 q10Shape15T215=true := by decide

private def q10Shape15T217 : Tree := (.split 10 (.split 11 (.split 19 (.split 20 (.split 12 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) none)) (.split 0 (.split 7 (.split 8 (.tip (.drop 6 7 8 (some 3) (some 3) (some 3))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7)))) (.split 21 (.split 2 (.split 8 (.split 13 (.tip (.drop 6 7 8 (some 5) (some 5) (some 5))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 8))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 8)))
private theorem q10Shape15T217OK : fastTreeOK (forms 15) 33570864 231047752 q10Shape15T217=true := by decide

private def q10Shape15T218 : Tree := (.split 17 (.split 1 (.split 7 (.split 13 (.split 0 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 4 7 9)))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 2 3 5 6 7))) (.tip (.cover 0 1 2 4 7)))
private theorem q10Shape15T218OK : fastTreeOK (forms 15) 33570928 231047688 q10Shape15T218=true := by decide

private def q10Shape15T216 : Tree := .split 6 q10Shape15T217 q10Shape15T218
private theorem q10Shape15T216OK : fastTreeOK (forms 15) 33570864 231047688 q10Shape15T216=true := by
  change (fastTreeOK (forms 15) 33570864 (231047688 ||| 2^6) q10Shape15T217 &&
    fastTreeOK (forms 15) (33570864 ||| 2^6) 231047688 q10Shape15T218)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T217OK,q10Shape15T218OK⟩

private def q10Shape15T214 : Tree := .split 5 q10Shape15T215 q10Shape15T216
private theorem q10Shape15T214OK : fastTreeOK (forms 15) 33570832 231047688 q10Shape15T214=true := by
  change (fastTreeOK (forms 15) 33570832 (231047688 ||| 2^5) q10Shape15T215 &&
    fastTreeOK (forms 15) (33570832 ||| 2^5) 231047688 q10Shape15T216)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T215OK,q10Shape15T216OK⟩

private def q10Shape15T208 : Tree := .split 4 q10Shape15T209 q10Shape15T214
private theorem q10Shape15T208OK : fastTreeOK (forms 15) 33570816 231047688 q10Shape15T208=true := by
  change (fastTreeOK (forms 15) 33570816 (231047688 ||| 2^4) q10Shape15T209 &&
    fastTreeOK (forms 15) (33570816 ||| 2^4) 231047688 q10Shape15T214)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T209OK,q10Shape15T214OK⟩

private def q10Shape15T219 : Tree := (.tip (.cover 0 1 4 7 9))
private theorem q10Shape15T219OK : fastTreeOK (forms 15) 33636352 230982152 q10Shape15T219=true := by decide

private def q10Shape15T207 : Tree := .split 16 q10Shape15T208 q10Shape15T219
private theorem q10Shape15T207OK : fastTreeOK (forms 15) 33570816 230982152 q10Shape15T207=true := by
  change (fastTreeOK (forms 15) 33570816 (230982152 ||| 2^16) q10Shape15T208 &&
    fastTreeOK (forms 15) (33570816 ||| 2^16) 230982152 q10Shape15T219)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T208OK,q10Shape15T219OK⟩

private def q10Shape15T220 : Tree := (.tip (.cover 0 1 4 8 9))
private theorem q10Shape15T220OK : fastTreeOK (forms 15) 33603584 230949384 q10Shape15T220=true := by decide

private def q10Shape15T206 : Tree := .split 15 q10Shape15T207 q10Shape15T220
private theorem q10Shape15T206OK : fastTreeOK (forms 15) 33570816 230949384 q10Shape15T206=true := by
  change (fastTreeOK (forms 15) 33570816 (230949384 ||| 2^15) q10Shape15T207 &&
    fastTreeOK (forms 15) (33570816 ||| 2^15) 230949384 q10Shape15T220)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T207OK,q10Shape15T220OK⟩

private def q10Shape15T221 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T221OK : fastTreeOK (forms 15) 33832960 230687240 q10Shape15T221=true := by decide

private def q10Shape15T205 : Tree := .split 18 q10Shape15T206 q10Shape15T221
private theorem q10Shape15T205OK : fastTreeOK (forms 15) 33570816 230687240 q10Shape15T205=true := by
  change (fastTreeOK (forms 15) 33570816 (230687240 ||| 2^18) q10Shape15T206 &&
    fastTreeOK (forms 15) (33570816 ||| 2^18) 230687240 q10Shape15T221)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T206OK,q10Shape15T221OK⟩

private def q10Shape15T187 : Tree := .split 14 q10Shape15T188 q10Shape15T205
private theorem q10Shape15T187OK : fastTreeOK (forms 15) 33554432 230687240 q10Shape15T187=true := by
  change (fastTreeOK (forms 15) 33554432 (230687240 ||| 2^14) q10Shape15T188 &&
    fastTreeOK (forms 15) (33554432 ||| 2^14) 230687240 q10Shape15T205)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T188OK,q10Shape15T205OK⟩

private def q10Shape15T229 : Tree := (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 12 (.tip (.cover 2 4 5 6 7)) (.split 15 (.split 17 (.tip (.cover 0 1 3 5 8)) (.tip (.cover 2 5 6 8 9))) (.split 21 (.tip (.cover 0 1 3 4 8)) (.tip (.cover 2 4 6 8 9)))))))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7))) (.tip (.cover 0 3 4 5 7)))
private theorem q10Shape15T229OK : fastTreeOK (forms 15) 33554944 230968440 q10Shape15T229=true := by decide

private def q10Shape15T231 : Tree := (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 15 (.tip (.cover 0 3 5 8 9)) (.tip (.cover 0 3 4 8 9)))))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7)))
private theorem q10Shape15T231OK : fastTreeOK (forms 15) 33555008 230972472 q10Shape15T231=true := by decide

private def q10Shape15T232 : Tree := (.split 1 (.split 2 (.split 15 (.split 16 (.split 17 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 7 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 1 3 5 7))))) (.tip (.cover 0 3 5 7 9))) (.tip (.cover 0 2 3 5 8))) (.split 16 (.tip (.cover 0 2 3 5 7)) (.split 17 (.split 19 (.split 20 (.split 21 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 3 4 7 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 1 3 4 7))))) (.tip (.cover 4 5 6 7 9))) (.tip (.cover 4 5 6 7 9)))
private theorem q10Shape15T232OK : fastTreeOK (forms 15) 33559104 230968376 q10Shape15T232=true := by decide

private def q10Shape15T230 : Tree := .split 12 q10Shape15T231 q10Shape15T232
private theorem q10Shape15T230OK : fastTreeOK (forms 15) 33555008 230968376 q10Shape15T230=true := by
  change (fastTreeOK (forms 15) 33555008 (230968376 ||| 2^12) q10Shape15T231 &&
    fastTreeOK (forms 15) (33555008 ||| 2^12) 230968376 q10Shape15T232)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T231OK,q10Shape15T232OK⟩

private def q10Shape15T228 : Tree := .split 6 q10Shape15T229 q10Shape15T230
private theorem q10Shape15T228OK : fastTreeOK (forms 15) 33554944 230968376 q10Shape15T228=true := by
  change (fastTreeOK (forms 15) 33554944 (230968376 ||| 2^6) q10Shape15T229 &&
    fastTreeOK (forms 15) (33554944 ||| 2^6) 230968376 q10Shape15T230)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T229OK,q10Shape15T230OK⟩

private def q10Shape15T233 : Tree := (.split 6 (.tip (.cover 0 3 4 5 8)) (.split 12 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 0 1 2 3 7))))
private theorem q10Shape15T233OK : fastTreeOK (forms 15) 33554976 230968344 q10Shape15T233=true := by decide

private def q10Shape15T227 : Tree := .split 5 q10Shape15T228 q10Shape15T233
private theorem q10Shape15T227OK : fastTreeOK (forms 15) 33554944 230968344 q10Shape15T227=true := by
  change (fastTreeOK (forms 15) 33554944 (230968344 ||| 2^5) q10Shape15T228 &&
    fastTreeOK (forms 15) (33554944 ||| 2^5) 230968344 q10Shape15T233)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T228OK,q10Shape15T233OK⟩

private def q10Shape15T235 : Tree := (.split 6 (.tip (.cover 0 3 4 5 7)) (.split 12 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 8 9)))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 0 1 2 3 8))))
private theorem q10Shape15T235OK : fastTreeOK (forms 15) 33554960 230968360 q10Shape15T235=true := by decide

private def q10Shape15T241 : Tree := (.split 12 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.split 17 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) none)) (.split 1 (.split 2 (.split 7 (.split 13 (.tip (.small 1)) (.tip (.cover 2 4 6 7 9))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 2 4 6 7 9))) (.tip (.cover 0 2 3 5 7)))) (.split 21 (.split 1 (.split 2 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 2 5 6 7 9))) (.tip (.cover 0 2 3 7 9)))))
private theorem q10Shape15T241OK : fastTreeOK (forms 15) 33554992 232639560 q10Shape15T241=true := by decide

private def q10Shape15T242 : Tree := (.tip (.cover 0 3 4 5 7))
private theorem q10Shape15T242OK : fastTreeOK (forms 15) 34603568 231590984 q10Shape15T242=true := by decide

private def q10Shape15T240 : Tree := .split 20 q10Shape15T241 q10Shape15T242
private theorem q10Shape15T240OK : fastTreeOK (forms 15) 33554992 231590984 q10Shape15T240=true := by
  change (fastTreeOK (forms 15) 33554992 (231590984 ||| 2^20) q10Shape15T241 &&
    fastTreeOK (forms 15) (33554992 ||| 2^20) 231590984 q10Shape15T242)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T241OK,q10Shape15T242OK⟩

private def q10Shape15T243 : Tree := (.tip (.cover 0 3 4 5 8))
private theorem q10Shape15T243OK : fastTreeOK (forms 15) 34079280 231066696 q10Shape15T243=true := by decide

private def q10Shape15T239 : Tree := .split 19 q10Shape15T240 q10Shape15T243
private theorem q10Shape15T239OK : fastTreeOK (forms 15) 33554992 231066696 q10Shape15T239=true := by
  change (fastTreeOK (forms 15) 33554992 (231066696 ||| 2^19) q10Shape15T240 &&
    fastTreeOK (forms 15) (33554992 ||| 2^19) 231066696 q10Shape15T243)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T240OK,q10Shape15T243OK⟩

private def q10Shape15T244 : Tree := (.tip (.cover 0 3 4 5 7))
private theorem q10Shape15T244OK : fastTreeOK (forms 15) 33620528 231001160 q10Shape15T244=true := by decide

private def q10Shape15T238 : Tree := .split 16 q10Shape15T239 q10Shape15T244
private theorem q10Shape15T238OK : fastTreeOK (forms 15) 33554992 231001160 q10Shape15T238=true := by
  change (fastTreeOK (forms 15) 33554992 (231001160 ||| 2^16) q10Shape15T239 &&
    fastTreeOK (forms 15) (33554992 ||| 2^16) 231001160 q10Shape15T244)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T239OK,q10Shape15T244OK⟩

private def q10Shape15T245 : Tree := (.tip (.cover 0 3 4 5 8))
private theorem q10Shape15T245OK : fastTreeOK (forms 15) 33587760 230968392 q10Shape15T245=true := by decide

private def q10Shape15T237 : Tree := .split 15 q10Shape15T238 q10Shape15T245
private theorem q10Shape15T237OK : fastTreeOK (forms 15) 33554992 230968392 q10Shape15T237=true := by
  change (fastTreeOK (forms 15) 33554992 (230968392 ||| 2^15) q10Shape15T238 &&
    fastTreeOK (forms 15) (33554992 ||| 2^15) 230968392 q10Shape15T245)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T238OK,q10Shape15T245OK⟩

private def q10Shape15T246 : Tree := (.split 12 (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 2 4 5 6 7))) (.tip (.cover 0 1 2 3 7)))
private theorem q10Shape15T246OK : fastTreeOK (forms 15) 33555056 230968328 q10Shape15T246=true := by decide

private def q10Shape15T236 : Tree := .split 6 q10Shape15T237 q10Shape15T246
private theorem q10Shape15T236OK : fastTreeOK (forms 15) 33554992 230968328 q10Shape15T236=true := by
  change (fastTreeOK (forms 15) 33554992 (230968328 ||| 2^6) q10Shape15T237 &&
    fastTreeOK (forms 15) (33554992 ||| 2^6) 230968328 q10Shape15T246)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T237OK,q10Shape15T246OK⟩

private def q10Shape15T234 : Tree := .split 5 q10Shape15T235 q10Shape15T236
private theorem q10Shape15T234OK : fastTreeOK (forms 15) 33554960 230968328 q10Shape15T234=true := by
  change (fastTreeOK (forms 15) 33554960 (230968328 ||| 2^5) q10Shape15T235 &&
    fastTreeOK (forms 15) (33554960 ||| 2^5) 230968328 q10Shape15T236)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T235OK,q10Shape15T236OK⟩

private def q10Shape15T226 : Tree := .split 4 q10Shape15T227 q10Shape15T234
private theorem q10Shape15T226OK : fastTreeOK (forms 15) 33554944 230968328 q10Shape15T226=true := by
  change (fastTreeOK (forms 15) 33554944 (230968328 ||| 2^4) q10Shape15T227 &&
    fastTreeOK (forms 15) (33554944 ||| 2^4) 230968328 q10Shape15T234)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T227OK,q10Shape15T234OK⟩

private def q10Shape15T247 : Tree := (.tip (.cover 0 1 3 7 9))
private theorem q10Shape15T247OK : fastTreeOK (forms 15) 33556992 230966280 q10Shape15T247=true := by decide

private def q10Shape15T225 : Tree := .split 11 q10Shape15T226 q10Shape15T247
private theorem q10Shape15T225OK : fastTreeOK (forms 15) 33554944 230966280 q10Shape15T225=true := by
  change (fastTreeOK (forms 15) 33554944 (230966280 ||| 2^11) q10Shape15T226 &&
    fastTreeOK (forms 15) (33554944 ||| 2^11) 230966280 q10Shape15T247)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T226OK,q10Shape15T247OK⟩

private def q10Shape15T248 : Tree := (.tip (.cover 0 1 3 8 9))
private theorem q10Shape15T248OK : fastTreeOK (forms 15) 33555968 230965256 q10Shape15T248=true := by decide

private def q10Shape15T224 : Tree := .split 10 q10Shape15T225 q10Shape15T248
private theorem q10Shape15T224OK : fastTreeOK (forms 15) 33554944 230965256 q10Shape15T224=true := by
  change (fastTreeOK (forms 15) 33554944 (230965256 ||| 2^10) q10Shape15T225 &&
    fastTreeOK (forms 15) (33554944 ||| 2^10) 230965256 q10Shape15T248)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T225OK,q10Shape15T248OK⟩

private def q10Shape15T249 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T249OK : fastTreeOK (forms 15) 33817088 230703112 q10Shape15T249=true := by decide

private def q10Shape15T223 : Tree := .split 18 q10Shape15T224 q10Shape15T249
private theorem q10Shape15T223OK : fastTreeOK (forms 15) 33554944 230703112 q10Shape15T223=true := by
  change (fastTreeOK (forms 15) 33554944 (230703112 ||| 2^18) q10Shape15T224 &&
    fastTreeOK (forms 15) (33554944 ||| 2^18) 230703112 q10Shape15T249)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T224OK,q10Shape15T249OK⟩

private def q10Shape15T250 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T250OK : fastTreeOK (forms 15) 33571328 230686728 q10Shape15T250=true := by decide

private def q10Shape15T222 : Tree := .split 14 q10Shape15T223 q10Shape15T250
private theorem q10Shape15T222OK : fastTreeOK (forms 15) 33554944 230686728 q10Shape15T222=true := by
  change (fastTreeOK (forms 15) 33554944 (230686728 ||| 2^14) q10Shape15T223 &&
    fastTreeOK (forms 15) (33554944 ||| 2^14) 230686728 q10Shape15T250)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T223OK,q10Shape15T250OK⟩

private def q10Shape15T186 : Tree := .split 9 q10Shape15T187 q10Shape15T222
private theorem q10Shape15T186OK : fastTreeOK (forms 15) 33554432 230686728 q10Shape15T186=true := by
  change (fastTreeOK (forms 15) 33554432 (230686728 ||| 2^9) q10Shape15T187 &&
    fastTreeOK (forms 15) (33554432 ||| 2^9) 230686728 q10Shape15T222)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T187OK,q10Shape15T222OK⟩

private def q10Shape15T257 : Tree := (.split 0 (.split 1 (.split 2 (.split 7 (.tip (.small 1)) (.split 8 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 10 (.split 15 (.tip (.cover 0 2 5 8 9)) (.tip (.cover 0 2 4 8 9))) (.tip (.cover 0 2 3 8 9)))))) (.tip (.cover 3 4 5 6 7))) (.tip (.cover 3 4 5 6 7))) (.tip (.cover 3 4 5 6 7)))
private theorem q10Shape15T257OK : fastTreeOK (forms 15) 33554440 230965872 q10Shape15T257=true := by decide

private def q10Shape15T261 : Tree := (.split 0 (.split 7 (.split 8 (.split 1 (.tip (.small 1)) (.split 2 (.tip (.small 1)) (.split 13 (.tip (.small 1)) (.split 15 (.split 17 (.tip (.cover 0 1 2 5 8)) (.tip (.cover 3 5 6 8 9))) (.split 21 (.tip (.cover 0 1 2 4 8)) (.tip (.cover 3 4 6 8 9))))))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 7)))
private theorem q10Shape15T261OK : fastTreeOK (forms 15) 33554504 230972976 q10Shape15T261=true := by decide

private def q10Shape15T262 : Tree := (.split 7 (.split 8 (.split 15 (.split 16 (.split 17 (.split 19 (.tip (.cover 0 1 6 8 9)) (.split 20 (.tip (.cover 0 1 6 7 9)) (.split 21 (.split 1 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 1 2 5 7))))) (.tip (.cover 0 2 5 7 9))) (.tip (.cover 0 2 3 5 8))) (.split 16 (.tip (.cover 0 2 3 5 7)) (.split 17 (.split 19 (.split 20 (.split 21 (.split 2 (.split 13 (.tip (.small 1)) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 4 7 9))) (.tip (.cover 0 2 3 4 8))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 1 2 4 7))))) (.tip (.cover 4 5 6 7 9))) (.tip (.cover 4 5 6 7 9)))
private theorem q10Shape15T262OK : fastTreeOK (forms 15) 33558600 230968880 q10Shape15T262=true := by decide

private def q10Shape15T260 : Tree := .split 12 q10Shape15T261 q10Shape15T262
private theorem q10Shape15T260OK : fastTreeOK (forms 15) 33554504 230968880 q10Shape15T260=true := by
  change (fastTreeOK (forms 15) 33554504 (230968880 ||| 2^12) q10Shape15T261 &&
    fastTreeOK (forms 15) (33554504 ||| 2^12) 230968880 q10Shape15T262)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T261OK,q10Shape15T262OK⟩

private def q10Shape15T263 : Tree := (.split 12 (.tip (.cover 0 2 4 5 8)) (.tip (.cover 0 1 2 3 7)))
private theorem q10Shape15T263OK : fastTreeOK (forms 15) 33556552 230966832 q10Shape15T263=true := by decide

private def q10Shape15T259 : Tree := .split 11 q10Shape15T260 q10Shape15T263
private theorem q10Shape15T259OK : fastTreeOK (forms 15) 33554504 230966832 q10Shape15T259=true := by
  change (fastTreeOK (forms 15) 33554504 (230966832 ||| 2^11) q10Shape15T260 &&
    fastTreeOK (forms 15) (33554504 ||| 2^11) 230966832 q10Shape15T263)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T260OK,q10Shape15T263OK⟩

private def q10Shape15T264 : Tree := (.split 12 (.split 11 (.tip (.cover 0 2 4 5 7)) (.split 15 (.split 16 (.split 19 (.split 20 (.split 17 (.split 21 (.tip (.drop 7 8 9 (some 6) (some 6) none)) (.split 1 (.split 7 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 3 4 6 7 9))) (.tip (.cover 3 4 6 7 9))) (.tip (.cover 0 2 3 5 7))) (.tip (.cover 0 2 3 5 7)))) (.split 21 (.split 2 (.split 7 (.split 8 (.split 13 (.tip (.small 1)) (.tip (.cover 3 5 6 7 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 3 5 6 7 9))) (.tip (.cover 0 2 3 4 7))) (.tip (.cover 0 2 3 7 9)))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 8))) (.tip (.cover 0 2 4 5 7))) (.tip (.cover 0 2 4 5 8)))) (.tip (.cover 0 1 2 3 8)))
private theorem q10Shape15T264OK : fastTreeOK (forms 15) 33555528 230965808 q10Shape15T264=true := by decide

private def q10Shape15T258 : Tree := .split 10 q10Shape15T259 q10Shape15T264
private theorem q10Shape15T258OK : fastTreeOK (forms 15) 33554504 230965808 q10Shape15T258=true := by
  change (fastTreeOK (forms 15) 33554504 (230965808 ||| 2^10) q10Shape15T259 &&
    fastTreeOK (forms 15) (33554504 ||| 2^10) 230965808 q10Shape15T264)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T259OK,q10Shape15T264OK⟩

private def q10Shape15T256 : Tree := .split 6 q10Shape15T257 q10Shape15T258
private theorem q10Shape15T256OK : fastTreeOK (forms 15) 33554440 230965808 q10Shape15T256=true := by
  change (fastTreeOK (forms 15) 33554440 (230965808 ||| 2^6) q10Shape15T257 &&
    fastTreeOK (forms 15) (33554440 ||| 2^6) 230965808 q10Shape15T258)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T257OK,q10Shape15T258OK⟩

private def q10Shape15T265 : Tree := (.tip (.cover 0 1 2 7 9))
private theorem q10Shape15T265OK : fastTreeOK (forms 15) 33554472 230965776 q10Shape15T265=true := by decide

private def q10Shape15T255 : Tree := .split 5 q10Shape15T256 q10Shape15T265
private theorem q10Shape15T255OK : fastTreeOK (forms 15) 33554440 230965776 q10Shape15T255=true := by
  change (fastTreeOK (forms 15) 33554440 (230965776 ||| 2^5) q10Shape15T256 &&
    fastTreeOK (forms 15) (33554440 ||| 2^5) 230965776 q10Shape15T265)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T256OK,q10Shape15T265OK⟩

private def q10Shape15T266 : Tree := (.tip (.cover 0 1 2 8 9))
private theorem q10Shape15T266OK : fastTreeOK (forms 15) 33554456 230965760 q10Shape15T266=true := by decide

private def q10Shape15T254 : Tree := .split 4 q10Shape15T255 q10Shape15T266
private theorem q10Shape15T254OK : fastTreeOK (forms 15) 33554440 230965760 q10Shape15T254=true := by
  change (fastTreeOK (forms 15) 33554440 (230965760 ||| 2^4) q10Shape15T255 &&
    fastTreeOK (forms 15) (33554440 ||| 2^4) 230965760 q10Shape15T266)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T255OK,q10Shape15T266OK⟩

private def q10Shape15T267 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T267OK : fastTreeOK (forms 15) 33816584 230703616 q10Shape15T267=true := by decide

private def q10Shape15T253 : Tree := .split 18 q10Shape15T254 q10Shape15T267
private theorem q10Shape15T253OK : fastTreeOK (forms 15) 33554440 230703616 q10Shape15T253=true := by
  change (fastTreeOK (forms 15) 33554440 (230703616 ||| 2^18) q10Shape15T254 &&
    fastTreeOK (forms 15) (33554440 ||| 2^18) 230703616 q10Shape15T267)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T254OK,q10Shape15T267OK⟩

private def q10Shape15T268 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T268OK : fastTreeOK (forms 15) 33570824 230687232 q10Shape15T268=true := by decide

private def q10Shape15T252 : Tree := .split 14 q10Shape15T253 q10Shape15T268
private theorem q10Shape15T252OK : fastTreeOK (forms 15) 33554440 230687232 q10Shape15T252=true := by
  change (fastTreeOK (forms 15) 33554440 (230687232 ||| 2^14) q10Shape15T253 &&
    fastTreeOK (forms 15) (33554440 ||| 2^14) 230687232 q10Shape15T268)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T253OK,q10Shape15T268OK⟩

private def q10Shape15T269 : Tree := (.tip (.cover 2 3 4 5 7))
private theorem q10Shape15T269OK : fastTreeOK (forms 15) 33554952 230686720 q10Shape15T269=true := by decide

private def q10Shape15T251 : Tree := .split 9 q10Shape15T252 q10Shape15T269
private theorem q10Shape15T251OK : fastTreeOK (forms 15) 33554440 230686720 q10Shape15T251=true := by
  change (fastTreeOK (forms 15) 33554440 (230686720 ||| 2^9) q10Shape15T252 &&
    fastTreeOK (forms 15) (33554440 ||| 2^9) 230686720 q10Shape15T269)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T252OK,q10Shape15T269OK⟩

private def q10Shape15T185 : Tree := .split 3 q10Shape15T186 q10Shape15T251
private theorem q10Shape15T185OK : fastTreeOK (forms 15) 33554432 230686720 q10Shape15T185=true := by
  change (fastTreeOK (forms 15) 33554432 (230686720 ||| 2^3) q10Shape15T186 &&
    fastTreeOK (forms 15) (33554432 ||| 2^3) 230686720 q10Shape15T251)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T186OK,q10Shape15T251OK⟩

private def q10Shape15T270 : Tree := (.tip (.cover 0 1 6 7 9))
private theorem q10Shape15T270OK : fastTreeOK (forms 15) 167772160 96468992 q10Shape15T270=true := by decide

private def q10Shape15T184 : Tree := .split 27 q10Shape15T185 q10Shape15T270
private theorem q10Shape15T184OK : fastTreeOK (forms 15) 33554432 96468992 q10Shape15T184=true := by
  change (fastTreeOK (forms 15) 33554432 (96468992 ||| 2^27) q10Shape15T185 &&
    fastTreeOK (forms 15) (33554432 ||| 2^27) 96468992 q10Shape15T270)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T185OK,q10Shape15T270OK⟩

private def q10Shape15T271 : Tree := (.tip (.cover 0 1 6 8 9))
private theorem q10Shape15T271OK : fastTreeOK (forms 15) 100663296 29360128 q10Shape15T271=true := by decide

private def q10Shape15T183 : Tree := .split 26 q10Shape15T184 q10Shape15T271
private theorem q10Shape15T183OK : fastTreeOK (forms 15) 33554432 29360128 q10Shape15T183=true := by
  change (fastTreeOK (forms 15) 33554432 (29360128 ||| 2^26) q10Shape15T184 &&
    fastTreeOK (forms 15) (33554432 ||| 2^26) 29360128 q10Shape15T271)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T184OK,q10Shape15T271OK⟩

private def q10Shape15T3 : Tree := .split 25 q10Shape15T4 q10Shape15T183
private theorem q10Shape15T3OK : fastTreeOK (forms 15) 0 29360128 q10Shape15T3=true := by
  change (fastTreeOK (forms 15) 0 (29360128 ||| 2^25) q10Shape15T4 &&
    fastTreeOK (forms 15) (0 ||| 2^25) 29360128 q10Shape15T183)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T4OK,q10Shape15T183OK⟩

private def q10Shape15T272 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape15T272OK : fastTreeOK (forms 15) 16777216 12582912 q10Shape15T272=true := by decide

private def q10Shape15T2 : Tree := .split 24 q10Shape15T3 q10Shape15T272
private theorem q10Shape15T2OK : fastTreeOK (forms 15) 0 12582912 q10Shape15T2=true := by
  change (fastTreeOK (forms 15) 0 (12582912 ||| 2^24) q10Shape15T3 &&
    fastTreeOK (forms 15) (0 ||| 2^24) 12582912 q10Shape15T272)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T3OK,q10Shape15T272OK⟩

private def q10Shape15T273 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape15T273OK : fastTreeOK (forms 15) 8388608 4194304 q10Shape15T273=true := by decide

private def q10Shape15T1 : Tree := .split 23 q10Shape15T2 q10Shape15T273
private theorem q10Shape15T1OK : fastTreeOK (forms 15) 0 4194304 q10Shape15T1=true := by
  change (fastTreeOK (forms 15) 0 (4194304 ||| 2^23) q10Shape15T2 &&
    fastTreeOK (forms 15) (0 ||| 2^23) 4194304 q10Shape15T273)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T2OK,q10Shape15T273OK⟩

private def q10Shape15T274 : Tree := (.tip (.cover 0 1 7 8 9))
private theorem q10Shape15T274OK : fastTreeOK (forms 15) 4194304 0 q10Shape15T274=true := by decide

private def q10Shape15T0 : Tree := .split 22 q10Shape15T1 q10Shape15T274
private theorem q10Shape15T0OK : fastTreeOK (forms 15) 0 0 q10Shape15T0=true := by
  change (fastTreeOK (forms 15) 0 (0 ||| 2^22) q10Shape15T1 &&
    fastTreeOK (forms 15) (0 ||| 2^22) 0 q10Shape15T274)=true
  rw [Bool.and_eq_true]
  exact ⟨q10Shape15T1OK,q10Shape15T274OK⟩


theorem q10Shape15_cover (b : Nat→Bool) (H : Ranked (adj (forms 15) b)) :
    ∃ u v w z t,Effective (adj (forms 15) b) (adj (forms 15) b) u v w z t :=
  checked_fastTree (forms 15) b H q10Shape15T0 q10Shape15T0OK

#print axioms q10Shape15_cover
end Graffiti384b.Q10
